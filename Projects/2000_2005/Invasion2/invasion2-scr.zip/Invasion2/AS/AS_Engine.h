#ifndef __AS_ENGINE_H__
#define __AS_ENGINE_H__


// Definitions: ***************************************************************
#define AS_WINDOW_NAME "AS-Engine"
enum {MODULE_GAME};
#define AS_GAME_INFO_FILE "Game.ini" // Game information file
#define AS_LOG_FILE "Log.html"
#define GAME_NAME "Invasion2"
#define GAME_VERSION "V1.1" // Program version
#define GAME_WINDOW_NAME "Invasion2"
#define ASO_FILE "Object files (*.aso)\0*.aso\0"
#define TGA_FILE "BMP files (*.bmp)\0*.bmp\0"
///////////////////////////////////////////////////////////////////////////////
// Includes: ******************************************************************
#include "AS_BibIncludes.h"
#include "..\Resource.h"
#include "AS_Window.h"
#include "AS_OpenGL.h"
#include "AS_Config.h"
#include "AS_Sound.h"
#include "AS.h"
#include "AS_Object.h"
#include "..\WindowProc.h"
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_ENGINE__
#ifndef __AS_H__
#define __AS_H__


// Definitions: ***************************************************************
enum {X, Y, Z};
#define PI            3.14159265358979
#define PId2          1.5707963279489
///////////////////////////////////////////////////////////////////////////////
// Structures: ****************************************************************
typedef struct AS_TEXTURE
{
	char byFilename[256]; // The filename of the texture
	BYTE *pbyData; // The texture data
	int iColorDepth; // Color depth
	int iWidth, iHeight; // The size of the texture
	int iID; // The ID
	GLuint iOpenGLID; // The OpenGL ID
	int iUsed; // How often is this texture used?
	GLenum iFormat; // The texture format RGB or RGBA
	int iImageBits; // The number of image bit depth
	char byColorComponents; // The number of color components
	BOOL bNoMipmap; // This texture should never used as mipmap (maybe there are some graphic bugs...)

} AS_TEXTURE;
///////////////////////////////////////////////////////////////////////////////
// Classes: *******************************************************************
typedef class
{
	public:
		char byVersion[128], byDate[128], byTime[128];

		void Init(void);
} AS_PROGRAM_INFO;

typedef class AS_ENGINE
{
	HINSTANCE hInstance;
    LPSTR lpCmdLine;
	int iCmdShow;
	HANDLE hMutex;
	int iWindows;
	BOOL bShutDown;
	BOOL bActive;
	int iModule;
	int iNextModule;
	
	SYSTEMTIME StartTime;
	DWORD dwFPSTimeNow, dwFPSTimeLast, dwFPSTimeDifference;
	int iFPSRenderedFrames, iFPSFramesSinceCheck, iFPS;
	BOOL bMainWindow; // Is there a main window?
	// The Log:
	FILE *pLogFile;

	public:
		AS_ENGINE(HINSTANCE, LPSTR, int, BOOL);
		~AS_ENGINE(void);

		void WriteLog(const char *, ...);
		void WriteLogMessage(const char *, ...);
		HWND ASCreateWindow(WNDPROC, LPCTSTR, LPCTSTR, DWORD, DWORD, HMENU, BOOL,							HRESULT (*)(AS_WINDOW *), HRESULT (*)(AS_WINDOW *),
							HBRUSH, BOOL, BOOL);
		HRESULT ASDestroyWindow(HWND *, LPCTSTR);
		HRESULT EnumerateDisplayModeInfos(void);
		HRESULT AddDisplayModeInfo(DEVMODE);
		HRESULT DestroyDisplayModeInfo(void);
		void UpdateWindows(void);
		int FindWindowID(HWND);
		int UpdateFPS(void);
		void ShowMouseCursor(BOOL);

		HINSTANCE GetInstance(void) { return hInstance; }
		LPSTR GetCmdLine(void) { return lpCmdLine; };
		int GetCmdShow(void) { return iCmdShow; };
		BOOL GetShutDown(void) { return bShutDown; }
		void SetShutDown(BOOL bState) { bShutDown = bState; }
		BOOL GetActive(void) { return bActive; }
		void SetActive(BOOL bState) { bActive = bState; }
		void SetModule(int iModuleT) { iModule = iNextModule = iModuleT; }
		int GetModule(void) { return iModule; }
		void SetNextModule(int iNextModuleT) { iNextModule = iNextModuleT; }
		int GetNextModule(void) { return iNextModule; }
		BOOL CheckModuleChange(void) { if(iModule != iNextModule) return TRUE; return FALSE; }
		int GetWindows(void) { return iWindows; }

		int GetFPS(void) { return iFPS; };

		AS_WINDOW *pWindow;
		LPTSTR pbyProgramPath;
		LPTSTR pbyProgramExeName;
		LPTSTR pbyProgramDrive;
		LPTSTR pbyProgramDir;
		LPTSTR pbyUserName;
		BOOL bLog;
		LPTSTR pbyLogFile;
		LPTSTR pbyConfigFile;
		LPTSTR pbyHighscoreFile;
		LPTSTR pbyObjectsFile;
		LPTSTR pbyBitmapsFile;
		LPTSTR pbyMusicFile;
		BOOL bSoundPossible;

	friend AS_WINDOW;
} AS_ENGINE;

typedef class AS_CAMERA
{
	float fPos[3];

	public:
		AS_CAMERA(void);
		~AS_CAMERA(void);

		void SetPos(float, float, float);
		void Move(float, float, float);
		float GetXPos(void) { return fPos[X]; }
		float GetYPos(void) { return fPos[Y]; }
		float GetZPos(void) { return fPos[Z]; }

} AS_CAMERA;


#define ASO_FILE "Object files (*.aso)\0*.aso\0"

typedef float FLOAT3[3];
typedef float FLOAT2[2];
typedef int INT2[2];
typedef int INT3[3];
typedef int SHORT2[2];
typedef int SHORT3[3];
typedef float MATRIX[4][4];

extern BOOL ASPlayMidi(HWND, char *);
extern BOOL ASStopMidi(void);
extern void NormalizeFace(FLOAT3 *, FLOAT3, FLOAT3, FLOAT3);

#define SubtVer(AB, a, b)\
	((AB)[X] = (b)[X]-(a)[X],\
     (AB)[Y] = (b)[Y]-(a)[Y],\
     (AB)[Z] = (b)[Z]-(a)[Z])
#define CrossProductVer(AB, a, b)\
	((AB)[X] = (a)[Y]*(b)[Z]-(a)[Z]*(b)[Y],\
     (AB)[Y] = (a)[Z]*(b)[X]-(a)[X]*(b)[Z],\
     (AB)[Z] = (a)[X]*(b)[Y]-(a)[Y]*(b)[X])
#define glEnableLighting() if(_ASConfig->byLight != 0) { glEnable(GL_LIGHTING); }


///////////////////////////////////////////////////////////////////////////////
// Variables: *****************************************************************
extern AS_PROGRAM_INFO _ASProgramInfo;
extern AS_ENGINE *_AS;
extern AS_CAMERA *_ASCamera;
extern UCHAR ASKeys[256];
// Path Info
extern char ExeName[_MAX_PATH];
extern char Drive[_MAX_DRIVE];
extern char Dir[_MAX_DIR];
extern char Directory[_MAX_DRIVE+_MAX_DIR];
// OpenGL Info
extern char *pbyOpenGLVersion, *pbyOpenGLChipInfo, *pbyOpenGLRendererInfo, *pbyOpenGLExtensionInfo;
// General speed variables
extern long g_lProgramStartTime;
extern long g_lGameLength;
extern long g_lNow;
extern long g_lLastlooptime;
extern long g_lDeltatime;
extern int AS_WINDOW_ID;
// Math stuff:
extern const double ltconvertdegtorad;
///////////////////////////////////////////////////////////////////////////////
// Functions: *****************************************************************
extern void NormalizeFace(FLOAT3 *, FLOAT3, FLOAT3, FLOAT3);
extern HRESULT ASDraw(AS_WINDOW *);
extern HRESULT ASCheck(AS_WINDOW *);
extern void ASSwapBuffers(HDC);
extern char *ASGetFileName(HWND,  char *, char *, BOOL, BOOL);
extern BOOL ASLoadTGA(AS_TEXTURE *, char *);
extern BOOL ASLoadJpegRGB(AS_TEXTURE *, char *);
extern void ASLoadTextures(char (*)[256], int, AS_TEXTURE *);
extern void ASDestroyTextures(int, AS_TEXTURE *);
extern void ASGenOpenGLTextures(int, AS_TEXTURE *);
extern void ASDestroyOpenGLTextures(int, AS_TEXTURE *);
///////////////////////////////////////////////////////////////////////////////



#endif // __AS__
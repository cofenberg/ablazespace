#include "AS_Engine.h"

AS_TEXTURE FontTexture;


GLvoid AS_WINDOW::BuildFont(GLvoid)								// Build Our Font Display List
{
	float	cx;											// Holds Our X Character Coord
	float	cy;											// Holds Our Y Character Coord
	short loop;
	char byTemp[256];
	
	sprintf(byTemp, "%s%s\\Font.jpg", _AS->pbyProgramPath, _AS->pbyBitmapsFile);
	ASLoadJpegRGB(&FontTexture, byTemp);
	ASGenOpenGLTextures(1, &FontTexture);

	iFontBase=glGenLists(256);							// Creating 256 Display Lists
	glBindTexture(GL_TEXTURE_2D, FontTexture.iOpenGLID);		// Select Our Font Texture
	for (loop=0; loop<256; loop++)						// Loop Through All 256 Lists
	{
		cx=float(loop%16)/16.0f;						// X Position Of Current Character
		cy=float(loop/16)/16.0f;						// Y Position Of Current Character

		glNewList(iFontBase+loop,GL_COMPILE);			// Start Building A List
			glBegin(GL_QUADS);							// Use A Quad For Each Character
				glTexCoord2f(cx,1-cy-0.0625f);			// Texture Coord (Bottom Left)
				glVertex2i(0,0);						// Vertex Coord (Bottom Left)
				glTexCoord2f(cx+0.0625f,1-cy-0.0625f);	// Texture Coord (Bottom Right)
				glVertex2i(16,0);						// Vertex Coord (Bottom Right)
				glTexCoord2f(cx+0.0625f,1-cy);			// Texture Coord (Top Right)
				glVertex2i(16,16);						// Vertex Coord (Top Right)
				glTexCoord2f(cx,1-cy);					// Texture Coord (Top Left)
				glVertex2i(0,16);						// Vertex Coord (Top Left)
			glEnd();									// Done Building Our Quad (Character)
			glTranslated(10,0,0);						// Move To The Right Of The Character
		glEndList();									// Done Building The Display List
	}													// Loop Until All 256 Are Built
}

GLvoid AS_WINDOW::KillFont(GLvoid)									// Delete The Font From Memory
{
	glDeleteTextures(1, &FontTexture.iOpenGLID);				// Kill The Textures
	if(FontTexture.pbyData)
		free(FontTexture.pbyData);
	glDeleteLists(iFontBase,256);						// Delete All 256 Display Lists
}

GLvoid AS_WINDOW::glPrint(GLint x, GLint y, char *string, int set)	// Where The Printing Happens
{
	if (set>1)
		set=1;
	glBindTexture(GL_TEXTURE_2D, FontTexture.iOpenGLID);		// Select Our Font Texture
	glDisable(GL_DEPTH_TEST);							// Disables Depth Testing
	glMatrixMode(GL_PROJECTION);						// Select The Projection Matrix
	glPushMatrix();										// Store The Projection Matrix
	glLoadIdentity();									// Reset The Projection Matrix
	glOrtho(0,640,0,480,-100,100);						// Set Up An Ortho Screen
	glMatrixMode(GL_MODELVIEW);							// Select The Modelview Matrix
	glPushMatrix();										// Store The Modelview Matrix
	glLoadIdentity();									// Reset The Modelview Matrix
	glTranslated(x,y,0);								// Position The Text (0,0 - Bottom Left)
	glListBase(iFontBase-32+(128*set));					// Choose The Font Set (0 or 1)
	glCallLists(strlen(string),GL_BYTE,string);			// Write The Text To The Screen
	glMatrixMode(GL_PROJECTION);						// Select The Projection Matrix
	glPopMatrix();										// Restore The Old Projection Matrix
	glMatrixMode(GL_MODELVIEW);							// Select The Modelview Matrix
	glPopMatrix();										// Restore The Old Projection Matrix
	glEnable(GL_DEPTH_TEST);							// Enables Depth Testing
}

// AS_WINDOW functions: *******************************************************
HWND AS_WINDOW::ASCreateWindow(WNDPROC WindowProc,
							   LPCTSTR pbyTitle,
							   LPCTSTR pbyName,
							   DWORD dwWidth,
							   DWORD dwHeight,
			   				   HMENU Menu,
							   BOOL bFullScreen,
							   HRESULT (*pDrawTemp)(AS_WINDOW *),
							   HRESULT (*pCheckTemp)(AS_WINDOW *),
							   HBRUSH hBackground, 
							   BOOL bToolbox,
							   BOOL bIsMainWindowT)
{ // begin AS_WINDOW::ASCreateWindow()
    WNDCLASS wc;
	DWORD dwStyle, dwExStyle;

	bDeactivated = FALSE;
	bIsMainWindow = bIsMainWindowT;
	pDraw = pDrawTemp;
	pCheck = pCheckTemp;
	if(bFullScreen)
	{
		dwExStyle = WS_EX_APPWINDOW;
		dwStyle = WS_POPUP;
		_AS->ShowMouseCursor(FALSE);
		Menu = FALSE;
		dwWidth = _ASConfig->DevMode.dmPelsWidth;
		dwHeight = _ASConfig->DevMode.dmPelsHeight;
	}
	else
	{
		dwExStyle = WS_EX_APPWINDOW | WS_EX_WINDOWEDGE | WS_EX_DLGMODALFRAME;
		if(bToolbox)
			dwStyle = WS_OVERLAPPED | WS_SYSMENU;
		else
			dwStyle = WS_OVERLAPPEDWINDOW;
		SetCursor(LoadCursor(NULL, IDC_ARROW));
		_AS->ShowMouseCursor(TRUE);
	}
	// Set up and register window class
    wc.style = CS_HREDRAW | CS_VREDRAW | CS_OWNDC | CS_PARENTDC;
    wc.lpfnWndProc = WindowProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = _AS->hInstance;
    wc.hIcon = LoadIcon(_AS->hInstance, MAKEINTRESOURCE(IDI_ICON));
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = (HBRUSH) hBackground;
    wc.lpszMenuName = NULL;
    wc.lpszClassName = pbyName;
    RegisterClass(&wc);
    if(bToolbox)
		dwExStyle |= WS_EX_TOOLWINDOW;
	hWnd = CreateWindowEx(dwExStyle,
						  pbyName,
						  pbyTitle,
						  dwStyle |
						  WS_CLIPSIBLINGS |
						  WS_CLIPCHILDREN,
						  0,
						  0,
						  dwWidth,
						  dwHeight,
						  NULL,
						  Menu,
						  _AS->hInstance,
						  NULL);
	iWidth = dwWidth;
	iHeight = dwHeight;
	SendMessage(hWnd, WM_INITDIALOG, 0, 0);
	return hWnd;
} // end AS_WINDOW::ASCreateWindow()

HRESULT AS_WINDOW::ASDestroyWindow(HWND *hWnd, LPCTSTR pbyName)
{ // begin AS_WINDOW::ASDestroyWindow()
	if(*hWnd && !DestroyWindow(*hWnd))
	{
		MessageBox(NULL,"Could not release hWnd.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		return 1;
	}
	if(!UnregisterClass(pbyName, _AS->hInstance))
	{
		MessageBox(NULL,"Could not unregister class.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		return 1;
 	}
	*hWnd = NULL;
	return 0;
} // end AS_WINDOW::ASDestroyWindow()

HRESULT AS_WINDOW::Draw(void)
{ // begin AS_WINDOW::Draw()
	if(bDeactivated)
		return 0;
/* You need this only if you handle with more than 1 windows: (costs a little bit speed)
	if(!wglMakeCurrent(hDC, hRC))
		return 1;
*/
	if(!pDraw)
		return 0;
	return pDraw(pWindow);
} // end AS_WINDOW::Draw()

HRESULT AS_WINDOW::Check(void)
{ // begin AS_WINDOW::Check()
	if(bDeactivated)
		return 0;
/* You need this only if you handle with more than 1 windows: (costs a little bit speed)
	if(!wglMakeCurrent(hDC, hRC))
		return 1;
*/
	if(pCheck)
		return pCheck(pWindow);
	return 0;
} // end AS_WINDOW::Check()

void AS_WINDOW::Resize(int iWidthT, int iHeightT)
{ // begin AS_WINDOW::Resize()
	_AS->WriteLogMessage("Resizing window(ID: %d)", iID);
	if(!wglMakeCurrent(hDC, hRC))
		return;
	iWidth = iWidthT;
	iHeight = iHeightT;
	ASConfigOpenGL(iWidth, iHeight);
} // end AS_WINDOW::Resize()

void makeBGR (unsigned char *p, int size)
{
	unsigned char temp;
	int i;

	for (i = 0; i < size * 3; i += 3)
	{
		temp = p[i];
		p[i] = p[i + 2];
		p[i + 2] = temp;
	}
}

void writeTGA (char *name, unsigned char *buff, int w, int h)
{
	unsigned char *header;
	unsigned char info[6];
	
	header = new UCHAR [14];
	strcpy((char *)header, "\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00");
	
	FILE *s;

	s = fopen (name, "w");

	// write the header to the file
	fwrite (header, sizeof (char), 12, s);
	
	// image dimension information
	info[0] = w;
	info[1] = (w >> 8);
	info[2] = h;
	info[3] = (h >> 8);
	info[4] = 24;
	info[5] = 0;
	
	// write dimension info to file
	fwrite (&info, sizeof (char), 6, s);
	
	// since the frame buffer is RGB we need to convert it to BGR for a targa file
	makeBGR (buff, w * h);

	// dump the image data to the file
	fwrite (buff, sizeof (char), w * h * 3, s);

	fclose (s);

	delete header;
}

void AS_WINDOW::MakeScreenshot(char *pbyFilename)
{ // begin AS_WINDOW::MakeScreenshot()
	FILE *fp;
	char byTemp[256], byFilename[256];
	int i;
	BYTE *pbyBuffer;

	if(!wglMakeCurrent(hDC, hRC))
		return;
	_AS->WriteLogMessage("Make screenshot from window(ID: %d)", iID);
	pbyBuffer = (BYTE *) malloc((iWidth+1)*(iHeight+1)*3);
	if(!pbyBuffer)
	{
		_AS->WriteLogMessage("Couldn't make screenshot from window(ID: %d)", iID);
		return;
	}
	if(!pbyFilename)
	{ // Use default screenshot name:
		for(i = 0;; i++)
		{
			sprintf(byTemp, "shot%d.tga", i);
			fp = fopen(byTemp, "r");
			if(!fp)
				break;
		}
		strcpy(byFilename, byTemp);		
	}
	else
		strcpy(byFilename, pbyFilename);
	// Save screenshot:
	glReadBuffer(GL_FRONT);
	glReadPixels(0, 0, iWidth, iHeight, GL_RGB, GL_UNSIGNED_BYTE, pbyBuffer);
	writeTGA(byFilename, pbyBuffer, iWidth, iHeight);
	free(pbyBuffer);
	_AS->WriteLogMessage("Screenshot success");
} // end AS_WINDOW::MakeScreenshot()
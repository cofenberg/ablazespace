#include "AS_Engine.h"


// Variables: *****************************************************************
AS_PROGRAM_INFO _ASProgramInfo;
AS_ENGINE *_AS;
AS_CAMERA *_ASCamera;
UCHAR ASKeys[256];
// OpenGL Info
char *pbyOpenGLVersion, *pbyOpenGLChipInfo, *pbyOpenGLRendererInfo, *pbyOpenGLExtensionInfo;
// General speed variables
long g_lProgramStartTime	= 0;		// The Program Start Time
long g_lGameLength			= 0;		// Application Run Time Variable
long g_lNow	                = 0;		// The Actual Time
long g_lLastlooptime		= 0;		// Time When Last Loop Was Started
long g_lDeltatime			= 0;		// Change In Time Since Last Iteration
int AS_WINDOW_ID;
// Math stuff:
const double ltconvertdegtorad	= 0.0174532925199432957692369076848861;
///////////////////////////////////////////////////////////////////////////////
// Functions: *****************************************************************
BOOL ASPlayMidi(HWND, char *);
BOOL ASStopMidi(void);
void NormalizeFace(FLOAT3 *, FLOAT3, FLOAT3, FLOAT3);
HRESULT ASDraw(AS_WINDOW *);
HRESULT ASCheck(AS_WINDOW *);
void ASSwapBuffers(HDC);
char *ASGetFileName(HWND,  char *, char *, BOOL, BOOL);
BOOL ASLoadTGA(AS_TEXTURE *, char *);
BOOL ASLoadJpegRGB(AS_TEXTURE *, char *);
void ASLoadTextures(char (*)[256], int, AS_TEXTURE *);
void ASDestroyTextures(int, AS_TEXTURE *);
void ASGenOpenGLTextures(int, AS_TEXTURE *);
void ASDestroyOpenGLTextures(int, AS_TEXTURE *);
///////////////////////////////////////////////////////////////////////////////


BOOL ASPlayMidi(HWND hWnd, char *sFileName)
{
    if(!_ASConfig->bMusic)
		return 0;
    char buf[256];
    sprintf(buf, "open %s type sequencer alias MUSIC", sFileName);
    if(mciSendString("close all", NULL, 0, NULL) != 0)
        return FALSE;
    if(mciSendString(buf, NULL, 0, NULL) != 0)
        return FALSE;
    if(mciSendString("play MUSIC from 0", NULL, 0, hWnd) != 0)
        return FALSE;
    return TRUE;
}

BOOL ASStopMidi(void)
{
    if(mciSendString("close all", NULL, 0, NULL) != 0)
        return FALSE;
    return TRUE;
}

void NormalizeFace(FLOAT3 *ResultV, FLOAT3 V1, FLOAT3 V2, FLOAT3 V3)
{
	FLOAT3 V1_V2, V1_V3;
	float fLength;

	SubtVer(V1_V2, V1, V2);
	SubtVer(V1_V3, V1, V3);
	CrossProductVer(*ResultV, V1_V2, V1_V3);
	fLength = (float) sqrt((*ResultV)[X]*(*ResultV)[X]+(*ResultV)[Y]*(*ResultV)[Y]+(*ResultV)[Z]*(*ResultV)[Z]);
	(*ResultV)[X] /= fLength;
	(*ResultV)[Y] /= fLength;
	(*ResultV)[Z] /= fLength;
}

// AS_PROGRAM_INFO functions: *************************************************
void AS_PROGRAM_INFO::Init(void)
{ // begin AS_PROGRAM_INFO()
	strcpy(byVersion, GAME_VERSION);
	strcpy(byDate, __DATE__);
	strcpy(byTime, __TIME__);
} // end AS_PROGRAM_INFO()


// AS_ENGINE functions: *******************************************************
AS_ENGINE::AS_ENGINE(HINSTANCE hInstanceT, LPSTR lpCmdLineT, int iCmdShowT, BOOL bOnlyOne)
{ // begin AS_ENGINE::AS_ENGINE()
	DWORD i = MAX_PATH;
	char byTemp[256];
	BOOL bTemp;
	SYSTEM_INFO SystemInfo;
	OSVERSIONINFO VersionInformation;

	// Init all:
	memset((this), 0, sizeof(AS_ENGINE));
	_AS = this;
	GetLocalTime(&StartTime);
	// Set important stuff
	hInstance = hInstanceT;
	lpCmdLine = lpCmdLineT;
	iCmdShow = iCmdShowT;
    hMutex = OpenMutex(SYNCHRONIZE, FALSE, GAME_NAME);
    if(hMutex)
    {
        if(bOnlyOne)
		{
			CloseHandle(hMutex);
			sprintf(byTemp, GAME_NAME" is running twice!!");
			MessageBox(0, byTemp, GAME_NAME, MB_ICONERROR | MB_OK);
			bShutDown = TRUE;
			return;
		}
    }
    else
        hMutex = CreateMutex(NULL, TRUE, GAME_NAME);
	SetPriorityClass(hInstance, 31);
	SetThreadPriority(hInstance, 31);
	_ASProgramInfo.Init();
	iWindows = 0;
	pWindow = NULL;
	bShutDown = FALSE;
	bActive = TRUE;
	// Initalize The Random Generator
	srand((unsigned) time(NULL));
  	pbyProgramPath = new char[_MAX_DRIVE+_MAX_DIR];
	pbyProgramExeName = new char[MAX_PATH];
	pbyProgramDrive = new char[_MAX_DRIVE];
	pbyProgramDir = new char[_MAX_DIR];
  	pbyUserName = new char[MAX_PATH];
	pbyLogFile = new char[MAX_PATH];
	pbyConfigFile = new char[MAX_PATH];
  	pbyHighscoreFile = new char[MAX_PATH];
  	pbyObjectsFile = new char[MAX_PATH];
  	pbyBitmapsFile = new char[MAX_PATH];
  	pbyMusicFile = new char[MAX_PATH];
	// Find Path Info
	GetModuleFileName(hInstance, pbyProgramExeName, MAX_PATH);
	_splitpath(pbyProgramExeName, pbyProgramDrive, pbyProgramDir, NULL, NULL);
	sprintf(pbyProgramPath, "%s%s", pbyProgramDrive, pbyProgramDir);
	SetCurrentDirectory(pbyProgramPath);
	GetUserName(pbyUserName, &i);
    // Loads the game stuff:
	sprintf(byTemp, "%sGame.ini", pbyProgramPath);
	bLog = GetPrivateProfileInt("General", "log", 1, byTemp);
	GetPrivateProfileString("General", "log_file", "Log.html", pbyLogFile, MAX_PATH, byTemp);
	GetPrivateProfileString("General", "config_file", "Config.ini", pbyConfigFile, MAX_PATH, byTemp);
	GetPrivateProfileString("General", "highscore_file", "Highscore.dat", pbyHighscoreFile, MAX_PATH, byTemp);
	GetPrivateProfileString("General", "objects_file", "Data\\Objects", pbyObjectsFile, MAX_PATH, byTemp);
	GetPrivateProfileString("General", "bitmaps_file", "Data\\Bitmaps", pbyBitmapsFile, MAX_PATH, byTemp);
	GetPrivateProfileString("General", "music_file", "Data\\Music", pbyMusicFile, MAX_PATH, byTemp);
	if(bLog)
	{
		// Open the Log:
		bTemp = _ASConfig->bLog;
		_ASConfig->bLog = TRUE;
		pLogFile = fopen(AS_LOG_FILE, "wt");
		if(!pLogFile)
		{
			MessageBox(NULL, "Couldn't open or create: "AS_LOG_FILE"\n(Maybe used by an other program...)\n", "ERROR", MB_OK | MB_ICONINFORMATION);
			bShutDown = TRUE;
			return;
		}
		// Create Header:
		WriteLog("<HTML>");
		WriteLog("<HEAD>");
		WriteLog("<TITLE>Log</TITLE>");
		WriteLog("</HEAD>");
		WriteLog("<BODY>");
		////////////////////////////////////
		WriteLog("<P ALIGN=\"CENTER\"><FONT SIZE=\"+1\" COLOR=\"#0080FF\"><U><B>Log-System activated</B></U></FONT></P>");
		WriteLog("<P ALIGN=\"CENTER\"><B><FONT SIZE=\"+1\"><B><U>Program start time:</B></U> Date: %d.%d.%d - Time: %d:%d:%d:%d</FONT></B></P>", StartTime.wMonth, StartTime.wDay, StartTime.wYear, 
																											  StartTime.wHour, StartTime.wMinute, 
																											  StartTime.wSecond, StartTime.wMilliseconds);
		////////////////////////////////////
		WriteLog("<P ALIGN=\"CENTER\"><FONT SIZE=\"+4\"><U><B><I><FONT COLOR=\"#FF0000\">%s %s<FONT></I></B></U></FONT></FONT></P>", GAME_NAME, GAME_VERSION);
		WriteLog("<P ALIGN=\"CENTER\"><B><FONT SIZE=\"+1\">Build: %s %s</FONT></B></P>", _ASProgramInfo.byDate, _ASProgramInfo.byTime);
		// Print out the general system info:
		WriteLog("<P ALIGN=\"CENTER\"><FONT SIZE=\"+2\"><U><B>General system info:</B></U></FONT></P>");
		WriteLog("<TABLE WIDTH=\"1000\">");
		WriteLogMessage("User name: %s", pbyUserName);
	}
	GetSystemInfo(&SystemInfo);
	GetVersionEx(&VersionInformation);
	switch(VersionInformation.dwPlatformId)
	{
		case VER_PLATFORM_WIN32_WINDOWS: 
			if(!VersionInformation.dwMinorVersion)
				WriteLogMessage("System platform: Windows 95");
			else
				WriteLogMessage("System platform: Windows 98 or higher");
		break;
		case VER_PLATFORM_WIN32_NT: WriteLogMessage("System platform: Windows NT"); break;
	}
	WriteLogMessage("Number of processors: %d", SystemInfo.dwNumberOfProcessors);
	sprintf(byTemp, "OEM ID: %d", SystemInfo.dwOemId);
	WriteLogMessage(byTemp);	
	switch(SystemInfo.dwProcessorType)
	{
		case PROCESSOR_INTEL_386: sprintf(byTemp, "INTEL 386"); break;
		case PROCESSOR_INTEL_486: sprintf(byTemp, "INTEL 486"); break;
		case PROCESSOR_INTEL_PENTIUM: sprintf(byTemp, "INTEL PENTIUM"); break;
		case PROCESSOR_MIPS_R4000: sprintf(byTemp, "MIPS R4000"); break;
		case PROCESSOR_ALPHA_21064: sprintf(byTemp, "ALPHA 21064"); break;
	}
	WriteLogMessage("Processor type: %s", byTemp);
	if(IsProcessorFeaturePresent(PF_FLOATING_POINT_EMULATED))
		WriteLogMessage("Floating-point operations are emulated using a software");
	else
		WriteLogMessage("Floating-point operations are not emulated using a software");
	if(!IsProcessorFeaturePresent(PF_MMX_INSTRUCTIONS_AVAILABLE))
		WriteLogMessage("MMX is available");
	else
		WriteLogMessage("MMX isn't available");
	if(GetSystemMetrics(SM_NETWORK))
		WriteLogMessage("There is a network");
	else
		WriteLogMessage("There is no network");
	if(GetSystemMetrics(SM_MOUSEPRESENT))
		WriteLogMessage("There is a mouse");
	else
		WriteLogMessage("There is no mouse");
	sprintf(byTemp, "Number of mouse buttons: %d", GetSystemMetrics(SM_CMOUSEBUTTONS));
	WriteLogMessage(byTemp);	
	sprintf(byTemp, "Display resolution: %dx%d", GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN));
	WriteLogMessage(byTemp);
	WriteLog("</TABLE>");
	// Print out path info:
	WriteLog("<P ALIGN=\"CENTER\"><FONT SIZE=\"+2\"><U><B>File info:</B></U></FONT></P>");
	WriteLog("<TABLE WIDTH=\"1000\">");
	WriteLog("<TR><TD><B><U>Program path:</B></U> %s</TD></TR>", pbyProgramPath);
	WriteLog("<TR><TD><B><U>Game info file:</B></U> "AS_GAME_INFO_FILE"</TD></TR>");
	WriteLog("<TR><TD><B><U>Log file:</B></U> %s</TD></TR>", pbyLogFile);
	WriteLog("<TR><TD><B><U>Config file:</B></U> %s</TD></TR>", pbyConfigFile);
	WriteLog("<TR><TD><B><U>Highscore file:</B></U> %s</TD></TR>", pbyHighscoreFile);
	WriteLog("<TR><TD><B><U>Objects file:</B></U> %s</TD></TR>", pbyObjectsFile);
	WriteLog("<TR><TD><B><U>Bitmaps file:</B></U> %s</TD></TR>", pbyBitmapsFile);
	WriteLog("<TR><TD><B><U>Music file:</B></U> %s</TD></TR>", pbyMusicFile);
	WriteLog("</TABLE>");
	WriteLog("<P ALIGN=\"CENTER\"><FONT SIZE=\"+2\"><U><B>Messages:</B></U></FONT></P>");
	WriteLog("<TABLE WIDTH=\"1000\">");
    // Init FPS:
	dwFPSTimeNow = GetTickCount();
	dwFPSTimeLast = GetTickCount();
	dwFPSTimeDifference = 0;
	iFPSRenderedFrames = iFPSFramesSinceCheck = iFPS = 0;
	EnumerateDisplayModeInfos();
	// Get the OpenGL stuff:
	WriteLogMessage("Get OpenGL information");
	ASCreateWindow(WindowProc, AS_WINDOW_NAME, AS_WINDOW_NAME, 400, 1, NULL, FALSE, ASDraw, ASCheck, NULL, FALSE, TRUE);
	AS_WINDOW_ID = _AS->GetWindows()-1;
	ASInitOpenGL(&_AS->pWindow[AS_WINDOW_ID],
				 NULL,
				 _AS->pWindow[AS_WINDOW_ID].GethDC(),
				 _AS->pWindow[AS_WINDOW_ID].GethRC(), _ASConfig->bFullScreen);
	ShowWindow(*_AS->pWindow[AS_WINDOW_ID].GethWnd(), SW_SHOW);	
	ASDestroyOpenGL(&_AS->pWindow[AS_WINDOW_ID],
					NULL,
				    *_AS->pWindow[AS_WINDOW_ID].GethDC(),
				    *_AS->pWindow[AS_WINDOW_ID].GethRC());
	ASDestroyWindow(_AS->pWindow[AS_WINDOW_ID].GethWnd(), AS_WINDOW_NAME);
	WriteLogMessage("OpenGL information received");
	// Print out the OpenGL information:
	WriteLogMessage("Show OpenGL information");
	WriteLogMessage("Version:");
	WriteLogMessage(pbyOpenGLVersion);
	WriteLogMessage("Chip info:");
	WriteLogMessage(pbyOpenGLChipInfo);
	WriteLogMessage("Renderer info:");
	WriteLogMessage(pbyOpenGLRendererInfo);
	WriteLogMessage("Extensions info:");
	WriteLogMessage(pbyOpenGLExtensionInfo);
	WriteLogMessage("That's all from OpenGL");
	// Init complete:
	WriteLogMessage("Init lookup tables");
	_ASConfig->bLog = bTemp;
	g_lProgramStartTime = GetTickCount();
} // end AS_ENGINE::AS_ENGINE()

AS_ENGINE::~AS_ENGINE(void)
{ // begin AS_ENGINE::~AS_ENGINE()
	BOOL bTemp;

	// Delete OpenGL Information
	if(pbyOpenGLVersion)
		delete pbyOpenGLVersion;
	pbyOpenGLVersion = NULL;
	// Chip Info
	if(pbyOpenGLChipInfo)
		delete pbyOpenGLChipInfo;
	pbyOpenGLChipInfo = NULL;
	// Renderer Info
	if(pbyOpenGLRendererInfo)
		delete pbyOpenGLRendererInfo;
	pbyOpenGLRendererInfo = NULL;
	// Extensions Info
	if(pbyOpenGLExtensionInfo)
		delete pbyOpenGLExtensionInfo;
	pbyOpenGLExtensionInfo = NULL;
	// Create last stuff:
  	if(pbyProgramPath)
		delete pbyProgramPath;
	if(pbyProgramExeName)
		delete pbyProgramExeName;
	if(pbyProgramDrive)
		delete pbyProgramDrive;
	if(pbyProgramDir)
		delete pbyProgramDir;
  	if(pbyUserName)
		delete pbyUserName;
	if(pbyConfigFile)
		delete pbyConfigFile;
  	if(pbyHighscoreFile)
		delete pbyHighscoreFile;
  	if(pbyObjectsFile)
		delete pbyObjectsFile;
  	if(pbyBitmapsFile)
		delete pbyBitmapsFile;
  	if(pbyMusicFile)
		delete pbyMusicFile;
	DestroyDisplayModeInfo();
	////////////////////////////////////
	if(bLog)
	{
		// Close the Log:
		bTemp = _ASConfig->bLog;
		_ASConfig->bLog = TRUE;
		WriteLogMessage("Shut down AS-Engine");
		WriteLog("</TABLE>");
		WriteLog("<P ALIGN=\"CENTER\"><FONT SIZE=\"+1\" COLOR=\"#0080FF\"><U><B>Log-System closed</B></U></FONT></P>");
		WriteLog("</BODY>\n");
		WriteLog("</HTML>\n");
		fclose(pLogFile);
		_ASConfig->bLog = bTemp;
	}
	////////////////////////////////////
} // end AS_ENGINE::~AS_ENGINE()

void AS_ENGINE::WriteLog(const char *pbyMessage, ...)
{ // begin AS_ENGINE::WriteLog()
	char byText[1000];
	va_list	list;

	if(!pLogFile || !_ASConfig->bLog || !bLog)
		return;
	va_start(list, pbyMessage);
		vsprintf(byText, pbyMessage, list);
	va_end(list);
	fprintf(pLogFile, byText);
	fflush(pLogFile);
} // end AS_ENGINE::WriteLog()

void AS_ENGINE::WriteLogMessage(const char *pbyMessage, ...)
{ // begin AS_ENGINE::WriteLogMessage()
	char byText[1000];
	va_list	list;

	if(!pLogFile || !_ASConfig->bLog || !bLog)
		return;
	va_start(list, pbyMessage);
		vsprintf(byText, pbyMessage, list);
	va_end(list);
	fprintf(pLogFile, "<TR><TD><FONT SIZE=\"+1\">%s</FONT></TD</TR>", byText);
	fflush(pLogFile);
} // end AS_ENGINE::WriteLogMessage()

HWND AS_ENGINE::ASCreateWindow(WNDPROC WindowProc,
							   LPCTSTR pbyTitle,
							   LPCTSTR pbyName,
							   DWORD dwWidth,
							   DWORD dwHeight,
			   				   HMENU Menu,
							   BOOL bFullScreen,
							   HRESULT (*pDrawTemp)(AS_WINDOW *),
							   HRESULT (*pCheckTemp)(AS_WINDOW *),
							   HBRUSH hBackground,
							   BOOL bToolbox,
							   BOOL bIsMainWindowT)
{ // begin AS_ENGINE::ASCreateWindow()
	HWND hWnd;
	int i;
		
	WriteLogMessage("Create window");
	if(bMainWindow && bIsMainWindowT)
	{
		WriteLogMessage("There is already a main window!");
		return NULL;
	}
	WriteLogMessage("Titel: %s", pbyTitle);
	WriteLogMessage("Name: %s", pbyName);
	WriteLogMessage("Width: %d", dwWidth);
	WriteLogMessage("Height: %d", dwHeight);
	WriteLogMessage("Full screen: %d", bFullScreen);
	iWindows++;
	pWindow = (AS_WINDOW *) realloc(pWindow, sizeof(AS_WINDOW)*iWindows);
	for(i = 0; i < iWindows; i++)
		pWindow[i].SetWindow(&pWindow[i]);
	hWnd = pWindow[iWindows-1].ASCreateWindow(WindowProc, 
											  pbyTitle,
											  pbyName,
											  dwWidth,
											  dwHeight,
											  Menu,
											  bFullScreen,
											  pDrawTemp,
											  pCheckTemp,
											  hBackground,
											  bToolbox,
											  bIsMainWindowT);
	pWindow[iWindows-1].SetID(iWindows-1);
	WriteLogMessage("Window(ID: %d) successful created", iWindows-1);
	if(!bMainWindow && bIsMainWindowT)
		bMainWindow = TRUE;
	return hWnd;
} // end AS_ENGINE::ASCreateWindow()

HRESULT AS_ENGINE::ASDestroyWindow(HWND *hWnd, LPCTSTR pbyName)
{ // begin AS_ENGINE::ASDestroyWindow()
	int i;
	LPTSTR lpClassName = new char[MAX_PATH];
	
	WriteLogMessage("Destroy window");
	WriteLogMessage("Name: %s", pbyName);
	if(!hWnd)
	{ // Find the window self:
		for(i = 0; i < iWindows; i++)
		{
			GetClassName(*pWindow[i].GethWnd(), lpClassName, MAX_PATH);
			if(!strcmp(lpClassName, pbyName))
			{ // We�ve found the window!
				HWND hTemp; 

				hTemp = *pWindow[i].GethWnd();
				hWnd = &hTemp;
				break;
			}
		}
	}
	if(!hWnd)
		return 1;
	for(i = 0; i < iWindows; i++)
		if(*pWindow[i].GethWnd() == *hWnd)
		{
			WriteLogMessage("ID: %d", i);
			if(pWindow[i].GetIsMainWindow())
				bMainWindow = FALSE;
			pWindow[i].ASDestroyWindow(hWnd, pbyName);			
			pWindow[i] = pWindow[iWindows-1];
			iWindows--;
			pWindow = (AS_WINDOW *) realloc(pWindow, sizeof(AS_WINDOW)*iWindows);
			WriteLogMessage("Window successful destroyed");
			return 0;
		}
	return 1;
} // end AS_ENGINE::ASDestroyWindow()

HRESULT AS_ENGINE::EnumerateDisplayModeInfos(void)
{ // begin AS_ENGINE::EnumerateDisplayModeInfos()
	int i;
	DEVMODE devMode;

	DestroyDisplayModeInfo();
	WriteLogMessage("Enumerate display modes...");
	for(i = 0;;i++) 
	{
		if(!EnumDisplaySettings(NULL, i, &devMode)) 
			break;
		AddDisplayModeInfo(devMode);
	}
	WriteLogMessage("Complete");
    return 0;
} // end AS_ENGINE::EnumerateDisplayModeInfos()

HRESULT AS_ENGINE::AddDisplayModeInfo(DEVMODE lpDevMode)
{ // begin AS_ENGINE::AddDisplayModeInfo()
	if(lpDevMode.dmBitsPerPel < 16)
		return 1;
	DisplayModeInfo.Number++;
	DisplayModeInfo.pDevMode = (DEVMODE *) realloc(DisplayModeInfo.pDevMode, sizeof(DEVMODE)*DisplayModeInfo.Number);
	if(!DisplayModeInfo.pDevMode)
		return 1;
	CopyMemory(&DisplayModeInfo.pDevMode[DisplayModeInfo.Number-1], &lpDevMode, sizeof(DEVMODE));
	WriteLogMessage("Found: %dx%dx%d", DisplayModeInfo.pDevMode[DisplayModeInfo.Number-1].dmPelsWidth,
									   DisplayModeInfo.pDevMode[DisplayModeInfo.Number-1].dmPelsHeight,
									   DisplayModeInfo.pDevMode[DisplayModeInfo.Number-1].dmBitsPerPel);
	return 0;
} // end AS_ENGINE::AddDisplayModeInfo()

HRESULT AS_ENGINE::DestroyDisplayModeInfo(void)
{ // begin AS_ENGINE::DestroyDisplayModeInfo()
	if(DisplayModeInfo.pDevMode)
		free(DisplayModeInfo.pDevMode);
	DisplayModeInfo.pDevMode = NULL;
	DisplayModeInfo.Number = 0;
	return 0;
} // end AS_ENGINE::DestroyDisplayModeInfo()

void AS_ENGINE::UpdateWindows(void)
{ // begin AS_ENGINE::UpdateWindows()
	int i;
	
	// Check the speed control stuff
	g_lNow = GetTickCount();
	g_lDeltatime = g_lNow-g_lLastlooptime;
	g_lLastlooptime = g_lNow;
	g_lGameLength = (g_lNow-g_lProgramStartTime)/1000;	
	if(g_lDeltatime > 100)
		g_lDeltatime = 100;
	// Check the windows
	for(i = 0; i < iWindows; i++)
	{
		pWindow[i].Draw();
		pWindow[i].Check();
	}
	UpdateFPS();
} // end AS_ENGINE::UpdateWindows()

int AS_ENGINE::FindWindowID(HWND hWnd)
{ // begin AS_ENGINE::FindWindowID()
	int i; 

	for(i = 0; i < iWindows; i++)
		if(*pWindow[i].GethWnd() == hWnd)
			return i;
	return -1;
} // end AS_ENGINE::FindWindowID()

int AS_ENGINE::UpdateFPS(void)
{ // begin AS_ENGINE::UpdateFPS()
	dwFPSTimeNow = GetTickCount();
	dwFPSTimeDifference = dwFPSTimeNow-dwFPSTimeLast;
	iFPSRenderedFrames++;
	iFPSFramesSinceCheck++;
	if(dwFPSTimeDifference > 1000)
	{
		dwFPSTimeLast = dwFPSTimeNow;
		iFPS = iFPSFramesSinceCheck;
		iFPSFramesSinceCheck = 0;
	}
    return iFPS;
} // end AS_ENGINE::UpdateFPS()

void AS_ENGINE::ShowMouseCursor(BOOL bState)
{ // begin AS_ENGINE::ShowMouseCursor()
	int i;
	
	// Disables/Enables the mouse cursor:
	if(!bState)
	{
		for(;;)
		{
			i = ShowCursor(FALSE);
			if(i < 0)
				break;
		}
	}
	else
	{
		for(;;)
		{
			i = ShowCursor(TRUE);
			if(i >= 0)
				break;
		}
	}
} // end AS_ENGINE::ShowMouseCursor()


// AS_CAMERA functions: *******************************************************
AS_CAMERA::AS_CAMERA(void)
{ // begin AS_CAMERA::AS_CAMERA()
} // end AS_CAMERA::AS_CAMERA()

AS_CAMERA::~AS_CAMERA(void)
{ // begin AS_CAMERA::~AS_CAMERA()
} // end AS_CAMERA::~AS_CAMERA()

void AS_CAMERA::SetPos(float fXPos, float fYPos, float fZPos)
{ // begin AS_CAMERA::SetPos()
	fPos[X] = fXPos;
	fPos[Y] = fYPos;
	fPos[Z] = fZPos;
} // end AS_CAMERA::SetPos()

void AS_CAMERA::Move(float fXPos, float fYPos, float fZPos)
{ // begin AS_CAMERA::Move()
	fPos[X] += fXPos;
	fPos[Y] += fYPos;
	fPos[Z] += fZPos;
} // end AS_CAMERA::Move()


// Functions: *****************************************************************
HRESULT ASDraw(AS_WINDOW *pWindow)
{ // begin ASDraw()
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	ASSwapBuffers(*pWindow->GethDC());
	return 0;
} // end ASDraw()

HRESULT ASCheck(AS_WINDOW *pWindow)
{ // begin ASCheck()
	return 0;
} // end ASCheck()

void ASSwapBuffers(HDC hDC)
{ // begin ASSwapBuffers()
	SwapBuffers(hDC);
} // end ASSwapBuffers()

char *ASGetFileName(HWND hWnd,  char *pbyTitle, char *pbyFilter, BOOL bMode, BOOL bMultiSelect)
{ // begin ASGetFileName()
    static char file[256];
    static char fileTitle[256];
    OPENFILENAME ofn;

    lstrcpy( file, "");
    lstrcpy( fileTitle, "");

    ofn.lStructSize       = sizeof(OPENFILENAME);
    ofn.hwndOwner         = hWnd;
#ifdef WIN32
    ofn.hInstance         = (HINSTANCE) GetWindowLong(hWnd, GWL_HINSTANCE);
#else
    ofn.hInstance         = (HINSTANCE) GetWindowWord(hWnd, GWW_HINSTANCE);
#endif
    ofn.lpstrFilter       = pbyFilter;
    ofn.lpstrCustomFilter = (LPSTR) NULL;
    ofn.nMaxCustFilter    = 0L;
    ofn.nFilterIndex      = 1L;
    ofn.lpstrFile         = file;
    ofn.nMaxFile          = sizeof(file);
    ofn.lpstrFileTitle    = fileTitle;
    ofn.nMaxFileTitle     = sizeof(fileTitle);
    ofn.lpstrInitialDir   = _AS->pbyProgramPath;
    ofn.lpstrTitle        = pbyTitle;
    ofn.nFileOffset       = 0;
    ofn.nFileExtension    = 0;
    ofn.lpstrDefExt       = pbyFilter;
	ofn.lCustData         = 0;

	ofn.Flags = OFN_PATHMUSTEXIST | OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_NONETWORKBUTTON;
    if(!bMode) // We loads a file...
		ofn.Flags |= OFN_FILEMUSTEXIST;
	if(bMultiSelect)
		ofn.Flags |= OFN_ALLOWMULTISELECT;
    if (GetOpenFileName(&ofn))
	    return (char*)ofn.lpstrFile;
	return NULL;
} // end ASGetFileName()

AUX_RGBImageRec *LoadBMP2(char *Filename)                // Loads A Bitmap Image
{
        FILE *File=NULL;                                // File Handle

        if (!Filename)                                  // Make Sure A Filename Was Given
        {
                return NULL;                            // If Not Return NULL
        }

        File=fopen(Filename,"r");                       // Check To See If The File Exists

        if (File)                                       // Does The File Exist?
        {
                fclose(File);                           // Close The Handle
                return auxDIBImageLoad(Filename);       // Load The Bitmap And Return A Pointer
        }
        return NULL;                                    // If Load Failed Return NULL
}

BOOL ASLoadTGA(AS_TEXTURE *texture, char *filename)
{ // begin ASLoadTGA()
    AUX_RGBImageRec *TextureImage[1];               // Create Storage Space For The Texture

    memset(TextureImage,0,sizeof(void *)*1);        // Set The Pointer To NULL
    // Load The Bitmap, Check For Errors, If Bitmap's Not Found Quit
    if (TextureImage[0]=LoadBMP2(filename))
    {
		texture->iWidth = TextureImage[0]->sizeX;
		texture->iHeight = TextureImage[0]->sizeY;
		texture->pbyData = (BYTE *) malloc(sizeof(BYTE)*texture->iWidth*texture->iHeight*3);
	    memcpy(texture->pbyData, TextureImage[0]->data, sizeof(BYTE)*texture->iWidth*texture->iHeight*3);
    }
	if(TextureImage[0])                            // If Texture Exists
    {
        if(TextureImage[0]->data)              // If Texture Image Exists
			free(TextureImage[0]->data);    // Free The Texture Image Memory
        free(TextureImage[0]);                  // Free The Image Structure
    }
	return true;											// Texture Building Went Ok, Return True
} // end ASLoadTGA()

// Loads a jpg texture:
BOOL ASLoadJpegRGB(AS_TEXTURE *pTexture, char *pbyFilename)
{ // begin ASLoadJpegRGB()
	JPEG_CORE_PROPERTIES jcProps;
	
	_AS->WriteLogMessage("Load jpg: %s", pbyFilename);
	memset(&jcProps, 0, sizeof(JPEG_CORE_PROPERTIES));
	ijlInit(&jcProps);
	jcProps.JPGFile = pbyFilename;
	ijlRead(&jcProps, IJL_JFILE_READPARAMS);

	pTexture->iWidth = (int) jcProps.JPGWidth;
	pTexture->iHeight = (int) jcProps.JPGHeight;

	// Setup texture information:
	pTexture->iFormat = GL_RGB;
	pTexture->iImageBits = 24;
	pTexture->byColorComponents = 3;

	pTexture->pbyData = (BYTE *) malloc(pTexture->iWidth*pTexture->iHeight*pTexture->byColorComponents);
	jcProps.DIBWidth = jcProps.JPGWidth;
	jcProps.DIBHeight = jcProps.JPGHeight;
	jcProps.DIBChannels = 3;
	jcProps.DIBColor = IJL_RGB;
	jcProps.DIBPadBytes = 0;
	jcProps.DIBBytes = (BYTE *) pTexture->pbyData;
	jcProps.JPGColor = IJL_YCBCR;
	if(ijlRead(&jcProps, IJL_JFILE_READWHOLEIMAGE) != IJL_OK)
	{
		if(pTexture->pbyData)
			delete pTexture->pbyData;
		return true;
	}
	ijlFree(&jcProps);
	
	return false;
} // end ASLoadJpegRGB()

void ASLoadTextures(char (*byFilename)[256], int iTextures, AS_TEXTURE *pTexture)
{ // begin ASLoadTextures()
	AS_TEXTURE *pTextureT;
	char byTemp[256];

	_AS->WriteLogMessage("Load textures");
	for(int i = 0; i < iTextures; i++)
	{
		pTextureT = &pTexture[i];
		sprintf(byTemp, "%s%s\\%s", _AS->pbyProgramPath, _AS->pbyBitmapsFile, byFilename[i]);
		_AS->WriteLogMessage("Load texture: %s", byTemp);
		strcpy(pTextureT->byFilename, byTemp);
		ASLoadJpegRGB(pTextureT, byTemp);
		if(!pTextureT->iWidth)
			_AS->WriteLogMessage("Couldn't load that texture!");
	}
} // begin ASLoadTextures()

void ASDestroyTextures(int iTextures, AS_TEXTURE *Texture)
{ // begin ASDestroyTextures()
	for(int i = 0; i < iTextures; i++)
	{
		if(Texture[i].pbyData)
			Texture[i].pbyData;
	}
} // end ASDestroyTextures()

void ASGenOpenGLTextures(int iTextures, AS_TEXTURE *Texture)
{ // begin ASGenOpenGLTextures()
	AS_TEXTURE *pTextureT;

	if(!Texture[0].pbyData)
		return;
	_AS->WriteLogMessage("Generate OpenGL textures");
	for(int i = 0; i < iTextures; i++)
	{
		pTextureT = &Texture[i];
		glGenTextures(1, &pTextureT->iOpenGLID);
		glBindTexture(GL_TEXTURE_2D, pTextureT->iOpenGLID);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
		if(_ASConfig->bUseMipmaps && !pTextureT->bNoMipmap)
		{
			if(_ASConfig->bFastTexturing)
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST_MIPMAP_NEAREST);
				gluBuild2DMipmaps(GL_TEXTURE_2D, pTextureT->byColorComponents, pTextureT->iWidth,
								  pTextureT->iHeight, pTextureT->iFormat, GL_UNSIGNED_BYTE,
								  pTextureT->pbyData);
			}
			else
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);
				gluBuild2DMipmaps(GL_TEXTURE_2D, pTextureT->byColorComponents, pTextureT->iWidth,
								  pTextureT->iHeight, pTextureT->iFormat, GL_UNSIGNED_BYTE,
								  pTextureT->pbyData);
			}
		}
		else
		{
			if(_ASConfig->bFastTexturing)
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
				glTexImage2D(GL_TEXTURE_2D, 0, pTextureT->byColorComponents, pTextureT->iWidth,
							 pTextureT->iHeight, 0, pTextureT->iFormat, GL_UNSIGNED_BYTE,
							 pTextureT->pbyData);
			}
			else
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
				glTexImage2D(GL_TEXTURE_2D, 0, pTextureT->byColorComponents, pTextureT->iWidth,
							 pTextureT->iHeight, 0, pTextureT->iFormat, GL_UNSIGNED_BYTE,
							 pTextureT->pbyData);
			}
		}
	}
} // end ASGenOpenGLTextures()

void ASDestroyOpenGLTextures(int iTextures, AS_TEXTURE *Texture)
{ // begin ASDestroyOpenGLTextures()
	if(!Texture[0].pbyData)
		return;
	for(int i = 0; i < iTextures; i++)
		glDeleteTextures(1, &Texture[i].iOpenGLID);
} // end ASDestroyOpenGLTextures()
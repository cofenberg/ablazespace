#ifndef __AS_CONFIG_H__
#define __AS_CONFIG_H__


// Structures: ****************************************************************
typedef struct
{
	int Number;
	DEVMODE *pDevMode;
} DISPLAY_MODE_INFO;
///////////////////////////////////////////////////////////////////////////////
// Classes: *******************************************************************
typedef class AS_CONFIG
{
	public:
		BOOL bFirstRun;
		BOOL bError;
		BOOL bSetError;
		BOOL bFullScreen;
		BOOL bSound;
		BOOL bMusic;
		BOOL bDrawBounding;
		BOOL bShowFPS;
		BOOL bFastTexturing;
		BOOL bUseMipmaps;
		BOOL bLog;
		BOOL bParticles;
		DWORD dwMode;
		char byLight; // 0 = none, 1 = flat, 2 = smooth
		int iColorDepthFilter;
		int iWindowWidth, iWindowHeight;
		int iModeIndex; 
		DEVMODE DevMode;
		int iScreenPixels, iScreenSize;
		// Keys:
		short iLeftKey[2], iRightKey[2], iThrustKey[2], iShieldKey[2],
		      iStopKey[2], iFireKey[2];

		AS_CONFIG(void);
		~AS_CONFIG(void);

		void Check(void);
        HRESULT Load(char *);
	    HRESULT Save(char *);
} AS_CONFIG;
///////////////////////////////////////////////////////////////////////////////
// Variables: *****************************************************************
extern AS_CONFIG *_ASConfig;
extern DISPLAY_MODE_INFO DisplayModeInfo;
///////////////////////////////////////////////////////////////////////////////
// Functions: *****************************************************************
extern LRESULT CALLBACK ConfigProc(HWND, UINT, WPARAM, LPARAM);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_CONFIG_H__
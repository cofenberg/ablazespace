#include "AS_ENGINE.h"


// Functions: *****************************************************************
extern LRESULT CALLBACK CreditsProc(HWND, UINT, WPARAM, LPARAM);
// Functions: *****************************************************************
LRESULT CALLBACK ConfigProc(HWND, UINT, WPARAM, LPARAM);
// HRESULT CONFIG::Check(void);
// HRESULT CONFIG::Load(char *);
// HRESULT CONFIG::Save(char *)
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
AS_CONFIG *_ASConfig;
AS_CONFIG ConfigT;
DISPLAY_MODE_INFO DisplayModeInfo;
///////////////////////////////////////////////////////////////////////////////


// AS_CONFIG functions: *******************************************************
AS_CONFIG::AS_CONFIG(void)
{ // begin AS_CONFIG::AS_CONFIG()
	memset(this, 0, sizeof(AS_CONFIG));
} // end AS_CONFIG::AS_CONFIG()

AS_CONFIG::~AS_CONFIG(void)
{ // begin AS_CONFIG::~AS_CONFIG()
} // end AS_CONFIG::~AS_CONFIG()

void AS_CONFIG::Check(void)
{ // begin AS_CONFIG::Check()
	if(!DevMode.dmSize)
		DevMode.dmSize = sizeof(DEVMODE);
	iScreenPixels = DevMode.dmPelsWidth*DevMode.dmPelsHeight;
	iScreenSize = DevMode.dmPelsWidth*DevMode.dmPelsHeight*(DevMode.dmBitsPerPel/8);
	DevMode.dmFields = DM_BITSPERPEL | DM_PELSWIDTH | DM_PELSHEIGHT;
	for(int i = 0; i < DisplayModeInfo.Number; i++)
	{
		if(DevMode.dmPelsWidth == DisplayModeInfo.pDevMode[i].dmPelsWidth && 
		   DevMode.dmPelsHeight == DisplayModeInfo.pDevMode[i].dmPelsHeight && 	
		   DevMode.dmBitsPerPel == DisplayModeInfo.pDevMode[i].dmBitsPerPel && 
		   DevMode.dmDisplayFrequency == DisplayModeInfo.pDevMode[i].dmDisplayFrequency)
		{
			iModeIndex = i;
			CopyMemory(&DevMode, &DisplayModeInfo.pDevMode[iModeIndex], sizeof(DEVMODE));
			break;
		}
	}
	if(!_AS->bSoundPossible)
		bSound = FALSE;
} // end AS_CONFIG::Check()

HRESULT AS_CONFIG::Load(char *pbyFilename)
{ // begin CONFIG::Load()
	bFirstRun = GetPrivateProfileInt("General", "firstrun", 1, pbyFilename);
	bError = GetPrivateProfileInt("General", "error", 1, pbyFilename);
	bFullScreen = GetPrivateProfileInt("General", "fullscreen", 1, pbyFilename);
	bSound = GetPrivateProfileInt("General", "sound", 1, pbyFilename);
	bMusic = GetPrivateProfileInt("General", "music", 1, pbyFilename);
	bDrawBounding = GetPrivateProfileInt("General", "draw_bounding", 0, pbyFilename);
	byLight = GetPrivateProfileInt("General", "light_mode", 0, pbyFilename);
	bShowFPS = GetPrivateProfileInt("General", "show_fps", 0, pbyFilename);
	bFastTexturing = GetPrivateProfileInt("General", "fast_texturing", 1, pbyFilename);
	bUseMipmaps = GetPrivateProfileInt("General", "use_mipmaps", 1, pbyFilename);
	bParticles = GetPrivateProfileInt("General", "particles", 0, pbyFilename);
	bLog = GetPrivateProfileInt("General", "log", 1, pbyFilename);
	DevMode.dmPelsWidth = GetPrivateProfileInt("General", "width", 640, pbyFilename);
	DevMode.dmPelsHeight = GetPrivateProfileInt("General", "height", 480, pbyFilename);
	DevMode.dmBitsPerPel = GetPrivateProfileInt("General", "colordepth", 16, pbyFilename);
	DevMode.dmDisplayFrequency = GetPrivateProfileInt("General", "refresh_rate", 0, pbyFilename);
	iColorDepthFilter = GetPrivateProfileInt("General", "color_depth_filter", 16, pbyFilename);
	iWindowWidth = GetPrivateProfileInt("General", "window_width", DevMode.dmPelsWidth, pbyFilename);
	iWindowHeight = GetPrivateProfileInt("General", "window_height", DevMode.dmPelsHeight, pbyFilename);	
	// Keys:
	// Player 1:
	iLeftKey[0] = GetPrivateProfileInt("General", "p1_left", 37, pbyFilename);	
	iRightKey[0] = GetPrivateProfileInt("General", "p1_right", 39, pbyFilename);	
	iThrustKey[0] = GetPrivateProfileInt("General", "p1_thrust", 38, pbyFilename);	
	iShieldKey[0] = GetPrivateProfileInt("General", "p1_shield", 40, pbyFilename);	
	iStopKey[0] = GetPrivateProfileInt("General", "p1_stop", 13, pbyFilename);	
	iFireKey[0] = GetPrivateProfileInt("General", "p1_fire", 32, pbyFilename);	
	// Player 2:
	iLeftKey[1] = GetPrivateProfileInt("General", "p2_left", 65, pbyFilename);	
	iRightKey[1] = GetPrivateProfileInt("General", "p2_right", 68, pbyFilename);	
	iThrustKey[1] = GetPrivateProfileInt("General", "p2_thrust", 87, pbyFilename);	
	iShieldKey[1] = GetPrivateProfileInt("General", "p2_shield", 83, pbyFilename);	
	iStopKey[1] = GetPrivateProfileInt("General", "p2_stop", 9, pbyFilename);	
	iFireKey[1] = GetPrivateProfileInt("General", "p2_fire", 81, pbyFilename);	
	//
	Check();
	return 0;
} // end AS_CONFIG::Load()

HRESULT AS_CONFIG::Save(char *pbyFileName)
{ // begin AS_CONFIG::Save()
	FILE *pFile;

	pFile = fopen(pbyFileName, "wt");
	if(!pFile)
		return 1;
	fprintf(pFile, "[General]\n");
    fprintf(pFile, "firstrun=%d\n", bFirstRun);
    fprintf(pFile, "error=%d\n", bError);
    fprintf(pFile, "fullscreen=%d\n", bFullScreen);
    fprintf(pFile, "sound=%d\n", bSound);
    fprintf(pFile, "music=%d\n", bMusic);
    fprintf(pFile, "draw_bounding=%d\n", bDrawBounding);
    fprintf(pFile, "particles=%d\n", bParticles);
    fprintf(pFile, "light_mode=%d\n", byLight);
    fprintf(pFile, "show_fps=%d\n", bShowFPS);
    fprintf(pFile, "fast_texturing=%d\n", bFastTexturing);
    fprintf(pFile, "use_mipmaps=%d\n", bUseMipmaps);
    fprintf(pFile, "log=%d\n", bLog);
	fprintf(pFile, "width=%d\n", DevMode.dmPelsWidth);
	fprintf(pFile, "height=%d\n", DevMode.dmPelsHeight);
	fprintf(pFile, "colordepth=%d\n", DevMode.dmBitsPerPel);
	fprintf(pFile, "refresh_rate=%d HZ\n", DevMode.dmDisplayFrequency);
	fprintf(pFile, "color_depth_filter=%d Bit\n", iColorDepthFilter);
	fprintf(pFile, "window_width=%d\n", iWindowWidth);
	fprintf(pFile, "window_height=%d\n", iWindowHeight);
	// Keys
	fprintf(pFile, "[Keys]\n");
	// Player 1:
    fprintf(pFile, "p1_left=%d\n", iLeftKey[0]);
    fprintf(pFile, "p1_right=%d\n", iRightKey[0]);
    fprintf(pFile, "p1_thrust=%d\n", iThrustKey[0]);
    fprintf(pFile, "p1_shield=%d\n", iShieldKey[0]);
    fprintf(pFile, "p1_stop=%d\n", iStopKey[0]);
    fprintf(pFile, "p1_fire=%d\n", iFireKey[0]);
	// Player 2:
    fprintf(pFile, "p2_left=%d\n", iLeftKey[1]);
    fprintf(pFile, "p2_right=%d\n", iRightKey[1]);
    fprintf(pFile, "p2_thrust=%d\n", iThrustKey[1]);
    fprintf(pFile, "p2_shield=%d\n", iShieldKey[1]);
    fprintf(pFile, "p2_stop=%d\n", iStopKey[1]);
    fprintf(pFile, "p2_fire=%d\n", iFireKey[1]);
	//
	fclose(pFile);
	return 0;
} // end AS_CONFIG::Save()


// Functions: *****************************************************************
LRESULT CALLBACK ConfigProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin ConfigInfoProc()
    LPSTR pbyTemp = new char[MAX_PATH];
	BOOL bTemp;
	int i, i2, i3;

	switch(iMessage)
    {
        case WM_INITDIALOG:
			memcpy(&ConfigT, _ASConfig, sizeof(AS_CONFIG));
		InitConfigDialog:
			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
			SendDlgItemMessage(hWnd, IDC_CONFIG_FULLSCREEN, BM_SETCHECK, _ASConfig->bFullScreen, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_MUSIC, BM_SETCHECK, _ASConfig->bMusic, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND, BM_SETCHECK, _ASConfig->bSound, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_DRAW_BOUNDING, BM_SETCHECK, _ASConfig->bDrawBounding, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_PARTICLES, BM_SETCHECK, _ASConfig->bParticles, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_SHOW_FPS, BM_SETCHECK, _ASConfig->bShowFPS, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_FAST_TEXTURING, BM_SETCHECK, _ASConfig->bFastTexturing, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_USE_MIPMAPS, BM_SETCHECK, _ASConfig->bUseMipmaps, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_LOG, BM_SETCHECK, _ASConfig->bLog, 0L);
			switch(_ASConfig->byLight)
			{
				case 0: CheckRadioButton(hWnd, IDC_CONFIG_LIGHT_NONE, IDC_CONFIG_LIGHT_SMOOTH, IDC_CONFIG_LIGHT_NONE); break;
				case 1: CheckRadioButton(hWnd, IDC_CONFIG_LIGHT_NONE, IDC_CONFIG_LIGHT_SMOOTH, IDC_CONFIG_LIGHT_FLAT); break;
				case 2: CheckRadioButton(hWnd, IDC_CONFIG_LIGHT_NONE, IDC_CONFIG_LIGHT_SMOOTH, IDC_CONFIG_LIGHT_SMOOTH); break;
			}	
 			SendDlgItemMessage(hWnd, IDC_CONFIG_COLOR_DEPTH, CB_RESETCONTENT, 0, 0);
 			SendDlgItemMessage(hWnd, IDC_CONFIG_MODES, CB_RESETCONTENT, 0, 0);
			wsprintf(pbyTemp, "All");
   			SendDlgItemMessage(hWnd, IDC_CONFIG_COLOR_DEPTH, CB_ADDSTRING, 0, (LONG)(LPSTR) pbyTemp);
			for(i = 0; i < 3; i++)
			{
				wsprintf(pbyTemp, "%d Bit", 8+(i+1)*8);
	   			SendDlgItemMessage(hWnd, IDC_CONFIG_COLOR_DEPTH, CB_ADDSTRING, 0, (LONG)(LPSTR) pbyTemp);
			}
			if(!_ASConfig->iColorDepthFilter)
				SendDlgItemMessage(hWnd, IDC_CONFIG_COLOR_DEPTH, CB_SETCURSEL, 0, 0L);
			else
				SendDlgItemMessage(hWnd, IDC_CONFIG_COLOR_DEPTH, CB_SETCURSEL, _ASConfig->iColorDepthFilter/8-1, 0L);
			// Put in the new entries:
			for(i = 0, i2 = 0; i < DisplayModeInfo.Number-1; i++)
			{
				if(_ASConfig->iColorDepthFilter)
				{
					if(DisplayModeInfo.pDevMode[i].dmBitsPerPel != (unsigned char) _ASConfig->iColorDepthFilter)
						continue;
				}
				wsprintf(pbyTemp, "%dx%dx%d  %d HZ", 
						DisplayModeInfo.pDevMode[i].dmPelsWidth, 
						DisplayModeInfo.pDevMode[i].dmPelsHeight, 
						DisplayModeInfo.pDevMode[i].dmBitsPerPel, 
						DisplayModeInfo.pDevMode[i].dmDisplayFrequency);
     			SendDlgItemMessage(hWnd, IDC_CONFIG_MODES, CB_ADDSTRING, 0, (LONG)(LPSTR) pbyTemp);
     			SendDlgItemMessage(hWnd, IDC_CONFIG_MODES, CB_SETITEMDATA, i2, i);
				i2++;
			}
			if(_ASConfig->iColorDepthFilter)
			{
				if(DisplayModeInfo.pDevMode[_ASConfig->iModeIndex].dmBitsPerPel == (unsigned char) _ASConfig->iColorDepthFilter)
				{			
					for(i = 0; i < i2; i++)
					{
						i3 = SendDlgItemMessage(hWnd, IDC_CONFIG_MODES, CB_GETITEMDATA, i, 0);
						if(i3 == _ASConfig->iModeIndex)
							break;
					}
					SendDlgItemMessage(hWnd, IDC_CONFIG_MODES, CB_SETCURSEL, i, 0L);
				}
			}
			else
				SendDlgItemMessage(hWnd, IDC_CONFIG_MODES, CB_SETCURSEL, _ASConfig->iModeIndex, 0L);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_CONFIG_OK:
				Cancel:
					if(IsDlgButtonChecked(hWnd, IDC_CONFIG_LIGHT_NONE))
						_ASConfig->byLight = 0;
					else
					if(IsDlgButtonChecked(hWnd, IDC_CONFIG_LIGHT_FLAT))
						_ASConfig->byLight = 1;
					else
					if(IsDlgButtonChecked(hWnd, IDC_CONFIG_LIGHT_SMOOTH))
						_ASConfig->byLight = 2;
					EndDialog(hWnd, FALSE);
					if(!_ASConfig->bMusic)
						ASStopMidi();
                return TRUE;

				case ID_CONFIG_CANCEL:
					memcpy(_ASConfig, &ConfigT, sizeof(AS_CONFIG));
					EndDialog(hWnd, FALSE);
				break;

				case IDC_CONFIG_OPENGL:
					DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_OPENGL), hWnd, (DLGPROC) OpenGLInfoProc);
				break;

				case IDC_CONFIG_CREDITS:
					DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CREDITS), hWnd, (DLGPROC) CreditsProc);
				break;

				case IDC_CONFIG_FULLSCREEN:
				    _ASConfig->bFullScreen = SendDlgItemMessage(hWnd, IDC_CONFIG_FULLSCREEN, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_MODES:
   					i = SendDlgItemMessage(hWnd, IDC_CONFIG_MODES, CB_GETCURSEL, 0, 0L);
					i = SendDlgItemMessage(hWnd, IDC_CONFIG_MODES, CB_GETITEMDATA, i, 0);
					_ASConfig->iModeIndex = i;                         	
					CopyMemory(&_ASConfig->DevMode, &DisplayModeInfo.pDevMode[_ASConfig->iModeIndex], sizeof(DEVMODE));
				break;

                case IDC_CONFIG_COLOR_DEPTH:
				    i = SendDlgItemMessage(hWnd, IDC_CONFIG_COLOR_DEPTH, CB_GETCURSEL, 0, 0L);
					if(!_ASConfig->iColorDepthFilter)
					{
						if(!i)
							break;
					}
					else
						if(_ASConfig->iColorDepthFilter == i)
							break;					
					if(!i)
						_ASConfig->iColorDepthFilter = 0;
					else
						_ASConfig->iColorDepthFilter = i*8+8;
					goto InitConfigDialog;
				break;

				case IDC_CONFIG_MUSIC:
					_ASConfig->bMusic = SendDlgItemMessage(hWnd, IDC_CONFIG_MUSIC, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_SOUND:
					_ASConfig->bSound = SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_DRAW_BOUNDING:
					_ASConfig->bDrawBounding = SendDlgItemMessage(hWnd, IDC_CONFIG_DRAW_BOUNDING, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_PARTICLES:
					_ASConfig->bParticles = SendDlgItemMessage(hWnd, IDC_CONFIG_PARTICLES, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_SHOW_FPS:
					_ASConfig->bShowFPS = SendDlgItemMessage(hWnd, IDC_CONFIG_SHOW_FPS, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_FAST_TEXTURING:
					_ASConfig->bFastTexturing = SendDlgItemMessage(hWnd, IDC_CONFIG_FAST_TEXTURING, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_USE_MIPMAPS:
					_ASConfig->bUseMipmaps = SendDlgItemMessage(hWnd, IDC_CONFIG_USE_MIPMAPS, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_LOG:
					_ASConfig->bLog = SendDlgItemMessage(hWnd, IDC_CONFIG_LOG, BM_GETCHECK, 0, 0L);
					bTemp = _ASConfig->bLog;
					_ASConfig->bLog = TRUE;
					if(!bTemp)
						_AS->WriteLogMessage("Deactivate the log");
					else
						_AS->WriteLogMessage("Activate the log");
					_ASConfig->bLog = bTemp;
				break;

				case IDC_HOMEPAGE:
					ShellExecute(0, "open", "http://www.ablazespace.de/", 0, 0, SW_SHOW);
				break;

				case IDC_NEHE_HOMEPAGE:
					ShellExecute(0, "open", "http://nehe.gamedev.net/", 0, 0, SW_SHOW);
				break;

				case IDC_BLENDER_HOMEPAGE:
					ShellExecute(0, "open", "http://www.blender.nl/", 0, 0, SW_SHOW);
				break;

				case IDC_INVASION_HELP:
					ShellExecute(0, "open", "help.html", 0, 0, SW_SHOW);
				break;
            }
            break;

		case WM_CLOSE:
			goto Cancel;
    }
    return FALSE;
} // end ConfigInfoProc()
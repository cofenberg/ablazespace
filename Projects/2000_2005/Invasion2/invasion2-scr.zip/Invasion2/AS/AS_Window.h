#ifndef __AS_WINDOW_H__
#define __AS_WINDOW_H__


// Classes: *******************************************************************
typedef class AS_WINDOW
{
	AS_WINDOW *pWindow; // Address of the window
	
	HWND  hWnd;
	HDC	  hDC; // Private GDI device context
	HGLRC hRC; // Permanent rendering context

	int iWidth, iHeight;
	int iID;
	BOOL bIsMainWindow; // Is this the main window?
	BOOL bDeactivated;

	GLuint iFontBase;

	HRESULT (*pDraw)(AS_WINDOW *);
	HRESULT (*pCheck)(AS_WINDOW *);

	public:

		HWND ASCreateWindow(WNDPROC, LPCTSTR, LPCTSTR, DWORD, DWORD, HMENU, BOOL,
							HRESULT (*)(AS_WINDOW *), HRESULT (*)(AS_WINDOW *), HBRUSH, BOOL, BOOL);
		HRESULT ASDestroyWindow(HWND *, LPCTSTR);
		HRESULT InitOpenGL(void);
		HRESULT DestroyOpenGL(void);
		HRESULT Draw(void);
		HRESULT Check(void);
		HWND *GethWnd(void) { return &hWnd; }
		HDC *GethDC(void) { return &hDC; }
		HGLRC *GethRC(void) { return &hRC; }
		void SetID(int iIDT) { iID = iIDT; }
		int GetID(void) { return iID; }
		BOOL GetIsMainWindow(void) { return bIsMainWindow; }
		void SetWindow(AS_WINDOW *pTemp) { pWindow = pTemp; }
		void SetDrawFunction(HRESULT (*pTemp)(AS_WINDOW *)) { pDraw = pTemp; }
		void SetCheckFunction(HRESULT (*pTemp)(AS_WINDOW *)) { pCheck = pTemp; }
		void SetDeactivated(BOOL bTemp) { bDeactivated = bTemp; }
		void Resize(int, int);
		void MakeScreenshot(char *);

		GLvoid BuildFont(GLvoid);
		GLvoid KillFont(GLvoid);
		GLvoid glPrint(GLint, GLint, char *, int);

} AS_WINDOW;
///////////////////////////////////////////////////////////////////////////////

struct AS_TEXTURE;
extern AS_TEXTURE FontTexture;


#endif // __AS_WINDOW__
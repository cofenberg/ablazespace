#include "AS_ENGINE.h"


extern void LoadGameTextures(void);
extern void DestroyGameTextures(void);
extern void CreateGameLists(void);
extern void DestroyGameLists(void);
extern void LoadSounds(void);
extern void DestroySounds(void);

// Functions: *****************************************************************
LRESULT CALLBACK OpenGLInfoProc(HWND, UINT, WPARAM, LPARAM);
HRESULT ASInitOpenGL(AS_WINDOW *, HWND, HDC *, HGLRC *, BOOL);
void ASConfigOpenGL(int, int);
HRESULT ASDestroyOpenGL(AS_WINDOW *, HWND, HDC, HGLRC);
///////////////////////////////////////////////////////////////////////////////


GLfloat LightDiffuse[]	= { 0.01f, 0.01f, 0.01f, 1.0f }; 
GLfloat LightAmbient[]	= { 0.5f, 0.5f, 0.5f, 1.0f };
GLfloat LightPosition[]	= { 10.0f, 10.0f, 10.0f, 1.0f };


LRESULT CALLBACK OpenGLInfoProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin OpenGLInfoProc()
	char *pbyTemp, byTemp[256];

    switch(iMessage)
    {
        case WM_INITDIALOG:
				_AS->WriteLogMessage("Open OpenGL dialog");
			    ShowWindow(hWnd, _AS->GetCmdShow());
				UpdateWindow(hWnd);
            	SetDlgItemText(hWnd, IDC_OPENGL_VERSION_INFO, pbyOpenGLVersion);
            	SetDlgItemText(hWnd, IDC_OPENGL_CHIP_INFO, pbyOpenGLChipInfo);
            	SetDlgItemText(hWnd, IDC_OPENGL_RENDERER_INFO, pbyOpenGLRendererInfo);
				pbyTemp = pbyOpenGLExtensionInfo;
				for(;;)
				{
					if(sscanf(pbyTemp, "%s", byTemp) == EOF)
						break;
					SendDlgItemMessage(hWnd, IDC_OPENGL_EXTENSIONS_INFO, LB_ADDSTRING, 0, (LONG)(LPSTR) byTemp);
					if(*(pbyTemp+strlen(byTemp)+1) == 0)
						break;
					pbyTemp += strlen((const char *) byTemp)+1;
				}
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_OPENGL_OK:
				Cancel:
					EndDialog(hWnd, FALSE);
					_AS->WriteLogMessage("Close OpenGL dialog(OK)");
                return TRUE;
            }
        break;
		
		case WM_CLOSE:
			goto Cancel;
    }
    return FALSE;
} // end OpenGLInfoProc()

HRESULT ASInitOpenGL(AS_WINDOW *pWindow, HWND hWndT, HDC *hDC, HGLRC *hRC, BOOL bFullScreen)
{ // begin ASInitOpenGL()
	HWND hWnd;
	GLuint PixelFormat;

	_AS->WriteLogMessage("Init OpenGL for window");
	if(pWindow)
		hWnd = *pWindow->GethWnd();
	else
	{
		if(!hWndT)
		{
			_AS->WriteLogMessage("There is no handle for this window!");
			return 1;
		}
		hWnd = hWndT;
	}
	if(bFullScreen)
	{
		_AS->WriteLogMessage("Change display mode");
		if(ChangeDisplaySettings(&_ASConfig->DevMode, CDS_FULLSCREEN) != DISP_CHANGE_SUCCESSFUL)
		{
			_AS->WriteLogMessage("Couln't change display mode");
			return 1;
		}
		_AS->ShowMouseCursor(FALSE);
	}
	else
		_AS->ShowMouseCursor(TRUE);
	static PIXELFORMATDESCRIPTOR pfd =				// pfd Tells Windows How We Want Things To Be
	{
		sizeof(PIXELFORMATDESCRIPTOR),				// Size Of This Pixel Format Descriptor
		1,											// Version Number
		PFD_DRAW_TO_WINDOW |						// Format Must Support Window
		PFD_SUPPORT_OPENGL |						// Format Must Support OpenGL
		PFD_DOUBLEBUFFER,							// Must Support Double Buffering
		PFD_TYPE_RGBA,								// Request An RGBA Format
		(UCHAR) _ASConfig->DevMode.dmBitsPerPel,              // Select Our Color Depth
		0, 0, 0, 0, 0, 0,							// Color Bits Ignored
		0,											// No Alpha Buffer
		0,											// Shift Bit Ignored
		0,											// No Accumulation Buffer
		0, 0, 0, 0,									// Accumulation Bits Ignored
		16,											// 16Bit Z-Buffer (Depth Buffer)  
		0,											// No Stencil Buffer
		0,											// No Auxiliary Buffer
		PFD_MAIN_PLANE,								// Main Drawing Layer
		0,											// Reserved
		0, 0, 0										// Layer Masks Ignored
	};
	if(!(*hDC = GetDC(hWnd)))							// Did We Get A Device Context?
	{
		_AS->WriteLogMessage("Can't Create A GL Device Context");
		MessageBox(NULL,"Can't Create A GL Device Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		ASDestroyOpenGL(pWindow, hWndT, *hDC, *hRC);
		return 1;
	}
	if(!(PixelFormat = ChoosePixelFormat(*hDC, &pfd)))	// Did Windows Find A Matching Pixel Format?
	{
		_AS->WriteLogMessage("Can't Find A Suitable PixelFormat");
		MessageBox(NULL,"Can't Find A Suitable PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		ASDestroyOpenGL(pWindow, hWndT, *hDC, *hRC);
		return 1;
	}
	if(!SetPixelFormat(*hDC, PixelFormat, &pfd))		// Are We Able To Set The Pixel Format?
	{
		_AS->WriteLogMessage("Can't Set The PixelFormat");
		MessageBox(NULL,"Can't Set The PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		ASDestroyOpenGL(pWindow, hWndT, *hDC, *hRC);
		return 1;
	}
	if(!(*hRC = wglCreateContext(*hDC)))				// Are We Able To Get A Rendering Context?
	{
		_AS->WriteLogMessage("Can't Create A GL Rendering Context");
		MessageBox(NULL,"Can't Create A GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		ASDestroyOpenGL(pWindow, hWndT, *hDC, *hRC);
		return 1;
	}
	if(!wglMakeCurrent(*hDC, *hRC))
		return 0;
	RECT Rect;
	GetWindowRect(hWnd, &Rect);
	ASConfigOpenGL(Rect.right-Rect.left, Rect.bottom-Rect.top);
	if(pWindow && pWindow->GetIsMainWindow())
	{
		_AS->WriteLogMessage("This is the main window");
		// Get OpenGL Information
		// Version
		if(pbyOpenGLVersion)
			delete pbyOpenGLVersion;
		pbyOpenGLVersion = new char[strlen((const char *) glGetString(GL_VERSION))+1];
		strcpy(pbyOpenGLVersion, (const char *) glGetString(GL_VERSION));
		// Chip Info
		if(pbyOpenGLChipInfo)
			delete pbyOpenGLChipInfo;
		pbyOpenGLChipInfo = new char[strlen((const char *) glGetString(GL_VENDOR))+1];
		strcpy(pbyOpenGLChipInfo, (const char *) glGetString(GL_VENDOR));
		// Renderer Info
		if(pbyOpenGLRendererInfo)
			delete pbyOpenGLRendererInfo;
		pbyOpenGLRendererInfo = new char[strlen((const char *) glGetString(GL_RENDERER))+1];
		strcpy(pbyOpenGLRendererInfo, (const char *) glGetString(GL_RENDERER));
		// Extensions Info
		if(pbyOpenGLExtensionInfo)
			delete pbyOpenGLExtensionInfo;
		pbyOpenGLExtensionInfo = new char[strlen((const char *) glGetString(GL_EXTENSIONS))+1];
		strcpy(pbyOpenGLExtensionInfo, (const char *) glGetString(GL_EXTENSIONS));
		// Initialize DirectX sound
		_AS->WriteLogMessage("Initialize DirectX sound");
		if(FAILED(DSUtil_InitDirectSound(hWnd)))
		{
			_AS->WriteLogMessage("DirectX sound couldn't be initializing");
			_AS->bSoundPossible = FALSE;
			_ASConfig->bSound = FALSE;
		}
		else
			_AS->bSoundPossible = TRUE;
		LoadSounds();
	}
	_AS->WriteLogMessage("Create fonts");
	if(pWindow)
	{
		pWindow->BuildFont();
		LoadGameTextures();
		CreateGameLists();
	}
	_AS->WriteLogMessage("OpenGL init complete");
	return 0;
} // end ASInitOpenGL()
		
HRESULT ASDestroyOpenGL(AS_WINDOW *pWindow, HWND hWndT, HDC hDC, HGLRC hRC)
{ // begin ASDestroyOpenGL()
	HWND hWnd;

	_AS->WriteLogMessage("Destroy OpenGL from window");
	if(pWindow)
		hWnd = *pWindow->GethWnd();
	else
	{
		if(!hWndT)
		{
			_AS->WriteLogMessage("There is no handle for this window!");
			return 1;
		}
		hWnd = hWndT;
	}
	if(!wglMakeCurrent(hDC, hRC))
		return 0;
	if(pWindow && pWindow->GetIsMainWindow())
	{
		_AS->WriteLogMessage("This is the main window");
		DestroySounds();
		_AS->WriteLogMessage("Destroy DirectX sound");
		if(_AS->bSoundPossible)
			DSUtil_FreeDirectSound();
	}
	_AS->WriteLogMessage("Kill fonts");
	if(pWindow)
	{
		DestroyGameLists();
		DestroyGameTextures();
		pWindow->KillFont();
	}
	_AS->WriteLogMessage("Set display mode to default");
	glDisableClientState(GL_COLOR_ARRAY);
	glDisableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_NORMAL_ARRAY);

	ChangeDisplaySettings(NULL, 0);					// If So Switch Back To The Desktop
	if(hRC)											// Do We Have A Rendering Context?
	{
		if(!wglMakeCurrent(NULL, NULL))					// Are We Able To Release The DC And RC Contexts?
		{
			_AS->WriteLogMessage("Release Of DC And RC Failed");
			MessageBox(NULL,"Release Of DC And RC Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}
		if(!wglDeleteContext(hRC))						// Are We Able To Delete The RC?
		{
			_AS->WriteLogMessage("Release Rendering Context Failed");
			MessageBox(NULL,"Release Rendering Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}
		hRC = NULL;										// Set RC To NULL
	}
	if(hDC && !ReleaseDC(hWnd, hDC))					// Are We Able To Release The DC
	{
		_AS->WriteLogMessage("Release Device Context Failed");
		MessageBox(NULL,"Release Device Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hDC = NULL;										// Set DC To NULL
	}
	_AS->WriteLogMessage("OpenGL successful destroyed");
	return 0;
} // ASDestroyOpenGL()

void ASConfigOpenGL(int iWidth, int iHeight)
{ // begin ASConfigOpenGL()
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glViewport(0, 0, iWidth, iHeight);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0f, (GLfloat)iWidth/(GLfloat)iHeight, 0.1f, 100.0f);
	glMatrixMode(GL_MODELVIEW);

	glPolygonMode(GL_FRONT, GL_FILL);
	glPolygonMode(GL_BACK, GL_FILL);

	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);

	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_FASTEST);
	glHint(GL_LINE_SMOOTH_HINT, GL_FASTEST);
	glHint(GL_FOG_HINT, GL_FASTEST);
	glHint(GL_POINT_SMOOTH_HINT, GL_FASTEST);
	glHint(GL_POLYGON_SMOOTH_HINT, GL_FASTEST);
	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);
	switch(_ASConfig->byLight)
	{
		case 1:
			glShadeModel(GL_FLAT);					    // Enable Smooth Shading
		break;

		case 2:
			glShadeModel(GL_SMOOTH);					// Enable Smooth Shading
		break;
	}
	glColor4f(1.0f, 1.0f, 1.0f, 1.0);
	glEnable(GL_COLOR_MATERIAL);
	glEnable(GL_COLOR_MATERIAL_FACE);
	glColorMaterial(GL_FRONT,GL_AMBIENT_AND_DIFFUSE);
	glMateriali(GL_FRONT,GL_SHININESS,128);

	glBlendFunc(GL_SRC_ALPHA, GL_ONE);					// Set The Blending Function For Translucency
	glEnable(GL_TEXTURE_2D);

	glLightfv(GL_LIGHT1, GL_AMBIENT, LightAmbient);		// Setup The Ambient Light
//	glLightfv(GL_LIGHT1, GL_DIFFUSE, LightDiffuse);		// Setup The Diffuse Light
	glLightfv(GL_LIGHT1, GL_POSITION,LightPosition);	// Position The Light
	glEnable(GL_LIGHT1);								// Enable Light One

	glEnableLighting();

	glEnableClientState(GL_COLOR_ARRAY);
	glEnableClientState(GL_VERTEX_ARRAY);
	glEnableClientState(GL_NORMAL_ARRAY);
} // end ASConfigOpenGL()
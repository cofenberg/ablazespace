#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Functions: *****************************************************************
LRESULT CALLBACK WindowProc(HWND, unsigned, WPARAM, LPARAM);
///////////////////////////////////////////////////////////////////////////////

 
LRESULT CALLBACK WindowProc(HWND hWnd, unsigned uMsg, WPARAM wParam, LPARAM lParam)
{ // begin WindowProc()
	short i;
	BOOL bTempFullscreen;
	
	switch(uMsg)
    {
		case WM_KEYDOWN:
			ASKeys[wParam] = TRUE;
		break;
		
		case WM_KEYUP:
			ASKeys[wParam] = FALSE;
		break;

		case WM_PAINT:
			i = _AS->FindWindowID(hWnd);
			if(i == -1)
				break;
			_AS->pWindow[i].Draw();
		break;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				// Game:
				case ID_GAME_FILE_QUIT:
					_AS->SetShutDown(TRUE);
				break;
				
				// Options:
				case ID_OPTIONS_CONFIG:
					bTempFullscreen = _ASConfig->bFullScreen;
					DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CONFIG), hWnd, (DLGPROC) ConfigProc);
					if(bTempFullscreen != _ASConfig->bFullScreen)
						ChangeDisplayMode();
					i = _AS->FindWindowID(hWnd);
					if(i == -1)
						break;
					_AS->pWindow[i].Resize(_ASConfig->iWindowWidth, _ASConfig->iWindowHeight);
					ASDestroyOpenGLTextures(GAME_TEXTURES, GameTexture);
					ASGenOpenGLTextures(GAME_TEXTURES, GameTexture);
				break;

				// Help:
				case ID_HELP_HELP:
					_AS->WriteLogMessage("Open help file");
					ShellExecute(0, "open", "help.html", 0, 0, SW_SHOW);
				break;
				
				case ID_HELP_HOMEPAGE:
					_AS->WriteLogMessage("Open homepage");
					ShellExecute(0, "open", "http://www.ablazespace.de/", 0, 0, SW_SHOW);
				break;

				case ID_HELP_CREDITS:
					DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CREDITS), NULL, (DLGPROC) CreditsProc);
				break;
				
				case ID_FILE_SHOW_LOG:
					_AS->WriteLogMessage("Open Log");
					ShellExecute(0, "open", AS_LOG_FILE, 0, 0, SW_SHOW);				
				break;
			}
		break;

		case WM_SIZE:
			if(wParam == SIZE_MINIMIZED)
			{
				InvalidateRect(hWnd, NULL, TRUE);
				_AS->SetActive(FALSE);
			}
			else
				_AS->SetActive(TRUE);
			i = _AS->FindWindowID(hWnd);
			if(i == -1)
				break;
			_ASConfig->iWindowWidth = LOWORD(lParam);
			_ASConfig->iWindowHeight = HIWORD(lParam);
			_AS->pWindow[i].Resize(LOWORD(lParam), HIWORD(lParam));
		break;

		case WM_SYSKEYUP:
			switch(wParam)
			{
				case VK_RETURN:
					// Switch to fullscreen or to window mode:
					_ASConfig->bFullScreen = !_ASConfig->bFullScreen;
					ChangeDisplayMode();
				break;
			}
		break;

		case WM_CLOSE:
			_AS->SetShutDown(TRUE);
		return 0;
    }
    return DefWindowProc(hWnd, uMsg, wParam, lParam);
} // end WindowProc()
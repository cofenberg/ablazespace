#ifndef __AS_GAME_H__
#define __AS_GAME_H__


// Definitions: ***************************************************************
#define GAME_TEXTURES 17
///////////////////////////////////////////////////////////////////////////////
// Variables: *****************************************************************
extern AS_TEXTURE GameTexture[GAME_TEXTURES];
extern int GAME_WINDOW_ID;
#define MAX_ACTORS 50
#define MAX_PARTICLES 350
#define MAX_SHOTS 50
#define START_SHILD_TIME 3000
extern GLuint iBackgroundList;
extern GLuint iWaveList;
extern GLuint iShieldList;
extern GLuint iSmokeList;
extern GLuint iStarList;
extern GLfloat fBackgroundRot;
extern int iPlayerScore[2];
extern char byPlayerWeapon[2];
extern BOOL bShowPlayerText;
extern FLOAT3 fPlayerShipRot;
extern bCheatsActivated, bUnlimitedPower, bInvulnerable, bNoBlackHole, bMoorhuhnModus;
extern BOOL bMainMenu, bBlackHole;
extern BOOL bGameWon;
extern long lNextUfoTime, lNextBlackHoleParticleTime;
extern BOOL b2Player, bDeadMatch, bPlayerWar, bGravity, bUFOS, bOccurrences;

#define SPACE_WIDTH 28.0f
#define SPACE_HEIGHT 22.0f
#define GRAVITY 0.0005f
#define MAX_HIGHSCORES 10
#define SINGLE_SHOT_POWER 10.0f
#define DOUBLE_SHOT_POWER 5.0f
#define PLAYER_GHOST_TIME 2000
// Points:
#define ASTEROID_POINTS 5
#define PLAYER_KILL_POINTS 200
#define FULL_POWER_POINTS 25
#define POWER_INCREASE_POINTS 50
#define LIVE_POINTS 100
#define SINGLE_LASER_WEAPON_POINTS 30
#define DOUBLE_LASER_WEAPON_POINTS 40
#define UFO_POINTS 15
// Weapons:
enum {SINGLE_LASER_WEAPON, DOUBLE_LASER_WEAPON};
// Actors:
enum {ASTEROID_ACTOR, UFO_ACTOR, OBJECT_SINGLE_LASER_ACTOR, OBJECT_DOUBLE_LASER_ACTOR,
      OBJECT_LIVE_ACTOR, OBJECT_POWER_INCREASE_ACTOR, OBJECT_FULL_POWER_ACTOR,
	  OBJECT_POINTS_ACTOR, BLACK_HOLE_ACTOR, SINGLE_LASER_SHOT, DOUBLE_LASER_SHOT, UFO_SHOT};
// Players:
enum {PLAYER1_ACTOR, PLAYER2_ACTOR};
// Objects:
extern AS_OBJECT *pInvasion2Obj;
extern AS_OBJECT *pPlayer1Obj;
extern AS_OBJECT *pPlayer2Obj;
extern AS_OBJECT *pAsteroidObj[4];
extern AS_OBJECT *pUFOObj;
extern AS_OBJECT *pSingleLaserWeaponObj;
extern AS_OBJECT *pSingleLaserShotObj;
extern AS_OBJECT *pDoubleLaserWeaponObj;
extern AS_OBJECT *pDoubleLaserShotObj;
extern AS_OBJECT *pUFOShotObj;
extern AS_OBJECT *pObjectSingleLaserObj;
extern AS_OBJECT *pObjectDoubleLaserObj;
extern AS_OBJECT *pObjectLiveObj;
extern AS_OBJECT *pObjectPowerIncreaseObj;
extern AS_OBJECT *pObjectFullPowerObj;
extern AS_OBJECT *pObjectPointsObj;
extern AS_OBJECT *pPowerDisplayObj;
// Sounds:
extern SoundObject *pThrustSound;
extern BOOL bThrustSoundOn[2];
extern SoundObject *pExplosion1Sound;
extern SoundObject *pExplosion2Sound;
extern SoundObject *pShot1Sound;
extern SoundObject *pCollision1Sound;
extern SoundObject *pUFOSound;
///////////////////////////////////////////////////////////////////////////////
// Functions: *****************************************************************
extern HRESULT Game(void);
extern HRESULT GameDraw(AS_WINDOW *);
extern HRESULT GameCheck(AS_WINDOW *);
extern void LoadGameTextures(void);
extern void DestroyGameTextures(void);
extern void LoadSounds(void);
extern void DestroySounds(void);
extern void CreateGameLists(void);
extern void DestroyGameLists(void);
extern void InitGameObjects(void);
extern void DestroyGameObjects(void);
extern void ActivateLights(void);
extern void DeactivateShotLights(void);
extern void SetupMainMenu(void);
extern void DeactivateAllActors(void);
extern void CreateLevel(void);
extern void CreateNewActor(void);
extern HRESULT LoadHighscore(void);
extern HRESULT SaveHighscore(void);
extern void DrawPlayersHighscore(AS_WINDOW *);
extern void CheckPlayersHighscore(void);
extern void GameOver(void);
extern void GameWon(void);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_GAME_H__
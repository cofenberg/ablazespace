#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"

// Variables: *****************************************************************
ACTOR *pPlayer[2];
ACTOR *pShot[MAX_SHOTS];
ACTOR *pActors[MAX_ACTORS];
ACTOR *pParticle1[MAX_PARTICLES];
ACTOR *pParticle2[MAX_PARTICLES];
///////////////////////////////////////////////////////////////////////////////
// Functions: *****************************************************************
void DrawExplosions(void);
void CheckGravity(ACTOR *);
void DrawActors(void);
HRESULT CheckActors(BOOL);
void DrawParticles(void);
void CheckParticles(void);
void CreateSmoke(ACTOR *);
void MakeStars(ACTOR *);
ACTOR *FindNoneActiveActor(void);
ACTOR *FindNoneActiveParticle1(void);
ACTOR *FindNoneActiveParticle2(void);
void CheckBallCollision(ACTOR *, ACTOR *, float, float);
void DivideActor(ACTOR *, ACTOR *);
HRESULT CountAsteroids(void);
void DrawPlayers(void);
HRESULT CheckPlayers(BOOL);
void PlayerDead(short);
void DrawShots(void);
void CheckShots(void);
ACTOR *FindNoneActiveShot(void);
///////////////////////////////////////////////////////////////////////////////

void DrawExplosions(void)
{ // begin DrawExplosions()
	AS_OBJECT *pObject;
	ACTOR *pActor;
	short i;
	float fScale;

	glEnable(GL_TEXTURE_2D);
	glDisable(GL_CULL_FACE);
	glDisable(GL_DEPTH_TEST);
	for(i = 0; i < 2; i++)
	{
		pActor = pPlayer[i];
		if(!pActor->bActive || pActor->iExplosionStep == -1)
			continue;
		glPushMatrix();
		glTranslatef(pActor->fPos[X]+0.5f, pActor->fPos[Y]+0.5f, pActor->fPos[Z]);
		if(!pActor->byPlayer)
			pObject = pPlayer1Obj;
		else
			pObject = pPlayer2Obj;
		glMultMatrixf(pObject->Matrix[0]);
		glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
		fScale = pActor->fRadius*2-((pActor->fRadius*2)-((g_lNow-pActor->lStartTime)/100.0f));
		if(((pActor->fRadius*2)-((g_lNow-pActor->lStartTime))/400.0f) <= 0.0f)
			pActor->bActive = FALSE;
		glScalef(fScale, fScale, fScale);
		fScale = pActor->fRadius*2/(pActor->fRadius*2-((pActor->fRadius*2)-((g_lNow-pActor->lStartTime)/100.0f)));
		glColor4f(1.0f, 1.0f, 1.0f, fScale-0.3f);
		glCallList(iWaveList);
		glRotatef(45.0f, 1.0f, 0.0f, 0.0f);
		glCallList(iWaveList);
		glRotatef(45.0f, 1.0f, 0.0f, 0.0f);
		glCallList(iWaveList);
		glRotatef(45.0f, 1.0f, 0.0f, 0.0f);
		glCallList(iWaveList);
		glPopMatrix();
	}
	for(i = 0; i < MAX_ACTORS; i++)
	{
		pActor = pActors[i];
		if(!pActor->bActive || pActor->iExplosionStep == -1)
			continue;
		glPushMatrix();
		glTranslatef(pActor->fPos[X]+0.5f, pActor->fPos[Y]+0.5f, pActor->fPos[Z]);
		switch(pActor->iType)
		{
			case ASTEROID_ACTOR: pObject = pAsteroidObj[pActor->byPlayer]; break;
			case UFO_ACTOR: pObject = pUFOObj; pActor->fScale = 1.0f; break;
			case OBJECT_SINGLE_LASER_ACTOR: pObject = pObjectSingleLaserObj; break;
			case OBJECT_DOUBLE_LASER_ACTOR: pObject = pObjectDoubleLaserObj; break;
			case OBJECT_LIVE_ACTOR: pObject = pObjectLiveObj; break;
			case OBJECT_POWER_INCREASE_ACTOR: pObject = pObjectPowerIncreaseObj; break;
			case OBJECT_FULL_POWER_ACTOR: pObject = pObjectFullPowerObj; break;
			case OBJECT_POINTS_ACTOR: pObject = pObjectPointsObj; break;
			default: continue;
		}
		glMultMatrixf(pObject->Matrix[0]);
		glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
		fScale = pActor->fRadius*2-((pActor->fRadius*2)-((g_lNow-pActor->lStartTime)/100.0f));
		if(((pActor->fRadius*2)-((g_lNow-pActor->lStartTime))/400.0f) <= 0.0f)
			pActor->bActive = FALSE;
		glScalef(fScale, fScale, fScale);
		fScale = pActor->fRadius*2/(pActor->fRadius*2-((pActor->fRadius*2)-((g_lNow-pActor->lStartTime)/100.0f)));
		glColor4f(1.0f, 1.0f, 1.0f, fScale-0.3f);
		glCallList(iWaveList);
		glRotatef(45.0f, 1.0f, 0.0f, 0.0f);
		glCallList(iWaveList);
		glRotatef(45.0f, 1.0f, 0.0f, 0.0f);
		glCallList(iWaveList);
		glRotatef(45.0f, 1.0f, 0.0f, 0.0f);
		glCallList(iWaveList);
		glPopMatrix();
	}
	glEnable(GL_CULL_FACE);
	glEnable(GL_DEPTH_TEST);
} // end DrawExplosions()

void CheckGravity(ACTOR *pActor)
{ // begin CheckGravity()
	if(!bBlackHole)
		return;
	float f = 1.0f;
	
	if(pActor->iType == SINGLE_LASER_SHOT || pActor->iType == DOUBLE_LASER_SHOT ||
	   pActor->iType == UFO_SHOT)
	   f = 10.0f;
	if(pActor->fPos[X] > 0.0f)
		pActor->fVelocity[X] -= 0.0005f*g_lDeltatime*f;
	if(pActor->fPos[X] < 0.0f)
		pActor->fVelocity[X] += 0.0005f*g_lDeltatime*f;
	if(pActor->fPos[Y] > 0.0f)
		pActor->fVelocity[Y] -= 0.0005f*g_lDeltatime*f;
	if(pActor->fPos[Y] < 0.0f)
		pActor->fVelocity[Y] += 0.0005f*g_lDeltatime*f;
} // end CheckGravity()

void DrawActors(void)
{ // begin DrawActors()
	AS_OBJECT *pObject;
	ACTOR *pActor;
	short i;

	for(i = 0; i < MAX_ACTORS; i++)
	{
		pActor = pActors[i];
		if(!pActor->bActive
		   || (pActor->iExplosionStep != -1 && ((pActor->fRadius*2)-((g_lNow-pActor->lStartTime))/200.0f) <= 0.0f)
		   || (pActor->iExplosionStep != -1 && pActor->iType == ASTEROID_ACTOR) ||
		   pActor->iType == BLACK_HOLE_ACTOR)
			continue;		
		glPushMatrix();
		glTranslatef(pActor->fPos[X], pActor->fPos[Y], pActor->fPos[Z]);
		if(pActor->iType >= OBJECT_SINGLE_LASER_ACTOR && pActor->iType <= OBJECT_POINTS_ACTOR)
		{
			glEnable(GL_TEXTURE_GEN_S);
			glEnable(GL_TEXTURE_GEN_T);
		}
		switch(pActor->iType)
		{
			case ASTEROID_ACTOR: pObject = pAsteroidObj[pActor->byPlayer]; break;
			case UFO_ACTOR: pObject = pUFOObj; pActor->fScale = 1.0f; break;
			case OBJECT_SINGLE_LASER_ACTOR: pObject = pObjectSingleLaserObj; break;
			case OBJECT_DOUBLE_LASER_ACTOR: pObject = pObjectDoubleLaserObj; break;
			case OBJECT_LIVE_ACTOR: pObject = pObjectLiveObj; break;
			case OBJECT_POWER_INCREASE_ACTOR: pObject = pObjectPowerIncreaseObj; break;
			case OBJECT_FULL_POWER_ACTOR: pObject = pObjectFullPowerObj; break;
			case OBJECT_POINTS_ACTOR: pObject = pObjectPointsObj; break;
		}
		glDisable(GL_BLEND);
		glScalef(pActor->fScale, pActor->fScale, pActor->fScale);
		glMultMatrixf(pObject->Matrix[0]);
		// Rotate
		glRotatef(pActor->fRot[X], 1.0f, 0.0f, 0.0f);
		glRotatef(pActor->fRot[Y], 0.0f, 1.0f, 0.0f);
		glRotatef(pActor->fRot[Z], 0.0f, 0.0f, 1.0f);
		pObject->SetAnimationT(pActor->iAnimationT);
		pObject->SetAnimationStepT(pActor->iStepT);
		pObject->pChild[0]->dwLastTime = pActor->dwLastTime;
		pObject->Draw(TRUE, TRUE, _ASConfig->bDrawBounding);
		pActor->dwLastTime = pObject->pChild[0]->dwLastTime;
		pActor->iStepT = pObject->pChild[0]->pAnimationT->pStepT->iID;
		pActor->pFrameT = pObject->pChild[0]->pAnimationT->pStepT->pFrame;
		glPopMatrix();
		if(pActor->iType >= OBJECT_SINGLE_LASER_ACTOR && pActor->iType <= OBJECT_POINTS_ACTOR)
		{
			glDisable(GL_TEXTURE_GEN_S);
			glDisable(GL_TEXTURE_GEN_T);
		}
	}
} // end DrawActors()

HRESULT CheckActors(BOOL bOnlyCheck)
{ // begin CheckActors()
	ACTOR *pActor1, *pActor2;
	float fDeltaX, fDeltaY, fDistance;
	BOOL bCollision = FALSE;
	short i, i2;

	for(i = 0; i < MAX_ACTORS; i++)
	{
		pActor1 = pActors[i];
		if(!pActor1->bActive)
			continue;
		if(!bOnlyCheck)
		{
			pActor1->fLastPos[X] = pActor1->fPos[X];
			pActor1->fPos[X] += (pActor1->fVelocity[X]*g_lDeltatime)/55.0f;
			pActor1->fLastPos[Y] = pActor1->fPos[Y];
			pActor1->fPos[Y] += (pActor1->fVelocity[Y]*g_lDeltatime)/55.0f;
			if(pActor1->fPos[X]-pActor1->fRadius > SPACE_WIDTH && pActor1->fVelocity[X] > 0.0f)
				pActor1->fPos[X] = -SPACE_WIDTH-pActor1->fRadius;
			if(pActor1->fPos[X]+pActor1->fRadius < -SPACE_WIDTH && pActor1->fVelocity[X] < 0.0f)
				pActor1->fPos[X] = SPACE_WIDTH+pActor1->fRadius;
			if(pActor1->fPos[Y]-pActor1->fRadius > SPACE_HEIGHT && pActor1->fVelocity[Y] > 0.0f)
				pActor1->fPos[Y] = -SPACE_HEIGHT-pActor1->fRadius;
			if(pActor1->fPos[Y]+pActor1->fRadius < -SPACE_HEIGHT && pActor1->fVelocity[Y] < 0.0f)
				pActor1->fPos[Y] = SPACE_HEIGHT+pActor1->fRadius;
			CheckGravity(pActor1);
			if(pActor1->fVelocity[X] > 0.5f)
				pActor1->fVelocity[X] = 0.5f;
			if(pActor1->fVelocity[X] < -0.5f)
				pActor1->fVelocity[X] = -0.5f;
			if(pActor1->fVelocity[Y] > 0.5f)
				pActor1->fVelocity[Y] = 0.5f;
			if(pActor1->fVelocity[Y] < -0.5f)
				pActor1->fVelocity[Y] = -0.5f;
			pActor1->fRot[X] += pActor1->fRotVelocity[X]*g_lDeltatime;
			pActor1->fRot[Y] += pActor1->fRotVelocity[Y]*g_lDeltatime;
			pActor1->fRot[Z] += pActor1->fRotVelocity[Z]*g_lDeltatime;
			if(pActor1->iType == UFO_ACTOR && pActor1->iExplosionStep == -1)
			{
				if((g_lNow-pActor1->lLastShotTime) > 300)
				{
					pActor1->lLastShotTime = g_lNow;
					CreateSmoke(pActor1);
				}
				if((rand() % 100) == 5)
				{ // The UFO changes the direction:
					if(rand() % 2)
						pActor1->fVelocity[X] = ((float) (rand() % 100))/1000.0f+0.1f;
					else
						pActor1->fVelocity[X] = -((float) (rand() % 100))/1000.0f-0.1f;
					if(rand() % 2)
						pActor1->fVelocity[Y] = ((float) (rand() % 100))/1000.0f+0.1f;
					else
						pActor1->fVelocity[Y] = -((float) (rand() % 100))/1000.0f-0.1f;
					pActor1->fRotVelocity[Z] = ((float) (rand() % 100)/2000.0f)+0.3f;
				}
				if((g_lNow-pActor1->lLastShotTime2) > 500)
				{ // The UFO fires a shot:
					pActor1->lLastShotTime2 = g_lNow;
					pActor2 = FindNoneActiveShot();
					if(pActor2)
					{
						pActor2->Init();
						pActor2->bActive = TRUE;
						pActor2->fRadius = 0.7f;
						pActor2->fPos[X] = pActor1->fPos[X];
						pActor2->fPos[Y] = pActor1->fPos[Y];
						pActor2->fPos[Z] = pActor1->fPos[Z];
						pActor2->iType = UFO_SHOT;
						pActor2->lStartTime = g_lNow;
						pActor2->lEndTime = pActor2->lStartTime+2000;
						if(rand() % 2)
							pActor2->fVelocity[X] = ((float) (rand() % 100))/1000.0f+0.1f;
						else
							pActor2->fVelocity[X] = -((float) (rand() % 100))/1000.0f-0.1f;
						if(rand() % 2)
							pActor2->fVelocity[Y] = ((float) (rand() % 100))/1000.0f+0.1f;
						else
							pActor2->fVelocity[Y] = -((float) (rand() % 100))/1000.0f-0.1f;
						DSUtil_PlaySound(pUFOSound, 0);
					}
				}
			}
		}
		if(pActor1->iExplosionStep != -1)
			continue;
		// Check if we have a collision between two actors:
		for(i2 = 0; i2 < MAX_ACTORS; i2++)
		{
			if(i2 == i)
				continue;
			pActor2 = pActors[i2];
			if(!pActor2->bActive || pActor2->iExplosionStep != -1)
				continue;
			fDeltaX = pActor1->fPos[X]-pActor2->fPos[X];
			fDeltaY = pActor1->fPos[Y]-pActor2->fPos[Y];
			fDistance = (fDeltaX*fDeltaX+fDeltaY*fDeltaY);
			if(fDistance <= (pActor1->fRadius+pActor2->fRadius)*(pActor1->fRadius+pActor2->fRadius))
			{
				bCollision = TRUE;
				if(bOnlyCheck)
					continue;
				// We have a collision!
				pActor1->fPos[X] = pActor1->fLastPos[X];
				pActor1->fPos[Y] = pActor1->fLastPos[Y];
				// Make the asteroids smaller:
				if(pActor1->iType == UFO_ACTOR && (pActor2->iType == ASTEROID_ACTOR ||
				   pActor2->iType == BLACK_HOLE_ACTOR))
				{
					pActor1->iExplosionStep = 0;
					pActor1->lStartTime = g_lNow;
					pActor1->fVelocity[X] = 0.0f;
					pActor1->fVelocity[Y] = 0.0f;
					pActor1->fRotVelocity[X] = 0.3f;
					pActor1->fRotVelocity[Y] = 0.3f;
					DSUtil_PlaySound(pExplosion2Sound, 0);
					MakeStars(pActor1);
				}
				else
				if(pActor2->iType == UFO_ACTOR && (pActor1->iType == ASTEROID_ACTOR ||
				   pActor1->iType == BLACK_HOLE_ACTOR))
				{
					pActor2->iExplosionStep = 0;
					pActor2->lStartTime = g_lNow;
					pActor2->fVelocity[X] = 0.0f;
					pActor2->fVelocity[Y] = 0.0f;
					pActor2->fRotVelocity[X] = 0.3f;
					pActor2->fRotVelocity[Y] = 0.3f;
					DSUtil_PlaySound(pExplosion2Sound, 0);
					MakeStars(pActor1);
				}
				else
				if(pActor1->iType == BLACK_HOLE_ACTOR && pActor2->iType == ASTEROID_ACTOR)
				{
					pActor2->fScale -= 0.005f;
					pActor2->fRadius = 6.5f*pActor2->fScale;
					pActor2->fMass = pActor2->fRadius*((float) PI);
					if(pActor2->fRadius <= 0.5f)
					{
						pActor2->bActive = FALSE;
						if((rand() % 2) == 1)
							CreateNewActor();
						continue;
					}
				}
				else
				if(pActor2->iType == BLACK_HOLE_ACTOR && pActor1->iType == ASTEROID_ACTOR)
				{
					pActor1->fScale -= 0.005f;
					pActor1->fRadius = 6.5f*pActor1->fScale;
					pActor1->fMass = pActor1->fRadius*((float) PI);
					if(pActor1->fRadius <= 0.5f)
					{
						pActor1->bActive = FALSE;
						if((rand() % 2) == 1)
							CreateNewActor();
						continue;
					}
				}
				else
				if(pActor1->iType == ASTEROID_ACTOR && pActor2->iType == ASTEROID_ACTOR)
				{
					pActor1->fScale -= 0.001f;
					pActor1->fRadius = 6.0f*pActor1->fScale;
					pActor1->fMass = pActor1->fRadius*((float) PI);
					if(pActor1->fRadius <= 0.5f)
					{
						pActor1->bActive = FALSE;
						if((rand() % 2) == 1)
							CreateNewActor();
					}
				}
				else
				if(pActor1->iType == ASTEROID_ACTOR && pActor2->iType == ASTEROID_ACTOR)
				{
					pActor2->fScale -= 0.001f;
					pActor2->fRadius = 6.0f*pActor2->fScale;
					pActor2->fMass = pActor2->fRadius*((float) PI);
					if(pActor2->fRadius <= 0.5f)
					{
						pActor2->bActive = FALSE;
						if((rand() % 2) == 1)
							CreateNewActor();
					}
				}
				else
				{
					if(pActor1->iType == BLACK_HOLE_ACTOR && pActor2->iType != BLACK_HOLE_ACTOR)
					{
						pActor2->iExplosionStep = 0;
						pActor2->lStartTime = g_lNow;
						pActor2->fVelocity[X] = 0.0f;
						pActor2->fVelocity[Y] = 0.0f;
						pActor2->fRotVelocity[X] = 0.3f;
						pActor2->fRotVelocity[Y] = 0.3f;
						DSUtil_PlaySound(pExplosion2Sound, 0);
						MakeStars(pActor2);
					}
					else
					if(pActor1->iType != BLACK_HOLE_ACTOR && pActor2->iType == BLACK_HOLE_ACTOR)
					{
						pActor1->iExplosionStep = 0;
						pActor1->lStartTime = g_lNow;
						pActor1->fVelocity[X] = 0.0f;
						pActor1->fVelocity[Y] = 0.0f;
						pActor1->fRotVelocity[X] = 0.3f;
						pActor1->fRotVelocity[Y] = 0.3f;
						DSUtil_PlaySound(pExplosion2Sound, 0);
						MakeStars(pActor1);
					}
				}
				pActor1->fRotVelocity[X] = ((float) (rand() % 100)/2000.0f);
				pActor1->fRotVelocity[Y] = ((float) (rand() % 100)/2000.0f);
				pActor2->fRotVelocity[X] = ((float) (rand() % 100)/2000.0f);
				pActor2->fRotVelocity[Y] = ((float) (rand() % 100)/2000.0f);
				if(pActor1->iType != BLACK_HOLE_ACTOR && pActor2->iType != BLACK_HOLE_ACTOR)
					CheckBallCollision(pActor1, pActor2, fDeltaX, fDeltaY);
			}
		}
	}
	if(bBlackHole)
	{
		if(g_lNow > lNextBlackHoleParticleTime)
		{
			lNextBlackHoleParticleTime = g_lNow+50;
			// Fire:
			pActor2 = FindNoneActiveParticle1();
			if(pActor2)
			{
				pActor2->Init();
				pActor2->bActive = TRUE;
				pActor2->fPos[X] = 0.0f;
				pActor2->fPos[Y] = 0.0f;
				pActor2->fPos[Z] = 0.0f;
				pActor2->lStartTime = g_lNow;
				pActor2->lEndTime = pActor2->lStartTime+700+(rand() % 100);
				pActor2->fRed = 0.0f;
				if((rand() % 2) == 1)
				{
					pActor2->fGreen = (float) (rand() % 100)/100.0f;
					pActor2->fBlue = 0.0f;
				}
				else
				{
					pActor2->fGreen = 0.0f;
					pActor2->fBlue = (float) (rand() % 100)/100.0f;
				}
			}
		}
	}
	if(bMainMenu || (bDeadMatch && !bUFOS) || bOnlyCheck)
		return 0;
	if(!bDeadMatch && CountAsteroids() < 4)
		CreateNewActor();
	if(bOccurrences && !bNoBlackHole)
	{
		if(!bBlackHole && (rand() % 10000) == 5000)
		{ // Activate the black hole:
			pActor1 = FindNoneActiveActor();
			if(pActor1)
			{
				bBlackHole = TRUE;
				pActor1->Init();
				pActor1->bActive = TRUE;
				pActor1->iType = BLACK_HOLE_ACTOR;
				pActor1->fRadius = 2.0f;
			}
		}
		else
		{
			if(bBlackHole && (rand() % 3000) == 2000)
			{
				bBlackHole = FALSE;
				for(i = 0; i < MAX_ACTORS; i++)
				{
					if(!pActors[i]->bActive)
						continue;
					if(pActors[i]->iType == BLACK_HOLE_ACTOR)
					{
						pActors[i]->bActive = FALSE;
						break;
					}
				}
			}
		}
	}
	// Check if we should create a ufo:
	if(!bOnlyCheck && g_lNow > lNextUfoTime && (rand() % 500) == 5)
	{
		lNextUfoTime = g_lNow+10000;
		pActor1 = FindNoneActiveActor();
		if(!pActor1)
			goto Next;
		pActor1->Init();
		pActor1->bActive = TRUE;
		pActor1->fScale = 1.0f;
		pActor1->fRadius = 1.5f*pActor1->fScale;
		pActor1->fMass = pActor1->fRadius*((float) PI);
		if(rand() % 2)
			pActor1->fVelocity[X] = ((float) (rand() % 100))/1000.0f+0.1f;
		else
			pActor1->fVelocity[X] = -((float) (rand() % 100))/1000.0f-0.1f;
		if(rand() % 2)
			pActor1->fVelocity[Y] = ((float) (rand() % 100))/1000.0f+0.1f;
		else
			pActor1->fVelocity[Y] = -((float) (rand() % 100))/1000.0f-0.1f;
		pActor1->fRotVelocity[Z] = ((float) (rand() % 100)/2000.0f)+0.3f;
		pActor1->iType = UFO_ACTOR;
		for(i = 0; i < 100; i++)
		{
			if(pActor1->fVelocity[X] > 0.0f)
				pActor1->fPos[X] = -SPACE_WIDTH-5.0f;
			else
				pActor1->fPos[X] = SPACE_WIDTH+5.0f;
			if(pActor1->fVelocity[Y] > 0.0f)
				pActor1->fPos[Y] = SPACE_HEIGHT-5.0f;
			else
				pActor1->fPos[Y] = SPACE_HEIGHT+5.0f;
			if(CheckActors(TRUE))
				continue;
		}
	}
	Next:
	return bCollision;
} // end CheckActors()

void DrawParticles(void)
{ // begin DrawParticles()
	ACTOR *pActor;
	short i;
	
	if(!_ASConfig->bParticles)
		return;
	glDisable(GL_LIGHTING);
	glDisable(GL_CULL_FACE);
	glDisable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	// Particle 1:
	glBindTexture(GL_TEXTURE_2D, GameTexture[9].iOpenGLID);
	for(i = 0; i < MAX_PARTICLES; i++)
	{
		pActor = pParticle1[i];
		if(!pActor->bActive)
			continue;		
		glPushMatrix();
		glTranslatef(pActor->fPos[X], pActor->fPos[Y], pActor->fPos[Z]);
		glMultMatrixf(pPlayer1Obj->Matrix[0]);
		glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
		glColor4f(pActor->fRed, pActor->fGreen, pActor->fBlue, 1.0f-(float) (g_lNow-pActor->lStartTime+1)/(pActor->lEndTime-pActor->lStartTime+0.1f));
		glScalef(pActor->fScale, pActor->fScale, pActor->fScale);
		glCallList(iSmokeList);
		glPopMatrix();
	}
	// Particle 2:
	glBindTexture(GL_TEXTURE_2D, GameTexture[10].iOpenGLID);
	for(i = 0; i < MAX_PARTICLES; i++)
	{
		pActor = pParticle2[i];
		if(!pActor->bActive)
			continue;		
		glPushMatrix();
		glTranslatef(pActor->fPos[X], pActor->fPos[Y], pActor->fPos[Z]);
		glMultMatrixf(pPlayer1Obj->Matrix[0]);
		glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
		glColor4f(pActor->fRed, pActor->fGreen, pActor->fBlue, 1.0f-(float) (g_lNow-pActor->lStartTime+1)/(pActor->lEndTime-pActor->lStartTime+0.1f));
		glScalef(pActor->fScale, pActor->fScale, pActor->fScale);
		glCallList(iStarList);
		glPopMatrix();
	}
	glEnable(GL_LIGHTING);
	glEnable(GL_CULL_FACE);
	glEnable(GL_DEPTH_TEST);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND);
	glDisable(GL_BLEND);
} // end DrawParticles()

void CheckParticles(void)
{ // begin CheckParticles()
	ACTOR *pActor1;
	short i;

	if(!_ASConfig->bParticles)
		return;
	// Particle 1:
	for(i = 0; i < MAX_ACTORS; i++)
	{
		pActor1 = pParticle1[i];
		if(!pActor1->bActive)
			continue;
		pActor1->fScale = pActor1->fRadius*2-((pActor1->fRadius*2)-((g_lNow-pActor1->lStartTime)/100.0f));
		if(g_lNow > pActor1->lEndTime)
		{
			pActor1->bActive = FALSE;
			continue;
		}
		pActor1->fLastPos[X] = pActor1->fPos[X];
		pActor1->fPos[X] += (pActor1->fVelocity[X]*g_lDeltatime)/55.0f;
		pActor1->fLastPos[Y] = pActor1->fPos[Y];
		pActor1->fPos[Y] += (pActor1->fVelocity[Y]*g_lDeltatime)/55.0f;
		if(pActor1->fPos[X]-pActor1->fRadius > SPACE_WIDTH && pActor1->fVelocity[X] > 0.0f)
			pActor1->fPos[X] = -SPACE_WIDTH-pActor1->fRadius;
		if(pActor1->fPos[X]+pActor1->fRadius < -SPACE_WIDTH && pActor1->fVelocity[X] < 0.0f)
			pActor1->fPos[X] = SPACE_WIDTH+pActor1->fRadius;
		if(pActor1->fPos[Y]-pActor1->fRadius > SPACE_HEIGHT && pActor1->fVelocity[Y] > 0.0f)
			pActor1->fPos[Y] = -SPACE_HEIGHT-pActor1->fRadius;
		if(pActor1->fPos[Y]+pActor1->fRadius < -SPACE_HEIGHT && pActor1->fVelocity[Y] < 0.0f)
			pActor1->fPos[Y] = SPACE_HEIGHT+pActor1->fRadius;
	}
	// Particle 2:
	for(i = 0; i < MAX_ACTORS; i++)
	{
		pActor1 = pParticle2[i];
		if(!pActor1->bActive)
			continue;
		pActor1->fScale = 2.0f-pActor1->fRadius*2-((pActor1->fRadius*2)-((g_lNow-pActor1->lStartTime)/100.0f));
		if(g_lNow > pActor1->lEndTime)
		{
			pActor1->bActive = FALSE;
			continue;
		}
		pActor1->fLastPos[X] = pActor1->fPos[X];
		pActor1->fPos[X] += (pActor1->fVelocity[X]*g_lDeltatime)/55.0f;
		pActor1->fLastPos[Y] = pActor1->fPos[Y];
		pActor1->fPos[Y] += (pActor1->fVelocity[Y]*g_lDeltatime)/55.0f;
		if(pActor1->fPos[X]-pActor1->fRadius > SPACE_WIDTH && pActor1->fVelocity[X] > 0.0f)
			pActor1->fPos[X] = -SPACE_WIDTH-pActor1->fRadius;
		if(pActor1->fPos[X]+pActor1->fRadius < -SPACE_WIDTH && pActor1->fVelocity[X] < 0.0f)
			pActor1->fPos[X] = SPACE_WIDTH+pActor1->fRadius;
		if(pActor1->fPos[Y]-pActor1->fRadius > SPACE_HEIGHT && pActor1->fVelocity[Y] > 0.0f)
			pActor1->fPos[Y] = -SPACE_HEIGHT-pActor1->fRadius;
		if(pActor1->fPos[Y]+pActor1->fRadius < -SPACE_HEIGHT && pActor1->fVelocity[Y] < 0.0f)
			pActor1->fPos[Y] = SPACE_HEIGHT+pActor1->fRadius;
	}
} // end CheckParticles()

void CreateSmoke(ACTOR *pActor1)
{ // begin CreateSmoke()
	float f;
	ACTOR *pActor2;

	// Smoke
	pActor2 = FindNoneActiveParticle1();
	if(pActor2)
	{
		pActor2->Init();
		pActor2->bActive = TRUE;
		pActor2->fPos[X] = pActor1->fPos[X]+(float) cos((pActor1->fRot[Y]+pActor1->fTempRot2[Y]-90.0f)*ltconvertdegtorad);
		pActor2->fPos[Y] = pActor1->fPos[Y]+(float) sin((pActor1->fRot[Y]+pActor1->fTempRot2[Y]-90.0f)*ltconvertdegtorad);
		pActor2->fPos[Z] = pActor1->fPos[Z];
		pActor2->lStartTime = g_lNow;
		pActor2->lEndTime = pActor2->lStartTime+1000+(rand() % 500);
		f = (float) (rand() % 100)/100.0f;
		pActor2->fRed = f;
		pActor2->fGreen = f;
		pActor2->fBlue = f;
	}
	// Fire:
	pActor2 = FindNoneActiveParticle1();
	if(pActor2)
	{
		pActor2->Init();
		pActor2->bActive = TRUE;
		pActor2->fPos[X] = pActor1->fPos[X]+(float) cos((pActor1->fRot[Y]+pActor1->fTempRot2[Y]-90.0f)*ltconvertdegtorad);
		pActor2->fPos[Y] = pActor1->fPos[Y]+(float) sin((pActor1->fRot[Y]+pActor1->fTempRot2[Y]-90.0f)*ltconvertdegtorad);
		pActor2->fPos[Z] = pActor1->fPos[Z];
		pActor2->lStartTime = g_lNow;
		pActor2->lEndTime = pActor2->lStartTime+700+(rand() % 100);
		pActor2->fRed = 1.0f;
		pActor2->fGreen = 1.0f;
		pActor2->fBlue = (float) (rand() % 100)/100.0f;
	}
	// Fire:
	pActor2 = FindNoneActiveParticle1();
	if(pActor2)
	{
		pActor2->Init();
		pActor2->bActive = TRUE;
		pActor2->fPos[X] = pActor1->fPos[X]+(float) cos((pActor1->fRot[Y]+pActor1->fTempRot2[Y]-90.0f)*ltconvertdegtorad)*2;
		pActor2->fPos[Y] = pActor1->fPos[Y]+(float) sin((pActor1->fRot[Y]+pActor1->fTempRot2[Y]-90.0f)*ltconvertdegtorad)*2;
		pActor2->fPos[Z] = pActor1->fPos[Z];
		pActor2->lStartTime = g_lNow;
		pActor2->lEndTime = pActor2->lStartTime+600+(rand() % 100);
		pActor2->fRed = (float) (rand() % 50)/100.0f+0.5f;
		pActor2->fGreen = 0.0f;
		pActor2->fBlue = 0.0;
	}
} // end CreateSmoke()

void MakeStars(ACTOR *pActor1)
{ // begin MakeStars()
	ACTOR *pActor2;
	short i, i2;

	i2 = (rand() % 10)+5;
	for(i = 0; i < i2; i++)
	{
		pActor2 = FindNoneActiveParticle2();
		if(!pActor2)
			break;
		pActor2->Init();
		pActor2->bActive = TRUE;
		if(rand() % 2)
			pActor2->fPos[X] = pActor1->fPos[X]+((float) (rand() % 100))/100.0f;
		else
			pActor2->fPos[X] = pActor1->fPos[X]-((float) (rand() % 100))/100.0f;
		if(rand() % 2)
			pActor2->fPos[Y] = pActor1->fPos[Y]+((float) (rand() % 100))/100.0f;
		else
			pActor2->fPos[Y] = pActor1->fPos[Y]-((float) (rand() % 100))/100.0f;
		pActor2->fPos[Z] = pActor1->fPos[Z];
		pActor2->lStartTime = g_lNow;
		pActor2->fRadius = 2.0f+((float) (rand() % 100)/100.0f);
		pActor2->lEndTime = pActor2->lStartTime+500+(rand() % 250);
		pActor2->fRed = (float) (rand() % 100)/100.0f;
		pActor2->fGreen = (float) (rand() % 100)/100.0f;
		pActor2->fBlue = (float) (rand() % 100)/100.0f;
		if(rand() % 2)
			pActor2->fVelocity[X] = ((float) (rand() % 100))/100.0f;
		else
			pActor2->fVelocity[X] = -((float) (rand() % 100))/100.0f;
		if(rand() % 2)
			pActor2->fVelocity[Y] = ((float) (rand() % 100))/100.0f;
		else
			pActor2->fVelocity[Y] = -((float) (rand() % 100))/100.0f;
	}
} // end MakeStars()

ACTOR *FindNoneActiveActor(void)
{ // begin FindNoneActiveActor()
	for(short i = 0; i < MAX_ACTORS; i++)
	{
		if(!pActors[i]->bActive)
			return pActors[i];
	}
	return NULL;
} // end FindNoneActiveActor()

ACTOR *FindNoneActiveParticle1(void)
{ // begin FindNoneActiveParticle1()
	if(!_ASConfig->bParticles)
		return NULL;
	for(short i = 0; i < MAX_PARTICLES; i++)
	{
		if(!pParticle1[i]->bActive)
			return pParticle1[i];
	}
	return NULL;
} // end FindNoneActiveParticle1()

ACTOR *FindNoneActiveParticle2(void)
{ // begin FindNoneActiveParticle2()
	if(!_ASConfig->bParticles)
		return NULL;
	for(short i = 0; i < MAX_PARTICLES; i++)
	{
		if(!pParticle2[i]->bActive)
			return pParticle2[i];
	}
	return NULL;
} // end FindNoneActiveParticle1()

void CheckBallCollision(ACTOR *pActor1, ACTOR *pActor2, float fDeltaX, float fDeltaY)
{ // begin CheckBallCollision()
	float fContactAngle,
		  fXClosingVelocity, fYClosingVelocity, fResVelocity, fXContactVelocity,
		  fYContactVelocity, fClosingAngle, fMassFactor, fMass1, fMass2, fAdiff, fPortion;

	// Determine the angle of contact
	if(fDeltaX != 0)
	{
		fContactAngle = (float) atan(fDeltaY/fDeltaX);
		if(fContactAngle < 0)
			fContactAngle = -fContactAngle;
	}
	else
		fContactAngle = (float)  PId2;
	// To determine how the objects will rebound off of each
	// other, we are not concerned with the speed of each
	// object, but rather the relative, or closing, speeds
	// of the two objects.
	fXClosingVelocity = pActor2->fVelocity[X]-pActor1->fVelocity[X];
	fYClosingVelocity = pActor2->fVelocity[Y]-pActor1->fVelocity[Y];
	// Calculate the x & y speed in the direction of contact
	fResVelocity = (float)  sqrt(fXClosingVelocity*fXClosingVelocity+fYClosingVelocity*fYClosingVelocity);
	fXContactVelocity = (float)  cos(fContactAngle)*fResVelocity;
	fYContactVelocity = (float)  sin(fContactAngle)*fResVelocity;
	// Now, determine the closing angle.
	if(fXClosingVelocity != 0)
	{
		fClosingAngle = (float) atan(fYClosingVelocity/fXClosingVelocity);
		if(fClosingAngle < 0)
			fClosingAngle = -fClosingAngle;
	}
	else
		fClosingAngle = (float) PId2;
	// Hmmmm...
	// With equal masses,
	// the max rebound speed is 1/2 the closing speed.
	// With unequal masses,
	// the max rebound speed is the closing speed.
	// Okay then,
	// Normalize the two masses to be:  mass1 + mass2 = 2.0
	fMassFactor = 2/(pActor1->fMass+pActor2->fMass);
	fMass1 = pActor1->fMass*fMassFactor;
	fMass2 = pActor2->fMass*fMassFactor;
	// Quadrant-specific stuff
	if(pActor1->fPos[X] > pActor2->fPos[X])
	{
		if(pActor1->fPos[Y] < pActor2->fPos[Y])
		{
			// pActor1 is contacting upper right quadrant of pActor2
			if(fYClosingVelocity < 0)
			{
				if(fXClosingVelocity < 0)
					fAdiff = (float) PI-fContactAngle-fClosingAngle;
				else
					fAdiff = fContactAngle-fClosingAngle;
			}
			else
				fAdiff = fContactAngle+fClosingAngle;
			fPortion = (float) cos(fAdiff);
			pActor1->fVelocity[X] += fXContactVelocity*fPortion*fMass2;
			pActor1->fVelocity[Y] -= fYContactVelocity*fPortion*fMass2;
			pActor2->fVelocity[X] -= fXContactVelocity*fPortion*fMass1;
			pActor2->fVelocity[Y] += fYContactVelocity*fPortion*fMass1;
		}
		else
		{
			// pActor1 is contacting lower right quadrant of pActor2
			if(fYClosingVelocity > 0)
			{
				if(fXClosingVelocity < 0)
					fAdiff = (float) PI-fContactAngle-fClosingAngle;
				else
					fAdiff = fContactAngle-fClosingAngle;
			}
			else
				fAdiff = fContactAngle+fClosingAngle;
			fPortion = (float) cos(fAdiff);
			pActor1->fVelocity[X] += fXContactVelocity*fPortion*fMass2;
			pActor1->fVelocity[Y] += fYContactVelocity*fPortion*fMass2;
			pActor2->fVelocity[X] -= fXContactVelocity*fPortion*fMass1;
			pActor2->fVelocity[Y] -= fYContactVelocity*fPortion*fMass1;
		}
	}
	else
	{
		if(pActor1->fPos[Y] < pActor2->fPos[Y])
		{
			// pActor1 is contacting upper left quadrant of pActor2
			if(fYClosingVelocity < 0)
			{
				if(fXClosingVelocity < 0)
					fAdiff = fContactAngle-fClosingAngle;
				else
					fAdiff = (float) PI-fContactAngle-fClosingAngle;
			}
			else
				fAdiff = fContactAngle+fClosingAngle;
			fPortion = (float) cos(fAdiff);
			pActor1->fVelocity[X] -= fXContactVelocity*fPortion*fMass2;
			pActor1->fVelocity[Y] -= fYContactVelocity*fPortion*fMass2;
			pActor2->fVelocity[X] += fXContactVelocity*fPortion*fMass2;
			pActor2->fVelocity[Y] += fYContactVelocity*fPortion*fMass2;
		}
		else
		{
			// pActor1 is contacting lower left quadrant of pActor2
			if(fYClosingVelocity > 0)
			{
				if(fXClosingVelocity < 0)
					fAdiff = fContactAngle-fClosingAngle;
				else
					fAdiff = (float) PI-fContactAngle-fClosingAngle;
			}
			else
				fAdiff = fContactAngle+fClosingAngle;
			fPortion = (float) cos(fAdiff);
			pActor1->fVelocity[X] -= fXContactVelocity*fPortion*fMass2;
			pActor1->fVelocity[Y] += fYContactVelocity*fPortion*fMass2;
			pActor2->fVelocity[X] += fXContactVelocity*fPortion*fMass1;
			pActor2->fVelocity[Y] -= fYContactVelocity*fPortion*fMass1;
		}
	}
} // end CheckBallCollision()

void DivideActor(ACTOR *pActor, ACTOR *pActor2)
{ // begin DivideActor()
	ACTOR *pActor3;

	if(pActor && pActor->iType != UFO_SHOT)
		iPlayerScore[pActor->byPlayer] += ASTEROID_POINTS;
	MakeStars(pActor2);
	pActor3 = FindNoneActiveActor();
	if(!pActor3)
		return;
	memcpy(pActor3, pActor2, sizeof(ACTOR));
	// Destroy the old actor:
	pActor2->fVelocity[X] = pActor2->fVelocity[Y] = 0.0f;
	pActor2->iExplosionStep = 0;
	pActor2->lStartTime = g_lNow;
	// Divide the actor:
	if(!bMoorhuhnModus)
		pActor3->byPlayer = rand() % 4;
	pActor3->fScale /= 2.0f;
	pActor3->fRadius = 6.5f*pActor3->fScale;
	pActor3->fMass = pActor3->fRadius*((float) PI);
	pActor3->fPos[X] -= pActor3->fRadius;
	pActor3->fPos[Y] -= pActor3->fRadius;
	if(pActor3->fRadius <= 0.5f)
	{ // This actor isn't more!
		pActor3->bActive = FALSE;
		if((rand() % 2) == 1)
			CreateNewActor();
		return;
	}					
	pActor2 = pActor3;
	pActor3 = FindNoneActiveActor();
	if(!pActor3)
		return;
	if((rand() % 10) == 5)
		CreateNewActor();
	memcpy(pActor3, pActor2, sizeof(ACTOR));
	if(!bMoorhuhnModus)
		pActor3->byPlayer = rand() % 4;
	pActor3->fPos[X] += pActor3->fRadius*2;
	pActor3->fPos[Y] += pActor3->fRadius*2;
	pActor3->fVelocity[X] = -pActor3->fVelocity[X];
	pActor3->fVelocity[Y] = -pActor3->fVelocity[Y];
	pActor2->fVelocity[X] *= 1.5f;
	pActor3->fVelocity[X] *= 1.5f;
	pActor2->fVelocity[Y] *= 1.5f;
	pActor3->fVelocity[Y] *= 1.5f;
} // end DivideActor()

HRESULT CountAsteroids(void)
{ // begin CountAsteroids()
	short i, i2 = 0;

	for(i = 0; i < MAX_ACTORS; i++)
	{
		if(!pActors[i]->bActive)
			continue;
		if(pActors[i]->iType == ASTEROID_ACTOR)
			i2++;
	}
	return i2;
} // end CountAsteroids()

void DrawPlayers(void)
{ // begin DrawPlayers()
	AS_OBJECT *pObject;
	ACTOR *pActor;
	short i;

	for(i = 0; i < 2; i++)
	{
		glDisable(GL_BLEND);
		pActor = pPlayer[i];
		if(!pActor->bActive
		   || (pActor->iExplosionStep != -1 && ((pActor->fRadius*2)-((g_lNow-pActor->lStartTime))/200.0f) <= 0.0f))
			continue;		
		glPushMatrix();
		glTranslatef(pActor->fPos[X], pActor->fPos[Y], pActor->fPos[Z]);
		glBindTexture(GL_TEXTURE_2D, GameTexture[5].iOpenGLID);
		if(pActor->bShield)
		{
			glEnable(GL_TEXTURE_GEN_S);
			glEnable(GL_TEXTURE_GEN_T);
			glEnable(GL_BLEND);
			if(!i)
				glColor4f(1.0f, 0.0f, 0.0f, 0.95f);
			else
				glColor4f(0.0f, 1.0f, 0.0f, 0.95f);
		}
		if(!i)
			pObject = pPlayer1Obj;
		else
			pObject = pPlayer2Obj;
		glMultMatrixf(pObject->Matrix[0]);
		// Rotate
		glRotatef(pActor->fRot[X]+pActor->fTempRot2[X], 1.0f, 0.0f, 0.0f);
		glRotatef(pActor->fRot[Y]+pActor->fTempRot2[Y], 0.0f, 1.0f, 0.0f);
		glRotatef(pActor->fRot[Z]+pActor->fTempRot2[Z], 0.0f, 0.0f, 1.0f);
		pObject->SetAnimationT(pActor->iAnimationT);
		pObject->SetAnimationStepT(pActor->iStepT);
		pObject->pChild[0]->dwLastTime = pActor->dwLastTime;
		// Set the right weapon:
		switch(byPlayerWeapon[i])
		{
			case SINGLE_LASER_WEAPON: pObject->pChild[1]->pTemp = pSingleLaserWeaponObj; break;
			case DOUBLE_LASER_WEAPON: pObject->pChild[1]->pTemp = pDoubleLaserWeaponObj; break;
		}
		pObject->Draw(TRUE, TRUE, _ASConfig->bDrawBounding);
		pObject->pChild[1]->pTemp = NULL;
		pActor->dwLastTime = pObject->pChild[0]->dwLastTime;
		pActor->iStepT = pObject->pChild[0]->pAnimationT->pStepT->iID;
		pActor->pFrameT = pObject->pChild[0]->pAnimationT->pStepT->pFrame;
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
		if(pActor->bShield)
		{
			glPopMatrix();
			glPushMatrix();
			if(!i)
				glColor4f(1.0f, 0.0f, 0.0f, 0.95f);
			else
				glColor4f(0.0f, 1.0f, 0.0f, 0.95f);
			glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
			glTranslatef(pActor->fPos[X], pActor->fPos[Y], pActor->fPos[Z]);
			glMultMatrixf(pObject->Matrix[0]);
			glDisable(GL_CULL_FACE);
			glDepthMask(FALSE);
			glScalef(pActor->fRadius*1.5f, pActor->fRadius*1.5f, pActor->fRadius*1.5f);
			glEnable(GL_BLEND);
			glRotatef(pActor->fTempRot[X], 0.0f, 0.0f, 1.0f);
			glRotatef(pActor->fTempRot[Y], 1.0f, 0.0f, 0.0f);
			glRotatef(pActor->fTempRot[Z], 1.0f, 0.0f, 0.0f);
			glCallList(iShieldList);
			glRotatef(pActor->fTempRot[X]*-2.0f, 0.0f, 0.0f, 1.0f);
			glRotatef(pActor->fTempRot[Y]*-2.0f, 1.0f, 0.0f, 0.0f);
			glRotatef(pActor->fTempRot[Z]*-2.0f, 1.0f, 0.0f, 0.0f);
			glCallList(iShieldList);
			glRotatef(pActor->fTempRot[X]*1.5f, 0.0f, 0.0f, 1.0f);
			glRotatef(pActor->fTempRot[Y]*1.5f, 1.0f, 0.0f, 0.0f);
			glRotatef(pActor->fTempRot[Z]*1.5f, 1.0f, 0.0f, 0.0f);
			glCallList(iShieldList);
			glDepthMask(TRUE);
			glDisable(GL_BLEND);
			glEnable(GL_CULL_FACE);
		}
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND);
		glPopMatrix();
	}
} // end DrawPlayers()

//--------------------------------------------------------
// Get an random integer within a specified range
//--------------------------------------------------------
int randInt(int min, int max) {
	int range = max - min;
	int num = rand() % range;
	return (num + min);
}

//--------------------------------------------------------
// Get a random float within a specified range
//--------------------------------------------------------
float randFloat(float min, float max) {
	float range = max - min;
	float num = range * rand() / RAND_MAX;
	return (num + min);
}

//--------------------------------------------------------
// abs for floats
//--------------------------------------------------------
float absFloat(float value) {
	if (value < 0)
		return (value * -1);
	else
		return value;
}

HRESULT CheckPlayers(BOOL bOnlyCheck)
{ // begin CheckPlayers()
	ACTOR *pActor1, *pActor2;
	float fDeltaX, fDeltaY, fDistance;
	short i, i2;
	short iLeftKey, iRightKey, iUpKey, iDownKey, iStopKey, iFireKey;
	BOOL bCollision = FALSE;

	if(!b2Player)
	{
		if(pPlayer[0]->byLives == -1 && !pPlayer[0]->bActive)
		{
			GameOver();
			return 0;
		}
	}
	else
	{
		if(pPlayer[0]->byLives == -1 && !pPlayer[0]->bActive &&
		   pPlayer[1]->byLives == -1  && !pPlayer[1]->bActive)
		{
			GameOver();
			return 0;
		}
	}
	for(i = 0; i < b2Player+1; i++)
	{
		pActor1 = pPlayer[i];
		if(bDeadMatch)
			pActor1->byLives = 3;
		if(!bOnlyCheck)
		{
			pActor1->fTempRot[X] += 0.05f*g_lDeltatime;
			pActor1->fTempRot[Y] += 0.05f*g_lDeltatime;
			pActor1->fTempRot[Z] += 0.05f*g_lDeltatime;
			pActor1->fRot[X] += pActor1->fRotVelocity[X]*g_lDeltatime;
			pActor1->fRot[Y] += pActor1->fRotVelocity[Y]*g_lDeltatime;
			pActor1->fRot[Z] += pActor1->fRotVelocity[Z]*g_lDeltatime;
		}
		// Check player control:		
		iLeftKey = _ASConfig->iLeftKey[i];
		iRightKey = _ASConfig->iRightKey[i];
		iUpKey = _ASConfig->iThrustKey[i];
		iDownKey = _ASConfig->iShieldKey[i];
		iStopKey = _ASConfig->iStopKey[i];
		iFireKey = _ASConfig->iFireKey[i];
		if(ASKeys[iFireKey] && !bGameWon)
		{
			ASKeys[iFireKey] = FALSE;
			if(!pActor1->bActive && pActor1->byLives != -1)
			{ // Bring the player into the game
				for(i2 = 0; i2 < 100; i2++)
				{
					pActor1->bActive = TRUE;
					pActor1->iExplosionStep = -1;
					pActor1->bGhost = TRUE;
					pActor1->lStartTime = g_lNow;
					byPlayerWeapon[i] = SINGLE_LASER_WEAPON;
					if(!i)
						pActor1->iType = PLAYER1_ACTOR;
					else
						pActor1->iType = PLAYER2_ACTOR;
					switch(rand() % 4)
					{
						case 0: // Left top
							pActor1->fPos[X] = -((float) (rand() % (int) (SPACE_WIDTH-pActor1->fRadius)));
							pActor1->fPos[Y] = -((float) (rand() % (int) (SPACE_HEIGHT-pActor1->fRadius)));
						break;

						case 1: // Right top
							pActor1->fPos[X] = ((float) (rand() % (int) (SPACE_WIDTH-pActor1->fRadius)));
							pActor1->fPos[Y] = -((float) (rand() % (int) (SPACE_HEIGHT-pActor1->fRadius)));
						break;

						case 2: // Right bottom
							pActor1->fPos[X] = ((float) (rand() % (int) (SPACE_WIDTH-pActor1->fRadius)));
							pActor1->fPos[Y] = ((float) (rand() % (int) (SPACE_HEIGHT-pActor1->fRadius)));
						break;

						case 3: // Left bottom
							pActor1->fPos[X] = -((float) (rand() % (int) (SPACE_WIDTH-pActor1->fRadius)));
							pActor1->fPos[Y] = ((float) (rand() % (int) (SPACE_HEIGHT-pActor1->fRadius)));
						break;
					}
					pActor1->fRadius = 1.5f;
					pActor1->fMass = pActor1->fRadius*((float) PI);
					pActor1->fRadius *= 4.0f;
					if(CheckPlayers(TRUE))
					{
						pActor1->bActive = FALSE;
						continue;
					}
					pActor1->fRadius = 2.0f;
					break;
				}
				pActor1->bShield = TRUE;
				pActor1->lStartTime = g_lNow;
				pActor1->iExplosionStep = -1;
				pActor1->fRot[X] = 0.0f;
				pActor1->fRot[Y] = 0.0f;
				pActor1->fRot[Z] = 0.0f;
				pActor1->fRotVelocity[X] = 0.0f;
				pActor1->fRotVelocity[Y] = 0.0f;
				pActor1->fRotVelocity[Z] = 0.0f;
				return 0;
			}
			if(!pActor1->bActive || pActor1->iExplosionStep != -1 ||
				(g_lNow-pPlayer[i]->lLastShotTime) < 200)
				continue;
 			pActor2 = FindNoneActiveShot();
			pPlayer[i]->lLastShotTime = g_lNow;
			if(pActor2)
			{
				switch(byPlayerWeapon[i])
				{
					case SINGLE_LASER_WEAPON: case DOUBLE_LASER_WEAPON:
						switch(byPlayerWeapon[i])
						{
							case SINGLE_LASER_WEAPON:
								if(pActor1->fPower-SINGLE_SHOT_POWER < 0.0f)
									goto Next;
								pActor1->fPower -= SINGLE_SHOT_POWER;
							break;

							case DOUBLE_LASER_WEAPON:
								if(pActor1->fPower-DOUBLE_SHOT_POWER < 0.0f)
									goto Next;
								pActor1->fPower -= DOUBLE_SHOT_POWER;
							break;
						}
						pActor2->Init();
						pActor2->bActive = TRUE;
						pActor2->fRadius = 0.7f;
						if(byPlayerWeapon[i] != DOUBLE_LASER_WEAPON)
						{
							pActor2->fPos[X] = pActor1->fPos[X]+(float) cos((pActor1->fRot[Y]+pActor1->fTempRot2[Y]+90.0f)*ltconvertdegtorad);
							pActor2->fPos[Y] = pActor1->fPos[Y]+(float) sin((pActor1->fRot[Y]+pActor1->fTempRot2[Y]+90.0f)*ltconvertdegtorad);
						}
						else
						{
							pActor2->fPos[X] = pActor1->fPos[X]+(float) cos((pActor1->fRot[Y]+pActor1->fTempRot2[Y])*ltconvertdegtorad);
							pActor2->fPos[Y] = pActor1->fPos[Y]+(float) sin((pActor1->fRot[Y]+pActor1->fTempRot2[Y])*ltconvertdegtorad);
						}
						pActor2->fPos[Z] = pActor1->fPos[Z];
						pActor2->fVelocity[X] = (float) cos((pActor1->fRot[Y]+pActor1->fTempRot2[Y]+90.0f)*ltconvertdegtorad)*4;
						pActor2->fVelocity[Y] = (float) sin((pActor1->fRot[Y]+pActor1->fTempRot2[Y]+90.0f)*ltconvertdegtorad)*4;
						switch(byPlayerWeapon[i])
						{
							case SINGLE_LASER_WEAPON: pActor2->iType = SINGLE_LASER_SHOT; break;
							case DOUBLE_LASER_WEAPON: pActor2->iType = DOUBLE_LASER_SHOT; break;
						}
						pActor2->byPlayer = (char) i;
						pActor2->lStartTime = g_lNow;
						pActor2->lEndTime = pActor2->lStartTime+2000;
						DSUtil_PlaySound(pShot1Sound, 0);
						if(byPlayerWeapon[i] != DOUBLE_LASER_WEAPON)
							break;
						pActor2 = FindNoneActiveShot();
						if(!pActor2)
							break;
						pActor2->Init();
						pActor2->bActive = TRUE;
						pActor2->fRadius = 0.7f;
						pActor2->fPos[X] = pActor1->fPos[X]-(float) cos((pActor1->fRot[Y]+pActor1->fTempRot2[Y])*ltconvertdegtorad);
						pActor2->fPos[Y] = pActor1->fPos[Y]-(float) sin((pActor1->fRot[Y]+pActor1->fTempRot2[Y])*ltconvertdegtorad);
						pActor2->fPos[Z] = pActor1->fPos[Z];
						pActor2->fVelocity[X] = (float) cos((pActor1->fRot[Y]+pActor1->fTempRot2[Y]+90.0f)*ltconvertdegtorad)*4;
						pActor2->fVelocity[Y] = (float) sin((pActor1->fRot[Y]+pActor1->fTempRot2[Y]+90.0f)*ltconvertdegtorad)*4;
						switch(byPlayerWeapon[i])
						{
							case SINGLE_LASER_WEAPON: pActor2->iType = SINGLE_LASER_SHOT; break;
							case DOUBLE_LASER_WEAPON: pActor2->iType = DOUBLE_LASER_SHOT; break;
						}
						pActor2->byPlayer = (char) i;
						pActor2->lStartTime = g_lNow;
						pActor2->lEndTime = pActor2->lStartTime+2000;
					break;
				}
			}
		}
		Next:
		if(!pActor1->bActive || pActor1->iExplosionStep != -1)
			continue;
		if(bUnlimitedPower)
			pActor1->fPower = pActor1->fMaxPower;
		pActor1->bShield = FALSE;
		if(bGameWon)
		{
			if(pActor1->fMaxPower >= 200)
			{
				pActor1->bShield = TRUE;
				CreateSmoke(pActor1);
				continue;
			}
		}
		else
		{
			if(ASKeys[iLeftKey])
				pActor1->fRot[Y] += 0.25f*g_lDeltatime;
			else
			if(ASKeys[iRightKey])
				pActor1->fRot[Y] -= 0.25f*g_lDeltatime;
			if(ASKeys[iUpKey])
			{
				pActor1->fVelocity[X] += (float) cos((pActor1->fRot[Y]+90.0f)*ltconvertdegtorad)*g_lDeltatime/500.0f;
				pActor1->fVelocity[Y] += (float) sin((pActor1->fRot[Y]+90.0f)*ltconvertdegtorad)*g_lDeltatime/500.0f;
				if(pActor1->fPower > 0.02f*g_lDeltatime)
					pActor1->fPower -= 0.02f*g_lDeltatime;
				if(!bThrustSoundOn[0] && !bThrustSoundOn[1])
					DSUtil_PlaySound(pThrustSound, DSBPLAY_LOOPING);
				bThrustSoundOn[i] = TRUE;
				pActor1->fTempRot2[X] = ((float) (rand() % 10));
				pActor1->fTempRot2[Y] = ((float) (rand() % 10));
				pActor1->fTempRot2[Z] = ((float) (rand() % 10));
				if((g_lNow-pActor1->lLastShotTime) > 50)
				{
					pActor1->lLastShotTime = g_lNow;
					CreateSmoke(pActor1);
				}
			}
			else
			{
				pActor1->fTempRot2[X] = 0.0f;
				pActor1->fTempRot2[Y] = 0.0f;
				pActor1->fTempRot2[Z] = 0.0f;
				bThrustSoundOn[i] = FALSE;
				if(!bThrustSoundOn[0] && !bThrustSoundOn[1])
					DSUtil_StopSound(pThrustSound);
				if(ASKeys[iDownKey])
				{
					if(!pActor1->bGhost)
						if(pActor1->fPower > 0.02f*g_lDeltatime)
						{
							pActor1->fPower -= 0.02f*g_lDeltatime;
							pActor1->bShield = TRUE;
						}
				}
				else
				if(ASKeys[iStopKey])
				{
					ASKeys[iStopKey] = FALSE;
					pActor1->fVelocity[X] = 0.0f;
					pActor1->fVelocity[Y] = 0.0f;
					pActor1->fPower /= 2;
					for(i2 = 0; i2 < 20; i2++)
						CreateSmoke(pActor1);
				}
			}
			if(pActor1->bGhost)
				pActor1->bShield = TRUE;
		}
		// Check the player
		memcpy(pActor1->fLastPos, pActor1->fPos, sizeof(FLOAT3));
		if(!bOnlyCheck)
		{
			// Move player
			pActor1->fPos[X] += pActor1->fVelocity[X]*g_lDeltatime/100.0f;
			pActor1->fPos[Y] += pActor1->fVelocity[Y]*g_lDeltatime/100.0f;
			if(pActor1->fPos[X]-pActor1->fRadius*2 > SPACE_WIDTH && pActor1->fVelocity[X] > 0.0f)
				pActor1->fPos[X] = -SPACE_WIDTH-pActor1->fRadius*2;
			if(pActor1->fPos[X]+pActor1->fRadius*2 < -SPACE_WIDTH && pActor1->fVelocity[X] < 0.0f)
				pActor1->fPos[X] = SPACE_WIDTH+pActor1->fRadius*2;
			if(bGravity)
			{
				if(pActor1->fPos[Y]+1.5f > SPACE_HEIGHT && pActor1->fVelocity[Y] > 0.0f ||
				   pActor1->fPos[Y] < -SPACE_HEIGHT && pActor1->fVelocity[Y] < 0.0f)
				{
					if(pActor1->bShield)
					{
						pActor1->fVelocity[Y] = -pActor1->fVelocity[Y];
						pActor1->fPos[Y] = pActor1->fLastPos[Y];
					}
					else
					{
						pActor1->fVelocity[X] = 0.0f;
						pActor1->fVelocity[Y] = 0.0f;
						pActor1->fPos[Y] = pActor1->fLastPos[Y];
						PlayerDead(i);
					}
				}
			}
			else
			{
				if(pActor1->fPos[Y]-pActor1->fRadius > SPACE_HEIGHT && pActor1->fVelocity[Y] > 0.0f)
					pActor1->fPos[Y] = -SPACE_HEIGHT;
				if(pActor1->fPos[Y]+pActor1->fRadius < -SPACE_HEIGHT && pActor1->fVelocity[Y] < 0.0f)
					pActor1->fPos[Y] = SPACE_HEIGHT+pActor1->fRadius*2;
			}
			// Check Players Power
			if(pActor1->fPower < pActor1->fMaxPower)
			{
				pActor1->fPower += 0.02f*g_lDeltatime;
				if(pActor1->fPower > pActor1->fMaxPower)
					pActor1->fPower = pActor1->fMaxPower;
			}	
			if(pActor1->bGhost)
				if((g_lNow-pActor1->lStartTime) > PLAYER_GHOST_TIME)
					pActor1->bGhost = FALSE;
			if(bGravity) // Gravity:
				pActor1->fVelocity[Y] -= GRAVITY*g_lDeltatime;
			CheckGravity(pActor1);
		}
		// Check if we have a collision with the other player:
		for(i2 = 0; i2 < 2; i2++)
		{
			if(i2 == i)
				continue;
			pActor2 = pPlayer[i2];
			if(!pActor2->bActive || pActor2->iExplosionStep != -1)
				continue;
			fDeltaX = pActor1->fPos[X]-pActor2->fPos[X];
			fDeltaY = pActor1->fPos[Y]-pActor2->fPos[Y];
			fDistance = (fDeltaX*fDeltaX+fDeltaY*fDeltaY);
			if(fDistance <= (pActor1->fRadius+pActor2->fRadius)*(pActor1->fRadius+pActor2->fRadius))
			{
				bCollision = TRUE;
				if(bOnlyCheck)
					continue;
				// We have a collision!
				pActor1->fPos[X] = pActor1->fLastPos[X];
				pActor1->fPos[Y] = pActor1->fLastPos[Y];
				if(!pPlayer[0]->bShield && !pPlayer[1]->bShield && !bInvulnerable)
				{
					PlayerDead(0);
					PlayerDead(1);
				}
				// Make the asteroids smaller:
				CheckBallCollision(pActor1, pActor2, fDeltaX, fDeltaY);			
				DSUtil_PlaySound(pCollision1Sound, 0);
			}
		}
		// Check if we have a collision with a actor:
		for(i2 = 0; i2 < MAX_ACTORS; i2++)
		{
			pActor2 = pActors[i2];
			if(!pActor2->bActive || pActor2->iExplosionStep != -1)
				continue;
			fDeltaX = pActor1->fPos[X]-pActor2->fPos[X];
			fDeltaY = pActor1->fPos[Y]-pActor2->fPos[Y];
			fDistance = (fDeltaX*fDeltaX+fDeltaY*fDeltaY);
			if(fDistance <= (pActor1->fRadius+pActor2->fRadius)*(pActor1->fRadius+pActor2->fRadius))
			{
				bCollision = TRUE;
				if(bOnlyCheck)
					continue;
				// We have a collision!
				if(pActor2->iType == BLACK_HOLE_ACTOR && !bInvulnerable)
					PlayerDead(i);
				if(pActor2->iType == ASTEROID_ACTOR ||
				   pActor2->iType == UFO_ACTOR)
				{
					pActor1->fPos[X] = pActor1->fLastPos[X];
					pActor1->fPos[Y] = pActor1->fLastPos[Y];
					if(pActor2->iType != ASTEROID_ACTOR && !pActor1->bShield)
						pActor2->bActive = FALSE;
					if(pActor2->iType == ASTEROID_ACTOR)
					{
						// Make the asteroids smaller:
						pActor2->fScale -= 0.01f;
						pActor2->fRadius = 6.5f*pActor2->fScale;
						pActor2->fMass = pActor2->fRadius*((float) PI);
						if(pActor2->fRadius <= 0.5f)
						{
							pActor2->bActive = FALSE;
							if((rand() % 2) == 1)
								CreateNewActor();
						}
					}
					CheckBallCollision(pActor1, pActor2, fDeltaX, fDeltaY);			
					if(!pActor1->bShield && !bInvulnerable)
						PlayerDead(i);
					else
						DSUtil_PlaySound(pCollision1Sound, 0);
				}
				else
				{
					if(!pActor1->bShield)
					{
						switch(pActor2->iType)
						{
							case OBJECT_SINGLE_LASER_ACTOR:
								byPlayerWeapon[i] = SINGLE_LASER_WEAPON;
								iPlayerScore[i] += SINGLE_LASER_WEAPON_POINTS; 
							break;

							case OBJECT_DOUBLE_LASER_ACTOR:
								byPlayerWeapon[i] = DOUBLE_LASER_WEAPON;
								iPlayerScore[i] += DOUBLE_LASER_WEAPON_POINTS; 
 							break;

							case OBJECT_LIVE_ACTOR:
								pActor1->byLives++;
								iPlayerScore[i] += LIVE_POINTS;
							break;

							case OBJECT_POWER_INCREASE_ACTOR:
								pActor1->fMaxPower += 10.0f;
								iPlayerScore[i] += POWER_INCREASE_POINTS;
								if(pActor1->fMaxPower >= 200)
									GameWon();
							break;

							case OBJECT_FULL_POWER_ACTOR:
								pActor1->fPower = pActor1->fMaxPower;
								iPlayerScore[i] += FULL_POWER_POINTS;
							break;

							case OBJECT_POINTS_ACTOR:
								iPlayerScore[i] += rand() % 101+1;
							break;
						}
						pActor2->bActive = FALSE;
					}
					else
						CheckBallCollision(pActor1, pActor2, fDeltaX, fDeltaY);			
				}
			}
		}
	}
	return bCollision;
} // end CheckPlayers()

void PlayerDead(short i)
{ // begin PlayerDead()
	// The player loose a live:
	pPlayer[i]->iExplosionStep = 0;
	pPlayer[i]->lStartTime = g_lNow;
	pPlayer[i]->fVelocity[X] = 0.0f;
	pPlayer[i]->fVelocity[Y] = 0.0f;
	pPlayer[i]->fRotVelocity[X] = 0.3f;
	pPlayer[i]->fRotVelocity[Y] = 0.3f;
	pPlayer[i]->fPower = pPlayer[i]->fMaxPower;
	pPlayer[i]->byLives--;
	DSUtil_PlaySound(pExplosion1Sound, 0);
	bThrustSoundOn[i] = FALSE;
	if(!bThrustSoundOn[0] && !bThrustSoundOn[1])
		DSUtil_StopSound(pThrustSound);
	MakeStars(pPlayer[i]);
} // end PlayerDead()

void DrawShots(void)
{ // begin DrawShots()
	short i;
	ACTOR *pActor;
	AS_OBJECT *pObject;
	
	if(bMainMenu)
		return;
	for(i = 0; i < MAX_SHOTS; i++)
	{
		pActor = pShot[i];
		if(!pActor->bActive)
			continue;
		glPushMatrix();
		if(!pActor->byPlayer)
			glColor3f(1.0f, 0.0f, 0.0f);
		else
			glColor3f(0.0f, 1.0f, 0.0f);
		switch(pActor->iType)
		{
			case SINGLE_LASER_SHOT:
				glTranslatef(pActor->fPos[X], pActor->fPos[Y], pActor->fPos[Z]);
				pObject = pSingleLaserShotObj;
			break;

			case DOUBLE_LASER_SHOT:
				glTranslatef(pActor->fPos[X], pActor->fPos[Y], pActor->fPos[Z]);
				pObject = pDoubleLaserShotObj;
			break;

			case UFO_SHOT:
				glTranslatef(pActor->fPos[X], pActor->fPos[Y], pActor->fPos[Z]);
				pObject = pUFOShotObj;
			break;
		}
		glMultMatrixf(pObject->Matrix[0]);
		glRotatef(pActor->fRot[X], 1.0f, 0.0f, 0.0f);
		glRotatef(pActor->fRot[Y], 0.0f, 1.0f, 0.0f);
		glRotatef(pActor->fRot[Z], 0.0f, 0.0f, 1.0f);
		pObject->Draw(TRUE, FALSE, _ASConfig->bDrawBounding);
		pActor->pFrameT = pObject->pChild[0]->pAnimationT->pStepT->pFrame;
		if(!pActor->pMainFrameT)
			pActor->pMainFrameT = pActor->pFrameT;
		glPopMatrix();
	}
} // end DrawShots

void CheckShots(void)
{ // begin CheckShots()
	short i, i2;
	ACTOR *pActor1, *pActor2, *pActor3;
	float fDeltaX, fDeltaY, fDistance;

	for(i = 0; i < MAX_SHOTS; i++)
	{
		pActor1 = pShot[i];
		if(!pActor1->bActive || pActor1->iExplosionStep != -1)
			continue;
		memcpy(pActor1->fLastPos, pActor1->fPos, sizeof(FLOAT3));
		pActor1->fPos[X] += pActor1->fVelocity[X]*g_lDeltatime/100.0f;
		pActor1->fPos[Y] += pActor1->fVelocity[Y]*g_lDeltatime/100.0f;
		if(pActor1->fPos[X]-pActor1->fRadius*2 > SPACE_WIDTH && pActor1->fVelocity[X] > 0.0f)
			pActor1->fPos[X] = -SPACE_WIDTH-pActor1->fRadius*2;
		if(pActor1->fPos[X]+pActor1->fRadius*2 < -SPACE_WIDTH && pActor1->fVelocity[X] < 0.0f)
			pActor1->fPos[X] = SPACE_WIDTH+pActor1->fRadius*2;
		if(bGravity) // Gravity:
			pActor1->fVelocity[Y] -= GRAVITY*g_lDeltatime*10;
		if(bGravity)
		{
			if(pActor1->fPos[Y]+1.5f > SPACE_HEIGHT && pActor1->fVelocity[Y] > 0.0f ||
			   pActor1->fPos[Y] < -SPACE_HEIGHT && pActor1->fVelocity[Y] < 0.0f)
			{
				pActor1->fVelocity[Y] = -pActor1->fVelocity[Y];
				pActor1->fPos[Y] = pActor1->fLastPos[Y];
			}
		}
		else
		{
			if(pActor1->fPos[Y]-pActor1->fRadius > SPACE_HEIGHT && pActor1->fVelocity[Y] > 0.0f)
				pActor1->fPos[Y] = -SPACE_HEIGHT;
			if(pActor1->fPos[Y]+pActor1->fRadius < -SPACE_HEIGHT && pActor1->fVelocity[Y] < 0.0f)
				pActor1->fPos[Y] = SPACE_HEIGHT+pActor1->fRadius*2;
		}
		CheckGravity(pActor1);
		pActor1->fRot[X] += 0.05f*g_lDeltatime;
		pActor1->fRot[Y] += 0.05f*g_lDeltatime;
 		pActor1->fRot[Z] += 0.05f*g_lDeltatime;
		if(g_lNow > pActor1->lLastShotTime)
		{ // Create a shot particle:
			if(bMainMenu || pActor1->iType == UFO_SHOT)
				pActor1->lLastShotTime = g_lNow+100;
			else
				pActor1->lLastShotTime = g_lNow+5;
			pActor2 = FindNoneActiveParticle1();
			if(pActor2)
			{
				pActor2->Init();
				pActor2->bActive = TRUE;
				pActor2->fPos[X] = pActor1->fPos[X];
				pActor2->fPos[Y] = pActor1->fPos[Y];
				pActor2->fPos[Z] = pActor1->fPos[Z];
				pActor2->fScale = 4.0f;
				pActor2->lStartTime = g_lNow;
				pActor2->lEndTime = pActor2->lStartTime+200+(rand() % 100);
				if(pActor1->iType == UFO_SHOT)
				{
					pActor2->fRed = 0.0f;
					pActor2->fGreen = 0.0f;
					pActor2->fBlue = (float) (rand() % 100)/100.0f;
				}
				else
				{
					if(!pActor1->byPlayer)
					{
						pActor2->fRed = (float) (rand() % 100)/100.0f;
						pActor2->fGreen = 0.0f;
						pActor2->fBlue = 0.0f;
					}
					else
					{
						pActor2->fRed = 0.0f;
						pActor2->fGreen = (float) (rand() % 100)/100.0f;
						pActor2->fBlue = 0.0f;
					}
				}
			}
		}
		if(!bMainMenu)
		{
			// Check if a player has shot on the other player:
			for(i2 = 0; i2 < 2; i2++)
			{
				pActor2 = pPlayer[i2];
				if(!pActor2->bActive || pActor2->iExplosionStep != -1 ||
				   (pActor1->iType != UFO_SHOT && pActor1->byPlayer == i2))
					continue;
				fDeltaX = pActor1->fPos[X]-pActor2->fPos[X];
				fDeltaY = pActor1->fPos[Y]-pActor2->fPos[Y];
				fDistance = (fDeltaX*fDeltaX+fDeltaY*fDeltaY);
				if(fDistance <= (pActor1->fRadius+pActor2->fRadius)*(pActor1->fRadius+pActor2->fRadius))
				{
					// We have a collision!
					pActor1->bActive = FALSE;
					if(!pActor2->bShield && !bInvulnerable)
					{
						if(pActor1->iType != UFO_SHOT)
						{
							if(bPlayerWar)
							{
								if(!pActor1->byPlayer)
								{
									PlayerDead(1);
									iPlayerScore[0] += (short) (iPlayerScore[1]*0.2f)+PLAYER_KILL_POINTS;
									iPlayerScore[1] -= (short) (iPlayerScore[1]*0.2f);
								}
								else
								{
									PlayerDead(0);
									iPlayerScore[1] += (short) (iPlayerScore[0]*0.2f)+PLAYER_KILL_POINTS;
									iPlayerScore[0] -= (short) (iPlayerScore[0]*0.2f);
								}
							}
						}
						else
							PlayerDead(i2);
					}
				}
			}
			// Check if the shot has hit a actor:
			// Check if we have a collision with a actor:
			for(i2 = 0; i2 < MAX_ACTORS; i2++)
			{
				pActor2 = pActors[i2];
				if(!pActor2->bActive || pActor2->iExplosionStep != -1 ||
				   pActor2->iType == BLACK_HOLE_ACTOR)
					continue;
				fDeltaX = pActor1->fPos[X]-pActor2->fPos[X];
				fDeltaY = pActor1->fPos[Y]-pActor2->fPos[Y];
				fDistance = (fDeltaX*fDeltaX+fDeltaY*fDeltaY);
				if(fDistance <= (pActor1->fRadius+pActor2->fRadius)*(pActor1->fRadius+pActor2->fRadius))
				{
					// We have a collision!
					if(pActor2->iType == ASTEROID_ACTOR)
					{
						pActor1->bActive = FALSE;
						DivideActor(pActor1, pActor2);
						DSUtil_PlaySound(pExplosion2Sound, 0);
					}
					else
					{
						if(pActor2->iType == UFO_ACTOR)
						{
							if(pActor1->iType == UFO_SHOT)
								continue;
							iPlayerScore[pActor1->byPlayer] += UFO_POINTS;
						}
						pActor1->bActive = FALSE;
						// A shot has destroyed a object!
						pActor2->iExplosionStep = 0;
						pActor2->lStartTime = g_lNow;
						pActor2->fVelocity[X] = 0.0f;
						pActor2->fVelocity[Y] = 0.0f;
						pActor2->fRotVelocity[X] = 0.3f;
						pActor2->fRotVelocity[Y] = 0.3f;				
						DSUtil_PlaySound(pExplosion2Sound, 0);
						MakeStars(pActor1);
					}
					// Should we create a object?
					if((rand() % 5) == 1)
					{
						pActor3 = FindNoneActiveActor();
						if(!pActor3)
							continue;
						pActor3->Init();
						pActor3->bActive = TRUE;
						pActor3->iExplosionStep = -1;
						pActor3->fPos[X] = pActor2->fPos[X];
						pActor3->fPos[Y] = pActor2->fPos[Y];
						pActor3->fScale = 0.5f;
						pActor3->fRadius = 1.0f*pActor3->fScale;
						pActor3->fMass = pActor3->fRadius*((float) PI);
						if(rand() % 2)
							pActor3->fVelocity[X] = ((float) (rand() % 100))/1000.0f;
						else
							pActor3->fVelocity[X] = -((float) (rand() % 100))/1000.0f;
						if(rand() % 2)
							pActor3->fVelocity[Y] = ((float) (rand() % 100))/1000.0f;
						else
							pActor3->fVelocity[Y] = -((float) (rand() % 100))/1000.0f;
						pActor3->fRotVelocity[X] = ((float) (rand() % 100)/2000.0f);
						pActor3->fRotVelocity[Y] = ((float) (rand() % 100)/2000.0f);
						pActor3->fRotVelocity[Z] = ((float) (rand() % 100)/2000.0f);
						// What should we create?
						pActor3->iType = 2+rand() % 6;
					}
				}
			}
		}
		if(g_lNow > pActor1->lEndTime)
			pActor1->bActive = FALSE;
	}
} // end CheckShots

ACTOR *FindNoneActiveShot(void)
{ // begin FindNoneActiveShot()
	short i;

	for(i = 0; i < MAX_SHOTS; i++)
	{
		if(!pShot[i]->bActive)
			return pShot[i];
	}
	return NULL;
} // end FindNoneActiveShot()

ACTOR::ACTOR(void)
{ // begin ACTOR()
	memset(this, 0, sizeof(ACTOR));
} // end ACTOR()

ACTOR::~ACTOR(void)
{ // begin ~ACTOR()
} // end ~ACTOR()

void ACTOR::Init(void)
{ // begin Init()
	memset(this, 0, sizeof(ACTOR));
	fScale = 1.0f;
	iExplosionStep = -1;
} // end Init()
#ifndef __BLAZE_CHICKEN_H__
#define __BLAZE_CHICKEN_H__


// Variables: *****************************************************************
extern AS_CAMERA *pCamera;
extern AS_CONFIG *pConfig;
///////////////////////////////////////////////////////////////////////////////
// Functions: *****************************************************************
extern int PASCAL WinMain(HINSTANCE, HINSTANCE, LPSTR, int);
extern void ChangeDisplayMode(void);
extern LRESULT CALLBACK CreditsProc(HWND, UINT, WPARAM, LPARAM);
///////////////////////////////////////////////////////////////////////////////


#endif // __BLAZE_CHICKEN_H__
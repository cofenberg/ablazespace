#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
AS_TEXTURE GameTexture[GAME_TEXTURES];
int GAME_WINDOW_ID;
GLuint iBackgroundList;
GLuint iWaveList;
GLuint iShieldList;
GLuint iSmokeList;
GLuint iStarList;
GLfloat fBackgroundRot = 0.0f; // Background motion velocity
int iPlayerScore[2];
char byPlayerWeapon[2];
BOOL bShowPlayerText;
FLOAT3 fPlayerShipRot;
BOOL bCheatsActivated, bUnlimitedPower, bInvulnerable, bNoBlackHole, bMoorhuhnModus;
long lBackFlashTime, lBackFlashTimeDelay;
float fBackFlash, fLastBackFlash, fCurrentBackFlash, fBackFlashDelta;
BOOL bMainMenu, bCredits, bDeadMatchMenu, bOptionsMenu, bBlendIn, bBlendOut, bCreditsWaiting;
float fCreditsText, fInvasionZPos, fInvasionYPos;
long lNextAniTime, lLastShotTime2, lCreditsNext, lNextUfoTime, lNextBlackHoleParticleTime;
char byAniStep, byCreditsStep;
BOOL bAniStep, bStep[2], bBackground, bBlackHole, bPlayerKeys, bConfigKeysMenu;
char bySelectedOption, byPlayerHighscore;
BOOL b2Player, bDeadMatch, bPlayerWar, bGravity, bUFOS, bOccurrences;
int iMaxLights;
short iConfigKey;

BOOL bGameOver;							// Is the game over?
BOOL bGameWon;							// Is the game won?
BOOL bShowHighscore;					// Should the highscore displayed at the game intro
// Highscore stuff
typedef struct
{
	char byName[30];
	int iScore;
} HIGHSCORE;

HIGHSCORE Highscore[MAX_HIGHSCORES] = 
{
	{"Invasion2", 1000},
	{"a AblazeSpace project", 1},
	{"Programmed & Designed", 1},
	{"by Christian Ofenberg", 1},
	{"Music", 1},
	{"by Mike Spang", 1},
	{"Thank's to:", 1},
	{"Juergen Stuetz", 1},
	{"Stephan Wetzel", 1},
	{"and all other a know", 1},
};
BOOL bPlayerEnteringHighScore;
char byPlayersHScorePlace;
char byHighScoreInitialsIndex;
const char byLegalHighScoreChars[38] = " 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
// Objects:
AS_OBJECT *pInvasion2Obj;
AS_OBJECT *pPlayer1Obj;
AS_OBJECT *pPlayer2Obj;
AS_OBJECT *pAsteroidObj[4];
AS_OBJECT *pUFOObj;
AS_OBJECT *pSingleLaserWeaponObj;
AS_OBJECT *pSingleLaserShotObj;
AS_OBJECT *pDoubleLaserWeaponObj;
AS_OBJECT *pDoubleLaserShotObj;
AS_OBJECT *pUFOShotObj;
AS_OBJECT *pObjectSingleLaserObj;
AS_OBJECT *pObjectDoubleLaserObj;
AS_OBJECT *pObjectLiveObj;
AS_OBJECT *pObjectPowerIncreaseObj;
AS_OBJECT *pObjectFullPowerObj;
AS_OBJECT *pObjectPointsObj;
AS_OBJECT *pPowerDisplayObj;
// Sounds:
SoundObject *pThrustSound;
BOOL bThrustSoundOn[2];
SoundObject *pExplosion1Sound;
SoundObject *pExplosion2Sound;
SoundObject *pShot1Sound;
SoundObject *pCollision1Sound;
SoundObject *pUFOSound;
///////////////////////////////////////////////////////////////////////////////
// Functions: *****************************************************************
HRESULT Game(void);
HRESULT GameDraw(AS_WINDOW *);
HRESULT GameCheck(AS_WINDOW *);
void LoadGameTextures(void);
void DestroyGameTextures(void);
void LoadSounds(void);
void DestroySounds(void);
void CreateGameLists(void);
void DestroyGameLists(void);
void InitGameObjects(void);
void DestroyGameObjects(void);
void ActivateLights(void);
void DeactivateShotLights(void);
void SetupMainMenu(void);
void DeactivateAllActors(void);
void CreateLevel(void);
void CreateNewActor(void);
HRESULT LoadHighscore(void);
HRESULT SaveHighscore(void);
void DrawPlayersHighscore(AS_WINDOW *);
void CheckPlayersHighscore(void);
void GameOver(void);
///////////////////////////////////////////////////////////////////////////////


void StartNewGame(void)
{
	short i;

	DeactivateAllActors();
	bBackground = 0;
	bGravity = FALSE;
	bUFOS = TRUE;
	bOccurrences = TRUE;
	bMainMenu = FALSE;
	bPlayerEnteringHighScore = FALSE;
	bGameOver = FALSE;
	bGameWon = FALSE;
	bShowHighscore = FALSE;
	bBlackHole = FALSE;
	for(i = 0; i < 2; i++)
	{
		if(!pPlayer[i])
			continue;
		pPlayer[i]->Init();
		pPlayer[i]->byLives = 3;
		pPlayer[i]->fMaxPower = 100.0f;
		pPlayer[i]->fPower = pPlayer[i]->fMaxPower;
		byPlayerWeapon[i] = SINGLE_LASER_WEAPON;
		iPlayerScore[i] = 0;
	}
	if(!bDeadMatch)
		CreateLevel();
}

HRESULT Game(void)
{ // begin Game()
	MSG msg;

	glGetIntegerv(GL_MAX_LIGHTS, &iMaxLights);
	_AS->WriteLogMessage("Enter game module");
	_AS->ASCreateWindow(WindowProc, GAME_WINDOW_NAME, GAME_WINDOW_NAME, _ASConfig->iWindowWidth, _ASConfig->iWindowHeight, LoadMenu(_AS->GetInstance(), MAKEINTRESOURCE(IDR_GAME)), _ASConfig->bFullScreen, GameDraw, GameCheck, NULL, FALSE, TRUE);
	GAME_WINDOW_ID = _AS->GetWindows()-1;
	ASInitOpenGL(&_AS->pWindow[GAME_WINDOW_ID],
				 NULL,
				 _AS->pWindow[GAME_WINDOW_ID].GethDC(),
				 _AS->pWindow[GAME_WINDOW_ID].GethRC(), _ASConfig->bFullScreen);
	ShowWindow(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), SW_SHOW);	
	LoadHighscore();
	InitGameObjects();
	SetupMainMenu();
	g_lNow = GetTickCount();
	g_lLastlooptime = g_lNow;
	for(;;)
	{
		if(PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
    	{
        	if(!GetMessage(&msg, NULL, 0, 0))
                break;
        	TranslateMessage(&msg);
        	DispatchMessage(&msg);
    	}
		else
		{	
			if(_AS->GetShutDown() || _AS->CheckModuleChange())
				PostQuitMessage(0);
			if(!_AS->GetActive())
				continue;
			_AS->UpdateWindows();
		}
	}
	ASStopMidi();

	DestroyGameObjects();
	SaveHighscore();
	ASDestroyOpenGL(&_AS->pWindow[GAME_WINDOW_ID],
					NULL,
				    *_AS->pWindow[GAME_WINDOW_ID].GethDC(),
				    *_AS->pWindow[GAME_WINDOW_ID].GethRC());
	_AS->ASDestroyWindow(_AS->pWindow[GAME_WINDOW_ID].GethWnd(), GAME_WINDOW_NAME);
	return msg.wParam;
} // end Game()

HRESULT GameDraw(AS_WINDOW *pWindow)
{ // begin GameDraw()
	float x;
	char byTemp[256];

	if(_ASConfig->bSetError)
		return 0;
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	ActivateLights();	
	if(!bMainMenu)
	{ // We are in the game:
		// Draw the background
		if(!bBackground)
		{
 			glDisable(GL_LIGHTING);
			glDisable(GL_DEPTH_TEST);
			glDisable(GL_BLEND);
			glColor4ub(255,255,255,128);
			glTranslatef(0.0f, 0.0f, -30.0f);
			glMatrixMode(GL_TEXTURE_2D);
			glRotatef(180.0f*float(cos(fBackgroundRot/10.0f)),0.0f,0.0f,1.0f);
			glTranslatef((3.0f*float(cos(fBackgroundRot)))+(2.1f*float(sin(fBackgroundRot*1.4f))),(2.8f*float(sin(fBackgroundRot)))+(1.3f*float(sin(fBackgroundRot*1.4f))),0.0f);
			glRotatef(10.0f*float(sin(fBackgroundRot*1.2f)),1.0f,0.0f,0.0f);
			glMatrixMode(GL_MODELVIEW);
			glCallList(iBackgroundList);
		}
		else
		{
			glDisable(GL_LIGHTING);
			glDisable(GL_DEPTH_TEST);
			glEnable(GL_TEXTURE_2D);
			glLoadIdentity();
			glColor3f(fCurrentBackFlash, fCurrentBackFlash, fCurrentBackFlash);
			glTranslatef(0.0f, 0.0f, -20.0f);
			glBindTexture(GL_TEXTURE_2D, GameTexture[8].iOpenGLID);
			glNormal3f(0.0f, 0.0f, 1.0f);
			// First quad (background layer 1)
			glBegin(GL_QUADS);
				glTexCoord2f(2.0f,1.5f+fBackgroundRot); glVertex3f( 11.0f, 11.0f, 0.0f);
				glTexCoord2f(0.0f,1.5f+fBackgroundRot); glVertex3f(-11.0f, 11.0f, 0.0f);
				glTexCoord2f(0.0f,0.0f+fBackgroundRot); glVertex3f(-11.0f,-11.0f, 0.0f);
				glTexCoord2f(2.0f,0.0f+fBackgroundRot); glVertex3f( 11.0f,-11.0f, 0.0f);
			glEnd();
			// Rotate the second background layer
			glRotatef(fBackgroundRot*10.0f, 0.0f, 0.0f, 1.0f);
			glColor4f(1.0f, 1.0f, 1.0f, 0.95f);
			glNormal3f(0.0f, 0.0f, 1.0f);
			glBlendFunc(GL_DST_COLOR,GL_ZERO);
			glEnable(GL_BLEND);
			// Start drawing quad (background layer 2)
			glBegin(GL_QUADS);
				glTexCoord2f(1.0f+0.5f*float(cos(fBackgroundRot)),2.5f-fBackgroundRot); glVertex3f( 14.0f, 14.0f, 0.0f);
				glTexCoord2f(0.0f,2.5f-fBackgroundRot); glVertex3f(-14.0f, 14.0f, 0.0f);
				glTexCoord2f(0.0f,0.0f-fBackgroundRot); glVertex3f(-14.0f,-14.0f, 0.0f);
				glTexCoord2f(1.0f+0.5f*float(cos(fBackgroundRot)),0.0f-fBackgroundRot); glVertex3f( 14.0f,-14.0f, 0.0f);
			glEnd();
			glDisable(GL_BLEND);
			glBlendFunc(GL_SRC_ALPHA, GL_ONE);
		}
		if(bGravity)
		{ // Outlines			
			glEnable(GL_BLEND);
			glDisable(GL_TEXTURE_2D);
			glLoadIdentity();
			glTranslatef(0.0f, 0.0f, -50.0f);
			glLineWidth(3.f);
			glColor4f(1.0f, 1.0f, 1.0f, 0.8f);
			glBegin(GL_LINES);
				glVertex3f(-SPACE_WIDTH, SPACE_HEIGHT-2.0f, 0.0f);
				glVertex3f(SPACE_WIDTH, SPACE_HEIGHT-2.0f, 0.0f);
				glVertex3f(-SPACE_WIDTH, -SPACE_HEIGHT+2.0f, 0.0f);
				glVertex3f(SPACE_WIDTH, -SPACE_HEIGHT+2.0f, 0.0f);
			glEnd();	
			glEnable(GL_TEXTURE_2D);
		}
		glEnable(GL_DEPTH_TEST);
		glEnable(GL_LIGHTING);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND);		
		glLoadIdentity();
		glTranslatef(0.0f, 0.0f, -50.0f);
		DrawParticles();
		glBindTexture(GL_TEXTURE_2D, GameTexture[4].iOpenGLID);
		DrawActors();
		DrawPlayers();
		glDisable(GL_TEXTURE_2D);
		DrawShots();

		glEnable(GL_TEXTURE_2D);
		glEnable(GL_BLEND);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		DrawExplosions();

		if(!bGameOver && !bGameWon)
		{
			glDisable(GL_DEPTH_TEST);
			// Draw players power:
			// Player 1:
			glBindTexture(GL_TEXTURE_2D, GameTexture[5].iOpenGLID);
			glEnable(GL_TEXTURE_GEN_S);
			glEnable(GL_TEXTURE_GEN_T);
			glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND);		
			glColor4f(1.0f, 1.0f, 1.0f, 0.95f);
			if(pPlayer[0]->bActive && pPlayer[0]->byLives != -1)
			{
				glLoadIdentity();
				glTranslatef(-7.0f, 5.0f, -15.0f);
				glRotatef(135, 0.0f, 1.0f, 0.0f);
				glRotatef(135, 1.0f, 0.0f, 0.0f);
				glRotatef(0, 0.0f, 0.0f, 1.0f);
				x = pPlayer[0]->fPower/pPlayer[0]->fMaxPower;
				glScalef(x, x, x);
				pPowerDisplayObj->Draw(TRUE, FALSE, FALSE);
			}
			// Player 2:
			if(b2Player && pPlayer[1]->bActive && pPlayer[1]->byLives != -1)
			{
				glLoadIdentity();
				glTranslatef(7.0f, 5.0f, -15.0f);
				glRotatef(90, 0.0f, 1.0f, 0.0f);
				glRotatef(45, 1.0f, 0.0f, 0.0f);
				glRotatef(45, 0.0f, 0.0f, 1.0f);
				x = pPlayer[1]->fPower/pPlayer[1]->fMaxPower;
				glScalef(x, x, x);
				pPowerDisplayObj->Draw(TRUE, FALSE, FALSE);
			}
			glDisable(GL_BLEND);
			// Draw players lives:
			// Player 1:
			if(pPlayer[0]->bActive && pPlayer[0]->byLives != -1)
			{
				glLoadIdentity();
				glTranslatef(-25, 15.0f, -50.0f);
				if(bDeadMatch && iPlayerScore[0] != iPlayerScore[1] && iPlayerScore[0] > iPlayerScore[1])
					glScalef(1.5f, 1.5f, 1.5f);
				else
					goto Player1;
				glRotatef(fPlayerShipRot[X], 1.0f, 0.0f, 0.0f);
				glRotatef(fPlayerShipRot[Y], 0.0f, 1.0f, 0.0f);
				glRotatef(fPlayerShipRot[Z], 0.0f, 0.0f, 1.0f);
				pPlayer1Obj->pChild[0]->Draw(TRUE, TRUE, FALSE);
			}
		Player1:
			// Player 2:
			if(b2Player && pPlayer[1]->bActive && pPlayer[1]->byLives != -1)
			{
				glLoadIdentity();
				glTranslatef(25.0f, 15.0f, -50.0f);
				if(bDeadMatch && iPlayerScore[0] != iPlayerScore[1] && iPlayerScore[1] > iPlayerScore[0])
					glScalef(1.5f, 1.5f, 1.5f);
				else
					goto Player2;
				glRotatef(fPlayerShipRot[X], 1.0f, 0.0f, 0.0f);
				glRotatef(fPlayerShipRot[Y], 0.0f, 1.0f, 0.0f);
				glRotatef(fPlayerShipRot[Z], 0.0f, 0.0f, 1.0f);
				pPlayer2Obj->pChild[0]->Draw(TRUE, TRUE, FALSE);
			}
		Player2:
			glDisable(GL_TEXTURE_GEN_S);
			glDisable(GL_TEXTURE_GEN_T);
			glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
			// Draw players score:
			// Player 1:
			glEnable(GL_BLEND);
			if(bBlackHole && (((g_lNow-g_lProgramStartTime) / 1000)) % 2)
			{
				glColor4f(1.0f, 0.0f, 0.0f, 0.8f);
				pWindow->glPrint(230, 5, "Danger black hole!", 0);
			}
			glColor4f(1.0f, 1.0f, 1.0f, 0.8f);
			pWindow->glPrint(30, 440, "Player 1", 0);
			if(pPlayer[0]->bActive && pPlayer[0]->byLives != -1)
			{
				sprintf(byTemp, "Score: %d", iPlayerScore[0]);
				pWindow->glPrint(30, 360, byTemp, 0);
				if(!bDeadMatch)
				{
					sprintf(byTemp, "* %d", pPlayer[0]->byLives);
					pWindow->glPrint(90, 410, byTemp, 0);
				}
				sprintf(byTemp, "P: %0.2f", pPlayer[0]->fPower);
				pWindow->glPrint(30, 385, byTemp, 0);
			}
			else
			{
				if(bShowPlayerText)
					if(pPlayer[0]->byLives == -1)
					{ // Player 1 is dead
						pWindow->glPrint(40, 360, "GAME OVER", 0);
					}
					else
					{ // Player 1 isn't activated
						pWindow->glPrint(10, 360, "PRESS FIRE TO START", 0);
					}
			}
			if(b2Player)
			{
				// Player 2:
				pWindow->glPrint(500, 440, "Player 2", 0);
				if(pPlayer[1]->bActive && pPlayer[1]->byLives != -1)
				{
					sprintf(byTemp, "Score: %d", iPlayerScore[1]);
					pWindow->glPrint(500, 360, byTemp, 0);
					if(!bDeadMatch)
					{
						sprintf(byTemp, "%d *", pPlayer[1]->byLives);
						pWindow->glPrint(500, 410, byTemp, 0);
					}
					sprintf(byTemp, "P: %0.2f", pPlayer[1]->fPower);
					pWindow->glPrint(500, 385, byTemp, 0);
				}
				else
				{
					if(bShowPlayerText)
						if(pPlayer[1]->byLives == -1)
						{ // Player 2 is dead
							pWindow->glPrint(500, 360, "GAME OVER", 0);
						}
						else
						{ // Player 2 isn't activated
							pWindow->glPrint(430, 360, "PRESS FIRE TO START", 0);
						}
				}
			}
		}
	}
	else
	{ // We are in the main or credits menu:
		// Draw the background
 		glDisable(GL_LIGHTING);
		glDisable(GL_DEPTH_TEST);
		glDisable(GL_BLEND);
		glEnable(GL_TEXTURE_2D);
		glColor4ub(255,255,255,128);
		glTranslatef(0.0f, 0.0f, -30.0f);
		glMatrixMode(GL_TEXTURE_2D);
		glRotatef(180.0f*float(cos(fBackgroundRot/10.0f)),0.0f,0.0f,1.0f);
		glTranslatef((3.0f*float(cos(fBackgroundRot)))+(2.1f*float(sin(fBackgroundRot*1.4f))),(2.8f*float(sin(fBackgroundRot)))+(1.3f*float(sin(fBackgroundRot*1.4f))),0.0f);
		glRotatef(10.0f*float(sin(fBackgroundRot*1.2f)),1.0f,0.0f,0.0f);
		glMatrixMode(GL_MODELVIEW);
		glCallList(iBackgroundList);


		glEnable(GL_DEPTH_TEST);
		glEnable(GL_LIGHTING);

		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND);		
		glLoadIdentity();
		glTranslatef(0.0f, 0.0f, -50.0f);
		glBindTexture(GL_TEXTURE_2D, GameTexture[4].iOpenGLID);
		DrawActors();
		glDisable(GL_TEXTURE_2D);
		DrawShots();
		glEnable(GL_TEXTURE_2D);
		DrawParticles();

		glBindTexture(GL_TEXTURE_2D, GameTexture[11+byAniStep].iOpenGLID);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND);		
		glLoadIdentity();
		glTranslatef(0.0f, 10.0f-fInvasionYPos, -50.0f+fInvasionZPos);
		pInvasion2Obj->Draw(TRUE, TRUE, FALSE);

		glBindTexture(GL_TEXTURE_2D, GameTexture[4].iOpenGLID);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		glEnable(GL_BLEND);
		glScalef(1.05f, 1.05f, 1.05f);
		pInvasion2Obj->Draw(TRUE, TRUE, FALSE);

		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
 		glDisable(GL_LIGHTING);

		if(bCredits)
		{ // We are in the credits menu:
			glDisable(GL_CULL_FACE);
			glDisable(GL_DEPTH_TEST);
			glColor4f(1.0f, 1.0f, 1.0f, fCreditsText);
			if(byCreditsStep == 1 || byCreditsStep == 2)
			{
				// Display credits pictures:
				glLoadIdentity();
				glTranslatef(-2.0f, -1.2f, -5.0f);
				// COfenberg
				if(byCreditsStep == 1)
					glBindTexture(GL_TEXTURE_2D, GameTexture[15].iOpenGLID);
				// MSpang
				if(byCreditsStep == 2)
					glBindTexture(GL_TEXTURE_2D, GameTexture[16].iOpenGLID);
				glBegin(GL_QUADS); 
					glNormal3f( 0.0f, 0.0f, 1.0f);
					glTexCoord2f(0.01f, 0.99f); glVertex3f(0.0f, 0.0f, 0.0f);
					glTexCoord2f(0.01f, 0.01f); glVertex3f(0.0f, 1.0f, 0.0f);
					glTexCoord2f(0.99f, 0.01f); glVertex3f(1.0f, 1.0f, 0.0f);
					glTexCoord2f(0.99f, 0.99f); glVertex3f(1.0f, 0.0f, 0.0f);
				glEnd();
			}
			// Display credits texts:
			glColor4f(1.0f, 1.0f, 1.0f, 0.95f);
			pWindow->glPrint(280, 300, "Credits", 1);
			if(bBlendIn)
			{
				fCreditsText += 0.001f*g_lDeltatime;
				if(fCreditsText > 1.0f)
				{
					fCreditsText = 1.0f;
					bBlendIn = FALSE;
					bCreditsWaiting = TRUE;
					lCreditsNext = g_lNow+5000;
				}
			}
			if(bBlendOut)
			{
				fCreditsText -= 0.001f*g_lDeltatime;
				if(fCreditsText < 0.0f)
				{
					bBlendOut = FALSE;
					fCreditsText = 0.0f;
					// Go to the next text:
					bBlendIn = TRUE;
					byCreditsStep++;
					if(byCreditsStep > 8)
						byCreditsStep = 0;
				}
			}
			if(bCreditsWaiting)
			{
				if(g_lNow > lCreditsNext)
				{
					bCreditsWaiting = FALSE;
					bBlendOut = TRUE;
				}
			}
			glColor4f(1.0f, 1.0f, 1.0f, fCreditsText);
			switch(byCreditsStep)
			{
				case 0:
					pWindow->glPrint(250, 180, "Invasion2 is a", 0);
					pWindow->glPrint(250, 160, "AblazeSpace", 0);
					pWindow->glPrint(250, 140, "project", 0);
				break;

				case 1:
					pWindow->glPrint(280, 180, "Programmed & Designed by", 1);
					pWindow->glPrint(280, 150, "Christian Ofenberg", 0);
				break;

				case 2:
					pWindow->glPrint(280, 180, "Music by", 1);
					pWindow->glPrint(280, 150, "Mike Spang", 0);
				break;
				
				case 3:
					pWindow->glPrint(250, 170, "Thanks to", 1);
				break;

				case 4:
					pWindow->glPrint(200, 150, "Jeff Molofee and his NeHe side", 0);
				break;

				case 5:
					pWindow->glPrint(200, 150, "Thom Wetzel and his LMNOPC side", 0);
				break;

				case 6:
					pWindow->glPrint(250, 160, "Juergen Stuetz", 0);
					pWindow->glPrint(250, 140, "for testing and tips ;-)", 0);
				break;

				case 7:
					pWindow->glPrint(250, 160, "Stephan Wezel", 0);
					pWindow->glPrint(250, 140, "for testing", 0);
				break;

				case 8:
					pWindow->glPrint(200, 170, "Visit the AblazeSpace homepage:", 1);
					pWindow->glPrint(200, 140, "www.ablazespace.de", 0);
				break;
			}
		}
		else
		{ // We are in the main menu:
			glEnable(GL_TEXTURE_2D);
			glEnable(GL_BLEND);
			glColor4f(1.0f, 1.0f, 1.0f, 0.95f);
			if(bConfigKeysMenu)
			{
				sprintf(byTemp, "Key configuration for player %d", bPlayerKeys+1);
				pWindow->glPrint(180, 300, byTemp, 1);
				switch(iConfigKey)
				{
					case 0: sprintf(byTemp, "Press the 'turn left' key"); break;
					case 1: sprintf(byTemp, "Press the 'turn right' key"); break;
					case 2: sprintf(byTemp, "Press the 'thrust' key"); break;
					case 3: sprintf(byTemp, "Press the 'shield' key"); break;
					case 4: sprintf(byTemp, "Press the 'stop' key"); break;
					case 5: sprintf(byTemp, "Press the 'fire' key"); break;
				}
				pWindow->glPrint(220, 150, byTemp, 0);
			}
			else
			if(bOptionsMenu)
			{
				pWindow->glPrint(280, 300, "Options", 1);
				glColor4f(0.5f, 0.5f, 0.5f, 0.8f);
				if(bySelectedOption == 0)
					glColor4f(1.0f, 0.0f, 0.0f, 0.95f);
				pWindow->glPrint(200, 200, "Set player 1 keys", 0);
				glColor4f(0.5f, 0.5f, 0.5f, 0.8f);
				if(bySelectedOption == 1)
					glColor4f(1.0f, 0.0f, 0.0f, 0.95f);
				pWindow->glPrint(200, 170, "Set player 1 standart keys", 0);
				glColor4f(0.5f, 0.5f, 0.5f, 0.8f);
				if(bySelectedOption == 2)
					glColor4f(1.0f, 0.0f, 0.0f, 0.95f);
				pWindow->glPrint(200, 140, "Set player 2 keys", 0);
				glColor4f(0.5f, 0.5f, 0.5f, 0.8f);
				if(bySelectedOption == 3)
					glColor4f(1.0f, 0.0f, 0.0f, 0.95f);
				pWindow->glPrint(200, 110, "Set player 2 standart keys", 0);
				glColor4f(0.5f, 0.5f, 0.5f, 0.8f);
				if(bySelectedOption == 4)
					glColor4f(1.0f, 0.0f, 0.0f, 0.95f);
				pWindow->glPrint(200, 80, "Other options", 0);
			}
			else
			if(bDeadMatchMenu)
			{
				pWindow->glPrint(280, 300, "Dead Match", 1);
				glColor4f(0.5f, 0.5f, 0.5f, 0.8f);
				if(bySelectedOption == 0)
					glColor4f(1.0f, 0.0f, 0.0f, 0.95f);
				pWindow->glPrint(200, 200, "Only players - normal mode", 0);
				glColor4f(0.5f, 0.5f, 0.5f, 0.8f);
				if(bySelectedOption == 1)
					glColor4f(1.0f, 0.0f, 0.0f, 0.95f);
				pWindow->glPrint(200, 170, "Only players - gravity mode", 0);
				glColor4f(0.5f, 0.5f, 0.5f, 0.8f);
				if(bySelectedOption == 2)
					glColor4f(1.0f, 0.0f, 0.0f, 0.95f);
				pWindow->glPrint(200, 140, "Players and Ufos", 0);
				glColor4f(0.5f, 0.5f, 0.5f, 0.8f);
				if(bySelectedOption == 3)
					glColor4f(1.0f, 0.0f, 0.0f, 0.95f);
				pWindow->glPrint(200, 110, "Players, Ufos and occurrences", 0);
			}
			else
			{
				if(!bShowHighscore)
				{
					glColor4f(0.5f, 0.5f, 0.5f, 0.8f);
					if(bySelectedOption == 0)
						glColor4f(1.0f, 0.0f, 0.0f, 0.95f);
					pWindow->glPrint(250, 280, "1 Player", 0);
					glColor4f(0.5f, 0.5f, 0.5f, 0.8f);
					if(bySelectedOption == 1)
						glColor4f(1.0f, 0.0f, 0.0f, 0.95f);
					pWindow->glPrint(250, 250, "2 Player work", 0);
					glColor4f(0.5f, 0.5f, 0.5f, 0.8f);
					if(bySelectedOption == 2)
						glColor4f(1.0f, 0.0f, 0.0f, 0.95f);
					pWindow->glPrint(250, 220, "2 Player war", 0);
					glColor4f(0.5f, 0.5f, 0.5f, 0.8f);
					if(bySelectedOption == 3)
						glColor4f(1.0f, 0.0f, 0.0f, 0.95f);
					pWindow->glPrint(250, 190, "Dead match", 0);
					glColor4f(0.5f, 0.5f, 0.5f, 0.8f);
					if(bySelectedOption == 4)
						glColor4f(1.0f, 0.0f, 0.0f, 0.95f);
					pWindow->glPrint(250, 160, "Highscore", 0);
					glColor4f(0.5f, 0.5f, 0.5f, 0.8f);
					if(bySelectedOption == 5)
						glColor4f(1.0f, 0.0f, 0.0f, 0.95f);
					pWindow->glPrint(250, 130, "Help", 0);
					glColor4f(0.5f, 0.5f, 0.5f, 0.8f);
					if(bySelectedOption == 6)
						glColor4f(1.0f, 0.0f, 0.0f, 0.95f);
					pWindow->glPrint(250, 100, "Options", 0);
					glColor4f(0.5f, 0.5f, 0.5f, 0.8f);
					if(bySelectedOption == 7)
						glColor4f(1.0f, 0.0f, 0.0f, 0.95f);
					pWindow->glPrint(250, 70, "Credits", 0);
					glColor4f(0.5f, 0.5f, 0.5f, 0.8f);
					if(bySelectedOption == 8)
						glColor4f(1.0f, 0.0f, 0.0f, 0.95f);
					pWindow->glPrint(250, 40, "Exit", 0);
				}
			}
			glColor4f(1.0f, 1.0f, 1.0f, 0.8f);
			pWindow->glPrint(0, 5, "Invasion2 is a AblazeSpace project (www.ablazespace.de)", 0);
		}
	}
	if(bPlayerEnteringHighScore || bShowHighscore)
		DrawPlayersHighscore(pWindow);	
	DeactivateShotLights();
	if(_ASConfig->bShowFPS)
	{ // Display FPS		
		sprintf(byTemp, "FPS: %d", _AS->GetFPS());
		pWindow->glPrint(280, 460, byTemp, 0);
	}
	ASSwapBuffers(*pWindow->GethDC());
	return 0;
} // end GameDraw()

HRESULT GameCheck(AS_WINDOW *pWindow)
{ // begin GameCheck()
	short i;
	float fDelta;
	ACTOR *pActor2;
	char byTemp[256];
	BOOL bTempFullscreen;

	if(_ASConfig->bSetError)
		return 0;
	for(i = 0; i < 3; i++)
		fPlayerShipRot[i] += 0.05f*g_lDeltatime;
	bShowPlayerText = ((BOOL) ((g_lNow-g_lProgramStartTime) / 1000)) % 2;
	if(g_lNow > lNextAniTime)
	{
		lNextAniTime = g_lNow+100;
		if(!bAniStep)
		{
			byAniStep++;
			if(byAniStep > 2)
				bAniStep = 1;
		}
		else
		{
			byAniStep--;
			if(byAniStep < 1)
				bAniStep = 0;
		}
	}
	// Animate the background
	if(!bBackground)
		fBackgroundRot += 0.0005f*g_lDeltatime;
	else
		fBackgroundRot += 0.00005f*g_lDeltatime;
	// Animate the alien background:
	if((g_lNow-lBackFlashTime) > lBackFlashTimeDelay)
	{
		lBackFlashTime = g_lNow;
		lBackFlashTimeDelay = rand() % 500+300;
		fLastBackFlash = fBackFlash;
		fBackFlash = (float) (rand() % 50)/100.0f+0.5f;
		fBackFlashDelta = fBackFlash-fLastBackFlash;
	}
	fDelta = ((float) (g_lNow-lBackFlashTime+1)/lBackFlashTimeDelay);
	if(fDelta < 0.0f)
		fDelta = -fDelta;
	if(fBackFlash > fLastBackFlash)
		fCurrentBackFlash = (float) fLastBackFlash+fBackFlashDelta*fDelta;
	else
		fCurrentBackFlash = (float) fLastBackFlash+fBackFlashDelta*fDelta;
	CheckActors(FALSE);
	CheckShots();
	CheckParticles();
	if(bPlayerEnteringHighScore)
		CheckPlayersHighscore();
	if(ASKeys[VK_F12])
	{
		ASKeys[VK_F12] = FALSE;
		bTempFullscreen = _ASConfig->bFullScreen;
		if(_ASConfig->bFullScreen)
		{
			_ASConfig->bFullScreen = FALSE;
			ChangeDisplayMode();
		}
		_ASConfig->bFullScreen = bTempFullscreen;
		DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CONFIG), *_AS->pWindow[GAME_WINDOW_ID].GethWnd(), (DLGPROC) ConfigProc);
		if(_ASConfig->bFullScreen)
			ChangeDisplayMode();
		else
			_AS->pWindow[GAME_WINDOW_ID].Resize(_ASConfig->iWindowWidth, _ASConfig->iWindowHeight);
		ASDestroyOpenGLTextures(GAME_TEXTURES, GameTexture);
		ASGenOpenGLTextures(GAME_TEXTURES, GameTexture);
	}
	if(!bMainMenu)
	{ // We are in the game:
		if(ASKeys[VK_ESCAPE] && !bShowHighscore)
		{
			ASKeys[VK_ESCAPE] = FALSE;
			SetupMainMenu();
			return 0;
		}
		CheckPlayers(FALSE);
		if(bCheatsActivated && !bGameOver)
		{
			// Player 1
			if(ASKeys[VK_F1])
			{
				ASKeys[VK_F1] = FALSE;
				byPlayerWeapon[0] = SINGLE_LASER_WEAPON;
			}
			if(ASKeys[VK_F2])
			{
				ASKeys[VK_F2] = FALSE;
				byPlayerWeapon[0] = DOUBLE_LASER_WEAPON;
			}
			if(ASKeys[VK_F3])
			{
				ASKeys[VK_F3] = FALSE;
				pPlayer[0]->fPower = pPlayer[0]->fMaxPower;
			}
			if(ASKeys[VK_F4])
			{
				ASKeys[VK_F4] = FALSE;
				if(pPlayer[0]->byLives < 3)
					pPlayer[0]->byLives++;
			}
			// Player 2
			if(ASKeys[VK_F5])
			{
				ASKeys[VK_F5] = FALSE;
				byPlayerWeapon[1] = SINGLE_LASER_WEAPON;
			}
			if(ASKeys[VK_F6])
			{
				ASKeys[VK_F6] = FALSE;
				byPlayerWeapon[1] = DOUBLE_LASER_WEAPON;
			}
			if(ASKeys[VK_F7])
			{
				ASKeys[VK_F7] = FALSE;
				pPlayer[1]->fPower = pPlayer[1]->fMaxPower;
			}
			if(ASKeys[VK_F8])
			{
				ASKeys[VK_F8] = FALSE;
				if(pPlayer[1]->byLives < 3)
					pPlayer[1]->byLives++;
			}
		}
	}
	else
	{
		if(fInvasionZPos > 0.0f)
		{
			fInvasionZPos -= 0.01f*g_lDeltatime;
			if(fInvasionZPos < 0.0f)
				fInvasionZPos = 0.0f;
		}
		if(fInvasionYPos > 0.0f)
		{
			fInvasionYPos -= 0.001f*g_lDeltatime;
			if(fInvasionYPos < 0.0f)
				fInvasionYPos = 0.0f;
		}
		if(bCredits || bShowHighscore)
		{ // We are in the credits menu:
			for(i = 0; i < 256; i++)
			{
				if(ASKeys[i])
				{
					ASKeys[i] = FALSE;
					SetupMainMenu();
				}
			}
			goto Shots;
		}
		if(bConfigKeysMenu)
		{
			for(i = 0; i < 256; i++)
			{
				if(ASKeys[i])
				{
					ASKeys[i] = FALSE;
					switch(iConfigKey)
					{
						case 0: _ASConfig->iLeftKey[bPlayerKeys] = i; break;
						case 1: _ASConfig->iRightKey[bPlayerKeys] = i; break;
						case 2: _ASConfig->iThrustKey[bPlayerKeys] = i; break;
						case 3: _ASConfig->iShieldKey[bPlayerKeys] = i; break;
						case 4: _ASConfig->iStopKey[bPlayerKeys] = i; break;
						case 5:
							_ASConfig->iFireKey[bPlayerKeys] = i;
							bConfigKeysMenu = FALSE;
						break;
					}
					iConfigKey++;
				}
			}
			goto Shots;
		}
		// We are in the main menu:
	 	if(ASKeys[VK_ESCAPE])
		{
			ASKeys[VK_ESCAPE] = FALSE;
			if(bOptionsMenu)
			{
				bOptionsMenu = FALSE;
				bySelectedOption = 0;
			}
			else
			if(bDeadMatchMenu)
			{
				bDeadMatchMenu = FALSE;
				bySelectedOption = 0;
			}
			else
				_AS->SetShutDown(TRUE);
			return 0;
		}
		if(ASKeys[VK_UP])
		{
			ASKeys[VK_UP] = FALSE;
			bySelectedOption--;
			if(bOptionsMenu)
			{
				if(bySelectedOption < 0)
					bySelectedOption = 4;
			}
			else
			if(bDeadMatchMenu)
			{
				if(bySelectedOption < 0)
					bySelectedOption = 3;
			}
			else
			{
				if(bySelectedOption < 0)
					bySelectedOption = 8;
			}
		}
		if(ASKeys[VK_DOWN])
		{
			ASKeys[VK_DOWN] = FALSE;
			bySelectedOption++;
			if(bOptionsMenu)
			{
				if(bySelectedOption > 4)
					bySelectedOption = 0;
			}
			else
			if(bDeadMatchMenu)
			{
				if(bySelectedOption > 3)
					bySelectedOption = 0;
			}
			else
			{
				if(bySelectedOption > 8)
					bySelectedOption = 0;
			}
		}
		if(ASKeys[VK_RETURN] || ASKeys[VK_SPACE])
		{
			ASKeys[VK_RETURN] = FALSE;
			ASKeys[VK_SPACE] = FALSE;
			if(bOptionsMenu)
			{
				switch(bySelectedOption)
				{
					case 0: // Set player 1 keys
						bPlayerKeys = 0;
						iConfigKey = 0;
						bConfigKeysMenu = TRUE;
					break;

					case 1: // Set player 1 standart keys
						_ASConfig->iLeftKey[0] = 37;
						_ASConfig->iRightKey[0] = 39;
						_ASConfig->iThrustKey[0] = 38;
						_ASConfig->iShieldKey[0] = 40;
						_ASConfig->iStopKey[0] = 13;
						_ASConfig->iFireKey[0] = 32;
					break;

					case 2: // Set player 2 keys
						bPlayerKeys = 1;
						iConfigKey = 0;
						bConfigKeysMenu = TRUE;
					break;

					case 3: // Set player 2 standart keys
						_ASConfig->iLeftKey[1] = 65;
						_ASConfig->iRightKey[1] = 68;
						_ASConfig->iThrustKey[1] = 87;
						_ASConfig->iShieldKey[1] = 83;
						_ASConfig->iStopKey[1] = 9;
						_ASConfig->iFireKey[1] = 81;
					break;

					case 4: // Other options
						bTempFullscreen = _ASConfig->bFullScreen;
						if(_ASConfig->bFullScreen)
						{
							_ASConfig->bFullScreen = FALSE;
							ChangeDisplayMode();
						}
						_ASConfig->bFullScreen = bTempFullscreen;
						DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CONFIG), *_AS->pWindow[GAME_WINDOW_ID].GethWnd(), (DLGPROC) ConfigProc);
						if(_ASConfig->bFullScreen)
							ChangeDisplayMode();
						else
							_AS->pWindow[GAME_WINDOW_ID].Resize(_ASConfig->iWindowWidth, _ASConfig->iWindowHeight);
						ASDestroyOpenGLTextures(GAME_TEXTURES, GameTexture);
						ASGenOpenGLTextures(GAME_TEXTURES, GameTexture);
					break;
				}
			}
			else
			if(bDeadMatchMenu)
			{
				switch(bySelectedOption)
				{
					case 0: // Only players - normal mode
						bDeadMatch = TRUE;
						StartNewGame();
						bUFOS = FALSE;
						bOccurrences = FALSE;
						goto GoIntoDeadMatch;
					
					case 1: // Only players - gravity mode
						bDeadMatch = TRUE;
						StartNewGame();
						bOccurrences = FALSE;
						bGravity = TRUE;
						bUFOS = FALSE;
					GoIntoDeadMatch:
						bPlayerWar = TRUE;
						b2Player = TRUE;
						bBackground = rand() % 2;
						ASStopMidi();
						sprintf(byTemp, "%s%s//Nighttrain.mid", _AS->pbyProgramPath, _AS->pbyMusicFile);
						ASPlayMidi(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), byTemp);
						return 0;
					break;

					case 2: // Players and UFOS
						bDeadMatch = TRUE;
						StartNewGame();
						bOccurrences = FALSE;
						goto GoIntoDeadMatch;

					case 3: // Players, UFOS and occurrences
						bDeadMatch = TRUE;
						StartNewGame();
						goto GoIntoDeadMatch;
				}
				goto Particles;
			}
			else
			{
				switch(bySelectedOption)
				{
					case 0: // 1 Player
						bDeadMatch = FALSE;
						bPlayerWar = FALSE;
						StartNewGame();
						b2Player = FALSE;
						goto StartGameMusic;
					
					case 1: // 2 Player work
						bDeadMatch = FALSE;
						bPlayerWar = FALSE;
						StartNewGame();
						b2Player = TRUE;
						goto StartGameMusic;
					
					case 2: // 2 Player war
						bDeadMatch = FALSE;
						bPlayerWar = TRUE;
						StartNewGame();
						b2Player = TRUE;
					StartGameMusic:
						ASStopMidi();
						sprintf(byTemp, "%s%s//NativeLove.mid", _AS->pbyProgramPath, _AS->pbyMusicFile);
						ASPlayMidi(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), byTemp);
						return 0;
					
					case 3: // Dead match
						bDeadMatchMenu = TRUE;
						bySelectedOption = 0;
						return 0;

					case 4: // Highscore
						byPlayersHScorePlace = -1;
						bShowHighscore = TRUE;
					break;
					
					case 5: // Help
						if(_ASConfig->bFullScreen)
						{
							_ASConfig->bFullScreen = FALSE;
							ChangeDisplayMode();
						}
						_AS->WriteLogMessage("Open help file");
						ShellExecute(0, "open", "help.html", 0, 0, SW_SHOW);
					break;

					case 6: // Options
						bOptionsMenu = TRUE;
						bySelectedOption = 0;
					break;
					
					case 7: // Credits
						bCredits = TRUE;
						byCreditsStep = 0;
						fCreditsText = 0.0f;
						bBlendIn = TRUE;
						bBlendOut = FALSE;
						bCreditsWaiting = FALSE;
						ASStopMidi();
						sprintf(byTemp, "%s%s//CosmicAngel_Part2.mid", _AS->pbyProgramPath, _AS->pbyMusicFile);
						ASPlayMidi(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), byTemp);
					break;
					
					case 8: // Exit
						_AS->SetShutDown(TRUE);
					break;
				}
			}
		}
	Particles:
		// Make particles:
		for(i = 0; i < 2; i++)
		{
			if(bDeadMatchMenu  || bOptionsMenu)
				pPlayer[i]->fPos[Y] = -3.0f*bySelectedOption-2.3f;
			else
				pPlayer[i]->fPos[Y] = -3.0f*bySelectedOption+5.7f;
			if(!bStep[i])
			{
				pPlayer[i]->fPos[X] += 0.01f*g_lDeltatime;
				if(bDeadMatchMenu || bOptionsMenu)
				{
					if(pPlayer[i]->fPos[X] > 20.0f)
						bStep[i] = 1;
				}
				else
				{
					if(pPlayer[i]->fPos[X] > 10.0f)
						bStep[i] = 1;
				}
			}
			else
			{
				pPlayer[i]->fPos[X] -= 0.01f*g_lDeltatime;
				if(bDeadMatchMenu || bOptionsMenu)
				{
					if(pPlayer[i]->fPos[X] < -20.0f)
						bStep[i] = 0;
				}
				else
				{
					if(pPlayer[i]->fPos[X] < -10.0f)
						bStep[i] = 0;
				}
			}
			if((g_lNow-pPlayer[i]->lLastShotTime) > 200)
			{
				pPlayer[i]->lLastShotTime = g_lNow;
				CreateSmoke(pPlayer[i]);
			}
		}
	Shots:
		// Make shots:
		if((g_lNow-lLastShotTime2) > 1000)
		{ // The UFO fires a shot:
			lLastShotTime2 = g_lNow;
			pActor2 = FindNoneActiveShot();
			if(pActor2)
			{
				pActor2->Init();
				pActor2->bActive = TRUE;
				i = rand() % 3;
				pActor2->iType = SINGLE_LASER_SHOT;
				if(i == 1)
					pActor2->byPlayer = 1;
				if(i == 2)
					pActor2->iType = UFO_SHOT;
				pActor2->fRadius = 0.7f;
				pActor2->fPos[X] = -35.0f;
				pActor2->fPos[Y] = 12.0f;
				pActor2->fPos[Z] = 0.0f;
				pActor2->lStartTime = g_lNow;
				pActor2->lEndTime = pActor2->lStartTime+10000;
				pActor2->fVelocity[X] = ((float) (rand() % 100))/100.0f+0.1f;
			}
		}
	}
	return 0;
} // end GameCheck()

void LoadGameTextures(void)
{ // begin LoadGameTextures()
	char byFilename[GAME_TEXTURES][256] = {"space_lt.jpg",
										   "space_rt.jpg",
										   "space_rb.jpg",
										   "space_lb.jpg",
										   "Asteroid.jpg",
										   "Ship.jpg",
										   "Wave.jpg",
										   "Shield.jpg",
										   "AlienBack.jpg",
										   "Smoke.jpg",
										   "Star.jpg",
										   "Fire1.jpg",
										   "Fire2.jpg",
										   "Fire3.jpg",
										   "Fire4.jpg",
										   "COfenberg.jpg",
										   "MSpang.jpg"};

	ASLoadTextures(byFilename, GAME_TEXTURES, GameTexture);
	ASGenOpenGLTextures(GAME_TEXTURES, GameTexture);
} // begin LoadGameTextures()

void DestroyGameTextures(void)
{ // begin DestroyGameTextures()
	ASDestroyOpenGLTextures(GAME_TEXTURES, GameTexture);
	ASDestroyTextures(GAME_TEXTURES, GameTexture);
} // end DestroyGameTextures()

void LoadSounds(void)
{ // begin LoadSounds()
	if(!_AS->bSoundPossible)
		return;
    pThrustSound = DSUtil_CreateSound(TEXT("THRUST"), 1);
	bThrustSoundOn[0] = FALSE;
	bThrustSoundOn[1] = FALSE;
    pExplosion1Sound = DSUtil_CreateSound(TEXT("EXPLOSION1"), 1);
    pExplosion2Sound = DSUtil_CreateSound(TEXT("EXPLOSION"), 1);
    pShot1Sound = DSUtil_CreateSound(TEXT("SHOT1"), 1);
    pCollision1Sound = DSUtil_CreateSound(TEXT("COLLISION1"), 1);
    pUFOSound = DSUtil_CreateSound(TEXT("UFO"), 1);
} // end LoadSounds()

void DestroySounds(void)
{ // begin DestroySounds()
	if(!_AS->bSoundPossible)
		return;
	DSUtil_DestroySound(pThrustSound);
	pThrustSound = NULL;
	DSUtil_DestroySound(pExplosion1Sound);
	pExplosion1Sound = NULL;
	DSUtil_DestroySound(pExplosion2Sound);
	pExplosion2Sound = NULL;
	DSUtil_DestroySound(pShot1Sound);
	pShot1Sound = NULL;
	DSUtil_DestroySound(pCollision1Sound);
	pCollision1Sound = NULL;
	DSUtil_DestroySound(pUFOSound);
	pUFOSound = NULL;
} // end DestroySounds()

void CreateGameLists(void)
{ // begin CreateGameLists()
	iBackgroundList = glGenLists(1);
	glNewList(iBackgroundList, GL_COMPILE);
		// Upper left
		glBindTexture(GL_TEXTURE_2D, GameTexture[0].iOpenGLID);
		glBegin(GL_QUADS);
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f(-22.0f, 16 * 1.4f, 0.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f(-22.0f, 0.0f        , 0.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f( 0.0f       , 0.0f        , 0.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f( 0.0f       , 16 * 1.4f, 0.0f);
		glEnd();
		// Upper right
		glBindTexture(GL_TEXTURE_2D, GameTexture[1].iOpenGLID);
		glBegin(GL_QUADS); 
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f( 0.0f       , 16 * 1.4f, 0.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f( 0.0f       , 0.0f        , 0.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f( 22.0f, 0.0f        , 0.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f( 22.0f, 16 * 1.4f, 0.0f);
		glEnd();		
		// Lower right
		glBindTexture(GL_TEXTURE_2D, GameTexture[2].iOpenGLID);
		glBegin(GL_QUADS); 
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f( 0.0f       , 0.0f        , 0.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f( 0.0f       ,-16 * 1.4f, 0.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f( 22.0f,-16 * 1.4f, 0.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f( 22.0f, 0.0f        , 0.0f);
		glEnd();
		// Lower left
		glBindTexture(GL_TEXTURE_2D, GameTexture[3].iOpenGLID);
		glBegin(GL_QUADS); 
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f(-22.0f, 0.0f        , 0.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f(-22.0f,-16 * 1.4f, 0.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f( 0.0f       ,-16 * 1.4f, 0.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f( 0.0f       , 0.0f        , 0.0f);
		glEnd();		
	glEndList();
	iWaveList = glGenLists(1);
	glNewList(iWaveList, GL_COMPILE);
		glBindTexture(GL_TEXTURE_2D, GameTexture[6].iOpenGLID);
		glBegin(GL_QUADS);
			// Left bottom
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f(-0.5f, -0.5f, 0.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f(0.0f, -0.5f, 0.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f(0.0f, 0.0f, 0.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f(-0.5f, 0.0f, 0.0f);
			// Right bottom
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f(0.0f, -0.5f, 0.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f(0.5f, -0.5f, 0.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f(0.5f, 0.0f, 0.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f(0.0f, 0.0f, 0.0f);
			// Left Top
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f(-0.5f, 0.0f, 0.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f(0.0f, 0.0f, 0.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f(0.0f, 0.5f, 0.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f(-0.5f, 0.5f, 0.0f);
			// Right Top
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f(0.0f, 0.0f, 0.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f(0.5f, 0.0f, 0.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f(0.5f, 0.5f, 0.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f(0.0f, 0.5f, 0.0f);
		glEnd();
	glEndList();
	iShieldList = glGenLists(1);
	glNewList(iShieldList, GL_COMPILE);
		glBindTexture(GL_TEXTURE_2D, GameTexture[7].iOpenGLID);
		glBegin(GL_QUADS);
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f,-1.0f, 0.0f);
			glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f,-1.0f, 0.0f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f, 1.0f, 0.0f);
			glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f, 1.0f, 0.0f);
		glEnd();
	glEndList();
	iSmokeList = glGenLists(1);
	glNewList(iSmokeList, GL_COMPILE);
		glBegin(GL_QUADS);
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.0f, 0.0f); glVertex3f(-0.5f, -0.5f,  0.0f);
			glTexCoord2f(1.0f, 0.0f); glVertex3f( 0.5f, -0.5f,  0.0f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f( 0.5f,  0.5f,  0.0f);
			glTexCoord2f(0.0f, 1.0f); glVertex3f(-0.5f,  0.5f,  0.0f);
		glEnd();
	glEndList();
	iStarList = glGenLists(1);
	glNewList(iStarList, GL_COMPILE);
		glBegin(GL_QUADS);
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.0f, 0.0f); glVertex3f(-0.5f, -0.5f,  0.0f);
			glTexCoord2f(1.0f, 0.0f); glVertex3f( 0.5f, -0.5f,  0.0f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f( 0.5f,  0.5f,  0.0f);
			glTexCoord2f(0.0f, 1.0f); glVertex3f(-0.5f,  0.5f,  0.0f);
		glEnd();
	glEndList();
} // end CreateGameLists();

void DestroyGameLists(void)
{ // begin DestroyGameLists()
	glDeleteLists(iBackgroundList, 1);
	glDeleteLists(iWaveList, 1);
	glDeleteLists(iShieldList, 1);
	glDeleteLists(iSmokeList, 1);
	glDeleteLists(iStarList, 1);
} // end DestroyeGameLists()()

void InitGameObjects(void)
{ // begin InitGameObjects()
	short i;
	char byTemp[256], byTemp2[256];

	// Load objects:
	sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyObjectsFile);
	pInvasion2Obj = new AS_OBJECT;
	sprintf(byTemp2, "%s\\%s", byTemp, "Invasion2.aso");
	if(pInvasion2Obj->Load(byTemp2) == -1)
	{
		delete pInvasion2Obj;
		pInvasion2Obj = NULL;
		goto Error;
	}
	pPlayer1Obj = new AS_OBJECT;
	sprintf(byTemp2, "%s\\%s", byTemp, "Player1.aso");
	if(pPlayer1Obj->Load(byTemp2) == -1)
	{
		delete pPlayer1Obj;
		pPlayer1Obj = NULL;
		goto Error;
	}
	pPlayer2Obj = new AS_OBJECT;
	sprintf(byTemp2, "%s\\%s", byTemp, "Player2.aso");
	if(pPlayer2Obj->Load(byTemp2) == -1)
	{
		delete pPlayer2Obj;
		pPlayer2Obj = NULL;
		goto Error;
	}
	if(!bMoorhuhnModus)
	{
		for(i = 0; i < 4; i++)
		{
			pAsteroidObj[i] = new AS_OBJECT;
			sprintf(byTemp2, "%s\\Asteroid%d.aso", byTemp, i+1);
			if(pAsteroidObj[i]->Load(byTemp2) == -1)
			{
				delete pAsteroidObj[i];
				pAsteroidObj[i] = NULL;
				goto Error;
			}
		}
	}
	else
	{
		pAsteroidObj[0] = new AS_OBJECT;
		sprintf(byTemp2, "%s\\%s", byTemp, "Alien5.aso");
		if(pAsteroidObj[0]->Load(byTemp2) == -1)
		{
			delete pAsteroidObj[0];
			pAsteroidObj[0] = NULL;
			goto Error;
		}
	}
	pUFOObj = new AS_OBJECT;
	sprintf(byTemp2, "%s\\%s", byTemp, "UFO.aso");
	if(pUFOObj->Load(byTemp2) == -1)
	{	
		delete pUFOObj;
		pUFOObj = NULL;
		goto Error;
	}
	pSingleLaserWeaponObj = new AS_OBJECT;
	sprintf(byTemp2, "%s\\%s", byTemp, "SingleLaserWeapon.aso");
	if(pSingleLaserWeaponObj->Load(byTemp2) == -1)
	{
		delete pSingleLaserWeaponObj;
		pSingleLaserWeaponObj = NULL;
		goto Error;
	}
	pSingleLaserShotObj = new AS_OBJECT;
	sprintf(byTemp2, "%s\\%s", byTemp, "SingleLaserShot.aso");
	if(pSingleLaserShotObj->Load(byTemp2) == -1)
	{
		delete pSingleLaserShotObj;
		pSingleLaserShotObj = NULL;
		goto Error;
	}
	pDoubleLaserWeaponObj = new AS_OBJECT;
	sprintf(byTemp2, "%s\\%s", byTemp, "DoubleLaserWeapon.aso");
	if(pDoubleLaserWeaponObj->Load(byTemp2) == -1)
	{
		delete pDoubleLaserWeaponObj;
		pDoubleLaserWeaponObj = NULL;
		goto Error;
	}
	pDoubleLaserShotObj = new AS_OBJECT;
	sprintf(byTemp2, "%s\\%s", byTemp, "DoubleLaserShot.aso");
	if(pDoubleLaserShotObj->Load(byTemp2) == -1)
	{
		delete pDoubleLaserShotObj;
		pDoubleLaserShotObj = NULL;
		goto Error;
	}
	pUFOShotObj = new AS_OBJECT;
	sprintf(byTemp2, "%s\\%s", byTemp, "UFOShot.aso");
	if(pUFOShotObj->Load(byTemp2) == -1)
	{
		delete pUFOShotObj;
		pUFOShotObj = NULL;
		goto Error;
	}
	pObjectSingleLaserObj = new AS_OBJECT;
	sprintf(byTemp2, "%s\\%s", byTemp, "ObjectSingleLaser.aso");
	if(pObjectSingleLaserObj->Load(byTemp2) == -1)
	{
		delete pObjectSingleLaserObj;
		pObjectSingleLaserObj = NULL;
		goto Error;
	}
	pObjectDoubleLaserObj = new AS_OBJECT;
	sprintf(byTemp2, "%s\\%s", byTemp, "ObjectDoubleLaser.aso");
	if(pObjectDoubleLaserObj->Load(byTemp2) == -1)
	{
		delete pObjectDoubleLaserObj;
		pObjectDoubleLaserObj = NULL;
		goto Error;
	}
	pObjectLiveObj = new AS_OBJECT;
	sprintf(byTemp2, "%s\\%s", byTemp, "ObjectLive.aso");
	if(pObjectLiveObj->Load(byTemp2) == -1)
	{
		delete pObjectLiveObj;
		pObjectLiveObj = NULL;
		goto Error;
	}
	pObjectPowerIncreaseObj = new AS_OBJECT;
	sprintf(byTemp2, "%s\\%s", byTemp, "ObjectPowerIncrease.aso");
	if(pObjectPowerIncreaseObj->Load(byTemp2) == -1)
	{
		delete pObjectPowerIncreaseObj;
		pObjectPowerIncreaseObj = NULL;
		goto Error;
	}
	pObjectFullPowerObj = new AS_OBJECT;
	sprintf(byTemp2, "%s\\%s", byTemp, "ObjectFullPower.aso");
	if(pObjectFullPowerObj->Load(byTemp2) == -1)
	{
		delete pObjectFullPowerObj;
		pObjectFullPowerObj = NULL;
		goto Error;
	}
	pObjectPointsObj = new AS_OBJECT;
	sprintf(byTemp2, "%s\\%s", byTemp, "ObjectPoints.aso");
	if(pObjectPointsObj->Load(byTemp2) == -1)
	{
		delete pObjectPointsObj;
		pObjectPointsObj = NULL;
		goto Error;
	}
	pPowerDisplayObj = new AS_OBJECT;
	sprintf(byTemp2, "%s\\%s", byTemp, "PowerDisplay.aso");
	if(pPowerDisplayObj->Load(byTemp2) == -1)
	{
		delete pPowerDisplayObj;
		pPowerDisplayObj = NULL;
		goto Error;
	}
	// Initialize Actors:
	for(i = 0; i < 2; i++)
		pPlayer[i] = new ACTOR;
	for(i = 0; i < MAX_ACTORS; i++)
		pActors[i] = new ACTOR;
	for(i = 0; i < MAX_PARTICLES; i++)
	{
		pParticle1[i] = new ACTOR;
		pParticle2[i] = new ACTOR;
	}
	for(i = 0; i < MAX_SHOTS; i++)
		pShot[i] = new ACTOR;
	return;
Error:
	_AS->WriteLogMessage("------------------------------------------", byTemp2);
	_AS->WriteLogMessage("Couldn't load: %s   program couldn't run!!", byTemp2);
	_AS->WriteLogMessage("------------------------------------------", byTemp2);
	_ASConfig->bError = TRUE;
	_ASConfig->bSetError = TRUE;
	_AS->SetShutDown(TRUE);
	return;
} // end InitGameObjects()

void DestroyGameObjects(void)
{ // begin DestroyGameObjects()
	short i;

	if(pInvasion2Obj)
	{
		pInvasion2Obj->Destroy();
		delete pInvasion2Obj;
	}
	if(pPlayer1Obj)
	{
		pPlayer1Obj->Destroy();
		delete pPlayer1Obj;
	}
	if(pPlayer2Obj)
	{
		pPlayer2Obj->Destroy();
		delete pPlayer2Obj;
	}
	for(i = 0; i < 4; i++)
	{
		if(pAsteroidObj[i])
		{
			pAsteroidObj[i]->Destroy();
			delete pAsteroidObj[i];
		}
	}
	if(pUFOObj)
	{
		pUFOObj->Destroy();
		delete pUFOObj;
	}
	if(pSingleLaserWeaponObj)
	{
		pSingleLaserWeaponObj->Destroy();
		delete pSingleLaserWeaponObj;
	}
	if(pSingleLaserShotObj)
	{
		pSingleLaserShotObj->Destroy();
		delete pSingleLaserShotObj;
	}
	if(pDoubleLaserWeaponObj)
	{
		pDoubleLaserWeaponObj->Destroy();
		delete pDoubleLaserWeaponObj;
	}
	if(pDoubleLaserShotObj)
	{
		pDoubleLaserShotObj->Destroy();
		delete pDoubleLaserShotObj;
	}
	if(pUFOShotObj)
	{
		pUFOShotObj->Destroy();
		delete pUFOShotObj;
	}
	if(pObjectSingleLaserObj)
	{
		pObjectSingleLaserObj->Destroy();
		delete pObjectSingleLaserObj;
	}
	if(pObjectDoubleLaserObj)
	{
		pObjectDoubleLaserObj->Destroy();
		delete pObjectDoubleLaserObj;
	}
	if(pObjectLiveObj)
	{
		pObjectLiveObj->Destroy();
		delete pObjectLiveObj;
	}
	if(pObjectPowerIncreaseObj)
	{
		pObjectPowerIncreaseObj->Destroy();
		delete pObjectPowerIncreaseObj;
	}
	if(pObjectFullPowerObj)
	{
		pObjectFullPowerObj->Destroy();
		delete pObjectFullPowerObj;
	}
	if(pObjectPointsObj)
	{
		pObjectPointsObj->Destroy();
		delete pObjectPointsObj;
	}
	if(pPowerDisplayObj)
	{
		pPowerDisplayObj->Destroy();
		delete pPowerDisplayObj;
	}
	for(i = 0; i < 2; i++)
		delete pPlayer[i];
	for(i = 0; i < MAX_ACTORS; i++)
		delete pActors[i];
	for(i = 0; i < MAX_PARTICLES; i++)
	{
		delete pParticle1[i];
		delete pParticle2[i];
	}
	for(i = 0; i < MAX_SHOTS; i++)
		delete pShot[i];
} // end DestroyGameObjects()

void ActivateLights(void)
{ // begin ActivateLights()
	short i, iLightCounter = 0;
	GLfloat afLightData[4]  = {0.0f, 0.0f, 0.0f, 0.0f};
	ACTOR *pActor;

	if(!_ASConfig->byLight)
		return;
	afLightData[0] = 0.0f;
	afLightData[1] = 0.0f;
	afLightData[2] = 0.0f;
	afLightData[3] = 1.0f;
	glLightfv(GL_LIGHT2+iLightCounter, GL_POSITION, afLightData);
	afLightData[0] = fCurrentBackFlash;
	afLightData[1] = fCurrentBackFlash;
	afLightData[2] = fCurrentBackFlash;
	glLightfv(GL_LIGHT2+iLightCounter, GL_DIFFUSE, afLightData);
	glEnable(GL_LIGHT2+iLightCounter);
	iLightCounter++;
	for(i = 0; i < 2; i++)
	{
		if(!pPlayer[i]->bActive)
			continue;
		if(pPlayer[i]->bShield || pPlayer[i]->iExplosionStep != -1)	
		{
			afLightData[0] = pPlayer[i]->fPos[X];
			afLightData[1] = pPlayer[i]->fPos[Y];
			afLightData[2] = pPlayer[i]->fPos[Z];
			afLightData[3] = 1.0f;
			glLightfv(GL_LIGHT2+iLightCounter, GL_POSITION, afLightData);
			if(!i || pPlayer[i]->iExplosionStep != -1)
			{
				afLightData[0] = 1.0f;
				afLightData[1] = 0.0f;
			}
			else
			{
				afLightData[0] = 0.0f;
				afLightData[1] = 1.0f;
			}
			afLightData[2] = 0.0f;
			glLightfv(GL_LIGHT2+iLightCounter, GL_DIFFUSE, afLightData);
			glEnable(GL_LIGHT2+iLightCounter);
			iLightCounter++;
		}
	}
	for(i = 0; i < MAX_SHOTS; i++)
	{
		pActor = pShot[i];
		if(!pActor->bActive)
			continue;
		if(iMaxLights < iLightCounter-2)
			break;
		afLightData[0] = pActor->fPos[X];
		afLightData[1] = pActor->fPos[Y];
		afLightData[2] = pActor->fPos[Z];
		afLightData[3] = 1.0f;
		glLightfv(GL_LIGHT2+iLightCounter, GL_POSITION, afLightData);
		if(pActor->iType == UFO_SHOT)
		{
			afLightData[0] = 0.0f;
			afLightData[1] = 0.0f;
			afLightData[2] = 1.0f;
		}
		else
		{
			if(!pActor->byPlayer)
			{
				afLightData[0] = 1.0f;
				afLightData[1] = 0.0f;
				afLightData[2] = 0.0f;
			}
			else
			{
				afLightData[0] = 0.0f;
				afLightData[1] = 1.0f;
				afLightData[2] = 0.0f;
			}
		}
		glLightfv(GL_LIGHT2+iLightCounter, GL_DIFFUSE, afLightData);
		glEnable(GL_LIGHT2+iLightCounter);
		iLightCounter++;
	}
} // end ActivateLights()

void DeactivateShotLights(void)
{ // begin DeactivateShotLights()
	short i, iLightCounter = 0;

	if(!_ASConfig->byLight)
		return;
	for(i = 0; i < 2; i++)
	{
		if(!pPlayer[i]->bActive)
			continue;
		if(pPlayer[i]->bShield || pPlayer[i]->iExplosionStep != -1)	
		{
			glDisable(GL_LIGHT2+iLightCounter);
			iLightCounter++;
		}
	}
	for(i = 0; i < MAX_SHOTS; i++)
	{
		if(!pShot[i]->bActive)
			continue;
		if(iMaxLights < iLightCounter-2)
			break;
		glDisable(GL_LIGHT2+iLightCounter);
		iLightCounter++;
	}
} // end DeactivateShotLights()

void SetupMainMenu(void)
{ // begin SetupMainMenu()
	char byTemp[256];

	if(_ASConfig->bSetError)
		return;
	bDeadMatchMenu = FALSE;
	bDeadMatch = FALSE;
	byAniStep = 0;
	bAniStep = 0;
	bySelectedOption = 0;
	bMainMenu = TRUE;
	if(!bCredits && !bShowHighscore)
	{
		StartNewGame();
		fInvasionZPos = 40.0f;
		fInvasionYPos = 10.0f;
	}
	if(!bShowHighscore)
	{
		ASStopMidi();
		sprintf(byTemp, "%s%s//MysteryTalesby_Mike!.mid", _AS->pbyProgramPath, _AS->pbyMusicFile);
		ASPlayMidi(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), byTemp);
	}
	pPlayer[0]->fPos[X] = 20.0f;
	bStep[0] = 1;
	pPlayer[1]->fPos[X] = -20.0f;
	bStep[0] = 0;
	bMainMenu = TRUE;
	bCredits = FALSE;
	bShowHighscore = FALSE;
} // end SetupMainMenu()

void DeactivateAllActors(void)
{ // begin DeactivateAllActors()
	short i;

	for(i = 0; i < MAX_ACTORS; i++)
	{
		if(pActors[i])
			pActors[i]->bActive = FALSE;
	}
	for(i = 0; i < MAX_PARTICLES; i++)
	{
		if(pParticle1[i])
			pParticle1[i]->bActive = FALSE;
		if(pParticle2[i])
			pParticle2[i]->bActive = FALSE;
	}
	for(i = 0; i < MAX_SHOTS; i++)
	{
		if(pShot[i])
			pShot[i]->bActive = FALSE;
	}
} // end DeactivateAllActors()

void CreateLevel(void)
{ // begin CreateLevel()
	short i, i2;
	ACTOR *pActor;
	
	for(i = 0; i < 5; i++)
	{
		pActor = FindNoneActiveActor();	
		if(!pActor)
			break;
		for(i2 = 0; i2 < 100; i2++)
		{
			pActor->bActive = TRUE;
			pActor->iExplosionStep = -1;
			pActor->iType = ASTEROID_ACTOR;
			pActor->fScale = 1.0f-(((float) (rand() % 100))/500.0f);
			pActor->fRadius = 6.0f*pActor->fScale;
			if(!bMoorhuhnModus)
				pActor->byPlayer = rand() % 4;
			switch(rand() % 4)
			{
				case 0: // Left top
					pActor->fPos[X] = -((float) (rand() % (int) (SPACE_WIDTH-pActor->fRadius)));
					pActor->fPos[Y] = -((float) (rand() % (int) (SPACE_HEIGHT-pActor->fRadius)));
				break;

				case 1: // Right top
					pActor->fPos[X] = ((float) (rand() % (int) (SPACE_WIDTH-pActor->fRadius)));
					pActor->fPos[Y] = -((float) (rand() % (int) (SPACE_HEIGHT-pActor->fRadius)));
				break;

				case 2: // Right bottom
					pActor->fPos[X] = ((float) (rand() % (int) (SPACE_WIDTH-pActor->fRadius)));
					pActor->fPos[Y] = ((float) (rand() % (int) (SPACE_HEIGHT-pActor->fRadius)));
				break;

				case 3: // Left bottom
					pActor->fPos[X] = -((float) (rand() % (int) (SPACE_WIDTH-pActor->fRadius)));
					pActor->fPos[Y] = ((float) (rand() % (int) (SPACE_HEIGHT-pActor->fRadius)));
				break;
			}
			if(CheckActors(TRUE))
			{
				pActor->bActive = FALSE;
				continue;
			}
			pActor->fMass = pActor->fRadius*((float) PI);
			if(rand() % 2)
				pActor->fVelocity[X] = ((float) (rand() % 100))/1000.0f;
			else
				pActor->fVelocity[X] = -((float) (rand() % 100))/1000.0f;
			if(rand() % 2)
				pActor->fVelocity[Y] = ((float) (rand() % 100))/1000.0f;
			else
				pActor->fVelocity[Y] = -((float) (rand() % 100))/1000.0f;
			pActor->fRotVelocity[X] = ((float) (rand() % 100)/3000.0f);
			pActor->fRotVelocity[Y] = ((float) (rand() % 100)/3000.0f);
		}
	}
} // end CreateLevel()

void CreateNewActor(void)
{ // begin CreateNewActor()
	short i;
	ACTOR *pActor;

	if(CountAsteroids() > 20)
		return;
	for(i = 0; i < 100; i++)
	{
  		pActor = FindNoneActiveActor();
		if(!pActor)
			continue;
		pActor->bActive = TRUE;
		pActor->iExplosionStep = -1;
		pActor->iType = ASTEROID_ACTOR;
		pActor->fScale = 1.0f-(((float) (rand() % 100))/500.0f);
		pActor->fRadius = 6.0f*pActor->fScale;
		if(!bMoorhuhnModus)
			pActor->byPlayer = rand() % 4;
		if(rand() % 2)
			pActor->fVelocity[X] = ((float) (rand() % 100))/1000.0f;
		else
			pActor->fVelocity[X] = -((float) (rand() % 100))/1000.0f;
		if(rand() % 2)
			pActor->fVelocity[Y] = ((float) (rand() % 100))/1000.0f;
		else
			pActor->fVelocity[Y] = -((float) (rand() % 100))/1000.0f;
		if(pActor->fVelocity[X] > 0.0f)
			pActor->fPos[X] = -SPACE_WIDTH-5.0f;
		else
			pActor->fPos[X] = SPACE_WIDTH+5.0f;
		if(pActor->fVelocity[Y] > 0.0f)
			pActor->fPos[Y] = SPACE_HEIGHT-5.0f;
		else
			pActor->fPos[Y] = SPACE_HEIGHT+5.0f;
		if(CheckActors(TRUE))
		{
			pActor->bActive = FALSE;
			continue;
		}
		pActor->fMass = pActor->fRadius*((float) PI);
		pActor->fRotVelocity[X] = ((float) (rand() % 100)/3000.0f);
		pActor->fRotVelocity[Y] = ((float) (rand() % 100)/3000.0f);
		break;
	}
} // end CreateNewActor()

HRESULT LoadHighscore(void)
{ // begin LoadHighscore()
	FILE *pFile = NULL;
	char byTemp[256];
	
	sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyHighscoreFile);
	pFile = fopen(byTemp, "r");
	if(!pFile)
		return 1;
	fread(Highscore, sizeof(HIGHSCORE), MAX_HIGHSCORES, pFile);
	fclose(pFile);
	return 0;
} // end LoadHighscore()

HRESULT SaveHighscore(void)
{ // begin SaveHighscore()
	FILE *pFile = NULL;
	char byTemp[256];
	
	sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyHighscoreFile);
	pFile = fopen(byTemp, "w");
	if(!pFile)
		return 0;
	fwrite(Highscore, sizeof(HIGHSCORE), MAX_HIGHSCORES, pFile);
	fclose(pFile);
	return 0;
} // end SaveHighscore()

void DrawPlayersHighscore(AS_WINDOW *pWindow)
{ // begin DrawPlayersHighscore()
	short i, y;
	char byTemp[256];

	glDisable(GL_LIGHTING);
	glEnable(GL_BLEND);
	glColor4ub(255, 255, 255, 255);
	if(bGameWon && pPlayer[byPlayerHighscore]->fMaxPower >= 200)
	{
		pWindow->glPrint(200, 420, "You Have Won The Game!", 1);
		if(!bMoorhuhnModus)
		{
			pWindow->glPrint(110, 400, "Try to start the program whith the parameter", 0);
			pWindow->glPrint(260, 380, "-Moorhuhn", 0);
		}
		pWindow->glPrint(110, 360, "You could find cheats on the AblazeSpace", 0);
		pWindow->glPrint(111, 340, "homepage under the Invasion2 features...", 0);
	}
	if(!bPlayerEnteringHighScore)
		pWindow->glPrint(280, 300, "Highscore", 1);
	else
	{ // The player enters or not his name into the highscore:
		if(byPlayersHScorePlace != -2)
		{
			pWindow->glPrint(260, 300, "Congratulations!", 0);
			pWindow->glPrint(220, 290, "You are in the highscore!", 0);
			pWindow->glPrint(140, 280, "Enter your name and hit enter when done.", 0);
		}
		else // He's a looser:
		{
			pWindow->glPrint(270, 300, "You looser!", 0);
			pWindow->glPrint(180, 290, "You are not in the highscore!", 0);
			pWindow->glPrint(270, 280, "Press enter.", 0);
		}
		if(b2Player && !byPlayerHighscore)
			pWindow->glPrint(280, 450, "Player 1", 1);
		if(b2Player && byPlayerHighscore)
			pWindow->glPrint(280, 450, "Player 2", 1);
	}
	pWindow->glPrint(50, 230, "Place", 0);
	pWindow->glPrint(150, 230, "Name", 0);
	pWindow->glPrint(500, 230, "Score", 0);
	for(i = 0, y = 220; i < MAX_HIGHSCORES; i++, y -= 15)
	{
		if(byPlayersHScorePlace == i || byPlayersHScorePlace == -1)
			glColor4f(1.0f, 1.0f, 1.0f, 0.9f);
		else
			glColor4f(0.6f, 0.6f, 0.6f, 0.9f);
		sprintf(byTemp, "%d.", i);
		pWindow->glPrint(50, y, byTemp, 0);
		pWindow->glPrint(150, y, Highscore[i].byName, 0);
		sprintf(byTemp, "%d",  Highscore[i].iScore);
		pWindow->glPrint(500, y, byTemp, 0);
	}
} // end DrawPlayersHighscore()

void CheckPlayersHighscore(void)
{ // begin CheckPlayersHighscore()
	int i, i2;

	if(byPlayersHScorePlace == -1)
	{ // Check if the player is in the highscore:
		for(i = 0; i < MAX_HIGHSCORES; i++)
		{
			if(iPlayerScore[byPlayerHighscore] >= Highscore[i].iScore)
			{ // The player is better as someone:
				// Make place for the new king:
				for(i2 = MAX_HIGHSCORES-1; i2 >= i; i2--)
				{
					Highscore[i2].iScore = Highscore[i2-1].iScore;
					strcpy(Highscore[i2].byName, Highscore[i2-1].byName);
				}
				Highscore[i].iScore = iPlayerScore[byPlayerHighscore];
				byPlayersHScorePlace = i;
				memset(Highscore[i].byName, 0, 30);
				for(i2 = 0; i2 < 30; i2++)
				{
					Highscore[i].byName[i2] = _AS->pbyUserName[i2];
					if(_AS->pbyUserName[i2] == '\0')
						break;
				}
				byHighScoreInitialsIndex = i2;
				break;
			}
		}
		if(byPlayersHScorePlace == -1)
		{ // The player is a looser:
			byPlayersHScorePlace = -2;
		}
	}
	if(byHighScoreInitialsIndex < 30)
	{
		if((((g_lNow-g_lProgramStartTime) / 500)) % 2)
			Highscore[byPlayersHScorePlace].byName[byHighScoreInitialsIndex] = '_';
		else
			Highscore[byPlayersHScorePlace].byName[byHighScoreInitialsIndex] = ' ';
	}
	if(ASKeys[VK_RETURN])
	{ // Close The Hightscore Menu:
		ASKeys[VK_RETURN] = FALSE;
		if(byHighScoreInitialsIndex < 9)
			Highscore[byPlayersHScorePlace].byName[byHighScoreInitialsIndex] = ' ';
		if(b2Player && !byPlayerHighscore)
		{
			byPlayerHighscore++;
			bShowHighscore = TRUE;
			bPlayerEnteringHighScore = TRUE;
			byPlayersHScorePlace = -1;
			return;
		}
		bShowHighscore = FALSE;
		bCredits = FALSE;
		SetupMainMenu();
		return;
	}
	if(byPlayersHScorePlace != -2)
	{
		if(ASKeys[VK_BACK])
		{
			ASKeys[VK_BACK] = FALSE;
			if(byHighScoreInitialsIndex > 0)
			{
				Highscore[byPlayersHScorePlace].byName[byHighScoreInitialsIndex] = ' ';
				byHighScoreInitialsIndex--;
				Highscore[byPlayersHScorePlace].byName[byHighScoreInitialsIndex] = ' ';
			}
		}
		else 
		if(byHighScoreInitialsIndex <= 29)
		{			
			for(i = 0; i < 38; i++) 
			{
				if(ASKeys[byLegalHighScoreChars[i]])
				{
					Highscore[byPlayersHScorePlace].byName[byHighScoreInitialsIndex] = byLegalHighScoreChars[i];
					ASKeys[byLegalHighScoreChars[i]] = FALSE;
					byHighScoreInitialsIndex++;
					break;
				}
			}
		}
	}
} // end CheckPlayersHighscore()

void GameOver(void)
{ // begin GameOver()
	char byTemp[256];
	
	if(bGameOver)
		return;	
	bGameOver = TRUE;
	// Enable the highscore
	bShowHighscore = TRUE;
	bPlayerEnteringHighScore = TRUE;
	byPlayersHScorePlace = -1;
	byPlayerHighscore = 0;
	ASStopMidi();
	sprintf(byTemp, "%s%s//Rendezvous.mid", _AS->pbyProgramPath, _AS->pbyMusicFile);
	ASPlayMidi(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), byTemp);
} // end GameOver()

void GameWon(void)
{ // begin GameWon()
	char byTemp[256];

	if(bGameWon || bDeadMatch)
		return;	
	bGameWon = TRUE;
	// Enable the highscore
	bShowHighscore = TRUE;
	bPlayerEnteringHighScore = TRUE;
	byPlayersHScorePlace = -1;
	byPlayerHighscore = 0;
	ASStopMidi();
	sprintf(byTemp, "%s%s//Rendezvous.mid", _AS->pbyProgramPath, _AS->pbyMusicFile);
	ASPlayMidi(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), byTemp);
} // end GameWon()
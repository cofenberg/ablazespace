#ifndef __ACTORS_H__
#define __ACTORS_H__


typedef class ACTOR
{
	public:
		BOOL bActive;
		short iID;
		short iType;
		FLOAT3 fPos;
		FLOAT3 fLastPos;
		FLOAT3 fStartPos;
		FLOAT3 fOldPos;
		FLOAT3 fRot;
		FLOAT3 fTempRot;
		FLOAT3 fTempRot2;
		FLOAT2 fVelocity;
		FLOAT3 fRotVelocity;
		float fRed, fGreen, fBlue;
		float fMass;
		float fRadius;
		float fScale;
		char byPlayer; // From which player comes this actor?

		short iExplosionStep;
		long lStartTime;
		long lEndTime;
		long lLastShotTime, lLastShotTime2;
		char byLives;
		AS_OBJECT_FRAME *pMainFrameT;
		AS_OBJECT_FRAME *pFrameT;
		short iAnimationT;
		short iStepT;
		DWORD dwLastTime;
		float fPower, fMaxPower;
		char byDirection;

		BOOL bShield;
		BOOL bGhost;

		ACTOR(void);
		~ACTOR(void);

		void Init(void);

} ACTOR;

enum {LEFT, RIGHT, UP, DOWN};
// Variables: *****************************************************************
extern ACTOR *pPlayer[2];
extern ACTOR *pShot[MAX_SHOTS];
extern ACTOR *pActors[MAX_ACTORS];
extern ACTOR *pParticle1[MAX_PARTICLES];
extern ACTOR *pParticle2[MAX_PARTICLES];
///////////////////////////////////////////////////////////////////////////////
// Functions: *****************************************************************
extern void DrawExplosions(void);
extern void CheckGravity(ACTOR *);
extern void DrawActors(void);
extern HRESULT CheckActors(BOOL);
extern void DrawParticles(void);
extern void CheckParticles(void);
extern void CreateSmoke(ACTOR *);
extern void MakeStars(ACTOR *);
extern ACTOR *FindNoneActiveActor(void);
extern ACTOR *FindNoneActiveParticle1(void);
extern ACTOR *FindNoneActiveParticle2(void);
extern void CheckBallCollision(ACTOR *, ACTOR *, float, float);
extern void DivideActor(ACTOR *, ACTOR *);
extern HRESULT CountAsteroids(void);
extern void DrawPlayers(void);
extern HRESULT CheckPlayers(BOOL);
extern void PlayerDead(short);
extern void DrawShots(void);
extern void CheckShots(void);
extern ACTOR *FindNoneActiveShot(void);
///////////////////////////////////////////////////////////////////////////////


#endif // __ACTORS_H__
#ifndef __MODULE_HEADRES_H__
#define __MODULE_HEADRES_H__


// Includes: ******************************************************************
#include "Invasion2.h"
#include "Game.h"
#include "Actors.h"
#include "WindowProc.h"
///////////////////////////////////////////////////////////////////////////////


#endif // __MODULE_HEADRES_H__
/*
 *	The game Invasion was written by Christian Ofenberg 2000. (www.ablazespace.de)
 *  The code isn't well documented... but it should easy to understand.
 *  I know not all is perfect... but it works!
 * 	Some functions were taken out from the tutorials from NeHe. (nehe.gamedev.net)
 * 	So a big thank to Jeff Molofee for his great homepage who helps 
 *	people which started in OpenGL coding.
 */
#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
AS_CAMERA *pCamera;
AS_CONFIG *pConfig;
///////////////////////////////////////////////////////////////////////////////
// Functions: *****************************************************************
int PASCAL WinMain(HINSTANCE, HINSTANCE, LPSTR, int);
void ChangeDisplayMode(void);
LRESULT CALLBACK CreditsProc(HWND, UINT, WPARAM, LPARAM);
///////////////////////////////////////////////////////////////////////////////

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine, int iCmdShow)
{ // begin WinMain()
	char byTemp[MAX_PATH], byTemp2[256];
	BOOL bTemp, bOpenConfig;
	LPSTR lpTemp;

	pConfig = new AS_CONFIG;
	_ASConfig = pConfig;
	_AS = new AS_ENGINE(hInstance, lpCmdLine, iCmdShow, TRUE);
	if(_AS->GetShutDown())
		return 1;
	sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyConfigFile);
	pConfig->Load(byTemp);
	bTemp = _ASConfig->bLog;
	 _ASConfig->bLog = TRUE;
	if(!bTemp)
		_AS->WriteLogMessage("Deactivate the log");
	_ASConfig->bLog = bTemp;
	if(_ASConfig->bFirstRun)
	{
		_AS->WriteLogMessage("First program start detected");
		MessageBox(NULL, "This is the first program start please check the setup.\n"
						 "Please see the help for informations.\n", GAME_NAME, MB_OK | MB_ICONINFORMATION);
	}
	bCheatsActivated = FALSE;
	bUnlimitedPower = FALSE;
	bInvulnerable = FALSE;
	bNoBlackHole = FALSE;
	bMoorhuhnModus = FALSE;
	bOpenConfig = FALSE;
	lpTemp = lpCmdLine;
	for(;;)
	{
		if(sscanf(lpTemp, "%s", byTemp2) == EOF)
			break;
		if(!strcmp(byTemp2, "-config"))
			bOpenConfig = TRUE;
		if(!strcmp(byTemp2, "-cheats"))
			bCheatsActivated = TRUE;
		if(!strcmp(byTemp2, "-unlimited_power"))
			bUnlimitedPower = TRUE;
		if(!strcmp(byTemp2, "-invulnerable"))
			bInvulnerable = TRUE;
		if(!strcmp(byTemp2, "-no_blackhole"))
			bNoBlackHole = TRUE;
		if(!strcmp(byTemp2, "-Moorhuhn"))
			bMoorhuhnModus = TRUE;
		if(*(lpTemp+strlen(byTemp2)) == 0)
			break;
		lpTemp += strlen(byTemp2)+1;
	}
	if(bMoorhuhnModus)
		MessageBox(NULL,"You play now in the moorhuhn modus!\nAll asteroids are replaced through Moorhuhns.",
		           "Easter Egg", MB_OK | MB_ICONQUESTION);
	// Is An Error Detected?
	if(_ASConfig->bError)
		MessageBox(NULL, "The program wasn't correctly shut down on the last run!\n",
				   GAME_NAME, MB_OK | MB_ICONINFORMATION);
	// Check if we want to show the config dialog:
	if(bOpenConfig || _ASConfig->bFirstRun || _ASConfig->bError) 
		DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CONFIG), NULL, (DLGPROC) ConfigProc);
	pCamera = new AS_CAMERA;
	pCamera->SetPos(0.0f, 0.0f, 0.0f);
	_ASCamera = pCamera;
	_AS->SetModule(MODULE_GAME);
	_ASConfig->bError = TRUE;
	_AS->WriteLogMessage("Go into program loop");
	sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyConfigFile);
	pConfig->Save(byTemp);
	for(;;)
	{
		if(_AS->GetShutDown())
			break;
		_AS->SetModule(_AS->GetNextModule());
		switch(_AS->GetModule())
		{
			case MODULE_GAME:
				Game();
			break;
		}
	}
	_AS->WriteLogMessage("Program loop left");
	_AS->WriteLogMessage("Shut down program");
	if(!_ASConfig->bSetError)
		_ASConfig->bError = FALSE;
	else
		_ASConfig->bError = TRUE;;
	_ASConfig->bFirstRun = FALSE;
	
	sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyConfigFile);
	pConfig->Save(byTemp);
	if(_ASConfig->bError)
		MessageBox(NULL, "There was an error! Please check the log file for more information. (It must be activated in the game)\n",
		           GAME_NAME, MB_OK | MB_ICONINFORMATION);
	delete pCamera;
	delete pConfig;
	delete _AS;
	return 0;
} // end WinMain()

void ChangeDisplayMode(void)
{
	switch(_AS->GetModule())
	{
		case MODULE_GAME:
			// Destroy the old window:
			ASDestroyOpenGL(&_AS->pWindow[GAME_WINDOW_ID], 
							NULL,
							*_AS->pWindow[GAME_WINDOW_ID].GethDC(),
							*_AS->pWindow[GAME_WINDOW_ID].GethRC());
			_AS->ASDestroyWindow(_AS->pWindow[GAME_WINDOW_ID].GethWnd(), GAME_WINDOW_NAME);
			// Create the new window:
			_AS->ASCreateWindow(WindowProc, GAME_WINDOW_NAME, GAME_WINDOW_NAME, _ASConfig->iWindowWidth, _ASConfig->iWindowHeight, LoadMenu(_AS->GetInstance(), MAKEINTRESOURCE(IDR_GAME)), _ASConfig->bFullScreen, GameDraw, GameCheck, NULL, FALSE, TRUE);
			GAME_WINDOW_ID = _AS->GetWindows()-1;
			ASInitOpenGL(&_AS->pWindow[GAME_WINDOW_ID], 
  						 NULL,
						 _AS->pWindow[GAME_WINDOW_ID].GethDC(),
						 _AS->pWindow[GAME_WINDOW_ID].GethRC(), _ASConfig->bFullScreen);
			ShowWindow(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), SW_SHOW);
		break;
	}
}

LRESULT CALLBACK CreditsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin CreditsProc()
    switch(iMessage)
    {
        case WM_INITDIALOG:
				_AS->WriteLogMessage("Open credits dialog");
			    ShowWindow(hWnd, _AS->GetCmdShow());
				UpdateWindow(hWnd);
            	SetDlgItemText(hWnd, IDC_CREDITS_VERSION, _ASProgramInfo.byVersion);
            	SetDlgItemText(hWnd, IDC_CREDITS_BUILD_DATE, _ASProgramInfo.byDate);
            	SetDlgItemText(hWnd, IDC_CREDITS_BUILD_TIME, _ASProgramInfo.byTime);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case IDC_CREDITS_OK:
				OK:
					EndDialog(hWnd, FALSE);
					_AS->WriteLogMessage("Close credits dialog(OK)");
                return TRUE;
            }
        break;

		case WM_CLOSE:
			goto OK;
    }
    return FALSE;
} // end CreditsProc()
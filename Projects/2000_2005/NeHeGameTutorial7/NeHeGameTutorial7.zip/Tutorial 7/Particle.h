//==================================================================//
//==================================================================//
//= Particle.h =====================================================//
//==================================================================//
//= Original coder: Trent Polack (ShiningKnight) ===================//
//==================================================================//

#ifndef Particle_H
#define Particle_H



//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- INCLUDES -------------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//

#include "Shining3D.h"

//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- CONSTANTS ------------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//

/* Particle Engine constants */

	#define MAX_PARTICLES 500

	#define TYPE_BILLBOARD   0
	#define TYPE_MESH	     1
	#define TYPE_ONLY_UPDATE 2

	#define ONLY_CREATE		  0
	#define ONLY_UPDATE		  1
	#define UPDATE_AND_CREATE 2

	#define DEATH_AGE  0.0f

	#define ATTRACTION 0
	#define STOP       1

	#define GET_X 0
	#define GET_Y 1
	#define GET_Z 2

	#define SK_OFF false
	#define SK_ON  true

	#define MIN_SPEED	 0.0f
	#define MIN_SIZE     0.1f
	#define MIN_LIFETIME 0.01f
	#define MIN_SPREAD	 0.01f
	#define MIN_EMISSION 1.0f
	#define MIN_GRAVITY -10.0f
	#define MIN_ALPHA	 0.0f
	#define MIN_COLOR	 0.0f

	#define MAX_SPEED	 300.0f
	#define MAX_SIZE     100.0f
	#define MAX_LIFETIME 20.0f
	#define MAX_SPREAD   180.0f
	#define MAX_EMISSION 1000
	#define MAX_GRAVITY  10.0f
	#define MAX_ALPHA	 1.0f
	#define MAX_COLOR	 1.0f


//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- STRUCTURES -----------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//


//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- CLASSES --------------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//

class PARTICLE;
class PARTICLE_SYSTEM;


//------------------------------------------------------------------//
//- class PARTICLE ------------------------------------------//
//------------------------------------------------------------------//
//- A class that contains all of the information for the Particle  -//
//- Engine.  Defined in Particle.cpp.							   -//
//------------------------------------------------------------------//
class PARTICLE
	{
	private:
		PARTICLE_SYSTEM* Parent;

	public:
		VECTOR3D prevLocation;	//The particle's last position
		VECTOR3D location;		//The particle's current position
		VECTOR3D velocity;		//The particle's current velocity

		unsigned int texture;

		float color[4];			//The particle's color
		float colorCounter[4];	//The color counter!

		float alpha;			//The particle's current transparency
		float alphaCounter;		//Adds/subtracts transparency over time

		float size;				//The particle's current size
		float sizeCounter;		//Adds/subtracts transparency over time

		float age;				//The particle's current age
		float dyingAge;			//The age at which the particle DIES!

	void SetParentSystem(PARTICLE_SYSTEM* parent);
	void Create(PARTICLE_SYSTEM* parent, float timeCounter);
	bool Update(float timeCounter);

	PARTICLE();
	~PARTICLE();
	};



//------------------------------------------------------------------//
//- class PARTICLE_SYSTEM ------------------------------------------//
//------------------------------------------------------------------//
//- A class that contains all of the information for the Particle  -//
//- Engine.  Defined in Particle.cpp.							   -//
//------------------------------------------------------------------//
class PARTICLE_SYSTEM
	{
	private:
		bool attracting;			//Is the system attracting particle towards itself?
		bool stopped;				//Have the particles stopped emitting?

		unsigned int particlesPerSec;	//Particles emitted per second
		unsigned int particlesNumbAlive;//The number of particles currently alive
		
		float age;					//The system's current age (in seconds)
		
		float lastUpdate;			//The last time the system was updated

		float emissionResidue;		//Helps emit very precise amounts of particles


	public:
		PARTICLE particle[MAX_PARTICLES];//All of our particles

		VECTOR3D prevLocation;		//The last known location of the system
		VECTOR3D location;			//The current known position of the system
		VECTOR3D velocity;			//The current known velocity of the system

		unsigned int texture;		//The particle's texture

		float startSize;			//The starting size of the particles
		float sizeCounter;			//Adds/subtracts particle size over time
		float endSize;				//The particle's end size (used for a MAX boundry)

		float startAlpha;			//The starting transparency of the particle
		float alphaCounter;			//Adds/subtracts particle's transparency over time
		float endAlpha;				//The end transparency (used for a MAX boundry)

		VECTOR3D startColor;			//The starting color
		VECTOR3D colorCounter;		//The color that we interpolate over time
		VECTOR3D endColor;			//The ending color

		float speed;				//The system's speed
		float speedCounter;			//The system's speed counter

		float life;					//The system's life (in seconds)
		float lifeCounter;			//The system's life counter

		float angle;				//System's angle (90==1/2 sphere, 180==full sphere)

		int spreadMin;				//Used for random positioning around the emitter
		int spreadMax;
		float spreadFactor;			//Used to divide spread

		VECTOR3D gravity;				//Gravity for the X, Y, and Z axis
		float attractionPercent;

	/* Necessary functions */
	bool Update(float time, int flag, float numToCreate);
	void Render(void);

	
	/* Informational functions */
	unsigned int ActiveParticles(void);
	float GetLocation(int coordinate);
	bool IsAttracting(void)
		{	return attracting;	}
	bool IsStopped(void)
		{	return stopped;	}

	/* Customization functions */
	void SetLocation(float x, float y, float z);
	void SetTexture(unsigned int textureID);
	void SetParticlesPerSec(unsigned int number);
	void SetVelocity(float xv, float yv, float zv);
	void SetSize(float StartSize, float EndSize);
	void SetAlpha(float StartAlpha, float EndAlpha);
	void SetSpeed(float Speed);
	void SetAngle(float halfAngle);
	void SetSystemFlag(int flag, bool state);
	void SetColor(float startRed, float startGreen, float startBlue, float endRed, float endGreen, float endBlue);
	void SetLife(float seconds);
	void SetSpread(int SpreadMin, int SpreadMax, float SpreadFactor);
	void SetAttraction(unsigned int Attraction_Percent);
	void SetGravity(float xpull, float ypull, float zpull);

	PARTICLE_SYSTEM();
	~PARTICLE_SYSTEM();
	};

#endif	//Particle.h
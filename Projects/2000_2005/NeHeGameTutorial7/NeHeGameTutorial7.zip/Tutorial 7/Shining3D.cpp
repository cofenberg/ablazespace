//==================================================================//
//==================================================================//
//= Shining3D.cpp ==================================================//
//==================================================================//
//= Original coder: Trent Polack (ShiningKnight) ===================//
//= Code modifications by: Christian Ofenberg (AblazeSpace) ========//
//==================================================================//
//==================================================================//



//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- INCLUDES -------------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//

#include "Shining3D.h"



//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- GLOBALS --------------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//
HINSTANCE hinstance; //Handle to the window's instance
HWND	  hwnd;		 //Handle to the actual window

UCHAR keyBuffer[256];	//The keyboard's key buffer

LOG S3Dlog;			//The error log


//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- FUNCTION DECLARATIONS ------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//



//------------------------------------------------------------------//
//- bool SHINING3D:: OpenGL_Init(int, int, int, int) ---------------//
//------------------------------------------------------------------//
//- Description: This function takes care of all the necessary	   -//
//-              OpenGL initiation things.  You can provide the    -//
//-              dimensions (width, height, and bits per pixel),   -//
//-              and you can also make it a window, fullscreen or  -//
//-              give the user a choice, using these flags:	       -//
//-                  - FULLSCREEN (Just start with a fullscreen)   -//
//-                  - WINDOW (Just start as a window)             -//
//-                  - GIVE_CHOICE ("Would you like to run in fullscreen mode?") -//
//------------------------------------------------------------------//
bool SHINING3D::
	OpenGLInit(int width, int height, int bpp, int screenflag)
	{
	WNDCLASS winclass;				//The windows class structure
	DEVMODE  dmScreenSettings;		//Device Mode
	GLuint	 PixelFormat;			//Hold the correct match for the pixel format
	DWORD	 dwExStyle;				//Window extended style
	DWORD	 dwStyle;				//Window style
	RECT     winrect;   

	SCREEN_WIDTH =width;			//Set the class's constants to the 
	SCREEN_HEIGHT=height;			//parameter's provided by the 
	SCREEN_BPP   =bpp;				//user.

	winrect.left  =(long)0;			//Upper left  x (x1)
	winrect.top   =(long)0;			//Upper left  y (y1)
	winrect.right =(long)width;		//Lower right x (x2)
	winrect.bottom=(long)height;	//Lower right y (y2)

	hinstance				=GetModuleHandle(NULL);				//Get the window's instance
	winclass.style			=CS_HREDRAW | CS_VREDRAW | CS_OWNDC;//Redraw the window on resize
	winclass.lpfnWndProc	=WindowProc;						//handle the WINPROC messages
	winclass.cbClsExtra		=0;									//No extra win data
	winclass.cbWndExtra		=0;									//No extra win data
	winclass.hInstance		=hinstance;							//Set the window's instance
	winclass.hIcon			=LoadIcon(NULL, IDI_WINLOGO);		//Load the default icon
	winclass.hCursor		=LoadCursor(NULL, IDC_ARROW);		//Load the mouse pointer
	winclass.hbrBackground	=NULL;								//No background required for OpenGL stuff
	winclass.lpszMenuName	=NULL;								//No menu
	winclass.lpszClassName	=CLASSNAME;							//Set the class name

	S3Dlog.Output("Window initiation:");

	if(!RegisterClass(&winclass))		//Register the window class
		{
		S3Dlog.Output("	Could not register window class");
		return false;		
		}

	else
		S3Dlog.Output("	Window class registered");
	
	if(screenflag==GIVE_CHOICE)
		{
		//Ask the user which screen mode they prefer
		if(MessageBox(NULL,"Would you like to run in fullscreen mode?", TITLE, MB_YESNO|MB_ICONQUESTION)==IDNO)
			fullscreen=FULLSCREEN_OFF;					//Windowed mode
		}

	if(FULLSCREEN || fullscreen==FULLSCREEN_ON)			//Attempt fullscreen mode?
		{
		fullscreen=FULLSCREEN_ON;

		memset(&dmScreenSettings,0,sizeof(dmScreenSettings));	// Makes sure memory's cleared
		dmScreenSettings.dmSize=sizeof(dmScreenSettings);		// Size of the devmode structure
		dmScreenSettings.dmPelsWidth	= width;				// Selected screen width
		dmScreenSettings.dmPelsHeight	= height;				// Selected screen height
		dmScreenSettings.dmBitsPerPel	= bpp;					// Selected bits per pixel
		dmScreenSettings.dmFields=DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;

		//Try to set selected mode and get results.  NOTE: CDS_FULLSCREEN Gets Rid Of Start Bar.
		if(ChangeDisplaySettings(&dmScreenSettings,CDS_FULLSCREEN)!=DISP_CHANGE_SUCCESSFUL)
			{
			//If the mode fails, offer 2 options. Quit or use windowed mode.
			if(MessageBox(NULL,"The Requested Fullscreen Mode Is Not Supported By\nYour Video Card. Use Windowed Mode Instead?","NeHe GL",MB_YESNO|MB_ICONEXCLAMATION)==IDYES)
				{
				S3Dlog.Output("Fullscreen mode not supported.");
				fullscreen=FALSE;		//Windowed mode selected. Turn fullscreen flag off
				}
			else
				{
				//Create a message box letting the user know the program is closing.
				MessageBox(NULL,"Program Will Now Close.","ERROR",MB_OK|MB_ICONSTOP);
				return FALSE;
				}
			}
		}

	if(FULLSCREEN || fullscreen==FULLSCREEN_ON)					//Did the user want a fullscreen window?
		{
		dwExStyle=WS_EX_APPWINDOW;								//Window extended style
		dwStyle=WS_POPUP;										//Windows style
		ShowCursor(FALSE);										//Hide the mouse pointer
		}
	else
		{
		fullscreen=FULLSCREEN_OFF;
		dwExStyle=WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;			//Window extended style
		dwStyle=WS_OVERLAPPEDWINDOW;							//Windows style
		}

	//Adjust window to the actual requested size
	AdjustWindowRectEx(&winrect, dwStyle, FALSE, dwExStyle);

	//Create the window
	if(fullscreen)
		{
		if(!(hwnd=CreateWindowEx(dwExStyle,				//The extended style for the window
								 CLASSNAME,				//The class name
								 TITLE,					//The window's title
								 WS_SYSMENU | WS_BORDER | 
								 WS_CAPTION | WS_VISIBLE,		 
								 0, 0,					//The window's position
								 winrect.right -winrect.left,	//Calculate the window's width
								 winrect.bottom-winrect.top,	//Calculate the window's height
								 NULL,					//No parent window
								 NULL,					//No menu needed
								 hinstance,				//The window's instance
								 NULL)))				//Nothing to pass to WM_CREATE
			{
			//If the window could not be created
			OpenGLShutdown();						//Kill the window				
			S3Dlog.Output("	Window could not be created.");
			return false;			
			}
		}
	else
		{
		if(!(hwnd=CreateWindowEx(dwExStyle,				//The extended style for the window
								 CLASSNAME,				//The class name
								 TITLE,					//The window's title
								 WS_POPUP | WS_VISIBLE, //No minimize/maximize commands
								 0, 0,					//The window's position
								 winrect.right -winrect.left,//Calculate the window's width
								 winrect.bottom-winrect.top,//Calculate the window's height
								 NULL,					//No parent window
								 NULL,					//No menu needed
								 hinstance,				//The window's instance
								 NULL)))				//Nothing to pass to WM_CREATE
			{
			//If the window could not be created
			OpenGLShutdown();						//Kill the window				
			S3Dlog.Output("	Window could not be created.");
			return false;			
			}
		}

	static PIXELFORMATDESCRIPTOR pfd=	//Get the pixel format's description
		{
		sizeof(PIXELFORMATDESCRIPTOR),	//Get the size of the structure
		1,								//Version number
		PFD_DRAW_TO_WINDOW |			//Format must support Windows
		PFD_SUPPORT_OPENGL |			//Format must support OpenGL
		PFD_DOUBLEBUFFER,				//Must support Double Buffering
		PFD_TYPE_RGBA,					//Request a RGBA (red,green,blue,alpha) format
		bpp,							//Select the bits per pixel
		0, 0, 0, 0, 0, 0,				//Color bits ignored
		0,								//No alpha buffer
		0,								//shift bit ignored
		0,								//No accumulation buffer (advanced)
		0, 0, 0, 0,						//Accumulation bits ignored
		16,								//16 bit Z-Buffer (Depth Buffer)  
		0,								//No Stencil Buffer (advanced)
		0,								//No Auxiliary Buffer (advanced)
		PFD_MAIN_PLANE,					//The main drawing layer
		0,								//Reserved area
		0, 0, 0							//Layer masks ignored
		};
	
	//Could the device context be "grabbed?"
	if(!(hdc=GetDC(hwnd)))
		{
		OpenGLShutdown();				//Kill the window
		S3Dlog.Output("	Could not create a GL device context");
		return false;								
		}
	else
		S3Dlog.Output("	OpenGL Device Context created.");

	//Did Windows find a matching pixel format?
	if(!(PixelFormat=ChoosePixelFormat(hdc,&pfd)))
		{
		OpenGLShutdown();				//Kill the window
		S3Dlog.Output("	Could not find a suitable pixel format");
		return false;						
		}
	else
		S3Dlog.Output("	Found suitable pixel format");

	//Could the pixel format be set?
	if(!SetPixelFormat(hdc,PixelFormat,&pfd))
		{
		OpenGLShutdown();				//Kill the window
		S3Dlog.Output("	Could not set pixel format");
		return false;						
		}
	else
		S3Dlog.Output("	Set pixel format.");
	
	//Could a rendering context be "grabbed?"
	if(!(hrc=wglCreateContext(hdc)))
		{
		OpenGLShutdown();				//Kill the window
		S3Dlog.Output("	Could not create an OpenGL Rendering Context");
		return false;		
		}
	else
		S3Dlog.Output("	Created a OpenGL Rendering Context.");

	//Could the rendering context be activated?
	if(!wglMakeCurrent(hdc,hrc))
		{
		OpenGLShutdown();				//Kill the Window
		S3Dlog.Output("	Could not activate an OpenGL Rendering Context");
		return false;			
		}
	else
		S3Dlog.Output("	Activated an OpenGL Rendering Context");

	glEnable(GL_TEXTURE_2D);							//Enable two dimensional texture mapping
	glShadeModel(GL_SMOOTH);							//Enable smooth shading (so you can't see the individual polygons of a primitive, best shown when drawing a sphere)
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);				//Completely black background
	glClearDepth(1.0);									//Depth buffer setup
	glEnable(GL_DEPTH_TEST);							//Enable depth testing
	glDepthFunc(GL_LEQUAL);								//The type of depth testing to do (LEQUAL==less than or equal to)
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	//The nicest perspective look

	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);					//Full brightness.
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);					//Set the blending function for transparency

	ShowWindow(hwnd,SW_SHOW);			//Show the window
	SetForegroundWindow(hwnd);			//Give the window a high priority
	SetFocus(hwnd);						//Sets the keyboard's focus to the window
	ResizeGLScene(width, height);		//Set up the OpenGL perspective view

	return true;
	}

//------------------------------------------------------------------//
//- bool SHINING3D:: OpenGL_Shutdown(void) -------------------------//
//------------------------------------------------------------------//
//- Description: This function takes care of all the necessary     -//
//-              OpenGL shutdown precautions.					   -//
//------------------------------------------------------------------//
void SHINING3D::
	OpenGLShutdown(void)
	{
	if(fullscreen==FULLSCREEN_ON)			//Are we in fullscreen mode?
		{
		ChangeDisplaySettings(NULL,0);		//If so switch back to the desktop
		ShowCursor(TRUE);					//Show mouse pointer
		}

	S3Dlog.Output("Shutdown:");	

	if(hrc)			//Tru to release rendring context and device context
		{
		if(!wglMakeCurrent(NULL,NULL))	
			S3Dlog.Output("	Could not release RC and DC.");
		else
			S3Dlog.Output("	Released RC and DC.");

		if(!wglDeleteContext(hrc))		
			S3Dlog.Output("	Could not release rendering context.");
		else
			S3Dlog.Output("	Released rendering context.");
		
		hrc=NULL;		
		}

	if(hdc && !ReleaseDC(hwnd,hdc))	//Release the device context
		{
		S3Dlog.Output("	Could not release the graphics device context.");
		hdc=NULL;				
		}
	else
		S3Dlog.Output("	Released the Graphics Device Context.");

	if(hwnd && !DestroyWindow(hwnd))	//Release the main window handle
		{
		S3Dlog.Output("	Could not release main window handle.");
		hwnd=NULL;					
		}
	else
		S3Dlog.Output("	Released Main Window Handle.");

	if(!UnregisterClass(CLASSNAME,hinstance))	//Unregister the window's class
		{
		S3Dlog.Output("	Could not unregister window class.");	
		hinstance=NULL;			
		}
	else
		S3Dlog.Output("	Unregistered window class.");
	}

//------------------------------------------------------------------//
//- GLvoid SHINING3D:: Resize_GLScene(GLsizei, GLsizei) ------------//
//------------------------------------------------------------------//
//- Description: This function resizes the OpenGL SCENE (not the   -//
//-              window) so that the same proportions in the scene -//
//-              are the same.									   -//
//------------------------------------------------------------------//
GLvoid ResizeGLScene(GLsizei width, GLsizei height)
	{
	if(height==0)										//Prevent a divide by zero (bad)
		height=1;										//Making height equal one

	glViewport(0,0,width,height);						//Reset the current viewport

	glMatrixMode(GL_PROJECTION);						//Select the projection matrix
	glLoadIdentity();									//Reset the projection matrix

	//Calculate the aspect ratio of the window
	gluPerspective(45.0f,(GLfloat)width/(GLfloat)height,1.0f,10000.0f);

	glMatrixMode(GL_MODELVIEW);							//Select the modelview matrix
	glLoadIdentity();									//Reset The modelview matrix
	}

//------------------------------------------------------------------//
//- void SHINING3D:: HandleMessages(void) --------------------------//
//------------------------------------------------------------------//
//- Description: This function handles all of the necessary        -//
//-              messages that your window will recieve. This      -//
//-              function is more of a 'space-saver' for to reduce -//
//-              the amount of stuff you have to look through in   -//
//-              your console.									   -//
//------------------------------------------------------------------//
bool SHINING3D::
	HandleMessages(void)
	{
	MSG msg;

	//These are functions that are needed to process the messages
	//that the window is recieving.
	while(PeekMessage(&msg,NULL,0,0,PM_REMOVE))
		{ 
	    TranslateMessage(&msg);
	    DispatchMessage(&msg); 

		if(msg.message==WM_QUIT)
			return false;
		}
	return true;
	}

//------------------------------------------------------------------//
//- LRESULT CALLBACK WindowProc(HWND, UINT, WPARAM, LPARAM) --------//
//------------------------------------------------------------------//
//- Description: This function handles all of the specific messages-//
//-              that the window will be recieving throughout it's -//
//-              life.											   -//
//------------------------------------------------------------------//
LRESULT CALLBACK WindowProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
	{
	switch(msg)
		{	
		case WM_DESTROY:		//If the user is pressing esc, then quit
			PostQuitMessage(0);
			return false;
			break;
	
		case WM_SYSCOMMAND:
			switch(lparam)
				{
				case SC_SCREENSAVE:		//Is the computer trying to get a screen saver going?
				case SC_MONITORPOWER:	//Does the computer want to go to sleep? (I know I do :) )
				default: break;
				}
			break;

		case WM_CLOSE:				//Does the user want to close?
			PostQuitMessage(0);		//Send a quit message to windows
			return false;
			break;

		case WM_SIZE:				//Resize the OpenGL window (and then resize the current scene to fit
			ResizeGLScene(LOWORD(lparam),HIWORD(lparam));  // LOWORD=width, HIWORD=height
			return false;
			break;

		default:break; 
		} 

	return DefWindowProc(hwnd, msg, wparam, lparam);
	}


//------------------------------------------------------------------//
//- GLvoid SHINING3D::Font_Init(GLvoid) ----------------------------//
//------------------------------------------------------------------//
//- Description: This function initiates the font engine. Just put -//
//-              a call to this function in the initiation part of -//
//-              your program.									   -//
//------------------------------------------------------------------//
GLvoid SHINING3D::
	FontInit(GLvoid)	
	{
	float cx=0;
	float cy=0;
	int loop;

	font.LoadTGA("Art/font.tga", GL_LINEAR, GL_LINEAR);

	base=glGenLists(95);						//Creating a display list that can hold 95
	glBindTexture(GL_TEXTURE_2D, font.ID);	//Bind our font texture
	for(loop=0; loop<95; loop++)				//Loop through the display list
		{
		cx=float(loop%16)/16.0f;				//X position of current character
		cy=float(loop/16)/8.0f;					//Y position of current character

		glNewList(base+loop,GL_COMPILE);		//Start building a list
			glBegin(GL_TRIANGLE_STRIP);			//Use a quad for each character
				//Top right (tex/vertex) coordinates
				glTexCoord2f( (cx+0.0830f), (1.0f-cy));		
				glVertex2i(16,16);
				//Top left (tex/vertex) coordinates
				glTexCoord2f( (cx),			(1.0f-cy));	
				glVertex2i(0,16);
				//Bottom right (tex/vertex) coordinates
				glTexCoord2f( (cx+0.0830f), (1.0f-cy-0.120f)); 
				glVertex2i(16,0);
				//Bottom left (tex/vertex) coordinates
				glTexCoord2f( (cx),			(1.0f-cy-0.120f)); 
				glVertex2i(0,0);
			glEnd();							//Done Building Our Quad (Character)
			glTranslated(10,0,0);				//Move To The Right Of The Character
		glEndList();							//Done Building The Display List
		}															// Loop Until All 256 Are Built
	}


//------------------------------------------------------------------//
//- GLvoid SHINING3D:: Font_Shutdown(GLvoid) -----------------------//
//------------------------------------------------------------------//
//- Description: This function shuts down the font engine.  Put a  -//
//-              call to this in the shutdown part of your program.-//
//------------------------------------------------------------------//
GLvoid SHINING3D::
	FontShutdown(GLvoid)		
	{ glDeleteLists(base, 96); }

//------------------------------------------------------------------//
//- GLvoid SHINING3D::glPrint(GLint, GLint, const char*, ...) ------//
//------------------------------------------------------------------//
//- Description: This function prints a string of text onto the    -//
//-				 the screen.  You *must* be in ortho view to use   -//
//-              this function, but thats not a bad thing, it makes-//
//-              positioning the text easier.  Also, this function -//
//-              functions (hehehe) almost exactly like printf(...)-//
//-              in dos.										   -//
//------------------------------------------------------------------//
GLvoid SHINING3D::
	glPrint(GLint x, GLint y, const char *string, ...)
	{
	char		text[256];								//Holds Our String
	va_list		va;										//Pointer To List Of Arguments

	if(string==NULL)									//If There's No Text
		return;											//Do Nothing

	va_start(va, string);								//Parses The String For Variables
	    vsprintf(text, string, va);						//And Converts Symbols To Actual Numbers
	va_end(va);											//Results Are Stored In Text

	glBindTexture(GL_TEXTURE_2D, font.ID);				//Select Our Font Texture
	glPushMatrix();										//Store The Modelview Matrix
	glLoadIdentity();									//Reset The Modelview Matrix
	glTranslated(x,y,0);								//Position The Text (0,0 - Bottom Left)
	glListBase(base-32);								//Choose The Font Set
	glCallLists(strlen(text), GL_UNSIGNED_BYTE, text);	//Draws The Display List Text
	glPopMatrix();										//Restore The Old Projection Matrix
	}


//------------------------------------------------------------------//
//- GLvoid LOG::Init() ---------------------------------------------//
//------------------------------------------------------------------//
//- Description: Don't even bother using this function at all, it  -//
//-              initiates the output log, but I put this function -//
//-              in the log's constructor, so it's automatically   -//
//-              called.										   -//
//------------------------------------------------------------------//
bool LOG::
	Init(void)	
	{
	//Clear the log contents
	if((logfile=fopen("Shining3D Log.txt", "wb"))==NULL)
		return false;

	//Close the file, and return a success!
	fclose(logfile);
	return true;
	}
//------------------------------------------------------------------//
//- GLvoid LOG::Init() ---------------------------------------------//
//------------------------------------------------------------------//
//- Description: Don't even bother using this function at all, it  -//
//-              shuts down the output log, but I put this function-//
//-              in the log's destructor, so it's automatically    -//
//-              called.										   -//
//------------------------------------------------------------------//
bool LOG::
	Shutdown(void)
	{
	if(logfile)
		fclose(logfile);

	return true;
	}

//------------------------------------------------------------------//
//- GLvoid LOG::Output() -------------------------------------------//
//------------------------------------------------------------------//
//- Description: This function outputs text the error log, the     -//
//-              function functions (I won't even say "hehehe" this-//
//-              time) exactly like printf(...).				   -//
//------------------------------------------------------------------//
bool LOG::
	Output(char* text, ...)
	{
	va_list arg_list;

	//Initialize variable argument list
	va_start(arg_list, text);

	//Open the log file for append
	if((logfile = fopen("Shining3D Log.txt", "a+"))==NULL)
		return false;

	//Write the text and a newline
	vfprintf(logfile, text, arg_list);
	putc('\n', logfile);

	//Close the file
	fclose(logfile);
	va_end(arg_list);

	return true;
	}

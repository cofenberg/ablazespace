//==================================================================//
//==================================================================//
//= Math.h =========================================================//
//==================================================================//
//= Original coder: Trent Polack (ShiningKnight) ===================//
//= Code modifications by: Christian Ofenberg (AblazeSpace) ========//
//==================================================================//

#ifndef Math_H
#define Math_H


//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- INCLUDES -------------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//
#include "Shining3D.h"

//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- CONSTANTS ------------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//
#define EPSILON 1e-12
#define PI		   3.1415926535897932384626433832795f
#define PId2          1.5707963279489
#define PIOVER180  0.0174532925199432957692369076848861f
#define PIUNDER180 57.2957795130823208767981548141052f
enum {X, Y, Z};
enum {HEADING, PITCH, ROLL};

//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- MACROS ---------------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//
//Andr�'s macros. Thanks a lot.  
#define MIN(a, b)  (((a) < (b)) ? (a) : (b))
#define MAX(a, b)  (((a) > (b)) ? (b) : (a))

#define SWAP(a, b) { float f = a; a = b; b = f; }
#define RANDOM_FLOAT (((float)rand()-(float)rand())/RAND_MAX)
#define CHECK_RANGE(x,min,max) ((x= (x<min  ? min : x<max ? x : max)))
#define DEG_TO_RAD(angle)  ((angle)*PIOVER180)
#define RAD_TO_DEG(radians) ((radians)*PIUNDER180)
#define SQUARE(number) (number*number)


//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- STRUCTURES -----------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//


//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- CLASSES --------------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//

//------------------------------------------------------------------//
//- class VECTOR2D -------------------------------------------------//
//------------------------------------------------------------------//
//- A class for all two dimensional vectors. This will have some   -//
//- very nice features so that we can add/multiply/subtract/divide -//
//- vectors together now! (Also used for vertices)				   -//
//------------------------------------------------------------------//
typedef class VECTOR2D
	{
	public:
		union
			{
			float v[2];
			struct
				{
				float x, y;
				};
			};

		//Constructor
		VECTOR2D(void) { x = y = 0.0f; }
		VECTOR2D(float xT, float yT) { x = xT, y = yT; }
		VECTOR2D(const float *vT) { *this = vT; }
		VECTOR2D(const VECTOR2D &vT) { *this = vT; }

		//Assignment operators
		VECTOR2D &operator=(const float *vT)
			{
			x = *vT++, y = *vT;
			return  *this;
			}
		VECTOR2D &operator=(const VECTOR2D &vT)
			{
			x = vT.x, y = vT.y;
			return *this;
			}
		VECTOR2D &operator=(const float f)
			{
			x = y = f;
			return *this;
			}

		//Comparison
		bool operator==(const VECTOR2D vT)
			{ return x == vT.x && y == vT.y; }
		bool operator!=(const VECTOR2D vT)
			{ return !(*this == vT); }

		//Vector
	    VECTOR2D operator - ()
			{ return VECTOR2D(-x, -y); }
		VECTOR2D &operator+=(const VECTOR2D vT)
			{
			x += vT.x, y += vT.y;
			return *this;
			}
		VECTOR2D operator+(const VECTOR2D vT)
			{ return VECTOR2D(x+vT.x, y+vT.y); }
		VECTOR2D &operator+=(const float f)
			{
			x += f, y += f;
			return *this;
			}
		VECTOR2D operator+(const float f)
			{ return VECTOR2D(x+f, y+f); }
		VECTOR2D &operator-=(const VECTOR2D vT)
			{
			x -= vT.x, y -= vT.y;
			return *this;
			}
		VECTOR2D operator-(const VECTOR2D vT)
			{ return VECTOR2D(x-vT.x, y-vT.y); }
		VECTOR2D &operator-=(const float f)
			{
			x -= f, y -= f;
			return *this;
			}
		VECTOR2D operator-(const float f)
			{ return VECTOR2D(x-f, y-f); }
		VECTOR2D &operator*=(const VECTOR2D vT)
			{
			x *= vT.x, y *= vT.y;
			return *this;
			}
		VECTOR2D operator*(const VECTOR2D vT)
			{ return VECTOR2D(x*vT.x, y*vT.y); }
		VECTOR2D &operator/=(const VECTOR2D vT)
			{
			x /= vT.x, y /= vT.y;
			return *this;
			}
		VECTOR2D operator/(const VECTOR2D vT)
			{ return VECTOR2D(x/vT.x, y/vT.y); }

		//Scalar
		VECTOR2D &operator*=(float f)
			{
			x *= f, y *= f;
			return *this;
			}
		VECTOR2D operator*(float f)
			{ return VECTOR2D(x*f, y*f); }
		VECTOR2D &operator/=(float f)
			{
			x /= f, y /= f;
			return *this;
			}
		VECTOR2D operator/(float f)
			{ return VECTOR2D(x/f, y/f); }

		//Stuff
		float GetLength(void) { return (float) sqrt(x*x+y*y); }
		void SetLength(float f) { *this *= f/GetLength(); }

		VECTOR2D &Normalize(void)
			{
			float f = x*x+y*y;
			if(fabs(f-1.0f) < EPSILON)
				return *this;
			f = 1.0f/(float) sqrt(f);
			*this *= f;
			return *this;
			}

		VECTOR2D GetNormalized(void)
			{ return VECTOR2D(*this).Normalize(); }

		float DotProduct(void) { return x*x+y*y; }
		float DotProduct(const VECTOR2D vT) { return x*vT.x+y*vT.y; }

		void SendToOGL(void)
			{ glVertex2fv(v);}

		// Misc:
		bool IsNull(void)
			{
			if(!x && !y)
				return true;
			return false;
			}

} VECTOR2D;

//------------------------------------------------------------------//
//- class VECTOR3D -------------------------------------------------//
//------------------------------------------------------------------//
//- A class for all three dimensional vectors. This will have some -//
//- very nice features so that we can add/multiply/subtract/divide -//
//- vectors together now! (Also used for vertices)				   -//
//------------------------------------------------------------------//
typedef class VECTOR3D
	{
	public:
		union
			{
			float v[3];
			struct
				{
				float x, y, z;
				};
			struct
				{
				float heading, pitch, roll;
				};
			};

		//Constructor
		VECTOR3D(void) { x = y = z = 0.0f; }
		VECTOR3D(float xT, float yT, float zT)
			{ x = xT, y = yT, z = zT; }
		VECTOR3D(const float *vT) { *this = vT; }
		VECTOR3D(const VECTOR3D &vT) { *this = vT; }

		//Assignment operators
		VECTOR3D &operator=(const VECTOR3D &vT)
			{
			x = vT.x, y = vT.y, z = vT.z;
			return *this;
			}
		VECTOR3D &operator=(const float *vT)
			{
			x = *vT++, y = *vT++, z = *vT;
			return *this;
			}
		VECTOR3D &operator=(const float f)
			{
			x = y = z = f;
			return *this;
			}

		//Comparison
		bool operator==(const VECTOR3D &vT)
			{ return x == vT.x && y == vT.y && z == vT.z; }
		bool operator!=(const VECTOR3D vT)
			{ return !(*this == vT); }

		// Vector:
	    VECTOR3D operator - ()
			{ return VECTOR3D(-x, -y, -z); }
		VECTOR3D &operator+=(const VECTOR3D vT)
			{
			x += vT.x, y += vT.y, z += vT.z;
			return *this;
			}
		VECTOR3D operator+(const VECTOR3D vT)
			{ return VECTOR3D(x+vT.x, y+vT.y, z+vT.z); }
		VECTOR3D &operator+=(const float f)
			{
			x += f, y += f, z += f;
			return *this;
			}
		VECTOR3D operator+(const float f)
			{ return VECTOR3D(x+f, y+f, z+f); }
		VECTOR3D &operator-=(const VECTOR3D vT)
			{
			x -= vT.x, y -= vT.y, z -= vT.z;
			return *this;
			}
		VECTOR3D operator-(const VECTOR3D vT)
			{ return VECTOR3D(x-vT.x, y-vT.y, z-vT.z); }
		VECTOR3D &operator-=(const float f)
			{
			x -= f, y -= f, z -= f;
			return *this;
			}
		VECTOR3D operator-(const float f)
			{ return VECTOR3D(x-f, y-f, z-f); }
		VECTOR3D &operator*=(const VECTOR3D vT)
			{
			x *= vT.x, y *= vT.y, z *= vT.z;
			return *this;
			}
		VECTOR3D operator*(const VECTOR3D vT)
			{ return VECTOR3D(x*vT.x, y*vT.y, z*vT.z); }
		VECTOR3D &operator/=(const VECTOR3D vT)
			{
			x /= vT.x, y /= vT.y, z /= vT.z;
			return *this;
			}
		VECTOR3D operator/(const VECTOR3D vT)
			{ return VECTOR3D(x/vT.x, y/vT.y, z/vT.z); }

		//Scalar
		VECTOR3D &operator*=(float f)
			{
			x *= f, y *= f, z *= f;
			return *this;
			}
		VECTOR3D operator*(float f)
			{ return VECTOR3D(x*f, y*f, z*f); }
		VECTOR3D &operator/=(float f)
			{
			*this*=1.0f/f;
			return *this;
			}
		VECTOR3D operator/(float f)
			{ return operator*(1.0f/f); }

		//Stuff
		float GetLength(void) { return (float) sqrt(x*x+y*y+z*z); }
		void SetLength(float f) { *this *= f/GetLength(); }

		VECTOR3D &Normalize(void)
			{
			float f = x*x+y*y+z*z;
			if(fabs(f-1.0f) < EPSILON)
				return *this;
			f = 1.0f/(float) sqrt(f);
			*this *= f;
			return *this;
			}

		VECTOR3D GetNormalized(void)
			{ return VECTOR3D(*this).Normalize(); }

		VECTOR3D CrossProduct(const VECTOR3D vT)
			{
			return VECTOR3D((y*vT.z)-(z*vT.y),
							(z*vT.x)-(x*vT.z),
							(x*vT.y)-(y*vT.x));
			}
		float AngleBetween(VECTOR3D vT)
			{ return (DotProduct(vT)/(GetLength()*vT.GetLength())); }

		float DotProduct(void) { return x*x+y*y+z*z; }
		float DotProduct(const VECTOR3D vT) { return x*vT.x+y*vT.y+z*vT.z; }

		void SendToOGL(void)
			{ glVertex3fv(v);}

		// Misc:
		bool IsNull(void)
			{
			if(!x && !y && !z)
				return true;
			return false;
			}

	} VECTOR3D;


//------------------------------------------------------------------//
//- class MATRIX4X4 ------------------------------------------------//
//------------------------------------------------------------------//
//- A class for 4x4 matrices.									   -//
//------------------------------------------------------------------//
typedef class MATRIX4X4
	{
	public:
		union
			{
			float m[16];
			struct
				{
				float xx, xy, xz, xw;
				float yx, yy, yz, yw;
				float zx, zy, zz, zw;
				float wx, wy, wz, ww;
				};
			struct
				{
				float m44[4][4];
				};
			};

		//Constructor
		MATRIX4X4(void) { LoadIdentity(); }
		MATRIX4X4(const float *f)	{ *this = f; }
		MATRIX4X4(const MATRIX4X4 &mT) { *this = mT; }

		//Assignment operators
		MATRIX4X4 &operator=(const MATRIX4X4 mT)
			{
			xx = mT.xx, xy = mT.xy, xz = mT.xz, xw = mT.xw;
			yx = mT.yx, yy = mT.yy, yz = mT.yz, yw = mT.yw;
			zx = mT.zx, zy = mT.zy, zz = mT.zz, zw = mT.zw;
			wx = mT.wx, wy = mT.wy, wz = mT.wz, ww = mT.ww;
			return *this;
			}

		//Misc
		void LoadIdentity(void)
			{
			xx = 1.0f, xy = 0.0f, xz = 0.0f, xw = 0.0f;
			yx = 0.0f, yy = 1.0f, yz = 0.0f, yw = 0.0f;
			zx = 0.0f, zy = 0.0f, zz = 1.0f, zw = 0.0f;
			wx = 0.0f, wy = 0.0f, wz = 0.0f, ww = 1.0f;
			}

		void XRot(const float angle)
			{
    		const float c = (float) cos(angle);
			const float s = (float) sin(angle);

			yy = c;
			yz = s;
			zy = -s;
			zz = c;
			}

		void YRot(const float angle)
			{
    		const float c = (float) cos(angle);
			const float s = (float) sin(angle);

			xx = c;
			xz = -s;
			zx = s;
			zz = c;
			}

		void ZRot(const float angle)
			{
    		const float c = (float) cos(angle);
			const float s = (float) sin(angle);

			xx = c;
			xy = s;
			yx = -s;
			yy = c;
			}

		void Scale(const float xT, const float yT, const float zT)
			{
    		xx = xT;
			yy = yT;
			zz = zT;
			}
		void Scale(const VECTOR3D vT) { Scale(vT.x, vT.y, vT.z); }
		void Scale(const float *vT) { Scale(*vT++, *vT++, *vT); }

		void Translate(const float xT, const float yT, const float zT)
			{
			wx += xx*xT + yx*yT + zx*zT;
			wy += xy*xT + yy*yT + zy*zT;
			wz += xz*xT + yz*yT + zz*zT;
			ww += xw*xT + yw*yT + zw*zT;
			}
		void Translate(const VECTOR3D vT) { Translate(vT.x, vT.y, vT.z); }
		void Translate(const float *vT) { Translate(*vT++, *vT++, *vT); }

		MATRIX4X4 operator*(const MATRIX4X4);
		void operator*=(const MATRIX4X4 mT)
			{ *this = *this*mT; }
		inline VECTOR3D operator*(const VECTOR3D);

		inline void Transpose(void);
		MATRIX4X4 Invert(void);
		VECTOR3D Transform(const VECTOR3D);
		void GetEulerAngles(float &, float &, float &);

	} MATRIX4X4;      


typedef class QUATERNION
	{
	public:
		union
			{
			float q[4];
			struct
				{
				float w, x, y, z;
				};
			};

		//Constructor
		QUATERNION(void);
		QUATERNION(const QUATERNION &);
		QUATERNION(float, float, float);
		QUATERNION(float, float, float, float);
		
		//Misc
		QUATERNION &Reset(void);
		QUATERNION &Set(const QUATERNION &);
		QUATERNION &Set(float, float, float);
		QUATERNION &Set(float, float, float, float);
		QUATERNION &PostMult(const QUATERNION &);
		QUATERNION &MultAndSet(const QUATERNION &, const QUATERNION &);
		QUATERNION &Normalize(void);
		QUATERNION Inversed(void);
		float DotProduct(void);
		float DotProduct(QUATERNION);
		float GetLength(void);
		void GetMatrix(MATRIX4X4 *);
		void GetInvertedMatrix(MATRIX4X4 *);
		void SetMatrix(MATRIX4X4);
		void GetAxisAngle(float &, float &, float &, float &);
		void GetDirectionVector(VECTOR3D *);
		void EulerToQuat(const float, const float, const float);
		void GetEulerAngles(float &, float &, float &);
		void Slerp(const QUATERNION, const QUATERNION, const float);
		void SquadSlerp(QUATERNION, QUATERNION, QUATERNION, QUATERNION, float);
		void Invert(void);
		void Mult(QUATERNION, QUATERNION);
		void Ln(void);
		void LnDif(QUATERNION, QUATERNION);
		void Exp(void);
		void InnerPoint(QUATERNION, QUATERNION, QUATERNION);

	} QUATERNION;


//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- FUNCTION DECLARATIONS ------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//
extern int Random(GLint, GLint);
extern void	ComputeNormal(VECTOR3D, VECTOR3D, VECTOR3D);


#endif	//Math.h
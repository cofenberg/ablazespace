//==================================================================//
//==================================================================//
//= DirectInput.cpp ================================================//
//==================================================================//
//= Original coder: Trent Polack (ShiningKnight) ===================//
//==================================================================//
//==================================================================//

#include "Shining3D.h"


//------------------------------------------------------------------//
//- bool DInput_Init(void) -----------------------------------------//
//------------------------------------------------------------------//
//- Description: Initiates DirectInput (with the keyboard).  Will  -//
//-              return true if everything goes ok, and false if   -//
//-              something goes wrong.							   -//
//------------------------------------------------------------------//
SHININGINPUT::
	SHININGINPUT()
	{	memset(&keyBuffer, 0, sizeof(unsigned char[256]));	}

SHININGINPUT::
	~SHININGINPUT()
	{	}

bool SHININGINPUT::
	DInputInit(void)
	{
	HRESULT hr;	//DirectX result variable

	S3Dlog.Output("DirectInput initiation:");

	//Create the main DirectInput object
	hr= (DirectInput8Create(hinstance, DIRECTINPUT_VERSION,
						   IID_IDirectInput8, (void**)&lpdi, NULL));
	if(FAILED(hr))
		{
		MessageBox(hwnd, "Could not create main DInput object", TITLE, MB_OK);
		S3Dlog.Output("	Could not create main DInput object");
		return false;
		}

	//Create the keyboard's device object
	hr= (lpdi->CreateDevice(GUID_SysKeyboard, &lpdiKeyboard, NULL));
	if(FAILED(hr))
		{
		MessageBox(hwnd, "Could not create keyboard's object",TITLE,MB_OK);
		S3Dlog.Output("	Could not create main keyboard's object");
		DInputShutdown();
		return false;
		}

	//Set the keyboard's data format 
	hr= (lpdiKeyboard->SetDataFormat(&c_dfDIKeyboard));
	if(FAILED(hr))
		{
		MessageBox(hwnd, "Could not set keyboard's data format",TITLE,MB_OK);
		S3Dlog.Output("	Could not set keyboard's data format");
		DInputShutdown();
		return false;
		}

	//Set the keyboard's cooperation level with your computer's
	//environment.
	hr= (lpdiKeyboard->SetCooperativeLevel(hwnd, DISCL_BACKGROUND |
												  DISCL_NONEXCLUSIVE));
	if(FAILED(hr))
		{
		MessageBox(hwnd, "Could not set keyboard's cooperation level",
				   TITLE, MB_OK);
		S3Dlog.Output("	Could not set keyboard's cooperation level");
		DInputShutdown();
		return false;
		}

	//And finally, acquire the keyboard for use.
	lpdiKeyboard->Acquire();

	S3Dlog.Output("	Everything went A-OK!");

	return true;
	}
	
	
//------------------------------------------------------------------//
//- bool DInput_Shutdown(void) -------------------------------------//
//------------------------------------------------------------------//
//- Description: This function shuts down DirectInput.  This       -//
//-              function is automatically called if there is an   -//
//-              error in the initiation sequence, but if there was-//
//-              no error, you will need to call it from your      -//
//-              shutdown function.								   -//
//------------------------------------------------------------------//	
void SHININGINPUT::
	DInputShutdown(void)
	{
	//First, since we create the keyboard last, we need to 'destroy'
	//it first.
	if(lpdiKeyboard!=NULL)
		{
		//Unacquire the keyboard
		lpdiKeyboard->Unacquire();
		
		//Let the keyboard go faster than your ex-girlfriend's phone number
		lpdiKeyboard->Release();
		lpdiKeyboard=NULL;
		}
	
	//Now the main DirectInput object
	if(lpdi!=NULL)
		{
		//Kill, burn, and destroy the main object
		lpdi->Release();
		lpdi=NULL;
		}

	S3Dlog.Output("DirectInput shutdown:");
	S3Dlog.Output("	Everything has been shut down");
	}


//------------------------------------------------------------------//
//- bool DInput_Update(void) ---------------------------------------//
//------------------------------------------------------------------//
//- Description: This function updates DirectInput to make sure    -//
//-              that your program still has access to the keyboard-//
//-              and if it doesn't, the function tries to reacquire-//
//-              it.  If not, the function calls DInput_Shutdown().-//
//------------------------------------------------------------------//
void SHININGINPUT::
	DInputUpdate(void)
	{
	HRESULT hr;
	
	//First, check to see if the keyboard is still working/functioning
    hr= (lpdiKeyboard->GetDeviceState(sizeof(UCHAR[256]),(LPVOID)&keyBuffer));
    if(FAILED(hr))
		{ 
        if(hr==DIERR_INPUTLOST) 
			{
			//Try to re-acquire the keyboard
			hr= (lpdiKeyboard->Acquire());
			if(FAILED(hr))
				{
				MessageBox(hwnd, "Keyboard has been lost", TITLE, MB_OK);
				S3Dlog.Output("Keyboard has been lost");
				DInputShutdown();
				}
			}
		}
	}
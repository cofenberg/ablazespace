//==================================================================//
//==================================================================//
//= Tutorial x.cpp =================================================//
//==================================================================//
//= Original coder: Trent Polack (ShiningKnight) ===================//
//= Code modifications by: Christian Ofenberg (AblazeSpace) ========//
//==================================================================//
//==================================================================//


//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- INCLUDES -------------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//
#include "Shining3D.h"
#include "Particle.h"


//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- CONSTANTS ------------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//
#define RENDER_WIRE				0
#define RENDER_ANTIALIASED_WIRE 1
#define RENDER_POINT			2
#define RENDER_TEX				3


//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- STRUCTURES -----------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//


//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- GLOBALS --------------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//
SHINING3D s3d; //The Shining3D engine
SHININGINPUT sinput; //To handle the input

DWORD deltaTime = 0L; //Change in time since last iteration

TEXTURE flare;

TEXTURE asteroidBeltTexture; //The asteroid belt texture
GLint asteroidBeltList; //The asteroid beld list (sky cube)

TEXTURE radarTexture; //The radar texture

TEXTURE asteroidTexture; //The asteroid texture
GLint asteroidList; //The asteroid list

RECT window;

int render_mode = RENDER_TEX; //The current render mode


//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- MACROS ---------------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//


//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- FUNCTION DECLARATIONS ------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//
extern bool Game_Draw(void);
extern bool Game_Check(void);
extern bool Game_InitOther(void);


bool Game_Init(void);
bool Game_Main(void);
bool Game_Shutdown(void);
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow);


//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- FUNCTION DEFINITIONS -------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//


//------------------------------------------------------------------//
//- bool Game_Init(void) -------------------------------------------//
//------------------------------------------------------------------//
//- Description: This function does all the necesary initiation    -//
//-              that you want done in your game.  It is called    -//
//-              once, and only once.                              -//
//------------------------------------------------------------------//
bool Game_Init(void)
	{
	s3d.OpenGLInit(640,480,16, GIVE_CHOICE);	//Create a fullscreen/window with 640x480x16 dimensions
	sinput.DInputInit();			//Initiate DirectInput
	s3d.FontInit();				//Initiate the font

	flare.LoadTGA("Art/flare.tga", GL_LINEAR, GL_LINEAR);

	asteroidBeltTexture.LoadTGA("Art/AsteroidBelt.tga", GL_LINEAR, GL_LINEAR);
	radarTexture.LoadTGA("Art/Radar.tga", GL_LINEAR, GL_LINEAR);
	asteroidTexture.LoadTGA("Art/Asteroid.tga", GL_LINEAR, GL_LINEAR);

	//Create the sky cube list:
	float fSkyPoints[8][3] = 
	{
		{-1.0f, -1.0f, -1.0f}, //0
		{1.0f, -1.0f, -1.0f}, //1
		{1.0f, 1.0f, -1.0f}, //2
		{-1.0f, 1.0f, -1.0f}, //3
		{-1.0f, -1.0f, 1.0f}, //4
		{1.0f, -1.0f, 1.0f}, //5
		{1.0f, 1.0f, 1.0f}, //6
		{-1.0f, 1.0f, 1.0f}, //7
	}; //The sky cube is created it this way to avoid gaps between the sky sides

	asteroidBeltList = glGenLists(1);
	glNewList(asteroidBeltList, GL_COMPILE);
		glEnable(GL_TEXTURE_2D);
		glDisable(GL_LIGHTING);
		glDisable(GL_CULL_FACE);
		glDisable(GL_DEPTH_TEST);
		glDisable(GL_BLEND);
		glDisable(GL_FOG);
		glColor3f(1.0f, 1.0f, 1.0f);
		glScalef(10.0f, 10.0f, 10.0f);

		glEnableClientState(GL_VERTEX_ARRAY);
		glVertexPointer(3, GL_FLOAT, 0, fSkyPoints);

		glBindTexture(GL_TEXTURE_2D, asteroidBeltTexture.ID);
		glBegin(GL_QUADS);
		
			//Floor face
			glTexCoord2f(0.0f, 0.0f); glArrayElement(4);
			glTexCoord2f(1.0f, 0.0f); glArrayElement(5);
			glTexCoord2f(1.0f, 1.0f); glArrayElement(6);
			glTexCoord2f(0.0f, 1.0f); glArrayElement(7);

			//Sky face
			glTexCoord2f(0.0f, 1.0f); glArrayElement(0);
			glTexCoord2f(0.0f, 0.0f); glArrayElement(3);
			glTexCoord2f(1.0f, 0.0f); glArrayElement(2);
			glTexCoord2f(1.0f, 1.0f); glArrayElement(1);

			//Left face
			glTexCoord2f(1.0f, 0.0f); glArrayElement(0);
			glTexCoord2f(1.0f, 1.0f); glArrayElement(4);
			glTexCoord2f(0.0f, 1.0f); glArrayElement(7);
			glTexCoord2f(0.0f, 0.0f); glArrayElement(3);

			//Front face
			glTexCoord2f(0.0f, 0.0f); glArrayElement(0);
			glTexCoord2f(1.0f, 0.0f); glArrayElement(1);
			glTexCoord2f(1.0f, 1.0f); glArrayElement(5);
			glTexCoord2f(0.0f, 1.0f); glArrayElement(4);

			//Right face
			glTexCoord2f(0.0f, 0.0f); glArrayElement(1);
			glTexCoord2f(1.0f, 0.0f); glArrayElement(2);
			glTexCoord2f(1.0f, 1.0f); glArrayElement(6);
			glTexCoord2f(0.0f, 1.0f); glArrayElement(5);
	
			//Back face
			glTexCoord2f(1.0f, 0.0f); glArrayElement(3);
			glTexCoord2f(1.0f, 1.0f); glArrayElement(7);
			glTexCoord2f(0.0f, 1.0f); glArrayElement(6);
			glTexCoord2f(0.0f, 0.0f); glArrayElement(2);

		glEnd();
		
		glDisableClientState(GL_VERTEX_ARRAY);
		glEnable(GL_CULL_FACE);
		glEnable(GL_DEPTH_TEST);
	glEndList();
	
	GLUquadricObj *quadric;
	asteroidList = glGenLists(1);
	glNewList(asteroidList, GL_COMPILE);
		quadric = gluNewQuadric();
		gluQuadricDrawStyle(quadric, GLU_FILL);
		gluQuadricNormals(quadric, GLU_SMOOTH);
		gluQuadricTexture(quadric, GL_TRUE);
		gluSphere(quadric, 1.0f, 5, 5);
		gluDeleteQuadric(quadric);
	glEndList();

	Game_InitOther();

	return true;
	}


//------------------------------------------------------------------//
//- bool Game_Main(void) -------------------------------------------//
//------------------------------------------------------------------//
//- Description: This function is the heart of your program/game,  -//
//-              it is called in succession until you return a     -//
//-              false value to it, then the Game_Shutdown()       -//
//-              function is called.                               -//
//------------------------------------------------------------------//
bool Game_Main(void)
	{
	static FLOAT fps      = 0.0f;
    static FLOAT last_time= 0.0f;
    static DWORD frames	  = 0L;
	static DWORD timeNow = 0L;
	static DWORD lastLooptime = 0L;
	float time;

	sinput.DInputUpdate();		//Update DirectInput to make sure it's still alive
	if(KEY_DOWN(DIK_ESCAPE))	//Check to see if the user wants to quit
		PostQuitMessage(0);

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	//Clear screen and depth buffer
	glLoadIdentity();									//Reset the current modelview matrix

	if(render_mode==RENDER_WIRE)
		{
		glColor4f(0.5f, 0.5f, 0.5f, 1.0f);
		glDisable(GL_BLEND);
		glDisable(GL_LINE_SMOOTH);
		glDisable(GL_TEXTURE_2D);
		glPolygonMode(GL_FRONT, GL_LINE);
		glPolygonMode(GL_BACK, GL_LINE);
		}
	if(render_mode==RENDER_ANTIALIASED_WIRE)
		{
		glColor4f(1.0f, 1.0f, 1.0f, .5f);
		glDisable(GL_TEXTURE_2D);
		glEnable(GL_LINE_SMOOTH);
		glEnable(GL_BLEND);
		glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
		glPolygonMode(GL_FRONT, GL_LINE);
		glPolygonMode(GL_BACK, GL_LINE);
		}
	if(render_mode==RENDER_POINT)
		{
		glColor3d(1, 1, 1);
		glDisable(GL_TEXTURE_2D);
		glEnable(GL_LINE_SMOOTH);
		glHint(GL_POINT_SMOOTH_HINT, GL_NICEST);
		glPolygonMode(GL_FRONT, GL_POINT);
		glPolygonMode(GL_BACK, GL_POINT);
		}
	if(render_mode==RENDER_TEX)
		{
		glColor3d(1, 1, 1);
		glEnable(GL_TEXTURE_2D);
		glPolygonMode(GL_FRONT, GL_FILL);
		glPolygonMode(GL_BACK, GL_FILL);
		}

	//--------------------------------------------------------------//
	//- START GAME SPECIFIC STUFF ----------------------------------//
	//--------------------------------------------------------------//
	Game_Draw();
	Game_Check();
	//--------------------------------------------------------------//
	//- END GAME SPECIFIC STUFF ------------------------------------//
	//--------------------------------------------------------------//

	if(KEY_DOWN(DIK_W))
		render_mode= RENDER_WIRE;
	if(KEY_DOWN(DIK_A))
		render_mode= RENDER_ANTIALIASED_WIRE;
	if(KEY_DOWN(DIK_P))
		render_mode= RENDER_POINT;
	if(KEY_DOWN(DIK_T))
		render_mode= RENDER_TEX;	

	// Keep track of the time lapse and frame count
    time= timeGetTime()*0.001f; // Get current time in seconds
    ++frames;

    // Update the frame rate once per second
    if(time-last_time>1.0f)
		{
        fps      = frames/(time-last_time);
        last_time= time;
        frames   = 0L;
		}
	
	//Get the past time since the last frame
	timeNow = GetTickCount();
	deltaTime = timeNow-lastLooptime;
	if(deltaTime <= 0)
		deltaTime = 1; //Avoid possible divisions through zero and other errors
	if(deltaTime > 100)
		deltaTime = 100; //Avoid large 'jumps'
	lastLooptime = timeNow;

	//--------------------------------------------------------------//
	//- START ORTHOGRAPHIC MODE ------------------------------------//
	//--------------------------------------------------------------//
	GetClientRect(hwnd,&window);					//Get the window's dimensions
	glMatrixMode(GL_PROJECTION);					//Select the projection matrix
	glPushMatrix();									//Store the projection matrix
	glLoadIdentity();								//Reset the projection matrix
	glOrtho(0,window.right,0,window.bottom,-1,1);	//Set up an ortho screen
	glMatrixMode(GL_MODELVIEW);						//Select the modelview matrix

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	glEnable(GL_TEXTURE_2D);
	glPolygonMode(GL_FRONT, GL_FILL);
	glPolygonMode(GL_BACK, GL_FILL);
	
	//Demo title
	glColor4d(1,1,1,1);
	s3d.glPrint(200,450,"Free 3D Movement Demo");
	s3d.glPrint(0,  435,"FPS: %f", fps);

	glDisable(GL_BLEND);

	glMatrixMode(GL_PROJECTION);					//Select the projection matrix
	glPopMatrix();									//Restore the old projection matrix
	glMatrixMode(GL_MODELVIEW);						//Select the modelview matrix
	//--------------------------------------------------------------//
	//- END ORTHOGRAPHIC MODE --------------------------------------//
	//--------------------------------------------------------------//

	glFlush();
	s3d.BufferSwap();			//Finally, swap the buffers
	return true;
	}


//------------------------------------------------------------------//
//- bool Game_Shutdown(void) ---------------------------------------//
//------------------------------------------------------------------//
//- Description: This function does all the necesary shutdown      -//
//-				 procedures in your program/game. It is called once-//
//-              the program recieves a false value from           -//
//-              Game_Main().                                      -//
//------------------------------------------------------------------//
bool Game_Shutdown(void)
	{
	if(glIsList(asteroidBeltList))
		glDeleteLists(asteroidBeltList, 1);	
	if(glIsList(asteroidList))
		glDeleteLists(asteroidList, 1);	
	
	s3d.FontShutdown();

	sinput.DInputShutdown();
	s3d.OpenGLShutdown();

	return false;
	}



//------------------------------------------------------------------//
//- int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int) -----------//
//------------------------------------------------------------------//
//- Description: This is Window's equivalent to Main in dos.  You  -//
//-              don't have to put anything in this function, use  -//
//-              Game_Init(), Game_Main(), and Game_Shutdown() for -//
//-              all of yours needs.                               -//
//------------------------------------------------------------------//
int WINAPI WinMain(HINSTANCE hInstance, 
				   HINSTANCE hPrevInstance, 
				   LPSTR lpCmdLine, 
				   int nCmdShow) 
	{
	//Do all of the Initiation stuff
	if(Game_Init()==false)
		return 0;

	while(TRUE)
		{
		if(s3d.HandleMessages()==false)
			break;
		//Go to the Game_Main function to do everything
		Game_Main();
		} 

	//Call Game_Shutdown, and do all the shutdown procedures
	Game_Shutdown();

	return 0;
	}

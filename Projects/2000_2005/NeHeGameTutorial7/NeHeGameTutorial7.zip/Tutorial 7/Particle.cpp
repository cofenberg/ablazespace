//------------------------------------------------------------------//
//- Particle.cpp				                                   -//
//- Created by: Trent Polack  (aka ShiningKnight)                  -//
//------------------------------------------------------------------//
//- The definitions for the single Particle class in my nice, kewl -//
//- awesome little Particle Engine.  Particles are sooooo kewl, are-//
//- they not?													   -//
//------------------------------------------------------------------//

//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- INCLUDES -------------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//
#include "Particle.h"


//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- DEFINITIONS ----------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//

//------------------------------------------------------------------//
//- PARTICLE:: PARTICLE() ------------------------------------------//
//------------------------------------------------------------------//
//- Description: Default constructor that only inits all of the	   -//
//-				 Particle's values to 0.						   -//
//------------------------------------------------------------------//
PARTICLE::
	PARTICLE() : age(0.0f), dyingAge(0.0f),
				 size(0.0f), sizeCounter(0.0f),
				 alpha(0.0f), alphaCounter(0.0f)
		{
		color[0]=0.0f;		//Set all of the vectors to 0.0 
		color[1]=0.0f; 
		color[2]=0.0f; 
		color[3]=0.0f;

		colorCounter[0]=0.0f;
		colorCounter[1]=0.0f;
		colorCounter[2]=0.0f;
		colorCounter[3]=0.0f;
		}

//------------------------------------------------------------------//
//- PARTICLE:: ~PARTICLE() -----------------------------------------//
//------------------------------------------------------------------//
//- Description: Default deconstructor that only shuts down all of -//
//-				 the Particle's values to 0.					   -//	   -//
//------------------------------------------------------------------//	
PARTICLE::
	~PARTICLE()
		{	} 

//------------------------------------------------------------------//
//- GLvoid PARTICLE:: Set_ParentSystem(PARTICLE_SYSTEM*) -----------//
//------------------------------------------------------------------//
//- Description: Gives the class's particle a parent.  This parent -//
//-				 will be used for various updating stuff. Is it a  -//
//-				 mommy or a daddy? No one may ever know. o_O	   -//
//------------------------------------------------------------------//
GLvoid PARTICLE::
	SetParentSystem(PARTICLE_SYSTEM* parent)
	{	Parent= parent;	}

//------------------------------------------------------------------//
//- GLvoid PARTICLE::Create(PARTICLE_SYSTEM*,float) ----------------//
//------------------------------------------------------------------//
//- Description: Creates a particle.  Its private, so you don't    -//
//-				 get to use it at all... HAHAHA. :)                -//
//------------------------------------------------------------------//
GLvoid PARTICLE::
	Create(PARTICLE_SYSTEM* parent, float timeCounter)
	{
	VECTOR3D tempVelocity;
	float randomYaw;
	float randomPitch;
	float newSpeed;

	//This particle is dead, so its free to mess around with.
	//Now, this is where the fun starts.  Kick butt baby.
	age=0.0;
	dyingAge= (parent->life)+(RANDOM_FLOAT*(parent->lifeCounter));
	CHECK_RANGE(dyingAge, MIN_LIFETIME, MAX_LIFETIME);

	texture= parent->texture;

	//Now, we are going to set the particle's color.  The color
	//is going to be the system's start color*color counter
	color[0]= (parent->startColor.x)+RANDOM_FLOAT*(parent->colorCounter.x);
	color[1]= (parent->startColor.y)+RANDOM_FLOAT*(parent->colorCounter.y);
	color[2]= (parent->startColor.z)+RANDOM_FLOAT*(parent->colorCounter.z);
	color[3]= 1.0f;

	//Lets make sure that the color is legal
	CHECK_RANGE(color[0], MIN_COLOR, MAX_COLOR);
	CHECK_RANGE(color[1], MIN_COLOR, MAX_COLOR);
	CHECK_RANGE(color[2], MIN_COLOR, MAX_COLOR);

	//Now, lets calculate the color's counter, so that by the
	//time the particle is ready to die (poor guy), it will
	//have reached the system's end color.
	colorCounter[0]= ((parent->endColor.x)-color[0])/dyingAge;
	colorCounter[1]= ((parent->endColor.y)-color[1])/dyingAge;
	colorCounter[2]= ((parent->endColor.z)-color[2])/dyingAge;

	//Calculate the particle's alpha from the system's.
	alpha= (parent->startAlpha)+(RANDOM_FLOAT*(parent->alphaCounter));
	//Make sure the result of the above line is legal
	CHECK_RANGE(alpha, MIN_ALPHA, MAX_ALPHA);
	//Calculate the particle's alpha counter so that by the
	//time the particle is ready to die, it will have reached 
	//the system's end alpha
	alphaCounter=((parent->endAlpha)-alpha)/dyingAge;

	//Now, same routine as above, except with size
	size= (parent->startSize)+(RANDOM_FLOAT*(parent->sizeCounter));
	CHECK_RANGE(size, MIN_SIZE, MAX_SIZE);
	sizeCounter= ((parent->endSize)-size)/dyingAge;

	//Now, we calculate the velocity that the particle would 
	//have to move to from prev_location to current_location
	//in time_counter seconds.
	tempVelocity.x= ((parent->location.x)-(parent->prevLocation.x))/timeCounter;
	tempVelocity.y= ((parent->location.y)-(parent->prevLocation.y))/timeCounter;
	tempVelocity.z= ((parent->location.z)-(parent->prevLocation.z))/timeCounter;

	//Now emit the particle from a location between the last
	//known location, and the current location.  And don't
	//worry, this function is almost done.  Its mostly comments
	//if you look at it. Nice to know I have wasted a lot of
	//time typing these comments for you.  Blah. :)
	location.x= (parent->prevLocation.x)+tempVelocity.x*RANDOM_FLOAT*timeCounter;
	location.y= (parent->prevLocation.y)+tempVelocity.y*RANDOM_FLOAT*timeCounter;
	location.z= (parent->prevLocation.z)+tempVelocity.z*RANDOM_FLOAT*timeCounter;

	//Now a simple randomization of the point that the particle
	//is emitted from.
	location.x+=(Random((parent->spreadMin), (parent->spreadMax)))/(parent->spreadFactor);
	location.y+=(Random((parent->spreadMin), (parent->spreadMax)))/(parent->spreadFactor);
	location.z+=(Random((parent->spreadMin), (parent->spreadMax)))/(parent->spreadFactor);

	//Update the previous location so the next update can 
	//remember where we were
	(parent->prevLocation.x)=(parent->location.x);
	(parent->prevLocation.y)=(parent->location.y);
	(parent->prevLocation.z)=(parent->location.z);

	//The emitter has a direction.  This is where we find it:
	randomYaw  = (float)(RANDOM_FLOAT*PI*2.0f);
	randomPitch= (float)(DEG_TO_RAD(RANDOM_FLOAT*((parent->angle))));

	//The following code uses spherical coordinates to randomize
	//the velocity vector of the particle
	velocity.x=(cosf(randomPitch))*(parent->velocity.x);
	velocity.y=(sinf(randomPitch)*cosf(randomYaw))*(parent->velocity.y);
	velocity.z=(sinf(randomPitch)*sinf(randomYaw))*(parent->velocity.z);

	//Velocity at this point is just a direction (normalized
	//vector) and needs to be multiplied by the speed 
	//component to be legit.
	newSpeed= ((parent->speed)+(RANDOM_FLOAT*(parent->speedCounter)));
	CHECK_RANGE(newSpeed, MIN_SPEED, MAX_SPEED);
	velocity.x*= newSpeed;
	velocity.y*= newSpeed;
	velocity.z*= newSpeed;

	//Who's yo daddy!?
	SetParentSystem(parent);
	}

//------------------------------------------------------------------//
//- bool PARTICLE:: Update(float) ----------------------------------//
//------------------------------------------------------------------//
//- Description: This function updates the class's particle.	   -//
//-				 Nothing too hard about that, eh?				   -//
//------------------------------------------------------------------//
bool PARTICLE::
	Update(float timeCounter)
	{
	static VECTOR3D attractLocation;
	static VECTOR3D attractNormal;

	//Age the particle by the time counter
	age+= timeCounter;

	if(age>=dyingAge)
		{
		//Kill the particle. NOOOOOO... Ah, well, we have enough of
		//them, I probably won't even be able to tell the difference
		age=-1.0f;
		return false;
		}
	
	//Set the particle's previous location with the location that
	//will be the old one by the time we get through this function
	prevLocation.x=location.x;
	prevLocation.y=location.y;
	prevLocation.z=location.z;

	//Move the particle's current location
	location.x+= velocity.x*timeCounter;
	location.y+= velocity.y*timeCounter;
	location.z+= velocity.z*timeCounter;

	//Update the particle's velocity by the gravity vector by time.
	velocity.x+= (Parent->gravity.x*timeCounter);
	velocity.y+= (Parent->gravity.y*timeCounter);
	velocity.z+= (Parent->gravity.z*timeCounter);

	//Hehehe, sounds kewl.  If parent is attracting....  Well, I have
	//*NEVER* seen an attracting parent... Thats just wrong
	if(Parent->IsAttracting())	
		{
		//Find out where our Parent is located so we can track it
		attractLocation.x=Parent->GetLocation(GET_X);
		attractLocation.y=Parent->GetLocation(GET_Y);
		attractLocation.z=Parent->GetLocation(GET_Z);

		//Calculate the vector between the particle and the attractor
		attractNormal.x= attractLocation.x-location.x; 
		attractNormal.y= attractLocation.y-location.y; 
		attractNormal.z= attractLocation.z-location.z; 

		//We can turn off attraction for certain axes to create 
		//some kewl effects (such as a tornado!)
		glNormal3fv(attractNormal.v);

		//If you decide to use this simple method you really should use a variable multiplier
		//instead of a hardcoded value like 25.0f
		velocity.x+= attractNormal.x*5.0f*timeCounter;
		velocity.y+= attractNormal.y*5.0f*timeCounter;
		velocity.z+= attractNormal.z*5.0f*timeCounter;
		}

	//Adjust the current color (if you didn't realize that, 
	//then I wouldn't be surprised if you got done with your first
	//"Hello World!" program this morning... Sick and twisted)
	color[0]+= colorCounter[0] *timeCounter;
	color[1]+= colorCounter[1] *timeCounter;
	color[2]+= colorCounter[2] *timeCounter;

	//Adjust the alpha values (for transparency)
	alpha+= alphaCounter*timeCounter;

	//Adjust current size 
	size+= sizeCounter*timeCounter;

	//Annnnnddddd finally, set our color vector's spot #4 to the alpha,
	//because, things are a lot quick if we can use OpenGL's vector
	//color function.
	color[3]=alpha;

	return true;	//Yeee-aahhhhh buddy!
	}
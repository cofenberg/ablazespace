//==================================================================//
//==================================================================//
//= Tutorial x.cpp =================================================//
//==================================================================//
//= Original coder: Christian Ofenberg (mail@AblazeSpace.de) =======//
//=	Homepage: www.ablazespace.de							 =======//
//==================================================================//
//==================================================================//


//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- INCLUDES -------------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//
#include "Shining3D.h"
#include "Particle.h"


//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- CONSTANTS ------------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//
#define MAX_ACTORS 10 //The maximum number of actors in our universe
#define PLAYFIELD_RADIUS 300.0f //The radius of your 'universe'
enum ACTOR_TYPE //The different actor types to identify each actor
	{
	ACTOR_PLAYER, //The players actor
	ACTOR_ASTEROID, //An asteroid actor
	};


//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- CLASSES --------------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//

//------------------------------------------------------------------//
//- class ACTOR ----------------------------------------------------//
//------------------------------------------------------------------//
//- A class that contains all of the information about an actor    -//
//------------------------------------------------------------------//
typedef class ACTOR
{
	public:
		bool active; // Is the actor active?
		
		ACTOR_TYPE type; // The actors type
		
		VECTOR3D worldPos, //The current world position
				 lastWorldPos, //The last world position
				 worldVelocity, //The world velocity
				 rot, rotVelocity, //The rotation
				 directionVector, //The direction vector (object orientation)
				 rightVector, //The up direction vector
				 upVector; //The right direction vector

		float slideLRVelocity, //Left/right slide velocity
			  slideUDVelocity, //Up/down slide velocity
			  forward, //The acceleration in the current direction
			  backward, //The acceleration in the current direction
			  normalMaxVelocity, //The normal max velocity
			  currentMaxVelocity, //The current max velocity
			  maxVelocity, //The maximum velocity (Afterburner)
			  velocity, //The current real velocity (result velocity)
			  radius, //The radius of the actor (bounding sphere)
			  mass, //The actors mass
			  afterburnerPower; //The power of the afterburner

		//Shake effect: (could be used for the afterburner shaking)
		VECTOR3D shakePos, //The current shake position
				 lastShakePos, //The last current shake position
				 newShakePos, //The target shake position
				 shakeSpeed; //The current shake speed
		float shakePower; //The intensity of the shaking (for smooth fade in/out the effect)

		QUATERNION rotation; //The rotation saved as an quaternion
		
		ACTOR(void);
		bool Apply(void);
		bool ApplyToCamera(bool);
		bool Update(void);

} ACTOR;

//------------------------------------------------------------------//
//- class RADAR ----------------------------------------------------//
//------------------------------------------------------------------//
//- A class that contains all of the information about the radar   -//
//------------------------------------------------------------------//
typedef class RADAR
{
	public:
		VECTOR2D center; //The center position of the radar
		float radius; //The radius of the radar

		bool Init(void);
		bool GetRadarCoord(ACTOR *, VECTOR3D, VECTOR2D *);
		bool Draw(ACTOR *);
		bool DrawTargetArrow(VECTOR2D, ACTOR *);

} RADAR;


//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- GLOBALS --------------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//
extern SHINING3D s3d; //The Shining3D engine
extern DWORD deltaTime; //Change in time since last iteration
extern RECT window; //Stores the window's dimensions
extern GLint asteroidBeltList; //The asteroid beld list (sky cube)
extern TEXTURE radarTexture; //The radar texture

extern TEXTURE asteroidTexture; //The asteroid texture
extern GLint asteroidList; //The asteroid list

RADAR radar; //Radar information
ACTOR actorList[MAX_ACTORS]; //A list of all actors
ACTOR *player; //A pointer to the player in the actor list (for fast access)
			   //Normally the player is stored in the first actor list entry
bool realistic; //Should the flight model be realistic? (no speed decrease)
bool roll; //Should the roll control be activated?


//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- FUNCTION DECLARATIONS ------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//
bool Game_Draw(void);
bool Game_Check(void);
bool Game_InitActors(void);
bool Player_Check(void);
bool Draw_Actors(void);
bool Check_Actors(bool);
bool Ball_Collision(ACTOR *, ACTOR *, VECTOR3D);


//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- FUNCTION DEFINITIONS -------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//

//------------------------------------------------------------------//
//- bool Game_Draw(void) -------------------------------------------//
//------------------------------------------------------------------//
//- Description: Draws all game related stuff				       -//
//------------------------------------------------------------------//
bool Game_Draw(void)
	{
	//Setup the camera
	glMatrixMode(GL_MODELVIEW); //Select the modelview matrix
	glLoadIdentity(); //Reset the modelview matrix
	
	//Draw sky cube
	player->ApplyToCamera(true); //Rotate the scene
	glCallList(asteroidBeltList); //Draw the asteroid beld sky cube

	//Draw actors
	glLoadIdentity(); //Reset the modelview matrix
	player->ApplyToCamera(false); //Translate and rotate the scene
	Draw_Actors(); //Draw all actors
	
	//Other
	radar.Draw(player); //Draw the radar

	//Show some text
	GetClientRect(hwnd,&window); //Get the window's dimensions
	glMatrixMode(GL_PROJECTION); //Select the projection matrix
	glPushMatrix(); //Store the projection matrix
	glLoadIdentity(); //Reset the projection matrix
	glOrtho(0,window.right,0,window.bottom,-1,1); //Set up an ortho screen
	glMatrixMode(GL_MODELVIEW); //Select the modelview matrix

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	glEnable(GL_TEXTURE_2D);
	glPolygonMode(GL_FRONT, GL_FILL);
	glPolygonMode(GL_BACK, GL_FILL);
	
	//Demo title
	glColor4d(1,1,1,1);
	if(realistic)
		s3d.glPrint(10,  10,"Realistic flight model");
	if(roll)
		s3d.glPrint(10,  20,"Roll control");

	//Show the current velocity
	s3d.glPrint(380+(int) (actorList[0].shakePos.x*actorList[0].shakePower*600),
				20+(int) (actorList[0].shakePos.y*actorList[0].shakePower*600),
				"velocity: %0.1f", player->velocity);		

	glDisable(GL_BLEND);

	glMatrixMode(GL_PROJECTION); //Select the projection matrix
	glPopMatrix(); //Restore the old projection matrix
	glMatrixMode(GL_MODELVIEW);	//Select the modelview matrix

	return true;
	}

//------------------------------------------------------------------//
//- bool Game_Check(void) ------------------------------------------//
//------------------------------------------------------------------//
//- Description: Checks/updates all game related stuff	           -//
//------------------------------------------------------------------//
bool Game_Check(void)
	{
	//Check player:
	Player_Check();
	
	//Check/update all actors
	Check_Actors(false);

	//Change flight model
	if(KEY_DOWN(DIK_R))
		realistic = !realistic;

	//Change roll mode
	if(KEY_DOWN(DIK_M))
		roll = !roll;

	//Reset all actors:
	if(KEY_DOWN(DIK_SPACE))
		Game_InitActors();

	return true;
	}

//------------------------------------------------------------------//
//- bool Player_Check(void) ----------------------------------------//
//------------------------------------------------------------------//
//- Description: Check and handle the players input	   			   -//
//------------------------------------------------------------------//
bool Player_Check(void)
	{
	static DWORD fullStopTimer = GetTickCount(); //Stores the time were
												 //the last fullstop
												 //speed decrease occured
	float speed100 = (float) deltaTime/100, //Timing variable
		  speed200 = (float) deltaTime/200; //Timing variable
	int i;

	//Afterburner
	if(KEY_DOWN(DIK_TAB))
		{ //Increase the forward speed
		player->forward += (float) deltaTime/5;
	 	player->afterburnerPower += (float) deltaTime/500;
		if(player->afterburnerPower > 1.0f)
			player->afterburnerPower = 1.0f;
		}
	else
		{
		player->afterburnerPower -= (float) deltaTime/500;
		if(player->afterburnerPower < 0.0f)
			player->afterburnerPower = 0.0f;
		}
	
	//Compute the current maximum velocity
	player->currentMaxVelocity = player->normalMaxVelocity+
								 ((player->maxVelocity-player->normalMaxVelocity)*
								  player->afterburnerPower);

	//Forward
	if(KEY_DOWN(DIK_S))
		player->forward += speed100*8; //Increase the forward speed
	else
		{
		if(!KEY_DOWN(DIK_TAB))
			{ //Decrease the forward speed
			player->forward -= speed100*8;
			if(player->forward < 0.0f)
				player->forward = 0.0f;
			}
		}

	// Backward
	if(KEY_DOWN(DIK_X))
		player->backward += speed100*8; //Increase the backward speed
	else
		{ //Dencrease the backward speed
		player->backward -= speed100*8;
		if(player->backward < 0.0f)
			player->backward = 0.0f;
		}
	
	//Sliding
	if(KEY_DOWN(DIK_RSHIFT))
		{
		//Slide left
		if(KEY_DOWN(DIK_LEFT))
			player->slideLRVelocity += speed100*2;
		
		//Slide up
		if(KEY_DOWN(DIK_UP))
			player->slideUDVelocity += speed100*2;

		//Slide right
		if(KEY_DOWN(DIK_RIGHT))
			player->slideLRVelocity -= speed100*2;

		//Slide down
		if(KEY_DOWN(DIK_DOWN))
			player->slideUDVelocity -= speed100*2;
		}
	else
		{
		if(!roll)
			{
			//Turn left
			if(KEY_DOWN(DIK_LEFT))
				player->rotVelocity.heading += speed200;

			//Turn right
			if(KEY_DOWN(DIK_RIGHT))
				player->rotVelocity.heading -= speed200;
			}
		else
			{
			//Roll left
			if(KEY_DOWN(DIK_LEFT))
				player->rotVelocity.roll -= speed200;

			//Roll right
			if(KEY_DOWN(DIK_RIGHT))
				player->rotVelocity.roll += speed200;
			}

		//Turn up
		if(KEY_DOWN(DIK_UP))
			player->rotVelocity.pitch += speed200;

		//Turn down
		if(KEY_DOWN(DIK_DOWN))
			player->rotVelocity.pitch -= speed200;
		}

	if(!roll)
		{
		//Roll left
		if(KEY_DOWN(DIK_DELETE))
			player->rotVelocity.roll -= speed200;

		//Roll right
		if(KEY_DOWN(DIK_INSERT))
			player->rotVelocity.roll += speed200;
		}

	//Full stop
	if(KEY_DOWN(DIK_END))
		{
		if(GetTickCount()-fullStopTimer > 10)
			{
			fullStopTimer = GetTickCount();
			player->slideLRVelocity = player->slideLRVelocity/1.1f;
			player->slideUDVelocity = player->slideUDVelocity/1.1f;
			player->slideLRVelocity = player->slideLRVelocity/1.1f;
			player->slideUDVelocity = player->slideUDVelocity/1.1f;
			for(i = 0; i < 3; i++)
				{ //Decrease player speed
				player->worldVelocity.v[i] = player->worldVelocity.v[i]/1.1f;
				player->rotVelocity.v[i] = player->rotVelocity.v[i]/1.1f;
				}
			}
	}

	return true;
	}

//------------------------------------------------------------------//
//- bool Game_InitOther(void) --------------------------------------//
//------------------------------------------------------------------//
//- Description: Initializes game related stuff			           -//
//------------------------------------------------------------------//
bool Game_InitOther(void)
	{
	radar.Init(); //Initialize the radar
	Game_InitActors(); //Initialize all actors
	
	return true;
	}

//------------------------------------------------------------------//
//- bool Game_InitActors(void) -------------------------------------//
//------------------------------------------------------------------//
//- Description: Initializes all actors					           -//
//------------------------------------------------------------------//
bool Game_InitActors(void)
	{
	ACTOR *actor; //An pointer to an actor
	int i, d;
	
	//Reset all actors
	for(i = 0; i < MAX_ACTORS; i++)
		memset(&actorList[i], 0, sizeof(ACTOR)); //Set all to zero

	//Setup the players actor
	player = &actorList[0]; //Get the pointer to the players actor
	player->type = ACTOR_PLAYER; //Set the actors type
	player->active = true; //Activate the actor
	player->rotation.Reset(); //Reset the rotation quaternion
	player->radius = 2.0f; //Set the actors radius
	player->mass = (float) (player->radius*PI); //Calculate the actors mass
	player->normalMaxVelocity = player->currentMaxVelocity = 70.0f; //Setup the max velocities
	player->maxVelocity = 200.0f; //Setup the total max velocity

	//Loop through the actor list and initialize each actor
	for(i = 1; i < MAX_ACTORS; i++)
		{
		actor = &actorList[i]; //Get the pointer to this actor
		actor->type = ACTOR_ASTEROID; //Set the actors type
		actor->active = true; //Activate the actor
		actor->radius = (float) 2.0f+(rand() % 1000)/100.0f; //Set the actors radius
		actor->mass = (float) (actor->radius*PI); //Calculate the actors mass
		actor->rotation.Reset(); //Reset the rotation quaternion
		actor->normalMaxVelocity = actor->currentMaxVelocity = 70.0f; //Setup the max velocities
		actor->maxVelocity = 200.0f; //Setup the total max velocity
		
		//Set the actor to an random position and go sure that there is 
		//no collision between the actors
		for(;;)
			{
			//Set an random position
			for(d = 0; d < 3; d++)
				{
				actor->worldPos.v[d] = (float) (rand() % ((int) (PLAYFIELD_RADIUS*10)))/10.0f;
				if(!(rand() % 2))
					actor->worldPos.v[d] = -actor->worldPos.v[d];
				}
		
			//Check if there is an collision with an other actor
			if(!Check_Actors(true))
				break; //Good, there was no collision
			
			//Else, find another position for this actor
			}
		}

	return true;
	}

//------------------------------------------------------------------//
//- bool Draw_Actors(void) -----------------------------------------//
//------------------------------------------------------------------//
//- Description: Draws all actors								   -//
//------------------------------------------------------------------//
bool Draw_Actors(void)
	{
	ACTOR *actor; //A pointer to an actor
	int i;

	//Setup texture and color
	glBindTexture(GL_TEXTURE_2D, asteroidTexture.ID);
	glColor4d(1,1,1,1);

	for(i = 1; i < MAX_ACTORS; i++)
		{
		actor = &actorList[i]; //Get the pointer to this actor
		if(!actor->active) //Is this actor active?
			continue; //Nope!
		
		glPushMatrix();
		actor->Apply(); //Translate and rotate the actor
		glScalef(actor->radius, actor->radius, actor->radius);

		//Draw the actor according its type
		switch(actor->type)
			{
			case ACTOR_ASTEROID: glCallList(asteroidList); break;
			}

		glPopMatrix();
		}

	return true;
	}

//------------------------------------------------------------------//
//- bool Check_Actors(bool) ----------------------------------------//
//------------------------------------------------------------------//
//- Description: Checks/updates all actors				           -//
//------------------------------------------------------------------//
bool Check_Actors(bool checkOnly)
	{
	bool collisionFound = false; //Was an collsion between actors detected?
	ACTOR *actor, *actor2; //A pointer to an actor
	float distance;
	VECTOR3D delta;
	int i, i2;

	for(i = 0; i < MAX_ACTORS; i++)
		{
		actor = &actorList[i]; //Get the pointer to this actor
		if(!actor->active) //Is this actor active?
			continue; //Nope!
		
		if(!checkOnly) //Should we only check if there is an collision?
			actor->Update(); //Update the actors movement related data:

		//Check if there is an collision with another actor
		for(i2 = 0; i2 < MAX_ACTORS; i2++)
			{
			if(i == i2)
				continue; //The actor couln't collide with him self!

			actor2 = &actorList[i2]; //Get the pointer to this actor
			if(!actor2->active) //Is this actor active?
				continue; //Nope!
			
			delta = actor->worldPos-actor2->worldPos; //Compute the delta between the two actors
			distance = delta.DotProduct();//Compute the distance between the two actors

			//Did they collide?
			if(distance <= (actor->radius+actor2->radius)*(actor->radius+actor2->radius))
				{ //We have a collision!
				collisionFound = true; //Remember that we found an collision

				if(!checkOnly) //Should we only check if there is an collision?
					{
					Ball_Collision(actor, actor2, delta); //Do collision response
				
					//Set the actor to the last save position
					actor->worldPos = actor->lastWorldPos;
					}
				}
			}
		}

	return collisionFound;
	}

//------------------------------------------------------------------//
//- bool Ball_Collision(void) --------------------------------------//
//------------------------------------------------------------------//
//- Description: Calculates the new velocities of two actors after -//
//-				 their collision								   -//
//------------------------------------------------------------------//
// Note: There's still an error in the z velocity update!
bool Ball_Collision(ACTOR *actor1, ACTOR *actor2, VECTOR3D delta)
{ // begin CheckBallCollision()
	float contactAngle, zFactorCos, zFactorSin,
		  resVelocity, closingAngle, massFactor,
		  mass1, mass2, adiff, portion, contactAngle2;
	VECTOR3D closingVelocity, contactVelocity;

	//Determine the angle of contact
	if(delta.x)
		{
		contactAngle = (float) atan(delta.y/delta.x);
		if(contactAngle < 0)
			contactAngle = -contactAngle;
		contactAngle2 = (float) tan(delta.z);
		if(contactAngle2 < 0)
			contactAngle2 = -contactAngle2;
		}
	else
		{
		contactAngle = (float) PId2;
		contactAngle2 = (float) PId2;
		}


	//To determine how the objects will rebound off of each
	//other, we are not concerned with the speed of each
	//object, but rather the relative, or closing, speeds
	//of the two objects
	closingVelocity = actor2->worldVelocity-actor1->worldVelocity;

	zFactorCos = (float) cos(contactAngle2);
	zFactorSin = (float) -sin(contactAngle2);

	//Calculate the x, y & z speed in the direction of contact
	resVelocity = closingVelocity.GetLength();
	contactVelocity.x = (float) cos(contactAngle)*resVelocity;
	contactVelocity.y = (float) sin(contactAngle)*resVelocity;
	contactVelocity.z = (float) sqrt(closingVelocity.z*closingVelocity.z)*zFactorSin;

	//Now, determine the closing angle
	if(closingVelocity.x)
		{
		closingAngle = (float) atan(closingVelocity.y/closingVelocity.x);
		if(closingAngle < 0)
			closingAngle = -closingAngle;
		}
	else
		closingAngle = (float) PId2;

	//Hmmmm...
	//With equal masses, the max rebound speed is 1/2 the closing speed.
	//With unequal masses, the max rebound speed is the closing speed.
	//Okay then, Normalize the two masses to be:  mass1 + mass2 = 2.0
	massFactor = 2/(actor1->mass+actor2->mass);
	mass1 = actor1->mass*massFactor;
	mass2 = actor2->mass*massFactor;

	//Handle z coordinate
	if(actor1->worldPos.z > actor2->worldPos.z)
	{
		actor1->worldVelocity.z -= contactVelocity.z*mass2;
		actor2->worldVelocity.z += contactVelocity.z*mass1;
	}
	else
	{
		actor1->worldVelocity.z += contactVelocity.z*mass2;
		actor2->worldVelocity.z -= contactVelocity.z*mass1;
	}

	//Quadrant-specific stuff
	if(actor1->worldPos.x > actor2->worldPos.x)
		{
		if(actor1->worldPos.y < actor2->worldPos.y)
			{
			//actor1 is contacting upper right quadrant of actor2
			if(closingVelocity.y < 0)
				{
				if(closingVelocity.x < 0)
					adiff = (float) PI-contactAngle-closingAngle;
				else
					adiff = contactAngle-closingAngle;
				}
			else
				adiff = contactAngle+closingAngle;
			portion = (float) cos(adiff)*zFactorCos;
			
			//Update the velocities
			actor1->worldVelocity.x += contactVelocity.x*portion*mass2;
			actor1->worldVelocity.y -= contactVelocity.y*portion*mass2;
			actor2->worldVelocity.x -= contactVelocity.x*portion*mass1;
			actor2->worldVelocity.y += contactVelocity.y*portion*mass1;
			}
		else
			{
			//actor1 is contacting lower right quadrant of actor2
			if(closingVelocity.y > 0)
				{
				if(closingVelocity.x < 0)
					adiff = (float) PI-contactAngle-closingAngle;
				else
					adiff = contactAngle-closingAngle;
				}
			else
				adiff = contactAngle+closingAngle;
			portion = (float) cos(adiff)*zFactorCos;

			//Update the velocities
			actor1->worldVelocity.x += contactVelocity.x*portion*mass2;
			actor1->worldVelocity.y += contactVelocity.y*portion*mass2;
			actor2->worldVelocity.x -= contactVelocity.x*portion*mass1;
			actor2->worldVelocity.y -= contactVelocity.y*portion*mass1;
			}
		}
	else
		{
		if(actor1->worldPos.y < actor2->worldPos.y)
			{
			//actor1 is contacting upper left quadrant of actor2
			if(closingVelocity.y < 0)
				{
				if(closingVelocity.x < 0)
					adiff = contactAngle-closingAngle;
				else
					adiff = (float) PI-contactAngle-closingAngle;
				}
			else
				adiff = contactAngle+closingAngle;
			portion = (float) cos(adiff)*zFactorCos;

			//Update the velocities
			actor1->worldVelocity.x -= contactVelocity.x*portion*mass2;
			actor1->worldVelocity.y -= contactVelocity.y*portion*mass2;
			actor2->worldVelocity.x += contactVelocity.x*portion*mass1;
			actor2->worldVelocity.y += contactVelocity.y*portion*mass1;
			}
		else
			{
			//actor1 is contacting lower left quadrant of actor2
			if(closingVelocity.y > 0)
				{
				if(closingVelocity.x < 0)
					adiff = contactAngle-closingAngle;
				else
					adiff = (float) PI-contactAngle-closingAngle;
				}
			else
				adiff = contactAngle+closingAngle;
			portion = (float) cos(adiff)*zFactorCos;

			//Update the velocities
			actor1->worldVelocity.x -= contactVelocity.x*portion*mass2;
			actor1->worldVelocity.y += contactVelocity.y*portion*mass2;
			actor2->worldVelocity.x += contactVelocity.x*portion*mass1;
			actor2->worldVelocity.y -= contactVelocity.y*portion*mass1;
			}
		}
		
		return false;
	}



// ACTOR functions ***************************************************

//------------------------------------------------------------------//
//- ACTOR::ACTOR(void) ---------------------------------------------//
//------------------------------------------------------------------//
//- Description: The ACTOR class constructor			           -//
//------------------------------------------------------------------//

ACTOR::ACTOR(void)
	{
	memset(this, 0, sizeof(ACTOR)); //Set all to zero
	}

//------------------------------------------------------------------//
//- bool ACTOR::Apply(void) ----------------------------------------//
//------------------------------------------------------------------//
//- Description: Translates and rotates the actor		           -//
//------------------------------------------------------------------//
bool ACTOR::Apply(void)
	{
	float axisX, axisY, axisZ, rotAngle;
	
	glTranslatef(worldPos.x+shakePos.x*shakePower/10,
				 worldPos.y+shakePos.y*shakePower/10,
				 -worldPos.z+shakePos.z*shakePower/10);
	rotation.GetAxisAngle(axisX, axisY, axisZ, rotAngle);
	glRotatef((float) (rotAngle*PIUNDER180),
			  axisX+shakePos.x*shakePower,
			  axisY+shakePos.y*shakePower,
			  -axisZ+shakePos.z*shakePower);

	return true;
	}

//------------------------------------------------------------------//
//- bool ACTOR::ApplyToCamera(bool) --------------------------------//
//------------------------------------------------------------------//
//- Description: Translates and rotates the actor		           -//
//------------------------------------------------------------------//
bool ACTOR::ApplyToCamera(bool onlyRot)
	{
	float axisX, axisY, axisZ, rotAngle;
	
	rotation.GetAxisAngle(axisX, axisY, axisZ, rotAngle);
	glRotatef((float) (rotAngle*PIUNDER180),
			  -axisX+shakePos.x*shakePower,
			  -axisY+shakePos.y*shakePower,
			  axisZ+shakePos.z*shakePower);
	if(!onlyRot)
		glTranslatef(-worldPos.x+shakePos.x*shakePower/10,
					 -worldPos.y+shakePos.y*shakePower/10,
					 worldPos.z+shakePos.z*shakePower/10);

	return true;
	}

//------------------------------------------------------------------//
//- bool ACTOR::Update(void) ---------------------------------------//
//------------------------------------------------------------------//
//- Description: Updates the actors movement data				   -//
//------------------------------------------------------------------//
bool ACTOR::Update(void)
	{
	float speed = (float) deltaTime/1000, //Timing variable
		  factor;
	QUATERNION rotationT;
	int i;

	//Rotate the actor
	rotation.PostMult(QUATERNION(rotVelocity.pitch*speed/5,
								 rotVelocity.heading*speed/5,
								 rotVelocity.roll*speed/5));

	//Compute the direction vector
	rotation.GetDirectionVector(&directionVector);

	//Slide movement
	//Left/right
	memcpy(&rotationT, &rotation, sizeof(QUATERNION));
	rotation.PostMult(QUATERNION(0.0f, 90.0f, 0.0f));
	rotation.GetDirectionVector(&rightVector);
	for(i = 0; i < 3; i++)
		worldVelocity.v[i] += (rightVector.v[i]*slideLRVelocity)*speed*15;
	memcpy(&rotation, &rotationT, sizeof(QUATERNION));

	//Up/Down
	rotation.PostMult(QUATERNION(90.0f, 0.0f, 0.0f));
	rotation.GetDirectionVector(&upVector);
	for(i = 0; i < 3; i++)
		worldVelocity.v[i] += (upVector.v[i]*slideUDVelocity)*speed*15;
	memcpy(&rotation, &rotationT, sizeof(QUATERNION));
		
	//Do movement
	for(i = 0; i < 3; i++)
		{
		//Update the velocity
		worldVelocity.v[i] += (directionVector.v[i]*forward)*speed;
		worldVelocity.v[i] -= (directionVector.v[i]*backward)*speed;
		
		lastWorldPos.v[i] = worldPos.v[i]; //Save last world position
		worldPos.v[i] += worldVelocity.v[i]*speed; //Get the new world position
		
		//Update rotation
		rot.v[i] += rotVelocity.v[i]*speed*10;
		if(rot.v[i] >= 360.0f)
			rot.v[i] -= 360.0f;
		else
			if(rot.v[i] < 0.0f)
				rot.v[i] += 360.0f;
		}

	if(!realistic && type != ACTOR_ASTEROID)
		{ //Decrease the velocities
		for(i = 0; i < 3; i++)
			{
			worldVelocity.v[i] -= worldVelocity.v[i]/20.0f*((float) deltaTime/30);
			rotVelocity.v[i] -= rotVelocity.v[i]/60.0f*((float) deltaTime/30);
			}
		}

	//Decrease the slide velocity
	slideLRVelocity -= slideLRVelocity/10.0f*((float) deltaTime/30);
	slideUDVelocity -= slideUDVelocity/10.0f*((float) deltaTime/30);
	
	//Check if one velocity is too hight 
	if(forward > currentMaxVelocity)
		forward = currentMaxVelocity;
	if(forward < -currentMaxVelocity)
		forward = -currentMaxVelocity;
	if(backward > currentMaxVelocity)
		backward = currentMaxVelocity;
	if(backward < -currentMaxVelocity)
		backward = -currentMaxVelocity;
	if(slideLRVelocity > currentMaxVelocity)
		slideLRVelocity = currentMaxVelocity;
	if(slideLRVelocity < -currentMaxVelocity)
		slideLRVelocity = -currentMaxVelocity;
	if(slideUDVelocity > currentMaxVelocity)
		slideUDVelocity = currentMaxVelocity;
	if(slideUDVelocity < -currentMaxVelocity)
		slideUDVelocity = -currentMaxVelocity;

	velocity = worldVelocity.GetLength();
	if(velocity > currentMaxVelocity && !realistic)
		{ //The velocity is to high!!
		factor = currentMaxVelocity/velocity;
		for(i = 0; i < 3; i++)
			worldVelocity.v[i] *= factor;
		velocity = currentMaxVelocity;
		}
	
	//Creates the shake effect:
	shakePower = afterburnerPower; //Set the shake power to the afterburner power
	if(!shakePower)
		{ //There is no shaking
		shakePos = newShakePos = 0.0f;
		shakeSpeed = 0.0f;
		}
	else
		{
		for(i = 0; i < 3; i++)
			{
			if(lastShakePos.v[i] > newShakePos.v[i])
				{
				shakePos.v[i] -= (float) shakeSpeed.v[i]*deltaTime/10000;
				if(shakePos.v[i] <= newShakePos.v[i])
					{
					shakeSpeed.v[i] = 5.0f+((float) (rand() % 100)/1000);
					lastShakePos.v[i] = shakePos.v[i];
					if((rand() % 2))
						newShakePos.v[i] = (float) (rand() % 100)/10000.0f;
					else
						newShakePos.v[i] = -(float) (rand() % 100)/10000.0f;
					}
				}
			else
				{
				shakePos.v[i] += (float) shakeSpeed.v[i]*deltaTime/10000;
				if(shakePos.v[i] >= newShakePos.v[i])
					{
					lastShakePos.v[i] = shakePos.v[i];
					shakeSpeed.v[i] = 5.0f+((float) (rand() % 100)/1000);
					if((rand() % 2))
						newShakePos.v[i] = (float) (rand() % 100)/10000.0f;
					else
						newShakePos.v[i] = -(float) (rand() % 100)/10000.0f;
					}
				}
			}
		}

	return true;
	}




// RADAR functions ***************************************************

//------------------------------------------------------------------//
//- bool RADAR::Init(void) -----------------------------------------//
//------------------------------------------------------------------//
//- Description: Initializes the radar					           -//
//------------------------------------------------------------------//
bool RADAR::Init(void)
	{
	center.x = s3d.SCREEN_WIDTH/2.0f;
	center.y = s3d.SCREEN_HEIGHT/8.0f;
	radius = s3d.SCREEN_HEIGHT/8.0f-10.0f;
	
	return true;
	}

//------------------------------------------------------------------//
//- bool RADAR::GetRadarCoord(void) --------------------------------//
//------------------------------------------------------------------//
//- Description: Compute the two-D radar coordinates of an object  -//
//------------------------------------------------------------------//
bool RADAR::GetRadarCoord(ACTOR *actor, VECTOR3D pos3D, VECTOR2D *radarPos2D)
	{
	float radarR, radarCOS, radarSIN, rT;
	VECTOR3D deltaPos, v;

	//Compute coords of object relative to the actor
	deltaPos = pos3D-actor->worldPos;
	
	//Normalize that
	deltaPos.Normalize();
	
	//Distance of blip from center of radar is cosine of angle
	//between view direction and direction to object
	radarR = actor->directionVector.DotProduct(deltaPos);
	
	//Determine projection of object on plane perpendicular
	//to viewing plane
	v = deltaPos+actor->directionVector*(-radarR);
	
	//Handle special case of null v, meaning object is on
	//line of sight
	if(v.IsNull())
	{
		(*radarPos2D) = center;
		return true;
	}
	
	//Else normalize v
	v.Normalize();
	
	//v is now a vector from the actor's viewpoint to projection
	//of object on the actors's plane. Compute angle from actors's
	//up vector to object
	radarSIN = actor->rightVector.DotProduct(v);
	radarCOS = actor->upVector.DotProduct(v);
	
	//Convert to cartesian
	rT = (1.0f-radarR)/2.0f;
	(*radarPos2D).x = center.x+radius*(-rT)*radarSIN;
	(*radarPos2D).y = center.y+radius*rT*radarCOS;
	
	return true;
	}

//------------------------------------------------------------------//
//- bool RADAR::Draw(void) -----------------------------------------//
//------------------------------------------------------------------//
//- Description: Displays the Wing Commander-like radar	           -//
//------------------------------------------------------------------//
bool RADAR::Draw(ACTOR *actor)
	{
	VECTOR3D pos3D, worldPosT;
	VECTOR2D pos2D;
	ACTOR *actorT; //A pointer to an actor
	int i;
	
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_CULL_FACE);

	// Arrow pointing to the center of your space
	glColor4f(1.0f, 1.0f, 1.0f, 0.9f);
	GetRadarCoord(actor, worldPosT, &pos2D);
	pos2D -= radar.center;
	DrawTargetArrow(pos2D, actor);

	// Draw the radar itself
	glColor4f(1.0f, 1.0f, 1.0f, 0.9f);
	glLoadIdentity();
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	glOrtho(0.0, ((double) s3d.SCREEN_WIDTH), 0.0,
			((double) s3d.SCREEN_HEIGHT), -1.0, 1.0);
	glTranslatef(actor->shakePos.x*actor->shakePower*500,
				 actor->shakePos.y*actor->shakePower*500,
				 0.0f);

	//Draw the radar itself
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, radarTexture.ID);
	glEnable(GL_BLEND);
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f);
		glVertex2f(center.x-radius, center.y-radius);
		glTexCoord2f(1.0f, 0.0f);
		glVertex2f(center.x+radius, center.y-radius);
		glTexCoord2f(1.0f, 1.0f);
		glVertex2f(center.x+radius, center.y+radius);
		glTexCoord2f(0.0f, 1.0f);
		glVertex2f(center.x-radius, center.y+radius);
	glEnd();

	// Draw radar points
	// Center
	glColor4f(1.0f, 1.0f, 1.0f, 0.9f);
	glDisable(GL_TEXTURE_2D);
	glEnable(GL_POINT_SMOOTH);
	glPointSize(8.0f);
	radar.GetRadarCoord(actor, worldPosT, &pos2D);
	glBegin(GL_POINTS);
		glVertex2f(320.0f, 240.0f); //Cursor
		glVertex2f(pos2D.x, pos2D.y); //Radar point
	glEnd();

	//Show the positions of the actors:
	glPointSize(6.0f);
	glColor4f(1.0f, 0.0f, 0.0f, 0.9f);
	glBegin(GL_POINTS);
		for(i = 0; i < MAX_ACTORS; i++)
			{
			actorT = &actorList[i]; //Get the pointer to this actor
			if(!actorT->active) //Is this actor active?
				continue; //Nope!
			
			if(actorT == player)
				continue; //The player shouldn't be drawn
			radar.GetRadarCoord(actor, actorT->worldPos, &pos2D);
			glVertex2f(pos2D.x, pos2D.y);
			}
	glEnd();
	
	glDisable(GL_POINT_SMOOTH);
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_CULL_FACE);
	glEnable(GL_DEPTH_TEST);
	glPointSize(1.0f);
	
	return true;
	}

//------------------------------------------------------------------//
//- bool RADAR::DrawTargetArrow(void) ------------------------------//
//------------------------------------------------------------------//
//- Draw an arrow pointing in an given direction		           -//
//------------------------------------------------------------------//
bool RADAR::DrawTargetArrow(VECTOR2D pos2D, ACTOR *actor)
	{
	float angle;
	
	//Should the arrow be shown?
	if(pos2D.x > -0.3f && pos2D.y > -0.3f &&
	   pos2D.x < 0.3f && pos2D.y < 0.3f)
	   return true; //No, the point is in the players view
	
	glPushMatrix();
	glLoadIdentity();
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glLineWidth(1.0f);
	
	//Get arrow angle
	if(pos2D.x)
	{
		if(pos2D.x > 0)
			angle = (float) (atan(pos2D.y/pos2D.x)*PIUNDER180);
		else
			angle = (float) ((atan(pos2D.y/pos2D.x)*PIUNDER180)-180.0f);
	}
	
	//Setup arrow
	glRotatef(angle, 0.0f, 0.0f, 1.0f);
	glTranslatef(0.5f+actor->shakePos.x*actor->shakePower*10,
				 actor->shakePos.x*actor->shakePower*10,
				 -8.0f+actor->shakePos.z*actor->shakePower*10);
	
	//Draw arrow
	glBegin(GL_LINES);
		glVertex3f(0.0f, 0.1f, 0.0f);
		glVertex3f(0.3f, 0.0f, 0.0f);
		glVertex3f(0.0f, -0.1f, 0.0f);
		glVertex3f(0.3f, 0.0f, 0.0f);
		glVertex3f(0.0f, -0.1f, 0.0f);
		glVertex3f(0.0f, 0.1f, 0.0f);
	glEnd();

	glPopMatrix();
	
	return true;
	}
Keys:

tab - afterburner
s - forward
x - backward
cursor keys - rotate
right shift + cursor keys - slide
delete & insert - roll
end - full stop

r - changes between realistic and easy flight model
m - changes between roll and normal control
space - reset all actors

w - wireframe mode
a - antialiased wireframe mode
t - texture mode
p - point mode
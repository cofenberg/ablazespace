Im Editor kann die Kamera durch diese Tasten ver�ndert werden:

Diese Taste gedr�ckt halten und die Pfeiltasten verwenden:
- Enter
- Zur�ck
- Links Shift
- Links Strg 

Mit Numpad 5 wird wieder alles auf Standart gesetzt.


Debug-Tasten:
Alt-m: Lade alle Modelle neu
Alt-t: Lade alle Texturen neu
Alt-s: Lade alle Sounds neu
Alt-k: Lade alle Texte neu

Alt-p: Spiel pausieren, jedoch kein Men� einblenden... damit dann man quasi alles 
       Einfrieren um dann details zu betrachten...



Es sind noch einige Bugs enthalten... aber diese sollten nicht so sehr aufallen...
die Fortschritte sollten sich aber trotzdem erkennen lassen...
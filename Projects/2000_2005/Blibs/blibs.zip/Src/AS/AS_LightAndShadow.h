//-----------------------------------------------------------------------------
// File: AS_LightAndShadow.h
//-----------------------------------------------------------------------------

#ifndef __AS_LIGHT_AND_SHADOW_H__
#define __AS_LIGHT_AND_SHADOW_H__


// Classes: *******************************************************************
typedef class AS_DLIGHT
{
	public:
		AS_VECTOR3D vPos,
					vColor;
		float fRadius, fDensity;

	public:
		AS_DLIGHT(void);
		virtual ~AS_DLIGHT(void);
		void Light(AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D, AS_PLANE, BOOL);

} AS_DLIGHT;
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_LIGHT_AND_SHADOW_H__
#ifndef RELEASEPTR
#define RELEASEPTR(x) if(x){x->Release(); x=NULL;}
#endif

#ifndef RELEASE
#define RELEASE(x) RELEASEPTR(x)
#endif

#ifndef DELETEPTR
#define DELETEPTR(x) if(x){delete x;x=NULL;}
#endif

#ifndef FREEPTR
#define FREEPTR(x) if(x){free(x);x=NULL;}
#endif

#include "windows.h"

#include "mmreg.h"
#include "mmsystem.h"

#include "stdio.h"

#include "assert.h"

#pragma comment(lib,"winmm.lib")

#ifndef __WAVE_H__
#define __WAVE_H__

static HRESULT GetWaveFmt(char *strFilename,WAVEFORMATEX& wfmtex)
{
	HMMIO ptr;
	MMCKINFO mmckChunk,mmckParent;

	ptr=mmioOpen(strFilename,NULL,MMIO_READ|MMIO_ALLOCBUF);
	if(ptr==NULL){
		mmioClose(ptr,0);
		return E_FAIL;
	}

	DWORD dwWave=mmioFOURCC('W','A','V','E');

	ZeroMemory(&mmckParent,sizeof(MMCKINFO));
	if(mmioDescend(ptr,&mmckParent,NULL,0)!=0){
		mmioClose(ptr,0);
		return E_FAIL;
	}

	if(mmckParent.ckid!=FOURCC_RIFF||mmckParent.fccType!=dwWave){
		mmioClose(ptr,0);
		return E_FAIL;
	}

	ZeroMemory(&mmckChunk,sizeof(MMCKINFO));
	mmckChunk.ckid=mmioFOURCC('f','m','t',' ');

	if(mmioDescend(ptr,&mmckChunk,&mmckParent,MMIO_FINDCHUNK)!=0){
		mmioClose(ptr,0);
		return E_FAIL;
	}

	if(mmckChunk.cksize<sizeof(WAVEFORMATEX)-sizeof(wfmtex.cbSize)){
		mmioClose(ptr,0);
		return E_FAIL;
	}

	if(mmioRead(ptr,(char*)&wfmtex,sizeof(wfmtex))<sizeof(WAVEFORMATEX)-sizeof(wfmtex.cbSize)){
		mmioClose(ptr,0);
		return E_FAIL;
	}

	mmioClose(ptr,0);

	return S_OK;
}

static HRESULT LoadWaveFile(char *strFilename,BYTE*& lpData,DWORD& dwLen,WAVEFORMATEX& wfmtex)
{
	HMMIO ptr;
	MMCKINFO mmckChunk,mmckParent;

	ptr=mmioOpen(strFilename,NULL,MMIO_READ|MMIO_ALLOCBUF);
	if(ptr==NULL){
		mmioClose(ptr,0);
		return E_FAIL;
	}

	DWORD dwWave=mmioFOURCC('W','A','V','E');

	ZeroMemory(&mmckParent,sizeof(MMCKINFO));
	if(mmioDescend(ptr,&mmckParent,NULL,0)!=0){
		mmioClose(ptr,0);
		return E_FAIL;
	}

	if(mmckParent.ckid!=FOURCC_RIFF||mmckParent.fccType!=dwWave){
		mmioClose(ptr,0);
		return E_FAIL;
	}

	ZeroMemory(&mmckChunk,sizeof(MMCKINFO));
	mmckChunk.ckid=mmioFOURCC('f','m','t',' ');

	if(mmioDescend(ptr,&mmckChunk,&mmckParent,MMIO_FINDCHUNK)!=0){
		mmioClose(ptr,0);
		return E_FAIL;
	}

	if(mmckChunk.cksize<sizeof(WAVEFORMATEX)-sizeof(wfmtex.cbSize)){
		mmioClose(ptr,0);
		return E_FAIL;
	}

	if(mmioRead(ptr,(char*)&wfmtex,sizeof(wfmtex))<sizeof(WAVEFORMATEX)-sizeof(wfmtex.cbSize)){
		mmioClose(ptr,0);
		return E_FAIL;
	}

	if(mmioSeek(ptr,mmckParent.dwDataOffset+sizeof(FOURCC),SEEK_SET)==-1){
		mmioClose(ptr,0);
		return E_FAIL;
	}

	ZeroMemory(&mmckChunk,sizeof(MMCKINFO));
	mmckChunk.ckid=mmioFOURCC('d','a','t','a');

	if(mmioDescend(ptr,&mmckChunk,&mmckParent,MMIO_FINDCHUNK)!=0){
		mmioClose(ptr,0);
		return E_FAIL;
	}

	lpData=(BYTE*)malloc(mmckChunk.cksize);
	assert(lpData!=NULL);

	if((dwLen=mmioRead(ptr,(char*)lpData,mmckChunk.cksize))<(signed)mmckChunk.cksize){
		FREEPTR(lpData);
		mmioClose(ptr,0);
		return E_FAIL;
	}

	mmioClose(ptr,0);

	return S_OK;
}

#endif
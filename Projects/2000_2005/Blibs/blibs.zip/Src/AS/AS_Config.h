//-----------------------------------------------------------------------------
// File: AS_Config.h
//-----------------------------------------------------------------------------

#ifndef __AS_CONFIG_H__
#define __AS_CONFIG_H__


// Structures: ****************************************************************
typedef struct
{
	int Number;
	DEVMODE *pDevMode;
} DISPLAY_MODE_INFO;
///////////////////////////////////////////////////////////////////////////////

// Classes: *******************************************************************
typedef class AS_CONFIG
{
	public:
		// General:
		BOOL bFirstRun,
			 bError, bSetError,
			 bMouseScroll,
			 bShowFPS;
		RECT EditorWindow;
		char byLanguage[256];
		BOOL bRotateMove,
			 bBackCamera,
			 bTiltCamera;
		float fMouseSensibility;
				
		// Graphic:
		BOOL bFullScreen,
			 bUseLevelVertexColor,
			 bFastTexturing,
			 bUseMipmaps,
			 bMultitexturing,
			 bHightRenderQuality,
			 bLightmaps,
			 bShadowmaps;
		DWORD dwMode;
		char byZBuffer; // The z buffer bit depth
		char byLight; // 0 = none, 1 = flat, 2 = smooth
		int iWindowWidth, iWindowHeight,
			iModeIndex; 
		DEVMODE DevMode;
		int iScreenPixels, iScreenSize;
		BOOL bParticles; // Are the particles activated?
		float fParticleDensity, // The number of partilces (1.0 = full)
			  fVisibility; // How far could the play look?

		// Sound:
		BOOL bSound, // Are the sounds activated?
			 bMusic; // Are the music activated?
		char bySoundOutput; // The selected sound output device
		int iMusicVolume, // The volume of the music
			iSoundVolume; // The volume of the sound

		// Keys:
		// [0] = Key array position
		// [1] = Key description array position
		int iLeftKey[2], iRightKey[2], iUpKey[2], iDownKey[2],
			iShotKey[2], iKickKey[2], iActionKey[2], iPullKey[2], iSuicideKey[2],
			iJumpKey[2], iChangePerspectiveKey[2], iStandartViewKey[2],
			iPauseKey[2], iQuickLoadKey[2], iQuickSaveKey[2], iLevelRestartKey[2],
			iShowLevelMissionsKey[2];

		// Debug:
		BOOL bDrawBounding,
			 bShowQuadtrees,
			 bFrustumCulling,
			 bShowCulledObjects,
			 bShowTriangles,
			 bShowFieldInfo,
			 bWireframeMode,
			 bPointMode;

		AS_CONFIG(void);
		~AS_CONFIG(void);

		void Check(void);
		int EnumerateKeyUsage(int);
        HRESULT Load(char *);
	    HRESULT Save(char *);

} AS_CONFIG;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern AS_CONFIG *_ASConfig;
extern DISPLAY_MODE_INFO DisplayModeInfo;
extern BOOL bFirstRunConfigDialog;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern void OpenConfigDialog(HWND);
extern void SetConfigLanguage(void);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_CONFIG_H__
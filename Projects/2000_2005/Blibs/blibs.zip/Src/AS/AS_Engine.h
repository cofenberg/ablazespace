//-----------------------------------------------------------------------------
// File: AS_Engine.h
//-----------------------------------------------------------------------------

#ifndef __AS_ENGINE_H__
#define __AS_ENGINE_H__


// Definitions: ***************************************************************
#define AS_WINDOW_NAME "AS-Engine"
enum {MODULE_GAME, MODULE_EDITOR};
#define AS_GAME_INFO_FILE "Game.ini"
#define AS_LOG_FILE "Log.txt"
#define GAME_NAME "Blibs"
#define GAME_VERSION "V0.63"
#define GAME_WINDOW_NAME "Blibs"
#define ASO_FILE "Object files (*.aso)\0*.aso\0"
#define ASS_FILE "Surface files (*.ass)\0*.ass\0"
#define MD2_FILE "Model files (*.md2)\0*.md2\0"
#define CAM_FILE "Campaign files (*.cam)\0*.cam\0"
#define JPG_FILE "JPG files (*.jpg)\0*.jpg\0"
#define BMP_FILE "BMP files (*.bmp)\0*.bmp\0"
#define PPM_FILE "PPM files (*.ppm)\0*.ppm\0"
#define TGA_FILE "TGA files (*.tga)\0*.tga\0"
#define TXT_FILE "Text files (*.txt)\0*.txt\0"
#define LEV_FILE "Level files (*.lev)\0*.lev\0"
#define TEXTURE_FILES \
		TEXT("JPG Files (*.jpg)\0*.jpg\0") \
		TEXT("BMP Files (*.bmp)\0*.bmp\0") \
		TEXT("PPM Files (*.ppm)\0*.ppm\0") \
		TEXT("TGA Files (*.tga)\0*.tga\0") \
		TEXT("All Files (*.*)\0*.*;\0\0")
#define VIDEO_FILES \
		TEXT("AVI Files (*.avi)\0*.avi\0")
#define MUSIC_FILES \
		TEXT("Audio files (*.mp3; *.wav;)\0*.mp3; *.wav\0")\
		TEXT("Midi Files (*.mid; *.midi;)\0*.mid; *.midi;\0")\
		TEXT("Mod Files (*.it; *.mod; *.s3m; *.xm)\0*.it; *.mod; *.s3m; *.xm\0")\
		TEXT("All Files (*.*)\0*.*;\0\0")
///////////////////////////////////////////////////////////////////////////////

// Includes: ******************************************************************
#include "AS_BibIncludes.h"
#include "..\Resource.h"
#include "AS_FrustumCulling.h"
#include "AS_ProgressWindow.h"
#include "AS_Window.h"
#include "AS_OpenGL.h"
#include "AS_Config.h"
#include "AS_Language.h"
#include "AS.h"
#include "AS_Fmod.h"
#include "AS_DXInput.h"
#include "AS_Math.h"
#include "AS_Vector.h"
#include "AS_Plane.h"
#include "AS_Matrix.h"
#include "AS_MD2.h"
#include "AS_Particle.h"
#include "AS_Quaternion.h"
#include "AS_Collision.h"
#include "AS_LightAndShadow.h"
#include "AS_Avi.h"
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_ENGINE__
//-----------------------------------------------------------------------------
// File: AS_Math.cpp
//-----------------------------------------------------------------------------

#include "AS_Engine.h"


// Variables: *****************************************************************
unsigned int ASFastSqrtTable[0x10000]; // Declare table of square roots
float   two = 2.0f;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
void ASBuildSqrtTable(void);
void ASAddVec(FLOAT3, FLOAT3, FLOAT3 *);
void ASSubVec(FLOAT3, FLOAT3, FLOAT3 *);
void ASMulVec(FLOAT3, FLOAT3, FLOAT3 *);
void ASScaleVec(FLOAT3, float, FLOAT3 *);
void ASInvertVec(FLOAT3, FLOAT3 *);
void ASRotateVectorX(FLOAT3, float, FLOAT3 *);
void ASRotateVectorY(FLOAT3, float, FLOAT3 *);
void ASRotateVectorZ(FLOAT3, float, FLOAT3 *);
void ASCatmullRom(AS_CAMERA *, AS_CAMERA *, AS_CAMERA *, AS_CAMERA *, float, AS_CAMERA *);
///////////////////////////////////////////////////////////////////////////////


void ASBuildSqrtTable(void)
{ // begin ASBuildSqrtTable()
	unsigned int i;
	FastSqrtUnion s;

	for(i = 0; i <= 0x7FFF; i++)
	{
		// Build a float with the bit pattern i as mantissa
		// and an exponent of 0, stored as 127:
		s.i = (i << 8) | (0x7F << 23);
		s.f = (float) sqrt(s.f);

		// Take the square root then strip the first 7 bits of
		// the mantissa into the table:
		ASFastSqrtTable[i + 0x8000] = (s.i & 0x7FFFFF);

		// Repeat the process, this time with an exponent of 1, 
		// stored as 128:

		s.i = (i << 8) | (0x80 << 23);
		s.f = (float)sqrt(s.f);

		ASFastSqrtTable[i] = (s.i & 0x7FFFFF);
	}
} // end ASBuildSqrtTable()

void ASAddVec(FLOAT3 v1, FLOAT3 v2, FLOAT3 *res)
{ // begin ASAddVec()
	(*res)[0] = v1[0]+v2[0];
	(*res)[1] = v1[1]+v2[1];
	(*res)[2] = v1[2]+v2[2];
} // end ASAddVec()

void ASSubVec(FLOAT3 v1, FLOAT3 v2, FLOAT3 *res)
{ // begin ASSubVec()
	(*res)[0] = v1[0]-v2[0];
	(*res)[1] = v1[1]-v2[1];
	(*res)[2] = v1[2]-v2[2];
} // end ASSubVec()

void ASMulVec(FLOAT3 v, FLOAT3 v2, FLOAT3 *res)
{ // begin ASMulVec()
	(*res)[0] = v[0]*v2[0];
	(*res)[1] = v[1]*v2[1];
	(*res)[2] = v[2]*v2[2];
} // end ASMulVec()

void ASScaleVec(FLOAT3 v, float fScale, FLOAT3 *res)
{ // begin ASScaleVec()
	(*res)[0] = v[0]*fScale;
	(*res)[1] = v[1]*fScale;
	(*res)[2] = v[2]*fScale;
} // end ASScaleVec()

void ASInvertVec(FLOAT3 v, FLOAT3 *res)
{ // begin ASInvertVec()
	(*res)[0] = -v[0];
	(*res)[1] = -v[1];
	(*res)[2] = -v[2];
} // end ASInvertVec()

void ASRotateVectorX(FLOAT3 fVec, float amnt, FLOAT3 *fDestVec)
{ // begin ASRotateVectorX()
   amnt *= (float) PI/180;
   float s = (float) sin(amnt);
   float c = (float) cos(amnt);
   float y = fVec[1];
   float z = fVec[2];

   (*fDestVec)[0] = fVec[0];
   (*fDestVec)[1] = (y * c) - (z * s);
   (*fDestVec)[2] = (y * s) + (z * c);
} // ned ASRotateVectorX()

void ASRotateVectorY(FLOAT3 fVec, float amnt, FLOAT3 *fDestVec)
{ // begin ASRotateVectorY()
   amnt *= (float) PI/180;
   float s = (float) sin(amnt);
   float c = (float) cos(amnt);
   float x = fVec[0];
   float z = fVec[2];

   (*fDestVec)[0] = (x * c) + (z * s);
   (*fDestVec)[1] = fVec[1];
   (*fDestVec)[2] = (z * c) - (x * s);
} // end ASRotateVectorY()

void ASRotateVectorZ(FLOAT3 fVec, float amnt, FLOAT3 *fDestVec)
{ // begin ASRotateVectorZ()
   amnt *= (float) PI/180;
   float s = (float) sin(amnt);
   float c = (float) cos(amnt);
   float x = fVec[0];
   float y = fVec[1];

   (*fDestVec)[0] = (x * c) - (y * s);
   (*fDestVec)[1] = (y * c) + (x * s);
   (*fDestVec)[2] = fVec[2];
} // end  // begin ASRotateVectorZ()







// Catmull-Rom Curve calculations:
void ASCatmullRom(AS_CAMERA *pC1, AS_CAMERA *pC2, AS_CAMERA *pC3, AS_CAMERA *pC4, float t, AS_CAMERA *pResCamera)
{ // begin ASCatmullRom()
	float t2, t3, t1;

	t2 = t*t;
	t3 = t*t*t;
	t1 = (1-t)*(1-t);

	pResCamera->fPos[X] = (-t*t1*pC1->fPos[X] + (2-5*t2+3*t3)*pC2->fPos[X] + t*(1+4*t-3*t2)*pC3->fPos[X] - t2*(1-t)*pC4->fPos[X])/2;
	pResCamera->fPos[Y] = (-t*t1*pC1->fPos[Y] + (2-5*t2+3*t3)*pC2->fPos[Y] + t*(1+4*t-3*t2)*pC3->fPos[Y] - t2*(1-t)*pC4->fPos[Y])/2;
	pResCamera->fPos[Z] = (-t*t1*pC1->fPos[Z] + (2-5*t2+3*t3)*pC2->fPos[Z] + t*(1+4*t-3*t2)*pC3->fPos[Z] - t2*(1-t)*pC4->fPos[Z])/2;
	
	pResCamera->fRot[X] = (-t*t1*pC1->fRot[X] + (2-5*t2+3*t3)*pC2->fRot[X] + t*(1+4*t-3*t2)*pC3->fRot[X] - t2*(1-t)*pC4->fRot[X])/2;
	pResCamera->fRot[Y] = (-t*t1*pC1->fRot[Y] + (2-5*t2+3*t3)*pC2->fRot[Y] + t*(1+4*t-3*t2)*pC3->fRot[Y] - t2*(1-t)*pC4->fRot[Y])/2;
	pResCamera->fRot[Z] = (-t*t1*pC1->fRot[Z] + (2-5*t2+3*t3)*pC2->fRot[Z] + t*(1+4*t-3*t2)*pC3->fRot[Z] - t2*(1-t)*pC4->fRot[Z])/2;

	pResCamera->fFOV = (-t*t1*pC1->fFOV + (2-5*t2+3*t3)*pC2->fFOV + t*(1+4*t-3*t2)*pC3->fFOV - t2*(1-t)*pC4->fFOV)/2;

	pResCamera->fStretch[X] = (-t*t1*pC1->fStretch[X] + (2-5*t2+3*t3)*pC2->fStretch[X] + t*(1+4*t-3*t2)*pC3->fStretch[X] - t2*(1-t)*pC4->fStretch[X])/2;
	pResCamera->fStretch[Y] = (-t*t1*pC1->fStretch[Y] + (2-5*t2+3*t3)*pC2->fStretch[Y] + t*(1+4*t-3*t2)*pC3->fStretch[Y] - t2*(1-t)*pC4->fStretch[Y])/2;
} // eno ASCatmullRom()
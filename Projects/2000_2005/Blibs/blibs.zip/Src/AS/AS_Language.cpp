//-----------------------------------------------------------------------------
// File: AS_Language.cpp
//-----------------------------------------------------------------------------

#include "AS_Engine.h"
#include "..\ModuleHeaders.h"


// Variables: *****************************************************************
char *pbyASHelpFile;
char *pbyASText[AS_TEXTS];
char *pbyASMessage[AS_MESSAGES];
int iASCreditsTexts;
char **pbyASCreditsText;
int iASCreditsTextures;
char **pbyASCreditsTexture;
int iASLanguages;  // The number of languages
char **pbyASLanguage; // All found languages names
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
void EnumerateLanguages(void);
void SetLanguage(char *);
void DestroyLanguage(void);
BOOL SetStartLanguage(void);
///////////////////////////////////////////////////////////////////////////////


void EnumerateLanguages(void)
{ // begin EnumerateLanguages()
	WIN32_FIND_DATA FindFileData;
    int i;
	char byTemp[256];
	HANDLE Find;
	                   
	_AS->WriteLogMessage("Enumerate languages");
	if(pbyASLanguage)
	{
		for(i = 0; i < iASLanguages; i++)
			free(pbyASLanguage[i]);
		free(pbyASLanguage);
	}
	iASLanguages = 0;
	sprintf(byTemp, "%s%s\\*.*", _AS->byProgramPath, _AS->byLanguagesDirectory);
	Find = FindFirstFile(byTemp, &FindFileData);
	for(;;)
	{
		if(FindFileData.cFileName[0] != '.' &&
		   (FindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == FILE_ATTRIBUTE_DIRECTORY)
		{ // We found a dictory:
			iASLanguages++;
			pbyASLanguage = (char **) realloc(pbyASLanguage, sizeof(char **)*iASLanguages);
			pbyASLanguage[iASLanguages-1] = new char[strlen(FindFileData.cFileName)+1];
			strcpy(pbyASLanguage[iASLanguages-1], FindFileData.cFileName);
			_strupr(pbyASLanguage[iASLanguages-1]);
		}
		if(!FindNextFile(Find, &FindFileData))
			break;
	}
	FindClose(Find);
} // end EnumerateLanguages()

void SetLanguage(char *pbyLanguage)
{ // begin SetLanguage()
    int i;
	char byFile[256], byTemp[256];

	sprintf(byTemp, "Set language to %s", pbyLanguage);
	_AS->WriteLogMessage(byTemp);
	DestroyLanguage();
	sprintf(byFile, "%s%s\\%s\\general.txt", _AS->byProgramPath, _AS->byLanguagesDirectory, pbyLanguage);
	GetPrivateProfileString("help", "file", "", byTemp, MAX_PATH, byFile);
	pbyASHelpFile = (char *) malloc(strlen(byTemp)+1);
	strcpy(pbyASHelpFile, byTemp);
	
	// Load all texts:
	for(i = 0; i < AS_TEXTS; i++)
	{
		sprintf(byTemp, "%d", i);
		GetPrivateProfileString("general", byTemp, "", byTemp, MAX_PATH, byFile);
		pbyASText[i] = (char *) malloc(strlen(byTemp)+1);
		strcpy(pbyASText[i], byTemp);
	}
	
	// Load all messages:
	for(i = 0; i < AS_MESSAGES; i++)
	{
		sprintf(byTemp, "%d", i);
		GetPrivateProfileString("messages", byTemp, "", byTemp, MAX_PATH, byFile);
		pbyASMessage[i] = (char *) malloc(strlen(byTemp)+1);
		strcpy(pbyASMessage[i], byTemp);
	}

	// Load credits texts:
	sprintf(byFile, "%s%s\\%s\\credits.txt", _AS->byProgramPath, _AS->byLanguagesDirectory, pbyLanguage);
	iASCreditsTexts = GetPrivateProfileInt("general", "texts", 0, byFile);
	pbyASCreditsText = (char **) malloc(sizeof(char *)*iASCreditsTexts);
	for(i = 0; i < iASCreditsTexts; i++)
	{
		sprintf(byTemp, "%d", i);
		GetPrivateProfileString("texts", byTemp, "", byTemp, MAX_PATH, byFile);
		pbyASCreditsText[i] = (char *) malloc(strlen(byTemp)+1);
		strcpy(pbyASCreditsText[i], byTemp);
	}

	iASCreditsTextures = GetPrivateProfileInt("general", "textures", 0, byFile);
	pbyASCreditsTexture = (char **) malloc(sizeof(char *)*iASCreditsTextures);
	for(i = 0; i < iASCreditsTextures; i++)
	{
		sprintf(byTemp, "%d", i);
		GetPrivateProfileString("textures", byTemp, "", byTemp, MAX_PATH, byFile);
		pbyASCreditsTexture[i] = (char *) malloc(strlen(byTemp)+1);
		strcpy(pbyASCreditsTexture[i], byTemp);
	}
	
	// Update the dialogs and so on:
	SetConfigLanguage();
	SetEditorLanguage();
	SetGameLanguage();
} // end SetLanguage()

void DestroyLanguage(void)
{ // begin DestroyLanguage()
	SAFE_DELETE(pbyASHelpFile);
	for(int i = 0; i < AS_TEXTS; i++)
		SAFE_DELETE(pbyASText[i]);
	for(i = 0; i < AS_MESSAGES; i++)
		SAFE_DELETE(pbyASMessage[i]);
	for(i = 0; i < iASCreditsTexts; i++)
		SAFE_DELETE(pbyASCreditsText[i]);
	SAFE_DELETE(pbyASCreditsText);
	for(i = 0; i < iASCreditsTextures; i++)
		SAFE_DELETE(pbyASCreditsTexture[i]);
	SAFE_DELETE(pbyASCreditsTexture);
} // end DestroyLanguage()

BOOL SetStartLanguage(void)
{ // begin SetStartLanguage()
	char byTemp[256];
	BOOL bLanguage;
	int i;

	// Check if the selected language is available:
	bLanguage = FALSE;
	for(i = 0; i < iASLanguages; i++)
		if(!strcmp(pbyASLanguage[i], _ASConfig->byLanguage))
		{
			bLanguage = TRUE;
			break;
		}
	if(!bLanguage)
	{ // No this language isn't available:
		if(!iASLanguages)
		{ // Oh, no! There is no other language!!
			MessageBox(NULL, "There are no languages!!\nAs result there are no text's!",
					   GAME_NAME, MB_OK | MB_ICONINFORMATION);
		}
		else
		{ // Change to the first best language:
			sprintf(byTemp, "The selected language (%s) isn't available!!\nPlease choose an other language.\n",
					_ASConfig->byLanguage);
			MessageBox(NULL, byTemp, GAME_NAME, MB_OK | MB_ICONINFORMATION);
			strcpy(_ASConfig->byLanguage, pbyASLanguage[0]);
			SetLanguage(_ASConfig->byLanguage);
		}
	}
	else
		SetLanguage(_ASConfig->byLanguage);

	return bLanguage;
} // end SetStartLanguage()
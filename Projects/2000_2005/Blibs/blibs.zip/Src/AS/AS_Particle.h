//-----------------------------------------------------------------------------
// File: AS_Particle.h
//-----------------------------------------------------------------------------

#ifndef __AS_PARTICLE_H__
#define __AS_PARTICLE_H__


typedef class ACTOR ACTOR;

// Definitions: ***************************************************************
// The types of particle systems
enum AS_PARTICLE_SYSTEM_TYPE
{
	PS_Md2Trace = 0, // A trace of a md2 model
	PS_ShotTrace1, // A shot trace
	PS_Smoke1, // Smoke
	PS_Smoke2, // Smoke
	PS_ParticleLogo, // Particle logo
	PS_Autosave, // Player autosave view
	PS_WaterWaves, // Water waves
	PS_Beamer, // Beamer particles
	PS_X3Acid, // Acid particles
	PS_Bubbles, // Bubble particles if the player is under water
	PS_Explosion1, // An explosion
	PS_WingSmoke, // If Blibs have wings
	PS_Lights, // Different particle lights
};
///////////////////////////////////////////////////////////////////////////////

// Structures: ****************************************************************
typedef class AS_PARTICLE
{
	private:

	public:
		BOOL bAlive; // Is this particle active?
		float fEngine; // The engine (equal to the live time)
		float fDensity; // The particles density
		float fFadeSpeed; // The fade speed
		float fColor[3]; // The color of this particle
		float fFixPos[3]; // The fix positon in the space (e.g. used for particle images)
		float fPos[3]; // The positon in the space
		float fLastPos[3]; // The last positon
		float fVelocity[3]; // The velocity
		float fSize; // The size of the particle
		BOOL bTemp[3]; // For different stuff...

		float fLastTestedHeight;
		long lLastHeightTestTime;

		// For the animated particle:
		int iAnimationStep, // The current animation step
			iAnimationSpeed; // The speed of the animation
		long lLastAnimtationTime; // The time were the last animation step change occurred

} AS_PARTICLE;

typedef class AS_PARTICLE_SYSTEM
{
	private:

	public:
		int iID; // The systems ID in the manager
		AS_PARTICLE_SYSTEM_TYPE Type; // The type of this particle system
		AS_TEXTURE *pTexture; // A pointer to the particle texture
		
		BOOL bActive; // Is the particle system active?
		BOOL bGoingInActive; // Should the system been going inactive?
		BOOL bUpdate;
		BOOL bChecked;

		int iMaxParticles; // The maximum number of particles
		int iParticles; // The number of particles (scaled by the configuration)
		AS_PARTICLE *pParticle; // The particles

		BOOL bRandomDelay; // Is the delay is created my random?
		long lMaxRandomDelay; // The greatest random delay
		long lTimeDelay; // How long should be waited to the next update?
		long lLastTime; // The last time were the system was updated (the particle emission)
		long lNextTime; // The next time were the system should be updated (the particle emission)
		
		long lLiveStartTime; // The time were the system came into live
		long lLiveEndTime; // The time were the system live should be end (-1 = no live time limit)
		
		FLOAT3 fStartPos; // The start position of this particle system:
		int iVertex; // A vertex of a model the particle system is connected with
		 
		// For partikel animation:
		BOOL bAnimatedParticles; // Has this system animated particles? 
		int iAnimationColumns, // The number of animation steps per columns
			iAnimationRows, // The number of animation steps per row
			iTextureWidth, iTextureHeight; // The size of the texture

		ACTOR *pActor; // A pointer to the actor, if the system is connected with it
		FLOAT3 fBoundingBox[2]; // The bounding box of this particle system

		void (*Check)(AS_PARTICLE_SYSTEM *);
		void (*Draw)(AS_PARTICLE_SYSTEM *);

		void CreateMd2Vertices(AS_MD2_MODEL *, int, int, float, FLOAT3, int);

		int GetFreeParticle(void);

} AS_PARTICLE_SYSTEM;

typedef class AS_PARTICLE_MANAGER
{
	private:

	public:
		int iSystems; // The number of particle systems:
		AS_PARTICLE_SYSTEM *pSystem; // The particle systems

		void Check(void);
		void Draw(BOOL);

		int AddNewSystem(AS_PARTICLE_SYSTEM_TYPE, int, ACTOR *, AS_TEXTURE *, AS_TEXTURE *);
		void DeleteSystem(int);
		void Destroy(void);
		void UpdateSystems(void);

} AS_PARTICLE_MANAGER;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_PARTICLE__
//-----------------------------------------------------------------------------
// File: AS_Avi.h
//-----------------------------------------------------------------------------

#ifndef __AS_AVI_H__
#define __AS_AVI_H__


// Functions: *****************************************************************
extern HRESULT ASPlayVideo(int, char *);
extern void flipIt(void *);
extern void OpenSound(LPCSTR, HWND);
extern void OpenAVI(LPCSTR, HWND);
extern void GrabAVIFrame(int);
extern void CloseAVI(void);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_AVI_H__



//-----------------------------------------------------------------------------
// File: AS_OpenGL.h
//-----------------------------------------------------------------------------

#ifndef __AS_OPENGL_H__
#define __AS_OPENGL_H__


// Functions: *****************************************************************
extern LRESULT CALLBACK OpenGLInfoProc(HWND, UINT, WPARAM, LPARAM);
extern HRESULT ASInitOpenGL(AS_WINDOW *, HWND, HDC *, HGLRC *, BOOL);
extern HRESULT ASDestroyOpenGL(AS_WINDOW *, HWND, HDC, HGLRC);
extern void ASConfigOpenGL(int, int);
extern void ASSetFillMode(void);
extern void ASBuildFont(void);
extern void ASKillFont(void);
extern void ASPrint(int, int, char *, int);
extern void ASSimplePrint(int, int, char *, GLuint);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_OPENGL_H__
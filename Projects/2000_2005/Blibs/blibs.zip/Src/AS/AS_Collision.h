//-----------------------------------------------------------------------------
// File: AS_Collsison.h
//-----------------------------------------------------------------------------

#ifndef __AS_COLLISION_H__
#define __AS_COLLISION_H__


// Definitions: ***************************************************************
#define AS_PLANE_BACKSIDE 0x000001
#define AS_PLANE_FRONT    0x000010
#define AS_ON_PLANE       0x000100
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern double ASIntersectRayPlane(AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D);
extern BOOL ASCheckPointInTriangle(AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D);
extern BOOL ASCheckPointInTriangle(AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D);
extern AS_VECTOR3D ASClosestPointOnLine(AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D);
extern AS_VECTOR3D ASClosestPointOnTriangle(AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D);
extern BOOL ASCheckPointInSphere(AS_VECTOR3D, AS_VECTOR3D, float);
extern AS_VECTOR3D ASTangentPlaneNormalOfEllipsoid(AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D);
extern DWORD ASClassifyPoint(AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D);
extern double ASIntersectRaySphere(AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D, float);
extern BOOL ASCheckTriangleCollision(AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D *,
									 AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D);
extern BOOL ASCheckLineInBox(AS_VECTOR3D, AS_VECTOR3D, FLOAT3 [2]);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_COLLISION_H__
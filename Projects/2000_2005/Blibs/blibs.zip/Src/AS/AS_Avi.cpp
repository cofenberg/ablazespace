// The main code was taken from NeHe's side:
// Playing AVI Files In OpenGL Jeff Molofee's Lesson 36 http://nehe.gamedev.net 2001

//-----------------------------------------------------------------------------
// File: AS_Avi.cpp
//-----------------------------------------------------------------------------

#include "AS_Engine.h"
#include "..\ModuleHeaders.h"


#include <vfw.h>												// Header File For Video For Windows
#include "AS_DXSound.h"

LPDIRECTSOUND8 lpDS;
LPDIRECTSOUNDBUFFER lpDSPrimaryBuf,lpBuf=NULL;
LPDIRECTSOUND3DLISTENER lpDSListener;

float		angle;												// Used For Rotation
float		next;												// Used For Rotation
int			frame=0;											// Frame Counter
int			effect;												// Current Effect
bool		sp;													// Space Bar Pressed?
bool		env=TRUE;											// Environment Mapping (Default On)
bool		ep;													// 'E' Pressed?
bool		bg=TRUE;											// Background (Default On)
bool		bp;													// 'B' Pressed?

bool playing=0;
bool audio=0;
long avi_time;
float avi_ms_per_frame;
DWORD start_time;

AVISTREAMINFO		psi;										// Pointer To A Structure Containing Stream Info
PAVISTREAM			pavi;										// Handle To An Open Stream
PGETFRAME			pgf;										// Pointer To A GetFrame Object
BITMAPINFOHEADER	bmih;										// Header Information For DrawDibDraw Decoding
long				lastframe;									// Last Frame Of The Stream
int					width;										// Video Width
int					height;										// Video Height
char				*pdata;										// Pointer To Texture Data
UINT iVideoLayer;

HDRAWDIB hdd;													// Handle For Our Dib
HBITMAP hBitmap;												// Handle To A Device Dependant Bitmap
HDC hdc = CreateCompatibleDC(0);								// Creates A Compatible Device Context
unsigned char* data = 0;										// Pointer To Our Resized Image



HRESULT ASPlayVideo(int, char *);
void flipIt(void *);
void OpenSound(LPCSTR, HWND);
void OpenAVI(LPCSTR, HWND);
void GrabAVIFrame(int);
void CloseAVI(void);


HRESULT ASPlayVideo(int iWindow, char *pbyFilename)
{ // begin ASPlayVideo()
	FILE *fp;
	MSG msg;

	Sleep(1);

	_AS->WriteLogMessage("Playing video: %s", pbyFilename);

	// Check if the file is there:
	fp = fopen(pbyFilename, "rb");
	if(!fp)
	{
		_AS->WriteLogMessage("Couldn't find file!");
		return -1;
	}
	fclose(fp);

	// Create video layer:
	glGenTextures(1, &iVideoLayer);
	glBindTexture(GL_TEXTURE_2D, iVideoLayer);
	
	hdd = DrawDibOpen();
	OpenAVI(pbyFilename, *_AS->pWindow[iWindow].GethWnd());
	frame = 0;
	playing = FALSE;

	for(;;)
	{
		if(PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
    	{
        	if(!GetMessage(&msg, NULL, 0, 0))
                break;
        	TranslateMessage(&msg);
        	DispatchMessage(&msg);
    	}
		else
		{	
			if(_AS->GetShutDown() || _AS->CheckModuleChange())
				PostQuitMessage(0);
			
			SendMessage(*_AS->pWindow[iWindow].GethWnd(), WM_MOVE, 0, 0);
			_AS->ReadDXInput(*_AS->pWindow[iWindow].GethWnd());
			
			// Check video:
			DWORD elapsedTime;
			if(!playing)
			{
				playing = TRUE;
				if(audio)
				{
					lpBuf->Stop();
					lpBuf->Play(0, 0, 0);
				}
				start_time = timeGetTime();
			}

			elapsedTime=timeGetTime()-start_time;

 			frame= (int) (elapsedTime/avi_ms_per_frame);
			if (frame>=lastframe)
			{	
				frame = lastframe-1;
				playing=0;
				ASKeyFirst[DIK_ESCAPE] = TRUE;
			}

			// Draw video:
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
			glBindTexture(GL_TEXTURE_2D, iVideoLayer);
			GrabAVIFrame(frame);
			glEnable(GL_TEXTURE_2D);
			glDisable(GL_BLEND);
			glLoadIdentity();
			glBegin(GL_QUADS);
				glTexCoord2f(1.0f, 1.0f); glVertex3f( 11.0f,  8.3f, -20.0f);
				glTexCoord2f(0.0f, 1.0f); glVertex3f(-11.0f,  8.3f, -20.0f);
				glTexCoord2f(0.0f, 0.0f); glVertex3f(-11.0f, -8.3f, -20.0f);
				glTexCoord2f(1.0f, 0.0f); glVertex3f( 11.0f, -8.3f, -20.0f);
			glEnd();
			glEnable(GL_BLEND);
			ASSwapBuffers(*_AS->pWindow[iWindow].GethDC(), &_AS->pWindow[iWindow], TRUE);
			_AS->UpdateFPS();
			
			// Check keys:
			if(ASKeyFirst[DIK_F1])
			{ // Open the help file:
				if(_ASConfig->bFullScreen)
				{ // Switch to window mode:
					_ASConfig->bFullScreen = FALSE;
					ChangeDisplayMode();
				}
				OpenHelp();
			}
			if(ASKeyFirst[DIK_F12])
			{ // Open the configuration menu:
				SendMessage(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), WM_COMMAND, ID_OPTIONS_CONFIG, 0);
			}
			if(ASKeyFirst[DIK_ESCAPE])
				break;
		}
	}

	_AS->WriteLogMessage("Video playback stopped");
	if(audio)
	{
		if(lpBuf)
			dxsndCleanupBuffer(&lpBuf, NULL);
		dxsndCleanup();
	}

	CloseAVI();													// Close The AVI File
	
	// Destroy video layer:
	glDeleteTextures(1, &iVideoLayer);

	return msg.wParam;
} // end ASPlayVideo()

void flipIt(void* buffer)										// Flips The Red And Blue Bytes (256x256)
{
	void* b = buffer;											// Pointer To The Buffer
	__asm														// Assembler Code To Follow
	{
		mov ecx, 512*512										// Counter Set To Dimensions Of Our Memory Block
		mov ebx, b												// Points ebx To Our Data (b)
		label:													// Label Used For Looping
			mov al,[ebx+0]										// Loads Value At ebx Into al
			mov ah,[ebx+2]										// Loads Value At ebx+2 Into ah
			mov [ebx+2],al										// Stores Value In al At ebx+2
			mov [ebx+0],ah										// Stores Value In ah At ebx
			
			add ebx,3											// Moves Through The Data By 3 Bytes
			dec ecx												// Decreases Our Loop Counter
			jnz label											// If Not Zero Jump Back To Label
	}
}

void OpenSound(LPCSTR szFile, HWND hWnd)
{
	PAVISTREAM pwav;
	if(AVIStreamOpenFromFile(&pwav,szFile,streamtypeAUDIO,0,OF_READ,NULL)==0){
		if(FAILED(dxsndInitialize(hWnd,1,2,16,44100,0))){
			AVIStreamRelease(pwav);
			return;//init DXSound
		}

		AVISTREAMINFO wavinf;
		AVIStreamInfo(pwav,&wavinf,sizeof(wavinf));
		int audio_len=AVIStreamLength(pwav);

		long bytes,samples;

		long wfxsize=sizeof(WAVEFORMATEX);
		WAVEFORMATEX wfx;

		wfx.cbSize=sizeof(wfx);
		AVIStreamReadFormat(pwav,0,&wfx,&wfxsize);

		audio_len=audio_len*wavinf.dwSampleSize;

		void *audio_ptr=malloc(audio_len);
		AVIStreamRead(pwav,0,audio_len/wavinf.dwSampleSize,audio_ptr,audio_len,&bytes,&samples);

		if(FAILED(dxsndCreateSecondaryBuffer(&lpBuf,NULL,wfx,0,(DWORD)bytes)))
			return;//create our buffer
		dxsndFillBuffer(lpBuf,audio_ptr,bytes);

		free(audio_ptr);

		AVIStreamRelease(pwav);										// Release The Stream

		//we have audio
		audio=1;
	}
}

void OpenAVI(LPCSTR szFile, HWND hWnd)										// Opens An AVI File (szFile)
{
	AVIFileInit();												// Opens The AVIFile Library

	// Opens The AVI Stream
	if (AVIStreamOpenFromFile(&pavi, szFile, streamtypeVIDEO, 0, OF_READ, NULL) !=0)
	{
		// An Error Occurred Opening The Stream
		MessageBox (HWND_DESKTOP, "Failed To Open The AVI Stream", "Error", MB_OK | MB_ICONEXCLAMATION);
	}

	OpenSound(szFile, hWnd);

	AVIStreamInfo(pavi, &psi, sizeof(psi));						// Reads Information About The Stream Into psi
	width=psi.rcFrame.right-psi.rcFrame.left;					// Width Is Right Side Of Frame Minus Left
	height=psi.rcFrame.bottom-psi.rcFrame.top;					// Height Is Bottom Of Frame Minus Top

	lastframe=AVIStreamLength(pavi);							// The Last Frame Of The Stream

	avi_time=AVIStreamSampleToTime(pavi,lastframe);
	avi_ms_per_frame=(float)avi_time/(float)lastframe;

	bmih.biSize = sizeof (BITMAPINFOHEADER);					// Size Of The BitmapInfoHeader
	bmih.biPlanes = 1;											// Bitplanes
	bmih.biBitCount = 24;										// Bits Format We Want (24 Bit, 3 Bytes)
	bmih.biWidth = 512;											// Width We Want (256 Pixels)
	bmih.biHeight = 512;										// Height We Want (256 Pixels)
	bmih.biCompression = BI_RGB;								// Requested Mode = RGB

	hBitmap = CreateDIBSection (hdc, (BITMAPINFO*)(&bmih), DIB_RGB_COLORS, (void**)(&data), NULL, NULL);
	SelectObject (hdc, hBitmap);								// Select hBitmap Into Our Device Context (hdc)

	pgf=AVIStreamGetFrameOpen(pavi, NULL);						// Create The PGETFRAME	Using Our Request Mode
	if (pgf==NULL)
	{
		// An Error Occurred Opening The Frame
		MessageBox (HWND_DESKTOP, "Failed To Open The AVI Frame", "Error", MB_OK | MB_ICONEXCLAMATION);
	}
}

void GrabAVIFrame(int frame)									// Grabs A Frame From The Stream
{
	LPBITMAPINFOHEADER lpbi;									// Holds The Bitmap Header Information
	lpbi = (LPBITMAPINFOHEADER)AVIStreamGetFrame(pgf, frame);	// Grab Data From The AVI Stream
	if(!lpbi)
		return;
	pdata=(char *)lpbi+lpbi->biSize+lpbi->biClrUsed * sizeof(RGBQUAD);	// Pointer To Data Returned By AVIStreamGetFrame

	// Convert Data To Requested Bitmap Format
	DrawDibDraw (hdd, hdc, 0, 0, 512, 512, lpbi, pdata, 0, 0, width, height, 0);

	flipIt(data);												// Swap The Red And Blue Bytes (GL Compatability)

	// Update The Texture
	if(_ASConfig->bFastTexturing)
	{
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
		glTexImage2D(GL_TEXTURE_2D, 0, 3, 512, 512, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
	}
	else
	{
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
		glTexImage2D(GL_TEXTURE_2D, 0, 3, 512, 512, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
	}
}

void CloseAVI(void)												// Properly Closes The Avi File
{
	DeleteObject(hBitmap);										// Delete The Device Dependant Bitmap Object
	DrawDibClose(hdd);											// Closes The DrawDib Device Context
	AVIStreamGetFrameClose(pgf);								// Deallocates The GetFrame Resources
	AVIStreamRelease(pavi);										// Release The Stream
	AVIFileExit();												// Release The File
}
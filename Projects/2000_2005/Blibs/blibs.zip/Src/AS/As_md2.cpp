//-----------------------------------------------------------------------------
// File: AS_MD2.cpp
//-----------------------------------------------------------------------------

#include "AS_Engine.h"


// Functions: *****************************************************************
AS_MD2_MODEL *ASLoadMd2Model(char *);
void ASDrawMd2Frame(AS_MD2_MODEL *, int);
void ASDrawMd2FrameInt(AS_MD2_MODEL *, int, int, float);
void ASPrecomputeMd2FrameInt(AS_MD2_MODEL *, int, int, float);
void ASDrawPrecomputedMd2Frame(AS_MD2_MODEL *);
void ASFreeMd2Model(AS_MD2_MODEL *);
AS_MD2_ANI ASMakeMd2Ani(AS_MD2_MODEL *);
void AS_Md2GenerateLightNormals(AS_MD2_MODEL *);
void AS_Md2_GetBoundingBox(AS_MD2_MODEL *);
void AS_Md2_GetFrameBoundingBox(AS_MD2_MODEL *, int, FLOAT3 (*)[2]);
void AS_Md2_GetCurrentBoundingBox(AS_MD2_MODEL *, int, int, float, FLOAT3 (*)[2]);
void ASGetMd2Vertex(AS_MD2_MODEL *, int, int, float, FLOAT3,
					float, float, float, float,
					int, FLOAT3 *);
BOOL ASRayIntersectMd2(AS_MD2_MODEL *, int, int, float,
					   AS_VECTOR3D, AS_VECTOR3D);
BOOL ASRaySphereIntersectMd2(AS_MD2_MODEL *, int, int, float,
					         AS_VECTOR3D, AS_VECTOR3D, float, FLOAT3 (*)[2]);
///////////////////////////////////////////////////////////////////////////////


AS_MD2_MODEL *ASLoadMd2Model(char *model_name)
{ // begin ASLoadMd2Model()
	FILE *md2file;
	char ver[5];
	int	i, iFrame, iVertex;
	AS_MD2_MODEL *mdl;
	byte buffer[MD2_MAX_FRAMESIZE];
	AS_MD2_FRAME *pFrameT;
	
	mdl = (AS_MD2_MODEL *) malloc(sizeof(AS_MD2_MODEL));
	memset(mdl, 0, sizeof(AS_MD2_MODEL));
	md2file = fopen(model_name, "rb");

	if(md2file == NULL)
		return NULL;
	else
	{
		strcpy(mdl->byFilename, model_name);

		fread(&mdl->header, 1, sizeof(AS_MD2_HEADER), md2file);
		
		sprintf(ver, "%c%c%c%c", mdl->header.magic, mdl->header.magic>>8, mdl->header.magic>>16, mdl->header.magic>>24);

		if(strcmp(ver, "IDP2") || mdl->header.version != 8)
			return NULL;

		fseek(md2file, mdl->header.offsetSkins, SEEK_SET);
		
		mdl->skins = (AS_MD2_SKIN *) malloc(sizeof(AS_MD2_SKIN)*mdl->header.numSkins);
		for(i = 0; i < mdl->header.numSkins; i++)
			fread(&mdl->skins[i], sizeof(AS_MD2_SKIN), 1, md2file);
		
		fseek(md2file, mdl->header.offsetTexCoords, SEEK_SET);

		mdl->texCoords = (AS_MD2_TEXTURE_COORDINATE *) malloc(sizeof(AS_MD2_TEXTURE_COORDINATE) * mdl->header.numTexCoords);
		mdl->texCoord = (FLOAT2 *) malloc(sizeof(FLOAT2) * mdl->header.numTexCoords);
		
		for(i = 0; i < mdl->header.numTexCoords; i++)
		{
			fread(&mdl->texCoords[i], sizeof(AS_MD2_TEXTURE_COORDINATE), 1, md2file);
			mdl->texCoord[i][X] = (float) mdl->texCoords[i].s/mdl->header.skinWidth;
			mdl->texCoord[i][Y] = (float) mdl->texCoords[i].t/mdl->header.skinHeight;
		}
		
		fseek(md2file, mdl->header.offsetTriangles, SEEK_SET);
		
		mdl->triangles = (AS_MD2_TRIANGLE *) malloc(sizeof(AS_MD2_TRIANGLE) * mdl->header.numTriangles);
		
		for(i = 0; i < mdl->header.numTriangles; i++)
			fread(&mdl->triangles[i], sizeof(AS_MD2_TRIANGLE), 1, md2file);
		
		fseek(md2file, mdl->header.offsetFrames, SEEK_SET);
		mdl->prevertex = (FLOAT3 *) malloc(sizeof(FLOAT3)*mdl->header.numVertices);
		mdl->prenormal = (FLOAT3 *) malloc(sizeof(FLOAT3)*mdl->header.numVertices);
		mdl->frames = (AS_MD2_FRAME *) malloc(sizeof(AS_MD2_FRAME) * mdl->header.numFrames);

		for(iFrame = 0; iFrame < mdl->header.numFrames; iFrame++)
		{
			pFrameT = &mdl->frames[iFrame];
			AS_MD2_ALIAS_FRAME *frame = (AS_MD2_ALIAS_FRAME *) buffer;

			pFrameT->vertices = (AS_MD2_TRIANGLE_VERTEX *) malloc(sizeof(AS_MD2_TRIANGLE_VERTEX) * mdl->header.numVertices);
			pFrameT->facenormals = (FLOAT3 *) malloc(sizeof(FLOAT3) * mdl->header.numTriangles);
			pFrameT->vertex = (FLOAT3 *) malloc(sizeof(FLOAT3) * mdl->header.numVertices);
			pFrameT->normal = (FLOAT3 *) malloc(sizeof(FLOAT3) * mdl->header.numVertices);

			fread(frame, 1, mdl->header.frameSize, md2file);
			strcpy(pFrameT->name, frame->name);
			
			// Get the vertices:
			for(iVertex = 0; iVertex < mdl->header.numVertices; iVertex++)
			{
				pFrameT->vertex[iVertex][X] = pFrameT->vertices[iVertex].vertex[0] = (float) ((int) frame->alias_vertices[iVertex].vertex[0]) * frame->scale[0] + frame->translate[0];
				pFrameT->vertex[iVertex][Z] = pFrameT->vertices[iVertex].vertex[2] = -1* ((float) ((int) frame->alias_vertices[iVertex].vertex[1]) * frame->scale[1] + frame->translate[1]);
				pFrameT->vertex[iVertex][Y] = pFrameT->vertices[iVertex].vertex[1] = (float) ((int) frame->alias_vertices[iVertex].vertex[2]) * frame->scale[2] + frame->translate[2];
			}

			// Get the bounding box:
			AS_Md2_GetFrameBoundingBox(mdl, iFrame, &pFrameT->fBoundingBox);
		}

		fseek(md2file, mdl->header.offsetGlCommands, SEEK_SET);

		mdl->glCommandBuffer = (int *) malloc(sizeof(int) * mdl->header.numGlCommands);
		fread(mdl->glCommandBuffer, sizeof(int), mdl->header.numGlCommands, md2file);
		
		fclose(md2file);
	}
	mdl->Ani = ASMakeMd2Ani(mdl);
	AS_Md2GenerateLightNormals(mdl);
	AS_Md2_GetBoundingBox(mdl);
	return mdl;
} // end ASLoadMd2Model()

void ASDrawMd2Frame(AS_MD2_MODEL *model, int frame)
{ // begin ASDrawMd2Frame()
	AS_MD2_FRAME *f = &model->frames[frame];
	FLOAT2 *texCoord;
	AS_MD2_TRIANGLE *t;
	int i;

	glDisableClientState(GL_COLOR_ARRAY);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);
	glEnableClientState(GL_VERTEX_ARRAY);
	glEnableClientState(GL_NORMAL_ARRAY);
	glVertexPointer(3, GL_FLOAT, 0, f->vertex);
	glNormalPointer(GL_FLOAT, 0, f->normal);
	if(_AS->bCompiledVertexArraySupported)
		glLockArraysEXT(0, model->header.numVertices);

	texCoord = model->texCoord;
	glBegin (GL_TRIANGLES);
		for (i = 0; i < model->header.numTriangles; i++)
		{
			t = &model->triangles[i];
			glTexCoord2fv(texCoord[t->textureIndices[0]]);
			glArrayElement(t->vertexIndices[0]);
			glTexCoord2fv(texCoord[t->textureIndices[1]]);
			glArrayElement(t->vertexIndices[1]);
			glTexCoord2fv(texCoord[t->textureIndices[2]]);
			glArrayElement(t->vertexIndices[2]);
		}
	glEnd ();
	if(_AS->bCompiledVertexArraySupported)
		glUnlockArraysEXT();
	_AS->iTriangles += model->header.numTriangles;
} // end ASDrawMd2Frame()

void ASDrawMd2FrameInt(AS_MD2_MODEL *model, int frame1, int frame2, float pol)
{ // begin ASDrawMd2FrameInt()
	AS_MD2_FRAME *f1 = &model->frames[frame1];
	AS_MD2_FRAME *f2 = &model->frames[frame2];
	FLOAT2 *texCoord;
	float x1, y1, z1, x2, y2, z2, *n1, *n2;
	AS_MD2_TRIANGLE *t;
	int i;

	if(frame1 < 0 || frame2 < 0 ||
	   frame1 >= model->header.numFrames || frame2 >= model->header.numFrames)
	   return;

	texCoord = model->texCoord;
	glBegin (GL_TRIANGLES);

	for (i = 0; i < model->header.numTriangles; i++)
	{
		t = &model->triangles[i];
		glTexCoord2fv(texCoord[t->textureIndices[0]]);
		n1 = f1->vertices[t->vertexIndices[0]].normal;
		n2 = f2->vertices[t->vertexIndices[0]].normal;
		glNormal3f((1.0f - pol) * n1[0] + pol * n2[0],
			(1.0f - pol) * n1[1] + pol * n2[1],
			(1.0f - pol) * n1[2] + pol * n2[2]);
		x1 = f1->vertices[t->vertexIndices[0]].vertex[0];
		y1 = f1->vertices[t->vertexIndices[0]].vertex[1];
		z1 = f1->vertices[t->vertexIndices[0]].vertex[2];
		x2 = f2->vertices[t->vertexIndices[0]].vertex[0];
		y2 = f2->vertices[t->vertexIndices[0]].vertex[1];
		z2 = f2->vertices[t->vertexIndices[0]].vertex[2];
		glVertex3f (x1 + pol * (x2 - x1),
			y1 + pol * (y2 - y1),
			z1 + pol * (z2 - z1));

		glTexCoord2fv(texCoord[t->textureIndices[1]]);
		n1 = f1->vertices[t->vertexIndices[1]].normal;
		n2 = f2->vertices[t->vertexIndices[1]].normal;
		glNormal3f ((1.0f - pol) * n1[0] + pol * n2[0],
			(1.0f - pol) * n1[1] + pol * n2[1],
			(1.0f - pol) * n1[2] + pol * n2[2]);
		x1 = f1->vertices[t->vertexIndices[1]].vertex[0];
		y1 = f1->vertices[t->vertexIndices[1]].vertex[1];
		z1 = f1->vertices[t->vertexIndices[1]].vertex[2];
		x2 = f2->vertices[t->vertexIndices[1]].vertex[0];
		y2 = f2->vertices[t->vertexIndices[1]].vertex[1];
		z2 = f2->vertices[t->vertexIndices[1]].vertex[2];
		glVertex3f (x1 + pol * (x2 - x1),
			y1 + pol * (y2 - y1),
			z1 + pol * (z2 - z1));

		glTexCoord2fv(texCoord[t->textureIndices[2]]);
		n1 = f1->vertices[t->vertexIndices[2]].normal;
		n2 = f2->vertices[t->vertexIndices[2]].normal;
		glNormal3f ((1.0f - pol) * n1[0] + pol * n2[0],
			(1.0f - pol) * n1[1] + pol * n2[1],
			(1.0f - pol) * n1[2] + pol * n2[2]);

		x1 = f1->vertices[t->vertexIndices[2]].vertex[0];
		y1 = f1->vertices[t->vertexIndices[2]].vertex[1];
		z1 = f1->vertices[t->vertexIndices[2]].vertex[2];
		x2 = f2->vertices[t->vertexIndices[2]].vertex[0];
		y2 = f2->vertices[t->vertexIndices[2]].vertex[1];
		z2 = f2->vertices[t->vertexIndices[2]].vertex[2];
		glVertex3f (x1 + pol * (x2 - x1),
			y1 + pol * (y2 - y1),
			z1 + pol * (z2 - z1));
	}
	glEnd ();

	_AS->iTriangles += model->header.numTriangles;
} // end ASDrawMd2FrameInt()

void ASPrecomputeMd2FrameInt(AS_MD2_MODEL *model, int frame1, int frame2, float pol)
{ // begin ASPrecomputeMd2FrameInt()
	AS_MD2_FRAME *f1 = &model->frames[frame1];
	AS_MD2_FRAME *f2 = &model->frames[frame2];
	float x1, y1, z1, x2, y2, z2, *n1, *n2;
	int i;

	if(frame1 < 0 || frame2 < 0 ||
	   frame1 >= model->header.numFrames || frame2 >= model->header.numFrames)
	   return;

	for (i = 0; i < model->header.numVertices; i++)
	{
		n1 = f1->vertices[i].normal;
		n2 = f2->vertices[i].normal;
		model->prenormal[i][X] = (1.0f - pol) * n1[0] + pol * n2[0];
		model->prenormal[i][Y] = (1.0f - pol) * n1[1] + pol * n2[1];
		model->prenormal[i][Z] = (1.0f - pol) * n1[2] + pol * n2[2];
		
		x1 = f1->vertices[i].vertex[0];
		y1 = f1->vertices[i].vertex[1];
		z1 = f1->vertices[i].vertex[2];
		x2 = f2->vertices[i].vertex[0];
		y2 = f2->vertices[i].vertex[1];
		z2 = f2->vertices[i].vertex[2];
		model->prevertex[i][X] = x1 + pol * (x2 - x1);
		model->prevertex[i][Y] = y1 + pol * (y2 - y1);
		model->prevertex[i][Z] = z1 + pol * (z2 - z1);
	}
} // end ASPrecomputeMd2FrameInt()

void ASDrawPrecomputedMd2Frame(AS_MD2_MODEL *model)
{ // begin ASDrawPrecomputedMd2Frame()
	vertlist vert_list[64];
	int i, vertnum, index;
	BOOL type;
	int *command;

	glDisableClientState(GL_COLOR_ARRAY);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);
	glEnableClientState(GL_VERTEX_ARRAY);
	glEnableClientState(GL_NORMAL_ARRAY);
	glVertexPointer(3, GL_FLOAT, 0, model->prevertex);
	glNormalPointer(GL_FLOAT, 0, model->prenormal);
	if(_AS->bCompiledVertexArraySupported)
		glLockArraysEXT(0, model->header.numVertices);
	command = model->glCommandBuffer;
	while ((*command) != 0)
	{
		if (*command > 0)
			{vertnum = *command; command++; type = 0;}//triangle strip
		else
			{vertnum = - *command; command++; type = 1;}//triangle fan

		if (vertnum<0) vertnum = -vertnum;

		for (i=0, index = 0;i<vertnum;i++)
		{
			vert_list[index].texcoord[X] = *((float*)command); command++;
			vert_list[index].texcoord[Y] = *((float*)command); command++;
			vert_list[index].i = *command; command++;
			index++;
		}

		if (type==0)
		{
			glBegin(GL_TRIANGLE_STRIP);
			for (i=0;i<index;i++)
			{
				glTexCoord2fv(vert_list[i].texcoord);
				glArrayElement(vert_list[i].i);
			}
			glEnd();
			
		}

		else
		{
			glBegin(GL_TRIANGLE_FAN);
			for (i=0;i<index;i++)
			{
				glTexCoord2fv(vert_list[i].texcoord);
				glArrayElement(vert_list[i].i);
			}
			glEnd();
		}
	}

	if(_AS->bCompiledVertexArraySupported)
		glUnlockArraysEXT();
	_AS->iTriangles += model->header.numTriangles;
} // end ASDrawPrecomputedMd2Frame()

void ASFreeMd2Model(AS_MD2_MODEL *mdl)
{ // begin ASFreeMd2Model()
	if(!mdl)
		return;
	SAFE_FREE(mdl->skins);
	SAFE_FREE(mdl->texCoords);
	SAFE_FREE(mdl->texCoord);
	SAFE_FREE(mdl->triangles);
	SAFE_FREE(mdl->prevertex);
	SAFE_FREE(mdl->prenormal);
	if(mdl->frames)
	{
		for(int i = 0; i < mdl->header.numFrames; i++)
		{
			SAFE_FREE(mdl->frames[i].vertices);
			SAFE_FREE(mdl->frames[i].facenormals);
			SAFE_FREE(mdl->frames[i].vertex);
			SAFE_FREE(mdl->frames[i].normal);
		}
		SAFE_FREE(mdl->frames);
	}

	SAFE_FREE(mdl->glCommandBuffer);
	SAFE_FREE(mdl);
} // end ASFreeMd2Model()

AS_MD2_ANI ASMakeMd2Ani(AS_MD2_MODEL *mdl)
{ // begin ASMakeMd2Ani()
	char	t_st[16], t_name[16], t_last[16];
	int		anim_vector[MD2_MAX_FRAMES];
	int		count_anim, anim_index, t_ln, i;
	AS_MD2_ANI	animation;

	anim_index = 0;
	count_anim = 0;

	for(i = 0; i < MD2_MAX_FRAMES; i++)
		anim_vector[i] = 0;

	memset(animation.anim, 0, sizeof(AS_MD2_ANIMATION)*MD2_MAX_FRAMES);
	strcpy(animation.anim[count_anim].nameAnimation, "all frames");
	animation.anim[count_anim].firstFrame = 0;
	animation.anim[count_anim].lastFrame = mdl->header.numFrames;
	count_anim++;

	strcpy(t_last, "_0_");
	for(i = 0; i < mdl->header.numFrames; i++)
	{
		strcpy(t_st, mdl->frames[i].name);
		t_ln = strlen(t_st);

		t_ln--;
		while(t_st[t_ln] >= '0' && t_st[t_ln] <= '9' || t_st[t_ln] == '_')
			t_ln--;
		t_ln++;

		strncpy(t_name, t_st, t_ln);
		t_name[t_ln] = '\0';

		if(strcmp(t_name, t_last))
		{
			anim_vector[anim_index] = i;
			anim_index++;
				
			strcpy(animation.anim[count_anim].nameAnimation, t_name);
			animation.anim[count_anim].firstFrame = -1;
			animation.anim[count_anim].lastFrame = -1;
			count_anim++;
		}
		
		strcpy(t_last, t_name);
	}

	anim_vector[anim_index] = mdl->header.numFrames;
	anim_index++;

	for(i = 0; i < anim_index; i++)
	{
		animation.anim[i+1].firstFrame = anim_vector[i];
		animation.anim[i+1].lastFrame = anim_vector[i+1];
	}
	
	animation.count_anim = count_anim;

	return animation;
} // end ASMakeMd2Ani()

void AS_Md2GenerateLightNormals(AS_MD2_MODEL *model)
{ // begin AS_Md2GenerateLightNormals()
	int i;
	float l;
	FLOAT3 *fN, fNormalT;
	int k;
	int j;
	AS_MD2_TRIANGLE *t;
	AS_MD2_FRAME *pFrameT;

	if(!model)
		return;

	for (i = 0; i < model->header.numFrames; i++)
	{
		pFrameT = &model->frames[i];

		/* clear all normals */
		for (j = 0; j < model->header.numVertices; j++)
		{
			pFrameT->vertices[j].normal[0] = 0.0f;
			pFrameT->vertices[j].normal[1] = 0.0f;
			pFrameT->vertices[j].normal[2] = 0.0f;
		}

		/* calc normals */
		for (j = 0; j < model->header.numTriangles; j++)
		{
			t = &model->triangles[j];
			NormalizeFace(&fNormalT, pFrameT->vertices[t->vertexIndices[0]].vertex,
									 pFrameT->vertices[t->vertexIndices[2]].vertex,
									 pFrameT->vertices[t->vertexIndices[1]].vertex);
			for (k = 0; k < 3; k++)
			{
				pFrameT->vertices[t->vertexIndices[k]].normal[0] += fNormalT[0];
				pFrameT->vertices[t->vertexIndices[k]].normal[1] += fNormalT[1];
				pFrameT->vertices[t->vertexIndices[k]].normal[2] += fNormalT[2];
			}
		}

		// normalize normals:
		for (j = 0; j < model->header.numVertices; j++)
		{
			fN = &model->frames[i].vertices[j].normal;
			l = ASFastSqrt((*fN)[0]*(*fN)[0]+(*fN)[1]*(*fN)[1]+(*fN)[2]*(*fN)[2]);
			if(l != 0.0f)
			{
				(*fN)[0] /= l;
				(*fN)[1] /= l;
				(*fN)[2] /= l;
			}
			model->frames[i].normal[j][X] = (*fN)[X];
			model->frames[i].normal[j][Y] = (*fN)[Y];
			model->frames[i].normal[j][Z] = (*fN)[Z];
		}
	}
} // end AS_Md2GenerateLightNormals()

void AS_Md2_GetBoundingBox(AS_MD2_MODEL *model)
{ // begin AS_Md2_GetBoundingBox()
	AS_MD2_TRIANGLE_VERTEX *v;
	FLOAT3 min, max;
	float fX, fY, fZ;
	int i, i2;

	for(i2 = 0; i2 < 3; i2++)
	{
		min[i2] = 999999.0f;
		max[i2] = -999999.0f;
	}

	/* get bounding box */
	for (i = 0; i < model->header.numVertices; i++)
	{
		v = &model->frames[0].vertices[i];

		for(i2 = 0; i2 < 3; i2++)
		{
			if(v->vertex[i2] < min[i2])
				model->fBoundingBox[0][i2] = min[i2] = v->vertex[i2];
			else
			if(v->vertex[i2] > max[i2])
				model->fBoundingBox[1][i2] = max[i2] = v->vertex[i2];
		}
	}

	fX = max[X]-min[X];
	if(fX < 0)
		fX = -fX;
	fY = max[Y]-min[Y];
	if(fY < 0)
		fY = -fY;
	fZ = max[Z]-min[Z];
	if(fZ < 0)
		fZ = -fZ;

	model->fBoundigBoxSize = fX;
	if(fY > model->fBoundigBoxSize)
		model->fBoundigBoxSize = fY;
	if(fZ > model->fBoundigBoxSize)
		model->fBoundigBoxSize = fZ;
	model->fBoundigBoxSize /= 2;
} // end AS_Md2_GetBoundingBox()

void AS_Md2_GetFrameBoundingBox(AS_MD2_MODEL *model, int iFrame, FLOAT3 (*fBoundingBox)[2])
{ // begin AS_Md2_GetFrameBoundingBox()
	AS_MD2_TRIANGLE_VERTEX *v;
	int i, i2;

	for(i = 0; i < 3; i++)
	{
		(*fBoundingBox)[0][i] = 999999.0f;
		(*fBoundingBox)[1][i] = -999999.0f;
	}

	/* get bounding box */
	for (i = 0; i < model->header.numVertices; i++)
	{
		v = &model->frames[iFrame].vertices[i];

		for(i2 = 0; i2 < 3; i2++)
		{
			if(v->vertex[i2] < (*fBoundingBox)[0][i2])
				(*fBoundingBox)[0][i2] = v->vertex[i2];
			else
			if(v->vertex[i2] > (*fBoundingBox)[1][i2])
				(*fBoundingBox)[1][i2] = v->vertex[i2];
		}
	}
} // end AS_Md2_GetFrameBoundingBox()

void AS_Md2_GetCurrentBoundingBox(AS_MD2_MODEL *model, int iFrame1, int iFrame2, float fPol, FLOAT3 (*fBoundingBox)[2])
{ // begin AS_Md2_GetCurrentBoundingBox()
	FLOAT3 (*fBB1)[2], (*fBB2)[2];
	int i;

	fBB1 = &model->frames[iFrame1].fBoundingBox;
	fBB2 = &model->frames[iFrame2].fBoundingBox;
	for(i = 0; i < 3; i++)
	{
		(*fBoundingBox)[0][i] = (*fBB1)[0][i]+fPol*((*fBB2)[0][i]-(*fBB1)[0][i]);
		(*fBoundingBox)[1][i] = (*fBB1)[1][i]+fPol*((*fBB2)[1][i]-(*fBB1)[1][i]);
	}
} // end AS_Md2_GetCurrentBoundingBox()

// Get a vertex position of a md2 model:
void ASGetMd2Vertex(AS_MD2_MODEL *model, int frame1, int frame2, float pol, FLOAT3 fPos,
					float fScale, float fXRot, float fYRot, float fZRot,
					int iVertex, FLOAT3 *fRes)
{ // begin ASGetMd2Vertex()
	AS_MD2_FRAME *f1 = &model->frames[frame1];
	AS_MD2_FRAME *f2 = &model->frames[frame2];
	float x1, y1, z1, x2, y2, z2;

	// Calculate the vertex position:
	x1 = f1->vertices[iVertex].vertex[0];
	y1 = f1->vertices[iVertex].vertex[1];
	z1 = f1->vertices[iVertex].vertex[2];
	x2 = f2->vertices[iVertex].vertex[0];
	y2 = f2->vertices[iVertex].vertex[1];
	z2 = f2->vertices[iVertex].vertex[2];
	(*fRes)[X] = (x1+pol*(x2-x1));
	(*fRes)[Y] = (y1+pol*(y2-y1));
	(*fRes)[Z] = (z1+pol*(z2-z1));

	ASRotateVectorX(*fRes, fXRot, fRes);
	ASRotateVectorZ(*fRes, fYRot, fRes);

	(*fRes)[X] *= fScale;
	(*fRes)[Y] *= fScale;
	(*fRes)[Z] *= fScale;

	(*fRes)[X] += fPos[X];
	(*fRes)[Y] += fPos[Y];
	(*fRes)[Z] += fPos[Z];
} // end ASGetMd2Vertex()

BOOL ASRayIntersectMd2(AS_MD2_MODEL *model, int frame1, int frame2, float pol,
					   AS_VECTOR3D vROrigin, AS_VECTOR3D vRNormal)
{ // begin ASRayIntersectMd2()
	AS_MD2_FRAME *f1 = &model->frames[frame1];
	AS_MD2_FRAME *f2 = &model->frames[frame2];
	float fX1, fY1, fZ1, fX2, fY2, fZ2;
	AS_VECTOR3D vP1, vP2, vP3, vV1, vV2, vPOrigin, vPNormal, vPIPoint;
	double dDistToPlaneIntersection;
	AS_MD2_TRIANGLE *t;
	float fDistanceToTravel;
	int i;
	
	// Check if this ray is in the bounding box:
	if(!ASCheckLineInBox(vROrigin, vROrigin+vRNormal, model->fBoundingBox))
		return FALSE; // No intersection:
	
	// Check ray/mesh intersection:
	fDistanceToTravel = vRNormal.GetLength();
	vRNormal.Normalize();
	for(i = 0; i < model->header.numTriangles; i++)
	{
		t = &model->triangles[i];
		
		// Get current vertices:
		// Vertex 1:
		fX1 = f1->vertices[t->vertexIndices[0]].vertex[X];
		fY1 = f1->vertices[t->vertexIndices[0]].vertex[Y];
		fZ1 = f1->vertices[t->vertexIndices[0]].vertex[Z];
		fX2 = f2->vertices[t->vertexIndices[0]].vertex[X];
		fY2 = f2->vertices[t->vertexIndices[0]].vertex[Y];
		fZ2 = f2->vertices[t->vertexIndices[0]].vertex[Z];
		vP1.fX = fX1+pol*(fX2-fX1);
		vP1.fY = fY1+pol*(fY2-fY1);
		vP1.fZ = fZ1+pol*(fZ2-fZ1);

		// Vertex 2:
		fX1 = f1->vertices[t->vertexIndices[1]].vertex[X];
		fY1 = f1->vertices[t->vertexIndices[1]].vertex[Y];
		fZ1 = f1->vertices[t->vertexIndices[1]].vertex[Z];
		fX2 = f2->vertices[t->vertexIndices[1]].vertex[X];
		fY2 = f2->vertices[t->vertexIndices[1]].vertex[Y];
		fZ2 = f2->vertices[t->vertexIndices[1]].vertex[Z];
		vP2.fX = fX1+pol*(fX2-fX1);
		vP2.fY = fY1+pol*(fY2-fY1);
		vP2.fZ = fZ1+pol*(fZ2-fZ1);

		// Vertex 3:
		fX1 = f1->vertices[t->vertexIndices[2]].vertex[X];
		fY1 = f1->vertices[t->vertexIndices[2]].vertex[Y];
		fZ1 = f1->vertices[t->vertexIndices[2]].vertex[Z];
		fX2 = f2->vertices[t->vertexIndices[2]].vertex[X];
		fY2 = f2->vertices[t->vertexIndices[2]].vertex[Y];
		fZ2 = f2->vertices[t->vertexIndices[2]].vertex[Z];
		vP3.fX = fX1+pol*(fX2-fX1);
		vP3.fY = fY1+pol*(fY2-fY1);
		vP3.fZ = fZ1+pol*(fZ2-fZ1);

		// Make the plane containing this triangle:
		vPOrigin = vP1;
		vV1 = vP2-vP1;
		vV2 = vP3-vP1;

		// Determine normal to plane containing polygon:
		vPNormal = vV1.CrossProduct(vV2);
		vPNormal.Normalize();

		// Find plane intersection point:
		dDistToPlaneIntersection = ASIntersectRayPlane(vROrigin, vRNormal, vPOrigin, vPNormal);
		if(dDistToPlaneIntersection < AS_EPSILON || dDistToPlaneIntersection > fDistanceToTravel)
			continue; // No intersection!

		// Calculate plane intersection point:
		vPIPoint.fX = (float) (vROrigin.fX+dDistToPlaneIntersection*vRNormal.fX); 
		vPIPoint.fY = (float) (vROrigin.fY+dDistToPlaneIntersection*vRNormal.fY); 
		vPIPoint.fZ = (float) (vROrigin.fZ+dDistToPlaneIntersection*vRNormal.fZ); 	
		
		// Check if the plane intersection point is in the triangle:
		if(ASCheckPointInTriangle(vPIPoint, vPNormal, vP1, vP2, vP3))
			return TRUE; // We found an intersection!
	}
	return FALSE;
} // end ASRayIntersectMd2()

BOOL ASRaySphereIntersectMd2(AS_MD2_MODEL *model, int frame1, int frame2, float pol,
					   AS_VECTOR3D vROrigin, AS_VECTOR3D vRNormal, float fSRadius, FLOAT3 (*fBoundingBox)[2])
{ // begin ASRaySphereIntersectMd2()
	AS_MD2_FRAME *f1 = &model->frames[frame1];
	AS_MD2_FRAME *f2 = &model->frames[frame2];
	float fX1, fY1, fZ1, fX2, fY2, fZ2;
	AS_VECTOR3D vP1, vP2, vP3, vV1, vV2, vPOrigin, vPNormal, vPIPoint,
				 vSIPoint, vPolyIPoint;
	double dDistToPlaneIntersection, dDistToEllipsoidIntersection;
	AS_MD2_TRIANGLE *t;
	float fDistanceToTravel;
	int i;
	
	// Check if this ray is in the bounding box:
	if(!ASCheckLineInBox(vROrigin, vROrigin+vRNormal, *fBoundingBox))
		return FALSE; // No intersection:

	return TRUE; // No intersection:

	// Check ray/mesh intersection:
	vROrigin /= fSRadius;
	vRNormal /= fSRadius;
	fDistanceToTravel = vRNormal.GetLength();
	vRNormal.Normalize();
	for(i = 0; i < model->header.numTriangles; i++)
	{
		t = &model->triangles[i];
		
		// Get current vertices:
		// Vertex 1:
		fX1 = f1->vertices[t->vertexIndices[0]].vertex[X];
		fY1 = f1->vertices[t->vertexIndices[0]].vertex[Y];
		fZ1 = f1->vertices[t->vertexIndices[0]].vertex[Z];
		fX2 = f2->vertices[t->vertexIndices[0]].vertex[X];
		fY2 = f2->vertices[t->vertexIndices[0]].vertex[Y];
		fZ2 = f2->vertices[t->vertexIndices[0]].vertex[Z];
		vP1.fX = fX1+pol*(fX2-fX1);
		vP1.fY = fY1+pol*(fY2-fY1);
		vP1.fZ = fZ1+pol*(fZ2-fZ1);

		// Vertex 2:
		fX1 = f1->vertices[t->vertexIndices[1]].vertex[X];
		fY1 = f1->vertices[t->vertexIndices[1]].vertex[Y];
		fZ1 = f1->vertices[t->vertexIndices[1]].vertex[Z];
		fX2 = f2->vertices[t->vertexIndices[1]].vertex[X];
		fY2 = f2->vertices[t->vertexIndices[1]].vertex[Y];
		fZ2 = f2->vertices[t->vertexIndices[1]].vertex[Z];
		vP2.fX = fX1+pol*(fX2-fX1);
		vP2.fY = fY1+pol*(fY2-fY1);
		vP2.fZ = fZ1+pol*(fZ2-fZ1);

		// Vertex 3:
		fX1 = f1->vertices[t->vertexIndices[2]].vertex[X];
		fY1 = f1->vertices[t->vertexIndices[2]].vertex[Y];
		fZ1 = f1->vertices[t->vertexIndices[2]].vertex[Z];
		fX2 = f2->vertices[t->vertexIndices[2]].vertex[X];
		fY2 = f2->vertices[t->vertexIndices[2]].vertex[Y];
		fZ2 = f2->vertices[t->vertexIndices[2]].vertex[Z];
		vP3.fX = fX1+pol*(fX2-fX1);
		vP3.fY = fY1+pol*(fY2-fY1);
		vP3.fZ = fZ1+pol*(fZ2-fZ1);

		// Scale vector system:
		vP1 /= fSRadius;
		vP2 /= fSRadius;
		vP3 /= fSRadius;
		
		// Make the plane containing this triangle:
		vPOrigin = vP1;
		vV1 = vP2-vP1;
		vV2 = vP3-vP1;

		// Determine normal to plane containing polygon:
		vPNormal = vV1.CrossProduct(vV2);
		vPNormal.Normalize();

		// Calculate sphere intersection point:
		vSIPoint = vROrigin-vPNormal;     

		// Classify point to determine if ellipsoid span the plane:
		DWORD pClass = ASClassifyPoint(vSIPoint, vPOrigin, vPNormal);

		// Find the plane intersection point:
		if(pClass == PLANE_BACKSIDE)
		{ // Plane is embedded in ellipsoid:
			// Find plane intersection point by shooting a ray from the 
			// sphere intersection point along the planes normal:
			dDistToPlaneIntersection = ASIntersectRayPlane(vSIPoint, vPNormal, vPOrigin, vPNormal);

			// Calculate plane intersection point:
			vPIPoint.fX = (float) (vSIPoint.fX+dDistToPlaneIntersection*vPNormal.fX); 
			vPIPoint.fY = (float) (vSIPoint.fY+dDistToPlaneIntersection*vPNormal.fY); 
			vPIPoint.fZ = (float) (vSIPoint.fZ+dDistToPlaneIntersection*vPNormal.fZ);
		} 
		else
		{
			// Shoot ray along the velocity vector:
			dDistToPlaneIntersection = ASIntersectRayPlane(vSIPoint, vRNormal, vPOrigin, vPNormal);

			if(dDistToPlaneIntersection < AS_EPSILON && dDistToPlaneIntersection > 0.0f)
				dDistToPlaneIntersection = dDistToPlaneIntersection;
			// Calculate plane intersection point:
			vPIPoint.fX = (float) (vSIPoint.fX+dDistToPlaneIntersection*vRNormal.fX);
			vPIPoint.fY = (float) (vSIPoint.fY+dDistToPlaneIntersection*vRNormal.fY);
			vPIPoint.fZ = (float) (vSIPoint.fZ+dDistToPlaneIntersection*vRNormal.fZ);
		}

		// Find polygon intersection point. By default we assume its equal to the 
		// plane intersection point:
		vPolyIPoint = vPIPoint;
		dDistToEllipsoidIntersection = dDistToPlaneIntersection;

		if(!ASCheckPointInTriangle(vPIPoint, vPNormal, vP1, vP2, vP3))
		{ // If not in triangle:
			vPolyIPoint = ASClosestPointOnTriangle(vP1, vP2, vP3, vPIPoint);	
			dDistToEllipsoidIntersection = ASIntersectRaySphere(vPolyIPoint, -vRNormal, vROrigin, 1.0f);

			if(dDistToEllipsoidIntersection > 0)
			{ // Calculate true sphere intersection point:
     			vSIPoint.fX = (float) (vPolyIPoint.fX+dDistToEllipsoidIntersection*(-vRNormal.fX));
     			vSIPoint.fY = (float) (vPolyIPoint.fY+dDistToEllipsoidIntersection*(-vRNormal.fY));
     			vSIPoint.fZ = (float) (vPolyIPoint.fZ+dDistToEllipsoidIntersection*(-vRNormal.fZ));
			}
		} 

		// Do we hit something?
		if(ASCheckPointInSphere(vPolyIPoint, vROrigin, 1.0f) ||
		  (dDistToEllipsoidIntersection > 0) && (dDistToEllipsoidIntersection <= fDistanceToTravel))
			return TRUE; // We found an intersection!
	}
	return FALSE;
} // end ASRaySphereIntersectMd2()
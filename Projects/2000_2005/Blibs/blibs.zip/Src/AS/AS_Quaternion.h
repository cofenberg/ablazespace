//-----------------------------------------------------------------------------
// File: AS_Quaternion.h
//-----------------------------------------------------------------------------

#ifndef __AS_QUATERNION_H_
#define __AS_QUATERNION_H_


// Classes: *******************************************************************
typedef class AS_QUATERNION
{
	public:
		union
		{
			float fQ[4];
			struct
			{
				float w, x, y, z;
			};
			struct
			{
				float fW, fX, fY, fZ;
			};
		};


		// Assignment operators:
		AS_QUATERNION operator+(const AS_QUATERNION Q)
		{ return AS_QUATERNION(fX+Q.fX, fY+Q.fY, fZ+Q.fZ); }
		AS_QUATERNION operator*(float f)
		{ return AS_QUATERNION(fX*f, fY*f, fZ*f); }
		AS_QUATERNION operator*(AS_QUATERNION Q)
		{ return AS_QUATERNION(fX*Q.fX, fY*Q.fY, fZ*Q.fZ); }

		// Constructor:
		AS_QUATERNION(void);
		AS_QUATERNION(const AS_QUATERNION &);
		AS_QUATERNION(float, float, float);
		AS_QUATERNION(float, float, float, float);

		// Misc:
		AS_QUATERNION &Reset(void);
		AS_QUATERNION &Set(const AS_QUATERNION &);
		AS_QUATERNION &Set(float, float, float);
		AS_QUATERNION &Set(float, float, float, float);
		AS_QUATERNION &PostMult(const AS_QUATERNION &);
		AS_QUATERNION &MultAndSet(const AS_QUATERNION &, const AS_QUATERNION &);
		AS_QUATERNION &Normalize(void);
		AS_QUATERNION Inversed(void);
		float DotProduct(void);
		float DotProduct(AS_QUATERNION);
		float GetLength(void);
		void GetMatrix(AS_MATRIX *);
		void GetInvertedMatrix(AS_MATRIX *);
		void SetMatrix(AS_MATRIX);
		void GetAxisAngle(float &, float &, float &, float &);
		void GetDirectionVector(AS_VECTOR3D *);
		void EulerToQuat(const float, const float, const float);
		void GetEulerAngles(float &, float &, float &);
		void Slerp(const AS_QUATERNION, const AS_QUATERNION, const float);
		void SquadSlerp(AS_QUATERNION, AS_QUATERNION, AS_QUATERNION, AS_QUATERNION, float);
		void Invert(void);
		void Mult(AS_QUATERNION, AS_QUATERNION);
		void Ln(void);
		void LnDif(AS_QUATERNION, AS_QUATERNION);
		void Exp(void);
		void InnerPoint(AS_QUATERNION, AS_QUATERNION, AS_QUATERNION);

} AS_QUATERNION;
///////////////////////////////////////////////////////////////////////////////


#endif	// __AS_QUATERNION_H_
// The most frustum culling code was taken from Mark Morleys frustrum culling tutorial.
// His Tutorial could be found at:
// http://www.markmorley.com/opengl/frustumculling.html

#include "AS_Engine.h"


// Functions: *****************************************************************
void ASExtractFrustum(void);
bool ASPointInFrustum(float, float, float);
bool SphereInFrustum(float, float, float, float);
bool CubeInFrustum(float, float, float, float);
bool ASCubeInFrustum(float, float, float, float, float, float);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
float ASFrustum[6][4];		// Holds The Current Frustum Plane Equations
int iCulledObjects;
///////////////////////////////////////////////////////////////////////////////


void ASExtractFrustum(void)									// Extracts The Current View Frustum Plane Equations
{ // begin ASExtractFrustum()
	iCulledObjects = 0;

	if(!_ASConfig->bFrustumCulling)
		return;

	float proj[16],									// For Grabbing The PROJECTION Matrix
		  modl[16],									// For Grabbing The MODELVIEW Matrix
		  clip[16],									// Result Of Concatenating PROJECTION and MODELVIEW
		  t;										// Temporary Work Variable
	
	glGetFloatv( GL_PROJECTION_MATRIX, proj );			// Grab The Current PROJECTION Matrix
	glGetFloatv( GL_MODELVIEW_MATRIX, modl );			// Grab The Current MODELVIEW Matrix

	// Concatenate (Multiply) The Two Matricies
	clip[ 0] = modl[ 0] * proj[ 0] + modl[ 1] * proj[ 4] + modl[ 2] * proj[ 8] + modl[ 3] * proj[12];
	clip[ 1] = modl[ 0] * proj[ 1] + modl[ 1] * proj[ 5] + modl[ 2] * proj[ 9] + modl[ 3] * proj[13];
	clip[ 2] = modl[ 0] * proj[ 2] + modl[ 1] * proj[ 6] + modl[ 2] * proj[10] + modl[ 3] * proj[14];
	clip[ 3] = modl[ 0] * proj[ 3] + modl[ 1] * proj[ 7] + modl[ 2] * proj[11] + modl[ 3] * proj[15];

	clip[ 4] = modl[ 4] * proj[ 0] + modl[ 5] * proj[ 4] + modl[ 6] * proj[ 8] + modl[ 7] * proj[12];
	clip[ 5] = modl[ 4] * proj[ 1] + modl[ 5] * proj[ 5] + modl[ 6] * proj[ 9] + modl[ 7] * proj[13];
	clip[ 6] = modl[ 4] * proj[ 2] + modl[ 5] * proj[ 6] + modl[ 6] * proj[10] + modl[ 7] * proj[14];
	clip[ 7] = modl[ 4] * proj[ 3] + modl[ 5] * proj[ 7] + modl[ 6] * proj[11] + modl[ 7] * proj[15];

	clip[ 8] = modl[ 8] * proj[ 0] + modl[ 9] * proj[ 4] + modl[10] * proj[ 8] + modl[11] * proj[12];
	clip[ 9] = modl[ 8] * proj[ 1] + modl[ 9] * proj[ 5] + modl[10] * proj[ 9] + modl[11] * proj[13];
	clip[10] = modl[ 8] * proj[ 2] + modl[ 9] * proj[ 6] + modl[10] * proj[10] + modl[11] * proj[14];
	clip[11] = modl[ 8] * proj[ 3] + modl[ 9] * proj[ 7] + modl[10] * proj[11] + modl[11] * proj[15];

	clip[12] = modl[12] * proj[ 0] + modl[13] * proj[ 4] + modl[14] * proj[ 8] + modl[15] * proj[12];
	clip[13] = modl[12] * proj[ 1] + modl[13] * proj[ 5] + modl[14] * proj[ 9] + modl[15] * proj[13];
	clip[14] = modl[12] * proj[ 2] + modl[13] * proj[ 6] + modl[14] * proj[10] + modl[15] * proj[14];
	clip[15] = modl[12] * proj[ 3] + modl[13] * proj[ 7] + modl[14] * proj[11] + modl[15] * proj[15];


	// Extract the RIGHT clipping plane
	ASFrustum[0][0] = clip[ 3] - clip[ 0];
	ASFrustum[0][1] = clip[ 7] - clip[ 4];
	ASFrustum[0][2] = clip[11] - clip[ 8];
	ASFrustum[0][3] = clip[15] - clip[12];

	// Normalize it
	t = ASFastSqrt( ASFrustum[0][0] * ASFrustum[0][0] + ASFrustum[0][1] * ASFrustum[0][1] + ASFrustum[0][2] * ASFrustum[0][2] );
	ASFrustum[0][0] /= t;
	ASFrustum[0][1] /= t;
	ASFrustum[0][2] /= t;
	ASFrustum[0][3] /= t;


	// Extract the LEFT clipping plane
	ASFrustum[1][0] = clip[ 3] + clip[ 0];
	ASFrustum[1][1] = clip[ 7] + clip[ 4];
	ASFrustum[1][2] = clip[11] + clip[ 8];
	ASFrustum[1][3] = clip[15] + clip[12];

	// Normalize it
	t = ASFastSqrt( ASFrustum[1][0] * ASFrustum[1][0] + ASFrustum[1][1] * ASFrustum[1][1] + ASFrustum[1][2] * ASFrustum[1][2] );
	ASFrustum[1][0] /= t;
	ASFrustum[1][1] /= t;
	ASFrustum[1][2] /= t;
	ASFrustum[1][3] /= t;


	// Extract the BOTTOM clipping plane
	ASFrustum[2][0] = clip[ 3] + clip[ 1];
	ASFrustum[2][1] = clip[ 7] + clip[ 5];
	ASFrustum[2][2] = clip[11] + clip[ 9];
	ASFrustum[2][3] = clip[15] + clip[13];

	// Normalize it
	t = ASFastSqrt( ASFrustum[2][0] * ASFrustum[2][0] + ASFrustum[2][1] * ASFrustum[2][1] + ASFrustum[2][2] * ASFrustum[2][2] );
	ASFrustum[2][0] /= t;
	ASFrustum[2][1] /= t;
	ASFrustum[2][2] /= t;
	ASFrustum[2][3] /= t;


	// Extract the TOP clipping plane
	ASFrustum[3][0] = clip[ 3] - clip[ 1];
	ASFrustum[3][1] = clip[ 7] - clip[ 5];
	ASFrustum[3][2] = clip[11] - clip[ 9];
	ASFrustum[3][3] = clip[15] - clip[13];

	// Normalize it
	t = ASFastSqrt( ASFrustum[3][0] * ASFrustum[3][0] + ASFrustum[3][1] * ASFrustum[3][1] + ASFrustum[3][2] * ASFrustum[3][2] );
	ASFrustum[3][0] /= t;
	ASFrustum[3][1] /= t;
	ASFrustum[3][2] /= t;
	ASFrustum[3][3] /= t;


	// Extract the FAR clipping plane
	ASFrustum[4][0] = clip[ 3] - clip[ 2];
	ASFrustum[4][1] = clip[ 7] - clip[ 6];
	ASFrustum[4][2] = clip[11] - clip[10];
	ASFrustum[4][3] = clip[15] - clip[14];

	// Normalize it
	t = ASFastSqrt( ASFrustum[4][0] * ASFrustum[4][0] + ASFrustum[4][1] * ASFrustum[4][1] + ASFrustum[4][2] * ASFrustum[4][2] );
	ASFrustum[4][0] /= t;
	ASFrustum[4][1] /= t;
	ASFrustum[4][2] /= t;
	ASFrustum[4][3] /= t;


	// Extract the NEAR clipping plane.  This is last on purpose (see pointinASFrustum() for reason)
	ASFrustum[5][0] = clip[ 3] + clip[ 2];
	ASFrustum[5][1] = clip[ 7] + clip[ 6];
	ASFrustum[5][2] = clip[11] + clip[10];
	ASFrustum[5][3] = clip[15] + clip[14];

	// Normalize it
	t = ASFastSqrt( ASFrustum[5][0] * ASFrustum[5][0] + ASFrustum[5][1] * ASFrustum[5][1] + ASFrustum[5][2] * ASFrustum[5][2] );
	ASFrustum[5][0] /= t;
	ASFrustum[5][1] /= t;
	ASFrustum[5][2] /= t;
	ASFrustum[5][3] /= t;
} // end ASExtractFrustum()

// Test If A Point Is In The Frustum.
bool ASPointInFrustum( float x, float y, float z )
{ // begin ASPointInFrustum()
	if(!_ASConfig->bFrustumCulling)
		return true;

	for(int p = 0; p < 6; p++ )
		if( ASFrustum[p][0] * x + ASFrustum[p][1] * y + ASFrustum[p][2] * z + ASFrustum[p][3] <= 0 )
		{
			iCulledObjects++;
			return false;
		}
	return true;
} // end ASPointInFrustum()

// Test If A Sphere Is In The Frustum
bool SphereInFrustum( float x, float y, float z, float radius )
{ // begin SphereInFrustum()
	if(!_ASConfig->bFrustumCulling)
		return true;

	for(int p = 0; p < 6; p++ )
		if( ASFrustum[p][0] * x + ASFrustum[p][1] * y + ASFrustum[p][2] * z + ASFrustum[p][3] <= -radius )
		{
			iCulledObjects++;
			return false;
		}
	return true;
} // end SphereInFrustum()

// Test If A Cube Is In The Frustum
bool CubeInFrustum( float x, float y, float z, float size )
{ // begin CubeInFrustum()
	if(!_ASConfig->bFrustumCulling)
		return true;

	for(int p = 0; p < 6; p++ )
	{
		if( ASFrustum[p][0] * (x - size) + ASFrustum[p][1] * (y - size) + ASFrustum[p][2] * (z - size) + ASFrustum[p][3] > 0 )
			continue;
		if( ASFrustum[p][0] * (x + size) + ASFrustum[p][1] * (y - size) + ASFrustum[p][2] * (z - size) + ASFrustum[p][3] > 0 )
			continue;
		if( ASFrustum[p][0] * (x - size) + ASFrustum[p][1] * (y + size) + ASFrustum[p][2] * (z - size) + ASFrustum[p][3] > 0 )
			continue;
		if( ASFrustum[p][0] * (x + size) + ASFrustum[p][1] * (y + size) + ASFrustum[p][2] * (z - size) + ASFrustum[p][3] > 0 )
			continue;
		if( ASFrustum[p][0] * (x - size) + ASFrustum[p][1] * (y - size) + ASFrustum[p][2] * (z + size) + ASFrustum[p][3] > 0 )
			continue;
		if( ASFrustum[p][0] * (x + size) + ASFrustum[p][1] * (y - size) + ASFrustum[p][2] * (z + size) + ASFrustum[p][3] > 0 )
			continue;
		if( ASFrustum[p][0] * (x - size) + ASFrustum[p][1] * (y + size) + ASFrustum[p][2] * (z + size) + ASFrustum[p][3] > 0 )
			continue;
		if( ASFrustum[p][0] * (x + size) + ASFrustum[p][1] * (y + size) + ASFrustum[p][2] * (z + size) + ASFrustum[p][3] > 0 )
			continue;
		iCulledObjects++;
		return false;
	}
	return true;
} // end CubeInFrustum()

bool ASCubeInFrustum(float fXMin, float fXMax, float fYMin, float fYMax, float fZMin, float fZMax)
{ // begin ASCubeInFrustum()
	if(!_ASConfig->bFrustumCulling)
		return true;

	for(int p = 0; p < 6; p++ )
	{
		if( ASFrustum[p][0] * fXMin + ASFrustum[p][1] * fYMin + ASFrustum[p][2] * fZMin + ASFrustum[p][3] > 0 )
			continue;
		if( ASFrustum[p][0] * fXMax + ASFrustum[p][1] * fYMin + ASFrustum[p][2] * fZMin + ASFrustum[p][3] > 0 )
			continue;
		if( ASFrustum[p][0] * fXMin + ASFrustum[p][1] * fYMax + ASFrustum[p][2] * fZMin + ASFrustum[p][3] > 0 )
			continue;
		if( ASFrustum[p][0] * fXMax + ASFrustum[p][1] * fYMax + ASFrustum[p][2] * fZMin + ASFrustum[p][3] > 0 )
			continue;
		if( ASFrustum[p][0] * fXMin + ASFrustum[p][1] * fYMin + ASFrustum[p][2] * fZMax + ASFrustum[p][3] > 0 )
			continue;
		if( ASFrustum[p][0] * fXMax + ASFrustum[p][1] * fYMin + ASFrustum[p][2] * fZMax + ASFrustum[p][3] > 0 )
			continue;
		if( ASFrustum[p][0] * fXMin + ASFrustum[p][1] * fYMax + ASFrustum[p][2] * fZMax + ASFrustum[p][3] > 0 )
			continue;
		if( ASFrustum[p][0] * fXMax + ASFrustum[p][1] * fYMax + ASFrustum[p][2] * fZMax + ASFrustum[p][3] > 0 )
			continue;
		iCulledObjects++;
		return false;
	}
	return true;
} // end ASCubeInFrustum()
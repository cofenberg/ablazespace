#ifndef __AS_MATH_H__
#define __AS_MATH_H__


#define M_PI_2 1.57079632679489661923
#define DEG_TO_RAD 0.0174532925199432957692369076848861
#define RAD_TO_DEG 57.29577951
#define AS_EPSILON 1e-12
#define EPSILON 0.05f
#define PLANE_BACKSIDE 0x000001
#define PLANE_FRONT    0x000010
#define ON_PLANE       0x000100


typedef union FastSqrtUnion
{
  float f;
  unsigned int i;
} FastSqrtUnion;


#define AS_ABS(a)    (a >= 0 ? a : -a) 
#define AS_MAX(a, b) (a > b ? a : b)

#define FP_BITS(fp) (*(DWORD *)&(fp))
#define FP_ABS_BITS(fp) (FP_BITS(fp)&0x7FFFFFFF)
#define FP_SIGN_BIT(fp) (FP_BITS(fp)&0x80000000)
#define FP_ONE_BITS 0x3F800000


// r = 1/p
#define FP_INV(r,p)                                                          \
{                                                                            \
    int _i = 2 * FP_ONE_BITS - *(int *)&(p);                                 \
    r = *(float *)&_i;                                                       \
    r = r * (2.0f - (p) * r);                                                \
}

extern float   two;

#define FP_INV2(r,p)                     \
{                                        \
    __asm { mov     eax,0x7F000000    }; \
    __asm { sub     eax,dword ptr [p] }; \
    __asm { mov     dword ptr [r],eax }; \
    __asm { fld     dword ptr [p]     }; \
    __asm { fmul    dword ptr [r]     }; \
    __asm { fsubr   [two]             }; \
    __asm { fmul    dword ptr [r]     }; \
    __asm { fstp    dword ptr [r]     }; \
}

/////////////////////////////////////////////////


#define FP_EXP(e,p)                                                          \
{                                                                            \
    int _i;                                                                  \
    e = -1.44269504f * (float)0x00800000 * (p);                              \
    _i = (int)e + 0x3F800000;                                                \
    e = *(float *)&_i;                                                       \
}

#define FP_NORM_TO_BYTE(i,p)                                                 \
{                                                                            \
    float _n = (p) + 1.0f;                                                   \
    i = *(int *)&_n;                                                         \
    if (i >= 0x40000000)     i = 0xFF;                                       \
    else if (i <=0x3F800000) i = 0;                                          \
    else i = ((i) >> 15) & 0xFF;                                             \
}


// Variables: *****************************************************************
extern unsigned int ASFastSqrtTable[0x10000]; // Declare table of square roots
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern void ASBuildSqrtTable(void);
extern void ASAddVec(FLOAT3, FLOAT3, FLOAT3 *);
extern void ASSubVec(FLOAT3, FLOAT3, FLOAT3 *);
extern void ASMulVec(FLOAT3, FLOAT3, FLOAT3 *);
extern void ASScaleVec(FLOAT3, float, FLOAT3 *);
extern void ASInvertVec(FLOAT3, FLOAT3 *);
extern void ASRotateVectorX(FLOAT3, float, FLOAT3 *);
extern void ASRotateVectorY(FLOAT3, float, FLOAT3 *);
extern void ASRotateVectorZ(FLOAT3, float, FLOAT3 *);
extern void ASCatmullRom(AS_CAMERA *, AS_CAMERA *, AS_CAMERA *, AS_CAMERA *, float, AS_CAMERA *);
///////////////////////////////////////////////////////////////////////////////

inline unsigned long FP_NORM_TO_BYTE2(float p)                                                 
{                                                                            
  float fpTmp = p + 1.0f;                                                      
  return ((*(unsigned *)&fpTmp) >> 15) & 0xFF;  
}

inline unsigned long FP_NORM_TO_BYTE3(float p)     
{
  float ftmp = p + 12582912.0f;                                                      
  return ((*(unsigned long *)&ftmp) & 0xFF);
}

inline float ASFastSqrt(float n)
{ // begin ASFastSqrt()
	if(!FP_BITS(n))
		return 0.0; // Check for square root of 0

	FP_BITS(n) = ASFastSqrtTable[(FP_BITS(n) >> 8) & 0xFFFF] | ((((FP_BITS(n) - 0x3F800000) >> 1) + 0x3F800000) & 0x7F800000);

	return n;
} // end ASFastSqrt()

inline void ASLimitMinMax(float f, float fMin, float fMax)
{ // begin ASGetLengthOfVector()
	if(f < fMin)
		f = fMin;
	if(f > fMax)
		f = fMax;
} // end ASLimitMinMax()
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_MATH_H__
//-----------------------------------------------------------------------------
// File: AS_LightAndShadow.cpp
//-----------------------------------------------------------------------------

#include "AS_Engine.h"


AS_DLIGHT::AS_DLIGHT(void)
{ // begin AS_DLIGHT::AS_DLIGHT()
	fRadius = 3.0f;
	fDensity = 1.0f;
	vColor.fX = 1.0f;
	vColor.fY = 1.0f;
	vColor.fZ = 1.0f;
} // end  AS_DLIGHT::AS_DLIGHT()

AS_DLIGHT::~AS_DLIGHT(void)
{ // begin AS_DLIGHT::~AS_DLIGHT()
} // end AS_DLIGHT::~AS_DLIGHT()

void AS_DLIGHT::Light(AS_VECTOR3D vV1, AS_VECTOR3D vV2, AS_VECTOR3D vV3,
					  AS_VECTOR3D vRight, AS_VECTOR3D vUp, AS_PLANE Plane,
					  BOOL bUseBrightness)
{ // begin AS_DLIGHT::Light()
	float fDis, fBrightness, fScale;
    AS_VECTOR3D vNearest, vVerNear;

	fDis = AS_ABS(Plane.DistanceToPlane(vPos));
	if(fDis > fRadius*2)
		return; // Too far: don't light the polygon:

	// Nearest point to plane:
	vPos.ProjectPlane(vRight, vUp, vNearest);

//	if(((vPos-vV1).DotProduct(Plane.vN)) > 0.0)
//		return;

	// Intense is dependable on distance:
	fBrightness = (1.0f-(fDis/fRadius));
	fScale = 1.0f/(fRadius*2.0f-fDis);
	if(bUseBrightness)
		glColor4f(vColor.fX*fBrightness, vColor.fY*fBrightness,
				  vColor.fZ*fBrightness, fDensity);
	else
		glColor4f(vColor.fX, vColor.fY, vColor.fZ, fDensity);

	// Vector from polygons vertex to nearest point:
	vVerNear = vV1-vNearest;
	glTexCoord2f((float) (vVerNear.DotProduct(vRight*fScale)+0.5f), (float) (vVerNear.DotProduct(vUp*fScale)+0.5f));
	glVertex3fv(vV1.fV);

	vVerNear = vV2-vNearest;
	glTexCoord2f((float) (vVerNear.DotProduct(vRight*fScale)+0.5f), (float) (vVerNear.DotProduct(vUp*fScale)+0.5f));
	glVertex3fv(vV2.fV);

	vVerNear = vV3-vNearest;
	glTexCoord2f((float) (vVerNear.DotProduct(vRight*fScale)+0.5f), (float) (vVerNear.DotProduct(vUp*fScale)+0.5f));
	glVertex3fv(vV3.fV);

	_AS->iTriangles++;
} // end AS_DLIGHT::Light()
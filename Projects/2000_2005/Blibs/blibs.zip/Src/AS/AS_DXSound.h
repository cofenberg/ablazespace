#include "windows.h"
#include <mmsystem.h>
#include <mmreg.h>

#include "dsound.h"

#include "AS_Wave.h"//loading of wave files

#pragma comment(lib,"dsound.lib")
#pragma comment(lib,"dxguid.lib")

#ifndef __DXSOUND_H__
#define __DXSOUND_H__

extern LPDIRECTSOUND8 lpDS;
extern LPDIRECTSOUNDBUFFER lpDSPrimaryBuf;
extern LPDIRECTSOUND3DLISTENER lpDSListener;

//DEFAULTS: ch=2, bitrate=8/16bit, freq=11025*x
//if b3D is 0, no secondary buffers can be 3d
static HRESULT dxsndInitialize(HWND wnd,BOOL bExclusive,DWORD numchannels,DWORD bitrate,DWORD freq,BOOL b3D)
{
	HRESULT hr;

	if(wnd==NULL)
		return E_INVALIDARG;

	if(FAILED(hr=DirectSoundCreate8(NULL,&lpDS,NULL)))
		return hr;

	if(bExclusive){
		if(FAILED(hr=lpDS->SetCooperativeLevel(wnd,DSSCL_EXCLUSIVE)))
			return hr;
	}
	else{
		if(FAILED(hr=lpDS->SetCooperativeLevel(wnd,DSSCL_PRIORITY)))
			return hr;
	}

	//Create Primary Buffer
	DSBUFFERDESC dsbd;

	ZeroMemory(&dsbd,sizeof(DSBUFFERDESC));

	dsbd.dwSize=sizeof(DSBUFFERDESC);
	dsbd.lpwfxFormat=NULL;
	dsbd.dwFlags=DSBCAPS_PRIMARYBUFFER;
	if(b3D)
		dsbd.dwFlags|=DSBCAPS_CTRL3D;

	if(FAILED(hr=lpDS->CreateSoundBuffer(&dsbd,&lpDSPrimaryBuf,NULL)))
		return hr;

	WAVEFORMATEX wfx;

	ZeroMemory(&wfx,sizeof(WAVEFORMATEX));

	wfx.wFormatTag=WAVE_FORMAT_PCM;
	wfx.nChannels=(WORD)numchannels;
	wfx.nSamplesPerSec=freq;
	wfx.wBitsPerSample=(WORD)bitrate;
	wfx.cbSize=0;

	wfx.nBlockAlign=wfx.nChannels*wfx.wBitsPerSample/8;
	wfx.nAvgBytesPerSec=wfx.nBlockAlign*wfx.nSamplesPerSec;

	if(FAILED(hr=lpDSPrimaryBuf->SetFormat(&wfx)))
		return hr;

	if(b3D)
		if(FAILED(hr=lpDSPrimaryBuf->QueryInterface(IID_IDirectSound3DListener,(VOID**)&lpDSListener)))
			return hr;

	return hr;
}

static void dxsndCleanup()
{
	if(lpDSListener)
		lpDSListener->Release();
	lpDSPrimaryBuf->Release();
	lpDS->Release();
}

//creates a static/dynamic buffer bufsize bytes long
static HRESULT dxsndCreateSecondaryBuffer(LPDIRECTSOUNDBUFFER *lpBuf,LPDIRECTSOUND3DBUFFER *lp3DBuf,WAVEFORMATEX wfx,DWORD flags
										  ,DWORD bufsize)
{
	HRESULT hr;

	assert(lpBuf!=NULL);

	DSBUFFERDESC dsbd;
	ZeroMemory(&dsbd,sizeof(DSBUFFERDESC));

	dsbd.dwSize=sizeof(DSBUFFERDESC);
	dsbd.lpwfxFormat=&wfx;
	dsbd.dwFlags=flags|(lp3DBuf!=NULL)?DSBCAPS_CTRL3D:0;
	dsbd.dwBufferBytes=bufsize;

	if(FAILED(hr=lpDS->CreateSoundBuffer(&dsbd,lpBuf,NULL)))
		return hr;

	if(lp3DBuf)
		if(FAILED(hr=(*lpBuf)->QueryInterface(IID_IDirectSound3DBuffer,(VOID**)lp3DBuf)))
			return hr;

		return hr;
}

//creates a streaming buffer that holds "seconds" seconds of data at the current format
static HRESULT dxsndCreateSecondaryBuffer(LPDIRECTSOUNDBUFFER *lpBuf,LPDIRECTSOUND3DBUFFER *lp3DBuf,WAVEFORMATEX wfx,DWORD flags
										  ,float seconds)
{
	return dxsndCreateSecondaryBuffer(lpBuf,lp3DBuf,wfx,flags,(DWORD)(seconds*(float)wfx.nAvgBytesPerSec));
}

//creates a streaming buffer that holds "seconds" seconds of data at a file's format
static HRESULT dxsndCreateSecondaryBuffer(LPDIRECTSOUNDBUFFER *lpBuf,LPDIRECTSOUND3DBUFFER *lp3DBuf,WAVEFORMATEX& wfx,char *file,DWORD flags
										  ,float seconds)
{
	if(FAILED(GetWaveFmt(file,wfx)))
		return E_FAIL;
	return dxsndCreateSecondaryBuffer(lpBuf,lp3DBuf,wfx,flags,seconds);
}

//creates a static buffer and loads specified file
static HRESULT dxsndCreateSecondaryBuffer(LPDIRECTSOUNDBUFFER *lpBuf,LPDIRECTSOUND3DBUFFER *lp3DBuf,DWORD flags,char *soundfile)
{
	WAVEFORMATEX wfx;
	BYTE *lpData;
	void *lpPtr;
	DWORD dwLen;
	HRESULT hr;

	if(FAILED(hr=LoadWaveFile(soundfile,lpData,dwLen,wfx)))
		return hr;

	assert(wfx.wFormatTag==WAVE_FORMAT_PCM);

	if(FAILED(hr=dxsndCreateSecondaryBuffer(lpBuf,lp3DBuf,wfx,flags,dwLen))){
		free(lpData);
		return hr;
	}

	if(FAILED(hr=(*lpBuf)->Lock(0,0,&lpPtr,&dwLen,NULL,NULL,DSBLOCK_ENTIREBUFFER)))
		return hr;

	memcpy(lpPtr,lpData,dwLen);

	FREEPTR(lpData);

	if(FAILED(hr=(*lpBuf)->Unlock(lpPtr,dwLen,NULL,NULL)))
		return hr;

	return hr;
}

static HRESULT dxsndFillBuffer(LPDIRECTSOUNDBUFFER lpBuf,void *ptr,DWORD len)
{
	void *lpPtr;
	HRESULT hr;

	if(FAILED(hr=lpBuf->Lock(0,0,&lpPtr,&len,NULL,NULL,DSBLOCK_ENTIREBUFFER)))
		return hr;

	memcpy(lpPtr,ptr,len);

	if(FAILED(hr=lpBuf->Unlock(lpPtr,len,NULL,NULL)))
		return hr;

	return hr;
}

static void dxsndCleanupBuffer(LPDIRECTSOUNDBUFFER *lpBuf,LPDIRECTSOUND3DBUFFER *lp3DBuf)
{
	(*lpBuf)->Stop();

	(*lpBuf)->Release();
	(*lpBuf)=NULL;
}

#endif
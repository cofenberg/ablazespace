//-----------------------------------------------------------------------------
// File: AS_Vector.h
//-----------------------------------------------------------------------------


#ifndef __AS_VECTOR_H__
#define __AS_VECTOR_H__


// Classes: *******************************************************************
typedef class AS_VECTOR2D
{
	public:
		union
		{
			float fV[2];
			struct
			{
				float fX, fY;
			};
		};

		// Constructor:
		AS_VECTOR2D(void) { fX = fY = 0.0f; }
		AS_VECTOR2D(float fXT, float fYT) { fY = fXT, fY = fYT; }
		AS_VECTOR2D(const float *fV) { *this = fV; }
		AS_VECTOR2D(const AS_VECTOR2D &V) { *this = V; }

		// Assignment operators:
		AS_VECTOR2D &operator=(const float *fV)
		{
			fX = *fV++, fY = *fV;
			return  *this;
		}
		AS_VECTOR2D &operator=(const AS_VECTOR2D &V)
		{
			fX = V.fX, fY = V.fY;
			return *this;
		}
		AS_VECTOR2D &operator=(const float fD)
		{
			fX = fY = fD;
			return *this;
		}

		// Comparison:
		bool operator==(const AS_VECTOR2D V)
		{ return fX == V.fX && fY == V.fY; }
		bool operator!=(const AS_VECTOR2D V)
		{ return !(*this == V); }

		// Vector:
	    AS_VECTOR2D operator - ()
		{ return AS_VECTOR2D(-fX, -fY); }
		AS_VECTOR2D &operator+=(const AS_VECTOR2D V)
		{
			fX += V.fX, fY += V.fY;
			return *this;
		}
		AS_VECTOR2D operator+(const AS_VECTOR2D V)
		{ return AS_VECTOR2D(fX+V.fX, fY+V.fY); }
		AS_VECTOR2D &operator+=(const float fN)
		{
			fX += fN, fY += fN;
			return *this;
		}
		AS_VECTOR2D operator+(const float fN)
		{ return AS_VECTOR2D(fX+fN, fY+fN); }
		AS_VECTOR2D &operator-=(const AS_VECTOR2D V)
		{
			fX -= V.fX, fY -= V.fY;
			return *this;
		}
		AS_VECTOR2D operator-(const AS_VECTOR2D V)
		{ return AS_VECTOR2D(fX-V.fX, fY-V.fY); }
		AS_VECTOR2D &operator-=(const float fN)
		{
			fX -= fN, fY -= fN;
			return *this;
		}
		AS_VECTOR2D operator-(const float fN)
		{ return AS_VECTOR2D(fX-fN, fY-fN); }
		AS_VECTOR2D &operator*=(const AS_VECTOR2D V)
		{
			fX *= V.fX, fY *= V.fY;
			return *this;
		}
		AS_VECTOR2D operator*(const AS_VECTOR2D V)
		{ return AS_VECTOR2D(fX*V.fX, fY*V.fY); }
		AS_VECTOR2D &operator/=(const AS_VECTOR2D V)
		{
			fX /= V.fX, fY /= V.fY;
			return *this;
		}
		AS_VECTOR2D operator/(const AS_VECTOR2D V)
		{ return AS_VECTOR2D(fX/V.fX, fY/V.fY); }

		// Scalar
		AS_VECTOR2D &operator*=(float fS)
		{
			fX *= fS, fY *= fS;
			return *this;
		}
		AS_VECTOR2D operator*(float fS)
		{ return AS_VECTOR2D(fX*fS, fY*fS); }
		AS_VECTOR2D &operator/=(float fS)
		{
			fX /= fS, fY /= fS;
			return *this;
		}
		AS_VECTOR2D operator/(float fS)
		{ return AS_VECTOR2D(fX/fS, fY/fS); }

		// Stuff:
		void Set(const float fXT, const float fYT)
		{ fX = fXT; fY = fYT; }
		float GetLength(void) { return (float) ASFastSqrt(fX*fX+fY*fY); }
		void SetLength(float fL) { *this *= fL/GetLength(); }

		AS_VECTOR2D &Normalize(void)
		{
			float fU = fX*fX+fY*fY;
			if(fabs(fU-1.0) < AS_EPSILON)
				return *this;
			fU = 1.0f/(float) ASFastSqrt(fU);
			*this *= fU;
			return *this;
		}

		AS_VECTOR2D GetNormalized(void)
		{ return AS_VECTOR2D(*this).Normalize(); }

		float DotProduct(void) { return fX*fX+fY*fY; }
		float DotProduct(const AS_VECTOR2D V) { return fX*V.fX+fY*V.fY; }

		// Misc:
		bool IsNull(void)
		{
			if(!fX && !fY)
				return true;
			return false;
		}

} AS_VECTOR2D;

typedef class AS_VECTOR3D
{
	public:
		union
		{
			float fV[3];
			struct
			{
				float fX, fY, fZ;
			};
			struct
			{
				float fHeading, fPitch, fRoll;
			};
		};

		// Constructor:
		AS_VECTOR3D(void) { fX = fY = fZ = 0.0f; }
		AS_VECTOR3D(float fXT, float fYT, float fZT)
		{ fX = fXT, fY = fYT, fZ = fZT; }
		AS_VECTOR3D(const float *fV) { *this = fV; }
		AS_VECTOR3D(const AS_VECTOR3D &V) { *this = V; }

		// Assignment operators:
		AS_VECTOR3D &operator=(const AS_VECTOR3D &V)
		{
			fX = V.fX, fY = V.fY, fZ = V.fZ;
			return *this;
		}
		AS_VECTOR3D &operator=(const float *fV)
		{
			fX = *fV++, fY = *fV++, fZ = *fV;
			return *this;
		}
		AS_VECTOR3D &operator=(const float fD)
		{
			fX = fY = fZ = fD;
			return *this;
		}

		// Comparison:
		bool operator==(const AS_VECTOR3D &V)
		{ return fX == V.fX && fY == V.fY && fZ == V.fZ; }
		bool operator!=(const AS_VECTOR3D V)
		{ return !(*this == V); }

		// Vector:
	    AS_VECTOR3D operator - ()
		{ return AS_VECTOR3D(-fX, -fY, -fZ); }
		AS_VECTOR3D &operator+=(const AS_VECTOR3D V)
		{
			fX += V.fX, fY += V.fY, fZ += V.fZ;
			return *this;
		}
		AS_VECTOR3D operator+(const AS_VECTOR3D V)
		{ return AS_VECTOR3D(fX+V.fX, fY+V.fY, fZ+V.fZ); }
		AS_VECTOR3D &operator+=(const float fN)
		{
			fX += fN, fY += fN, fZ += fN;
			return *this;
		}
		AS_VECTOR3D operator+(const float fN)
		{ return AS_VECTOR3D(fX+fN, fY+fN, fZ+fN); }
		AS_VECTOR3D &operator-=(const AS_VECTOR3D V)
		{
			fX -= V.fX, fY -= V.fY, fZ -= V.fZ;
			return *this;
		}
		AS_VECTOR3D operator-(const AS_VECTOR3D V)
		{ return AS_VECTOR3D(fX-V.fX, fY-V.fY, fZ-V.fZ); }
		AS_VECTOR3D &operator-=(const float fN)
		{
			fX -= fN, fY -= fN, fZ -= fN;
			return *this;
		}
		AS_VECTOR3D operator-(const float fN)
		{ return AS_VECTOR3D(fX-fN, fY-fN, fZ-fN); }
		AS_VECTOR3D &operator*=(const AS_VECTOR3D V)
		{
			fX *= V.fX, fY *= V.fY, fZ *= V.fZ;
			return *this;
		}
		AS_VECTOR3D operator*(const AS_VECTOR3D V)
		{ return AS_VECTOR3D(fX*V.fX, fY*V.fY, fZ*V.fZ); }
		AS_VECTOR3D &operator/=(const AS_VECTOR3D V)
		{
			fX /= V.fX, fY /= V.fY, fZ /= V.fZ;
			return *this;
		}
		AS_VECTOR3D operator/(const AS_VECTOR3D V)
		{ return AS_VECTOR3D(fX/V.fX, fY/V.fY, fZ/V.fZ); }

		// Scalar:
		AS_VECTOR3D &operator*=(float fS)
		{
			fX *= fS, fY *= fS, fZ *= fS;
			return *this;
		}
		AS_VECTOR3D operator*(float fS)
		{ return AS_VECTOR3D(fX*fS, fY*fS, fZ*fS); }
		AS_VECTOR3D &operator/=(float fS)
		{
			*this*=1.0f/fS;
			return *this;
		}
		AS_VECTOR3D operator/(float fS)
		{ return operator*(1.0f/fS); }

		// Stuff:
		void Set(const float fXT, const float fYT, const float fZT)
		{ fX = fXT; fY = fYT; fZ = fZT; }

		float GetLength(void) { return (float) ASFastSqrt(fX*fX+fY*fY+fZ*fZ); }
		void SetLength(float fL) { *this *= fL/GetLength(); }

		AS_VECTOR3D &Normalize(void)
		{
			float fU = fX*fX+fY*fY+fZ*fZ;
			if(fabs(fU-1.0) < AS_EPSILON)
				return *this;
			fU = 1.0f/(float) ASFastSqrt(fU);
			*this *= fU;
			return *this;
		}

		AS_VECTOR3D GetNormalized(void)
		{ return AS_VECTOR3D(*this).Normalize(); }

		AS_VECTOR3D CrossProduct(const AS_VECTOR3D V)
		{
			return AS_VECTOR3D((fY*V.fZ)-(fZ*V.fY),
								(fZ*V.fX)-(fX*V.fZ),
								(fX*V.fY)-(fY*V.fX));
		}

		void CrossProduct(const AS_VECTOR3D vV1, const AS_VECTOR3D vV2)
		{
			fX = (vV1.fY*vV2.fZ)-(vV1.fZ*vV2.fY);
			fY = (vV1.fZ*vV2.fX)-(vV1.fX*vV2.fZ);
			fZ = (vV1.fX*vV2.fY)-(vV1.fY*vV2.fX);
		}

		void GetFaceNormal(AS_VECTOR3D vP1,
						   AS_VECTOR3D vP2,
						   AS_VECTOR3D vP3)
		{
			CrossProduct(vP1-vP2, vP1-vP3);
			Normalize();
		}

		// Get the right and up vectors for a given normal:
		void GetRightUp(AS_VECTOR3D &vRight, AS_VECTOR3D &vUp)
		{
			AS_VECTOR3D vFN(AS_ABS(fX), AS_ABS(fY), AS_ABS(fZ));
			if(vFN.fX > 1.0f)
				vFN.fZ = 1.0f;
			if(vFN.fY > 1.0f)
				vFN.fY = 1.0f;
			if(vFN.fZ > 1.0f)
				vFN.fZ = 1.0f;
			int iMajor = X;
			AS_VECTOR3D vAxis[3] = 
			{
			   AS_VECTOR3D(1.01f, 0.0f, 0.0f),
			   AS_VECTOR3D(0.0f, 1.0f, 0.0f),
			   AS_VECTOR3D(0.0f, 0.0f, 1.0f)
			};

			// Find the major axis:
			if(vFN.fY > vFN.fV[iMajor])
			  iMajor = Y;
			if(vFN.fZ > vFN.fV[iMajor])
			  iMajor = Z;

			// Build right vector by hand: (faster)
			if(vFN.fX == 1.0f || vFN.fY == 1.0f || vFN.fZ == 1.0f)
			{
				if(iMajor == X && fX > 0.0f)
					vRight.Set(0.0f, 0.0f, -1.0f);
				else
					if(iMajor == X)
						vRight.Set(0.0f, 0.0f, 1.0f);

			  if(iMajor == Y || (iMajor == Z && fZ > 0.0f))
				 vRight.Set(1.0f, 0.0f, 0.0f);
			  if(iMajor == Z && fZ < 0.0f)
				 vRight.Set(-1.0f, 0.0f, 0.0f);
			}
			else
				vRight.CrossProduct(vAxis[iMajor], *this);


			vUp.CrossProduct(*this, vRight);
			vRight.Normalize();
			vUp.Normalize();
		}

		// Project the vector onto the vector 'vV'
		void ProjectVector(AS_VECTOR3D vV, AS_VECTOR3D &vRes)
		{
		   vRes = vV;
		   vRes *= ((vV.DotProduct(*this))/(vV.DotProduct()));
		}

		// Project the vector on to the plane created by 'v1' and 'v2'. 'v1' and
		// 'v2' MUST be perpindicular to eachother!
		void ProjectPlane(const AS_VECTOR3D vV1, const AS_VECTOR3D vV2, AS_VECTOR3D &vRes)
		{
		   AS_VECTOR3D vT1, vT2;
   
		   ProjectVector(vV1, vT1);
		   ProjectVector(vV2, vT2);
		   vRes = vT1+vT2;
		}

		float AngleBetween(AS_VECTOR3D V)
		{ return (DotProduct(V)/(GetLength()*V.GetLength())); }

		float DotProduct(void) { return fX*fX+fY*fY+fZ*fZ; }
		float DotProduct(const AS_VECTOR3D V) { return fX*V.fX+fY*V.fY+fZ*V.fZ; }

		// Misc:
		bool IsNull(void)
		{
			if(!fX && !fY && !fZ)
				return true;
			return false;
		}

} AS_VECTOR3D;
///////////////////////////////////////////////////////////////////////////////


inline float ASGetLengthOfVector(AS_VECTOR3D vV)
{ // begin ASGetLengthOfVector()
	return (float) ASFastSqrt(vV.fX*vV.fX+vV.fY*vV.fY+vV.fZ*vV.fZ);
} // end ASGetLengthOfVector()


#endif // __AS_VECTOR_H__
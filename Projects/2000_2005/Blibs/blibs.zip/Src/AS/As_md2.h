//-----------------------------------------------------------------------------
// File: AS_MD2.h
//-----------------------------------------------------------------------------

#ifndef __AS_MD2_H__
#define __AS_MD2_H__


// Definitions: ***************************************************************
#define MD2_MAX_TRIANGLES		4096
#define MD2_MAX_VERTICES		2048
#define MD2_MAX_TEXCOORDS		2048
#define MD2_MAX_FRAMES			512
#define MD2_MAX_SKINS			32
#define MD2_MAX_FRAMESIZE		(MD2_MAX_VERTICES*4+128)
typedef char AS_MD2_SKIN[64];
///////////////////////////////////////////////////////////////////////////////

// Structures: ****************************************************************
typedef struct vertlist
{
	int i;
	FLOAT2 texcoord;
} vertlist;

typedef struct 
{ 
   int magic; 
   int version; 
   int skinWidth; 
   int skinHeight; 
   int frameSize; 
   int numSkins; 
   int numVertices; 
   int numTexCoords; 
   int numTriangles; 
   int numGlCommands; 
   int numFrames; 
   int offsetSkins; 
   int offsetTexCoords; 
   int offsetTriangles; 
   int offsetFrames; 
   int offsetGlCommands; 
   int offsetEnd; 
} AS_MD2_HEADER;

typedef struct
{
   byte vertex[3];
   byte lightNormalIndex;
} AS_MD2_ALIAS_TRIANGLE_VERTEX;

typedef struct
{
   float vertex[3];
   float normal[3];
} AS_MD2_TRIANGLE_VERTEX;

typedef struct
{
   short vertexIndices[3];
   short textureIndices[3];
} AS_MD2_TRIANGLE;

typedef struct
{
   short s, t;
} AS_MD2_TEXTURE_COORDINATE;

typedef struct
{
   float scale[3];
   float translate[3];
   char name[16];
   AS_MD2_ALIAS_TRIANGLE_VERTEX alias_vertices[1];
} AS_MD2_ALIAS_FRAME;

typedef struct
{
   char name[16];
   AS_MD2_TRIANGLE_VERTEX *vertices;
   FLOAT3 *facenormals;
   FLOAT3 *vertex; // For faster rendering
   FLOAT3 *normal; // For faster rendering
   FLOAT3 fBoundingBox[2];
} AS_MD2_FRAME;

typedef struct
{
   float s, t;
   int vertexIndex;
} AS_MD2_GLCOMMAND_VERTEX;

typedef struct animation_s
{
	char	nameAnimation[16];
	int		firstFrame;
	int		lastFrame;
} AS_MD2_ANIMATION;

typedef struct md2_anim_s
{
	int			count_anim;
	AS_MD2_ANIMATION anim[MD2_MAX_FRAMES];
} AS_MD2_ANI;

typedef struct
{
	char byFilename[256];
	
	AS_MD2_HEADER			header;
	AS_MD2_SKIN				*skins;
	AS_MD2_TEXTURE_COORDINATE	*texCoords;
	FLOAT2 *texCoord; // For faster rendering
	AS_MD2_TRIANGLE			*triangles;
	AS_MD2_FRAME			*frames;
	int						*glCommandBuffer;
	AS_MD2_ANI Ani;
	float fBoundingBox[2][3],
		  fBoundigBoxSize;

	// Precomputed frame data for faster rendering:
	FLOAT3 *prevertex;
	FLOAT3 *prenormal;
} AS_MD2_MODEL;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern void ASDrawMd2Frame(AS_MD2_MODEL *, int);
extern void ASDrawMd2FrameInt(AS_MD2_MODEL *, int, int, float);
extern void ASPrecomputeMd2FrameInt(AS_MD2_MODEL *, int, int, float);
extern void ASDrawPrecomputedMd2Frame(AS_MD2_MODEL *);
extern void ASFreeMd2Model(AS_MD2_MODEL *);
extern AS_MD2_ANI ASMakeMd2Ani(AS_MD2_MODEL *);
extern AS_MD2_MODEL *ASLoadMd2Model(char *);
extern void AS_Md2_GetBoundingBox(AS_MD2_MODEL *, float *);
extern void AS_Md2_GetFrameBoundingBox(AS_MD2_MODEL *, int, FLOAT3 (*)[2]);
extern void AS_Md2_GetCurrentBoundingBox(AS_MD2_MODEL *, int, int, float, FLOAT3 (*)[2]);
extern void ASGetMd2Vertex(AS_MD2_MODEL *, int, int, float, FLOAT3,
					       float, float, float, float,
					       int, FLOAT3 *);
extern BOOL ASRayIntersectMd2(AS_MD2_MODEL *, int, int, float,
							  AS_VECTOR3D, AS_VECTOR3D);
extern BOOL ASRaySphereIntersectMd2(AS_MD2_MODEL *, int, int, float,
									AS_VECTOR3D, AS_VECTOR3D, float, FLOAT3 (*)[2]);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_MD2__
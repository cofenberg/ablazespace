The "Intel Jpeg Library" to load JPEG files could be found at the Intel homepage. (www.intel.com)
You will need the headers to compile the program.
You will also need the stuff of the Fmod (V3.33) library to compile the game. They could be found at www.fmod.org.
//-----------------------------------------------------------------------------
// File: AS_Collision.cpp
//-----------------------------------------------------------------------------

#include "AS_Engine.h"


// Functions: *****************************************************************
double ASIntersectRayPlane(AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D);
BOOL ASCheckPointInTriangle(AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D);
BOOL ASCheckPointInTriangle(AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D);
AS_VECTOR3D ASClosestPointOnLine(AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D);
AS_VECTOR3D ASClosestPointOnTriangle(AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D);
BOOL ASCheckPointInSphere(AS_VECTOR3D, AS_VECTOR3D, float);
AS_VECTOR3D ASTangentPlaneNormalOfEllipsoid(AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D);
DWORD ASClassifyPoint(AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D);
double ASIntersectRaySphere(AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D, float);
BOOL ASCheckLineInBox(AS_VECTOR3D, AS_VECTOR3D, FLOAT3 [2]);
///////////////////////////////////////////////////////////////////////////////


double ASIntersectRayPlane(AS_VECTOR3D vROrigin, AS_VECTOR3D vRVector,
						   AS_VECTOR3D vPOrigin, AS_VECTOR3D vPNormal)
{ // begin ASIntersectRayPlane()
	double dD = -vPNormal.DotProduct(vPOrigin);
	double dNumer = vPNormal.DotProduct(vROrigin)+dD;
	double dDenom = vPNormal.DotProduct(vRVector);

	if(!dDenom) // Normal is orthogonal to vector, cant intersect:
		return -1.0f;

	return -(dNumer/dDenom);	
} // end ASIntersectRayPlane()

BOOL ASCheckPointInTriangle(AS_VECTOR3D vPoint, AS_VECTOR3D vA,
							AS_VECTOR3D vB, AS_VECTOR3D vC)
{ // begin ASCheckPointInTriangle()
	double dTotalAngles = 0.0f;
	float f;

	// Is the tested point near in that triangle??
	if((vPoint.fX < vA.fX &&
		vPoint.fX < vB.fX && 
		vPoint.fX < vC.fX) ||
	   (vPoint.fX > vA.fX &&
		vPoint.fX > vB.fX && 
		vPoint.fX > vC.fX) ||
	   (vPoint.fY < vA.fY &&
		vPoint.fY < vB.fY && 
		vPoint.fY < vC.fY) ||
	   (vPoint.fY > vA.fY &&
		vPoint.fY > vB.fY && 
		vPoint.fY > vC.fY))
		return FALSE; // Nope!

	// Check if the point is on one of the triangles edges:
	if((vPoint.fX == vA.fX && vPoint.fY == vA.fY && vPoint.fZ == vA.fZ) ||
	   (vPoint.fX == vB.fX && vPoint.fY == vB.fY && vPoint.fZ == vB.fZ) ||
	   (vPoint.fX == vC.fX && vPoint.fY == vC.fY && vPoint.fZ == vC.fZ))
		return TRUE;

	// Make the 3 vectors:
	AS_VECTOR3D vV1 = vPoint-vA;
	AS_VECTOR3D vV2 = vPoint-vB;
	AS_VECTOR3D vV3 = vPoint-vC;

	vV1.Normalize();
	vV2.Normalize();
	vV3.Normalize();

	f = vV1.DotProduct(vV2);
	ASLimitMinMax(f, -1.0f, 1.0f);
	dTotalAngles += acos((double) f);

	f = vV2.DotProduct(vV3);
	ASLimitMinMax(f, -1.0f, 1.0f);
	dTotalAngles += acos((double) f);

	f = vV3.DotProduct(vV1);
	ASLimitMinMax(f, -1.0f, 1.0f);
	dTotalAngles += acos((double) f);

	if(fabs(dTotalAngles-2*PI) <= 0.005)
		return TRUE;

	return FALSE;
} // end ASCheckPointInTriangle()

BOOL ASCheckPointInTriangle(AS_VECTOR3D vPoint, AS_VECTOR3D vNormal,
							AS_VECTOR3D vP1, AS_VECTOR3D vP2, AS_VECTOR3D vP3)
{ // begin ASCheckPointInTriangle()
	static const float Delta = 1.0e-05f;
	float u0, u1, u2;
	float v0, v1, v2;
	float a, b;
	float max;
	int i, j;
	bool bInter = 0;

	// Is the tested point near in that triangle??
	if((vPoint.fX < vP1.fX &&
		vPoint.fX < vP2.fX && 
		vPoint.fX < vP3.fX) ||
	   (vPoint.fX > vP1.fX &&
		vPoint.fX > vP2.fX && 
		vPoint.fX > vP3.fX) ||
	   (vPoint.fY < vP1.fY &&
		vPoint.fY < vP2.fY && 
		vPoint.fY < vP3.fY) ||
	   (vPoint.fY > vP1.fY &&
		vPoint.fY > vP2.fY && 
		vPoint.fY > vP3.fY))
		return FALSE; // Nope!

	// Check if the point is on one of the triangles edges:
	if((vPoint.fX == vP1.fX && vPoint.fY == vP1.fY) ||
	   (vPoint.fX == vP2.fX && vPoint.fY == vP2.fY) ||
	   (vPoint.fX == vP3.fX && vPoint.fY == vP3.fY))
		return TRUE;

#define ABS(X) (((X)<0.f)?-(X):(X) )
#define MAX(A, B) (((A)<(B))?(B):(A))	
	max = MAX(MAX(ABS(vNormal.fX), ABS(vNormal.fY)), ABS(vNormal.fZ));
#undef MAX
	if (max == ABS(vNormal.fX)) {i = 1; j = 2;} // y, z
	if (max == ABS(vNormal.fY)) {i = 0; j = 2;} // x, z
	if (max == ABS(vNormal.fZ)) {i = 0; j = 1;} // x, y
#undef ABS
	
	u0 = vPoint.fV[i]-vP1.fV[i];
	v0 = vPoint.fV[j]-vP1.fV[j];
	u1 = vP2.fV[i]-vP1.fV[i];
	v1 = vP2.fV[j]-vP1.fV[j];
	u2 = vP3.fV[i]-vP1.fV[i];
	v2 = vP3.fV[j]-vP1.fV[j];

	if (u1 > -Delta && u1 < Delta)
	{
		b = u0 / u2;
		if (0.0f <= b && b <= 1.0f)
		{
			a = (v0 - b * v2) / v1;
			if ((a >= 0.0f) && (( a + b ) <= 1.0f))
				bInter = 1;
		}
	}
	else
	{
		b = (v0 * u1 - u0 * v1) / (v2 * u1 - u2 * v1);
		if (0.0f <= b && b <= 1.0f)
		{
			a = (u0 - b * u2) / u1;
			if ((a >= 0.0f) && (( a + b ) <= 1.0f ))
				bInter = 1;
		}
	}

	return bInter;
} // end ASCheckPointInTriangle()

AS_VECTOR3D ASClosestPointOnLine(AS_VECTOR3D vA, AS_VECTOR3D vB, AS_VECTOR3D vP)
{ // begin ASClosestPointOnLine()
	// Determine dT: (the length of the vector from �dA� to �dP�)
	AS_VECTOR3D vC = vP-vA;
	AS_VECTOR3D vV = vB-vA; 
  
	double dD = vV.GetLength();
  
	vV.Normalize();

	double dT = vV.DotProduct(vC);

	// Check to see if �dT� is beyond the extents of the line segment:
	if(dT < 0.0f)
		return vA;
	if(dT > dD)
		return vB;

	// Return the point between �vA� and �vB�
	// set length of vV to dT. vV is normalized so this is easy:
	vV *= (float) dT;
       
	return (vA+vV);
} // end ASClosestPointOnLine()

AS_VECTOR3D ASClosestPointOnTriangle(AS_VECTOR3D vA, AS_VECTOR3D vB,
									 AS_VECTOR3D vC, AS_VECTOR3D vP)
{ // begin ASClosestPointOnTriangle()
	AS_VECTOR3D vRab = ASClosestPointOnLine(vA, vB, vP);
	AS_VECTOR3D vRbc = ASClosestPointOnLine(vB, vC, vP);
	AS_VECTOR3D vRca = ASClosestPointOnLine(vC, vA, vP);

	double dAB = (vP-vRab).GetLength();
	double dBC = (vP-vRbc).GetLength();
	double dCA = (vP-vRca).GetLength();
	double dMin = dAB;

	AS_VECTOR3D vResult = vRab;

	if(dBC < dMin)
	{
		dMin = dBC;
		vResult = vRbc;
	}

	if(dCA < dMin)
		vResult = vRca;

	return vResult;	
} // end ASClosestPointOnTriangle()

BOOL ASCheckPointInSphere(AS_VECTOR3D vPoint, AS_VECTOR3D vS, float fR)
{ // begin ASCheckPointInSphere()
	float fD = (vPoint-vS).GetLength();

	if(fD <= fR)
		return TRUE;
	return FALSE;	
} // end ASCheckPointInSphere()

AS_VECTOR3D ASTangentPlaneNormalOfEllipsoid(AS_VECTOR3D vPoint,
											AS_VECTOR3D vE, AS_VECTOR3D vER)
{ // begin ASTangentPlaneNormalOfEllipsoid()
	AS_VECTOR3D vP = vPoint-vE;

	double dA2 = vER.fX*vE.fX;
	double dB2 = vER.fY*vE.fY;
	double dC2 = vER.fZ*vE.fZ;

	AS_VECTOR3D vRes;
	vRes.fX = (float) (vP.fX/dA2);
	vRes.fY = (float) (vP.fY/dB2);
	vRes.fZ = (float) (vP.fZ/dC2);

	vRes.Normalize();
	return vRes;
} // end ASTangentPlaneNormalOfEllipsoid()

DWORD ASClassifyPoint(AS_VECTOR3D vPoint, AS_VECTOR3D vP, AS_VECTOR3D vN)
{ // begin ASClassifyPoint()
	AS_VECTOR3D vDir = vP-vPoint;
	double dD = vDir.DotProduct(vN);

	if(dD < -0.001f)
		return AS_PLANE_FRONT;	
	else
		if(dD > 0.001f)
			return AS_PLANE_BACKSIDE;	

	return AS_ON_PLANE;	
} // end ASClassifyPoint()

double ASIntersectRaySphere(AS_VECTOR3D vRayPos, AS_VECTOR3D vRayDir,
							AS_VECTOR3D vSpherePos, float fSphereRadius)
{ // begin ASIntersectRaySphere()
	AS_VECTOR3D vDelta = vSpherePos-vRayPos;

	float fC = vDelta.GetLength();
	float fV = vDelta.DotProduct(vRayDir);
	float fD = fSphereRadius*fSphereRadius-(fC*fC-fV*fV);

	if(fD < 0.0)
		return -1.0f; // There was no intersection
   
   // Return the distance to the (first) intersecting point:
	return (fV-ASFastSqrt(fD));
} // end ASIntersectRaySphere()

// Checks if an point is in the given triangle:
BOOL ASCheckTriangleCollision(AS_VECTOR3D vStartPoint, AS_VECTOR3D vRayDirection, AS_VECTOR3D *pvIntersectionPoint,
							  AS_VECTOR3D vPoint1, AS_VECTOR3D vPoint2, AS_VECTOR3D vPoint3, AS_VECTOR3D vNormal)
{ // begin ASCheckTriangleCollision()
	AS_VECTOR3D vV1, vV2, // The distances between the triangle points
			   	vOrigin; // The trianlges origin
	double fDistToPlaneIntersection; // The distance from the ray start point to the triangle

	// Make the plane containing this triangle:
	vOrigin = vPoint1;
	vV1 = vPoint2-vPoint1;
	vV2 = vPoint3-vPoint1;

	// Shoot ray along the velocity vector:
	fDistToPlaneIntersection = ASIntersectRayPlane(vStartPoint, vRayDirection, vOrigin, vNormal);

	// Calculate plane intersection point:
	pvIntersectionPoint->fX = (float) (vStartPoint.fX+fDistToPlaneIntersection*vRayDirection.fX);
	pvIntersectionPoint->fY = (float) (vStartPoint.fY+fDistToPlaneIntersection*vRayDirection.fY);
	pvIntersectionPoint->fZ = (float) (vStartPoint.fZ+fDistToPlaneIntersection*vRayDirection.fZ);

	if(((*pvIntersectionPoint).fZ < vPoint1.fZ &&
	   (*pvIntersectionPoint).fZ < vPoint2.fZ &&
	   (*pvIntersectionPoint).fZ < vPoint3.fZ) ||
	   ((*pvIntersectionPoint).fZ > vPoint1.fZ &&
	    (*pvIntersectionPoint).fZ > vPoint2.fZ &&
	    (*pvIntersectionPoint).fZ > vPoint3.fZ))
		return 0; // There is something wrong!?!

	// Check if the intersection point is in the triangle:
	if(!ASCheckPointInTriangle(*pvIntersectionPoint, vPoint1, vPoint2, vPoint3))
		return 0; // It's not in the triangle!
	
	return 1; // It's in the triangle!
} // end ASCheckTriangleCollision()

BOOL ASBoxIntersectionX(float fX, AS_VECTOR3D vLineS, AS_VECTOR3D vLineM, AS_VECTOR3D *vRes)
{ // begin ASBoxIntersectionX()
    if(vLineM.fX)
	{
        float t = (fX-vLineS.fX)/vLineM.fX;
        if((t >= 0.0f) && (t <= 1.0f))
		{
            (*vRes) = vLineS+vLineM*t;
            return TRUE;
        }
    }
    return FALSE;
} // end ASBoxIntersectionX()

BOOL ASBoxIntersectionY(float fY, AS_VECTOR3D vLineS, AS_VECTOR3D vLineM, AS_VECTOR3D *vRes)
{ // begin ASBoxIntersectionY()
    if(vLineM.fY)
	{
        float t = (fY-vLineS.fY)/vLineM.fY;
        if((t >= 0.0f) && (t <= 1.0f))
		{
            (*vRes) = vLineS+vLineM*t;
            return TRUE;
        }
    }
    return FALSE;
} // end ASBoxIntersectionY()

BOOL ASBoxIntersectionZ(float fZ, AS_VECTOR3D vLineS, AS_VECTOR3D vLineM, AS_VECTOR3D *vRes)
{ // begin ASBoxIntersectionZ()
    if(vLineM.fZ)
	{
        float t = (fZ-vLineS.fZ)/vLineM.fZ;
        if((t >= 0.0f) && (t <= 1.0f))
		{
            (*vRes) = vLineS+vLineM*t;
            return TRUE;
        }
    }
    return FALSE;
} // end ASBoxIntersectionZ()

BOOL ASCheckBoxVecX(AS_VECTOR3D vVec, FLOAT3 fBox[2])
{ // begin ASCheckBoxVecX()
    if((vVec.fY >= fBox[MIN][Y]) && (vVec.fY <= fBox[MAX][Y]) && (vVec.fZ >= fBox[MIN][Z]) && (vVec.fZ <= fBox[MAX][Z]))
		return TRUE;
    return FALSE;
} // end ASCheckBoxVecX()

BOOL ASCheckBoxVecY(AS_VECTOR3D vVec, FLOAT3 fBox[2])
{ // begin ASCheckBoxVecY()
    if((vVec.fX >= fBox[MIN][X]) && (vVec.fX <= fBox[MAX][X]) && (vVec.fZ >= fBox[MIN][Z]) && (vVec.fZ <= fBox[MAX][Z]))
		return TRUE;
    return FALSE;
} // end ASCheckBoxVecY()

BOOL ASCheckBoxVecZ(AS_VECTOR3D vVec, FLOAT3 fBox[2])
{ // begin ASCheckBoxVecZ()
    if((vVec.fX >= fBox[MIN][X]) && (vVec.fX <= fBox[MAX][X]) && (vVec.fY >= fBox[MIN][Y]) && (vVec.fY <= fBox[MAX][Y]))
		return TRUE;
    return FALSE;
} // end ASCheckBoxVecZ()

BOOL ASCheckLineInBox(AS_VECTOR3D vLineS, AS_VECTOR3D vLineM, FLOAT3 fBox[2])
{ // begin ASCheckRayBox()
	AS_VECTOR3D vLineE;
	
	vLineE.fX = vLineS.fX+vLineM.fX;
	vLineE.fY = vLineS.fY+vLineM.fY;
	vLineE.fZ = vLineS.fZ+vLineM.fZ;
    if(((vLineS.fX >= fBox[MIN][X]) && (vLineS.fY >= fBox[MIN][Y]) && (vLineS.fZ >= fBox[MIN][Z]) &&
        (vLineS.fX <= fBox[MAX][X]) && (vLineS.fY <= fBox[MAX][Y]) && (vLineS.fZ <= fBox[MAX][Y])) ||
       ((vLineE.fX >= fBox[MIN][X]) && (vLineE.fY >= fBox[MIN][Y]) && (vLineE.fZ >= fBox[MIN][Z]) &&
        (vLineE.fX <= fBox[MAX][X]) && (vLineE.fY <= fBox[MAX][Y]) && (vLineE.fZ <= fBox[MAX][Z])))
        return TRUE;
    AS_VECTOR3D vPos;
    int i;

    for(i = 0; i < 6; i++)
	{
        switch(i)
		{
            case 0:
                if(ASBoxIntersectionX(fBox[MIN][X], vLineS, vLineM, &vPos) && ASCheckBoxVecX(vPos, fBox))
					return TRUE;
            break;
           
		    case 1:
                if(ASBoxIntersectionX(fBox[MAX][X], vLineS, vLineM, &vPos) && ASCheckBoxVecX(vPos, fBox))
					return TRUE;
            break;
           
		    case 2:
                if(ASBoxIntersectionY(fBox[MIN][Y], vLineS, vLineM, &vPos) && ASCheckBoxVecY(vPos, fBox))
					return TRUE;
            break;
           
		    case 3:
                if(ASBoxIntersectionY(fBox[MAX][Y], vLineS, vLineM, &vPos) && ASCheckBoxVecY(vPos, fBox))
					return TRUE;
            break;
           
		    case 4:
                if(ASBoxIntersectionZ(fBox[MIN][Z], vLineS, vLineM, &vPos) && ASCheckBoxVecZ(vPos, fBox))
					return TRUE;
            break;
           
		    case 5:
				if(ASBoxIntersectionZ(fBox[MAX][Z], vLineS, vLineM, &vPos) && ASCheckBoxVecZ(vPos, fBox))
					return TRUE;
            break;
        }
    }
    return FALSE;
} // end ASCheckRayBox()
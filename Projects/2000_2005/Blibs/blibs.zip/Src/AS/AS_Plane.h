//-----------------------------------------------------------------------------
// File: AS_Plane.h
//-----------------------------------------------------------------------------

#ifndef __AS_PLANE_H__
#define __AS_PLANE_H__


// Classes: *******************************************************************
typedef class AS_PLANE
{
	public:
		AS_VECTOR3D vN;
		float fD;

		AS_PLANE(float fA = 1.0f, float fB = 0.0f, float fC = 0.0f, float fD1 = 0.0f)
		{
				vN = AS_VECTOR3D(fA, fB, fC).Normalize();
				fD = fD1;
		}
		AS_PLANE(AS_VECTOR3D &vVertexA, AS_VECTOR3D &vVertexB, AS_VECTOR3D &vVertexC)
		{
			ComputeND(vVertexA, vVertexB, vVertexC);
		}

		AS_PLANE &operator = (AS_PLANE &Plane)
		{
			vN = Plane.vN;
			fD = Plane.fD;
			return *this;
		}

		void ComputeND(AS_VECTOR3D vVertexA, AS_VECTOR3D vVertexB, AS_VECTOR3D vVertexC)
		{
			AS_VECTOR3D vNormalA = ((vVertexC-vVertexA).Normalize());
			AS_VECTOR3D vNormalB = ((vVertexC-vVertexB).Normalize());
			vN = (vNormalA.CrossProduct(vNormalB)).Normalize();
			fD = -vVertexA.DotProduct(vN);
		}

		// Boolean Operators:
		BOOL operator == (AS_PLANE &Plane)
		{
			return vN == Plane.vN && fD == Plane.fD;
		}
		BOOL operator != (AS_PLANE &Plane)
		{
			return !(*this == Plane);
		}

		BOOL PointOnPlane(AS_VECTOR3D &vPoint)
		{
			return DistanceToPlane(vPoint) == 0;
		}
		float DistanceToPlane(AS_VECTOR3D &vPoint)
		{
			return ((vN.DotProduct(vPoint))+fD);
		}
		AS_VECTOR3D RayIntersection(AS_VECTOR3D &vRayPos, AS_VECTOR3D &vRayDir)
		{
			float fA = vN.DotProduct(vRayDir);
			if(!fA)
				return vRayPos;	// Error line parallel to plane
			
			return vRayPos-vRayDir*(DistanceToPlane(vRayPos)/fA);
		}

} AS_PLANE;
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_PLANE_H__

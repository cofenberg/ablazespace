//-----------------------------------------------------------------------------
// File: AS_Fmod.h
//-----------------------------------------------------------------------------

#ifndef __AS_FMOD_H__
#define __AS_FMOD_H__


// Definitions: ***************************************************************
#define AS_MAX_SOUND_CHANNELS 64
///////////////////////////////////////////////////////////////////////////////

// Structures: ****************************************************************
typedef struct AS_FMOD_SAMPLE
{
	char byFilename[256]; // The filename
	FSOUND_SAMPLE *pSample; // Pointer to the Fmod sample
	int iChannel;

} AS_FMOD_SAMPLE;

typedef struct AS_FMOD_MUSIC
{
	char byFilename[256]; // The filename
	FMUSIC_MODULE *pMod; // Pointer to the Fmod music
	FSOUND_STREAM *pStream; // Pointer to the music stream

} AS_FMOD_MUSIC;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern BOOL bASMusicFinished; // Is the music finished??
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern BOOL ASInitFmod(void);
extern BOOL ASDestroyFmod(void);
extern BOOL ASLoadFmodSamples(char (*)[256], int, AS_FMOD_SAMPLE *);
extern BOOL ASDestroyFmodSamples(int, AS_FMOD_SAMPLE *);
extern BOOL ASLoadFmodSample(AS_FMOD_SAMPLE *, char *, int);
extern BOOL ASPlayFmodSample(AS_FMOD_SAMPLE *, int);
extern BOOL ASStopAllFmodSamples(int, AS_FMOD_SAMPLE *);
extern BOOL ASStopFmodSample(AS_FMOD_SAMPLE *);
extern BOOL ASPlayFmodMusic(AS_FMOD_MUSIC *, char *);
extern BOOL ASDestroyFmodMusic(AS_FMOD_MUSIC *);
extern BOOL ASSetPauseFmodMusic(AS_FMOD_MUSIC *, BOOL);
extern signed char ASFmodEndCallback(FSOUND_STREAM *, void *, int, int);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_FMOD_H__

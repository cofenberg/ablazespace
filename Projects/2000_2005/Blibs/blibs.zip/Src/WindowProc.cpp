//-----------------------------------------------------------------------------
// File: WindowProc.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Functions: *****************************************************************
LRESULT CALLBACK WindowProc(HWND, unsigned, WPARAM, LPARAM);
///////////////////////////////////////////////////////////////////////////////


LRESULT CALLBACK WindowProc(HWND hWnd, unsigned uMsg, WPARAM wParam, LPARAM lParam)
{ // begin WindowProc()
	BOOL bTempFullscreen;
	char byTemp[256];
	int i;
	
	switch(uMsg)
    {
        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
			// Game:
				case ID_GAME_GENERAL_MAIN_MENU:
					bInGameMenu = TRUE;
				break;
				
				case ID_GAME_GENERAL_EDITOR:
					_AS->SetNextModule(MODULE_EDITOR);
				break;

				case ID_GAME_GENERAL_QUIT:
					_AS->SetShutDown(TRUE);
				break;

			// Options:
				case ID_OPTIONS_CONFIG:
					bTempFullscreen = _ASConfig->bFullScreen;
					_ASConfig->bFullScreen = FALSE;
					ChangeDisplayMode();
					_ASConfig->bFullScreen = bTempFullscreen;
					hWnd = *_AS->pWindow[GAME_WINDOW_ID].GethWnd();
					OpenConfigDialog(hWnd);
					ChangeDisplayMode();
					i = _AS->FindWindowID(hWnd);
					if(i == -1)
						break;
					_AS->pWindow[i].Resize(_ASConfig->iWindowWidth, _ASConfig->iWindowHeight);
					dwMainMenuStartTime = g_lGameTimer;
				break;

				case ID_OPTIONS_SHOW_LOG:
					_AS->WriteLogMessage("Open Log");
					sprintf(byTemp, "%s"AS_LOG_FILE, _AS->byProgramPath);
					ShellExecute(0, "open", byTemp, 0, 0, SW_SHOW);				
				break;

			// Help:
				case ID_HELP_HELP:
					OpenHelp();
				break;
				
				case ID_HELP_CREACTIVE_MEDIA_HOMEPAGE:
					OpenCreactiveMediaHomepage();
				break;

				case ID_HELP_ECLYPSE_ENTERTAINMENT_HOMEPAGE:
					OpenEclypseEntertainmentHomepage();
				break;

				case ID_HELP_CREDITS:
					OpenCreditsDialog(hWnd);
				break;
			}
		break;

        case WM_SIZE:
			// We change the size of our window:
			if(wParam == SIZE_MINIMIZED)
			{
				InvalidateRect(hWnd, NULL, TRUE);
				_AS->SetActive(FALSE);
				if(_ASConfig->bFullScreen && _ASConfig->bFullScreen)
				{
					_ASConfig->bFullScreen = FALSE;
					ChangeDisplayMode();
					SendMessage(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), WM_SYSCOMMAND, SC_MINIMIZE, 0);
					_ASConfig->bFullScreen = TRUE;
					_AS->bFullScreen = FALSE;
					break;
				}
			}
			else
			{
				if(!_AS->GetActive())
				{
					_AS->SetActive(TRUE);
					if(!_AS->bFullScreen && _ASConfig->bFullScreen)
					{
						_AS->bFullScreen = _ASConfig->bFullScreen;
						ChangeDisplayMode();
					}
				}
			}
			i = _AS->FindWindowID(hWnd);
			if(i == -1)
				break;
			_ASConfig->iWindowWidth = LOWORD(lParam);
			_ASConfig->iWindowHeight = HIWORD(lParam);
			_AS->pWindow[i].Resize(LOWORD(lParam), HIWORD(lParam));
		break;

		case WM_ACTIVATE:
			if(LOWORD(wParam) == WA_INACTIVE || ((BOOL) HIWORD(wParam)))
				break;
			i = _AS->FindWindowID(hWnd);
			if(i == -1)
				break;
			_AS->pWindow[i].Resize(_ASConfig->iWindowWidth, _ASConfig->iWindowHeight);
		break;

		case WM_SYSKEYUP:
			switch(wParam)
			{
				case VK_RETURN:
					// Switch to fullscreen or to window mode:
					_ASConfig->bFullScreen = !_ASConfig->bFullScreen;
					ChangeDisplayMode();
				break;
			}
		break;

		case WM_CLOSE:
			_AS->SetShutDown(TRUE);
		return 0;
    }
    return DefWindowProc(hWnd, uMsg, wParam, lParam);
} // end WindowProc()
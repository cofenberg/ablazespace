//-----------------------------------------------------------------------------
// File: Surface.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Structures: ****************************************************************
typedef struct ANIMATION_TOOL
{
	int iColumns, iRows, iMoveX, iMoveY, iSteps;

} ANIMATION_TOOL;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
ANIMATION_TOOL AnimationTool;
HWND hWndBitmap, hWndBitmap2, hWndBitmap3, hWndBitmap4, hWndBitmap5;
HDC hDCBitmap, hDCBitmap2, hDCBitmap3, hDCBitmap4, hDCBitmap5;
HWND hWndSurfaces, hWndSurface, hWndTextures;
BOOL bSurfaceSave, bAnimation;
FLOAT3 fTextureViewPos, fTextureViewPos2, fTextureViewPos3, fTextureViewRot;
int iCurrentTexturePos, iCurrentTextureAniStep, iCurrentTextureAniStep2;
char byFilenameTemp[MAX_PATH];
FLOAT2 fCursorPos;
long lTimer, lTimer2;
BOOL bNewSurface, bTexturePosAdvanced;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
LRESULT CALLBACK SurfacesProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK SurfaceProc(HWND, UINT, WPARAM, LPARAM);
void SurfaceUpdate(void);
LRESULT CALLBACK TexturesProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK CopyTexturePosProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK SetAnimationStepsProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK AnimationToolProc(HWND, UINT, WPARAM, LPARAM);
///////////////////////////////////////////////////////////////////////////////


// SURFACE functions: *********************************************************
SURFACE::SURFACE(void)
{ // begin SURFACE::SURFACE()
	memset(this, 0, sizeof(SURFACE));
} // end SURFACE::SURFACE()

SURFACE::~SURFACE(void)
{ // begin SURFACE::~SURFACE()
} // end SURFACE::~SURFACE()

HRESULT SURFACE::Load(char *pbyFilename)
{ // begin SURFACE::Load()
	FILE *fp;
	int i, i2;

	char byTemp[256];

	_AS->WriteLogMessage("Load surface: %s", pbyFilename);	
	fp = fopen(pbyFilename, "rb");
	if(!fp)
		return 1;

	// Load general information:
	i = Header.iID;
	fread(&Header, sizeof(SURFACE_HEADER), 1, fp);
	Header.iID = i;

	// Update the surface filename:
	strcpy(Header.byFilename, pbyFilename);

	pTexturePos = (TEXTURE_POS *) malloc(sizeof(TEXTURE_POS)*Header.iAniSteps);
	byTextureFilename = (char **) malloc(sizeof(char *)*Header.iAniSteps);
	iTextureID = (int *) malloc(sizeof(int)*Header.iAniSteps);
	pTexture = (AS_TEXTURE **) malloc(sizeof(AS_TEXTURE *)*Header.iAniSteps);

	// Load the animation steps:
	for(i2 = 0; i2 < Header.iAniSteps; i2++)
	{
		byTextureFilename[i2] = (char *) malloc(sizeof(char)*MAX_PATH);
		fread(byTextureFilename[i2], sizeof(char)*MAX_PATH, 1, fp);
		strcpy(byTemp, byTextureFilename[i2]);
		for(i = 0; i < 9; i++)
			fread(&pTexturePos[i2].iPos[i], sizeof(INT2), 1, fp);
		fread(&pTexturePos[i2].iTimeToNext, sizeof(long), 1, fp);
		iTextureID[i2] = 0;
		pTexture[i2] = NULL;
	}
	fclose(fp);

	// Check if we have to load a texture:
	for(i2 = 0; i2 < Header.iAniSteps; i2++)
	{
		pLevel->LoadTexture(byTextureFilename[i2]);
		iTextureID[i2] = pLevel->iCurrentTexture;
		pTexture[i2] = pLevel->pCurrentTexture;
	}
	
	// Give this surface the right texture:
	CalculateFloatTexturePos();

	return 0;
} // end SURFACE::Load()

HRESULT SURFACE::Save(char *pbyFilename)
{ // begin SURFACE::Save()
	FILE *fp;
	int i, i2;

	_AS->WriteLogMessage("Save surface: %s", pbyFilename);	
	fp = fopen(pbyFilename, "wb");
	if(!fp)
		return 1;

	// Update the surface filename:
	strcpy(Header.byFilename, pbyFilename);

	// Load general information:
	fwrite(&Header, sizeof(SURFACE_HEADER), 1, fp);

	// Save the animation steps:
	for(i2 = 0; i2 < Header.iAniSteps; i2++)
	{
		fwrite(byTextureFilename[i2], sizeof(char)*MAX_PATH, 1, fp);
		for(i = 0; i < 9; i++)
			fwrite(&pTexturePos[i2].iPos[i], sizeof(INT2), 1, fp);
		fwrite(&pTexturePos[i2].iTimeToNext, sizeof(long), 1, fp);
	}
	fclose(fp);
	return 0;
} // end SURFACE::Save()

void SURFACE::CalculateFloatTexturePos(void)
{ // begin SURFACE::CalculateFloatTexturePos()
	int i, i2;

	for(i2 = 0; i2 < Header.iAniSteps; i2++)
	{
		for(i = 0; i < 9; i++)
		{
			pTexturePos[i2].fPos[i][X] = ((float) pTexturePos[i2].iPos[i][X])/pTexture[i2]->iWidth;
			pTexturePos[i2].fPos[i][Y] = ((float) pTexturePos[i2].iPos[i][Y])/pTexture[i2]->iHeight;
		}
		
		// Looks more fine: (because there is not enough precision)
		pTexturePos[i2].fPos[0][X] += 0.001f;
		pTexturePos[i2].fPos[0][Y] -= 0.001f;
		
		pTexturePos[i2].fPos[2][X] -= 0.001f;
		pTexturePos[i2].fPos[2][Y] -= 0.001f;

		pTexturePos[i2].fPos[4][X] -= 0.001f;
		pTexturePos[i2].fPos[4][Y] += 0.001f;
		
		pTexturePos[i2].fPos[6][X] += 0.001f;
		pTexturePos[i2].fPos[6][Y] += 0.001f;
	}
} // end SURFACE::CalculateFloatTexturePos()

void SURFACE::Destroy(void)
{ // begin SURFACE::Destroy()
	int i;

	for(i = 0; i < Header.iAniSteps; i++)
		SAFE_DELETE(byTextureFilename[i]);
	SAFE_DELETE(byTextureFilename);
	for(i = 0; i < Header.iAniSteps; i++)
		pTexture[i]->iUsed--;
	SAFE_DELETE(pTexture);
	SAFE_DELETE(pTexturePos);
	SAFE_DELETE(iTextureID);
} // end SURFACE::Destroy()

void SURFACE::ChangeAnimationSteps(int iAniStepsT)
{ // begin SURFACE::AddAnimationStep()
	int i;
	
	if(iAniStepsT < Header.iAniSteps)
	{ // Delete the old filenames:
		for(i =	iAniStepsT; i < Header.iAniSteps; i++)
			free(byTextureFilename[i]);
	}
	byTextureFilename = (char **) realloc(byTextureFilename, sizeof(char *)*iAniStepsT);
	pTexturePos = (TEXTURE_POS *) realloc(pTexturePos, sizeof(TEXTURE_POS)*iAniStepsT);
	iTextureID = (int *) realloc(iTextureID, sizeof(int)*iAniStepsT);
	pTexture = (AS_TEXTURE **) realloc(pTexture, sizeof(AS_TEXTURE *)*iAniStepsT);
	for(i =	Header.iAniSteps; i < iAniStepsT; i++)
	{
		byTextureFilename[i] = (char *) malloc(sizeof(char)*MAX_PATH);
		memset(&pTexturePos[i], 0, sizeof(TEXTURE_POS));
		iTextureID[i] = 0;
		pTexture[i] = &pLevel->pTexture[iTextureID[i]];
		strcpy(byTextureFilename[i], pLevel->pTexture[iTextureID[i]].byFilename);
	}
	Header.iAniSteps = iAniStepsT;
	CalculateFloatTexturePos();
} // end SURFACE::AddAnimationStep()

// Functions: *****************************************************************
LRESULT CALLBACK SurfacesProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin SurfacesProc()
	char *pbyTemp, byTemp[256], byTemp2[256], byTemp3[256], byTemp4[256];
	static POINT MousePos, OldMousePos;
	TEXTURE_POS *pTexturePos;
	SURFACE *pSurfaceT = pLevel->pCurrentSurface;
	FLOAT3 *pFloat;
	RECT Rect;
	FILE *fp;
	int i;

    switch(iMessage)
    {
        case WM_INITDIALOG:
				if(hWndSurfaces)
				{
					EndDialog(hWnd, FALSE);
					break;
				}
				hWndSurfaces = hWnd;
				SetWindowText(hWnd, AS_T(T_Surfaces));
				SetDlgItemText(hWnd, ID_SURFACES_OK, AS_T(T_Ok));
				SetDlgItemText(hWnd, ID_SURFACES_NEW, AS_T(T_New));
				SetDlgItemText(hWnd, ID_SURFACES_ADJUST, AS_T(T_Adjust));
				SetDlgItemText(hWnd, ID_SURFACES_LOAD, AS_T(T_Load));
				SetDlgItemText(hWnd, ID_SURFACES_UNLOAD, AS_T(T_Unload));
				SetDlgItemText(hWnd, ID_SURFACES_RESET_TEXTURE_VIEW, AS_T(T_Reset));
				iCurrentTextureAniStep = 0;
				lTimer = g_lGameTimer;
			    hWndBitmap3 = GetDlgItem(hWnd, ID_SURFACES_SHOW);
				ASInitOpenGL(NULL, hWndBitmap3, &hDCBitmap3, &hRCEditorShow, FALSE);
				SetTimer(hWnd, 1, 1, NULL);
				_AS->WriteLogMessage("Open surfaces dialog");
				if(pLevel->iCurrentSurface < 0 || pLevel->iCurrentSurface > pLevel->Header.iSurfaces-1)
					pLevel->iCurrentSurface = 0;
				fTextureViewPos[X] = fTextureViewPos[Y] = 0.0f;
				fTextureViewPos[Z] = -3.0f;
			Init:
				SendDlgItemMessage(hWnd, ID_SURFACES_LIST, LB_RESETCONTENT , 0, 0L);
				for(i = 0; i < pLevel->Header.iSurfaces; i++)
				{
					sprintf(byTemp, "%s (Used:%d)", pLevel->pSurface[i].Header.byName, pLevel->pSurface[i].iUsed);
					SendDlgItemMessage(hWnd, ID_SURFACES_LIST, LB_ADDSTRING, 0, (LPARAM) byTemp);
				}
				SendDlgItemMessage(hWnd, ID_SURFACES_LIST, LB_SETCURSEL, pLevel->iCurrentSurface, 0L);
				if(!pLevel->Header.iSurfaces)
				{	
					EnableWindow(GetDlgItem(hWnd, ID_SURFACES_ADJUST), FALSE);
					EnableWindow(GetDlgItem(hWnd, ID_SURFACES_UNLOAD), FALSE);
					pLevel->iCurrentSurface = 0;
				}
				else
				{
					i = (int) SendDlgItemMessage(hWnd, ID_SURFACES_LIST, LB_GETCURSEL, 0, 0L);
					if(i >= 0 && i <= pLevel->Header.iSurfaces-1)
					{
						pLevel->iCurrentSurface = i;
						EnableWindow(GetDlgItem(hWnd, ID_SURFACES_ADJUST), TRUE);
						EnableWindow(GetDlgItem(hWnd, ID_SURFACES_UNLOAD), TRUE);
					}
					else
						pLevel->iCurrentSurface = 0;
				}
				pLevel->pCurrentSurface = &pLevel->pSurface[pLevel->iCurrentSurface];
				if(!pLevel->iCurrentSurface)
				{	
					EnableWindow(GetDlgItem(hWnd, ID_SURFACES_ADJUST), FALSE);
					EnableWindow(GetDlgItem(hWnd, ID_SURFACES_UNLOAD), FALSE);
				}
				ShowWindow(hWnd, _AS->GetCmdShow());
				UpdateWindow(hWnd);
				BringWindowToTop(hWnd);
		return TRUE;

        case WM_LBUTTONDOWN: case WM_LBUTTONUP: case WM_RBUTTONDOWN:
        case WM_RBUTTONUP: case WM_MOUSEMOVE:
			i = wParam;
			memcpy(&OldMousePos, &MousePos, sizeof(POINT));
			GetCursorPos(&MousePos);
			GetWindowRect(hWnd, &Rect);
			GetWindowRect(hWndBitmap2, &Rect);
			pFloat = &fTextureViewPos;
			if(MousePos.x > Rect.left && MousePos.x < Rect.right &&
			   MousePos.y > Rect.top && MousePos.y < Rect.bottom)
			{ // The mouse is over the window enable view control:
				if(i & MK_LBUTTON && i & MK_RBUTTON)
					(*pFloat)[Z] -= (float) (MousePos.x-OldMousePos.x+MousePos.y-OldMousePos.y)/20;
				else
					if(i & MK_RBUTTON)
					{
						(*pFloat)[X] -= (float) (OldMousePos.x-MousePos.x)/100;
						(*pFloat)[Y] -= (float) (MousePos.y-OldMousePos.y)/100;
					}
			}
        break;

		case WM_TIMER:
			if(iCurrentTextureAniStep >= pSurfaceT->Header.iAniSteps)
				iCurrentTextureAniStep = 0;
			if(!wglMakeCurrent(hDCBitmap3, hRCEditorShow))
				break;
			glDisable(GL_LIGHTING);
			glDisable(GL_FOG);
			glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
			glLoadIdentity();
			glTranslatef(fTextureViewPos[X], fTextureViewPos[Y], fTextureViewPos[Z]);
			glEnable(GL_TEXTURE_2D);
			if(pSurfaceT && pSurfaceT->pTexture && pSurfaceT->pTexturePos)
			{
				if(pSurfaceT->Header.bEnvironmentMappingS)
					glEnable(GL_TEXTURE_GEN_S);
				if(pSurfaceT->Header.bEnvironmentMappingT)
					glEnable(GL_TEXTURE_GEN_T);
				pTexturePos = &pSurfaceT->pTexturePos[iCurrentTextureAniStep];
				if(pSurfaceT->pTexture[iCurrentTextureAniStep])
				{
					glBindTexture(GL_TEXTURE_2D, pSurfaceT->pTexture[iCurrentTextureAniStep]->iOpenGLID);
					glBegin(GL_QUADS);
						// Quad 3:
						glTexCoord2fv(pTexturePos->fPos[6]);
						glVertex3f(-1.0f, -1.0f, 1.0f);
						glTexCoord2fv(pTexturePos->fPos[5]);
						glVertex3f(0.0f, -1.0f, 1.0f);
						glTexCoord2fv(pTexturePos->fPos[8]);
						glVertex3f(0.0f, 0.0f, 1.0f);
						glTexCoord2fv(pTexturePos->fPos[7]);
						glVertex3f(-1.0f, 0.0f, 1.0f);
						// Quad 2:
						glTexCoord2fv(pTexturePos->fPos[5]);
						glVertex3f(0.0f, -1.0f, 1.0f);
						glTexCoord2fv(pTexturePos->fPos[4]);
						glVertex3f(1.0f, -1.0f, 1.0f);
						glTexCoord2fv(pTexturePos->fPos[3]);
						glVertex3f(1.0f, 0.0f, 1.0f);
						glTexCoord2fv(pTexturePos->fPos[8]);
						glVertex3f(0.0f, 0.0f, 1.0f);
						// Quad 1:
						glTexCoord2fv(pTexturePos->fPos[8]);
						glVertex3f(0.0f, 0.0f, 1.0f);
						glTexCoord2fv(pTexturePos->fPos[3]);
						glVertex3f(1.0f, 0.0f, 1.0f);
						glTexCoord2fv(pTexturePos->fPos[2]);
						glVertex3f(1.0f, 1.0f, 1.0f);
						glTexCoord2fv(pTexturePos->fPos[1]);
						glVertex3f(0.0f, 1.0f, 1.0f);
						// Quad 0:
						glTexCoord2fv(pTexturePos->fPos[7]);
						glVertex3f(-1.0f, 0.0f, 1.0f);
						glTexCoord2fv(pTexturePos->fPos[8]);
						glVertex3f(0.0f, 0.0f, 1.0f);
						glTexCoord2fv(pTexturePos->fPos[1]);
						glVertex3f(0.0f, 1.0f, 1.0f);
						glTexCoord2fv(pTexturePos->fPos[0]);
						glVertex3f(-1.0f, 1.0f, 1.0f);
					glEnd();
				}
				glDisable(GL_TEXTURE_GEN_S);
				glDisable(GL_TEXTURE_GEN_T);
			}
			ASSwapBuffers(hDCBitmap3, NULL, FALSE);
			// Animate the preview:
			if(!ASCheckTimeUpdate(&lTimer, pSurfaceT->pTexturePos[iCurrentTextureAniStep].iTimeToNext))
				break;
			iCurrentTextureAniStep++;
			if(iCurrentTextureAniStep >= pSurfaceT->Header.iAniSteps)
				iCurrentTextureAniStep = 0;
		break;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_SURFACES_OK:
					if(hDCBitmap3 && !ReleaseDC(hWnd, hDCBitmap3))
						hDCBitmap3 = NULL;
					EndDialog(hWnd, FALSE);
	 				KillTimer(hWnd, 1);
					hWndSurfaces = NULL;
					_AS->WriteLogMessage("Close surfaces dialog");
                return TRUE;

				case ID_SURFACES_NEW:
					if(hWndSurface)
						break;
					pLevel->CreateSurface();
					bNewSurface = TRUE;
					KillTimer(hWnd, 1);
					if(DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_SURFACE), hWnd, (DLGPROC) SurfaceProc) == TRUE)
					{
						SetTimer(hWnd, 1, 1, NULL);
						goto Init;
					}
					else
						SetTimer(hWnd, 1, 1, NULL);
				break;

				case ID_SURFACES_ADJUST:
					bNewSurface = FALSE;
					if(!pSurfaceT->Header.iID || hWndSurface)
						break;
					
					// Test is this surface already exist:
					if(!strcmp(pSurfaceT->Header.byFilename, "") || !(fp = fopen(pSurfaceT->Header.byFilename, "r")))
					{ // No. Ask the user if we should create it now:
						// Get filename:
						bSurfaceSave = TRUE;
						sprintf(byTemp, "%s%s", _AS->byProgramPath, _AS->bySurfacesDirectory);
						KillTimer(hWndSurfaces, 1);
						pbyTemp = ASGetFileName(hWnd, AS_T(T_SaveSurface), ASS_FILE, 1, FALSE, byTemp, NULL);
						SetTimer(hWndSurfaces, 1, 1, NULL);
						bSurfaceSave = FALSE;
						if(!pbyTemp)
							break;
						strcpy(pSurfaceT->Header.byFilename, pbyTemp);
					}
					else
						fclose(fp);

					if(pSurfaceT->Save(pSurfaceT->Header.byFilename))
					{
						sprintf(byTemp, "%s: %s", pSurfaceT->Header.byFilename, AS_M(M_SaveSurfaceFailed));
						KillTimer(hWndSurfaces, 1);
						if(MessageBox(hWndSurfaces, byTemp, AS_T(T_Error), MB_YESNO | MB_ICONINFORMATION) == IDNO)
						{
							SetTimer(hWndSurfaces, 1, 1, NULL);
							_AS->WriteLogMessage("Save  %s  failed! User didn't left the surface dialog.", pSurfaceT->Header.byFilename);
							break;
						}
						SetTimer(hWndSurfaces, 1, 1, NULL);
						_AS->WriteLogMessage("Save  %s  failed! User left surface dialog without saving.", pSurfaceT->Header.byFilename);
						break;
					}
					KillTimer(hWnd, 1);
					if(DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_SURFACE), hWnd, (DLGPROC) SurfaceProc) == TRUE)
					{
						SetTimer(hWnd, 1, 1, NULL);
						goto Init;
					}
					SetTimer(hWnd, 1, 1, NULL);
				break;

				case ID_SURFACES_LOAD:
					sprintf(byTemp, "%s%s", _AS->byProgramPath, _AS->bySurfacesDirectory);
					KillTimer(hWndSurfaces, 1);
					pbyTemp = ASGetFileName(hWnd, AS_T(T_LoadSurface), ASS_FILE, 0, TRUE, byTemp, NULL);
					SetTimer(hWndSurfaces, 1, 1, NULL);
					if(!pbyTemp)
						break;
					// 	
					fp = fopen(pbyTemp, "rb");
					if(fp) // It's only one file:
					{
						fclose(fp);
						pLevel->LoadSurface(pbyTemp);
						pSurfaceT = pLevel->pCurrentSurface;
						// Insert the surface into the surface list:
						sprintf(byTemp, "%s (Used:%d)", pSurfaceT->Header.byName, pSurfaceT->iUsed);
						SendDlgItemMessage(hWnd, ID_SURFACES_LIST, LB_ADDSTRING, 0, (LPARAM) byTemp);
						SendDlgItemMessage(hWnd, ID_SURFACES_LIST, LB_SETCURSEL, pLevel->iCurrentSurface, 0L);
						pLevel->DestroyTexturesOpenGL(hDCEditorShow, 
												  hRCEditorShow);
						pLevel->GenTexturesOpenGL(hDCEditorShow, 
												  hRCEditorShow);
						goto Init;
					}
					//
					sscanf(pbyTemp, "%s", byTemp); // Read the path
					pbyTemp += strlen(byTemp)+1;
					// Load the selected files:
					for(;;)
					{
						if(sscanf(pbyTemp, "%s", byTemp2) == EOF)
							break;
						if(byTemp[strlen(byTemp)-1] != '\\')
							sprintf(byTemp3, "%s\\%s", byTemp, byTemp2);
						else
							sprintf(byTemp3, "%s%s", byTemp, byTemp2);
						if(pLevel->LoadSurface(byTemp3))
							break;
						// Insert the surface into the surface list:
						pSurfaceT = pLevel->pCurrentSurface;
						sprintf(byTemp4, "%s (Used:%d)", pSurfaceT->Header.byName, pSurfaceT->iUsed);
						SendDlgItemMessage(hWnd, ID_SURFACES_LIST, LB_ADDSTRING, 0, (LPARAM) byTemp4);
						SendDlgItemMessage(hWnd, ID_SURFACES_LIST, LB_SETCURSEL, pLevel->iCurrentSurface, 0L);
						if(*(pbyTemp+strlen(byTemp2)) == 0)
							break;
						pbyTemp += strlen(byTemp2)+1;
					}
					pLevel->DestroyTexturesOpenGL(hDCEditorShow, 
										  hRCEditorShow);
					pLevel->GenTexturesOpenGL(hDCEditorShow, 
											  hRCEditorShow);
					goto Init;

				case ID_SURFACES_UNLOAD:
					if(!pSurfaceT->Header.iID)
						break;
					// Destroy the surface:
					if(pSurfaceT->iUsed)
					{
						sprintf(byTemp, "%s %s %d)", pSurfaceT->Header.byName,
													 AS_M(M_SurfaceIsUsed), pSurfaceT->iUsed);
						KillTimer(hWndSurfaces, 1);
						if(MessageBox(hWndSurfaces, byTemp, AS_T(T_Question), MB_YESNO | MB_ICONINFORMATION) == IDNO)
						{
							SetTimer(hWndSurfaces, 1, 1, NULL);
							break;
						}
						SetTimer(hWndSurfaces, 1, 1, NULL);
					}
					pLevel->DestroySurface(pLevel->iCurrentSurface);
					goto Init;

				case ID_SURFACES_LIST:
					i = (int) SendDlgItemMessage(hWnd, ID_SURFACES_LIST, LB_GETCURSEL, 0, 0L);
					if(i < 0 || i > pLevel->Header.iSurfaces-1)
					{
						pLevel->iCurrentSurface	= -1;
						pSurfaceT = NULL;
					}
					else
					{
						pLevel->iCurrentSurface	= i;
						pSurfaceT = &pLevel->pSurface[pLevel->iCurrentSurface];
					}
					if(pLevel->iCurrentSurface >= 0 || pLevel->iCurrentSurface <= pLevel->Header.iSurfaces)
					{
						EnableWindow(GetDlgItem(hWnd, ID_SURFACES_ADJUST), TRUE);
						EnableWindow(GetDlgItem(hWnd, ID_SURFACES_UNLOAD), TRUE);
					}
					else
					{
						EnableWindow(GetDlgItem(hWnd, ID_SURFACES_ADJUST), FALSE);
						EnableWindow(GetDlgItem(hWnd, ID_SURFACES_UNLOAD), FALSE);
					}
					iCurrentTextureAniStep = 0;
					lTimer = g_lGameTimer;
					goto Init;

				case ID_SURFACES_RESET_TEXTURE_VIEW:
					fTextureViewPos[X] = fTextureViewPos[Y] = 0.0f;
					fTextureViewPos[Z] = -5.0f;
				break;
            }
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_SURFACES_OK, 0);
		break;
    }
    return FALSE;
} // end SurfacesProc()

LRESULT CALLBACK SurfaceProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin SurfaceProc()
	int i, i2, iX, iY, x, y, iDeltaX, iDeltaY, iT, iHeight;
	SURFACE *pSurfaceT = pLevel->pCurrentSurface;
	TEXTURE_POS *pTexturePosT, *pTexturePosT2;
	static POINT MousePos, OldMousePos;
    char *pbyTemp, byTemp[256];
	TEXTURE_POS *pTexturePos;
	static int iMouseButton;
	FLOAT3 *pFloat;
	RECT Rect;

	switch(iMessage)
    {
        case WM_INITDIALOG:
				if(hWndSurface)
				{
					EndDialog(hWnd, FALSE);
					break;
				}
				fCursorPos[X] = 0.0f;
				fCursorPos[Y] = 0.0f;
				iCurrentTextureAniStep2 = 0;
				hWndSurface = hWnd;
				// Texts
				SetWindowText(hWnd, AS_T(T_Surface));
				SetDlgItemText(hWnd, ID_SURFACE_OK, AS_T(T_Ok));
				SetDlgItemText(hWnd, ID_SURFACE_CANCEL, AS_T(T_Cancel));
				SetDlgItemText(hWnd, ID_SURFACE_RESET_TEXTURE_VIEW, AS_T(T_Reset));
				SetDlgItemText(hWnd, ID_SURFACE_RESET_TEXTURE_VIEW2, AS_T(T_Reset));
				SetDlgItemText(hWnd, IDC_SURFACE_TEXTURE_T, AS_T(T_Texture));
				SetDlgItemText(hWnd, IDC_SURFACE_WHOLE_TEXTURE, AS_T(T_WholeTexture));
				SetDlgItemText(hWnd, IDC_SURFACE_NAME_T, AS_T(T_Name));
				SetDlgItemText(hWnd, IDC_SURFACE_FILENAME_T, AS_T(T_File));
				SetDlgItemText(hWnd, IDC_SURFACE_TEXTURE_SELECTION_T, AS_T(T_Texture));
				SetDlgItemText(hWnd, ID_SURFACE_TEXTURE_POS_ADVANCED, AS_T(T_Advanced));
				SetDlgItemText(hWnd, IDC_SURFACE_TEXTURE_POS_T, AS_T(T_TexturePos));
				SetDlgItemText(hWnd, ID_SURFACE_TEXTURE_ANI_STEPS, AS_T(T_Steps));
				SetDlgItemText(hWnd, IDC_SURFACE_ANIMATE, AS_T(T_Play));
				SetDlgItemText(hWnd, IDC_SURFACE_COPY, AS_T(T_Copy));
				SetDlgItemText(hWnd, IDC_SURFACE_MOVE, AS_T(T_Move));
				SetDlgItemText(hWnd, IDC_SURFACE_NEXT_TIME_T, AS_T(T_NextTime));
				SetDlgItemText(hWnd, IDC_SURFACE_NEXT_TIME_ALL, AS_T(T_All));
				SetDlgItemText(hWnd, IDC_SURFACE_ANIMATION_T, AS_T(T_Animation));
				SetDlgItemText(hWnd, IDC_SURFACE_ANIMATION_TOOL, AS_T(T_AnimationTool));
				// Attributes:				
				SetDlgItemText(hWnd, IDC_SURFACE_ATTRIBUTES_T, AS_T(T_Attributes));
				SetDlgItemText(hWnd, IDC_SURFACE_FRICTION_T, AS_T(T_Friction));
				SetDlgItemText(hWnd, IDC_SURFACE_AT_ALCOVE, AS_T(T_Alcove));
				SetDlgItemText(hWnd, IDC_SURFACE_AT_RADIOACTIVE, AS_T(T_Radioactive));
				SetDlgItemText(hWnd, IDC_SURFACE_AT_HEALTH, AS_T(T_Health));
				SetDlgItemText(hWnd, IDC_SURFACE_AT_EXIT, AS_T(T_Exit));
				SetDlgItemText(hWnd, IDC_SURFACE_AT_HOLE, AS_T(T_Hole));
				SetDlgItemText(hWnd, IDC_SURFACE_AT_ANCHOR, AS_T(T_Anchor));
				SetDlgItemText(hWnd, IDC_SURFACE_AT_COLOR_PAINTER, AS_T(T_ColorPainter));
				SetDlgItemText(hWnd, IDC_SURFACE_AT_COLOR_SCANNER, AS_T(T_ColorScanner));
				SetDlgItemText(hWnd, IDC_SURFACE_ATTRIBUTES_CHANGE_T, AS_T(T_Change));
				SetDlgItemText(hWnd, IDC_SURFACE_AT_CHANGE_ON_ENTER, AS_T(T_Enter));
				SetDlgItemText(hWnd, IDC_SURFACE_AT_CHANGE_ON_LEAVE, AS_T(T_Leave));
				SetDlgItemText(hWnd, IDC_SURFACE_AT_CHANGE_ON_ANIMATION_END, AS_T(T_AnimationEnd));
				SetDlgItemText(hWnd, IDC_SURFACE_AT_CHANGE_ON_TIME, AS_T(T_Time));
				SetDlgItemText(hWnd, IDC_SURFACE_AT_BEAMER, AS_T(T_Beamer));
				SetDlgItemText(hWnd, IDC_SURFACE_ATTRIBUTES_ENVIRONMENT_MAPPING, AS_T(T_EnvironmentMapping));
				
				//
				SendDlgItemMessage(hWnd, ID_SURFACE_TEXTURE_POS_ADVANCED, BM_SETCHECK, bTexturePosAdvanced, 0L);
				_AS->WriteLogMessage("Open surface dialog");
			    hWndBitmap = GetDlgItem(hWnd, ID_SURFACE_TEXTURE_SHOW);
			    hWndBitmap5 = GetDlgItem(hWnd, ID_SURFACE_TEXTURE_SHOW2);
				ASInitOpenGL(NULL, hWndBitmap, &hDCBitmap, &hRCEditorShow, FALSE);
				ASInitOpenGL(NULL, hWndBitmap5, &hDCBitmap5, &hRCEditorShow, FALSE);
				SetTimer(hWnd, 1, 1, NULL);
				iCurrentTexturePos = 0;
				strcpy(byFilenameTemp, pSurfaceT->Header.byFilename);
				if(pSurfaceT->iTextureID[iCurrentTextureAniStep2] != -1)
					iCurrentTexturePos = 0;
				else
					iCurrentTexturePos = -1;
				fTextureViewPos2[X] = 0.0f;
				fTextureViewPos2[Y] = 0.0f;
				fTextureViewPos2[Z] = -5.0f;
				fTextureViewPos3[X] = 0.0f;
				fTextureViewPos3[Y] = (float) -pSurfaceT->pTexture[iCurrentTextureAniStep2]->iHeight;
				fTextureViewPos3[Z] = 500.0f;
				bAnimation = 0;
				lTimer2 = g_lGameTimer;
			    SendDlgItemMessage(hWnd, IDC_SURFACE_MOVE, BM_SETCHECK, 0, 0L);
				// Attributes:
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_ALCOVE, BM_SETCHECK, pSurfaceT->Header.bAlcove, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_RADIOACTIVE, BM_SETCHECK, pSurfaceT->Header.bRadioactive, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_HEALTH, BM_SETCHECK, pSurfaceT->Header.bHealth, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_EXIT, BM_SETCHECK, pSurfaceT->Header.bExit, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_HOLE, BM_SETCHECK, pSurfaceT->Header.bHole, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_ANCHOR, BM_SETCHECK, pSurfaceT->Header.bAnchor, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_COLOR_PAINTER, BM_SETCHECK, pSurfaceT->Header.bColorPainter, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_COLOR_SCANNER, BM_SETCHECK, pSurfaceT->Header.bColorScanner, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_ANCHOR_TYPE, CB_RESETCONTENT , 0, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_ANCHOR_TYPE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_ForAll));
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_ANCHOR_TYPE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Normal));
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_ANCHOR_TYPE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Red));
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_ANCHOR_TYPE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Green));
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_ANCHOR_TYPE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Blue));
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_ANCHOR_TYPE, CB_SETCURSEL, pSurfaceT->Header.byAnchorType, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_COLOR_PAINTER_TYPE, CB_RESETCONTENT , 0, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_COLOR_PAINTER_TYPE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Normal));
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_COLOR_PAINTER_TYPE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Red));
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_COLOR_PAINTER_TYPE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Green));
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_COLOR_PAINTER_TYPE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Blue));
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_COLOR_PAINTER_TYPE, CB_SETCURSEL, pSurfaceT->Header.byColorPainterType, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_COLOR_SCANNER_TYPE, CB_RESETCONTENT , 0, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_COLOR_SCANNER_TYPE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Normal));
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_COLOR_SCANNER_TYPE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Red));
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_COLOR_SCANNER_TYPE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Green));
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_COLOR_SCANNER_TYPE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Blue));
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_COLOR_SCANNER_TYPE, CB_SETCURSEL, pSurfaceT->Header.byColorScannerType, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_ENTER, BM_SETCHECK, pSurfaceT->Header.bChangeOnEnter, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_LEAVE, BM_SETCHECK, pSurfaceT->Header.bChangeOnLeave, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_ANIMATION_END, BM_SETCHECK, pSurfaceT->Header.bChangeOnAnimationEnd, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_TIME, BM_SETCHECK, pSurfaceT->Header.bChangeOnTime, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_ATTRIBUTES_ENVIRONMENT_MAPPING_S, BM_SETCHECK, pSurfaceT->Header.bEnvironmentMappingS, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_ATTRIBUTES_ENVIRONMENT_MAPPING_T, BM_SETCHECK, pSurfaceT->Header.bEnvironmentMappingT, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_ENTER_SURFACE, CB_RESETCONTENT, 0, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_LEAVE_SURFACE, CB_RESETCONTENT, 0, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_ANIMATION_END_SURFACE, CB_RESETCONTENT, 0, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_TIME_SURFACE, CB_RESETCONTENT, 0, 0L);
				for(i = 0; i < pLevel->Header.iSurfaces; i++)
				{
					sprintf(byTemp, "%s", pLevel->pSurface[i].Header.byName, pLevel->pSurface[i].iUsed);
					SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_ENTER_SURFACE, CB_ADDSTRING, 0, (LPARAM) byTemp);
					SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_LEAVE_SURFACE, CB_ADDSTRING, 0, (LPARAM) byTemp);
					SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_ANIMATION_END_SURFACE, CB_ADDSTRING, 0, (LPARAM) byTemp);
					SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_TIME_SURFACE, CB_ADDSTRING, 0, (LPARAM) byTemp);
				}
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_ENTER_SURFACE, CB_SETCURSEL, pSurfaceT->Header.iChangeOnEnterSurface, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_LEAVE_SURFACE, CB_SETCURSEL, pSurfaceT->Header.iChangeOnLeaveSurface, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_ANIMATION_END_SURFACE, CB_SETCURSEL, pSurfaceT->Header.iChangeOnAnimationEndSurface, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_TIME_SURFACE, CB_SETCURSEL, pSurfaceT->Header.iChangeOnTimeSurface, 0L);
				sprintf(byTemp, "%d", pSurfaceT->Header.lChangeTime);
				SetDlgItemText(hWnd, IDC_SURFACE_AT_CHANGE_ON_TIME_TIME, byTemp);
				sprintf(byTemp, "%f", pSurfaceT->Header.fAlcoveSpeed);
				SetDlgItemText(hWnd, IDC_SURFACE_AT_ALCOVE_SPEED, byTemp);
				sprintf(byTemp, "%f", pSurfaceT->Header.fRadioactiveSpeed);
				SetDlgItemText(hWnd, IDC_SURFACE_AT_RADIOACTIVE_SPEED, byTemp);
				sprintf(byTemp, "%f", pSurfaceT->Header.fHealthSpeed);
				SetDlgItemText(hWnd, IDC_SURFACE_AT_HEALTH_SPEED, byTemp);
				sprintf(byTemp, "%f", pSurfaceT->Header.fFriction);
				SetDlgItemText(hWnd, IDC_SURFACE_FRICTION, byTemp);

			Init:
				SurfaceUpdate();
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_BEAMER, BM_SETCHECK, pSurfaceT->Header.bBeamer, 0L);
				SetDlgItemText(hWnd, ID_SURFACE_NAME, pSurfaceT->Header.byName);
				SetDlgItemText(hWnd, ID_SURFACE_FILENAME, pSurfaceT->Header.byFilename);
				SendDlgItemMessage(hWnd, ID_SURFACE_TEXTURE, CB_RESETCONTENT , 0, 0L);
				for(i = 0; i < pLevel->Header.iTextures; i++)
				{
					sprintf(byTemp, "%s (Used:%d)", pLevel->pTexture[i].byFilename, pLevel->pTexture[i].iUsed);
					SendDlgItemMessage(hWnd, ID_SURFACE_TEXTURE, CB_ADDSTRING, 0, (LPARAM) byTemp);
				}
				if(pSurfaceT->iTextureID[iCurrentTextureAniStep2] != -1)
					SendDlgItemMessage(hWnd, ID_SURFACE_TEXTURE, CB_SETCURSEL, pSurfaceT->iTextureID[iCurrentTextureAniStep2], 0L);
				EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_1), TRUE);
				EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_2), TRUE);
				EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_3), TRUE);
				EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_4), TRUE);
				EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_5), TRUE);
				EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_6), TRUE);
				EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_7), TRUE);
				EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_8), TRUE);
				EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_9), TRUE);
				switch(iCurrentTexturePos)
				{
					case 0:	EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_1), FALSE); break;
					case 1:	EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_2), FALSE); break;
					case 2:	EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_3), FALSE); break;
					case 3:	EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_4), FALSE); break;
					case 4:	EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_5), FALSE); break;
					case 5:	EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_6), FALSE); break;
					case 6:	EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_7), FALSE); break;
					case 7:	EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_8), FALSE); break;
					case 8:	EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_9), FALSE); break;
				}
				if(bTexturePosAdvanced)
				{
					fCursorPos[X] = (float) pSurfaceT->pTexturePos[iCurrentTextureAniStep2].iPos[iCurrentTexturePos][X];
					fCursorPos[Y] = (float) pSurfaceT->pTexturePos[iCurrentTextureAniStep2].iPos[iCurrentTexturePos][Y];
				}
				else
				{
					if(iCurrentTexturePos > 3)
						iCurrentTexturePos = 0;
					i = iCurrentTexturePos*2;
					fCursorPos[X] = (float) pSurfaceT->pTexturePos[iCurrentTextureAniStep2].iPos[i][X];
					fCursorPos[Y] = (float) pSurfaceT->pTexturePos[iCurrentTextureAniStep2].iPos[i][Y];
				}

				sprintf(byTemp, "%d", pSurfaceT->pTexturePos[iCurrentTextureAniStep2].iTimeToNext);
				SetDlgItemText(hWnd, IDC_SURFACE_NEXT_TIME, byTemp);
				sprintf(byTemp, "%d", (int) fCursorPos[X]);
				SetDlgItemText(hWnd, ID_SURFACE_TEXTURE_POS_X, byTemp);
				sprintf(byTemp, "%d", (int) fCursorPos[Y]);
				SetDlgItemText(hWnd, ID_SURFACE_TEXTURE_POS_Y, byTemp);
				
				EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_X), TRUE);
				EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_Y), TRUE);
				if(pSurfaceT->iTextureID[iCurrentTextureAniStep2] == -1)
				{
					EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_1), FALSE);
					EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_2), FALSE);
					EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_3), FALSE);
					EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_4), FALSE);
					EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_X), FALSE);
					EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_Y), FALSE);
				}
				SendDlgItemMessage(hWnd, ID_SURFACE_TEXTURE_ANIS, CB_RESETCONTENT , 0, 0L);
				for(i = 0; i < pSurfaceT->Header.iAniSteps; i++)
				{
					sprintf(byTemp, "%d", i);
					SendDlgItemMessage(hWnd, ID_SURFACE_TEXTURE_ANIS, CB_ADDSTRING, 0, (LPARAM) byTemp);
				}
				SendDlgItemMessage(hWnd, ID_SURFACE_TEXTURE_ANIS, CB_SETCURSEL, iCurrentTextureAniStep2, 0L);
				ShowWindow(hWnd, _AS->GetCmdShow());
				UpdateWindow(hWnd);
				BringWindowToTop(hWnd);
		return TRUE;

        case WM_LBUTTONDOWN: case WM_LBUTTONUP: case WM_RBUTTONDOWN:
        case WM_RBUTTONUP: case WM_MOUSEMOVE:
			iMouseButton = wParam;
			memcpy(&OldMousePos, &MousePos, sizeof(POINT));
			GetCursorPos(&MousePos);
			GetWindowRect(hWndBitmap, &Rect);
			pFloat = &fTextureViewPos3;
			if(MousePos.x > Rect.left && MousePos.x < Rect.right &&
			   MousePos.y > Rect.top && MousePos.y < Rect.bottom)
			{ // The mouse is over the window enable view control:
				if(iMouseButton & MK_LBUTTON && iMouseButton & MK_RBUTTON)
					(*pFloat)[Z] -= (float) (MousePos.x-OldMousePos.x+MousePos.y-OldMousePos.y);
				else
					if(iMouseButton & MK_LBUTTON)
					{
						fCursorPos[X] -= (float) (OldMousePos.x-MousePos.x);
						fCursorPos[Y] += (float) (MousePos.y-OldMousePos.y);
						if(fCursorPos[X] < 0.0f)
							fCursorPos[X] = 0.0f;
						if(fCursorPos[X] >= pSurfaceT->pTexture[iCurrentTextureAniStep2]->iWidth)
							fCursorPos[X] = (float) pSurfaceT->pTexture[iCurrentTextureAniStep2]->iWidth-1;
						if(fCursorPos[Y] < 0.0f)
							fCursorPos[Y] = 0.0f;
						if(fCursorPos[Y] >= pSurfaceT->pTexture[iCurrentTextureAniStep2]->iHeight)
							fCursorPos[Y] = (float) pSurfaceT->pTexture[iCurrentTextureAniStep2]->iHeight-1;
					}
				else
					if(iMouseButton & MK_RBUTTON)
					{
						(*pFloat)[X] -= (float) (OldMousePos.x-MousePos.x);
						(*pFloat)[Y] -= (float) (MousePos.y-OldMousePos.y);
					}
			}
			GetWindowRect(hWndBitmap5, &Rect);
			pFloat = &fTextureViewPos2;
			if(MousePos.x > Rect.left && MousePos.x < Rect.right &&
			   MousePos.y > Rect.top && MousePos.y < Rect.bottom)
			{ // The mouse is over the window enable view control:
				if(iMouseButton & MK_LBUTTON && iMouseButton & MK_RBUTTON)
					(*pFloat)[Z] -= (float) (MousePos.x-OldMousePos.x+MousePos.y-OldMousePos.y)/20.0f;
				else
					if(iMouseButton & MK_RBUTTON)
					{
						(*pFloat)[X] -= (float) (OldMousePos.x-MousePos.x)/100.0f;
						(*pFloat)[Y] -= (float) (MousePos.y-OldMousePos.y)/100.0f;
					}
			}
        break;

		case WM_TIMER:
			if(iCurrentTextureAniStep2 >= pSurfaceT->Header.iAniSteps)
			{
				iCurrentTextureAniStep2 = 0;
				goto Init;
			}
			// Show the whole texture:
			if(!wglMakeCurrent(hDCBitmap, hRCEditorShow))
				break;
			glDisable(GL_LIGHTING);
			glDisable(GL_FOG);
			glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
			pTexturePosT = &pSurfaceT->pTexturePos[iCurrentTextureAniStep2];
			if(!bTexturePosAdvanced && !SendDlgItemMessage(hWnd, IDC_SURFACE_MOVE, BM_GETCHECK, 0, 0L))
			{
				switch(iCurrentTexturePos)
				{
					case 0:
						pTexturePosT->iPos[0][X] = (int) fCursorPos[X];
						pTexturePosT->iPos[0][Y] = (int) fCursorPos[Y];
						// Calculate middle points:
						pTexturePosT->iPos[1][X] = (pTexturePosT->iPos[0][X]+pTexturePosT->iPos[2][X])/2;
						pTexturePosT->iPos[1][Y] = (pTexturePosT->iPos[0][Y]+pTexturePosT->iPos[2][Y])/2;
						pTexturePosT->iPos[7][X] = (pTexturePosT->iPos[0][X]+pTexturePosT->iPos[6][X])/2;
						pTexturePosT->iPos[7][Y] = (pTexturePosT->iPos[0][Y]+pTexturePosT->iPos[6][Y])/2;
					break;

					case 1:
						pTexturePosT->iPos[2][X] = (int) fCursorPos[X];
						pTexturePosT->iPos[2][Y] = (int) fCursorPos[Y];
						// Calculate middle points:
						pTexturePosT->iPos[1][X] = (pTexturePosT->iPos[0][X]+pTexturePosT->iPos[2][X])/2;
						pTexturePosT->iPos[1][Y] = (pTexturePosT->iPos[0][Y]+pTexturePosT->iPos[2][Y])/2;
						pTexturePosT->iPos[3][X] = (pTexturePosT->iPos[2][X]+pTexturePosT->iPos[4][X])/2;
						pTexturePosT->iPos[3][Y] = (pTexturePosT->iPos[2][Y]+pTexturePosT->iPos[4][Y])/2;
					break;

					case 2:
						pTexturePosT->iPos[4][X] = (int) fCursorPos[X];
						pTexturePosT->iPos[4][Y] = (int) fCursorPos[Y];
						// Calculate middle points:
						pTexturePosT->iPos[3][X] = (pTexturePosT->iPos[2][X]+pTexturePosT->iPos[4][X])/2;
						pTexturePosT->iPos[3][Y] = (pTexturePosT->iPos[2][Y]+pTexturePosT->iPos[4][Y])/2;
						pTexturePosT->iPos[5][X] = (pTexturePosT->iPos[4][X]+pTexturePosT->iPos[6][X])/2;
						pTexturePosT->iPos[5][Y] = (pTexturePosT->iPos[4][Y]+pTexturePosT->iPos[6][Y])/2;
					break;

					case 3:
						pTexturePosT->iPos[6][X] = (int) fCursorPos[X];
						pTexturePosT->iPos[6][Y] = (int) fCursorPos[Y];
						// Calculate middle points:
						pTexturePosT->iPos[5][X] = (pTexturePosT->iPos[4][X]+pTexturePosT->iPos[6][X])/2;
						pTexturePosT->iPos[5][Y] = (pTexturePosT->iPos[4][Y]+pTexturePosT->iPos[6][Y])/2;
						pTexturePosT->iPos[7][X] = (pTexturePosT->iPos[0][X]+pTexturePosT->iPos[6][X])/2;
						pTexturePosT->iPos[7][Y] = (pTexturePosT->iPos[0][Y]+pTexturePosT->iPos[6][Y])/2;
					break;
				}
				// Calculate middle point:
				pTexturePosT->iPos[8][X] = (pTexturePosT->iPos[0][X]+pTexturePosT->iPos[2][X]+
											pTexturePosT->iPos[4][X]+pTexturePosT->iPos[6][X])/4;
				pTexturePosT->iPos[8][Y] = (pTexturePosT->iPos[0][Y]+pTexturePosT->iPos[2][Y]+
											pTexturePosT->iPos[4][Y]+pTexturePosT->iPos[6][Y])/4;
				pSurfaceT->CalculateFloatTexturePos();
			}
			if(iMouseButton & MK_LBUTTON)
			{
				// Check if the mouse in in the texture view:
				GetWindowRect(hWndBitmap, &Rect);
				if(MousePos.x > Rect.left &&
				   MousePos.x < Rect.right &&
				   MousePos.y > Rect.top &&
				   MousePos.y < Rect.bottom)
				{ // Yea, we are inside:
					// Set this texture coordinate:
					if(SendDlgItemMessage(hWnd, IDC_SURFACE_MOVE, BM_GETCHECK, 0, 0L))
					{ // We move the whole current animation step:
						iCurrentTexturePos = 0;
						iX = pTexturePosT->iPos[0][X];
						iY = pTexturePosT->iPos[0][Y];
						pTexturePosT->iPos[0][X] = (int) fCursorPos[X];
						pTexturePosT->iPos[0][Y] = (int) fCursorPos[Y];
						iDeltaX = iX-(int) fCursorPos[X];
						iDeltaY = iY-(int) fCursorPos[Y];
						for(i = 1; i < 9; i++)
						{
							pTexturePosT->iPos[i][X] -= iDeltaX;
							pTexturePosT->iPos[i][Y] -= iDeltaY;
						}
						pSurfaceT->CalculateFloatTexturePos();
						sprintf(byTemp, "%d", pTexturePosT->iPos[iCurrentTexturePos][X]);
						SetDlgItemText(hWnd, ID_SURFACE_TEXTURE_POS_X, byTemp);
						sprintf(byTemp, "%d", pTexturePosT->iPos[iCurrentTexturePos][Y]);
						SetDlgItemText(hWnd, ID_SURFACE_TEXTURE_POS_Y, byTemp);
					}
					else
					{ // Move only one point:
						if(bTexturePosAdvanced)
						{
							pTexturePosT->iPos[iCurrentTexturePos][X] = (int) fCursorPos[X];
							pTexturePosT->iPos[iCurrentTexturePos][Y] = (int) fCursorPos[Y];
							pSurfaceT->CalculateFloatTexturePos();
							sprintf(byTemp, "%d", pTexturePosT->iPos[iCurrentTexturePos][X]);
							SetDlgItemText(hWnd, ID_SURFACE_TEXTURE_POS_X, byTemp);
							sprintf(byTemp, "%d", pTexturePosT->iPos[iCurrentTexturePos][Y]);
							SetDlgItemText(hWnd, ID_SURFACE_TEXTURE_POS_Y, byTemp);
						}
						else
						{
							sprintf(byTemp, "%d", pTexturePosT->iPos[iCurrentTexturePos*2][X]);
							SetDlgItemText(hWnd, ID_SURFACE_TEXTURE_POS_X, byTemp);
							sprintf(byTemp, "%d", pTexturePosT->iPos[iCurrentTexturePos*2][Y]);
							SetDlgItemText(hWnd, ID_SURFACE_TEXTURE_POS_Y, byTemp);
						}
					}										
				}
			}
			//
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
			glLoadIdentity();
			glTranslatef(fTextureViewPos3[X], fTextureViewPos3[Y], fTextureViewPos3[Z]);
			glEnable(GL_TEXTURE_2D);
			if(pSurfaceT && pSurfaceT->pTexture)
			{
				glBindTexture(GL_TEXTURE_2D, pSurfaceT->pTexture[iCurrentTextureAniStep2]->iOpenGLID);
				glBegin(GL_TRIANGLE_FAN);
					glTexCoord2f(0.0f, 1.0f);
					glVertex3f(0.0f, 0.0f, -1000.0f);
					glTexCoord2f(1.0f, 1.0f);
					glVertex3f((float) pSurfaceT->pTexture[iCurrentTextureAniStep2]->iWidth, 0.0f, -1000.0f);
					glTexCoord2f(1.0f, 0.0f);
					glVertex3f((float) pSurfaceT->pTexture[iCurrentTextureAniStep2]->iWidth, (float) pSurfaceT->pTexture[iCurrentTextureAniStep2]->iHeight, -1000.0f);
					glTexCoord2f(0.0f, 0.0f);
					glVertex3f(0.0f, (float) pSurfaceT->pTexture[iCurrentTextureAniStep2]->iHeight, -1000.0f);
				glEnd();
			}
			// Draw the cursor:
			glLineWidth(3.0f);
			glColor3f((rand() % 100)/100.0f, 1.0f, 0.5f);
			glDisable(GL_TEXTURE_2D);
			glDisable(GL_BLEND);
			glDisable(GL_DEPTH_TEST);
			glBegin(GL_LINES);
				glVertex3f(fCursorPos[X]-10.0f, pSurfaceT->pTexture[iCurrentTextureAniStep2]->iHeight-fCursorPos[Y], -1000.0f);
				glVertex3f(fCursorPos[X]+10.0f, pSurfaceT->pTexture[iCurrentTextureAniStep2]->iHeight-fCursorPos[Y], -1000.0f);
				glVertex3f(fCursorPos[X], pSurfaceT->pTexture[iCurrentTextureAniStep2]->iHeight-fCursorPos[Y]-10.0f, -1000.0f);
				glVertex3f(fCursorPos[X], pSurfaceT->pTexture[iCurrentTextureAniStep2]->iHeight-fCursorPos[Y]+10.0f, -1000.0f);
			glEnd();
			// Draw a frame around the selected area:
			glLineWidth(1.0f);
			iHeight = pSurfaceT->pTexture[iCurrentTextureAniStep2]->iHeight;
			// Quad 0:
			glBegin(GL_LINE_STRIP);
				glVertex3f((float) pTexturePosT->iPos[0][X], (float) iHeight-pTexturePosT->iPos[0][Y], -1000.0f);
				glVertex3f((float) pTexturePosT->iPos[7][X], (float) iHeight-pTexturePosT->iPos[7][Y], -1000.0f);
				glVertex3f((float) pTexturePosT->iPos[8][X], (float) iHeight-pTexturePosT->iPos[8][Y], -1000.0f);
				glVertex3f((float) pTexturePosT->iPos[1][X], (float) iHeight-pTexturePosT->iPos[1][Y], -1000.0f);
				glVertex3f((float) pTexturePosT->iPos[0][X], (float) iHeight-pTexturePosT->iPos[0][Y], -1000.0f);
			glEnd();
			// Quad 1:
			glBegin(GL_LINE_STRIP);
				glVertex3f((float) pTexturePosT->iPos[1][X], (float) iHeight-pTexturePosT->iPos[1][Y], -1000.0f);
				glVertex3f((float) pTexturePosT->iPos[2][X], (float) iHeight-pTexturePosT->iPos[2][Y], -1000.0f);
				glVertex3f((float) pTexturePosT->iPos[3][X], (float) iHeight-pTexturePosT->iPos[3][Y], -1000.0f);
				glVertex3f((float) pTexturePosT->iPos[8][X], (float) iHeight-pTexturePosT->iPos[8][Y], -1000.0f);
			glEnd();
			// Quad 2:
			glBegin(GL_LINE_STRIP);
				glVertex3f((float) pTexturePosT->iPos[3][X], (float) iHeight-pTexturePosT->iPos[3][Y], -1000.0f);
				glVertex3f((float) pTexturePosT->iPos[4][X], (float) iHeight-pTexturePosT->iPos[4][Y], -1000.0f);
				glVertex3f((float) pTexturePosT->iPos[5][X], (float) iHeight-pTexturePosT->iPos[5][Y], -1000.0f);
				glVertex3f((float) pTexturePosT->iPos[8][X], (float) iHeight-pTexturePosT->iPos[8][Y], -1000.0f);
			glEnd();
			// Quad 3:
			glBegin(GL_LINE_STRIP);
				glVertex3f((float) pTexturePosT->iPos[5][X], (float) iHeight-pTexturePosT->iPos[5][Y], -1000.0f);
				glVertex3f((float) pTexturePosT->iPos[6][X], (float) iHeight-pTexturePosT->iPos[6][Y], -1000.0f);
				glVertex3f((float) pTexturePosT->iPos[7][X], (float) iHeight-pTexturePosT->iPos[7][Y], -1000.0f);
			glEnd();
			glEnable(GL_DEPTH_TEST);
			ASSwapBuffers(hDCBitmap, NULL, FALSE);
			
			// Show the texture:
			if(!wglMakeCurrent(hDCBitmap5, hRCEditorShow))
				break;
			glDisable(GL_LIGHTING);
			glDisable(GL_FOG);
			glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
			glLoadIdentity();
			glTranslatef(fTextureViewPos2[X], fTextureViewPos2[Y], fTextureViewPos2[Z]);
			glEnable(GL_TEXTURE_2D);
			if(pSurfaceT && pSurfaceT->pTexture)
			{
				if(pSurfaceT->Header.bEnvironmentMappingS)
					glEnable(GL_TEXTURE_GEN_S);
				if(pSurfaceT->Header.bEnvironmentMappingT)
					glEnable(GL_TEXTURE_GEN_T);
				pTexturePos = &pSurfaceT->pTexturePos[iCurrentTextureAniStep2];
				glBindTexture(GL_TEXTURE_2D, pSurfaceT->pTexture[iCurrentTextureAniStep2]->iOpenGLID);
				glBegin(GL_QUADS);
					// Quad 3:
					glTexCoord2fv(pTexturePos->fPos[6]);
					glVertex3f(-1.0f, -1.0f, 1.0f);
					glTexCoord2fv(pTexturePos->fPos[5]);
					glVertex3f(0.0f, -1.0f, 1.0f);
					glTexCoord2fv(pTexturePos->fPos[8]);
					glVertex3f(0.0f, 0.0f, 1.0f);
					glTexCoord2fv(pTexturePos->fPos[7]);
					glVertex3f(-1.0f, 0.0f, 1.0f);
					// Quad 2:
					glTexCoord2fv(pTexturePos->fPos[5]);
					glVertex3f(0.0f, -1.0f, 1.0f);
					glTexCoord2fv(pTexturePos->fPos[4]);
					glVertex3f(1.0f, -1.0f, 1.0f);
					glTexCoord2fv(pTexturePos->fPos[3]);
					glVertex3f(1.0f, 0.0f, 1.0f);
					glTexCoord2fv(pTexturePos->fPos[8]);
					glVertex3f(0.0f, 0.0f, 1.0f);
					// Quad 1:
					glTexCoord2fv(pTexturePos->fPos[8]);
					glVertex3f(0.0f, 0.0f, 1.0f);
					glTexCoord2fv(pTexturePos->fPos[3]);
					glVertex3f(1.0f, 0.0f, 1.0f);
					glTexCoord2fv(pTexturePos->fPos[2]);
					glVertex3f(1.0f, 1.0f, 1.0f);
					glTexCoord2fv(pTexturePos->fPos[1]);
					glVertex3f(0.0f, 1.0f, 1.0f);
					// Quad 0:
					glTexCoord2fv(pTexturePos->fPos[7]);
					glVertex3f(-1.0f, 0.0f, 1.0f);
					glTexCoord2fv(pTexturePos->fPos[8]);
					glVertex3f(0.0f, 0.0f, 1.0f);
					glTexCoord2fv(pTexturePos->fPos[1]);
					glVertex3f(0.0f, 1.0f, 1.0f);
					glTexCoord2fv(pTexturePos->fPos[0]);
					glVertex3f(-1.0f, 1.0f, 1.0f);
				glEnd();
				glDisable(GL_TEXTURE_GEN_S);
				glDisable(GL_TEXTURE_GEN_T);
			}
			ASSwapBuffers(hDCBitmap5, NULL, FALSE);
			if(!bAnimation)
				break;
			// Animate the preview:
			if(ASCheckTimeUpdate(&lTimer2, pSurfaceT->pTexturePos[iCurrentTextureAniStep2].iTimeToNext))
				break;
			iCurrentTextureAniStep2++;
			if(iCurrentTextureAniStep2 >= pSurfaceT->Header.iAniSteps)
				iCurrentTextureAniStep2 = 0;
			goto Init;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_SURFACE_OK:
					// Save the surface:
					if(pSurfaceT->Header.byFilename[0] == '\0')
					{ // Get an filename:
						bSurfaceSave = TRUE;
						sprintf(byTemp, "%s%s", _AS->byProgramPath, _AS->bySurfacesDirectory);
						KillTimer(hWndSurface, 1);
						pbyTemp = ASGetFileName(hWnd, AS_T(T_SaveSurface), ASS_FILE, 1, FALSE, byTemp, pSurfaceT->Header.byName);
						SetTimer(hWndSurface, 1, 1, NULL);
						bSurfaceSave = FALSE;
						if(!pbyTemp)
							break;
						if(strlen(pbyTemp) > strlen(_AS->byProgramPath))
							strcpy(pSurfaceT->Header.byFilename, &pbyTemp[strlen(_AS->byProgramPath)]);
					}
					else
						if(strlen(pSurfaceT->Header.byFilename) > strlen(_AS->byProgramPath))
							strcpy(pSurfaceT->Header.byFilename, &pSurfaceT->Header.byFilename[strlen(_AS->byProgramPath)]);
					sprintf(byTemp, "%s%s", _AS->byProgramPath, pSurfaceT->Header.byFilename);
					if(pSurfaceT->Save(byTemp))
					{
						sprintf(byTemp, "%s: %s", pSurfaceT->Header.byFilename, AS_M(M_SaveSurfaceFailed));
						KillTimer(hWndSurface, 1);
						if(MessageBox(hWndSurface, byTemp, AS_T(T_Error), MB_YESNO | MB_ICONINFORMATION) == IDNO)
						{
							SetTimer(hWndSurface, 1, 1, NULL);
							_AS->WriteLogMessage("Save  %s  failed! User didn't left the surface dialog.", pSurfaceT->Header.byFilename);
							break;
						}
						SetTimer(hWndSurface, 1, 1, NULL);
						_AS->WriteLogMessage("Save  %s  failed! User left surface dialog without saving.", pSurfaceT->Header.byFilename);
						goto LeftWithoutSave;
					}
					// Close dialog:
	 				KillTimer(hWnd, 1);
					if(hDCBitmap && !ReleaseDC(hWnd, hDCBitmap))
						hDCBitmap = NULL;
					if(hDCBitmap5 && !ReleaseDC(hWnd, hDCBitmap5))
						hDCBitmap5 = NULL;
					EndDialog(hWnd, TRUE);
					hWndSurface = NULL;
					//				
					_AS->WriteLogMessage("Close surface dialog(OK)");
                return TRUE;

                case ID_SURFACE_CANCEL:
				LeftWithoutSave:
					// Close dialog:
	 				KillTimer(hWnd, 1);
					if(hDCBitmap && !ReleaseDC(hWnd, hDCBitmap))
						hDCBitmap = NULL;
					if(hDCBitmap5 && !ReleaseDC(hWnd, hDCBitmap5))
						hDCBitmap5 = NULL;
					hWndSurface = NULL;
					EndDialog(hWnd, FALSE);
					if(!bNewSurface)
					{
						pSurfaceT->Destroy();
						pSurfaceT->Load(byFilenameTemp);
					}
					else
					{
						pLevel->DestroySurface(pLevel->iCurrentSurface);
						pSurfaceT = NULL;
					}
					//
					_AS->WriteLogMessage("Close surface dialog(CANCEL)");
                return TRUE;

				case ID_SURFACE_NAME:
					GetDlgItemText(hWnd, ID_SURFACE_NAME, pSurfaceT->Header.byName, 256);
					SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_ENTER_SURFACE, CB_RESETCONTENT , 0, 0L);
					SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_LEAVE_SURFACE, CB_RESETCONTENT , 0, 0L);
					SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_ANIMATION_END_SURFACE, CB_RESETCONTENT , 0, 0L);
					SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_TIME_SURFACE, CB_RESETCONTENT , 0, 0L);
					for(i = 0; i < pLevel->Header.iSurfaces; i++)
					{
						sprintf(byTemp, "%s", pLevel->pSurface[i].Header.byName, pLevel->pSurface[i].iUsed);
						SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_ENTER_SURFACE, CB_ADDSTRING, 0, (LPARAM) byTemp);
						SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_LEAVE_SURFACE, CB_ADDSTRING, 0, (LPARAM) byTemp);
						SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_ANIMATION_END_SURFACE, CB_ADDSTRING, 0, (LPARAM) byTemp);
						SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_TIME_SURFACE, CB_ADDSTRING, 0, (LPARAM) byTemp);
					}
					SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_ENTER_SURFACE, CB_SETCURSEL, pSurfaceT->Header.iChangeOnEnterSurface, 0L);
					SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_LEAVE_SURFACE, CB_SETCURSEL, pSurfaceT->Header.iChangeOnLeaveSurface, 0L);
					SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_ANIMATION_END_SURFACE, CB_SETCURSEL, pSurfaceT->Header.iChangeOnAnimationEndSurface, 0L);
					SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_TIME_SURFACE, CB_SETCURSEL, pSurfaceT->Header.iChangeOnTimeSurface, 0L);
				break;

				case ID_SURFACE_FILENAME:
					GetDlgItemText(hWnd, ID_SURFACE_FILENAME, pSurfaceT->Header.byFilename, 256);
				break;

				case ID_SURFACE_TEXTURE:
					if(!pLevel->Header.iTextures)
						break;
					if(pSurfaceT->iTextureID[iCurrentTextureAniStep2] != -1 && pLevel->pCurrentTexture)
						pLevel->pCurrentTexture->iUsed--;
					i = (int) SendDlgItemMessage(hWnd, ID_SURFACE_TEXTURE, CB_GETCURSEL, 0, 0L);
					if(i < 0 || i > pLevel->Header.iTextures-1 || pLevel->iCurrentTexture == i)
						break;
					pLevel->iCurrentTexture = i;
					pLevel->pCurrentTexture = &pLevel->pTexture[pLevel->iCurrentTexture];
					pSurfaceT->iTextureID[iCurrentTextureAniStep2] = pLevel->iCurrentTexture;
					pSurfaceT->pTexture[iCurrentTextureAniStep2] = pLevel->pCurrentTexture;
					pLevel->pCurrentTexture->iUsed++;
					strcpy(pSurfaceT->byTextureFilename[iCurrentTextureAniStep2], pLevel->pCurrentTexture->byFilename);
					iCurrentTexturePos = 0;
					fTextureViewPos3[X] = 0.0f;
					fTextureViewPos3[Y] = (float) -pSurfaceT->pTexture[iCurrentTextureAniStep2]->iHeight;
					fTextureViewPos3[Z] = 500.0f;
					goto Init;
			
				case ID_SURFACE_TEXTURE_ANI_STEPS:
					KillTimer(hWnd, 1);
					if((i = DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_SET_ANIMATION_STEPS), hWnd, (DLGPROC) SetAnimationStepsProc)) == -1)
					{
						SetTimer(hWnd, 1, 1, NULL);
						break;
					}
					SetTimer(hWnd, 1, 1, NULL);
					pSurfaceT->ChangeAnimationSteps(i);
					goto Init;

				case ID_SURFACE_TEXTURE_ANIS:
					i = (int) SendDlgItemMessage(hWnd, ID_SURFACE_TEXTURE_ANIS, CB_GETCURSEL, 0, 0L);
					if(i < 0 || i >= pSurfaceT->Header.iAniSteps)
						break;
					iCurrentTextureAniStep2 = i;
					goto Init;

				case ID_SURFACE_TEXTURE_POS_ADVANCED: SurfaceUpdate(); goto Init;

				case ID_SURFACE_TEXTURE_POS_1: case IDC_SURFACE_MOVE:
					iCurrentTexturePos = 0;
					goto Init;

				case ID_SURFACE_TEXTURE_POS_2:
					if(SendDlgItemMessage(hWnd, IDC_SURFACE_MOVE, BM_GETCHECK, 0, 0L))
						break;
					iCurrentTexturePos = 1;
					goto Init;

				case ID_SURFACE_TEXTURE_POS_3:
					if(SendDlgItemMessage(hWnd, IDC_SURFACE_MOVE, BM_GETCHECK, 0, 0L))
						break;
					iCurrentTexturePos = 2;
					goto Init;

				case ID_SURFACE_TEXTURE_POS_4:
					if(SendDlgItemMessage(hWnd, IDC_SURFACE_MOVE, BM_GETCHECK, 0, 0L))
						break;
					iCurrentTexturePos = 3;
					goto Init;

				case ID_SURFACE_TEXTURE_POS_5:
					if(SendDlgItemMessage(hWnd, IDC_SURFACE_MOVE, BM_GETCHECK, 0, 0L))
						break;
					iCurrentTexturePos = 4;
					goto Init;

				case ID_SURFACE_TEXTURE_POS_6:
					if(SendDlgItemMessage(hWnd, IDC_SURFACE_MOVE, BM_GETCHECK, 0, 0L))
						break;
					iCurrentTexturePos = 5;
					goto Init;

				case ID_SURFACE_TEXTURE_POS_7:
					if(SendDlgItemMessage(hWnd, IDC_SURFACE_MOVE, BM_GETCHECK, 0, 0L))
						break;
					iCurrentTexturePos = 6;
					goto Init;

				case ID_SURFACE_TEXTURE_POS_8:
					if(SendDlgItemMessage(hWnd, IDC_SURFACE_MOVE, BM_GETCHECK, 0, 0L))
						break;
					iCurrentTexturePos = 7;
					goto Init;

				case ID_SURFACE_TEXTURE_POS_9:
					if(SendDlgItemMessage(hWnd, IDC_SURFACE_MOVE, BM_GETCHECK, 0, 0L))
						break;
					iCurrentTexturePos = 8;
					goto Init;

				case ID_SURFACE_TEXTURE_POS_X:
					GetDlgItemText(hWnd, ID_SURFACE_TEXTURE_POS_X, byTemp, 256);
					if(bTexturePosAdvanced)
						i = iCurrentTexturePos;
					else
						i = iCurrentTexturePos*2;
					pSurfaceT->pTexturePos[iCurrentTextureAniStep2].iPos[i][X] = atoi(byTemp);
					if(!pSurfaceT->pTexture)
						break;
					pSurfaceT->CalculateFloatTexturePos();
					fCursorPos[X] = (float) pSurfaceT->pTexturePos[iCurrentTextureAniStep2].iPos[i][X];


				break;

				case ID_SURFACE_TEXTURE_POS_Y:
					GetDlgItemText(hWnd, ID_SURFACE_TEXTURE_POS_Y, byTemp, 256);
					if(bTexturePosAdvanced)
						i = iCurrentTexturePos;
					else
						i = iCurrentTexturePos*2;
					pSurfaceT->pTexturePos[iCurrentTextureAniStep2].iPos[i][Y] = atoi(byTemp);
					if(!pSurfaceT->pTexture)
						break;
					pSurfaceT->CalculateFloatTexturePos();
					fCursorPos[Y] = (float) pSurfaceT->pTexturePos[iCurrentTextureAniStep2].iPos[i][Y];
				break;

				case ID_SURFACE_RESET_TEXTURE_VIEW:
					fTextureViewPos3[X] = fTextureViewPos3[Y] = 0.0f;
					fTextureViewPos3[Z] = 500.0f;
					fCursorPos[X] = 0.0f;
					fCursorPos[Y] = 0.0f;
				break;

				case ID_SURFACE_RESET_TEXTURE_VIEW2:
					fTextureViewPos2[X] = fTextureViewPos2[Y] = 0.0f;
					fTextureViewPos2[Z] = -5.0f;
				break;

				case IDC_SURFACE_NEXT_TIME:
					GetDlgItemText(hWnd, IDC_SURFACE_NEXT_TIME, byTemp, 256);
					pSurfaceT->pTexturePos[iCurrentTextureAniStep2].iTimeToNext = atoi(byTemp);
				break;

				case IDC_SURFACE_NEXT_TIME_ALL:
					for(i = 0; i < pSurfaceT->Header.iAniSteps; i++)
						pSurfaceT->pTexturePos[i].iTimeToNext = pSurfaceT->pTexturePos[iCurrentTextureAniStep2].iTimeToNext;
				break;

				case IDC_SURFACE_ANIMATE:
					lTimer2 = g_lGameTimer;
					bAnimation = !bAnimation;
					SurfaceUpdate();
				break;

				case IDC_SURFACE_COPY:
					KillTimer(hWnd, 1);
					if((i = DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_COPY_TEXTURE_POS), hWnd, (DLGPROC) CopyTexturePosProc)) == -1)
					{
						SetTimer(hWnd, 1, 1, NULL);
						break;
					}
					SetTimer(hWnd, 1, 1, NULL);
					memcpy(pSurfaceT->byTextureFilename[i], pSurfaceT->byTextureFilename[iCurrentTextureAniStep2], strlen(pSurfaceT->byTextureFilename[iCurrentTextureAniStep2]));
					memcpy(&pSurfaceT->pTexturePos[i], &pSurfaceT->pTexturePos[iCurrentTextureAniStep2], sizeof(TEXTURE_POS));
					pSurfaceT->iTextureID[iCurrentTextureAniStep2] = pSurfaceT->iTextureID[i];
					pSurfaceT->pTexture[i] = pSurfaceT->pTexture[iCurrentTextureAniStep2];
					iCurrentTextureAniStep2 = i;
					goto Init;

				case IDC_SURFACE_COPY_LEFT:
					i = iCurrentTextureAniStep2;
					iCurrentTextureAniStep2--;
					if(iCurrentTextureAniStep2 < 0)
						iCurrentTextureAniStep2 = pSurfaceT->Header.iAniSteps-1;
					memset(pSurfaceT->byTextureFilename[iCurrentTextureAniStep2], 0, 256);
					memcpy(pSurfaceT->byTextureFilename[iCurrentTextureAniStep2], pSurfaceT->byTextureFilename[i], strlen(pSurfaceT->byTextureFilename[i]));
					memcpy(&pSurfaceT->pTexturePos[iCurrentTextureAniStep2], &pSurfaceT->pTexturePos[i], sizeof(TEXTURE_POS));
					pSurfaceT->iTextureID[iCurrentTextureAniStep2] = pSurfaceT->iTextureID[i];
					pSurfaceT->pTexture[iCurrentTextureAniStep2] = pSurfaceT->pTexture[i];
					goto Init;

				case IDC_SURFACE_COPY_RIGHT:
					i = iCurrentTextureAniStep2;
					iCurrentTextureAniStep2++;
					if(iCurrentTextureAniStep2 >= pSurfaceT->Header.iAniSteps)
						iCurrentTextureAniStep2 = 0;
					memset(pSurfaceT->byTextureFilename[iCurrentTextureAniStep2], 0, 256);
					memcpy(pSurfaceT->byTextureFilename[iCurrentTextureAniStep2], pSurfaceT->byTextureFilename[i], strlen(pSurfaceT->byTextureFilename[i]));
					memcpy(&pSurfaceT->pTexturePos[iCurrentTextureAniStep2], &pSurfaceT->pTexturePos[i], sizeof(TEXTURE_POS));
					pSurfaceT->iTextureID[iCurrentTextureAniStep2] = pSurfaceT->iTextureID[i];
					pSurfaceT->pTexture[iCurrentTextureAniStep2] = pSurfaceT->pTexture[i];
					goto Init;

					// Attributes:
					case IDC_SURFACE_AT_ALCOVE:
						pSurfaceT->Header.bAlcove = SendDlgItemMessage(hWnd, IDC_SURFACE_AT_ALCOVE, BM_GETCHECK, 0, 0L);
					break;

					case IDC_SURFACE_AT_RADIOACTIVE:
						pSurfaceT->Header.bRadioactive = SendDlgItemMessage(hWnd, IDC_SURFACE_AT_RADIOACTIVE, BM_GETCHECK, 0, 0L);
					break;

					case IDC_SURFACE_AT_HEALTH:
						pSurfaceT->Header.bHealth = SendDlgItemMessage(hWnd, IDC_SURFACE_AT_HEALTH, BM_GETCHECK, 0, 0L);
					break;

					case IDC_SURFACE_AT_EXIT:
						pSurfaceT->Header.bExit = SendDlgItemMessage(hWnd, IDC_SURFACE_AT_EXIT, BM_GETCHECK, 0, 0L);
					break;

					case IDC_SURFACE_AT_HOLE:
						pSurfaceT->Header.bHole = SendDlgItemMessage(hWnd, IDC_SURFACE_AT_HOLE, BM_GETCHECK, 0, 0L);
					break;

					case IDC_SURFACE_AT_ANCHOR:
						pSurfaceT->Header.bAnchor = SendDlgItemMessage(hWnd, IDC_SURFACE_AT_ANCHOR, BM_GETCHECK, 0, 0L);
						SurfaceUpdate();
					break;

					case IDC_SURFACE_AT_COLOR_PAINTER:
						pSurfaceT->Header.bColorPainter = SendDlgItemMessage(hWnd, IDC_SURFACE_AT_COLOR_PAINTER, BM_GETCHECK, 0, 0L);
						SurfaceUpdate();
					break;

					case IDC_SURFACE_AT_COLOR_SCANNER:
						pSurfaceT->Header.bColorScanner = SendDlgItemMessage(hWnd, IDC_SURFACE_AT_COLOR_SCANNER, BM_GETCHECK, 0, 0L);
						SurfaceUpdate();
					break;

					case IDC_SURFACE_AT_BEAMER:
						pSurfaceT->Header.bBeamer = SendDlgItemMessage(hWnd, IDC_SURFACE_AT_BEAMER, BM_GETCHECK, 0, 0L);
						SurfaceUpdate();
					break;

					case IDC_SURFACE_AT_ANCHOR_TYPE:
						i = (int) SendDlgItemMessage(hWnd, IDC_SURFACE_AT_ANCHOR_TYPE, CB_GETCURSEL, 0, 0L);
						if(i < 0)
							i = 0;
						if(i > 4)
							i = 4;
						pSurfaceT->Header.byAnchorType = (char) i;
					break;

					case IDC_SURFACE_AT_COLOR_PAINTER_TYPE:
						i = (int) SendDlgItemMessage(hWnd, IDC_SURFACE_AT_COLOR_PAINTER_TYPE, CB_GETCURSEL, 0, 0L);
						if(i < 0)
							i = 0;
						if(i > 4)
							i = 4;
						pSurfaceT->Header.byColorPainterType = (char) i;
					break;

					case IDC_SURFACE_AT_COLOR_SCANNER_TYPE:
						i = (int) SendDlgItemMessage(hWnd, IDC_SURFACE_AT_COLOR_SCANNER_TYPE, CB_GETCURSEL, 0, 0L);
						if(i < 0)
							i = 0;
						if(i > 4)
							i = 4;
						pSurfaceT->Header.byColorScannerType = (char) i;
					break;

					case IDC_SURFACE_AT_CHANGE_ON_ENTER:
						pSurfaceT->Header.bChangeOnEnter = SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_ENTER, BM_GETCHECK, 0, 0L);
						SurfaceUpdate();
					break;

					case IDC_SURFACE_AT_CHANGE_ON_LEAVE:
						pSurfaceT->Header.bChangeOnLeave = SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_LEAVE, BM_GETCHECK, 0, 0L);
						SurfaceUpdate();
					break;

					case IDC_SURFACE_AT_CHANGE_ON_ANIMATION_END:
						pSurfaceT->Header.bChangeOnAnimationEnd = SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_ANIMATION_END, BM_GETCHECK, 0, 0L);
						SurfaceUpdate();
					break;

					case IDC_SURFACE_AT_CHANGE_ON_TIME:
						pSurfaceT->Header.bChangeOnTime = SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_TIME, BM_GETCHECK, 0, 0L);
						SurfaceUpdate();
					break;

					case IDC_SURFACE_AT_CHANGE_ON_TIME_TIME:
						GetDlgItemText(hWnd, IDC_SURFACE_AT_CHANGE_ON_TIME_TIME, byTemp, 256);
						pSurfaceT->Header.lChangeTime = atoi(byTemp);
					break;

					case IDC_SURFACE_AT_ALCOVE_SPEED:
						GetDlgItemText(hWnd, IDC_SURFACE_AT_ALCOVE_SPEED, byTemp, 256);
						pSurfaceT->Header.fAlcoveSpeed = (float) atof(byTemp);
					break;

					case IDC_SURFACE_AT_RADIOACTIVE_SPEED:
						GetDlgItemText(hWnd, IDC_SURFACE_AT_RADIOACTIVE_SPEED, byTemp, 256);
						pSurfaceT->Header.fRadioactiveSpeed = (float) atof(byTemp);
					break;

					case IDC_SURFACE_AT_HEALTH_SPEED:
						GetDlgItemText(hWnd, IDC_SURFACE_AT_HEALTH_SPEED, byTemp, 256);
						pSurfaceT->Header.fHealthSpeed = (float) atof(byTemp);
					break;

					case IDC_SURFACE_FRICTION:
						GetDlgItemText(hWnd, IDC_SURFACE_FRICTION, byTemp, 256);
						pSurfaceT->Header.fFriction = (float) atof(byTemp);
					break;

					case IDC_SURFACE_AT_CHANGE_ON_ENTER_SURFACE:
						i = (int) SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_ENTER_SURFACE, CB_GETCURSEL, 0, 0L);
						if(i == -1 || i >= pLevel->Header.iSurfaces)
							break;
						pSurfaceT->Header.iChangeOnEnterSurface = i;
					break;

					case IDC_SURFACE_AT_CHANGE_ON_LEAVE_SURFACE:
						i = (int) SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_LEAVE_SURFACE, CB_GETCURSEL, 0, 0L);
						if(i == -1 || i >= pLevel->Header.iSurfaces)
							break;
						pSurfaceT->Header.iChangeOnLeaveSurface = i;
					break;

					case IDC_SURFACE_AT_CHANGE_ON_ANIMATION_END_SURFACE:
						i = (int) SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_ANIMATION_END_SURFACE, CB_GETCURSEL, 0, 0L);
						if(i == -1 || i >= pLevel->Header.iSurfaces)
							break;
						pSurfaceT->Header.iChangeOnAnimationEndSurface = i;
					break;

					case IDC_SURFACE_AT_CHANGE_ON_TIME_SURFACE:
						i = (int) SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_ON_TIME_SURFACE, CB_GETCURSEL, 0, 0L);
						if(i == -1 || i >= pLevel->Header.iSurfaces)
							break;
						pSurfaceT->Header.iChangeOnTimeSurface = i;
					break;

					case IDC_SURFACE_ATTRIBUTES_ENVIRONMENT_MAPPING_S:
						pSurfaceT->Header.bEnvironmentMappingS = SendDlgItemMessage(hWnd, IDC_SURFACE_ATTRIBUTES_ENVIRONMENT_MAPPING_S, BM_GETCHECK, 0, 0L);
					break;

					case IDC_SURFACE_ATTRIBUTES_ENVIRONMENT_MAPPING_T:
						pSurfaceT->Header.bEnvironmentMappingT = SendDlgItemMessage(hWnd, IDC_SURFACE_ATTRIBUTES_ENVIRONMENT_MAPPING_T, BM_GETCHECK, 0, 0L);
					break;

					case IDC_SURFACE_ANIMATION_TOOL:
						if(iCurrentTextureAniStep2 < 0 || iCurrentTextureAniStep2 >= pSurfaceT->Header.iAniSteps)
							break;
						KillTimer(hWnd, 1);
						if(!DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_ANIMATION_TOOL), hWnd, (DLGPROC) AnimationToolProc))
						{
							SetTimer(hWnd, 1, 1, NULL);
							break;
						}
						SetTimer(hWnd, 1, 1, NULL);
						// Ok, we have the required information, now
						// create the animation:						
						iT = iCurrentTextureAniStep2;
						pTexturePosT = &pSurfaceT->pTexturePos[iCurrentTextureAniStep2];
						iY = 0;
						for(i2 = 0, y = 0; y < AnimationTool.iRows; y++, iY += AnimationTool.iMoveY)
						{
							iX = 0;
							for(x = 0; x < AnimationTool.iColumns; x++, iCurrentTextureAniStep2++, iX += AnimationTool.iMoveX, i2++)
							{
								
								if(iT == iCurrentTextureAniStep2)
									continue;
								if(iCurrentTextureAniStep2 >= pSurfaceT->Header.iAniSteps ||
								  i2 >= AnimationTool.iSteps)
								{
									iCurrentTextureAniStep2 = iT;
									return TRUE;
								}
								// Setup the animation step:
								pTexturePosT2 = &pSurfaceT->pTexturePos[iCurrentTextureAniStep2];
								for(i = 0; i < 9; i++)
								{
									pTexturePosT2->iPos[i][X] = pTexturePosT->iPos[i][X]+iX;
									pTexturePosT2->iPos[i][Y] = pTexturePosT->iPos[i][Y]+iY;
								}
								pTexturePosT2->iTimeToNext = pTexturePosT->iTimeToNext;
								pSurfaceT->iTextureID[iCurrentTextureAniStep2] =
								pSurfaceT->iTextureID[iT];
								pSurfaceT->pTexture[iCurrentTextureAniStep2] =
								pSurfaceT->pTexture[iT];
								memset(pSurfaceT->byTextureFilename[iCurrentTextureAniStep2], 0, 256);
								strcpy(pSurfaceT->byTextureFilename[iCurrentTextureAniStep2],
									   pSurfaceT->byTextureFilename[iT]);
							}
						}
						pSurfaceT->CalculateFloatTexturePos();
						iCurrentTextureAniStep2 = iT;
					break;
            }
        break;

		case WM_CLOSE: case WM_DESTROY:
			if(pSurfaceT)
				SendMessage(hWnd, WM_COMMAND, ID_SURFACE_OK, 0);
			else
			{
				pLevel->iCurrentSurface = 0;
				pSurfaceT = &pLevel->pSurface[0];
			}
		break;
    }
    return FALSE;
} // end SurfaceProc()

void SurfaceUpdate(void)
{ // begin SurfaceUpdate()
	SURFACE *pSurfaceT = pLevel->pCurrentSurface;

	EnableWindow(GetDlgItem(hWndSurface, IDC_SURFACE_AT_ANCHOR_TYPE), pSurfaceT->Header.bAnchor);
	EnableWindow(GetDlgItem(hWndSurface, IDC_SURFACE_AT_COLOR_PAINTER_TYPE), pSurfaceT->Header.bColorPainter);
	EnableWindow(GetDlgItem(hWndSurface, IDC_SURFACE_AT_COLOR_SCANNER_TYPE), pSurfaceT->Header.bColorScanner);
	if(!bAnimation)
		SetDlgItemText(hWndSurface, IDC_SURFACE_ANIMATE, AS_T(T_Play));
	else
		SetDlgItemText(hWndSurface, IDC_SURFACE_ANIMATE, AS_T(T_Stop));
	// Change:
	EnableWindow(GetDlgItem(hWndSurface, IDC_SURFACE_AT_CHANGE_ON_ENTER_SURFACE), pSurfaceT->Header.bChangeOnEnter);
	EnableWindow(GetDlgItem(hWndSurface, IDC_SURFACE_AT_CHANGE_ON_LEAVE_SURFACE), pSurfaceT->Header.bChangeOnLeave);
	EnableWindow(GetDlgItem(hWndSurface, IDC_SURFACE_AT_CHANGE_ON_ANIMATION_END_SURFACE), pSurfaceT->Header.bChangeOnAnimationEnd);
	EnableWindow(GetDlgItem(hWndSurface, IDC_SURFACE_AT_CHANGE_ON_TIME_SURFACE), pSurfaceT->Header.bChangeOnTime);
	EnableWindow(GetDlgItem(hWndSurface, IDC_SURFACE_AT_CHANGE_ON_TIME_TIME), pSurfaceT->Header.bChangeOnTime);
	if(SendDlgItemMessage(hWndSurface, ID_SURFACE_TEXTURE_POS_ADVANCED, BM_GETCHECK, 0, 0L))
		bTexturePosAdvanced = TRUE;
	else
		bTexturePosAdvanced = FALSE;
	ShowWindow(GetDlgItem(hWndSurface, ID_SURFACE_TEXTURE_POS_5), bTexturePosAdvanced);
	ShowWindow(GetDlgItem(hWndSurface, ID_SURFACE_TEXTURE_POS_6), bTexturePosAdvanced);
	ShowWindow(GetDlgItem(hWndSurface, ID_SURFACE_TEXTURE_POS_7), bTexturePosAdvanced);
	ShowWindow(GetDlgItem(hWndSurface, ID_SURFACE_TEXTURE_POS_8), bTexturePosAdvanced);
	ShowWindow(GetDlgItem(hWndSurface, ID_SURFACE_TEXTURE_POS_9), bTexturePosAdvanced);
} // end SurfaceUpdate()

LRESULT CALLBACK TexturesProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin TexturesProc()
    char *pbyTemp, byTemp[256], byTemp2[256], byTemp3[256];
	static POINT MousePos, OldMousePos;
	FLOAT3 *pFloat;
	RECT Rect;
	FILE *fp;
	int i;

	switch(iMessage)
    {
        case WM_INITDIALOG:
			if(hWndTextures)
			{
				EndDialog(hWnd, FALSE);
				break;
			}
		WholeInit:
			hWndTextures = hWnd;
			// Texts:
			SetWindowText(hWnd, AS_T(T_Textures));
			SetDlgItemText(hWnd, ID_TEXTURES_OK, AS_T(T_Ok));
			SetDlgItemText(hWnd, ID_TEXTURES_LOAD, AS_T(T_Load));
			SetDlgItemText(hWnd, ID_TEXTURES_UNLOAD, AS_T(T_Unload));
			SetDlgItemText(hWnd, ID_TEXTURES_UPDATE, AS_T(T_Update));
			SetDlgItemText(hWnd, ID_TEXTURES_RESET_VIEW, AS_T(T_Reset));
			//
			_AS->WriteLogMessage("Open textures dialog");
			hWndBitmap2 = GetDlgItem(hWnd, ID_TEXTURES_VIEW);
			ASInitOpenGL(NULL, hWndBitmap2, &hDCBitmap2, &hRCEditorShow, FALSE);
			SetTimer(hWnd, 1, 1, NULL);
			fTextureViewPos[X] = fTextureViewPos[Y] = 0.0f;
			fTextureViewPos[Z] = -3.0f;
		Init:
			if(!pLevel->Header.iTextures)
			{	
				EnableWindow(GetDlgItem(hWnd, ID_TEXTURES_UNLOAD), FALSE);
				pLevel->iCurrentTexture = 0;
				pLevel->pCurrentTexture = &pLevel->pTexture[pLevel->iCurrentTexture];
			}
			else
				if(pLevel->iCurrentTexture >= 0 || pLevel->iCurrentTexture <= pLevel->Header.iTextures)
					EnableWindow(GetDlgItem(hWnd, ID_TEXTURES_UNLOAD), TRUE);
			if(!pLevel->iCurrentTexture)
				EnableWindow(GetDlgItem(hWnd, ID_TEXTURES_UNLOAD), FALSE);
			SendDlgItemMessage(hWnd, ID_TEXTURE_LIST, LB_RESETCONTENT , 0, 0L);
			for(i = 0; i < pLevel->Header.iTextures; i++)
			{
				sprintf(byTemp, "%s (Used:%d)", pLevel->pTexture[i].byFilename, pLevel->pTexture[i].iUsed);
				SendDlgItemMessage(hWnd, ID_TEXTURE_LIST, LB_ADDSTRING, 0, (LPARAM) byTemp);
			}
			SendDlgItemMessage(hWnd, ID_TEXTURE_LIST, LB_SETCURSEL, pLevel->iCurrentTexture, 0L);
			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
			BringWindowToTop(hWnd);
		return TRUE;

		case WM_TIMER:
			if(!wglMakeCurrent(hDCBitmap2, hRCEditorShow))
				break;
			glDisable(GL_LIGHTING);
			glDisable(GL_FOG);
			glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
			glLoadIdentity();
			glTranslatef(fTextureViewPos[X], fTextureViewPos[Y], fTextureViewPos[Z]);
			glEnable(GL_TEXTURE_2D);
			if(pLevel->pCurrentTexture)
			{
				glBindTexture(GL_TEXTURE_2D, pLevel->pCurrentTexture->iOpenGLID);
				glBegin(GL_QUADS);
					glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f, -1.0f,  1.0f);
					glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f, -1.0f,  1.0f);
					glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f,  1.0f,  1.0f);
					glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f,  1.0f,  1.0f);
				glEnd();
			}
			ASSwapBuffers(hDCBitmap2, NULL, FALSE);
		break;

        case WM_LBUTTONDOWN: case WM_LBUTTONUP: case WM_RBUTTONDOWN:
        case WM_RBUTTONUP: case WM_MOUSEMOVE:
			i = wParam;
			memcpy(&OldMousePos, &MousePos, sizeof(POINT));
			GetCursorPos(&MousePos);
			GetWindowRect(hWnd, &Rect);
			GetWindowRect(hWndBitmap2, &Rect);
			pFloat = &fTextureViewPos;
			if(MousePos.x > Rect.left && MousePos.x < Rect.right &&
			   MousePos.y > Rect.top && MousePos.y < Rect.bottom)
			{ // The mouse is over the window enable view control:
				if(i & MK_LBUTTON && i & MK_RBUTTON)
					(*pFloat)[Z] -= (float) (MousePos.x-OldMousePos.x+MousePos.y-OldMousePos.y)/20;
				else
					if(i & MK_RBUTTON)
					{
						(*pFloat)[X] -= (float) (OldMousePos.x-MousePos.x)/100;
						(*pFloat)[Y] -= (float) (MousePos.y-OldMousePos.y)/100;
					}
			}
        break;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_TEXTURES_OK:
					if(hDCBitmap2 && !ReleaseDC(hWnd, hDCBitmap2))
						hDCBitmap2 = NULL;
					if(hWndTextures)
					{
						hWndTextures = NULL;
						EndDialog(hWnd, FALSE);
	 				}
					KillTimer(hWnd, 1);
					_AS->WriteLogMessage("Close textures dialog");
				return TRUE;
				
				case ID_TEXTURES_LOAD:
					sprintf(byTemp, "%s%s", _AS->byProgramPath, _AS->byTexturesDirectory);
					KillTimer(hWnd, 1);
					pbyTemp = ASGetFileName(hWnd, AS_T(T_LoadTexture), TEXTURE_FILES, 0, TRUE, byTemp, NULL);
					SetTimer(hWndTextures, 1, 1, NULL);
					if(!pbyTemp)
						break;
					// 	
					fp = fopen(pbyTemp, "rb");
					if(fp) // It's only oen file:
					{
						fclose(fp);
						// Cut off the main path:
						strcpy(byTemp3, &pbyTemp[strlen(_AS->byProgramPath)]);
						//
						// Check if the texture is already loaded:
						for(i = 0; i < pLevel->Header.iTextures; i++)
						{
							if(!strcmp(pLevel->pTexture[i].byFilename, byTemp3))
							{ // This texture is already loaded:
								sprintf(byTemp, "%s: %s", byTemp3, AS_M(M_TextureIsAlreadyLoaded));
								KillTimer(hWndTextures, 1);
								MessageBox(hWndTextures, byTemp, AS_T(T_Info), MB_OK | MB_ICONINFORMATION);
								SetTimer(hWndTextures, 1, 1, NULL);
								return 0;
							}
						}
						pLevel->LoadTexture(byTemp3);
						SendDlgItemMessage(hWnd, ID_TEXTURE_LIST, LB_SETCURSEL, pLevel->iCurrentTexture, 0L);
						pLevel->DestroyTexturesOpenGL(hDCEditorShow, 
												  hRCEditorShow);
						pLevel->GenTexturesOpenGL(hDCEditorShow, 
												  hRCEditorShow);
						goto WholeInit;
					}
					//
					sscanf(pbyTemp, "%s", byTemp); // Read the path
					pbyTemp += strlen(byTemp)+1;
					// Load the selected files:
					for(;;)
					{
						if(sscanf(pbyTemp, "%s", byTemp2) == EOF)
							break;
						if(byTemp[strlen(byTemp)-1] != '\\')
							sprintf(byTemp3, "%s\\%s", byTemp, byTemp2);
						else
							sprintf(byTemp3, "%s%s", byTemp, byTemp2);
						// Check if the texture is already loaded:
						for(i = 0; i < pLevel->Header.iTextures; i++)
						{
							if(!strcmp(pLevel->pTexture[i].byFilename, byTemp3))
							{ // This texture is already loaded:
								sprintf(byTemp, "%s: %s", byTemp3, AS_M(M_TextureIsAlreadyLoaded));
								KillTimer(hWndTextures, 1);
								MessageBox(hWndTextures, byTemp, AS_T(T_Info), MB_OK | MB_ICONINFORMATION);
								SetTimer(hWndTextures, 1, 1, NULL);
								goto NextFile;
							}
						}
						// Cut off the main path:
						strcpy(byTemp3, &byTemp3[strlen(_AS->byProgramPath)]);
						//
						if(pLevel->LoadTexture(byTemp3))
							break;
					NextFile:
						if(*(pbyTemp+strlen(byTemp2)) == 0)
							break;
						pbyTemp += strlen(byTemp2)+1;
					}
					pLevel->DestroyTexturesOpenGL(hDCEditorShow, 
											  hRCEditorShow);
					pLevel->GenTexturesOpenGL(hDCEditorShow, 
											  hRCEditorShow);
					goto WholeInit;

				case ID_TEXTURES_UNLOAD:
					if(!pLevel->pCurrentTexture->iID)
						break;
					if(pLevel->pCurrentTexture->iUsed)
					{
						sprintf(byTemp, "%s %s %d)", pLevel->pCurrentTexture->byFilename,
													 AS_M(M_TextureIsUsed), pLevel->pCurrentTexture->iUsed);
						KillTimer(hWndTextures, 1);
						if(MessageBox(hWndTextures, byTemp, AS_T(T_Question), MB_YESNO | MB_ICONINFORMATION) == IDNO)
						{
							SetTimer(hWndTextures, 1, 1, NULL);
							break;
						}
						SetTimer(hWndTextures, 1, 1, NULL);
					}
					pLevel->DestroyTexture(pLevel->iCurrentTexture);
					goto WholeInit;

				case ID_TEXTURES_UPDATE:
					pLevel->ReloadTextures();
					pLevel->GenTexturesOpenGL(hDCEditorShow, hRCEditorShow);
					goto WholeInit;

				case ID_TEXTURE_LIST:
					i = (int) SendDlgItemMessage(hWnd, ID_TEXTURE_LIST, LB_GETCURSEL, 0, 0L);
					if(i < 0 || i > pLevel->Header.iTextures-1)
					{
						pLevel->iCurrentTexture = -1;
						pLevel->pCurrentTexture = NULL;
					}
					else
					{
						pLevel->iCurrentTexture = i;
						pLevel->pCurrentTexture = &pLevel->pTexture[pLevel->iCurrentTexture];
					}
					if(pLevel->iCurrentTexture >= 0 || pLevel->iCurrentSurface <= pLevel->Header.iTextures)
						EnableWindow(GetDlgItem(hWnd, ID_TEXTURES_UNLOAD), TRUE);
					else
						EnableWindow(GetDlgItem(hWnd, ID_TEXTURES_UNLOAD), FALSE);
					goto Init;

				case ID_TEXTURES_RESET_VIEW:
					fTextureViewPos[X] = fTextureViewPos[Y] = 0.0f;
					fTextureViewPos[Z] = -5.0f;
				break;
			}
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_TEXTURES_OK, 0);
		break;
    }
    return FALSE;
} // end TexturesProc()

LRESULT CALLBACK CopyTexturePosProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin CopyTexturePosProc()
	SURFACE *pSurfaceT = pLevel->pCurrentSurface;
	char byTemp[256];
	int i;

    switch(iMessage)
    {
        case WM_INITDIALOG:
			sprintf(byTemp, "%s (Nr. %d)", AS_T(T_CopyTexturePos), iCurrentTextureAniStep);
			SetWindowText(hWnd, byTemp);
			SetDlgItemText(hWnd, ID_COPY_TEXTURE_POS_OK, AS_T(T_Ok));
			SetDlgItemText(hWnd, ID_COPY_TEXTURE_POS_CANCEL, AS_T(T_Cancel));
			SendDlgItemMessage(hWnd, ID_COPY_TEXTURE_POS_LIST, CB_RESETCONTENT , 0, 0L);
			for(i = 0; i < pSurfaceT->Header.iAniSteps; i++)
			{
				sprintf(byTemp, "%d", i);
				SendDlgItemMessage(hWnd, ID_COPY_TEXTURE_POS_LIST, CB_ADDSTRING, 0, (LPARAM) byTemp);
			}
			SendDlgItemMessage(hWnd, ID_COPY_TEXTURE_POS_LIST, CB_SETCURSEL, iCurrentTextureAniStep2, 0L);
			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
			BringWindowToTop(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_COPY_TEXTURE_POS_OK:
					EndDialog(hWnd, SendDlgItemMessage(hWnd, ID_COPY_TEXTURE_POS_LIST, CB_GETCURSEL, 0, 0L));
                return TRUE;

                case ID_COPY_TEXTURE_POS_CANCEL:
					EndDialog(hWnd, -1);
                return TRUE;
            }
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_COPY_TEXTURE_POS_CANCEL, 0);
		break;
    }
    return FALSE;
} // end CopyTexturePosProc()

LRESULT CALLBACK SetAnimationStepsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin SetAnimationStepsProc()
	SURFACE *pSurfaceT = pLevel->pCurrentSurface;
	char byTemp[256];
	int i;

    switch(iMessage)
    {
        case WM_INITDIALOG:
			SetWindowText(hWnd, AS_T(T_SetAnimationSteps));
			SetDlgItemText(hWnd, ID_SET_ANIMATION_STEPS_OK, AS_T(T_Ok));
			SetDlgItemText(hWnd, ID_SET_ANIMATION_STEPS_CANCEL, AS_T(T_Cancel));
			sprintf(byTemp, "%d", pSurfaceT->Header.iAniSteps);
			SetDlgItemText(hWnd, ID_SET_ANIMATION_STEPS_NUMBER, byTemp);
			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
			BringWindowToTop(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_SET_ANIMATION_STEPS_OK:
					GetDlgItemText(hWnd, ID_SET_ANIMATION_STEPS_NUMBER, byTemp, 256);
					i = (int) atoi(byTemp);
					if(!i)
						i++;
					EndDialog(hWnd, i);
                return TRUE;

                case ID_SET_ANIMATION_STEPS_CANCEL:
					EndDialog(hWnd, -1);
                return TRUE;
            }
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_SET_ANIMATION_STEPS_CANCEL, 0);
		break;
    }
    return FALSE;
} // end SetAnimationStepsProc()

LRESULT CALLBACK AnimationToolProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin AnimationToolProc()
	char byTemp[256];
	int i;

    switch(iMessage)
    {
        case WM_INITDIALOG:
			SetWindowText(hWnd, AS_T(T_SetAnimationSteps));
			SetDlgItemText(hWnd, ID_ANIMATION_TOOL_OK, AS_T(T_Ok));
			SetDlgItemText(hWnd, ID_ANIMATION_TOOL_CANCEL, AS_T(T_Cancel));
			SetDlgItemText(hWnd, ID_ANIMATION_TOOL_ROWS_T, AS_T(T_Rows));
			SetDlgItemText(hWnd, ID_ANIMATION_TOOL_COLUMNS_T, AS_T(T_Columns));
			SetDlgItemText(hWnd, ID_ANIMATION_TOOL_MOVE_X_T, AS_T(T_MoveX));
			SetDlgItemText(hWnd, ID_ANIMATION_TOOL_MOVE_Y_T, AS_T(T_MoveY));
			SetDlgItemText(hWnd, ID_ANIMATION_TOOL_STEPS_T, AS_T(T_Steps));

			if(AnimationTool.iRows <= 0)
				AnimationTool.iRows = 1;
			if(AnimationTool.iColumns <= 0)
				AnimationTool.iColumns = 1;
			if(AnimationTool.iSteps <= 0)
				AnimationTool.iSteps = 1;
			
			sprintf(byTemp, "%d", AnimationTool.iRows);
			SetDlgItemText(hWnd, ID_ANIMATION_TOOL_ROWS, byTemp);
			sprintf(byTemp, "%d", AnimationTool.iColumns);
			SetDlgItemText(hWnd, ID_ANIMATION_TOOL_COLUMNS, byTemp);
			sprintf(byTemp, "%d", AnimationTool.iMoveX);
			SetDlgItemText(hWnd, ID_ANIMATION_TOOL_MOVE_X, byTemp);
			sprintf(byTemp, "%d", AnimationTool.iMoveY);
			SetDlgItemText(hWnd, ID_ANIMATION_TOOL_MOVE_Y, byTemp);
			sprintf(byTemp, "%d", AnimationTool.iSteps);
			SetDlgItemText(hWnd, ID_ANIMATION_TOOL_STEPS, byTemp);

			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
			BringWindowToTop(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_ANIMATION_TOOL_OK:
					EndDialog(hWnd, TRUE);
                return TRUE;

                case ID_ANIMATION_TOOL_CANCEL:
					EndDialog(hWnd, FALSE);
                return FALSE;

				case ID_ANIMATION_TOOL_ROWS:
					GetDlgItemText(hWnd, ID_ANIMATION_TOOL_ROWS, byTemp, 256);
					i = (int) atoi(byTemp);
					if(i <= 0)
					{
						i = 1;
						SetDlgItemText(hWnd, ID_ANIMATION_TOOL_ROWS, "1");
					}
					AnimationTool.iRows = i;
				break;

				case ID_ANIMATION_TOOL_COLUMNS:
					GetDlgItemText(hWnd, ID_ANIMATION_TOOL_COLUMNS, byTemp, 256);
					i = (int) atoi(byTemp);
					if(i <= 0)
					{
						i = 1;
						SetDlgItemText(hWnd, ID_ANIMATION_TOOL_COLUMNS, "1");
					}
					AnimationTool.iColumns = i;
				break;

				case ID_ANIMATION_TOOL_MOVE_X:
					GetDlgItemText(hWnd, ID_ANIMATION_TOOL_MOVE_X, byTemp, 256);
					i = (int) atoi(byTemp);
					AnimationTool.iMoveX = i;
				break;

				case ID_ANIMATION_TOOL_MOVE_Y:
					GetDlgItemText(hWnd, ID_ANIMATION_TOOL_MOVE_Y, byTemp, 256);
					i = (int) atoi(byTemp);
					AnimationTool.iMoveY = i;
				break;

				case ID_ANIMATION_TOOL_STEPS:
					GetDlgItemText(hWnd, ID_ANIMATION_TOOL_STEPS, byTemp, 256);
					i = (int) atoi(byTemp);
					if(i <= 0)
					{
						i = 1;
						SetDlgItemText(hWnd, ID_ANIMATION_TOOL_STEPS, "1");
					}
					AnimationTool.iSteps = i;
				break;
            }
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_ANIMATION_TOOL_CANCEL, 0);
		break;
    }
    return FALSE;
} // end AnimationToolProc()
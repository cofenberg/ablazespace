//-----------------------------------------------------------------------------
// File: Blibs.h
//-----------------------------------------------------------------------------

#ifndef __BLIBS_H__
#define __BLIBS_H__


// Variables: *****************************************************************
extern AS_CONFIG *pConfig;
extern AS_CAMERA *pCamera;
extern BOOL bOnlyConfig, bLoader;
// Cheats:
extern BOOL bCheatsActivated,
			bInvulnerable,
			bFreeCamera,
			bAllLevels,
			bBlibsPeeping;
// Master access: (only for me!! ;-)
extern BOOL bMasterAccess;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern void ChangeDisplayMode(void);
extern void OpenCreditsDialog(HWND);
extern void SetCreditsLanguage(void);
extern void OpenHelp(void);
extern void OpenCreactiveMediaHomepage(void);
extern void OpenEclypseEntertainmentHomepage(void);
///////////////////////////////////////////////////////////////////////////////


#endif // __BLIBS_H__
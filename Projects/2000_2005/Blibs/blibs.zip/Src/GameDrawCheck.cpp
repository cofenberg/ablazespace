//-----------------------------------------------------------------------------
// File: GameDrawCheck.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


extern BOOL bTemp;
extern int iTemp;

// Variables: *****************************************************************
float fShowLevelMissionsBlend, fInGameMenuBlend;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
HRESULT GameDraw(AS_WINDOW *);
HRESULT GameCheck(AS_WINDOW *);
void ShowLevelMissionsMenu(AS_WINDOW *);
void CheckShowLevelMissionsMenu(void);
void DrawUnderWaterBlend(void);
///////////////////////////////////////////////////////////////////////////////


HRESULT GameDraw(AS_WINDOW *pWindow)
{ // begin GameDraw()
	AS_VECTOR3D vPos;
	float fBlend, f, fScale;
	char byTemp[256];
	int i;

	if(!_AS->bDraw)
		return 0;
	glDepthMask(GL_TRUE);
	if(!pLevel->Environment.bSkyCube ||
	   _ASConfig->bWireframeMode || _ASConfig->bPointMode)
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	else
		glClear(GL_DEPTH_BUFFER_BIT);
	SetCameraTranslation(TRUE);
	pLevel->DrawSkyCube();

	// Draw the level:
	glEnable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);
	
	SetCameraTranslation(FALSE);
	ASExtractFrustum();
	pLevel->UpdateVisibilityInformation();
	ASEnableLighting();
	pLevel->InitLevelDraw();
	pLevel->Draw(FALSE);
	pLevel->DrawActors();
	pLevel->DrawWater();	
	pLevel->DrawTransparent();
	glDisable(GL_FOG);
	pLevel->DrawLightMaps();
	pLevel->DrawShadowMaps();
	ParticleManager.Draw(TRUE);
	if(pLevel->Environment.bFog)
		glEnable(GL_FOG);
	pLevel->DrawActorEffects();
	// Draw autosave flares:
	if(_ASConfig->bHightRenderQuality)
	{
		vPos = ParticleManager.pSystem[PS_PLAYER_AUTOSAVE].fStartPos;
		vPos.fZ -= 0.7f;
		DrawFlares(vPos, 1.0f, 1.0f, 1.0f, 0.4f, fFlareRot);
	}

	pLevel->DrawOther(FALSE);
	pLevel->DrawActorText(pWindow);

	glDisable(GL_LIGHTING);
	glDepthMask(GL_TRUE);
	glClear(GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.f, (GLfloat)_ASConfig->iWindowWidth/(GLfloat)_ASConfig->iWindowHeight, 0.1f, 100.0f);
	glMatrixMode(GL_MODELVIEW);

	DrawUnderWaterBlend();

	if(pPlayer && pPlayer->bGoingDeath) // The player is going death:
		f = ((float) (g_lGameTimer-pPlayer->lStartTime)/PLAYER_DEAD_FLOOR_TIME);
			
	if(!fPauseBlend)
		pLevel->TextScriptManager.DrawTSPlayback(pWindow);

	if(pLevel->State.bLevelComplete)
		bSpecialPause = FALSE;
	if(bSpecialPause)
		fPauseBlend = 0.0f;
	if(fPauseBlend != 0.0f && !bSpecialPause)
	{ // Draw the game title:
		glDisable(GL_LIGHTING);
		glDisable(GL_FOG);
		glEnable(GL_BLEND);
		glDisable(GL_DEPTH_TEST);
		glDisable(GL_TEXTURE_2D);
		glDisable(GL_CULL_FACE);
		glBlendFunc(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);
		glColor4f(0.1f, 0.1f, 0.1f, 1.0f-fPauseBlend+0.2f);
		glLoadIdentity();
		glTranslatef(0.0f, 0.0f, -24.0f);
		glBegin(GL_QUADS);
			glVertex2f(-15.0f, -11.0f);
			glVertex2f( 15.0f, -11.0f);
			glVertex2f( 15.0f,  11.0f);
			glVertex2f(-15.0f,  11.0f);
		glEnd();
		_AS->iTriangles += 2;
		glEnable(GL_CULL_FACE);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);

		glEnable(GL_TEXTURE_2D);
		glColor4f(1.0f, 1.0f, 1.0f, fPauseBlend);
		glLoadIdentity();
		if(!bGameOver)
			glTranslatef(-1.0f, 0.4f, -1.8f);
		else
			glTranslatef(-1.0f, 0.6f, -1.8f);
		glRotatef(70.0f, 1.0f, 0.0f, 0.0f);
		glEnable(GL_DEPTH_TEST);
		glEnable(GL_BLEND);
		
		if(pLevel->State.bLevelComplete)
		{
			glColor4f(1.0f, 1.0f, 1.0f, fPauseBlend);
			pWindow->PrintAnimated(320, 200, "Level complete", 0, 3.0f, fFontAni, 1);
			glColor4f(0.7f, 0.7f, 0.7f, fPauseBlend*0.6f);
			pWindow->PrintAnimated(320, 203, "Level complete", 0, 3.1f, fFontAni, 1);
			glColor4f(0.5f, 0.5f, 0.5f, fPauseBlend*0.3f);
			pWindow->PrintAnimated(320, 206, "Level complete", 0, 3.2f, fFontAni, 1);
			glColor4f(0.3f, 0.3f, 0.3f, fPauseBlend*0.2f);
			pWindow->PrintAnimated(320, 209, "Level complete", 0, 3.3f, fFontAni, 1);
			glColor4f(0.2f, 0.2f, 0.2f, fPauseBlend*0.1f);
			pWindow->PrintAnimated(320, 212, "Level complete", 0, 3.4f, fFontAni, 1);
			glColor4f(1.0f, 1.0f, 1.0f, fPauseBlend);
		}
		if(!pLevel->State.bLevelComplete && !bCameraAnimation)
			ShowInGameMenu(pWindow); // Show menu:
	}
	glEnable(GL_BLEND);
	ShowLoadSaveMenu(pWindow);
	ShowOptionMenu(pWindow);
	ShowLevelMissionsMenu(pWindow);
	glDisable(GL_BLEND);

	if(pPlayer->fAir > pPlayer->fMaxAir)
		pPlayer->fAir = pPlayer->fMaxAir;
	if(pPlayer && pPlayer->fAir != pPlayer->fMaxAir && fPauseBlend != 1.0f && !pPlayer->bGoingDeath)
	{ // Show the players air:
		if(fPauseBlend != 0.0f)
			glEnable(GL_BLEND);
		else
			glDisable(GL_BLEND);
		glLoadIdentity();
		glDisable(GL_TEXTURE_2D);
		glDisable(GL_CULL_FACE);
		glDisable(GL_DEPTH_TEST);
		glTranslatef(-.5f, -0.7f, -2.0f);
		glColor4f(0.0f, 0.0f, 0.0f, 1.0f-fPauseBlend);
		glBegin(GL_QUADS);
			glVertex2f(-0.01f, -0.01f);
			glVertex2f(1.01f, -0.01f);
			glVertex2f(1.01f, 0.06f);
			glVertex2f(-0.01f, 0.06f);
		glEnd();
		_AS->iTriangles += 2;
		if(pPlayer->fAir > pPlayer->fMaxAir)
			glColor4f(0.0f, 1.0f, 0.0f, 1.0f-fPauseBlend);
		else
			glColor4f(1.0f-pPlayer->fAir/pPlayer->fMaxAir, 0.0f, pPlayer->fAir/pPlayer->fMaxAir, 1.0f-fPauseBlend);
		glBegin(GL_QUADS);
			glVertex2f(0.0f, 0.0f);
			glVertex2f(pPlayer->fAir/pPlayer->fMaxAir, 0.0f);
			glVertex2f(pPlayer->fAir/pPlayer->fMaxAir, 0.05f);
			glVertex2f(0.0f, 0.05f);
		glEnd();
		_AS->iTriangles += 2;
		glEnable(GL_TEXTURE_2D);
		glEnable(GL_CULL_FACE);
		glEnable(GL_BLEND);
		glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
		sprintf(byTemp, "%0.0f/%0.0f", pPlayer->fAir, pPlayer->fMaxAir);
		pWindow->PrintAnimated(320, 36, byTemp, 0, 1.0f, fFontAni, 1);
		glEnable(GL_DEPTH_TEST);
	}

	if(bCameraAnimation && (pLevel->pCurrentCameraScript == &pLevel->pCameraScript[pLevel->Camera.iStartCamera]))
	{
	}
	else
	if(pPlayer && (fPauseBlend != 1.0f || pLevel->State.bLevelComplete) && !bSpecialPause)
	{ // Display player info:	
		glEnable(GL_TEXTURE_2D);
		glEnable(GL_BLEND);
		glDisable(GL_LIGHTING);
		glDisable(GL_FOG);
		glDisable(GL_DEPTH_TEST);
		if(!pLevel->State.bLevelComplete)
			fBlend = 1.0f-fPauseBlend;
		else
			fBlend = 1.0f;
		
		// Display the texts:
		glColor4f(1.0f, 1.0f, 1.0f, fBlend);
		
		// Lives:
		sprintf(byTemp, "* %d", pPlayer->Item[AT_LIFE_ITEM].iNumber);
		pWindow->PrintAnimated(60, 425, byTemp, 0, 1.0f, fFontAni, 0);
		
		// Health:
		if(pPlayer->fHealth <= 20.0f)
			glColor4f(1.0f, 0.0f, 0.0f, fBlend);
		if(pPlayer->fHealth > pPlayer->fMaxHealth)
			glColor4f(0.0f, 1.0f, 0.0f, fBlend);
		sprintf(byTemp, "* %0.0f/%0.0f", pPlayer->fHealth, pPlayer->fMaxHealth);
		pWindow->PrintAnimated(60, 385, byTemp, 0, 1.0f, fFontAni, 0);
		glColor4f(1.0f, 1.0f, 1.0f, fBlend);
		
		// Coins:
		sprintf(byTemp, "* %d", pPlayer->Item[AT_COIN_ITEM].iNumber);
		pWindow->PrintAnimated(60, 345, byTemp, 0, 1.0f, fFontAni, 0);

		// Display this stuff if it is available:
		// Force:
		if(pPlayer->Item[AT_STRENGTH_ITEM].iNumber != 1)
		{
			if(!pPlayer->Item[AT_STRENGTH_ITEM].bUnlimited)
			{
				sprintf(byTemp, "* %d (%0.f%%)", pPlayer->Item[AT_STRENGTH_ITEM].iNumber, pPlayer->fStrength*100);
				pWindow->PrintAnimated(60, 235, byTemp, 0, 1.0f, fFontAni, 0);
			}
			DisplayActor[STRENGTH_DISPLAY].bActive = TRUE;
		}
		else
			DisplayActor[STRENGTH_DISPLAY].bActive = FALSE;
		
		// Weapon:
		if(pPlayer->bWeapon)
		{
			if(!pPlayer->Item[AT_WEAPON_ITEM].bUnlimited)
			{
				sprintf(byTemp, "* %d", pPlayer->Item[AT_WEAPON_ITEM].iNumber);
				pWindow->PrintAnimated(60, 155, byTemp, 0, 1.0f, fFontAni, 0);
			}
			DisplayActor[WEAPON_DISPLAY].bActive = TRUE;
		}
		else
			DisplayActor[WEAPON_DISPLAY].bActive = FALSE;
		
		// Pull:
		if(pPlayer->bPullBoxesPossible)
		{
			if(!pPlayer->Item[AT_PULL_ITEM].bUnlimited)
			{
				sprintf(byTemp, "* %d", pPlayer->Item[AT_PULL_ITEM].iNumber);
				pWindow->PrintAnimated(60, 115, byTemp, 0, 1.0f, fFontAni, 0);
			}
			DisplayActor[PULL_DISPLAY].bActive = TRUE;
		}
		else
			DisplayActor[PULL_DISPLAY].bActive = FALSE;
		
		// Throw:
		if(pPlayer->bThrowBoxesPossible)
		{
			if(!pPlayer->Item[AT_THROW_ITEM].bUnlimited)
			{
				sprintf(byTemp, "* %d", pPlayer->Item[AT_THROW_ITEM].iNumber);
				pWindow->PrintAnimated(60, 195, byTemp, 0, 1.0f, fFontAni, 0);
			}
			DisplayActor[THROW_DISPLAY].bActive = TRUE;
		}
		else
			DisplayActor[THROW_DISPLAY].bActive = FALSE;

		// Ghost:
		if(pPlayer->bGhostMode)
		{
			if(pPlayer->fGhostModeTime <= 5.0f)
			{
				glColor4f(1.0f, 0.0f, 0.0f, fBlend);
				fScale = 1.2f;
			}
			else
				fScale = 1.0f;
			sprintf(byTemp, "* %0.1f", pPlayer->fGhostModeTime);
			pWindow->PrintAnimated(60, 75, byTemp, 0, fScale, fFontAni, 0);
			DisplayActor[GHOST_DISPLAY].bActive = TRUE;
		}
		else
			DisplayActor[GHOST_DISPLAY].bActive = FALSE;
		
		// Speed:
		if(pPlayer->bSpeedMode)
		{
			if(pPlayer->fSpeedModeTime <= 5.0f)
			{
				glColor4f(1.0f, 0.0f, 0.0f, fBlend);
				fScale = 1.2f;
			}
			else
				fScale = 1.0f;
			sprintf(byTemp, "* %0.1f", pPlayer->fSpeedModeTime);
			pWindow->PrintAnimated(60, 35, byTemp, 0, fScale, fFontAni, 0);
			DisplayActor[SPEED_DISPLAY].bActive = TRUE;
		}
		else
			DisplayActor[SPEED_DISPLAY].bActive = FALSE;
		glColor4f(1.0f, 1.0f, 1.0f, fBlend);
		
		// Wing:
		if(pPlayer->bWingMode)
		{
			if(pPlayer->fWingModeTime <= 5.0f)
			{
				glColor4f(1.0f, 0.0f, 0.0f, fBlend);
				fScale = 1.2f;
			}
			else
				fScale = 1.0f;
			sprintf(byTemp, "* %0.1f", pPlayer->fWingModeTime);
			pWindow->PrintAnimated(550, 230, byTemp, 0, fScale, fFontAni, 0);
			DisplayActor[WING_DISPLAY].bActive = TRUE;
		}
		else
			DisplayActor[WING_DISPLAY].bActive = FALSE;
		glColor4f(1.0f, 1.0f, 1.0f, fBlend);
		
		// Shield:
		if(pPlayer->bShieldMode)
		{
			if(pPlayer->fShieldModeTime <= 5.0f)
			{
				glColor4f(1.0f, 0.0f, 0.0f, fBlend);
				fScale = 1.2f;
			}
			else
				fScale = 1.0f;
			sprintf(byTemp, "* %0.1f", pPlayer->fShieldModeTime);
			pWindow->PrintAnimated(550, 195, byTemp, 0, fScale, fFontAni, 0);
			DisplayActor[SHIELD_DISPLAY].bActive = TRUE;
		}
		else
			DisplayActor[SHIELD_DISPLAY].bActive = FALSE;
		
		// Jump:
		if(pPlayer->bJumpingPossible)
		{
			if(!pPlayer->Item[AT_JUMP_ITEM].bUnlimited)
			{
				sprintf(byTemp, "* %d", pPlayer->Item[AT_JUMP_ITEM].iNumber);
				pWindow->PrintAnimated(550, 160, byTemp, 0, 1.0f, fFontAni, 0);
			}
			DisplayActor[JUMP_DISPLAY].bActive = TRUE;
		}
		else
			DisplayActor[JUMP_DISPLAY].bActive = FALSE;
		if(pPlayer->Item[AT_DYNAMITE_ITEM].iNumber ||
		   pPlayer->Item[AT_DYNAMITE_ITEM].bUnlimited)
		{
			if(pPlayer->Item[AT_DYNAMITE_ITEM].iNumber)
			{
				sprintf(byTemp, "* %d", pPlayer->Item[AT_DYNAMITE_ITEM].iNumber);
				pWindow->PrintAnimated(550, 130, byTemp, 0, 1.0f, fFontAni, 0);
			}
			DisplayActor[DYNAMITE_DISPLAY].bActive = TRUE;
		}
		else
			DisplayActor[DYNAMITE_DISPLAY].bActive = FALSE;
		glColor4f(1.0f, 1.0f, 1.0f, fBlend);
		if(((pLevel->State.bLevelComplete && pLevel->Missions.iTimeLimit) || !pLevel->State.bLevelComplete) &&
		   (pLevel->Missions.bShowTime || pLevel->Missions.bTimeLimit))
		{ // Time:
			if(pLevel->Missions.bTimeLimit && pLevel->Missions.iTimeLimit < 10)
			{
				glColor4f(1.0f, 0.0f, 0.0f, fBlend);
				fScale = 1.2f;
			}
			else
				fScale = 1.0f;
			sprintf(byTemp, "* %d", pLevel->Missions.iTimeLimit);
			pWindow->PrintAnimated(550, 425, byTemp, 0, fScale, fFontAni, 0);
		}
		else
			DisplayActor[TIME_DISPLAY].bActive = FALSE;
		glColor4f(1.0f, 1.0f, 1.0f, fBlend);
		if(((pLevel->State.bLevelComplete && pLevel->Missions.iStepsLimit) || !pLevel->State.bLevelComplete) &&
		    (pLevel->Missions.bShowSteps || pLevel->Missions.bStepsLimit))
		{ // Steps:
			if(pLevel->Missions.bStepsLimit && pLevel->Missions.iStepsLimit < 10)
			{
				glColor4f(1.0f, 0.0f, 0.0f, fBlend);
				fScale = 1.2f;
			}
			else
				fScale = 1.0f;
			sprintf(byTemp, "* %d", pLevel->Missions.iStepsLimit);
			pWindow->PrintAnimated(550, 385, byTemp, 0, fScale, fFontAni, 0);
		}
		else
			DisplayActor[STEPS_DISPLAY].bActive = FALSE;
		
		// Draw the symbol:
		glColor4f(1.0f, 1.0f, 1.0f, fBlend);
		if(fBlend == 1.0f)
			glDisable(GL_BLEND);
		glBindTexture(GL_TEXTURE_2D, GameTexture[24].iOpenGLID);
		for(i = 0; i < DISPLAY_ACTORS; i++)
		{
			if(!DisplayActor[i].bActive)
				continue;
			glLoadIdentity();
			glTranslatef(DisplayActor[i].fWorldPos[X], DisplayActor[i].fWorldPos[Y], DisplayActor[i].fWorldPos[Z]);
			glRotatef(DisplayActor[i].fRot[X], 1.0f, 0.0f, 0.0f);
			glRotatef(DisplayActor[i].fRot[Y], 0.0f, 1.0f, 0.0f);
			glRotatef(DisplayActor[i].fRot[Z], 0.0f, 0.0f, 1.0f);
			glScalef(DisplayActor[i].fSize*0.007f, DisplayActor[i].fSize*0.007f, DisplayActor[i].fSize*0.007f);
			switch(i)
			{
				case HEALTH_DISPLAY: glCallList(iHealthItemList); break;
				case LIFE_DISPLAY: glCallList(iLifeItemList); break;
				case PULL_DISPLAY: glCallList(iPullItemList); break;
				case STRENGTH_DISPLAY: glCallList(iStrengthItemList); break;
				
				case POINT_DISPLAY:
					if(_ASConfig->bMultitexturing)
					{ // Render unit 2:
						glActiveTextureARB(GL_TEXTURE1_ARB);
						glEnable(GL_TEXTURE_2D);
						glEnable(GL_TEXTURE_GEN_S);
						glEnable(GL_TEXTURE_GEN_T);
						glColor3f(1.0f, 1.0f, 1.0f);
						glBindTexture(GL_TEXTURE_2D, GameTexture[20].iOpenGLID);
						glActiveTextureARB(GL_TEXTURE0_ARB);
					}	
					glScalef(1.5f, 1.5f, 1.5f);
					glCallList(iCoinItemList);
					if(_ASConfig->bMultitexturing)
					{ // Deactivate the second render unit:
						glActiveTextureARB(GL_TEXTURE1_ARB);
						glDisable(GL_TEXTURE_2D);
						glDisable(GL_TEXTURE_GEN_S);
						glDisable(GL_TEXTURE_GEN_T);
						glActiveTextureARB(GL_TEXTURE0_ARB);
					}
				break;

				case WEAPON_DISPLAY: glCallList(iWeaponItemList); break;
				case TIME_DISPLAY: glCallList(iTimeItemList); break;
				case STEPS_DISPLAY: glCallList(iStepsItemList); break;
				case SPEED_DISPLAY: glCallList(iSpeedItemList); break;
				case WING_DISPLAY: glCallList(iWingItemList); break;
				case JUMP_DISPLAY: glCallList(iJumpItemList); break;
				case THROW_DISPLAY: glCallList(iThrowItemList); break;
			}
		}

		glBindTexture(GL_TEXTURE_2D, GameTexture[25].iOpenGLID);
		for(i = 0; i < DISPLAY_ACTORS; i++)
		{
			if(!DisplayActor[i].bActive)
				continue;
			glLoadIdentity();
			glTranslatef(DisplayActor[i].fWorldPos[X], DisplayActor[i].fWorldPos[Y], DisplayActor[i].fWorldPos[Z]);
			glRotatef(DisplayActor[i].fRot[X], 1.0f, 0.0f, 0.0f);
			glRotatef(DisplayActor[i].fRot[Y], 0.0f, 1.0f, 0.0f);
			glRotatef(DisplayActor[i].fRot[Z], 0.0f, 0.0f, 1.0f);
			glScalef(DisplayActor[i].fSize*0.007f, DisplayActor[i].fSize*0.007f, DisplayActor[i].fSize*0.007f);
			switch(i)
			{
				case GHOST_DISPLAY:
					if(GHOST_TIME-(g_lGameTimer-pPlayer->lGhostModeTime) <= 0)
						glScalef(2.0f, 2.0f, 2.0f);
					glCallList(iGhostItemList);
				break;
				case SHIELD_DISPLAY: glCallList(iShieldItemList); break;
				case DYNAMITE_DISPLAY: glCallList(iDynamiteItemList); break;
			}
		}
	}

//	if(fPauseBlend == 0.0f)
//		DisplayTextScript(pWindow);

	// Show text:	
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glColor4f(1.0f, 1.0f, 1.0f, 0.95f);
	if(!bGameOver)
		DisplaySmallMessage(pWindow);
	
	if(bPause || pLevel->State.bLevelComplete)
	{
		if(fPauseBlend < 1.0f)
		{
			fPauseBlend += (float) g_lDeltatime/500;
			if(fPauseBlend > 1.0f)
				fPauseBlend = 1.0f;
		}
	}
	else
	{
		if(fPauseBlend > 0.0f)
		{
			fPauseBlend -= (float) g_lDeltatime/500;
			if(fPauseBlend < 0.0f)
				fPauseBlend = 0.0f;
		}
	}

	if(fPauseBlend != 0.0f && !pLevel->State.bLevelComplete && !bGameOver)
	{
		glColor4f(1.0f, 1.0f, 1.0f, fPauseTextBlend);
		pWindow->Print(320, 460, AS_T(T_Pause), 0, 1);
	}
//	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
//	sprintf(byTemp, "%f %f %f", pPlayer->fFieldPos[X],  pPlayer->fFieldPos[Y],  pPlayer->fWorldPos[Z]);
//	pWindow->Print(300, 450, byTemp, 0, 0);
	
/*	if(bTemp)
		pWindow->Print(300, 450, "On_", 0, 0);
	else
		pWindow->Print(300, 450, "Off", 0, 0);*/


/////////// Show vertex pos test: //////////////////////////
//	glColor4f(1.0f, 1.0f, 1.0f, 0.9f);
//	sprintf(byTemp, "%d", iTemp);
//	pWindow->Print(300, 450, byTemp, 0, 0);
/////////////////////////////////////////////////////////////////

	
	if(bLevelPressAnyKey && pLevel->State.bLevelComplete)
	{
		glColor4f(1.0f, 1.0f, 1.0f, fPauseTextBlend);
		pWindow->Print(320, 60, AS_M(M_PressAnyKeyToContinue), 0, 1);
	}
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	
	if(pPlayer && OktaActor.bActive && !pPlayer->bGoingDeath && !pLevel->State.bLevelComplete
	   && bHurryUpText && !bPause && fPauseBlend == 0.0f && !bGameOver)
		pWindow->Print(320, 10, AS_T(T_HurryUp), 0, 1);


//	sprintf(byTemp, "%d      %d     %d", g_lGameTimer, GetTickCount(), bTemp);
/*	if(pPlayer->MoveMode == ACTOR_MOVE_FORWARD)
		pWindow->Print(320, 60, "Vor", 0, 1);
	else
		pWindow->Print(320, 60, "Zur�ck", 0, 1);*/

	pLevel->DeInitLevelDraw();
	ASSwapBuffers(*pWindow->GethDC(), pWindow, TRUE);
	
	return FALSE;
} // end GameDraw()

HRESULT GameCheck(AS_WINDOW *pWindow)
{ // begin GameCheck()
	float fXAcceleration = 0.0f, fYAcceleration = 0.0f;
//  char byTemp[256];
	FLOAT3 fRotT;
	BOOL bLoop;
	int i, iFastLoop;

	_AS->ReadDXInput(*pWindow->GethWnd());

	CheckDebugKeys();
	AnimateFont();
	if(bGameOver)
		bPause = TRUE;
	pLevel->Check(TRUE);
	if(!bPause || (bPause && pLevel->State.bLevelComplete))
	{
		pLevel->CreateWaterBubbles();
		ParticleManager.Check();
		fFlareRot += (float) g_lDeltatime/80;
	}
	if(pLevel->State.bLevelComplete)
	{ 
		if(!pLevel->Header.bEndScreen)
			goto LeaveLevel;
		if(!bLevelPressAnyKey)
		{ // Take all tools like the weapon shots and give the player points for this:
			if(ASCheckTimeUpdate(&lLevelCompleteTimer, iLevelCompleteSpeed))
			{
				iFastLoop = 1;
				if(iLevelCompleteSpeed == 0)
				{
					for(i = 0; i < 256; i++)
					{
						if(ASKeyFirst[i])
						{
							iFastLoop = -1;;
							break;
						}
					}
				}
				for(i = 0; i < 2; i++)
				{
					if(iFastLoop == -1)
						i = 0;
					if(pPlayer)
					{
						pPlayer->MakeToolsToPoints();
						// Check if the player could now go to the next level:
						if(!pPlayer->bWeapon &&
						   !pPlayer->bPullBoxesPossible &&
						   !pPlayer->bThrowBoxesPossible && 
						   pPlayer->Item[AT_STRENGTH_ITEM].iNumber == 1 &&		
						   !pPlayer->bGhostMode &&
						   !pPlayer->bSpeedMode &&
						   !pPlayer->bWingMode &&
						   !pPlayer->bJumpingPossible &&
						   !pPlayer->bShieldMode &&
						   !pLevel->Missions.iTimeLimit &&
						   !pLevel->Missions.iStepsLimit)
						{
							bLevelPressAnyKey = TRUE; // The player could now go to the next level
							return 0;
						}
					}
					else
						bLevelPressAnyKey = TRUE; // The player could now go to the next level
				}
				// Stop now:
				if(ASKeyFirst[_ASConfig->iLevelRestartKey[0]])
				{ // Restart the current level:
					StartCurrentLevel();
					return 0;
				}
				if(CHECK_KEY(ASKeys, _ASConfig->iQuickLoadKey[0]))
				{
					QuickLoad();
					return 0;
				}
				for(i = 0; i < 256; i++)
				{
					if(CHECK_KEY(ASKeys, i))
					{
						iLevelCompleteSpeed = 0;
						break;
					}
				}
			}
		}
		else
		{ // Left this level now?
			if(ASKeyFirst[_ASConfig->iLevelRestartKey[0]])
			{ // Restart the current level:
				StartCurrentLevel();
				return 0;
			}
			if(CHECK_KEY(ASKeys, _ASConfig->iQuickLoadKey[0]))
			{
				QuickLoad();
				return 0;
			}
			for(i = 0; i < 256; i++)
			{
				if(ASKeyFirst[i])
				{ // Go into the next level:
				LeaveLevel:
					if(bEditorTestLevel)
					{
						_AS->SetNextModule(MODULE_EDITOR);
						return 0;					
					}
					
					if(PlayerIdentity.iSelectedLevel > CurrentCampaign.iLevels || bSingleLevel)
					{ // The game is finished!
						bInGameMenu = TRUE;
						return 0;
					}
					else
					{ // Go into the next level:
						PlayerIdentity.iSelectedLevel++;
						PlayerIdentity.iFinishedLevels++;
					}
					if(!bSingleLevel)
					{ // Save the player identity:
						if(pPlayer) // Backup the players actor:
							memcpy(&PlayerIdentity.PlayerBackup[PlayerIdentity.iSelectedLevel-1], pPlayer, sizeof(ACTOR));
						SavePlayerIdentity(&PlayerIdentity, &CurrentCampaign);
					}

					sprintf(byCurrentLevelName, "%s%s", _AS->byProgramPath, CurrentCampaign.byLevelFilename[PlayerIdentity.iSelectedLevel-1]);
					StartLevel(byCurrentLevelName, pLevel->Header.bEndScreen);
					break;
				}
			}
		}
	}
	if(bPause)
	{
		if(!pLevel->State.bLevelComplete)
		{
			for(i = 0; i < pLevel->Header.iMaxActors; i++)
				pLevel->pActorList[i]->dwAniTime = g_lGameTimer-pLevel->pActorList[i]->dwAniDeltaTime;
			OktaActor.dwAniTime = g_lGameTimer-OktaActor.dwAniDeltaTime;
			lSmallMessageTimer = g_lGameTimer-lSmallMessageTempTimer;
		}
		if(fPauseBlend != 1.0f)
			fPauseTextBlend = fPauseBlend;
		else
		{
			if(!bPauseTextBlend)
			{
				fPauseTextBlend += (float) g_lDeltatime/1000;
				if(fPauseTextBlend > 1.0f)
				{
					fPauseTextBlend = 1.0f;
					bPauseTextBlend = 1;
				}
			}
			else
			{
				fPauseTextBlend -= (float) g_lDeltatime/1000;
				if(fPauseTextBlend < 0.0f)
				{
					fPauseTextBlend = 0.0f;
					bPauseTextBlend = 0;
				}
			}
		}
		PlayerTemp.SetAction(AA_FUNNY);
		PlayerTemp.AnimateModel(pBlibsModel);
	}
	if(fPauseBlend != 1.0f)
		fPauseTextBlend = fPauseBlend;

	// Animate the display actors:
	if(!bPause || pLevel->State.bLevelComplete)
	{
		for(i = 0; i < DISPLAY_ACTORS; i++)
		{
			if(!DisplayActor[i].bActive)
				continue;
			if(ASCheckTimeUpdate(&DisplayActor[i].dwAniTime, OBJECTS_ANI_SPEED))
			{
				DisplayActor[i].iAniStep++;
				if(DisplayActor[i].iAniStep > 3)
					DisplayActor[i].iAniStep = 0;
			}
			// Rotate the object:
			DisplayActor[i].fRot[X] += (float) g_lDeltatime/OBJECT_ROTATE_SPEED;
			DisplayActor[i].fRot[Y] += (float) g_lDeltatime/OBJECT_ROTATE_SPEED;
			DisplayActor[i].fRot[Z] += (float) g_lDeltatime/OBJECT_ROTATE_SPEED;
		}
	}
		
	// Camera:
	if(!bCameraAnimation && !bGameOver && fPauseBlend <= 0.2f &&
	  !pPlayer->bFallIntoHole)
	{
		CheckCameraKeys(FALSE);
		//	Mouse camera movement and rotate:
		// Compute the player acceleration corresponding the mouse movement:
		fXAcceleration = ((float) ASMouse.lX)*_ASConfig->fMouseSensibility/30;
		fYAcceleration = ((float) ASMouse.lY)*_ASConfig->fMouseSensibility/30;
		if(CHECK_KEY(ASMouse.byButtons, 0) && CHECK_KEY(ASMouse.byButtons, 1) && !bPlayerCameraView)
			_ASCamera->fZ -= fYAcceleration;
		else
		{
			if(!bPlayerCameraView)
			{
				if(CHECK_KEY(ASMouse.byButtons, 1))
				{
					_ASCamera->fZ -= fYAcceleration;
					_ASCamera->fRot[Y] += fXAcceleration*5.0f;
				}
				if(CHECK_KEY(ASMouse.byButtons, 0))
				{
					if(fXAcceleration)
					{
						_ASCamera->fPos2[X] -= fSin90*fXAcceleration;
						_ASCamera->fPos2[Y] -= fCos90*fXAcceleration;
					}
					if(fYAcceleration)
					{
						_ASCamera->fPos2[X] -= fSin*fYAcceleration;
						_ASCamera->fPos2[Y] -= fCos*fYAcceleration;
					}
				}
				if((!CHECK_KEY(ASMouse.byButtons, 0) && !CHECK_KEY(ASMouse.byButtons, 1)) ||
				   CHECK_KEY(ASMouse.byButtons, 2))
				{
					_ASCamera->fRot[Z] -= fXAcceleration*10.0f;
					_ASCamera->fRot[X] += -_ASCamera->fRot2[X]+fYAcceleration*10.0f;
				}
			}
			else
			{
				_ASCamera->fRot2[Z] -= fXAcceleration*10;
				_ASCamera->fRot2[X] += fYAcceleration*10;
				if(CHECK_KEY(ASMouse.byButtons, 1))
					_ASCamera->fRot2[Y] += fXAcceleration*8;
			}
		}
	}
	if(bGameOver)
		_ASCamera->fRot[Z] += (float) g_lDeltatime/100;
	CalculateCamersSinCos(); // Update the sin/cos for the camera
	if(pLevel->Camera.bEndCameraLoop && pLevel->State.bLevelComplete)
		bLoop = TRUE;
	else
		bLoop = FALSE;
	if(!bPause || pLevel->State.bLevelComplete)
		pLevel->TextScriptManager.CheckTSPlayback();

	CheckSmallMessage();
	if(PlayCameraScript(bLoop))
	{
		if(!bPause)
			pLevel->CheckActors(FALSE);
		return 0;
	}
	if(pPlayer)
	{ // Connect he camera with the players actor:
		if(!bPlayerCameraView)
		{ // We are in the free camera perspective:
			if(_ASCamera->fZ > -2.0f)
				_ASCamera->fZ = -2.0f;
			if(_ASCamera->fZ < -15.0f)
				_ASCamera->fZ = -15.0f;
			if(_ASCamera->fRot[Y] > 90.0f)
				_ASCamera->fRot[Y] = 90.0f;
			if(_ASCamera->fRot[Y] < -90.0f)
				_ASCamera->fRot[Y] = -90.0f;
			if(_ASConfig->bTiltCamera)
			{ // Tilt the camera dependent on the players position:
				if(pPlayer->fWorldPos[X] > pLevel->Header.fWholeWidth/2)
				{
					if(!(pPlayer->fWorldPos[X]-pLevel->Header.fWholeWidth/2))
						fRotT[Y] = 0.0f;
					else
						fRotT[Y] = 100.0f*((pPlayer->fWorldPos[X]-pLevel->Header.fWholeWidth/2)/pLevel->Header.fWholeWidth/2);
				}
				else
				{
					if(!(pLevel->Header.fWholeWidth/2-pPlayer->fWorldPos[X]))
						fRotT[Y] = 0.0f;
					else
						fRotT[Y] = -100.0f*((pLevel->Header.fWholeWidth/2-pPlayer->fWorldPos[X])/pLevel->Header.fWholeWidth/2);
				}
				if(pPlayer->fWorldPos[Y] > pLevel->Header.fWholeHeight/2)
				{
					if(!(pPlayer->fWorldPos[Y]-pLevel->Header.fWholeHeight/2))
						fRotT[X] = 0.0f;
					else
						fRotT[X] = 100.0f*((pPlayer->fWorldPos[Y]-pLevel->Header.fWholeHeight/2)/pLevel->Header.fWholeHeight/2);
				}
				else
				{
					if(!(pLevel->Header.fWholeHeight/2-pPlayer->fWorldPos[Y]))
						fRotT[X] = 0.0f;
					else
						fRotT[X] = -100.0f*((pLevel->Header.fWholeHeight/2-pPlayer->fWorldPos[Y])/pLevel->Header.fWholeHeight/2);
				}
				_ASCamera->fRot[X] = fRotT[X]*fCos+fRotT[Y]*fSin;
				_ASCamera->fRot[Y] = fRotT[Y]*fCos+fRotT[X]*fSin;
			}
			// Set the current camera view:
			if(!pPlayer->bFallIntoHole)
			{
				_ASCamera->fPos[X] = -pPlayer->fWorldPos[X]+_ASCamera->fPos2[X]-0.5f;
				_ASCamera->fPos[Y] = -pPlayer->fWorldPos[Y]+_ASCamera->fPos2[Y]-0.5f;
				_ASCamera->fPos[Z] = _ASCamera->fZ+_ASCamera->fPos2[Z];
			}

			_ASCamera->fPos2[X] -= _ASCamera->fPos2[X]/4*((float) g_lDeltatime/100);
			_ASCamera->fPos2[Y] -= _ASCamera->fPos2[Y]/4*((float) g_lDeltatime/100);
			_ASCamera->fPos2[Z] -= _ASCamera->fPos2[Z]/4*((float) g_lDeltatime/100);
			if(_ASConfig->bBackCamera)
			{ // Set the back camera:
				_ASCamera->fRot[Z] = -pPlayer->fRot[Y]-90.0f;
			}
		}
		else
		{ // We are in the ego-shooter perspective:
			_ASCamera->fPos[X] = -pPlayer->fWorldPos[X]-0.5f;
			_ASCamera->fPos[Y] = -pPlayer->fWorldPos[Y]-0.5f;
			_ASCamera->fPos[Z] = pPlayer->fWorldPos[Z]-0.2f;
			
			// Check the rotation boundings:
			for(i = 0; i < 3; i++)
			{
				if(_ASCamera->fRot2[i] > 40)
					_ASCamera->fRot2[i] = 40;
				if(_ASCamera->fRot2[i] < -40)
					_ASCamera->fRot2[i] = -40;
			}
			_ASCamera->fRot[X] = 90.0f+_ASCamera->fRot2[X];
			_ASCamera->fRot[Y] = _ASCamera->fRot2[Y];
			_ASCamera->fRot[Z] = -pPlayer->fRot[Y]+90.0f+_ASCamera->fRot2[Z];
			if(ASCheckTimeUpdate(&lCameraTimerT, 10))
			{
				for(i = 0; i < 3; i++)
				{
					_ASCamera->fRot2[i] /= 1.001f;
					_ASCamera->fRot2Velocity[i] /= 1.03f;
					_ASCamera->fRot2[i] += (float) _ASCamera->fRot2Velocity[i]*g_lDeltatime/10;
				}
			}
		}
	}

	if(pLevel->State.bLevelComplete)
	{
		pLevel->CheckActors(FALSE);
		return 0;
	}
// Keys:
	if(byGameMenuMenu == GM_MAIN_MENU && ASKeyFirst[_ASConfig->iLevelRestartKey[0]])
	{ // Restart the current level:
		StartCurrentLevel();
		return 0;
	}
	
	
	if(ASKeyFirst[DIK_Q])
	{
//		pLevel->TextScriptManager.PlayTextScript(NULL, 1);
		bTemp = !bTemp;
		if(!bTemp)
		{
		glEnable(GL_DITHER);
		}
		else
		{
		glDisable(GL_DITHER);

		}
		//_ASConfig->bShowQuadtrees = !_ASConfig->bShowQuadtrees;
	}
		glDisable(GL_DITHER);
	
//////////////// Show vertex pos test: //////////////////////////
	if(ASKeyFirst[DIK_A])
	{
		if(iTemp > 1)
			iTemp--;
	}
	if(ASKeyFirst[DIK_S])
	{
		if(iTemp < pLuciferModel->header.numVertices-1)
			iTemp++;
	}
	if(CHECK_KEY(ASKeys, DIK_D))
	{
		if(iTemp > 1)
			iTemp--;
	}
	if(CHECK_KEY(ASKeys, DIK_F))
	{
		if(iTemp < pLuciferModel->header.numVertices-1)
			iTemp++;
	}
/////////////////////////////////////////////////////////////////

/*	if(ASKeyFirst[DIK_A])
	{
		DestroyGameObjects();
		InitGameObjects();

		DestroyGameLists();
		CreateGameLists();
//		bTemp = !bTemp;
	}*/
//	if(ASKeyFirst[DIK_Q])
//		_ASConfig->bShadowmaps = !_ASConfig->bShadowmaps;
	if(ASKeyFirst[DIK_W])
		_ASConfig->bLightmaps = !_ASConfig->bLightmaps;

	if(ASKeyFirst[_ASConfig->iShowLevelMissionsKey[0]])
	{ // Show the level missions:
//		bPlayTextScript = FALSE;
		byGameMenuMenu = GM_SHOW_LEVEL_MISSIONS;
		ASKeyFirst[_ASConfig->iPauseKey[0]] = TRUE;
	}
	fInGameMenuBlend *= fPauseBlend;
	if(bPause && !pLevel->State.bLevelComplete)
	{ // The player has some options in the pause screen:
		CheckInGameMenu();
	}
	if(ASKeyFirst[DIK_ESCAPE])
		ASKeyFirst[DIK_ESCAPE] = ASKeyFirst[DIK_ESCAPE];
	CheckLoadSaveMenu();
	CheckOptionMenu();
	CheckShowLevelMissionsMenu();
	if(ASKeyFirst[DIK_ESCAPE] && !byGameMenuMenu)
	{ // Pause the game:
//		bPlayTextScript = FALSE;
		ASKeyFirst[_ASConfig->iPauseKey[0]] = TRUE;
	}
	if(ASKeyFirst[_ASConfig->iPauseKey[0]] && !byGameMenuMenu &&
	   !pLevel->State.bLevelComplete && pPlayer && !pPlayer->bGoingDeath &&
	   !bGameOver || (byGameMenuMenu == GM_SHOW_LEVEL_MISSIONS && ASKeyFirst[_ASConfig->iShowLevelMissionsKey[0]]))
	{
		if(bPause)
			byGameMenuMenu = GM_MAIN_MENU;
		else
		{
			if(!fPauseBlend)
			{
				wglMakeCurrent(*pWindow->GethDC(), *pWindow->GethRC());
				TakeSaveGameScreenshot(pWindow, &TempSaveScreenshot);
			}
		}
		if(CHECK_KEY(ASKeys, 56))
			bSpecialPause = TRUE;
		else
			bSpecialPause = FALSE;
		InitMenuPoints();
		lPauseTimer = g_lGameTimer;
		bPause = !bPause;
		if(bPause)
			fPauseBlend = 0.0f;
		byGameMenuSelected = 0;
		lSmallMessageTempTimer = g_lGameTimer-lSmallMessageTimer;
	}
	if(ASKeyFirst[DIK_F1])
		OpenHelp(); // Open the help file:

	if(byGameMenuMenu == GM_MAIN_MENU)
	{
		if(ASKeyFirst[_ASConfig->iChangePerspectiveKey[0]])
		{ // Change the perscective:
			if(!bPlayerCameraView && pLevel->Camera.bPlayerCamera)
			{
				memcpy(&TempCamera, _ASCamera, sizeof(AS_CAMERA));
				bPlayerCameraView = TRUE;
				for(i = 0; i < 3; i++)
					_ASCamera->fRot[i] = _ASCamera->fRot2[i] = _ASCamera->fRot2Velocity[i] = 0;
			}
			else
			if(bPlayerCameraView && pLevel->Camera.bFreeCamera)
			{
				memcpy(_ASCamera, &TempCamera, sizeof(AS_CAMERA));
				_ASCamera->fPos2[Z] = -_ASCamera->fPos[Z];
				bPlayerCameraView = FALSE;
			}
		}

		if(CHECK_KEY(ASKeys, _ASConfig->iQuickLoadKey[0]))
			QuickLoad();
		if(CHECK_KEY(ASKeys, _ASConfig->iQuickSaveKey[0]))
		{
			TakeSaveGameScreenshot(pWindow, &TempSaveScreenshot);
			QuickSave();
		}
	}
	
	if(ASKeyFirst[DIK_F12])
	{ // Open the configuration menu:
		SendMessage(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), WM_COMMAND, ID_OPTIONS_CONFIG, 0);
	}

	if(bPause)
		return 0;
// Actors:
	if(!bPause && !pLevel->State.bLevelComplete)
		pLevel->CheckActors(FALSE);

	// Level time limit:
	pLevel->Missions.CheckTime();
	pLevel->CheckMissions();
	if(OktaActor.bActive && ASCheckTimeUpdate(&lHurryUpTimer, 500))
		bHurryUpText = !bHurryUpText;
	return 0;
} // end GameCheck()

void ShowLevelMissionsMenu(AS_WINDOW *pWindow)
{ // begin ShowLevelMissionsMenu()
	pLevel->ShowMissionState(pWindow, fShowLevelMissionsBlend);
} // end ShowLevelMissionsMenu()

void CheckShowLevelMissionsMenu(void)
{ // begin CheckShowLevelMissionsMenu()
	fShowLevelMissionsBlend -= (float) g_lDeltatime/1000;
	if(fShowLevelMissionsBlend < 0.0f)
		fShowLevelMissionsBlend = 0.0f;
	if(byGameMenuMenu != GM_SHOW_LEVEL_MISSIONS)
		return;
	fShowLevelMissionsBlend += (float) g_lDeltatime/500;
	if(fShowLevelMissionsBlend > 1.0f)
		fShowLevelMissionsBlend = 1.0f;
	if(ASKeyFirst[DIK_ESCAPE])
	{
		ASPlayFmodSample(pChangeSample, FSOUND_LOOP_OFF);
		byGameMenuSelected = 0;
		byGameMenuMenu = GM_MAIN_MENU;
	}
} // end CheckShowLevelMissionsMenu()

void DrawUnderWaterBlend(void)
{ // begin DrawUnderWaterBlend()
	FLOAT4 fWaterColor;

	if(!bUnderWater)
		return;

	glDisable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_FOG);
	glBlendFunc(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);

	// Get the water color at the camera position:
	pLevel->ComputeWaterColor(_ASCamera->fWorldPos[X], _ASCamera->fWorldPos[Y], &fWaterColor);
	fWaterColor[A] = 1.0f-fWaterColor[A];
	if(fWaterColor[A] < 0.1f)
		fWaterColor[A] += 0.2f;
	glColor4fv(fWaterColor);
	glDisable(GL_CULL_FACE);
	glLoadIdentity();
	glTranslatef(0.0f, 0.0f, -24.0f);
	glBegin(GL_QUADS);
		glVertex2f(-30.0f, -30.0f);
		glVertex2f( 30.0f, -30.0f);
		glVertex2f( 30.0f,  30.0f);
		glVertex2f(-30.0f,  30.0f);
	glEnd();
	_AS->iTriangles += 2;
	glEnable(GL_CULL_FACE);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
} // end DrawUnderWaterBlend()
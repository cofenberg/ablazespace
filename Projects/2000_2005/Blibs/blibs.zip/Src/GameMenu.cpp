//-----------------------------------------------------------------------------
// File: GameMenu.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
BOOL bInGameMenu;
AS_TEXTURE GameMenuTexture[GAME_MENU_TEXTURES];
AS_TEXTURE CreditsTexture[100];
int iGameMenuBackgroundAniStep;
long lGameMenuBackgroundAniTimer, lPressNewKeyTimer, lCreditsTextTimer;
long lBackFlashTime, lBackFlashTimeDelay, lLastGameMenuKeyTime;
float fBackFlash, fBackFlashDelta, fCurrentBackFlash, fLastBackFlash,
	  fGameMenuBlend, fSelectedSize, fCreditsBlend, fGalaxyIn, fAlienRot,
	  fMainOptionsBlend, fOptionsBlend, fKeysSetupBlend, fSelectSingeLevelBlend,
	  fSelectCampaignBlend, fSelectPlayerIDBlend, fSelectCampaignLevelBlend,
	  fSelectCampaignPlayerIDBlend, fAreYouSureBlend, fCreditsAlienBlend,
	  fLoadMenuBlend, fSaveMenuBlend, fPlayerIDMenuBlend;
int iCreditsBackground, iWholeCreditsTextY;
float fCreditsBackgroundTimer, fCreditsBackgroundBlend;
char byGameMenuSelected, byGameMenuMenu, byLastGameMenuMenu, byLastGameMenuMenu2,
	 byGameMenuSelectedTemp;
int iCreditsTextY;
BOOL bGetPlayerName, // Does the player give in his name?
     bGetNewKey, // Does we wait for a new key definition?
	 bPressNewKeyText,
	 bAreYouSureQuestion,
	 bAreYouSureQuestionAnswer,
	 bSelectedSize,
	 bShowCredits,
	 bMenuChange,
	 bCursorVisible, // For the blinking cursor
	 bShowLogosAfterCredits;
char byGetPlayerName[256]; // The players name
long dwMainMenuStartTime, //  The start time of the main menu
	 dwCursorTime; // For the blinking cursor
MENU_POINT MenuPoint[MENU_POINTS];
MENU_POINT 
		// Main menu:
		   *pMP_MainMenu_StartGame = &MenuPoint[0],
		   *pMP_MainMenu_ContinueGame = &MenuPoint[1],
		   *pMP_MainMenu_SingleLevel = &MenuPoint[2],
		   *pMP_MainMenu_Options = &MenuPoint[3],
		   *pMP_MainMenu_Editor = &MenuPoint[4],
		   *pMP_MainMenu_Help = &MenuPoint[5],
		   *pMP_MainMenu_Credits = &MenuPoint[6],
		   *pMP_MainMenu_Quit = &MenuPoint[7],
		   
		// Are you sure:
		   *pMP_AreYouSure_Yes = &MenuPoint[8],
		   *pMP_AreYouSure_No = &MenuPoint[9],
		   
		// Options:
		   *pMP_Options_KeysSetup = &MenuPoint[10],
		   *pMP_Options_OtherOptions = &MenuPoint[11],
		   *pMP_Options_Back = &MenuPoint[12],

		// Keys setup:
		   *pMP_KeysSetup_Left = &MenuPoint[13],
		   *pMP_KeysSetup_Right = &MenuPoint[14],
		   *pMP_KeysSetup_Up = &MenuPoint[15],
		   *pMP_KeysSetup_Down = &MenuPoint[16],
		   *pMP_KeysSetup_Shot = &MenuPoint[17],
		   *pMP_KeysSetup_Kick = &MenuPoint[18],
		   *pMP_KeysSetup_Action = &MenuPoint[19],
		   *pMP_KeysSetup_Pull = &MenuPoint[20],
		   *pMP_KeysSetup_Suicide = &MenuPoint[21],
		   *pMP_KeysSetup_Jump = &MenuPoint[22],
		   *pMP_KeysSetup_ShowLevelMissions = &MenuPoint[23],
		   *pMP_KeysSetup_LevelRestart = &MenuPoint[24],
		   *pMP_KeysSetup_QuickLoad = &MenuPoint[25],
		   *pMP_KeysSetup_QuickSave = &MenuPoint[26],
		   *pMP_KeysSetup_Pause = &MenuPoint[27],
		   *pMP_KeysSetup_StandartView = &MenuPoint[28],
		   *pMP_KeysSetup_ChangePerspective = &MenuPoint[29],
		   *pMP_KeysSetup_StandartConfiguration = &MenuPoint[30],
		   *pMP_KeysSetup_Back = &MenuPoint[31],
		
		// Ingame menu:
		   *pMP_InGameMenu_Continue = &MenuPoint[32],
		   *pMP_InGameMenu_ShowLevelMissions = &MenuPoint[33],
		   *pMP_InGameMenu_Load = &MenuPoint[34],
		   *pMP_InGameMenu_Save = &MenuPoint[35],
		   *pMP_InGameMenu_LevelRestart = &MenuPoint[36],
		   *pMP_InGameMenu_RestartCampaign = &MenuPoint[37],
		   *pMP_InGameMenu_Options = &MenuPoint[38],
		   *pMP_InGameMenu_Exit = &MenuPoint[39],
		   
		// Player ID menu:
		   *pMP_PlayerIDMenu_StartGame = &MenuPoint[40],
		   *pMP_PlayerIDMenu_SelectLevel = &MenuPoint[41],
		   *pMP_PlayerIDMenu_Load = &MenuPoint[42],
		   *pMP_PlayerIDMenu_Back = &MenuPoint[43];

// Game titel:
FLOAT3 fTitelGridPoint[TITEL_GRID_X_SIZE*TITEL_GRID_Y_SIZE];
FLOAT2 fTitelGridTexture[TITEL_GRID_X_SIZE*TITEL_GRID_Y_SIZE];
float fGameTitleTimer;
// For the animated font in the main menu:
float fFontAni[4][2]; // The current vertex position
float fFontAniLast[4][2]; // The last vertex position
float fFontAniT[4][2]; // The vertex target position
float fFontAniV[4][2]; // The vertex velocity
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
HRESULT GameMenuLoop(void);
void LoadMainMenuTextures(void);
void DestroyMainMenuTextures(void);
void LoadCreditsTextures(void);
void DestroyCreditsTextures(void);
void StartMusic(void);
HRESULT GameMenuDraw(AS_WINDOW *);
void DrawMenuBackground(float, float, float, float,
						float, float, float, float,
						FLOAT3, float);
void ShowLoadSaveMenu(AS_WINDOW *);
void ShowOptionMenu(AS_WINDOW *);
HRESULT GameMenuCheck(AS_WINDOW *);
void CheckLoadSaveMenu(void);
void CheckOptionMenu(void);
void ShowInGameMenu(AS_WINDOW *);
void CheckInGameMenu(void);
void CheckDeletePlayerID(void);
void CheckDeletePlayerSaveGame(void);
void GameMenuStartCampaignWithOldPlayerID(void);
void AnimateFont(void);
void InitMenuPoints(void);
void CheckMenuPoints(void);
void SetMenuPointColor(MENU_POINT *, float, int);
void ShowMainMenu(void);
void ShowCredits(void);
void ShowLogos(void);
void DrawTitel(void);
void CheckTitel(void);
void InitTitel(void);
///////////////////////////////////////////////////////////////////////////////
void InitGalaxy(void);
void DrawGalaxy(void);
void DrawStar(float);
///////////////////////////////////////////////////////////////////////////////


HRESULT GameMenuLoop(void)
{ // begin GameMenuLoop()
	MSG msg;

	InitMenuPoints();
	InitGalaxy();
	InitTitel();
	bEditorTestLevel = FALSE;
	byGameMenuMenu = GM_MAIN_MENU;
	iGameMenuBackgroundAniStep = byGameMenuSelected = 0;
	lGameMenuBackgroundAniTimer = lBackFlashTime = lLastGameMenuKeyTime = 0;
	fGameMenuBlend = fCreditsBlend = 0.0f;
	dwMainMenuStartTime = g_lGameTimer = 0;
	bMenuChange = bSelectedSize = bShowCredits = FALSE;
	fSelectedSize = 0.5f;
	fGalaxyIn = 0.1f;
	fCreditsAlienBlend = 0.0f;
	g_lDeltatime = g_lLastlooptime = g_lNow = GetTickCount();

	_AS->pWindow[GAME_WINDOW_ID].SetDrawFunction(GameMenuDraw);
	_AS->pWindow[GAME_WINDOW_ID].SetCheckFunction(GameMenuCheck);

	LoadMainMenuTextures();
	StartMusic("MainMenu.mp3");
	
	// Go into the game menu loop:
	_AS->WriteLogMessage("Enter the game menu loop");
	for(;;)
	{
		if(PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
    	{
        	if(!GetMessage(&msg, NULL, 0, 0))
                break;
        	TranslateMessage(&msg);
        	DispatchMessage(&msg);
    	}
		else
		{	
			if(bShowLogos)
				break;
			if(_AS->GetShutDown() || _AS->CheckModuleChange() || !bInGameMenu)
				PostQuitMessage(0);
			if(!_AS->GetActive())
				continue;
			_AS->UpdateWindows(FALSE);
			CheckMusic();
		}
	}
	_AS->WriteLogMessage("Left the game menu loop");

	DestroySingleLevelList();
	DestroyCampaignsList();
	DestroyPlayerIDList();
	DestroyMainMenuTextures();

	return msg.wParam;
} // end GameMenuLoop()

void LoadMainMenuTextures(void)
{ // begin LoadMainMenuTextures()
	char byFilename[GAME_MENU_TEXTURES][256] = {"Water.jpg", "G_Cloud.jpg", "BlibsTitel.jpg",
												"Credits1.jpg", "Credits2.jpg", "Credits3.jpg",
												"CreditsLogo.jpg", "Blibs.jpg"};
	ASLoadTextures(byFilename, GAME_MENU_TEXTURES, GameMenuTexture);
	ASGenOpenGLTextures(GAME_MENU_TEXTURES, GameMenuTexture);
	LoadCreditsTextures();
} // end LoadMainMenuTextures()

void DestroyMainMenuTextures(void)
{ // begin DestroyMainMenuTextures()
	DestroyCreditsTextures();
	ASDestroyOpenGLTextures(GAME_MENU_TEXTURES, GameMenuTexture);
	ASDestroyTextures(GAME_MENU_TEXTURES, GameMenuTexture);
} // end DestroyMainMenuTextures()

void LoadCreditsTextures(void)
{ // begin LoadCreditsTextures()
	char byFilename[100][256];

	for(int i = 0; i < iASCreditsTextures; i++)
		strcpy(byFilename[i], pbyASCreditsTexture[i]);
	ASLoadTextures(byFilename, iASCreditsTextures, CreditsTexture);
	ASGenOpenGLTextures(iASCreditsTextures, CreditsTexture);
} // end LoadCreditsTextures()

void DestroyCreditsTextures(void)
{ // begin DestroyCreditsTextures()
	ASDestroyOpenGLTextures(iASCreditsTextures, CreditsTexture);
	ASDestroyTextures(iASCreditsTextures, CreditsTexture);
} // end DestroyCreditsTextures()

HRESULT GameMenuDraw(AS_WINDOW *pWindow)
{ // begin GameMenuMenu()
	FLOAT3 fColor = {fCurrentBackFlash-0.3f, fCurrentBackFlash-0.3f, 0.2f+fCurrentBackFlash};
	int iX, iY, i, i2;
	float fX, fY, fSize;
	float fBackAni[4][2];
	int iMenuBlendMove;
	char byTemp[256];

	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glDisable(GL_FOG);
	glDisable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_DEPTH_TEST);
	gluPerspective(45.f, (GLfloat)_ASConfig->iWindowWidth/(GLfloat)_ASConfig->iWindowHeight, 0.1f, 100.0f);
	if(fCreditsBlend && fCreditsAlienBlend)
	{
		fAlienRot += (float) g_lDeltatime/50;
		glViewport(0, 0, 128, 128);	// Set our viewport (match texture size)

		GLfloat afLightData[4]  = {0.0f, 0.0f, 0.0f, 1.0f};
		glLightfv(GL_LIGHT2, GL_POSITION, afLightData);
		afLightData[0] = 0.2f;
		afLightData[1] = 0.2f;
		afLightData[2] = 0.2f;
		afLightData[3] = 1.0f;
		glLightfv(GL_LIGHT2, GL_DIFFUSE, afLightData);
		glEnable(GL_LIGHT2);
		ASEnableLighting();
		 // Draw the 'dancing' alien:
		glDisable(GL_BLEND);
		glEnable(GL_DEPTH_TEST);
		glCullFace(GL_FRONT);
		glColor3f(0.5f, 0.5f, 0.5f);
		glLoadIdentity();
		glTranslatef(5.0f, -4.0f, -15.0f);
		glRotatef(-90.0f+fAlienRot, 0.0f, 1.0f, 0.0f);
		glScalef(0.025f, 0.025f, 0.025f);
		glBindTexture(GL_TEXTURE_2D, GameMenuTexture[7].iOpenGLID);
		ASDrawMd2FrameInt(pBlibsModel, PlayerTemp.iAniStep, PlayerTemp.iNextAniStep, (float) (g_lGameTimer-PlayerTemp.dwAniTime)/(float) (PLAYER_ANIMATION_SPEED));
		glBindTexture(GL_TEXTURE_2D, GameTexture[4+PlayerTemp.bSkinSleep].iOpenGLID);
		ASDrawMd2FrameInt(pBlibsEyesModel, PlayerTemp.iAniStep, PlayerTemp.iNextAniStep, (float) (g_lGameTimer-PlayerTemp.dwAniTime)/(float) (PLAYER_ANIMATION_SPEED));
		glDisable(GL_LIGHT2);
		glDisable(GL_LIGHTING);
		glCullFace(GL_BACK);

		glBindTexture(GL_TEXTURE_2D, BlurTexture.iOpenGLID); // Bind to the blur texture
		// Copy our viewport to the blur texture (from 0,0 to 128,128... no border)
		glCopyTexImage2D(GL_TEXTURE_2D, 0, GL_LUMINANCE, 0, 0, 128, 128, 0);

		// Now draw the real visible stuff:
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glViewport(0, 0, _ASConfig->iWindowWidth, _ASConfig->iWindowHeight);
	}
	
	if(fGameMenuBlend != 0.0f)
	{ // Draw the galaxy:
		glEnable(GL_BLEND);
		glColor4f(1.0f, 1.0f, 1.0f, 0.99f);
		glBlendFunc(GL_ONE, GL_ONE);
		DrawGalaxy();
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);

		// Draw the water background:
		// Calculate the current frame:
		iY = (int) iGameMenuBackgroundAniStep/7;
		iX = iGameMenuBackgroundAniStep-iY*7;
		fX = (float) (1+65*iX)/512;
		fY = (float) (1+65*iY)/512;
		fSize = 0.125f;
		glColor4f(fCurrentBackFlash, fCurrentBackFlash, 0.5f+fCurrentBackFlash, 0.5f);
		glEnable(GL_BLEND);
		glLoadIdentity();
		glTranslatef(0.0f, 0.0f, -34.0f);
		glBindTexture(GL_TEXTURE_2D, GameMenuTexture[0].iOpenGLID);
		glBegin(GL_QUADS);
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(fX, fY); glVertex3f(-15.0f, -11.0f, 10.0f);
			glTexCoord2f(fX+fSize, fY); glVertex3f(15.0f, -11.0f, 10.0f);
			glTexCoord2f(fX+fSize, fY+fSize); glVertex3f(15.0f, 11.0f, 10.0f);
			glTexCoord2f(fX, fY+fSize); glVertex3f(-15.0f, 11.0f, 10.0f);
		glEnd();
		_AS->iTriangles += 2;

		glColor3f(1.0f, 1.0f, 1.0f);	
		pWindow->Print(560, 430, GAME_VERSION, 0, 0);

		DrawTitel();

		glLoadIdentity();
		glBindTexture(GL_TEXTURE_2D, GameMenuTexture[0].iOpenGLID);
		glTranslatef(0.0f, 0.0f, -24.0f*fGameMenuBlend-10.0f);
		glBlendFunc(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);
		
		for(i = 0; i < 4; i++)
			for(i2 = 0; i2 < 2; i2++)
				fBackAni[i][i2] = -fFontAni[i][i2]*0.1f;
			
		glColor4f(fCurrentBackFlash-0.3f, fCurrentBackFlash-0.3f, 0.2f+fCurrentBackFlash, 0.4f);
		if(fMainOptionsBlend)
		{ // Main menu background:
			DrawMenuBackground(fX, fY, fSize*fMainOptionsBlend, 10.0f,
							   -4.5f+fBackAni[3][0], -7.4f+fBackAni[3][1],
							   5.0f+fBackAni[2][0], 1.5f+fBackAni[0][1],
							   fColor, 1.0f-0.8f*fMainOptionsBlend);
			// The info bar:
			DrawMenuBackground(fX, fY, fSize*fMainOptionsBlend, 10.0f,
							   -14.0f, -9.0f,
							   14.0f, -12.0f,
							   fColor, 1.0f-0.8f*fMainOptionsBlend);
		}
		if(fSelectSingeLevelBlend)
			DrawMenuBackground(fX, fY, fSize*fSelectSingeLevelBlend, 10.0f,
							   -14.0f+fBackAni[3][0], -10.0f+fBackAni[3][1],
							   14.0f+fBackAni[2][0], 1.0f+fBackAni[0][1],
							   fColor, 1.0f-0.8f*fSelectSingeLevelBlend);
		if(fSelectCampaignBlend)
			DrawMenuBackground(fX, fY, fSize*fSelectCampaignBlend, 10.0f,
							   -14.0f+fBackAni[3][0], -10.0f+fBackAni[3][1],
							   14.0f+fBackAni[2][0], 1.0f+fBackAni[0][1],
							   fColor, 1.0f-0.8f*fSelectCampaignBlend);
		if(fSelectPlayerIDBlend)
			DrawMenuBackground(fX, fY, fSize*fSelectPlayerIDBlend, 10.0f,
							   -14.0f+fBackAni[3][0], -10.0f+fBackAni[3][1],
							   14.0f+fBackAni[2][0], 1.0f+fBackAni[0][1],
							   fColor, 1.0f-0.8f*fSelectPlayerIDBlend);
		if(fSelectCampaignLevelBlend)
			DrawMenuBackground(fX, fY, fSize*fSelectCampaignLevelBlend, 10.0f,
							   -14.0f+fBackAni[3][0], -10.0f+fBackAni[3][1],
							   14.0f+fBackAni[2][0], 1.0f+fBackAni[0][1],
							   fColor, 1.0f-0.8f*fSelectCampaignLevelBlend);
		if(fOptionsBlend) // The options menu:
			DrawMenuBackground(fX, fY, fSize*fOptionsBlend, 10.0f,
							   -5.0f+fBackAni[3][0], -3.0f+fBackAni[3][1],
							   5.5f+fBackAni[2][0], 1.3f+fBackAni[0][1],
							   fColor, 1.0f-0.8f*fOptionsBlend);
		if(fKeysSetupBlend) // Keys setup menu:
			DrawMenuBackground(fX, fY, fSize*fKeysSetupBlend, 10.0f,
							   -11.0f+fBackAni[3][0], -8.0f+fBackAni[3][1],
							   11.0f+fBackAni[2][0], 5.5f+fBackAni[0][1],
							   fColor, 1.0f-0.8f*fKeysSetupBlend);
		if(fSelectCampaignPlayerIDBlend) // Select player ID or create a new one:
			DrawMenuBackground(fX, fY, fSize*fSelectCampaignPlayerIDBlend, 10.0f,
							   -14.0f+fBackAni[3][0], -10.0f+fBackAni[3][1],
							   14.0f+fBackAni[2][0], 1.5f+fBackAni[0][1],
							   fColor, 1.0f-0.8f*fSelectCampaignPlayerIDBlend);
		if(fAreYouSureBlend) // Are you sure question:
			DrawMenuBackground(fX, fY, fSize*fAreYouSureBlend, 10.0f,
							   -5.0f+fBackAni[3][0], -3.0f+fBackAni[3][1],
							   5.5f+fBackAni[2][0], 1.0f+fBackAni[0][1],
							   fColor, 1.0f-0.8f*fAreYouSureBlend);
		if(fLoadMenuBlend) // Load menu:
			DrawMenuBackground(fX, fY, fSize*fLoadMenuBlend, 10.0f,
							   -14.0f+fBackAni[3][0], -1.0f+fBackAni[3][1],
							   14.0f+fBackAni[2][0], 10.0f+fBackAni[0][1],
							   fColor, 1.0f-0.8f*fLoadMenuBlend);
		if(fSaveMenuBlend) // Save menu:
			DrawMenuBackground(fX, fY, fSize*fSaveMenuBlend, 10.0f,
							   -14.0f+fBackAni[3][0], -1.0f+fBackAni[3][1],
							   14.0f+fBackAni[2][0], 10.0f+fBackAni[0][1],
							   fColor, 1.0f-0.8f*fSaveMenuBlend);
		if(fPlayerIDMenuBlend) // The player ID menu:
			DrawMenuBackground(fX, fY, fSize*fPlayerIDMenuBlend, 10.0f,
							   -5.0f+fBackAni[3][0], -3.0f+fBackAni[3][1],
							   5.5f+fBackAni[2][0], 1.3f+fBackAni[0][1],
							   fColor, 1.0f-0.8f*fPlayerIDMenuBlend);
		if((fLoadMenuBlend || fSaveMenuBlend) &&
		    iPlayerSaveGamesList && byGameMenuSelected < iPlayerSaveGamesList)
		{ // Draw the save game info bar:
			// Draw background:
			DrawMenuBackground(fX, fY, fSize*fLoadMenuBlend, 10.0f,
							   -7.0f+fBackAni[3][0], -10.0f+fBackAni[3][1],
							   7.0f+fBackAni[2][0], -2.0f+fBackAni[0][1],
							   fColor, 1.0f-0.8f*fLoadMenuBlend);
		}
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);
		glEnable(GL_BLEND);
		// Draw the options:
		// Menu name:
		if(fMainOptionsBlend)
		{ // Main menu:
			iMenuBlendMove = (int) ((1.0f-fMainOptionsBlend)*500.0f);
			glColor4f(1.0f, 1.0f, 1.0f, fMainOptionsBlend);
			pWindow->Print(0, 5-iMenuBlendMove, "A game by Eclypse Entertainment 2002       All rights reserved!", 0, 0);			
			pWindow->PrintAnimated(320-iMenuBlendMove, 240, AS_T(T_MainMenu), 0, 2.0f*fGameMenuBlend, fFontAni, 1);
			// Start game:
			SetMenuPointColor(pMP_MainMenu_StartGame, fMainOptionsBlend, -1);
			pWindow->PrintAnimated(320-iMenuBlendMove, 210, AS_T(T_StartGame), 0, 1.2f*fGameMenuBlend*pMP_MainMenu_StartGame->fSize, fFontAni, 1);
			// Continue game:
			SetMenuPointColor(pMP_MainMenu_ContinueGame, fMainOptionsBlend, -1);
			pWindow->PrintAnimated(320-iMenuBlendMove, 190, AS_T(T_ContinueGame), 0, 1.2f*fGameMenuBlend*pMP_MainMenu_ContinueGame->fSize, fFontAni, 1);
			// Single level:
			SetMenuPointColor(pMP_MainMenu_SingleLevel, fMainOptionsBlend, -1);
			pWindow->PrintAnimated(320-iMenuBlendMove, 170, AS_T(T_SingleLevel), 0, 1.2f*fGameMenuBlend*pMP_MainMenu_SingleLevel->fSize, fFontAni, 1);
			// Options:
			SetMenuPointColor(pMP_MainMenu_Options, fMainOptionsBlend, -1);
			pWindow->PrintAnimated(320-iMenuBlendMove, 150, AS_T(T_Options), 0, 1.2f*fGameMenuBlend*pMP_MainMenu_Options->fSize, fFontAni, 1);
			// Editor:
			SetMenuPointColor(pMP_MainMenu_Editor, fMainOptionsBlend, -1);
			pWindow->PrintAnimated(320-iMenuBlendMove, 130, AS_T(T_Editor), 0, 1.2f*fGameMenuBlend*pMP_MainMenu_Editor->fSize, fFontAni, 1);
			// Help:
			SetMenuPointColor(pMP_MainMenu_Help, fMainOptionsBlend, -1);
			pWindow->PrintAnimated(320-iMenuBlendMove, 110, AS_T(T_Help), 0, 1.2f*fGameMenuBlend*pMP_MainMenu_Help->fSize, fFontAni, 1);
			// Credits:
			SetMenuPointColor(pMP_MainMenu_Credits, fMainOptionsBlend, -1);
			pWindow->PrintAnimated(320-iMenuBlendMove, 90, AS_T(T_Credits), 0, 1.2f*fGameMenuBlend*pMP_MainMenu_Credits->fSize, fFontAni, 1);
			// Quit:
			SetMenuPointColor(pMP_MainMenu_Quit, fMainOptionsBlend, -1);
			pWindow->PrintAnimated(320-iMenuBlendMove, 70, AS_T(T_Quit), 0, 1.2f*fGameMenuBlend*pMP_MainMenu_Quit->fSize, fFontAni, 1);
		}
		if(fSelectSingeLevelBlend)
		{ // Select single level:
			iMenuBlendMove = (int) ((1.0f-fSelectSingeLevelBlend)*500.0f);
			glColor4f(1.0f, 1.0f, 1.0f, fSelectSingeLevelBlend);
			pWindow->PrintAnimated(320-iMenuBlendMove, 230, AS_T(T_SingleLevel), 0, 2.0f*fGameMenuBlend, fFontAni, 1);
			glColor4f(1.0f, 0.0f, 0.0f, fSelectSingeLevelBlend);
			for(i = byGameMenuSelected-5, iY = 200; i < byGameMenuSelected+11; i++)
			{
				if(i < 0)
					continue;
				if(i >= iSingleLevelsList)
				{
					iY -= 10;
					if(i == byGameMenuSelected)
					{
						glColor4f(1.0f, 0.0f, 0.0f, fSelectSingeLevelBlend);
						pWindow->PrintAnimated(320-iMenuBlendMove, iY, AS_T(T_BackReturn), 0, 1.0f*fGameMenuBlend*fSelectedSize, fFontAni, 1);
					}
					else
					{
						glColor4f(1.0f, 1.0f, 1.0f, fSelectSingeLevelBlend);
						pWindow->PrintAnimated(320-iMenuBlendMove, iY, AS_T(T_BackReturn), 0, 1.0f*fGameMenuBlend, fFontAni, 1);
					}
					break;
				}
				glColor4f(1.0f, 1.0f, 1.0f, fSelectSingeLevelBlend);
				if(i == byGameMenuSelected)
				{
					glColor4f(1.0f, 0.0f, 0.0f, fSelectSingeLevelBlend);
					pWindow->PrintAnimated(10-iMenuBlendMove, iY, pbySingleLevelsList[i], 0, 1.0f*fGameMenuBlend*fSelectedSize, fFontAni, 0);
				}
				else
					pWindow->PrintAnimated(10-iMenuBlendMove, iY, pbySingleLevelsList[i], 0, 1.0f*fGameMenuBlend, fFontAni, 0);
				iY -= 20;
			}
		}
		if(fSelectCampaignBlend)
		{ // Select campaign:
			iMenuBlendMove = (int) ((1.0f-fSelectCampaignBlend)*500.0f);
			glColor4f(1.0f, 1.0f, 1.0f, fSelectCampaignBlend);
			pWindow->PrintAnimated(320-iMenuBlendMove, 230, AS_T(T_SelectCampaign), 0, 2.0f*fGameMenuBlend, fFontAni, 1);
			for(i = byGameMenuSelected-5, iY = 200; i < byGameMenuSelected+11; i++)
			{
				if(i < 0)
					continue;
				if(i >= iCampaignsList)
				{
					iY -= 10;
					if(i == byGameMenuSelected)
					{
						glColor4f(1.0f, 0.0f, 0.0f, fSelectCampaignBlend);
						pWindow->PrintAnimated(320-iMenuBlendMove, iY, AS_T(T_BackReturn), 0, 1.0f*fGameMenuBlend*fSelectedSize, fFontAni, 1);
					}
					else
					{
						glColor4f(1.0f, 1.0f, 1.0f, fSelectCampaignBlend);
						pWindow->PrintAnimated(320-iMenuBlendMove, iY, AS_T(T_BackReturn), 0, 1.0f*fGameMenuBlend, fFontAni, 1);
					}
					break;
				}
				glColor4f(1.0f, 1.0f, 1.0f, fSelectCampaignBlend);
				if(i == byGameMenuSelected)
				{
					glColor4f(1.0f, 0.0f, 0.0f, fSelectCampaignBlend);
					pWindow->PrintAnimated(10-iMenuBlendMove, iY, pbyCampaignList[i], 0, 1.0f*fGameMenuBlend*fSelectedSize, fFontAni, 0);
				}
				else
					pWindow->PrintAnimated(10-iMenuBlendMove, iY, pbyCampaignList[i], 0, 1.0f*fGameMenuBlend, fFontAni, 0);
				iY -= 20;
			}
		}
		if(fSelectPlayerIDBlend)
		{  // Select player ID: (for continue game)
			iMenuBlendMove = (int) ((1.0f-fSelectPlayerIDBlend)*500.0f);
			glColor4f(1.0f, 1.0f, 1.0f, fSelectPlayerIDBlend);
			pWindow->PrintAnimated(320-iMenuBlendMove, 230, AS_T(T_SelectYourID), 0, 2.0f*fGameMenuBlend, fFontAni, 1);
			for(i = byGameMenuSelected-5, iY = 200; i < byGameMenuSelected+11; i++)
			{
				if(i < 0)
					continue;
				if(i >= iPlayerIDsList)
				{
					iY -= 10;
					if(i == byGameMenuSelected)
					{
						glColor4f(1.0f, 0.0f, 0.0f, fSelectPlayerIDBlend);
						pWindow->PrintAnimated(320-iMenuBlendMove, iY, AS_T(T_BackReturn), 0, 1.0f*fGameMenuBlend*fSelectedSize, fFontAni, 1);
					}
					else
						pWindow->PrintAnimated(320-iMenuBlendMove, iY, AS_T(T_BackReturn), 0, 1.0f*fGameMenuBlend, fFontAni, 1);
					break;
				}
				if(i == byGameMenuSelected)
				{
					glColor4f(1.0f, 0.0f, 0.0f, fSelectPlayerIDBlend);
					pWindow->PrintAnimated(10-iMenuBlendMove, iY, pbyPlayerIDList[i], 0, 1.0f*fGameMenuBlend*fSelectedSize, fFontAni, 0);
				}
				else
					pWindow->PrintAnimated(10-iMenuBlendMove, iY, pbyPlayerIDList[i], 0, 1.0f*fGameMenuBlend, fFontAni, 0);
				glColor4f(1.0f, 1.0f, 1.0f, fSelectPlayerIDBlend);
				iY -= 20;
			}
		}
		if(fSelectCampaignLevelBlend)
		{ // Select level of the selected campaign:
			iMenuBlendMove = (int) ((1.0f-fSelectCampaignLevelBlend)*500.0f);
			glColor4f(1.0f, 1.0f, 1.0f, fSelectCampaignLevelBlend);
			pWindow->PrintAnimated(320-iMenuBlendMove, 230, AS_T(T_SelectLevel), 0, 2.0f*fGameMenuBlend, fFontAni, 1);
			for(i = byGameMenuSelected-5, iY = 200; i < byGameMenuSelected+11; i++)
			{
				if(i < 0)
					continue;
				if(i >= PlayerIdentity.iFinishedLevels+1 || !pbyCampaignListLevelNames || i >= CurrentCampaign.iLevels || !pbyCampaignListLevelNames[i])
				{
					iY -= 10;
					if(i == byGameMenuSelected)
					{
						glColor4f(1.0f, 0.0f, 0.0f, fSelectCampaignLevelBlend);
						pWindow->PrintAnimated(320-iMenuBlendMove, iY, AS_T(T_BackReturn), 0, 1.0f*fGameMenuBlend*fSelectedSize, fFontAni, 1);
					}
					else
						pWindow->PrintAnimated(320-iMenuBlendMove, iY, AS_T(T_BackReturn), 0, 1.0f*fGameMenuBlend, fFontAni, 1);
					break;
				}
				if(i == byGameMenuSelected)
				{
					glColor4f(1.0f, 0.0f, 0.0f, fSelectCampaignLevelBlend);
					pWindow->PrintAnimated(10-iMenuBlendMove, iY, pbyCampaignListLevelNames[i], 0, 1.0f*fGameMenuBlend*fSelectedSize, fFontAni, 0);
				}
				else
					pWindow->PrintAnimated(10-iMenuBlendMove, iY, pbyCampaignListLevelNames[i], 0, 1.0f*fGameMenuBlend, fFontAni, 0);
				glColor4f(1.0f, 1.0f, 1.0f, fSelectCampaignLevelBlend);
				iY -= 20;
			}
		}
		if(fSelectCampaignPlayerIDBlend)
		{ // Select player ID or create a new one:
			iMenuBlendMove = (int) ((1.0f-fSelectCampaignPlayerIDBlend)*500.0f);
			glColor4f(1.0f, 1.0f, 1.0f, fSelectCampaignPlayerIDBlend);
			pWindow->PrintAnimated(320-iMenuBlendMove, 230, AS_T(T_SelectYourID), 0, 2.0f*fGameMenuBlend, fFontAni, 1);
			for(i = byGameMenuSelected-5, iY = 200; i < byGameMenuSelected+11; i++)
			{
				if(i < 0)
					continue;
				if(i >= iPlayerIDsList)
				{
					if(i == iPlayerIDsList)
					{
						iY -= 10;
						if(i == byGameMenuSelected)
						{ // Create a new player ID:
							glColor4f(1.0f, 0.0f, 0.0f, fSelectCampaignPlayerIDBlend);
							if(!bGetPlayerName)
								pWindow->PrintAnimated(320-iMenuBlendMove, iY, AS_T(T_CreateANewPlayerID), 0, 1.0f*fGameMenuBlend*fSelectedSize, fFontAni, 1);
							else
							{ // The player gives in his name:
								if(!bCursorVisible)
									sprintf(byTemp, "%s", byGetPlayerName);
								else
									sprintf(byTemp, "%s_", byGetPlayerName);
								pWindow->PrintAnimated(10-iMenuBlendMove, iY, byTemp, 0, 1.0f*fGameMenuBlend, fFontAni, 0);
							}
						}
						else
						{ // Back:
							if(!bGetPlayerName)
								pWindow->PrintAnimated(320-iMenuBlendMove, iY, AS_T(T_CreateANewPlayerID), 0, 1.0f*fGameMenuBlend, fFontAni, 1);
							else
							{ // The player gives in his name:
								if(!bCursorVisible)
									sprintf(byTemp, "%s", byGetPlayerName);
								else
									sprintf(byTemp, "%s_", byGetPlayerName);
								pWindow->PrintAnimated(10-iMenuBlendMove, iY, byTemp, 0, 1.0f*fGameMenuBlend, fFontAni, 0);
							}
						}
						iY -= 20;
					}
					else
					{
						if(i == byGameMenuSelected)
						{
							glColor4f(1.0f, 0.0f, 0.0f, fSelectCampaignPlayerIDBlend);
							pWindow->PrintAnimated(320-iMenuBlendMove, iY, AS_T(T_BackReturn), 0, 1.0f*fGameMenuBlend*fSelectedSize, fFontAni, 1);
						}
						else
						{
							glColor4f(1.0f, 1.0f, 1.0f, fSelectCampaignPlayerIDBlend);
							pWindow->PrintAnimated(320-iMenuBlendMove, iY, AS_T(T_BackReturn), 0, 1.0f*fGameMenuBlend, fFontAni, 1);
						}
						break;
					}
					continue;
				}
				if(i == byGameMenuSelected)
				{
					glColor4f(1.0f, 0.0f, 0.0f, fSelectCampaignPlayerIDBlend);
					pWindow->PrintAnimated(10-iMenuBlendMove, iY, pbyPlayerIDList[i], 0, 1.0f*fGameMenuBlend*fSelectedSize, fFontAni, 0);
				}
				else
					pWindow->PrintAnimated(10-iMenuBlendMove, iY, pbyPlayerIDList[i], 0, 1.0f*fGameMenuBlend, fFontAni, 0);
				glColor4f(1.0f, 1.0f, 1.0f, fSelectCampaignPlayerIDBlend);
				iY -= 20;
			}
		}
		if(fPlayerIDMenuBlend)
		{ // Player ID menu:
			iMenuBlendMove = (int) ((1.0f-fPlayerIDMenuBlend)*500.0f);
			glColor4f(1.0f, 1.0f, 1.0f, fPlayerIDMenuBlend);
			pWindow->PrintAnimated(320-iMenuBlendMove, 240, AS_T(T_PlayerIDMenu), 0, 1.5f*fGameMenuBlend, fFontAni, 1);
			if(!PlayerIdentity.bSingleLevel)
			{
				iY = 185;
				SetMenuPointColor(pMP_PlayerIDMenu_StartGame, fPlayerIDMenuBlend, -1);
				pWindow->PrintAnimated(320-iMenuBlendMove, 215, AS_T(T_StartGame), 0, 1.0f*fGameMenuBlend*pMP_PlayerIDMenu_StartGame->fSize, fFontAni, 1);
				SetMenuPointColor(pMP_PlayerIDMenu_SelectLevel, fPlayerIDMenuBlend, -1);
				pWindow->PrintAnimated(320-iMenuBlendMove, 200, AS_T(T_SelectLevel), 0, 1.0f*fGameMenuBlend*pMP_PlayerIDMenu_SelectLevel->fSize, fFontAni, 1);
			}
			else
				iY = 205;
			SetMenuPointColor(pMP_PlayerIDMenu_Load, fPlayerIDMenuBlend, -1);
			pWindow->PrintAnimated(320-iMenuBlendMove, iY, AS_T(T_Load), 0, 1.0f*fGameMenuBlend*pMP_PlayerIDMenu_Load->fSize, fFontAni, 1);
			SetMenuPointColor(pMP_PlayerIDMenu_Back, fPlayerIDMenuBlend, -1);
			pWindow->PrintAnimated(320-iMenuBlendMove, iY-15, AS_T(T_BackReturn), 0, 1.0f*fGameMenuBlend*pMP_PlayerIDMenu_Back->fSize, fFontAni, 1);
		}
		ShowOptionMenu(pWindow);
		ShowLoadSaveMenu(pWindow);
	
	    // For smooth blend in and out:
		glClear(GL_DEPTH_BUFFER_BIT);
		glEnable(GL_BLEND);
		glDisable(GL_TEXTURE_2D);
		glBlendFunc(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);
		glColor4f(0.0f, 0.0f, 0.0f, fGameMenuBlend);
		glDisable(GL_CULL_FACE);
		glLoadIdentity();
		glTranslatef(0.0f, 0.0f, -24.0f);
		glBegin(GL_QUADS);
			glVertex2f(-15.0f, -11.0f);
			glVertex2f( 15.0f, -11.0f);
			glVertex2f( 15.0f,  11.0f);
			glVertex2f(-15.0f,  11.0f);
		glEnd();
		_AS->iTriangles += 2;
		glEnable(GL_CULL_FACE);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	}

	DisplaySmallMessage(pWindow);
	CheckSmallMessage();

	if(fCreditsBlend != 0.0f)
	{ // Draw the credits menu:
		glEnable(GL_BLEND);
		glEnable(GL_TEXTURE_2D);
		
		// Draw the background picture:
		glColor4f(0.5f, 0.5f, 0.5f, fCreditsBlend*fCreditsBackgroundBlend);
		glLoadIdentity();
		glTranslatef(0.0f, 0.0f, -24.0f);
		glBindTexture(GL_TEXTURE_2D, GameMenuTexture[3+iCreditsBackground].iOpenGLID);
		glBegin(GL_QUADS);
			glTexCoord2f(0.0f, 1.0f); glVertex2f(-13.5f, -10.0f);
			glTexCoord2f(1.0f, 1.0f); glVertex2f(13.5f, -10.0f);
			glTexCoord2f(1.0f, 0.0f); glVertex2f(13.5f, 10.0f);
			glTexCoord2f(0.0f, 0.0f); glVertex2f(-13.5f, 10.0f);
		glEnd();
		_AS->iTriangles += 2;

		// Draw the water animation over the background picture:
		iY = (int) iGameMenuBackgroundAniStep/7;
		iX = iGameMenuBackgroundAniStep-iY*7;
		fX = (float) (1+65*iX)/512;
		fY = (float) (1+65*iY)/512;
		fSize = 0.125f;
		glColor4f(0.5f*fCreditsBlend, 0.5f*fCreditsBlend, 0.8f*fCreditsBlend, 0.7f);
		glEnable(GL_BLEND);
		glLoadIdentity();
		glTranslatef(0.0f, 0.0f, -34.0f);
		glBindTexture(GL_TEXTURE_2D, GameMenuTexture[0].iOpenGLID);
		glBlendFunc(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);
		glBegin(GL_QUADS);
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(fX, fY); glVertex3f(-15.0f, -11.0f, 10.0f);
			glTexCoord2f(fX+fSize, fY); glVertex3f(15.0f, -11.0f, 10.0f);
			glTexCoord2f(fX+fSize, fY+fSize); glVertex3f(15.0f, 11.0f, 10.0f);
			glTexCoord2f(fX, fY+fSize); glVertex3f(-15.0f, 11.0f, 10.0f);
		glEnd();
		_AS->iTriangles += 2;
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);

		if(fCreditsAlienBlend)
		{ // Draw the 'dancing' alien:
			GLfloat afLightData[4]  = {0.0f, 0.0f, 0.0f, 1.0f};
			glLightfv(GL_LIGHT2, GL_POSITION, afLightData);
			afLightData[0] = 0.4f;
			afLightData[1] = 0.4f;
			afLightData[2] = 0.4f;
			afLightData[3] = 1.0f;
			glLightfv(GL_LIGHT2, GL_DIFFUSE, afLightData);
			glEnable(GL_LIGHT2);
			ASEnableLighting();
			glEnable(GL_BLEND);
			glEnable(GL_DEPTH_TEST);
			glColor4f(1.0f, 1.0f, 1.0f, fCreditsAlienBlend);
			if(fCreditsAlienBlend == 1.0f)
				glDisable(GL_BLEND);
			glCullFace(GL_FRONT);
			glLoadIdentity();
			glTranslatef(5.0f, -4.0f, -15.0f);
			glRotatef(-90.0f+fAlienRot, 0.0f, 1.0f, 0.0f);
			glScalef(0.025f, 0.025f, 0.025f);
			glBindTexture(GL_TEXTURE_2D, GameMenuTexture[7].iOpenGLID);
			ASDrawMd2FrameInt(pBlibsModel, PlayerTemp.iAniStep, PlayerTemp.iNextAniStep, (float) (g_lGameTimer-PlayerTemp.dwAniTime)/(float) (PLAYER_ANIMATION_SPEED));
			glBindTexture(GL_TEXTURE_2D, GameTexture[4+PlayerTemp.bSkinSleep].iOpenGLID);
			ASDrawMd2FrameInt(pBlibsEyesModel, PlayerTemp.iAniStep, PlayerTemp.iNextAniStep, (float) (g_lGameTimer-PlayerTemp.dwAniTime)/(float) (PLAYER_ANIMATION_SPEED));
			glCullFace(GL_BACK);
			glDisable(GL_LIGHT2);
			glDisable(GL_LIGHTING);
			glEnable(GL_BLEND);

			// Now draw the blur around the alien:
			glDisable(GL_DEPTH_TEST);
			glEnable(GL_BLEND);
			glBlendFunc(GL_SRC_ALPHA, GL_ONE);
			glBindTexture(GL_TEXTURE_2D, BlurTexture.iOpenGLID);
			glMatrixMode(GL_PROJECTION);
			glPushMatrix();
			glLoadIdentity();
			glOrtho(0, _ASConfig->iWindowWidth, _ASConfig->iWindowHeight, 0, -1, 1);
			glMatrixMode(GL_MODELVIEW);
			glPushMatrix();
			glLoadIdentity();		

			float fInc = 0.015f, fSpost = 0.0f, fAlphainc = 0.8f/15, fAlpha = 0.3f;
			glBegin(GL_QUADS);
				for(i = 0; i < 15; i++)
				{
					glColor4f(1.0f, 1.0f, 1.0f, fAlpha*fCreditsAlienBlend*0.8f);
					glTexCoord2f(0.0f+fSpost, 1.0f-fSpost);
					glVertex2f(0.0f, 0.0f);
					glTexCoord2f(0.0f+fSpost, 0.0f+fSpost);
					glVertex2f(0.0f, (float) _ASConfig->iWindowHeight);
					glTexCoord2f(1.0f-fSpost, 0.0f+fSpost);
					glVertex2f((float) _ASConfig->iWindowWidth, (float) _ASConfig->iWindowHeight);
					glTexCoord2f(1.0f-fSpost, 1.0f-fSpost);
					glVertex2f((float) _ASConfig->iWindowWidth, 0.0f);
					_AS->iTriangles += 2;
					fSpost += fInc;
					fAlpha -= fAlphainc;
				}
			glEnd();

			glMatrixMode(GL_MODELVIEW);
			glLoadIdentity();
			glViewport(0, 0, _ASConfig->iWindowWidth, _ASConfig->iWindowHeight);
			glMatrixMode(GL_PROJECTION);
			glLoadIdentity();
			gluPerspective(45.f, (GLfloat)_ASConfig->iWindowWidth/(GLfloat)_ASConfig->iWindowHeight, 0.1f, 1000.0f);
			glMatrixMode(GL_MODELVIEW);
			glDisable(GL_DEPTH_TEST);
			glLoadIdentity();
		}	
		
		// Animate the alien:
		PlayerTemp.SetAction(AA_WALKING);
		PlayerTemp.iNextAniStep = PlayerTemp.iAniStep+1;
		if(PlayerTemp.iNextAniStep >= pBlibsModel->Ani.anim[PlayerTemp.byAnimation].lastFrame)
			PlayerTemp.iNextAniStep = pBlibsModel->Ani.anim[PlayerTemp.byAnimation].firstFrame;
		if(ASCheckTimeUpdate(&PlayerTemp.dwAniTime, PLAYER_ANIMATION_SPEED))
		{
			PlayerTemp.iAniStep++;
			if(PlayerTemp.iAniStep >= pBlibsModel->Ani.anim[PlayerTemp.byAnimation].lastFrame)
				PlayerTemp.iAniStep = pBlibsModel->Ani.anim[PlayerTemp.byAnimation].firstFrame;
		}

		glColor4f(1.0f, 1.0f, 1.0f, fCreditsBlend);
		for(i = 0; i < 4; i++)
			for(i2 = 0; i2 < 2; i2++)
				fBackAni[i][i2] = -fFontAni[i][i2]*0.5f;
		for(i = 0, iY = iCreditsTextY; i < iASCreditsTexts; i++, iY -= 25)
		{
			if(pbyASCreditsText[i][0] == '[' &&
			   pbyASCreditsText[i][1] == '-' &&
			   pbyASCreditsText[i][2] == 't')
			{
				sprintf(byTemp, pbyASCreditsText[i]+3);
				byTemp[strlen(byTemp)-1] = '\0';
				glMatrixMode(GL_PROJECTION);
				glPushMatrix();
				glLoadIdentity();
				glEnable(GL_BLEND);
				glOrtho(0, 640, 0, 480, -100, 100);
				glMatrixMode(GL_MODELVIEW);
				glPushMatrix();
				glLoadIdentity();
				glTranslated(220, iY-50, 0);
				glBindTexture(GL_TEXTURE_2D, CreditsTexture[atoi(byTemp)].iOpenGLID);
				if(CreditsTexture[atoi(byTemp)].iFormat == GL_RGBA)
				{
					glEnable(GL_ALPHA_TEST);
					glAlphaFunc(GL_GEQUAL, 0.5);
					glDisable(GL_BLEND);
				}
				glBegin(GL_QUADS);
					glTexCoord2f(0.0f, 1.0f); glVertex2f(-70.0f, -70.0f);
					glTexCoord2f(1.0f, 1.0f); glVertex2f(70.0f, -70.0f);
					glTexCoord2f(1.0f, 0.0f); glVertex2f(70.0f, 70.0f);
					glTexCoord2f(0.0f, 0.0f); glVertex2f(-70.0f, 70.0f);
				glEnd();
				glMatrixMode(GL_PROJECTION);
				glPopMatrix();
				glMatrixMode(GL_MODELVIEW);
				glPopMatrix();
				glColor4f(1.0f, 1.0f, 1.0f, fCreditsBlend);
				glDisable(GL_ALPHA_TEST);
				glEnable(GL_BLEND);

				iY -= 120;
			}
			else
				pWindow->PrintAnimated(220, iY, pbyASCreditsText[i], 0, 1.4f, fBackAni, 1);
		}
		iWholeCreditsTextY = iY-iCreditsTextY;	
	}
	if(bGetPlayerName && bPressNewKeyText)
	{
		glEnable(GL_TEXTURE_2D);
		glColor3f(1.0f, 1.0f, 1.0f);	
		pWindow->Print(320, 5, AS_T(T_EnterName), 0, 1);
	}

	ASSwapBuffers(*pWindow->GethDC(), pWindow, TRUE);
	return 0;
} // end GameMenuMenu()

void DrawMenuBackground(float fX, float fY, float fSize, float fZ,
						float fLeft, float fTop, float fRight, float fBottom,
						FLOAT3 fColor, float fDensity)
{ // begin DrawMenuBackground()
	glDisable(GL_CULL_FACE);
	glColor4f(fColor[R], fColor[G], fColor[B], fDensity);
	glBegin(GL_QUADS);
		glTexCoord2f(fX, fY); glVertex3f(fLeft, fTop, fZ);
		glTexCoord2f(fX+fSize, fY); glVertex3f(fRight, fTop, fZ);
		glTexCoord2f(fX+fSize, fY+fSize); glVertex3f(fRight, fBottom, fZ);
		glTexCoord2f(fX, fY+fSize); glVertex3f(fLeft, fBottom, fZ);
	glEnd();
	_AS->iTriangles += 2;

	// Create a smooth bounding:
	glBegin(GL_QUADS);
		// Left:
		glColor4f(fColor[R], fColor[G], fColor[B], fDensity);
		glVertex3d(fRight, fBottom, fZ);
		glVertex3d(fRight, fTop, fZ);
		glColor4f(fColor[R], fColor[G], fColor[B], 1.0f);
		glVertex3d(fRight+0.5f, fTop-0.5f, fZ+1.0f);
		glVertex3d(fRight+0.5f, fBottom+0.5f, fZ+1.0f);

		// Top:
		glColor4f(fColor[R], fColor[G], fColor[B], 1.0f);
		glVertex3d(fLeft-0.5f, fBottom+0.5f, fZ+1.0f);
		glColor4f(fColor[R], fColor[G], fColor[B], fDensity);
		glVertex3d(fLeft, fBottom, fZ);
		glVertex3d(fRight, fBottom, fZ);
		glColor4f(fColor[R], fColor[G], fColor[B], 1.0f);
		glVertex3d(fRight+0.5f, fBottom+0.5f, fZ+1.0f);

		// Right:
		glColor4f(fColor[R], fColor[G], fColor[B], 1.0f);
		glVertex3d(fLeft-0.5f, fTop-0.5f, fZ+1.0f);
		glVertex3d(fLeft-0.5f, fBottom+0.5f, fZ+1.0f);
		glColor4f(fColor[R], fColor[G], fColor[B], fDensity);
		glVertex3d(fLeft, fBottom, fZ);
		glVertex3d(fLeft, fTop, fZ);

		// Bottom:
		glColor4f(fColor[R], fColor[G], fColor[B], 1.0f);
		glVertex3d(fLeft-0.5f, fTop-0.5f, fZ+1.0f);
		glColor4f(fColor[R], fColor[G], fColor[B], fDensity);
		glVertex3d(fLeft, fTop, fZ);
		glVertex3d(fRight, fTop, fZ);
		glColor4f(fColor[R], fColor[G], fColor[B], 1.0f);
		glVertex3d(fRight+0.5f, fTop-0.5f, fZ+1.0f);
	glEnd();
	_AS->iTriangles += 8;
	glEnable(GL_CULL_FACE);
} // end DrawMenuBackground()

void ShowLoadSaveMenu(AS_WINDOW *pWindow)
{ // begin ShowLoadSaveMenu()
	int iMenuBlendMove, i, iY, i2;
	float fBlend;
	char byTemp[256];

	glEnable(GL_TEXTURE_2D);
	if((fLoadMenuBlend || fSaveMenuBlend) &&
	    iPlayerSaveGamesList && byGameMenuSelected < iPlayerSaveGamesList)
	{
		if(fLoadMenuBlend && fSaveMenuBlend)
			fBlend = fLoadMenuBlend*fSaveMenuBlend;
		else
		if(fLoadMenuBlend)
			fBlend = fLoadMenuBlend;
		else
		if(fSaveMenuBlend)
			fBlend = fSaveMenuBlend;

		// Draw save game screenshot:
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);
		glLoadIdentity();
		glBindTexture(GL_TEXTURE_2D, PlayerSaveGame.Screenshot.iOpenGLID);
		glTranslatef(0.0f, -12.5f, -24.0f*fGameMenuBlend-10.0f);
		if(fBlend == 1.0f)
		{
			glDisable(GL_BLEND);
			glColor3f(1.0f, 1.0f, 1.0f);
		}
		else
		{
			glColor4f(1.0f, 1.0f, 1.0f, fBlend);
			glEnable(GL_BLEND);
		}
		glDisable(GL_CULL_FACE);
		glBegin(GL_QUADS);
			glTexCoord2f(0.0f, 1.0f); glVertex3f(-4.0f, 3.0f, 10.0f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f(4.0f, 3.0f, 10.0f);
			glTexCoord2f(1.0f, 0.0f); glVertex3f(4.0f, 9.0f, 10.0f);
			glTexCoord2f(0.0f, 0.0f); glVertex3f(-4.0f, 9.0f, 10.0f);
		glEnd();
		glEnable(GL_CULL_FACE);
		_AS->iTriangles += 2;

		// Show save game save time:
		glEnable(GL_BLEND);
		glColor4f(1.0f, 1.0f, 1.0f, fBlend);
		pWindow->PrintAnimated(320, 160, PlayerSaveGame.bySaveTime, 0, 1.2f*fGameMenuBlend, fFontAni, 1);
	}
	if(fLoadMenuBlend)
	{ // Load menu:
		iMenuBlendMove = (int) ((1.0f-fLoadMenuBlend)*500.0f);
		glColor4f(1.0f, 1.0f, 1.0f, fLoadMenuBlend);
		pWindow->PrintAnimated(320-iMenuBlendMove, 430, AS_T(T_Load), 0, 2.0f*fGameMenuBlend, fFontAni, 1);
		for(i = byGameMenuSelected-5, i2 = 0, iY = 400; i2 < 10; i++)
		{
			if(i < 0)
				continue;
			i2++;
			if(i >= iPlayerSaveGamesList)
			{
				iY -= 10;
				if(i == byGameMenuSelected)
				{
					glColor4f(1.0f, 0.0f, 0.0f, fLoadMenuBlend);
					pWindow->PrintAnimated(320-iMenuBlendMove, iY, AS_T(T_BackReturn), 0, 1.0f*fGameMenuBlend*fSelectedSize, fFontAni, 1);
				}
				else
					pWindow->PrintAnimated(320-iMenuBlendMove, iY, AS_T(T_BackReturn), 0, 1.0f*fGameMenuBlend, fFontAni, 1);
				break;
			}
			if(i == byGameMenuSelected)
			{
				glColor4f(1.0f, 0.0f, 0.0f, fLoadMenuBlend);
				pWindow->PrintAnimated(10-iMenuBlendMove, iY, pbyPlayerSaveGamesList[i], 0, 1.0f*fGameMenuBlend*fSelectedSize, fFontAni, 0);
			}
			else
				pWindow->PrintAnimated(10-iMenuBlendMove, iY, pbyPlayerSaveGamesList[i], 0, 1.0f*fGameMenuBlend, fFontAni, 0);
			glColor4f(1.0f, 1.0f, 1.0f, fLoadMenuBlend);
			iY -= 20;
		}
	}
	if(fSaveMenuBlend)
	{ // Save menu:
		iMenuBlendMove = (int) ((1.0f-fSaveMenuBlend)*500.0f);
		glColor4f(1.0f, 1.0f, 1.0f, fSaveMenuBlend);
		pWindow->PrintAnimated(320-iMenuBlendMove, 430, AS_T(T_Save), 0, 2.0f*fGameMenuBlend, fFontAni, 1);
		for(i = byGameMenuSelected-5, i2 = 0, iY = 400; i2 < 10; i++)
		{
			if(i < 0)
				continue;
			i2++;
			if(i >= iPlayerSaveGamesList)
			{
				iY -= 10;
				if(i == iPlayerSaveGamesList)
				{ // Create a new player ID:
					iY -= 10;
					if(i == byGameMenuSelected)
					{
						glColor4f(1.0f, 0.0f, 0.0f, fSaveMenuBlend);
						if(!bGetPlayerName)
							pWindow->PrintAnimated(320-iMenuBlendMove, iY, AS_T(T_CreateANewSaveGame), 0, 1.0f*fGameMenuBlend*fSelectedSize, fFontAni, 1);
						else
						{ // The player gives in the name:
							if(!bCursorVisible)
								sprintf(byTemp, "%s", byGetPlayerName);
							else
								sprintf(byTemp, "%s_", byGetPlayerName);
							pWindow->PrintAnimated(10-iMenuBlendMove, iY, byTemp, 0, 1.0f*fGameMenuBlend, fFontAni, 0);
						}
					}
					else
					{
						if(!bGetPlayerName)
							pWindow->PrintAnimated(320-iMenuBlendMove, iY, AS_T(T_CreateANewSaveGame), 0, 1.0f*fGameMenuBlend, fFontAni, 1);
						else
						{ // The player gives in the name:
							if(!bCursorVisible)
								sprintf(byTemp, "%s", byGetPlayerName);
							else
								sprintf(byTemp, "%s_", byGetPlayerName);
							pWindow->PrintAnimated(10-iMenuBlendMove, iY, byTemp, 0, 1.0f*fGameMenuBlend, fFontAni, 0);
						}
					}
					iY -= 20;
				}
				else
				{
					if(i == byGameMenuSelected)
					{
						glColor4f(1.0f, 0.0f, 0.0f, fSaveMenuBlend);
						pWindow->PrintAnimated(320-iMenuBlendMove, iY, AS_T(T_BackReturn), 0, 1.0f*fGameMenuBlend*fSelectedSize, fFontAni, 1);
					}
					else
					{
						glColor4f(1.0f, 1.0f, 1.0f, fSaveMenuBlend);
						pWindow->PrintAnimated(320-iMenuBlendMove, iY, AS_T(T_BackReturn), 0, 1.0f*fGameMenuBlend, fFontAni, 1);
					}
					break;
				}
				continue;
			}
			if(i == byGameMenuSelected)
			{
				glColor4f(1.0f, 0.0f, 0.0f, fSaveMenuBlend);
				pWindow->PrintAnimated(10-iMenuBlendMove, iY, pbyPlayerSaveGamesList[i], 0, 1.0f*fGameMenuBlend*fSelectedSize, fFontAni, 0);
			}
			else
				pWindow->PrintAnimated(10-iMenuBlendMove, iY, pbyPlayerSaveGamesList[i], 0, 1.0f*fGameMenuBlend, fFontAni, 0);
			glColor4f(1.0f, 1.0f, 1.0f, fSaveMenuBlend);
			iY -= 20;
		}
	}
} // end ShowLoadSaveMenu()

void ShowOptionMenu(AS_WINDOW *pWindow)
{ // begin ShowOptionMenu()
	int iMenuBlendMove;
	
	if(fOptionsBlend)
	{ // Options:
		iMenuBlendMove = (int) ((1.0f-fOptionsBlend)*500.0f);
		glColor4f(1.0f, 1.0f, 1.0f, fOptionsBlend);
		pWindow->PrintAnimated(320-iMenuBlendMove, 240, AS_T(T_Options), 0, 1.5f*fGameMenuBlend, fFontAni, 1);
		// Set keys:
		SetMenuPointColor(pMP_Options_KeysSetup, fOptionsBlend, -1);
		pWindow->PrintAnimated(320-iMenuBlendMove, 210, AS_T(T_KeysSetup), 0, 1.0f*fGameMenuBlend*pMP_Options_KeysSetup->fSize, fFontAni, 1);
		// Other Options:
		SetMenuPointColor(pMP_Options_OtherOptions, fOptionsBlend, -1);
		pWindow->PrintAnimated(320-iMenuBlendMove, 195, AS_T(T_OtherOptions), 0, 1.0f*fGameMenuBlend*pMP_Options_OtherOptions->fSize, fFontAni, 1);
		// Back:
		SetMenuPointColor(pMP_Options_Back, fOptionsBlend, -1);
		pWindow->PrintAnimated(320-iMenuBlendMove, 180, AS_T(T_BackReturn), 0, 1.0f*fGameMenuBlend*pMP_Options_Back->fSize, fFontAni, 1);
	}
	if(fKeysSetupBlend)
	{ // Keys setup:
		iMenuBlendMove = (int) ((1.0f-fKeysSetupBlend)*500.0f);
		glColor4f(1.0f, 1.0f, 1.0f, fKeysSetupBlend);
		pWindow->PrintAnimated(320-iMenuBlendMove, 340, AS_T(T_KeysSetup), 0, 1.5f*fGameMenuBlend, fFontAni, 1);
		// Left:
		SetMenuPointColor(pMP_KeysSetup_Left, fKeysSetupBlend, _ASConfig->iLeftKey[0]);
		pWindow->PrintAnimated(100-iMenuBlendMove, 307, AS_T(T_Left), 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_Left->fSize, fFontAni, 0);
		pWindow->PrintAnimated(380-iMenuBlendMove, 307, AS_DXInputKeys[_ASConfig->iLeftKey[1]].byName, 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_Left->fSize, fFontAni, 0);
		// Right:
		SetMenuPointColor(pMP_KeysSetup_Right, fKeysSetupBlend, _ASConfig->iRightKey[0]);
		pWindow->PrintAnimated(100-iMenuBlendMove, 294, AS_T(T_Right), 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_Right->fSize, fFontAni, 0);
		pWindow->PrintAnimated(380-iMenuBlendMove, 294, AS_DXInputKeys[_ASConfig->iRightKey[1]].byName, 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_Right->fSize, fFontAni, 0);
		// Up:
		SetMenuPointColor(pMP_KeysSetup_Up, fKeysSetupBlend, _ASConfig->iUpKey[0]);
		pWindow->PrintAnimated(100-iMenuBlendMove, 281, AS_T(T_Up), 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_Up->fSize, fFontAni, 0);
		pWindow->PrintAnimated(380-iMenuBlendMove, 281, AS_DXInputKeys[_ASConfig->iUpKey[1]].byName, 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_Up->fSize, fFontAni, 0);
		// Down:
		SetMenuPointColor(pMP_KeysSetup_Down, fKeysSetupBlend, _ASConfig->iDownKey[0]);
		pWindow->PrintAnimated(100-iMenuBlendMove, 268, AS_T(T_Down), 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_Down->fSize, fFontAni, 0);
		pWindow->PrintAnimated(380-iMenuBlendMove, 268, AS_DXInputKeys[_ASConfig->iDownKey[1]].byName, 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_Down->fSize, fFontAni, 0);
		// Shot:
		SetMenuPointColor(pMP_KeysSetup_Shot, fKeysSetupBlend, _ASConfig->iShotKey[0]);
		pWindow->PrintAnimated(100-iMenuBlendMove, 255, AS_T(T_Shot), 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_Shot->fSize, fFontAni, 0);
		pWindow->PrintAnimated(380-iMenuBlendMove, 255, AS_DXInputKeys[_ASConfig->iShotKey[1]].byName, 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_Shot->fSize, fFontAni, 0);
		// Kick:
		SetMenuPointColor(pMP_KeysSetup_Kick, fKeysSetupBlend, _ASConfig->iKickKey[0]);
		pWindow->PrintAnimated(100-iMenuBlendMove, 242, AS_T(T_Kick), 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_Kick->fSize, fFontAni, 0);
		pWindow->PrintAnimated(380-iMenuBlendMove, 242, AS_DXInputKeys[_ASConfig->iKickKey[1]].byName, 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_Kick->fSize, fFontAni, 0);
		// Action:
		SetMenuPointColor(pMP_KeysSetup_Action, fKeysSetupBlend, _ASConfig->iActionKey[0]);
		pWindow->PrintAnimated(100-iMenuBlendMove, 229, AS_T(T_Action), 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_Action->fSize, fFontAni, 0);
		pWindow->PrintAnimated(380-iMenuBlendMove, 229, AS_DXInputKeys[_ASConfig->iActionKey[1]].byName, 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_Action->fSize, fFontAni, 0);
		// Pull:
		SetMenuPointColor(pMP_KeysSetup_Pull, fKeysSetupBlend, _ASConfig->iPullKey[0]);
		pWindow->PrintAnimated(100-iMenuBlendMove, 216, AS_T(T_Pull), 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_Pull->fSize, fFontAni, 0);
		pWindow->PrintAnimated(380-iMenuBlendMove, 216, AS_DXInputKeys[_ASConfig->iPullKey[1]].byName, 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_Pull->fSize, fFontAni, 0);
		// Suicide:
		SetMenuPointColor(pMP_KeysSetup_Suicide, fKeysSetupBlend, _ASConfig->iSuicideKey[0]);
		pWindow->PrintAnimated(100-iMenuBlendMove, 203, AS_T(T_Suicide), 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_Suicide->fSize, fFontAni, 0);
		pWindow->PrintAnimated(380-iMenuBlendMove, 203, AS_DXInputKeys[_ASConfig->iSuicideKey[1]].byName, 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_Suicide->fSize, fFontAni, 0);
		// Jump:
		SetMenuPointColor(pMP_KeysSetup_Jump, fKeysSetupBlend, _ASConfig->iJumpKey[0]);
		pWindow->PrintAnimated(100-iMenuBlendMove, 190, AS_T(T_Jump), 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_Jump->fSize, fFontAni, 0);
		pWindow->PrintAnimated(380-iMenuBlendMove, 190, AS_DXInputKeys[_ASConfig->iJumpKey[1]].byName, 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_Jump->fSize, fFontAni, 0);
		// Change perspective:
		SetMenuPointColor(pMP_KeysSetup_ChangePerspective, fKeysSetupBlend, _ASConfig->iChangePerspectiveKey[0]);
		pWindow->PrintAnimated(100-iMenuBlendMove, 177, AS_T(T_ChangePerspective), 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_ChangePerspective->fSize, fFontAni, 0);
		pWindow->PrintAnimated(380-iMenuBlendMove, 177, AS_DXInputKeys[_ASConfig->iChangePerspectiveKey[1]].byName, 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_ChangePerspective->fSize, fFontAni, 0);
		// Standart view:
		SetMenuPointColor(pMP_KeysSetup_StandartView, fKeysSetupBlend, _ASConfig->iStandartViewKey[0]);
		pWindow->PrintAnimated(100-iMenuBlendMove, 164, AS_T(T_StandartView), 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_StandartView->fSize, fFontAni, 0);
		pWindow->PrintAnimated(380-iMenuBlendMove, 164, AS_DXInputKeys[_ASConfig->iStandartViewKey[1]].byName, 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_StandartView->fSize, fFontAni, 0);
		// Pause:
		SetMenuPointColor(pMP_KeysSetup_Pause, fKeysSetupBlend, _ASConfig->iPauseKey[0]);
		pWindow->PrintAnimated(100-iMenuBlendMove, 151, AS_T(T_Pause), 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_Pause->fSize, fFontAni, 0);
		pWindow->PrintAnimated(380-iMenuBlendMove, 151, AS_DXInputKeys[_ASConfig->iPauseKey[1]].byName, 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_Pause->fSize, fFontAni, 0);
		// Quick load:
		SetMenuPointColor(pMP_KeysSetup_QuickLoad, fKeysSetupBlend, _ASConfig->iQuickLoadKey[0]);
		pWindow->PrintAnimated(100-iMenuBlendMove, 138, AS_T(T_QuickLoad), 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_QuickLoad->fSize, fFontAni, 0);
		pWindow->PrintAnimated(380-iMenuBlendMove, 138, AS_DXInputKeys[_ASConfig->iQuickLoadKey[1]].byName, 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_QuickLoad->fSize, fFontAni, 0);
		// Quick save:
		SetMenuPointColor(pMP_KeysSetup_QuickSave, fKeysSetupBlend, _ASConfig->iQuickSaveKey[0]);
		pWindow->PrintAnimated(100-iMenuBlendMove, 125, AS_T(T_QuickSave), 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_QuickSave->fSize, fFontAni, 0);
		pWindow->PrintAnimated(380-iMenuBlendMove, 125, AS_DXInputKeys[_ASConfig->iQuickSaveKey[1]].byName, 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_QuickSave->fSize, fFontAni, 0);
		// Level restart:
		SetMenuPointColor(pMP_KeysSetup_LevelRestart, fKeysSetupBlend, _ASConfig->iLevelRestartKey[0]);
		pWindow->PrintAnimated(100-iMenuBlendMove, 112, AS_T(T_LevelRestart), 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_LevelRestart->fSize, fFontAni, 0);
		pWindow->PrintAnimated(380-iMenuBlendMove, 112, AS_DXInputKeys[_ASConfig->iLevelRestartKey[1]].byName, 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_LevelRestart->fSize, fFontAni, 0);
		// Show level missions:
		SetMenuPointColor(pMP_KeysSetup_ShowLevelMissions, fKeysSetupBlend, _ASConfig->iShowLevelMissionsKey[0]);
		pWindow->PrintAnimated(100-iMenuBlendMove, 99, AS_T(T_ShowLevelMissions), 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_ShowLevelMissions->fSize, fFontAni, 0);
		pWindow->PrintAnimated(380-iMenuBlendMove, 99, AS_DXInputKeys[_ASConfig->iShowLevelMissionsKey[1]].byName, 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_ShowLevelMissions->fSize, fFontAni, 0);
		// Standart configuration:
		SetMenuPointColor(pMP_KeysSetup_StandartConfiguration, fKeysSetupBlend, -1);
		pWindow->PrintAnimated(320-iMenuBlendMove, 61, AS_T(T_StandartConfiguration), 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_StandartConfiguration->fSize, fFontAni, 1);
		// Back:
		SetMenuPointColor(pMP_KeysSetup_Back, fKeysSetupBlend, -1);
		pWindow->PrintAnimated(320-iMenuBlendMove, 46, AS_T(T_BackReturn), 0, 1.0f*fGameMenuBlend*pMP_KeysSetup_Back->fSize, fFontAni, 1);
		if(bGetNewKey && bPressNewKeyText)
		{
			glColor4f(1.0f, 1.0f, 1.0f, fKeysSetupBlend);
			pWindow->Print(320, 5, AS_T(T_PressNewKey), 0, 1);
		}
	}
	if(fAreYouSureBlend)
	{ // Are you sure question:
		iMenuBlendMove = (int) ((1.0f-fAreYouSureBlend)*500.0f);
		glColor4f(1.0f, 1.0f, 1.0f, fAreYouSureBlend);
		pWindow->PrintAnimated(320-iMenuBlendMove, 230, AS_M(M_AreYouSure), 0, 1.5f*fGameMenuBlend, fFontAni, 1);
		SetMenuPointColor(pMP_AreYouSure_Yes, fAreYouSureBlend, -1);
		pWindow->PrintAnimated(320-iMenuBlendMove, 200, AS_T(T_Yes), 0, 1.0f*fGameMenuBlend*pMP_AreYouSure_Yes->fSize, fFontAni, 1);
		SetMenuPointColor(pMP_AreYouSure_No, fAreYouSureBlend, -1);
		pWindow->PrintAnimated(320-iMenuBlendMove, 185, AS_T(T_No), 0, 1.0f*fGameMenuBlend*pMP_AreYouSure_No->fSize, fFontAni, 1);
	}
} // end ShowOptionMenu()

HRESULT GameMenuCheck(AS_WINDOW *pWindow)
{ // begin GameMenuCheck()
	char byTemp[256], byTemp2[256];
	float fDelta;
	USHORT iKey;
	int i;
	
	_AS->ReadDXInput(*pWindow->GethWnd());
	
	CheckDebugKeys();
	if(bShowCredits)
	{
		if(ASKeyFirst[DIK_ESCAPE])
		{
			ASKeyFirst[DIK_ESCAPE] = FALSE;
			ASPlayFmodSample(pChangeSample, FSOUND_LOOP_OFF);
			ShowMainMenu();
		}
	}
	else
	{
		for(i = 0; i < 256; i++)
		{
			if(i == AS_SCREENSHOT_KEY)
				continue;
			if(ASKeyFirst[i])
			{
				if(bMenuChange)
					ASKeyFirst[i] = FALSE;
				ShowMainMenu();
			}
		}
	}

	CheckMenuPoints();
	// Game menu blend:
	if(!bShowLogos && fGameMenuBlend < 1.0f && !bShowCredits && !fCreditsAlienBlend && !bMenuChange)
	{
		fGameMenuBlend += (float) g_lDeltatime/2000;
		if(fGameMenuBlend > 1.0f)
			fGameMenuBlend = 1.0f;
	}
	if(ASCheckTimeUpdate(&dwMainMenuStartTime, 40000) && !bMenuChange && !bShowCredits && !fCreditsAlienBlend)
	{ // Blend out the main menu and show the logos:
		fGameMenuBlend -= (float) g_lDeltatime/1000;
		if(fGameMenuBlend < 0.0f)
		{
			bShowLogosAfterCredits = TRUE;
			ShowCredits();
		}
	}
	if(bMenuChange || bShowCredits)
	{ // Game menu blend:
		fGameMenuBlend -= (float) g_lDeltatime/5000;
		if(fGameMenuBlend < 0.0f)
			fGameMenuBlend = 0.0f;
	}

	PlayerTemp.AnimateBlibsEyes();

	// Galaxy movement:
	CheckTitel();
	fGalaxyIn += (float) g_lDeltatime/10000;
	if(fGalaxyIn >= 1.0f)
		fGalaxyIn = 1.0f;

	// Credits blend:
	if(bShowCredits && fCreditsBlend <= 1.0f)
	{
		fCreditsBlend += (float) g_lDeltatime/5000;
		if(fCreditsBlend >= 1.0f)
		{
			fCreditsBlend = 1.0f;
			fCreditsAlienBlend += (float) g_lDeltatime/5000;
			if(fCreditsAlienBlend >= 1.0f)
				fCreditsAlienBlend = 1.0f;
		}
	}
	else
	{
		if(!bShowCredits)
		{
			if(fCreditsAlienBlend)
			{
				fCreditsAlienBlend -= (float) g_lDeltatime/1000;
				if(fCreditsAlienBlend < 0.0f)
					fCreditsAlienBlend = 0.0f;
			}
			else
				if(fCreditsBlend > 0.0f)
				{
					fCreditsBlend -= (float) g_lDeltatime/2000;
					if(fCreditsBlend < 0.0f)
						fCreditsBlend = 0.0f;
				}
		}
	}
	if(fCreditsBlend != 0.0f)
	{
		if(fCreditsBackgroundBlend < 1.0f && fCreditsBackgroundTimer < 1.0f)
		{
			fCreditsBackgroundBlend += (float) g_lDeltatime/1000;
			if(fCreditsBackgroundBlend > 1.0f)
				fCreditsBackgroundBlend = 1.0f;
		}
		else
		{
			fCreditsBackgroundTimer += (float) g_lDeltatime/20000;
			if(fCreditsBackgroundTimer >= 1.0f)
			{ // Show the next credits background picture:
				fCreditsBackgroundBlend -= (float) g_lDeltatime/1000;
				if(fCreditsBackgroundBlend <= 0.0f)
				{
					fCreditsBackgroundTimer = fCreditsBackgroundBlend = 0.0f;
					iCreditsBackground++;
					if(iCreditsBackground > 2)
						iCreditsBackground = 0;
				}
			}
		}
		if(ASCheckTimeUpdate(&lCreditsTextTimer, 20))
			iCreditsTextY++;
	}

// Keys:
	if(ASKeyFirst[DIK_F1])
	{ // Open the help file:
		OpenHelp();
		return 0;
	}
	if(ASKeyFirst[DIK_F12])
	{ // Open the configuration menu:
		SendMessage(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), WM_COMMAND, ID_OPTIONS_CONFIG, 0);
	}

	AnimateFont();

	// Check the main blending:
	fMainOptionsBlend -= (float) g_lDeltatime/1000;
	if(fMainOptionsBlend < 0.0f)
		fMainOptionsBlend = 0.0f;
	fSelectSingeLevelBlend -= (float) g_lDeltatime/1000;
	if(fSelectSingeLevelBlend < 0.0f)
		fSelectSingeLevelBlend = 0.0f;
	fSelectCampaignBlend -= (float) g_lDeltatime/1000;
	if(fSelectCampaignBlend < 0.0f)
		fSelectCampaignBlend = 0.0f;
	fSelectPlayerIDBlend -= (float) g_lDeltatime/1000;
	if(fSelectPlayerIDBlend < 0.0f)
		fSelectPlayerIDBlend = 0.0f;
	fSelectCampaignLevelBlend -= (float) g_lDeltatime/1000;
	if(fSelectCampaignLevelBlend < 0.0f)
		fSelectCampaignLevelBlend = 0.0f;
	fSelectCampaignPlayerIDBlend -= (float) g_lDeltatime/1000;
	if(fSelectCampaignPlayerIDBlend < 0.0f)
		fSelectCampaignPlayerIDBlend = 0.0f;
	fPlayerIDMenuBlend -= (float) g_lDeltatime/1000;
	if(fPlayerIDMenuBlend < 0.0f)
		fPlayerIDMenuBlend = 0.0f;
		
	// The select keys:
	if(!bShowCredits && !fCreditsAlienBlend)
	{
		if(!bGetPlayerName && !bGetNewKey)
		{
			if(ASKeyFirst[DIK_UP])
			{
				byGameMenuSelected--;
				ASPlayFmodSample(pSelectSample, FSOUND_LOOP_OFF);
			}
			if(ASKeyFirst[DIK_DOWN])
			{
				byGameMenuSelected++;
				ASPlayFmodSample(pSelectSample, FSOUND_LOOP_OFF);
			}
		}
		switch(byGameMenuMenu)
		{
			case GM_MAIN_MENU: // Main menu:
				fMainOptionsBlend += (float) g_lDeltatime/500;
				if(fMainOptionsBlend > 1.0f)
					fMainOptionsBlend = 1.0f;
				if(byGameMenuSelected < 0)
					byGameMenuSelected = 7;
				else
					if(byGameMenuSelected >= 8)
						byGameMenuSelected = 0;
				switch(byGameMenuSelected)
				{
					case 0: pMP_MainMenu_StartGame->bSelected = TRUE; break;
					case 1: pMP_MainMenu_ContinueGame->bSelected = TRUE; break;
					case 2: pMP_MainMenu_SingleLevel->bSelected = TRUE; break;
					case 3: pMP_MainMenu_Options->bSelected = TRUE; break;
					case 4: pMP_MainMenu_Editor->bSelected = TRUE; break;
					case 5: pMP_MainMenu_Help->bSelected = TRUE; break;
					case 6: pMP_MainMenu_Credits->bSelected = TRUE; break;
					case 7: pMP_MainMenu_Quit->bSelected = TRUE; break;
				}
				if(ASKeyFirst[DIK_ESCAPE])
				{
					ASKeyFirst[DIK_ESCAPE] = FALSE;
					ASPlayFmodSample(pChangeSample, FSOUND_LOOP_OFF);
					_AS->SetShutDown(TRUE);
				}
				if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
				{ // Check what the player has selected:
					ASKeyFirst[DIK_SPACE] = ASKeyFirst[DIK_RETURN] = FALSE;
					ASPlayFmodSample(pChangeSample, FSOUND_LOOP_OFF);
					switch(byGameMenuSelected)
					{
						case 0: // New game:
							EnumerateCampaigns();
							if(!iCampaignsList)
							{ // There is no campaign!!
								_AS->WriteLogMessage("There is no campaign!");
								ShowSmallMessage(AS_M(M_ThereIsNoCampaign), 3000);
								break;
							}
							byLastGameMenuMenu = byGameMenuMenu;
							byGameMenuMenu = GM_SELECT_CAMPAIGN;
							byGameMenuSelected = 0;
						break;

						case 1: // Continue game:
							EnumeratePlayerIDs();
							if(!iPlayerIDsList)
							{ // There is no player ID!!
								_AS->WriteLogMessage("There is no player ID!");
								ShowSmallMessage(AS_M(M_ThereIsNoPlayerID), 3000);
								break;
							}
							byGameMenuMenu = GM_CONTINUE_GAME;
							byGameMenuSelected = 0;
						break;

						case 2: // Single level:
							EnumerateSingleLevels();
							if(!iSingleLevelsList)
							{ // There is no single level!!
								_AS->WriteLogMessage("There is no single level!");
								ShowSmallMessage(AS_M(M_ThereIsNoSingleLevel), 3000);
								break;
							}
							byGameMenuMenu = GM_SINGLE_LEVEL;
							byGameMenuSelected = 0;
						break;

						case 3: // Options:
							byGameMenuMenu = GM_OPTIONS;
							byGameMenuSelected = 0;
							ASKeyFirst[DIK_SPACE] = ASKeyFirst[DIK_RETURN] = FALSE;
						break;

						case 4: _AS->SetNextModule(MODULE_EDITOR); break; // Editor:
						case 5:  OpenHelp(); break; // Help:
						case 6:	ShowCredits(); break; // Show the credits
						case 7: _AS->SetShutDown(TRUE); break; // Quit
					}
				}
			break;

			case GM_SINGLE_LEVEL: // Select a single level:
				fSelectSingeLevelBlend += (float) g_lDeltatime/500;
				if(fSelectSingeLevelBlend > 1.0f)
					fSelectSingeLevelBlend = 1.0f;
				if(byGameMenuSelected < 0)
					byGameMenuSelected = iSingleLevelsList;
				else
					if(byGameMenuSelected >= iSingleLevelsList+1)
						byGameMenuSelected = 0;
				if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
				{ // Check what the player has selected:
					ASKeyFirst[DIK_SPACE] = ASKeyFirst[DIK_RETURN] = FALSE;
					if(byGameMenuSelected == iSingleLevelsList)
						ASKeyFirst[DIK_ESCAPE] = TRUE;
					else
					{ // Start the selected single level:
						ASPlayFmodSample(pChangeSample, FSOUND_LOOP_OFF);
						bInGameMenu = FALSE;
						bSingleLevel = TRUE;
						CurrentCampaign.iLevels = 1;
						strcpy(bySelectedSingleLevel, pbySingleLevelsList[byGameMenuSelected]);

						// Create a new player identity:
						CreateNewPlayerInfo(&PlayerIdentity, &CurrentCampaign);
						strcpy(PlayerIdentity.byName, AS_T(T_SingleLevel));
						PlayerIdentity.bSingleLevel = TRUE;
						strcpy(PlayerIdentity.bySingleLevelName, bySelectedSingleLevel);
						SavePlayerIdentity(&PlayerIdentity, &CurrentCampaign);
					}
				}
				if(ASKeyFirst[DIK_ESCAPE])
				{
					ASKeyFirst[DIK_ESCAPE] = FALSE;
					ASPlayFmodSample(pChangeSample, FSOUND_LOOP_OFF);
					byGameMenuSelected = 0;
					byGameMenuMenu = GM_MAIN_MENU;
					break;
				}
			break;

			case GM_SELECT_CAMPAIGN: // Select campaign:
				fSelectCampaignBlend += (float) g_lDeltatime/500;
				if(fSelectCampaignBlend > 1.0f)
					fSelectCampaignBlend = 1.0f;
				if(byGameMenuSelected < 0)
					byGameMenuSelected = iCampaignsList;
				else
					if(byGameMenuSelected >= iCampaignsList+1)
						byGameMenuSelected = 0;
				if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
				{ // Check what the player has selected:
					ASKeyFirst[DIK_SPACE] = ASKeyFirst[DIK_RETURN] = FALSE;
					if(byGameMenuSelected == iCampaignsList)
						ASKeyFirst[DIK_ESCAPE] = TRUE;
					else
					{ // Load the campaign:
						ASPlayFmodSample(pChangeSample, FSOUND_LOOP_OFF);
						sprintf(byTemp, "%s%s\\%s\\%s.cam", _AS->byProgramPath, _AS->byCampaignsDirectory, pbyCampaignList[byGameMenuSelected],
															pbyCampaignList[byGameMenuSelected]);
						if(LoadCampaign(&CurrentCampaign, byTemp))
						{
							_AS->WriteLogMessage("Couldn't open %s!", byTemp);
							break;
						}
						// Go sure that there is the right campaign name:
						strcpy(CurrentCampaign.byName, pbyCampaignList[byGameMenuSelected]);
						if(byLastGameMenuMenu == GM_MAIN_MENU)
						{
							byGameMenuMenu = GM_GET_PLAYER_ID;
							EnumeratePlayerIDs();
						}
						else
						{ // Start now the game:
							GameMenuStartCampaignWithOldPlayerID();
						}
						byGameMenuSelected = 0;
						bGetPlayerName = FALSE;
					}
				}
				if(ASKeyFirst[DIK_ESCAPE])
				{
					ASKeyFirst[DIK_ESCAPE] = FALSE;
					ASPlayFmodSample(pChangeSample, FSOUND_LOOP_OFF);
					byGameMenuSelected = 0;
					byGameMenuMenu = byLastGameMenuMenu;
					break;
				}
			break;

			case GM_CONTINUE_GAME: // Select player ID: (for continue game)
				fSelectPlayerIDBlend += (float) g_lDeltatime/500;
				if(fSelectPlayerIDBlend > 1.0f)
					fSelectPlayerIDBlend = 1.0f;
				if(byGameMenuSelected < 0)
					byGameMenuSelected = iPlayerIDsList;
				else
					if(byGameMenuSelected >= iPlayerIDsList+1)
						byGameMenuSelected = 0;
				CheckDeletePlayerID();
				if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
				{ // Check what the player has selected:
					ASKeyFirst[DIK_SPACE] = ASKeyFirst[DIK_RETURN] = FALSE;
					if(byGameMenuSelected == iPlayerIDsList)
						ASKeyFirst[DIK_ESCAPE] = TRUE;
					else
					{ // Load the player ID:
						ASPlayFmodSample(pChangeSample, FSOUND_LOOP_OFF);
						ASKeyFirst[DIK_SPACE] = ASKeyFirst[DIK_RETURN] = FALSE;
						DestroyCampaign(&CurrentCampaign);
						LoadPlayerIdentity(pbyPlayerIDList[byGameMenuSelected], &PlayerIdentity, &CurrentCampaign);
						bSingleLevel = PlayerIdentity.bSingleLevel;
						if(!PlayerIdentity.bSingleLevel)
						{
							sprintf(byTemp, "%s%s\\%s\\%s.cam", _AS->byProgramPath, _AS->byCampaignsDirectory, PlayerIdentity.byCampaignName, PlayerIdentity.byCampaignName);
							if(LoadCampaign(&CurrentCampaign, byTemp))
							{
								_AS->WriteLogMessage("Couldn't open %s!", byTemp);
								break;
							}
						}
						else
							strcpy(bySelectedSingleLevel, PlayerIdentity.bySingleLevelName);
						// Setup now the final player identity:
						LoadPlayerIdentity(pbyPlayerIDList[byGameMenuSelected], &PlayerIdentity, &CurrentCampaign);
						if(!PlayerIdentity.bSingleLevel)
							byGameMenuSelected = 0;
						else
							byGameMenuSelected = 2;
						byGameMenuMenu = GM_PLAYER_ID_MENU;
					}
				}
				if(ASKeyFirst[DIK_ESCAPE])
				{
					ASKeyFirst[DIK_ESCAPE] = FALSE;
					ASPlayFmodSample(pChangeSample, FSOUND_LOOP_OFF);
					byGameMenuSelected = 0;
					byGameMenuMenu = GM_MAIN_MENU;
					break;
				}
			break;

			case GM_SELECT_LEVEL_OF_CAMPAIGN: // Select level of the selected campaign:
				fSelectCampaignLevelBlend += (float) g_lDeltatime/500;
				if(fSelectCampaignLevelBlend > 1.0f)
					fSelectCampaignLevelBlend = 1.0f;
				if(byGameMenuSelected < 0)
					byGameMenuSelected = (char) PlayerIdentity.iFinishedLevels+1;
				else
					if(byGameMenuSelected >= PlayerIdentity.iFinishedLevels+2 ||
					   byGameMenuSelected >= CurrentCampaign.iLevels+1)
						byGameMenuSelected = 0;
				if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
				{ // Check what the player has selected:
					ASKeyFirst[DIK_SPACE] = ASKeyFirst[DIK_RETURN] = FALSE;
					if(byGameMenuSelected == (char) PlayerIdentity.iFinishedLevels+1)
						ASKeyFirst[DIK_ESCAPE] = TRUE;
					else
					{ // Start the selected level:
						ASPlayFmodSample(pChangeSample, FSOUND_LOOP_OFF);
						PlayerIdentity.iSelectedLevel = byGameMenuSelected+1;
						bInGameMenu = FALSE;
						bSingleLevel = FALSE;
					}
				}
				if(ASKeyFirst[DIK_ESCAPE])
				{
					ASKeyFirst[DIK_ESCAPE] = FALSE;
					ASPlayFmodSample(pChangeSample, FSOUND_LOOP_OFF);
					byGameMenuSelected = 0;
					byGameMenuMenu = GM_PLAYER_ID_MENU;
					break;
				}
			break;

			case GM_GET_PLAYER_ID: // Select player ID or create a new one:
				fSelectCampaignPlayerIDBlend += (float) g_lDeltatime/500;
				if(fSelectCampaignPlayerIDBlend > 1.0f)
					fSelectCampaignPlayerIDBlend = 1.0f;
				if(byGameMenuSelected < 0)
					byGameMenuSelected = (char) iPlayerIDsList+1;
				else
					if(byGameMenuSelected >= iPlayerIDsList+2)
						byGameMenuSelected = 0;
				if(bGetPlayerName)
				{
					if(strlen(byGetPlayerName) < PLAYER_NAME_LENGTH-1)
					{
						for(i = 0; i < 256; i++)
						{
							if(i == DIK_BACK || i == DIK_RETURN || i == DIK_ESCAPE)
								continue;
							if(ASKeyFirst[i])
							{
								ASPlayFmodSample(pInputSample, FSOUND_LOOP_OFF);
								ConvertScancodeToASCII(i, &iKey);
								sprintf(byGetPlayerName, "%s%c", byGetPlayerName, iKey);
							}
						}
					}
					if(ASKeyFirst[DIK_BACK] && strlen(byGetPlayerName) > 1)
						byGetPlayerName[strlen(byGetPlayerName)-2] = '\0';
					if(ASKeyFirst[DIK_ESCAPE])
					{
						ASKeyFirst[DIK_ESCAPE] = FALSE;
						ASPlayFmodSample(pChangeSample, FSOUND_LOOP_OFF);
						bGetPlayerName = FALSE;
					}
					if(ASKeyFirst[DIK_RETURN])
					{ // Get the player name:
						ASKeyFirst[DIK_SPACE] = ASKeyFirst[DIK_RETURN] = FALSE;
						bGetPlayerName = FALSE;
						if(byGetPlayerName[0] == '\0')
							strcpy(byGetPlayerName, "Blibs");
						else
							byGetPlayerName[strlen(byGetPlayerName)] = '\0';

						// Check if thats an vailed name:
						strcpy(byTemp, byGetPlayerName);
						_strupr(byTemp);
						for(i = 0; i < 2; i++)
						{
							if(!i)
								strcpy(byTemp2, AS_T(T_SingleLevel));
							else
								strcpy(byTemp2, AS_T(T_EditorLevelTest));
							_strupr(byTemp2);
							if(!strcmp(byTemp, byTemp2))
							{ // Nope!
								ShowSmallMessage(AS_M(M_InvalidName), 3000);
								break;
							}
						}

						// Create a new player identity:
						CreateNewPlayerInfo(&PlayerIdentity, &CurrentCampaign);
						strcpy(PlayerIdentity.byName, byGetPlayerName);
						sprintf(byTemp, "%s%s\\%s\\", _AS->byProgramPath, _AS->byIdentityDirectory, PlayerIdentity.byName);
						ASRemoveDirectory(byTemp);
						SavePlayerIdentity(&PlayerIdentity, &CurrentCampaign);
						EnumeratePlayerIDs();
						for(byGameMenuSelected = 0;; byGameMenuSelected++)
						{
							if(!strcmp(PlayerIdentity.byName, byGetPlayerName))
								break;
						}
						goto StartSelectedCampaign;
					}
				}
				else
				{
					CheckDeletePlayerID();
					if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
					{ // Check what the player has selected:
						ASKeyFirst[DIK_SPACE] = ASKeyFirst[DIK_RETURN] = FALSE;
						if(iPlayerIDsList+1 == byGameMenuSelected)
							ASKeyFirst[DIK_ESCAPE] = TRUE;
						else
						{ // Load the player ID:
							ASPlayFmodSample(pChangeSample, FSOUND_LOOP_OFF);
							if(iPlayerIDsList == byGameMenuSelected)
							{ // Create a new player ID:
								bGetPlayerName = TRUE;
								strcpy(byGetPlayerName, "");
								break;
							}
							else
							{ // Use a old player ID:
								GameMenuStartCampaignWithOldPlayerID();
							}
						StartSelectedCampaign:
							// Start the selected campaign:
							bInGameMenu = FALSE;
							bSingleLevel = FALSE;
						}
					}
					if(ASKeyFirst[DIK_ESCAPE])
					{
						ASKeyFirst[DIK_ESCAPE] = FALSE;
						ASPlayFmodSample(pChangeSample, FSOUND_LOOP_OFF);
						byGameMenuSelected = 0;
						byGameMenuMenu = GM_SELECT_CAMPAIGN;
						bGetPlayerName = FALSE;
						break;
					}
				}
			break;

			case GM_PLAYER_ID_MENU: // Player ID menu:
				fPlayerIDMenuBlend += (float) g_lDeltatime/500;
				if(fPlayerIDMenuBlend > 1.0f)
					fPlayerIDMenuBlend = 1.0f;
				if(!PlayerIdentity.bSingleLevel)
				{
					if(byGameMenuSelected < 0)
						byGameMenuSelected = 3;
					else
						if(byGameMenuSelected >= 4)
							byGameMenuSelected = 0;
				}
				else
				{
					if(byGameMenuSelected < 2)
						byGameMenuSelected = 3;
					else
						if(byGameMenuSelected >= 4)
							byGameMenuSelected = 2;
				}
				switch(byGameMenuSelected)
				{
					case 0: pMP_PlayerIDMenu_StartGame->bSelected = TRUE; break;
					case 1: pMP_PlayerIDMenu_SelectLevel->bSelected = TRUE; break;
					case 2: pMP_PlayerIDMenu_Load->bSelected = TRUE; break;
					case 3: pMP_PlayerIDMenu_Back->bSelected = TRUE; break;
				}
				if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
				{ // Check what the player has selected:
					ASKeyFirst[DIK_SPACE] = ASKeyFirst[DIK_RETURN] = FALSE;
					ASPlayFmodSample(pChangeSample, FSOUND_LOOP_OFF);
					ASKeyFirst[DIK_SPACE] = ASKeyFirst[DIK_RETURN] = FALSE;
					switch(byGameMenuSelected)
					{
						case 0: // New game:
							EnumerateCampaigns();
							if(!iCampaignsList)
							{ // There is no campaign!!
								_AS->WriteLogMessage("There is no campaign!");
								ShowSmallMessage(AS_M(M_ThereIsNoCampaign), 3000);
								break;
							}
							byLastGameMenuMenu = byGameMenuMenu;
							byGameMenuSelected = 0;
							byGameMenuMenu = GM_SELECT_CAMPAIGN;
						break;

						case 1: // Select level:
							byGameMenuSelected = (char) PlayerIdentity.iFinishedLevels;
							if(byGameMenuSelected >= CurrentCampaign.iLevels)
								byGameMenuSelected--;
							byGameMenuMenu = GM_SELECT_LEVEL_OF_CAMPAIGN;
						break;

						case 2: // Load:
							byLastGameMenuMenu = byGameMenuMenu;
							byGameMenuMenu = GM_LOAD_MENU;
							byGameMenuSelected = 0;
							EnumeratePlayerSaveGames();
						break;

						case 3: // Back:
							ASKeyFirst[DIK_ESCAPE] = TRUE;
						break;
					}
				}
				if(ASKeyFirst[DIK_ESCAPE])
				{
					ASKeyFirst[DIK_ESCAPE] = FALSE;
					ASPlayFmodSample(pChangeSample, FSOUND_LOOP_OFF);
					bAreYouSureQuestionAnswer = FALSE;
					byGameMenuSelected = 0;
					byGameMenuMenu = GM_CONTINUE_GAME;
				}
			break;
		}
		CheckLoadSaveMenu();
		CheckOptionMenu();
	}
	else
	{
		if(iCreditsTextY >= -iWholeCreditsTextY+450)
		{
			if(bShowLogosAfterCredits)
			{
				if(fCreditsAlienBlend)
				{
					fCreditsAlienBlend -= (float) g_lDeltatime/500;
					if(fCreditsAlienBlend < 0.0f)
						fCreditsAlienBlend = 0.0f;
				}
				if(fCreditsAlienBlend <= 0.0f)
				{
					fCreditsBlend -= (float) g_lDeltatime/1000;
					if(fCreditsBlend < 0.0f)
					{
						fCreditsBlend = 0.0f;
						ShowLogos();
					}
				}
			}
			else
			{
				dwMainMenuStartTime = g_lGameTimer;
				bShowLogos = FALSE;
				if(bMenuChange || bShowCredits)
				{
					byGameMenuSelected = 0;
					byGameMenuMenu = GM_MAIN_MENU;
					ASKeyFirst[DIK_ESCAPE] = FALSE;
				}
				bMenuChange	= FALSE;
				bShowCredits = FALSE;
				StartMusic("MainMenu.mp3");
				if(fGameMenuBlend < 0.0f)
					fGameMenuBlend = 0.0f;
			}
		}
	}
	
	// Animate the background:
	if(ASCheckTimeUpdate(&lGameMenuBackgroundAniTimer, 70))
	{ // Go to the next animation step:
		iGameMenuBackgroundAniStep++;
		if(iGameMenuBackgroundAniStep >= 32)
			iGameMenuBackgroundAniStep = 0;
	}
	
	// Change the color of the background:
	if(ASCheckTimeUpdate(&lBackFlashTime, lBackFlashTimeDelay))
	{
		lBackFlashTimeDelay = rand() % 500+300;
		fLastBackFlash = fBackFlash;
		fBackFlash = (float) (rand() % 50)/100.0f;
		fBackFlashDelta = fBackFlash-fLastBackFlash;
	}
	fDelta = ((float) (g_lGameTimer-lBackFlashTime+1)/lBackFlashTimeDelay);
	if(fDelta < 0.0f)
		fDelta = -fDelta;
	if(fBackFlash > fLastBackFlash)
		fCurrentBackFlash = (float) fLastBackFlash+fBackFlashDelta*fDelta;
	else
		fCurrentBackFlash = (float) fLastBackFlash+fBackFlashDelta*fDelta;
	return 0;
} // end GameMenuCheck()

void CheckLoadSaveMenu(void)
{ // begin CheckLoadSaveMenu()
	char byTemp[256];
	USHORT iKey;
	int i;

	fLoadMenuBlend -= (float) g_lDeltatime/1000;
	if(fLoadMenuBlend < 0.0f)
		fLoadMenuBlend = 0.0f;
	fSaveMenuBlend -= (float) g_lDeltatime/1000;
	if(fSaveMenuBlend < 0.0f)
		fSaveMenuBlend = 0.0f;
	switch(byGameMenuMenu)
	{
		case GM_LOAD_MENU:
			if(!iPlayerSaveGamesList)
			{ // There are no save games!
				_AS->WriteLogMessage("There is are no save games!");
				ShowSmallMessage(AS_M(M_ThereAreNoSaveGames), 3000);
				byGameMenuSelected = 0;
				byGameMenuMenu = byLastGameMenuMenu;
				break;
			}

			fLoadMenuBlend += (float) g_lDeltatime/500;
			if(fLoadMenuBlend > 1.0f)
				fLoadMenuBlend = 1.0f;
			if(byGameMenuSelected < 0)
				byGameMenuSelected = iPlayerSaveGamesList;
			else
				if(byGameMenuSelected >= iPlayerSaveGamesList+1)
					byGameMenuSelected = 0;
		    if(iPlayerSaveGamesList && byGameMenuSelected < iPlayerSaveGamesList)
			{
				PlayerSaveGame.LoadInfos(pbyPlayerSaveGamesList[byGameMenuSelected], FALSE);
				CheckDeletePlayerSaveGame();
			}
			if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
			{ // Check what the player has selected:
				ASKeyFirst[DIK_SPACE] = ASKeyFirst[DIK_RETURN] = FALSE;
				if(byGameMenuSelected == iPlayerSaveGamesList)
					ASKeyFirst[DIK_ESCAPE] = TRUE;
				else
				{ // Load the save game:
					ASPlayFmodSample(pChangeSample, FSOUND_LOOP_OFF);
					bInGameMenu = FALSE;
					LoadGame(pbyPlayerSaveGamesList[byGameMenuSelected]);
					ASKeyFirst[DIK_ESCAPE] = TRUE;
					bPause = FALSE;
				}
			}
			if(ASKeyFirst[DIK_ESCAPE])
			{
				ASKeyFirst[DIK_ESCAPE] = FALSE;
				ASPlayFmodSample(pChangeSample, FSOUND_LOOP_OFF);
				if(!PlayerIdentity.bSingleLevel)
					byGameMenuSelected = 0;
				else
					byGameMenuSelected = 2;
				byGameMenuMenu = byLastGameMenuMenu;
				break;
			}
		break;

		case GM_SAVE_MENU:
			fSaveMenuBlend += (float) g_lDeltatime/500;
			if(fSaveMenuBlend > 1.0f)
				fSaveMenuBlend = 1.0f;
			if(bGetPlayerName)
			{
				if(strlen(byGetPlayerName) < PLAYER_NAME_LENGTH-1)
				{
					for(i = 0; i < 256; i++)
					{
						if(i == DIK_BACK || i == DIK_RETURN || i == DIK_ESCAPE)
							continue;
						if(ASKeyFirst[i])
						{
							ASPlayFmodSample(pInputSample, FSOUND_LOOP_OFF);
							ConvertScancodeToASCII(i, &iKey);
							sprintf(byGetPlayerName, "%s%c", byGetPlayerName, iKey);
						}
					}
				}
				if(ASKeyFirst[DIK_BACK] && strlen(byGetPlayerName) > 1)
					byGetPlayerName[strlen(byGetPlayerName)-2] = '\0';
				if(ASKeyFirst[DIK_ESCAPE])
					bGetPlayerName = FALSE;
				if(ASKeyFirst[DIK_RETURN])
				{ // Get the player name:
					ASKeyFirst[DIK_SPACE] = ASKeyFirst[DIK_RETURN] = FALSE;
					bGetPlayerName = FALSE;
					if(byGetPlayerName[0] == '\0')
						strcpy(byGetPlayerName, "Blibs");
					else
						byGetPlayerName[strlen(byGetPlayerName)] = '\0';

					// Check if thats an vailed name:
					strcpy(byTemp, byGetPlayerName);
					_strupr(byTemp);
					if(!strcmp(byTemp, "QUICKSAVE"))
					{ // Nope!
						ShowSmallMessage(AS_M(M_InvalidName), 3000);
						break;
					}

					SaveGame(byGetPlayerName);

					ASPlayFmodSample(pChangeSample, FSOUND_LOOP_OFF);
					byGameMenuSelected = 0;
					byGameMenuMenu = byLastGameMenuMenu;
				}
			}
			else
			{
				if(byGameMenuSelected < 0)
					byGameMenuSelected = iPlayerSaveGamesList+1;
				else
					if(byGameMenuSelected >= iPlayerSaveGamesList+2)
						byGameMenuSelected = 0;
				if(iPlayerSaveGamesList && byGameMenuSelected < iPlayerSaveGamesList)
				{
					PlayerSaveGame.LoadInfos(pbyPlayerSaveGamesList[byGameMenuSelected], FALSE);
					CheckDeletePlayerSaveGame();
				}
				if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
				{ // Check what the player has selected:
					ASKeyFirst[DIK_SPACE] = ASKeyFirst[DIK_RETURN] = FALSE;
					if(iPlayerSaveGamesList+1 == byGameMenuSelected)
						ASKeyFirst[DIK_ESCAPE] = TRUE;
					else
					{ // Save the game:
						ASPlayFmodSample(pChangeSample, FSOUND_LOOP_OFF);
						if(iPlayerSaveGamesList == byGameMenuSelected)
						{ // Create a new save game:
							bGetPlayerName = TRUE;
							strcpy(byGetPlayerName, "");
							break;
						}
						else
						{ // Use a old save game:
							SaveGame(pbyPlayerSaveGamesList[byGameMenuSelected]);
							ASKeyFirst[DIK_ESCAPE] = TRUE;
						}
					}
				}
				if(ASKeyFirst[DIK_ESCAPE])
				{
					ASKeyFirst[DIK_ESCAPE] = FALSE;
					ASPlayFmodSample(pChangeSample, FSOUND_LOOP_OFF);
					byGameMenuSelected = 0;
					byGameMenuMenu = byLastGameMenuMenu;
					break;
				}
			}
		break;
	}
} // end CheckLoadSaveMenu()

void CheckOptionMenu(void)
{ // begin CheckOptionMenu()
	int i;

	fOptionsBlend -= (float) g_lDeltatime/1000;
	if(fOptionsBlend < 0.0f)
		fOptionsBlend = 0.0f;
	fKeysSetupBlend -= (float) g_lDeltatime/1000;
	if(fKeysSetupBlend < 0.0f)
		fKeysSetupBlend = 0.0f;
	fAreYouSureBlend -= (float) g_lDeltatime/1000;
	if(fAreYouSureBlend < 0.0f)
		fAreYouSureBlend = 0.0f;
	if(ASCheckTimeUpdate(&lPressNewKeyTimer, 500))
		bPressNewKeyText = !bPressNewKeyText;
	if(g_lNow-lPressNewKeyTimer > 500)
	{
		lPressNewKeyTimer = g_lNow;
		bPressNewKeyText = !bPressNewKeyText;
	}
	// Animate blinking cursor:
	if(g_lNow-dwCursorTime > 700 || g_lNow-dwCursorTime < 0)
	{
		dwCursorTime = g_lNow;
		bCursorVisible = !bCursorVisible;
	}
	switch(byGameMenuMenu)
	{
		case GM_OPTIONS: // Options:
			fOptionsBlend += (float) g_lDeltatime/500;
			if(fOptionsBlend > 1.0f)
				fOptionsBlend = 1.0f;
			if(byGameMenuSelected < 0)
				byGameMenuSelected = 2;
			else
				if(byGameMenuSelected >= 3)
					byGameMenuSelected = 0;
			switch(byGameMenuSelected)
			{
				case 0: pMP_Options_KeysSetup->bSelected = TRUE; break;
				case 1: pMP_Options_OtherOptions->bSelected = TRUE; break;
				case 2: pMP_Options_Back->bSelected = TRUE; break;
			}
			if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
			{ // Check what the player has selected:
				ASKeyFirst[DIK_SPACE] = ASKeyFirst[DIK_RETURN] = FALSE;
				ASPlayFmodSample(pChangeSample, FSOUND_LOOP_OFF);
				switch(byGameMenuSelected)
				{
					case 0: // Setup keys
						byGameMenuSelected = 0;
						byGameMenuMenu = GM_SETUP_KEYS;
						bGetNewKey = FALSE;
					break;

					case 1: // Other options
						SendMessage(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), WM_COMMAND, ID_OPTIONS_CONFIG, 0);
					break;

					case 2: // Back
						ASKeyFirst[DIK_ESCAPE] = TRUE;
					break;
				}
			}
			if(ASKeyFirst[DIK_ESCAPE])
			{
				ASKeyFirst[DIK_ESCAPE] = FALSE;
				ASPlayFmodSample(pChangeSample, FSOUND_LOOP_OFF);
				byGameMenuSelected = 0;
				byGameMenuMenu = GM_MAIN_MENU;
				break;
			}
		break;

		case GM_SETUP_KEYS: // Setup keys:
			fKeysSetupBlend += (float) g_lDeltatime/500;
			if(fKeysSetupBlend > 1.0f)
				fKeysSetupBlend = 1.0f;
			if(byGameMenuSelected < 0)
				byGameMenuSelected = 18;
			else
				if(byGameMenuSelected >= 19)
					byGameMenuSelected = 0;
			switch(byGameMenuSelected)
			{
				case 0: pMP_KeysSetup_Left->bSelected = TRUE; break;
				case 1: pMP_KeysSetup_Right->bSelected = TRUE; break;
				case 2: pMP_KeysSetup_Up->bSelected = TRUE; break;
				case 3: pMP_KeysSetup_Down->bSelected = TRUE; break;
				case 4: pMP_KeysSetup_Shot->bSelected = TRUE; break;
				case 5: pMP_KeysSetup_Kick->bSelected = TRUE; break;
				case 6: pMP_KeysSetup_Action->bSelected = TRUE; break;
				case 7: pMP_KeysSetup_Pull->bSelected = TRUE; break;
				case 8: pMP_KeysSetup_Suicide->bSelected = TRUE; break;
				case 9: pMP_KeysSetup_Jump->bSelected = TRUE; break;
				case 10: pMP_KeysSetup_ChangePerspective->bSelected = TRUE; break;
				case 11: pMP_KeysSetup_StandartView->bSelected = TRUE; break;
				case 12: pMP_KeysSetup_Pause->bSelected = TRUE; break;
				case 13: pMP_KeysSetup_QuickLoad->bSelected = TRUE; break;
				case 14: pMP_KeysSetup_QuickSave->bSelected = TRUE; break;
				case 15: pMP_KeysSetup_LevelRestart->bSelected = TRUE; break;
				case 16: pMP_KeysSetup_ShowLevelMissions->bSelected = TRUE; break;
				case 17: pMP_KeysSetup_StandartConfiguration->bSelected = TRUE; break;
				case 18: pMP_KeysSetup_Back->bSelected = TRUE; break;
			}
			if(bGetNewKey)
			{
				if(ASKeyFirst[DIK_ESCAPE])
				{
					bGetNewKey = FALSE;
					ASKeyFirst[DIK_ESCAPE] = FALSE;
					break;
				}
				for(i = 0; i < 256; i++)
				{
					if(!ASKeyFirst[i])
						continue;
					// Set the new key:
					switch(byGameMenuSelected)
					{
						case 0: _ASConfig->iLeftKey[0] = i; break;
						case 1: _ASConfig->iRightKey[0] = i; break;
						case 2: _ASConfig->iUpKey[0] = i; break;
						case 3: _ASConfig->iDownKey[0] = i; break;
						case 4: _ASConfig->iShotKey[0] = i; break;
						case 5: _ASConfig->iKickKey[0] = i; break;
						case 6: _ASConfig->iActionKey[0] = i; break;
						case 7: _ASConfig->iPullKey[0] = i; break;
						case 8: _ASConfig->iSuicideKey[0] = i; break;
						case 9: _ASConfig->iJumpKey[0] = i; break;
						case 10: _ASConfig->iChangePerspectiveKey[0] = i; break;
						case 11: _ASConfig->iStandartViewKey[0] = i; break;
						case 12: _ASConfig->iPauseKey[0] = i; break;
						case 13: _ASConfig->iQuickLoadKey[0] = i; break;
						case 14: _ASConfig->iQuickSaveKey[0] = i; break;
						case 15: _ASConfig->iLevelRestartKey[0] = i; break;
						case 16: _ASConfig->iShowLevelMissionsKey[0] = i; break;
					}
					bGetNewKey = FALSE;
					_ASConfig->Check();
				}
			}
			else
			{
				if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
				{ // Check what the player has selected:
					ASKeyFirst[DIK_SPACE] = ASKeyFirst[DIK_RETURN] = FALSE;
					ASPlayFmodSample(pChangeSample, FSOUND_LOOP_OFF);
					switch(byGameMenuSelected)
					{
						case 17: // Set all key to standart:
							_ASConfig->iLeftKey[0] = STANDART_LEFT_KEY;
							_ASConfig->iRightKey[0] = STANDART_RIGHT_KEY;
							_ASConfig->iUpKey[0] = STANDART_UP_KEY;
							_ASConfig->iDownKey[0] = STANDART_DOWN_KEY;
							_ASConfig->iShotKey[0] = STANDART_SHOT_KEY;
							_ASConfig->iKickKey[0] = STANDART_KICK_KEY;
							_ASConfig->iActionKey[0] = STANDART_ACTION_KEY;
							_ASConfig->iPullKey[0] = STANDART_PULL_KEY;
							_ASConfig->iSuicideKey[0] = STANDART_SUICIDE_KEY;
							_ASConfig->iJumpKey[0] = STANDART_JUMP_KEY;
							_ASConfig->iChangePerspectiveKey[0] = STANDART_CHANGE_PERSPECTIVE_KEY;
							_ASConfig->iPauseKey[0] = STANDART_PAUSE_KEY;
							_ASConfig->iStandartViewKey[0] = STANDART_STANDART_VIEW_KEY;
							_ASConfig->iQuickLoadKey[0] = STANDART_QUICK_LOAD_KEY;
							_ASConfig->iQuickSaveKey[0] = STANDART_QUICK_SAVE_KEY;
							_ASConfig->iLevelRestartKey[0] = STANDART_LEVEL_RESTART_KEY;
							_ASConfig->iShowLevelMissionsKey[0] = STANDART_SHOW_LEVEL_MISSIONS_KEY;
							_ASConfig->Check();
						break;

						case 18: // Back
							ASKeyFirst[DIK_ESCAPE] = TRUE;
						break;
						
						default: // Get the new key:
							bGetNewKey = TRUE;
						break;
					}
				}
				if(ASKeyFirst[DIK_ESCAPE])
				{
					ASKeyFirst[DIK_ESCAPE] = FALSE;
					ASPlayFmodSample(pChangeSample, FSOUND_LOOP_OFF);
					if(bGetNewKey)
						bGetNewKey = FALSE;
					else
					{
						byGameMenuSelected = 0;
						byGameMenuMenu = GM_OPTIONS;
					}
					break;
				}
			}
		break;

		case GM_ARE_YOU_SURE: // Are you sure question:
			fAreYouSureBlend += (float) g_lDeltatime/500;
			if(fAreYouSureBlend > 1.0f)
				fAreYouSureBlend = 1.0f;
			if(byGameMenuSelected < 0)
				byGameMenuSelected = 1;
			else
				if(byGameMenuSelected >= 2)
					byGameMenuSelected = 0;
			switch(byGameMenuSelected)
			{
				case 0: pMP_AreYouSure_Yes->bSelected = TRUE; break;
				case 1: pMP_AreYouSure_No->bSelected = TRUE; break;
			}
			if(ASKeyFirst[DIK_ESCAPE])
			{
				ASKeyFirst[DIK_ESCAPE] = FALSE;
				ASPlayFmodSample(pChangeSample, FSOUND_LOOP_OFF);
				bAreYouSureQuestionAnswer = FALSE;
				byGameMenuSelected = byGameMenuSelectedTemp;
				byGameMenuMenu = byLastGameMenuMenu2;
			}
			if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
			{
				ASKeyFirst[DIK_SPACE] = ASKeyFirst[DIK_RETURN] = FALSE;
				ASPlayFmodSample(pChangeSample, FSOUND_LOOP_OFF);
				if(!byGameMenuSelected)
					bAreYouSureQuestionAnswer = TRUE;
				else
					bAreYouSureQuestionAnswer = FALSE;
				byGameMenuSelected = byGameMenuSelectedTemp;
				byGameMenuMenu = byLastGameMenuMenu2;
			}
		break;
	}
} // end CheckOptionMenu()

void ShowInGameMenu(AS_WINDOW *pWindow)
{ // begin ShowInGameMenu()
	int i, iX, iY;

	if(bGameOver)
	{
		glColor4f(1.0f, 1.0f, 1.0f, fPauseBlend);
		pWindow->PrintAnimated(320, 200, AS_T(T_GameOver), 0, 6.0f, fFontAni, 1);
		glColor4f(0.7f, 0.7f, 0.7f, fPauseBlend*0.6f);
		pWindow->PrintAnimated(320, 203, AS_T(T_GameOver), 0, 6.2f, fFontAni, 1);
		glColor4f(0.5f, 0.5f, 0.5f, fPauseBlend*0.3f);
		pWindow->PrintAnimated(320, 206, AS_T(T_GameOver), 0, 6.4f, fFontAni, 1);
		glColor4f(0.3f, 0.3f, 0.3f, fPauseBlend*0.2f);
		pWindow->PrintAnimated(320, 209, AS_T(T_GameOver), 0, 6.6f, fFontAni, 1);
		glColor4f(0.2f, 0.2f, 0.2f, fPauseBlend*0.1f);
		pWindow->PrintAnimated(320, 212, AS_T(T_GameOver), 0, 6.8f, fFontAni, 1);
		glColor4f(1.0f, 1.0f, 1.0f, fPauseBlend);
	}
	if(fInGameMenuBlend)
	{ // Game main menu:
		if(!bGameOver)
		{
			iX = iY = 0;
			SetMenuPointColor(pMP_InGameMenu_Continue, fInGameMenuBlend, -1);
			pWindow->PrintAnimated(320, 250, AS_T(T_Continue), 0, 1.2f*pMP_InGameMenu_Continue->fSize, fFontAni, 1);
		}
		else
		{
			iX = 0;
			iY = -70;
		}
		if(!bGameOver)
		{
			SetMenuPointColor(pMP_InGameMenu_ShowLevelMissions, fInGameMenuBlend, -1);
			pWindow->PrintAnimated(320+iX, 230+iY, AS_T(T_ShowLevelMissions), 0, 1.2f*pMP_InGameMenu_ShowLevelMissions->fSize, fFontAni, 1);
		}
		SetMenuPointColor(pMP_InGameMenu_Load, fInGameMenuBlend, -1);
		pWindow->PrintAnimated(320+iX, 210+iY, AS_T(T_Load), 0, 1.2f*pMP_InGameMenu_Load->fSize, fFontAni, 1);
		if(!bGameOver)
		{
			SetMenuPointColor(pMP_InGameMenu_Save, fInGameMenuBlend, -1);
			pWindow->PrintAnimated(320+iX, 190+iY, AS_T(T_Save), 0, 1.2f*pMP_InGameMenu_Save->fSize, fFontAni, 1);
		}
		else
			iY += 20;
		SetMenuPointColor(pMP_InGameMenu_LevelRestart, fInGameMenuBlend, -1);
		pWindow->PrintAnimated(320+iX, 170+iY, AS_T(T_LevelRestart), 0, 1.2f*pMP_InGameMenu_LevelRestart->fSize, fFontAni, 1);
		if(!bSingleLevel)
		{
			SetMenuPointColor(pMP_InGameMenu_RestartCampaign, fInGameMenuBlend, -1);
			pWindow->PrintAnimated(320+iX, 150+iY, AS_T(T_RestartCampaign), 0, 1.2f*pMP_InGameMenu_RestartCampaign->fSize, fFontAni, 1);
			i = 130;
		}
		else
			i = 150;
		if(!bGameOver)
		{
			SetMenuPointColor(pMP_InGameMenu_Options, fInGameMenuBlend, -1);
			pWindow->PrintAnimated(320+iX, i+iY, AS_T(T_Options), 0, 1.2f*pMP_InGameMenu_Options->fSize, fFontAni, 1);
		}
		else
			i += 20;
		SetMenuPointColor(pMP_InGameMenu_Exit, fInGameMenuBlend, -1);
		pWindow->PrintAnimated(320+iX, i-20+iY, AS_T(T_Exit), 0, 1.2f*pMP_InGameMenu_Exit->fSize, fFontAni, 1);
	}
} // end ShowInGameMenu()

void CheckInGameMenu(void)
{ // begin CheckInGameMenu()
	char byTemp[256];

	CheckMenuPoints();
	fInGameMenuBlend -= (float) g_lDeltatime/1000;
	if(fInGameMenuBlend < 0.0f)
		fInGameMenuBlend = 0.0f;
	if(byGameMenuMenu == GM_MAIN_MENU)
	{ // Game main menu:
		fInGameMenuBlend += (float) g_lDeltatime/500;
		if(fInGameMenuBlend > 1.0f)
			fInGameMenuBlend = 1.0f;
		if(ASKeyFirst[DIK_UP])
		{
			byGameMenuSelected--;
			if(bGameOver && (byGameMenuSelected == 6))
				byGameMenuSelected--;
			if(bSingleLevel && byGameMenuSelected == 5)
				byGameMenuSelected--;
			if(bGameOver && (byGameMenuSelected == 3))
				byGameMenuSelected--;
			if(bGameOver && (byGameMenuSelected == 1))
				byGameMenuSelected -= 2;
			ASPlayFmodSample(pSelectSample, FSOUND_LOOP_OFF);
		}
		if(ASKeyFirst[DIK_DOWN])
		{
			byGameMenuSelected++;
			if(bGameOver && (byGameMenuSelected == 1))
				byGameMenuSelected++;
			if(bGameOver && byGameMenuSelected == 3)
				byGameMenuSelected++;
			if(bSingleLevel && byGameMenuSelected == 5)
				byGameMenuSelected++;
			if(bGameOver && byGameMenuSelected == 6)
				byGameMenuSelected++;
			ASPlayFmodSample(pSelectSample, FSOUND_LOOP_OFF);
		}
		if(!bGameOver)
		{
			if(byGameMenuSelected < 0)
				byGameMenuSelected = 7;
			if(byGameMenuSelected >= 8)
				byGameMenuSelected = 0;
		}
		else
		{
			if(byGameMenuSelected < 2)
				byGameMenuSelected = 7;
			if(byGameMenuSelected >= 8)
				byGameMenuSelected = 2;
		}
		switch(byGameMenuSelected)
		{
			case 0: pMP_InGameMenu_Continue->bSelected = TRUE; break;
			case 1: pMP_InGameMenu_ShowLevelMissions->bSelected = TRUE; break;
			case 2: pMP_InGameMenu_Load->bSelected = TRUE; break;
			case 3: pMP_InGameMenu_Save->bSelected = TRUE; break;
			case 4: pMP_InGameMenu_LevelRestart->bSelected = TRUE; break;
			case 5: pMP_InGameMenu_RestartCampaign->bSelected = TRUE; break;
			case 6: pMP_InGameMenu_Options->bSelected = TRUE; break;
			case 7: pMP_InGameMenu_Exit->bSelected = TRUE; break;
		}
		if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
		{
			ASKeyFirst[DIK_SPACE] = ASKeyFirst[DIK_RETURN] = FALSE;
			ASPlayFmodSample(pChangeSample, FSOUND_LOOP_OFF);
			switch(byGameMenuSelected)
			{
				case 0: // Continue game:
					ASKeyFirst[_ASConfig->iPauseKey[0]] = TRUE;
				break;

				case 1: // Show level missions:
					byGameMenuMenu = GM_SHOW_LEVEL_MISSIONS;
					byGameMenuSelected = 0;
				break;

				case 2: // Load:
					byLastGameMenuMenu = byGameMenuMenu;
					byGameMenuMenu = GM_LOAD_MENU;
					byGameMenuSelected = 0;
					EnumeratePlayerSaveGames();
				break;

				case 3: // Save:
					byLastGameMenuMenu = byGameMenuMenu;
					byGameMenuMenu = GM_SAVE_MENU;
					byGameMenuSelected = 0;
					EnumeratePlayerSaveGames();
				break;

				case 4: // Restart level:
					StartCurrentLevel();
				break;

				case 5: // Restart campaign:
					strcpy(byTemp, PlayerIdentity.byName);
					CreateNewPlayerInfo(&PlayerIdentity, &CurrentCampaign);
					strcpy(PlayerIdentity.byName, byTemp);
					StartCurrentLevel();
				break;

				case 6: // Options:
					byGameMenuMenu = GM_OPTIONS;
					byGameMenuSelected = 0;
				break;

				case 7: // Quit:
					if(!bEditorTestLevel)
						SendMessage(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), WM_COMMAND, ID_GAME_GENERAL_MAIN_MENU, 0);
					else
						_AS->SetNextModule(MODULE_EDITOR);
				break;
			}
		}
	}
	else
	{ // Something other:
		if(!bGetPlayerName)
		{
			if(ASKeyFirst[DIK_UP])
			{
				byGameMenuSelected--;
				ASPlayFmodSample(pSelectSample, FSOUND_LOOP_OFF);
			}
			if(ASKeyFirst[DIK_DOWN])
			{
				byGameMenuSelected++;
				ASPlayFmodSample(pSelectSample, FSOUND_LOOP_OFF);
			}
			ASKeyFirst[_ASConfig->iPauseKey[0]] = FALSE;
		}
	}
} // end CheckInGameMenu()

void CheckDeletePlayerID(void)
{ // begin CheckDeletePlayerID()
	char byTemp[256];

	if(!iPlayerIDsList || byGameMenuSelected >= iPlayerIDsList)
		return;
	if(ASKeyFirst[DIK_DELETE])
	{ // Delete the selected ID:
		byLastGameMenuMenu2 = byGameMenuMenu;
		byGameMenuMenu = GM_ARE_YOU_SURE;
		byGameMenuSelectedTemp = byGameMenuSelected;
		byGameMenuSelected = 0;
		bAreYouSureQuestion = TRUE;
		bAreYouSureQuestionAnswer = FALSE;
		return;
	}
	if(bAreYouSureQuestion)
	{
		bAreYouSureQuestion = FALSE;
		if(bAreYouSureQuestionAnswer)
		{ // Delete this player ID:
			byGameMenuSelected = byGameMenuSelectedTemp;
			_AS->WriteLogMessage("Delete player ID: %s", pbyPlayerIDList[byGameMenuSelected]);
			sprintf(byTemp, "%s%s\\%s\\", _AS->byProgramPath, _AS->byIdentityDirectory, pbyPlayerIDList[byGameMenuSelected]);
			ASRemoveDirectory(byTemp);
			EnumeratePlayerIDs();
			if(!iPlayerIDsList)
				if(byGameMenuMenu != GM_GET_PLAYER_ID)
					byGameMenuMenu = byLastGameMenuMenu;
			byGameMenuSelected = 0;
		}
	}
} // end CheckDeletePlayerID()

void CheckDeletePlayerSaveGame(void)
{ // begin CheckDeletePlayerSaveGame()
	char byTemp[256];

	if(!iPlayerSaveGamesList || byGameMenuSelected >= iPlayerSaveGamesList)
		return;
	if(ASKeyFirst[DIK_DELETE])
	{ // Delete the selected ID:
		byLastGameMenuMenu2 = byGameMenuMenu;
		byGameMenuMenu = GM_ARE_YOU_SURE;
		byGameMenuSelectedTemp = byGameMenuSelected;
		byGameMenuSelected = 0;
		bAreYouSureQuestion = TRUE;
		bAreYouSureQuestionAnswer = FALSE;
		return;
	}
	if(bAreYouSureQuestion)
	{
		bAreYouSureQuestion = FALSE;
		if(bAreYouSureQuestionAnswer)
		{ // Delete this save game:
			byGameMenuSelected = byGameMenuSelectedTemp;
			_AS->WriteLogMessage("Delete save game: %s", pbyPlayerSaveGamesList[byGameMenuSelected]);
			sprintf(byTemp, "%s%s\\%s\\%s\\", _AS->byProgramPath, _AS->byIdentityDirectory, PlayerIdentity.byName, pbyPlayerSaveGamesList[byGameMenuSelected]);
			ASRemoveDirectory(byTemp);
			EnumeratePlayerSaveGames();
			if(!iPlayerSaveGamesList)
				byGameMenuMenu = byLastGameMenuMenu;
			byGameMenuSelected = 0;
		}
	}
} // end CheckDeletePlayerSaveGame()

void GameMenuStartCampaignWithOldPlayerID(void)
{ // begin GameMenuStartCampaignWithOldPlayerID()
	char byTemp[256];

	LoadPlayerIdentity(pbyPlayerIDList[byGameMenuSelected], &PlayerIdentity, &CurrentCampaign);
	strcpy(byGetPlayerName, PlayerIdentity.byName);
	DestroyPlayerInfo(&PlayerIdentity);
	CreateNewPlayerInfo(&PlayerIdentity, &CurrentCampaign);
	strcpy(PlayerIdentity.byName, byGetPlayerName);
	sprintf(byTemp, "%s%s\\%s\\", _AS->byProgramPath, _AS->byIdentityDirectory, PlayerIdentity.byName);
	ASRemoveDirectory(byTemp);
	SavePlayerIdentity(&PlayerIdentity, &CurrentCampaign);
	bInGameMenu = FALSE;
	bSingleLevel = FALSE;
} // end GameMenuStartCampaignWithOldPlayerID()

void AnimateFont(void)
{ // begin AnimateFont()
	int i, i2;

	if(!bSelectedSize)
	{
		fSelectedSize += (float) g_lDeltatime/3000;
		if(fSelectedSize > 1.0f)
		{
			fSelectedSize = 1.0f;
			bSelectedSize = TRUE;
		}
	}
	else
	{
		fSelectedSize -= (float) g_lDeltatime/3000;
		if(fSelectedSize < 0.8f)
		{
			fSelectedSize = 0.8f;
			bSelectedSize = FALSE;
		}
	}

	if(!bShowCredits)
	{
		for(i = 0; i < 4; i++)
			for(i2 = 0; i2 < 2; i2++)
			{
				fFontAni[i][i2] += fFontAniV[i][i2]*((float) g_lDeltatime/800);
				if(fFontAniLast[i][i2] >= fFontAniT[i][i2])
				{
					fFontAniV[i][i2] -= ((float) g_lDeltatime/200);
					if(fFontAniV[i][i2] < -1.2f)
						fFontAniV[i][i2] = -1.2f;
					if(fFontAni[i][i2] <= fFontAniT[i][i2])
					{
						fFontAniLast[i][i2] = fFontAni[i][i2];
						if(!(rand() % 2))
							fFontAniT[i][i2] = ((float) (rand() % 10)/8);
						else
							fFontAniT[i][i2] = -((float) (rand() % 10)/8);
					}
				}
				if(fFontAniLast[i][i2] < fFontAniT[i][i2])
				{
					fFontAniV[i][i2] += ((float) g_lDeltatime/200);
					if(fFontAniV[i][i2] > 1.2f)
						fFontAniV[i][i2] = 1.2f;
					if(fFontAni[i][i2] >= fFontAniT[i][i2])
					{
						fFontAniLast[i][i2] = fFontAni[i][i2];
						if(!(rand() % 2))
							fFontAniT[i][i2] = ((float) (rand() % 10)/8);
						else
							fFontAniT[i][i2] = -((float) (rand() % 10)/8);
					}
				}
			}
	}
	else
	{
		for(i = 0; i < 4; i++)
			for(i2 = 0; i2 < 2; i2++)
			{
				fFontAni[i][i2] += fFontAniV[i][i2]*((float) g_lDeltatime/800);
				if(fFontAniLast[i][i2] >= fFontAniT[i][i2])
				{
					fFontAniV[i][i2] -= ((float) g_lDeltatime/200);
					if(fFontAniV[i][i2] < -2.0f)
						fFontAniV[i][i2] = -2.0f;
					if(fFontAni[i][i2] <= fFontAniT[i][i2])
					{
						fFontAniLast[i][i2] = fFontAni[i][i2];
						if(!(rand() % 2))
							fFontAniT[i][i2] = ((float) (rand() % 10)/2);
						else
							fFontAniT[i][i2] = -((float) (rand() % 10)/2);
					}
				}
				if(fFontAniLast[i][i2] < fFontAniT[i][i2])
				{
					fFontAniV[i][i2] += ((float) g_lDeltatime/200);
					if(fFontAniV[i][i2] > 2.0f)
						fFontAniV[i][i2] = 2.0f;
					if(fFontAni[i][i2] >= fFontAniT[i][i2])
					{
						fFontAniLast[i][i2] = fFontAni[i][i2];
						if(!(rand() % 2))
							fFontAniT[i][i2] = ((float) (rand() % 10)/2);
						else
							fFontAniT[i][i2] = -((float) (rand() % 10)/2);
					}
				}
			}
	}
} // end AnimateFont()

void InitMenuPoints(void)
{ // begin InitMenuPoints()
	MENU_POINT *pMPT;
	int i, i2;
	
	for(i = 0; i < MENU_POINTS; i++)
	{
		pMPT = &MenuPoint[i];
		pMPT->fSize = 1.0f;
		for(i2 = 0; i2 < 3; i2++)
			pMPT->fColor[i2] = 1.0f;
	}
} // end InitMenuPoints()

void CheckMenuPoints(void)
{ // begin CheckMenuPoints()
	MENU_POINT *pMPT;

	for(int i = 0; i < MENU_POINTS; i++)
	{
		pMPT = &MenuPoint[i];
		if(pMPT->bSelected)
		{
			if(pMPT->fColor[R] > 0.0f)
			{
				pMPT->fColor[R] -= (float) g_lDeltatime/200;
				if(pMPT->fColor[R] < 0.0f)
					pMPT->fColor[R] = 0.0f;
			}
			if(pMPT->fColor[B] > 0.0f)
			{
				pMPT->fColor[B] -= (float) g_lDeltatime/200;
				if(pMPT->fColor[B] < 0.0f)
					pMPT->fColor[B] = 0.0f;
			}
			if(!pMPT->bSize)
			{
				pMPT->fSize += (float) g_lDeltatime/3000;
				if(pMPT->fSize > 1.0f)
				{
					pMPT->fSize = 1.0f;
					pMPT->bSize = TRUE;
				}
			}
			else
			{
				pMPT->fSize -= (float) g_lDeltatime/3000;
				if(pMPT->fSize < 0.8f)
				{
					pMPT->fSize = 0.8f;
					pMPT->bSize = FALSE;
				}
			}
		}
		else
		{
			if(pMPT->fColor[R] < 1.0f)
			{
				pMPT->fColor[R] += (float) g_lDeltatime/200;
				if(pMPT->fColor[R] > 1.0f)
					pMPT->fColor[R] = 1.0f;
			}
			if(pMPT->fColor[B] < 1.0f)
			{
				pMPT->fColor[B] += (float) g_lDeltatime/200;
				if(pMPT->fColor[B] > 1.0f)
					pMPT->fColor[B] = 1.0f;
			}
			if(pMPT->fSize > 1.0f)
			{
				pMPT->fSize -= (float) g_lDeltatime/3000;
				if(pMPT->fSize < 1.0f)
					pMPT->fSize = 1.0f;
			}
			if(pMPT->fSize < 1.0f)
			{
				pMPT->fSize += (float) g_lDeltatime/3000;
				if(pMPT->fSize > 1.0f)
					pMPT->fSize = 1.0f;
			}
		}
		pMPT->bSelected = FALSE;
	}
} // end CheckMenuPoints() 

void SetMenuPointColor(MENU_POINT *pMenuPointT, float fBlend, int iKeyCode)
{ // begin SetMenuPointColor()
	if(iKeyCode == -1 || _ASConfig->EnumerateKeyUsage(iKeyCode) <= 1)
		glColor4f(pMenuPointT->fColor[R], pMenuPointT->fColor[G], pMenuPointT->fColor[B], fBlend);
	else
	{
		glColor4f(pMenuPointT->fColor[R], pMenuPointT->fColor[G]*0.6f, pMenuPointT->fColor[B]*0.6f, fBlend);
		pMenuPointT->fColor[R] += (float) g_lDeltatime/100;
	}
} // end SetMenuPointColor()

void ShowMainMenu(void)
{ // begin ShowMainMenu()
	bShowLogosAfterCredits = FALSE;
	dwMainMenuStartTime = g_lGameTimer;
	bShowLogos = FALSE;
	if(bMenuChange || bShowCredits)
	{
		byGameMenuSelected = 0;
		byGameMenuMenu = GM_MAIN_MENU;
	}
	bMenuChange	= FALSE;
	bShowCredits = FALSE;
	StartMusic("MainMenu.mp3");
	if(fGameMenuBlend < 0.0f)
		fGameMenuBlend = 0.0f;
} // end ShowMainMenu()

void ShowCredits(void)
{ // begin ShowCredits()
	bShowCredits = TRUE;
	iCreditsTextY = -11;
	iCreditsBackground = 0;
	fCreditsBackgroundTimer = fCreditsBackgroundBlend = 0.0f;
	StartMusic("Credits.mp3");
} // end ShowCredits()

void ShowLogos(void)
{ // begin ShowLogos()
	fGameMenuBlend = 0.0f;
	bShowLogos = TRUE;
	bInGameMenu = FALSE;
	bGetPlayerName = FALSE;
} // end ShowLogos()

void DrawTitel(void)
{ // begin DrawTitel()
	int iX, iY;
	
	// Draw the grid:
	glDisableClientState(GL_COLOR_ARRAY);
	glDisableClientState(GL_NORMAL_ARRAY);
	glLoadIdentity();
	glRotatef(180.0f, 0.0f, 0.0f, 1.0f);
	glTranslatef(12.0f, -9.0f, -25.0f);
	glRotatef(180.0f, 0.0f, 1.0f, 0.0f);

	glDisable(GL_CULL_FACE);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_FOG);
	glDisable(GL_LIGHTING);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	glEnable(GL_BLEND);
	glEnable(GL_TEXTURE_2D);
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);

	glBindTexture(GL_TEXTURE_2D, GameMenuTexture[2].iOpenGLID);
	glEnableClientState(GL_VERTEX_ARRAY);
	glEnableClientState(GL_TEXTURE_COORD_ARRAY);
	glVertexPointer(3, GL_FLOAT, 0, fTitelGridPoint);
	glTexCoordPointer(2, GL_FLOAT, 0, fTitelGridTexture);
	glBegin(GL_TRIANGLES);
		for(iY = 0; iY < TITEL_GRID_Y_SIZE-1; iY++)
		{
			for(iX = 1; iX < TITEL_GRID_X_SIZE-1; iX++)
			{
				// Draw the first triangle of the quad:
				glArrayElement((iX-1)+iY*TITEL_GRID_X_SIZE);
				glArrayElement(iX+iY*TITEL_GRID_X_SIZE);
				glArrayElement(iX+(iY+1)*TITEL_GRID_X_SIZE);
				// Draw the second triangle of the quad:
				glArrayElement(iX+(iY+1)*TITEL_GRID_X_SIZE);
				glArrayElement((iX-1)+(iY+1)*TITEL_GRID_X_SIZE);
				glArrayElement((iX-1)+iY*TITEL_GRID_X_SIZE);
				_AS->iTriangles += 2;
			}
		}
	glEnd();
} // end DrawTitel()

void CheckTitel(void)
{ // begin CheckTitel()
	int iX, iY;

	fGameTitleTimer += (float) g_lDeltatime/1000;
	// Setup the grid:
	float fGalaxy = (float) (0.5f-0.5f*cos(sin(fGalaxyIn*PId2)*PI));
	for(iY = 0; iY < TITEL_GRID_Y_SIZE; iY++)
	{
		for(iX = 0; iX < TITEL_GRID_X_SIZE; iX++)
		{ // Set the z coordinate:
			fTitelGridPoint[iX+iY*TITEL_GRID_X_SIZE][X] = (float) iX*1.3f+(300-iX*iX*iX*fGalaxy)*(1.0f-fGalaxy);
			fTitelGridPoint[iX+iY*TITEL_GRID_X_SIZE][Y] = (float) iY*fGalaxy/1.5f+(100*(iY*iY*fGalaxy))*(1.0f-fGalaxy);

			fTitelGridPoint[iX+iY*TITEL_GRID_X_SIZE][Z] = (float) (
														 0.2f*sin((float) iX+fGameTitleTimer)+
														 0.2f*sin((float) iY+fGameTitleTimer));
		}
	}
} // end CheckTitel()

void InitTitel(void)
{ // begin InitTitel()
	int iX, iY;

	// Setup the grid:
	for(iY = 0; iY < TITEL_GRID_Y_SIZE; iY++)
	{
		for(iX = 0; iX < TITEL_GRID_X_SIZE; iX++)
		{ // Set the coordinates:
			fTitelGridTexture[iX+iY*TITEL_GRID_X_SIZE][X] = (float) iX/(TITEL_GRID_X_SIZE-2);
			fTitelGridTexture[iX+iY*TITEL_GRID_X_SIZE][Y] = (float) iY/(TITEL_GRID_Y_SIZE-1);

			fTitelGridPoint[iX+iY*TITEL_GRID_X_SIZE][X] = (float) iX*1.3f;
			fTitelGridPoint[iX+iY*TITEL_GRID_X_SIZE][Y] = (float) iY/1.5f;
			fTitelGridPoint[iX+iY*TITEL_GRID_X_SIZE][Z] = (float) (
														 0.2f*sin((float) iX+fGameTitleTimer)+
														 0.2f*sin((float) iY+fGameTitleTimer));
		}
	}
} // end InitTitel()
/*==========================================================================*/




/*==========================================================================*/
/*==========================================================================*/
/* The orginal galaxy code was taken from:									*/
/*																			*/
/*  Galaxy Demo                                                             */
/*  Author: Roman Podobedov                                                 */
/*  Email: romka@ut.ee                                                      */
/*  WEB: http://romka.demonews.com                                          */
/*==========================================================================*/

#define GALAXY_P 200
#define GALAXY_P1 800

typedef struct GALAXY_POINT
{
	float x, y, z;
	float r, g, b;
	float speed;
} GALAXY_POINT;

GALAXY_POINT p1[GALAXY_P];
GALAXY_POINT p2[GALAXY_P];
GALAXY_POINT p3[GALAXY_P1];
float fGalaxyAngle = 0.0f;


void InitGalaxy(void)
{ // begin InitGalaxy()
	float alpha, x, z, r, theta, a, b;
	int i, j;
	
	_AS->WriteLogMessage("Init galaxy");
	// Calculate central level (very condensed particles)
	for(j = 0; j < 4; j++)
	{
		a = 0.9f;
		b = 0.31f;
		theta = 0;
		for(i = 0; i < 50; i++)
		{
			// Spiral formula: r = a*exp(b*theta)
			r = a*(float) exp(b*theta);
			theta += 2.5f/(float)(i+1);
			
			// Particle coordinates in xz plane
			x = r*(float) cos(theta);
			z = r*(float) sin(theta);
			alpha = (float) (((float) j*90)*PI)/180;
			
			// Particle coordinates in xz plane + rotation
			p1[j*50+i].x = x*(float) cos(alpha)-z*(float) sin(alpha);
			p1[j*50+i].z = x*(float) sin(alpha)+z*(float) cos(alpha);
			
			// Particle color
			x = (float) (rand() % 256)/512;
			p1[j*50+i].r = x;
			p1[j*50+i].g = x;
			p1[j*50+i].b = x;
		}
	}
	// Next level of particles: normal condensation
	for(j = 0; j < 4; j++)
	{
		a = 1.9f;
		b = 0.3f;
		theta = 0;
		for(i = 0; i < 50; i++)
		{
			// r = a*exp(b*theta)
			r = a*(float) exp(b*theta);
			theta += 2.3f/(float) (i+1);
			x = r*(float) cos(theta);
			z = r*(float) sin(theta);
			alpha = (float) (((float) j*90+(float) (rand() % 180))*PI)/180;
			
			// Particle coordinates in xyz space + rotation
			p2[j*50+i].x = x*(float) cos(alpha)-z*(float) sin(alpha);
			p2[j*50+i].y = (float) (rand() % 40)-20;
			p2[j*50+i].z = x*(float) sin(alpha)+z*(float) cos(alpha);
			
			// Particle color
			x = (float) (rand() % 256)/512;
			p2[j*50+i].r = 0.2f+x;
			p2[j*50+i].g = 0.2f+x;
			p2[j*50+i].b = 0.5f+x;
			
			// Random speed of particles
			p2[j*50+i].speed = (float) (rand() % 100)/100+0.1f;
		}
	}
	for(j = 0; j < 4; j++)
	{
		a = 1.5f;
		b = 0.3f;
		theta = 0;
		for(i = 0; i < 200; i++)
		{
			// r = a*exp(b*theta)
			r = a*(float) exp(b*theta);
			theta += 2.2f/(float) (i+1);
			x = r*(float) cos(theta);
			z = r*(float) sin(theta);
			alpha = (float) (((float)j*90+(float) (rand() % 360))*PI)/180;
			
			// Particle coordinates in xyz space + rotation
			p3[j*50+i].x = x*(float) cos(alpha)-z*(float) sin(alpha);
			p3[j*50+i].y = (float) (rand() % 40)-20;
			p3[j*50+i].z = x*(float) sin(alpha)+z*(float) cos(alpha);
			
			// Particle color
			x = (float) (rand() % 256)/256;
			p3[j*50+i].r = 0.5f+x;
			p3[j*50+i].g = 0.5f+x;
			p3[j*50+i].b = 0.2f+x;
			
			// Random speed of particles
			p3[j*50+i].speed = (float) (rand() % 100)/100+0.1f;
		}
	}
	_AS->WriteLogMessage("OK");
} // end InitGalaxy()

void DrawGalaxy(void)
{ // begin DrawGalaxy()
	float a, b, ang1, fGalaxy;
	int i;

	glClear(GL_COLOR_BUFFER_BIT);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(125.0f, (GLfloat)_ASConfig->iWindowWidth/(GLfloat)_ASConfig->iWindowHeight*1.5f, 0.1f, 10000.0f);
	glMatrixMode(GL_MODELVIEW);

	glLoadIdentity();
	fGalaxy = (float) (0.5f-0.5f*cos(sin(fGalaxyIn*PId2)*PI));
	glTranslatef(-2500+fGalaxy*2500, 1100-fGalaxy*1100, -820.0f+fGalaxy*800.0f);
	glRotatef(-fGalaxy*120, 1.0f, 0.0f, 0.0f);
	glRotatef(fGalaxy*280.0f, 0.0f, 1.0f, 0.0f);
	glRotatef(-(1.0f-fGalaxy)*100.0f, 0.0f, 0.0f, 1.0f);

	// Rotate galaxy:
	fGalaxyAngle -= 0.001f*g_lDeltatime;

	glDisable(GL_CULL_FACE);
	glColor4f(1.0f, 1.0f, 1.0f, 0.5f);
	// Draw inside part of galaxy (very condensed part)
	glBindTexture(GL_TEXTURE_2D, GameTexture[11].iOpenGLID);
	glBegin(GL_QUADS);
		for(i = 0; i < GALAXY_P; i++)
		{
			glColor3f(p1[i].r, p1[i].g, p1[i].b);
			a = p1[i].x*(float) cos(fGalaxyAngle*PI/180)-p1[i].z*(float) sin(fGalaxyAngle*PI/180);
			b = p1[i].x*(float) sin(fGalaxyAngle*PI/180)+p1[i].z*(float) cos(fGalaxyAngle*PI/180);
			glTexCoord2f(0, 0); glVertex3f(a-6, 0, b-6);
			glTexCoord2f(1, 0); glVertex3f(a-6, 0, b+6);
			glTexCoord2f(1, 1); glVertex3f(a+6, 0, b+6);
			glTexCoord2f(0, 1); glVertex3f(a+6, 0, b-6);
		}
	glEnd();

	// Draw part of galaxy (normal condensed part)
	glBindTexture(GL_TEXTURE_2D, GameTexture[12].iOpenGLID);
	glBegin(GL_QUADS);
		for(i = 0; i < GALAXY_P; i++)
		{
			glColor4f(p2[i].r-0.5f, p2[i].g-0.5f, p2[i].b-0.5f, 1);
			ang1 = fGalaxyAngle*p2[i].speed;
			a = p2[i].x*(float) cos(ang1*PI/180)-p2[i].z*(float) sin(ang1*PI/180);
			b = p2[i].x*(float) sin(ang1*PI/180)+p2[i].z*(float) cos(ang1*PI/180);
			glTexCoord2f(0, 0); glVertex3f(a-2, p2[i].y, b-2);
			glTexCoord2f(1, 0); glVertex3f(a-2, p2[i].y, b+2);
			glTexCoord2f(1, 1); glVertex3f(a+2, p2[i].y, b+2);
			glTexCoord2f(0, 1); glVertex3f(a+2, p2[i].y, b-2);
		}

		// Draw part of galaxy (slightly condensed part)
		for(i = 0; i < GALAXY_P1; i++)
		{
			glColor4f(p3[i].r, p3[i].g, p3[i].b, 1);
			ang1 = fGalaxyAngle*p3[i].speed;
			a = p3[i].x*(float) cos(ang1*PI/180)-p3[i].z*(float) sin(ang1*PI/180);
			b = p3[i].x*(float) sin(ang1*PI/180)+p3[i].z*(float) cos(ang1*PI/180);
			glTexCoord2f(0, 0); glVertex3f(a-1, p3[i].y, b-1);
			glTexCoord2f(1, 0); glVertex3f(a-1, p3[i].y, b+1);
			glTexCoord2f(1, 1); glVertex3f(a+1, p3[i].y, b+1);
			glTexCoord2f(0, 1); glVertex3f(a+1, p3[i].y, b-1);
		}
	glEnd();

	// Draw foggly part of galaxy (simply polygon with texture)
	glColor4f(0.7f, 0.7f, 0.7f, 1.0f);
	glBindTexture(GL_TEXTURE_2D, GameMenuTexture[1].iOpenGLID);
	glPushMatrix();
	glRotatef(-fGalaxyAngle, 0, 1, 0);
	glBegin(GL_QUADS);
		glTexCoord2f(0, 0); glVertex3f(-60, 0, -60);
		glTexCoord2f(1, 0); glVertex3f(-60, 0, 60);
		glTexCoord2f(1, 1); glVertex3f(60, 0, 60);
		glTexCoord2f(0, 1); glVertex3f(60, 0, -60);
	glEnd();
	_AS->iTriangles += 2;
	glPopMatrix();
	glEnable(GL_CULL_FACE);

	// Draw background:
	glPushMatrix();
	// Flip to projection mode:
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	// Set new 2D projection
	gluOrtho2D(-1, 1, -1, 1);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	// Flip back to normal 3D mode
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
	glPopMatrix();
	gluPerspective(45.0f, (GLfloat)_ASConfig->iWindowWidth/(GLfloat)_ASConfig->iWindowHeight, 0.1f, 100.0f);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0f, (GLfloat)_ASConfig->iWindowWidth/(GLfloat)_ASConfig->iWindowHeight, 0.1f, 100.0f);
	glMatrixMode(GL_MODELVIEW);
} // end DrawGalaxy()

void DrawStar(float psize)
{ // begin DrawStar()
    // Draw polygon and particle texture mapping
	glTexCoord2f(0, 0); glVertex3f(-psize, 0, -psize);
	glTexCoord2f(1, 0); glVertex3f(-psize, 0, psize);
	glTexCoord2f(1, 1); glVertex3f(psize, 0, psize);
	glTexCoord2f(0, 1); glVertex3f(psize, 0, -psize);
	_AS->iTriangles += 2;
} // end DrawStar()
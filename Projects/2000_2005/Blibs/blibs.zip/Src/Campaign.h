//-----------------------------------------------------------------------------
// File: Campaign.h
//-----------------------------------------------------------------------------

#ifndef __CAMPAIGN_H__
#define __CAMPAIGN_H__


// Structures: ****************************************************************
typedef struct CAMPAIGN
{
	BOOL bKeyword;			// Is there a keyword?
	char byKeyword[256],	// The keyword for the editing access
		 byFilename[256],	// The filename of this campaign
		 byName[256];		// The name of this campaign
	int iLevels;			// The number of Levels
	char **byLevelFilename; // The level filenames

} CAMPAIGN;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern CAMPAIGN CurrentCampaign;
extern int iCurrentCampaignLevel;
extern char **pbyCampaignListLevelNames;
extern char **pbyCampaignList;
extern int iCampaignsList;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern LRESULT CALLBACK CampaignEditorProc(HWND, UINT, WPARAM, LPARAM);
extern BOOL LoadCampaign(CAMPAIGN *, char *);
extern void SaveCampaign(CAMPAIGN *, char *);
extern void DestroyCampaign(CAMPAIGN *);
void EnumerateCampaigns(void);
void DestroyCampaignsList(void);
///////////////////////////////////////////////////////////////////////////////


#endif // __CAMPAIGN_H__
#include <windows.h>
#include <windowsx.h>
#include <basetsd.h>
#include <ddraw.h>
#include <dinput.h>
#include <dmusici.h>
#include <tchar.h>
#include <stdio.h>
#include "resource.h"



// Definitions: ***************************************************************
#define SAFE_DELETE(p)  { if(p) { delete (p);     (p)=NULL; } }
#define LOADER_NAME "Blibs loader"
#define GAME_INFO_FILE "Game.ini"
#define TEXTS 10
#define MESSAGES 1
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
LRESULT CALLBACK LoaderProc(HWND, UINT, WPARAM, LPARAM);
DWORD GetDXVersion(void);
void EnumerateLanguages(void);
void SetLanguage(char *);
void DestroyLanguage(void);
void SetLoaderTexts(void);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
POINT LastMousePos;
BOOL bMoveLoader, bFirstRun;
LPTSTR pbyProgramPath;
LPTSTR pbyProgramExeName;
LPTSTR pbyProgramDrive;
LPTSTR pbyProgramDir;
LPTSTR pbyLanguagesFile;
LPTSTR pbyConfigFile;
HWND hWndLoader;
char byParameters[256];
typedef HRESULT(WINAPI * DIRECTDRAWCREATE)( GUID*, LPDIRECTDRAW*, IUnknown* );
typedef HRESULT(WINAPI * DIRECTDRAWCREATEEX)( GUID*, VOID**, REFIID, IUnknown* );
typedef HRESULT(WINAPI * DIRECTINPUTCREATE)( HINSTANCE, DWORD, LPDIRECTINPUT*,
                                             IUnknown* );
char *pbyText[TEXTS];
char *pbyMessage[MESSAGES];
short iLanguages;  // The number of languages
char **pbyLanguage; // All found languages names
char bySelectedLanguage[256];
// Here are all pointers to the texts:
char *T_HelpFile, *T_Play, *T_Editor, *T_Config, *T_Help, *T_Exit, *T_BlibsLoader,
	 *T_NoDirectX, *T_DirectXVersion, *T_WrongDirectXVersion;
// Pointer to messages:	
char *M_TheProgramIsAlreadyRunning;
///////////////////////////////////////////////////////////////////////////////


int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                   LPSTR strCmdLine, int nCmdShow)
{ // begin WinMain()
	short i;
    TCHAR* strResult;
	char byTemp[256], byTemp2[256];
	BOOL bError = FALSE, bLanguage;
    DWORD  dwDXVersion = GetDXVersion();

	// Find path info
  	pbyProgramPath = new char[_MAX_DRIVE+_MAX_DIR];
	pbyProgramExeName = new char[MAX_PATH];
	pbyProgramDrive = new char[_MAX_DRIVE];
	pbyProgramDir = new char[_MAX_DIR];
	GetModuleFileName(hInstance, pbyProgramExeName, MAX_PATH);
	_splitpath(pbyProgramExeName, pbyProgramDrive, pbyProgramDir, NULL, NULL);
	sprintf(pbyProgramPath, "%s%s", pbyProgramDrive, pbyProgramDir);
	SetCurrentDirectory(pbyProgramPath);

	// Some other stuff:
	pbyLanguagesFile = new char[MAX_PATH];
	pbyConfigFile = new char[MAX_PATH];
	sprintf(byTemp, "%s"GAME_INFO_FILE"", pbyProgramPath);
	GetPrivateProfileString("General", "languages_file", "Data\\Languages", pbyLanguagesFile, MAX_PATH, byTemp);
	GetPrivateProfileString("General", "config_file", "Config.ini", pbyConfigFile, MAX_PATH, byTemp);
	sprintf(byTemp, "%s%s", pbyProgramPath, pbyConfigFile);
	GetPrivateProfileString("General", "language", "GB", bySelectedLanguage, MAX_PATH, byTemp);
	bFirstRun = GetPrivateProfileInt("General", "firstrun", 1, byTemp);

	if(bFirstRun)
	{
		sprintf(byTemp, "%sBlibs.exe", pbyProgramPath);
		sprintf(byTemp2, "-onlyconfig -loader %s", byParameters);
		ShellExecute(0, "open", byTemp, byTemp2, 0, SW_SHOW);
		return 0;
	}

	// Check if the selected language is available:
	EnumerateLanguages();
	bLanguage = FALSE;
	for(i = 0; i < iLanguages; i++)
		if(!strcmp(pbyLanguage[i], bySelectedLanguage))
		{
			bLanguage = TRUE;
			break;
		}
	if(!bLanguage)
	{ // No this language isn't available:
		if(!iLanguages)
		{ // Oh, no! There is no other language!!
			MessageBox(NULL, "There are no languages!!\nAs result there are no text's!",
					   LOADER_NAME, MB_OK | MB_ICONINFORMATION);
		}
		else
		{ // Change to the first best language:
			sprintf(byTemp, "The selected language (%s) isn't available!!\nPlease choose an other language.\n",
					bySelectedLanguage);
			MessageBox(NULL, byTemp, LOADER_NAME, MB_OK | MB_ICONINFORMATION);
			strcpy(bySelectedLanguage, pbyLanguage[0]);
			SetLanguage(bySelectedLanguage);
		}
	}
	else
		SetLanguage(bySelectedLanguage);

	// First check the DirectX version:
	switch(dwDXVersion)
	{
		case 0x000: strResult = _T(T_NoDirectX); bError = TRUE; break;
		case 0x100:
		case 0x200:
		case 0x300:
		case 0x500:
		case 0x600:
		case 0x601:
		case 0x700:
			strResult = _T(T_WrongDirectXVersion); bError = TRUE; break;
		break;
	}
	if(bError)
		MessageBox(NULL, strResult, T_DirectXVersion, MB_OK | MB_ICONINFORMATION);
	
	// Open loader dialog:
	DialogBox(hInstance, MAKEINTRESOURCE(IDD_LOADER), NULL, (DLGPROC) LoaderProc);

  	// Set down program:
	DestroyLanguage();
	delete pbyProgramPath;
	delete pbyProgramExeName;
	delete pbyProgramDrive;
	delete pbyProgramDir;
	delete pbyLanguagesFile;
	delete pbyConfigFile;
	
	return 0;
} // end WinMain()


LRESULT CALLBACK LoaderProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin LoaderProc()
    char byTemp[256], byTemp2[512];
	POINT MousePos;
	FILE *pFile;
	long iX, iY;
	RECT Rect;
	
	switch(iMessage)
    {
        case WM_INITDIALOG:
			hWndLoader = hWnd;
			
			// Load config:
			sprintf(byTemp2, "%sBlibsLoader.ini", pbyProgramPath);
			GetPrivateProfileString("general", "parameters", "", byTemp, MAX_PATH, byTemp2);
			SetDlgItemText(hWnd, ID_PARAMETERS, byTemp);

			SetLoaderTexts();
			UpdateWindow(hWnd);
		return TRUE;

		case WM_LBUTTONDOWN:
			bMoveLoader = TRUE;
			GetCursorPos(&MousePos);
			memcpy(&LastMousePos, &MousePos, sizeof(POINT));
		break;

		case WM_LBUTTONUP: bMoveLoader = FALSE; break;
		
		case WM_MOUSEMOVE:
			if(!bMoveLoader)
				break;
			GetCursorPos(&MousePos);
			GetWindowRect(hWnd, &Rect);
			// Check if the mouse is in the loader area:
			if(MousePos.x > Rect.left &&
			   MousePos.x < Rect.right &&
			   MousePos.y > Rect.top &&
			   MousePos.y < Rect.bottom)
			{ // Yea, we are inside:
				iX = MousePos.x-LastMousePos.x;
				iY = MousePos.y-LastMousePos.y;
				memcpy(&LastMousePos, &MousePos, sizeof(POINT));
				SetWindowPos(hWnd, HWND_NOTOPMOST,
							 Rect.left+iX, Rect.top+iY,
							 Rect.right-Rect.left, Rect.bottom-Rect.top, 0);
			}
		break;

		case WM_COMMAND:
            switch(LOWORD(wParam))
            {				
				case ID_PLAY:
					sprintf(byTemp, "%sBlibs.exe", pbyProgramPath);
					sprintf(byTemp2, "-game %s", byParameters);
					ShellExecute(0, "open", byTemp, byTemp2, 0, SW_SHOW);
					SendMessage(hWnd, WM_CLOSE, 0, 0);
				break;

				case ID_EDITOR:
					sprintf(byTemp, "%sBlibs.exe", pbyProgramPath);
					sprintf(byTemp2, "-editor %s", byParameters);
					ShellExecute(0, "open", byTemp, byTemp2, 0, SW_SHOW);
					SendMessage(hWnd, WM_CLOSE, 0, 0);
				break;

				case ID_CONFIG:
					sprintf(byTemp, "%sBlibs.exe", pbyProgramPath);
					sprintf(byTemp2, "-onlyconfig -loader %s", byParameters);
					ShellExecute(0, "open", byTemp, byTemp2, 0, SW_SHOW);
					hWndLoader = NULL;
					EndDialog(hWnd, FALSE);
				break;

				case ID_HELP_:
					sprintf(byTemp, "%s%s", pbyProgramPath, T_HelpFile);
					ShellExecute(0, "open", byTemp, 0, 0, SW_SHOW);
				break;

				case ID_EXIT:
					SendMessage(hWnd, WM_CLOSE, 0, 0);
				break;
				
				case ID_PARAMETERS:
					GetDlgItemText(hWnd, ID_PARAMETERS, byParameters, 256);
				break;

				case ID_ABLAZESPACE:
					ShellExecute(0, "open", "http://www.ablazespace.de/", 0, 0, SW_SHOW);
				break;
            }
        break;

		case WM_CLOSE:
			// Save config:
			sprintf(byTemp2, "%sBlibsLoader.ini", pbyProgramPath);
			pFile = fopen(byTemp2, "wt");
			if(pFile)
			{
				fprintf(pFile, "[general]\n");
				GetDlgItemText(hWnd, ID_PARAMETERS, byTemp, 256);
				fprintf(pFile, "parameters=%s\n", byTemp);
				fclose(pFile);
			}

			hWndLoader = NULL;
			EndDialog(hWnd, FALSE);
		break;
    }
    return FALSE;
} // end LoaderProc()


//-----------------------------------------------------------------------------
// Name: GetDXVersion()
// Desc: This function returns the DirectX version number as follows:
//          0x0000 = No DirectX installed
//          0x0100 = DirectX version 1 installed
//          0x0200 = DirectX 2 installed
//          0x0300 = DirectX 3 installed
//          0x0500 = At least DirectX 5 installed.
//          0x0600 = At least DirectX 6 installed.
//          0x0601 = At least DirectX 6.1 installed.
//          0x0700 = At least DirectX 7 installed.
//          0x0800 = At least DirectX 8 installed.
// 
//       Please note that this code is intended as a general guideline. Your
//       app will probably be able to simply query for functionality (via
//       QueryInterface) for one or two components.
//
//       Please also note:
//          "if( dwDXVersion != 0x500 ) return FALSE;" is VERY BAD. 
//          "if( dwDXVersion <  0x500 ) return FALSE;" is MUCH BETTER.
//       to ensure your app will run on future releases of DirectX.
//-----------------------------------------------------------------------------
DWORD GetDXVersion(void)
{ // begin GetDXVersion()
    DIRECTDRAWCREATE     DirectDrawCreate   = NULL;
    DIRECTDRAWCREATEEX   DirectDrawCreateEx = NULL;
    DIRECTINPUTCREATE    DirectInputCreate  = NULL;
    HINSTANCE            hDDrawDLL          = NULL;
    HINSTANCE            hDInputDLL         = NULL;
    HINSTANCE            hD3D8DLL           = NULL;
    LPDIRECTDRAW         pDDraw             = NULL;
    LPDIRECTDRAW2        pDDraw2            = NULL;
    LPDIRECTDRAWSURFACE  pSurf              = NULL;
    LPDIRECTDRAWSURFACE3 pSurf3             = NULL;
    LPDIRECTDRAWSURFACE4 pSurf4             = NULL;
    DWORD                dwDXVersion        = 0;
    HRESULT              hr;

    // First see if DDRAW.DLL even exists.
    hDDrawDLL = LoadLibrary( "DDRAW.DLL" );
    if( hDDrawDLL == NULL )
    {
        dwDXVersion = 0;
        return dwDXVersion;
    }

    // See if we can create the DirectDraw object.
    DirectDrawCreate = (DIRECTDRAWCREATE)GetProcAddress( hDDrawDLL, "DirectDrawCreate" );
    if( DirectDrawCreate == NULL )
    {
        dwDXVersion = 0;
        FreeLibrary( hDDrawDLL );
        OutputDebugString( "Couldn't LoadLibrary DDraw\r\n" );
        return dwDXVersion;
    }

    hr = DirectDrawCreate( NULL, &pDDraw, NULL );
    if( FAILED(hr) )
    {
        dwDXVersion = 0;
        FreeLibrary( hDDrawDLL );
        OutputDebugString( "Couldn't create DDraw\r\n" );
        return dwDXVersion;
    }

    // So DirectDraw exists.  We are at least DX1.
    dwDXVersion = 0x100;

    // Let's see if IID_IDirectDraw2 exists.
    hr = pDDraw->QueryInterface( IID_IDirectDraw2, (VOID**)&pDDraw2 );
    if( FAILED(hr) )
    {
        // No IDirectDraw2 exists... must be DX1
        pDDraw->Release();
        FreeLibrary( hDDrawDLL );
        OutputDebugString( "Couldn't QI DDraw2\r\n" );
        return dwDXVersion;
    }

    // IDirectDraw2 exists. We must be at least DX2
    pDDraw2->Release();
    dwDXVersion = 0x200;


	//-------------------------------------------------------------------------
    // DirectX 3.0 Checks
	//-------------------------------------------------------------------------

    // DirectInput was added for DX3
    hDInputDLL = LoadLibrary( "DINPUT.DLL" );
    if( hDInputDLL == NULL )
    {
        // No DInput... must not be DX3
        OutputDebugString( "Couldn't LoadLibrary DInput\r\n" );
        pDDraw->Release();
        return dwDXVersion;
    }

    DirectInputCreate = (DIRECTINPUTCREATE)GetProcAddress( hDInputDLL,
                                                        "DirectInputCreateA" );
    if( DirectInputCreate == NULL )
    {
        // No DInput... must be DX2
        FreeLibrary( hDInputDLL );
        FreeLibrary( hDDrawDLL );
        pDDraw->Release();
        OutputDebugString( "Couldn't GetProcAddress DInputCreate\r\n" );
        return dwDXVersion;
    }

    // DirectInputCreate exists. We are at least DX3
    dwDXVersion = 0x300;
    FreeLibrary( hDInputDLL );

    // Can do checks for 3a vs 3b here


	//-------------------------------------------------------------------------
    // DirectX 5.0 Checks
	//-------------------------------------------------------------------------

    // We can tell if DX5 is present by checking for the existence of
    // IDirectDrawSurface3. First, we need a surface to QI off of.
    DDSURFACEDESC ddsd;
    ZeroMemory( &ddsd, sizeof(ddsd) );
    ddsd.dwSize         = sizeof(ddsd);
    ddsd.dwFlags        = DDSD_CAPS;
    ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE;

    hr = pDDraw->SetCooperativeLevel( NULL, DDSCL_NORMAL );
    if( FAILED(hr) )
    {
        // Failure. This means DDraw isn't properly installed.
        pDDraw->Release();
        FreeLibrary( hDDrawDLL );
        dwDXVersion = 0;
        OutputDebugString( "Couldn't Set coop level\r\n" );
        return dwDXVersion;
    }

    hr = pDDraw->CreateSurface( &ddsd, &pSurf, NULL );
    if( FAILED(hr) )
    {
        // Failure. This means DDraw isn't properly installed.
        pDDraw->Release();
        FreeLibrary( hDDrawDLL );
        dwDXVersion = 0;
        OutputDebugString( "Couldn't CreateSurface\r\n" );
        return dwDXVersion;
    }

    // Query for the IDirectDrawSurface3 interface
    if( FAILED( pSurf->QueryInterface( IID_IDirectDrawSurface3,
                                       (VOID**)&pSurf3 ) ) )
    {
        pDDraw->Release();
        FreeLibrary( hDDrawDLL );
        return dwDXVersion;
    }

    // QI for IDirectDrawSurface3 succeeded. We must be at least DX5
    dwDXVersion = 0x500;


	//-------------------------------------------------------------------------
    // DirectX 6.0 Checks
	//-------------------------------------------------------------------------

    // The IDirectDrawSurface4 interface was introduced with DX 6.0
    if( FAILED( pSurf->QueryInterface( IID_IDirectDrawSurface4,
                                       (VOID**)&pSurf4 ) ) )
    {
        pDDraw->Release();
        FreeLibrary( hDDrawDLL );
        return dwDXVersion;
    }

    // IDirectDrawSurface4 was create successfully. We must be at least DX6
    dwDXVersion = 0x600;
    pSurf->Release();
    pDDraw->Release();


	//-------------------------------------------------------------------------
    // DirectX 6.1 Checks
	//-------------------------------------------------------------------------

    // Check for DMusic, which was introduced with DX6.1
    LPDIRECTMUSIC pDMusic = NULL;
    CoInitialize( NULL );
    hr = CoCreateInstance( CLSID_DirectMusic, NULL, CLSCTX_INPROC_SERVER,
                           IID_IDirectMusic, (VOID**)&pDMusic );
    if( FAILED(hr) )
    {
        OutputDebugString( "Couldn't create CLSID_DirectMusic\r\n" );
        FreeLibrary( hDDrawDLL );
        return dwDXVersion;
    }

    // DirectMusic was created successfully. We must be at least DX6.1
    dwDXVersion = 0x601;
    pDMusic->Release();
    CoUninitialize();
    

	//-------------------------------------------------------------------------
    // DirectX 7.0 Checks
	//-------------------------------------------------------------------------

    // Check for DirectX 7 by creating a DDraw7 object
    LPDIRECTDRAW7 pDD7;
    DirectDrawCreateEx = (DIRECTDRAWCREATEEX)GetProcAddress( hDDrawDLL,
                                                       "DirectDrawCreateEx" );
    if( NULL == DirectDrawCreateEx )
    {
        FreeLibrary( hDDrawDLL );
        return dwDXVersion;
    }

    if( FAILED( DirectDrawCreateEx( NULL, (VOID**)&pDD7, IID_IDirectDraw7,
                                    NULL ) ) )
    {
        FreeLibrary( hDDrawDLL );
        return dwDXVersion;
    }

    // DDraw7 was created successfully. We must be at least DX7.0
    dwDXVersion = 0x700;
    pDD7->Release();


	//-------------------------------------------------------------------------
    // DirectX 8.0 Checks
	//-------------------------------------------------------------------------

    // Simply see if D3D8.dll exists.
    hD3D8DLL = LoadLibrary( "D3D8.DLL" );
    if( hD3D8DLL == NULL )
    {
	    FreeLibrary( hDDrawDLL );
        return dwDXVersion;
    }

    // D3D8.dll exists. We must be at least DX8.0
    dwDXVersion = 0x800;


	//-------------------------------------------------------------------------
    // End of checking for versions of DirectX 
	//-------------------------------------------------------------------------

    // Close open libraries and return
    FreeLibrary( hDDrawDLL );
    FreeLibrary( hD3D8DLL );
    
    return dwDXVersion;
} // end GetDXVersion()

void EnumerateLanguages(void)
{ // begin EnumerateLanguages()
	WIN32_FIND_DATA FindFileData;
    short i;
	char byTemp[256];
	HANDLE Find;
	                   
	if(pbyLanguage)
	{
		for(i = 0; i < iLanguages; i++)
			free(pbyLanguage[i]);
		free(pbyLanguage);
	}
	iLanguages = 0;
	sprintf(byTemp, "%s%s\\*.*", pbyProgramPath, pbyLanguagesFile);
	Find = FindFirstFile(byTemp, &FindFileData);
	for(;;)
	{
		if(FindFileData.cFileName[0] != '.' &&
		   (FindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == FILE_ATTRIBUTE_DIRECTORY)
		{ // We found a dictory:
			iLanguages++;
			pbyLanguage = (char **) realloc(pbyLanguage, sizeof(char **)*iLanguages);
			pbyLanguage[iLanguages-1] = new char[strlen(FindFileData.cFileName)+1];
			strcpy(pbyLanguage[iLanguages-1], FindFileData.cFileName);
		}
		if(!FindNextFile(Find, &FindFileData))
			break;
	}
	FindClose(Find);
} // end EnumerateLanguages()

void SetLanguage(char *pbyToLanguage)
{ // begin SetLanguage()
    short i;
	char byFile[256], byTemp[256];

	DestroyLanguage();
	sprintf(byFile, "%s%s\\%s\\loader.txt", pbyProgramPath, pbyLanguagesFile, pbyToLanguage);
	GetPrivateProfileString("help", "file", "", byTemp, MAX_PATH, byFile);
	pbyText[0] = (char *) malloc(strlen(byTemp)+1);
	strcpy(pbyText[0], byTemp);
	// Load all texts:
	for(i = 1; i < TEXTS; i++)
	{
		sprintf(byTemp, "%d", i-1);
		GetPrivateProfileString("general", byTemp, "", byTemp, MAX_PATH, byFile);
		pbyText[i] = (char *) malloc(strlen(byTemp)+1);
		strcpy(pbyText[i], byTemp);
	}
	// Load all messages:
	for(i = 0; i < MESSAGES; i++)
	{
		sprintf(byTemp, "%d", i);
		GetPrivateProfileString("messages", byTemp, "", byTemp, MAX_PATH, byFile);
		pbyMessage[i] = (char *) malloc(strlen(byTemp)+1);
		strcpy(pbyMessage[i], byTemp);
	}

	
	// Here are all pointers to the texts:
	T_HelpFile = pbyText[0],
	T_Play = pbyText[1],
	T_Editor = pbyText[2],
	T_Config = pbyText[3],
	T_Help = pbyText[4],
	T_Exit = pbyText[5],
	T_BlibsLoader = pbyText[6],
	T_NoDirectX = pbyText[7],
	T_DirectXVersion = pbyText[8],
	T_WrongDirectXVersion = pbyText[9],

	// Pointer to messages:	
	M_TheProgramIsAlreadyRunning = pbyMessage[0],


	// Update the dialog:
	SetLoaderTexts();
} // end SetLanguage()

void DestroyLanguage(void)
{ // begin DestroyLanguage()
	for(short i = 0; i < TEXTS; i++)
		SAFE_DELETE(pbyText[i]);
	for(i = 0; i < MESSAGES; i++)
		SAFE_DELETE(pbyMessage[i]);
} // end DestroyLanguage()

void SetLoaderTexts(void)
{ // begin SetLoaderTexts()
	if(!hWndLoader)
		return;
	SetDlgItemText(hWndLoader, IDC_LOADER,  T_BlibsLoader);
	SetDlgItemText(hWndLoader, ID_PLAY, T_Play);
	SetDlgItemText(hWndLoader, ID_EDITOR, T_Editor);
	SetDlgItemText(hWndLoader, ID_CONFIG, T_Config);
	SetDlgItemText(hWndLoader, ID_HELP_, T_Help);
	SetDlgItemText(hWndLoader, ID_EXIT, T_Exit);
} // end SetLoaderTexts()
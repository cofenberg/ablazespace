//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Resource.rc
//
#define IDD_LOADER                      101
#define IDI_ICON                        105
#define ID_PLAY                         1001
#define ID_ABLAZESPACE                  1002
#define ID_EDITOR                       1004
#define ID_CONFIG                       1005
#define ID_PARAMETERS                   1007
#define IDC_LOADER                      1013
#define ID_HELP_                        1014
#define ID_EXIT                         57671

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

//-----------------------------------------------------------------------------
// File: EditorMenu.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
HWND hWndEditor,				 // The editor window handle
	 hWndEditorTab[EDITOR_TABS], // The tab handles
	 hWndKeyword;				 // The keyword dialog handle
int iCurrentEditorTab;		 // The current selected tab
char byKeyword[256];			 // The level keyword (temp)
BOOL bAlreadySaved = FALSE;
FIELD *pFieldLast = NULL;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern HRESULT EditorDraw(void);
extern HRESULT EditorCheck(void);
LRESULT CALLBACK EditorProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditorSelectProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditorBrushProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditorSurfacesProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditorObjectsProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditorTerrainProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditorEnvironmentProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditorCameraProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditorDecorationProc(HWND, UINT, WPARAM, LPARAM);
void SetupEditorTabs(void);
void SetEditorLanguage(void);
LRESULT CALLBACK KeywordProc(HWND, UINT, WPARAM, LPARAM);
void KeywordLanguage(void);
HRESULT SaveLevelQuestion(void);
LRESULT CALLBACK SetCameraVelocityProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK CopyCameraStepProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK SetCameraStepsProc(HWND, UINT, WPARAM, LPARAM);
void FillItemListElement(HWND, int);
///////////////////////////////////////////////////////////////////////////////


LRESULT CALLBACK EditorProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorProc()
	char *pbyTemp, byTemp[256];
	RECT Rect1, Rect2;
	BOOL bKeyword;
	int i;

    switch(iMessage)
    {
        case WM_INITDIALOG:
			_AS->bDraw = FALSE;
			if(!hWndEditor)
				iCurrentEditorTab = -1;
			iCurrentDecorationModel = -1;
			hWndEditor = hWnd;
			bPlayerCameraView = bAdvancedTerrainManipulation = FALSE;

			// Set the last editor window size:
			if(_ASConfig->EditorWindow.left < 0)
			{
				_ASConfig->EditorWindow.right += -_ASConfig->EditorWindow.left;
				_ASConfig->EditorWindow.left = 0;
			}
			if(_ASConfig->EditorWindow.top < 0)
			{
				_ASConfig->EditorWindow.bottom += -_ASConfig->EditorWindow.top;
				_ASConfig->EditorWindow.top = 0;
			}
			SetWindowPos(hWndEditor, HWND_BOTTOM, _ASConfig->EditorWindow.left, _ASConfig->EditorWindow.top,
						 _ASConfig->EditorWindow.right-_ASConfig->EditorWindow.left,
						 _ASConfig->EditorWindow.bottom-_ASConfig->EditorWindow.top, 0);

			// Setup the level show area:
			hWndEditorShow = GetDlgItem(hWnd, IDC_EDITOR_LEVEL);
			ASInitOpenGL(NULL, hWndEditorShow, &hDCEditorShow, &hRCEditorShow, FALSE);
			GetWindowRect(hWndEditor, &Rect1);
			GetWindowRect(hWndEditorShow, &Rect2);
			SetWindowPos(hWndEditorShow, HWND_NOTOPMOST, Rect2.left, Rect2.top, Rect1.right-Rect2.left-10, Rect1.bottom-Rect2.top-10, 0);
			GetWindowRect(hWndEditorShow, &Rect2);
			wglMakeCurrent(hDCEditorShow, hRCEditorShow);
			ASConfigOpenGL(Rect2.right-Rect2.left, Rect2.bottom-Rect2.top);
			SendMessage(hWnd, WM_SIZE, 0, 0);
			ASBuildFont();

			_AS->CreateDXInputDevices(hWnd, FALSE, TRUE, TRUE, FALSE);
			SetTimer(hWnd, 1, 1, NULL);
					
			// Init editor brush sizes: (6 possible sizes) 
			sprintf(byTemp, "1x1");
			SendDlgItemMessage(hWnd, IDC_EDITOR_SIZE, LB_ADDSTRING, 0, (LONG)(LPSTR) byTemp);
			sprintf(byTemp, "2x2");
			SendDlgItemMessage(hWnd, IDC_EDITOR_SIZE, LB_ADDSTRING, 0, (LONG)(LPSTR) byTemp);
			for(i = 1; i < 5; i++)
			{
				sprintf(byTemp, "%dx%d", i*2+1, i*2+1);
				SendDlgItemMessage(hWnd, IDC_EDITOR_SIZE, LB_ADDSTRING, 0, (LONG)(LPSTR) byTemp);
			}
 			byEditorBrushSize = 0;
			SendDlgItemMessage(hWnd, IDC_EDITOR_SIZE, LB_SETCURSEL, byEditorBrushSize, 0L);
			
			ASGenOpenGLTextures(GAME_TEXTURES, GameTexture);
			CreateGameLists();
			InitGameParticleSystems();
	
			// Setup the current level:
			pLevel = new LEVEL;
			if(bEditorTestLevel)
				pLevel->Load(byCurrentLevelName); // Load the last loaded level
			else
			{
				pLevel->Create(21, 21); // Create a new one
				SetStandartPlayer();
			}
			pLevel->GenTexturesOpenGL(hDCEditorShow, hRCEditorShow);
			LoadRequiredActorTextues(hDCEditorShow, hRCEditorShow, TRUE);
			bEditorTestLevel = FALSE;
			
			// Setup the other stuff:
			lCameraTimer = g_lLastlooptime = g_lNow = GetTickCount();
			SetEditorLanguage();
			TabCtrl_SetCurSel(GetDlgItem(hWnd, IDC_EDITOR_TAB), 0);
			SendMessage(hWnd, WM_NOTIFY, IDC_EDITOR_TAB, 0);
			bCameraAnimation = bPause = bCameraAnimation = FALSE;
			_AS->ShowMouseCursor(TRUE);
			UpdateWindow(hWnd);
			_AS->bDraw = TRUE;
		return TRUE;
		
		case WM_TIMER:
			EditorDraw();
			EditorCheck();
			_AS->UpdateWindows(bPause);
		break;

        case WM_SIZE:
			hWndEditorShow = GetDlgItem(hWnd, IDC_EDITOR_LEVEL);
			GetWindowRect(hWndEditor, &Rect1);
			GetWindowRect(hWndEditorShow, &Rect2);
			SetWindowPos(hWndEditorShow, NULL, Rect2.left, Rect2.top, Rect1.right-Rect2.left-10, Rect1.bottom-Rect2.top-10, SWP_NOMOVE);
			GetWindowRect(hWndEditorShow, &Rect2);
			wglMakeCurrent(hDCEditorShow, hRCEditorShow);
			ASConfigOpenGL(Rect2.right-Rect2.left, Rect2.bottom-Rect2.top);
		break;

		case WM_COMMAND:
            switch(LOWORD(wParam))
            {				
				case ID_EDITOR_GENERAL_TEXTURES:
					KillTimer(hWnd, 1);
					DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_TEXTURES), hWnd, (DLGPROC) TexturesProc);
					SetTimer(hWnd, 1, 1, NULL);
					ASInitOpenGL(NULL, hWndEditorShow, &hDCEditorShow, &hRCEditorShow, FALSE);
				break;
				
				case ID_EDITOR_GENERAL_CAMPAIGN_EDITOR:
					KillTimer(hWnd, 1);
					DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CAMPAIGN_EDITOR), hWnd, (DLGPROC) CampaignEditorProc);
					SetTimer(hWnd, 1, 1, NULL);
				break;

				case ID_EDITOR_GENERAL_TEXT_SCRIPT_EDITOR:
					KillTimer(hWnd, 1);
					OpenTSE(hWnd);
					SetTimer(hWnd, 1, 1, NULL);
				break;

				case IDC_EDITOR_SIZE:
   					byEditorBrushSize = (char) SendDlgItemMessage(hWnd, IDC_EDITOR_SIZE, LB_GETCURSEL, 0, 0L);
				break;

				case IDC_EDITOR_PAUSE: bPause = !bPause; break;

			// Menu:
				case ID_EDITOR_GENERAL_GAME:
					_AS->SetNextModule(MODULE_GAME);
					SendMessage(hWndEditor, WM_CLOSE, 0, 0);
				break;

				case ID_EDITOR_GENERAL_QUIT:
					_AS->SetShutDown(TRUE);
					SendMessage(hWndEditor, WM_CLOSE, 0, 0);
				break;

				case ID_LEVEL_NEW:
					if(SaveLevelQuestion())
						break;
					KillTimer(hWnd, 1);
					NewLevelDialog();
					SetTimer(hWnd, 1, 1, NULL);
					TabCtrl_SetCurSel(GetDlgItem(hWnd, IDC_EDITOR_TAB), 0);
					SendMessage(hWnd, WM_NOTIFY, IDC_EDITOR_TAB, 0);
					iCurrentDecorationModel = -1;
				break;

				case ID_LEVEL_SAVE:
					if(pLevel->Header.byFilename[0] == '\0')
						goto SaveAs;
					if(pLevel->Save(pLevel->Header.byFilename))
					{
						sprintf(byTemp, "%s: %s", pLevel->Header.byFilename, AS_M(M_FileCouldNotSaved));
						KillTimer(hWnd, 1);
						MessageBox(hWnd, byTemp, AS_T(T_Error), MB_OK | MB_ICONINFORMATION);
						SetTimer(hWnd, 1, 1, NULL);
						break;
					}
				break;

				case ID_LEVEL_SAVE_AS:
				SaveAs:
					sprintf(byTemp, "%s%s", _AS->byProgramPath, _AS->bySingleLevelsDirectory);
					KillTimer(hWnd, 1);
					pbyTemp = ASGetFileName(hWnd, AS_T(T_SaveLevel), LEV_FILE, 1, FALSE, byTemp, NULL);
					SetTimer(hWnd, 1, 1, NULL);
					if(!pbyTemp)
						break;
					if(pLevel->Save(pbyTemp))
					{
						sprintf(byTemp, "%s: %s", pbyTemp, AS_M(M_FileCouldNotSaved));
						KillTimer(hWnd, 1);
						MessageBox(hWnd, byTemp, AS_T(T_Error), MB_OK | MB_ICONINFORMATION);
						SetTimer(hWnd, 1, 1, NULL);
						break;
					}
				break;

				case ID_LEVEL_LOAD:
					if(SaveLevelQuestion())
						break;
					sprintf(byTemp, "%s%s", _AS->byProgramPath, _AS->bySingleLevelsDirectory);
					KillTimer(hWnd, 1);
					pbyTemp = ASGetFileName(hWnd, AS_T(T_LoadLevel), LEV_FILE, 0, FALSE, byTemp, NULL);
					SetTimer(hWnd, 1, 1, NULL);
					if(!pbyTemp)
						break;
					bKeyword = GetLevelKeyword(pbyTemp, byKeyword);
					if(bKeyword && !bMasterAccess)
					{ // Check the keyword:
						bKeyword = DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_KEYWORD), hWnd, (DLGPROC) KeywordProc);
						if(!bKeyword)
						{ // Wrong keyword!!
							KillTimer(hWnd, 1);
							MessageBox(hWnd, AS_M(M_WrongKeyword), GAME_NAME, MB_OK | MB_ICONINFORMATION);
							SetTimer(hWnd, 1, 1, NULL);
							break;
						}
						else
							if(bKeyword == -1)
								break;
					}
					bPause = TRUE;
					pLevel->Load(pbyTemp);
					InitGameParticleSystems();
					TabCtrl_SetCurSel(GetDlgItem(hWnd, IDC_EDITOR_TAB), 0);
					SendMessage(hWnd, WM_NOTIFY, IDC_EDITOR_TAB, 0);
					iCurrentDecorationModel = -1;
				break;

				case ID_LEVEL_ADJUST:
					KillTimer(hWnd, 1);
					AdjustLevelDialog();
					SetTimer(hWnd, 1, 1, NULL);
				break;

				case ID_LEVEL_PLAY:
					_AS->WriteLogMessage("Editor: Play current level");
					if(pLevel->Header.byFilename[0] == '\0')
					{
						_AS->WriteLogMessage("Error: The current level has no filename");
						KillTimer(hWnd, 1);
						MessageBox(hWnd, AS_M(M_TheLevelHasNoFilename), AS_T(T_Error), MB_OK | MB_ICONINFORMATION);
						sprintf(byTemp, "%s%s", _AS->byProgramPath, _AS->bySingleLevelsDirectory);
						pbyTemp = ASGetFileName(hWnd, AS_T(T_SaveLevel), LEV_FILE, 1, FALSE, byTemp, NULL);
						SetTimer(hWnd, 1, 1, NULL);
						if(!pbyTemp)
							break;
						strcpy(byTemp, pbyTemp);
					}
					else
						strcpy(byTemp, pLevel->Header.byFilename);
					if(pLevel->Save(byTemp))
					{
						sprintf(byTemp, "%s: %s", byTemp, AS_M(M_FileCouldNotSaved));
						KillTimer(hWnd, 1);
						MessageBox(hWnd, byTemp, AS_T(T_Error), MB_OK | MB_ICONINFORMATION);
						SetTimer(hWnd, 1, 1, NULL);
						break;
					}
					_AS->WriteLogMessage("Save level %s", byTemp);
					bEditorTestLevel = TRUE;
					sprintf(byCurrentLevelName, pLevel->Header.byFilename);
					_AS->SetNextModule(MODULE_GAME);
					bAlreadySaved = TRUE;
					SendMessage(hWndEditor, WM_CLOSE, 0, 0);
				break;
				
			// Options:
				case ID_OPTIONS_CONFIG:
					KillTimer(hWnd, 1);
					OpenConfigDialog(hWnd);
					SetTimer(hWnd, 1, 1, NULL);
				break;

				case ID_OPTIONS_SHOW_LOG:
					_AS->WriteLogMessage("Open Log");
					sprintf(byTemp, "%s"AS_LOG_FILE, _AS->byProgramPath);
					ShellExecute(0, "open", byTemp, 0, 0, SW_SHOW);				
				break;

			// Help:
				case ID_HELP_HELP: OpenHelp(); break;
				case ID_HELP_CREACTIVE_MEDIA_HOMEPAGE: OpenCreactiveMediaHomepage(); break;
				case ID_HELP_ECLYPSE_ENTERTAINMENT_HOMEPAGE: OpenEclypseEntertainmentHomepage(); break;

				case ID_HELP_CREDITS:
					KillTimer(hWnd, 1);
					OpenCreditsDialog(hWnd);
					SetTimer(hWnd, 1, 1, NULL);
				break;
			}
        break;

        case WM_NOTIFY: 
			switch(wParam)
			{
				case IDC_EDITOR_TAB:
					EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_SIZE), TRUE);
					i = TabCtrl_GetCurSel(GetDlgItem(hWnd, IDC_EDITOR_TAB));
					iCurrentEditorTab = i;
					if(iCurrentEditorTab < 0)
						iCurrentEditorTab = 0;
					for(i = 0; i < EDITOR_TABS; i++)
					{
						ShowWindow(hWndEditorTab[i], SW_HIDE);
						UpdateWindow(hWndEditorTab[i]);
					}
					TabCtrl_SetCurSel(GetDlgItem(hWnd, IDC_EDITOR_TAB), iCurrentEditorTab);
					ShowWindow(hWndEditorTab[iCurrentEditorTab], SW_SHOW);
					UpdateWindow(hWndEditorTab[iCurrentEditorTab]);
					UpdateWindow(hWnd);
					SetFocus(hWndEditorTab[iCurrentEditorTab]);
					BringWindowToTop(hWndEditorTab[iCurrentEditorTab]);
					SendMessage(hWndEditorTab[iCurrentEditorTab], WM_INITDIALOG, 0, 0);
				break;
			} 
		break;

		case WM_CLOSE:			
			if(_AS->GetNextModule() != MODULE_GAME)
				_AS->SetShutDown(TRUE); // The game should be closed

			if(!bAlreadySaved && SaveLevelQuestion())
			{ // The user will not close the editor:
				_AS->SetShutDown(FALSE);
				break;
			}
			bAlreadySaved = FALSE;
			_AS->bDraw = FALSE;

			// Kill our editor data:
			ASDestroyOpenGLTextures(GAME_TEXTURES, GameTexture);
			pLevel->DestroyTexturesOpenGL(hDCEditorShow, hRCEditorShow);
			ActorDestroyTexturesOpenGL(hDCEditorShow, hRCEditorShow, TRUE);
			DestroyGameParticleSystems();
			ASKillFont();
			// This makes some trouble if you go to game and switch back to editor...
			if(_AS->GetNextModule() != MODULE_GAME)
				ASDestroyOpenGL(NULL, hWndEditorShow, hDCEditorShow, hRCEditorShow);
			_AS->FreeDXInputDevices();

			// Kill all editor windows:
			GetWindowRect(hWndEditor, &_ASConfig->EditorWindow);
			KillTimer(hWnd, 1);
			for(i = 0; i < EDITOR_TABS; i++)
			{
				DestroyWindow(hWndEditorTab[i]);
				hWndEditorTab[i] = NULL;
			}
			DestroyWindow(hWndEditorShow);
			EndDialog(hWndEditor, FALSE);
			hWndEditor = hWndEditorShow = NULL;
			
			// Kill now our level:
			DestroyLevel(&pLevel);

			// At last save the configuration:	
			sprintf(byTemp, "%s%s", _AS->byProgramPath, _AS->byConfigFilename);
			_ASConfig->Save(byTemp);
		break;
    }

    return FALSE;
} // end EditorProc()

LRESULT CALLBACK EditorSelectProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorSelectProc()
	char byTemp[256];
	FIELD *pFieldT;
	int i;
	
	EnableWindow(GetDlgItem(hWndEditor, IDC_EDITOR_SIZE), FALSE);
	if(!pLevel)
		return 0;
	pFieldT = pLevel->pCurrentField;
	if(pFieldLast != pFieldT)
	{
		pFieldLast = pFieldT;
		goto Init;
	}
	if(!pFieldT)
		return 0;
	switch(iMessage)
    {
        case WM_INITDIALOG:
			byEditorSelected = -1;
			iCurrentEditorSelectTab = 0;

			// Texts:

  		Init:
			SetupEditorSelectTabs();

			sprintf(byTemp, "ID: %d", pFieldT->iID);
			SetDlgItemText(hWnd, IDD_EDITOR_SELECT_FIELD_ID, byTemp);

			sprintf(byTemp, "X: %d", pFieldT->iXField);
			SetDlgItemText(hWnd, IDD_EDITOR_SELECT_FIELD_X_POS, byTemp);

			sprintf(byTemp, "Y: %d", pFieldT->iYField);
			SetDlgItemText(hWnd, IDD_EDITOR_SELECT_FIELD_Y_POS, byTemp);
			
			byEditorMenu = EDITOR_SELECT_MENU;
			BringWindowToTop(hWnd);
		return TRUE;

        case WM_NOTIFY: 
			switch(wParam)
			{
				case IDD_EDITOR_SELECT_TAB:
					i = TabCtrl_GetCurSel(GetDlgItem(hWnd, IDD_EDITOR_SELECT_TAB));
					iCurrentEditorSelectTab = i;
					if(iCurrentEditorSelectTab < 0)
						iCurrentEditorSelectTab = 0;
					for(i = 0; i < EDITOR_SELECT_TABS; i++)
					{
						ShowWindow(hWndEditorSelectTab[i], SW_HIDE);
						UpdateWindow(hWndEditorSelectTab[i]);
					}
					TabCtrl_SetCurSel(GetDlgItem(hWnd, IDD_EDITOR_SELECT_TAB), iCurrentEditorSelectTab);
					ShowWindow(hWndEditorSelectTab[iCurrentEditorSelectTab], SW_SHOW);
					UpdateWindow(hWndEditorSelectTab[iCurrentEditorSelectTab]);
					UpdateWindow(hWnd);
					SetFocus(hWndEditorSelectTab[iCurrentEditorSelectTab]);
					BringWindowToTop(hWndEditorSelectTab[iCurrentEditorSelectTab]);
					SendMessage(hWndEditorSelectTab[iCurrentEditorSelectTab], WM_INITDIALOG, 0, 0);
				break;
			} 
		break;
    }

    return FALSE;
} // end EditorSelectProc()

LRESULT CALLBACK EditorBrushProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorBrushProc()
	if(!pLevel)
		return 0;
	switch(iMessage)
    {
        case WM_INITDIALOG:
  			// Texts:
			SetDlgItemText(hWnd, IDC_EDITOR_BRUSH_WALL, AS_T(T_Wall));
			SetDlgItemText(hWnd, IDC_EDITOR_BRUSH_DEACTIVATE_FIELD, AS_T(T_DeactivateField));
			SetDlgItemText(hWnd, IDC_EDITOR_BRUSH_ACTIVATE_WATER, AS_T(T_ActivateWater));
			SetDlgItemText(hWnd, IDC_EDITOR_BRUSH_WATER_TYPE, AS_T(T_WaterType));
			SetDlgItemText(hWnd, IDC_EDITOR_BRUSH_ACTIVATE_WATER_BUBBLES, AS_T(T_ActivateWaterBubbles));
			SetDlgItemText(hWnd, IDC_EDITOR_BRUSH_FORCE_WATER_BUBBLES, AS_T(T_ForceWaterBubbles));
			SetDlgItemText(hWnd, IDC_EDITOR_BRUSH_CLEAR_FIELD, AS_T(T_ClearField));
			SetDlgItemText(hWnd, IDC_EDITOR_BRUSH_WALL_HOLE, AS_T(T_WallHole));
			SetDlgItemText(hWnd, IDC_EDITOR_BRUSH_ALWAYS_WALL, AS_T(T_AlwaysWall));
			SetDlgItemText(hWnd, IDC_EDITOR_BRUSH_INDESTRUCTIBLE_WALL, AS_T(T_IndestructibleWall));
			SetDlgItemText(hWnd, IDC_EDITOR_BRUSH_NO_BRIDGE_POSSIBLE, AS_T(T_NoBridgePossible));
			//
			byEditorMenu = EDITOR_BRUSH_MENU;
			byEditorSelected = EDITOR_SELECTED_WALL;
			BringWindowToTop(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_EDITOR_BRUSH_WALL: byEditorSelected = EDITOR_SELECTED_WALL; break;
				case IDC_EDITOR_BRUSH_DEACTIVATE_FIELD: byEditorSelected = EDITOR_SELECTED_DEACTIVATE_FIELD; break;
				case IDC_EDITOR_BRUSH_ACTIVATE_WATER: byEditorSelected = EDITOR_SELECTED_ACTIVATE_WATER; break;
				case IDC_EDITOR_BRUSH_WATER_TYPE: byEditorSelected = EDITOR_SELECTED_WATER_TYPE; break;
				case IDC_EDITOR_BRUSH_ACTIVATE_WATER_BUBBLES: byEditorSelected = EDITOR_SELECTED_ACTIVATE_WATER_BUBBLES; break;
				case IDC_EDITOR_BRUSH_FORCE_WATER_BUBBLES: byEditorSelected = EDITOR_SELECTED_FORCE_WATER_BUBBLES; break;
				case IDC_EDITOR_BRUSH_CLEAR_FIELD: byEditorSelected = EDITOR_SELECTED_CLEAR_FIELD; break;
				case IDC_EDITOR_BRUSH_WALL_HOLE: byEditorSelected = EDITOR_SELECTED_WALL_HOLE; break;
				case IDC_EDITOR_BRUSH_ALWAYS_WALL: byEditorSelected = EDITOR_SELECTED_ALWAYS_WALL; break;
				case IDC_EDITOR_BRUSH_INDESTRUCTIBLE_WALL: byEditorSelected = EDITOR_SELECTED_INDESTRUCTIBLE_WALL; break;
				case IDC_EDITOR_BRUSH_NO_BRIDGE_POSSIBLE: byEditorSelected = EDITOR_SELECTED_NO_BRIDGE_POSSIBLE; break;
            }
            break;
    }

    return FALSE;
} // end EditorBrushProc()

LRESULT CALLBACK EditorSurfacesProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorSurfacesProc()
	char byTemp[256];
	
	if(!pLevel)
		return 0;
	switch(iMessage)
    {
        case WM_INITDIALOG:
  			// Texts:
			SetDlgItemText(hWnd, IDC_EDITOR_SURFACES_CHOOSE, AS_T(T_Surface));
			SetDlgItemText(hWnd, IDC_EDITOR_SURFACES_ROTATION_T, AS_T(T_Rotation));
			SetDlgItemText(hWnd, IDC_EDITOR_SURFACES_SURFACE, AS_T(T_Surface));
			SetDlgItemText(hWnd, IDC_EDITOR_SURFACES_SECOND_SURFACE, AS_T(T_SecondSurface));
			SetDlgItemText(hWnd, IDC_EDITOR_SURFACES_REMOVE_SECOND_SURFACE, AS_T(T_RemoveSecondSurface));
			SetDlgItemText(hWnd, IDC_EDITOR_SURFACE_2_SIDES, AS_T(T_2Sides));
			SetDlgItemText(hWnd, IDC_EDITOR_SURFACE_SWAP_SIDES, AS_T(T_SwapSides));
			SetDlgItemText(hWnd, IDC_EDITOR_SURFACE_FLOOR, AS_T(T_Floor));
			SetDlgItemText(hWnd, IDC_EDITOR_SURFACE_FRONT, AS_T(T_Front));
			SetDlgItemText(hWnd, IDC_EDITOR_SURFACE_TOP, AS_T(T_Top));
			SetDlgItemText(hWnd, IDC_EDITOR_SURFACE_RIGHT, AS_T(T_Right));
			SetDlgItemText(hWnd, IDC_EDITOR_SURFACE_BOTTOM, AS_T(T_Bottom));
			SetDlgItemText(hWnd, IDC_EDITOR_SURFACE_LEFT, AS_T(T_Left));
			SetDlgItemText(hWnd, IDC_EDITOR_SURFACE_WATER, AS_T(T_Water));
			SetDlgItemText(hWnd, IDC_EDITOR_SURFACES_ATTRIBUTES_T, AS_T(T_Attributes));
			SetDlgItemText(hWnd, IDC_EDITOR_SURFACE_SET_ONLY_ATTRIBUTES, AS_T(T_SetOnlyAttributes));
			SetDlgItemText(hWnd, IDC_EDITOR_SURFACE_ALWAYS_ACTIVE, AS_T(T_AlwaysActive));
			SetDlgItemText(hWnd, IDC_EDITOR_SURFACE_DISABLE_WATER_SIDE, AS_T(T_DisableWaterSide));
			SetDlgItemText(hWnd, IDC_EDITOR_SURFACE_WALL_SIDE, AS_T(T_Wall));
			SetDlgItemText(hWnd, IDC_EDITOR_SURFACE_INVISIBLE, AS_T(T_Invisible));
			byEditorMenu = EDITOR_SURFACE_MENU;
			iEditorRotate = 0;
			//
		Init:
			switch(iEditorCurrentSurfaceType)
			{
				case 0: CheckRadioButton(hWnd, IDC_EDITOR_SURFACES_SURFACE, IDC_EDITOR_SURFACES_REMOVE_SECOND_SURFACE, IDC_EDITOR_SURFACES_SURFACE); break;
				case 1: CheckRadioButton(hWnd, IDC_EDITOR_SURFACES_SURFACE, IDC_EDITOR_SURFACES_REMOVE_SECOND_SURFACE, IDC_EDITOR_SURFACES_SECOND_SURFACE); break;
				case 2: CheckRadioButton(hWnd, IDC_EDITOR_SURFACES_SURFACE, IDC_EDITOR_SURFACES_REMOVE_SECOND_SURFACE, IDC_EDITOR_SURFACES_REMOVE_SECOND_SURFACE); break;
			}	

			sprintf(byTemp, "%d�", iEditorRotate*90);
			SetDlgItemText(hWnd, IDC_EDITOR_SURFACES_ROTATION, byTemp);
			BringWindowToTop(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_EDITOR_SURFACES_CHOOSE:
					DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_SURFACES), hWnd, (DLGPROC) SurfacesProc);
					ASInitOpenGL(NULL, hWndEditorShow, &hDCEditorShow, &hRCEditorShow, FALSE);
				break;

				case IDC_EDITOR_SURFACES_PLUS:
					iEditorRotate++;
					if(iEditorRotate > 3)
						iEditorRotate = 0;
					goto Init;

				case IDC_EDITOR_SURFACES_MINUS:
					iEditorRotate--;
					if(iEditorRotate < 0)
						iEditorRotate = 3;
					goto Init;
		
				case IDC_EDITOR_SURFACES_SURFACE:
				case IDC_EDITOR_SURFACES_SECOND_SURFACE:
				case IDC_EDITOR_SURFACES_REMOVE_SECOND_SURFACE:
					if(IsDlgButtonChecked(hWnd, IDC_EDITOR_SURFACES_SURFACE))
						iEditorCurrentSurfaceType = 0;
					if(IsDlgButtonChecked(hWnd, IDC_EDITOR_SURFACES_SECOND_SURFACE))
						iEditorCurrentSurfaceType = 1;
					if(IsDlgButtonChecked(hWnd, IDC_EDITOR_SURFACES_REMOVE_SECOND_SURFACE))
						iEditorCurrentSurfaceType = 2;
				break;
            }
            break;
    }

    return FALSE;
} // end EditorSurfacesProc()

LRESULT CALLBACK EditorObjectsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorObjectsProc()
	char byTemp[256], bySelecedSide;
	int i, iRotT;

	if(!pLevel)
		return FALSE;
	switch(iMessage)
    {
        case WM_INITDIALOG:
  			// Texts:
			SetDlgItemText(hWnd, IDC_EDITOR_OBJECTS_ROTATION_T, AS_T(T_Rotation));
			SetDlgItemText(hWnd, IDC_EDITOR_OBJECTS_NUMBER_T, AS_T(T_Number));
			SetDlgItemText(hWnd, IDD_EDITOR_OBJECTS_OBJECTS_T, AS_T(T_Objects));
			SetDlgItemText(hWnd, IDD_EDITOR_OBJECTS_ENEMIES_T, AS_T(T_Enemies));
			SetDlgItemText(hWnd, IDD_EDITOR_OBJECTS_ITEMS_T, AS_T(T_Items));
			SetDlgItemText(hWnd, IDD_EDITOR_OBJECTS_BOX_SURFACES_T, AS_T(T_BoxSurfaces));
			SetDlgItemText(hWnd, IDD_EDITOR_OBJECTS_BOX_SURFACE_ROTATION_T, AS_T(T_SurfaceRotation));
			SetDlgItemText(hWnd, IDD_EDITOR_OBJECTS_BOX_SURFACE_ALL, AS_T(T_All));
			SetDlgItemText(hWnd, IDD_EDITOR_OBJECTS_BOX_ENVIRONMENT, AS_T(T_Environment));
			
			byEditorSelected = -1;
			iEditorRotate = 0;
			//

			// Box sides:
			SendDlgItemMessage(hWnd, IDD_EDITOR_OBJECTS_BOX_SIDE, CB_RESETCONTENT, 0, 0L);
			SendDlgItemMessage(hWnd, IDD_EDITOR_OBJECTS_BOX_SIDE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Floor));
			SendDlgItemMessage(hWnd, IDD_EDITOR_OBJECTS_BOX_SIDE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Top));
			SendDlgItemMessage(hWnd, IDD_EDITOR_OBJECTS_BOX_SIDE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Left));
			SendDlgItemMessage(hWnd, IDD_EDITOR_OBJECTS_BOX_SIDE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Right));
			SendDlgItemMessage(hWnd, IDD_EDITOR_OBJECTS_BOX_SIDE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Bottom));
			SendDlgItemMessage(hWnd, IDD_EDITOR_OBJECTS_BOX_SIDE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Front));
			SendDlgItemMessage(hWnd, IDD_EDITOR_OBJECTS_BOX_SIDE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Environment));
			SendDlgItemMessage(hWnd, IDD_EDITOR_OBJECTS_BOX_SIDE, CB_SETCURSEL, 0, 0L);

		Init:
			if(pLevel->Header.iBoxSurface[6] == -1)
				SendDlgItemMessage(hWnd, IDD_EDITOR_OBJECTS_BOX_ENVIRONMENT, BM_SETCHECK, FALSE, 0L);
			else
				SendDlgItemMessage(hWnd, IDD_EDITOR_OBJECTS_BOX_ENVIRONMENT, BM_SETCHECK, TRUE, 0L);
			
			// Objects list:
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_RESETCONTENT , 0, 0L);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_SETITEMDATA, SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) "Blibs"), 0);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_SETITEMDATA, SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) AS_T(T_BlibsClone)), 1);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_SETITEMDATA, SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) AS_T(T_BoxNormal)), 2);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_SETITEMDATA, SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) AS_T(T_BoxRed)), 3);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_SETITEMDATA, SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) AS_T(T_BoxGreen)), 4);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_SETITEMDATA, SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) AS_T(T_BoxBlue)), 5);

			// Items list:
			FillItemListElement(hWnd, IDC_EDITOR_OBJECTS_ITEMS_LIST);

			// Enemies list:
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_ENEMIES_LIST, CB_RESETCONTENT , 0, 0L);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_ENEMIES_LIST, CB_ADDSTRING, 0, (LPARAM) "Mobmob");
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_ENEMIES_LIST, CB_ADDSTRING, 0, (LPARAM) "X3");
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_ENEMIES_LIST, CB_ADDSTRING, 0, (LPARAM) "Lucifer-Head");
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_ENEMIES_LIST, CB_ADDSTRING, 0, (LPARAM) "Lucifer");

			// Rotation:
			sprintf(byTemp, "%d�", iEditorRotate*90);
			SetDlgItemText(hWnd, IDC_EDITOR_OBJECTS_ROTATION, byTemp);

			// Number:
			sprintf(byTemp, "%d", iEditorObjectsNumber);
			SetDlgItemText(hWnd, IDC_EDITOR_OBJECTS_NUMBER, byTemp);

			// Box:
			SetDlgItemText(hWnd, IDD_EDITOR_OBJECTS_BOX_SURFACE_ROTATION_T, AS_T(T_Box));
			SetDlgItemText(hWnd, IDD_EDITOR_OBJECTS_BOX_SURFACE_ROTATION_T, AS_T(T_Rotation));
			sprintf(byTemp, "%d", pLevel->Header.byBoxSurfaceRot[0]*90);
			SetDlgItemText(hWnd, IDD_EDITOR_OBJECTS_BOX_SURFACE_ROTATION, byTemp);

			// Box surfaces:
			bySelecedSide = (int) SendDlgItemMessage(hWnd, IDD_EDITOR_OBJECTS_BOX_SIDE, CB_GETCURSEL, 0, 0L);
			if(bySelecedSide == -1 || bySelecedSide > 6)
				break;
			if(bySelecedSide == 6)
			{
				EnableWindow(GetDlgItem(hWnd, IDD_EDITOR_OBJECTS_BOX_SIDE_SURFACE), SendDlgItemMessage(hWnd, IDD_EDITOR_OBJECTS_BOX_ENVIRONMENT, BM_GETCHECK, 0, 0L));
				ShowWindow(GetDlgItem(hWnd, IDD_EDITOR_OBJECTS_BOX_ENVIRONMENT), SW_SHOW);
			}
			else
			{
				ShowWindow(GetDlgItem(hWnd, IDD_EDITOR_OBJECTS_BOX_ENVIRONMENT), SW_HIDE);
				EnableWindow(GetDlgItem(hWnd, IDD_EDITOR_OBJECTS_BOX_SIDE_SURFACE), TRUE);
			}
			SendDlgItemMessage(hWnd, IDD_EDITOR_OBJECTS_BOX_SIDE_SURFACE, CB_RESETCONTENT, 0, 0L);
			for(i = 0; i < pLevel->Header.iSurfaces; i++)
			{
				sprintf(byTemp, "%s", pLevel->pSurface[i].Header.byName, pLevel->pSurface[i].iUsed);
				SendDlgItemMessage(hWnd, IDD_EDITOR_OBJECTS_BOX_SIDE_SURFACE, CB_ADDSTRING, 0, (LPARAM) byTemp);
			}
			SendDlgItemMessage(hWnd, IDD_EDITOR_OBJECTS_BOX_SIDE_SURFACE, CB_SETCURSEL, pLevel->Header.iBoxSurface[bySelecedSide], 0L);

			byEditorMenu = EDITOR_OBJECT_MENU;
			BringWindowToTop(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_EDITOR_OBJECTS_LIST:
					i = (int) SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_GETCURSEL, 0, 0L);
					i = (int) SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_GETITEMDATA, i, 0L);
					if(i < 0)
						i = 0;
					if(i > 5)
						i = 5;
					switch(i)
					{
						case 0:
							byEditorSelected = EDITOR_SELECTED_OBJECT_BLIBS;
							iEditorObjectsNumber = 1;
						break;

						case 1:
							byEditorSelected = EDITOR_SELECTED_OBJECT_BLIBS_CLONE;
							iEditorObjectsNumber = 1;
						break;
						
						case 2:
							byEditorSelected = EDITOR_SELECTED_OBJECT_BOX_NORMAL;
							iEditorObjectsNumber = 1;
						break;
						
						case 3:
							byEditorSelected = EDITOR_SELECTED_OBJECT_BOX_RED;
							iEditorObjectsNumber = 1;
						break;
						
						case 4:
							byEditorSelected = EDITOR_SELECTED_OBJECT_BOX_GREEN;
							iEditorObjectsNumber = 1;
						break;
						
						case 5:
							byEditorSelected = EDITOR_SELECTED_OBJECT_BOX_BLUE;
							iEditorObjectsNumber = 1;
						break;
					}
					sprintf(byTemp, "%d", iEditorObjectsNumber);
					SetDlgItemText(hWnd, IDC_EDITOR_OBJECTS_NUMBER, byTemp);
				break;

				case IDC_EDITOR_OBJECTS_ITEMS_LIST:
					i = (int) SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_ITEMS_LIST, CB_GETCURSEL, 0, 0L);
					i = (int) SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_ITEMS_LIST, CB_GETITEMDATA, i, 0L);
					if(i < 0)
						i = 0;
					if(i > ITEMS)
						i = ITEMS;
					switch(i)
					{
						case 0:
							byEditorSelected = EDITOR_SELECTED_ITEM_HEALTH;
							iEditorObjectsNumber = HEALTH_OBJ_NUMBER;
						break;

						case 1:
							byEditorSelected = EDITOR_SELECTED_ITEM_HEALTH_INCREASE;
							iEditorObjectsNumber = HEALTH_INCREASE_OBJ_NUMBER;
						break;
						
						case 2:	
							byEditorSelected = EDITOR_SELECTED_ITEM_LIFE;
							iEditorObjectsNumber = LIFE_OBJ_NUMBER;
						break;
						
						case 3:
							byEditorSelected = EDITOR_SELECTED_ITEM_PULL;
							iEditorObjectsNumber = PULL_OBJ_NUMBER;
						break;
						
						case 4:	
							byEditorSelected = EDITOR_SELECTED_ITEM_CHEST;
							iEditorObjectsNumber = CHEST_OBJ_NUMBER;
						break;
						
						case 5:
							byEditorSelected = EDITOR_SELECTED_ITEM_STRENGTH;
							iEditorObjectsNumber = STRENGTH_OBJ_NUMBER;
						break;
						
						case 6:
							byEditorSelected = EDITOR_SELECTED_ITEM_WEAPON;
							iEditorObjectsNumber = WEAPON_OBJ_NUMBER;
						break;
						
						case 7:
							byEditorSelected = EDITOR_SELECTED_ITEM_COIN;
							iEditorObjectsNumber = COIN_OBJ_NUMBER;
						break;
						
						case 8:
							byEditorSelected = EDITOR_SELECTED_ITEM_GHOST;
							iEditorObjectsNumber = GHOST_TIME;
						break;
						
						case 9:
							byEditorSelected = EDITOR_SELECTED_ITEM_TIME;
							iEditorObjectsNumber = TIME_OBJ_NUMBER;
						break;
						
						case 10:
							byEditorSelected = EDITOR_SELECTED_ITEM_STEP;
							iEditorObjectsNumber = STEPS_OBJ_NUMBER;
						break;
						
						case 11:
							byEditorSelected = EDITOR_SELECTED_ITEM_SPEED;
							iEditorObjectsNumber = SPEED_TIME;
						break;
						
						case 12:
							byEditorSelected = EDITOR_SELECTED_ITEM_WING;
							iEditorObjectsNumber = WING_TIME;
						break;
						
						case 13:
							byEditorSelected = EDITOR_SELECTED_ITEM_SHIELD;
							iEditorObjectsNumber = SHIELD_TIME;
						break;
						
						case 14:
							byEditorSelected = EDITOR_SELECTED_ITEM_JUMP;
							iEditorObjectsNumber = JUMP_OBJ_NUMBER;
						break;
						
						case 15:
							byEditorSelected = EDITOR_SELECTED_ITEM_AIR;
							iEditorObjectsNumber = AIR_OBJ_NUMBER;
						break;

						case 16:
							byEditorSelected = EDITOR_SELECTED_ITEM_AIR_INCREASE;
							iEditorObjectsNumber = AIR_INCREASE_OBJ_NUMBER;
						break;

						case 17:
							byEditorSelected = EDITOR_SELECTED_ITEM_THROW;
							iEditorObjectsNumber = THROW_OBJ_NUMBER;
						break;

						case 18:
							byEditorSelected = EDITOR_SELECTED_ITEM_KICK;
							iEditorObjectsNumber = KICK_OBJ_NUMBER;
						break;

						case 19:
							byEditorSelected = EDITOR_SELECTED_ITEM_BAG;
							iEditorObjectsNumber = BAG_OBJ_NUMBER;
						break;

						case 20:
							byEditorSelected = EDITOR_SELECTED_ITEM_DYNAMITE;
							iEditorObjectsNumber = DYNAMITE_OBJ_NUMBER;
						break;
					}
					sprintf(byTemp, "%d", iEditorObjectsNumber);
					SetDlgItemText(hWnd, IDC_EDITOR_OBJECTS_NUMBER, byTemp);
				break;

				case IDC_EDITOR_OBJECTS_ENEMIES_LIST:
					i = (int) SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_ENEMIES_LIST, CB_GETCURSEL, 0, 0L);
					if(i < 0)
						i = 0;
					if(i > 3)
						i = 3;
					switch(i)
					{
						case 0: byEditorSelected = EDITOR_SELECTED_ENEMY_MOBMOB; break;
						case 1: byEditorSelected = EDITOR_SELECTED_ENEMY_X3; break;
						case 2: byEditorSelected = EDITOR_SELECTED_ENEMY_LUCIFER_HEAD; break;
						case 3: byEditorSelected = EDITOR_SELECTED_ENEMY_LUCIFER; break;
					}
				break;

				case IDC_EDITOR_OBJECTS_PLUS:
					iEditorRotate++;
					if(iEditorRotate > 3)
						iEditorRotate = 0;
					goto Init;

				case IDC_EDITOR_OBJECTS_MINUS:
					iEditorRotate--;
					if(iEditorRotate < 0)
						iEditorRotate = 3;
					goto Init;
				
				case IDC_EDITOR_OBJECTS_NUMBER:
					GetDlgItemText(hWnd, IDC_EDITOR_OBJECTS_NUMBER, byTemp, 256);
					iEditorObjectsNumber = atoi(byTemp);
				break;

			// Box:
				case IDD_EDITOR_OBJECTS_BOX_SIDE:
					goto Init;

				case IDD_EDITOR_OBJECTS_BOX_SIDE_SURFACE:
					i = (int) SendDlgItemMessage(hWnd, IDD_EDITOR_OBJECTS_BOX_SIDE_SURFACE, CB_GETCURSEL, 0, 0L);
					if(i == -1 || i >= pLevel->Header.iSurfaces)
						break;
					bySelecedSide = (int) SendDlgItemMessage(hWnd, IDD_EDITOR_OBJECTS_BOX_SIDE, CB_GETCURSEL, 0, 0L);
					if(bySelecedSide == -1 || bySelecedSide > 6)
						break;
					pLevel->Header.iBoxSurface[bySelecedSide] = i;
				break;

				case IDD_EDITOR_OBJECTS_BOX_SURFACE_ALL:
					i = (int) SendDlgItemMessage(hWnd, IDD_EDITOR_OBJECTS_BOX_SIDE_SURFACE, CB_GETCURSEL, 0, 0L);
					if(i == -1 || i >= pLevel->Header.iSurfaces)
						break;
					GetDlgItemText(hWnd, IDD_EDITOR_OBJECTS_BOX_SURFACE_ROTATION, byTemp, 256);
					iRotT = atoi(byTemp);
					for(bySelecedSide = 0; bySelecedSide < 6; bySelecedSide++)
					{
						pLevel->Header.iBoxSurface[bySelecedSide] = i;
						pLevel->Header.byBoxSurfaceRot[bySelecedSide] = iRotT;
					}
				break;

				case IDD_EDITOR_OBJECTS_BOX_ENVIRONMENT:
					i = SendDlgItemMessage(hWnd, IDD_EDITOR_OBJECTS_BOX_ENVIRONMENT, BM_GETCHECK, 0, 0L);
					if(pLevel->Header.iBoxSurface[6] == -1 || i)
						pLevel->Header.iBoxSurface[6] = 0; // Enable
					else
						pLevel->Header.iBoxSurface[6] = -1; // Disable
					goto Init;
				
				case IDD_EDITOR_OBJECTS_BOX_SURFACE_ROTATION_PLUS:
					bySelecedSide = (int) SendDlgItemMessage(hWnd, IDD_EDITOR_OBJECTS_BOX_SIDE, CB_GETCURSEL, 0, 0L);
					if(bySelecedSide == -1 || bySelecedSide > 5)
						break;
					pLevel->Header.byBoxSurfaceRot[bySelecedSide]--;
					if(pLevel->Header.byBoxSurfaceRot[bySelecedSide] < 0)
						pLevel->Header.byBoxSurfaceRot[bySelecedSide] = 3;
					sprintf(byTemp, "%d", pLevel->Header.byBoxSurfaceRot[bySelecedSide]*90);
					SetDlgItemText(hWnd, IDD_EDITOR_OBJECTS_BOX_SURFACE_ROTATION, byTemp);
				break;

				case IDD_EDITOR_OBJECTS_BOX_SURFACE_ROTATION_MINUS:
					bySelecedSide = (int) SendDlgItemMessage(hWnd, IDD_EDITOR_OBJECTS_BOX_SIDE, CB_GETCURSEL, 0, 0L);
					if(bySelecedSide == -1 || bySelecedSide > 5)
						break;
					pLevel->Header.byBoxSurfaceRot[bySelecedSide]++;
					if(pLevel->Header.byBoxSurfaceRot[bySelecedSide] > 3)
						pLevel->Header.byBoxSurfaceRot[bySelecedSide] = 0;
					sprintf(byTemp, "%d", pLevel->Header.byBoxSurfaceRot[bySelecedSide]*90);
					SetDlgItemText(hWnd, IDD_EDITOR_OBJECTS_BOX_SURFACE_ROTATION, byTemp);
				break;
            }
		break;
    }

    return FALSE;
} // end EditorObjectsProc()

LRESULT CALLBACK EditorTerrainProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorTerrainProc()
	if(!pLevel)
		return 0;

	switch(iMessage)
    {
        case WM_INITDIALOG:
  			// Texts:
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_COLOR, AS_T(T_Color));
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_SECOND_COLOR, AS_T(T_SecondColor));
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_ALPHA_COLOR, AS_T(T_AlphaColor));
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_SECOND_ALPHA_COLOR, AS_T(T_SecondAlphaColor));
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_HEIGHT, AS_T(T_Height));
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_POINT, AS_T(T_Point));
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_MIDDLE_HEIGHT, AS_T(T_MiddleHeight));
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_GREATEST_HEIGHT, AS_T(T_GreatestHeight));
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_LOWEST_HEIGHT, AS_T(T_LowestHeight));
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_WATER_AMPLITUDE, AS_T(T_WaterAmplitude));
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_ADVANCED, AS_T(T_Advanced));
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_FLOOR, AS_T(T_Floor));
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_MIDDLE, AS_T(T_Middle));
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_TOP, AS_T(T_Top));
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_WATER, AS_T(T_Water));
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_RANDOMLY, AS_T(T_Randomly));
			//
			SendDlgItemMessage(hWnd, IDC_EDITOR_TERRAIN_ADVANCED, BM_SETCHECK, bAdvancedTerrainManipulation, 0L);
			//
			byEditorMenu = EDITOR_TERRAIN_MENU;
			byEditorSelected = EDITOR_SELECTED_HEIGHT;
			BringWindowToTop(hWnd);
		Init:
			ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_TERRAIN_MIDDLE), bAdvancedTerrainManipulation);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_EDITOR_TERRAIN_COLOR: byEditorSelected = EDITOR_SELECTED_COLOR; break;
				case IDC_EDITOR_TERRAIN_SECOND_COLOR: byEditorSelected = EDITOR_SELECTED_SECOND_COLOR; break;
				case IDC_EDITOR_TERRAIN_ALPHA_COLOR: byEditorSelected = EDITOR_SELECTED_ALPHA_COLOR; break;
				case IDC_EDITOR_TERRAIN_SECOND_ALPHA_COLOR: byEditorSelected = EDITOR_SELECTED_SECOND_ALPHA_COLOR; break;
				case IDC_EDITOR_TERRAIN_HEIGHT: byEditorSelected = EDITOR_SELECTED_HEIGHT; break;
				case IDC_EDITOR_TERRAIN_POINT: byEditorSelected = EDITOR_SELECTED_POINT; break;
				case IDC_EDITOR_TERRAIN_MIDDLE_HEIGHT: byEditorSelected = EDITOR_SELECTED_MIDDLE_HEIGHT; break;
				case IDC_EDITOR_TERRAIN_LOWEST_HEIGHT: byEditorSelected = EDITOR_SELECTED_LOWEST_HEIGHT; break;
				case IDC_EDITOR_TERRAIN_GREATEST_HEIGHT: byEditorSelected = EDITOR_SELECTED_GREATEST_HEIGHT; break;
				case IDC_EDITOR_TERRAIN_ADVANCED: bAdvancedTerrainManipulation = SendDlgItemMessage(hWnd, IDC_EDITOR_TERRAIN_ADVANCED, BM_GETCHECK, 0, 0L); goto Init;
				case IDC_EDITOR_TERRAIN_WATER_AMPLITUDE: byEditorSelected = EDITOR_SELECTED_WATER_AMPLITUDE; break;
				case IDC_EDITOR_TERRAIN_RANDOMLY: byEditorSelected = EDITOR_SELECTED_TERRAIN_RANDOMLY; break;
            }
            break;
    }

    return FALSE;
} // end EditorTerrainProc()

LRESULT CALLBACK EditorEnvironmentProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorEnvironmentProc()
	if(!pLevel)
		return 0;
	switch(iMessage)
    {
        case WM_INITDIALOG:
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_LIGHT, AS_T(T_Color));
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_MOVE_SHADOWS, AS_T(T_MoveShadows));
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_SHADOWS_DENSITY_SIZE, AS_T(T_ShadowsDensity_Size));
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_FOG_T, AS_T(T_Fog));
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_FOG, AS_T(T_Active));
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_FOG_COLOR, AS_T(T_Color));
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_FOG_DENSITY, AS_T(T_Density));
		    SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_FOG, BM_SETCHECK, pLevel->Environment.bFog, 0L);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_WATER_T, AS_T(T_Water));
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_WATER_COLOR, AS_T(T_Color));
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_WATER_DENSITY, AS_T(T_Density));
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_WATER_HEIGHT, AS_T(T_Height));
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_WATER_AMPLITUDE, AS_T(T_Amplitude));
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_WATER_SPEED, AS_T(T_Speed));
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_WATER_WAVE_AMPLITUDE, AS_T(T_WaveAmplitude));
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_WATER_WAVE_SPEED, AS_T(T_WaveSpeed));
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_WATER_WAVE_SIZE, AS_T(T_WaveSize));

			SetDlgItemText(hWnd, IDC_ENVIRONMENT_WATER_BUBBLES_COLOR, AS_T(T_Color));
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_WATER_BUBBLES_DENSITY, AS_T(T_Density));
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_WATER_BUBBLES_SPEED, AS_T(T_Speed));
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_WATER_BUBBLES_FREQUENCY, AS_T(T_Frequency));
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_WATER_BUBBLES_SIZE, AS_T(T_Size));
			
			byEditorMenu = EDITOR_ENVIRONMENT_MENU;
			byEditorSelected = EDITOR_ENVIRONMENT_LIGHT;
			BringWindowToTop(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_ENVIRONMENT_LIGHT: byEditorSelected = EDITOR_ENVIRONMENT_LIGHT; break;
				case IDC_ENVIRONMENT_MOVE_SHADOWS: byEditorSelected = EDITOR_ENVIRONMENT_MOVE_SHADOWS; break;
				case IDC_ENVIRONMENT_SHADOWS_DENSITY_SIZE: byEditorSelected = EDITOR_ENVIRONMENT_SHADOWS_DENSITY_SIZE; break;
				case IDC_ENVIRONMENT_FOG: pLevel->Environment.bFog = SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_FOG, BM_GETCHECK, 0, 0L); break;
				case IDC_ENVIRONMENT_FOG_COLOR: byEditorSelected = EDITOR_ENVIRONMENT_FOG_COLOR; break;
				case IDC_ENVIRONMENT_FOG_DENSITY: byEditorSelected = EDITOR_ENVIRONMENT_FOG_DENSITY; break;
				case IDC_ENVIRONMENT_WATER_COLOR: byEditorSelected = EDITOR_ENVIRONMENT_WATER_COLOR; break;
				case IDC_ENVIRONMENT_WATER_DENSITY: byEditorSelected = EDITOR_ENVIRONMENT_WATER_DENSITY; break;
				case IDC_ENVIRONMENT_WATER_HEIGHT: byEditorSelected = EDITOR_ENVIRONMENT_WATER_HEIGHT; break;
				case IDC_ENVIRONMENT_WATER_AMPLITUDE: byEditorSelected = EDITOR_ENVIRONMENT_WATER_AMPLITUDE; break;
				case IDC_ENVIRONMENT_WATER_SPEED: byEditorSelected = EDITOR_ENVIRONMENT_WATER_SPEED; break;
				case IDC_ENVIRONMENT_WATER_WAVE_AMPLITUDE: byEditorSelected = EDITOR_ENVIRONMENT_WATER_WAVE_AMPLITUDE; break;
				case IDC_ENVIRONMENT_WATER_WAVE_SPEED: byEditorSelected = EDITOR_ENVIRONMENT_WATER_WAVE_SPEED; break;
				case IDC_ENVIRONMENT_WATER_WAVE_SIZE: byEditorSelected = EDITOR_ENVIRONMENT_WATER_WAVE_SIZE; break;
				case IDC_ENVIRONMENT_WATER_BUBBLES_COLOR: byEditorSelected = EDITOR_ENVIRONMENT_WATER_BUBBLES_COLOR; break;
				case IDC_ENVIRONMENT_WATER_BUBBLES_DENSITY: byEditorSelected = EDITOR_ENVIRONMENT_WATER_BUBBLES_DENSITY; break;
				case IDC_ENVIRONMENT_WATER_BUBBLES_SPEED: byEditorSelected = EDITOR_ENVIRONMENT_WATER_BUBBLES_SPEED; break;
				case IDC_ENVIRONMENT_WATER_BUBBLES_FREQUENCY: byEditorSelected = EDITOR_ENVIRONMENT_WATER_BUBBLES_FREQUENCY; break;
				case IDC_ENVIRONMENT_WATER_BUBBLES_SIZE: byEditorSelected = EDITOR_ENVIRONMENT_WATER_BUBBLES_SIZE; break;
            }
            break;
    }

    return FALSE;
} // end EditorEnvironmentProc()

LRESULT CALLBACK EditorCameraProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorCameraProc()
	char byTemp[256];
	BOOL bEnable;
	int i, i2;

	if(!pLevel)
		return 0;
	switch(iMessage)
    {
        case WM_INITDIALOG:
			// Texts:
			SetDlgItemText(hWnd, IDC_EDITOR_CAMERA_SET_VELOCITY, AS_T(T_CameraVelocity));
			SetDlgItemText(hWnd, ID_EDITOR_CAMERA_NEW, AS_T(T_New));
			SetDlgItemText(hWnd, ID_EDITOR_CAMERA_DUPLICATE, AS_T(T_Duplicate));
			SetDlgItemText(hWnd, ID_EDITOR_CAMERA_DELETE, AS_T(T_Delete));
			SetDlgItemText(hWnd, IDC_EDITOR_CAMERA_STEPS, AS_T(T_Steps));
			SetDlgItemText(hWnd, IDC_EDITOR_CAMERA_COPY, AS_T(T_Copy));
			SetDlgItemText(hWnd, IDC_EDITOR_CAMERA_PLAY, AS_T(T_Play));
			SetDlgItemText(hWnd, IDC_EDITOR_CAMERA_SET, AS_T(T_Set));
			SetDlgItemText(hWnd, IDC_EDITOR_CAMERA_NEXT_TIME_ALL, AS_T(T_All));
			SetDlgItemText(hWnd, IDC_EDITOR_CAMERA_NAME_T, AS_T(T_Name));
			SetDlgItemText(hWnd, IDC_EDITOR_CAMERA_NEXT_TIME_T, AS_T(T_NextTime));
			
			if(!bCameraAnimation)
				SetDlgItemText(hWnd, IDC_EDITOR_CAMERA_PLAY, AS_T(T_Play));
			else
				SetDlgItemText(hWnd, IDC_EDITOR_CAMERA_PLAY, AS_T(T_Stop));
		Init:
			SendDlgItemMessage(hWnd, ID_EDITOR_CAMERA_SELECTED, LB_RESETCONTENT, 0, 0L);
			for(i = 0; i < pLevel->Header.iCameraScripts; i++)
			{
				sprintf(byTemp, "%s", pLevel->pCameraScript[i].byName);
				SendDlgItemMessage(hWnd, ID_EDITOR_CAMERA_SELECTED, LB_ADDSTRING, 0, (LPARAM) byTemp);
			}
		Init2:
			if(pLevel->pCurrentCameraScript)
				SendDlgItemMessage(hWnd, IDC_EDITOR_CAMERA_TEXT_SCRIPT, LB_SETCURSEL, pLevel->pCurrentCameraScript->iTextScript+1, 0L);
			else
				SendDlgItemMessage(hWnd, IDC_EDITOR_CAMERA_TEXT_SCRIPT, LB_SETCURSEL, 0, 0L);
			if(pLevel->pCurrentCameraScript)
			{
				bEnable = TRUE;
				if(pLevel->Camera.iCurrentCameraStep < 0)
					pLevel->Camera.iCurrentCameraStep = 0;
				if(pLevel->Camera.iCurrentCameraStep >= pLevel->pCurrentCameraScript->iSteps)
					pLevel->Camera.iCurrentCameraStep = pLevel->pCurrentCameraScript->iSteps-1;
				SetDlgItemText(hWnd, IDC_EDITOR_CAMERA_NAME, pLevel->pCurrentCameraScript->byName);
				SendDlgItemMessage(hWnd, IDC_EDITOR_CAMERA_STEP_LIST, CB_RESETCONTENT, 0, 0L);
				for(i = 0; i < pLevel->pCurrentCameraScript->iSteps; i++)
				{
					sprintf(byTemp, "%d", i);
					SendDlgItemMessage(hWnd, IDC_EDITOR_CAMERA_STEP_LIST, CB_ADDSTRING, 0, (LPARAM) byTemp);
				}
				SendDlgItemMessage(hWnd, IDC_EDITOR_CAMERA_STEP_LIST, CB_SETCURSEL, pLevel->Camera.iCurrentCameraStep, 0L);
				sprintf(byTemp, "%d", pLevel->pCurrentCameraScript->pCamera[pLevel->Camera.iCurrentCameraStep].iTimeToNext);
				SetDlgItemText(hWnd, IDC_EDITOR_CAMERA_NEXT_TIME, byTemp);				

/*				SendDlgItemMessage(hWnd, IDC_EDITOR_CAMERA_TEXT_SCRIPT, CB_RESETCONTENT, 0, 0L);
				sprintf(byTemp, " - %s", T_NoTextScript);
				SendDlgItemMessage(hWnd, IDC_EDITOR_CAMERA_TEXT_SCRIPT, CB_ADDSTRING, 0, (LPARAM) byTemp);
				for(i = 0; i < pLevel->TextScriptsManager.iTextsScripts; i++)
				{
					sprintf(byTemp, "%d: %s", i, pTextScript[i].byName);
					SendDlgItemMessage(hWnd, IDC_EDITOR_CAMERA_TEXT_SCRIPT, CB_ADDSTRING, 0, (LPARAM) byTemp);
				}
				SendDlgItemMessage(hWnd, IDC_EDITOR_CAMERA_TEXT_SCRIPT, CB_SETCURSEL, pLevel->pCurrentCameraScript->iTextScript+1, 0L);
*/				
			}
			else
				bEnable = FALSE;
			EnableWindow(GetDlgItem(hWnd, ID_EDITOR_CAMERA_DUPLICATE), bEnable);
			EnableWindow(GetDlgItem(hWnd, ID_EDITOR_CAMERA_DELETE), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_NAME), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_COPY_LEFT), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_COPY), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_COPY_RIGHT), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_PLAY), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_STEPS), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_STEP_LIST), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_NEXT_TIME), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_NEXT_TIME_ALL), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_SET), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_TEXT_SCRIPT), bEnable);
			//
			byEditorMenu = EDITOR_CAMERA_MENU;
			BringWindowToTop(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_EDITOR_CAMERA_SET_VELOCITY:
					DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_SET_CAMERA_VELOCITY), hWnd, (DLGPROC) SetCameraVelocityProc);
				break;
				
				case ID_EDITOR_CAMERA_NEW:
					// Create a new camera script:
					pLevel->Header.iCameraScripts++;
					pLevel->pCameraScript = (AS_CAMERA_SCRIPT *) realloc(pLevel->pCameraScript, sizeof(AS_CAMERA_SCRIPT)*pLevel->Header.iCameraScripts);
					memset(&pLevel->pCameraScript[pLevel->Header.iCameraScripts-1], 0, sizeof(AS_CAMERA_SCRIPT));
					pLevel->iCurrentCameraScript = pLevel->Header.iCameraScripts-1;
					pLevel->pCurrentCameraScript = &pLevel->pCameraScript[pLevel->iCurrentCameraScript];
					// Create the temp camera:
					pLevel->pCurrentCameraScript->iSteps++;
					pLevel->pCurrentCameraScript->pCamera = (AS_CAMERA *) malloc(sizeof(AS_CAMERA)*pLevel->pCurrentCameraScript->iSteps);
					memset(&pLevel->pCurrentCameraScript->pCamera[0], 0, sizeof(AS_CAMERA));
					sprintf(pLevel->pCurrentCameraScript->byName, "Camera script %d", pLevel->iCurrentCameraScript);
					pLevel->pCurrentCameraScript->iTextScript = -1;
					pLevel->pCurrentCameraScript->pCamera[0].iTimeToNext = 2000;
					goto Init;

				case ID_EDITOR_CAMERA_DUPLICATE:
					// Create a new camera script:
					pLevel->Header.iCameraScripts++;
					pLevel->pCameraScript = (AS_CAMERA_SCRIPT *) realloc(pLevel->pCameraScript, sizeof(AS_CAMERA_SCRIPT)*pLevel->Header.iCameraScripts);
					memset(&pLevel->pCameraScript[pLevel->Header.iCameraScripts-1], 0, sizeof(AS_CAMERA_SCRIPT));
					pLevel->pCurrentCameraScript = &pLevel->pCameraScript[pLevel->iCurrentCameraScript];
					// Copy the script into the duplicate:
					memcpy(&pLevel->pCameraScript[pLevel->Header.iCameraScripts-1], pLevel->pCurrentCameraScript, sizeof(AS_CAMERA_SCRIPT));
					pLevel->pCameraScript[pLevel->Header.iCameraScripts-1].pCamera = (AS_CAMERA *) malloc(sizeof(AS_CAMERA)*pLevel->pCameraScript[pLevel->Header.iCameraScripts-1].iSteps);
					for(i = 0; i < pLevel->pCurrentCameraScript->iSteps; i++)
						memcpy(&pLevel->pCameraScript[pLevel->Header.iCameraScripts-1].pCamera[i], &pLevel->pCurrentCameraScript->pCamera[i], sizeof(AS_CAMERA));
					// Setup new camera script:
					pLevel->iCurrentCameraScript = pLevel->Header.iCameraScripts-1;
					pLevel->pCurrentCameraScript = &pLevel->pCameraScript[pLevel->iCurrentCameraScript];
					sprintf(pLevel->pCurrentCameraScript->byName, "Camera script %d", pLevel->iCurrentCameraScript);
					goto Init;
				
				case ID_EDITOR_CAMERA_DELETE:
					// Update the camera users:
					if(pLevel->Camera.iStartCamera == pLevel->iCurrentCameraScript)
						pLevel->Camera.bStartCamera = FALSE;
					else
						if(pLevel->Camera.iStartCamera > pLevel->iCurrentCameraScript)
							pLevel->Camera.iStartCamera--;
					if(pLevel->Camera.iEndCamera == pLevel->iCurrentCameraScript)
						pLevel->Camera.bEndCamera = FALSE;
					else
						if(pLevel->Camera.iEndCamera > pLevel->iCurrentCameraScript)
							pLevel->Camera.iEndCamera--;
					for(i = 0; i < pLevel->Header.iFields; i++)
					{
						if(pLevel->pField[i].iCamera > pLevel->iCurrentCameraScript)
							pLevel->pField[i].iCamera--;
						if(pLevel->pField[i].iCamera == pLevel->iCurrentCameraScript)
							pLevel->pField[i].iCamera = -1;
					}

					// Delete the selected camera script:
					free(pLevel->pCurrentCameraScript->pCamera);
					for(i = pLevel->iCurrentCameraScript; i < pLevel->Header.iCameraScripts-1; i++)
						memcpy(&pLevel->pCameraScript[i], &pLevel->pCameraScript[i+1], sizeof(AS_CAMERA_SCRIPT));
					pLevel->Header.iCameraScripts--;
					pLevel->pCameraScript = (AS_CAMERA_SCRIPT *) realloc(pLevel->pCameraScript, sizeof(AS_CAMERA_SCRIPT)*pLevel->Header.iCameraScripts);
					if(pLevel->iCurrentCameraScript >= pLevel->Header.iCameraScripts)
						pLevel->iCurrentCameraScript = pLevel->Header.iCameraScripts-1;
					if(pLevel->iCurrentCameraScript != -1)
						pLevel->pCurrentCameraScript = &pLevel->pCameraScript[pLevel->iCurrentCameraScript];
					else
						pLevel->pCurrentCameraScript = NULL;
					goto Init;

				case ID_EDITOR_CAMERA_SELECTED:
					if(!pLevel)
						break;
					i = (int) SendDlgItemMessage(hWnd, ID_EDITOR_CAMERA_SELECTED, LB_GETCURSEL, 0, 0L);
					if(i < 0)
						i = 0;
					if(i >= pLevel->Header.iCameraScripts)
						i = pLevel->Header.iCameraScripts-1;
					pLevel->iCurrentCameraScript = i;
					if(pLevel->iCurrentCameraScript < 0)
					{
						pLevel->pCurrentCameraScript = NULL;
						break;
					}
					pLevel->pCurrentCameraScript = &pLevel->pCameraScript[pLevel->iCurrentCameraScript];
					goto Init2;

				case IDC_EDITOR_CAMERA_NAME:
					GetDlgItemText(hWnd, IDC_EDITOR_CAMERA_NAME, pLevel->pCurrentCameraScript->byName, 256);
					SendDlgItemMessage(hWnd, ID_EDITOR_CAMERA_SELECTED, LB_RESETCONTENT, 0, 0L);
					for(i = 0; i < pLevel->Header.iCameraScripts; i++)
					{
						sprintf(byTemp, "%s", pLevel->pCameraScript[i].byName);
						SendDlgItemMessage(hWnd, ID_EDITOR_CAMERA_SELECTED, LB_ADDSTRING, 0, (LPARAM) byTemp);
					}
					SendDlgItemMessage(hWnd, ID_EDITOR_CAMERA_SELECTED, LB_SETCURSEL, pLevel->iCurrentCameraScript, 0L);
				break;

				case IDC_EDITOR_CAMERA_COPY:
					if((i = DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_COPY_CAMERA_STEP), hWnd, (DLGPROC) CopyCameraStepProc)) == -1)
						break;
					memcpy(&pLevel->pCurrentCameraScript->pCamera[i], &pLevel->pCurrentCameraScript->pCamera[pLevel->Camera.iCurrentCameraStep], sizeof(AS_CAMERA));
					pLevel->Camera.iCurrentCameraStep = i;
					goto Init2;

				case IDC_EDITOR_CAMERA_COPY_LEFT:
					i = pLevel->Camera.iCurrentCameraStep-1;
					if(i < 0)
						i = pLevel->pCurrentCameraScript->iSteps-1;
					memcpy(&pLevel->pCurrentCameraScript->pCamera[i], &pLevel->pCurrentCameraScript->pCamera[pLevel->Camera.iCurrentCameraStep], sizeof(AS_CAMERA));
					pLevel->Camera.iCurrentCameraStep = i;
					goto Init2;

				case IDC_EDITOR_CAMERA_COPY_RIGHT:
					i = pLevel->Camera.iCurrentCameraStep+1;
					if(i >= pLevel->pCurrentCameraScript->iSteps)
						i = 0;
					memcpy(&pLevel->pCurrentCameraScript->pCamera[i], &pLevel->pCurrentCameraScript->pCamera[pLevel->Camera.iCurrentCameraStep], sizeof(AS_CAMERA));
					pLevel->Camera.iCurrentCameraStep = i;
					goto Init2;
				break;

				case IDC_EDITOR_CAMERA_STEPS:
					if((i = DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_SET_CAMERA_STEPS), hWnd, (DLGPROC) SetCameraStepsProc)) == -1)
						break;
					i2 = pLevel->pCurrentCameraScript->iSteps;
					pLevel->pCurrentCameraScript->iSteps = i;
					pLevel->pCurrentCameraScript->pCamera = (AS_CAMERA *) realloc(pLevel->pCurrentCameraScript->pCamera, sizeof(AS_CAMERA)*pLevel->pCurrentCameraScript->iSteps);
					for(; i2 < i; i2++)
					{
						memset(&pLevel->pCurrentCameraScript->pCamera[i2], 0, sizeof(AS_CAMERA));
						pLevel->pCurrentCameraScript->pCamera[i2].iTimeToNext = 2000;
					}
					if(pLevel->Camera.iCurrentCameraStep >= pLevel->pCurrentCameraScript->iSteps)
						pLevel->Camera.iCurrentCameraStep = pLevel->pCurrentCameraScript->iSteps-1;
					goto Init2;

				case IDC_EDITOR_CAMERA_NEXT_TIME:
					GetDlgItemText(hWnd, IDC_EDITOR_CAMERA_NEXT_TIME, byTemp, 256);
					pLevel->pCurrentCameraScript->pCamera[pLevel->Camera.iCurrentCameraStep].iTimeToNext = (int) atoi(byTemp);
				break;

				case IDC_EDITOR_CAMERA_NEXT_TIME_ALL:
					for(i = 0; i < pLevel->pCurrentCameraScript->iSteps; i++)
						pLevel->pCurrentCameraScript->pCamera[i].iTimeToNext = pLevel->pCurrentCameraScript->pCamera[pLevel->Camera.iCurrentCameraStep].iTimeToNext;
				break;

				case IDC_EDITOR_CAMERA_STEP_LIST:
					if(!pLevel || !pLevel->pCurrentCameraScript)
						goto Init;
					i = (int) SendDlgItemMessage(hWnd, IDC_EDITOR_CAMERA_STEP_LIST, CB_GETCURSEL, 0, 0L);
					if(i < 0)
						i = 0;
					if(i >= pLevel->pCurrentCameraScript->iSteps)
						i = pLevel->pCurrentCameraScript->iSteps-1;
					pLevel->Camera.iCurrentCameraStep = i;
					// Set the level camera to  this camera:
					memcpy(pCamera, &pLevel->pCurrentCameraScript->pCamera[pLevel->Camera.iCurrentCameraStep], sizeof(AS_CAMERA));
					goto Init2;
				
				case IDC_EDITOR_CAMERA_PLAY:
					lCameraTimer = g_lGameTimer;
					bCameraAnimation = !bCameraAnimation;
					memset(&TempCamera, 0, sizeof(AS_CAMERA));
					if(!bCameraAnimation)
					{
						SetDlgItemText(hWnd, IDC_EDITOR_CAMERA_PLAY, AS_T(T_Play));
						memcpy(pCamera, &pLevel->pCurrentCameraScript->pCamera[pLevel->Camera.iCurrentCameraStep], sizeof(AS_CAMERA));
					}
					else
					{
						SetDlgItemText(hWnd, IDC_EDITOR_CAMERA_PLAY, AS_T(T_Stop));
						pLevel->Camera.iCurrentCameraStep = 0;
					}
				break;

				case IDC_EDITOR_CAMERA_SET:
					// Set the level camera to the camera from the script:
					memcpy(&pLevel->pCurrentCameraScript->pCamera[pLevel->Camera.iCurrentCameraStep], pCamera, sizeof(AS_CAMERA));
				break;

/*				case IDC_EDITOR_CAMERA_TEXT_SCRIPT:
					if(!pLevel || !pLevel->pCurrentCameraScript)
						goto Init;
					i = (int) SendDlgItemMessage(hWnd, IDC_EDITOR_CAMERA_TEXT_SCRIPT, CB_GETCURSEL, 0, 0L);
					if(i < 0 || i > pLevel->TextScriptsManager.iTextsScripts)
						break;
					pLevel->pCurrentCameraScript->iTextScript = i-1;
				break;*/
            }
            break;
    }

    return FALSE;
} // end EditorCameraProc()

LRESULT CALLBACK EditorDecorationProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorDecorationProc()
	char byTemp[256];
	int i;

	if(!pLevel)
		return 0;
	switch(iMessage)
    {
        case WM_INITDIALOG:
			SetDlgItemText(hWnd, IDC_DECRATION_DECORATION, AS_T(T_Decoration));
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_SKY_CUBE_T, AS_T(T_SkyCube));
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_SKY_CUBE, AS_T(T_Active));
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_SKY_CUBE_COLOR, AS_T(T_Color));
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SIZE, AS_T(T_Size));
		    SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE, BM_SETCHECK, pLevel->Environment.bSkyCube, 0L);
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SIDE, CB_RESETCONTENT, 0, 0L);
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SIDE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Floor));
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SIDE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Top));
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SIDE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Left));
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SIDE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Right));
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SIDE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Bottom));
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SIDE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Front));
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SIDE, CB_SETCURSEL, byCurrentSkyCubeSide, 0L);
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_ALL, CB_ADDSTRING, 0, (LPARAM) T_All);
			//
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SURFACE, CB_RESETCONTENT, 0, 0L);
			for(i = 0; i < pLevel->Header.iSurfaces; i++)
			{
				sprintf(byTemp, "%s", pLevel->pSurface[i].Header.byName);
				SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SURFACE, CB_ADDSTRING, 0, (LPARAM) byTemp);
			}
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SURFACE, CB_SETCURSEL, pLevel->Environment.iSkyCubeSurface[byCurrentSkyCubeSide], 0L);
			//
			byEditorMenu = EDITOR_DECORATION_MENU;
			BringWindowToTop(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_DECRATION_DECORATION:
					KillTimer(hWndEditor, 1);
					DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_DECORATION), hWnd, (DLGPROC) DecorationProc);
					SetTimer(hWndEditor, 1, 1, NULL);
				break;

				case IDC_ENVIRONMENT_SKY_CUBE_SIDE:
					i = (int) SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SIDE, CB_GETCURSEL, 0, 0L);
					if(i < 0 || i > 6)
						byCurrentSkyCubeSide = 0;
					else
						byCurrentSkyCubeSide = (char) i;
					SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SURFACE, CB_SETCURSEL, pLevel->Environment.iSkyCubeSurface[byCurrentSkyCubeSide], 0L);
				break;

				case IDC_ENVIRONMENT_SKY_CUBE_SURFACE:
					i = (int) SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SURFACE, CB_GETCURSEL, 0, 0L);
					if(i < 0 || i > pLevel->Header.iSurfaces-1)
					{
						pLevel->iCurrentSurface	= -1;
						pLevel->pCurrentSurface = NULL;
					}
					else
						pLevel->Environment.iSkyCubeSurface[byCurrentSkyCubeSide] = pLevel->iCurrentSurface	= i;
				break;

				case IDC_ENVIRONMENT_SKY_CUBE: pLevel->Environment.bSkyCube = SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE, BM_GETCHECK, 0, 0L); break;
				case IDC_ENVIRONMENT_SKY_CUBE_COLOR: byEditorSelected = EDITOR_ENVIRONMENT_SKY_CUBE_COLOR; break;
				case IDC_ENVIRONMENT_SKY_CUBE_SIZE: byEditorSelected = EDITOR_ENVIRONMENT_SKY_CUBE_SIZE; break;

				case IDC_ENVIRONMENT_SKY_CUBE_PLUS:
					pLevel->Environment.iSkyCubeSurfaceRotation[byCurrentSkyCubeSide]++;
					if(pLevel->Environment.iSkyCubeSurfaceRotation[byCurrentSkyCubeSide] > 4)
						pLevel->Environment.iSkyCubeSurfaceRotation[byCurrentSkyCubeSide] = 0;
				break;

				case IDC_ENVIRONMENT_SKY_CUBE_MINUS:
					pLevel->Environment.iSkyCubeSurfaceRotation[byCurrentSkyCubeSide]--;
					if(pLevel->Environment.iSkyCubeSurfaceRotation[byCurrentSkyCubeSide] < 0)
						pLevel->Environment.iSkyCubeSurfaceRotation[byCurrentSkyCubeSide] = 4;
				break;

				case IDC_ENVIRONMENT_SKY_CUBE_ALL:
					for(i = 0; i < 6; i++)
					{
						pLevel->Environment.iSkyCubeSurface[i] = pLevel->iCurrentSurface;
						pLevel->Environment.iSkyCubeSurfaceRotation[i] = pLevel->Environment.iSkyCubeSurfaceRotation[byCurrentSkyCubeSide];
					}
				break;
			}
            break;
    }

    return FALSE;
} // end EditorDecorationProc()

void SetupEditorTabs(void)
{ // begin SetupEditorTabs()
	HWND hWndTab;
	TC_ITEM tie; 

	// Setup editor tabs:
	hWndTab = GetDlgItem(hWndEditor, IDC_EDITOR_TAB);
	TabCtrl_DeleteAllItems(hWndTab);
	tie.mask = TCIF_TEXT;
	// Select:
	tie.pszText	= AS_T(T_Select);
	TabCtrl_InsertItem(hWndTab, TAB_EDITOR_SELECT, &tie);
	if(hWndEditorTab[TAB_EDITOR_SELECT])
		DestroyWindow(hWndEditorTab[TAB_EDITOR_SELECT]);
	hWndEditorTab[TAB_EDITOR_SELECT] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_SELECT), hWndTab, (DLGPROC) EditorSelectProc, WM_INITDIALOG);
	// Brush:
	tie.pszText	= AS_T(T_Brush);
	TabCtrl_InsertItem(hWndTab, TAB_EDITOR_BRUSH, &tie);
	if(hWndEditorTab[TAB_EDITOR_BRUSH])
		DestroyWindow(hWndEditorTab[TAB_EDITOR_BRUSH]);
	hWndEditorTab[TAB_EDITOR_BRUSH] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_BRUSH), hWndTab, (DLGPROC) EditorBrushProc, WM_INITDIALOG);
	// Surfaces:
	tie.pszText	= AS_T(T_Surfaces);
	TabCtrl_InsertItem(hWndTab, TAB_EDITOR_SURFACES, &tie);
	if(hWndEditorTab[TAB_EDITOR_SURFACES])
		DestroyWindow(hWndEditorTab[TAB_EDITOR_SURFACES]);
	hWndEditorTab[TAB_EDITOR_SURFACES] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_SURFACES), hWndTab, (DLGPROC) EditorSurfacesProc, WM_INITDIALOG);
	// Objects:
	tie.pszText	= AS_T(T_Objects);
	TabCtrl_InsertItem(hWndTab, TAB_EDITOR_OBJECTS, &tie);
	if(hWndEditorTab[TAB_EDITOR_OBJECTS])
		DestroyWindow(hWndEditorTab[TAB_EDITOR_OBJECTS]);
	hWndEditorTab[TAB_EDITOR_OBJECTS] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_OBJECTS), hWndTab, (DLGPROC) EditorObjectsProc, WM_INITDIALOG);
	// Terrain:
	tie.pszText	= AS_T(T_Terrain);
	TabCtrl_InsertItem(hWndTab, TAB_EDITOR_TERRAIN, &tie);
	if(hWndEditorTab[TAB_EDITOR_TERRAIN])
		DestroyWindow(hWndEditorTab[TAB_EDITOR_TERRAIN]);
	hWndEditorTab[TAB_EDITOR_TERRAIN] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_TERRAIN), hWndTab, (DLGPROC) EditorTerrainProc, WM_INITDIALOG);
	// Environment:
	tie.pszText	= AS_T(T_Environment);
	TabCtrl_InsertItem(hWndTab, TAB_EDITOR_ENVIRONMENT, &tie);
	if(hWndEditorTab[TAB_EDITOR_ENVIRONMENT])
		DestroyWindow(hWndEditorTab[TAB_EDITOR_ENVIRONMENT]);
	hWndEditorTab[TAB_EDITOR_ENVIRONMENT] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_ENVIRONMENT), hWndTab, (DLGPROC) EditorEnvironmentProc, WM_INITDIALOG);
	// Camera:
	tie.pszText	= AS_T(T_Camera);
	TabCtrl_InsertItem(hWndTab, TAB_EDITOR_CAMERA, &tie);
	if(hWndEditorTab[TAB_EDITOR_CAMERA])
		DestroyWindow(hWndEditorTab[TAB_EDITOR_CAMERA]);
	hWndEditorTab[TAB_EDITOR_CAMERA] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_CAMERA), hWndTab, (DLGPROC) EditorCameraProc, WM_INITDIALOG);
	// Decoration:
	tie.pszText	= AS_T(T_DecorationAndSkyCube);
	TabCtrl_InsertItem(hWndTab, TAB_EDITOR_DECORATION, &tie);
	if(hWndEditorTab[TAB_EDITOR_DECORATION])
		DestroyWindow(hWndEditorTab[TAB_EDITOR_DECORATION]);
	hWndEditorTab[TAB_EDITOR_DECORATION] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_DECORATION), hWndTab, (DLGPROC) EditorDecorationProc, WM_INITDIALOG);

	//
	if(iCurrentEditorTab != -1 && iCurrentEditorTab < EDITOR_TABS)
	{
		TabCtrl_SetCurSel(GetDlgItem(hWndEditor, IDC_EDITOR_TAB), iCurrentEditorTab);
		ShowWindow(hWndEditorTab[iCurrentEditorTab], SW_SHOW);
	}
	SendMessage(hWndEditor, WM_NOTIFY, IDC_EDITOR_TAB, 0);
	ShowWindow(hWndEditor, _AS->GetCmdShow());
	UpdateWindow(hWndEditor);
} // end SetupEditorTabs()

void SetEditorLanguage(void)
{ // begin SetEditorLanguage()
	char byTemp[256];
	
	if(!hWndEditor)
		return;
	SetWindowText(hWndEditor, AS_T(T_Editor));
	SetDlgItemText(hWndEditor, IDC_EDITOR_SIZE_TEXT, AS_T(T_Size_));
	SetDlgItemText(hWndEditor, IDC_EDITOR_PAUSE, AS_T(T_Pause));

	// Setup the texts of the menu bar:
	HMENU hMenu = GetMenu(hWndEditor);
	MENUITEMINFO SubMenuInfo = { sizeof(MENUITEMINFO),
							     MIIM_ID | MIIM_TYPE,
								 MFT_STRING, MFS_DEFAULT,
								 ID_EDITOR_GENERAL_TEXTURES,
								 NULL, NULL, NULL, NULL,
								 AS_T(T_Textures), 0};
	ModifyMenu(hMenu, 0, MF_STRING | MF_BYPOSITION, 0, AS_T(T_General));
	SetMenuItemInfo(GetSubMenu(hMenu, 0), 0, TRUE, &SubMenuInfo);
	
	SubMenuInfo.wID = ID_EDITOR_GENERAL_CAMPAIGN_EDITOR;
	SubMenuInfo.dwTypeData = AS_T(T_CampaignEditor);
	SetMenuItemInfo(GetSubMenu(hMenu, 0), 1, TRUE, &SubMenuInfo);
	
	SubMenuInfo.wID = ID_EDITOR_GENERAL_TEXT_SCRIPT_EDITOR;
	SubMenuInfo.dwTypeData = AS_T(T_TextScriptEditor);
	SetMenuItemInfo(GetSubMenu(hMenu, 0), 2, TRUE, &SubMenuInfo);
	
	SubMenuInfo.wID = ID_EDITOR_GENERAL_GAME;
	SubMenuInfo.dwTypeData = AS_T(T_GoToGame);
	SetMenuItemInfo(GetSubMenu(hMenu, 0), 4, TRUE, &SubMenuInfo);

	SubMenuInfo.wID = ID_EDITOR_GENERAL_QUIT;
	sprintf(byTemp, "%s\tESC", AS_T(T_Quit));
	SubMenuInfo.dwTypeData = byTemp;
	SetMenuItemInfo(GetSubMenu(hMenu, 0), 6, TRUE, &SubMenuInfo);

	
	
	ModifyMenu(hMenu, 1, MF_STRING | MF_BYPOSITION, 0, AS_T(T_Level));

	SubMenuInfo.wID = ID_LEVEL_NEW;
	SubMenuInfo.dwTypeData = AS_T(T_New);
	SetMenuItemInfo(GetSubMenu(hMenu, 1), 0, TRUE, &SubMenuInfo);

	SubMenuInfo.wID = ID_LEVEL_LOAD;
	SubMenuInfo.dwTypeData = AS_T(T_Load);
	SetMenuItemInfo(GetSubMenu(hMenu, 1), 1, TRUE, &SubMenuInfo);

	SubMenuInfo.wID = ID_LEVEL_SAVE;
	sprintf(byTemp, "%s\tF2", AS_T(T_Save));
	SubMenuInfo.dwTypeData = byTemp;
	SetMenuItemInfo(GetSubMenu(hMenu, 1), 2, TRUE, &SubMenuInfo);

	SubMenuInfo.wID = ID_LEVEL_SAVE_AS;
	SubMenuInfo.dwTypeData = AS_T(T_SaveAs);
	SetMenuItemInfo(GetSubMenu(hMenu, 1), 3, TRUE, &SubMenuInfo);

	SubMenuInfo.wID = ID_LEVEL_ADJUST;
	sprintf(byTemp, "%s\tF3", AS_T(T_Adjust));
	SubMenuInfo.dwTypeData = byTemp;
	SetMenuItemInfo(GetSubMenu(hMenu, 1), 4, TRUE, &SubMenuInfo);

	SubMenuInfo.wID = ID_LEVEL_PLAY;
	SubMenuInfo.dwTypeData = AS_T(T_Play);
	SetMenuItemInfo(GetSubMenu(hMenu, 1), 6, TRUE, &SubMenuInfo);


	ModifyMenu(hMenu, 2, MF_STRING | MF_BYPOSITION, 0, AS_T(T_Configurations));
	
	SubMenuInfo.wID = ID_OPTIONS_CONFIG;
	sprintf(byTemp, "%s\tF12", AS_T(T_Configurations));
	SubMenuInfo.dwTypeData = byTemp;
	SetMenuItemInfo(GetSubMenu(hMenu, 2), 0, TRUE, &SubMenuInfo);
	
	SubMenuInfo.wID = ID_OPTIONS_SHOW_LOG;
	SubMenuInfo.dwTypeData = AS_T(T_ShowLog);
	SetMenuItemInfo(GetSubMenu(hMenu, 2), 1, TRUE, &SubMenuInfo);


	ModifyMenu(hMenu, 3, MF_STRING | MF_BYPOSITION, 0, AS_T(T_Help));
	
	SubMenuInfo.wID = ID_HELP_HELP;
	sprintf(byTemp, "%s\tF1", AS_T(T_Help));
	SubMenuInfo.dwTypeData = byTemp;
	SetMenuItemInfo(GetSubMenu(hMenu, 3), 0, TRUE, &SubMenuInfo);
	
	SubMenuInfo.wID = ID_HELP_CREACTIVE_MEDIA_HOMEPAGE;
	SubMenuInfo.dwTypeData = AS_T(T_CreactiveMediaHomepage);
	SetMenuItemInfo(GetSubMenu(hMenu, 3), 1, TRUE, &SubMenuInfo);

	SubMenuInfo.wID = ID_HELP_ECLYPSE_ENTERTAINMENT_HOMEPAGE;
	SubMenuInfo.dwTypeData = AS_T(T_EclypseEntertainmentHomepage);
	SetMenuItemInfo(GetSubMenu(hMenu, 3), 2, TRUE, &SubMenuInfo);

	SubMenuInfo.wID = ID_HELP_CREDITS;
	SubMenuInfo.dwTypeData = AS_T(T_Credits);
	SetMenuItemInfo(GetSubMenu(hMenu, 3), 3, TRUE, &SubMenuInfo);

	DrawMenuBar(hWndEditor);
	SetupEditorTabs();
} // end SetEditorLanguage()

LRESULT CALLBACK KeywordProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin KeywordProc()
	char byTemp[256];

    switch(iMessage)
    {
        case WM_INITDIALOG:
			hWndKeyword = hWnd;
			KeywordLanguage();
			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
			BringWindowToTop(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_KEYWORD_OK:
					hWndKeyword = NULL;
					// Check if this keyword is right:
					GetDlgItemText(hWnd, ID_KEYWORD_KEYWORD, byTemp, 256);
					if(!strcmp(byKeyword, byTemp))
						EndDialog(hWnd, 1);
					else
						EndDialog(hWnd, 0);
                return TRUE;

                case ID_KEYWORD_CANCEL:
					hWndKeyword = NULL;
					EndDialog(hWnd, -1);
                return TRUE;
            }
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_KEYWORD_CANCEL, 0);
		break;
    }

    return FALSE;
} // end KeywordProc()

void KeywordLanguage(void)
{ // begin KeywordLanguage()
	SetWindowText(hWndKeyword, AS_T(T_Keyword));
	SetDlgItemText(hWndKeyword, ID_SET_ANIMATION_STEPS_OK, AS_T(T_Ok));
	SetDlgItemText(hWndKeyword, ID_SET_ANIMATION_STEPS_CANCEL, AS_T(T_Cancel));
} // end KeywordLanguage()

HRESULT SaveLevelQuestion(void)
{ // begin SaveLevelQuestion()
	char *pbyTemp, byTemp[256];
	int i;
	
	KillTimer(hWndEditor, 1);
	i = MessageBox(hWndEditor, AS_M(M_SaveCurrentLevelQuestion), AS_T(T_Question), MB_YESNOCANCEL | MB_ICONQUESTION);
	SetTimer(hWndEditor, 1, 1, NULL);
	if(i == IDCANCEL)
		return 1;
	if(i == IDYES)
	{ // Save the current level:
		_AS->WriteLogMessage("Save level %s", pLevel->Header.byFilename);
		sprintf(byTemp, "%s%s", _AS->byProgramPath, _AS->bySingleLevelsDirectory);
		KillTimer(hWndEditor, 1);
		pbyTemp = ASGetFileName(hWndEditor, AS_T(T_SaveLevel), LEV_FILE, 1, FALSE, byTemp, NULL);
		SetTimer(hWndEditor, 1, 1, NULL);
		if(!pbyTemp)
			return 1;
		pLevel->Save(pbyTemp);
	}

	return 0;
} // end SaveLevelQuestion();

LRESULT CALLBACK SetCameraVelocityProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin SetCameraVelocityProc()
	char byTemp[256];

    switch(iMessage)
    {
        case WM_INITDIALOG:
			SetWindowText(hWnd, AS_T(T_CameraVelocity));
			SetDlgItemText(hWnd, ID_SET_CAMERA_VELOCITY_OK, AS_T(T_Ok));
			SetDlgItemText(hWnd, ID_SET_CAMERA_VELOCITY_CANCEL, AS_T(T_Cancel));
			sprintf(byTemp, "%f", fCameraVelocity);
			SetDlgItemText(hWnd, ID_SET_CAMERA_VELOCITY_NUMBER, byTemp);
			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
			BringWindowToTop(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_SET_CAMERA_VELOCITY_OK:
					GetDlgItemText(hWnd, ID_SET_CAMERA_VELOCITY_NUMBER, byTemp, 256);
					fCameraVelocity = (float) atof(byTemp);
					EndDialog(hWnd, 0);
                return TRUE;

                case ID_SET_CAMERA_VELOCITY_CANCEL: EndDialog(hWnd, 0); return TRUE;
            }
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_SET_CAMERA_VELOCITY_CANCEL, 0);
		break;
    }

    return FALSE;
} // end SetCameraVelocityProc()

LRESULT CALLBACK CopyCameraStepProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin CopyCameraStepProc()
	char byTemp[256];
	int i;

    switch(iMessage)
    {
        case WM_INITDIALOG:
			sprintf(byTemp, "%s (Nr. %d)", AS_T(T_CopyTexturePos), pLevel->Camera.iCurrentCameraStep);
			SetWindowText(hWnd, byTemp);
			SetDlgItemText(hWnd, ID_COPY_CAMERA_STEP_OK, AS_T(T_Ok));
			SetDlgItemText(hWnd, ID_COPY_CAMERA_STEP_CANCEL, AS_T(T_Cancel));
			SendDlgItemMessage(hWnd, ID_COPY_CAMERA_STEP_LIST, CB_RESETCONTENT , 0, 0L);
			for(i = 0; i < pLevel->pCurrentCameraScript->iSteps; i++)
			{
				sprintf(byTemp, "%d", i);
				SendDlgItemMessage(hWnd, ID_COPY_CAMERA_STEP_LIST, CB_ADDSTRING, 0, (LPARAM) byTemp);
			}
			SendDlgItemMessage(hWnd, ID_COPY_CAMERA_STEP_LIST, CB_SETCURSEL, pLevel->Camera.iCurrentCameraStep, 0L);
			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
			BringWindowToTop(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_COPY_CAMERA_STEP_OK:
					EndDialog(hWnd, SendDlgItemMessage(hWnd, ID_COPY_CAMERA_STEP_LIST, CB_GETCURSEL, 0, 0L));
                return TRUE;

                case ID_COPY_CAMERA_STEP_CANCEL: EndDialog(hWnd, -1); return TRUE;
            }
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_COPY_CAMERA_STEP_CANCEL, 0);
		break;
    }

    return FALSE;
} // end CopyCameraStepProc()

LRESULT CALLBACK SetCameraStepsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin SetCameraStepsProc()
	char byTemp[256];
	int i;

    switch(iMessage)
    {
        case WM_INITDIALOG:
			SetWindowText(hWnd, AS_T(T_SetCameraSteps));
			SetDlgItemText(hWnd, ID_SET_CAMERA_STEPS_OK, AS_T(T_Ok));
			SetDlgItemText(hWnd, ID_SET_CAMERA_STEPS_CANCEL, AS_T(T_Cancel));
			sprintf(byTemp, "%d", pLevel->pCurrentCameraScript->iSteps);
			SetDlgItemText(hWnd, ID_SET_CAMERA_STEPS_NUMBER, byTemp);
			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
			BringWindowToTop(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_SET_CAMERA_STEPS_OK:
					GetDlgItemText(hWnd, ID_SET_CAMERA_STEPS_NUMBER, byTemp, 256);
					i = (int) atoi(byTemp);
					if(!i)
						i++;
					EndDialog(hWnd, i);
                return TRUE;

                case ID_SET_CAMERA_STEPS_CANCEL: EndDialog(hWnd, -1); return TRUE;
            }
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_SET_CAMERA_STEPS_CANCEL, 0);
		break;
    }

    return FALSE;
} // end SetCameraStepsProc()

void FillItemListElement(HWND hWnd, int iID)
{ // begin FillItemListElement()
	SendDlgItemMessage(hWnd, iID, CB_RESETCONTENT , 0, 0L);
	SendDlgItemMessage(hWnd, iID, CB_SETITEMDATA, SendDlgItemMessage(hWnd, iID, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Health)), 0);
	SendDlgItemMessage(hWnd, iID, CB_SETITEMDATA, SendDlgItemMessage(hWnd, iID, CB_ADDSTRING, 0, (LPARAM) AS_T(T_HealthIncrease)), 1);
	SendDlgItemMessage(hWnd, iID, CB_SETITEMDATA, SendDlgItemMessage(hWnd, iID, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Life)), 2);
	SendDlgItemMessage(hWnd, iID, CB_SETITEMDATA, SendDlgItemMessage(hWnd, iID, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Pull)), 3);
	SendDlgItemMessage(hWnd, iID, CB_SETITEMDATA, SendDlgItemMessage(hWnd, iID, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Chest)), 4);
	SendDlgItemMessage(hWnd, iID, CB_SETITEMDATA, SendDlgItemMessage(hWnd, iID, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Strength)), 5);
	SendDlgItemMessage(hWnd, iID, CB_SETITEMDATA, SendDlgItemMessage(hWnd, iID, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Weapon)), 6);
	SendDlgItemMessage(hWnd, iID, CB_SETITEMDATA, SendDlgItemMessage(hWnd, iID, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Coin)), 7);
	SendDlgItemMessage(hWnd, iID, CB_SETITEMDATA, SendDlgItemMessage(hWnd, iID, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Ghost)), 8);
	SendDlgItemMessage(hWnd, iID, CB_SETITEMDATA, SendDlgItemMessage(hWnd, iID, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Time)), 9);
	SendDlgItemMessage(hWnd, iID, CB_SETITEMDATA, SendDlgItemMessage(hWnd, iID, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Step)), 10);
	SendDlgItemMessage(hWnd, iID, CB_SETITEMDATA, SendDlgItemMessage(hWnd, iID, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Speed)), 11);
	SendDlgItemMessage(hWnd, iID, CB_SETITEMDATA, SendDlgItemMessage(hWnd, iID, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Wings)), 12);
	SendDlgItemMessage(hWnd, iID, CB_SETITEMDATA, SendDlgItemMessage(hWnd, iID, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Shield)), 13);
	SendDlgItemMessage(hWnd, iID, CB_SETITEMDATA, SendDlgItemMessage(hWnd, iID, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Jump)), 14);
	SendDlgItemMessage(hWnd, iID, CB_SETITEMDATA, SendDlgItemMessage(hWnd, iID, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Air)), 15);
	SendDlgItemMessage(hWnd, iID, CB_SETITEMDATA, SendDlgItemMessage(hWnd, iID, CB_ADDSTRING, 0, (LPARAM) AS_T(T_AirIncrease)), 16);
	SendDlgItemMessage(hWnd, iID, CB_SETITEMDATA, SendDlgItemMessage(hWnd, iID, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Throw)), 17);
	SendDlgItemMessage(hWnd, iID, CB_SETITEMDATA, SendDlgItemMessage(hWnd, iID, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Kick)), 18);
	SendDlgItemMessage(hWnd, iID, CB_SETITEMDATA, SendDlgItemMessage(hWnd, iID, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Bag)), 19);
	SendDlgItemMessage(hWnd, iID, CB_SETITEMDATA, SendDlgItemMessage(hWnd, iID, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Dynamite)), 20);
} // end FillItemListElement()
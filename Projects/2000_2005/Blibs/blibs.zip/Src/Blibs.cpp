//-----------------------------------------------------------------------------
// File: Blibs.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
AS_CAMERA *pCamera;			// The main game camera
HWND hWndCredits;			// The dialog handle of the credits dialog
BOOL bOnlyConfig,			// Should only the config dialog be shown? (no game run after this...)
	 bLoader;				// Started with the loader program?
// Cheats:
BOOL bCheatsActivated,		// Are the cheats active?
	 bInvulnerable,			// Are we invulnerable?
	 bFreeCamera,			// Is it allowed to move/rotate the camera absolutely free?
	 bAllLevels,			// Is it possible to select all levels?
	 bBlibsPeeping;			// Fun cheat: If Blibs walks backward its feeler blinking :)
// Master access: (only for me!! ;-)
BOOL bMasterAccess;			// Is the master access activated? (no keywords... hehe)
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int);
void ChangeDisplayMode(void);
void OpenCreditsDialog(HWND);
LRESULT CALLBACK CreditsProc(HWND, UINT, WPARAM, LPARAM);
void OpenHelp(void);
void OpenCreactiveMediaHomepage(void);
void OpenEclypseEntertainmentHomepage(void);
///////////////////////////////////////////////////////////////////////////////


int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine, int iCmdShow)
{ // begin WinMain()
	BOOL bOpenConfig, bGame, bEditor, bLanguage;
	char byTemp[MAX_PATH];
	LPSTR lpTemp;

	// Startup the engine:
	_AS = new AS_ENGINE(hInstance, lpCmdLine, iCmdShow, TRUE);
	if(_AS->GetShutDown())
		return 1;
/*
long lStart, lEnd, lTime, i;

	float fSin;

lStart = GetTickCount();
for(i = 0; i < 1000000; i++)
	fSin = (float) sin(25.0f);
lEnd = GetTickCount();
lTime = lEnd-lStart;
*/
/*
AS_VECTOR3D vPoint, vNormal, vP1, vP2, vP3;
int i;
long lStart, lEnd, lTime;
 vP1.fX = 1.1f;
 vP2.fZ = 2.5f;
 vP2 = -1;
 vNormal.GetFaceNormal(vP1, vP2, vP3);


lStart = GetTickCount();
for(i = 0; i < 100000; i++)
{
	ASCheckPointInTriangle(vPoint, vNormal, vP1, vP2, vP3);
}
lEnd = GetTickCount();
lTime = lEnd-lStart;


lStart = GetTickCount();
for(i = 0; i < 100000; i++)
{
	ASCheckPointInTriangle(vPoint, vP1, vP2, vP3);
}
lEnd = GetTickCount();
lTime = lEnd-lStart;

	delete _AS;

	return 1;*/


	// Setup the camera:
	_ASCamera = pCamera = new AS_CAMERA;

	// Setup the language:
	bLanguage = SetStartLanguage();
	
	// Is this the first program start?:
	if(_ASConfig->bFirstRun)
	{ // Yep!
		_AS->WriteLogMessage("First program start detected");
		MessageBox(NULL, AS_M(M_FirstProgramStart), GAME_NAME, MB_OK | MB_ICONINFORMATION);
	}

	// Check the given program parameters:
	bCheatsActivated = FALSE;
	bInvulnerable = FALSE;
	bFreeCamera = FALSE;
	bAllLevels = FALSE;
	bBlibsPeeping = FALSE;
	bMasterAccess = FALSE;
	bOpenConfig = FALSE;
	bOnlyConfig = FALSE;
	bGame = FALSE;
	bEditor = FALSE;
	lpTemp = lpCmdLine;
	for(;;)
	{
		if(sscanf(lpTemp, "%s", byTemp) == EOF)
			break;

		// Check the program parameter:
		if(!strcmp(byTemp, "-config"))
			bOpenConfig = TRUE;
		if(!strcmp(byTemp, "-onlyconfig"))
			bOnlyConfig = TRUE;
		if(!strcmp(byTemp, "-loader"))
			bLoader = TRUE;
		if(!strcmp(byTemp, "-game"))
			bGame = TRUE;
		if(!strcmp(byTemp, "-editor"))
			bEditor = TRUE;
		// Check the cheats:
		if(!strcmp(byTemp, "-cheats"))
		{
			_AS->WriteLogMessage("Cheats activated");
			bCheatsActivated = TRUE;
		}
		// Check the master access:
		if(!strcmp(byTemp, "-MasterAccess"))
		{
			_AS->WriteLogMessage("Master Access");
			bMasterAccess = TRUE;
		}
		if(!strcmp(byTemp, "-all_levels"))
			bAllLevels = TRUE;
		if(!strcmp(byTemp, "-peep"))
			bBlibsPeeping = TRUE;
		if(*(lpTemp+strlen(byTemp)) == 0)
			break;
		lpTemp += strlen(byTemp)+1;
	}
	
	// Is an error detected? (from the last run)
	if(_ASConfig->bError)
	{
		_AS->WriteLogMessage("Program wasn't shut down correctly at the last time");
		MessageBox(NULL, AS_M(M_ProgramWasNotSutDownCorrectlyAtLastTime), GAME_NAME, MB_OK | MB_ICONINFORMATION);
	}
	
	// Check if we want to show the config dialog:
	if(bOpenConfig || bOnlyConfig || _ASConfig->bFirstRun || _ASConfig->bError)
	{
		bFirstRunConfigDialog = TRUE;
		OpenConfigDialog(NULL);
		bFirstRunConfigDialog = FALSE;
	}
	
	if(!bOnlyConfig)
	{


//		bAllLevels = TRUE;
//		bCheatsActivated = TRUE;
//		bMasterAccess = TRUE;


		// Set the current program module:
		if(_AS->bStartEditor)
			_AS->SetModule(MODULE_EDITOR);
		else
			_AS->SetModule(MODULE_GAME);

//		_AS->SetModule(MODULE_GAME);

		// The given program parameter forces the program to go into the required game module:
		bShowLogos = _AS->bShowLogos;
		_AS->bShowLogos = TRUE;
		if(bGame)
			_AS->SetModule(MODULE_GAME);
		else
			if(bEditor)
			{
				bShowLogos = FALSE;
				_AS->SetModule(MODULE_EDITOR);
			}

		// Load all sound samples:
		LoadSamples();

		// Load all global game data:
		InitGameObjects();
		LoadGameTextures();
		
		if(bCheatsActivated)	
			ShowSmallMessage(AS_T(T_CheatsActivated), 3000);

		// Go into the main loop:
		_ASConfig->bError = TRUE;
		_AS->WriteLogMessage("Go into program loop");
		for(;;)
		{
			if(_AS->GetShutDown())
				break;
			_AS->SetModule(_AS->GetNextModule());

			// Go into the current program module:
			switch(_AS->GetModule())
			{
				case MODULE_GAME: Game(); break;
				case MODULE_EDITOR: Editor(); bShowLogos = FALSE; break;
			}
		}

		// Destroy all sound samples:
		ASDestroyFmodSamples(GAME_SAMPLES, GameSample);

		// Destroy all global game data:
		DestroyGameObjects();
		ActorDestroyTextures(TRUE);
		ASDestroyTextures(GAME_TEXTURES, GameTexture);
		ASDestroyTexture(&TempSaveScreenshot);
	}
	if(bLoader)
	{ // Start the Blibs loader program:
		_AS->WriteLogMessage("Open loader program");
		sprintf(byTemp, "%sBlibsLoader.exe", _AS->byProgramPath);
		ShellExecute(0, "open", byTemp, 0, 0, SW_SHOW);
	}
		
	// Delete the rest:
	delete pCamera;
	delete _AS;
	
	// That's all!
	return 0;
} // end WinMain()

void ChangeDisplayMode(void)
{ // begin ChangeDisplayMode()
	switch(_AS->GetModule())
	{
		case MODULE_GAME:
			_AS->WriteLogMessage("Change display mode");

			// Destroy the old window:
			_AS->FreeDXInputDevices();
			DestroyCreditsTextures();
			ASDestroyOpenGLTextures(GAME_TEXTURES, GameTexture);
			ASDestroyOpenGLTextures(GAME_MENU_TEXTURES, GameMenuTexture);
			ASDestroyOpenGLTextures(LOGOS_TEXTURES, LogosTexture);
			ASDestroyOpenGLTextures(ACTOR_TEXTURES, ActorTexture);
			ASDestroyOpenGLTextures(1, &PlayerSaveGame.Screenshot);
			DestroyBlurTexture();
			DestroyGameLists();

			if(pLevel)
				pLevel->DestroyTexturesOpenGL(*_AS->pWindow[GAME_WINDOW_ID].GethDC(), 
										      *_AS->pWindow[GAME_WINDOW_ID].GethRC());
			ASDestroyOpenGL(&_AS->pWindow[GAME_WINDOW_ID], 
							NULL,
							*_AS->pWindow[GAME_WINDOW_ID].GethDC(),
							*_AS->pWindow[GAME_WINDOW_ID].GethRC());
			_AS->ASDestroyWindow(_AS->pWindow[GAME_WINDOW_ID].GethWnd(), GAME_WINDOW_NAME);
			// Create the new window:
			_AS->ASCreateWindow(WindowProc, GAME_WINDOW_NAME, GAME_WINDOW_NAME, _ASConfig->iWindowWidth,
								_ASConfig->iWindowHeight, LoadMenu(_AS->GetInstance(), MAKEINTRESOURCE(IDR_GAME)),
								_ASConfig->bFullScreen, GameMenuDraw, GameMenuCheck, NULL, TRUE);
			GAME_WINDOW_ID = _AS->GetWindows()-1;
			SetGameLanguage();
			if(bShowLogos)
			{
				_AS->pWindow[GAME_WINDOW_ID].SetDrawFunction(LogosDraw);
				_AS->pWindow[GAME_WINDOW_ID].SetCheckFunction(LogosCheck);
			}
			else
			if(!bInGameMenu)
			{
				_AS->pWindow[GAME_WINDOW_ID].SetDrawFunction(GameDraw);
				_AS->pWindow[GAME_WINDOW_ID].SetCheckFunction(GameCheck);
			}
			ASInitOpenGL(&_AS->pWindow[GAME_WINDOW_ID], 
  						 NULL,
						 _AS->pWindow[GAME_WINDOW_ID].GethDC(),
						 _AS->pWindow[GAME_WINDOW_ID].GethRC(), _ASConfig->bFullScreen);
			_AS->CreateDXInputDevices(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), FALSE, TRUE, TRUE, FALSE);
			if(pLevel)
				pLevel->GenTexturesOpenGL(*_AS->pWindow[GAME_WINDOW_ID].GethDC(), 
										  *_AS->pWindow[GAME_WINDOW_ID].GethRC());
			LoadCreditsTextures();
			ASGenOpenGLTextures(GAME_TEXTURES, GameTexture);
			ASGenOpenGLTextures(GAME_MENU_TEXTURES, GameMenuTexture);
			ASGenOpenGLTextures(LOGOS_TEXTURES, LogosTexture);
			ASGenOpenGLTextures(ACTOR_TEXTURES, ActorTexture);
			ASGenOpenGLTextures(1, &PlayerSaveGame.Screenshot);
			CreateBlurTexture();
			CreateGameLists();
			ShowWindow(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), SW_SHOW);
			ShowWindow(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), SW_SHOWNORMAL);
			UpdateWindow(*_AS->pWindow[GAME_WINDOW_ID].GethWnd());
			SetForegroundWindow(*_AS->pWindow[GAME_WINDOW_ID].GethWnd());
			SetFocus(*_AS->pWindow[GAME_WINDOW_ID].GethWnd());
		break;
	}
} // end ChangeDisplayMode()

void OpenCreditsDialog(HWND hWnd)
{ // begin OpenCreditsDialog()
	DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CREDITS), hWnd, (DLGPROC) CreditsProc);
} // end OpenCreditsDialog()

LRESULT CALLBACK CreditsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin CreditsProc()
	char byTemp[256];

	switch(iMessage)
    {
        case WM_INITDIALOG:
				_AS->WriteLogMessage("Open credits dialog");
			    hWndCredits = hWnd;
				ShowWindow(hWnd, _AS->GetCmdShow());
				UpdateWindow(hWnd);
            	SetDlgItemText(hWnd, IDC_CREDITS_VERSION, _ASProgramInfo.byVersion);
            	SetDlgItemText(hWnd, IDC_CREDITS_BUILD_DATE, _ASProgramInfo.byDate);
            	SetDlgItemText(hWnd, IDC_CREDITS_BUILD_TIME, _ASProgramInfo.byTime);
				// Texts:
				SetWindowText(hWnd, AS_T(T_Credits));
				SetDlgItemText(hWnd, IDC_CREDITS_VERSION_TEXT, AS_T(T_Version_));
  				SetDlgItemText(hWnd, IDC_CREDITS_PROGRAM_INFO, AS_T(T_ProgramInfo_));
  				SetDlgItemText(hWnd, IDC_CREDITS_BUILD, AS_T(T_Build_));
  				SetDlgItemText(hWnd, IDC_CREDITS_OK, AS_T(T_Ok));
  				SetDlgItemText(hWnd, IDC_CREDITS_MORE, AS_T(T_MoreCredits));
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case IDC_CREDITS_OK:
					EndDialog(hWnd, FALSE);
					hWndCredits = NULL;
					_AS->WriteLogMessage("Close credits dialog(OK)");
                return TRUE;

				case ID_CREDITS_ECLYPSE_ENTERTAINMENT_HOMEPAGE:
					_AS->WriteLogMessage("Open Eclypse Entertainment homepage");
					ShellExecute(0, "open", "http://www.eclypse.de/", 0, 0, SW_SHOW);
				break;

				case ID_CREDITS_CREACTIVE_MEDIA_HOMEPAGE:
					_AS->WriteLogMessage("Open Creactive Media homepage");
					ShellExecute(0, "open", "http://www.creactive-media.de/", 0, 0, SW_SHOW);
				break;

				case IDC_CREDITS_MORE:
					_AS->WriteLogMessage("Open help file");
					sprintf(byTemp, "%s%s", _AS->byProgramPath, T_CreditsFile);
					ShellExecute(0, "open", byTemp, 0, 0, SW_SHOW);
				break;
            }
        break;

		case WM_CLOSE: SendMessage(hWnd, WM_COMMAND, IDC_CREDITS_OK, 0); break;
    }
    return FALSE;
} // end CreditsProc()

void OpenHelp(void)
{ // begin OpenHelp()
	char byTemp[256];

	_AS->WriteLogMessage("Open help file");
	if(_AS->GetWindows())
		SendMessage(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), WM_SYSCOMMAND, SC_MINIMIZE, 0);
	sprintf(byTemp, "%s%s", _AS->byProgramPath, pbyASHelpFile);
	ShellExecute(0, "open", byTemp, 0, 0, SW_SHOW);
} // end OpenHelp()

void OpenCreactiveMediaHomepage(void)
{ // begin OpenCreactiveMediaHomepage()
	_AS->WriteLogMessage("Open Creactive Media homepage");
	if(_AS->GetWindows())
		SendMessage(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), WM_SYSCOMMAND, SC_MINIMIZE, 0);
	ShellExecute(0, "open", "http://www.creactive-media.de/", 0, 0, SW_SHOW);
} // end OpenCreactiveMediaHomepage()

void OpenEclypseEntertainmentHomepage(void)
{ // begin OpenEclypseEntertainmentHomepage()
	_AS->WriteLogMessage("Open Eclypse Entertainment homepage");
	if(_AS->GetWindows())
		SendMessage(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), WM_SYSCOMMAND, SC_MINIMIZE, 0);
	ShellExecute(0, "open", "http://www.eclypse.de/", 0, 0, SW_SHOW);
} // end OpenEclypseEntertainmentHomepage()
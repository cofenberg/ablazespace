//-----------------------------------------------------------------------------
// File: Sound.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
char byCurrentMusic[256]; // The current played music file
AS_FMOD_SAMPLE GameSample[GAME_SAMPLES];
AS_FMOD_SAMPLE *pCollectSample = &GameSample[0],
			   *pChangeSample = &GameSample[1],
			   *pBlibsShotSample = &GameSample[2],
			   *pBeamerSample = &GameSample[3],
			   *pExplosion1Sample = &GameSample[4],
			   *pSelectSample = &GameSample[5],
			   *pBlibsDeathSample = &GameSample[6],
			   *pMobmobDeathSample = &GameSample[7],
			   *pBlibsShotDeathSample = &GameSample[8],
			   *pBoxToBridgeSample = &GameSample[9],
			   *pBlibsJumpSample = &GameSample[10],
			   *pBoxDeathSample = &GameSample[11],
			   *pBlibsWrongSample = &GameSample[12],
			   *pMobmobAttackSample = &GameSample[13],
			   *pBlibsPainSample = &GameSample[14],
			   *pInputSample = &GameSample[15],
			   *pPeepSample = &GameSample[16],
			   *pBlibsKickSample = &GameSample[17],
			   *pLuciferDamageSample = &GameSample[18],
			   *pLuciferLaughSample = &GameSample[19],
			   *pShieldHitSample = &GameSample[20];
AS_FMOD_MUSIC GameMusic;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
void LoadSamples(void);
void StartCurrentMusic(void);
void RestartSoundSystem(void);
void StartMusic(char *);
void StopMusic(void);
void CheckMusic(void);
///////////////////////////////////////////////////////////////////////////////


void LoadSamples(void)
{ // begin LoadSamples()
	char byFilename[GAME_SAMPLES][256] = {"Collect.wav", "Change.wav",
										  "BlibsShot.wav", "Beamer.wav",
										  "Explosion1.wav", "Select.wav",
										  "BlibsDeath.wav", "MobmobDeath.wav",
										  "BlibsShotDeath.wav", "BoxToBridge.wav",
										  "BlibsJump.wav", "BoxDeath.wav",
										  "BlibsWrong.wav", "MobmobAttack.wav",
										  "BlibsPain.wav", "Input.wav",
										  "Peep.wav", "BlibsKick.wav",
										  "LuciferDamage.wav", "LuciferLaugh.wav",
										  "ShieldHit.wav"};
	
	ASLoadFmodSamples(byFilename, GAME_SAMPLES, GameSample);
} // end LoadSamples()

void StartCurrentMusic(void)
{ // begin StartCurrentMusic()
	if(!_AS->bSoundPossible || !_ASConfig->bMusic)
		return;
	ASDestroyFmodMusic(&GameMusic);

	// Play the game music:
	_AS->WriteLogMessage("Load music: %s", byCurrentMusic);
	if(ASPlayFmodMusic(&GameMusic, byCurrentMusic))
		_AS->WriteLogMessage("Couldn't load this music!");
} // end StartCurrentMusic()

void RestartSoundSystem(void)
{ // begin RestartSoundSystem()
	_AS->WriteLogMessage("Restart sound system");

	ASDestroyFmodSamples(GAME_SAMPLES, GameSample);
	StopMusic();
	ASDestroyFmod();
	ASInitFmod();
	LoadSamples();
	StartCurrentMusic();
} // end RestartSoundSystem()

void StartMusic(char *pbyFilename)
{ // begin StartMusic()
	char byTemp[256];
 
	sprintf(byTemp, "%s%s\\%s", _AS->byProgramPath, _AS->byMusicDirectory, pbyFilename);
	if(!strcmp(byCurrentMusic, byTemp))
		return;
	ASDestroyFmodMusic(&GameMusic);

	// Play the menu music:
	sprintf(byCurrentMusic, "%s%s\\%s", _AS->byProgramPath, _AS->byMusicDirectory, pbyFilename);
	if(!_AS->bSoundPossible || !_ASConfig->bMusic)
		return;
	_AS->WriteLogMessage("Load music: %s", byCurrentMusic);
	if(ASPlayFmodMusic(&GameMusic, byCurrentMusic))
		_AS->WriteLogMessage("Couldn't load this music!");
} // end StartMusic()

void StopMusic(void)
{ // begin StopMusic()
	if(!_AS->bSoundPossible)
		return;
	ASDestroyFmodMusic(&GameMusic);
	memset(&GameMusic, 0, sizeof(AS_FMOD_MUSIC));
} // end StopMusic()

void CheckMusic(void)
{ // begin CheckMusic()
	if((GameMusic.pMod && !FMUSIC_IsFinished(GameMusic.pMod)) ||
	   !bASMusicFinished)
		return; // The music is still playing!
	StartCurrentMusic(); // Restart the current music!
} // end CheckMusic()
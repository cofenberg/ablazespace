//-----------------------------------------------------------------------------
// File: Surface.h
//-----------------------------------------------------------------------------

#ifndef __SURFACE_H__
#define __SURFACE_H__


// Classes: *******************************************************************
typedef struct TEXTURE_POS
{
	INT2 iPos[9];	// The 'real' pixel position in the bitmap
	FLOAT2 fPos[9]; // The float position (1.0f is the maximum...)
	long iTimeToNext; // The time to the next animation step

} TEXTURE_POS;


typedef struct SURFACE_HEADER
{
	char byFilename[256]; // The surface filename
	char byName[256]; // The name of the surface (title)
	int iID; // The ID
	int iAniSteps; // The number of animation steps

	// Attributes:
	BOOL bAlcove, // Is this surface an alcove?
		 bRadioactive, // Is it radioactive?
		 bHealth, // Is it a health surface?
		 bExit, // Is this a exit?
		 bAnchor, // Is this surface an anchor?
		 bColorPainter,  // Is this an color painter?
		 bColorScanner,  // Is this an color scanner?
		 bBeamer, // Is this a beamer?
		 bEnvironmentMappingS, // Should environment mapping be used?
		 bEnvironmentMappingT, // Should environment mapping be used?
		 bHole; // Is this an hole? (the actors fall through)
	char byAnchorType, // If it's an anchor, then which type of anchor?
		 byColorPainterType, // If it's an color painter, then which type of color painter?
		 byColorScannerType; // If it's an color scanner, then which type of color scanner?

	// Surface change stuff:
	BOOL bChangeOnEnter,
		 bChangeOnLeave,
		 bChangeOnAnimationEnd,
		 bChangeOnTime;
	int iChangeOnEnterSurface,
		iChangeOnLeaveSurface,
		iChangeOnAnimationEndSurface,
		iChangeOnTimeSurface;
	long lChangeTime; // The last change time
	
	float fAlcoveSpeed, // The the health speed
		  fRadioactiveSpeed, // The the damage speed
		  fHealthSpeed, // The the health speed
		  fFriction; // The friction of this surface

} SURFACE_HEADER;

typedef class SURFACE
{
	public:

		SURFACE_HEADER Header; // General information

		int iUsed; // How many times is this surface used?
		char **byTextureFilename; // The texture filenames
		TEXTURE_POS *pTexturePos; // The position in a texture (for each animation step)
		int *iTextureID; // The texture ID (for each animation step)
		AS_TEXTURE **pTexture; // A pointer to the texture (for each animation step)


		SURFACE(void);
		~SURFACE(void);
		HRESULT Load(char *);
		HRESULT Save(char *);
		void CalculateFloatTexturePos(void);
		void ChangeAnimationSteps(int);
		void Destroy(void);

} SURFACE;

///////////////////////////////////////////////////////////////////////////////
// Definitions: ***************************************************************
///////////////////////////////////////////////////////////////////////////////
// Variables: *****************************************************************
extern HWND hWndSurfaces, hWndSurface, hWndTextures, hWndObjects;
extern BOOL bSurfaceSave, bLoadTexture;
extern FLOAT3 fTextureViewPos;
extern int iCurrentTexturePos, iCurrentTextureAniStep;
extern char byFilenameTemp[MAX_PATH];
///////////////////////////////////////////////////////////////////////////////
// Functions: *****************************************************************
extern LRESULT CALLBACK SurfacesProc(HWND, UINT, WPARAM, LPARAM);
extern LRESULT CALLBACK SurfaceProc(HWND, UINT, WPARAM, LPARAM);
extern LRESULT CALLBACK TexturesProc(HWND, UINT, WPARAM, LPARAM);
///////////////////////////////////////////////////////////////////////////////


#endif // __SURFACE_H__
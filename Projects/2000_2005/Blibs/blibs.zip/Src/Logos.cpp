//-----------------------------------------------------------------------------
// File: Logos.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
AS_TEXTURE LogosTexture[LOGOS_TEXTURES];
BOOL bShowLogos;
// Logos sequence:
float fPublisherBox[3], fEclypseBlend;
ACTOR BlibsActor;
int iStep, iASLogoPSSystem;
long lLogoWaitTime;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
void Logos(void);
void LoadLogosTextures(void);
void DestroyLogosTextures(void);
HRESULT LogosDraw(AS_WINDOW *);
HRESULT LogosCheck(AS_WINDOW *);
void DrawLogoBox(int [6]);
void InitLogos(void);
void SetLogosCamera(void);
///////////////////////////////////////////////////////////////////////////////


void Logos(void)
{ // begin Logos()
	MSG msg;

	if(!_AS->bShowLogos)
	{
		bShowLogos = FALSE;
		bInGameMenu = TRUE;
		return;
	}

	bShowLogos = TRUE;
	InitLogos();

	_AS->pWindow[GAME_WINDOW_ID].SetDrawFunction(LogosDraw);
	_AS->pWindow[GAME_WINDOW_ID].SetCheckFunction(LogosCheck);
	
	LoadLogosTextures();
	StartMusic("MainMenu.mp3");
	
	for(;;)
	{
		if(PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
		{
			if(!GetMessage(&msg, NULL, 0, 0))
				break;
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else
		{	
			if(_AS->GetShutDown() || _AS->CheckModuleChange() || !bShowLogos)
				PostQuitMessage(0);
			if(!_AS->GetActive())
				continue;
			_AS->UpdateWindows(FALSE);
		}
	}

	ParticleManager.Destroy();
	DestroyLogosTextures();
	bInGameMenu = TRUE;
} // end Logos()

void LoadLogosTextures(void)
{ // begin LoadLogosTextures()
	char byFilename[LOGOS_TEXTURES][256] = {"Box.jpg",
										    "Publisher.jpg",
											"Eclypse.jpg",
											"EclypseEntertainment.jpg",
											"EclypseParticle.jpg",
											"EclypseLogo.jpg",
											"Blibs.jpg"};
	ASLoadTextures(byFilename, LOGOS_TEXTURES, LogosTexture);
	ASGenOpenGLTextures(LOGOS_TEXTURES, LogosTexture);
} // end LoadLogosTextures()

void DestroyLogosTextures(void)
{ // begin DestroyLogosTextures()
	ASDestroyOpenGLTextures(LOGOS_TEXTURES, LogosTexture);
	ASDestroyTextures(LOGOS_TEXTURES, LogosTexture);
} // end DestroyLogosTextures()

HRESULT LogosDraw(AS_WINDOW *pWindow)
{ // begin LogosDraw()
	GLfloat afLightData[4]  = {0.0f, 0.0f, 0.0f, 0.0f};
	int iTexture[6], i, iLightID;
	float f;
	
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	f = (float) -cos(sin(fEclypseBlend)*PI);
	if(f < 0.0f)
		f = 0.0f;

	// Draw the Eclypse Logo:
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glDisable(GL_LIGHTING);
	glEnable(GL_BLEND);
	glColor4f(1.0f, 1.0f, 1.0f, f*2);
	glLoadIdentity();
	glTranslatef(0.0f, 1.0f, -30.0f);
	glBindTexture(GL_TEXTURE_2D, LogosTexture[5].iOpenGLID);
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 1.0f); glVertex2f(-7.0f, -6.8f);
		glTexCoord2f(1.0f, 1.0f); glVertex2f(5.5f, -6.8f);
		glTexCoord2f(1.0f, 0.0f); glVertex2f(5.5f, 6.8f);
		glTexCoord2f(0.0f, 0.0f); glVertex2f(-7.0f, 6.8f);
	glEnd();
	glColor4f(1.0f, 1.0f, 1.0f, fEclypseBlend);
	glLoadIdentity();
	glTranslatef(0.0f, -1.1f, -5.0f);
	glScalef(1.0f/f, f, 1.0f);

	// Eclypse Entertainment:
	glBindTexture(GL_TEXTURE_2D, LogosTexture[3].iOpenGLID);
	glBegin(GL_QUADS);
		glTexCoord2f(0.01f, 0.99f); glVertex2f(-1.2f, -0.5f);
		glTexCoord2f(0.99f, 0.99f); glVertex2f(1.2f, -0.5f);
		glTexCoord2f(0.99f, 0.01f); glVertex2f(1.2f, 0.0f);
		glTexCoord2f(0.01f, 0.01f); glVertex2f(-1.2f, 0.0f);
	glEnd();
	_AS->iTriangles += 4;
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);

	glLoadIdentity();
	glTranslatef(-45.0f, -35.0f, -200.0f);
	glDisable(GL_FOG);
	ParticleManager.Draw(FALSE);

	glColor3f(1.0f, 1.0f, 1.0f);
	glLoadIdentity();
	
	iLightID = GL_LIGHT0+_AS->iActiveLights;
	afLightData[0] = 4.0f;
	afLightData[1] = 5.0f;
	afLightData[2] = 2.0f;
	afLightData[3] = 2.0f;
	glLightfv(iLightID, GL_POSITION, afLightData);
	afLightData[0] = 0.8f;
	afLightData[1] = 0.8f;
	afLightData[2] = 0.8f;
	afLightData[3] = 1.0f;
	glLightfv(iLightID, GL_DIFFUSE, afLightData);
	glEnable(iLightID);
	_AS->iActiveLights++;

	glEnable(GL_TEXTURE_2D);
	glEnable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);
	ASEnableLighting();
	// Blibs;
	glCullFace(GL_FRONT);
	SetLogosCamera();
	glTranslatef(BlibsActor.fWorldPos[X], BlibsActor.fWorldPos[Y]-0.6f, BlibsActor.fWorldPos[Z]-0.25f);
	glRotatef(BlibsActor.fRot[Y]+90.0f, 0.0f, 1.0f, 0.0f);
	glScalef(0.0035f, 0.0035f, 0.0034f);

	glBindTexture(GL_TEXTURE_2D, LogosTexture[6].iOpenGLID);


	ASPrecomputeMd2FrameInt(pBlibsModel, BlibsActor.iAniStep, BlibsActor.iNextAniStep, BlibsActor.fAniInterpolation);
	ASDrawPrecomputedMd2Frame(pBlibsModel);


	glBindTexture(GL_TEXTURE_2D, GameTexture[4+BlibsActor.bSkinSleep].iOpenGLID);
	ASPrecomputeMd2FrameInt(pBlibsEyesModel, BlibsActor.iAniStep, BlibsActor.iNextAniStep, BlibsActor.fAniInterpolation);
	ASDrawPrecomputedMd2Frame(pBlibsEyesModel);

	glCullFace(GL_BACK);

	// Publisher box:
	SetLogosCamera();
	glRotatef(90.0f, 0.0f, 0.0f, 1.0f);
	glTranslatef(-0.6f+fPublisherBox[X], -0.5f+fPublisherBox[Y], 0.0f+fPublisherBox[Z]);
	for(i = 0; i < 6; i++)
		iTexture[i] = 0;
	iTexture[0] = 1;
	DrawLogoBox(iTexture);
	
	ASSwapBuffers(*pWindow->GethDC(), pWindow, TRUE);

	glDisable(GL_LIGHT1);
	return 0;
} // end LogosDraw()

HRESULT LogosCheck(AS_WINDOW *pWindow)
{ // begin LogosCheck()
	AS_PARTICLE_SYSTEM *pSystemT;
	AS_PARTICLE *pParticleT;
	int i, i2;
	
	_AS->ReadDXInput(*pWindow->GethWnd());

	CheckDebugKeys();
	AnimateFont();
	ParticleManager.Check();
	BlibsActor.AnimateBlibsEyes();

	// Publisher box;
	switch(iStep)
	{
		case 0: // Pull in publisher box:
			fPublisherBox[Y] += (float) g_lDeltatime/3000;
			if(fPublisherBox[Y] > -0.3f)
			{
				fPublisherBox[Y] = -0.3f;
				iStep++;
				lLogoWaitTime = g_lGameTimer;
			}
			BlibsActor.fWorldPos[X] = -(fPublisherBox[Y]+0.92f);
			if(BlibsActor.byAnimation != 5)
			{
				BlibsActor.byAnimation = 5;
				BlibsActor.iAniStep = pBlibsModel->Ani.anim[BlibsActor.byAnimation].firstFrame;
				BlibsActor.dwAniTime = g_lGameTimer;
			}
			// Show the AS logo:
        	if(iASLogoPSSystem == -1)
			{
				iASLogoPSSystem = ParticleManager.AddNewSystem(PS_ParticleLogo, LogosTexture[2].iWidth*LogosTexture[2].iHeight, NULL, &LogosTexture[4], &LogosTexture[2]);
				pSystemT = &ParticleManager.pSystem[iASLogoPSSystem];
				pSystemT->bActive = TRUE;
				pSystemT->bAnimatedParticles = TRUE;
				pSystemT->iAnimationColumns = 4;
				pSystemT->iAnimationRows = 4;
				pSystemT->iTextureWidth = 256;
				pSystemT->iTextureHeight = 256;
				// Disort particles:
				for(i = 0; i < ParticleManager.pSystem[iASLogoPSSystem].iParticles; i++)
				{
					pParticleT = &ParticleManager.pSystem[iASLogoPSSystem].pParticle[i];
					pParticleT->iAnimationStep = rand() % (pSystemT->iAnimationColumns*pSystemT->iAnimationRows);
					pParticleT->iAnimationSpeed = 1+(rand() % 50);
					for(i2 = 0; i2 < 2; i2++)
					{
						pParticleT->fPos[i2] = (float) (rand() % 100);
						pParticleT->fLastPos[i2] = pParticleT->fFixPos[i2];
					}
					pParticleT->fPos[Z] = (float) (rand() % 200);
					pParticleT->fLastPos[Z] = pParticleT->fFixPos[Z];
				}
			}
		break;
		
		case 1: // Waiting:
			if(g_lGameTimer-lLogoWaitTime > 6000)
				iStep++;
			if(BlibsActor.byAnimation != 7)
			{
				BlibsActor.byAnimation = 7;
				BlibsActor.iAniStep = pBlibsModel->Ani.anim[BlibsActor.byAnimation].firstFrame;
				BlibsActor.dwAniTime = g_lGameTimer;
			}
		break;
		
		case 2: // Pull out all boxes:
			fPublisherBox[Y] += (float) g_lDeltatime/1000;
			BlibsActor.fWorldPos[X] -= (float) g_lDeltatime/2500;
			if(BlibsActor.fWorldPos[X] < -1.0f)
			{
				iStep++;
				lLogoWaitTime = g_lGameTimer;
			}
			if(BlibsActor.byAnimation != 14)
			{
				BlibsActor.byAnimation = 14;
				BlibsActor.iAniStep = pBlibsModel->Ani.anim[BlibsActor.byAnimation].firstFrame;
				BlibsActor.dwAniTime = g_lGameTimer;
			}
		break;

		case 3:
			fPublisherBox[Y] += (float) g_lDeltatime/1000;
			BlibsActor.fWorldPos[X] -= (float) g_lDeltatime/2500;
			fEclypseBlend += (float) g_lDeltatime/14000;
			if(fEclypseBlend > 1.0f)
			{
				fEclypseBlend = 1.0f;
				iStep++;
				ParticleManager.pSystem[iASLogoPSSystem].bGoingInActive = TRUE;
				lLogoWaitTime = g_lGameTimer;
			}
		break;

		case 4:
			if(!ParticleManager.pSystem[iASLogoPSSystem].bActive)
				iStep++;
		break;

		case 5:
			fEclypseBlend -= (float) g_lDeltatime/13000;
			if(fEclypseBlend < 0.3f)
			{
				fEclypseBlend = 0.0f;
				bShowLogos = FALSE;
			}
		break;
	}

	// Blibs:
	BlibsActor.fRealAniSpeed = PLAYER_ANIMATION_SPEED;
	BlibsActor.AnimateModel(pBlibsModel);

	if(ASKeyFirst[DIK_ESCAPE])
		bShowLogos = FALSE;

	return 0;
} // end LogosCheck()

void DrawLogoBox(int iTexture[6])
{ // begin DrawLogoBox()
	// Floor face
	glBindTexture(GL_TEXTURE_2D, LogosTexture[iTexture[0]].iOpenGLID);
	glBegin(GL_QUADS);
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0.0f, 0.f); glVertex3f(1.0f, 1.0f, 0.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f(0.0f, 1.0f, 0.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f(0.0f, 0.0f, 0.0f);
	glEnd();

	// Sky face
	glBindTexture(GL_TEXTURE_2D, LogosTexture[iTexture[1]].iOpenGLID);
	glBegin(GL_QUADS);
		glNormal3f(0.0f, 0.0f, -1.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f(0.0f, 1.0f, -1.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f(1.0f, 1.0f, -1.0f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f(1.0f, 0.0f, -1.0f);
		glTexCoord2f(0.0f, 0.0f); glVertex3f(0.0f, 0.0f, -1.0f);
	glEnd();
		
	// Back face
	glBindTexture(GL_TEXTURE_2D, LogosTexture[iTexture[2]].iOpenGLID);
	glBegin(GL_QUADS);
		glNormal3f(0.0f, 1.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f); glVertex3f(1.0f, 1.0f, 0.0f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f(1.0f, 1.0f, -1.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f(0.0f, 1.0f, -1.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f(0.0f, 1.0f, 0.0f);
	glEnd();

	// Bottom Face
	glBindTexture(GL_TEXTURE_2D, LogosTexture[iTexture[3]].iOpenGLID);
	glBegin(GL_QUADS);
		glNormal3f(0.0f, -1.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f); glVertex3f(0.0f, 0.0f, -1.0f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f(1.0f, 0.0f, -1.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f(0.0f, 0.0f, 0.0f);
	glEnd();
		
	// Right face
	glBindTexture(GL_TEXTURE_2D, LogosTexture[iTexture[4]].iOpenGLID);
	glBegin(GL_QUADS);
		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f); glVertex3f(1.0f, 0.0f, -1.0f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f(1.0f, 1.0f, -1.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f(1.0f, 1.0f, 0.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f(1.0f, 0.0f, 0.0f);
	glEnd();

	// Left Face
	glBindTexture(GL_TEXTURE_2D, LogosTexture[iTexture[5]].iOpenGLID);
	glBegin(GL_QUADS);
		glNormal3f(-1.0f, 0.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f); glVertex3f(0.0f, 1.0f, 0.0f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f(0.0f, 1.0f, -1.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f(0.0f, 0.0f, -1.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f(0.0f, 0.0f, 0.0f);
	glEnd();
	_AS->iTriangles += 12;
} // end DrawLogoBox()

void InitLogos(void)
{ // begin InitLogos()
	DestroyGameParticleSystems();
	fGalaxyIn = 0.0f;
	fPublisherBox[Y] = -2.2f;
	iStep = 0; // 0
	fEclypseBlend = 0.5f;
	BlibsActor.fWorldPos[X] = -(fPublisherBox[Y]+0.78f);
	iASLogoPSSystem = -1;
} // end InitLogos()

void SetLogosCamera(void)
{ // begin SetLogosCamera()
	glLoadIdentity();
	glTranslatef(0.0f, 0.0f, -1.5f);
	glRotatef(20.0f, 1.0f, 0.0f, 0.0f);
} // end SetLogosCamera()
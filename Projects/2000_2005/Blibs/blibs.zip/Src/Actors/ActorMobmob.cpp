//-----------------------------------------------------------------------------
// File: ActorMobmob.cpp
//-----------------------------------------------------------------------------

#include "..\AS\AS_Engine.h"
#include "..\ModuleHeaders.h"


extern int iTemp;

// Draw the Mobmob actor:
void ACTOR::DrawMobmob(void)
{ // begin ACTOR::DrawMobmob()
	if(!bActive)
		return; // The actor isn't active!
	if(!bOnScreen)
	{ // The actor isn't on screen;
		iCulledObjects++;
		return;
	}

	glPushMatrix();
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_CULL_FACE);
	glCullFace(GL_FRONT);
	
	glTranslatef(fWorldPos[X], fWorldPos[Y], fWorldPos[Z]-0.7f);
	glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
	glRotatef(-fRot[Y]-180.0f, 0.0f, 1.0f, 0.0f);
	glScalef(0.03f, 0.03f, 0.03f);
	BeamingScale(4.0f);
	
	if(fBlendDensity != 1.0f)
	{ // The actor is blended:
		glEnable(GL_BLEND);
		glColor4f(1.0f, 1.0f, 1.0f, fBlendDensity);
		glDepthMask(FALSE);
		glDisable(GL_FOG);
	}
	else
		glColor3f(fColor[0], fColor[1], fColor[2]);

	// Bind the actors texture:
	if(iTexture == -1)
		glBindTexture(GL_TEXTURE_2D, ActorTexture[MOBMOB_TEXTURE].iOpenGLID);
	else
		glBindTexture(GL_TEXTURE_2D, pLevel->pTexture[iTexture].iOpenGLID);

	if(bShieldMode && _ASConfig->bMultitexturing)
	{ // Render unit 2:
		glActiveTextureARB(GL_TEXTURE1_ARB);
		glEnable(GL_TEXTURE_2D);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		glColor3f(1.0f, 1.0f, 1.0f);
		glBindTexture(GL_TEXTURE_2D, GameTexture[DisplayActor[0].iAniStep].iOpenGLID);
		glActiveTextureARB(GL_TEXTURE0_ARB);
	}

	
	ASPrecomputeMd2FrameInt(pMobmobModel, iAniStep, iNextAniStep, fAniInterpolation);
	AS_Md2_GetCurrentBoundingBox(pMobmobModel, iAniStep, iNextAniStep, fAniInterpolation, &fModelBoundingBox);
	ASDrawPrecomputedMd2Frame(pMobmobModel);


	if(bShieldMode && _ASConfig->bMultitexturing)
	{ // Deactivate the second render unit:
		glActiveTextureARB(GL_TEXTURE1_ARB);
		glDisable(GL_TEXTURE_2D);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
		glActiveTextureARB(GL_TEXTURE0_ARB);
	}
	if(_ASConfig->bDrawBounding)
	{ // Draw the bounding box around the mobmob:
		glColor3f(1.0f, 1.0f, 1.0f);
		ASDrawBoundingBox(fModelBoundingBox);
	}
	glDepthMask(TRUE);
	glCullFace(GL_BACK);
	glDisable(GL_BLEND);
	glPopMatrix();
	if(pLevel->Environment.bFog)
		glEnable(GL_FOG);
} // end ACTOR::DrawMobmob()

// Check the Mobmob actor:
void ACTOR::CheckMobmob(BOOL bEditor)
{ // begin ACTOR::CheckMobmob()
	AS_VECTOR3D vV, vN, vVT, vNT;
	AS_MATRIX Mat;
	ACTOR *pActorT;
	int iX, iY, i, iNextAniStepT;
	SURFACE *pSurfaceT;
	char byTempDirection, byDesiredDirection;

	if(!bActive)
		return; // The actor isn't active!

	if(bEditor)
	{ // We are in the editor:
		SetAction(AA_STANDING);
	}

	// Setup animation speed factor:
	if(!bSpeedMode)
		fAniSpeedFactor = 1.0f;
	else
		fAniSpeedFactor = 6.0f;	
	if(Action == AA_DEATH || Action == AA_DEATH1)
		fAniSpeedFactor /= 1.5f;
	fRealAniSpeed = fAniSpeed/fAniSpeedFactor;

	if(!bDeath)
		AnimateModel(pMobmobModel);
	Check(bEditor); // Do general actor checks
	if(bEditor || bCameraAnimation)
		return;

	if(bGoingDeath)
	{ // The actor is dies at the moment:
		if(!bDeath)
		{ // Check if the actor lies now death on the floor:
			iNextAniStepT = iAniStep+1;
			if((Action == AA_DEATH || Action == AA_DEATH1) &&
			   iNextAniStepT == pMobmobModel->Ani.anim[byAnimation].lastFrame-1)
			{
				DeliverItems();
				bDeath = TRUE;
				fDeathTime = 0.0f;
				lDeathTime = g_lGameTimer;
			}
			pCamera->fRot2Velocity[X] = -0.02f*g_lDeltatime;
		}
		else
		{
			fDeathTime += (float) g_lDeltatime/5000;
			if(!bDeathRemoved && fBlendDensity != 1.0f)
			{
				RemoveFromFields();
				bDeathRemoved = TRUE;
			}
			if(fDeathTime >= 1.5f)
			{ // Now the actor should be deactivated:
				if(Item[AT_LIFE_ITEM].iNumber > 1)
				{
					if(pLevel->pField[iCheckpointFieldID].pActor && pLevel->pField[iCheckpointFieldID].pActor != this)
						return; // The checkpoint field isn't free!!
				}
				DecreaseItemNumber(AT_LIFE_ITEM);
				if(!Item[AT_LIFE_ITEM].iNumber)
				{ // The actor is now 'really' death!
					memset(fVelocity, 0, sizeof(FLOAT3));
					bActive = FALSE;
					if(pLevel->Missions.iKillMobmobs-pLevel->State.iKilledMobmobs >= 0)
						pLevel->State.iKilledMobmobs++;
					return;
				}
				else
				{ // Set the actor to the last checkpoint:
					SetToCheckpoint();
				}
			}
		}
		return;
	}
	else
	{
		iNextAniStepT = iAniStep+1;
		if(iNextAniStepT >= pMobmobModel->Ani.anim[byAnimation].lastFrame)
		{
			if(Action == AA_FUNNY || Action == AA_FUNNY2 || Action == AA_PICK_UP ||
			   Action == AA_SHOOTING || Action == AA_PAIN || Action == AA_HEALTH ||
			   Action == AA_STANDING || Action == AA_DOCKED)
				SetAction(AA_NOTHING);
		}

		if(CheckBeamingProcess())
			return; // We are beamed at the moment!
		CheckWater(); // Check the water

		if(!CheckForBeaming())
		{
			if(!pLevel->State.bLevelComplete)
				CheckSurface(); // Check the surface were the actor is on
		}
	}
	if(!CheckTurning(g_lDeltatime/PLAYER_TURN_SPEED*fTurningSpeed))
	{ // Move the actor:
		Move(-1);
	}
	else
		return;
	if(!bMove && pTextScript && pTextScript->pManager->bPlayTextScript && pTextScript == pTextScript->pManager->pPlayedTS &&
	   pTextScript->pManager->pTalkToActor == this)
	{ // The actors text script is played at the moment!
		if(pPlayer->iFieldPos[X] > iFieldPos[X])
			byDirection = RIGHT;
		if(pPlayer->iFieldPos[X] < iFieldPos[X])
			byDirection = LEFT;
		if(pPlayer->iFieldPos[Y] > iFieldPos[Y])
			byDirection = DOWN;
		if(pPlayer->iFieldPos[Y] < iFieldPos[Y])
			byDirection = UP;
		SetAction(AA_STANDING);
		return;
	}
	if(Action == AA_FUNNY || Action == AA_FUNNY2 || Action == AA_PICK_UP ||
	   Action == AA_SHOOTING || Action == AA_PAIN || Action == AA_HEALTH ||
	   Action == AA_STANDING || Action == AA_DOCKED)
		return;

	if(bSpeedMode)
		fVelocity[0] = 2.0f;
	else
		fVelocity[0] = 1.5f;
	if(Action == AA_JUMPING)
	{ // If the actor jumps then there isn't an friction:
		fVelocity[0] /= 1.4f;
		bUseFriction = FALSE;
	}
	else
		bUseFriction = TRUE;
	
	if(bMove)
		return;
	if((pSurfaceT = pLevel->pField[iFieldID].Side[FACE_FLOOR].Surface[0].pSurface) &&
	  pSurfaceT->Header.bAnchor)
	{ // The mobmob is now 'docked':
		SetAction(AA_DOCKED);
		bDocked = TRUE;
		bMoveable = TRUE;
		return;
	}
	bDocked = FALSE;
	bMoveable = FALSE;

	if(bShieldMode || bGhostMode)
		bSquashable = FALSE;
	else
		bSquashable = TRUE;

	// Decide what the mobmob should do:
	byTempDirection = byDesiredDirection = -1;

	if(!bGhostMode && bFollow && pPlayer && pPlayer->bActive && !pPlayer->bDeath &&
	   !pPlayer->bGoingDeath && !pPlayer->bGhostMode && !pPlayer->bBeaming)
	{ // Check, if the player is in range to ran to him:
		iX = iFieldPos[X]-pPlayer->iFieldPos[X];
		iY = iFieldPos[Y]-pPlayer->iFieldPos[Y];
		if(iX < 0)
			iX = -iX;
		if(iY < 0)
			iY = -iY;
		if(iX < 3 && iY < 3)
		{ // Ok, check if we could go to him:
			if(!(rand() % 2))
			{
				if(iFieldPos[X] > pPlayer->iFieldPos[X])
					byDesiredDirection = LEFT;
				else
					byDesiredDirection = RIGHT;
			}
			else
			{
				if(iFieldPos[Y] > pPlayer->iFieldPos[Y])
					byDesiredDirection = UP;
				else
					byDesiredDirection = DOWN;
			}
		}
	}

	// Check if the Mobmob should change his direction:
	if(byDesiredDirection != -1)
	{
		if(!DoWalking(byDesiredDirection, TRUE) || !GetNextFieldActive(byDesiredDirection))
			byDesiredDirection  = -1; // Its not possible to move there!
		else
		{ // Set the new direction:
			byDirection = byDesiredDirection;
			if(CheckIsDirection(-1) && bMobile)
				DoWalking(-1, FALSE);
			return;
		}
	}
	else
	{
		if(!(rand() % 30))
		{ // Pick up something: (Health Mobmob)
			if(DoWalking(byDirection, TRUE) && GetNextFieldActive(byDirection))
			{
				SetAction(AA_PICK_UP);
				fHealth += 10;
				if(fHealth > fMaxHealth)
					fHealth = fMaxHealth;
			}
			return;
		}
		else
		if(!(rand() % 50))
		{ // Stand around:
			SetAction(AA_STANDING);
			return;
		}
	}

	// Check, if the Mobmob could attack the player:
	if(bAggressive && pPlayer && !pPlayer->bGhostMode && !pPlayer->bDeath && !pPlayer->bGoingDeath &&
	   !pPlayer->bBeaming && !CheckIfWall(-1, 1))
	{
		pActorT = GetNextFieldActor(byTempDirection);
		if(pActorT == pPlayer)
		{
			if(!pPlayer->bShieldMode)
			{
				pPlayer->fHealth -= 20.0f;
				pPlayer->SetupCameraRotation(AA_PAIN, pCamera);
				pPlayer->SetAction(AA_PAIN);
			}
			SetAction(AA_SHOOTING);
			return;
		}

		// Check, if we are near the player:
		for(byTempDirection = 0; byTempDirection < 4; byTempDirection++)
		{
			pActorT = GetNextFieldActor(byTempDirection);
			if(pActorT && pActorT == pPlayer)
			{ // Set the new direction:
				byDirection = byTempDirection;
				SetAction(AA_WALKING);
				return;
			}
		}
	}
	if(!bMobile)
	{
		SetAction(AA_STANDING);
		return;
	}
	if(!DoWalking(byDirection, TRUE) || !GetNextFieldActive(byDirection) || !(rand() % 5))
	{ // Yeah! He should change his direction!
		for(i = 0; i < 10; i++)
		{
			byTempDirection = rand() % 4;
			if(DoWalking(byTempDirection, TRUE) && GetNextFieldActive(byTempDirection))
				break;
		}
		if(!DoWalking(byTempDirection, TRUE))
		{ // The mobmob is in an entrapment!
			if(!(rand() % 8))
				SetAction(AA_FUNNY2);
			else
				SetAction(AA_FUNNY);
		}
		else
		{ // Set the new direction:
			byDirection = byTempDirection;
			SetAction(AA_WALKING);
		}
	}
	else
	{
		if(CheckIsDirection(-1))
			DoWalking(-1, FALSE);
	}
	if(!bMove)
		fFieldPos[X] = fFieldPos[Y] = 0.0f;
} // end ACTOR::CheckMobmob()
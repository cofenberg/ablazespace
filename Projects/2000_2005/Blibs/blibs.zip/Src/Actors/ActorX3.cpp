//-----------------------------------------------------------------------------
// File: ActorX3.cpp
//-----------------------------------------------------------------------------

#include "..\AS\AS_Engine.h"
#include "..\ModuleHeaders.h"


// Draw the X3 actor:
void ACTOR::DrawX3(void)
{ // begin ACTOR::DrawX3()
	if(!bActive)
		return; // The actor isn't active!
	if(!bOnScreen)
	{ // The actor isn't on screen;
		iCulledObjects++;
		return;
	}

	glPushMatrix();
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_CULL_FACE);
	glCullFace(GL_FRONT);
	
	glTranslatef(fWorldPos[X], fWorldPos[Y], fWorldPos[Z]-0.45f);
	glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
	glRotatef(-fRot[Y]-180.0f, 0.0f, 1.0f, 0.0f);
	glScalef(0.02f, 0.02f, 0.02f);
	BeamingScale(4.0f);
	
	if(fBlendDensity != 1.0f)
	{ // The actor is blended:
		glEnable(GL_BLEND);
		glColor4f(1.0f, 1.0f, 1.0f, fBlendDensity);
		glDepthMask(FALSE);
		glDisable(GL_FOG);
	}
	else
		glColor3f(fColor[0], fColor[1], fColor[2]);

	// Bind the actors texture:
	if(iTexture == -1)
		glBindTexture(GL_TEXTURE_2D, ActorTexture[X3_TEXTURE].iOpenGLID);
	else
		glBindTexture(GL_TEXTURE_2D, pLevel->pTexture[iTexture].iOpenGLID);

	if(bShieldMode && _ASConfig->bMultitexturing)
	{ // Render unit 2:
		glActiveTextureARB(GL_TEXTURE1_ARB);
		glEnable(GL_TEXTURE_2D);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		glColor3f(1.0f, 1.0f, 1.0f);
		glBindTexture(GL_TEXTURE_2D, GameTexture[DisplayActor[0].iAniStep].iOpenGLID);
		glActiveTextureARB(GL_TEXTURE0_ARB);
	}



	ASPrecomputeMd2FrameInt(pX3Model, iAniStep, iNextAniStep, fAniInterpolation);
	AS_Md2_GetCurrentBoundingBox(pX3Model, iAniStep, iNextAniStep, fAniInterpolation, &fModelBoundingBox);
	ASDrawPrecomputedMd2Frame(pX3Model);



	if(bShieldMode && _ASConfig->bMultitexturing)
	{ // Deactivate the second render unit:
		glActiveTextureARB(GL_TEXTURE1_ARB);
		glDisable(GL_TEXTURE_2D);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
		glActiveTextureARB(GL_TEXTURE0_ARB);
	}
	if(_ASConfig->bDrawBounding)
	{ // Draw the bounding box around the X3:
		glColor3f(1.0f, 1.0f, 1.0f);
		ASDrawBoundingBox(fModelBoundingBox);
	}
	glDepthMask(TRUE);
	glCullFace(GL_BACK);
	glDisable(GL_BLEND);
	glPopMatrix();
	if(pLevel->Environment.bFog)
		glEnable(GL_FOG);
} // end ACTOR::DrawX3()

// Check the X3 actor:
void ACTOR::CheckX3(BOOL bEditor)
{ // begin ACTOR::CheckX3()
	AS_VECTOR3D vV, vN, vVT, vNT;
	AS_MATRIX Mat;
	ACTOR *pActorT;
	int i, iNextAniStepT, iX, iY;
	char byTempDirection;
	AS_PARTICLE_SYSTEM *pSystemT;

	if(!bActive)
		return; // The actor isn't active!

	if(bEditor)
	{ // We are in the editor:
		SetAction(AA_STANDING);
	}

	// Setup animation speed factor:
	if(!bSpeedMode)
		fAniSpeedFactor = 1.0f;
	else
		fAniSpeedFactor = 6.0f;	
	if(Action == AA_SHOOTING || Action == AA_DEATH)
		fAniSpeedFactor /= 1.5f;
	fRealAniSpeed = fAniSpeed/fAniSpeedFactor;

	if(!bDeath)
		AnimateModel(pX3Model);
	Check(bEditor); // Do general actor checks

	if(bEditor || bCameraAnimation)
		return;

	if(bGoingDeath)
	{ // The actor is dies at the moment:
		if(!bDeath)
		{ // Check if the actor lies now death on the floor:
			iNextAniStepT = iAniStep+1;
			if(Action == AA_DEATH &&
			   iNextAniStepT == pX3Model->Ani.anim[byAnimation].lastFrame-1)
			{
				DeliverItems();
				bDeath = TRUE;
				fDeathTime = 0.0f;
				lDeathTime = g_lGameTimer;
			}
			pCamera->fRot2Velocity[X] = -0.02f*g_lDeltatime;
		}
		else
		{
			fDeathTime += (float) g_lDeltatime/5000;
			if(!bDeathRemoved && fBlendDensity != 1.0f)
			{
				RemoveFromFields();
				bDeathRemoved = TRUE;
			}
			if(fDeathTime >= 1.5f)
			{ // Now the actor should be deactivated:
				if(Item[AT_LIFE_ITEM].iNumber > 1)
				{
					if(pLevel->pField[iCheckpointFieldID].pActor && pLevel->pField[iCheckpointFieldID].pActor != this)
						return; // The checkpoint field isn't free!!
				}
				DecreaseItemNumber(AT_LIFE_ITEM);
				if(!Item[AT_LIFE_ITEM].iNumber)
				{ // The actor is now 'really' death!
					memset(fVelocity, 0, sizeof(FLOAT3));
					bActive = FALSE;
					return;
				}
				else
				{ // Set the actor to the last checkpoint:
					SetToCheckpoint();
				}
			}
		}
		return;
	}
	else
	{
		iNextAniStepT = iAniStep+1;
		if(iNextAniStepT >= pX3Model->Ani.anim[byAnimation].lastFrame)
		{
			if(Action == AA_FUNNY || Action == AA_STANDING ||
			   Action == AA_SHOOTING || Action == AA_PAIN)
				SetAction(AA_NOTHING);
		}

		if(CheckBeamingProcess())
			return; // We are beamed at the moment!
		CheckWater(); // Check the water

		if(!CheckForBeaming())
		{
			if(!pLevel->State.bLevelComplete)
				CheckSurface(); // Check the surface were the actor is on
		}
	}
	if(!CheckTurning(g_lDeltatime/PLAYER_TURN_SPEED*fTurningSpeed))
	{ // Move the actor:
		Move(-1);
	}
	else
		return;
	if(!bMove && pTextScript && pTextScript->pManager->bPlayTextScript && pTextScript == pTextScript->pManager->pPlayedTS &&
	   pTextScript->pManager->pTalkToActor == this)
	{ // The actors text script is played at the moment!
		if(pPlayer->iFieldPos[X] > iFieldPos[X])
			byDirection = RIGHT;
		if(pPlayer->iFieldPos[X] < iFieldPos[X])
			byDirection = LEFT;
		if(pPlayer->iFieldPos[Y] > iFieldPos[Y])
			byDirection = DOWN;
		if(pPlayer->iFieldPos[Y] < iFieldPos[Y])
			byDirection = UP;
		SetAction(AA_STANDING);
		return;
	}
	if(Action == AA_FUNNY ||
	   Action == AA_SHOOTING || Action == AA_PAIN)
		return;

	if(bSmall)
	{
		if(bSpeedMode)
			fVelocity[0] = 1.0f;
		else
			fVelocity[0] = 0.5f;
	}
	else
	{
		if(bSpeedMode)
			fVelocity[0] = 1.3f;
		else
			fVelocity[0] = 0.8f;
	}
	
	if(bMove)
		return;
	bMoveable = FALSE;

	if(bShieldMode || bGhostMode)
		bSquashable = FALSE;
	else
		bSquashable = TRUE;

	// Check, if the X3 could attack the player:
	pActorT = GetNextFieldActor(byDirection);
	if(pActorT && !pActorT->bGhostMode && !pActorT->bDeath && !pActorT->bGoingDeath &&
	   !pActorT->bBeaming && !CheckIfWall(-1, 1))
	{
		if((bAggressive && !bGuardian && pActorT == pPlayer) ||
			(bGuardian && pActorT->CheckIfEnemy() && pActorT != this))
		{
        	i = ParticleManager.AddNewSystem(PS_X3Acid, 10, this, &GameTexture[23], NULL);
			pSystemT = &ParticleManager.pSystem[i];
			pSystemT->bActive = TRUE;
			pSystemT->bAnimatedParticles = TRUE;
			pSystemT->iAnimationColumns = 2;
			pSystemT->iAnimationRows = 2;
			pSystemT->iTextureWidth = 256;
			pSystemT->iTextureHeight = 256;
			if(!pActorT->bShieldMode)
			{
				pActorT->fHealth -= 30.0f;
				pActorT->SetupCameraRotation(AA_PAIN, pCamera);
				pActorT->SetAction(AA_PAIN);
			}
			SetAction(AA_SHOOTING);
			return;
		}
	}

	if(!bMobile)
	{
		SetAction(AA_STANDING);
		return;
	}
	// Let the actor walk:
	iX = iFieldPos[X]-pPlayer->iFieldPos[X];
	iY = iFieldPos[Y]-pPlayer->iFieldPos[Y];
	if(iX < 0)
		iX = -iX;
	if(iY < 0)
		iY = -iY;
	if(!bGhostMode && bFollow && pPlayer && !pPlayer->bGhostMode && pPlayer->bActive && !pPlayer->bDeath && !pPlayer->bGoingDeath &&
	   !pPlayer->bBeaming && iX < 4 && iY < 4)
	{ // The actor should follow the player:
		if(!(rand() % 2) && pPlayer->iFieldPos[X] > iFieldPos[X])
			byDirection = RIGHT;
		else
		if(!(rand() % 2) && pPlayer->iFieldPos[X] < iFieldPos[X])
			byDirection = LEFT;
		else
		if(!(rand() % 2) && pPlayer->iFieldPos[Y] > iFieldPos[Y])
			byDirection = DOWN;
		else
		if(!(rand() % 2) && pPlayer->iFieldPos[Y] < iFieldPos[Y])
			byDirection = UP;
		if(DoWalking(byDirection, TRUE) && GetNextFieldActive(byDirection))
		{ // Set the new direction:
			if(CheckIsDirection(-1))
				DoWalking(-1, FALSE);
			return;
		}
		else
			SetAction(AA_STANDING);
	}
	else
	{ // The actor should go its own way:
		if(!DoWalking(byDirection, TRUE) || !GetNextFieldActive(byDirection))
		{ // Yeah! He should change his direction!
			if(bSmall)
				byTempDirection = (byDirection+2) % 4;
			else
			{
				if(!(rand() % 2))
					byTempDirection = (byDirection+1) % 4;
				else
					byTempDirection = (byDirection+3) % 4;
			}
			for(i = 0; i < 10; i++)
			{
				if(DoWalking(byTempDirection, TRUE) && GetNextFieldActive(byTempDirection))
					break;
				byTempDirection = rand() % 4;
			}
			if(!DoWalking(byTempDirection, TRUE))
			{ // The X3 is in an entrapment!
				SetAction(AA_FUNNY);
			}
			else
			{ // Set the new direction:
				byDirection = byTempDirection;
				SetAction(AA_WALKING);
			}
		}
		else
		{
			if(CheckIsDirection(-1))
				DoWalking(-1, FALSE);
		}
	}
	if(!bMove)
		fFieldPos[X] = fFieldPos[Y] = 0.0f;
} // end ACTOR::CheckX3()
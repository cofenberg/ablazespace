//-----------------------------------------------------------------------------
// File: Actors.h
//-----------------------------------------------------------------------------

#ifndef __ACTORS_H__
#define __ACTORS_H__


// Definitions: ***************************************************************

// Actor textures:
#define ACTOR_TEXTURES 5
#define BLIBS_TEXTURE 0
#define RAMBO_BLIBS_TEXTURE 1
#define MOBMOB_TEXTURE 2
#define X3_TEXTURE 3
#define LUCIFER_TEXTURE 4

enum ACTOR_MOVE {ACTOR_MOVE_FORWARD, ACTOR_MOVE_BACKWARD};

typedef class TEXT_SCRIPT TEXT_SCRIPT;

// Actor types:
enum ACTOR_TYPE
{
	// Items:
	AT_HEALTH_ITEM, // 1
	AT_HEALTH_INCREASE_ITEM, // 2
	AT_LIFE_ITEM,   // 3
	AT_PULL_ITEM,   // 4
	AT_CHEST_ITEM,  // 5
	AT_STRENGTH_ITEM,  // 6
	AT_WEAPON_ITEM, // 7
	AT_COIN_ITEM,  // 8
	AT_GHOST_ITEM,  // 9
	AT_TIME_ITEM,   // 10
	AT_STEP_ITEM,   // 11
	AT_SPEED_ITEM,  // 12
	AT_WING_ITEM,   // 13
	AT_SHIELD_ITEM, // 14
	AT_JUMP_ITEM,   // 15
	AT_AIR_ITEM,    // 16
	AT_AIR_INCREASE_ITEM,    // 17
	AT_THROW_ITEM,	// 18
	AT_KICK_ITEM,	// 19
	AT_BAG_ITEM,	// 20
	AT_DYNAMITE_ITEM,	// 21

	// The player:
	AT_BLIBS,
	
	// The different boxes:
	AT_BOX_NORMAL, AT_BOX_RED, AT_BOX_GREEN, AT_BOX_BLUE,

	// Enemies:
	AT_MOBMOB, AT_X3, AT_LUCIFER_HEAD, AT_LUCIFER,

	// Other
	AT_SHOT_1,
};

#define ITEMS 21

extern ACTOR_TYPE ATList[ITEMS];

// Possible actor actions:
enum ACTOR_ACTION
{
	AA_NOTHING, 
	AA_STANDING, AA_LOOK_AROUND, AA_WALKING, AA_PUSHING, AA_PULLING, AA_PULL_WEAPON,
	AA_POUCH_WEAPON, AA_SHOOTING, AA_KICKING, AA_FALLING, AA_THROWING, AA_SMOTHER,
	AA_JUMPING, AA_WALL_JUMPING, AA_CHECKPOINT, AA_PAIN, AA_DEATH, AA_DEATH1, AA_SWIMMING,
	AA_HOLE_FALLING, AA_WRONG, AA_FUNNY, AA_FUNNY2, AA_HEALTH, AA_PICK_UP, AA_DOCKED,
	AA_TALKING, AA_SWINGING, AA_ANGRY,
};
///////////////////////////////////////////////////////////////////////////////

// Classes: *******************************************************************
typedef struct ITEM_INFO
{
	BOOL bUnlimited; // Is this item unlimited available?
	int iNumber; // How often is this item available?
	BOOL bDeliver, // Should the item given out it the item holding actor dies?
		 bKeep; // The actor looses this item if he dies

} ITEM_INFO;

typedef class ACTOR
{
	public:
		BOOL bActive,		// Is the actor active?
			 bOnScreen;		// Is the actor on screen??
		ACTOR_TYPE Type;	// The actors type
		int iID,			// The ID of this actor
			iLastCheckedField,
			iFieldID;		// The field ID of the current field the actor is on
		SHORT2 iFieldPos;	// The field position in the level matrix
		FLOAT3 fFieldPos,	// The position in the current field
			   fWorldPos,	// The real world pos
			   fLastHeightCheckWorldPos, // The last world pos were a height check was done
			   fColor; // The actors color
		ACTOR_ACTION Action; // What did the actor do?
		char byDirection,	// The actors direction
			 byName[256]; // The name of the actor
		FLOAT3 fRot;		// The actors rotation
		FLOAT4 fEnvironmentColor; // The color of the environment (e.g. for the box environment texture...)
		float fSize,		// The actors size
			  fHealth,		// The health of this actor
			  fMaxHealth,	// The possible maximum health
			  fAir,			// The air of this actor. Under water this will be decreased
			  fMaxAir,		// The possible maximum air
			  fFloorHeight, // The hight of the current floor position
			  fBlendDensity, // How transparent is this actor (1.0f = none transparent)
			  fTurningSpeed, // The turning speed
			  fWeight; // The weight of this actor
		ACTOR_MOVE MoveMode; // How should the actor move? (forward or backward)
		BOOL bMove,		    // Does the actor move at the moment?
			 bMoveable,     // Is this actor moveable?
			 bIsThrown,	    // Is the actor thrown?
		 	 bIsJumping,    // Does the actor jump at the moment?
			 bIsJumpingEnd, // Does the jump ends on the next field?
			 bReadyToShoot, // Are we ready to fire a shot?
			 bGoingDeath,   // Should the actor die?
			 bDeath,		// Is the actor now complete death?
			 bDeathRemoved, // Is the actor already removed from the fields?
			 bClone,		// Is this an clone? (e.g. of Blibs)
			 bAggressive,	// Should the actor attack Blibs?
			 bSmall, // Should the actor be a small one (e.g. for the X3 enemy)
			 bKiller, // This actor attacks all other actors
			 bActionDone, // Is the current action already done?
			 bSmotherDone, // Is the actor smoether?
			 bGuardian, // Does the actor doesn't kill friendly actors?
			 bMobile, // Does the actor walk around?
			 bFollow, // Should this actor follow the player?
			 bFallIntoHole, // Does the actor at the moment falls in an hole?
			 bSquashable,   // Could this actor the squashed? (eg. from an box)
			 bUseBoxColor, // Should the box be painted corresponding its type?
			 bCollisionDamage, // The actor is damaged on an collision
			 bIndestructible, // Is this actor indestructible?
			 bThrowable, // Could the actor be thrown?
			 bNitroglycerin, // Does the box contain nitroglycerin? (extreme explosive...)
			 bDeathWave, // Does the actor have an death wave?
			 bShadow, // Does this actor have an shadow?
			 bTorch; // Does this actor have an torch?
		float fDeathTime;   // The checking time past since the actors death
		long lDeathTime;   // The time were the actor died
		int iNumber,        // E.g. the number of objects the player will receive
			iCheckpointFieldID,	// The last checkpoint field
			iTexture; // The texture which the actors uses (-1 for standart texture)
		char byTextureFilename[256]; // The textures filename
		BOOL bNumberUnlimited;
		BOOL bBeaming,		// Is the actor beamed at the moment?
			 bBeamingStep;  // The current beaming step (0 = dematerializing, 1 = materializing)
		float fBeamingBlend;// The beaming blend
		BOOL bShowInfoText; // Should some information about this actor be shown?
		float fShowInfoTextBlend,
			  fShowInfoTextTimer;
		BOOL bUseFriction;	// Should the friction be used??
		float fFriction;	// The actors friction (e.g. from a suface)
		ACTOR *pVelocityFromActor; // Pointer to the actor which 'give's' the velocity
		FLOAT3 fVelocity;	// The actors move velocity (0 is used for normal movement, 2 for falling etc.)
		float fMoveVelocity; // The real move velocity (time dependent)
		long lLastWaterWaveTime, // The time were the last water wave was created
			 lLastWaterBubbleTime, // The time were the last water bubble was created
			 lLastWaterBubbleTimeWait, // The time which should be waited untill the next water bubble should be created
			 lLastWingSmokeTime, // The time were the last wing smoke was created
			 lSurfaceCheckTimer; // Timer for surface checks
		AS_VECTOR3D vCollisionEllipsoid; // The collision ellipsoid of this actor

//		AS_MD2_MODEL *pModel; // A pointer to the actors model
		FLOAT3 fModelBoundingBox[2]; // The current model bounding box

		// For the animaiton;
		int byAnimation;		 // The current animation depends on the current action
		int iAniStep,			 // The current animation step
			iNextAniStep,		 // The next animation step
			iMultiAniStep[7];    // The animation steps for more elements (e.g. for the box surfaces)
		long  dwAniTime,		 // The time since the last animation step change
			  dwAniDeltaTime,	 // The past ani time (for pausing the animation)
			  dwMultiAniTime[7]; // The same for the multi animation
		float fAniInterpolation, // The animation progress (e.g. for the smooth model interpolation)
			  fAniSpeed,		 // The normal animation playback speed
			  fAniSpeedFactor,   // To speed up or slow down the animation playback speed
			  fRealAniSpeed,     // The real animation speed (depends of fAniSpeed and fAniSpeedFactor)
			  fBoringTimer,		 // The counter since the last action
			  fWrongTimer;		 // Check when the wrong animation should be played
		long dwWeaponAniTimer;   // Weapon animation timer
		char byWeaponAniStep;  // Weapon animation step

		// Skin animation:
		long dwSkinSleepAniTime;
		BOOL bSkinSleep;

		// Box information:
		int iBoxSurface[7]; // The box surfaces for each side (6 sides + environment map)
		char byBoxSurfaceRot[7]; // The box surface rotation for each side (6 sides + environment map)

		BOOL bTextScript,
			 bTextScriptAlways;
		TEXT_SCRIPT *pTextScript; // Pointer to the actors text script (if the player presses the use key...)

		
///////////////////////////////
		// Items:
		ITEM_INFO Item[ITEMS]; // Information about all items the actor have
		BOOL bReincarnationShield; // Should the actor become a reincarnation shield?

		// Addidional information about the items and actor skills:
		BOOL bPullBoxesPossible, // Could the actor pull boxes?
			 bThrowBoxesPossible, // Could the actor throw boxes?
			 bJumpingPossible, // Could the actor jump?
			 bKickingPossible, // Could the actor jump?
			 bWeapon,	  // Has the actor a weapon?
			 bGhostMode,		  // Is the actor a ghost amd could walk through things?
			 bSpeedMode,		  // Are we in the speed modus?
			 bWingMode,			 // Are we in the wing modus?
			 bShieldMode;		   // Are we in the shield modus?

		float fStrength; // Unit strength power. The actor will lost the strength
						 // if we do something... if this is zero the strength will
					     // be decreased
		float fGhostModeTime;     // The left ghost modus time
		long lGhostModeTime;	  // The time were the last left ghost modus time update occured	
		float fSpeedModeTime;     // The left ghost modus time
		long lSpeedModeTime;	  // The time were the last left speed modus time update occured	
		float fWingModeTime;     // The left ghost modus time
		long lWingModeTime;		 // The time were the last left wing modus time update occured	
		float fShieldModeTime;     // The left ghost modus time
		long lShieldModeTime;	   // The time were the last left shield modus time update occured	

		// Some shield stuff:
		float fShieldLighting,
		      fShieldLightingVelocity,
			  fShieldLightingTo;
		FLOAT3 fShieldRot[8];      // The shield rotation
///////////////////////////////


		// E.g. for a 'fly' effect:
		FLOAT3 fPosTemp; // A position which is added to the normal
		FLOAT3 fPosTempTo; // The position which should ge gone to
		FLOAT3 fPosTempVelocity; // The velocity for the temp pos

		//  E,g. for the box destruction effect:
		FLOAT3 fTempRot[6], fTempRotVelocity[6],
			   fTempPos[6], fTempPosVelocity[6];



		float fPeepBlend; // For Blibs blinking and peeping feeler (cheat :)
		BOOL bPeepStep;


		int iParticleSystemID; // If this actor have an particle system then this is not -1
		float fRadius;

		long lStartTime;
		char byLifes;
		
		//
		int	iTempFieldID;


		BOOL bDocked,	// Is it docked (e.g. for boxes)
			 bGoingDocked, // Is to actor to be going docked
			 bBridge,   // Is this actor a bridge?
			 bBridgeMovement;   // Does the actor at the moment fall into a gap?

		long dwDockedStartTime;

		ACTOR(void);
		~ACTOR(void);
		void Init(void);
		BOOL IsDirectionRotationComplete(void);
		BOOL CheckIsDirection(char);
		BOOL SetAction(ACTOR_ACTION);
		void SetupCameraRotation(ACTOR_ACTION, AS_CAMERA *);
		BOOL Squash(void);
		ACTOR *GetNextFieldActor(char);
		void RemoveFromFields(void);
		BOOL GetNextFieldActive(char);
		BOOL CheckIfWall(char, int);
		BOOL DoWalking(char, BOOL);
		BOOL DoKicking(void);
		BOOL DoJump(char);
		BOOL PlayActorTextScript(char);
		BOOL CheckTurning(float);
		void Move(char);
		void CheckSurface(void);
		void GetWorldPos(void);
		void ComputeHeight(void);
		BOOL CheckForBeaming(void);
		BOOL CheckBeamingProcess(void);
		void Check(BOOL);
		void SetLevelTools(void);
		void CheckWater(void);
		void SetToCheckpoint(void);
		void MakeDamage(float);
		void DeleteActorType(void);
		void AnimateModel(AS_MD2_MODEL *);
		void SetupLighting(void);
		void MakeToolsToPoints(void);
		BOOL CheckHeightDifference(ACTOR *);
		void IncreaseItemNumber(ACTOR_TYPE, int);
		void DecreaseItemNumber(ACTOR_TYPE);
		void CheckCollectItem(void);
		void DeliverItems(void);
		void IncreaseWrongTimer(void);
		void CheckWrongTimer(void);
		BOOL CheckIfEnemy(void);
		void BeamingScale(float);
		void ShowInfoText(void);
		void CheckInfoText(void);
		void CheckChangeWaterHeight(void);

		// ActorBlibs.cpp
		void DrawBlibs(void);
		void CheckBlibs(BOOL);
		BOOL CheckBlibsKeys(void);
		void AnimateBlibsEyes(void);
		void InitBlibs(int, int);

		// ActorBox.cpp
		BOOL DoBoxPushing(char);
		BOOL DoBoxPulling(char);
		BOOL DoThrowBox(char);
		void KillBox(void);
		BOOL CheckBoxThrow(void);
		void DisableBoxDocking(void);
		void SetNoneFreeBox(void);
		void DisableNoneFreeBox(void);
		BOOL SetNoneFreeAnchor(void);
		void DisableNoneFreeAnchor(void);
		void DrawBox(void);
		void CheckBox(BOOL);
		void SetBoxSideTranslation(char);
		void DrawBoxSide(int, int, int, int, int, TEXTURE_POS *);
		void DrawBoxSide(FLOAT3, FLOAT3, FLOAT3, FLOAT3, int, TEXTURE_POS *);
		void SetupBoxSideDraw(SURFACE *, BOOL);
		void InitBox(int, int);

		// ActorMobmob:
		void DrawMobmob(void);
		void CheckMobmob(BOOL);

		// ActorX3:
		void DrawX3(void);
		void CheckX3(BOOL);

		// ActorLuciferHead.cpp
		void DrawLuciferHead(void);
		void CheckLuciferHead(BOOL);
		
		// ActorLucifer.cpp
		void DrawLucifer(void);
		void CheckLucifer(BOOL);

		// ActorItems:
		void DrawItem(void);
		void CheckItem(void);
		BOOL ActorCollectsItem(ACTOR *, FLOAT3, float, BOOL);

		// ActorShots:
		void DrawShot1(void);
		void CheckShot1(void);

} ACTOR;
///////////////////////////////////////////////////////////////////////////////


#endif // __ACTORS_H__
//-----------------------------------------------------------------------------
// File: ActorBlibs.cpp
//-----------------------------------------------------------------------------

#include "..\AS\AS_Engine.h"
#include "..\ModuleHeaders.h"


extern int iTemp;


void ACTOR::DrawBlibs(void)
{ // begin ACTOR::DrawBlibs()
	FLOAT3 fRealColor;
	
	if(!bActive)
		return; // The actor isn't active!
	if(!bPlayerCameraView && !bOnScreen)
	{ // The actor isn't on screen;
		iCulledObjects++;
		return;
	}

	glPushMatrix();
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_CULL_FACE);
	glCullFace(GL_FRONT);
	
	glTranslatef(fWorldPos[X], fWorldPos[Y], fWorldPos[Z]);
	glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
	glRotatef(90.0f, 0.0f, 1.0f, 0.0f);
	glRotatef(-fRot[Y]-180.0f, 0.0f, 1.0f, 0.0f);
	glScalef(0.005f, 0.005f, 0.005f);
	BeamingScale(1.0f);
	
	// Make Blibs blue if he hasn't enough air:
	if(fBlendDensity == 1.0f)
	{
		fRealColor[R] = fColor[R]-(fMaxAir-fAir)/100;
		fRealColor[G] = fColor[G]-(fMaxAir-fAir)/100;
		fRealColor[B] = fColor[B]+(fMaxAir-fAir)/100;
	}
	else
		fRealColor[R] = fRealColor[G] = fRealColor[B] = 1.0f;
	glColor3f(fRealColor[0], fRealColor[1], fRealColor[2]);
	
	if(bWeapon && Action == AA_SHOOTING)
	{ // Blibs has an weapon:
		glBindTexture(GL_TEXTURE_2D, GameTexture[19].iOpenGLID);


		ASPrecomputeMd2FrameInt(pBlibsWeaponModel, iAniStep, iNextAniStep, fAniInterpolation);
		ASDrawPrecomputedMd2Frame(pBlibsWeaponModel);


	}

	if(fBlendDensity != 1.0f)
	{ // The actor is blended:
		glEnable(GL_BLEND);
		glColor4f(fRealColor[0], fRealColor[1], fRealColor[2], fBlendDensity);
		glDisable(GL_FOG);
		glDepthMask(FALSE);
	}

	// Bind the actors texture:
	if(iTexture == -1)
	{
		if(!bWeapon)
			glBindTexture(GL_TEXTURE_2D, ActorTexture[BLIBS_TEXTURE].iOpenGLID);
		else
			glBindTexture(GL_TEXTURE_2D, ActorTexture[RAMBO_BLIBS_TEXTURE].iOpenGLID);
	}
	else
		glBindTexture(GL_TEXTURE_2D, pLevel->pTexture[iTexture].iOpenGLID);

	if(bShieldMode && _ASConfig->bMultitexturing)
	{ // Render unit 2:
		glActiveTextureARB(GL_TEXTURE1_ARB);
		glEnable(GL_TEXTURE_2D);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		glColor3f(1.0f, 1.0f, 1.0f);
		glBindTexture(GL_TEXTURE_2D, GameTexture[DisplayActor[0].iAniStep].iOpenGLID);
		glActiveTextureARB(GL_TEXTURE0_ARB);
	}

	//

	
	ASPrecomputeMd2FrameInt(pBlibsModel, iAniStep, iNextAniStep, fAniInterpolation);
	AS_Md2_GetCurrentBoundingBox(pBlibsModel, iAniStep, iNextAniStep, fAniInterpolation, &fModelBoundingBox);
	ASDrawPrecomputedMd2Frame(pBlibsModel);


	if(!bPlayerCameraView)
	{ // Draw only Blibs eyes if we are not in first person mode:
		glColor4f(fRealColor[R], fRealColor[G], fRealColor[B], fBlendDensity);
		if(bGhostMode)
		{
			glDisable(GL_BLEND);
			glDepthMask(TRUE);
		}
		if(bGoingDeath || bDeath)
			glBindTexture(GL_TEXTURE_2D, GameTexture[10].iOpenGLID);
		else
		{
			if(Action == AA_SWINGING)
				glBindTexture(GL_TEXTURE_2D, GameTexture[26].iOpenGLID);
			else
				glBindTexture(GL_TEXTURE_2D, GameTexture[4+bSkinSleep].iOpenGLID);
		}


		ASPrecomputeMd2FrameInt(pBlibsEyesModel, iAniStep, iNextAniStep, fAniInterpolation);
		ASDrawPrecomputedMd2Frame(pBlibsEyesModel);


	}
	
	if(bShieldMode && _ASConfig->bMultitexturing)
	{ // Deactivate the second render unit:
		glActiveTextureARB(GL_TEXTURE1_ARB);
		glDisable(GL_TEXTURE_2D);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
		glActiveTextureARB(GL_TEXTURE0_ARB);
	}

	if(_ASConfig->bDrawBounding)
	{ // Draw the bounding box around Blibs:
		glColor3f(1.0f, 1.0f, 1.0f);
		ASDrawBoundingBox(fModelBoundingBox);
	}
	glDepthMask(TRUE);
	glCullFace(GL_BACK);
	glDisable(GL_BLEND);
	glPopMatrix();
	if(pLevel->Environment.bFog)
		glEnable(GL_FOG);

/////////// Show vertex pos test: //////////////////////////
/*	glColor3f(1.0f, 1.0f, 1.0f);
//	iTemp = 9;
	ASGetMd2Vertex(pBlibsModel, iAniStep, iNextAniStep, fAniInterpolation, fWorldPos,
				    0.005f, -90.0f, -fRot[Y]-180.0f, 0.0f, iTemp, &fPos);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);
	glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_2D);
	glPointSize(8.0f);
	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_POINTS);
		glVertex3fv(fPos);
	glEnd();
	glEnable(GL_DEPTH_TEST);*/
/////////////////////////////////////////////////////////////////


} // end ACTOR::DrawBlibs()

void ACTOR::CheckBlibs(BOOL bEditor)
{ // begin ACTOR::CheckBlibs()
	AS_PARTICLE *pParticleT;
	int i, i2, i3, iNextAniStepT;
	float fHeightT;
	FIELD *pFieldT;
	BOOL bSwinging;
	FLOAT3 fPos;

	if(!bActive)
		return; // The actor isn't active!

	if(bEditor)
	{ // We are in the editor:
		SetAction(AA_STANDING);
	}	
	if(pLevel->State.bLevelComplete)
		SetAction(AA_FUNNY);

	if(bShieldMode)
		bSquashable = FALSE;
	else
		bSquashable = TRUE;
	if(!bMove && Action != AA_PULLING)
		MoveMode = ACTOR_MOVE_FORWARD;

	// Setup animation speed factor:
	if(!bSpeedMode)
	{
		fAniSpeedFactor = 1.0f;
		fTurningSpeed = 1.0f;
	}
	else
	{
		fAniSpeedFactor = 6.0f;	
		fTurningSpeed = 3.0f;	
	}
	if(Action == AA_JUMPING)
		fAniSpeedFactor *= 3.0f;
	if(Action == AA_WALL_JUMPING)
		fAniSpeedFactor *= 2.0f;
	if(Action == AA_PULL_WEAPON || Action == AA_POUCH_WEAPON)
		fAniSpeedFactor *= 3.0f;
	if(Action == AA_THROWING)
		fAniSpeedFactor *= 3.0f;
	if(Action == AA_KICKING)
		fAniSpeedFactor *= 1.5f;
	if(bGoingDeath)
		fAniSpeedFactor /= 1.5f;
	if(Action == AA_TALKING)
		fAniSpeedFactor /= 1.2f;
	if(Action == AA_DEATH)
		fAniSpeedFactor *= 1.5f;
	if(Action == AA_ANGRY)
		fAniSpeedFactor *= 2.0f;
	if(Action == AA_WRONG)
		fAniSpeedFactor *= 3.0f;
	if(Action == AA_HOLE_FALLING)
		fAniSpeedFactor *= 5.0f;
	if(Action == AA_SWIMMING)
		fAniSpeedFactor /= 1.5f;
	if(Action == AA_SWINGING)
		fAniSpeedFactor /= 1.5f;
	if(Action == AA_WALKING)
		fAniSpeedFactor *= 3.0f;
	if(Action == AA_PUSHING || Action == AA_PULLING)
		fAniSpeedFactor *= 6.0f;
	if(Action == AA_LOOK_AROUND || Action == AA_STANDING)
		fAniSpeedFactor /= 1.5f;
	if(MoveMode == ACTOR_MOVE_BACKWARD)
		fAniSpeedFactor /= 2.0f;
	fRealAniSpeed = fAniSpeed/fAniSpeedFactor;
	
	AnimateBlibsEyes();
	if(!bDeath)
		AnimateModel(pBlibsModel);
	Check(bEditor); // Do general actor checks

	if(bWingMode && ASCheckTimeUpdate(&lLastWingSmokeTime, 50))
	{ // Create smoke coming out of Blibs legs:		
		for(i2 = 0; i2 < 2; i2++)
		{
			i = ParticleManager.pSystem[PS_PLAYER_WING_SMOKE].GetFreeParticle();
			if(i == -1)
				return;
			pParticleT = &ParticleManager.pSystem[PS_PLAYER_WING_SMOKE].pParticle[i];
			pParticleT->bAlive = TRUE;
			pParticleT->fEngine = (float) 1.0;
		
			if(!i2)
				ASGetMd2Vertex(pBlibsModel, iAniStep, iNextAniStep, fAniInterpolation, fWorldPos,
							   0.005f, -90.0f, fRot[Y]+90.0f, 0.0f, 367, &fPos);
			else
				ASGetMd2Vertex(pBlibsModel, iAniStep, iNextAniStep, fAniInterpolation, fWorldPos,			
							   0.005f, -90.0f, fRot[Y]+90.0f, 0.0f, 793, &fPos);
			for(i3 = 0; i3 < 2; i3++)
			{
				if(!(rand() % 2))
					fPos[i3] += (rand() % 100)/400.0f;
				else
					fPos[i3] -= (rand() % 100)/400.0f;
			}
			if(!(rand() % 2))
				fPos[Z] += (rand() % 100)/800.0f;
			else
				fPos[Z] -= (rand() % 100)/800.0f;
			pParticleT->fPos[X] = fPos[X];
			pParticleT->fPos[Y] = fPos[Y];
			pParticleT->fPos[Z] = fPos[Z];
			pParticleT->fColor[0] = 1.0f;
			pParticleT->fColor[1] = 1.0f;
			pParticleT->fColor[2] = 1.0f;
			pParticleT->fDensity = 0.6f;
			pParticleT->fFadeSpeed = 0.005f+(rand() % 100)/10000.0f;
			pParticleT->fSize = (rand() % 1000)/600.0f;
			pParticleT->lLastAnimtationTime = g_lGameTimer;
		}
	}

	if(bEditor || bCameraAnimation)
		return;

	if(fBoringTimer > 1.0f)
	{ // Blibs is boring:
		bSwinging = FALSE;
		if(!bWingMode && Action == AA_STANDING)
		{ // Check if Blibs should swing:
			if(!(pFieldT = pLevel->ComputeHeight(fWorldPos[X]-0.1f, fWorldPos[Y]-0.1f, &fHeightT, FACE_FLOOR, FALSE)) || (!pFieldT->pBridgeActor && pFieldT->bWallHole))
				bSwinging = TRUE;
			else
			if(!(pFieldT = pLevel->ComputeHeight(fWorldPos[X]+0.1f, fWorldPos[Y]-0.1f, &fHeightT, FACE_FLOOR, FALSE)) || (!pFieldT->pBridgeActor && pFieldT->bWallHole))
				bSwinging = TRUE;
			else
			if(!(pFieldT = pLevel->ComputeHeight(fWorldPos[X]+0.1f, fWorldPos[Y]+0.1f, &fHeightT, FACE_FLOOR, FALSE)) || (!pFieldT->pBridgeActor && pFieldT->bWallHole))
				bSwinging = TRUE;
			else
			if(!(pFieldT = pLevel->ComputeHeight(fWorldPos[X]-0.1f, fWorldPos[Y]+0.1f, &fHeightT, FACE_FLOOR, FALSE)) || (!pFieldT->pBridgeActor && pFieldT->bWallHole))
				bSwinging = TRUE;
			else
			if(!(pFieldT = pLevel->ComputeHeight(fWorldPos[X], fWorldPos[Y], &fHeightT, FACE_FLOOR, FALSE)) || (!pFieldT->pBridgeActor && pFieldT->bWallHole))
				bSwinging = TRUE;
		}
		fBoringTimer = 0.0f;
		if(bSwinging)
		{
			SetAction(AA_SWINGING);
			bActionDone = FALSE;
		}
		else
		{
			if(rand() % 5)
			{
				if(!(rand() % 4))
					SetAction(AA_STANDING);
				else
				if(!(rand() % 4))
					SetAction(AA_FUNNY);
				else
				if(!(rand() % 8))
					SetAction(AA_PAIN);
				else
				if(!(rand() % 4))
					SetAction(AA_WRONG);
				else
					SetAction(AA_LOOK_AROUND);
			}
		}
	}

	if(this == pPlayer)
	{
		if(bBlibsPeeping)
		{ // Cheat: Draw the 'lights' at Blibs feeler if he walks backward: :)
			// Update the blinking and peeping:
			if(!bPeepStep && bMove && MoveMode == ACTOR_MOVE_BACKWARD)
			{
				if(!fPeepBlend)
					ASPlayFmodSample(pPeepSample, FSOUND_LOOP_OFF);
				fPeepBlend += (float) g_lDeltatime/500;
				if(fPeepBlend >= 1.0f)
				{
					fPeepBlend = 1.0f;
					bPeepStep = TRUE;
				}
			}
			else
			{
				fPeepBlend -= (float) g_lDeltatime/400;
				if(fPeepBlend <= 0.0f)
				{
					fPeepBlend = 0.0f;
					bPeepStep = FALSE;
				}
			}

			// Update the two particles:
			for(i = 0; i < 2; i++)
			{
				pParticleT = &ParticleManager.pSystem[PS_LIGHTS].pParticle[i];
				if(!i)
					ASGetMd2Vertex(pBlibsModel, iAniStep, iNextAniStep, fAniInterpolation, fWorldPos,
								   0.005f, -90.0f, -fRot[Y]+90.0f, 0.0f, 295, &pParticleT->fPos);
				else
					ASGetMd2Vertex(pBlibsModel, iAniStep, iNextAniStep, fAniInterpolation, fWorldPos,
								   0.005f, -90.0f, -fRot[Y]+90.0f, 0.0f, 732, &pParticleT->fPos);
				pParticleT->bAlive = TRUE;
				pParticleT->fEngine = 1.0f;
				pParticleT->fColor[0] = 1.0f*fPeepBlend;
				pParticleT->fColor[1] = 0.8f*fPeepBlend;
				pParticleT->fColor[2] = 0.8f*fPeepBlend;
				pParticleT->fSize = 3.0f;
				pParticleT->fDensity = 0.99f;
			}
		}
	}

	if(!CheckTurning(g_lDeltatime/PLAYER_TURN_SPEED*fTurningSpeed))
	{ // Move the actor:
		Move(-1);
	}
	if(bGoingDeath)
	{ // Blibs is dies at the moment:
		if(this == pPlayer)
			CheckCollectItem();
		if(!bDeath)
		{ // Check if Blibs lies now death on the floor:
			iNextAniStepT = iAniStep+1;
			if(iNextAniStepT == pBlibsModel->Ani.anim[byAnimation].lastFrame-1)
			{ // Blibs lies now a few seconds on the floor: (in that time you could see Blibs soul flying against heaven)
				if(Action == AA_SWIMMING)
				{
					bSmotherDone = TRUE;
					return;
				}
				if(Action == AA_HOLE_FALLING)
				{
					SetAction(AA_DEATH);
					return;
				}
				if(Action == AA_DEATH)
				{
					DeliverItems();
					bDeath = TRUE;
					fDeathTime = 0.0f;
					lDeathTime = g_lGameTimer;
				}
			}
			pCamera->fRot2Velocity[X] = -0.02f*g_lDeltatime;
		}
		else
		{ // Check if the player press any key: (to get fast back into life)
			if(!bClone)
			{
				for(i = 0; i < 256; i++)
				{
					if(ASKeyFirst[i])
					{
						ASKeyFirst[i] = ASKeys[i] = FALSE;
						bDeath = TRUE;
						fDeathTime = 1.5f;
						break;
					}
					ASKeyFirst[i] = FALSE;
				}
			}
			fDeathTime += (float) g_lDeltatime/5000;

			if(fDeathTime >= 1.5f)
			{ // Now its time to decide what should happen with our death Blibs:
				// Was Blibs hunted by the Okta? If yes, does he hit Blibs?
				// Or is the time out?
				if(((pLevel->Missions.bTimeLimit && pLevel->Missions.iTimeLimit <= 0) ||
				   (pLevel->Missions.bStepsLimit && pLevel->Missions.iStepsLimit <= 0)) &&
				   !pLevel->State.bLevelComplete && !bClone)
				{ // Blibs was caught by the Okta! Restart the Level:
					StartCurrentLevel();
					return;
				}
			
				DecreaseItemNumber(AT_LIFE_ITEM);
				if(!Item[AT_LIFE_ITEM].iNumber)
				{ // Game over!
					memset(fVelocity, 0, sizeof(FLOAT3));
					bActive = FALSE;
					if(!bClone)
					{
						bGameOver = TRUE;
						byGameMenuSelected = 2;
					}
					return;
				}
				else
				{ // Set Blibs to the last checkpoint:
					SetToCheckpoint();
				}
			}
		}
	}
	else
	{
		iNextAniStepT = iAniStep+1;
		if(iNextAniStepT == 432 && !bActionDone)
		{ // Kicking:
			bActionDone = TRUE;
			if(DoKicking())
				ASPlayFmodSample(pBlibsKickSample, FSOUND_LOOP_OFF);
		}
		else
		if(iNextAniStepT == 272 && !bActionDone)
		{ // Throwing:
			bActionDone = TRUE;
			DoThrowBox(-1);
		}
		if(iNextAniStepT == 296 && !bActionDone)
		{ // Swinging:
			if(!(rand() % 5))
				bFallIntoHole = TRUE;
			bActionDone = TRUE;
		}
		if(iNextAniStepT >= pBlibsModel->Ani.anim[byAnimation].lastFrame)
		{
			if(Action == AA_PAIN || Action == AA_POUCH_WEAPON ||
			   Action == AA_CHECKPOINT || Action == AA_HEALTH ||
			   Action == AA_WRONG || Action == AA_FUNNY || 
			   Action == AA_KICKING || Action == AA_THROWING ||
			   Action == AA_JUMPING || Action == AA_WALL_JUMPING || 
			   Action == AA_LOOK_AROUND || Action == AA_SMOTHER ||
			   Action == AA_ANGRY || Action == AA_SWINGING)
			{
				if(bFallIntoHole)
				{
					RemoveFromFields();
					fHealth = 0.0f;
					fVelocity[Z] = 0.003f;
					SetAction(AA_HOLE_FALLING);
				}
				else
				if(Action == AA_WALL_JUMPING)
					SetAction(AA_ANGRY);
				else
					SetAction(AA_NOTHING);
			}
			if(Action == AA_PULL_WEAPON)
			{ // Now Blibs is ready to fire a shot:
				dwAniTime = g_lGameTimer;
				bReadyToShoot = TRUE;
			}
			if(Action == AA_SHOOTING)
				Action = AA_PULL_WEAPON;
		}

		if(this == pPlayer && !fFieldPos[X] && !fFieldPos[Y] && !pLevel->TextScriptManager.bPlayTextScript)
		{ // Check the text script on the floor face:
			FIELD *pFieldT = &pLevel->pField[iFieldID];
			if(iLastCheckedField != iFieldID)
			{
				iLastCheckedField = iFieldID;
				if(!pFieldT->bTextScriptActionKey[FACE_FLOOR] && pFieldT->bTextScript[FACE_FLOOR])
				{
					pLevel->TextScriptManager.PlayTextScript(pFieldT->pTextScript[FACE_FLOOR], 0);
					pLevel->TextScriptManager.pTalkToActor = NULL;
					if(!pFieldT->bTextScriptAlways[FACE_FLOOR])
						pFieldT->bTextScript[FACE_FLOOR] = FALSE;
				}
				// Check if an camera should be played:
				if(pFieldT->iCamera != -1)
				{ // Yes:
					bCameraAnimation = TRUE;
					memset(&TempCamera, 0, sizeof(AS_CAMERA));
					lCameraTimer = g_lGameTimer;
					pLevel->Camera.iCurrentCameraStep = 0;
					pLevel->pCurrentCameraScript = &pLevel->pCameraScript[pFieldT->iCamera];
					if(!pFieldT->bCameraAlways)
						pFieldT->iCamera = -1;
				}
			}

		}

		if(CheckBeamingProcess())
			return; // We are beamed at the moment!
		CheckWater(); // Check the water

		if(!CheckForBeaming())
		{ // Check if Blibs collects a object:
			if(this == pPlayer)
				CheckCollectItem();
			if(!pLevel->State.bLevelComplete)
			{
				CheckBlibsKeys(); // Check the players input
				CheckSurface(); // Check the surface were Blibs is on
			}
		}
	}
	if(bMove)
	{ // Make camera sluggishness:
		float fXAcceleration = 0.0f, fYAcceleration = 0.0f;

		switch(byDirection)
		{
			case LEFT: fXAcceleration = 1.0f; break;
			case UP: fYAcceleration = 1.0f; break;
			case RIGHT: fXAcceleration = -1.0f; break;
			case DOWN: fYAcceleration = 1.0f; break;
		}
		fXAcceleration *= fMoveVelocity/5;
		fYAcceleration *= fMoveVelocity/5;
		if(fXAcceleration)
		{
			_ASCamera->fPos2[X] -= fSin*fXAcceleration;
			_ASCamera->fPos2[Y] -= fCos*fXAcceleration;
		}
		if(fYAcceleration)
		{
			_ASCamera->fPos2[X] -= fSin90*fYAcceleration;
			_ASCamera->fPos2[Y] -= fCos90*fYAcceleration;
		}
	}
	else
		fFieldPos[X] = fFieldPos[Y] = 0.0f;

	if(bSpeedMode)
		fVelocity[0] = 2.0f;
	else
		fVelocity[0] = 1.0f;
	if(MoveMode == ACTOR_MOVE_BACKWARD)
		fVelocity[0] /= 1.5f;
	if(Action == AA_JUMPING || Action == AA_WALL_JUMPING)
	{ // If the actor jumps then there isn't an friction:
		fVelocity[0] *= 1.4f;
		bUseFriction = FALSE;
	}
	else
		bUseFriction = TRUE;
} // end ACTOR::CheckBlibs()

// Check the player input for controlling Blibs:
BOOL ACTOR::CheckBlibsKeys(void)
{ // begin ACTOR::CheckBlibsKeys()
	int byMoveKeys[4] = {_ASConfig->iLeftKey[0], _ASConfig->iUpKey[0],
						 _ASConfig->iRightKey[0], _ASConfig->iDownKey[0]};
	FIELD *pFieldT = &pLevel->pField[iFieldID];
	AS_PARTICLE_SYSTEM *pSystemT;
	char byMoveRotation = 0;
	ACTOR *pActorT;
	int i, iFace;

	if(pLevel->TextScriptManager.bPlayTextScript && pLevel->TextScriptManager.pCurrentTS &&
	   !pLevel->TextScriptManager.pCurrentTS->bMovementPossible)
	{
		if(pLevel->TextScriptManager.pCurrentTS->bTalkAnimation)
			SetAction(AA_TALKING);
		else
			SetAction(AA_STANDING);
		return FALSE; // The player couldn't move if that text script is active!
	}

	// Check if the player still do something:
	if(bMove || Action == AA_DEATH ||
	   Action == AA_SHOOTING || Action == AA_KICKING ||
	   Action == AA_CHECKPOINT || Action == AA_JUMPING || Action == AA_WALL_JUMPING ||
	   Action == AA_FALLING || Action == AA_THROWING || Action == AA_ANGRY ||
	   Action == AA_SWINGING ||
	   fVelocity[Z])
		return FALSE; // The player still do something!!

	if(CHECK_KEY(ASKeys, _ASConfig->iShotKey[0]) || (bPlayerCameraView && CHECK_KEY(ASMouse.byButtons, 0)))
	{ // Shooting:
		fBoringTimer = 0.0f;
		if(bWeapon && !bGhostMode && !CheckIfWall(-1, 1))
		{	
			if(!bReadyToShoot)
			{ // Pull weapon an shoot:
				SetAction(AA_PULL_WEAPON);
				return TRUE;
			}
			else
			{ // Create the shot:
				pActorT	= pLevel->FindFreeActor();
				if(!pActorT)
					return TRUE;
				pActorT->bActive = TRUE;
				ASGetMd2Vertex(pBlibsWeaponModel, iAniStep, iNextAniStep, fAniInterpolation,
								fWorldPos, 0.005f, -90.0f, fRot[Y]+90.0f, 0.0f, 69, &pActorT->fWorldPos);
				pActorT->fSize = 1.0f;
				pActorT->bDeathWave = TRUE;
				pActorT->bMove = TRUE;
				pActorT->Type = AT_SHOT_1;
				pActorT->byDirection = byDirection;

				// Create the shot particle system:
				// Shot trace:
        		i = ParticleManager.AddNewSystem(PS_ShotTrace1, 69, pActorT, &GameTexture[12], NULL);
				ParticleManager.pSystem[i].bActive = TRUE;
				
				// Weapon smoke:
				i = ParticleManager.AddNewSystem(PS_Smoke1, 69, pPlayer, &GameTexture[21], NULL);
				pSystemT = &ParticleManager.pSystem[i];
				pSystemT->bActive = TRUE;
				pSystemT->fStartPos[X] = pActorT->fWorldPos[X];
				pSystemT->fStartPos[Y] = pActorT->fWorldPos[Y];
				pSystemT->fStartPos[Z] = pActorT->fWorldPos[Z];
				pSystemT->bAnimatedParticles = TRUE;
				pSystemT->iAnimationColumns = 2;
				pSystemT->iAnimationRows = 2;
				pSystemT->iTextureWidth = 128;
				pSystemT->iTextureHeight = 128;

				// Shot animation:
  				SetAction(AA_SHOOTING);
				SetupCameraRotation(AA_SHOOTING, pCamera);

				ASPlayFmodSample(pBlibsShotSample, FSOUND_LOOP_OFF);
				DecreaseItemNumber(AT_WEAPON_ITEM);
				return TRUE;
			}
		}
		else
		{
			IncreaseWrongTimer();
			return TRUE;
		}
	}
	else
	{
		bReadyToShoot = FALSE;
		if(Action == AA_PULL_WEAPON || Action == AA_SHOOTING)
			SetAction(AA_POUCH_WEAPON);
	}

	if(Action == AA_POUCH_WEAPON)
		return TRUE; // Blibs pouches his weapon

	if(ASKeys[42] || ASKeys[29]) // Left Shift-key & Strg-key (camera manipulation)
		return FALSE;
		
	if(CHECK_KEY(ASKeys, _ASConfig->iKickKey[0]))
	{ // Kicking:
		fBoringTimer = 0.0f;
		if(!bKickingPossible || bGhostMode)
		{
			IncreaseWrongTimer();
			return TRUE;
		}
		else
		{
			bActionDone = FALSE;
			SetAction(AA_KICKING);
			DecreaseItemNumber(AT_KICK_ITEM);
			return TRUE;
		}
	}

	// Check Blibs movement: (walking & pushing)
	if(!bPlayerCameraView && !_ASConfig->bRotateMove && !_ASConfig->bBackCamera)
	{ // Camera dependent control:
		// Get camera walk direction:
		if(pCamera->fRot[Z] >= 315 && pCamera->fRot[Z] < 45)
			byMoveRotation = 0;
		else
		if(pCamera->fRot[Z] >= 45 && pCamera->fRot[Z] < 135)
			byMoveRotation = 1;
		else
		if(pCamera->fRot[Z] >= 135 && pCamera->fRot[Z] < 225)
			byMoveRotation = 2;
		else
		if(pCamera->fRot[Z] >= 225 && pCamera->fRot[Z] < 315)
			byMoveRotation = 3;

		if(CHECK_KEY(ASKeys, byMoveKeys[(LEFT+byMoveRotation) % 4]))
		{ // Walk/push left:
			fBoringTimer = 0.0f;
			byDirection = LEFT;
			if(CheckIsDirection(-1))
				if(!DoWalking(-1, FALSE))
					if(!DoBoxPushing(-1))
						IncreaseWrongTimer();
		}
		else
		if(CHECK_KEY(ASKeys, byMoveKeys[(UP+byMoveRotation) % 4]))
		{ // Walk/push up:
			fBoringTimer = 0.0f;
			byDirection = UP;
			if(CheckIsDirection(-1))
				if(!DoWalking(-1, FALSE))
					if(!DoBoxPushing(-1))
						IncreaseWrongTimer();
		}
		else
		if(CHECK_KEY(ASKeys, byMoveKeys[(RIGHT+byMoveRotation) % 4]))
		{ // Walk/push right:
			fBoringTimer = 0.0f;
			byDirection = RIGHT;
			if(CheckIsDirection(-1))
				if(!DoWalking(-1, FALSE))
					if(!DoBoxPushing(-1))
						IncreaseWrongTimer();
		}
		else
		if(CHECK_KEY(ASKeys, byMoveKeys[(DOWN+byMoveRotation) % 4]))
		{ // Walk/push down:
			fBoringTimer = 0.0f;
			byDirection = DOWN;
			if(CheckIsDirection(-1))
				if(!DoWalking(-1, FALSE))
					if(!DoBoxPushing(-1))
						IncreaseWrongTimer();
		}
	}
	else
	{ // Camera independent movement;
		if(!IsDirectionRotationComplete())
			return FALSE; // Blibs is still turning!
		if(CHECK_KEY(ASKeys, byMoveKeys[LEFT]))
		{ // Turn left:
			fBoringTimer = 0.0f;
			byDirection--;
			if(byDirection < 0)
				byDirection = 3;
		}
		else
		if(CHECK_KEY(ASKeys, byMoveKeys[RIGHT]))
		{ // Turn right:
			fBoringTimer = 0.0f;
			byDirection++;
			if(byDirection > 3)
				byDirection = 0;
		}
		else
		{
			if(CHECK_KEY(ASKeys, byMoveKeys[UP]))
			{ // Walk/push foreward:
				fBoringTimer = 0.0f;
				if(!DoWalking(-1, FALSE))
					if(!DoBoxPushing(-1))
						IncreaseWrongTimer();
				MoveMode = ACTOR_MOVE_FORWARD;
			}
			else
			if(CHECK_KEY(ASKeys, byMoveKeys[DOWN]))
			{ // Walk backward:
				fBoringTimer = 0.0f;
				if(!DoWalking((byDirection+2) % 4, FALSE))
					IncreaseWrongTimer();
				MoveMode = ACTOR_MOVE_BACKWARD;
			}
		}
	}

	// Actions:
	if(!IsDirectionRotationComplete())
		return FALSE; // Blibs is still turning!
	if(CHECK_KEY(ASKeys, _ASConfig->iJumpKey[0]))
	{ // Let Blibs jump:
		fBoringTimer = 0.0f;
		if(bJumpingPossible)
		{
			if(!DoJump(-1))
			{
				IncreaseWrongTimer();
				return TRUE; // Blibs couldn't jump at the moment!
			}
			ASPlayFmodSample(pBlibsJumpSample, FSOUND_LOOP_OFF);
			SetupCameraRotation(AA_JUMPING, pCamera);
			return FALSE;
		}
		else
			IncreaseWrongTimer();
	}
	else
	if(CHECK_KEY(ASKeys, _ASConfig->iPullKey[0]))
	{ // Pull a box:
		fBoringTimer = 0.0f;
		if(!DoBoxPulling(-1))
			IncreaseWrongTimer();
	}
	else
	if(ASKeyFirst[_ASConfig->iActionKey[0]])
	{ 
		fBoringTimer = 0.0f;

		// Check if theres a actor with a text script:
		if(this == pPlayer)
		{
			PlayActorTextScript(-1);

			// Check the text scripts:
			switch(byDirection)
			{
				case LEFT: iFace = FACE_LEFT; break;
				case UP: iFace = FACE_TOP; break;
				case RIGHT: iFace = FACE_RIGHT; break;
				case DOWN: iFace = FACE_BOTTOM; break;
			}
			if(pFieldT->bTextScriptActionKey[iFace] && pFieldT->bTextScript[iFace])
			{
				pLevel->TextScriptManager.PlayTextScript(pFieldT->pTextScript[iFace], 0);
				if(!pFieldT->bTextScriptAlways[iFace])
					pFieldT->bTextScript[iFace] = FALSE;
			}
			else
			if(pFieldT->bTextScriptActionKey[FACE_FLOOR] && pFieldT->bTextScript[FACE_FLOOR])
			{
				pLevel->TextScriptManager.PlayTextScript(pFieldT->pTextScript[FACE_FLOOR], 0);
				if(!pFieldT->bTextScriptAlways[FACE_FLOOR])
					pFieldT->bTextScript[FACE_FLOOR] = FALSE;
			}
		}

		// Throw a box:
		if(!bThrowBoxesPossible || bGhostMode)
		{
			IncreaseWrongTimer();
			return TRUE;
		}
		else
		{
			bActionDone = FALSE;
			SetAction(AA_THROWING);
			DecreaseItemNumber(AT_THROW_ITEM);
			return TRUE;
		}
	}
	else
	if(CHECK_KEY(ASKeys, _ASConfig->iSuicideKey[0]))
	{ // Self destruction:
		fBoringTimer = 0.0f;
		if(SetAction(AA_PAIN))
		{ // Hurt Blibs:
			SetupCameraRotation(AA_PAIN, pCamera);
			fHealth /= 2.0f;
			if(fHealth < 2.0f)
				fHealth = 0.0f;
		}
	}
	else
	if(!bMove &&
	   Action != AA_WRONG &&
	   Action != AA_PAIN &&
	   Action != AA_HEALTH &&
	   Action != AA_FUNNY &&
	   Action != AA_LOOK_AROUND &&
	   Action != AA_SMOTHER &&
	   Action != AA_SWINGING &&
	   Action != AA_ANGRY)
	{
		fBoringTimer += (float) g_lDeltatime/3000;
		SetAction(AA_STANDING);
		SetupCameraRotation(AA_STANDING, pCamera);

	}
	
	return FALSE;
} // end ACTOR::BlibsPlayerKeys()

// Animate Blibs eyes:
void ACTOR::AnimateBlibsEyes(void)
{ // begin ACTOR::AnimateBlibsEyes()
	// Animate the Blibs eyes:
	if(bGoingDeath || Action == AA_DEATH)
	{
		dwSkinSleepAniTime = g_lGameTimer;
		bSkinSleep = TRUE;
	}
	else
	{
		if(!bSkinSleep)
		{ // Should Blibs close his eyes?
			if(ASCheckTimeUpdate(&dwSkinSleepAniTime, 100))
			{
				if(!(rand() % 30))
					bSkinSleep = TRUE;
			}
		}
		else
		{ // Should Blibs open his eyes?
			if(ASCheckTimeUpdate(&dwSkinSleepAniTime, 10))
			{
				if(!(rand() % 30))
					bSkinSleep = FALSE;
			}
		}
	}
} // end ACTOR::AnimateBlibsEyes()

void ACTOR::InitBlibs(int iX, int iY)
{ // begin ACTOR::InitBlibs()
	bActive = TRUE;
	fHealth = 100.0f;
	fMaxHealth = 100.0f;
	Item[AT_LIFE_ITEM].iNumber = 3;
	fStrength = 1.0f;
	fSize = 1.0f;
	Item[AT_STRENGTH_ITEM].iNumber = 1;
	iFieldPos[X] = iX;
	iFieldPos[Y] = iY;
	Type = AT_BLIBS;
	bSquashable = TRUE;
	byDirection = iEditorRotate;
	fLastHeightCheckWorldPos[X] = -1.0f;
	fLastHeightCheckWorldPos[Y] = -1.0f;
	fRot[Y] = (float) byDirection*90;
	GET_FIELD_ID(iX, iY, iFieldID);
	pLevel->pField[iFieldID].pActor = this;
	fColor[0] = 1.0f;
	fColor[1] = 1.0f;
	fColor[2] = 1.0f;
	fAir = 100.0f;
	fMaxAir = 100.0f;
	fAniSpeed = 100.0f;
	fAniSpeedFactor = 1.0f;
	fRealAniSpeed = fAniSpeed/fAniSpeedFactor;
	fTurningSpeed = 1.0f;
	vCollisionEllipsoid = 0.2f;
	GetWorldPos();
} // end ACTOR::InitBlibs()
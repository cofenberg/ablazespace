//-----------------------------------------------------------------------------
// File: ActorLuciferHead.cpp
//-----------------------------------------------------------------------------

#include "..\AS\AS_Engine.h"
#include "..\ModuleHeaders.h"


void ACTOR::DrawLuciferHead(void)
{ // begin ACTOR::DrawLuciferHead()
} // end ACTOR::DrawLuciferHead()

void ACTOR::CheckLuciferHead(BOOL)
{ // begin ACTOR::CheckLuciferHead()
} // end ACTOR::CheckLuciferHead()
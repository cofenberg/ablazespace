//-----------------------------------------------------------------------------
// File: Actors.cpp
//-----------------------------------------------------------------------------

#include "..\AS\AS_Engine.h"
#include "..\ModuleHeaders.h"


// ACTOR functions: ***********************************************************
ACTOR::ACTOR(void)
{ // begin ACTOR()
	memset(this, 0, sizeof(ACTOR));
	fSize = 1.0f;
	iParticleSystemID = -1;
} // end ACTOR()

ACTOR::~ACTOR(void)
{ // begin ~ACTOR()
} // end ~ACTOR()

void ACTOR::Init(void)
{ // begin Init()
	memset(this, 0, sizeof(ACTOR));
	iParticleSystemID = -1;
	fAniSpeed = 100;
	fAniSpeedFactor = 1.0f;
} // end Init()

// Is the actors rotation complete?
BOOL ACTOR::IsDirectionRotationComplete(void)
{ // begin ACTOR::IsDirectionRotationComplete()
	if(byDirection == LEFT && fRot[Y] != 0.0f)
		return FALSE;
	else
	if(byDirection == UP && fRot[Y] != 90.0f)
		return FALSE;
	else
	if(byDirection == RIGHT && fRot[Y] != 180.0f)
		return FALSE;
	if(byDirection == DOWN && fRot[Y] != 270.0f)
		return FALSE;
	else

	return TRUE;
} // end ACTOR::IsDirectionRotationComplete()

// Checks if the actor looks in the given given direction:
BOOL ACTOR::CheckIsDirection(char byDirectionT)
{ // begin ACTOR::CheckIsDirection()
	if(byDirectionT == -1)
		byDirectionT = byDirection;
	switch(byDirectionT)
	{
		case LEFT:
			if(fRot[Y] != 0.0f)
				return FALSE;
		break;

		case UP:
			if(fRot[Y] != 90.0f)
				return FALSE;
		break;

		case RIGHT:
			if(fRot[Y] != 180.0f)
				return FALSE;
		break;

		case DOWN:
			if(fRot[Y] != 270.0f)
				return FALSE;
		break;
	}

	return TRUE;
} // end ACTOR::CheckIsDirection()

// Set the actors action:
BOOL ACTOR::SetAction(ACTOR_ACTION ActionT)
{ // begin ACTOR::SetAction()
	AS_MD2_MODEL *pModel;
	
	if(Action == ActionT)
		return FALSE; // This animation is already played!

	// Set the right model animation corresponding to the actors type:
	switch(Type)
	{
	// Blibs:
		case AT_BLIBS:
			switch(ActionT)
			{
				case AA_NOTHING: Action = ActionT; return FALSE;
				case AA_STANDING: byAnimation = 3; break;
				case AA_LOOK_AROUND: byAnimation = 2; break;
				
				case AA_WALKING:
					byAnimation = 1;
					MoveMode = ACTOR_MOVE_FORWARD;
					SetupCameraRotation(AA_WALKING, pCamera);
				break;

				case AA_PUSHING:
					byAnimation = 4;
					MoveMode = ACTOR_MOVE_FORWARD;
				break;

				case AA_PULLING:
					byAnimation = 5;
					MoveMode = ACTOR_MOVE_BACKWARD;
				break;

				case AA_PULL_WEAPON: byAnimation = 8; break;
				case AA_SHOOTING: byAnimation = 9; break;
				case AA_KICKING: byAnimation = 21; break;
				case AA_FALLING: byAnimation = 12; break;
				case AA_THROWING: byAnimation = 15; break;
				case AA_SMOTHER: byAnimation = 18; break;
				case AA_POUCH_WEAPON: byAnimation = 10; break;
				
				case AA_JUMPING:
					byAnimation = 11;
					MoveMode = ACTOR_MOVE_FORWARD;
				break;

				case AA_WALL_JUMPING:
					byAnimation = 20;
					MoveMode = ACTOR_MOVE_FORWARD;
				break;
				
				case AA_CHECKPOINT: byAnimation = 11; break;
				case AA_PAIN:
					byAnimation = 13;
					ASPlayFmodSample(pBlibsPainSample, FSOUND_LOOP_OFF);
				break;
				case AA_DEATH: byAnimation = 14; break;
				case AA_SWIMMING: byAnimation = 24; break;
				case AA_HOLE_FALLING: byAnimation = 19; break;

				case AA_WRONG:
					ASPlayFmodSample(pBlibsWrongSample, FSOUND_LOOP_OFF);
					byAnimation = 6;
				break;
				case AA_FUNNY: byAnimation = 7; break;
				case AA_FUNNY2: byAnimation = 7; break;
				case AA_HEALTH: byAnimation = 12; break;
				case AA_TALKING: byAnimation = 22; break;
				case AA_SWINGING: byAnimation = 16; break;
				case AA_ANGRY: byAnimation = 17; break;
				
				default: return FALSE;
			}
			pModel = pBlibsModel;
		break;
	
	// Mobmob:
		case AT_MOBMOB:
			switch(ActionT)
			{
				case AA_NOTHING: Action = ActionT; return FALSE;
				case AA_STANDING: byAnimation = 1; break;
				case AA_LOOK_AROUND: byAnimation = 13; break;
				
				case AA_WALKING:
					byAnimation = 2;
					MoveMode = ACTOR_MOVE_FORWARD;
					SetupCameraRotation(AA_WALKING, pCamera);
				break;

				case AA_SHOOTING:
					byAnimation = 3;
					ASPlayFmodSample(pMobmobAttackSample, FSOUND_LOOP_OFF);
				break;
				
				case AA_JUMPING:
					byAnimation = 5;
					MoveMode = ACTOR_MOVE_FORWARD;
				break;
				
				case AA_CHECKPOINT: byAnimation = 3; break;
				case AA_PAIN: byAnimation = 4; break;
				case AA_DEATH: byAnimation = 12; break;
				case AA_DEATH1: byAnimation = 13; break;
				case AA_FUNNY: byAnimation = 8; break;
				case AA_FUNNY2: byAnimation = 6; break;
				case AA_HEALTH: byAnimation = 7; break;
				case AA_PICK_UP: byAnimation = 10; break;
				case AA_DOCKED: byAnimation = 11; break;
				case AA_ANGRY: byAnimation = 8; break;
				default: return FALSE;
			}
			pModel = pMobmobModel;
		break;

	// X3:
		case AT_X3:
			if(!bSmall)
			{
				switch(ActionT)
				{
					case AA_NOTHING: Action = ActionT; return FALSE;
					case AA_STANDING: byAnimation = 1; break;
					
					case AA_WALKING:
						byAnimation = 2;
						MoveMode = ACTOR_MOVE_FORWARD;
						SetupCameraRotation(AA_WALKING, pCamera);
					break;

					case AA_SHOOTING:
						byAnimation = 3;
						ASPlayFmodSample(pMobmobAttackSample, FSOUND_LOOP_OFF);
					break;
					
					case AA_PAIN: byAnimation = 4; break;
					case AA_DEATH: byAnimation = 11; break;
					case AA_FUNNY: byAnimation = 5; break;
					case AA_ANGRY: byAnimation = 5; break;
					default: return FALSE;
				}
			}
			else
			{
				switch(ActionT)
				{
					case AA_NOTHING: Action = ActionT; return FALSE;
					case AA_STANDING: byAnimation = 6; break;
					
					case AA_WALKING:
						byAnimation = 7;
						MoveMode = ACTOR_MOVE_FORWARD;
						SetupCameraRotation(AA_WALKING, pCamera);
					break;

					case AA_SHOOTING:
						byAnimation = 9;
						ASPlayFmodSample(pMobmobAttackSample, FSOUND_LOOP_OFF);
					break;
					
					case AA_PAIN: byAnimation = 8; break;
					case AA_DEATH: byAnimation = 10; break;
					case AA_FUNNY: byAnimation = 6; break;
					case AA_ANGRY: byAnimation = 6; break;
					default: return FALSE;
				}
			}
			pModel = pX3Model;
		break;

		default: return FALSE;
	}
	
	// Setup the animation:
	Action = ActionT;
	dwAniTime = g_lGameTimer;
	iAniStep = pModel->Ani.anim[byAnimation].firstFrame;

	return TRUE;
} // end ACTOR::SetAction()

// Sets the camera rotation corresponding an action: (e.g. used for the first-person perspective)
void ACTOR::SetupCameraRotation(ACTOR_ACTION ActionT, AS_CAMERA *pCameraT)
{ // begin ACTOR::SetupCameraRotation()
	char i;

	switch(Action)
	{
		case AA_STANDING:
			for(i = 0; i < 3; i++)
			{
				if(pCameraT->fRot2Velocity[i] > 0.001f || pCameraT->fRot2Velocity[i] < -0.001f)
					continue;
				if(!(rand() % 2))
					pCameraT->fRot2Velocity[i] += (float) (rand() % 100)/100000;
				else
					pCameraT->fRot2Velocity[i] -= (float) (rand() % 100)/100000;
			}
		break;

		case AA_WALKING:
			for(i = 0; i < 3; i++)
			{
				if(pCameraT->fRot2Velocity[i] > 0.001f || pCameraT->fRot2Velocity[i] < -0.001f)
					continue;
				if(!(rand() % 2))
					pCameraT->fRot2Velocity[i] += (float) (rand() % 100)/10000;
				else
					pCameraT->fRot2Velocity[i] -= (float) (rand() % 100)/10000;
			}
		break;


		case AA_JUMPING: case AA_WALL_JUMPING: case AA_SHOOTING: case AA_KICKING: case AA_CHECKPOINT:
			for(i = 1; i < 3; i++)
			{
				if(pCameraT->fRot2Velocity[i] > 0.001f || pCameraT->fRot2Velocity[i] < -0.001f)
					continue;
				if(!(rand() % 2))
					pCameraT->fRot2Velocity[i] += (float) (rand() % 100)/10000;
				else
					pCameraT->fRot2Velocity[i] -= (float) (rand() % 100)/10000;
			}
			if(pCameraT->fRot2Velocity[X] < 0.001f && pCameraT->fRot2Velocity[X] > -0.001f)
				pCameraT->fRot2Velocity[X] -= 0.05f+((float) (rand() % 5)/50);
		break;
		
		case AA_PAIN:
			for(i = 0; i < 3; i++)
			{
				pCameraT->fRot2Velocity[i] = 0.0f;
				if(pCameraT->fRot2Velocity[i] > 0.001f || pCameraT->fRot2Velocity[i] < -0.001f)
					continue;
				if(!(rand() % 2))
					pCameraT->fRot2Velocity[i] += (float) (rand() % 100)/1000;
				else
					pCameraT->fRot2Velocity[i] -= (float) (rand() % 100)/1000;
			}
		break;
	}
} // end ACTOR::SetupCameraRotation()

// An actor is squashed: (eg. through an box)
BOOL ACTOR::Squash(void)
{ // begin ACTOR::Squash()
	if(!bSquashable)
		return FALSE; // This actor couldn't be squashed!

	fHealth = 0.0f;
	RemoveFromFields();
	
	return TRUE;
} // end ACTOR::Squash()

// Get an pointer to the actor on the next field in the given direction:
ACTOR *ACTOR::GetNextFieldActor(char byDirectionT)
{ // begin ACTOR::GetNextFieldActor()
	FIELD *pNextFieldT;
	int iX, iY;

	if(byDirectionT == -1)
		byDirectionT = byDirection;

	// Setup x/y direction:
	switch(byDirectionT)
	{
		case LEFT: iX = -1; iY = 0; break;
		case UP: iX = 0; iY = -1; break;
		case RIGHT: iX = 1; iY = 0; break;
		case DOWN: iX = 0; iY = 1; break;
	}
	if(!pLevel->CheckIfCorrectPos(iFieldPos[X]+iX, iFieldPos[Y]+iY))
		return NULL; // There couldn't be something!

	GET_FIELD_POINTER(iFieldPos[X]+iX, iFieldPos[Y]+iY, pNextFieldT);

	return pNextFieldT->pActor;
} // end ACTOR::GetNextFieldActor()

// Remove the actor from all level fields:
void ACTOR::RemoveFromFields(void)
{ // begin ACTOR::RemoveFromFields()
	if(bBridge)
	{
		for(int i = 0; i < pLevel->Header.iFields; i++)
			if(pLevel->pField[i].pBridgeActor == this)
				pLevel->pField[i].pBridgeActor = NULL;
	}
	else
	{
		for(int i = 0; i < pLevel->Header.iFields; i++)
			if(pLevel->pField[i].pActor == this)
				pLevel->pField[i].pActor = NULL;
	}
} // end ACTOR::RemoveFromFields()

// Checks if the next field in the given direction is active:
BOOL ACTOR::GetNextFieldActive(char byDirectionT)
{ // begin ACTOR::GetNextFieldActive()
	FIELD *pNextFieldT;
	int iX, iY;

	if(byDirectionT == -1)
		byDirectionT = byDirection;

	// Setup x/y direction:
	switch(byDirectionT)
	{
		case LEFT: iX = -1; iY = 0; break;
		case UP: iX = 0; iY = -1; break;
		case RIGHT: iX = 1; iY = 0; break;
		case DOWN: iX = 0; iY = 1; break;
	}
	if(!pLevel->CheckIfCorrectPos(iFieldPos[X]+iX, iFieldPos[Y]+iY))
		return FALSE; // There couldn't be something!

	GET_FIELD_POINTER(iFieldPos[X]+iX, iFieldPos[Y]+iY, pNextFieldT);

	if(pNextFieldT->bActive || pNextFieldT->pBridgeActor)
		return TRUE;
	else
		return FALSE;
} // end ACTOR::GetNextFieldActive()

// Checks if in the given direction is an wall:
BOOL ACTOR::CheckIfWall(char byDirectionT, int iDistance)
{ // begin ACTOR::CheckIfWall()
	FIELD *pFieldT;
	int iX, iY, iSide;

	if(byDirectionT == -1)
		byDirectionT = byDirection;

	// Check first, if we there is an wall side on the current field:
	switch(byDirectionT)
	{
		case LEFT: iX = -iDistance; iY = 0; iSide = FACE_RIGHT; break;
		case UP: iX = 0; iY = -iDistance; iSide = FACE_BOTTOM; break;
		case RIGHT: iX = iDistance; iY = 0; iSide = FACE_LEFT; break;
		case DOWN: iX = 0; iY = iDistance; iSide = FACE_TOP; break;
	}
	if(!pLevel->CheckIfCorrectPos(iFieldPos[X]+iX, iFieldPos[Y]+iY))
		return FALSE; // It's absolutely not possible to move!!
	GET_FIELD_POINTER(iFieldPos[X]+iX, iFieldPos[Y]+iY, pFieldT);
	if(pFieldT->Side[iSide].bWallSide)
		return TRUE;

	// Is there a color scanner?
	if(pFieldT->Side[iSide].bFaceActive &&
	   pFieldT->Side[iSide].Surface[0].pSurface->Header.bColorScanner)
	{ // YEP, check if the actor has the right color:
		switch(pFieldT->Side[iSide].Surface[0].pSurface->Header.byColorScannerType)
		{
			case 0: // Normal
				if(fColor[R] < 0.95f || fColor[G] < 0.95f || fColor[B] < 0.95f)
					return TRUE; // The actor haven't the right color!
			break;

			case 1: // Red
				if(fColor[R] < 0.95f || fColor[G] > 0.05f || fColor[B] > 0.05f)
					return TRUE; // The actor haven't the right color!
			break;

			case 2: // Green
				if(fColor[R] > 0.05f || fColor[G] < 0.95f || fColor[B] > 0.05f)
					return TRUE; // The actor haven't the right color!
			break;

			case 3: // Blue
				if(fColor[R] > 0.05f || fColor[G] > 0.05f || fColor[B] < 0.95f)
					return TRUE; // The actor haven't the right color!
			break;
		}
	}

	// Now check if theres an 'real' wall on the next field:
	if(byDirectionT == -1)
		byDirectionT = byDirection;

	if(!pLevel->CheckIfCorrectPos(iFieldPos[X]+iX, iFieldPos[Y]+iY))
		return TRUE; // It's absolutely not possible to move!!
	GET_FIELD_POINTER(iFieldPos[X]+iX, iFieldPos[Y]+iY, pFieldT);
	if((pFieldT->bWall && !pFieldT->bWallHole) || pFieldT->bAlwaysWall ||
	   (pFieldT->pBridgeActor && (pFieldT->pBridgeActor->bBridgeMovement ||
	    pFieldT->pBridgeActor->fWorldPos[Z]-fWorldPos[Z]-1.0f < -0.8f)))
		return TRUE;
	
	return FALSE;
} // end ACTOR::CheckIfWall()

// Checks if it's possible for the actor to move: 
// (if 'byDirectionT' is -1 then the actors current direction is used)
BOOL ACTOR::DoWalking(char byDirectionT, BOOL bOnlyCheck)
{ // begin ACTOR::DoWalking()
	FIELD *pFieldT, *pNextFieldT;
	int iX, iY, iFace;

	if(byDirectionT == -1)
		byDirectionT = byDirection;

	// Setup x/y direction:
	switch(byDirectionT)
	{
		case LEFT: iX = -1; iY = 0; iFace = FACE_LEFT; break;
		case UP: iX = 0; iY = -1; iFace = FACE_TOP; break;
		case RIGHT: iX = 1; iY = 0; iFace = FACE_RIGHT; break;
		case DOWN: iX = 0; iY = 1; iFace = FACE_BOTTOM; break;
	}

	if(this == pPlayer)
	{ // Check the text scripts:
		GET_FIELD_POINTER(iFieldPos[X], iFieldPos[Y], pFieldT);
		if(!pFieldT->bTextScriptActionKey[iFace] && pFieldT->bTextScript[iFace])
		{
			pLevel->TextScriptManager.PlayTextScript(pFieldT->pTextScript[iFace], 0);
			if(!pFieldT->bTextScriptAlways[iFace])
				pFieldT->bTextScript[iFace] = FALSE;
		}
	}

	if(!pLevel->CheckIfCorrectPos(iFieldPos[X]+iX, iFieldPos[Y]+iY))
		return FALSE; // It's absolutely not possible to move!!

	if(bGhostMode)
	{ // Yep, move:
		if(bOnlyCheck)
			return TRUE;

		SetAction(AA_WALKING);
		bMove = TRUE;

		return TRUE;
	}	
	
	GET_FIELD_POINTER(iFieldPos[X]+iX, iFieldPos[Y]+iY, pNextFieldT);
	if(CheckIfWall(byDirectionT, 1) || pNextFieldT->pActor)
		return FALSE; // Theres an obstacle on the next field!!

	if(!bOnlyCheck)
	{
		SetAction(AA_WALKING);
		bMove = TRUE;
		DecreaseItemNumber(AT_STEP_ITEM);

		// Give the next field that actor:
		pNextFieldT->pActor = this;
	}


	return TRUE; // Yes, lets walk!
} // end ACTOR::DoWalking()

// Let the actor kick:
BOOL ACTOR::DoKicking(void)
{ // begin ACTOR::DoKicking()
	FIELD *pNextFieldT;
	ACTOR *pActorT;
	int iX, iY;

	if(!bKickingPossible || bGhostMode)
		return FALSE;
	
	// Setup x/y direction:
	switch(byDirection)
	{
		case LEFT: iX = -1; iY = 0; break;
		case UP: iX = 0; iY = -1; break;
		case RIGHT: iX = 1; iY = 0; break;
		case DOWN: iX = 0; iY = 1; break;
	}

	GET_FIELD_POINTER(iFieldPos[X]+iX, iFieldPos[Y]+iY, pNextFieldT);
	if(pNextFieldT->pActor)
	{
		pActorT = pNextFieldT->pActor;
		if(pActorT && CheckHeightDifference(pActorT))
			return TRUE; // The height difference is to high!
	}
	else
		pActorT = pNextFieldT->pBridgeActor;
	if(pActorT)
	{ // Damage the actor:
		pActorT->MakeDamage(0.5f);
		return TRUE;
	}
	else
	{
		if(pNextFieldT->bWall)
			return TRUE;
	}

	return FALSE;
} // end ACTOR::DoKicking()

// Check if its possible for the actor to jump:
// (if 'byDirectionT' is -1 then the actors current direction is used)
BOOL ACTOR::DoJump(char byDirectionT)
{ // begin ACTOR::DoJump()
	FIELD *pNextFieldT;
	int iX, iY;

	if(byDirectionT == -1)
		byDirectionT = byDirection;

	// Setup x/y direction:
	switch(byDirectionT)
	{
		case LEFT: iX = -1; iY = 0; break;
		case UP: iX = 0; iY = -1; break;
		case RIGHT: iX = 1; iY = 0; break;
		case DOWN: iX = 0; iY = 1; break;
	}

	if(!pLevel->CheckIfCorrectPos(iFieldPos[X]+iX, iFieldPos[Y]+iY))
		return FALSE; // It's absolutely not possible to move!!
	GET_FIELD_POINTER(iFieldPos[X]+iX, iFieldPos[Y]+iY, pNextFieldT);

	// Check if we could jump:
	if(!bGhostMode && 
	   (CheckIfWall(byDirectionT, 1) || pNextFieldT->pActor ||
	   (pNextFieldT->pBridgeActor && pNextFieldT->pBridgeActor->bBridgeMovement)))
		return FALSE; // It's not possible to jump!
	
	if(CheckIfWall(byDirectionT, 2))
		SetAction(AA_WALL_JUMPING);
	else
		SetAction(AA_JUMPING);
	bMove = TRUE;
	DecreaseItemNumber(AT_JUMP_ITEM);
	bIsJumping = TRUE;
	bIsJumpingEnd = FALSE;
	pNextFieldT->pActor = this;

	return TRUE;
} // end ACTOR::DoJump()

BOOL ACTOR::PlayActorTextScript(char byDirectionT)
{ // begin ACTOR::PlayActorTextScript()
	FIELD *pNextFieldT;
	ACTOR *pActorT;
	int iX, iY;

	if(byDirectionT == -1)
		byDirectionT = byDirection;

	// Setup x/y direction:
	switch(byDirectionT)
	{
		case LEFT: iX = -1; iY = 0; break;
		case UP: iX = 0; iY = -1; break;
		case RIGHT: iX = 1; iY = 0; break;
		case DOWN: iX = 0; iY = 1; break;
	}

	if(!pLevel->CheckIfCorrectPos(iFieldPos[X]+iX, iFieldPos[Y]+iY))
		return FALSE; // It's absolutely not possible to move!!
	GET_FIELD_POINTER(iFieldPos[X]+iX, iFieldPos[Y]+iY, pNextFieldT);
	pActorT = pNextFieldT->pActor;
	if(pActorT && pActorT != this)
	{
		pActorT->ShowInfoText();
		if(pActorT->bTextScript && pActorT->pTextScript)
		{ // Play the text script:
			pLevel->TextScriptManager.PlayTextScript(pActorT->pTextScript, 0);
			pLevel->TextScriptManager.pTalkToActor = pActorT;
			if(!pActorT->bTextScriptAlways)
				pActorT->bTextScript = FALSE;
		}
		else
			return FALSE;
	}

	return TRUE;
} // end ACTOR::PlayActorTextScript()

// Check if the actor changes his direction, if yes then turn its direction smooth:
BOOL ACTOR::CheckTurning(float fSpeed)
{ // begin ACTOR::CheckTurning()
	if(byDirection == LEFT && fRot[Y] != 0.0f)
	{ // Turn to left:
		if(fRot[Y] > 180.0f)
		{
			fRot[Y] += fSpeed;
			if(fRot[Y] > 360.0f)
				fRot[Y] = 0.0f;
		}
		else
		if(fRot[Y] > 0.0f)
		{
			fRot[Y] -= fSpeed;
			if(fRot[Y] < 0.0f)
				fRot[Y] = 0.0f;
		}
		SetAction(AA_WALKING);
		return TRUE;
	}
	else
	if(byDirection == UP && fRot[Y] != 90.0f)
	{ // Turn to up:
		if(fRot[Y] > 90.0f)
		{
			fRot[Y] -= fSpeed;
			if(fRot[Y] < 90.0f)
				fRot[Y] = 90.0f;
		}
		else
		{
			fRot[Y] += fSpeed;
			if(fRot[Y] > 90.0f)
				fRot[Y] = 90.0f;
		}
		SetAction(AA_WALKING);
		return TRUE;
	}
	else
	if(byDirection == RIGHT && fRot[Y] != 180.0f)
	{ // Turn to right:
		if(fRot[Y] < 180.0f)
		{
			fRot[Y] += fSpeed;
			if(fRot[Y] > 180.0f)
				fRot[Y] = 180.0f;
		}
		else
		if(fRot[Y] > 0.0f)
		{
			fRot[Y] -= fSpeed;
			if(fRot[Y] < 0.0f)
				fRot[Y] = 0.0f;
		}
		else
		{
			fRot[Y] += fSpeed;
			if(fRot[Y] > 0.0f)
				fRot[Y] = 0.0f;
		}
		SetAction(AA_WALKING);
		return TRUE;
	}
	else
	if(byDirection == DOWN && fRot[Y] != 270.0f)
	{ // Turn to down:
		if(fRot[Y] < 90.0f)
		{
			fRot[Y] -= fSpeed;
			if(fRot[Y] < -90.0f)
				fRot[Y] = 270.0f;
		}
		else
		if(fRot[Y] > 270.0f)
		{
			fRot[Y] -= fSpeed;
			if(fRot[Y] < 270.0f)
				fRot[Y] = 270.0f;
		}
		else
		{
			fRot[Y] += fSpeed;
			if(fRot[Y] > 270.0f)
				fRot[Y] = 270.0f;
		}
		SetAction(AA_WALKING);
		return TRUE;
	}
	
	return FALSE;
} // end ACTOR::CheckTurning()

// Move the actor to the next field:
void ACTOR::Move(char byDirectionT)
{ // begin ACTOR::Move()
	if(!bMove) // Should we move?
		return; // NOPE!

	if(Action == AA_SHOOTING || Action == AA_KICKING ||
	   Action == AA_CHECKPOINT || bBeaming)
		return; // The actor still do something!!

	int iX, iY, iLastFieldID, iSurface;
	FIELD *pCurrentFieldT, *pLastFieldT, *pNextFieldT;
	FIELD_SIDE *pCurrentFieldSideT, *pLastFieldSideT;
	FIELD_SIDE_SURFACE *pFieldSurface;
	SURFACE *pSurfaceT;

	if(byDirectionT == -1)
		byDirectionT = byDirection;
	if(MoveMode == ACTOR_MOVE_BACKWARD)
		byDirectionT = (byDirectionT+2) % 4;

	// Get the movement velocity:
	if(pVelocityFromActor)
	{ // The actor gets his velocity from an other actor: (e.g. if its moved)
		fVelocity[X] = pVelocityFromActor->fVelocity[X];
		fFriction = pVelocityFromActor->fFriction;
	}

	if(bUseFriction)
		fMoveVelocity = fVelocity[X]/fFriction;
	else
		fMoveVelocity = fVelocity[X];
	fMoveVelocity = ((float) g_lDeltatime/350)*fMoveVelocity;

	if(Item[AT_STRENGTH_ITEM].iNumber > 1)
	{ // This action costs a little of the strength:
		fStrength -= 0.0001f;
		if(fStrength <= 0.0f)
		{
			fStrength = 1.0f;
			DecreaseItemNumber(AT_STRENGTH_ITEM);
		}
	}

	// Move now the actor:
	switch(byDirectionT)
	{
		case RIGHT:
			fFieldPos[X] += fMoveVelocity;
			fFieldPos[Y] = 0.0f;
			if(fFieldPos[X] >= 1.0f)
			{
				fFieldPos[X] -= 1.0f;
				iFieldPos[X]++;
				break;
			}
			return;

		case DOWN:
			fFieldPos[Y] += fMoveVelocity;
			fFieldPos[X] = 0.0f;
			if(fFieldPos[Y] >= 1.0f)
			{
				fFieldPos[Y] -= 1.0f;
				iFieldPos[Y]++;
				break;
			}
			return;

		case LEFT:
			fFieldPos[X] -= fMoveVelocity;
			fFieldPos[Y] = 0.0f;
			if(fFieldPos[X] <= -1.0f)
			{
				fFieldPos[X] += 1.0f;
				iFieldPos[X]--;
				break;
			}
			return;

		case UP:
			fFieldPos[Y] -= fMoveVelocity;
			fFieldPos[X] = 0.0f;
			if(fFieldPos[Y] <= -1.0f)
			{
				fFieldPos[Y] += 1.0f;
				iFieldPos[Y]--;
				break;
			}
			return;
	}

	// Ok, we are now on the next field:
	pVelocityFromActor = NULL;
	// Remove the actor from the last field:
	if(pLevel->pField[iFieldID].pActor == this)
		pLevel->pField[iFieldID].pActor = NULL;
	iLastFieldID = iFieldID;
	GET_FIELD_ID(iFieldPos[X], iFieldPos[Y], iFieldID)

	if(!bGhostMode)
	{ // Check if field surfaces should be changed:
		pCurrentFieldT = &pLevel->pField[iFieldID];
		pCurrentFieldSideT = &pCurrentFieldT->Side[FACE_FLOOR];
		pLastFieldT = &pLevel->pField[iLastFieldID];
		pLastFieldSideT = &pLastFieldT->Side[FACE_FLOOR];

		for(iSurface = 0; iSurface < 2; iSurface++)
		{
			// Current field:
			if(!bIsJumping || bIsJumpingEnd)
			{
				pFieldSurface = &pCurrentFieldSideT->Surface[iSurface]; 
				if((pSurfaceT = pFieldSurface->pSurface) &&
				   pSurfaceT->Header.bChangeOnEnter)
				{ // Yes, we have to change the surface:
					pFieldSurface->dwLastChangeTime = g_lGameTimer;
					pFieldSurface->iSurface = pSurfaceT->Header.iChangeOnEnterSurface;
					pFieldSurface->pSurface = &pLevel->pSurface[pFieldSurface->iSurface];
				}
			}
			
			// Last field:
			if(!bIsJumping || !bIsJumpingEnd)
			{
				pFieldSurface = &pLastFieldSideT->Surface[iSurface]; 
				if((pSurfaceT = pFieldSurface->pSurface) &&
				   pSurfaceT->Header.bChangeOnLeave)
				{ // Yes, we have to change the surface:
					pFieldSurface->dwLastChangeTime = g_lGameTimer;
					pFieldSurface->iSurface = pSurfaceT->Header.iChangeOnLeaveSurface;
					pFieldSurface->pSurface = &pLevel->pSurface[pFieldSurface->iSurface];
				}
			}
		}
	}

	if(bIsJumping)
	{ // Jump to the last field:
		if(!bIsJumpingEnd)
		{ // Check if the next fiel is free:
			if(DoWalking(-1, TRUE))
			{ // YEP!
				bIsJumpingEnd = TRUE;

				// Setup x/y direction:
				switch(byDirectionT)
				{
					case LEFT: iX = -1; iY = 0; break;
					case UP: iX = 0; iY = -1; break;
					case RIGHT: iX = 1; iY = 0; break;
					case DOWN: iX = 0; iY = 1; break;
				}

				GET_FIELD_POINTER(iFieldPos[X]+iX, iFieldPos[Y]+iY, pNextFieldT);
				pNextFieldT->pActor = this;
			}
			else
			{ // NOPE! The actor jumps against a wall:
				bIsJumping = FALSE;
				bMove = FALSE;
				if(Action != AA_WALL_JUMPING)
					SetAction(AA_ANGRY);
			}
		}
		else
		{
			bIsJumping = bIsJumpingEnd = bMove = FALSE;
			SetAction(AA_NOTHING);
		}
	}
	else
		bMove = FALSE;

	if(Type == AT_BLIBS && pPlayer == this)
	{
		pLevel->Missions.CheckSteps(); // Decrease the left steps
	}

	
//	pFieldT = &pLevel->pField[iFieldID];


/*	pFieldT = &pLevel->pField[iFieldID];
	
	if(Type == AT_BLIBS)
	{
		pLevel->Missions.CheckSteps(); // Decrease the left steps
		if(!bGhost)
		{ // Check if the surface of one field should be changed:
			if(Action != AA_DEATH && Action != AA_JUMPING)
			{
				// Check if an camera should be played:
				if(pFieldT->iCamera != -1 && pLevel->Header.iCameraScripts)
				{ // Yes:
					pLevel->pCurrentCameraScript = &pLevel->pCameraScript[pFieldT->iCamera];
					if(pLevel->pCurrentCameraScript->iSteps)
					{
						bCameraAnimation = TRUE;
						memset(&TempCamera, 0, sizeof(AS_CAMERA));
						lCameraTimer = g_lGameTimer;
						pLevel->Camera.iCurrentCameraStep = 0;
						if(pLevel->pCurrentCameraScript->iTextScript != -1)
							PlayTextScript(pLevel->pCurrentCameraScript->iTextScript);
						if(!pFieldT->bCameraAlways)
							pFieldT->iCamera = -1;
					}
				}
				// Check if an text script should be played:
				if(pFieldT->iTextScript != -1 && !bGhost)
				{ // Yes:
					PlayTextScript(pFieldT->iTextScript);
					if(!pFieldT->bTextScriptAlways)
						pFieldT->iTextScript = -1;
				}
			}

			// Check the last field:
			for(i = 0; i < 2; i++)
			{
				if(pLevel->pField[iBackupField].Side[FACE_FLOOR].Surface[i].iSurface == -1)
					break;
				pSurfaceT = &pLevel->pSurface[pLevel->pField[iBackupField].Side[FACE_FLOOR].Surface[i].iSurface];
				if(pSurfaceT->Header.bChange && pSurfaceT->Header.byChangeState && iTempFieldID != iBackupField &&
				   pSurfaceT->Header.byChangeState != 2)
				{ // Yes, we have to change the surface:
					if(pSurfaceT->Header.bChangeDestroy)
					{ // Destroy the field:
						pLevel->pField[iBackupField].bActive = FALSE;
						pLevel->pField[iBackupField].Side[FACE_FLOOR].Surface[i].iSurface = pSurfaceT->Header.iChangeSurface;
						pLevel->pField[iBackupField].Side[FACE_FLOOR].Surface[i].pSurface = &pLevel->pSurface[pSurfaceT->Header.iChangeSurface];
					}
					else
					{
						pLevel->pField[iBackupField].Side[FACE_FLOOR].Surface[i].iSurface = pSurfaceT->Header.iChangeSurface;
						pLevel->pField[iBackupField].Side[FACE_FLOOR].Surface[i].pSurface = &pLevel->pSurface[pSurfaceT->Header.iChangeSurface];
					}
					pLevel->pField[iBackupField].Side[FACE_FLOOR].Surface[i].dwLastChangeTime = g_lGameTimer;
				}
				// Check the new field:
				pSurfaceT = &pLevel->pSurface[pLevel->pField[iFieldID].Side[FACE_FLOOR].Surface[i].iSurface];
				if(pSurfaceT->Header.bChange && !pSurfaceT->Header.byChangeState && iTempFieldID != iFieldID &&
				   pSurfaceT->Header.byChangeState != 2)
				{ // Yes, we have to change the surface:
					if(pSurfaceT->Header.bChangeDestroy)
					{ // Destroy the field:
						pLevel->pField[iFieldID].bActive = FALSE;
						pLevel->pField[iFieldID].Side[FACE_FLOOR].Surface[i].iSurface = pSurfaceT->Header.iChangeSurface;
						pLevel->pField[iFieldID].Side[FACE_FLOOR].Surface[i].pSurface = &pLevel->pSurface[pSurfaceT->Header.iChangeSurface];
					}
					else
					{
						pLevel->pField[iFieldID].Side[FACE_FLOOR].Surface[i].iSurface = pSurfaceT->Header.iChangeSurface;
						pLevel->pField[iFieldID].Side[FACE_FLOOR].Surface[i].pSurface = &pLevel->pSurface[pSurfaceT->Header.iChangeSurface];
					}
					pLevel->pField[iFieldID].Side[FACE_FLOOR].Surface[i].dwLastChangeTime = g_lGameTimer;
				}
			}
		}
	}
	*/
} // end ACTOR::Move()

// Check the surface were the actor is on:
void ACTOR::CheckSurface(void)
{ // begin ACTOR::CheckSurface()
	SURFACE *pSurfaceT;
	FIELD *pFieldT;
	float fHeight;
	int i;

	if(!ASCheckTimeUpdate(&lSurfaceCheckTimer, 100) || Action == AA_JUMPING)
		return; // No checking now, please!
	lSurfaceCheckTimer = g_lGameTimer;

	// Get the right surface:
	if(!bMove)
		pFieldT = &pLevel->pField[iFieldID];
	else
		pFieldT = pLevel->ComputeHeight(fWorldPos[X], fWorldPos[Y], &fHeight, FACE_FLOOR, FALSE);
	if(!pFieldT)
		return;
	if(pFieldT->pBridgeActor)
		return; // There's an bridge! Therefore the floor surface is not relevant!
	if(!(pSurfaceT = pFieldT->Side[FACE_FLOOR].Surface[0].pSurface))
		return; // There is no surface!

	if(pSurfaceT->Header.bColorPainter)
	{
		switch(pSurfaceT->Header.byColorPainterType)
		{
			case 0: // Normal color painter
				for(i = 0; i < 3; i++)
				{
					fColor[i] += (float) g_lDeltatime/1000;
					if(fColor[i] > 0.9f)
						fColor[i] = 0.9f;
				}
			break;

			case 1: // Red color painter
				fColor[R] += (float) g_lDeltatime/1000;
				if(fColor[R] > 1.0f)
					fColor[R] = 1.0f;
				fColor[G] -= (float) g_lDeltatime/1000;
				if(fColor[G] < 0.0f)
					fColor[G] = 0.0f;
				fColor[B] -= (float) g_lDeltatime/1000;
				if(fColor[B] < 0.0f)
					fColor[B] = 0.0f;
			break;

			case 2: // Green color painter
				fColor[R] -= (float) g_lDeltatime/1000;
				if(fColor[R] < 0.0f)
					fColor[R] = 0.0f;
				fColor[G] += (float) g_lDeltatime/1000;
				if(fColor[G] > 1.0f)
					fColor[G] = 1.0f;
				fColor[B] -= (float) g_lDeltatime/1000;
				if(fColor[B] < 0.0f)
					fColor[B] = 0.0f;
			break;

			case 3: // Blue color painter
				fColor[R] -= (float) g_lDeltatime/1000;
				if(fColor[R] < 0.0f)
					fColor[R] = 0.0f;
				fColor[G] -= (float) g_lDeltatime/1000;
				if(fColor[G] < 0.0f)
					fColor[G] = 0.0f;
				fColor[B] += (float) g_lDeltatime/1000;
				if(fColor[B] > 1.0f)
					fColor[B] = 1.0f;
			break;
		}
	}

	if(pSurfaceT->Header.bRadioactive && !bShieldMode && !bGhostMode)
	{ // The actor is on a radioactive field:	
		switch(Type)
		{
			case AT_BOX_NORMAL: fHealth -= ((float) (rand() % 1000)/500.0f)*pSurfaceT->Header.fRadioactiveSpeed; fShowInfoTextBlend = TRUE; break;
			case AT_BOX_RED: fHealth -= ((float) (rand() % 1000)/100.0f)*pSurfaceT->Header.fRadioactiveSpeed; fShowInfoTextBlend = TRUE; break;
			case AT_BOX_GREEN: fHealth -= ((float) (rand() % 1000)/1000.0f)*pSurfaceT->Header.fRadioactiveSpeed; fShowInfoTextBlend = TRUE; break;
			case AT_BOX_BLUE: fHealth -= ((float) (rand() % 1000)/400.0f)*pSurfaceT->Header.fRadioactiveSpeed; fShowInfoTextBlend = TRUE; break;
			
			case AT_BLIBS:
			case AT_MOBMOB:
			case AT_X3:
				fHealth -= ((float) (rand() % 1000)/1000.0f)*pSurfaceT->Header.fRadioactiveSpeed;
				SetupCameraRotation(AA_PAIN, pCamera);
				SetAction(AA_PAIN);
				fShowInfoTextBlend = TRUE;
			break;
		}	
		return;
	}
	else
	if((pSurfaceT->Header.bHealth ||
		pSurfaceT->Header.bAlcove))
	{ // The actor is on a health field:	
		switch(Type)
		{
			case AT_BOX_NORMAL:
			case AT_BOX_RED:
			case AT_BOX_GREEN:
			case AT_BOX_BLUE:
			return;
		}

		if(pSurfaceT->Header.bAlcove)
		{ // Checkpoint:
			if(fFieldPos[X] == 0.0f && fFieldPos[Y] == 0.0f &&
			   iCheckpointFieldID != iFieldID && !bMove)
			{ // We are on a new checkpoint:
				SetupCameraRotation(AA_CHECKPOINT, pCamera);
				iCheckpointFieldID = iFieldID;
				if(_AS->GetModule() != MODULE_EDITOR && this == pPlayer)
				{
					ParticleManager.pSystem[PS_PLAYER_AUTOSAVE].bActive = TRUE;
					ParticleManager.pSystem[PS_PLAYER_AUTOSAVE].bUpdate = TRUE;
				}
				SetAction(AA_CHECKPOINT);
				return;
			}
		}
		if(fHealth < fMaxHealth && Action != AA_CHECKPOINT)
		{ // Heal the actor:
			SetupCameraRotation(AA_WALKING, pCamera);
			if(pSurfaceT->Header.bHealth)
				fHealth += ((float) (rand() % 1000)/500.0f)*pSurfaceT->Header.fHealthSpeed;
			else
			{
				if(Type != AT_BLIBS)
					return; // Only Blibs is healed on the alcove!
				fHealth += ((float) (rand() % 1000)/5000.0f)*pSurfaceT->Header.fAlcoveSpeed;
			}
			SetAction(AA_HEALTH);

			return;
		}
	}
} // end ACTOR::CheckSurface()

// Calculate the world position of the actor:
void ACTOR::GetWorldPos(void)
{ // begin ACTOR::GetWorldPos()
	FIELD *pFieldT;
	float fHeight;
	
	if(bBridge)
	{
		if(bBridge)
		{
			fWorldPos[X] = iFieldPos[X]+fFieldPos[X]+0.5f;
			fWorldPos[Y] = iFieldPos[Y]+fFieldPos[Y]+0.5f;
		}
		return; // The actor beams at the moment!
	}

	if(!bFallIntoHole)
	{ // Calculate the players position:
		fWorldPos[X] = iFieldPos[X]+fFieldPos[X]+0.5f;
		fWorldPos[Y] = iFieldPos[Y]+fFieldPos[Y]+0.5f;
		ComputeHeight();
	}
	else
	{ // The actor falls into an hole:
		fWorldPos[X] = iFieldPos[X]+fFieldPos[X]+0.5f;
		fWorldPos[Y] = iFieldPos[Y]+fFieldPos[Y]+0.5f;
		fWorldPos[Z] += g_lDeltatime*fVelocity[Z];
		pFieldT = pLevel->ComputeHeight(fWorldPos[X], fWorldPos[Y], &fHeight, FACE_FRONT, FALSE);
		if(pFieldT)
		{
			if(pFieldT->pBridgeActor)
				fVelocity[Z] = 0.0f;
			else
			if(pFieldT->bWallHole && fWorldPos[Z] > fHeight)
			{ // Now the actor lies at the ground of the hole!
				SetAction(AA_DEATH);
				fWorldPos[Z] = fHeight;
				fVelocity[Z] = 0.0f;
			}
		}
	}
	GET_FIELD_ID(iFieldPos[X], iFieldPos[Y], iFieldID)
} // end ACTOR::GetWorldPos()

void ACTOR::ComputeHeight(void)
{ // begin ACTOR::ComputeHeight()
	AS_VECTOR3D vEllipsoid;
	FIELD *pFieldT = NULL;
	int iNoField = 0;
	float fHeight;
	
	if(bDocked ||
	   fWorldPos[X] == fLastHeightCheckWorldPos[X] &&
	   fWorldPos[Y] == fLastHeightCheckWorldPos[Y] &&
	   fWorldPos[Z] == fLastHeightCheckWorldPos[Z] &&
	   !bMove)
	{
		if(!pLevel->pField[iFieldID].pBridgeActor)
			return;
		else
			pLevel->pField[iFieldID].pBridgeActor = pLevel->pField[iFieldID].pBridgeActor;
	}

	vEllipsoid = vCollisionEllipsoid*fSize; // Setup collision ellipsoid
	pFieldT = pLevel->ComputeHeight(fWorldPos[X]+0.001f, fWorldPos[Y]+0.001f, &fHeight, FACE_FLOOR, vEllipsoid);
	if(pFieldT && pFieldT->Side[FACE_FLOOR].Surface[0].pSurface && pFieldT->Side[FACE_FLOOR].Surface[0].pSurface->Header.bHole &&
	   !pFieldT->pBridgeActor)
		pFieldT = NULL; // Thats an hole!
	if(!pFieldT && !bWingMode && Action != AA_JUMPING &&
	   Action != AA_WALL_JUMPING && !bInvulnerable)
	{ // The actor falls in a hole:
		switch(Type)
		{
			case AT_BLIBS:
				SetAction(AA_ANGRY);
				bFallIntoHole = TRUE;
			break;

			case AT_MOBMOB:
			case AT_X3:
				if(bBeaming)
					SetAction(AA_WRONG);
				else
				if(Action != AA_WRONG)
				{
					RemoveFromFields();
					fHealth = 0.0f;
					fVelocity[Z] = 0.003f;
				}
			return;
		}
	}

	if(pFieldT)
	{ // Update the last check pos: (we only have to check if the position has changed)
		if(Action != AA_JUMPING && Action != AA_WALL_JUMPING)
		{
			fWorldPos[Z] = fFloorHeight = fHeight+vEllipsoid.fZ;
		}
		else
		{
			if(fWorldPos[Z] > fHeight+vEllipsoid.fZ)
				fWorldPos[Z] = fFloorHeight = fHeight+vEllipsoid.fZ;
			else
				fFloorHeight = fHeight+vEllipsoid.fZ;
		}
		
		fLastHeightCheckWorldPos[X] = fWorldPos[X];
		fLastHeightCheckWorldPos[Y] = fWorldPos[Y];
		fLastHeightCheckWorldPos[Z] = fWorldPos[Z];
	}

	if(pFieldT && !pFieldT->pBridgeActor && pFieldT->Side[FACE_FLOOR].Surface[0].pSurface)
		fFriction = pFieldT->Side[FACE_FLOOR].Surface[0].pSurface->Header.fFriction;
	else
		fFriction = 1.0f;
} // end ACTOR::ComputeHeight()

// Check, if the actor should be beamed:
BOOL ACTOR::CheckForBeaming(void)
{ // begin ACTOR::CheckForBeaming()
	SURFACE *pSurfaceT;
	FIELD *pFieldT;

	if(fFieldPos[X] != 0.0f || fFieldPos[Y] != 0.0f)
		return FALSE; // The actor isn't complete on the field!

	if(bBeaming)
		return FALSE; // The actor already beams at the moment!
	if(bGhostMode)
		return FALSE; // Beaming is not possible if the actor is in the ghost mode!!
	
	// Check if there is an useable beamer on the field were the actor is on:
	pFieldT = &pLevel->pField[iFieldID];
	if(pFieldT->Side[FACE_FLOOR].Surface[0].iSurface == -1)
		return FALSE; // There is no surface!!
	pSurfaceT = &pLevel->pSurface[pFieldT->Side[FACE_FLOOR].Surface[0].iSurface];
	if(!pSurfaceT->Header.bBeamer || pFieldT->iBeamerTarget == -1 ||
	   pFieldT->fBeamerPower != 1.0f)
		return FALSE; // No beamer usage possible!
	
	// Check, if the other side were the actor would came out is free:
	if(pLevel->pField[pFieldT->iBeamerTarget].pActor ||
	   (pLevel->pField[pFieldT->iBeamerTarget].bWall && !pLevel->pField[pFieldT->iBeamerTarget].bWallHole))
	   return FALSE; // NO!!
	
	pFieldT->fBeamerPower = 0.0f;
	
	pLevel->pField[pFieldT->iBeamerTarget].pActor = this;
	if(pLevel->pField[pFieldT->iBeamerTarget].Side[FACE_FLOOR].Surface[0].pSurface &&
	   pLevel->pField[pFieldT->iBeamerTarget].Side[FACE_FLOOR].Surface[0].pSurface->Header.bBeamer)
		pLevel->pField[pFieldT->iBeamerTarget].fBeamerPower = 0.0f;
	bBeaming = TRUE;
	bBeamingStep = 0;
	fBeamingBlend = 1.0;
	bSquashable = FALSE;
	ASPlayFmodSample(pBeamerSample, FSOUND_LOOP_OFF);

	return TRUE;
} // end ACTOR::CheckForBeaming()

// Check the beaming process:
BOOL ACTOR::CheckBeamingProcess(void)
{ // begin ACTOR::CheckBeamingProcess()
	FIELD *pFieldT, *pNextFieldT;
	SURFACE *pSurfaceT;
	int iX, iY;

	if(!bBeaming)
		return FALSE; // The actor isn't beamed at the moment!

	dwAniTime = g_lGameTimer;
	if(!bBeamingStep)
	{ // Dematerializing:
		fBeamingBlend -= (float) g_lDeltatime/2000;
		if(fBeamingBlend < 0.0f)
		{ // The actor is now complete dematerialized:
			fBeamingBlend = 0.0f;
			bBeamingStep = 1;			
			pFieldT = &pLevel->pField[iFieldID];
			iFieldID = pFieldT->iBeamerTarget;
			iFieldPos[X] = pLevel->pField[pFieldT->iBeamerTarget].iXField;
			iFieldPos[Y] = pLevel->pField[pFieldT->iBeamerTarget].iYField;
			fLastHeightCheckWorldPos[X] = -1;
			GetWorldPos();

			// Set the actor to the beamed position:
			pFieldT->pActor = NULL;

			if(Type == AT_BLIBS)
			{ // The camera should move to the new players position:
				float fTemp = fWorldPos[Z];
				pCamera->fPos2[X] = pCamera->fPos[X]+fWorldPos[X];
				pCamera->fPos2[Y] = pCamera->fPos[Y]+fWorldPos[Y];
				pCamera->fPos2[Z] = fTemp-fWorldPos[Z];
			}
			ASPlayFmodSample(pBeamerSample, FSOUND_LOOP_OFF);
		}
	}
	else
	{ // Materializing:
		fBeamingBlend += (float) g_lDeltatime/2000;
		if(fBeamingBlend > 1.0f)
		{ // The beaming process is now complete:
			fBeamingBlend = 1.0f;
			if(Action == AA_JUMPING || Action == AA_WALL_JUMPING || bIsJumping)
			{
				if(!DoWalking(-1, TRUE))
				{ // The actor jumps againt an obstacle:
					if(!pLevel->pField[iFieldID].bActive)
					{ // The actor falls into a gap:
						fHealth = 0.0f;
						fVelocity[Z] = 0.005f;
					}
					bIsJumping = FALSE;
					bMove = FALSE;
					SetAction(AA_WRONG);
				}

				// Increase the jump if we are on an overloaded beamer:
				pFieldT = &pLevel->pField[iFieldID];
				pSurfaceT = &pLevel->pSurface[pFieldT->Side[FACE_FLOOR].Surface[0].iSurface];
				if((pSurfaceT && !pSurfaceT->Header.bBeamer || pFieldT->iBeamerTarget == -1 ||
				   pFieldT->fBeamerPower != 1.0f) &&
				   (pLevel->pField[pFieldT->iBeamerTarget].pActor ||
				   pLevel->pField[pFieldT->iBeamerTarget].bWall))
				{ // Yeah! Its overloaded:
					DoJump(-1);
				}
				else
				{ // Nope, finish the old jump:
					if(!bIsJumpingEnd)
					{ // Check if the next fiel is free:
						if(DoWalking(-1, TRUE))
						{ // YEP!
							bIsJumpingEnd = TRUE;

							// Setup x/y direction:
							switch(byDirection)
							{
								case LEFT: iX = -1; iY = 0; break;
								case UP: iX = 0; iY = -1; break;
								case RIGHT: iX = 1; iY = 0; break;
								case DOWN: iX = 0; iY = 1; break;
							}

							GET_FIELD_POINTER(iFieldPos[X]+iX, iFieldPos[Y]+iY, pNextFieldT);
							pNextFieldT->pActor = this;
						}
						else
						{ // NOPE! The actor jumps against a wall:
							bIsJumping = FALSE;
							bMove = FALSE;
							SetAction(AA_WRONG);
						}
					}
					else
					{
						bIsJumping = bIsJumpingEnd = bMove = FALSE;
						SetAction(AA_NOTHING);
					}
				}
			}
			else
			{
				SetAction(AA_NOTHING);
				fLastHeightCheckWorldPos[X] = -1;
				ComputeHeight();
				bMove = FALSE;
			}
			bBeaming = FALSE;
			switch(Type)
			{
				case AT_BLIBS:
				case AT_MOBMOB:
				case AT_X3:
					bSquashable = TRUE;
				break;
			}
		}
	}
	
	return TRUE;
} // end ACTOR::CheckBeamingProcess()

// General check function for all actors:
void ACTOR::Check(BOOL bEditor)
{ // void ACTOR::Check()
	int i;
	
	CheckWrongTimer();
	CheckChangeWaterHeight();
	if(fFloorHeight != fWorldPos[Z] && !bGoingDeath)
	{
		if(fFloorHeight > fWorldPos[Z])
		{
			if(Action != AA_JUMPING && Action != AA_WALL_JUMPING)
			{
				fWorldPos[Z] += (float) g_lDeltatime/300;
				if(fFloorHeight < fWorldPos[Z])
					fWorldPos[Z] = fFloorHeight;
			}
		}
	}
	else
		if(Action == AA_FALLING)
			SetAction(AA_NOTHING);
	if(Action != AA_FALLING)
		GetWorldPos(); // Get the actors world position
	
	if(!bFallIntoHole)
		fVelocity[Z] = 0.0f;

	if(bShieldMode)
	{ // Rotate the shield:		
		for(i = 0; i < 8; i++)
		{
			fShieldRot[X][i] += (float) g_lDeltatime/(10.0f*((i+1)*0.5f));
			fShieldRot[Y][i] += (float) g_lDeltatime/(10.0f*((i+1)*0.5f));
			fShieldRot[Z][i] += (float) g_lDeltatime/(10.0f*((i+1)*0.5f));
		}
	}

	// Make the lighting effect:
	if(fShieldLighting > fShieldLightingTo)
	{
		fShieldLighting += (float) g_lDeltatime/100*fShieldLightingVelocity;
		fShieldLightingVelocity -= (float) g_lDeltatime/50;
		if(fShieldLightingVelocity < -1.0f)
			fShieldLightingVelocity = -1.0f;
		if(fShieldLighting <= fShieldLightingTo)
			fShieldLightingTo = (rand() % 400)/100.0f;
		if(!(rand() % 2))
			fShieldLightingTo = -fShieldLightingTo;
	}
	else
	{
		fShieldLighting += (float) g_lDeltatime/100*fShieldLightingVelocity;
		fShieldLightingVelocity += (float) g_lDeltatime/50;
		if(fShieldLightingVelocity > 1.0f)
			fShieldLightingVelocity = 1.0f;
		if(fShieldLighting >= fShieldLightingTo)
			fShieldLightingTo = (rand() % 400)/100.0f;
		if(!(rand() % 2))
			fShieldLightingTo = -fShieldLightingTo;
	}

	// Calculate the actors transparence:
	if(bGoingDeath && fDeathTime > 0.5f)
		fBlendDensity = 1.5f-fDeathTime;
	else
	if(bBeaming)
		fBlendDensity = fBeamingBlend;
	else
	if(bGhostMode)
		fBlendDensity = 0.3f;
	else
		fBlendDensity = 1.0f;
	CheckInfoText();

	if(bCameraAnimation)
		return;
	// Check the actor attributes:
	if(!Item[AT_PULL_ITEM].iNumber && !Item[AT_PULL_ITEM].bUnlimited)
		bPullBoxesPossible = FALSE;
	else
		bPullBoxesPossible = TRUE;
	if((!Item[AT_THROW_ITEM].iNumber && !Item[AT_THROW_ITEM].bUnlimited) ||
	    Item[AT_STRENGTH_ITEM].iNumber <= 1)
		bThrowBoxesPossible = FALSE;
	else
		bThrowBoxesPossible = TRUE;
	if(!Item[AT_JUMP_ITEM].iNumber && !Item[AT_JUMP_ITEM].bUnlimited)
		bJumpingPossible = FALSE;
	else
		bJumpingPossible = TRUE;
	if(!Item[AT_KICK_ITEM].iNumber && !Item[AT_KICK_ITEM].bUnlimited)
		bKickingPossible = FALSE;
	else
		bKickingPossible = TRUE;
	if(Item[AT_STRENGTH_ITEM].bUnlimited)
	{ // The actor has unlimited strength:
		Item[AT_STRENGTH_ITEM].iNumber = pLevel->Header.iWidth+pLevel->Header.iHeight;
		fStrength = 1.0f;
	}
	if(Item[AT_STRENGTH_ITEM].iNumber < 1)
	{
		Item[AT_STRENGTH_ITEM].iNumber = 1;
		fStrength = 1.0f;
	}
	if(!Item[AT_WEAPON_ITEM].iNumber && !Item[AT_WEAPON_ITEM].bUnlimited)
		bWeapon = FALSE;
	else
		bWeapon = TRUE;
	if(!bEditor)
	{
		// Check ghost mode:
		if(bGhostMode && ASCheckTimeUpdate(&lGhostModeTime, 100))
		{ // Its time for an ghost mode left time update:
			if(this == pPlayer)
				ParticleManager.pSystem[PS_PLAYER_GHOST].bActive = TRUE;
			if(!Item[AT_GHOST_ITEM].bUnlimited)
			{
				fGhostModeTime -= 0.1f;
				if(fGhostModeTime <= 0.0f)
				{ // The ghost time is left!
					// Check if the actor is in a wall or an other actor:
					if((pLevel->pField[iFieldID].bWall && !pLevel->pField[iFieldID].bWallHole) ||
					   (pLevel->pField[iFieldID].pActor && pLevel->pField[iFieldID].pActor != this))
					{ // Yea, we are in a object... that hurts!
						if(!bShieldMode)
							fHealth -= (float) g_lDeltatime/10;
					}
					else
					{ // Deactivate this mode:
						bGhostMode = FALSE;
						pLevel->pField[iFieldID].pActor = this;
						if(this == pPlayer)
							ParticleManager.pSystem[PS_PLAYER_GHOST].bGoingInActive = TRUE;
					}
				}
			}
		}
		
		// Check the speed mode:
		if(bSpeedMode && ASCheckTimeUpdate(&lSpeedModeTime, 100))
		{ // Its time for an speed mode left time update:
			if(this == pPlayer)
				ParticleManager.pSystem[PS_PLAYER_SPEED].bActive = TRUE;
			if(!Item[AT_SPEED_ITEM].bUnlimited)
			{
				fSpeedModeTime -= 0.1f;
				if(fSpeedModeTime <= 0.0f)
				{ // The speed mode time is left!
					bSpeedMode = FALSE;
					if(this == pPlayer)
						ParticleManager.pSystem[PS_PLAYER_SPEED].bGoingInActive = TRUE;
				}
			}
		}
		
		// Check the wing mode:
		if(bWingMode && ASCheckTimeUpdate(&lWingModeTime, 100))
		{ // Its time for an wing mode left time update:
			if(!Item[AT_WING_ITEM].bUnlimited)
			{
				fWingModeTime -= 0.1f;
				if(fWingModeTime <= 0.0f)
					bWingMode = FALSE; // The wing time is left!
			}
		}
		
		// Check the shield mode:
		if(bShieldMode && ASCheckTimeUpdate(&lShieldModeTime, 100) && !Item[AT_SHIELD_ITEM].bUnlimited)
		{ // Its time for an shield mode left time update:
			fShieldModeTime -= 0.1f;
			if(fShieldModeTime <= 0.0f)
				bShieldMode = FALSE; // The shield time is left!
		}
	}
	else
	{
		if(Item[AT_GHOST_ITEM].iNumber || Item[AT_GHOST_ITEM].bUnlimited)
		{
			bGhostMode = TRUE;
			fGhostModeTime = (float) Item[AT_GHOST_ITEM].iNumber;
			lGhostModeTime = g_lGameTimer;
			if(this == pPlayer)
				ParticleManager.pSystem[PS_PLAYER_GHOST].bActive = TRUE;
		}
		else
		{
			bGhostMode = FALSE;
			if(this == pPlayer)
				ParticleManager.pSystem[PS_PLAYER_GHOST].bActive = FALSE;
		}
		if(Item[AT_SPEED_ITEM].iNumber || Item[AT_SPEED_ITEM].bUnlimited)
		{
			bSpeedMode = TRUE;
			fSpeedModeTime = (float) Item[AT_SPEED_ITEM].iNumber;
			lSpeedModeTime = g_lGameTimer;
			if(this == pPlayer)
				ParticleManager.pSystem[PS_PLAYER_SPEED].bActive = TRUE;
		}
		else
		{
			bSpeedMode = FALSE;
			if(this == pPlayer)
				ParticleManager.pSystem[PS_PLAYER_SPEED].bActive = FALSE;
		}
		if(Item[AT_WING_ITEM].iNumber || Item[AT_WING_ITEM].bUnlimited)
		{
			bWingMode = TRUE;
			fWingModeTime = (float) Item[AT_WING_ITEM].iNumber;
			lWingModeTime = g_lGameTimer;
		}
		else
			bWingMode = FALSE;
		if(Item[AT_SHIELD_ITEM].iNumber || Item[AT_SHIELD_ITEM].bUnlimited)
		{
			bShieldMode = TRUE;
			fShieldModeTime = (float) Item[AT_SHIELD_ITEM].iNumber;
			lShieldModeTime = g_lGameTimer;
		}
		else
			bShieldMode = FALSE;
	}
	
	if(fHealth < 0.0f)
		fHealth = 0.0f;
	if(bInvulnerable && Type == AT_BLIBS)
	{ // The player couldn't die: (cheat)
		fHealth = 100.0f;
		bGoingDeath = FALSE;
		bFallIntoHole = FALSE;
	}
	else
	{ // Check the actors power:
		if(!bEditor && 
			fHealth < 1.0f && !bBeaming && 
		   (!bGoingDeath || (Action != AA_DEATH && Action != AA_DEATH1)))
		{ // The actor is now death:
			if(!fAir && !bSmotherDone)
			{
				bGoingDeath = TRUE;
				if(Action != AA_SWIMMING)
					SetAction(AA_SWIMMING);
			}
			else
			{
				bSmotherDone = FALSE;
				fHealth = 0.0f;
				if(Type == AT_MOBMOB)
				{
					switch((rand() % 2))
					{
						case 0: SetAction(AA_DEATH); break;
						case 1: SetAction(AA_DEATH1); break;
					}
					MoveMode = ACTOR_MOVE_FORWARD;
				}
				else
				{
					if(Action != AA_HOLE_FALLING)
					{
						MoveMode = ACTOR_MOVE_FORWARD;
						SetAction(AA_DEATH);
					}
				}
				if(!bGoingDeath)
				{
					switch(Type)
					{
						case AT_BLIBS: ASPlayFmodSample(pBlibsDeathSample, FSOUND_LOOP_OFF); break;
						case AT_MOBMOB: ASPlayFmodSample(pMobmobDeathSample, FSOUND_LOOP_OFF); break;
						case AT_X3: ASPlayFmodSample(pMobmobDeathSample, FSOUND_LOOP_OFF); break;
						
						case AT_BOX_NORMAL:
						case AT_BOX_RED:
						case AT_BOX_GREEN:
						case AT_BOX_BLUE:
							ASPlayFmodSample(pBoxDeathSample, FSOUND_LOOP_OFF); break;
						break;
					}
				}
				bGoingDeath = TRUE;
			}
		}
	}
} // begin ACTOR::Check()

// Set the actor tools corresponding to the level tools:
void ACTOR::SetLevelTools(void)
{ // begin ACTOR::SetLevelTools()
/*	 iLives = pLevel->Tools.iLives;
	 iPoints = pLevel->Tools.iPoints;
	 iWeaponShots = pLevel->Tools.iWeapon;
	 iPullBoxes = pLevel->Tools.iPull;
	 iThrowBoxes = pLevel->Tools.iThrow;
	 iStrength = pLevel->Tools.iStrength;
	 iJumps = pLevel->Tools.iJump;
	 bUnlimitedWeapon = pLevel->Tools.bUnlimitedWeapon;
	 bUnlimitedPulls = pLevel->Tools.bUnlimitedPull;
	 bUnlimitedThrows = pLevel->Tools.bUnlimitedThrow;
	 bUnlimitedStrength = pLevel->Tools.bUnlimitedStrength;
	 bUnlimitedJumps = pLevel->Tools.bUnlimitedJump;
	 bGhostMode = pLevel->Tools.bGhost;
	 bSpeedMode = pLevel->Tools.bSpeed;
	 bWingMode = pLevel->Tools.bWing;
	 bShieldMode = pLevel->Tools.bShield;
	 fGhostModeTime = (float) pLevel->Tools.lGhostTime;
	 fShieldModeTime = (float) pLevel->Tools.lShieldTime;
	 fSpeedModeTime = (float) pLevel->Tools.lSpeedTime;
	 fWingModeTime = (float) pLevel->Tools.lWingTime;*/
} // end ACTOR::SetLevelTools()

// Check the water:
void ACTOR::CheckWater(void)
{ // begin ACTOR::CheckWater()
	float fWaterHeight, fDepth, fActorHeight, fWaveSize;
	FLOAT3 fWaterWaveTestPos, fMouthTestPos;
	AS_PARTICLE *pParticleT;
	FIELD *pFieldT;
	BOOL bTestAir;
	int i;
	
	if(bGhostMode)
		return; // In the ghost mode the isn't influenced through the water!

	// Get the water height on your current position:
	if(Type == AT_BLIBS)
		int inio = 0;
	if(!(pFieldT = pLevel->ComputeWaterHeight(fWorldPos[X], fWorldPos[Y], &fWaterHeight)))
		fWaterHeight = 100.0f; // The water isn't active at this position!

	// Check actors water contact:
	switch(Type)
	{
		case AT_BLIBS:
			ASGetMd2Vertex(pBlibsModel, iAniStep, iNextAniStep, fAniInterpolation, fWorldPos,
						   0.005f, -90.0f, -fRot[Y]+90.0f, 0.0f, 843, &fWaterWaveTestPos);
			fActorHeight = 1.4f;
			ASGetMd2Vertex(pBlibsModel, iAniStep, iNextAniStep, fAniInterpolation, fWorldPos,
						   0.005f, -90.0f, -fRot[Y]+90.0f, 0.0f, 43, &fMouthTestPos);
			bTestAir = TRUE;
		break;

		default:
			fWaterWaveTestPos[Z] = fWorldPos[Z];
			fActorHeight = 1.0f;
			bTestAir = FALSE;
		break;
	}

	if(!bIndestructible && !bShieldMode && fWaterWaveTestPos[Z] > fWaterHeight &&
	   fWorldPos[Z] > fWaterHeight)
	{
		WATER_TYPE WaterType = pLevel->GetWaterType(fWorldPos[X], fWorldPos[Y]);

		// How far is the actor under water?
		fDepth = 50*((fWaterWaveTestPos[Z]-fWaterHeight));
		if(fDepth > 70.0f)
			fDepth = 70.0f;

		if(WaterType == WATER_LAVA)
		{ // The actor dies in the lava:
			switch(Type)
			{
				case AT_BOX_NORMAL: case AT_BOX_RED: case AT_BOX_GREEN: case AT_BOX_BLUE:
				case AT_BLIBS: case AT_MOBMOB: case AT_X3:
					fHealth = 0.0f;
				break;
			}
		}
		else
		if(WaterType == WATER_ACID)
		{ // The actor is damaged through the acid:
			switch(Type)
			{
				case AT_BOX_NORMAL: fHealth -= (float) g_lDeltatime/5000; fShowInfoTextBlend = TRUE; break;
				case AT_BOX_RED: fHealth -= (float) g_lDeltatime/1000; fShowInfoTextBlend = TRUE; break;
				case AT_BOX_GREEN: break;
				case AT_BOX_BLUE: fHealth -= (float) g_lDeltatime/15000; fShowInfoTextBlend = TRUE; break;

				case AT_BLIBS:
				case AT_MOBMOB:
				case AT_X3:
					SetAction(AA_PAIN);
					SetupCameraRotation(AA_PAIN, pCamera);
					fHealth -= (float) g_lDeltatime/(100-fDepth);
					fShowInfoTextBlend = TRUE;
				break;
			}	
		}
	}

	if(pLevel->pField[iFieldID].bOnScreen && fWaterWaveTestPos[Z] > fWaterHeight &&
	   fWorldPos[Z] > fWaterHeight)
	{ // The actor has contact with water:
		fDepth = fWaterHeight-fWorldPos[Z];
		if(fDepth < 0.0f)
			fDepth = -fDepth;
		if(fDepth > fActorHeight)
			fDepth = fActorHeight;
		if(bMove)
			fDepth *= 2;
		
		// Normalize the colors:
		for(i = 0; i < 3; i++)
			if(fColor[i] < 1.0f)
			{
				fColor[i] += (float) (g_lDeltatime*fDepth)/10000;
				if(fColor[i] > 1.0f)
					fColor[i] = 1.0f;
			}
		// Create the actors water waves:
		if(fWaterWaveTestPos[Z]-fActorHeight < fWaterHeight)
		{ // Yep, the actor creates waves:
			if(!bMove)
				i = (int) (3000-_ASConfig->fParticleDensity*2200);
			else
				i = (int) ((1/fMoveVelocity)*10+(500-_ASConfig->fParticleDensity*500));
			if(ASCheckTimeUpdate(&lLastWaterWaveTime, i))
			{
				fWaveSize = fWaterWaveTestPos[Z]-fWaterHeight;
				if(fWaveSize > 0.5f)
					fWaveSize = 1.0f-fWaveSize;
				CreateWaterWave(fWorldPos[X], fWorldPos[Y], fWaveSize);
			}
		}
	}
	
	// Check actors air: (fist get check point e.g. the mouth)
	if(bTestAir)
	{ // Yeah we should test the actors air:
		if(fMouthTestPos[Z] > fWaterHeight)
		{ // The actor is under water:
			fAir -= (float) g_lDeltatime/70;
			if(fAir < 10.0f)
				SetAction(AA_SMOTHER);
			if(fAir < 0.0f)
			{ // The actor suffocates now:
				fAir = 0.0f;
				fHealth -= (float) g_lDeltatime/50;
				ShowInfoText();
			}
	
			if(pLevel->pField[iFieldID].bOnScreen &&
			   g_lNow-lLastWaterBubbleTime > lLastWaterBubbleTimeWait)
			{ // Create water bubbles:
				lLastWaterBubbleTime = GetTickCount();
				lLastWaterBubbleTimeWait = (long) (5+(rand() % 600)*(fAir/fMaxAir));

				// Get an free water bubble particle:
				i = ParticleManager.pSystem[PS_WATER_BUBBLES].GetFreeParticle();
				if(i == -1)
					return;
				pParticleT = &ParticleManager.pSystem[PS_WATER_BUBBLES].pParticle[i];
				pParticleT->bAlive = TRUE;
				pParticleT->fEngine = 1.0f;
				pParticleT->fDensity = pLevel->Environment.fWaterBubblesDensity;
				pParticleT->fColor[0] = pLevel->Environment.fWaterBubblesColor[R];
				pParticleT->fColor[1] = pLevel->Environment.fWaterBubblesColor[G];
				pParticleT->fColor[2] = pLevel->Environment.fWaterBubblesColor[B];
				pParticleT->fFadeSpeed = 0.005f;
				pParticleT->fSize = (float) (rand() % 100)/200;
				if(pParticleT->fSize < 0.1f)
					pParticleT->fSize = 0.1f;
				pParticleT->fPos[X] = fMouthTestPos[X];
				pParticleT->fPos[Y] = fMouthTestPos[Y];
				pParticleT->fPos[Z] = fMouthTestPos[Z];
				if(!(rand() % 2))
					pParticleT->fVelocity[X] = (float) (rand() % 100)/200;
				else
					pParticleT->fVelocity[X] = (float) -(rand() % 100)/200;
				if(!(rand() % 2))
					pParticleT->fVelocity[Y] = (float) (rand() % 100)/200;
				else
					pParticleT->fVelocity[Y] = (float) -(rand() % 100)/200;
				pParticleT->fVelocity[Z] = (float) -(rand() % 100)/100;
				if(!pParticleT->fVelocity[Z])
					pParticleT->fVelocity[Z] = 0.01f;
				switch(byDirection)
				{
					case LEFT:
						pParticleT->fVelocity[X] *= 2;
						if(pParticleT->fVelocity[X] > 0.0f)
							pParticleT->fVelocity[X] = -pParticleT->fVelocity[X];
					break;

					case UP:
						pParticleT->fVelocity[Y] *= 2;
						if(pParticleT->fVelocity[Y] > 0.0f)
							pParticleT->fVelocity[Y] = -pParticleT->fVelocity[Y];
					break;

					case RIGHT:
						pParticleT->fVelocity[X] *= 2;
						if(pParticleT->fVelocity[X] < 0.0f)
							pParticleT->fVelocity[X] = -pParticleT->fVelocity[X];
					break;

					case DOWN:
						pParticleT->fVelocity[Y] *= 2;
						if(pParticleT->fVelocity[Y] < 0.0f)
							pParticleT->fVelocity[Y] = -pParticleT->fVelocity[Y];
					break;
				}
			}
		}
		else
		{ // The actor gets fresh air:
			if(fAir != fMaxAir)
			{
				if(fAir > fMaxAir)
				{
					fAir -= (float) g_lDeltatime/40;
					if(fAir < fMaxAir)
						fAir = fMaxAir;
				}
				else
					fAir += (float) g_lDeltatime/30;
			}
		}
	}
} // end ACTOR::CheckWater()

void ACTOR::SetToCheckpoint(void)
{ // begin ACTOR::SetToCheckpoint()
	ACTOR *pActorT;
	int i;

	if(iFieldID >= 0 && iFieldID < pLevel->Header.iFields &&
	   pLevel->pField[iFieldID].pActor == pPlayer)
		pLevel->pField[iFieldID].pActor = NULL;
	
	// Check if the field is free:
	iFieldID = iCheckpointFieldID;
	pActorT = pLevel->pField[iFieldID].pActor;
	if(pActorT &&
	  (pActorT->Type == AT_BOX_NORMAL ||
	   pActorT->Type == AT_BOX_RED ||
	   pActorT->Type == AT_BOX_GREEN ||
	   pActorT->Type == AT_BOX_BLUE))
	{
		pActorT->DeleteActorType();
		pActorT->bGoingDeath = TRUE;
	}
	pLevel->pField[iFieldID].pActor = this;
	memset(fFieldPos, 0, sizeof(FLOAT3));
	memset(fVelocity, 0, sizeof(FLOAT3));
	fVelocity[0] = PLAYER_MOVE_SPEED;
	iFieldPos[X] = pLevel->pField[iFieldID].iXField;
	iFieldPos[Y] = pLevel->pField[iFieldID].iYField;
	fFieldPos[X] = fFieldPos[Y] = 0.0f;
	Action = AA_NOTHING;
	bActive = TRUE;
	fDeathTime = 0.0f;
	bGoingDeath = bDeath = bFallIntoHole = FALSE;
	if(!fHealth)
		fHealth = fMaxHealth;
	fAir = fMaxAir;
	fFieldPos[Z] = 0.0f;
	bGoingDeath = bDeathRemoved = FALSE;
	bMove = FALSE;
	SetAction(AA_CHECKPOINT);

	GetWorldPos();

	// Set the camera to this new location:
	if(pPlayer == this && !bClone)
	{
		pCamera->fPos2[X] = pCamera->fPos[X]+fWorldPos[X];
		pCamera->fPos2[Y] = pCamera->fPos[Y]+fWorldPos[Y];
		pCamera->fPos2[Z] = -(pCamera->fPos[Z]-(fWorldPos[Z]));
	}
	ComputeHeight();
	
	if(bPlayerCameraView)
		for(i = 0; i < 3; i++)
			pCamera->fRot[i] = pCamera->fRot2[i] = pCamera->fRot2Velocity[i] = 0;

	if(bReincarnationShield)
	{ // Give the actor an small reincarnation shield:
		bShieldMode = TRUE;
		fShieldModeTime += (float) 5;
		lShieldModeTime = g_lGameTimer;
	}
} // end ACTOR::SetToCheckpoint()

// Damages an box:
void ACTOR::MakeDamage(float fPowerT)
{ // begin ACTOR::MakeDamage()
	if(bIndestructible || bShieldMode || bDeath || bGoingDeath)
	{
		if(bShieldMode)
		{
			ASPlayFmodSample(pShieldHitSample, FSOUND_LOOP_OFF);
			if(Type == AT_LUCIFER)
				ASPlayFmodSample(pLuciferLaughSample, FSOUND_LOOP_OFF);
		}
		return; // This actor couldn't be damaged!
	}

	switch(Type)
	{
		case AT_BLIBS: fHealth -= 40.0f*fPowerT; break;
		case AT_BOX_NORMAL: fHealth -= 30.0f*fPowerT; break;
		case AT_BOX_GREEN: fHealth -= 40.0f*fPowerT; break;
		case AT_BOX_BLUE: fHealth -= 50.0f*fPowerT; break;
		case AT_BOX_RED: fHealth -= 100.0f*fPowerT; break;
		case AT_MOBMOB: fHealth -= 30.0f*fPowerT; break;
		case AT_X3: fHealth -= 30.0f*fPowerT; break;

		case AT_LUCIFER:
			fHealth -= 20.0f*fPowerT;
			ASPlayFmodSample(pLuciferDamageSample, FSOUND_LOOP_OFF);
		break;
	}
	SetAction(AA_NOTHING);
	SetAction(AA_PAIN);
	ShowInfoText();
	if(bNitroglycerin)
		fHealth = 0.0f; // High explosive!
} // end ACTOR::MakeDamage()

// Updates the deletion of the actor in the level:
void ACTOR::DeleteActorType(void)
{ // begin ACTOR::DeleteActorType()
	AS_PARTICLE_SYSTEM *pSystemT;
	int i;

	DisableBoxDocking();
	if(bDocked || bBridge)
		DisableNoneFreeBox();
	switch(Type)
	{
		case AT_BOX_NORMAL: pLevel->Header.iNormalBoxes--; break;
		case AT_BOX_RED: pLevel->Header.iRedBoxes--; break;
		case AT_BOX_GREEN:
			pLevel->Header.iGreenBoxes--;
        	i = ParticleManager.AddNewSystem(PS_X3Acid, 10, this, &GameTexture[23], NULL);
			pSystemT = &ParticleManager.pSystem[i];
			pSystemT->bActive = TRUE;
			pSystemT->bAnimatedParticles = TRUE;
			pSystemT->iAnimationColumns = 2;
			pSystemT->iAnimationRows = 2;
			pSystemT->iTextureWidth = 256;
			pSystemT->iTextureHeight = 256;
		break;

		case AT_BOX_BLUE: pLevel->Header.iBlueBoxes--; break;
	}
} // end ACTOR::DeleteActorType()

void ACTOR::AnimateModel(AS_MD2_MODEL *pModel)
{ // begin ACTOR::AnimateModel()
	fAniInterpolation = (float) (g_lGameTimer-dwAniTime)/(float) (fRealAniSpeed);
	dwAniDeltaTime = g_lGameTimer-dwAniTime;

	// Animate the md2 model:
	iNextAniStep = iAniStep+1;
	if(iNextAniStep >= pModel->Ani.anim[byAnimation].lastFrame)
		iNextAniStep = pModel->Ani.anim[byAnimation].firstFrame;
	if(fAniInterpolation >=  1.0f)
	{
		fAniInterpolation = 1.0f;
		dwAniTime = g_lGameTimer;
		iAniStep++;
		if(iAniStep >= pModel->Ani.anim[byAnimation].lastFrame)
			iAniStep = pModel->Ani.anim[byAnimation].firstFrame;
	}
} // end ACTOR::AnimateModel()

void ACTOR::SetupLighting(void)
{ // begin ACTOR::SetupLighting()
	GLfloat afLightData[4]  = {0.0f, 0.0f, 0.0f, 0.0f};
	float fScale, f;
	int iLightID;

	if(!bActive)
		return; // The actor isn't active!
	if(!bOnScreen && Type != AT_BLIBS)
		return; // The actor isn't on the screen:

	switch(Type)
	{
		case AT_BLIBS: // Setup the Blibs 'aura':
			if(pPlayer != this)
				break;
			iLightID = GL_LIGHT0+_AS->iActiveLights;
			afLightData[0] = fWorldPos[X];
			afLightData[1] = fWorldPos[Y];
			afLightData[2] = fWorldPos[Z]-0.2f;
			afLightData[3] = 1.0f;
			glLightfv(iLightID, GL_POSITION, afLightData);
			afLightData[0] = 0.8f;
			afLightData[1] = 0.8f;
			afLightData[2] = 0.8f;
			afLightData[3] = 1.0f;
			glLightfv(iLightID, GL_DIFFUSE, afLightData);
			glEnable(iLightID);
			_AS->iActiveLights++;

			if(bShieldMode && this == pPlayer)
			{
				iLightID = GL_LIGHT0+_AS->iActiveLights;
				afLightData[0] = fWorldPos[X];
				afLightData[1] = fWorldPos[Y];
				afLightData[2] = fWorldPos[Z]-10;
				afLightData[3] = fShieldLighting;
				glLightfv(iLightID, GL_POSITION, afLightData);
				f = fShieldLighting;
				if(f > 0.8f)
					f = 0.8f;
				if(f < 0.4f)
					f = 0.4f;

				afLightData[0] = 0.3f*f;
				afLightData[1] = 0.7f*f;
				afLightData[2] = 0.3f*f;
				afLightData[3] = 1.0f;
				glLightfv(iLightID, GL_DIFFUSE, afLightData);
				glEnable(iLightID);
				_AS->iActiveLights++;
			}
			if(bBlibsPeeping && this == pPlayer)
			{
				iLightID = GL_LIGHT0+_AS->iActiveLights;
				afLightData[0] = fWorldPos[X];
				afLightData[1] = fWorldPos[Y];
				afLightData[2] = fWorldPos[Z]-0.5f;
				afLightData[3] = 1.0f;
				glLightfv(iLightID, GL_POSITION, afLightData);
				afLightData[0] = 1.0f*fPeepBlend;
				afLightData[1] = 0.6f*fPeepBlend;
				afLightData[2] = 0.6f*fPeepBlend;
				afLightData[3] = 1.0f;
				glLightfv(iLightID, GL_DIFFUSE, afLightData);
				glEnable(iLightID);
				_AS->iActiveLights++;
			}
		break;

		case AT_LUCIFER_HEAD:
			iLightID = GL_LIGHT0+_AS->iActiveLights;
			afLightData[0] = fWorldPos[X];
			afLightData[1] = fWorldPos[Y];
			afLightData[2] = fWorldPos[Z]-0.5f;
			afLightData[3] = 1.0f;
			glLightfv(iLightID, GL_POSITION, afLightData);
			afLightData[0] = 1.0f;
			afLightData[1] = 0.1f;
			afLightData[2] = 0.1f;
			afLightData[3] = 1.0f;
			glLightfv(iLightID, GL_DIFFUSE, afLightData);
			glEnable(iLightID);
			_AS->iActiveLights++;
		break;

		case AT_SHOT_1:
			iLightID = GL_LIGHT0+_AS->iActiveLights;
			fScale = fSize;
			afLightData[0] = fWorldPos[X];
			afLightData[1] = fWorldPos[Y];
			afLightData[2] = fWorldPos[Z]-0.5f;
			afLightData[3] = 1.0f;
			glLightfv(iLightID, GL_POSITION, afLightData);
			afLightData[0] = 1.0f*fScale;
			afLightData[1] = 0.3f*fScale;
			afLightData[2] = 0.3f*fScale;
			afLightData[3] = 1.0f;
			glLightfv(iLightID, GL_DIFFUSE, afLightData);
			glEnable(iLightID);
			_AS->iActiveLights++;
		break;

		case AT_BOX_NORMAL: case AT_BOX_RED: case AT_BOX_BLUE: case AT_X3: case AT_MOBMOB: break;

		default:
			if(bGoingDeath)
			{ // Setup the death light:
				iLightID = GL_LIGHT0+_AS->iActiveLights;
				fScale = fSize;
				afLightData[0] = fWorldPos[X];
				afLightData[1] = fWorldPos[Y];
				afLightData[2] = fWorldPos[Z]-0.5f;
				afLightData[3] = 1.0f;
				glLightfv(iLightID, GL_POSITION, afLightData);
				afLightData[0] = fColor[0]*fScale*fBlendDensity;
				afLightData[1] = fColor[1]*fScale*fBlendDensity;
				afLightData[2] = fColor[2]*fScale*fBlendDensity;
				afLightData[3] = 1.0f;
				glLightfv(iLightID, GL_DIFFUSE, afLightData);
				glEnable(iLightID);
				_AS->iActiveLights++;
			}
		break;
	}
} // end ACTOR::SetupLighting()

// Make all tools to points if the level is finished:
void ACTOR::MakeToolsToPoints(void)
{ // begin ACTOR::MakeToolsToPoints()
	if(!Item[AT_WEAPON_ITEM].bUnlimited && Item[AT_WEAPON_ITEM].iNumber > 0)
	{
		IncreaseItemNumber(AT_COIN_ITEM, 5);
		DecreaseItemNumber(AT_WEAPON_ITEM);
	}
	else
		bWeapon = FALSE;
	if(!Item[AT_PULL_ITEM].bUnlimited && Item[AT_PULL_ITEM].iNumber > 0)
	{
		IncreaseItemNumber(AT_COIN_ITEM, 5);
		DecreaseItemNumber(AT_PULL_ITEM);
	}
	else
		bPullBoxesPossible = FALSE;
	if(!Item[AT_JUMP_ITEM].bUnlimited && Item[AT_JUMP_ITEM].iNumber > 0)
	{
		IncreaseItemNumber(AT_COIN_ITEM, 5);
		DecreaseItemNumber(AT_JUMP_ITEM);
	}
	else
		bJumpingPossible = FALSE;
	if(!Item[AT_STRENGTH_ITEM].bUnlimited && Item[AT_STRENGTH_ITEM].iNumber > 1)
	{
		IncreaseItemNumber(AT_COIN_ITEM, 5);
		DecreaseItemNumber(AT_STRENGTH_ITEM);
	}
	else
		Item[AT_STRENGTH_ITEM].iNumber = 1;
	if(bGhostMode && GHOST_TIME-(g_lGameTimer-lGhostModeTime) > 0)
	{
		IncreaseItemNumber(AT_COIN_ITEM, 1);
		lGhostModeTime -= 500;
	}
	else
	{
		lGhostModeTime = g_lGameTimer;
		bGhostMode = FALSE;
		ParticleManager.pSystem[PS_PLAYER_GHOST].bGoingInActive = TRUE;
	}
	if(bSpeedMode && SPEED_TIME-(g_lGameTimer-lSpeedModeTime) > 0)
	{
		IncreaseItemNumber(AT_COIN_ITEM, 1);
		lSpeedModeTime -= 500;
	}
	else
	{
		lSpeedModeTime = g_lGameTimer;
		bSpeedMode = FALSE;
		ParticleManager.pSystem[PS_PLAYER_SPEED].bGoingInActive = TRUE;
	}
	if(bWingMode && WING_TIME-(g_lGameTimer-lWingModeTime) > 0)
	{
		IncreaseItemNumber(AT_COIN_ITEM, 1);
		lWingModeTime -= 500;
	}
	else
	{
		lWingModeTime = g_lGameTimer;
		bWingMode = FALSE;
	}
	if(bShieldMode && SHIELD_TIME-(g_lGameTimer-lShieldModeTime) > 0)
	{
		IncreaseItemNumber(AT_COIN_ITEM, 1);
		lShieldModeTime -= 500;
	}
	else
	{
		lShieldModeTime = g_lGameTimer;
		bShieldMode = FALSE;
	}
	if(!pLevel->Missions.bTimeLimit)
		pLevel->Missions.iTimeLimit = 0;
	else
	{
		if(pLevel->Missions.iTimeLimit > 0)
		{
			IncreaseItemNumber(AT_COIN_ITEM, 1);
			pLevel->Missions.iTimeLimit -= 5;
		}
		else
			pLevel->Missions.iTimeLimit = 0;
	}
	if(!pLevel->Missions.bStepsLimit)
		pLevel->Missions.iStepsLimit = 0;
	else
	{
		if(pLevel->Missions.iStepsLimit > 0)
		{
			IncreaseItemNumber(AT_COIN_ITEM, 1);
			pLevel->Missions.iStepsLimit -= 2;
		}
		else
			pLevel->Missions.iStepsLimit = 0;
	}
} // end ACTOR::MakeToolsToPoints()

// Check, if the height difference isn't to high:
BOOL ACTOR::CheckHeightDifference(ACTOR *pActorT)
{ // begin ACTOR::CheckHeightDifference()
	if(fWorldPos[Z] < pActorT->fWorldPos[Z]-1.0f ||
	   fWorldPos[Z]-1.0f > pActorT->fWorldPos[Z])
		return TRUE;

	return FALSE;
} // end ACTOR::CheckHeightDifference()

void ACTOR::IncreaseItemNumber(ACTOR_TYPE ActorType, int iNumberT)
{ // begin ACTOR::IncreaseItemNumber()
	ITEM_INFO *pItemT;
	
	pItemT = &Item[ActorType];
	if(pItemT->bUnlimited)
		return; // This item is unlimited available!

	pItemT->iNumber += iNumberT;
	if(pItemT->iNumber < 0)
		pItemT->iNumber = 0;
} // end ACTOR::IncreaseItemNumber()

void ACTOR::DecreaseItemNumber(ACTOR_TYPE ActorType)
{ // begin ACTOR::DecreaseItemNumber()
	ITEM_INFO *pItemT;
	
	pItemT = &Item[ActorType];
	if(pItemT->bUnlimited)
	{
		pItemT->iNumber = 99;
		return; // This item is unlimited available!
	}

	pItemT->iNumber--;
	if(pItemT->iNumber < 0)
		pItemT->iNumber = 0;
} // end ACTOR::DecreaseItemNumber()

void ACTOR::CheckCollectItem(void)
{ // begin ACTOR::CheckCollectItem()
	int iXStart, iXEnd, iYStart, iYEnd, iX, iY;
	FIELD *pFieldT;
	FLOAT3 fPosT;
	
	if(bGhostMode)
		return;

	iXStart = iFieldPos[X]-1;
	iXEnd = iFieldPos[X]+1;
	iYStart = iFieldPos[Y]-1;
	iYEnd = iFieldPos[Y]+1;
	if(iXStart < 0)
		iXStart = 0;
	if(iYStart < 0)
		iYStart = 0;
	if(iXEnd >= pLevel->Header.iWidth-1)
	   iXEnd = pLevel->Header.iWidth-2;
	if(iYEnd >= pLevel->Header.iHeight-1)
	   iYEnd = pLevel->Header.iHeight-2;
	for(iY = iYStart; iY <= iYEnd; iY++)
	{
		for(iX = iXStart; iX <= iXEnd; iX++)
		{
			// Get a pointer to this field:
			GET_FIELD_POINTER(iX, iY, pFieldT);
			if(pFieldT->pItem && pFieldT->pItem->bActive && !pFieldT->pItem->bGoingDeath)
			{
				ASGetMd2Vertex(pBlibsModel, iAniStep, iNextAniStep, fAniInterpolation, fWorldPos,
							   0.005f, -90.0f, -fRot[Y]+90.0f, 0.0f, 0, &fPosT);
				if(pFieldT->pItem->ActorCollectsItem(this, fPosT, 0.5f, TRUE))
					pFieldT->pItem = NULL;
			}
		}
	}
} // end ACTOR::CheckCollectItem()

void ACTOR::DeliverItems(void)
{ // begin ACTOR::DeliverItems()
	int iXStart, iXEnd, iYStart, iYEnd, iX, iY, i;
	BOOL bFound;
	ACTOR *pActorT;
	FIELD *pFieldT;

	for(i = 0; i < ITEMS; i++)
	{
		if(!Item[i].bDeliver || (!Item[i].iNumber && !Item[i].bUnlimited))
			continue; // This item shouldn't be delivered!

		// First, find a free field around the actor to put on the items:
		iX = iFieldPos[X];
		iY = iFieldPos[Y];
		if(pLevel->pField[iFieldID].pItem)
		{ // Damn, on the actors field is already an item... now check,if there is enought free place
			iXStart = iFieldPos[X]-1;
			iXEnd = iFieldPos[X]+1;
			iYStart = iFieldPos[Y]-1;
			iYEnd = iFieldPos[Y]+1;
			if(iXStart < 0)
				iXStart = 0;
			if(iYStart < 0)
				iYStart = 0;
			if(iXEnd >= pLevel->Header.iWidth-1)
			   iXEnd = pLevel->Header.iWidth-2;
			if(iYEnd >= pLevel->Header.iHeight-1)
			   iYEnd = pLevel->Header.iHeight-2;
			for(bFound = FALSE, iY = iYStart; iY <= iYEnd; iY++)
			{
				for(iX = iXStart; iX <= iXEnd; iX++)
				{
					// Get a pointer to this field:
					GET_FIELD_POINTER(iX, iY, pFieldT);
					if(pFieldT->pItem || (pFieldT->bWall && !pFieldT->bWallHole))
						continue; // There's already an item!
					bFound = TRUE;
					break;
				}
				if(bFound)
					break;
			}
			if(!bFound)
				return; // We found no free field!
		}
		
		// Now put the item on the field:
		if(!(pActorT = pLevel->FindFreeActor()))
			break;
		pActorT->bActive = TRUE;
		pActorT->iFieldPos[X] = iX;
		pActorT->iFieldPos[Y] = iY;
		pActorT->Type = (ACTOR_TYPE) i;
		pActorT->iNumber = Item[i].iNumber;
		pActorT->bNumberUnlimited = Item[i].bUnlimited;
		GET_FIELD_POINTER(iX, iY, pFieldT);
		pActorT->iFieldID = pFieldT->iID;
		pFieldT->pItem = pActorT;
		if(!Item[i].bKeep)
			memset(&Item[i], 0, sizeof(ITEM_INFO)); // The actor lose this item!
	}
} // end ACTOR::DeliverItems()

void ACTOR::IncreaseWrongTimer(void)
{ // begin ACTOR::IncreaseWrongTimer()
	if(Action == AA_WRONG)
		return;
	fWrongTimer += (float) g_lDeltatime/500;
	if(fWrongTimer > 1.0f)
	{
		SetAction(AA_WRONG);
		fWrongTimer = 0.0f;
	}
	else
		SetAction(AA_STANDING);
} // end ACTOR::IncreaseWrongTimer()

void ACTOR::CheckWrongTimer(void)
{ // begin ACTOR::CheckWrongTimer()
	fWrongTimer -= (float) g_lDeltatime/1000;
	if(fWrongTimer < 0.0f)
		fWrongTimer = 0.0f;
} // end ACTOR::CheckWrongTimer()

BOOL ACTOR::CheckIfEnemy(void)
{ // begin ACTOR::CheckIfEnemy()
	if(!bAggressive || bGuardian)
		return FALSE;
	return TRUE;
} // end ACTOR::CheckIfEnemy()

void ACTOR::BeamingScale(float fScaleT)
{ // begin ACTOR::BeamingScale()
	if(!bBeaming)
		return;
	float fTemp = (float) (0.5f-0.5f*cos(sin(fBeamingBlend*PId2)*PI));
	glScalef(fTemp, 1.0f+4.0f*(fScaleT-fTemp*fScaleT), fTemp);
} // end ACTOR::BeamingScale()

void ACTOR::ShowInfoText(void)
{ // begin ACTOR::ShowInfoText()
	if(this == pPlayer)
		return;
	bShowInfoText = TRUE;
} // end ACTOR::ShowInfoText()

void ACTOR::CheckInfoText(void)
{ // begin ACTOR::CheckInfoText()
	if(bShowInfoText)
	{
		if(fShowInfoTextBlend != 1.0f)
		{
			fShowInfoTextBlend += (float) g_lDeltatime/1000;
			if(fShowInfoTextBlend > 1.0f)
			{
				fShowInfoTextBlend = 1.0f;
				fShowInfoTextTimer = 0.0f;
			}
		}
		else
		{
			fShowInfoTextTimer += (float) g_lDeltatime/2000;
			if(fShowInfoTextTimer > 1.0f)
				bShowInfoText = FALSE;
		}
	}
	else
	{
		fShowInfoTextBlend -= (float) g_lDeltatime/1000;
		if(fShowInfoTextBlend < 0.0f)
			fShowInfoTextBlend = 0.0f;
	}
} // end ACTOR::CheckInfoText()

// Check if the level water height should be changed:
void ACTOR::CheckChangeWaterHeight(void)
{ // begin ACTOR::CheckChangeWaterHeight()
	FIELD *pFieldT;

	if(fFieldPos[X] != 0.0f || fFieldPos[Y] != 0.0f)
		return;
	GET_FIELD_POINTER(iFieldPos[X], iFieldPos[Y], pFieldT);
	if(!pFieldT->bWaterChangeHeight)
		return;
	if(pFieldT->bWaterChangePressed)
	{
		if(pLevel->Environment.fWaterHeight < pFieldT->fWaterChangeHeightTo)
		{
			pLevel->Environment.fWaterHeight += ((float) g_lDeltatime/5000)*pFieldT->fWaterChangeSpeed;
			if(pLevel->Environment.fWaterHeight > pFieldT->fWaterChangeHeightTo)
				pLevel->Environment.fWaterHeight = pFieldT->fWaterChangeHeightTo;
		}
		else
		{
			pLevel->Environment.fWaterHeight -= ((float) g_lDeltatime/5000)*pFieldT->fWaterChangeSpeed;
			if(pLevel->Environment.fWaterHeight < pFieldT->fWaterChangeHeightTo)
				pLevel->Environment.fWaterHeight = pFieldT->fWaterChangeHeightTo;
		}
	}
	else
	{
		pLevel->Environment.bWaterChangeHeight = TRUE;
		pLevel->Environment.fWaterChangeHeightTo = pFieldT->fWaterChangeHeightTo;
		pLevel->Environment.fWaterChangeSpeed = pFieldT->fWaterChangeSpeed;
	}
} // end ACTOR::CheckChangeWaterHeight()
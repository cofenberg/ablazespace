//-----------------------------------------------------------------------------
// File: ActorBox.cpp
//-----------------------------------------------------------------------------

#include "..\AS\AS_Engine.h"
#include "..\ModuleHeaders.h"


// The actor pushs a box (or more), if it's possible then do it and return 1 else return 0
// (if 'byDirectionT' is -1 then the actors current direction is used)
BOOL ACTOR::DoBoxPushing(char byDirectionT)
{ // begin ACTOR::DoBoxPushing()
	int iX, iY, iXD, iYD, i, iStrengthT, iTemp;
	ACTOR *pActorT, *pLastActorT;
	float fStrengthT, fVelocityT;
	FIELD *pFieldT;

	// Could the actor push boxes?
	if(bGhostMode)
		return FALSE; // Nope!

	if(byDirectionT == -1)
		byDirectionT = byDirection;

	// Setup x/y direction:
	switch(byDirectionT)
	{
		case LEFT: iX = -1; iY = 0; break;
		case UP: iX = 0; iY = -1; break;
		case RIGHT: iX = 1; iY = 0; break;
		case DOWN: iX = 0; iY = 1; break;
	}
	
	if(!pLevel->CheckIfCorrectPos(iFieldPos[X]+iX, iFieldPos[Y]+iY))
		return FALSE; // It's absolutely not possible to move!!
	
	GET_FIELD_POINTER(iFieldPos[X]+iX, iFieldPos[Y]+iY, pFieldT);
	if(pFieldT->pActor)
	{
//		pFieldT->pActor->CheckBox(FALSE); // Check the box to go sure that all is right
		if(!pFieldT->pActor)
			return FALSE;
	}
	if(CheckIfWall(byDirectionT, 1) ||
	   (pFieldT->pActor && (!pFieldT->pActor->bMoveable)) ||
	   (pFieldT->pBridgeActor && pFieldT->pBridgeActor->bBridgeMovement))
		return FALSE; // It's absolutely not possible to push!!
	
	// Get pushing data for testing:
	fVelocityT = fVelocity[0];
	iStrengthT = Item[AT_STRENGTH_ITEM].iNumber;
	fStrengthT = fStrength;
	
	// Check if we are able to push
	pLastActorT = this;
	for(i = 1;; i++)
	{ 
		// Get the next field:
		iXD = iX*i; iYD = iY*i;
		if(!pLevel->CheckIfCorrectPos(iFieldPos[X]+iXD, iFieldPos[Y]+iYD))
			return FALSE; // It's absolutely not possible to move!!
		GET_FIELD_POINTER(iFieldPos[X]+iXD, iFieldPos[Y]+iYD, pFieldT);
		pActorT = pFieldT->pActor;
		if(!pActorT || (pActorT->bSquashable && i != 1))
			break; // There is a more or less free field!
		// Check if we could push that:
//		pActorT->CheckBox(FALSE); // Check the box to go sure that all is right
		if(pActorT->CheckIfWall(byDirectionT, 1))
			return FALSE; // Theres no free field!
		if(!pActorT->bMoveable)
			return FALSE; // No chance to move this thing!!
		if(pLastActorT->CheckHeightDifference(pActorT))
			return FALSE; // The height difference is to high!

		// This action costs a little bit of the strength:
		fStrengthT -= pActorT->fWeight/10.0f;
		if(fStrengthT <= 0.0f)
		{
			fStrengthT = 1.0f;
			iStrengthT--;
		}

		// Did we have enought strength for pushing that?
		if(iStrengthT < i && i > 1)
			return FALSE; // NOPE! We haven't enought strength!

		// Decrease the pushing velocity:
		if(pFieldT->Side[FACE_FLOOR].Surface[0].pSurface)
			fVelocityT *= pActorT->fWeight*pFieldT->Side[FACE_FLOOR].Surface[0].pSurface->Header.fFriction;
		else
			fVelocityT *= pActorT->fWeight;
		pLastActorT = pActorT;
	}

	// Ok, now we know that we could push and we have the resulting push velocity.
	// Now perform the pushing:
	pLastActorT = this;
	for(i = 1; ; i++)
	{
		// Get the next field:
		iXD = iX*i; iYD = iY*i;
		GET_FIELD_POINTER(iFieldPos[X]+iXD, iFieldPos[Y]+iYD, pFieldT);

		if(!(pActorT = pFieldT->pActor))
			break; // Thats all!
		if(i != 1 && pActorT->Squash())
		{
			if(pLastActorT->bCollisionDamage)
				pLastActorT->MakeDamage(1.0f);
			break;
		}
		// This action costs a little bit of the strength:
		fStrength -= pActorT->fWeight/40.0f;
		if(fStrength <= 0.0f)
		{
			fStrength = 1.0f;
			Item[AT_STRENGTH_ITEM].iNumber--;
		}
		
		// Move the actor:
		pActorT->pVelocityFromActor = pLastActorT;
		pActorT->bMove = TRUE;
		pActorT->byDirection = byDirectionT;
		pLastActorT = pFieldT->pActor;
	}
	iTemp = i;

	// Now set the right actor field settings:
	for(i = iTemp-1; i > 0; i--)
	{
		// Get the next field:
		iXD = iX*i; iYD = iY*i;
		GET_FIELD_POINTER(iFieldPos[X]+iXD, iFieldPos[Y]+iYD, pFieldT);
		pActorT = pFieldT->pActor;
		
		// Give the next field this actor:
		iXD = iX*(i+1); iYD = iY*(i+1);
		GET_FIELD_POINTER(iFieldPos[X]+iXD, iFieldPos[Y]+iYD, pFieldT);
		pFieldT->pActor = pActorT;
	}

	// Setup the pushing actor:
	fVelocity[0] = fVelocityT;
	SetAction(AA_PUSHING);
	bMove = TRUE;

	// Give the next field that actor:
	GET_FIELD_POINTER(iFieldPos[X]+iX, iFieldPos[Y]+iY, pFieldT);
	pFieldT->pActor = this;

	return TRUE; // Yes, lets pushing!
} // end ACTOR::DoBoxPushing()

// The actor pulls a box, if it's possible then do it and return 1 else return 0
// (if 'byDirectionT' is -1 then the actors current direction is used)
BOOL ACTOR::DoBoxPulling(char byDirectionT)
{ // begin ACTOR::DoBoxPulling()
	int iX, iY;
	char byInversedDirection;
	ACTOR *pActorT;
	FIELD *pFieldT, *pBoxField, *pToGoField;

	// Could the actor pull boxes?
	if(!bPullBoxesPossible || bGhostMode)
		return FALSE; // Nope!

	if(byDirectionT == -1)
		byDirectionT = byDirection;

	// Setup x/y direction:
	switch(byDirectionT)
	{
		case LEFT: iX = -1; iY = 0; byInversedDirection = RIGHT; break;
		case UP: iX = 0; iY = -1; byInversedDirection = DOWN; break;
		case RIGHT: iX = 1; iY = 0; byInversedDirection = LEFT; break;
		case DOWN: iX = 0; iY = 1; byInversedDirection = UP; break;
	}

	if(!pLevel->CheckIfCorrectPos(iFieldPos[X]+iX, iFieldPos[Y]+iY) ||
	   !pLevel->CheckIfCorrectPos(iFieldPos[X]-iX, iFieldPos[Y]-iY))
		return FALSE; // It's absolutely not possible to move!!

	GET_FIELD_POINTER(iFieldPos[X]+iX, iFieldPos[Y]+iY, pBoxField);
	GET_FIELD_POINTER(iFieldPos[X], iFieldPos[Y], pFieldT);
	GET_FIELD_POINTER(iFieldPos[X]-iX, iFieldPos[Y]-iY, pToGoField);

//	if(pBoxField->pActor)
//		pBoxField->pActor->CheckBox(FALSE); // Check the box to go sure that all is right
	
	// Check if we could pull:
	if(CheckIfWall(byDirectionT, 1) || CheckIfWall(byInversedDirection, 1) ||
	   !pBoxField->pActor ||
	    pToGoField->pActor || !pBoxField->pActor->bMoveable ||
	   (pToGoField->pBridgeActor && pToGoField->pBridgeActor->bBridgeMovement))
		return FALSE; // It's absolutely not possible to pull!!

	if(CheckHeightDifference(pBoxField->pActor))
		return FALSE; // The height difference is to high!

	// Pull the box:
	pActorT = pBoxField->pActor;
	if(pActorT->CheckIfWall(byInversedDirection, 1))
		return FALSE; // It's absolutely not possible to pull!!
	fStrength -= pActorT->fWeight/30;
	if(pFieldT->Side[FACE_FLOOR].Surface[0].pSurface)
		fVelocity[0] *= pActorT->fWeight*pFieldT->Side[FACE_FLOOR].Surface[0].pSurface->Header.fFriction;
	else
		fVelocity[0] *= pActorT->fWeight;
	if(fStrength <= 0.0f)
	{
		fStrength = 1.0f;
		Item[AT_STRENGTH_ITEM].iNumber--;
	}
	pActorT->bMove = TRUE;
	pActorT->pVelocityFromActor = this;
	pActorT->byDirection = byInversedDirection;
	pFieldT->pActor = pActorT;

	// Setup the pulling actor:
	SetAction(AA_PULLING);
	bMove = TRUE;
	DecreaseItemNumber(AT_PULL_ITEM);
	pToGoField->pActor = this;

	return TRUE;
} // end ACTOR::DoBoxPulling()

// The actor throw a box, if it's possible then do it and return 1 else return 0
// (if 'byDirectionT' is -1 then the actors current direction is used)
BOOL ACTOR::DoThrowBox(char byDirectionT)
{ // begin ACTOR::DoThrowBox()
	FIELD *pBoxField, *pNextField;
	ACTOR *pActorT;
	int iX, iY;

	// Could the actor pull boxes?
	if(!bThrowBoxesPossible || bGhostMode)
		return FALSE; // Nope!

	if(byDirectionT == -1)
		byDirectionT = byDirection;

	if(CheckIfWall(byDirectionT, 1))
		return FALSE; // Theres an wall!

	// Setup x/y direction:
	switch(byDirectionT)
	{
		case LEFT: iX = -1; iY = 0; break;
		case UP: iX = 0; iY = -1; break;
		case RIGHT: iX = 1; iY = 0; break;
		case DOWN: iX = 0; iY = 1; break;
	}

	// Box field:
	if(!pLevel->CheckIfCorrectPos(iFieldPos[X]+iX, iFieldPos[Y]+iY))
		return FALSE; // It's absolutely not possible to throw!!
	GET_FIELD_POINTER(iFieldPos[X]+iX, iFieldPos[Y]+iY, pBoxField);
	pActorT = pBoxField->pActor;
	if(!pActorT || !pActorT->bMoveable || !pActorT->bThrowable)
		return FALSE; // It's absolutely not possible to throw something!!
	if(CheckHeightDifference(pActorT))
		return FALSE; // The height difference is to high!
	if(!pActorT->bMoveable)
		return FALSE; // It's absolutely not possible to throw!!

	// Next field:
	if(!pLevel->CheckIfCorrectPos(iFieldPos[X]+iX*2, iFieldPos[Y]+iY*2))
		return FALSE; // It's absolutely not possible to throw!!
	GET_FIELD_POINTER(iFieldPos[X]+iX*2, iFieldPos[Y]+iY*2, pNextField);
	if(pNextField->pActor)
	{
		if(pNextField->pActor->Squash() && pActorT->bCollisionDamage)
			pActorT->MakeDamage(1.0f);
	}
	if(pActorT->CheckIfWall(byDirectionT, 1) || pNextField->pActor ||
	   (pNextField->pBridgeActor && pNextField->pBridgeActor->bBridgeMovement))
		return FALSE; // It's absolutely not possible to throw!!
	
	if(pActorT->bNitroglycerin)
	{ // A nitroglycerin box couldn't be thrown (high explosive!!)
		pActorT->MakeDamage(1.0f);
		return FALSE;
	}

	// Throw the box:
	fStrength -= pActorT->fWeight/20.0f;
	pActorT->fVelocity[0] = 3.1f-pActorT->fWeight;
	if(Item[AT_STRENGTH_ITEM].iNumber > 1)
	{
		pActorT->fVelocity[0] += (Item[AT_STRENGTH_ITEM].iNumber-1)/10.0f;
		if(pActorT->fVelocity[0] > 6.0f)
			pActorT->fVelocity[0] = 6.0f;
	}
	pActorT->bMove = TRUE;
	pActorT->bIsThrown = TRUE;
	pActorT->bUseFriction = TRUE;
	pActorT->byDirection = byDirection;
	pNextField->pActor = pActorT;

	return TRUE;
} // end ACTOR::DoThrowBox()

// Kills the box:
void ACTOR::KillBox(void)
{ // begin ACTOR::KillBox()
	FIELD *pFieldT;
	FLOAT3 *fTemp;
	ACTOR *pActorT;
	int i, i2, i3, i4, i5, x, y, iTemp;

	if(bGoingDeath || bIndestructible)
		return;
	bGoingDeath = TRUE;
	DeliverItems();
	DeleteActorType();

	// Initialize the killing sequenze:
	for(i = 0; i < 6; i++)
	{
		fTemp = &fTempPos[i];
		switch(i)
		{
			case FACE_FLOOR: (*fTemp)[X] = 0.0f; (*fTemp)[Y] = 0.0f; (*fTemp)[Z] = 0.0f; break;
			case FACE_TOP: (*fTemp)[X] = 0.0f; (*fTemp)[Y] = -0.5f; (*fTemp)[Z] = -0.5f; break;
			case FACE_LEFT: (*fTemp)[X] = -0.5f; (*fTemp)[Y] = 0.0f; (*fTemp)[Z] = -0.5f; break;
			case FACE_RIGHT: (*fTemp)[X] = 0.5f; (*fTemp)[Y] = 0.0f; (*fTemp)[Z] = -0.5f; break;
			case FACE_BOTTOM: (*fTemp)[X] = 0.0f; (*fTemp)[Y] = 0.5f; (*fTemp)[Z] = -0.5f; break;
			case FACE_FRONT: (*fTemp)[X] = 0.0f; (*fTemp)[Y] = 0.0f; (*fTemp)[Z] = -1.0f; break;
		}
		for(i2 = 0; i2 < 3; i2++)
		{
			fTempRotVelocity[i][i2] = 0.3f+((float) (rand() % 1000)/300.0f);
			fTempPosVelocity[i][i2] = 0.2f+((float) (rand() % 1000)/500.0f);
			if(!(rand() % 2))
				fTempRotVelocity[i][i2] = -fTempRotVelocity[i][i2];
			if(!(rand() % 2))
				fTempPosVelocity[i][i2] = -fTempPosVelocity[i][i2];
		}
		fTempPosVelocity[i][Z] =  ((float) (rand() % 1000)/1000.0f);
		if(!(rand() % 2))
			fTempPosVelocity[i][Z] = -fTempPosVelocity[i][Z];
		fTempPosVelocity[i][Z] -= 1.0f;
	}

	// Check the box type:
	switch(Type)
	{
		case AT_BOX_NORMAL:
			pLevel->State.iDestroyedNormalBoxes++;
		break;
		
		case AT_BOX_RED: // Kill all other actors around this box, too:
			pLevel->State.iDestroyedRedBoxes++;
			i2 = 3+(rand() % 2);
			ASPlayFmodSample(pExplosion1Sample, FSOUND_LOOP_OFF);
			for(i = 0; i < i2; i++)
				CreateExplosion1(fWorldPos[X]-0.2f+(rand() % 140)/100.0f,
								 fWorldPos[Y]-0.2f+(rand() % 140)/100.0f,
								 fWorldPos[Z]-(rand() % 100)/100.0f, 4.0f+(rand() % 200)/100);
			for(y = -1; y < 2; y++)
			{
				for(x = -1; x < 2; x++)
				{
					if(!pLevel->CheckIfCorrectPos(iFieldPos[X]+x, iFieldPos[Y]+y))
						continue;
					
					// Check the field:
					GET_FIELD_ID((iFieldPos[X]+x), (iFieldPos[Y]+y), i2);
					pFieldT = &pLevel->pField[i2];
					pActorT = pFieldT->pActor;
					if(pActorT && !pActorT->bDeath && !pActorT->bGoingDeath)
					{
						if(pActorT->Type == AT_BOX_NORMAL ||
						   pActorT->Type == AT_BOX_RED ||
						   pActorT->Type == AT_BOX_GREEN ||
    					   pActorT->Type == AT_BOX_BLUE)
							pActorT->KillBox();
						else
							pActorT->MakeDamage(3.0f);
					}
					else
					{
						if(pFieldT->bWall && !pFieldT->bIndestructibleWall && !pFieldT->bWallHole)
							pLevel->SetFieldWall(pFieldT->iXField, pFieldT->iYField, FALSE, FALSE);  // Destroy this wall:
						if(pFieldT->bAlwaysWall && !pFieldT->bIndestructibleWall)
						{
							pFieldT->bAlwaysWall = FALSE;
							if(pFieldT->pDecoration)
							{ // Destroy decoration:
								if(pFieldT->pDecoration->iTexture >= 0)
									pLevel->pTexture[pFieldT->pDecoration->iTexture].iUsed++;
								SAFE_DELETE(pFieldT->pDecoration);
							}
						}
					}

					// Check wall sides:
					for(i = FACE_TOP; i < FACE_FRONT+1; i++)
					{
						if(pFieldT->Side[i].bWallSide)
 						{
							pFieldT->Side[i].bFaceAlwaysActive = pFieldT->Side[i].bFaceActive = 
							pFieldT->Side[i].bWallSide = FALSE;
						}
					}

					if(pFieldT->pBridgeActor)
						pFieldT->pBridgeActor->KillBox();
//					if(pFieldT->pItem)
//						pFieldT->pItem->bGoingDeath = TRUE;

					// Make the fields a little bit burned:
					for(i3 = 0; i3 < 6; i3++)
					{
						for(i4 = 0; i4 < 4; i4++)
						{
							for(i5 = 0; i5 < 4; i5++)
							{
								iTemp = pFieldT->Side[i3].SideQuad[i4].iPoint[i5];
								pLevel->fColor[iTemp][0] -= 0.05f;
								if(pLevel->fColor[iTemp][0] < 0.0f)
									pLevel->fColor[iTemp][0] = 0.0f;
								pLevel->fColor[iTemp][1] -= 0.05f;
								if(pLevel->fColor[iTemp][1] < 0.0f)
									pLevel->fColor[iTemp][1] = 0.0f;
								pLevel->fColor[iTemp][2] -= 0.05f;
								if(pLevel->fColor[iTemp][2] < 0.0f)
									pLevel->fColor[iTemp][2] = 0.0f;

								pLevel->fSecondColor[iTemp][0] -= 0.05f;
								if(pLevel->fSecondColor[iTemp][0] < 0.0f)
									pLevel->fSecondColor[iTemp][0] = 0.0f;
								pLevel->fSecondColor[iTemp][1] -= 0.05f;
								if(pLevel->fSecondColor[iTemp][1] < 0.0f)
									pLevel->fSecondColor[iTemp][1] = 0.0f;
								pLevel->fSecondColor[iTemp][2] -= 0.05f;
								if(pLevel->fSecondColor[iTemp][2] < 0.0f)
									pLevel->fSecondColor[iTemp][2] = 0.0f;
							}
						}
						iTemp = pFieldT->Side[i3].SideQuad[0].iPoint[2];
						pLevel->fColor[iTemp][0] -= 0.4f;
						if(pLevel->fColor[iTemp][0] < 0.0f)
							pLevel->fColor[iTemp][0] = 0.0f;
						pLevel->fColor[iTemp][1] -= 0.4f;
						if(pLevel->fColor[iTemp][1] < 0.0f)
							pLevel->fColor[iTemp][1] = 0.0f;
						pLevel->fColor[iTemp][2] -= 0.4f;
						if(pLevel->fColor[iTemp][2] < 0.0f)
							pLevel->fColor[iTemp][2] = 0.0f;

						pLevel->fSecondColor[iTemp][0] -= 0.4f;
						if(pLevel->fSecondColor[iTemp][0] < 0.0f)
							pLevel->fSecondColor[iTemp][0] = 0.0f;
						pLevel->fSecondColor[iTemp][1] -= 0.4f;
						if(pLevel->fSecondColor[iTemp][1] < 0.0f)
							pLevel->fSecondColor[iTemp][1] = 0.0f;
						pLevel->fSecondColor[iTemp][2] -= 0.4f;
						if(pLevel->fSecondColor[iTemp][2] < 0.0f)
							pLevel->fSecondColor[iTemp][2] = 0.0f;
					}
				}
			}
		break;

		case AT_BOX_GREEN: // Deactivate this field:
			pLevel->State.iDestroyedGreenBoxes++;
			GET_FIELD_ID(iFieldPos[X], iFieldPos[Y], i2);
			pFieldT = &pLevel->pField[i2];
			pFieldT->bActive = FALSE;
			if(pFieldT->Side[FACE_FLOOR].Surface[0].iSurface != -1 &&
			   pLevel->pSurface[pFieldT->Side[FACE_FLOOR].Surface[0].iSurface].Header.bAnchor)
			{
				switch(pLevel->pSurface[pFieldT->Side[FACE_FLOOR].Surface[0].iSurface].Header.byAnchorType)
				{
					case 0: pLevel->Header.iForAllAnchors--; break;
					case 1: pLevel->Header.iNormalAnchors--; break;
					case 2: pLevel->Header.iRedAnchors--; break;
					case 3: pLevel->Header.iGreenAnchors--; break;
					case 4: pLevel->Header.iBlueAnchors--; break;
				}
			}
			if(pFieldT->pBridgeActor && pFieldT->pBridgeActor->Type != AT_BOX_GREEN)
			{
				pFieldT->pBridgeActor->KillBox();
				pFieldT->pBridgeActor = NULL;
			}	
			if(pFieldT->pItem)
			{
				pFieldT->pItem->bActive = NULL;
   				pFieldT->pItem = NULL;
			}

			// Damage the boxes (and player) around this green box:
   			for(y = -1; y < 2; y++)
			{
				for(x = -1; x < 2; x++)
				{
					if(!pLevel->CheckIfCorrectPos(iFieldPos[X]+x, iFieldPos[Y]+y))
						continue;

					// Check the field:
					GET_FIELD_ID((iFieldPos[X]+x), (iFieldPos[Y]+y), i2);
					pFieldT = &pLevel->pField[i2];
					pActorT = pFieldT->pActor;
					if(pActorT)
					{
						switch(pActorT->Type)
						{
							// Damage the box if there is one:
							case AT_BOX_NORMAL:
							case AT_BOX_RED:
							case AT_BOX_BLUE:
								pActorT->MakeDamage(1.0f);
							break;
						
							// If the player is near this green box he will be damaged, too!
							default:
								if(!pActorT->bShieldMode)
								{
									pActorT->fHealth -= 20.0f;
									pActorT->SetupCameraRotation(AA_PAIN, pCamera);
									pActorT->SetAction(AA_PAIN);
								}
							break;
						}

						// Make the actor a little bit green:
						pActorT->fColor[0] -= 0.5f;
						pActorT->fColor[1] += 0.5f;
						pActorT->fColor[2] -= 0.5f;
						for(i3 = 0; i3 < 3; i3++)
						{
							if(pActorT->fColor[i3] < 0.0f)
								pActorT->fColor[i3] = 0.0f;
							if(pActorT->fColor[i3] > 1.0f)
								pActorT->fColor[i3] = 1.0f;
						}
					}
					// Make the fields a little bit green:
					for(i3 = 0; i3 < 6; i3++)
					{
						for(i4 = 0; i4 < 4; i4++)
							for(i5 = 0; i5 < 4; i5++)
							{
								iTemp = pFieldT->Side[i3].SideQuad[i4].iPoint[i5];
								pLevel->fColor[iTemp][0] -= 0.02f;
								if(pLevel->fColor[iTemp][0] < 0.0f)
									pLevel->fColor[iTemp][0] = 0.0f;
								pLevel->fColor[iTemp][1] += 0.02f;
								if(pLevel->fColor[iTemp][1] > 1.0f)
									pLevel->fColor[iTemp][1] = 1.0f;
								pLevel->fColor[iTemp][2] -= 0.02f;
								if(pLevel->fColor[iTemp][2] < 0.0f)
									pLevel->fColor[iTemp][2] = 0.0f;

								pLevel->fSecondColor[iTemp][0] -= 0.02f;
								if(pLevel->fSecondColor[iTemp][0] < 0.0f)
									pLevel->fSecondColor[iTemp][0] = 0.0f;
								pLevel->fSecondColor[iTemp][1] += 0.02f;
								if(pLevel->fSecondColor[iTemp][1] > 1.0f)
									pLevel->fSecondColor[iTemp][1] = 1.0f;
								pLevel->fSecondColor[iTemp][2] -= 0.02f;
								if(pLevel->fSecondColor[iTemp][2] < 0.0f)
									pLevel->fSecondColor[iTemp][2] = 0.0f;
							}
						iTemp = pFieldT->Side[i3].SideQuad[0].iPoint[2];
						pLevel->fColor[iTemp][0] -= 0.5f;
						if(pLevel->fColor[iTemp][0] < 0.0f)
							pLevel->fColor[iTemp][0] = 0.0f;
						pLevel->fColor[iTemp][1] += 0.5f;
						if(pLevel->fColor[iTemp][1] > 1.0f)
							pLevel->fColor[iTemp][1] = 1.0f;
						pLevel->fColor[iTemp][2] -= 0.5f;
						if(pLevel->fColor[iTemp][2] < 0.0f)
							pLevel->fColor[iTemp][2] = 0.0f;

						pLevel->fSecondColor[iTemp][0] -= 0.5f;
						if(pLevel->fSecondColor[iTemp][0] < 0.0f)
							pLevel->fSecondColor[iTemp][0] = 0.0f;
						pLevel->fSecondColor[iTemp][1] += 0.5f;
						if(pLevel->fSecondColor[iTemp][1] > 1.0f)
							pLevel->fSecondColor[iTemp][1] = 1.0f;
						pLevel->fSecondColor[iTemp][2] -= 0.5f;
						if(pLevel->fSecondColor[iTemp][2] < 0.0f)
							pLevel->fSecondColor[iTemp][2] = 0.0f;
					}
				}
			}
		break;

		case AT_BOX_BLUE: // Paint all other actors around this box blue:
			pLevel->State.iDestroyedBlueBoxes++;
   			for(y = -1; y < 2; y++)
			{
				for(x = -1; x < 2; x++)
				{
					if(!pLevel->CheckIfCorrectPos(iFieldPos[X]+x, iFieldPos[Y]+y))
						continue;
					
					// Check the field:
					GET_FIELD_ID((iFieldPos[X]+x), (iFieldPos[Y]+y), i2);
					pFieldT = &pLevel->pField[i2];
					pActorT = pFieldT->pActor;
					if(pActorT)
					{
						if(pActorT->Type == AT_BOX_NORMAL ||
						   pActorT->Type == AT_BOX_RED ||
						   pActorT->Type == AT_BOX_GREEN)
						{
							if(!pActorT->bGoingDeath)
							{
								pActorT->DeleteActorType();
								pActorT->Type = AT_BOX_BLUE;
								pLevel->Header.iBlueBoxes++;
								if(!pActorT->bUseBoxColor)
								{
									pActorT->fColor[0] = 0.2f;
									pActorT->fColor[1] = 0.2f;
									pActorT->fColor[2] = 0.8f;
								}
							}
						}
						else
						{
							pActorT->fColor[0] = 0.0f;
							pActorT->fColor[1] = 0.0f;
							pActorT->fColor[2] = 1.0f;
						}
					}
					if(pFieldT->pItem)
					{
						pActorT = pFieldT->pItem;
						pActorT->fColor[0] = 0.0f;
						pActorT->fColor[1] = 0.0f;
						pActorT->fColor[2] = 1.0f;
					}

					if(pFieldT->pBridgeActor && !pFieldT->pBridgeActor->bGoingDeath &&
					   pFieldT->pBridgeActor->Type != AT_BOX_BLUE)
					{
						pActorT = pFieldT->pBridgeActor;
						pActorT->DeleteActorType();
						pActorT->Type = AT_BOX_BLUE;
						pLevel->Header.iBlueBoxes++;
						pLevel->State.iNoneFreeBlueBoxes++;
					}
					// Make the field blue:
					for(i3 = 0; i3 < 6; i3++)
					{
						for(i4 = 0; i4 < 4; i4++)
							for(i5 = 0; i5 < 4; i5++)
							{
								iTemp = pFieldT->Side[i3].SideQuad[i4].iPoint[i5];
								pLevel->fColor[iTemp][0] -= 0.05f;
								if(pLevel->fColor[iTemp][0] < 0.0f)
									pLevel->fColor[iTemp][0] = 0.0f;
								pLevel->fColor[iTemp][1] -= 0.05f;
								if(pLevel->fColor[iTemp][1] < 0.0f)
									pLevel->fColor[iTemp][1] = 0.0f;
								pLevel->fColor[iTemp][2] += 0.05f;
								if(pLevel->fColor[iTemp][2] > 1.0f)
									pLevel->fColor[iTemp][2] = 1.0f;

								pLevel->fSecondColor[iTemp][0] -= 0.05f;
								if(pLevel->fSecondColor[iTemp][0] < 0.0f)
									pLevel->fSecondColor[iTemp][0] = 0.0f;
								pLevel->fSecondColor[iTemp][1] -= 0.05f;
								if(pLevel->fSecondColor[iTemp][1] < 0.0f)
									pLevel->fSecondColor[iTemp][1] = 0.0f;
								pLevel->fSecondColor[iTemp][2] += 0.05f;
								if(pLevel->fSecondColor[iTemp][2] > 1.0f)
									pLevel->fSecondColor[iTemp][2] = 1.0f;
							}
						iTemp = pFieldT->Side[i3].SideQuad[0].iPoint[2];
						pLevel->fColor[iTemp][0] -= 0.5f;
						if(pLevel->fColor[iTemp][0] < 0.0f)
							pLevel->fColor[iTemp][0] = 0.0f;
						pLevel->fColor[iTemp][1] -= 0.5f;
						if(pLevel->fColor[iTemp][1] < 0.0f)
							pLevel->fColor[iTemp][1] = 0.0f;
						pLevel->fColor[iTemp][2] += 0.5f;
						if(pLevel->fColor[iTemp][2] > 1.0f)
							pLevel->fColor[iTemp][2] = 1.0f;

						pLevel->fSecondColor[iTemp][0] -= 0.5f;
						if(pLevel->fSecondColor[iTemp][0] < 0.0f)
							pLevel->fSecondColor[iTemp][0] = 0.0f;
						pLevel->fSecondColor[iTemp][1] -= 0.5f;
						if(pLevel->fSecondColor[iTemp][1] < 0.0f)
							pLevel->fSecondColor[iTemp][1] = 0.0f;
						pLevel->fSecondColor[iTemp][2] += 0.5f;
						if(pLevel->fSecondColor[iTemp][2] > 1.0f)
							pLevel->fSecondColor[iTemp][2] = 1.0f;
					}
				}
			}
		break;
	}
} // end ACTOR::KillBox()

// Checks if an box is thrown:
BOOL ACTOR::CheckBoxThrow(void)
{ // begin ACTOR::CheckBoxThrow()
	FIELD *pFieldT, *pNextFieldT = NULL;
	ACTOR *pActorT;
	int iX, iY;
	BOOL bStopBox;

	if(!bIsThrown)
		return FALSE; // This box isn't thrown!
	if(bMove)
		return FALSE; // The box is still moving!

	if(fVelocity[X] <= 0.2f)
	{ // The box stand now:
		fVelocity[X] = 0.0f;
		bIsThrown = FALSE;
		return FALSE;
	}

	// Setup x/y direction:
	switch(byDirection)
	{
		case RIGHT: iX = 1; iY = 0; break;
		case DOWN: iX = 0; iY = 1; break;
		case LEFT: iX = -1; iY = 0; break;
		case UP: iX = 0; iY = -1; break;
	}

	if(!pLevel->CheckIfCorrectPos(iFieldPos[X]+iX, iFieldPos[Y]+iY))
		bStopBox = TRUE;
	else
	{
		bStopBox = FALSE;
		GET_FIELD_POINTER(iFieldPos[X]+iX, iFieldPos[Y]+iY, pNextFieldT);
		pActorT = pNextFieldT->pActor;
		if(pActorT && pActorT->Squash())
		{
			if(bCollisionDamage)
				MakeDamage(1.0f);
			bStopBox = TRUE;
		}
	}
	GET_FIELD_POINTER(iFieldPos[X], iFieldPos[Y], pFieldT);

	if((bStopBox || CheckIfWall(byDirection, 1) || pNextFieldT->pActor ||
	  (pNextFieldT->pBridgeActor && pNextFieldT->pBridgeActor->bBridgeMovement)) &&
	  (!pFieldT->bWall || pFieldT->pBridgeActor))
	{ // It's absolutely not possible to move!! Stop the box!
		fPosTemp[X] += (float) iX/10.0f;
		fPosTemp[Y] += (float) iY/10.0f;
		fPosTempVelocity[X] += (float) iX/15.0f;
		fPosTempVelocity[Y] += (float) iY/15.0f;
		if(pNextFieldT && pNextFieldT->pActor)
		{ // A other holds the box: (shock effect)
			pActorT = pNextFieldT->pActor;
			pActorT->fPosTemp[X] += (float) iX/10.0f;
			pActorT->fPosTemp[Y] += (float) iY/10.0f;
			pActorT->fPosTempVelocity[X] += (float) iX/10.0f;
			pActorT->fPosTempVelocity[Y] += (float) iY/10.0f;
	
			// Damage the hit box:
			if(pActorT->bCollisionDamage)
				pActorT->MakeDamage(1.0f);
		};
	
		// Damage the thrown box:
		if(bCollisionDamage)
			MakeDamage(1.0f);
		bIsThrown = FALSE;
		return FALSE;
	}
	
	if(!pFieldT->bWall || pFieldT->bWallHole || pFieldT->pBridgeActor)
	{ // The box fly 'again':
		bMove = TRUE;
		pNextFieldT->pActor = this;
	}
	
	return TRUE;
} // end ACTOR::CheckBoxThrow()

// Disables the box docking:
void ACTOR::DisableBoxDocking(void)
{ // begin ACTOR::DisableBoxDocking()
	if(!bDocked && !bGoingDocked)
		return; // This box isn't docked!
	
	// Check if this actor is really an box:
	if(Type != AT_BOX_NORMAL && Type != AT_BOX_RED && Type != AT_BOX_GREEN && Type != AT_BOX_BLUE)
		return; // It's no box!

	DisableNoneFreeAnchor();
	DisableNoneFreeBox();
	bDocked = FALSE;
	bGoingDocked = FALSE;
} // end ACTOR::DisableBoxDocking()

// Adds an none free box in the level information:
void ACTOR::SetNoneFreeBox(void)
{ // begin ACTOR::SetNoneFreeBox()
	switch(Type)
	{
		case AT_BOX_NORMAL: pLevel->State.iNoneFreeNormalBoxes++; break;
		case AT_BOX_RED: pLevel->State.iNoneFreeRedBoxes++; break;
		case AT_BOX_GREEN: pLevel->State.iNoneFreeGreenBoxes++; break;
		case AT_BOX_BLUE: pLevel->State.iNoneFreeBlueBoxes++; break;
	}
} // end ACTOR::SetNoneFreeBox()

// Deletes an none free box in the level information:
void ACTOR::DisableNoneFreeBox(void)
{ // begin ACTOR::DisableNoneFreeBox()
	switch(Type)
	{
		case AT_BOX_NORMAL: pLevel->State.iNoneFreeNormalBoxes--; break;
		case AT_BOX_RED: pLevel->State.iNoneFreeRedBoxes--; break;
		case AT_BOX_GREEN: pLevel->State.iNoneFreeGreenBoxes--; break;
		case AT_BOX_BLUE: pLevel->State.iNoneFreeBlueBoxes--; break;
	}
} // end ACTOR::DisableNoneFreeBox()

// Adds an none free anchor in the level information:
BOOL ACTOR::SetNoneFreeAnchor(void)
{ // begin ACTOR::SetNoneFreeAnchor()
	SURFACE *pSurfaceT;

	if(!(pSurfaceT = pLevel->pField[iFieldID].Side[FACE_FLOOR].Surface[0].pSurface) ||
	   !pSurfaceT->Header.bAnchor)
		return FALSE;
	switch(pSurfaceT->Header.byAnchorType)
	{
		case 0:	pLevel->State.iUsedForAllAnchors++; break;
		
		case 1:
			if(Type != AT_BOX_NORMAL)
				return FALSE;
			pLevel->State.iUsedNormalAnchors++;
		break;

		case 2:
			if(Type != AT_BOX_RED)
				return FALSE;
			pLevel->State.iUsedRedAnchors++;
		break;
		
		case 3:
			if(Type != AT_BOX_GREEN)
				return FALSE;
			pLevel->State.iUsedGreenAnchors++;
		break;

		case 4:
			if(Type != AT_BOX_BLUE)
				return FALSE;
			pLevel->State.iUsedBlueAnchors++;
		break;
	}

	return TRUE;
} // end ACTOR::SetNoneFreeAnchor()

// Deletes an none free anchor in the level information:
void ACTOR::DisableNoneFreeAnchor(void)
{ // begin ACTOR::DisableNoneFreeAnchor()
	SURFACE *pSurfaceT;

	if(!(pSurfaceT = pLevel->pField[iFieldID].Side[FACE_FLOOR].Surface[0].pSurface) ||
	  !pSurfaceT->Header.bAnchor)
		return;
	switch(pSurfaceT->Header.byAnchorType)
	{
		case 0:	pLevel->State.iUsedForAllAnchors--; break;
		
		case 1:
			if(Type != AT_BOX_NORMAL)
				return;
			pLevel->State.iUsedNormalAnchors--;
		break;

		case 2:
			if(Type != AT_BOX_RED)
				return;
			pLevel->State.iUsedRedAnchors--;
		break;
		
		case 3:
			if(Type != AT_BOX_GREEN)
				return;
			pLevel->State.iUsedGreenAnchors--;
		break;

		case 4:
			if(Type != AT_BOX_BLUE)
				return;
			pLevel->State.iUsedBlueAnchors--;
		break;
	}
} // end ACTOR::DisableNoneFreeAnchor()

void ACTOR::DrawBox(void)
{ // begin ACTOR::DrawBox()
	float fPosT, fBlend, fDensity;
	TEXTURE_POS *pTexturePosT;
	SURFACE *pSurfaceT;
	FLOAT3 fV1, fV2, fV3, fV4;
	FLOAT4 *pColorT, fColorT;
	int i, iAdd;
	
	glPushMatrix();
	fPosT = -(fSize-1.0f)/2;
	if(bDocked)
		glTranslatef(fWorldPos[X]+fPosT, fWorldPos[Y]+fPosT, fWorldPos[Z]-fPosT+fPosTemp[Z]);
	else
		glTranslatef(fWorldPos[X]+fPosT, fWorldPos[Y]+fPosT, fWorldPos[Z]);

	// Set the box color:
	if(fBlendDensity != 1.0f)
	{
		glEnable(GL_BLEND);
		fBlend = fBlendDensity;
		glDepthMask(FALSE);
	}
	else
		fBlend = fBlendDensity;
	if(fBlendDensity != 1.0f)
		fDensity = 1.0f;
	else
		fDensity = (fHealth+10.0f)/100.0f;
	fColorT[R] = fColor[R];
	fColorT[G] = fColor[G];
	fColorT[B] = fColor[B];
	pColorT = &fColorT;
	switch(Type)
	{
		case AT_BOX_NORMAL: glColor4f((*pColorT)[R]*fDensity, (*pColorT)[G]*fDensity, (*pColorT)[B]*fDensity, fBlend); break;
		case AT_BOX_RED: glColor4f((*pColorT)[R]*fDensity, ((*pColorT)[G]-0.2f)*fDensity, ((*pColorT)[B]-0.2f)*fDensity, fBlend); break;
		case AT_BOX_GREEN: glColor4f(((*pColorT)[R]-0.2f)*fDensity, (*pColorT)[G]*fDensity, ((*pColorT)[B]-0.2f)*fDensity, fBlend); break;
		case AT_BOX_BLUE: glColor4f(((*pColorT)[R]-0.2f)*fDensity, ((*pColorT)[G]-0.2f)*fDensity, (*pColorT)[B]*fDensity, fBlend); break;
	}

	// Check if all animation steps are vaild:
	for(i = 0; i < 7; i++)
	{
		if(iBoxSurface[i] == -1)
			continue;
		pSurfaceT = &pLevel->pSurface[iBoxSurface[i]];
		if(iMultiAniStep[i] >= pSurfaceT->Header.iAniSteps)
			iMultiAniStep[i] = 0;
	}

	glTranslatef(0.005f, 0.005f, 0.0f);
	glScalef(fSize-0.01f, fSize-0.01f, fSize-0.01f);
	BeamingScale(2.0f);

	// Draw now the box:
	if(!bGoingDeath)
	{ // Draw an normal box: (All sides are together)
		glBegin(GL_QUADS);
			// Floor face
			pSurfaceT = &pLevel->pSurface[iBoxSurface[FACE_FLOOR]];
			pTexturePosT = &pSurfaceT->pTexturePos[iMultiAniStep[FACE_FLOOR]];
			_AS->BindTexture_InQuads(pSurfaceT->pTexture[iMultiAniStep[FACE_FLOOR]]->iOpenGLID);
			SetupBoxSideDraw(pSurfaceT, TRUE);
			glNormal3f(0.0f, 0.0f, 1.0f);
			DrawBoxSide(1, 2, 3, 0, (byBoxSurfaceRot[FACE_FLOOR]+1) % 4, pTexturePosT);

			// Top face
			pSurfaceT = &pLevel->pSurface[iBoxSurface[FACE_TOP]];
			pTexturePosT = &pSurfaceT->pTexturePos[iMultiAniStep[FACE_TOP]];
			_AS->BindTexture_InQuads(pSurfaceT->pTexture[iMultiAniStep[FACE_TOP]]->iOpenGLID);
			SetupBoxSideDraw(pSurfaceT, TRUE);
			glNormal3f(0.0f, -1.0f, 0.0f);
			DrawBoxSide(4, 5, 1, 0, (byBoxSurfaceRot[FACE_TOP]+2) % 4, pTexturePosT);

			// Left face
			pSurfaceT = &pLevel->pSurface[iBoxSurface[FACE_LEFT]];
			pTexturePosT = &pSurfaceT->pTexturePos[iMultiAniStep[FACE_LEFT]];
			_AS->BindTexture_InQuads(pSurfaceT->pTexture[iMultiAniStep[FACE_LEFT]]->iOpenGLID);
			SetupBoxSideDraw(pSurfaceT, TRUE);
			glNormal3f(-1.0f, 0.0f, 0.0f);
			DrawBoxSide(3, 7, 4, 0, (byBoxSurfaceRot[FACE_LEFT]+1) % 4, pTexturePosT);

			// Right face
			pSurfaceT = &pLevel->pSurface[iBoxSurface[FACE_RIGHT]];
			pTexturePosT = &pSurfaceT->pTexturePos[iMultiAniStep[FACE_RIGHT]];
			_AS->BindTexture_InQuads(pSurfaceT->pTexture[iMultiAniStep[FACE_RIGHT]]->iOpenGLID);
			SetupBoxSideDraw(pSurfaceT, TRUE);
			glNormal3f(1.0f, 0.0f, 0.0f);
			DrawBoxSide(5, 6, 2, 1, (byBoxSurfaceRot[FACE_RIGHT]+2) % 4, pTexturePosT);
			
			// Bottom face
			pSurfaceT = &pLevel->pSurface[iBoxSurface[FACE_BOTTOM]];
			pTexturePosT = &pSurfaceT->pTexturePos[iMultiAniStep[FACE_BOTTOM]];
			_AS->BindTexture_InQuads(pSurfaceT->pTexture[iMultiAniStep[FACE_BOTTOM]]->iOpenGLID);
			SetupBoxSideDraw(pSurfaceT, TRUE);
			glNormal3f(0.0f, 1.0f, 0.0f);
			DrawBoxSide(2, 6, 7, 3, (byBoxSurfaceRot[FACE_BOTTOM]+1) % 4, pTexturePosT);
			
			// Front face
			pSurfaceT = &pLevel->pSurface[iBoxSurface[FACE_FRONT]];
			pTexturePosT = &pSurfaceT->pTexturePos[iMultiAniStep[FACE_FRONT]];
			_AS->BindTexture_InQuads(pSurfaceT->pTexture[iMultiAniStep[FACE_FRONT]]->iOpenGLID);
			SetupBoxSideDraw(pSurfaceT, TRUE);
			glNormal3f(0.0f, 0.0f, -1.0f);
			DrawBoxSide(7, 6, 5, 4, byBoxSurfaceRot[FACE_FRONT], pTexturePosT);
		glEnd();
	}
	else
	{ // Draw an destroyed box: (The sides could fly around)
		glDisable(GL_CULL_FACE);
		for(i = 0; i < 6; i++)
		{
			pSurfaceT = &pLevel->pSurface[iBoxSurface[i]];
			pTexturePosT = &pSurfaceT->pTexturePos[iMultiAniStep[i]];
			_AS->BindTexture(pSurfaceT->pTexture[iMultiAniStep[i]]->iOpenGLID);
			switch(i)
			{
				case FACE_FLOOR:
					fV1[X] = -0.5f; fV1[Y] = -0.5f; fV1[Z] = 0.0f;
					fV2[X] = 0.5f; fV2[Y] = -0.5f; fV2[Z] = 0.0f;
					fV3[X] = 0.5f; fV3[Y] = 0.5f; fV3[Z] = 0.0f;
					fV4[X] = -0.5f; fV4[Y] = 0.5f; fV4[Z] = 0.0f;
					iAdd = 0;
				break;

				case FACE_TOP:
					fV1[X] = 0.5f; fV1[Y] = 0.0f; fV1[Z] = 0.5f;
					fV2[X] = -0.5f; fV2[Y] = 0.0f; fV2[Z] = 0.5f;
					fV3[X] = -0.5f; fV3[Y] = 0.0f; fV3[Z] = -0.5f;
					fV4[X] = 0.5f; fV4[Y] = 0.0f; fV4[Z] = -0.5f;
					iAdd = 0;
				break;

				case FACE_LEFT:
					fV1[X] = 0.0f; fV1[Y] = -0.5f; fV1[Z] = 0.5f;
					fV2[X] = 0.0f; fV2[Y] = 0.5f; fV2[Z] = 0.5f;
					fV3[X] = 0.0f; fV3[Y] = 0.5f; fV3[Z] = -0.5f;
					fV4[X] = 0.0f; fV4[Y] = -0.5f; fV4[Z] = -0.5f;
					iAdd = 0;
				break;

				case FACE_RIGHT:
					fV1[X] = 0.0f; fV1[Y] = 0.5f; fV1[Z] = 0.5f;
					fV2[X] = 0.0f; fV2[Y] = -0.5f; fV2[Z] = 0.5f;
					fV3[X] = 0.0f; fV3[Y] = -0.5f; fV3[Z] = -0.5f;
					fV4[X] = 0.0f; fV4[Y] = 0.5f; fV4[Z] = -0.5f;
					iAdd = 0;
				break;

				case FACE_BOTTOM:
					fV1[X] = 0.5f; fV1[Y] = 0.0f; fV1[Z] = -0.5f;
					fV2[X] = -0.5f; fV2[Y] = 0.0f; fV2[Z] = -0.5f;
					fV3[X] = -0.5f; fV3[Y] = 0.0f; fV3[Z] = 0.5f;
					fV4[X] = 0.5f; fV4[Y] = 0.0f; fV4[Z] = 0.5f;
					iAdd = 2;
				break;

				case FACE_FRONT:
					fV1[X] = -0.5f; fV1[Y] = 0.5f; fV1[Z] = 0.0f;
					fV2[X] = 0.5f; fV2[Y] = 0.5f; fV2[Z] = 0.0f;
					fV3[X] = 0.5f; fV3[Y] = -0.5f; fV3[Z] = 0.0f;
					fV4[X] = -0.5f; fV4[Y] = -0.5f; fV4[Z] = 0.0f;
					iAdd = 0;
				break;
			}
			glPushMatrix();
			SetBoxSideTranslation(i);
			SetupBoxSideDraw(pSurfaceT, FALSE);
			glBegin(GL_QUADS);
				glNormal3f(0.0f, 0.0f, 1.0f);
				DrawBoxSide(fV1, fV2, fV3, fV4, (byBoxSurfaceRot[i]+iAdd) % 4, pTexturePosT);
			glEnd();
			glPopMatrix();
		}
		glEnable(GL_CULL_FACE);
	}					

	if(iBoxSurface[FACE_ENVIRONMENT] != -1)
	{ // Draw the environment texture:
		fBlend = fEnvironmentColor[A]*fBlendDensity;
		glEnable(GL_BLEND);
		glDepthMask(FALSE);
		if(fBlendDensity != 1.0f)
			fDensity = 1.0f;
		else
			fDensity = (fHealth+10.0f)/100.0f;
		pColorT = &fEnvironmentColor;
		switch(Type)
		{
			case AT_BOX_NORMAL: glColor4f((*pColorT)[R]*fDensity, (*pColorT)[G]*fDensity, (*pColorT)[B]*fDensity, fBlend); break;
			case AT_BOX_RED: glColor4f((*pColorT)[R]*fDensity, ((*pColorT)[G]-0.2f)*fDensity, ((*pColorT)[B]-0.2f)*fDensity, fBlend); break;
			case AT_BOX_GREEN: glColor4f(((*pColorT)[R]-0.2f)*fDensity, (*pColorT)[G]*fDensity, ((*pColorT)[B]-0.2f)*fDensity, fBlend); break;
			case AT_BOX_BLUE: glColor4f(((*pColorT)[R]-0.2f)*fDensity, ((*pColorT)[G]-0.2f)*fDensity, (*pColorT)[B]*fDensity, fBlend); break;
		}

		glDepthFunc(GL_EQUAL);
		pSurfaceT = &pLevel->pSurface[iBoxSurface[FACE_ENVIRONMENT]];
		pTexturePosT = &pSurfaceT->pTexturePos[iMultiAniStep[FACE_ENVIRONMENT]];
		_AS->BindTexture(pSurfaceT->pTexture[iMultiAniStep[FACE_ENVIRONMENT]]->iOpenGLID);
		if(!bGoingDeath)
		{ // Draw an normal box: (All sides are together)
			glBegin(GL_QUADS);
				SetupBoxSideDraw(pSurfaceT, TRUE);

				// Floor face
				glNormal3f(0.0f, 0.0f, 1.0f);
				DrawBoxSide(1, 2, 3, 0, (byBoxSurfaceRot[FACE_ENVIRONMENT]+1) % 4, pTexturePosT);

				// Top face
				glNormal3f(0.0f, -1.0f, 0.0f);
				DrawBoxSide(4, 5, 1, 0, (byBoxSurfaceRot[FACE_ENVIRONMENT]+2) % 4, pTexturePosT);

				// Left face
				glNormal3f(-1.0f, 0.0f, 0.0f);
				DrawBoxSide(3, 7, 4, 0, (byBoxSurfaceRot[FACE_ENVIRONMENT]+1) % 4, pTexturePosT);

				// Right face
				glNormal3f(1.0f, 0.0f, 0.0f);
				DrawBoxSide(5, 6, 2, 1, (byBoxSurfaceRot[FACE_ENVIRONMENT]+2) % 4, pTexturePosT);
				
				// Bottom face
				glNormal3f(0.0f, 1.0f, 0.0f);
				DrawBoxSide(2, 6, 7, 3, (byBoxSurfaceRot[FACE_ENVIRONMENT]+1) % 4, pTexturePosT);

				// Front face
				glNormal3f(0.0f, 0.0f, -1.0f);
				DrawBoxSide(7, 6, 5, 4, byBoxSurfaceRot[FACE_ENVIRONMENT], pTexturePosT);
			glEnd();
		}
		else
		{ // Draw an destroyed box: (The sides could fly around)
			glDisable(GL_CULL_FACE);
			
			// Floor face
			glPushMatrix();
			SetBoxSideTranslation(FACE_FLOOR);
			SetupBoxSideDraw(pSurfaceT, FALSE);
			glBegin(GL_QUADS);
				glNormal3f(0.0f, 0.0f, 1.0f);
				DrawBoxSide(1, 2, 3, 0, (byBoxSurfaceRot[FACE_ENVIRONMENT]+1) % 4, pTexturePosT);
			glEnd();
			glPopMatrix();
			
			// Top face
			glPushMatrix();
			SetBoxSideTranslation(FACE_TOP);
			SetupBoxSideDraw(pSurfaceT, FALSE);
			glBegin(GL_QUADS);
				glNormal3f(0.0f, -1.0f, 0.0f);
				DrawBoxSide(4, 5, 1, 0, (byBoxSurfaceRot[FACE_ENVIRONMENT]+2) % 4, pTexturePosT);
			glEnd();
			glPopMatrix();
			
			// Left face
			glPushMatrix();
			SetBoxSideTranslation(FACE_LEFT);
			SetupBoxSideDraw(pSurfaceT, FALSE);
			glBegin(GL_QUADS);
				glNormal3f(-1.0f, 0.0f, 0.0f);
				DrawBoxSide(3, 7, 4, 0, (byBoxSurfaceRot[FACE_ENVIRONMENT]+1) % 4, pTexturePosT);
			glEnd();
			glPopMatrix();
			
			// Right face
			glPushMatrix();
			SetBoxSideTranslation(FACE_RIGHT);
			SetupBoxSideDraw(pSurfaceT, FALSE);
			glBegin(GL_QUADS);
				glNormal3f(1.0f, 0.0f, 0.0f);
				DrawBoxSide(5, 6, 2, 1, (byBoxSurfaceRot[FACE_ENVIRONMENT]+2) % 4, pTexturePosT);
			glEnd();
			glPopMatrix();

			// Bottom face
			glPushMatrix();
			SetBoxSideTranslation(FACE_BOTTOM);
			SetupBoxSideDraw(pSurfaceT, FALSE);
			glBegin(GL_QUADS);
				glNormal3f(0.0f, 1.0f, 0.0f);
				DrawBoxSide(2, 6, 7, 3, (byBoxSurfaceRot[FACE_ENVIRONMENT]+1) % 4, pTexturePosT);
			glEnd();
			glPopMatrix();
			
			// Front face
			glPushMatrix();
			SetBoxSideTranslation(FACE_FRONT);
			SetupBoxSideDraw(pSurfaceT, FALSE);
			glBegin(GL_QUADS);
				glNormal3f(0.0f, 0.0f, -1.0f);
				DrawBoxSide(7, 6, 5, 4, byBoxSurfaceRot[FACE_ENVIRONMENT], pTexturePosT);
			glEnd();
			glPopMatrix();
			
			glEnable(GL_CULL_FACE);
		}
		_AS->SetNormalDepthFunc();
	}
	glPopMatrix();
	glDepthMask(TRUE);
	glDisable(GL_BLEND);
} // end ACTOR::DrawBox()

void ACTOR::CheckBox(BOOL bEditor)
{ // begin ACTOR::CheckBox()
	float fHeight, fHeightT;
	int i, iSide, iElement;
	SURFACE *pSurfaceT;
	FIELD *pFieldT;
	
	if(Type != AT_BOX_NORMAL &&
	   Type != AT_BOX_RED &&
	   Type != AT_BOX_GREEN &&
	   Type != AT_BOX_BLUE)
		return; // This isn't a box!

	// Does the actor beams at the moment?
	if(CheckBeamingProcess())
	{
		fBlendDensity = fBeamingBlend;
		bMoveable = FALSE;
		return;
	}
	bMoveable = TRUE;

	CheckWater(); // Check the water
	CheckInfoText();
	CheckChangeWaterHeight();

	// Check the power:
	if(fHealth <= 0.0f && !fFieldPos[X] && !fFieldPos[Y] && !bEditor)
	{
		fHealth = 0.0f;
		KillBox(); // The box is no longer!
	}
	
	// Calculate the world position of the box:
	GetWorldPos();
	fWorldPos[X] += fPosTemp[X];
	fWorldPos[Y] += fPosTemp[Y];

	// Animate the surfaces of this actor:
	for(i = 0; i < 7; i++)
	{
		if(iBoxSurface[i] == -1)
			continue;
		pSurfaceT = &pLevel->pSurface[iBoxSurface[i]];
		if(ASCheckTimeUpdate(&dwMultiAniTime[i], pSurfaceT->pTexturePos[iMultiAniStep[i]].iTimeToNext))
		{ // It's time for a animation frame update:
			iMultiAniStep[i]++;
			if(iMultiAniStep[i] >= pSurfaceT->Header.iAniSteps)
				iMultiAniStep[i] = 0;
		}
	}

	// Is the box destroyed?
	if(bGoingDeath)
	{ // Yes: (Killing sequenze)
		if(!bDeathRemoved)
		{
			RemoveFromFields();
			bDeathRemoved = TRUE;
		}
		if(pLevel->pField[iFieldID].pActor)
		{
			pLevel->pField[iFieldID].pActor->fLastHeightCheckWorldPos[X] = 
			pLevel->pField[iFieldID].pActor->fLastHeightCheckWorldPos[Y] = -1.0f;
		}
		for(i = 0, iSide = 0; iSide < 6; iSide++)
		{
			pFieldT = pLevel->ComputeHeight(fWorldPos[X]+fTempPos[iSide][X], fWorldPos[Y]+fTempPos[iSide][Y], &fHeight, FACE_FLOOR, FALSE);
			fHeight -= fWorldPos[Z];
			if(!pFieldT || fTempPos[iSide][Z] > fHeight)
			{
				i++;
				continue;
			}
			for(iElement = 0; iElement < 3; iElement++)
			{
				fTempRot[iSide][iElement] += (float) g_lDeltatime/10*fTempRotVelocity[iSide][iElement];
				fTempPos[iSide][iElement] += (float) g_lDeltatime/1000*fTempPosVelocity[iSide][iElement];
			}
			fTempPosVelocity[iSide][Z] += (float) g_lDeltatime/700;
			if(fTempPosVelocity[iSide][Z] > 6.0f)
				fTempPosVelocity[iSide][Z] = 6.0f;
		}
		if(i >= 5)
			fBlendDensity -= (float) g_lDeltatime/10000;
		if(fBlendDensity < 0.0f)
			bActive = FALSE;
		bMoveable = FALSE;
		return;
	}
	else
		fBlendDensity = 1.0f;

	if(bBridge && bBridgeMovement)
	{ // Let the box fall into a gap:	
		pFieldT = pLevel->ComputeHeight(fWorldPos[X]-0.5f, fWorldPos[Y]-0.5f, &fHeight, FACE_FLOOR, TRUE);
		i = 1;
		pFieldT = pLevel->ComputeHeight(fWorldPos[X]+0.5f, fWorldPos[Y]-0.5f, &fHeightT, FACE_FLOOR, TRUE);
		if(pFieldT)
		{
			fHeight += fHeightT;
			i++;
		}
		pFieldT = pLevel->ComputeHeight(fWorldPos[X]+0.5f, fWorldPos[Y]+0.5f, &fHeightT, FACE_FLOOR, TRUE);
		if(pFieldT)
		{
			fHeight += fHeightT;
			i++;
		}
		pFieldT = pLevel->ComputeHeight(fWorldPos[X]-0.5f, fWorldPos[Y]+0.5f, &fHeightT, FACE_FLOOR, TRUE);
		if(pFieldT)
		{
			fHeight += fHeightT;
			i++;
		}
		pFieldT = pLevel->ComputeHeight(fWorldPos[X], fWorldPos[Y], &fHeightT, FACE_FLOOR, TRUE);
		if(pFieldT)
		{
			fHeight += fHeightT;
			i++;
		}
		fHeight /= i;
		if(fWorldPos[Z] > fHeight+1.0f)
		{
			fVelocity[Z] += (float) g_lDeltatime/1500.0f;
			fWorldPos[Z] -= (float) (g_lDeltatime*fVelocity[Z]/100);
			if(fWorldPos[Z] < fHeight+1.0f)
			{ // Now the box is an bridge:
				bBridgeMovement = FALSE;
				fWorldPos[Z] = fHeight+1.0f;
			}
			else
				bBridgeMovement = TRUE;
		}
		else
		{
			fVelocity[Z] += (float)g_lDeltatime/1500.0f;
			fWorldPos[Z] += (float) (g_lDeltatime*fVelocity[Z]/100);
			if(fWorldPos[Z] > fHeight+1.0f)
			{
				bBridgeMovement = FALSE;
				fWorldPos[Z] = fHeight+1.0f;
			}
			else
				bBridgeMovement = TRUE;
		}
	}
	
	// Could this box be moved?
	if(!bBridge && !bMove && !bGoingDeath && !bDeath && !bBridgeMovement)
		bMoveable = TRUE;
	else
		bMoveable = FALSE;

	// Check box movement:
	Move(-1);
	CheckSurface();

	// Should the box be beamed?
	if(CheckForBeaming())
		return;
	
	if(!bMove)
		fFieldPos[X] = fFieldPos[Y] = 0.0f;
	if(fFieldPos[X] || fFieldPos[Y])
	{
		if(bIsThrown)
		{ // The box is thrown:
			if(bUseFriction)
				fVelocity[X] -= ((float) g_lDeltatime/300)*fFriction;
			else
				fVelocity[X] -= (float) g_lDeltatime/300;
			if(fVelocity[X] < 0.2f)
				fVelocity[X] = 0.2f;
		}
		DisableBoxDocking();
		return;
	}

	if(!CheckBoxThrow())
	{	// Does the box fall into a hole?
		pFieldT = &pLevel->pField[iFieldID];
		if((!pFieldT->bActive || (pFieldT->Side[FACE_FLOOR].Surface[0].pSurface &&
			pFieldT->Side[FACE_FLOOR].Surface[0].pSurface->Header.bHole)) &&
			!pFieldT->pBridgeActor)
		{ // YEP, make this box to an bridge:
			if(pFieldT->bNoBridgePossible)
			{ // There couldn't be a bridge!
				bIndestructible = FALSE;
				KillBox();
				return;
			}
			else
			{
				if(bNitroglycerin)
				{ // A nitroglycerin box couldn't be a bridge! (high explosive!!)
					MakeDamage(1.0f);
					return;
				}
				else
				{
					pFieldT->pActor = FALSE;
					pFieldT->pBridgeActor = this;
					bBridge = TRUE;
					bBridgeMovement = TRUE;
					bIsThrown = FALSE;
					SetNoneFreeBox();
					fVelocity[Z] = 0.0f;
					ASPlayFmodSample(pBoxToBridgeSample, FSOUND_LOOP_OFF);
				}
			}
		}
	}
	
	// Check docking:
	if((pSurfaceT = pLevel->pField[iFieldID].Side[FACE_FLOOR].Surface[0].pSurface) &&
	  pSurfaceT->Header.bAnchor && !bMove &&
	  (((pSurfaceT->Header.byAnchorType == 0 || pSurfaceT->Header.byAnchorType == 1) && Type == AT_BOX_NORMAL) ||
	   ((pSurfaceT->Header.byAnchorType == 0 || pSurfaceT->Header.byAnchorType == 2) && Type == AT_BOX_RED) ||
	   ((pSurfaceT->Header.byAnchorType == 0 || pSurfaceT->Header.byAnchorType == 3) && Type == AT_BOX_GREEN) ||
	   ((pSurfaceT->Header.byAnchorType == 0 || pSurfaceT->Header.byAnchorType == 4) && Type == AT_BOX_BLUE)))
	{
		if(!bDocked && !bGoingDocked)
		{
			if(SetNoneFreeAnchor())
			{
				SetNoneFreeBox();
				bGoingDocked = TRUE;
				dwDockedStartTime = g_lGameTimer;
			}
		}
	}
	else
		DisableBoxDocking();

	// Check if we should make the 'fly' animation:
	if(bGoingDocked && bMove)
		dwDockedStartTime = g_lGameTimer;
	if(bGoingDocked && ASCheckTimeUpdate(&dwDockedStartTime, 500))
	{ // The box should now going docked:
		bGoingDocked = FALSE;
		bDocked = TRUE;
		for(i = 0; i < 3; i++)
		{
			fPosTemp[i] = 0.0f;
			fPosTempTo[i] = 0.0f;
			fPosTempVelocity[i] = 0.0f;
		}
	}
	
	// Is the box docked?
	if(bDocked)
	{ // Yep:
		if(bOnScreen)
		{
			for(i = 0; i < 3; i++)
			{
				fPosTemp[i] += fPosTempVelocity[i]*g_lDeltatime/1000.0f;
				if(fPosTemp[i] <= fPosTempTo[i]+0.1f &&
				   fPosTemp[i] >= fPosTempTo[i]-0.1f)
				{ // Change the direction:
					if(fPosTempVelocity[i] > 0.25f)
						fPosTempVelocity[i] = 0.25f;
					if(fPosTempVelocity[i] < -0.25f)
						fPosTempVelocity[i] = -0.25f;
					if(!(rand() % 2))
						fPosTempTo[i] = -(float) (rand() % 200)/1000.0f;
					else
						fPosTempTo[i] = (float) (rand() % 200)/1000.0f;
				}
				else
				{ // Increase the velocity:
					if(fPosTemp[i] < fPosTempTo[i])
						fPosTempVelocity[i] += g_lDeltatime/3000.0f;
					else
						fPosTempVelocity[i] -= g_lDeltatime/3000.0f;
				}
			}
		}
		if(fSize > BOX_DOCKED_SIZE)
		{
			fSize -= g_lDeltatime/2000.0f;
			if(fSize < BOX_DOCKED_SIZE)
			{
				fSize = BOX_DOCKED_SIZE;
				// Get a new position:
				if(!(rand() % 2))
					fPosTempTo[i] = -(float) (rand() % 200)/1000.0f;
				else
					fPosTempTo[i] = (float) (rand() % 200)/1000.0f;
			}
		}
	}
	else
	{
		for(i = 0; i < 3; i++)
		{
			fPosTemp[i] += fPosTempVelocity[i]*g_lDeltatime/1000.0f;
			if(fPosTemp[i] <= 0.05f &&
			   fPosTemp[i] >= -0.05f)
			{ // Set all to zero:
				fPosTemp[i] = fPosTempTo[i] = fPosTempVelocity[i] = 0.0f;
			}
			else
			{ // Increase the velocity:
				if(fPosTemp[i] < fPosTempTo[i])
					fPosTempVelocity[i] += g_lDeltatime/1000.0f;
				else
					fPosTempVelocity[i] -= g_lDeltatime/1000.0f;
			}
		}
		if(fSize < BOX_NORMAL_SIZE)
		{
			fSize += g_lDeltatime/1000.0f;
			if(fSize > BOX_NORMAL_SIZE)
				fSize = BOX_NORMAL_SIZE;
		}
	}

	// Check box type:
	if(pSurfaceT && pSurfaceT->Header.bColorPainter &&
	  ((pSurfaceT->Header.byColorPainterType == 0 && Type != AT_BOX_NORMAL) ||
	   (pSurfaceT->Header.byColorPainterType == 1 && Type != AT_BOX_RED) ||
	   (pSurfaceT->Header.byColorPainterType == 2 && Type != AT_BOX_GREEN) ||
	   (pSurfaceT->Header.byColorPainterType == 3 && Type != AT_BOX_BLUE)))
	{
		DeleteActorType();
		switch(pSurfaceT->Header.byColorPainterType)
		{
			case 0:
				Type = AT_BOX_NORMAL;
				pLevel->Header.iNormalBoxes++;
			break;

			case 1:
				Type = AT_BOX_RED;
				pLevel->Header.iRedBoxes++;
			break;
			
			case 2:
				Type = AT_BOX_GREEN;
				pLevel->Header.iGreenBoxes++;
			break;
			
			case 3:
				Type = AT_BOX_BLUE;
				pLevel->Header.iBlueBoxes++;
			break;
		}
	}

	
	if(bUseBoxColor)
	{ // Check if we should change the box color corresponding its type:
		switch(Type)
		{
			case AT_BOX_NORMAL:
				for(i = 0; i < 3; i++)
					if(fColor[i] < 1.0f)
					{
						fColor[i] += (float) BOX_COLOR_CHANGE_SPEED*g_lDeltatime/10.0f;
						if(fColor[i] > 1.0f)
							fColor[i] = 1.0f;
					}
			break;

			case AT_BOX_RED:
				for(i = 1; i < 3; i++)
					if(fColor[i] > 0.0f)
					{
						fColor[i] -= (float) BOX_COLOR_CHANGE_SPEED*g_lDeltatime/10.0f;
						if(fColor[i] < 0.0f)
							fColor[i] = 0.0f;
					}
				if(fColor[0] < 1.0f)
				{
					fColor[0] += (float) BOX_COLOR_CHANGE_SPEED*g_lDeltatime/10.0f;
					if(fColor[0] > 1.0f)
						fColor[0] = 1.0f;
				}
			break;

			case AT_BOX_GREEN:
				if(fColor[0] > 0.0f)
				{
					fColor[0] -= (float) BOX_COLOR_CHANGE_SPEED*g_lDeltatime/10.0f;
					if(fColor[0] < 0.0f)
						fColor[0] = 0.0f;
				}
				if(fColor[1] < 1.0f)
				{
					fColor[1] += (float) BOX_COLOR_CHANGE_SPEED*g_lDeltatime/10.0f;
					if(fColor[1] > 1.0f)
						fColor[1] = 1.0f;
				}
				if(fColor[2] > 0.0f)
				{
					fColor[2] -= (float) BOX_COLOR_CHANGE_SPEED*g_lDeltatime/10.0f;
					if(fColor[2] < 0.0f)
						fColor[2] = 0.0f;
				}
			break;

			case AT_BOX_BLUE:
				for(i = 0; i < 2; i++)
					if(fColor[i] > 0.0f)
					{
						fColor[i] -= (float) BOX_COLOR_CHANGE_SPEED*g_lDeltatime/10.0f;
						if(fColor[i] < 0.0f)
							fColor[i] = 0.0f;
					}
				if(fColor[2] < 1.0f)
				{
					fColor[2] += (float) BOX_COLOR_CHANGE_SPEED*g_lDeltatime/10.0f;
					if(fColor[2] > 1.0f)
						fColor[2] = 1.0f;
				}
			break;
		}
	}
} // end ACTOR::CheckBox()

void ACTOR::SetBoxSideTranslation(char bySide)
{ // begin ACTOR::SetBoxSideTranslation()
	glTranslatef(fTempPos[bySide][X], fTempPos[bySide][Y], fTempPos[bySide][Z]);
	glRotatef(fTempRot[bySide][X], 1.0f, 0.0f, 0.0f);
	glRotatef(fTempRot[bySide][Y], 0.0f, 1.0f, 0.0f);
	glRotatef(fTempRot[bySide][Z], 0.0f, 0.0f, 1.0f);
} // end ACTOR::SetBoxSideTranslation()

void ACTOR::DrawBoxSide(int iV1, int iV2, int iV3, int iV4, int iRot, TEXTURE_POS *pTexturePosT)
{ // begin ACTOR::DrawBoxSide()
	switch(iRot)
	{
		case 0: // 0
			glTexCoord2fv(pTexturePosT->fPos[6]); glArrayElement(iV1);
			glTexCoord2fv(pTexturePosT->fPos[4]); glArrayElement(iV2);
			glTexCoord2fv(pTexturePosT->fPos[2]); glArrayElement(iV3);
			glTexCoord2fv(pTexturePosT->fPos[0]); glArrayElement(iV4);
			_AS->iTriangles += 2;
		break;

		case 1: // 90
			glTexCoord2fv(pTexturePosT->fPos[4]); glArrayElement(iV1);
			glTexCoord2fv(pTexturePosT->fPos[2]); glArrayElement(iV2);
			glTexCoord2fv(pTexturePosT->fPos[0]); glArrayElement(iV3);
			glTexCoord2fv(pTexturePosT->fPos[6]); glArrayElement(iV4);
			_AS->iTriangles += 2;
		break;

		case 2: // 180
			glTexCoord2fv(pTexturePosT->fPos[2]); glArrayElement(iV1);
			glTexCoord2fv(pTexturePosT->fPos[0]); glArrayElement(iV2);
			glTexCoord2fv(pTexturePosT->fPos[6]); glArrayElement(iV3);
			glTexCoord2fv(pTexturePosT->fPos[4]); glArrayElement(iV4);
			_AS->iTriangles += 2;
		break;

		case 3: // 270
			glTexCoord2fv(pTexturePosT->fPos[0]); glArrayElement(iV1);
			glTexCoord2fv(pTexturePosT->fPos[6]); glArrayElement(iV2);
			glTexCoord2fv(pTexturePosT->fPos[4]); glArrayElement(iV3);
			glTexCoord2fv(pTexturePosT->fPos[2]); glArrayElement(iV4);
			_AS->iTriangles += 2;
		break;
	}
} // end ACTOR::DrawBoxSide()

void ACTOR::DrawBoxSide(FLOAT3 fV1, FLOAT3 fV2, FLOAT3 fV3, FLOAT3 fV4, int iRot, TEXTURE_POS *pTexturePosT)
{ // begin ACTOR::DrawBoxSide()
	switch(iRot)
	{
		case 0: // 0
			glTexCoord2fv(pTexturePosT->fPos[6]); glVertex3fv(fV1);
			glTexCoord2fv(pTexturePosT->fPos[4]); glVertex3fv(fV2);
			glTexCoord2fv(pTexturePosT->fPos[2]); glVertex3fv(fV3);
			glTexCoord2fv(pTexturePosT->fPos[0]); glVertex3fv(fV4);
			_AS->iTriangles += 2;
		break;

		case 1: // 90
			glTexCoord2fv(pTexturePosT->fPos[4]); glVertex3fv(fV1);
			glTexCoord2fv(pTexturePosT->fPos[2]); glVertex3fv(fV2);
			glTexCoord2fv(pTexturePosT->fPos[0]); glVertex3fv(fV3);
			glTexCoord2fv(pTexturePosT->fPos[6]); glVertex3fv(fV4);
			_AS->iTriangles += 2;
		break;

		case 2: // 180
			glTexCoord2fv(pTexturePosT->fPos[2]); glVertex3fv(fV1);
			glTexCoord2fv(pTexturePosT->fPos[0]); glVertex3fv(fV2);
			glTexCoord2fv(pTexturePosT->fPos[6]); glVertex3fv(fV3);
			glTexCoord2fv(pTexturePosT->fPos[4]); glVertex3fv(fV4);
			_AS->iTriangles += 2;
		break;

		case 3: // 270
			glTexCoord2fv(pTexturePosT->fPos[0]); glVertex3fv(fV1);
			glTexCoord2fv(pTexturePosT->fPos[6]); glVertex3fv(fV2);
			glTexCoord2fv(pTexturePosT->fPos[4]); glVertex3fv(fV3);
			glTexCoord2fv(pTexturePosT->fPos[2]); glVertex3fv(fV4);
			_AS->iTriangles += 2;
		break;
	}
} // end ACTOR::DrawBoxSide()

void ACTOR::SetupBoxSideDraw(SURFACE *pSurfaceT, BOOL bRestart)
{ // begin ACTOR::SetupBoxSideDraw()
	return;
	GLboolean bEnvironmentMappingS, bEnvironmentMappingT;

	glGetBooleanv(GL_TEXTURE_GEN_S, &bEnvironmentMappingS);
	glGetBooleanv(GL_TEXTURE_GEN_T, &bEnvironmentMappingT);
	if(bEnvironmentMappingS != pSurfaceT->Header.bEnvironmentMappingS ||
	   pSurfaceT->Header.bEnvironmentMappingT != bEnvironmentMappingT)
	{
		if(bRestart)
			glEnd();
		if(pSurfaceT->Header.bEnvironmentMappingS)
			glEnable(GL_TEXTURE_GEN_S);
		else
			glDisable(GL_TEXTURE_GEN_S);
		if(pSurfaceT->Header.bEnvironmentMappingT)
			glEnable(GL_TEXTURE_GEN_T);
		else
			glDisable(GL_TEXTURE_GEN_T);
		if(bRestart)
			glBegin(GL_QUADS);
	}
} // end ACTOR::SetupBoxSideDraw()

void ACTOR::InitBox(int iX, int iY)
{ // begin ACTOR::InitBox()
	FIELD *pFieldT;
	int i;

	bActive = TRUE;
	fHealth = fMaxHealth = 100.0f;
	iFieldPos[X] = iX;
	iFieldPos[Y] = iY;
	vCollisionEllipsoid = 0.2f;
	bUseBoxColor = TRUE;
	fSize = 1.0f;
	fWeight = 1.1f;
	fEnvironmentColor[R] = 1.0f;
	fEnvironmentColor[G] = 1.0f;
	fEnvironmentColor[B] = 1.0f;
	fEnvironmentColor[A] = 1.0f;
	bThrowable = TRUE;
	fLastHeightCheckWorldPos[X] = -1.0f;
	fLastHeightCheckWorldPos[Y] = -1.0f;
	GET_FIELD_ID(iX, iY, iFieldID);
	pFieldT = &pLevel->pField[iFieldID];
	for(i = 0; i < 7; i++)
	{
		iBoxSurface[i] = pLevel->Header.iBoxSurface[i];
		byBoxSurfaceRot[i] = pLevel->Header.byBoxSurfaceRot[i];
	}
	if(!pFieldT->bActive)
	{
		pFieldT->bActive = TRUE;
		GetWorldPos();
		pFieldT->bActive = FALSE;
	}
	else
		GetWorldPos();
	pFieldT->pActor = this;
} // end ACTOR::InitBox()
//-----------------------------------------------------------------------------
// File: ActorItems.cpp
//-----------------------------------------------------------------------------

#include "..\AS\AS_Engine.h"
#include "..\ModuleHeaders.h"


// Variables: *****************************************************************
ACTOR_TYPE ATList[ITEMS] =
{
	AT_HEALTH_ITEM, AT_HEALTH_INCREASE_ITEM, AT_LIFE_ITEM, AT_PULL_ITEM, AT_CHEST_ITEM,
	AT_STRENGTH_ITEM, AT_WEAPON_ITEM, AT_COIN_ITEM, AT_GHOST_ITEM, AT_TIME_ITEM, AT_STEP_ITEM,
	AT_SPEED_ITEM, AT_WING_ITEM, AT_SHIELD_ITEM, AT_JUMP_ITEM, AT_AIR_ITEM,
	AT_AIR_INCREASE_ITEM, AT_THROW_ITEM, AT_KICK_ITEM, AT_BAG_ITEM, AT_DYNAMITE_ITEM,
};
///////////////////////////////////////////////////////////////////////////////


void ACTOR::DrawItem(void)
{ // begin ACTOR::DrawItem()
	FIELD *pFieldT;
	
	if(!bOnScreen)
	{ // The item isn't visible:
		iCulledObjects++;
		return;
	}
	glCullFace(GL_FRONT);
	pFieldT = &pLevel->pField[iFieldID];
	if(pFieldT->pActor &&
	   pFieldT->pActor->fFieldPos[X] == 0.0f &&
	   pFieldT->pActor->fFieldPos[Y] == 0.0f &&
	   !pFieldT->pActor->bGoingDeath && !pFieldT->pActor->bBeaming &&
	   (pFieldT->pActor->Type == AT_BOX_NORMAL ||
		pFieldT->pActor->Type == AT_BOX_RED ||
		pFieldT->pActor->Type == AT_BOX_GREEN ||
		pFieldT->pActor->Type == AT_BOX_BLUE))
	{ // A box is over this actor... this items is maybe a secret??
		iCulledObjects++;
		return;
	}

	ASEnableLighting();

	// Draw the object:
	glPushMatrix();

	// Calculate the world position of the object:
	GetWorldPos();
	fWorldPos[X] += fPosTemp[X];
	fWorldPos[Y] += fPosTemp[Y];

	if(Type == AT_COIN_ITEM)
		glTranslatef(fWorldPos[X], fWorldPos[Y], fWorldPos[Z]+0.5f-(1.0f/(fSize)));
	else
	if(Type == AT_CHEST_ITEM)
		glTranslatef(fWorldPos[X], fWorldPos[Y], fWorldPos[Z]-0.3f);
	else
		glTranslatef(fWorldPos[X], fWorldPos[Y], fWorldPos[Z]-0.5f);
	glTranslatef(fPosTemp[X], fPosTemp[Y], fPosTemp[Z]);
	glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
	glRotatef(fRot[X], 1.0f, 0.0f, 0.0f);
	glRotatef(fRot[Y], 0.0f, 1.0f, 0.0f);
	glRotatef(fRot[Z], 0.0f, 0.0f, 1.0f);
	glScalef(fSize*0.007f, fSize*0.007f, fSize*0.007f);
	glColor3f(fColor[R], fColor[G], fColor[B]);
	if(_ASConfig->bMultitexturing &&
	   Type == AT_COIN_ITEM || Type == AT_GHOST_ITEM || Type == AT_SPEED_ITEM)
	{ // Render unit 2:
		glActiveTextureARB(GL_TEXTURE1_ARB);
		glEnable(GL_TEXTURE_2D);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		if(Type == AT_SPEED_ITEM)
		{
			if(_AS->iCurrentTexture != DisplayActor[0].iAniStep)
			{
				_AS->iCurrentTexture = DisplayActor[0].iAniStep;
				glBindTexture(GL_TEXTURE_2D, GameTexture[DisplayActor[0].iAniStep].iOpenGLID);
			}
		}
		else
		{
			if(_AS->iCurrentTexture != 20)
			{
				_AS->iCurrentTexture = 20;
				glBindTexture(GL_TEXTURE_2D, GameTexture[20].iOpenGLID);
			}
		}
		glActiveTextureARB(GL_TEXTURE0_ARB);
	}

	switch(Type)
	{
		case AT_HEALTH_ITEM: glCallList(iHealthItemList); break;
		case AT_HEALTH_INCREASE_ITEM: glCallList(iHealthItemList); break;
		case AT_LIFE_ITEM: glCallList(iLifeItemList); break;
		case AT_PULL_ITEM: glCallList(iPullItemList); break;
		case AT_STRENGTH_ITEM: glCallList(iStrengthItemList); break;
		case AT_WEAPON_ITEM: glCallList(iWeaponItemList); break;
		case AT_COIN_ITEM: glCallList(iCoinItemList); break;
		case AT_SPEED_ITEM: glCallList(iSpeedItemList); break;
		case AT_WING_ITEM: glCallList(iWingItemList); break;
		case AT_JUMP_ITEM: glCallList(iJumpItemList); break;
		case AT_THROW_ITEM: glCallList(iThrowItemList); break;
		case AT_KICK_ITEM: glCallList(iKickItemList); break;
		case AT_SHIELD_ITEM: glCallList(iShieldItemList); break;
		case AT_CHEST_ITEM: glCallList(iChestItemList); break;
		case AT_GHOST_ITEM: glCallList(iGhostItemList); break;
		case AT_TIME_ITEM: glCallList(iTimeItemList); break;
		case AT_STEP_ITEM: glCallList(iStepsItemList); break;
		case AT_AIR_ITEM: glCallList(iAirItemList); break;
		case AT_AIR_INCREASE_ITEM: glCallList(iAirItemList); break;
		case AT_BAG_ITEM: glCallList(iBagItemList); break;
		case AT_DYNAMITE_ITEM: glCallList(iDynamiteItemList); break;
	}

	glPopMatrix();
	glCullFace(GL_BACK);

	if(_ASConfig->bMultitexturing)
	{ // Deactivate the second render unit:
		glActiveTextureARB(GL_TEXTURE1_ARB);
		glDisable(GL_TEXTURE_2D);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
		glActiveTextureARB(GL_TEXTURE0_ARB);
	}
} // end ACTOR::DrawItem()

void ACTOR::CheckItem(void)
{ // begin ACTOR::CheckItem()
	AS_PARTICLE *pParticleT;
	int i, i3;
	FLOAT3 fPos;
	
	vCollisionEllipsoid = 0.2f;
	fBlendDensity = 1.0f;
	GetWorldPos();

	// Has the player this object collected?
	if(bGoingDeath)
	{ // Yes: (Killing sequenze)
		fSize -= g_lDeltatime/OBJECT_KILLING_SPEED;
		if(fSize < 0.0f)
		{
			bActive = FALSE;
			pLevel->pField[iFieldID].pItem = FALSE;
		}
		return;
	}

	if(!bOnScreen)
		return;
	if(ASCheckTimeUpdate(&dwAniTime, OBJECTS_ANI_SPEED))
	{
		iAniStep++;
		if(iAniStep > 3)
			iAniStep = 0;
		if(iAniStep < 0)
			iAniStep = 0;
	}
	if(Type == AT_LIFE_ITEM)
	{ // Change the size:
		if(fSize > fPosTempTo[X]+0.001f ||
		   fSize < fPosTempTo[X]-0.001f)
			fPosTempTo[X] = 1.0f+(rand() % 100)/200.0f;
		fSize += (float) g_lDeltatime*fPosTempVelocity[X]/500.0f;
		if(fSize > fPosTempTo[X])
			fPosTempVelocity[X] -= (float) g_lDeltatime/800;
		else
			fPosTempVelocity[X] += (float) g_lDeltatime/800;
		if(fPosTempVelocity[X] > 0.5f)
			fPosTempVelocity[X] = 0.5f;
		if(fPosTempVelocity[X] < -0.5f)
			fPosTempVelocity[X] = -0.5f;
	}
	else
	{
		fSize += (float) g_lDeltatime/1000;
		if(fSize > 1.0f)
			fSize = 1.0f;
	}

	// Rotate the object:
	if(Type != AT_CHEST_ITEM)
		fRot[Y] += (float) g_lDeltatime/OBJECT_ROTATE_SPEED;
	if(Type == AT_SHIELD_ITEM)
	{ // Rotate the shield:		
		for(i = 0; i < 8; i++)
		{
			fShieldRot[X][i] += (float) g_lDeltatime/(10.0f*((i+1)*0.5f));
			fShieldRot[Y][i] += (float) g_lDeltatime/(10.0f*((i+1)*0.5f));
			fShieldRot[Z][i] += (float) g_lDeltatime/(10.0f*((i+1)*0.5f));
		}
	}
	if(Type == AT_WING_ITEM && ASCheckTimeUpdate(&lLastWingSmokeTime, 50))
	{ // Create smoke coming out of Blibs legs:		
		i = ParticleManager.pSystem[PS_PLAYER_WING_SMOKE].GetFreeParticle();
		if(i == -1)
			return;
		pParticleT = &ParticleManager.pSystem[PS_PLAYER_WING_SMOKE].pParticle[i];
		pParticleT->bAlive = TRUE;
		pParticleT->fEngine = (float) 1.0;
		fPos[X] = fWorldPos[X];
		fPos[Y] = fWorldPos[Y];
		fPos[Z] = fWorldPos[Z]-0.2f;
		for(i3 = 0; i3 < 2; i3++)
		{
			if(!(rand() % 2))
				fPos[i3] += (rand() % 100)/600.0f;
			else
				fPos[i3] -= (rand() % 100)/600.0f;
		}
		if(!(rand() % 2))
			fPos[Z] += (rand() % 100)/800.0f;
		else
			fPos[Z] -= (rand() % 100)/800.0f;
		pParticleT->fPos[X] = fPos[X];
		pParticleT->fPos[Y] = fPos[Y];
		pParticleT->fPos[Z] = fPos[Z];
		pParticleT->fColor[0] = 1.0f;
		pParticleT->fColor[1] = 1.0f;
		pParticleT->fColor[2] = 1.0f;
		pParticleT->fDensity = 0.6f;
		pParticleT->fFadeSpeed = 0.005f+(rand() % 100)/10000.0f;
		pParticleT->fSize = (rand() % 1000)/600.0f;
		pParticleT->lLastAnimtationTime = g_lGameTimer;
	}
} // end ACTOR::CheckItem()

// The item is collected by an actor:
BOOL ACTOR::ActorCollectsItem(ACTOR *pActorT, FLOAT3 fWorldPosT, float fRadiusT, BOOL bShowCollectMessage)
{ // begin ACTOR::ActorCollectsItem()
	AS_VECTOR3D vDelta;
	float fDistance;
	char byTemp[256];
	int i;
	
	if(pActorT->bBeaming || pActorT->bDeath || pActorT->bClone)
		return FALSE;

	// Check if the actor really collects this item:
	vDelta.fX = fWorldPosT[X]-(fWorldPos[X]+fPosTemp[X]);
	vDelta.fY = fWorldPosT[Y]-(fWorldPos[Y]+fPosTemp[Y]);
	vDelta.fZ = fWorldPosT[Z]-(fWorldPos[Z]+fPosTemp[Z]);
	fDistance = vDelta.DotProduct();
	float f = (fRadiusT+vCollisionEllipsoid.fX)*
	                (fRadiusT+vCollisionEllipsoid.fX);
	if(fDistance > (fRadiusT+vCollisionEllipsoid.fX)*
	                (fRadiusT+vCollisionEllipsoid.fX))
		return FALSE;// Nope!

	ASPlayFmodSample(pCollectSample, FSOUND_LOOP_OFF);
	bGoingDeath = TRUE;
	switch(Type)
	{
		case AT_HEALTH_ITEM:
			if(!iNumber)
				pActorT->fHealth = 0.0f;
			else
			{
				pActorT->IncreaseItemNumber(AT_HEALTH_ITEM, iNumber);
				pActorT->fHealth += iNumber;
				if(iNumber > 0)
					pActorT->SetAction(AA_HEALTH);
				else
					pActorT->SetAction(AA_PAIN);
			}
			if(bNumberUnlimited)
				pActorT->fHealth = 9999.0f;
		break;

		case AT_HEALTH_INCREASE_ITEM:
			if(!iNumber)
				pActorT->fMaxHealth = 0.0f;
			else
			{
				pActorT->fMaxHealth += iNumber;
				if(iNumber > 0)
					pActorT->SetAction(AA_HEALTH);
				else
					pActorT->SetAction(AA_PAIN);
			}
			if(bNumberUnlimited)
				pActorT->fMaxHealth = 9999.0f;
		break;

		case AT_LIFE_ITEM:
			pActorT->IncreaseItemNumber(AT_LIFE_ITEM, iNumber);
			if(bNumberUnlimited)
				pActorT->Item[AT_LIFE_ITEM].iNumber = 9999;
		break;
		
		case AT_PULL_ITEM:
			pActorT->IncreaseItemNumber(AT_PULL_ITEM, iNumber);
			if(bNumberUnlimited)
				pActorT->Item[AT_PULL_ITEM].bUnlimited = TRUE;
		break;

		case AT_CHEST_ITEM:
			pActorT->IncreaseItemNumber(AT_COIN_ITEM, iNumber);
			if(bNumberUnlimited)
				pActorT->Item[AT_COIN_ITEM].iNumber = 999999;
			for(i = 0; i < ITEMS; i++)
			{
				pActorT->IncreaseItemNumber(ATList[i], Item[i].iNumber);
				if(Item[i].bUnlimited)
					pActorT->Item[i].bUnlimited = TRUE;
			}
		break;
		
		case AT_STRENGTH_ITEM:
			pActorT->IncreaseItemNumber(AT_STRENGTH_ITEM, iNumber);
			pActorT->fStrength = 1.0f;
			if(bNumberUnlimited)
				pActorT->Item[AT_STRENGTH_ITEM].bUnlimited = TRUE;
		break;
		
		case AT_WEAPON_ITEM:
			pActorT->IncreaseItemNumber(AT_WEAPON_ITEM, iNumber);
			if(bNumberUnlimited)
				pActorT->Item[AT_WEAPON_ITEM].bUnlimited = TRUE;
		break;

		case AT_COIN_ITEM:
			pActorT->IncreaseItemNumber(AT_COIN_ITEM, iNumber);
			pLevel->State.iCollectedPoints++;
			if(bNumberUnlimited)
				pActorT->Item[AT_COIN_ITEM].iNumber = 999999;
		break;

		case AT_GHOST_ITEM:
			pActorT->IncreaseItemNumber(AT_GHOST_ITEM, iNumber);
			if(!iNumber)
				pActorT->fGhostModeTime = 0.0f;
			else
			{
				pActorT->bGhostMode = TRUE;
				pActorT->fGhostModeTime = (float) iNumber;
				pActorT->lGhostModeTime = g_lGameTimer;
				pActorT->RemoveFromFields();
				ParticleManager.pSystem[PS_PLAYER_GHOST].bActive = TRUE;
			}
		break;

		case AT_TIME_ITEM:
			pActorT->IncreaseItemNumber(AT_TIME_ITEM, iNumber);
			if(!iNumber)
				pLevel->Missions.iTimeLimit = 0;
			else
				pLevel->Missions.TimeObj(iNumber);
			if(bNumberUnlimited)
				pLevel->Missions.bTimeLimit = FALSE;
		break;

		case AT_STEP_ITEM:
			pActorT->IncreaseItemNumber(AT_STEP_ITEM, iNumber);
			if(!iNumber)
				pLevel->Missions.iStepsLimit = 0;
			else
				pLevel->Missions.StepsObj(iNumber);
			if(bNumberUnlimited)
				pLevel->Missions.bStepsLimit = FALSE;
		break;

		case AT_SPEED_ITEM:
			pActorT->IncreaseItemNumber(AT_SPEED_ITEM, iNumber);
			if(!iNumber)
				pActorT->fSpeedModeTime = 0.0f;
			else
			{
				pActorT->bSpeedMode = TRUE;
				pActorT->fSpeedModeTime = (float) iNumber;
				pActorT->lSpeedModeTime = g_lGameTimer;
				pActorT->fVelocity[0] = PLAYER_MOVE_SPEED/3;
				ParticleManager.pSystem[PS_PLAYER_SPEED].bActive = TRUE;
			}
		break;

		case AT_WING_ITEM:
			pActorT->IncreaseItemNumber(AT_WING_ITEM, iNumber);
			if(!iNumber)
				pActorT->fWingModeTime = 0.0f;
			else
			{
				pActorT->bWingMode = TRUE;
				pActorT->fWingModeTime = (float) iNumber;
				pActorT->lWingModeTime = g_lGameTimer;
			}
		break;

		case AT_SHIELD_ITEM:
			pActorT->IncreaseItemNumber(AT_SHIELD_ITEM, iNumber);
			if(!iNumber)
				pActorT->fShieldModeTime = 0.0f;
			else
			{
				pActorT->bShieldMode = TRUE;
				pActorT->fShieldModeTime = (float) iNumber;
				pActorT->lShieldModeTime = g_lGameTimer;
			}
		break;

		case AT_JUMP_ITEM:
			pActorT->IncreaseItemNumber(AT_JUMP_ITEM, iNumber);
			if(bNumberUnlimited)
				pActorT->Item[AT_JUMP_ITEM].bUnlimited = TRUE;
		break;

		case AT_AIR_ITEM:
			pActorT->IncreaseItemNumber(AT_AIR_ITEM, iNumber);
			if(!iNumber)
				pActorT->fAir = 0.0f;
			else
				pActorT->fAir += (float) iNumber;
			if(bNumberUnlimited)
				pActorT->fAir = 9999.0f;
		break;

		case AT_AIR_INCREASE_ITEM:
			if(!iNumber)
				pActorT->fMaxAir = 0.0f;
			else
				pActorT->fMaxAir += (float) iNumber;
			if(bNumberUnlimited)
				pActorT->fMaxAir = 9999.0f;
		break;

		case AT_THROW_ITEM:
			pActorT->IncreaseItemNumber(AT_THROW_ITEM, iNumber);
			if(bNumberUnlimited)
				pActorT->Item[AT_THROW_ITEM].bUnlimited = TRUE;
		break;

		case AT_KICK_ITEM:
			pActorT->IncreaseItemNumber(AT_KICK_ITEM, iNumber);
			if(bNumberUnlimited)
				pActorT->Item[AT_KICK_ITEM].bUnlimited = TRUE;
		break;

		case AT_BAG_ITEM:
			pActorT->IncreaseItemNumber(AT_COIN_ITEM, iNumber);
			pActorT->IncreaseItemNumber(AT_BAG_ITEM, iNumber);
			pLevel->State.iCollectedPoints++;
			if(bNumberUnlimited)
				pActorT->Item[AT_COIN_ITEM].iNumber = 999999;
		break;

		case AT_DYNAMITE_ITEM:
			pActorT->IncreaseItemNumber(AT_DYNAMITE_ITEM, iNumber);
			if(bNumberUnlimited)
				pActorT->Item[AT_DYNAMITE_ITEM].bUnlimited = TRUE;
		break;

		default:
			return TRUE;
	}
	if(bShowCollectMessage)
	{
		if(iNumber == 1)
			sprintf(byTemp, "%s", byName);
		else
			sprintf(byTemp, "%s (%d)", byName, iNumber);
		ShowSmallMessage(byTemp, 2000);
	}
	if(!iNumber)
		pActorT->SetAction(AA_WRONG);
	
	return TRUE;
} // end ACTOR::ActorCollectsItem()
//-----------------------------------------------------------------------------
// File: ActorLucifer.cpp
//-----------------------------------------------------------------------------

#include "..\AS\AS_Engine.h"
#include "..\ModuleHeaders.h"


extern int iTemp;

void ACTOR::DrawLucifer(void)
{ // begin ACTOR::DrawLucifer()
	if(!bActive)
		return; // The actor isn't active!
	if(!bOnScreen)
	{ // The actor isn't on screen;
		iCulledObjects++;
		return;
	}

	glPushMatrix();
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_CULL_FACE);
	glCullFace(GL_FRONT);
	
	glTranslatef(fWorldPos[X]+fPosTemp[X], fWorldPos[Y]+fPosTemp[Y], fWorldPos[Z]+fPosTemp[Z]);
	glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
	glRotatef(-fRot[Y]-180.0f, 0.0f, 1.0f, 0.0f);
	glScalef(0.015f, 0.015f, 0.015f);
	BeamingScale(1.0f);
	
	if(fBlendDensity != 1.0f)
	{ // The actor is blended:
		glEnable(GL_BLEND);
		glColor4f(1.0f, 1.0f, 1.0f, fBlendDensity);
		glDepthMask(FALSE);
		glDisable(GL_FOG);
	}
	else
		glColor3f(fColor[0], fColor[1], fColor[2]);

	// Bind the actors texture:
	if(iTexture == -1)
		glBindTexture(GL_TEXTURE_2D, ActorTexture[LUCIFER_TEXTURE].iOpenGLID);
	else
		glBindTexture(GL_TEXTURE_2D, pLevel->pTexture[iTexture].iOpenGLID);

	if(_ASConfig->bMultitexturing)
	{ // Render unit 2:
		glActiveTextureARB(GL_TEXTURE1_ARB);
		glEnable(GL_TEXTURE_2D);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		glColor3f(1.0f, 1.0f, 1.0f);
		if(bShieldMode)
			glBindTexture(GL_TEXTURE_2D, GameTexture[DisplayActor[0].iAniStep].iOpenGLID);
		else
			glBindTexture(GL_TEXTURE_2D, GameTexture[20].iOpenGLID);
		glActiveTextureARB(GL_TEXTURE0_ARB);
	}	
	
	if(bMobile)
		iAniStep = iNextAniStep = 0;
	else
		iAniStep = iNextAniStep = 1;

	ASPrecomputeMd2FrameInt(pLuciferModel, iAniStep, iNextAniStep, fAniInterpolation);
	AS_Md2_GetCurrentBoundingBox(pLuciferModel, iAniStep, iNextAniStep, fAniInterpolation, &fModelBoundingBox);
	ASDrawPrecomputedMd2Frame(pLuciferModel);


	if(_ASConfig->bMultitexturing)
	{ // Deactivate the second render unit:
		glActiveTextureARB(GL_TEXTURE1_ARB);
		glDisable(GL_TEXTURE_2D);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
		glActiveTextureARB(GL_TEXTURE0_ARB);
	}
	if(_ASConfig->bDrawBounding)
	{ // Draw the bounding box around Lucifer:
		glColor3f(1.0f, 1.0f, 1.0f);
		ASDrawBoundingBox(fModelBoundingBox);
	}
	glDepthMask(TRUE);
	glCullFace(GL_BACK);
	glDisable(GL_BLEND);
	glPopMatrix();
	if(pLevel->Environment.bFog)
		glEnable(GL_FOG);
} // end ACTOR::DrawLucifer()

void ACTOR::CheckLucifer(BOOL bEditor)
{ // begin ACTOR::CheckLucifer()
	AS_PARTICLE *pParticleT;
	AS_VECTOR3D vV, vN, vVT, vNT;
	AS_MATRIX Mat;
	int i, iNextAniStepT;

	if(!bActive)
		return; // The actor isn't active!

	if(bEditor)
	{ // We are in the editor:
		SetAction(AA_STANDING);
	}

	if(bMobile)
		iAniStep = iNextAniStep = 0;
	else
		iAniStep = iNextAniStep = 1;

	if(bOnScreen)
	{ // Make the fly animation:
		if(bMobile)
		{
			if(!bMove && pTextScript && pTextScript->pManager->bPlayTextScript && pTextScript == pTextScript->pManager->pPlayedTS &&
			   pTextScript->pManager->pTalkToActor == this)
			{ // The actors text script is played at the moment!
				if(pPlayer->iFieldPos[X] > iFieldPos[X])
					byDirection = RIGHT;
				if(pPlayer->iFieldPos[X] < iFieldPos[X])
					byDirection = LEFT;
				if(pPlayer->iFieldPos[Y] > iFieldPos[Y])
					byDirection = DOWN;
				if(pPlayer->iFieldPos[Y] < iFieldPos[Y])
					byDirection = UP;
				SetAction(AA_STANDING);
			}
			for(i = 0; i < 3; i++)
			{
				fPosTemp[i] += fPosTempVelocity[i]*g_lDeltatime/2000.0f;
				if(fPosTemp[i] <= fPosTempTo[i]+0.05f &&
				   fPosTemp[i] >= fPosTempTo[i]-0.05f)
				{ // Change the direction:
					if(fPosTempVelocity[i] > 0.15f)
						fPosTempVelocity[i] = 0.15f;
					if(fPosTempVelocity[i] < -0.15f)
						fPosTempVelocity[i] = -0.15f;
					if(!(rand() % 2))
						fPosTempTo[i] = -(float) (rand() % 200)/1000.0f;
					else
						fPosTempTo[i] = (float) (rand() % 200)/1000.0f;
				}
				else
				{ // Increase the velocity:
					if(fPosTemp[i] < fPosTempTo[i])
						fPosTempVelocity[i] += g_lDeltatime/3000.0f;
					else
						fPosTempVelocity[i] -= g_lDeltatime/3000.0f;
				}
			}

			// Setup its thrust particles:
			if(iParticleSystemID == -1)
			{
				iParticleSystemID = ParticleManager.AddNewSystem(PS_Smoke2, 50, this, &GameTexture[12], NULL);
				ParticleManager.pSystem[iParticleSystemID].bActive = TRUE;
				ParticleManager.pSystem[iParticleSystemID].fStartPos[X] = fWorldPos[X]+fPosTemp[X];
				ParticleManager.pSystem[iParticleSystemID].fStartPos[Y] = fWorldPos[Y]+fPosTemp[Y];
				ParticleManager.pSystem[iParticleSystemID].fStartPos[Z] = fWorldPos[Z]+fPosTemp[Z]-0.5f;
				ParticleManager.pSystem[iParticleSystemID].pActor = this;
				ParticleManager.pSystem[iParticleSystemID].iVertex = 1;
			}
			
			// Update the blinking light:
			fPeepBlend -= (float) g_lDeltatime/1400;
			if(fPeepBlend <= 0.0f)
			{
				fPeepBlend = 0.0f;
				bPeepStep = FALSE;
			}
		}
		else
		{
			for(i = 0; i < 3; i++)
			{
				fPosTemp[i] += fPosTempVelocity[i]*g_lDeltatime/1000.0f;
				if(fPosTemp[i] <= 0.10f &&
				   fPosTemp[i] >= -0.10f)
				{ // Set all to zero:
					fPosTemp[i] = fPosTempTo[i] = fPosTempVelocity[i] = 0.0f;
				}
				else
				{ // Increase the velocity:
					if(fPosTemp[i] < fPosTempTo[i])
						fPosTempVelocity[i] += g_lDeltatime/2000.0f;
					else
						fPosTempVelocity[i] -= g_lDeltatime/2000.0f;
				}
			}

			// Update the blinking light:
			if(!bPeepStep)
			{
				fPeepBlend += (float) g_lDeltatime/100;
				if(fPeepBlend >= 1.0f)
				{
					fPeepBlend = 1.0f;
					bPeepStep = TRUE;
				}
			}
			else
			{
				fPeepBlend -= (float) g_lDeltatime/1400;
				if(fPeepBlend <= 0.0f)
				{
					fPeepBlend = 0.0f;
					bPeepStep = FALSE;
				}
			}
		}

		// Update the particles:
		pParticleT = &ParticleManager.pSystem[PS_LIGHTS].pParticle[2];
		ASGetMd2Vertex(pLuciferModel, iAniStep, iNextAniStep, fAniInterpolation, fWorldPos,
					   0.015f, -90.0f, fRot[Y]-90.0f, 0.0f, 478, &pParticleT->fPos);
		pParticleT->bAlive = TRUE;
		pParticleT->fEngine = 1.0f;
		pParticleT->fColor[0] = 1.0f*fPeepBlend;
		pParticleT->fColor[1] = 1.0f*fPeepBlend;
		pParticleT->fColor[2] = 1.0f*fPeepBlend;
		pParticleT->fSize = 5.0f;
		pParticleT->fDensity = 0.99f;
	}

	// Setup animation speed factor:
	if(!bSpeedMode)
		fAniSpeedFactor = 1.0f;
	else
		fAniSpeedFactor = 6.0f;	
	if(Action == AA_SHOOTING || Action == AA_DEATH)
		fAniSpeedFactor /= 1.5f;
	fRealAniSpeed = fAniSpeed/fAniSpeedFactor;

	if(!bDeath)
		AnimateModel(pX3Model);
	Check(bEditor); // Do general actor checks

	if(bEditor || bCameraAnimation)
		return;

	iNextAniStepT = iAniStep+1;
	if(iNextAniStepT >= pLuciferModel->Ani.anim[byAnimation].lastFrame)
	{
		if(Action == AA_FUNNY || Action == AA_STANDING ||
		   Action == AA_SHOOTING || Action == AA_PAIN)
			SetAction(AA_NOTHING);
	}

	if(CheckBeamingProcess())
		return; // We are beamed at the moment!
	CheckWater(); // Check the water

	if(!CheckForBeaming())
	{
		if(!pLevel->State.bLevelComplete)
			CheckSurface(); // Check the surface were the actor is on
	}

	if(!CheckTurning(g_lDeltatime/PLAYER_TURN_SPEED*fTurningSpeed))
	{ // Move the actor:
		Move(-1);
	}
	else
		return;

	if(Action == AA_FUNNY ||
	   Action == AA_SHOOTING || Action == AA_PAIN)
		return;

	if(bMove)
		return;
	bMoveable = FALSE;

	if(bShieldMode || bGhostMode)
		bSquashable = FALSE;
	else
		bSquashable = TRUE;

	if(!bMobile)
	{
		SetAction(AA_STANDING);
		return;
	}
} // end ACTOR::CheckLucifer()
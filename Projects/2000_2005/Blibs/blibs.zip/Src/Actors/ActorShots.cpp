//-----------------------------------------------------------------------------
// File: ActorShots.cpp
//-----------------------------------------------------------------------------

#include "..\AS\AS_Engine.h"
#include "..\ModuleHeaders.h"


void ACTOR::DrawShot1(void)
{ // begin ACTOR::DrawShot1()
	if(!bOnScreen)
	{ // The shot isn't visible:
		iCulledObjects++;
		return;
	}

	// Draw the object:
	glPushMatrix();
	glTranslatef(fWorldPos[X], fWorldPos[Y], fWorldPos[Z]);
	glRotatef(fRot[X], 1.0f, 0.0f, 0.0f);
	glRotatef(fRot[Y], 0.0f, 1.0f, 0.0f);
	glRotatef(fRot[Z], 0.0f, 0.0f, 1.0f);
	glScalef(fSize*0.2f, fSize*0.2f, fSize*0.2f);
	glBindTexture(GL_TEXTURE_2D, GameTexture[iAniStep].iOpenGLID);
	glColor3f(fColor[0], fColor[1], fColor[2]);
	glScalef(0.15f, 0.15f, 0.15f);
	glCallList(iPlayerShotItemList);
	glPopMatrix();
} // end ACTOR::DrawShot1()

void ACTOR::CheckShot1(void)
{ // begin ACTOR::CheckShot1()
	AS_VECTOR3D vSourcePoint, vN, vERadius, vVT, vNT, vV;
	FIELD_DECORATION *pDecorationT;
	AS_MD2_MODEL *pModelT;
	int iField, iX, iY, i;
	AS_MATRIX Mat;
	ACTOR *pActorT;
	FIELD *pFieldT;
	FLOAT3 fPosT;
	
	// Animate the object:
	dwAniDeltaTime = g_lGameTimer-pPlayer->dwAniTime;
	if(ASCheckTimeUpdate(&dwAniTime, OBJECTS_ANI_SPEED))
	{
		dwAniTime = g_lGameTimer;
		iAniStep++;
		if(iAniStep > 3)
			iAniStep = 0;
		if(iAniStep < 0)
			iAniStep = 0;
	}

	// Setup x/y direction:
	switch(byDirection)
	{
		case LEFT: iX = -1; iY = 0; break;
		case UP: iX = 0; iY = -1; break;
		case RIGHT: iX = 1; iY = 0; break;
		case DOWN: iX = 0; iY = 1; break;
	}

	// Rotate the object:
	fRot[X] += (float) g_lDeltatime/SHOT_ROTATE_SPEED*10;
	fRot[Y] += (float) g_lDeltatime/SHOT_ROTATE_SPEED*10;
	fRot[Z] += (float) g_lDeltatime/SHOT_ROTATE_SPEED*10;
   	if(bGoingDeath)
	{ // Yes: (Killing sequenze)
		fSize -= g_lDeltatime/SHOT_KILLING_SPEED;
		if(fSize < 0.0f)
		{
			bActive = FALSE;
			if(iTempFieldID >= 0)
				ParticleManager.pSystem[iTempFieldID].bGoingInActive = TRUE;
		}
		return;
	}
	// Move the shot:
	fPosTemp[X] = fWorldPos[X];
	fPosTemp[Y] = fWorldPos[Y];
	fPosTemp[Z] = fWorldPos[Z];
	if(byDirection == RIGHT)
		fWorldPos[X] += (float) g_lDeltatime/PLAYER_SHOT_SPEED;
	else
	if(byDirection == DOWN)
		fWorldPos[Y] += (float) g_lDeltatime/PLAYER_SHOT_SPEED;
	else
	if(byDirection == LEFT)
		fWorldPos[X] -= (float) g_lDeltatime/PLAYER_SHOT_SPEED;
	else
	if(byDirection == UP)
		fWorldPos[Y] -= (float) g_lDeltatime/PLAYER_SHOT_SPEED;
	if(fWorldPos[X] < 0.0f-1.0f/2 || 
	   fWorldPos[Y] < 0.0f-1.0f/2 ||
	   fWorldPos[X] > pLevel->Header.fWholeWidth ||
	   fWorldPos[Y] > pLevel->Header.fWholeHeight)
	{ // The shot is now outside of the level:
		bGoingDeath = TRUE;
		ASPlayFmodSample(pBlibsShotDeathSample, FSOUND_LOOP_OFF);
		return;
	}
	COMPUTE_FIELD_POS(fWorldPos[X], fWorldPos[Y], iFieldPos[X], iFieldPos[Y]);
	GET_FIELD_ID(iFieldPos[X], iFieldPos[Y], iFieldID)
	
	// Check if the shot has hit something in the level:
	vSourcePoint = fWorldPos;
  	vN.fX = fWorldPos[X]-fPosTemp[X];
    vN.fY = fWorldPos[Y]-fPosTemp[Y];
	vN.fZ = fWorldPos[Z]-fPosTemp[Z];
	vERadius = 0.05f;
	// Check if the shot hits an other actor: (eg. an enemy)
    for(i = 0; i < pLevel->Header.iMaxActors; i++)
	{
		pActorT = pLevel->pActorList[i];
		if(!pActorT->bActive || pActorT->bDeath || pActorT->bGoingDeath)
			continue;
		switch(pActorT->Type)
		{
			case AT_MOBMOB:
				// Transform the ray into the model space:
				glLoadIdentity();
				glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
				glRotatef(-pActorT->fRot[Y], 0.0f, 1.0f, 0.0f);
				glGetFloatv(GL_MODELVIEW_MATRIX, Mat.fM);
				fPosT[X] = pActorT->fWorldPos[X];
				fPosT[Y] = pActorT->fWorldPos[Y];
				fPosT[Z] = pActorT->fWorldPos[Z]-0.7f;
				vVT = Mat.Transform(vSourcePoint-fPosT)*(1/0.03f);
				vNT = Mat.Transform(vN)*(1/0.03f);
				if(ASRaySphereIntersectMd2(pMobmobModel,
										   pActorT->iAniStep, pActorT->iNextAniStep,
										   pActorT->fAniInterpolation,
										   vVT, vNT, 0.2f, &pActorT->fModelBoundingBox))
				{ // We hit an actor!!
					ASPlayFmodSample(pBlibsShotDeathSample, FSOUND_LOOP_OFF);
       				bGoingDeath = TRUE;
					pActorT->MakeDamage(1.0f);
					pActorT->fColor[1] -= 0.4f;
					if(pActorT->fColor[1] < 0.0f)
						pActorT->fColor[1] = 0.0f;
					pActorT->fColor[2] -= 0.4f;
					if(pActorT->fColor[2] < 0.0f)
						pActorT->fColor[2] = 0.0f;
				}
			break;

			case AT_X3:
				// Transform the ray into the model space:
				glLoadIdentity();
				glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
				glRotatef(-pActorT->fRot[Y], 0.0f, 1.0f, 0.0f);
				glGetFloatv(GL_MODELVIEW_MATRIX, Mat.fM);
				fPosT[X] = pActorT->fWorldPos[X];
				fPosT[Y] = pActorT->fWorldPos[Y];
				fPosT[Z] = pActorT->fWorldPos[Z]-0.45f;
				vVT = Mat.Transform(vSourcePoint-fPosT)*1/0.02f;
				vNT = Mat.Transform(vN)*1/0.02f;
				if(ASRaySphereIntersectMd2(pX3Model,
										   pActorT->iAniStep, pActorT->iNextAniStep,
										   pActorT->fAniInterpolation,
										   vVT, vNT, 0.2f, &pActorT->fModelBoundingBox))
				{ // We hit an actor!!
					ASPlayFmodSample(pBlibsShotDeathSample, FSOUND_LOOP_OFF);
       				bGoingDeath = TRUE;
					pActorT->MakeDamage(1.0f);
					pActorT->fColor[0] -= 0.4f;
					if(pActorT->fColor[0] < 0.0f)
						pActorT->fColor[0] = 0.0f;
					pActorT->fColor[1] -= 0.4f;
					if(pActorT->fColor[1] < 0.0f)
						pActorT->fColor[1] = 0.0f;
					pActorT->fColor[2] -= 0.4f;
					if(pActorT->fColor[2] < 0.0f)
						pActorT->fColor[2] = 0.0f;
				}
			break;

			case AT_LUCIFER:
				// Transform the ray into the model space:
				glLoadIdentity();
				glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
       			glRotatef(pActorT->fRot[Y], 0.0f, 1.0f, 0.0f);
				glGetFloatv(GL_MODELVIEW_MATRIX, Mat.fM);
				fPosT[X] = pActorT->fWorldPos[X]+pActorT->fPosTemp[X];
       			fPosT[Y] = pActorT->fWorldPos[Y]+pActorT->fPosTemp[Y];
				fPosT[Z] = pActorT->fWorldPos[Z]+pActorT->fPosTemp[Z];
				vVT = Mat.Transform(vSourcePoint-fPosT)*1/0.015f;
				vNT = Mat.Transform(vN)*1/0.015f;
				if(ASRaySphereIntersectMd2(pLuciferModel,
										   pActorT->iAniStep, pActorT->iNextAniStep,
										   pActorT->fAniInterpolation,
										   vVT, vNT, 0.2f, &pActorT->fModelBoundingBox))
				{ // We hit an actor!!
					ASPlayFmodSample(pBlibsShotDeathSample, FSOUND_LOOP_OFF);
       				bGoingDeath = TRUE;
					if(pActorT->bMobile)
					{
						pActorT->fPosTemp[X] += (float) iX/5.0f;
						pActorT->fPosTemp[Y] += (float) iY/5.0f;
					}
					pActorT->MakeDamage(1.0f);
					pActorT->fColor[0] -= 0.4f;
					if(pActorT->fColor[0] < 0.0f)
						pActorT->fColor[0] = 0.0f;
					pActorT->fColor[1] -= 0.4f;
					if(pActorT->fColor[1] < 0.0f)
						pActorT->fColor[1] = 0.0f;
					pActorT->fColor[2] -= 0.4f;
					if(pActorT->fColor[2] < 0.0f)
						pActorT->fColor[2] = 0.0f;
				}
			break;
}
	}
	if((pFieldT = pLevel->CheckCollision(vSourcePoint, vERadius, vN)))
	{
		ASPlayFmodSample(pBlibsShotDeathSample, FSOUND_LOOP_OFF);
		bGoingDeath = TRUE;
	}
	
	if(bGoingDeath)
		return;
	pFieldT = &pLevel->pField[iFieldID];
      pActorT = pFieldT->pActor;
	if(pActorT &&
	   (pActorT->Type == AT_BOX_NORMAL ||
	    pActorT->Type == AT_BOX_RED ||
		pActorT->Type == AT_BOX_GREEN ||
		pActorT->Type == AT_BOX_BLUE))
	{ // We hit a wall:
		// Does we hit a box?
		if(!pActorT->bGoingDeath &&
		   fWorldPos[Z] < pActorT->fWorldPos[Z]+0.1f &&
           fWorldPos[Z] > pActorT->fWorldPos[Z]-1.1f)
		{ // Yes. Make damage:
			bGoingDeath = TRUE;
			ASPlayFmodSample(pBlibsShotDeathSample, FSOUND_LOOP_OFF);
			pActorT = pFieldT->pActor;
		   // Make the shock effect:
         	pActorT->fPosTemp[X] += (float) iX/10.0f;
			pActorT->fPosTemp[Y] += (float) iY/10.0f;
			pActorT->fPosTempVelocity[X] += (float) iX/10.0f;
			pActorT->fPosTempVelocity[Y] += (float) iY/10.0f;
			pActorT->MakeDamage(1.0f);
		}
	}

	// Did we hit a bridge box?
	pActorT = pFieldT->pBridgeActor;
	if(pActorT && !pActorT->bGoingDeath &&
	   fWorldPos[Z] < pActorT->fWorldPos[Z] &&
  	   fWorldPos[Z] > pActorT->fWorldPos[Z]-1.0f)
	{ // Yes. Make damage:
		bGoingDeath = TRUE;
		ASPlayFmodSample(pBlibsShotDeathSample, FSOUND_LOOP_OFF);
	   // Make the shock effect:
		pActorT->fPosTemp[X] += (float) iX/10.0f;
		pActorT->fPosTemp[Y] += (float) iY/10.0f;
		pActorT->fPosTempVelocity[X] += (float) iX/10.0f;
		pActorT->fPosTempVelocity[Y] += (float) iY/10.0f;
		pActorT->MakeDamage(1.0f);
	}
	
	// Check if the shot ray hits an decoration:
    for(iField = 0; iField < pLevel->Header.iFields; iField++)
	{
		pFieldT = &pLevel->pField[iField];
		if(!pFieldT)
			break;
		if(!pFieldT->pDecoration)
			continue;
		pDecorationT = pFieldT->pDecoration;
		pModelT = pDecorationModels[pDecorationT->iDecorationID].pModel;
		if(!pModelT)
			continue;

		// Transform the ray into the model space:
		glLoadIdentity();
		glRotatef(pDecorationT->fRot[X], 1.0f, 0.0f, 0.0f);
      	glRotatef(pDecorationT->fRot[Y], 0.0f, 1.0f, 0.0f);
		glRotatef(pDecorationT->fRot[Z], 0.0f, 0.0f, 1.0f);
		glGetFloatv(GL_MODELVIEW_MATRIX, Mat.fM);
		vVT = Mat.Transform(vSourcePoint-pDecorationT->fPos)*1/pDecorationT->fSize;
		vNT = Mat.Transform(vN)*1/pDecorationT->fSize;
		if(ASRaySphereIntersectMd2(pModelT,
								   pDecorationT->iAniStep, pDecorationT->iNextAniStep,
								   pDecorationT->fModelInterpolation,
								   vVT, vNT, 0.2f, &pDecorationT->fModelBoundingBox))
		{ // We hit an decoration!!
			ASPlayFmodSample(pBlibsShotDeathSample, FSOUND_LOOP_OFF);
      		bGoingDeath = TRUE;
		}
	}
} // end ACTOR::CheckShot1()
//-----------------------------------------------------------------------------
// File: Sound.h
//-----------------------------------------------------------------------------

#ifndef __AS_SOUND_H__
#define __AS_SOUND_H__


// Definitions: ***************************************************************
#define GAME_SAMPLES 21 // The number of sounds
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern char byCurrentMusic[256];
extern AS_FMOD_SAMPLE GameSample[GAME_SAMPLES];
extern AS_FMOD_SAMPLE *pCollectSample, *pChangeSample, *pBlibsShotSample,
					  *pBeamerSample, *pExplosion1Sample, *pSelectSample,
					  *pBlibsDeathSample, *pMobmobDeathSample,
			  		  *pBlibsShotDeathSample, *pBoxToBridgeSample,
					  *pBlibsJumpSample, *pBoxDeathSample,
					  *pBlibsWrongSample, *pMobmobAttackSample, *pBlibsPainSample,
					  *pInputSample, *pPeepSample, *pBlibsKickSample,
					  *pLuciferDamageSample, *pLuciferLaughSample,
					  *pShieldHitSample;
extern AS_FMOD_MUSIC GameMusic;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern void LoadSamples(void);
extern void StartCurrentMusic(void);
extern void RestartSoundSystem(void);
extern void StartMusic(char *);
extern void StopMusic(void);
extern void CheckMusic(void);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_SOUND_H__
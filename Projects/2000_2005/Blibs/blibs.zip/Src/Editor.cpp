//-----------------------------------------------------------------------------
// File: Editor.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"

extern BOOL bTemp;

// Variables: *****************************************************************
extern int iCurrentEditorTab;
HWND hWndEditorShow;	   // The window handle for the level view window
HDC hDCEditorShow;		   // Private GDI device context for the level view window
HGLRC hRCEditorShow;	   // Permanent rendering context for the level view window
BOOL bEditorTestLevel,	   // Do we test a level at the moment?
	 bCameraAnimation,	   // Should we play a camera script?
 	 bAdvancedTerrainManipulation, // Is it possible to manipulate all level vertices??
	 bTerrainChange;	   // Should the terrain be updated?
char byEditorBrushSize,    // The brush size (radius)
     byEditorMenu,		   // The selected menu (in the editor dialog)
	 byEditorSelected,	   // The selected action (e.g. set a wall, set a object...)
	 byEditorSelectedID,   // The selected ID (e.g. from a field, object...)
	 byCurrentSkyCubeSide, // The selected sky-cube side
	 iEditorRotate;		   // The selected rotation (e.g. for surface rotating)
int iEditorObjectsNumber,  // The number of objects
	iEditorCurrentSurfaceType; // The selected surface (first or second)
long lCameraTimer,		   // The time variable for the camera script animation
	 lEditorLastLevelUpdate;
int iFieldX, iFieldY,	   // The position of the current selected field (were the mouse is over)
	iPointX, iPointY;	   // The position of the current selected point (were the mouse is over)
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern LRESULT CALLBACK EditorProc(HWND, UINT, WPARAM, LPARAM);
HRESULT Editor(void);
HRESULT EditorDraw(void);
HRESULT EditorCheck(void);
void SetupMiddlePoints(int, int, int, float *);
void SetupMiddlePoints(int, int, int, FLOAT3 *, int);
void SetupMiddlePoints(int, int, int, FLOAT4 *, int);
void SetupMiddlePoints(int, int, int, int, int, FLOAT3 *, int);
void SetupMiddlePoints(int, int, int, int, int, FLOAT4 *, int);
void ManipulateColor(FLOAT3 *, float, BOOL);
void ManipulateColor(FLOAT4 *, float, BOOL);
void ManipulateDensity(FLOAT *, float, BOOL);
void ManipulateDensity(FLOAT4 *, float, BOOL);
///////////////////////////////////////////////////////////////////////////////


HRESULT Editor(void)
{ // begin Editor()
	_AS->WriteLogMessage("Enter editor module");

/*	sprintf(byCurrentLevelName, "d:\\Blibs\\Data\\SingleLevels\\1.lev");
	bEditorTestLevel = TRUE;
	_AS->SetNextModule(MODULE_GAME);
	return 0;*/


	// Open now the editor dialog:
	DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR), NULL, (DLGPROC) EditorProc);
	_AS->WriteLogMessage("Left editor module");
	
	return 0;
} // end Editor()

HRESULT EditorDraw(void)
{ // begin EditorDraw()
	// Check if we should update the level view window:
	if(hWndSurfaces || hWndSurface || hWndTextures ||
	   !wglMakeCurrent(hDCEditorShow, hRCEditorShow) ||
	   !_AS->bDraw)
		return 0;

	glDepthMask(GL_TRUE);
	if(!pLevel->Environment.bSkyCube)
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	else
		glClear(GL_DEPTH_BUFFER_BIT);
	SetCameraTranslation(TRUE);
	pLevel->DrawSkyCube();

	// Draw the level:
	glEnable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);
	SetCameraTranslation(FALSE);
	ASExtractFrustum();
	pLevel->UpdateVisibilityInformation();
	ASEnableLighting();
	pLevel->InitLevelDraw();
	pLevel->Draw(TRUE);
	pLevel->DrawActors();
	pLevel->DrawWater();
	pLevel->DrawTransparent();
	glDisable(GL_FOG);
	pLevel->DrawLightMaps();
	pLevel->DrawShadowMaps();
	ParticleManager.Draw(TRUE);
	if(pLevel->Environment.bFog)
		glEnable(GL_FOG);
	pLevel->DrawActorEffects();
	pLevel->DrawOther(TRUE);

	// Draw a temporary background. (for mouse pos checking...)
	glEnable(GL_BLEND);
	glEnable(GL_DEPTH_TEST);
	glColor4f(0.0f, 0.0f, 0.0f, 0.01f);
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_CULL_FACE);
	glDisable(GL_LIGHTING);
	glBegin(GL_QUADS);
		glVertex3d(-5.0f, -5.0f, 0.0f);
		glVertex3d(-5.0f, (pLevel->Header.iHeight+6), 0.0f);
		glVertex3d((pLevel->Header.iWidth+6), (pLevel->Header.iHeight+6), 0.0f);
		glVertex3d((pLevel->Header.iWidth+6), -5.0f, 0.0f);
	glEnd();
	glEnable(GL_CULL_FACE);
	glDisable(GL_BLEND);
	ASEnableLighting();

	glDisable(GL_LIGHTING);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.f, (GLfloat)_ASConfig->iWindowWidth/(GLfloat)_ASConfig->iWindowHeight, 0.1f, 100.0f);
	glMatrixMode(GL_MODELVIEW);
	DrawUnderWaterBlend();

//	char byTemp[256];

	// Show text:	
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glColor4f(1.0f, 1.0f, 1.0f, 0.95f);
//	sprintf(byTemp, "fx: %f, fy: %f    x: %d  y: %d", fX, fY, iFieldX, iFieldY);
// ASPrint(100, 10, byTemp, 0);

	if(fPauseTextBlend)
	{
		glColor4f(1.0f, 1.0f, 1.0f, fPauseTextBlend);
		ASPrint(280, 460, AS_T(T_Pause), 0);
	}

	pLevel->DeInitLevelDraw();
	ASSwapBuffers(hDCEditorShow, NULL, TRUE);

	return FALSE;
} // end EditorDraw()

HRESULT EditorCheck(void)
{ // begin EditorCheck()
	char byColor, byColors;
	BOOL bTop, bMiddle, bFloor, bWater, bFieldChange = 0, iSurface,
		 bNoneAdvanced;
	int i, i2, iX, iY, iXT, iYT, iSize, iFloorPointT, iMiddlePointT,
		iTopPointT;
	float fDepth, fTopMiddle, fMiddleMiddle, fFloorMiddle, fWaterMiddle, fGreatestTopHeight,
		  fLowestTopHeight, fGreatestMiddleHeight, fLowestMiddleHeight, fTemp,
		  fGreatestFloorHeight, fLowestFloorHeight, fGreatestWaterHeight, fLowestWaterHeight,
		  fIncrease;
	double fModelViewMatrix[16], fProjectionMatrix[16], fX, fY, fZ;
	int iViewport[4], iPointT;
	ACTOR_TYPE ActorType;
	POINT MousePos, MousePosT;
	static POINT LastMousePos;
	FIELD *pFieldT, *pFieldT2, *pCurrentFieldT;
	FIELD_DECORATION *pDecorationT;
	AS_MD2_MODEL *pModelT;	
	FLOAT3 *fPosT;
	FIELD_SIDE_SURFACE *pFieldSurfaceT;
	RECT Rect;
	HWND hWndT;
	ACTOR *pActorT;

	// Check the keys:
	_AS->ReadDXInput(hWndEditor);
	if(ASKeyFirst[DIK_ESCAPE])
	{
		if(!SaveLevelQuestion())
		{
			_AS->SetShutDown(TRUE);
			EndDialog(hWndEditor, FALSE);
		}
	}

	if(ASKeyFirst[DIK_T])
		pLevel->CalculateFieldNormals(TRUE);

	if(ASKeyFirst[DIK_F1])
	{ // Open the help file:
		OpenHelp();
	}
	if(ASKeyFirst[DIK_F2])
	{ // Save a level:
		SendMessage(hWndEditor, WM_COMMAND, ID_LEVEL_SAVE, 0);
	}
	if(ASKeyFirst[DIK_F3])
	{ // Save as level:
		SendMessage(hWndEditor, WM_COMMAND, ID_LEVEL_ADJUST, 0);
	}
	if(ASKeyFirst[DIK_F12])
	{ // Open the configuration menu:
		SendMessage(hWndEditor, WM_COMMAND, ID_OPTIONS_CONFIG, 0);
	}
	if(ASKeyFirst[DIK_S])
	{ // Open the selection tab::
		TabCtrl_SetCurSel(GetDlgItem(hWndEditor, IDC_EDITOR_TAB), 0);
		SendMessage(hWndEditor, WM_NOTIFY, IDC_EDITOR_TAB, 0);
	}
	CheckDebugKeys();
	if(ASKeyFirst[_ASConfig->iPauseKey[0]])
		bPause = !bPause;

	// Check if we should update the level view window:
	if(hWndSurfaces || hWndSurface || hWndTextures || GetForegroundWindow() != hWndEditor)
		return 0; // NO!
		
	// Check/update other stuff:	
	pCamera->fPos[Z] = pCamera->fZ;
	CalculateCamersSinCos(); // Update the sin/cos for the camera
	if(!bPause)
	{
		pLevel->Check(TRUE);
		pLevel->CheckActors(TRUE);
		pLevel->CreateWaterBubbles();
		ParticleManager.Check();
	}
	if(ASCheckTimeUpdate(&DisplayActor[0].dwAniTime, OBJECTS_ANI_SPEED))
	{
		DisplayActor[0].iAniStep++;
		if(DisplayActor[0].iAniStep > 3)
			DisplayActor[0].iAniStep = 0;
	}
	if(PlayCameraScript(TRUE))
		return 0;

	if(!bPauseTextBlend && bPause)
	{
		fPauseTextBlend += (float) g_lDeltatime/1000;
		if(fPauseTextBlend > 1.0f)
		{
			fPauseTextBlend = 1.0f;
			bPauseTextBlend = 1;
		}
	}
	else
	{
		fPauseTextBlend -= (float) g_lDeltatime/1000;
		if(fPauseTextBlend < 0.0f)
		{
			fPauseTextBlend = 0.0f;
			bPauseTextBlend = 0;
		}
	}

// Mouse usage for the level manipulaion:
	// Disable all field selection:
	for(i = 0; i < pLevel->Header.iFields; i++)
		pLevel->pField[i].bSelected = FALSE;
	// Disable all grid point selection:
	for(i = 0; i < pLevel->Header.iPoints+pLevel->Header.iLevelPoints; i++)
		pLevel->bPointSelected[i] = FALSE;
	
	// Check if the mouse is in the level view area:
	GetCursorPos(&MousePos);
	GetCursorPos(&MousePosT);
	GetWindowRect(hWndEditorShow, &Rect);
	if(MousePos.x < Rect.left ||
	   MousePos.x > Rect.right ||
	   MousePos.y < Rect.top ||
	   MousePos.y > Rect.bottom)
		return 0; // Nope, the mouse isn't in the level view area:
	
	CheckCameraKeys(TRUE);
	SetCameraTranslation(FALSE);

	// Check mouse scrolling:
	if(_ASConfig->bMouseScroll)
	{
		if(MousePos.x < Rect.left+10)
		{
			pCamera->fPos[X] += fSin90*SCROLL_SPEED*g_lDeltatime;
			pCamera->fPos[Y] += fCos90*SCROLL_SPEED*g_lDeltatime;
		}
		if(MousePos.x > Rect.right-10)
		{
			pCamera->fPos[X] -= fSin90*SCROLL_SPEED*g_lDeltatime;
			pCamera->fPos[Y] -= fCos90*SCROLL_SPEED*g_lDeltatime;
		}
		if(MousePos.y < Rect.top+10)
		{
			pCamera->fPos[X] += fSin*SCROLL_SPEED*g_lDeltatime;
			pCamera->fPos[Y] += fCos*SCROLL_SPEED*g_lDeltatime;
		}
		if(MousePos.y > Rect.bottom-10)
		{
			pCamera->fPos[X] -= fSin*SCROLL_SPEED*g_lDeltatime;
			pCamera->fPos[Y] -= fCos*SCROLL_SPEED*g_lDeltatime;
		}
	}

	// Get the 'real' mouse position in the level view area:
	MousePos.x -= Rect.left;
	MousePos.y = Rect.bottom-Rect.top-MousePos.y+Rect.top;

	// Check if the mouse should not be moved: (e.g. for changing terrain height)
	if((byEditorMenu == EDITOR_TERRAIN_MENU || byEditorMenu == EDITOR_ENVIRONMENT_MENU ||
		byEditorSelected == EDITOR_ENVIRONMENT_SKY_CUBE_COLOR ||
		byEditorMenu == EDITOR_SELECT_MENU ||
		byEditorSelected == EDITOR_ENVIRONMENT_SKY_CUBE_SIZE) &&
	    (CHECK_KEY(ASMouse.byButtons, 0) ||
	   CHECK_KEY(ASMouse.byButtons, 1) || CHECK_KEY(ASMouse.byButtons, 2)))
	{ // The user change the hight of some points or something like that:
		fIncrease = (float) ASMouse.lY;
		SetCursorPos(LastMousePos.x, LastMousePos.y);
		memcpy(&MousePos, &LastMousePos, sizeof(POINT));
		// Get the 'real' mouse position in the level view area, again:
		MousePos.x -= Rect.left;
		MousePos.y = Rect.bottom-Rect.top-MousePos.y+Rect.top;
	}
	else
	{
		fIncrease = 0.0f;
		memcpy(&LastMousePos, &MousePosT, sizeof(POINT));
		iPointX = iPointY = -1;
	}
	if(!CHECK_KEY(ASMouse.byButtons, 0) && !CHECK_KEY(ASMouse.byButtons, 1) &&
	   !CHECK_KEY(ASMouse.byButtons, 2))
	{
		memcpy(&LastMousePos, &MousePosT, sizeof(POINT));
		iPointX = iPointY = -1;
	}
		
	// Get the mouse position in our 3D world:
	glReadBuffer(GL_FRONT);
	glReadPixels(MousePos.x, MousePos.y, 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, &fDepth);
	glGetDoublev(GL_MODELVIEW_MATRIX, fModelViewMatrix);
	glGetDoublev(GL_PROJECTION_MATRIX, fProjectionMatrix);
	glGetIntegerv(GL_VIEWPORT, iViewport);
	gluUnProject(MousePos.x, MousePos.y, fDepth, fModelViewMatrix, fProjectionMatrix, iViewport, &fX, &fY, &fZ);

	// Calculate the current field we are on:
	COMPUTE_FIELD_POS(fX, fY, iFieldX, iFieldY)
	
// Check if we manipulate no field or points stuff:
	if(byEditorMenu == EDITOR_ENVIRONMENT_MENU)
	{ // We change the environment of our world:
		switch(byEditorSelected)
		{
			case EDITOR_ENVIRONMENT_LIGHT: // Change the world's light
				ManipulateColor(&pLevel->Environment.fColor, fIncrease, TRUE);
			break;

			case EDITOR_ENVIRONMENT_MOVE_SHADOWS: // Move the shadows
				ManipulateColor(&pLevel->Environment.fMoveShadows, fIncrease, FALSE);
			break;

			case EDITOR_ENVIRONMENT_SHADOWS_DENSITY_SIZE: // Setup shadows density, size etc.
				ManipulateColor(&pLevel->Environment.fShadowsDensity_Size, fIncrease, FALSE);
			break;

			case EDITOR_ENVIRONMENT_FOG_COLOR: // Change the fog light
				ManipulateColor(&pLevel->Environment.fFogColor, fIncrease, TRUE);
			break;

			case EDITOR_ENVIRONMENT_FOG_DENSITY: // Change the fog density
				ManipulateDensity(&pLevel->Environment.fFogDensity, fIncrease, TRUE);
			break;

			case EDITOR_ENVIRONMENT_WATER_COLOR: // Change the water color
				byColor = -1;
				byColors = 1;
				// Which color we have to manipulate?
				if(CHECK_KEY(ASMouse.byButtons, 0) && CHECK_KEY(ASMouse.byButtons, 1))
					byColors = 3;
				if(CHECK_KEY(ASMouse.byButtons, 0))
					byColor = R;
				else
				if(CHECK_KEY(ASMouse.byButtons, 1))
					byColor = G;
				else
				if(CHECK_KEY(ASMouse.byButtons, 2))
					byColor = B;
				if(byColor == -1 && byColors == 1)
					break;
				for(i = 0; i < pLevel->Header.iLevelPoints; i++)
				{
					for(i2 = 0; i2 < byColors; i2++)
					{
						if(byColors == 3)
							byColor = (char) i2;
						pLevel->fWaterColor[i][byColor] += fIncrease/500.0f;
						if(pLevel->fWaterColor[i][byColor] < 0.0f)
							pLevel->fWaterColor[i][byColor] = 0.0f;
						if(pLevel->fWaterColor[i][byColor] > 1.0f)
							pLevel->fWaterColor[i][byColor] = 1.0f;
					}
				}
			break;

			case EDITOR_ENVIRONMENT_WATER_DENSITY: // Change the water density
				if(!CHECK_KEY(ASMouse.byButtons, 0))
					break;
				for(i = 0; i < pLevel->Header.iLevelPoints; i++)
				{
					pLevel->fWaterColor[i][A] += fIncrease/500.0f;
					if(pLevel->fWaterColor[i][A] < 0.0f)
						pLevel->fWaterColor[i][A] = 0.0f;
					if(pLevel->fWaterColor[i][A] > 1.0f)
						pLevel->fWaterColor[i][A] = 1.0f;
				}
			break;

			case EDITOR_ENVIRONMENT_WATER_HEIGHT: // Change the water height
				if(CHECK_KEY(ASMouse.byButtons, 0))
				{
					pLevel->Environment.fWaterHeight += fIncrease/500.0f;
					break;
				}
				if(CHECK_KEY(ASMouse.byButtons, 1))
					pLevel->Environment.fWaterHeight = -0.3f;
			break;

			case EDITOR_ENVIRONMENT_WATER_AMPLITUDE: // Change the water amplitude
				if(CHECK_KEY(ASMouse.byButtons, 0))
				{
					pLevel->Environment.fWaterAmplitude += fIncrease/50.0f;
					if(pLevel->Environment.fWaterAmplitude < 0.0f)
						pLevel->Environment.fWaterAmplitude = 0.0f;
					break;
				}
				if(CHECK_KEY(ASMouse.byButtons, 1))
					pLevel->Environment.fWaterAmplitude = 1.0f;
			break;

			case EDITOR_ENVIRONMENT_WATER_SPEED: // Change the water speed
				if(CHECK_KEY(ASMouse.byButtons, 0))
				{
					pLevel->Environment.fWaterSpeed += fIncrease/500.0f;
					if(pLevel->Environment.fWaterSpeed < 0.0f)
						pLevel->Environment.fWaterSpeed = 0.0f;
					break;
				}
				if(CHECK_KEY(ASMouse.byButtons, 1))
					pLevel->Environment.fWaterSpeed = 1.0f;
			break;

			case EDITOR_ENVIRONMENT_WATER_WAVE_AMPLITUDE: // Change the water wave amplitude
				if(CHECK_KEY(ASMouse.byButtons, 0))
				{
					pLevel->Environment.fWaterWaveAmplitude += fIncrease/50.0f;
					if(pLevel->Environment.fWaterWaveAmplitude < 0.0f)
						pLevel->Environment.fWaterWaveAmplitude = 0.0f;
					break;
				}
				if(CHECK_KEY(ASMouse.byButtons, 1))
					pLevel->Environment.fWaterWaveAmplitude = 1.0f;
			break;

			case EDITOR_ENVIRONMENT_WATER_WAVE_SPEED: // Change the water wave speed
				if(CHECK_KEY(ASMouse.byButtons, 0))
				{
					pLevel->Environment.fWaterWaveSpeed += fIncrease*10;
					break;
				}
				if(CHECK_KEY(ASMouse.byButtons, 1))
					pLevel->Environment.fWaterWaveSpeed = 1.0f;
			break;

			case EDITOR_ENVIRONMENT_WATER_WAVE_SIZE: // Change the water wave size
				if(CHECK_KEY(ASMouse.byButtons, 0) || 
				   (CHECK_KEY(ASMouse.byButtons, 0) && CHECK_KEY(ASMouse.byButtons, 1)))
					pLevel->Environment.fWaterWaveSize[X] += fIncrease/500.0f;
				if(CHECK_KEY(ASMouse.byButtons, 1) ||
				   (CHECK_KEY(ASMouse.byButtons, 0) && CHECK_KEY(ASMouse.byButtons, 1)))
					pLevel->Environment.fWaterWaveSize[Y] += fIncrease/500.0f;
				if(CHECK_KEY(ASMouse.byButtons, 2))
				{
					pLevel->Environment.fWaterWaveSize[X] = 
					pLevel->Environment.fWaterWaveSize[Y] = 1.0f;
				}
			break;
			
			case EDITOR_ENVIRONMENT_WATER_BUBBLES_COLOR:
				ManipulateColor(&pLevel->Environment.fWaterBubblesColor, fIncrease, TRUE);
				if(CHECK_KEY(ASMouse.byButtons, 2))
					pLevel->Environment.fWaterBubblesColor[R] =
					pLevel->Environment.fWaterBubblesColor[G] =
					pLevel->Environment.fWaterBubblesColor[B] = 1.0f;
			break;

			case EDITOR_ENVIRONMENT_WATER_BUBBLES_DENSITY:
				ManipulateDensity(&pLevel->Environment.fWaterBubblesDensity, fIncrease, TRUE);
				if(CHECK_KEY(ASMouse.byButtons, 2))
					pLevel->Environment.fWaterBubblesDensity = 1.0f;
			break;

			case EDITOR_ENVIRONMENT_WATER_BUBBLES_SPEED:
				pLevel->Environment.fWaterBubblesSpeed += fIncrease/500.0f;
				if(pLevel->Environment.fWaterBubblesSpeed < 0.01f)
					pLevel->Environment.fWaterBubblesSpeed = 0.01f;
				if(CHECK_KEY(ASMouse.byButtons, 2))
					pLevel->Environment.fWaterBubblesSpeed = 1.0f;
			break;

			case EDITOR_ENVIRONMENT_WATER_BUBBLES_FREQUENCY:
				pLevel->Environment.fWaterBubblesFrequency += fIncrease/500.0f;
				if(pLevel->Environment.fWaterBubblesFrequency < 0.01f)
					pLevel->Environment.fWaterBubblesFrequency = 0.01f;
				if(CHECK_KEY(ASMouse.byButtons, 2))
					pLevel->Environment.fWaterBubblesFrequency = 1.0f;
			break;

			case EDITOR_ENVIRONMENT_WATER_BUBBLES_SIZE:
				pLevel->Environment.fWaterBubblesSize += fIncrease/500.0f;
				if(pLevel->Environment.fWaterBubblesSize < 0.01f)
					pLevel->Environment.fWaterBubblesSize = 0.01f;
				if(CHECK_KEY(ASMouse.byButtons, 2))
					pLevel->Environment.fWaterBubblesSize = 1.0f;
			break;
		}
		return 0;
	}
	if(byEditorMenu == EDITOR_DECORATION_MENU)
	{ // We change the worlds sky cube:
		switch(byEditorSelected)
		{
			case EDITOR_ENVIRONMENT_SKY_CUBE_COLOR: // Change the sky-cube color
				ManipulateColor(&pLevel->Environment.fSkyCubeColor, fIncrease, TRUE);
			break;

			case EDITOR_ENVIRONMENT_SKY_CUBE_SIZE: // Change the sky-cube size
				byColor = -1;
				byColors = 1;
				// Which color we have to manipulate?
				if(CHECK_KEY(ASMouse.byButtons, 0) && CHECK_KEY(ASMouse.byButtons, 1))
					byColors = 3;
				if(CHECK_KEY(ASMouse.byButtons, 0))
					byColor = R;
				else
				if(CHECK_KEY(ASMouse.byButtons, 1))
					byColor = G;
				else
				if(CHECK_KEY(ASMouse.byButtons, 2))
					byColor = B;
				if(byColor == -1 && byColors == 1)
					break;
				for(i = 0; i < byColors; i++)
				{
					if(byColors == 3)
						byColor = (char) i;
					pLevel->Environment.fSkyCubeSize[byColor] += fIncrease;
				}
			break;
		}
	}

	
// Ok, do the field/point manipulations:
	// Is the mouse in the level?
	if((iFieldX < 0 || iFieldY < 0 || iFieldX >= pLevel->Header.iWidth || iFieldY >= pLevel->Header.iHeight) &&
	   iPointX == -1 && iPointY == -1)
		return 0; // The mouse is not on the level
	
	// Setup some other stuff:
	if(byEditorMenu == EDITOR_SELECT_MENU)
		iSize = 0;
	else
		iSize = byEditorBrushSize;
	if(pLevel->pCurrentField && byEditorMenu == EDITOR_SELECT_MENU)
		pLevel->pCurrentField->bSelected = TRUE;

	// Points:
	if(byEditorMenu == EDITOR_TERRAIN_MENU)
	{
		hWndT = hWndEditorTab[TAB_EDITOR_TERRAIN];
		bNoneAdvanced = !bAdvancedTerrainManipulation;
		bFloor = SendDlgItemMessage(hWndT, IDC_EDITOR_TERRAIN_FLOOR, BM_GETCHECK, 0, 0L);
		if(bAdvancedTerrainManipulation)
			bMiddle = SendDlgItemMessage(hWndT, IDC_EDITOR_TERRAIN_MIDDLE, BM_GETCHECK, 0, 0L);
		else
			bMiddle = FALSE;
		bTop = SendDlgItemMessage(hWndT, IDC_EDITOR_TERRAIN_TOP, BM_GETCHECK, 0, 0L);
		bWater = SendDlgItemMessage(hWndT, IDC_EDITOR_TERRAIN_WATER, BM_GETCHECK, 0, 0L);

		// The mouse is on a field:
		fTopMiddle = fMiddleMiddle = fFloorMiddle = fWaterMiddle = 
		fGreatestTopHeight = fLowestTopHeight = fGreatestFloorHeight =
		fLowestFloorHeight = fGreatestMiddleHeight =
		fLowestMiddleHeight = fGreatestWaterHeight = fLowestWaterHeight = 0.0f;
		
		// Get the current point the mouse is on:
		if(!bAdvancedTerrainManipulation)
		{
			if(iPointX == -1 && iPointY == -1) 
			{
				iPointX = (int) (fX*2+0.5f);
				iPointY = (int) (fY*2+0.5f);
				fTemp = (float) iPointX/2+0.5f;
				if(iPointX/2+0.5f == fTemp)
					iPointX++;
				fTemp = (float) iPointY/2+0.5f;
				if(iPointY/2+0.5f == fTemp)
					iPointY++;
			}
		}
		else
		{
			if(iPointX == -1 && iPointY == -1) 
			{
				iPointX = (int) (fX*2+0.5f);
				iPointY = (int) (fY*2+0.5f);
			}
		}
		
		// Get some data from the selected field's: (middle hight, greatest hight...)
		iSize *= 1+bNoneAdvanced;
		if(!iSize)
			iY = iPointY-bNoneAdvanced;
		else
		{
			iY = iPointY-iSize;
			if(iSize > 1)
				iY++;
		}
		if(iY < 0)
			iY = 0;
		for(i = 0; iY < iPointY+iSize+1; iY += 1+bNoneAdvanced)
		{
			if(iY >= pLevel->Header.iYPoints)
				break;
			if(!iSize)
				iX = iPointX-bNoneAdvanced;
			else
			{
				iX = iPointX-iSize;
				if(iSize > 1)
					iX++;
			}
			if(iX < 0)
				iX = 0;
			for(; iX < iPointX+iSize+1; iX += 1+bNoneAdvanced)
			{
				if(iX >= pLevel->Header.iXPoints)
					continue;
				// Calculate the middle value:
				iPointT = iY*pLevel->Header.iXPoints+iX;
				if(bFloor)
					pLevel->bPointSelected[iPointT] = TRUE;
				fFloorMiddle += pLevel->fPoint[iPointT][Z];
				if(pLevel->fPoint[iPointT][Z] < fGreatestFloorHeight)
					fGreatestFloorHeight = pLevel->fPoint[iPointT][Z];
				if(pLevel->fPoint[iPointT][Z] > fLowestFloorHeight)
					fLowestFloorHeight = pLevel->fPoint[iPointT][Z];

				iPointT = iY*pLevel->Header.iXPoints+iX+pLevel->Header.iLevelPoints;
				if(bMiddle)
					pLevel->bPointSelected[iPointT] = TRUE;
				fMiddleMiddle += pLevel->fPoint[iPointT][Z];
				if(pLevel->fPoint[iPointT][Z] < fGreatestMiddleHeight)
					fGreatestMiddleHeight = pLevel->fPoint[iPointT][Z];
				if(pLevel->fPoint[iPointT][Z] > fLowestMiddleHeight)
					fLowestMiddleHeight = pLevel->fPoint[iPointT][Z];

				iPointT = iY*pLevel->Header.iXPoints+iX+pLevel->Header.iLevelPoints*2;
				if(bTop)
					pLevel->bPointSelected[iPointT] = TRUE;
				fTopMiddle += pLevel->fPoint[iPointT][Z];
				if(pLevel->fPoint[iPointT][Z] < fGreatestTopHeight)
					fGreatestTopHeight = pLevel->fPoint[iPointT][Z];
				if(pLevel->fPoint[iPointT][Z] > fLowestTopHeight)
					fLowestTopHeight = pLevel->fPoint[iPointT][Z];

				iPointT = iY*pLevel->Header.iXPoints+iX;
				fWaterMiddle += pLevel->fWaterStandartZ[iPointT];
				if(pLevel->fWaterStandartZ[iPointT] < fGreatestWaterHeight)
					fGreatestWaterHeight = pLevel->fWaterStandartZ[iPointT];
				if(pLevel->fWaterStandartZ[iPointT] > fLowestWaterHeight)
					fLowestWaterHeight = pLevel->fWaterStandartZ[iPointT];
				if(bWater)
					pLevel->bPointSelected[iPointT+pLevel->Header.iLevelPoints*3] = TRUE;
				i++;
			}
		}
		fTopMiddle /= i;
		fMiddleMiddle /= i;
		fFloorMiddle /= i;
		fWaterMiddle /= i;

		if(!iSize)
			iY = iPointY-bNoneAdvanced;
		else
		{
			iY = iPointY-iSize;
			if(iSize > 1)
				iY++;
		}
		if(iY < 0)
			iY = 0;
		for(; iY < iPointY+iSize+1; iY += 1+bNoneAdvanced)
		{
			if(iY >= pLevel->Header.iYPoints)
				break;
			if(!iSize)
				iX = iPointX-bNoneAdvanced;
			else
			{
				iX = iPointX-iSize;
				if(iSize > 1)
					iX++;
			}
			if(iX < 0)
				iX = 0;
			for(; iX < iPointX+iSize+1; iX += 1+bNoneAdvanced)
			{
				if(iX >= pLevel->Header.iXPoints)
					continue;
				iFloorPointT = iY*pLevel->Header.iXPoints+iX;
				iMiddlePointT = iFloorPointT+pLevel->Header.iLevelPoints;
				iTopPointT = iMiddlePointT+pLevel->Header.iLevelPoints;
				
				// Update the fields:
				for(iYT = iY/2-1; iYT < iY/2+1; iYT++)
				{
					if(iYT < 0 || iYT >= pLevel->Header.iHeight)
						continue;
					for(iXT = iX/2-1; iXT < iX/2+1; iXT++)
					{
						if(iXT < 0 || iXT >= pLevel->Header.iWidth)
							continue;
						GET_FIELD_POINTER(iXT, iYT, pFieldT);
						if(pFieldT)
							pFieldT->bUpdate = TRUE;

					}
				}

				switch(byEditorSelected)
				{
					case EDITOR_SELECTED_COLOR: // Change the vertex colors
					FirstColor:
						byColor = -1;
						byColors = 1;
						// Which color we have to manipulate?
						if(CHECK_KEY(ASMouse.byButtons, 0) && CHECK_KEY(ASMouse.byButtons, 1))
							byColors = 3;
						else
						if(CHECK_KEY(ASMouse.byButtons, 0))
							byColor = R;
						else
						if(CHECK_KEY(ASMouse.byButtons, 1))
							byColor = G;
						else
						if(CHECK_KEY(ASMouse.byButtons, 2))
							byColor = B;
						if(byColor == -1 && byColors == 1)
							break;
						for(i = 0; i < byColors; i++)
						{
							if(byColors == 3)
								byColor = (char) i;
							if(bFloor)
							{
								pLevel->fColor[iFloorPointT][byColor] += fIncrease/500.0f;
								if(pLevel->fColor[iFloorPointT][byColor] > 1.0f)
									pLevel->fColor[iFloorPointT][byColor] = 1.0f;
								if(pLevel->fColor[iFloorPointT][byColor] < 0.0f)
									pLevel->fColor[iFloorPointT][byColor] = 0.0f;
								SetupMiddlePoints(iX, iY, iFloorPointT, pLevel->fColor, byColor);
							}
							if(bMiddle)
							{
								pLevel->fColor[iMiddlePointT][byColor] += fIncrease/500.0f;
								if(pLevel->fColor[iMiddlePointT][byColor] > 1.0f)
									pLevel->fColor[iMiddlePointT][byColor] = 1.0f;
								if(pLevel->fColor[iMiddlePointT][byColor] < 0.0f)
									pLevel->fColor[iMiddlePointT][byColor] = 0.0f;
								SetupMiddlePoints(iX, iY, iMiddlePointT, pLevel->fColor, byColor);
							}
							if(bTop)
							{
								pLevel->fColor[iTopPointT][byColor] += fIncrease/500.0f;
								if(pLevel->fColor[iTopPointT][byColor] > 1.0f)
									pLevel->fColor[iTopPointT][byColor] = 1.0f;
								if(pLevel->fColor[iTopPointT][byColor] < 0.0f)
									pLevel->fColor[iTopPointT][byColor] = 0.0f;
								SetupMiddlePoints(iX, iY, iTopPointT, pLevel->fColor, byColor);
							}
							if(bWater)
							{
								pLevel->fWaterColor[iFloorPointT][byColor] += fIncrease/500.0f;
								if(pLevel->fWaterColor[iFloorPointT][byColor] > 1.0f)
									pLevel->fWaterColor[iFloorPointT][byColor] = 1.0f;
								if(pLevel->fWaterColor[iFloorPointT][byColor] < 0.0f)
									pLevel->fWaterColor[iFloorPointT][byColor] = 0.0f;
								SetupMiddlePoints(iX, iY, iFloorPointT, pLevel->fWaterColor, byColor);
							}
							if(bFloor || bTop)
								SetupMiddlePoints(iX, iY, iFloorPointT, iMiddlePointT, iTopPointT, pLevel->fColor, byColor);
						}
						if(ASKeys[15] && byEditorSelected == EDITOR_SELECTED_COLOR)
							goto SecondColor;
					break;

					case EDITOR_SELECTED_SECOND_COLOR: // Change the vertex second color value
					SecondColor:
						byColor = -1;
						byColors = 1;
						// Which color we have to manipulate?
						if(CHECK_KEY(ASMouse.byButtons, 0) && CHECK_KEY(ASMouse.byButtons, 1))
							byColors = 3;
						else
						if(CHECK_KEY(ASMouse.byButtons, 0))
							byColor = R;
						else
						if(CHECK_KEY(ASMouse.byButtons, 1))
							byColor = G;
						else
						if(CHECK_KEY(ASMouse.byButtons, 2))
							byColor = B;
						if(byColor == -1 && byColors == 1)
							break;
						for(i = 0; i < byColors; i++)
						{
							if(byColors == 3)
								byColor = (char) i;
							if(bFloor)
							{
								pLevel->fSecondColor[iFloorPointT][byColor] += fIncrease/500.0f;
								if(pLevel->fSecondColor[iFloorPointT][byColor] > 1.0f)
									pLevel->fSecondColor[iFloorPointT][byColor] = 1.0f;
								if(pLevel->fSecondColor[iFloorPointT][byColor] < 0.0f)
									pLevel->fSecondColor[iFloorPointT][byColor] = 0.0f;
								SetupMiddlePoints(iX, iY, iFloorPointT, pLevel->fSecondColor, byColor);
							}
							if(bMiddle)
							{
								pLevel->fSecondColor[iMiddlePointT][byColor] += fIncrease/500.0f;
								if(pLevel->fSecondColor[iMiddlePointT][byColor] > 1.0f)
									pLevel->fSecondColor[iMiddlePointT][byColor] = 1.0f;
								if(pLevel->fSecondColor[iMiddlePointT][byColor] < 0.0f)
									pLevel->fSecondColor[iMiddlePointT][byColor] = 0.0f;
								SetupMiddlePoints(iX, iY, iMiddlePointT, pLevel->fSecondColor, byColor);
							}
							if(bTop)
							{
								pLevel->fSecondColor[iTopPointT][byColor] += fIncrease/500.0f;
								if(pLevel->fSecondColor[iTopPointT][byColor] > 1.0f)
									pLevel->fSecondColor[iTopPointT][byColor] = 1.0f;
								if(pLevel->fSecondColor[iTopPointT][byColor] < 0.0f)
									pLevel->fSecondColor[iTopPointT][byColor] = 0.0f;
								SetupMiddlePoints(iX, iY, iTopPointT, pLevel->fSecondColor, byColor);
							}
							if(bWater)
							{
								pLevel->fWaterSecondColor[iFloorPointT][byColor] += fIncrease/500.0f;
								if(pLevel->fWaterSecondColor[iFloorPointT][byColor] > 1.0f)
									pLevel->fWaterSecondColor[iFloorPointT][byColor] = 1.0f;
								if(pLevel->fWaterSecondColor[iFloorPointT][byColor] < 0.0f)
									pLevel->fWaterSecondColor[iFloorPointT][byColor] = 0.0f;
								SetupMiddlePoints(iX, iY, iFloorPointT, pLevel->fWaterSecondColor, byColor);
							}
							if(bFloor || bTop)
								SetupMiddlePoints(iX, iY, iFloorPointT, iMiddlePointT, iTopPointT, pLevel->fSecondColor, byColor);
						}
						if(ASKeys[15] && byEditorSelected == EDITOR_SELECTED_SECOND_COLOR)
							goto FirstColor;
					break;

					case EDITOR_SELECTED_ALPHA_COLOR: // Change the vertex alpha color value
						if(!CHECK_KEY(ASMouse.byButtons, 0))
							break;
						if(bFloor)
						{
							pLevel->fColor[iFloorPointT][A] += fIncrease/500.0f;
							if(pLevel->fColor[iFloorPointT][A] > 1.0f)
								pLevel->fColor[iFloorPointT][A] = 1.0f;
							if(pLevel->fColor[iFloorPointT][A] < 0.0f)
								pLevel->fColor[iFloorPointT][A] = 0.0f;
							SetupMiddlePoints(iX, iY, iFloorPointT, pLevel->fColor, A);
						}
						if(bMiddle)
						{
							pLevel->fColor[iMiddlePointT][A] += fIncrease/500.0f;
							if(pLevel->fColor[iMiddlePointT][A] > 1.0f)
								pLevel->fColor[iMiddlePointT][A] = 1.0f;
							if(pLevel->fColor[iMiddlePointT][A] < 0.0f)
								pLevel->fColor[iMiddlePointT][A] = 0.0f;
							SetupMiddlePoints(iX, iY, iMiddlePointT, pLevel->fColor, A);
						}
						if(bTop)
						{
							pLevel->fColor[iTopPointT][A] += fIncrease/500.0f;
							if(pLevel->fColor[iTopPointT][A] > 1.0f)
								pLevel->fColor[iTopPointT][A] = 1.0f;
							if(pLevel->fColor[iTopPointT][A] < 0.0f)
								pLevel->fColor[iTopPointT][A] = 0.0f;
							SetupMiddlePoints(iX, iY, iTopPointT, pLevel->fColor, A);
						}
						if(bWater)
						{
							pLevel->fWaterColor[iFloorPointT][A] += fIncrease/500.0f;
							if(pLevel->fWaterColor[iFloorPointT][A] > 1.0f)
								pLevel->fWaterColor[iFloorPointT][A] = 1.0f;
							if(pLevel->fWaterColor[iFloorPointT][A] < 0.0f)
								pLevel->fWaterColor[iFloorPointT][A] = 0.0f;
							SetupMiddlePoints(iX, iY, iFloorPointT, pLevel->fWaterColor, A);
						}
						if(bFloor || bTop)
							SetupMiddlePoints(iX, iY, iFloorPointT, iMiddlePointT, iTopPointT, pLevel->fColor, A);
						pLevel->bForceVisiblityUpdate = TRUE;
					break;

					case EDITOR_SELECTED_SECOND_ALPHA_COLOR: // Change the vertex second alpha color value
						if(!CHECK_KEY(ASMouse.byButtons, 0))
							break;
						if(bFloor)
						{
							pLevel->fSecondColor[iFloorPointT][A] += fIncrease/500.0f;
							if(pLevel->fSecondColor[iFloorPointT][A] > 1.0f)
								pLevel->fSecondColor[iFloorPointT][A] = 1.0f;
							if(pLevel->fSecondColor[iFloorPointT][A] < 0.0f)
								pLevel->fSecondColor[iFloorPointT][A] = 0.0f;
							SetupMiddlePoints(iX, iY, iFloorPointT, pLevel->fSecondColor, A);
						}
						if(bMiddle)
						{
							pLevel->fSecondColor[iMiddlePointT][A] += fIncrease/500.0f;
							if(pLevel->fSecondColor[iMiddlePointT][A] > 1.0f)
								pLevel->fSecondColor[iMiddlePointT][A] = 1.0f;
							if(pLevel->fSecondColor[iMiddlePointT][A] < 0.0f)
								pLevel->fSecondColor[iMiddlePointT][A] = 0.0f;
							SetupMiddlePoints(iX, iY, iMiddlePointT, pLevel->fSecondColor, A);
						}
						if(bTop)
						{
							pLevel->fSecondColor[iTopPointT][A] += fIncrease/500.0f;
							if(pLevel->fSecondColor[iTopPointT][A] > 1.0f)
								pLevel->fSecondColor[iTopPointT][A] = 1.0f;
							if(pLevel->fSecondColor[iTopPointT][A] < 0.0f)
								pLevel->fSecondColor[iTopPointT][A] = 0.0f;
							SetupMiddlePoints(iX, iY, iTopPointT, pLevel->fSecondColor, A);
						}
						if(bWater)
						{
							pLevel->fWaterSecondColor[iFloorPointT][A] += fIncrease/500.0f;
							if(pLevel->fWaterSecondColor[iFloorPointT][A] > 1.0f)
								pLevel->fWaterSecondColor[iFloorPointT][A] = 1.0f;
							if(pLevel->fWaterSecondColor[iFloorPointT][A] < 0.0f)
								pLevel->fWaterSecondColor[iFloorPointT][A] = 0.0f;
							SetupMiddlePoints(iX, iY, iFloorPointT, pLevel->fWaterSecondColor, A);
						}
						if(bFloor || bTop)
							SetupMiddlePoints(iX, iY, iFloorPointT, iMiddlePointT, iTopPointT, pLevel->fSecondColor, A);
						pLevel->bForceVisiblityUpdate = TRUE;
					break;

					case EDITOR_SELECTED_HEIGHT: // Change the heights
						if(CHECK_KEY(ASMouse.byButtons, 2))
						{ // Set to the standart height:
							bTerrainChange = TRUE;
							if(bFloor)
							{
								pLevel->fPoint[iFloorPointT][Z] = 0.0f;
								SetupMiddlePoints(iX, iY, iFloorPointT, pLevel->fPoint, Z);
							}
							if(bMiddle)
							{
								pLevel->fPoint[iMiddlePointT][Z] = -1.0f;
								SetupMiddlePoints(iX, iY, iMiddlePointT, pLevel->fPoint, Z);
							}
							if(bTop)
							{
								pLevel->fPoint[iTopPointT][Z] = -1.0f;
								SetupMiddlePoints(iX, iY, iTopPointT, pLevel->fPoint, Z);
							}
							if(bWater)
							{
								pLevel->fWaterStandartZ[iFloorPointT] = 0.0f;
								SetupMiddlePoints(iX, iY, iFloorPointT, pLevel->fWaterStandartZ);
							}
							if(bFloor || bTop)
								SetupMiddlePoints(iX, iY, iFloorPointT, iMiddlePointT, iTopPointT, pLevel->fPoint, Z);
						}
						if(!CHECK_KEY(ASMouse.byButtons, 0))
							break;
						bTerrainChange = TRUE;
						if(bFloor)
						{
							pLevel->fPoint[iFloorPointT][Z] += fIncrease/50.0f;
							if(pLevel->fPoint[iFloorPointT][Z] > 10.0f)
								pLevel->fPoint[iFloorPointT][Z] = 10.0f;
							if(pLevel->fPoint[iFloorPointT][Z] < -10.0f)
								pLevel->fPoint[iFloorPointT][Z] = -10.0f;
							SetupMiddlePoints(iX, iY, iFloorPointT, pLevel->fPoint, Z);
						}
						if(bMiddle)
						{
							pLevel->fPoint[iMiddlePointT][Z] += fIncrease/50.0f;
							if(pLevel->fPoint[iMiddlePointT][Z] > 10.0f)
								pLevel->fPoint[iMiddlePointT][Z] = 10.0f;
							if(pLevel->fPoint[iMiddlePointT][Z] < -10.0f)
								pLevel->fPoint[iMiddlePointT][Z] = -10.0f;
							SetupMiddlePoints(iX, iY, iMiddlePointT, pLevel->fPoint, Z);
						}
						if(bTop)
						{
							pLevel->fPoint[iTopPointT][Z] += fIncrease/50.0f;
							if(pLevel->fPoint[iTopPointT][Z] > 20.0f)
								pLevel->fPoint[iTopPointT][Z] = 20.0f;
							if(pLevel->fPoint[iTopPointT][Z] < -20.0f)
								pLevel->fPoint[iTopPointT][Z] = -20.0f;
							SetupMiddlePoints(iX, iY, iTopPointT, pLevel->fPoint, Z);
						}
						if(bWater)
						{
							pLevel->fWaterStandartZ[iFloorPointT] += fIncrease/50.0f;
							SetupMiddlePoints(iX, iY, iFloorPointT, pLevel->fWaterStandartZ);
						}
						if(bFloor || bTop)
							SetupMiddlePoints(iX, iY, iFloorPointT, iMiddlePointT, iTopPointT, pLevel->fPoint, Z);
					break;
					
					case EDITOR_SELECTED_POINT: // Change the point positions
						if(CHECK_KEY(ASMouse.byButtons, 0))
						{ // Manipulate x position:
							if(bFloor)
								pLevel->fPoint[iFloorPointT][X] += fIncrease/100.0f;
							if(bMiddle)
								pLevel->fPoint[iMiddlePointT][X] += fIncrease/100.0f;
							if(bTop)
								pLevel->fPoint[iTopPointT][X] += fIncrease/100.0f;
							if(bWater)
								pLevel->fWaterPoint[iFloorPointT][X] += fIncrease/100.0f;
						}
						if(CHECK_KEY(ASMouse.byButtons, 1))
						{ // Manipulate y position:
							if(bFloor)
								pLevel->fPoint[iFloorPointT][Y] += fIncrease/100.0f;
							if(bMiddle)
								pLevel->fPoint[iMiddlePointT][Y] += fIncrease/100.0f;
							if(bTop)
								pLevel->fPoint[iTopPointT][Y] += fIncrease/100.0f;
							if(bWater)
								pLevel->fWaterPoint[iFloorPointT][Y] += fIncrease/100.0f;
						}
						// This effect should be not to extreme:
						for(i = 0; i < 4; i++)
						{
							switch(i)
							{
								case 0: fPosT = &pLevel->fPoint[iFloorPointT]; break;
								case 1: fPosT = &pLevel->fPoint[iMiddlePointT]; break;
								case 2: fPosT = &pLevel->fPoint[iTopPointT]; break;
								case 3: fPosT = &pLevel->fWaterPoint[iFloorPointT]; break;
							}
							
							if((*fPosT)[X] > (float) iX/2+0.5f)
								(*fPosT)[X] = (float) iX/2+0.5f;
							if((*fPosT)[X] < (float) iX/2-0.5f)
								(*fPosT)[X] = (float) iX/2-0.5f;
							
							if((*fPosT)[Y] > (float) iY/2+0.5f)
								(*fPosT)[Y] = (float) iY/2+0.5f;
							if((*fPosT)[Y] < (float) iY/2-0.5f)
								(*fPosT)[Y] = (float) iY/2-0.5f;
						}
						if(CHECK_KEY(ASMouse.byButtons, 2))
						{ // Set to standart position:
							if(bFloor)
							{
								pLevel->fPoint[iFloorPointT][X] = (float) iX/2;
								pLevel->fPoint[iFloorPointT][Y] = (float) iY/2;
							}
							if(bMiddle)
							{
								pLevel->fPoint[iMiddlePointT][X] = (float) iX/2;
								pLevel->fPoint[iMiddlePointT][Y] = (float) iY/2;
							}
							if(bTop)
							{
								pLevel->fPoint[iTopPointT][X] = (float) iX/2;
								pLevel->fPoint[iTopPointT][Y] = (float) iY/2;
							}
							if(bWater)
							{
								pLevel->fWaterPoint[iFloorPointT][X] = (float) iX/2;
								pLevel->fWaterPoint[iFloorPointT][Y] = (float) iY/2;
							}
						}
						if(!bAdvancedTerrainManipulation)
						{ // Update middle points:
							if(CHECK_KEY(ASMouse.byButtons, 0) || CHECK_KEY(ASMouse.byButtons, 2))
							{
								if(bFloor)
									SetupMiddlePoints(iX, iY, iFloorPointT, pLevel->fPoint, X);
								if(bMiddle)
									SetupMiddlePoints(iX, iY, iMiddlePointT, pLevel->fPoint, X);
								if(bTop)
									SetupMiddlePoints(iX, iY, iTopPointT, pLevel->fPoint, X);
								if(bWater)
									SetupMiddlePoints(iX, iY, iFloorPointT, pLevel->fWaterPoint, X);
								if(bFloor || bTop)
									SetupMiddlePoints(iX, iY, iFloorPointT, iMiddlePointT, iTopPointT, pLevel->fPoint, X);
							}
							if(CHECK_KEY(ASMouse.byButtons, 1) || CHECK_KEY(ASMouse.byButtons, 2))
							{
								if(bFloor)
									SetupMiddlePoints(iX, iY, iFloorPointT, pLevel->fPoint, Y);
								if(bMiddle)
									SetupMiddlePoints(iX, iY, iMiddlePointT, pLevel->fPoint, Y);
								if(bTop)
									SetupMiddlePoints(iX, iY, iTopPointT, pLevel->fPoint, Y);
								if(bWater)
									SetupMiddlePoints(iX, iY, iFloorPointT, pLevel->fWaterPoint, Y);
								if(bFloor || bTop)
									SetupMiddlePoints(iX, iY, iFloorPointT, iMiddlePointT, iTopPointT, pLevel->fPoint, Y);
							}
						}
						bTerrainChange = TRUE;
					break;

					case EDITOR_SELECTED_TERRAIN_RANDOMLY:
						if(!fIncrease)
							break;
						if(CHECK_KEY(ASMouse.byButtons, 0))
						{ // Manipulate x position:
							if(bFloor)
							{
								if(!(rand() % 2))
									pLevel->fPoint[iFloorPointT][X] += (rand() % (int) fIncrease*10)/1000.0f;
								else
									pLevel->fPoint[iFloorPointT][X] -= (rand() % (int) fIncrease*10)/1000.0f;
							}
							if(bMiddle)
							{
								if(!(rand() % 2))
									pLevel->fPoint[iMiddlePointT][X] += (rand() % (int) fIncrease*10)/1000.0f;
								else
									pLevel->fPoint[iMiddlePointT][X] -= (rand() % (int) fIncrease*10)/1000.0f;
							}
							if(bTop)
							{
								if(!(rand() % 2))
									pLevel->fPoint[iTopPointT][X] += (rand() % (int) fIncrease*10)/1000.0f;
								else
									pLevel->fPoint[iTopPointT][X] -= (rand() % (int) fIncrease*10)/1000.0f;
							}
							if(bWater)
							{
								if(!(rand() % 2))
									pLevel->fWaterPoint[iFloorPointT][X] += (rand() % (int) fIncrease*10)/1000.0f;
								else
									pLevel->fWaterPoint[iFloorPointT][X] -= (rand() % (int) fIncrease*10)/1000.0f;
							}
						}
						if(CHECK_KEY(ASMouse.byButtons, 1))
						{ // Manipulate y position:
							if(bFloor)
							{
								if(!(rand() % 2))
									pLevel->fPoint[iFloorPointT][Y] += (rand() % (int) fIncrease*10)/1000.0f;
								else
									pLevel->fPoint[iFloorPointT][Y] -= (rand() % (int) fIncrease*10)/1000.0f;
							}
							if(bMiddle)
							{
								if(!(rand() % 2))
									pLevel->fPoint[iMiddlePointT][Y] += (rand() % (int) fIncrease*10)/1000.0f;
								else
									pLevel->fPoint[iMiddlePointT][Y] -= (rand() % (int) fIncrease*10)/1000.0f;
							}
							if(bTop)
							{
								if(!(rand() % 2))
									pLevel->fPoint[iTopPointT][Y] += (rand() % (int) fIncrease*10)/1000.0f;
								else
									pLevel->fPoint[iTopPointT][Y] -= (rand() % (int) fIncrease*10)/1000.0f;
							}
							if(bWater)
							{
								if(!(rand() % 2))
									pLevel->fWaterPoint[iFloorPointT][Y] += (rand() % (int) fIncrease*10)/1000.0f;
								else
									pLevel->fWaterPoint[iFloorPointT][Y] -= (rand() % (int) fIncrease*10)/1000.0f;
							}
						}
						if(CHECK_KEY(ASMouse.byButtons, 2))
						{ // Manipulate y position:
							if(bFloor)
							{
								if(!(rand() % 2))
									pLevel->fPoint[iFloorPointT][Z] += (rand() % (int) fIncrease*10)/1000.0f;
								else
									pLevel->fPoint[iFloorPointT][Z] -= (rand() % (int) fIncrease*10)/1000.0f;
							}
							if(bMiddle)
							{
								if(!(rand() % 2))
									pLevel->fPoint[iMiddlePointT][Z] += (rand() % (int) fIncrease*10)/1000.0f;
								else
									pLevel->fPoint[iMiddlePointT][Z] -= (rand() % (int) fIncrease*10)/1000.0f;
							}
							if(bTop)
							{
								if(!(rand() % 2))
									pLevel->fPoint[iTopPointT][Z] += (rand() %(int)  fIncrease*10)/1000.0f;
								else
									pLevel->fPoint[iTopPointT][Z] -= (rand() %(int)  fIncrease*10)/1000.0f;
							}
							if(bWater)
							{
								if(!(rand() % 2))
									pLevel->fWaterPoint[iFloorPointT][Z] += (rand() % (int) fIncrease*10)/1000.0f;
								else
									pLevel->fWaterPoint[iFloorPointT][Z] -= (rand() % (int) fIncrease*10)/1000.0f;
							}
						}
						// This effect should be not to extreme:
						for(i = 0; i < 4; i++)
						{
							switch(i)
							{
								case 0: fPosT = &pLevel->fPoint[iFloorPointT]; break;
								case 1: fPosT = &pLevel->fPoint[iMiddlePointT]; break;
								case 2: fPosT = &pLevel->fPoint[iTopPointT]; break;
								case 3: fPosT = &pLevel->fWaterPoint[iFloorPointT]; break;
							}
							
							if((*fPosT)[X] > (float) iX/2+0.5f)
								(*fPosT)[X] = (float) iX/2+0.5f;
							if((*fPosT)[X] < (float) iX/2-0.5f)
								(*fPosT)[X] = (float) iX/2-0.5f;
							
							if((*fPosT)[Y] > (float) iY/2+0.5f)
								(*fPosT)[Y] = (float) iY/2+0.5f;
							if((*fPosT)[Y] < (float) iY/2-0.5f)
								(*fPosT)[Y] = (float) iY/2-0.5f;
						}
						if(!bAdvancedTerrainManipulation)
						{ // Update middle points:
							if(CHECK_KEY(ASMouse.byButtons, 0) || CHECK_KEY(ASMouse.byButtons, 2))
							{
								if(bFloor)
									SetupMiddlePoints(iX, iY, iFloorPointT, pLevel->fPoint, X);
								if(bMiddle)
									SetupMiddlePoints(iX, iY, iMiddlePointT, pLevel->fPoint, X);
								if(bTop)
									SetupMiddlePoints(iX, iY, iTopPointT, pLevel->fPoint, X);
								if(bWater)
									SetupMiddlePoints(iX, iY, iFloorPointT, pLevel->fWaterPoint, X);
								if(bFloor || bTop)
									SetupMiddlePoints(iX, iY, iFloorPointT, iMiddlePointT, iTopPointT, pLevel->fPoint, X);
							}
							if(CHECK_KEY(ASMouse.byButtons, 1) || CHECK_KEY(ASMouse.byButtons, 2))
							{
								if(bFloor)
									SetupMiddlePoints(iX, iY, iFloorPointT, pLevel->fPoint, Y);
								if(bMiddle)
									SetupMiddlePoints(iX, iY, iMiddlePointT, pLevel->fPoint, Y);
								if(bTop)
									SetupMiddlePoints(iX, iY, iTopPointT, pLevel->fPoint, Y);
								if(bWater)
									SetupMiddlePoints(iX, iY, iFloorPointT, pLevel->fWaterPoint, Y);
								if(bFloor || bTop)
									SetupMiddlePoints(iX, iY, iFloorPointT, iMiddlePointT, iTopPointT, pLevel->fPoint, Y);
							}
							if(bFloor)
							{
								if(pLevel->fPoint[iFloorPointT][Z] > 10.0f)
									pLevel->fPoint[iFloorPointT][Z] = 10.0f;
								if(pLevel->fPoint[iFloorPointT][Z] < -10.0f)
									pLevel->fPoint[iFloorPointT][Z] = -10.0f;
								SetupMiddlePoints(iX, iY, iFloorPointT, pLevel->fPoint, Z);
							}
							if(bMiddle)
							{
								if(pLevel->fPoint[iMiddlePointT][Z] > 10.0f)
									pLevel->fPoint[iMiddlePointT][Z] = 10.0f;
								if(pLevel->fPoint[iMiddlePointT][Z] < -10.0f)
									pLevel->fPoint[iMiddlePointT][Z] = -10.0f;
								SetupMiddlePoints(iX, iY, iMiddlePointT, pLevel->fPoint, Z);
							}
							if(bTop)
							{
								if(pLevel->fPoint[iTopPointT][Z] > 20.0f)
									pLevel->fPoint[iTopPointT][Z] = 20.0f;
								if(pLevel->fPoint[iTopPointT][Z] < -20.0f)
									pLevel->fPoint[iTopPointT][Z] = -20.0f;
								SetupMiddlePoints(iX, iY, iTopPointT, pLevel->fPoint, Z);
							}
							if(bWater)
								SetupMiddlePoints(iX, iY, iFloorPointT, pLevel->fWaterStandartZ);
						}
						bTerrainChange = TRUE;
					break;

					case EDITOR_SELECTED_MIDDLE_HEIGHT: // Middle the heights
						if(!CHECK_KEY(ASMouse.byButtons, 0))
							break;
						bTerrainChange = TRUE;
						if(bFloor)
						{
							if(pLevel->fPoint[iFloorPointT][Z] > fFloorMiddle)
							{
								pLevel->fPoint[iFloorPointT][Z] -= fIncrease/50.0f;
								if(pLevel->fPoint[iFloorPointT][Z] < fFloorMiddle)
									pLevel->fPoint[iFloorPointT][Z] = fFloorMiddle;
							}
							else
								if(pLevel->fPoint[iFloorPointT][Z] < fFloorMiddle)
								{
									pLevel->fPoint[iFloorPointT][Z] += fIncrease/50.0f;
									if(pLevel->fPoint[iFloorPointT][Z] > fFloorMiddle)
										pLevel->fPoint[iFloorPointT][Z] = fFloorMiddle;
								}
							SetupMiddlePoints(iX, iY, iFloorPointT, pLevel->fPoint, Z);
						}
						if(bMiddle)
						{
							if(pLevel->fPoint[iMiddlePointT][Z] > fMiddleMiddle)
							{
								pLevel->fPoint[iMiddlePointT][Z] -= fIncrease/50.0f;
								if(pLevel->fPoint[iMiddlePointT][Z] < fMiddleMiddle)
									pLevel->fPoint[iMiddlePointT][Z] = fMiddleMiddle;
							}
							else
								if(pLevel->fPoint[iMiddlePointT][Z] < fMiddleMiddle)
								{
									pLevel->fPoint[iMiddlePointT][Z] += fIncrease/50.0f;
									if(pLevel->fPoint[iMiddlePointT][Z] > fMiddleMiddle)
										pLevel->fPoint[iMiddlePointT][Z] = fMiddleMiddle;
								}
							SetupMiddlePoints(iX, iY, iMiddlePointT, pLevel->fPoint, Z);
						}
						if(bTop)
						{
							if(pLevel->fPoint[iTopPointT][Z] > fTopMiddle)
							{
								pLevel->fPoint[iTopPointT][Z] -= fIncrease/50.0f;
								if(pLevel->fPoint[iTopPointT][Z] < fTopMiddle)
									pLevel->fPoint[iTopPointT][Z] = fTopMiddle;
							}
							else
								if(pLevel->fPoint[iTopPointT][Z] < fTopMiddle)
								{
									pLevel->fPoint[iTopPointT][Z] += fIncrease/50.0f;
									if(pLevel->fPoint[iTopPointT][Z] > fTopMiddle)
										pLevel->fPoint[iTopPointT][Z] = fTopMiddle;
								}
							SetupMiddlePoints(iX, iY, iTopPointT, pLevel->fPoint, Z);
						}
						if(bWater)
						{
							if(pLevel->fWaterStandartZ[iFloorPointT] > fWaterMiddle)
							{
								pLevel->fWaterStandartZ[iFloorPointT] -= fIncrease/50.0f;
								if(pLevel->fWaterStandartZ[iFloorPointT] < fWaterMiddle)
									pLevel->fWaterStandartZ[iFloorPointT] = fWaterMiddle;
							}
							else
								if(pLevel->fWaterStandartZ[iFloorPointT] < fWaterMiddle)
								{
									pLevel->fWaterStandartZ[iFloorPointT] += fIncrease/50.0f;
									if(pLevel->fWaterStandartZ[iFloorPointT] > fWaterMiddle)
										pLevel->fWaterStandartZ[iFloorPointT] = fWaterMiddle;
								}
							SetupMiddlePoints(iX, iY, iFloorPointT, pLevel->fWaterStandartZ);
						}
						if(bFloor || bTop)
							SetupMiddlePoints(iX, iY, iFloorPointT, iMiddlePointT, iTopPointT, pLevel->fPoint, Z);
					break;
					
					case EDITOR_SELECTED_LOWEST_HEIGHT: // Set to the lowest height
						if(!CHECK_KEY(ASMouse.byButtons, 0))
							break;
						bTerrainChange = TRUE;
						if(bFloor &&
						   pLevel->fPoint[iFloorPointT][Z] < fLowestFloorHeight)
						{
							pLevel->fPoint[iFloorPointT][Z] += fIncrease/50.0f;
							if(pLevel->fPoint[iFloorPointT][Z] > fLowestFloorHeight)
								pLevel->fPoint[iFloorPointT][Z] = fLowestFloorHeight;
							SetupMiddlePoints(iX, iY, iFloorPointT, pLevel->fPoint, Z);
						}
						if(bMiddle &&
						   pLevel->fPoint[iMiddlePointT][Z] < fLowestMiddleHeight)
						{
							pLevel->fPoint[iMiddlePointT][Z] += fIncrease/50.0f;
							if(pLevel->fPoint[iMiddlePointT][Z] > fLowestMiddleHeight)
								pLevel->fPoint[iMiddlePointT][Z] = fLowestMiddleHeight;
							SetupMiddlePoints(iX, iY, iMiddlePointT, pLevel->fPoint, Z);
						}
						if(bTop &&
						   pLevel->fPoint[iTopPointT][Z] < fLowestTopHeight)
						{
							pLevel->fPoint[iTopPointT][Z] += fIncrease/50.0f;
							if(pLevel->fPoint[iTopPointT][Z] > fLowestTopHeight)
								pLevel->fPoint[iTopPointT][Z] = fLowestTopHeight;
							SetupMiddlePoints(iX, iY, iTopPointT, pLevel->fPoint, Z);
						}
						if(bWater &&
						   pLevel->fWaterStandartZ[iFloorPointT] < fLowestWaterHeight)
						{
							pLevel->fWaterStandartZ[iFloorPointT] += fIncrease/50.0f;
							if(pLevel->fWaterStandartZ[iFloorPointT] > fLowestWaterHeight)
								pLevel->fWaterStandartZ[iFloorPointT] = fLowestWaterHeight;
							SetupMiddlePoints(iX, iY, iFloorPointT, pLevel->fWaterStandartZ);
						}
						if(bFloor || bTop)
							SetupMiddlePoints(iX, iY, iFloorPointT, iMiddlePointT, iTopPointT, pLevel->fPoint, Z);
					break;

					case EDITOR_SELECTED_GREATEST_HEIGHT: // Set to the greatest height
						if(!CHECK_KEY(ASMouse.byButtons, 0))
							break;
						bTerrainChange = TRUE;
						if(bFloor &&
						   pLevel->fPoint[iFloorPointT][Z] > fGreatestFloorHeight)
						{
							pLevel->fPoint[iFloorPointT][Z] -= fIncrease/50.0f;
							if(pLevel->fPoint[iFloorPointT][Z] < fGreatestFloorHeight)
								pLevel->fPoint[iFloorPointT][Z] = fGreatestFloorHeight;
							SetupMiddlePoints(iX, iY, iFloorPointT, pLevel->fPoint, Z);
						}
						if(bMiddle &&
						   pLevel->fPoint[iMiddlePointT][Z] > fGreatestMiddleHeight)
						{
							pLevel->fPoint[iMiddlePointT][Z] -= fIncrease/50.0f;
							if(pLevel->fPoint[iMiddlePointT][Z] < fGreatestMiddleHeight)
								pLevel->fPoint[iMiddlePointT][Z] = fGreatestMiddleHeight;
							SetupMiddlePoints(iX, iY, iMiddlePointT, pLevel->fPoint, Z);
						}
						if(bTop &&
						   pLevel->fPoint[iTopPointT][Z] > fGreatestTopHeight)
						{
							pLevel->fPoint[iTopPointT][Z] -= fIncrease/50.0f;
							if(pLevel->fPoint[iTopPointT][Z] < fGreatestTopHeight)
								pLevel->fPoint[iTopPointT][Z] = fGreatestTopHeight;
							SetupMiddlePoints(iX, iY, iTopPointT, pLevel->fPoint, Z);
						}
						if(bWater &&
						   pLevel->fWaterStandartZ[iFloorPointT] > fGreatestWaterHeight)
						{
							pLevel->fWaterStandartZ[iFloorPointT] -= fIncrease/50.0f;
							if(pLevel->fWaterStandartZ[iFloorPointT] < fGreatestWaterHeight)
								pLevel->fWaterStandartZ[iFloorPointT] = fGreatestWaterHeight;
							SetupMiddlePoints(iX, iY, iFloorPointT, pLevel->fWaterStandartZ);
						}
						if(bFloor || bTop)
							SetupMiddlePoints(iX, iY, iFloorPointT, iMiddlePointT, iTopPointT, pLevel->fPoint, Z);
					break;

					case EDITOR_SELECTED_WATER_AMPLITUDE: // Manipulate water point amplitude
						if(!bWater)
							break;
						if(CHECK_KEY(ASMouse.byButtons, 0))
							pLevel->fWaterAmplitude[iFloorPointT] += fIncrease/20.0f;
						if(CHECK_KEY(ASMouse.byButtons, 1))
							pLevel->fWaterAmplitude[iFloorPointT] += fIncrease/200.0f;
						if(CHECK_KEY(ASMouse.byButtons, 2))
							pLevel->fWaterAmplitude[iFloorPointT] = 1.0f;
						SetupMiddlePoints(iX, iY, iFloorPointT, pLevel->fWaterAmplitude);
					break;
				}
			}
		}
	}
	else
	{ // Fields:
		if(!iSize)
			iY = iFieldY;
		else
		{
			iY = iFieldY-iSize;
			if(iSize > 1)
				iY++;
		}
		if(iY < 0)
			iY = 0;
		for(; iY < iFieldY+iSize+1; iY++)
		{
			if(iY >= pLevel->Header.iHeight-1)
				break;
			if(!iSize)
				iX = iFieldX;
			else
			{
				iX = iFieldX-iSize;
				if(iSize > 1)
					iX++;
			}
			if(iX < 0)
				iX = 0;
			for(; iX < iFieldX+iSize+1; iX++)
			{
				if(iX >= pLevel->Header.iWidth-1)
					continue;
				pFieldT = &pLevel->pField[iY*pLevel->Header.iWidth+iX];
				pFieldT->bSelected = TRUE;
				pCurrentFieldT = pLevel->pCurrentField;
				pActorT = pCurrentFieldT->pActor;
				pFieldT->bUpdate = TRUE;
				
				// Now what should be done?
				switch(byEditorMenu)
				{
				/////////////////////////////////////////////////////////////////////////////////////////////////////////////
					case EDITOR_SELECT_MENU:
						switch(byEditorSelected)
						{
							case EDITOR_SELECTED_DECORATION_POSITION:
								if(CHECK_KEY(ASMouse.byButtons, 2))
								{
									pCurrentFieldT->pDecoration->fPos[X] = (float) pCurrentFieldT->iXField+0.5f;
									pCurrentFieldT->pDecoration->fPos[Y] = (float) pCurrentFieldT->iYField+0.5f;
									pFieldT2 = pLevel->ComputeHeight(pCurrentFieldT->pDecoration->fPos[X],
																	 pCurrentFieldT->pDecoration->fPos[Y],
																	 &pCurrentFieldT->pDecoration->fPos[Z],
																	 FACE_FLOOR, FALSE);
									pCurrentFieldT->pDecoration->fPos[Z] -= (pDecorationModels[iCurrentDecorationModel].pModel->fBoundingBox[1][Z]-
																			pDecorationModels[iCurrentDecorationModel].pModel->fBoundingBox[0][Z])*0.03f;
								}
								else
								if(CHECK_KEY(ASMouse.byButtons, 0) && CHECK_KEY(ASMouse.byButtons, 1))
									pCurrentFieldT->pDecoration->fPos[Z] += fIncrease/100;
								else
								{
									if(CHECK_KEY(ASMouse.byButtons, 0))
										pCurrentFieldT->pDecoration->fPos[X] += fIncrease/100;
									if(CHECK_KEY(ASMouse.byButtons, 1))
										pCurrentFieldT->pDecoration->fPos[Y] += fIncrease/100;
								}
							break;

							case EDITOR_SELECTED_DECORATION_ROTATION:
								if(CHECK_KEY(ASMouse.byButtons, 2))
								{
									pCurrentFieldT->pDecoration->fRot[X] = -90.0f;
									pCurrentFieldT->pDecoration->fRot[Y] = 0.0f;
									pCurrentFieldT->pDecoration->fRot[Z] = 0.0f;
								}
								else
								if(CHECK_KEY(ASMouse.byButtons, 0) && CHECK_KEY(ASMouse.byButtons, 1))
									pCurrentFieldT->pDecoration->fRot[Z] += fIncrease/5;
								else
								{
									if(CHECK_KEY(ASMouse.byButtons, 0))
										pCurrentFieldT->pDecoration->fRot[X] += fIncrease/5;
									if(CHECK_KEY(ASMouse.byButtons, 1))
										pCurrentFieldT->pDecoration->fRot[Y] += fIncrease/5;
								}
							break;

							case EDITOR_SELECTED_DECORATION_COLOR:
								ManipulateColor(&pCurrentFieldT->pDecoration->fColor, fIncrease, TRUE);
							break;
							
							case EDITOR_SELECTED_DECORATION_DENSITY:
								ManipulateDensity(&pCurrentFieldT->pDecoration->fColor, fIncrease, TRUE);
							break;

							case EDITOR_SELECTED_DECORATION_SIZE:
								pDecorationT = pCurrentFieldT->pDecoration;
								if(CHECK_KEY(ASMouse.byButtons, 2))
								{
									pDecorationT->fSize[0] = 
									pDecorationT->fSize[1] = 
									pDecorationT->fSize[2] = 0.04f;
								}
								else
								if(CHECK_KEY(ASMouse.byButtons, 0) && CHECK_KEY(ASMouse.byButtons, 1))
									pDecorationT->fSize[Z] += fIncrease/3000;
								else
								{
									if(CHECK_KEY(ASMouse.byButtons, 0))
										pDecorationT->fSize[X] += fIncrease/3000;
									if(CHECK_KEY(ASMouse.byButtons, 1))
										pDecorationT->fSize[Y] += fIncrease/3000;
								}
								pModelT = pDecorationModels[pDecorationT->iDecorationID].pModel;

								// Calculate the real bounding box of this decoration:
								for(i = 0; i < 3; i++)
									for(i2 = 0; i2 < 2; i2++)
										pDecorationT->fModelBoundingBox[i2][i] = pModelT->fBoundingBox[i2][i]*pDecorationT->fSize[i];
							break;
							
							case EDITOR_SELECTED_BOX_ENVIRONMENT_COLOR:
								if(!pActorT)
									break;
								ManipulateColor(&pActorT->fEnvironmentColor, fIncrease, TRUE);
							break;

							case EDITOR_SELECTED_BOX_ENVIRONMENT_DENSITY:
								if(!pActorT)
									break;
								ManipulateDensity(&pActorT->fEnvironmentColor, fIncrease, TRUE);
							break;
						
							case EDITOR_SELECTED_ITEM_MOVE:
								pActorT = pCurrentFieldT->pItem;
								if(!pActorT)
									break;
								ManipulateColor(&pActorT->fPosTemp, fIncrease, FALSE);
							break;

							case EDITOR_SELECTED_ITEM_ROTATION:
								pActorT = pCurrentFieldT->pItem;
								if(!pActorT)
									break;
								if(CHECK_KEY(ASMouse.byButtons, 2))
								{
									pActorT->fRot[X] = 0.0f;
									pActorT->fRot[Y] = 0.0f;
									pActorT->fRot[Z] = 0.0f;
								}
								else
								if(CHECK_KEY(ASMouse.byButtons, 0) && CHECK_KEY(ASMouse.byButtons, 1))
									pActorT->fRot[Z] += fIncrease/5;
								else
								{
									if(CHECK_KEY(ASMouse.byButtons, 0))
										pActorT->fRot[X] += fIncrease/5;
									if(CHECK_KEY(ASMouse.byButtons, 1))
										pActorT->fRot[Y] += fIncrease/5;
								}
							break;

							case EDITOR_SELECTED_ITEM_COLOR:
								pActorT = pCurrentFieldT->pItem;
								if(!pActorT)
									break;
								ManipulateColor(&pActorT->fColor, fIncrease, TRUE);
							break;

							case EDITOR_SELECTED_ACTOR_COLOR:
								pActorT = pCurrentFieldT->pActor;
								if(!pActorT)
									break;
								ManipulateColor(&pActorT->fColor, fIncrease, TRUE);
							break;

							default:
								if(!CHECK_KEY(ASMouse.byButtons, 0))
									break;
								if(byEditorSelected == EDITOR_SELECTED_BEAMER_TARGET)
								{
									byEditorSelected = -1;
									if(pCurrentFieldT->iID == pFieldT->iID)
									{
										pCurrentFieldT->iBeamerTarget = -1;
										pCurrentFieldT->iBeamerParticleSystemID = -1;
									}
									else
										pCurrentFieldT->iBeamerTarget = pFieldT->iID;
									break;
								}
								pLevel->pCurrentField = pFieldT;
								iCurrentEditorTab = -1;
								SendMessage(hWndEditor, WM_NOTIFY, IDC_EDITOR_TAB, 0);
							break;
						}
					break;
				/////////////////////////////////////////////////////////////////////////////////////////////////////////////

				/////////////////////////////////////////////////////////////////////////////////////////////////////////////
					case EDITOR_BRUSH_MENU: // We set something into the level: (a wall, or deactivate a field...)
						if(CHECK_KEY(ASMouse.byButtons, 0))
						{
							bTerrainChange = bFieldChange = TRUE;
							switch(byEditorSelected)
							{
								case EDITOR_SELECTED_WALL: // Set a wall
									if(pFieldT->pActor || pFieldT->pBridgeActor || pFieldT->pItem)
										break;
									pFieldT->bWallHole = FALSE;
									pLevel->SetFieldWall(iX, iY, TRUE, FALSE);
								break;
				
								case EDITOR_SELECTED_DEACTIVATE_FIELD: // Deactivate a field
									pFieldT->bWallHole = FALSE;
									pLevel->SetFieldWall(iX, iY, FALSE, FALSE);
									pFieldT->bActive = FALSE;
									pFieldT->bWall = FALSE;
								goto FreeField;

								case EDITOR_SELECTED_ACTIVATE_WATER: // Activate the water on this field
									pFieldT->bActivateWater = TRUE;
								break;

								case EDITOR_SELECTED_ACTIVATE_WATER_BUBBLES: // Activate the water bubbles on this field
									pFieldT->bActivateWaterBubbles = TRUE;
								break;

								case EDITOR_SELECTED_FORCE_WATER_BUBBLES: // Force the water bubbles to be seen on this field
									pFieldT->bForceWaterBubbles = TRUE;
								break;
								
								case EDITOR_SELECTED_CLEAR_FIELD:
								FreeField:
									// Destroy all actors on this field;
									for(i = 0; i < pLevel->Header.iMaxActors; i++)
									{
										pActorT = pLevel->pActorList[i];
										if(pActorT->iFieldID == pFieldT->iID)
											pActorT->bActive = FALSE;
									}
									if(pFieldT->pActor && pFieldT->bWall)
										pFieldT->bWall = FALSE;
									if(pFieldT->pBridgeActor)
										pFieldT->bActive = FALSE;
									pFieldT->pActor = pFieldT->pBridgeActor = 
									pFieldT->pItem = NULL;
									if(pFieldT->pDecoration)
									{
										if(pFieldT->pDecoration->iTexture >= 0)
											pLevel->pTexture[pFieldT->pDecoration->iTexture].iUsed++;
										SAFE_DELETE(pFieldT->pDecoration);
									}
								break;

								case EDITOR_SELECTED_WALL_HOLE:
									pFieldT->bActive = FALSE;
									pFieldT->bWallHole = TRUE;
									pFieldT->bWall = TRUE;
									pLevel->SetFieldWall(iX, iY, pFieldT->bWall, FALSE);
								goto FreeField;

								case EDITOR_SELECTED_ALWAYS_WALL: pFieldT->bAlwaysWall = TRUE; break;
								case EDITOR_SELECTED_INDESTRUCTIBLE_WALL: pFieldT->bIndestructibleWall = TRUE; break;
								case EDITOR_SELECTED_NO_BRIDGE_POSSIBLE: pFieldT->bNoBridgePossible = TRUE; break;
							}
						}
						switch(byEditorSelected)
						{
							case EDITOR_SELECTED_WATER_TYPE: // Set the water type
								if(CHECK_KEY(ASMouse.byButtons, 0))
									pFieldT->WaterType = WATER_NORMAL;
								if(CHECK_KEY(ASMouse.byButtons, 1))
									pFieldT->WaterType = WATER_ACID;
								if(CHECK_KEY(ASMouse.byButtons, 2))
									pFieldT->WaterType = WATER_LAVA;
							break;
						}
						if(CHECK_KEY(ASMouse.byButtons, 1))
						{
							bTerrainChange = bFieldChange = TRUE;
							switch(byEditorSelected)
							{
								case EDITOR_SELECTED_WALL: // Delete a wall
									if(pFieldT->pActor || pFieldT->pBridgeActor || pFieldT->pItem)
										break;
									pFieldT->bWallHole = FALSE;
									pLevel->SetFieldWall(iX, iY, FALSE, FALSE);
								break;

								case EDITOR_SELECTED_DEACTIVATE_FIELD: // Activate a field
									if(iX != pLevel->Header.iWidth-1 && iY != pLevel->Header.iHeight-1)						
										pFieldT->bActive = TRUE;
									pFieldT->bWallHole = FALSE;
									pLevel->SetFieldWall(iX, iY, TRUE, TRUE);
								break;


								case EDITOR_SELECTED_ACTIVATE_WATER: // Activate the water on this field
									pFieldT->bActivateWater = FALSE;
								break;

								case EDITOR_SELECTED_ACTIVATE_WATER_BUBBLES: // Activate the water bubbles on this field
									pFieldT->bActivateWaterBubbles = FALSE;
								break;

								case EDITOR_SELECTED_FORCE_WATER_BUBBLES: // Force the water bubbles to be seen on this field
									pFieldT->bForceWaterBubbles = FALSE;
								break;

								case EDITOR_SELECTED_WALL_HOLE:
									if(pFieldT->bActive)
										break;
									pFieldT->bWallHole = FALSE;
									pLevel->SetFieldWall(iX, iY, FALSE, FALSE);
									pFieldT->bActive = FALSE;
								break;

								case EDITOR_SELECTED_ALWAYS_WALL: pFieldT->bAlwaysWall = FALSE; break;
								case EDITOR_SELECTED_INDESTRUCTIBLE_WALL: pFieldT->bIndestructibleWall = FALSE; break;
								case EDITOR_SELECTED_NO_BRIDGE_POSSIBLE: pFieldT->bNoBridgePossible = FALSE; break;
							}
						}							
					break;
				/////////////////////////////////////////////////////////////////////////////////////////////////////////////

				/////////////////////////////////////////////////////////////////////////////////////////////////////////////
					case EDITOR_OBJECT_MENU: // We set some stuff into your level
						switch(byEditorSelected)
						{
						// Objects:
							case EDITOR_SELECTED_OBJECT_BLIBS:
								if(CHECK_KEY(ASMouse.byButtons, 1))
								{ // Delete Blibs:
									bFieldChange = TRUE;
									if(pPlayer && pFieldT->pActor == pPlayer)
									{
										pPlayer->bActive = FALSE;
										pPlayer = NULL;
										pFieldT->pActor = NULL;
									}
									break;
								}
								if(!CHECK_KEY(ASMouse.byButtons, 0))
									break;
								if((pFieldT->bWall && !pFieldT->bWallHole) ||
								   (pFieldT->pActor && pFieldT->pActor != pPlayer) ||
								   (!pFieldT->bActive && !pFieldT->pBridgeActor) ||
								   (pFieldT->pBridgeActor && pFieldT->pBridgeActor->bBridgeMovement))
									break;
								if(!pPlayer)
								{
									pActorT	= pLevel->FindFreeActor();
									if(!pActorT)
										break;
									pPlayer = pActorT;
								}
								else
									pLevel->pField[pPlayer->iFieldID].pActor = NULL;
								pPlayer->InitBlibs(iX, iY);
							break;

							case EDITOR_SELECTED_OBJECT_BLIBS_CLONE:
								if(CHECK_KEY(ASMouse.byButtons, 1))
								{ // Delete Blibs:
									bFieldChange = TRUE;
									if(pFieldT->pActor &&
									   pFieldT->pActor->Type == AT_BLIBS &&
									   pFieldT->pActor != pPlayer)
									{
										pFieldT->pActor->bActive = FALSE;
										pFieldT->pActor = NULL;
									}
									break;
								}
								if(!CHECK_KEY(ASMouse.byButtons, 0))
									break;
								if((pFieldT->bWall && !pFieldT->bWallHole) ||
								   (pFieldT->pActor && pFieldT->pActor != pPlayer) ||
								   (!pFieldT->bActive && !pFieldT->pBridgeActor) ||
								   (pFieldT->pBridgeActor && pFieldT->pBridgeActor->bBridgeMovement))
									break;
								pActorT	= pLevel->FindFreeActor();
								if(!pActorT)
									break;
								pActorT->InitBlibs(iX, iY);
								pActorT->bClone = TRUE;
								pActorT->Item[AT_LIFE_ITEM].iNumber = 0;
							break;

							case EDITOR_SELECTED_OBJECT_BOX_NORMAL:
							case EDITOR_SELECTED_OBJECT_BOX_RED:
							case EDITOR_SELECTED_OBJECT_BOX_GREEN:
							case EDITOR_SELECTED_OBJECT_BOX_BLUE:
								if(CHECK_KEY(ASMouse.byButtons, 1))
								{ // Delete an box:
									bFieldChange = TRUE;
									if(pFieldT->pActor && 
									  (pFieldT->pActor->Type == AT_BOX_NORMAL ||
									   pFieldT->pActor->Type == AT_BOX_RED ||
									   pFieldT->pActor->Type == AT_BOX_GREEN ||
									   pFieldT->pActor->Type == AT_BOX_BLUE))
									{ // Delete this box;
										pFieldT->pActor->bActive = FALSE;
										pFieldT->pActor = NULL;
									}
									else
									if(pFieldT->pBridgeActor)
									{ // Delete the bridge actor;
										pFieldT->pBridgeActor->bActive = FALSE;
										pFieldT->pBridgeActor = NULL;
										pFieldT->bActive = FALSE;
									}
									break;
								}
								if(!CHECK_KEY(ASMouse.byButtons, 0))
									break;
								if((pFieldT->bWall && !pFieldT->bWallHole) || pFieldT->pActor ||
								   (pFieldT->pBridgeActor && pFieldT->pBridgeActor->bBridgeMovement))
									break;
								bFieldChange = TRUE;
								// Set a box on this field:
								pActorT	= pLevel->FindFreeActor();
								if(!pActorT)
									break;
								switch(byEditorSelected)
								{
									case EDITOR_SELECTED_OBJECT_BOX_NORMAL: pActorT->Type = AT_BOX_NORMAL; break;

									case EDITOR_SELECTED_OBJECT_BOX_RED:
										pActorT->Type = AT_BOX_RED;
										pActorT->fColor[G] = pActorT->fColor[B] = 0.0f;
									break;
									
									case EDITOR_SELECTED_OBJECT_BOX_GREEN:
										pActorT->Type = AT_BOX_GREEN;
										pActorT->fColor[R] = pActorT->fColor[B] = 0.0f;
									break;
									
									case EDITOR_SELECTED_OBJECT_BOX_BLUE:
										pActorT->Type = AT_BOX_BLUE;
										pActorT->fColor[R] = pActorT->fColor[G] = 0.0f;
									break;
								}
								pActorT->InitBox(iX, iY);
							break;


						// Items:
							case EDITOR_SELECTED_ITEM_HEALTH:
							case EDITOR_SELECTED_ITEM_HEALTH_INCREASE:
							case EDITOR_SELECTED_ITEM_LIFE:
							case EDITOR_SELECTED_ITEM_PULL:
							case EDITOR_SELECTED_ITEM_CHEST:
							case EDITOR_SELECTED_ITEM_STRENGTH:
							case EDITOR_SELECTED_ITEM_WEAPON:
							case EDITOR_SELECTED_ITEM_COIN:
							case EDITOR_SELECTED_ITEM_GHOST:
							case EDITOR_SELECTED_ITEM_TIME:
							case EDITOR_SELECTED_ITEM_STEP:
							case EDITOR_SELECTED_ITEM_SPEED:
							case EDITOR_SELECTED_ITEM_WING:
							case EDITOR_SELECTED_ITEM_SHIELD:
							case EDITOR_SELECTED_ITEM_JUMP:
							case EDITOR_SELECTED_ITEM_AIR:
							case EDITOR_SELECTED_ITEM_AIR_INCREASE:
							case EDITOR_SELECTED_ITEM_THROW:
							case EDITOR_SELECTED_ITEM_KICK:
							case EDITOR_SELECTED_ITEM_BAG:
							case EDITOR_SELECTED_ITEM_DYNAMITE:
								if(CHECK_KEY(ASMouse.byButtons, 1))
								{
									if(pFieldT->pItem)
									{
										pFieldT->pItem->bActive = FALSE;
										pFieldT->pItem = NULL;
									}
									break;
								}
								if(!CHECK_KEY(ASMouse.byButtons, 0))
									break;
								if((pFieldT->bWall && !pFieldT->bWallHole) || pFieldT->pItem)
									break;
								pActorT	= pLevel->FindFreeActor();
								if(!pActorT)
									break;
								pActorT->bActive = TRUE;
								pActorT->iFieldPos[X] = iX;
								pActorT->iFieldPos[Y] = iY;
								pActorT->byDirection = iEditorRotate;
								pActorT->fRot[Y] =  pActorT->byDirection*90.0f;
								pActorT->fSize = 1.0f;
								pActorT->bDeathWave = TRUE;
								pActorT->iFieldID = pFieldT->iID;
								pActorT->iNumber = iEditorObjectsNumber;
								switch(byEditorSelected)
								{
									case EDITOR_SELECTED_ITEM_HEALTH: pActorT->Type = AT_HEALTH_ITEM; strcpy(pActorT->byName, AS_T(T_Health)); break;
									case EDITOR_SELECTED_ITEM_HEALTH_INCREASE: pActorT->Type = AT_HEALTH_INCREASE_ITEM; strcpy(pActorT->byName, AS_T(T_HealthIncrease)); break;
									case EDITOR_SELECTED_ITEM_LIFE: pActorT->Type = AT_LIFE_ITEM; strcpy(pActorT->byName, AS_T(T_Life)); break;
									case EDITOR_SELECTED_ITEM_PULL: pActorT->Type = AT_PULL_ITEM; strcpy(pActorT->byName, AS_T(T_Pull)); break;
									case EDITOR_SELECTED_ITEM_CHEST: pActorT->Type = AT_CHEST_ITEM; strcpy(pActorT->byName, AS_T(T_Chest)); break;
									case EDITOR_SELECTED_ITEM_STRENGTH: pActorT->Type = AT_STRENGTH_ITEM; strcpy(pActorT->byName, AS_T(T_Strength)); break;
									case EDITOR_SELECTED_ITEM_WEAPON: pActorT->Type = AT_WEAPON_ITEM; strcpy(pActorT->byName, AS_T(T_Weapon)); break;
									case EDITOR_SELECTED_ITEM_COIN: pActorT->Type = AT_COIN_ITEM; strcpy(pActorT->byName, AS_T(T_Coin)); break;
									case EDITOR_SELECTED_ITEM_GHOST: pActorT->Type = AT_GHOST_ITEM; strcpy(pActorT->byName, AS_T(T_Ghost)); break;
									case EDITOR_SELECTED_ITEM_TIME: pActorT->Type = AT_TIME_ITEM; strcpy(pActorT->byName, AS_T(T_Time)); break;
									case EDITOR_SELECTED_ITEM_STEP: pActorT->Type = AT_STEP_ITEM; strcpy(pActorT->byName, AS_T(T_Step)); break;
									case EDITOR_SELECTED_ITEM_SPEED: pActorT->Type = AT_SPEED_ITEM; strcpy(pActorT->byName, AS_T(T_Speed)); break;
									case EDITOR_SELECTED_ITEM_WING: pActorT->Type = AT_WING_ITEM; strcpy(pActorT->byName, AS_T(T_Wings)); break;
									case EDITOR_SELECTED_ITEM_SHIELD: pActorT->Type = AT_SHIELD_ITEM; strcpy(pActorT->byName, AS_T(T_Shield)); break;
									case EDITOR_SELECTED_ITEM_JUMP: pActorT->Type = AT_JUMP_ITEM; strcpy(pActorT->byName, AS_T(T_Jump)); break;
									case EDITOR_SELECTED_ITEM_AIR: pActorT->Type = AT_AIR_ITEM; strcpy(pActorT->byName, AS_T(T_Air)); break;
									case EDITOR_SELECTED_ITEM_AIR_INCREASE: pActorT->Type = AT_AIR_INCREASE_ITEM; strcpy(pActorT->byName, AS_T(T_AirIncrease)); break;
									case EDITOR_SELECTED_ITEM_THROW: pActorT->Type = AT_THROW_ITEM; strcpy(pActorT->byName, AS_T(T_Throw)); break;
									case EDITOR_SELECTED_ITEM_KICK: pActorT->Type = AT_KICK_ITEM; strcpy(pActorT->byName, AS_T(T_Kick)); break;
									case EDITOR_SELECTED_ITEM_BAG: pActorT->Type = AT_BAG_ITEM; strcpy(pActorT->byName, AS_T(T_Bag)); break;
									case EDITOR_SELECTED_ITEM_DYNAMITE: pActorT->Type = AT_DYNAMITE_ITEM; strcpy(pActorT->byName, AS_T(T_Dynamite)); break;
								}
								pFieldT->pItem = pActorT;
							break;

						// Enemies:
							case EDITOR_SELECTED_ENEMY_X3:
								ActorType = AT_X3;
								goto SetEnemy;

							case EDITOR_SELECTED_ENEMY_LUCIFER_HEAD:
								ActorType = AT_LUCIFER_HEAD;
								goto SetEnemy;

							case EDITOR_SELECTED_ENEMY_LUCIFER:
								ActorType = AT_LUCIFER;
								goto SetEnemy;

							case EDITOR_SELECTED_ENEMY_MOBMOB:
								ActorType = AT_MOBMOB;
							SetEnemy:
								if(CHECK_KEY(ASMouse.byButtons, 1))
								{
									bFieldChange = TRUE;
									if(pFieldT->pActor && 
									  (pFieldT->pActor->Type == AT_MOBMOB ||
									   pFieldT->pActor->Type == AT_X3 ||
									   pFieldT->pActor->Type == AT_LUCIFER_HEAD ||
									   pFieldT->pActor->Type == AT_LUCIFER))
									{ // Delete this enemy;
										pFieldT->pActor->bActive = FALSE;
										pFieldT->pActor = NULL;
									}
									break;
								}
								if(!CHECK_KEY(ASMouse.byButtons, 0))
									break;
								if(ActorType != AT_LUCIFER_HEAD)
								{
									if((pFieldT->bWall && !pFieldT->bWallHole) || pFieldT->pActor ||
									   (pFieldT->pBridgeActor && pFieldT->pBridgeActor->bBridgeMovement))
										break;
								}
								else
								{
									if(pFieldT->pActor)
										break;
								}
								pActorT	= pLevel->FindFreeActor();
								if(!pActorT)
									break;
								bFieldChange = TRUE;
								pActorT->bActive = TRUE;
								pActorT->Type = ActorType;
								pActorT->iFieldPos[X] = iX;
								pActorT->iFieldPos[Y] = iY;
								pActorT->fSize = 1.0f;
								pActorT->fAir = 1.0f;
								pActorT->fMaxAir = 100.0f;
								pActorT->fTurningSpeed = 1.0f;
								pActorT->fAniSpeed = 200.0f;
								if(ActorType == AT_LUCIFER)
									pActorT->fHealth = pActorT->fMaxHealth = 1000.0f;
								else
									pActorT->fHealth = pActorT->fMaxHealth = 100.0f;
								pActorT->vCollisionEllipsoid = 0.2f;
								pActorT->bSquashable = TRUE;
								pActorT->bAggressive = TRUE;
								pActorT->bMobile = TRUE;
								pActorT->Action = AA_NOTHING;
								pActorT->fVelocity[1] = 1.0f;
								pActorT->byDirection = iEditorRotate;
								pActorT->fRot[Y] =  pActorT->byDirection*90.0f;
								pActorT->fColor[0] = 1.0f;
								pActorT->fColor[1] = 1.0f;
								pActorT->fColor[2] = 1.0f;
								pActorT->iFieldID = pFieldT->iID;
								pLevel->pField[pActorT->iFieldID].pActor = pActorT;
								if(ActorType == AT_MOBMOB)
									pActorT->bFollow = TRUE;
							break;
						}
					break;
				/////////////////////////////////////////////////////////////////////////////////////////////////////////////

				/////////////////////////////////////////////////////////////////////////////////////////////////////////////
					case EDITOR_SURFACE_MENU: // We setup surfaces on the field faces:
						if(!CHECK_KEY(ASMouse.byButtons, 0))
							break;
						bFieldChange = TRUE;
						if(!pFieldT->bActive)
						{
							if(CHECK_KEY(ASMouse.byButtons, 1) && !iEditorCurrentSurfaceType)
								pFieldT->bActive = TRUE;
						}
						hWndT = hWndEditorTab[TAB_EDITOR_SURFACES];
						for(i = 0; i < 7; i++)
						{
							iSurface = -1;
							if(i == 0 && SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_FLOOR, BM_GETCHECK, 0, 0L))
							{
								iSurface = FACE_FLOOR;
								pFieldT->iBeamerTarget = -1;
							}
							if(i == 1 && SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_FRONT, BM_GETCHECK, 0, 0L))
								iSurface = FACE_FRONT;
							if(i == 2 && SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_TOP, BM_GETCHECK, 0, 0L))
								iSurface = FACE_TOP;
							if(i == 3 && SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_RIGHT, BM_GETCHECK, 0, 0L))
								iSurface = FACE_RIGHT;
							if(i == 4 && SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_BOTTOM, BM_GETCHECK, 0, 0L))
								iSurface = FACE_BOTTOM;
							if(i == 5 && SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_LEFT, BM_GETCHECK, 0, 0L))
								iSurface = FACE_LEFT;
							if(i == 6 && SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_WATER, BM_GETCHECK, 0, 0L))
								iSurface = FACE_WATER;
							if(iSurface == -1)
								continue;
							pFieldT->Side[iSurface].bFaceAlwaysActive = SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_ALWAYS_ACTIVE, BM_GETCHECK, 0, 0L);
							pFieldT->Side[iSurface].bFace2Sides = SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_2_SIDES, BM_GETCHECK, 0, 0L);
							pFieldT->Side[iSurface].bFaceSwapSides = SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_SWAP_SIDES, BM_GETCHECK, 0, 0L);
							pFieldT->Side[iSurface].bDisableWaterSide = SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_DISABLE_WATER_SIDE, BM_GETCHECK, 0, 0L);
							pFieldT->Side[iSurface].bWallSide = SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_WALL_SIDE, BM_GETCHECK, 0, 0L);
							pFieldT->Side[iSurface].bInvisible = SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_INVISIBLE, BM_GETCHECK, 0, 0L);
							if(SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_SET_ONLY_ATTRIBUTES, BM_GETCHECK, 0, 0L))
								continue; // We only want to change the attributes!
							
							if(iSurface != FACE_WATER)
								pLevel->SetFieldWall(iX, iY, pFieldT->bWall, FALSE);
							if(iEditorCurrentSurfaceType != 2)
							{
								pFieldSurfaceT = &pFieldT->Side[iSurface].Surface[iEditorCurrentSurfaceType];
								if(pFieldSurfaceT->pSurface)
									pFieldSurfaceT->pSurface->iUsed--;
								pFieldSurfaceT->iSurface = pLevel->iCurrentSurface;
								pFieldSurfaceT->pSurface = pLevel->pCurrentSurface;
								pFieldSurfaceT->pSurface->iUsed++;
								pFieldSurfaceT->iSurfaceRotation = iEditorRotate;
								pFieldSurfaceT->iCurrentAniStep = 0;
								pFieldSurfaceT->dwLastTime = g_lGameTimer;
								pFieldSurfaceT->dwLastChangeTime = g_lGameTimer;
							}
							else
							{ // Remove the second surface:
								pFieldSurfaceT = &pFieldT->Side[iSurface].Surface[1];
								if(pFieldSurfaceT->pSurface)
								{
									pFieldSurfaceT->pSurface->iUsed--;
									pFieldSurfaceT->iSurface = -1;
									pFieldSurfaceT->pSurface = NULL;
								}
							}
						}
						bTerrainChange = TRUE;
					break;
				/////////////////////////////////////////////////////////////////////////////////////////////////////////////

				/////////////////////////////////////////////////////////////////////////////////////////////////////////////
					case EDITOR_DECORATION_MENU:
						if(CHECK_KEY(ASMouse.byButtons, 0) &&
						   iCurrentDecorationModel != -1 &&
						   !pFieldT->pDecoration && pDecorationModels)
						{ // Set decoration:
							pDecorationT = pFieldT->pDecoration = (FIELD_DECORATION *) malloc(sizeof(FIELD_DECORATION));
							memset(pDecorationT, 0, sizeof(FIELD_DECORATION));
							pDecorationT->fPos[X] = (float) pFieldT->iXField+0.5f;
							pDecorationT->fPos[Y] = (float) pFieldT->iYField+0.5f;
							pFieldT2 = pLevel->ComputeHeight(pDecorationT->fPos[X],
															 pDecorationT->fPos[Y],
															 &pDecorationT->fPos[Z],
															 FACE_FLOOR, FALSE);
							pDecorationT->fRot[X] = -90.0f;
							pDecorationT->fSize[0] = 
							pDecorationT->fSize[1] = 
							pDecorationT->fSize[2] = 0.04f;
							pDecorationT->fColor[R] = 
							pDecorationT->fColor[G] = 
							pDecorationT->fColor[B] = 
							pDecorationT->fColor[A] = 1.0f;
							pDecorationT->bCullBack = TRUE;
							pDecorationT->bAnimated = bDecorationModelAnimated;
							pDecorationT->iDecorationID = iCurrentDecorationModel;
							pDecorationT->iSpeed = iDecorationModelSpeed;
							pDecorationT->dwAniTime = g_lGameTimer;
							pDecorationT->iTexture = iCurrentModelTexture;
							pDecorationT->byAnimation = (char) iCurrentDecorationModelAnimation;
							pModelT = pDecorationModels[pDecorationT->iDecorationID].pModel;

							// Calculate the real bounding box of this decoration:
							for(i = 0; i < 3; i++)
								for(i2 = 0; i2 < 2; i2++)
									pDecorationT->fModelBoundingBox[i2][i] = pModelT->fBoundingBox[i2][i]*pDecorationT->fSize[i];

							if(pDecorationT->iTexture >= 0)
							{
								pLevel->pTexture[pDecorationT->iTexture].iUsed++;
								strcpy(pDecorationT->byTextureFilename, pLevel->pTexture[pFieldT->pDecoration->iTexture].byFilename);
							}
							LevelTempCamera.fPos[X] = -1;
							LevelTempCamera.fPos[Y] = -1;
							bFieldChange = TRUE;
						}
						if(CHECK_KEY(ASMouse.byButtons, 1))
						{ // Delete decoration:
							if(pFieldT->pDecoration)
							{
								if(pFieldT->pDecoration->iTexture >= 0)
									pLevel->pTexture[pFieldT->pDecoration->iTexture].iUsed++;
								SAFE_DELETE(pFieldT->pDecoration);
							}
							LevelTempCamera.fPos[Y] = -1;
							LevelTempCamera.fPos[X] = -1;
							bFieldChange = TRUE;
						}
					break;
				}
			}
		}
	}

	// Camera speed adjust keys:
	if(CHECK_KEY(ASKeys, DIK_1))
		fCameraVelocity = 0.1f;
	if(CHECK_KEY(ASKeys, DIK_2))
		fCameraVelocity = 0.2f;
	if(CHECK_KEY(ASKeys, DIK_3))
		fCameraVelocity = 0.3f;
	if(CHECK_KEY(ASKeys, DIK_4))
		fCameraVelocity = 0.4f;
	if(CHECK_KEY(ASKeys, DIK_5))
		fCameraVelocity = 0.5f;
	if(CHECK_KEY(ASKeys, DIK_6))
		fCameraVelocity = 0.6f;
	if(CHECK_KEY(ASKeys, DIK_7))
		fCameraVelocity = 0.7f;
	if(CHECK_KEY(ASKeys, DIK_8))
		fCameraVelocity = 0.8f;
	if(CHECK_KEY(ASKeys, DIK_9))
		fCameraVelocity = 0.9f;
	if(CHECK_KEY(ASKeys, DIK_0))
		fCameraVelocity = 1.0f;

	// Check if something on the fields has changed:
	if(bFieldChange)
	{
		pLevel->bForceVisiblityUpdate = TRUE;
		pLevel->UpdateMissions();
		pLevel->GetBeamerList();
		pLevel->GetBeamerList();
		pLevel->GetDecorationList();
		pLevel->GetTriggerList();
		pLevel->GetAnimatedSurfacesList();
	}
	if(!bTerrainChange || g_lNow-lEditorLastLevelUpdate < 200)
		return 0;	
	lEditorLastLevelUpdate = g_lNow;

	FLOAT3 fPoint;
	FLOAT3 fRayDirection;

	fRayDirection[X] = 0.0f;
	fRayDirection[Y] = 0.0f;
	fRayDirection[Z] = 1.0f;
	for(i = 0; i < pLevel->Header.iFields; i++)
	{
		if(pLevel->pField[i].iBeamerParticleSystemID == -1)
			continue;
		ParticleManager.pSystem[pLevel->pField[i].iBeamerParticleSystemID].fStartPos[X] = pLevel->pField[i].iXField+0.5f;
		ParticleManager.pSystem[pLevel->pField[i].iBeamerParticleSystemID].fStartPos[Y] = pLevel->pField[i].iYField+0.5f;
		fPoint[X] = fPoint[Y] = fPoint[Z] = 0.0f;
/*		pLevel->ComputeHeight(ParticleManager.pSystem[pLevel->pField[i].iBeamerParticleSystemID].fStartPos[X], 
							  ParticleManager.pSystem[pLevel->pField[i].iBeamerParticleSystemID].fStartPos[Y],
							  fRayDirection, &fPoint, FACE_FLOOR, 0.2f);*/
		ParticleManager.pSystem[pLevel->pField[i].iBeamerParticleSystemID].fStartPos[Z] = fPoint[Z];
	}
	
	// Recalculate all if something on the terrain has changed:
	for(i = 0; i < pLevel->Header.iMaxActors; i++)
	{
		pActorT = pLevel->pActorList[i];
		pActorT->fLastHeightCheckWorldPos[X] = 
		pActorT->fLastHeightCheckWorldPos[Y] = -1.0f;
		if(pActorT->bBridge)
			pActorT->bBridgeMovement = TRUE;
	}
	pLevel->bForceVisiblityUpdate = TRUE;
	pLevel->CalculateFieldNormals(FALSE);
	pLevel->CalculatePointNormals();
	pLevel->CalculateFacesMidPoint(FALSE);
	pLevel->CalculateFieldBoundingBoxes();
	pLevel->GetMinMiddleMax();
	pLevel->Quadtree.GetBoundingBox(pLevel);
	pLevel->DisableFieldUpdate();
	memset(&LevelTempCamera, 0, sizeof(AS_CAMERA));

	return 0;
} // end EditorCheck()

void SetupMiddlePoints(int iX, int iY, int iPointT, float *fTemp)
{ // begin SetupMiddlePoints()
	if(bAdvancedTerrainManipulation) // Setup the middle points:
		return;

	// Update the middle left, upper, right and lower points of this point:
	if(iX-2 >= 0)
		fTemp[iPointT-1] = (fTemp[iPointT]+fTemp[iPointT-2])/2;
	if(iY-2 >= 0)
		fTemp[iPointT-pLevel->Header.iXPoints] = (fTemp[iPointT]+
								fTemp[iPointT-pLevel->Header.iXPoints*2])/2;

	if(iX+2 < pLevel->Header.iXPoints)
		fTemp[iPointT+1] = (fTemp[iPointT]+fTemp[iPointT+2])/2;
	if(iY+2 < pLevel->Header.iYPoints)
		fTemp[iPointT+pLevel->Header.iXPoints] = (fTemp[iPointT]+
							 fTemp[iPointT+pLevel->Header.iXPoints*2])/2;
	// Setup the middle points of the bounding fields:
	// Left/upper field:
	if(iX-2 >= 0 && iY-2 >= 0)
		fTemp[iPointT-pLevel->Header.iXPoints-1] = 
					(fTemp[iPointT-pLevel->Header.iXPoints*2-2]+
					 fTemp[iPointT-pLevel->Header.iXPoints*2]+
					 fTemp[iPointT]+fTemp[iPointT-2])/4;
	// Left/lower field:
	if(iX-2 >= 0 && iY+2 < pLevel->Header.iYPoints)
		fTemp[iPointT+pLevel->Header.iXPoints-1] = 
					(fTemp[iPointT+pLevel->Header.iXPoints*2-2]+
					 fTemp[iPointT+pLevel->Header.iXPoints*2]+
					 fTemp[iPointT]+fTemp[iPointT-2])/4;

	// Right/upper field:
	if(iX+2 < pLevel->Header.iXPoints && iY-2 >= 0)
		fTemp[iPointT-pLevel->Header.iXPoints+1] = 
					(fTemp[iPointT-pLevel->Header.iXPoints*2+2]+
					 fTemp[iPointT-pLevel->Header.iXPoints*2]+
					 fTemp[iPointT]+fTemp[iPointT+2])/4;
	// Right/lower field:
	if(iX+2 < pLevel->Header.iXPoints && iY+2 < pLevel->Header.iYPoints)
		fTemp[iPointT+pLevel->Header.iXPoints+1] = 
					(fTemp[iPointT+pLevel->Header.iXPoints*2+2]+
					 fTemp[iPointT+pLevel->Header.iXPoints*2]+
					 fTemp[iPointT]+fTemp[iPointT+2])/4;
} // end SetupMiddlePoints()

void SetupMiddlePoints(int iX, int iY, int iPointT, FLOAT3 *fTemp, int i)
{ // begin SetupMiddlePoints()
	if(bAdvancedTerrainManipulation) // Setup the middle points:
		return;

	// Update the middle left, upper, right and lower points of this point:
	if(iX-2 >= 0)
		fTemp[iPointT-1][i] = (fTemp[iPointT][i]+fTemp[iPointT-2][i])/2;
	if(iY-2 >= 0)
		fTemp[iPointT-pLevel->Header.iXPoints][i] = (fTemp[iPointT][i]+
								fTemp[iPointT-pLevel->Header.iXPoints*2][i])/2;

	if(iX+2 < pLevel->Header.iXPoints)
		fTemp[iPointT+1][i] = (fTemp[iPointT][i]+fTemp[iPointT+2][i])/2;
	if(iY+2 < pLevel->Header.iYPoints)
		fTemp[iPointT+pLevel->Header.iXPoints][i] = (fTemp[iPointT][i]+
							 fTemp[iPointT+pLevel->Header.iXPoints*2][i])/2;
	// Setup the middle points of the bounding fields:
	// Left/upper field:
	if(iX-2 >= 0 && iY-2 >= 0)
		fTemp[iPointT-pLevel->Header.iXPoints-1][i] = 
					(fTemp[iPointT-pLevel->Header.iXPoints*2-2][i]+
					 fTemp[iPointT-pLevel->Header.iXPoints*2][i]+
					 fTemp[iPointT][i]+fTemp[iPointT-2][i])/4;
	// Left/lower field:
	if(iX-2 >= 0 && iY+2 < pLevel->Header.iYPoints)
		fTemp[iPointT+pLevel->Header.iXPoints-1][i] = 
					(fTemp[iPointT+pLevel->Header.iXPoints*2-2][i]+
					 fTemp[iPointT+pLevel->Header.iXPoints*2][i]+
					 fTemp[iPointT][i]+fTemp[iPointT-2][i])/4;

	// Right/upper field:
	if(iX+2 < pLevel->Header.iXPoints && iY-2 >= 0)
		fTemp[iPointT-pLevel->Header.iXPoints+1][i] = 
					(fTemp[iPointT-pLevel->Header.iXPoints*2+2][i]+
					 fTemp[iPointT-pLevel->Header.iXPoints*2][i]+
					 fTemp[iPointT][i]+fTemp[iPointT+2][i])/4;
	// Right/lower field:
	if(iX+2 < pLevel->Header.iXPoints && iY+2 < pLevel->Header.iYPoints)
		fTemp[iPointT+pLevel->Header.iXPoints+1][i] = 
					(fTemp[iPointT+pLevel->Header.iXPoints*2+2][i]+
					 fTemp[iPointT+pLevel->Header.iXPoints*2][i]+
					 fTemp[iPointT][i]+fTemp[iPointT+2][i])/4;
} // end SetupMiddlePoints()

void SetupMiddlePoints(int iX, int iY, int iPointT, FLOAT4 *fTemp, int i)
{ // begin SetupMiddlePoints()
	if(bAdvancedTerrainManipulation) // Setup the middle points:
		return;

	// Update the middle left, upper, right and lower points of this point:
	if(iX-2 >= 0)
		fTemp[iPointT-1][i] = (fTemp[iPointT][i]+fTemp[iPointT-2][i])/2;
	if(iY-2 >= 0)
		fTemp[iPointT-pLevel->Header.iXPoints][i] = (fTemp[iPointT][i]+
								fTemp[iPointT-pLevel->Header.iXPoints*2][i])/2;

	if(iX+2 < pLevel->Header.iXPoints)
		fTemp[iPointT+1][i] = (fTemp[iPointT][i]+fTemp[iPointT+2][i])/2;
	if(iY+2 < pLevel->Header.iYPoints)
		fTemp[iPointT+pLevel->Header.iXPoints][i] = (fTemp[iPointT][i]+
							 fTemp[iPointT+pLevel->Header.iXPoints*2][i])/2;
	// Setup the middle points of the bounding fields:
	// Left/upper field:
	if(iX-2 >= 0 && iY-2 >= 0)
		fTemp[iPointT-pLevel->Header.iXPoints-1][i] = 
					(fTemp[iPointT-pLevel->Header.iXPoints*2-2][i]+
					 fTemp[iPointT-pLevel->Header.iXPoints*2][i]+
					 fTemp[iPointT][i]+fTemp[iPointT-2][i])/4;
	// Left/lower field:
	if(iX-2 >= 0 && iY+2 < pLevel->Header.iYPoints)
		fTemp[iPointT+pLevel->Header.iXPoints-1][i] = 
					(fTemp[iPointT+pLevel->Header.iXPoints*2-2][i]+
					 fTemp[iPointT+pLevel->Header.iXPoints*2][i]+
					 fTemp[iPointT][i]+fTemp[iPointT-2][i])/4;

	// Right/upper field:
	if(iX+2 < pLevel->Header.iXPoints && iY-2 >= 0)
		fTemp[iPointT-pLevel->Header.iXPoints+1][i] = 
					(fTemp[iPointT-pLevel->Header.iXPoints*2+2][i]+
					 fTemp[iPointT-pLevel->Header.iXPoints*2][i]+
					 fTemp[iPointT][i]+fTemp[iPointT+2][i])/4;
	// Right/lower field:
	if(iX+2 < pLevel->Header.iXPoints && iY+2 < pLevel->Header.iYPoints)
		fTemp[iPointT+pLevel->Header.iXPoints+1][i] = 
					(fTemp[iPointT+pLevel->Header.iXPoints*2+2][i]+
					 fTemp[iPointT+pLevel->Header.iXPoints*2][i]+
					 fTemp[iPointT][i]+fTemp[iPointT+2][i])/4;
} // end SetupMiddlePoints()

void SetupMiddlePoints(int iX, int iY, int iFloorPointT, int iMiddlePointT, int iTopPointT, FLOAT3 *fTemp, int i)
{ // begin SetupMiddlePoints()
	if(bAdvancedTerrainManipulation) // Setup the middle points:
		return;
		
	// Setup the middle point between the floor and top point:
	fTemp[iMiddlePointT][i] = (fTemp[iFloorPointT][i]+fTemp[iTopPointT][i])/2;

	// Now, setup the other middle points around that point:
	SetupMiddlePoints(iX, iY, iMiddlePointT, fTemp, i);
} // end SetupMiddlePoints()

void SetupMiddlePoints(int iX, int iY, int iFloorPointT, int iMiddlePointT, int iTopPointT, FLOAT4 *fTemp, int i)
{ // begin SetupMiddlePoints()
	if(bAdvancedTerrainManipulation) // Setup the middle points:
		return;
		
	// Setup the middle point between the floor and top point:
	fTemp[iMiddlePointT][i] = (fTemp[iFloorPointT][i]+fTemp[iTopPointT][i])/2;

	// Now, setup the other middle points around that point:
	SetupMiddlePoints(iX, iY, iMiddlePointT, fTemp, i);
} // end SetupMiddlePoints()

void ManipulateColor(FLOAT3 *fColor, float fIncrease, BOOL bLimit)
{ // begin ManipulateColor()
	char byColor = -1, byColors = 1, i;
	
	// Which color we have to manipulate?
	if(CHECK_KEY(ASMouse.byButtons, 0) && CHECK_KEY(ASMouse.byButtons, 1))
		byColors = 3;
	if(CHECK_KEY(ASMouse.byButtons, 0))
		byColor = R;
	else
	if(CHECK_KEY(ASMouse.byButtons, 1))
		byColor = G;
	else
	if(CHECK_KEY(ASMouse.byButtons, 2))
		byColor = B;
	if(byColor == -1 && byColors == 1)
		return;
	for(i = 0; i < byColors; i++)
	{
		if(byColors == 3)
			byColor = i;
		(*fColor)[byColor] += fIncrease/500.0f;
		if(!bLimit)
			continue;
		if((*fColor)[byColor] < 0.0f)
			(*fColor)[byColor] = 0.0f;
		if((*fColor)[byColor] > 1.0f)
			(*fColor)[byColor] = 1.0f;
	}
} // end ManipulateColor()

void ManipulateColor(FLOAT4 *fColor, float fIncrease, BOOL bLimit)
{ // begin ManipulateColor()
	char byColor = -1, byColors = 1, i;
	
	// Which color we have to manipulate?
	if(CHECK_KEY(ASMouse.byButtons, 0) && CHECK_KEY(ASMouse.byButtons, 1))
		byColors = 3;
	if(CHECK_KEY(ASMouse.byButtons, 0))
		byColor = R;
	else
	if(CHECK_KEY(ASMouse.byButtons, 1))
		byColor = G;
	else
	if(CHECK_KEY(ASMouse.byButtons, 2))
		byColor = B;
	if(byColor == -1 && byColors == 1)
		return;
	for(i = 0; i < byColors; i++)
	{
		if(byColors == 3)
			byColor = i;
		(*fColor)[byColor] += fIncrease/500.0f;
		if(!bLimit)
			continue;
		if((*fColor)[byColor] < 0.0f)
			(*fColor)[byColor] = 0.0f;
		if((*fColor)[byColor] > 1.0f)
			(*fColor)[byColor] = 1.0f;
	}
} // end ManipulateColor()

void ManipulateDensity(FLOAT *fColor, float fIncrease, BOOL bLimit)
{ // begin ManipulateDensity()
	if(!CHECK_KEY(ASMouse.byButtons, 0))
		return;
	*fColor += fIncrease/500.0f;
	if(!bLimit)
		return;
	if(*fColor < 0.0f)
		*fColor = 0.0f;
	if(*fColor > 1.0f)
		*fColor = 1.0f;
} // end ManipulateDensity()

void ManipulateDensity(FLOAT4 *fColor, float fIncrease, BOOL bLimit)
{ // begin ManipulateDensity()
	if(!CHECK_KEY(ASMouse.byButtons, 0))
		return;
	(*fColor)[A] += fIncrease/500.0f;
	if(!bLimit)
		return;
	if((*fColor)[A] < 0.0f)
		(*fColor)[A] = 0.0f;
	if((*fColor)[A] > 1.0f)
		(*fColor)[A] = 1.0f;
} // end ManipulateDensity()
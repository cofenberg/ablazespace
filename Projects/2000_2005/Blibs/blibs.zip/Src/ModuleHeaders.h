//-----------------------------------------------------------------------------
// File: ModuleHeaders.h
//-----------------------------------------------------------------------------

#ifndef __MODULE_HEADRES_H__
#define __MODULE_HEADRES_H__


// Includes: ******************************************************************
#include "WindowProc.h"
#include "Surface.h"
#include "Decoration.h"
#include "Campaign.h"

// Actors:
#include "Actors\Actors.h"
#include "Actors\ActorTools.h"

// Level:
#include "Level\TextScripts.h"

// Level:
#include "Level\Level.h"
#include "Level\LevelDialogs.h"
#include "Level\LevelDraw.h"
#include "Level\LevelMissions.h"

#include "Blibs.h"
#include "Player.h"
#include "Sound.h"
#include "Game.h"
#include "GameDrawCheck.h"
#include "GameMenu.h"
#include "Editor.h"
#include "WindowProc.h"
#include "Logos.h"
///////////////////////////////////////////////////////////////////////////////


#endif // __MODULE_HEADRES_H__
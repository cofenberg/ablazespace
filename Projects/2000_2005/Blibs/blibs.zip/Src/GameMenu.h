//-----------------------------------------------------------------------------
// File: GameMenu.h
//-----------------------------------------------------------------------------

#ifndef __GAME_MENU_H__
#define __GAME_MENU_H__


// Definitions: ***************************************************************
#define GAME_MENU_TEXTURES 8
#define MENU_POINTS 44
#define TITEL_GRID_X_SIZE 20 // The width of the game title
#define TITEL_GRID_Y_SIZE 10 // The height of the game title
///////////////////////////////////////////////////////////////////////////////

// Structures: ****************************************************************
typedef struct MENU_POINT
{
	BOOL bSelected; // Is this menu point current selected?
	float fSize; // The size of the text
	BOOL bSize; // For the size animation
	FLOAT3 fColor; // The text color

} MENU_POINT;

// The different menus:
enum
{
	GM_MAIN_MENU,
	GM_SELECT_CAMPAIGN,
	GM_GET_PLAYER_ID,
	GM_CONTINUE_GAME,
	GM_SELECT_LEVEL_OF_CAMPAIGN,
	GM_SINGLE_LEVEL,
	GM_OPTIONS,
	GM_ARE_YOU_SURE,
	GM_SETUP_KEYS,
	GM_SHOW_LEVEL_MISSIONS,
	GM_LOAD_MENU,
	GM_SAVE_MENU,
	GM_PLAYER_ID_MENU,
};
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern BOOL bInGameMenu;
extern AS_TEXTURE GameMenuTexture[GAME_MENU_TEXTURES];
extern AS_TEXTURE CreditsTexture[100];
extern char byGameMenuSelected, byGameMenuMenu, byLastGameMenuMenu;
extern float fFontAni[4][2], fSelectedSize, fGalaxyIn;
extern long dwMainMenuStartTime;
extern BOOL bSelectedSize;
extern float fGameMenuBlend;
extern MENU_POINT MenuPoint[MENU_POINTS];
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern HRESULT GameMenuLoop(void);
extern void LoadCreditsTextures(void);
extern void DestroyCreditsTextures(void);
extern HRESULT GameMenuDraw(AS_WINDOW *);
extern void ShowLoadSaveMenu(AS_WINDOW *);
extern void ShowOptionMenu(AS_WINDOW *);
extern HRESULT GameMenuCheck(AS_WINDOW *);
extern void CheckDeletePlayerID(void);
extern void CheckLoadSaveMenu(void);
extern void CheckOptionMenu(void);
extern void ShowInGameMenu(AS_WINDOW *);
extern void CheckInGameMenu(void);
extern void AnimateFont(void);
extern void InitMenuPoints(void);
extern void CheckMenuPoints(void);
extern void SetMenuPointColor(MENU_POINT *, float);
extern void DrawTitel(void);
extern void CheckTitel(void);
extern void InitTitel(void);
///////////////////////////////////////////////////////////////////////////////


#endif // __GAME_MENU_H__
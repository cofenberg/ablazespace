//-----------------------------------------------------------------------------
// File: Player.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
ACTOR *pPlayer; // A pointer to the players actor
PLAYER_IDENTITY PlayerIdentity;
PLAYER_SAVE_GAME PlayerSaveGame;
char **pbyPlayerIDList; // The found player ID's
int iPlayerIDsList; // The number of found player ID's
char **pbyPlayerSaveGamesList; // The found players save games 
int iPlayerSaveGamesList; // The number of found players save games
float fPlayerTempZPos; // Used to find out if the camera has been moved (players height)
AS_TEXTURE TempSaveScreenshot;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
void CreateNewPlayerInfo(PLAYER_IDENTITY *, CAMPAIGN *);
void DestroyPlayerInfo(PLAYER_IDENTITY *);
void LoadPlayerIdentity(PLAYER_IDENTITY *, CAMPAIGN *);
void SavePlayerIdentity(PLAYER_IDENTITY *, CAMPAIGN *);
void QuickLoad(void);
void QuickSave(void);
void LoadGame(char *);
void SaveGame(char *);
void EnumeratePlayerIDs(void);
void DestroyPlayerIDList(void);
void EnumeratePlayerSaveGames(void);
void DestroyPlayerSaveGamesList(void);
void TakeSaveGameScreenshot(AS_WINDOW *, AS_TEXTURE *);
void SetStandartPlayer(void);
///////////////////////////////////////////////////////////////////////////////


void CreateNewPlayerInfo(PLAYER_IDENTITY *pPlayerIdentity, CAMPAIGN *pCampaign)
{ // begin CreateNewPlayerInfo()
	DestroyPlayerInfo(pPlayerIdentity);
	memset(pPlayerIdentity, 0, sizeof(PLAYER_IDENTITY));
	strcpy(pPlayerIdentity->byName, "Blibs");
	strcpy(pPlayerIdentity->byCampaignName, pCampaign->byName);
	pPlayerIdentity->iSelectedLevel = 1;
	if(pCampaign->iLevels)
	{
		pPlayerIdentity->PlayerBackup = (ACTOR *) malloc(sizeof(ACTOR)*pCampaign->iLevels);
		memset(pPlayerIdentity->PlayerBackup, 0, sizeof(ACTOR)*pCampaign->iLevels);
	}
} // end CreateNewPlayerInfo()

void DestroyPlayerInfo(PLAYER_IDENTITY *pPlayerIdentity)
{ // begin DestroyPlayerInfo()
	PlayerSaveGame.DestroyInfos(TRUE);
	SAFE_DELETE(pPlayerIdentity->iPoints);
	SAFE_DELETE(pPlayerIdentity->iLives);
	SAFE_DELETE(pPlayerIdentity->fPower);
} // end DestroyPlayerInfo()

void LoadPlayerIdentity(char *pbyName, PLAYER_IDENTITY *pPlayerIdentity, CAMPAIGN *pCampaign)
{ // begin LoadPlayerIdentity()
	char byFilename[256];
	FILE *fp;
	int i;

	sprintf(byFilename, "%s%s\\%s\\player.id", _AS->byProgramPath, _AS->byIdentityDirectory, pbyName);
	_AS->WriteLogMessage("Load player identity: %s", byFilename);
	fp = fopen(byFilename, "rb");
	if(!fp)
		return;
	CreateNewPlayerInfo(pPlayerIdentity, pCampaign);

	// General info:		
	fread(&pPlayerIdentity->byName, sizeof(char)*PLAYER_NAME_LENGTH, 1, fp);
	fread(&pPlayerIdentity->byCampaignName, sizeof(char)*256, 1, fp);
	fread(&pPlayerIdentity->iFinishedLevels, sizeof(int), 1, fp);
	fread(&pPlayerIdentity->iSelectedLevel, sizeof(int), 1, fp);
	if(pPlayerIdentity->iFinishedLevels >= pCampaign->iLevels)
		pPlayerIdentity->iFinishedLevels = pCampaign->iLevels-1;
	if(pPlayerIdentity->iSelectedLevel >= pCampaign->iLevels)
		pPlayerIdentity->iSelectedLevel = pCampaign->iLevels-1;
	fread(&pPlayerIdentity->bSingleLevel, sizeof(BOOL), 1, fp);
	fread(&pPlayerIdentity->bEditorLevelTest, sizeof(BOOL), 1, fp);
	fread(&pPlayerIdentity->bySingleLevelName, sizeof(char)*256, 1, fp);

	// Player info for each level of the campaign:
	for(i = 0; i < pCampaign->iLevels; i++)
		fread(&pPlayerIdentity->PlayerBackup[i], sizeof(ACTOR), 1, fp);
	fclose(fp);

	// Check the 'all levels' cheat:
	if(bAllLevels)
		pPlayerIdentity->iFinishedLevels = pCampaign->iLevels;
	
	// Get a list of all save games:
	EnumeratePlayerSaveGames();
} // end LoadPlayerIdentity()

void SavePlayerIdentity(PLAYER_IDENTITY *pPlayerIdentity, CAMPAIGN *pCampaign)
{ // begin SavePlayerIdentity()
	char byFilename[256];
	FILE *fp;
	int i;

	// Create the players folder:
	sprintf(byFilename, "%s%s\\%s", _AS->byProgramPath, _AS->byIdentityDirectory, pPlayerIdentity->byName);
	CreateDirectory(byFilename, NULL);

	sprintf(byFilename, "%s%s\\%s\\player.id", _AS->byProgramPath, _AS->byIdentityDirectory, pPlayerIdentity->byName);
	_AS->WriteLogMessage("Save player identity: %s", byFilename);
	remove(byFilename); // Delete the old file
	fp = fopen(byFilename, "wb");
	if(!fp)
		return;
	
	// General info:		
	fwrite(&pPlayerIdentity->byName, sizeof(char)*PLAYER_NAME_LENGTH, 1, fp);
	fwrite(&pPlayerIdentity->byCampaignName, sizeof(char)*256, 1, fp);
	fwrite(&pPlayerIdentity->iFinishedLevels, sizeof(int), 1, fp);
	fwrite(&pPlayerIdentity->iSelectedLevel, sizeof(int), 1, fp);
	fwrite(&pPlayerIdentity->bSingleLevel, sizeof(BOOL), 1, fp);
	fwrite(&pPlayerIdentity->bEditorLevelTest, sizeof(BOOL), 1, fp);
	fwrite(&pPlayerIdentity->bySingleLevelName, sizeof(char)*256, 1, fp);
	
	// Player info for each level of the campaign:
	for(i = 0; i < pCampaign->iLevels; i++)
		fwrite(&pPlayerIdentity->PlayerBackup[i], sizeof(ACTOR), 1, fp);
	fclose(fp);
} // end SavePlayerIdentity()

void QuickLoad(void)
{ // begin QuickLoad()
	_AS->WriteLogMessage("Quick load");	
	ShowSmallMessage(AS_T(T_QuickLoad), 2000);
	LoadGame("QuickSave");
} // end QuickLoad()

void QuickSave(void)
{ // begin QuickSave()
	if(pPlayer->bGoingDeath || pPlayer->bFallIntoHole || pPlayer->bDeath ||
	   (!pLevel->pField[pPlayer->iFieldID].bActive && !pLevel->pField[pPlayer->iFieldID].pBridgeActor))
		return;
	_AS->WriteLogMessage("Quick save");
	ShowSmallMessage(AS_T(T_QuickSave), 2000);
	SaveGame("QuickSave");
} // end QuickSave()

void LoadGame(char *pbyFilename)
{ // begin LoadGame()
	char byFilename[256], byTemp[256];
	FILE *fp;

	_AS->WriteLogMessage("Load game: %s", pbyFilename);
	sprintf(byFilename, "%s%s\\%s\\%s", _AS->byProgramPath, _AS->byIdentityDirectory, PlayerIdentity.byName, pbyFilename);
	
	// Load the data itself:
	sprintf(byTemp, "%s\\level.sav", byFilename);

	// Check if the level is there:
	fp = fopen(byTemp, "rb");
	if(!fp)
	{ // Nope!
		sprintf(byTemp, "%s (%s)", AS_M(M_CouldNotLoadSaveGame), pbyFilename);
		ShowSmallMessage(byTemp, 3000);
		return;
	}
	fclose(fp);

	StartLevel(byTemp, TRUE);
} // end LoadGame()

void SaveGame(char *pbyFilename)
{ // begin SaveGame()
	char byFilename[256], byTemp[256];

	_AS->WriteLogMessage("Save game: %s", pbyFilename);
	sprintf(byFilename, "%s%s\\%s\\%s", _AS->byProgramPath, _AS->byIdentityDirectory, PlayerIdentity.byName, pbyFilename);
	
	// Remove the old folder:
	ASRemoveDirectory(byFilename);

	// Create the new folder:
	CreateDirectory(byFilename, NULL);

	// Save the save game screenshot:
	sprintf(byTemp, "%s\\screenshot.ppm", byFilename);
	ASSavePpm(&TempSaveScreenshot, byTemp);

	// Save the data itself:
	sprintf(byTemp, "%s\\level.sav", byFilename);
	pLevel->Save(byTemp);
} // end SaveGame()

// Get a list of all player ID's:
void EnumeratePlayerIDs(void)
{ // begin EnumeratePlayerIDs()
	WIN32_FIND_DATA FindFileData;
	char byTemp[256];
	HANDLE Find;
	                   
	_AS->WriteLogMessage("Enumerate player IDs");
	DestroyPlayerIDList();
	sprintf(byTemp, "%s%s\\*.*", _AS->byProgramPath, _AS->byIdentityDirectory);
	Find = FindFirstFile(byTemp, &FindFileData);
	if(Find == INVALID_HANDLE_VALUE)
		return;
	for(;;)
	{	
		if(FindFileData.cFileName[0] != '.' &&
		   (FindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == FILE_ATTRIBUTE_DIRECTORY)
		{ // We found a player ID:
			iPlayerIDsList++;
			pbyPlayerIDList = (char **) realloc(pbyPlayerIDList, sizeof(char **)*iPlayerIDsList);
			pbyPlayerIDList[iPlayerIDsList-1] = new char[strlen(FindFileData.cFileName)+1];
			strcpy(pbyPlayerIDList[iPlayerIDsList-1], FindFileData.cFileName);
		}
		if(!FindNextFile(Find, &FindFileData))
			break;
	}
	FindClose(Find);
} // end EnumeratePlayerIDs()

// Destroy the player ID list:
void DestroyPlayerIDList(void)
{ // begin DestroyPlayerIDsList()
	DestroyPlayerSaveGamesList();
	if(pbyPlayerIDList)
	{
		for(int i = 0; i < iPlayerIDsList; i++)
			SAFE_FREE(pbyPlayerIDList[i]);
		SAFE_FREE(pbyPlayerIDList);
	}
	iPlayerIDsList = 0;
} // end DestroyPlayerIDList()

// Enumerate all save games from the current player:
void EnumeratePlayerSaveGames(void)
{ // begin EnumeratePlayerSaveGames()
	WIN32_FIND_DATA FindFileData;
	char byTemp[256];
	HANDLE Find;
	                   
	_AS->WriteLogMessage("Enumerate players game saves");
	DestroyPlayerSaveGamesList();
	sprintf(byTemp, "%s%s\\%s\\*.*", _AS->byProgramPath, _AS->byIdentityDirectory, PlayerIdentity.byName);
	Find = FindFirstFile(byTemp, &FindFileData);
	if(Find == INVALID_HANDLE_VALUE)
		return;
	for(;;)
	{	
		if(FindFileData.cFileName[0] != '.' &&
		   (FindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == FILE_ATTRIBUTE_DIRECTORY)
		{ // We found a save game ID:
			iPlayerSaveGamesList++;
			pbyPlayerSaveGamesList = (char **) realloc(pbyPlayerSaveGamesList, sizeof(char **)*iPlayerSaveGamesList);
			pbyPlayerSaveGamesList[iPlayerSaveGamesList-1] = new char[strlen(FindFileData.cFileName)+1];
			strcpy(pbyPlayerSaveGamesList[iPlayerSaveGamesList-1], FindFileData.cFileName);
		}
		if(!FindNextFile(Find, &FindFileData))
			break;
	}
	FindClose(Find);
	if(iPlayerSaveGamesList)
		PlayerSaveGame.LoadInfos(pbyPlayerSaveGamesList[0], TRUE);
} // end EnumeratePlayerSaveGames()

// Destroy the list of all save games from the current player:
void DestroyPlayerSaveGamesList(void)
{ // begin DestroyPlayerSaveGamesList()
	if(pbyPlayerSaveGamesList)
	{
		for(int i = 0; i < iPlayerSaveGamesList; i++)
			SAFE_FREE(pbyPlayerSaveGamesList[i]);
		SAFE_FREE(pbyPlayerSaveGamesList);
	}
	iPlayerSaveGamesList = 0;
} // end DestroyPlayerSaveGamesList()

// Gets a screenshot and scales it to 256x256: (e.g. for the save game screenshot)
void TakeSaveGameScreenshot(AS_WINDOW *pWindow, AS_TEXTURE *pTextureT)
{ // begin TakeSaveGameScreenshot()
	float fXIncrease, fYIncrease, fX, fY;
	BYTE *pbyBuffer, *pbyShotBuffer;
	int i, x, y, iIndex;

	x = pWindow->GetWidth();
	y = pWindow->GetHeight();
	_AS->WriteLogMessage("Create save screenshot...");
	pbyBuffer = (BYTE *) malloc((pWindow->GetWidth()+1)*(pWindow->GetHeight()+1)*3);
	if(!pbyBuffer)
	{
		_AS->WriteLogMessage("Couldn't create save screenshot!");
		return;
	}	
	// Read in the current OpenGL framebuffer:
	glReadPixels(0, 0, pWindow->GetWidth(), pWindow->GetHeight(), GL_RGB,
				 GL_UNSIGNED_BYTE, pbyBuffer);
	SAFE_FREE(pTextureT->pbyData);
	pTextureT->pbyData = (BYTE *) malloc(256*256*3);
	pbyShotBuffer = pTextureT->pbyData;
	if(!pbyShotBuffer)
	{
		_AS->WriteLogMessage("Couldn't create save screenshot!");
		free(pbyBuffer);
		return;
	}
	pTextureT->iWidth = pTextureT->iHeight = 256;
	pTextureT->byColorComponents = 3;
	pTextureT->iFormat = GL_RGB;
	
	// Scale the screenshot to 256x256:
	fXIncrease = (float) pWindow->GetWidth()/256;
	fYIncrease = (float) pWindow->GetHeight()/256;
	for(y = 0, fY = 0.0f; y < 256; y++, fY += fYIncrease)
		for(x = 0, fX = 0.0f; x < 256; x++, fX += fXIncrease)
			for(i = 0; i < 3; i++)
			{
				iIndex = (((int) fY)*pWindow->GetWidth()+((int) fX))*3+i;
				if(iIndex < 0 || iIndex > pWindow->GetWidth()*pWindow->GetHeight()*3)
					continue;
				pbyShotBuffer[(y*256+x)*3+i] = pbyBuffer[iIndex];
			}

	SAFE_FREE(pbyBuffer);
} // end TakeSaveGameScreenshot()

// Set Blibs into the middle of the new level:
void SetStandartPlayer(void)
{ // begin SetStandartPlayer()
	if(pPlayer)
		return;
	pPlayer	= pLevel->FindFreeActor();
	if(pPlayer)
		pPlayer->InitBlibs(pLevel->Header.iWidth/2, pLevel->Header.iHeight/2);
} // end SetStandartPlayer()

// PLAYER_SAVE_GAME functions: ************************************************
void PLAYER_SAVE_GAME::LoadInfos(char *pbyNameT, BOOL bForce)
{ // begin PLAYER_SAVE_GAME::LoadInfos()
	char byTemp[256];
	struct _stat FileState;

	if(!bForce && !strcmp(pbyNameT, byName))
		return; // This save game is already loaded!

	DestroyInfos(FALSE);
	strcpy(byName, pbyNameT);

	// Load the save game screenshot:
	sprintf(byTemp, "%s%s\\%s\\%s\\screenshot.ppm", _AS->byProgramPath, _AS->byIdentityDirectory, PlayerIdentity.byName, byName);

	ASLoadTexture(&Screenshot, byTemp);
	if(!Screenshot.iOpenGLID)
		ASGenOpenGLTextures(1, &Screenshot);
	else
	{
		glBindTexture(GL_TEXTURE_2D, Screenshot.iOpenGLID);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
		if(_ASConfig->bUseMipmaps && !Screenshot.bNoMipmap)
		{
			if(_ASConfig->bFastTexturing)
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST_MIPMAP_NEAREST);
				gluBuild2DMipmaps(GL_TEXTURE_2D, Screenshot.byColorComponents, Screenshot.iWidth,
								  Screenshot.iHeight, Screenshot.iFormat, GL_UNSIGNED_BYTE,
								  Screenshot.pbyData);
			}
			else
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);
				gluBuild2DMipmaps(GL_TEXTURE_2D, Screenshot.byColorComponents, Screenshot.iWidth,
								  Screenshot.iHeight, Screenshot.iFormat, GL_UNSIGNED_BYTE,
								  Screenshot.pbyData);
			}
		}
		else
		{
			if(_ASConfig->bFastTexturing)
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
				glTexImage2D(GL_TEXTURE_2D, 0, Screenshot.byColorComponents, Screenshot.iWidth,
							 Screenshot.iHeight, 0, Screenshot.iFormat, GL_UNSIGNED_BYTE,
							 Screenshot.pbyData);
			}
			else
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
				glTexImage2D(GL_TEXTURE_2D, 0, Screenshot.byColorComponents, Screenshot.iWidth,
							 Screenshot.iHeight, 0, Screenshot.iFormat, GL_UNSIGNED_BYTE,
							 Screenshot.pbyData);
			}
		}
	}
	
	// Get the time were the save game was created:
	_stat(byTemp, &FileState);
	sprintf(bySaveTime, "%s", ctime(&FileState.st_ctime));
} // end PLAYER_SAVE_GAME::LoadInfos()

void PLAYER_SAVE_GAME::DestroyInfos(BOOL bTexture)
{ // begin PLAYER_SAVE_GAME::DestroyInfos()
	int iTemp = 0;

	if(!Screenshot.pbyData)
		return;
	if(bTexture)
		ASDestroyOpenGLTextures(1, &Screenshot);
	else
		iTemp = Screenshot.iOpenGLID;
	ASDestroyTexture(&Screenshot);
	memset(this, 0, sizeof(PLAYER_SAVE_GAME));
	Screenshot.iOpenGLID = iTemp;
} // end PLAYER_SAVE_GAME::DestroyInfos()
///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// File: Player.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
CAMPAIGN CurrentCampaign;	 // The current campaign 
int iCurrentCampaignLevel; // The current level of the campaign
char **pbyCampaignListLevelNames; // The level names of the campaign (e.g. for the level selection)
HWND hWndCampaignEditor;
char **pbyCampaignList; // The found campaigns names
int iCampaignsList;   // The number of found campaigns
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
LRESULT CALLBACK CampaignEditorProc(HWND, UINT, WPARAM, LPARAM);
void UpdateCampaignEditorButtons(void);
LRESULT CALLBACK SetNumberOfCampaignLevelsProc(HWND, UINT, WPARAM, LPARAM);
BOOL LoadCampaign(CAMPAIGN *, char *);
void SaveCampaign(CAMPAIGN *, char *);
void DestroyCampaign(CAMPAIGN *);
void EnumerateCampaigns(void);
void DestroyCampaignsList(void);
///////////////////////////////////////////////////////////////////////////////


LRESULT CALLBACK CampaignEditorProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin CampaignEditorProc()
    char byTemp[256], *pbyTemp, byKeyword[256];
	BOOL bKeyword;
	int i, i2;
	FILE *fp;

	switch(iMessage)
    {
        case WM_INITDIALOG:
				_AS->WriteLogMessage("Open campaign editor");
				hWndCampaignEditor = hWnd;
				for(i = 0; i < CurrentCampaign.iLevels; i++)
					free(CurrentCampaign.byLevelFilename[i]);
				free(CurrentCampaign.byLevelFilename);
				memset(&CurrentCampaign, 0, sizeof(CAMPAIGN));
				iCurrentCampaignLevel = 0;
				CurrentCampaign.iLevels = 1;
				CurrentCampaign.byLevelFilename = (char **) malloc(sizeof(char *)*CurrentCampaign.iLevels);
				CurrentCampaign.byLevelFilename[0] = (char *) malloc(sizeof(char)*256);
				memset(CurrentCampaign.byLevelFilename[0], 0, sizeof(char)*256);
				// Icons:
				SendDlgItemMessage(hWnd, IDC_CAMPAIGN_EDITOR_FIND_FILENAME, BM_SETIMAGE, (WPARAM) IMAGE_ICON,
								   (LPARAM) LoadImage(_AS->GetInstance(), MAKEINTRESOURCE(IDI_AS_OPEN), IMAGE_ICON, 12, 12, LR_DEFAULTCOLOR));
				// Icons:
				SendDlgItemMessage(hWnd, IDC_CAMPAIGN_EDITOR_FIND_LEVEL_FILENAME, BM_SETIMAGE, (WPARAM) IMAGE_ICON,
								   (LPARAM) LoadImage(_AS->GetInstance(), MAKEINTRESOURCE(IDI_AS_OPEN), IMAGE_ICON, 12, 12, LR_DEFAULTCOLOR));
				// Texts:
				SetWindowText(hWnd, AS_T(T_CampaignEditor));
				SetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_FILE_T, AS_T(T_File));
				SetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_NAME_T, AS_T(T_Name));
				SetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_KEYWORD_T, AS_T(T_Keyword));
				SetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_LEVELS, AS_T(T_Levels));
				SetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_LEVEL_T, AS_T(T_Level));
				SetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_LEVEL_FILE_T, AS_T(T_File));
				SetDlgItemText(hWnd, ID_CAMPAIGN_EDITOR_OK, AS_T(T_Ok));
				SetDlgItemText(hWnd, ID_CAMPAIGN_EDITOR_CANCEL, AS_T(T_Cancel));
				SetDlgItemText(hWnd, ID_CAMPAIGN_EDITOR_LOAD, AS_T(T_Load));
				SetDlgItemText(hWnd, ID_CAMPAIGN_EDITOR_SAVE, AS_T(T_Save));
			Init:
				SetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_FILENAME, CurrentCampaign.byFilename);
				SetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_NAME, CurrentCampaign.byName);
				SetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_KEYWORD, CurrentCampaign.byKeyword);
				//
				UpdateCampaignEditorButtons();				
				ShowWindow(hWnd, _AS->GetCmdShow());
				UpdateWindow(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case ID_CAMPAIGN_EDITOR_OK:
					// Save the campaign:
					if(CurrentCampaign.byFilename[0] == '\0')
					{ // Get an filename:
						sprintf(byTemp, "%s%s", _AS->byProgramPath, _AS->byCampaignsDirectory);
						pbyTemp = ASGetFileName(hWnd, AS_T(T_SaveCampaign), CAM_FILE, 1, FALSE, byTemp, NULL);
						if(!pbyTemp)
							break;
						if(strlen(pbyTemp) > strlen(_AS->byProgramPath))
							strcpy(CurrentCampaign.byFilename, &pbyTemp[strlen(_AS->byProgramPath)]);
					}
					sprintf(byTemp, "%s%s", _AS->byProgramPath, CurrentCampaign.byFilename);
					SaveCampaign(&CurrentCampaign, byTemp);
					_AS->WriteLogMessage("Close campaign editor (ok)");
					EndDialog(hWnd, 0);
					return TRUE;

				case ID_CAMPAIGN_EDITOR_CANCEL: EndDialog(hWnd, 0); return TRUE;

				case ID_CAMPAIGN_EDITOR_LOAD:
					sprintf(byTemp, "%s%s", _AS->byProgramPath, _AS->byCampaignsDirectory);
					pbyTemp = ASGetFileName(hWnd, AS_T(T_LoadCampaign), CAM_FILE, 0, FALSE, byTemp, NULL);
					if(!pbyTemp)
						break;
					// Check for keyword:
					fp = fopen(pbyTemp, "rb");
					if(!fp)
						break;
					fread(&bKeyword, sizeof(BOOL), 1, fp);
					fread(&byKeyword, sizeof(char)*256, 1, fp);
					fclose(fp);
					if(bKeyword && !bMasterAccess)
					{ // Check the keyword:
						bKeyword = DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_KEYWORD), hWnd, (DLGPROC) KeywordProc);
						if(!bKeyword)
						{ // Wrong keyword!!
							MessageBox(hWnd, AS_M(M_WrongKeyword), GAME_NAME, MB_OK | MB_ICONINFORMATION);
							break;
						}
						else
							if(bKeyword == -1)
								break;
					}
					LoadCampaign(&CurrentCampaign, pbyTemp);
					if(strlen(pbyTemp) > strlen(_AS->byProgramPath))
						strcpy(CurrentCampaign.byFilename, &pbyTemp[strlen(_AS->byProgramPath)]);
					sprintf(byTemp, "%s%s", _AS->byProgramPath, CurrentCampaign.byFilename);
					goto Init;

				case ID_CAMPAIGN_EDITOR_SAVE:
					sprintf(byTemp, "%s%s", _AS->byProgramPath, _AS->byCampaignsDirectory);
					pbyTemp = ASGetFileName(hWnd, AS_T(T_SaveCampaign), CAM_FILE, 1, FALSE, byTemp, NULL);
					if(!pbyTemp)
						break;
					if(strlen(pbyTemp) > strlen(_AS->byProgramPath))
						strcpy(CurrentCampaign.byFilename, &pbyTemp[strlen(_AS->byProgramPath)]);
					sprintf(byTemp, "%s%s", _AS->byProgramPath, CurrentCampaign.byFilename);
					SaveCampaign(&CurrentCampaign, byTemp);
					goto Init;
				
				case IDC_CAMPAIGN_EDITOR_FILENAME:
					GetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_FILENAME, CurrentCampaign.byFilename, 256);
				break;

				case IDC_CAMPAIGN_EDITOR_FIND_FILENAME:
					sprintf(byTemp, "%s%s", _AS->byProgramPath, _AS->byCampaignsDirectory);
					pbyTemp = ASGetFileName(hWnd, AS_T(T_GetACampaignFilename), CAM_FILE, 0, TRUE, byTemp, NULL);
					if(!pbyTemp)
						break;
					if(strlen(pbyTemp) > strlen(_AS->byProgramPath))
						strcpy(pLevel->Header.byFilename, &pbyTemp[strlen(_AS->byProgramPath)]);
					SetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_FILENAME, pLevel->Header.byFilename);
				break;

				case IDC_CAMPAIGN_EDITOR_NAME:
					GetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_NAME, CurrentCampaign.byName, 256);
				break;

				case IDC_CAMPAIGN_EDITOR_KEYWORD_T:
					CurrentCampaign.bKeyword = SendDlgItemMessage(hWnd, IDC_CAMPAIGN_EDITOR_KEYWORD_T, BM_GETCHECK, 0, 0L);
					UpdateCampaignEditorButtons();
				break;

				case IDC_CAMPAIGN_EDITOR_KEYWORD:
					GetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_KEYWORD, CurrentCampaign.byKeyword, 256);
				break;

				case IDC_CAMPAIGN_EDITOR_LEVELS:
					if((i = DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_SET_NUMBER_OF_CAMPAIGN_LEVELS), hWnd, (DLGPROC) SetNumberOfCampaignLevelsProc)) == -1)
						break;
					if(i <= 0)
						i = 1;
					i2 = CurrentCampaign.iLevels;
					CurrentCampaign.iLevels = i;
					for(; i2 > i; i2--)
						free(CurrentCampaign.byLevelFilename[i2-1]);
					CurrentCampaign.byLevelFilename = (char **) realloc(CurrentCampaign.byLevelFilename, sizeof(char *)*CurrentCampaign.iLevels);
					for(; i2 < i; i2++)
					{
						CurrentCampaign.byLevelFilename[i2] = (char *) malloc(sizeof(char)*256);
						memset(CurrentCampaign.byLevelFilename[i2], 0, sizeof(char)*256);
					}
					if(iCurrentCampaignLevel >= CurrentCampaign.iLevels)
						iCurrentCampaignLevel = 0;
					UpdateCampaignEditorButtons();
				break;

				case ID_CAMPAIGN_EDITOR_LEVEL_LIST:
					i = (int) SendDlgItemMessage(hWnd, ID_CAMPAIGN_EDITOR_LEVEL_LIST, CB_GETCURSEL, 0, 0L);
					if(i == -1 || i >= CurrentCampaign.iLevels)
						break;
					iCurrentCampaignLevel = i;
					SetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_LEVEL_FILENAME, CurrentCampaign.byLevelFilename[iCurrentCampaignLevel]);
				break;

				case IDC_CAMPAIGN_EDITOR_LEVEL_FILENAME:
					GetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_LEVEL_FILENAME, CurrentCampaign.byLevelFilename[iCurrentCampaignLevel], 256);
					UpdateCampaignEditorButtons();
				break;

				case IDC_CAMPAIGN_EDITOR_FIND_LEVEL_FILENAME:
					sprintf(byTemp, "%s%s", _AS->byProgramPath, _AS->byCampaignsDirectory);
					pbyTemp = ASGetFileName(hWnd, AS_T(T_GetALevelFilename), LEV_FILE, 0, TRUE, byTemp, NULL);
					if(!pbyTemp)
						break;
					if(strlen(pbyTemp) > strlen(_AS->byProgramPath))
						strcpy(CurrentCampaign.byLevelFilename[iCurrentCampaignLevel], &pbyTemp[strlen(_AS->byProgramPath)]);
					SetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_LEVEL_FILENAME, CurrentCampaign.byLevelFilename[iCurrentCampaignLevel]);
					UpdateCampaignEditorButtons();
				break;
			}
        break;

		case WM_CLOSE: case WM_DESTROY:
			_AS->WriteLogMessage("Close campaign editor (cancel)");
			SendMessage(hWnd, WM_COMMAND, ID_CAMPAIGN_EDITOR_CANCEL, 0);
		break;
    }

    return FALSE;
} // end CampaignEditorProc()

void UpdateCampaignEditorButtons(void)
{ // begin UpdateCampaignEditorButtons()
	char byTemp[256];
	int i;
	
	if(!hWndCampaignEditor)
		return;
    SendDlgItemMessage(hWndCampaignEditor, IDC_CAMPAIGN_EDITOR_KEYWORD_T, BM_SETCHECK, CurrentCampaign.bKeyword, 0L);
	EnableWindow(GetDlgItem(hWndCampaignEditor, IDC_CAMPAIGN_EDITOR_KEYWORD), CurrentCampaign.bKeyword);
	SendDlgItemMessage(hWndCampaignEditor, ID_CAMPAIGN_EDITOR_LEVEL_LIST, CB_RESETCONTENT , 0, 0L);
	for(i = 0; i < CurrentCampaign.iLevels; i++)
	{
		sprintf(byTemp, "%d: %s", i+1, CurrentCampaign.byLevelFilename[i]);
		SendDlgItemMessage(hWndCampaignEditor, ID_CAMPAIGN_EDITOR_LEVEL_LIST, CB_ADDSTRING, 0, (LPARAM) byTemp);
	}
	SendDlgItemMessage(hWndCampaignEditor, ID_CAMPAIGN_EDITOR_LEVEL_LIST, CB_SETCURSEL, iCurrentCampaignLevel, 0L);
} // end UpdateCampaignEditorButtons()

LRESULT CALLBACK SetNumberOfCampaignLevelsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin SetNumberOfCampaignLevelsProc()
	char byTemp[256];
	int i;

    switch(iMessage)
    {
        case WM_INITDIALOG:
			SetWindowText(hWnd, AS_T(T_SetNumberOfCampaignLevels));
			SetDlgItemText(hWnd, ID_SET_CAMPAIGN_LEVELS_OK, AS_T(T_Ok));
			SetDlgItemText(hWnd, ID_SET_CAMPAIGN_LEVELS_CANCEL, AS_T(T_Cancel));
			sprintf(byTemp, "%d", CurrentCampaign.iLevels);
			SetDlgItemText(hWnd, ID_SET_CAMPAIGN_LEVELS_NUMBER, byTemp);
			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_SET_CAMPAIGN_LEVELS_OK:
					GetDlgItemText(hWnd, ID_SET_CAMPAIGN_LEVELS_NUMBER, byTemp, 256);
					i = (int) atoi(byTemp);
					if(!i)
						i++;
					EndDialog(hWnd, i);
                return TRUE;

                case ID_SET_CAMPAIGN_LEVELS_CANCEL: EndDialog(hWnd, -1); return TRUE;
            }
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_SET_CAMPAIGN_LEVELS_CANCEL, 0);
		break;
    }

    return FALSE;
} // end SetNumberOfCampaignLevelsProc()

BOOL LoadCampaign(CAMPAIGN *pCampaign, char *pbyFilename)
{ // begin LoadCampaign()
	char byTemp[256];
	FILE *fp;
	int i;


	_AS->WriteLogMessage("Load campaign: %s", pbyFilename);
	if(!pbyFilename)
		return 1;
	fp = fopen(pbyFilename, "rb");
	if(!fp)
		return 1;
	DestroyCampaign(pCampaign);
	strcpy(pCampaign->byFilename, pbyFilename);
	
	// Keyword:
	fread(&pCampaign->bKeyword, sizeof(BOOL), 1, fp);
	fread(&pCampaign->byKeyword, sizeof(char)*256, 1, fp);
	
	// Name:
	fread(&pCampaign->byName, sizeof(char)*256, 1, fp);
	
	// Levels
	fread(&pCampaign->iLevels, sizeof(int), 1, fp);
	pCampaign->byLevelFilename = (char **) malloc(sizeof(char *)*pCampaign->iLevels);
	for(i = 0; i < pCampaign->iLevels; i++)
	{
		pCampaign->byLevelFilename[i] = (char *) malloc(sizeof(char)*256);
		fread(pCampaign->byLevelFilename[i], sizeof(char)*256, 1, fp);
	}
	fclose(fp);

	// Get the level names:
	pbyCampaignListLevelNames = (char **) malloc(sizeof(char *)*pCampaign->iLevels);
	for(i = 0; i < pCampaign->iLevels; i++)
	{
		pbyCampaignListLevelNames[i] = (char *) malloc(sizeof(char)*256);
		sprintf(byTemp, "%s%s", _AS->byProgramPath, pCampaign->byLevelFilename[i]);
		GetLevelName(byTemp, pbyCampaignListLevelNames[i]);
	}
	_AS->WriteLogMessage("OK");

	return 0;
} // end LoadCampaign()

void SaveCampaign(CAMPAIGN *pCampaign, char *pbyFilename)
{ // begin SaveCampaign()
	FILE *fp;
	int i;

	_AS->WriteLogMessage("Save campaign: %s", pbyFilename);
	if(!pbyFilename)
		return;
	remove(pbyFilename); // Delete the old file
	fp = fopen(pbyFilename, "wb");
	if(!fp)
		return;
	// Keyword:
	fwrite(&pCampaign->bKeyword, sizeof(BOOL), 1, fp);
	fwrite(&pCampaign->byKeyword, sizeof(char)*256, 1, fp);
	// Name:
	fwrite(&pCampaign->byName, sizeof(char)*256, 1, fp);
	// Levels
	fwrite(&pCampaign->iLevels, sizeof(int), 1, fp);
	for(i = 0; i < pCampaign->iLevels; i++)
		fwrite(pCampaign->byLevelFilename[i], sizeof(char)*256, 1, fp);
	fclose(fp);
	_AS->WriteLogMessage("OK");
	strcpy(pCampaign->byFilename, pbyFilename);
} // end LoadCampaign()

void DestroyCampaign(CAMPAIGN *pCampaign)
{ // begin DestroyCampaign()
	// Destroy the game stuff:
	if(CurrentCampaign.byLevelFilename)
		for(int i = 0; i < CurrentCampaign.iLevels; i++)
			SAFE_DELETE(CurrentCampaign.byLevelFilename[i]);
	SAFE_DELETE(CurrentCampaign.byLevelFilename);
	SAFE_DELETE(pbyCampaignListLevelNames);
	memset(&CurrentCampaign, 0, sizeof(CAMPAIGN));
} // end DestroyCampaign()

void EnumerateCampaigns(void)
{ // begin EnumerateCampaigns()
	WIN32_FIND_DATA FindFileData;
	char byTemp[256];
	HANDLE Find;
	                   
	_AS->WriteLogMessage("Enumerate campaigns");
	DestroyCampaignsList();
	sprintf(byTemp, "%s%s\\*.*", _AS->byProgramPath, _AS->byCampaignsDirectory);
	Find = FindFirstFile(byTemp, &FindFileData);
	for(;;)
	{	
		if(FindFileData.cFileName[0] != '.' &&
		   (FindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == FILE_ATTRIBUTE_DIRECTORY)
		{ // We found a campaigns:
			iCampaignsList++;
			pbyCampaignList = (char **) realloc(pbyCampaignList, sizeof(char **)*iCampaignsList);
			pbyCampaignList[iCampaignsList-1] = new char[strlen(FindFileData.cFileName)+1];
			strcpy(pbyCampaignList[iCampaignsList-1], FindFileData.cFileName);
		}
		if(!FindNextFile(Find, &FindFileData))
			break;
	}
	FindClose(Find);
} // end EnumerateCampaigns()

void DestroyCampaignsList(void)
{ // begin DestroyCampaignsList()
	if(pbyCampaignList)
	{
		for(int i = 0; i < iCampaignsList; i++)
			SAFE_FREE(pbyCampaignList[i]);
		SAFE_FREE(pbyCampaignList);
	}
	iCampaignsList = 0;
} // end DestroyCampaignsList()
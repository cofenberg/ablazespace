//-----------------------------------------------------------------------------
// File: Player.h
//-----------------------------------------------------------------------------

#ifndef __PLAYER_H__
#define __PLAYER_H__


// Definitions: ***************************************************************
#define PLAYER_NAME_LENGTH 40 // The length of the player name
///////////////////////////////////////////////////////////////////////////////

// Structures: ****************************************************************
// Holds an player identity:
typedef struct PLAYER_IDENTITY
{
	char byName[PLAYER_NAME_LENGTH]; // The name of the player
	char byCampaignName[256]; // The name of the selected campaign
	int iFinishedLevels; // The number of finished levels (old could be selected, too)
	int iSelectedLevel; // The current selected level
	BOOL bSingleLevel, // Is this only a single level identity?
		 bEditorLevelTest; // Is this a editor level test?
	char bySingleLevelName[256]; // The name of the selected single level

	// Player info for each level of the campaign: (for replaying with the old player state)
	ACTOR *PlayerBackup;
	// (Only this stuff could be taken into another level!!)
	int *iPoints; // The points
	int *iLives; // The number of lives
	float *fPower; // The power state

} PLAYER_IDENTITY;

// Holds information about the current loaded save game:
typedef class PLAYER_SAVE_GAME
{
	public:
		AS_TEXTURE Screenshot; /// The screenshot of this save game
		
		char byName[256], // Its name
			 bySaveTime[256]; // Its save time

		void LoadInfos(char *, BOOL);
		void UpdateScreenshot(void);
		void DestroyInfos(BOOL);

} PLAYER_SAVE_GAME;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern ACTOR *pPlayer;
extern PLAYER_IDENTITY PlayerIdentity;
extern PLAYER_SAVE_GAME PlayerSaveGame;
extern char **pbyPlayerIDList;
extern int iPlayerIDsList;
extern char **pbyPlayerSaveGamesList;
extern int iPlayerSaveGamesList;
extern float fPlayerTempZPos;
extern AS_TEXTURE TempSaveScreenshot;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern void CreateNewPlayerInfo(PLAYER_IDENTITY *, CAMPAIGN *);
extern void DestroyPlayerInfo(PLAYER_IDENTITY *);
extern void LoadPlayerIdentity(char *, PLAYER_IDENTITY *, CAMPAIGN *);
extern void SavePlayerIdentity(PLAYER_IDENTITY *, CAMPAIGN *);
extern void QuickLoad(void);
extern void QuickSave(void);
extern void LoadGame(char *);
extern void SaveGame(char *);
extern void EnumeratePlayerIDs(void);
extern void DestroyPlayerIDList(void);
extern void EnumeratePlayerSaveGames(void);
extern void DestroyPlayerSaveGamesList(void);
extern void TakeSaveGameScreenshot(AS_WINDOW *, AS_TEXTURE *);
extern void SetStandartPlayer(void);
///////////////////////////////////////////////////////////////////////////////


#endif // __PLAYER_H__
//-----------------------------------------------------------------------------
// File: GameDrawCheck.h
//-----------------------------------------------------------------------------

#ifndef __AS_GAME_DRAW_CHECK_H__
#define __AS_GAME_DRAW_CHECK_H__


// Functions: *****************************************************************
extern HRESULT GameDraw(AS_WINDOW *);
extern HRESULT GameCheck(AS_WINDOW *);
extern void DrawUnderWaterBlend(void);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_GAME_DRAW_CHECK_H__
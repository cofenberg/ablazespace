//-----------------------------------------------------------------------------
// File: Game.h
//-----------------------------------------------------------------------------

#ifndef __AS_GAME_H__
#define __AS_GAME_H__


// Definitions: ***************************************************************
enum
{
	HEALTH_DISPLAY, LIFE_DISPLAY, PULL_DISPLAY, THROW_DISPLAY, STRENGTH_DISPLAY,
	WEAPON_DISPLAY, POINT_DISPLAY, GHOST_DISPLAY, SPEED_DISPLAY, TIME_DISPLAY,
	STEPS_DISPLAY, WING_DISPLAY, SHIELD_DISPLAY, JUMP_DISPLAY, DYNAMITE_DISPLAY,
};

// The game particle systems:
enum
{
	PS_PLAYER_SPEED, PS_PLAYER_GHOST, PS_PLAYER_AUTOSAVE, PS_WATER_BUBBLES, PS_WATER_WAVES,
	PS_EXPLOSION1, PS_PLAYER_WING_SMOKE, PS_LIGHTS,
};

#define GAME_TEXTURES 27
#define WATER_TEMP_TEXTURE 4
#define MODELS 30
#define OBJECTS 19
#define DISPLAY_ACTORS 15
#define X_MOUSE_SCREEN_POS 320
#define Y_MOUSE_SCREEN_POS 240
#define SCROLL_SPEED 0.01f
#define PLAYER_TURN_SPEED 3.0f
#define PLAYER_ANIMATION_SPEED 100
#define PLAYER_MOVE_SPEED 400
#define BOX_DOCKED_SIZE 0.6f
#define BOX_NORMAL_SIZE 1.0f
#define BOX_COLOR_CHANGE_SPEED 0.01f
#define OBJECT_KILLING_SPEED 1000.0f
#define OBJECTS_ANI_SPEED 100
#define OBJECT_ROTATE_SPEED 10
#define BOX_KILLING_SPEED 2000.0f
#define PLAYER_SHOT_SPEED 200.0f
#define SHOT_KILLING_SPEED 1000.0f
#define SHOT_ROTATE_SPEED 10.0f
#define OBJECT_PAINT_SPEED 100000.0f
#define PLAYER_DEAD_FLOOR_TIME 10000
#define PLAYER_PAINT_SPEED 100000.0f
#define PAUSE_KEY_TIME 100
#define SHIELD_ROTATE_SPEED 10.0f
///////////////////////////////////////////////////////////////////////////////
#define HEALTH_OBJ_NUMBER 50  // The number of health points the player will receive if he collect a health object
#define HEALTH_INCREASE_OBJ_NUMBER 10  // The number of health increase points the player will receive if he collect a health object
#define COIN_OBJ_NUMBER 1       // The number of points the player will receive if he collect a point object
#define LIFE_OBJ_NUMBER 1	     // The number of lifes the player will receive if he collect a life object
#define WEAPON_OBJ_NUMBER 10     // The number of shots the player will receive if he collect a weapon object
#define PULL_OBJ_NUMBER	10	     // The number of pulls the player will receive if he collect a pull object
#define CHEST_OBJ_NUMBER 100	 // The number of points the player will receive if he collect a cheast object
#define STRENGTH_OBJ_NUMBER 1	 // The number of strength units the player will receive if he collect a strength object
#define GHOST_TIME 10			 // The number of seconds of the ghost modus
#define SPEED_TIME 20			 // The number of seconds of the speed modus
#define TIME_OBJ_NUMBER 20		 // The number of seconds the time will be increased/decreased
#define STEPS_OBJ_NUMBER 10		 // The number of steps the step counter will be increased/decreased
#define WING_TIME 20			 // The number of seconds of the wing modus
#define SHIELD_TIME 20			 // The number of seconds of the shield modus
#define JUMP_OBJ_NUMBER 10       // The number of jumps the player will receive if he collect a jump object
#define AIR_OBJ_NUMBER 100       // The number of air the player will receive if he collect it
#define AIR_INCREASE_OBJ_NUMBER 10      // The number of air increases the player will receive if he collect it
#define THROW_OBJ_NUMBER 10       // The number of throws the player will receive if he collect a throw object
#define KICK_OBJ_NUMBER 10       // The number of kicks the player will receive if he collect a kick object
#define BAG_OBJ_NUMBER 10
#define DYNAMITE_OBJ_NUMBER 5

// Standart keys:
#define	STANDART_LEFT_KEY 203
#define	STANDART_RIGHT_KEY 205
#define	STANDART_UP_KEY 200
#define	STANDART_DOWN_KEY 208
#define	STANDART_SHOT_KEY 57
#define	STANDART_KICK_KEY 157
#define	STANDART_ACTION_KEY 28
#define	STANDART_PULL_KEY 14
#define	STANDART_SUICIDE_KEY 15
#define	STANDART_JUMP_KEY 54
#define	STANDART_CHANGE_PERSPECTIVE_KEY 60
#define	STANDART_PAUSE_KEY 25
#define	STANDART_STANDART_VIEW_KEY 76
#define	STANDART_QUICK_LOAD_KEY 67
#define	STANDART_QUICK_SAVE_KEY 63
#define	STANDART_LEVEL_RESTART_KEY 87
#define	STANDART_SHOW_LEVEL_MISSIONS_KEY 50
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern AS_PARTICLE_MANAGER ParticleManager;
extern int GAME_WINDOW_ID;
extern int iLevelCompleteSpeed;
extern AS_TEXTURE GameTexture[GAME_TEXTURES];
extern AS_TEXTURE BlurTexture;
// The current level:
extern char byCurrentLevelName[256];
extern char bySelectedSingleLevel[256];
extern LEVEL *pLevel;
extern ACTOR DisplayActor[DISPLAY_ACTORS];
extern ACTOR PlayerTemp;
extern ACTOR OktaActor;
extern BOOL bSingleLevel,						// Are we playing an single level?
			bPlayerCameraView;
extern AS_MD2_MODEL *pBlibsModel, *pBlibsWeaponModel, *pBlibsEyesModel,
					*pLuciferHeadModel, *pMobmobModel, *pX3Model,
					*pPencilModel, *pCameraModel, *pLuciferModel,
					*pHealthItemModel, *pHealthIncreaseItemModel, *pLifeItemModel,
					*pPullItemModel, *pChestItemModel, *pStrengthItemModel, *pCoinItemModel,
					*pGhostItemModel, *pTimeItemModel, *pStepsItemModel, *pSpeedItemModel,
					*pWingItemModel, *pShieldItemModel, *pJumpItemModel, *pAirItemModel,
					*pAirIncreaseItemModel, *pThrowItemModel, *pKickItemModel,
					*pWeaponItemModel, *pBagItemModel, *pDynamiteItemModel;

extern float fSin, fSin90, fCos, fCos90, fCameraVelocity, fPauseBlend,
	         fPauseTextBlend, fSmallMessageBlend, fFlareRot;
extern BOOL bPause, bPauseTextBlend, bLevelPressAnyKey, bHurryUpText,
			bGameOver, bUnderWater, bSpecialPause;
extern long lPauseTimer, lLevelCompleteTimer, lKeyTimer, lCameraTimerT, lHurryUpTimer,
            lCameraPauseTimerT, lSmallMessageTimer, lSmallMessageTempTimer;
extern AS_CAMERA TempCamera;
extern GLuint iWaveList, iShieldList, iHealthItemList, iHealthIncreaseItemList, iLifeItemList, iPullItemList,
			  iChestItemList, iStrengthItemList, iCoinItemList, iGhostItemList, iPlayerShotItemList,
			  iTimeItemList, iStepsItemList, iSpeedItemList, iWingItemList, iShieldItemList,
			  iJumpItemList, iAirItemList, iAirIncreaseItemList, iThrowItemList, iKickItemList,
			  iWeaponItemList, iBagItemList, iDynamiteItemList, iParticleList;
extern UCHAR byCheckedCharacter, byCrossCharacter, byDashCharacter;
extern float fInGameMenuBlend;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern HRESULT Game(void);
extern void	SetGameLanguage(void);
extern void LoadGameTextures(void);
extern void CreateBlurTexture(void);
extern void DestroyBlurTexture(void);
extern HRESULT GameLoop(void);
extern void UpdateAllTextures(void);
extern void UpdateRenderQuality(void);
extern void CreateGameLists(void);
extern void DestroyGameLists(void);
extern void InitGameObjects(void);
extern void DestroyGameObjects(void);
extern void InitGameParticleSystems(void);
extern void DestroyGameParticleSystems(void);
extern void CreateWaterWave(float, float, float);
extern void CreateExplosion1(float, float, float, float);
extern void CalculateCamersSinCos(void);
extern void CheckCameraKeys(BOOL);
extern BOOL PlayCameraScript(BOOL);
extern void SetCameraTranslation(BOOL);
extern void SetPerspective(float);
extern void WaterEntry(void);
extern void InitDisplayActors(void);
extern void ShowSmallMessage(char *, long);
extern void DisplaySmallMessage(AS_WINDOW *);
extern void CheckSmallMessage(void);
extern void CheckDebugKeys(void);
extern void ReloadModels(void);
extern void ReloadTextures(void);
extern void ReloadSounds(void);
extern void ReloadTexts(void);
extern void MakeFlare(float, float, float, float, float, float, FLOAT3);
extern void DrawFlares(AS_VECTOR3D, float, float, float, float, float);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_GAME_H__
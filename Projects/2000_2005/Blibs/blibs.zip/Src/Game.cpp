//-----------------------------------------------------------------------------
// File: Game.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"

int iTemp = 0;
BOOL bTemp = 1;

// Variables: *****************************************************************
AS_PARTICLE_MANAGER ParticleManager;
int GAME_WINDOW_ID = -1;
int iLevelCompleteSpeed;
ACTOR DisplayActor[DISPLAY_ACTORS];
ACTOR PlayerTemp;
ACTOR OktaActor;
AS_TEXTURE GameTexture[GAME_TEXTURES];	// The game textures
AS_TEXTURE BlurTexture;
char byCurrentLevelName[256];			// The name of the current level
char bySelectedSingleLevel[256];		// The name of the selected single player level
LEVEL *pLevel;							// The 'main' level
BOOL bSingleLevel,						// Are we playing an single level?
	 bPlayerCameraView,					// Are we in the ego-shooter camera perspective??
	 bUnderWater;						// Is the camera under water?
AS_MD2_MODEL *pBlibsModel, *pBlibsWeaponModel, *pBlibsEyesModel, *pLuciferHeadModel,
             *pMobmobModel, *pX3Model, *pPencilModel, *pCameraModel, *pLuciferModel,
			 *pHealthItemModel, *pHealthIncreaseItemModel, *pLifeItemModel,
			 *pPullItemModel, *pChestItemModel, *pStrengthItemModel, *pCoinItemModel,
			 *pGhostItemModel, *pTimeItemModel, *pStepsItemModel, *pSpeedItemModel,
			 *pWingItemModel, *pShieldItemModel, *pJumpItemModel, *pAirItemModel,
			 *pAirIncreaseItemModel, *pThrowItemModel, *pKickItemModel, *pWeaponItemModel,
			 *pBagItemModel, *pDynamiteItemModel;
AS_MD2_MODEL **pModels[] = {&pBlibsModel, &pBlibsWeaponModel,  &pBlibsEyesModel,
							&pLuciferHeadModel, &pMobmobModel, &pX3Model,
							&pPencilModel, &pCameraModel, &pLuciferModel,
							&pHealthItemModel, &pHealthIncreaseItemModel, &pLifeItemModel,
							&pPullItemModel, &pChestItemModel, &pStrengthItemModel,
							&pCoinItemModel, &pGhostItemModel, &pTimeItemModel,
							&pStepsItemModel, &pSpeedItemModel, &pWingItemModel,
							&pShieldItemModel, &pJumpItemModel, &pAirItemModel,
							&pAirIncreaseItemModel, &pThrowItemModel, &pKickItemModel,
							&pWeaponItemModel, &pBagItemModel, &pDynamiteItemModel};

float fSin, fSin90, fCos, fCos90, fCameraVelocity = 1.0f, fPauseBlend,
	  fPauseTextBlend, fFlareRot;
float fWaterScale[3], fWaterLastScale[3], fWaterToScale[3], fWaterScaleVelocity[3];
BOOL bPause, bPauseTextBlend, bLevelPressAnyKey, bHurryUpText,
	 bGameOver, bSpecialPause;
long lPauseTimer, lLevelCompleteTimer, lKeyTimer, lCameraTimerT, lHurryUpTimer,
     lCameraPauseTimerT;
AS_CAMERA TempCamera;
// OpenGL lists:
GLuint iWaveList, iShieldList, iHealthItemList, iHealthIncreaseItemList, iLifeItemList, iPullItemList,
	   iChestItemList, iStrengthItemList, iCoinItemList, iGhostItemList, iPlayerShotItemList,
	   iTimeItemList, iStepsItemList, iSpeedItemList, iWingItemList, iShieldItemList,
	   iJumpItemList, iAirItemList, iAirIncreaseItemList, iThrowItemList, iKickItemList,
	   iWeaponItemList, iBagItemList, iDynamiteItemList, iParticleList;
// Small message:
long lSmallMessageShowTime, lSmallMessageTimer, lSmallMessageTempTimer;
float fSmallMessageBlend;
char bySmallMessageText[256], bySmallMessageNewText[256];
BOOL bSmallMessageChangeText, bSmallMessageShowText;
// Some special font characters:
UCHAR byCheckedCharacter = 128,
	  byCrossCharacter = 129,
	  byDashCharacter = 144;

FLOAT3 fCameraPosT;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
HRESULT Game(void);
void SetGameLanguage(void);
void LoadGameTextures(void);
void CreateBlurTexture(void);
void DestroyBlurTexture(void);
HRESULT GameLoop(void);
void UpdateAllTextures(void);
void UpdateRenderQuality(void);
void CreateGameLists(void);
void DestroyGameLists(void);
void InitGameObjects(void);
void DestroyGameObjects(void);
void InitGameParticleSystems(void);
void DestroyGameParticleSystems(void);
void CreateWaterWave(float, float, float);
void CreateExplosion1(float, float, float, float);
void CalculateCamersSinCos(void);
void CheckCameraKeys(BOOL);
BOOL PlayCameraScript(BOOL);
void SetCameraTranslation(BOOL);
void SetPerspective(float);
void WaterEntry(void);
void InitDisplayActors(void);
void ShowSmallMessage(char *, long);
void DisplaySmallMessage(AS_WINDOW *);
void CheckSmallMessage(void);
void CheckDebugKeys(void);
void ReloadModels(void);
void ReloadTextures(void);
void ReloadSounds(void);
void ReloadTexts(void);
void MakeFlare(float, float, float, float, float, float, FLOAT3);
void DrawFlares(AS_VECTOR3D, float, float, float, float, float);
///////////////////////////////////////////////////////////////////////////////


HRESULT Game(void)
{ // begin Game()
	MSG msg;

	_AS->WriteLogMessage("Enter game module");

	// Create the game window and create the DirectInput stuff:
	_AS->ASCreateWindow(WindowProc, GAME_WINDOW_NAME, GAME_WINDOW_NAME, _ASConfig->iWindowWidth,
					    _ASConfig->iWindowHeight, LoadMenu(_AS->GetInstance(), MAKEINTRESOURCE(IDR_GAME)),
						_ASConfig->bFullScreen, GameMenuDraw, GameMenuCheck, NULL, TRUE);
	GAME_WINDOW_ID = _AS->GetWindows()-1;
	SetGameLanguage();
	ASInitOpenGL(&_AS->pWindow[GAME_WINDOW_ID],
				 NULL,
				 _AS->pWindow[GAME_WINDOW_ID].GethDC(),
				 _AS->pWindow[GAME_WINDOW_ID].GethRC(), _ASConfig->bFullScreen);
	_AS->CreateDXInputDevices(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), FALSE, TRUE, TRUE, FALSE);
	ShowWindow(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), SW_SHOW);	

	// Load and create the game objects and textures:
	ASGenOpenGLTextures(GAME_TEXTURES, GameTexture);
	CreateBlurTexture();
	CreateGameLists();
	InitGameParticleSystems();
	
	// Fist, show the logos:
	if(!bEditorTestLevel)
		bInGameMenu	= TRUE; // We don't test an level
	else
	{
		bInGameMenu = FALSE; // We came from the editor and want to test an level
		bSingleLevel = TRUE;

		// Create a new player identity:
		CurrentCampaign.iLevels = 1;
		CreateNewPlayerInfo(&PlayerIdentity, &CurrentCampaign);
		strcpy(PlayerIdentity.byName, AS_T(T_EditorLevelTest));
		PlayerIdentity.bSingleLevel = PlayerIdentity.bEditorLevelTest = TRUE;
		strcpy(PlayerIdentity.bySingleLevelName, byCurrentLevelName);
		SavePlayerIdentity(&PlayerIdentity, &CurrentCampaign);
	}

	_AS->WriteLogMessage("Enter game main loop");
	for(;;)
	{
		if(_AS->GetShutDown() || _AS->CheckModuleChange())
			break;
		if(bShowLogos)
			Logos();
		else
			if(bInGameMenu)
			{ // We are in the game menu:
				msg.wParam = GameMenuLoop();
			}
			else
			{ // We are in the game:
				StopMusic();
				msg.wParam = GameLoop();
				if(bEditorTestLevel && !bInGameMenu)
					_AS->SetNextModule(MODULE_EDITOR);
				StopMusic();
				byGameMenuMenu = GM_MAIN_MENU;
			}
	}
	_AS->WriteLogMessage("Left game main loop");

	StopMusic();
	DestroyCampaign(&CurrentCampaign);
	DestroyPlayerInfo(&PlayerIdentity);

	ASDestroyOpenGLTextures(GAME_TEXTURES, GameTexture);
	DestroyBlurTexture();
	DestroyGameLists();
	DestroyGameParticleSystems();
	ActorDestroyTexturesOpenGL(*_AS->pWindow[GAME_WINDOW_ID].GethDC(),
							   *_AS->pWindow[GAME_WINDOW_ID].GethRC(), TRUE);
	
	// Destroy the game window and the corresponding DirectInput stuff:
	_AS->FreeDXInputDevices();
	ASDestroyOpenGL(&_AS->pWindow[GAME_WINDOW_ID],
					NULL,
				    *_AS->pWindow[GAME_WINDOW_ID].GethDC(),
				    *_AS->pWindow[GAME_WINDOW_ID].GethRC());
	_AS->ASDestroyWindow(_AS->pWindow[GAME_WINDOW_ID].GethWnd(), GAME_WINDOW_NAME);
	GAME_WINDOW_ID = -1;
	
	// Left the game module:
	strcpy(byCurrentMusic, " ");
	_AS->SetModule(MODULE_EDITOR);
	_AS->WriteLogMessage("Left game module");

	return msg.wParam;
} // end Game()

void SetGameLanguage(void)
{ // begin SetGameLanguage()
	char byTemp[256];
	HWND hWndGame;
	
	if(GAME_WINDOW_ID == -1)
		return;
	hWndGame = *_AS->pWindow[GAME_WINDOW_ID].GethWnd();

	// Setup the texts of the menu bar:
	HMENU hMenu = GetMenu(hWndGame);
	MENUITEMINFO SubMenuInfo = { sizeof(MENUITEMINFO),
							     MIIM_ID | MIIM_TYPE,
								 MFT_STRING, MFS_DEFAULT,
								 ID_GAME_GENERAL_MAIN_MENU,
								 NULL, NULL, NULL, NULL,
								 AS_T(T_MainMenu), 0};
	ModifyMenu(hMenu, 0, MF_STRING | MF_BYPOSITION, 0, AS_T(T_General));
	SetMenuItemInfo(GetSubMenu(hMenu, 0), 0, TRUE, &SubMenuInfo);
	
	SubMenuInfo.wID = ID_GAME_GENERAL_EDITOR;
	SubMenuInfo.dwTypeData = AS_T(T_Editor);
	SetMenuItemInfo(GetSubMenu(hMenu, 0), 2, TRUE, &SubMenuInfo);
	
	SubMenuInfo.wID = ID_GAME_GENERAL_QUIT;
	sprintf(byTemp, "%s\tESC", AS_T(T_Quit));
	SubMenuInfo.dwTypeData = byTemp;
	SetMenuItemInfo(GetSubMenu(hMenu, 0), 4, TRUE, &SubMenuInfo);


	ModifyMenu(hMenu, 1, MF_STRING | MF_BYPOSITION, 0, AS_T(T_Configurations));
	
	SubMenuInfo.wID = ID_OPTIONS_CONFIG;
	sprintf(byTemp, "%s\tF12", AS_T(T_Configurations));
	SubMenuInfo.dwTypeData = byTemp;
	SetMenuItemInfo(GetSubMenu(hMenu, 1), 0, TRUE, &SubMenuInfo);
	
	SubMenuInfo.wID = ID_OPTIONS_SHOW_LOG;
	SubMenuInfo.dwTypeData = AS_T(T_ShowLog);
	SetMenuItemInfo(GetSubMenu(hMenu, 1), 1, TRUE, &SubMenuInfo);


	ModifyMenu(hMenu, 2, MF_STRING | MF_BYPOSITION, 0, AS_T(T_Help));
	
	SubMenuInfo.wID = ID_HELP_HELP;
	sprintf(byTemp, "%s\tF1", AS_T(T_Help));
	SubMenuInfo.dwTypeData = byTemp;
	SetMenuItemInfo(GetSubMenu(hMenu, 2), 0, TRUE, &SubMenuInfo);
	
	SubMenuInfo.wID = ID_HELP_CREACTIVE_MEDIA_HOMEPAGE;
	SubMenuInfo.dwTypeData = AS_T(T_CreactiveMediaHomepage);
	SetMenuItemInfo(GetSubMenu(hMenu, 2), 1, TRUE, &SubMenuInfo);

	SubMenuInfo.wID = ID_HELP_ECLYPSE_ENTERTAINMENT_HOMEPAGE;
	SubMenuInfo.dwTypeData = AS_T(T_EclypseEntertainmentHomepage);
	SetMenuItemInfo(GetSubMenu(hMenu, 2), 2, TRUE, &SubMenuInfo);

	SubMenuInfo.wID = ID_HELP_CREDITS;
	SubMenuInfo.dwTypeData = AS_T(T_Credits);
	SetMenuItemInfo(GetSubMenu(hMenu, 2), 3, TRUE, &SubMenuInfo);

	DrawMenuBar(hWndGame);
} // end SetGameLanguage()

void LoadGameTextures(void)
{ // begin LoadGameTextures()
	char byFilename[GAME_TEXTURES][256] = {"Fire1.jpg", "Fire2.jpg", "Fire3.jpg",
										   "Fire4.jpg", "BlibsEyes.jpg", "BlibsEyes_.jpg",
										   "Fire.jpg", "Wave.jpg", "Shield.jpg",
										   "Beam.jpg", "BlibsEyesXX.jpg",
										   "G_Particle1.jpg", "G_Particle2.jpg",
										   "Lightmap1.jpg", "Wave2.jpg",
										   "Shadowmap1.jpg", "Explosion1.jpg",
										   "Autosave.jpg", "Bubble.jpg",
										   "BlibsWeapon.jpg", "Metallic.jpg",
										   "G_Particle3.jpg", "G_Particle4.jpg",
										   "Acid.jpg", "Items1.tga", "Items2.tga",
										   "BlibsPanicEyes.jpg"};
	ASLoadTextures(byFilename, GAME_TEXTURES, GameTexture);

	// Some special texture settings:
	GameTexture[15].bNoMipmap = TRUE;
} // end LoadGameTextures()

void CreateBlurTexture(void)
{ // begin CreateBlurTexture()
	UINT *piData;

	// Create storage space for texture data (128x128x4)
	piData = (UINT *) new UINT[((128*128)*4*sizeof(UINT))];
	memset(piData, 0, sizeof(UINT)*128*128*4);

	glGenTextures(1, &BlurTexture.iOpenGLID);
	glBindTexture(GL_TEXTURE_2D, BlurTexture.iOpenGLID);
	glTexImage2D(GL_TEXTURE_2D, 0, 4, 128, 128, 0, GL_RGBA, GL_UNSIGNED_BYTE, piData);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	delete [] piData;
} // end CreateBlurTexture()

void DestroyBlurTexture(void)
{ // begin DestroyBlurTexture()
	glDeleteTextures(1, &BlurTexture.iOpenGLID);
} // end DestroyBlurTexture()

HRESULT GameLoop(void)
{ // begin GameLoop()
	char byTemp[256];
	MSG msg;

	_AS->bDraw = FALSE;
	byGameMenuMenu = byGameMenuSelected = 0;
	InitMenuPoints();
	_AS->pWindow[GAME_WINDOW_ID].SetDrawFunction(GameDraw);
	_AS->pWindow[GAME_WINDOW_ID].SetCheckFunction(GameCheck);
	glDisableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_COLOR_ARRAY);
	glDisableClientState(GL_NORMAL_ARRAY);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);
	StopMusic();

	if(!pLevel)
		StartCurrentLevel();
	if(!_AS->CheckModuleChange() && !bInGameMenu)
	{
		// Show the level start video if there is one:
		if(pLevel->Header.bStartVideo)
		{
			ASSetPauseFmodMusic(&GameMusic, TRUE);
			ASStopAllFmodSamples(GAME_SAMPLES, GameSample);
			sprintf(byTemp, "%s%s", _AS->byProgramPath, pLevel->Header.byStartVideoFilename);
			ASPlayVideo(GAME_WINDOW_ID, byTemp);
			ASSetPauseFmodMusic(&GameMusic, FALSE);
		}

		Sleep(1); // If this isn't done the system will crash... maybe an windows message error??
		lKeyTimer = 0;
		_AS->bDraw = TRUE;

		// Go into the game loop:
		_AS->WriteLogMessage("Enter the game loop");
		for(;;)
		{
			if(PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
    		{
        		if(!GetMessage(&msg, NULL, 0, 0))
					break;
        		TranslateMessage(&msg);
        		DispatchMessage(&msg);
    		}
			else
			{	
				if(_AS->GetShutDown() || _AS->CheckModuleChange() || bInGameMenu)
					PostQuitMessage(0);
				if(!_AS->GetActive())
					continue;
				if(pLevel && pLevel->State.bLevelComplete)
					_AS->UpdateWindows(FALSE);
				else
					_AS->UpdateWindows(bPause);
				CheckMusic();
			}
		}
	}
	_AS->WriteLogMessage("Left the game loop");
	DestroyLevel();

	// Save the configuration:	
	sprintf(byTemp, "%s%s", _AS->byProgramPath, _AS->byConfigFilename);
	_ASConfig->Save(byTemp);
	
	if(!bSingleLevel) // Save the player identity:
		SavePlayerIdentity(&PlayerIdentity, &CurrentCampaign);
	if(bEditorTestLevel)
	{ // Remove the test data:
		sprintf(byTemp, "%s%s\\%s\\", _AS->byProgramPath, _AS->byIdentityDirectory, PlayerIdentity.byName);
		ASRemoveDirectory(byTemp);
	}

	return msg.wParam;
} // end GameLoop()

void UpdateAllTextures(void)
{ // begin UpdateAllTextures()
	if(bFirstRunConfigDialog)
		return;
	ASDestroyOpenGLTextures(GAME_TEXTURES, GameTexture);
	ASDestroyOpenGLTextures(GAME_MENU_TEXTURES, GameMenuTexture);
	ASDestroyOpenGLTextures(LOGOS_TEXTURES, LogosTexture);
	ASGenOpenGLTextures(GAME_TEXTURES, GameTexture);
	ASGenOpenGLTextures(GAME_MENU_TEXTURES, GameMenuTexture);
	ASGenOpenGLTextures(LOGOS_TEXTURES, LogosTexture);
	switch(_AS->GetModule())
	{
		case MODULE_GAME:
			_AS->pWindow[GAME_WINDOW_ID].KillFont();
			_AS->pWindow[GAME_WINDOW_ID].BuildFont();
			if(pLevel)
			{
				pLevel->DestroyTexturesOpenGL(*_AS->pWindow[GAME_WINDOW_ID].GethDC(), 
											  *_AS->pWindow[GAME_WINDOW_ID].GethRC());
				pLevel->GenTexturesOpenGL(*_AS->pWindow[GAME_WINDOW_ID].GethDC(), 
										  *_AS->pWindow[GAME_WINDOW_ID].GethRC());
			}
		break;

		case MODULE_EDITOR:
			ASKillFont();
			ASBuildFont();
			if(pLevel)
			{
				pLevel->DestroyTexturesOpenGL(hDCEditorShow, hRCEditorShow);
				pLevel->GenTexturesOpenGL(hDCEditorShow, hRCEditorShow);
			}
		break;
	}
	DestroyBlurTexture();
	CreateBlurTexture();
} // end UpdateAllTextures()

void UpdateRenderQuality(void)
{ // begin UpdateRenderQuality()
	RECT Rect;

	if(bFirstRunConfigDialog)
		return;
	switch(_AS->GetModule())
	{
		case MODULE_GAME:
			ASConfigOpenGL(_AS->pWindow[GAME_WINDOW_ID].GetWidth(), _AS->pWindow[GAME_WINDOW_ID].GetWidth());
		break;

		case MODULE_EDITOR:
			GetWindowRect(hWndEditorShow, &Rect);
			wglMakeCurrent(hDCEditorShow, hRCEditorShow);
			ASConfigOpenGL(Rect.right-Rect.left, Rect.bottom-Rect.top);
		break;
	}
} // end UpdateRenderQuality()

void CreateGameLists(void)
{ // begin CreateGameLists()
	AS_PROGRESS_WINDOW ProgressWindow;

	ProgressWindow.CreateProgressWindow("Create lists");
	ProgressWindow.SetTask("...");
	ProgressWindow.SetProgress(0);

	_AS->WriteLogMessage("Create game lists");
	// Wave list:
	iWaveList = glGenLists(25);
	glNewList(iWaveList, GL_COMPILE);
		glBindTexture(GL_TEXTURE_2D, GameTexture[7].iOpenGLID);
		glBegin(GL_QUADS);
			// Left bottom
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f(-0.5f, -0.5f, 0.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f(0.0f, -0.5f, 0.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f(0.0f, 0.0f, 0.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f(-0.5f, 0.0f, 0.0f);
			// Right bottom
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f(0.0f, -0.5f, 0.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f(0.5f, -0.5f, 0.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f(0.5f, 0.0f, 0.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f(0.0f, 0.0f, 0.0f);
			// Left Top
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f(-0.5f, 0.0f, 0.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f(0.0f, 0.0f, 0.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f(0.0f, 0.5f, 0.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f(-0.5f, 0.5f, 0.0f);
			// Right Top
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f(0.0f, 0.0f, 0.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f(0.5f, 0.0f, 0.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f(0.5f, 0.5f, 0.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f(0.0f, 0.5f, 0.0f);
		glEnd();
	glEndList();
	// Shield list:
	iShieldList = iWaveList+1;
	glNewList(iShieldList, GL_COMPILE);
		glBindTexture(GL_TEXTURE_2D, GameTexture[8].iOpenGLID);
		glBegin(GL_QUADS);
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f(-0.8f, -0.8f, 0.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f(0.8f, -0.8f, 0.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f(0.8f, 0.8f, 0.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f(-0.8f, 0.8f, 0.0f);
		glEnd();
	glEndList();

	// Health item list:
	iHealthItemList = iShieldList+1;
	glNewList(iHealthItemList, GL_COMPILE);
		ASDrawMd2Frame(pHealthItemModel, 0);
	glEndList();
	// Health increase item list:
	iHealthIncreaseItemList = iHealthItemList+1;
	glNewList(iHealthItemList, GL_COMPILE);
		ASDrawMd2Frame(pHealthIncreaseItemModel, 0);
	glEndList();
	// Life item list:
	iLifeItemList = iHealthIncreaseItemList+1;
	glNewList(iLifeItemList, GL_COMPILE);
		ASDrawMd2Frame(pLifeItemModel, 0);
	glEndList();
	// Pull item list:
	iPullItemList = iLifeItemList+1;
	glNewList(iPullItemList, GL_COMPILE);
		ASDrawMd2Frame(pPullItemModel, 0);
	glEndList();
	// Chest item list:
	iChestItemList = iPullItemList+1;
	glNewList(iChestItemList, GL_COMPILE);
		ASDrawMd2Frame(pChestItemModel, 0);
	glEndList();
	// Strength item list:
	iStrengthItemList = iChestItemList+1;
	glNewList(iStrengthItemList, GL_COMPILE);
		ASDrawMd2Frame(pStrengthItemModel, 0);
	glEndList();
	// Coin item list:
	iCoinItemList = iStrengthItemList+1;
	glNewList(iCoinItemList, GL_COMPILE);
		glEnable(GL_ALPHA_TEST);
		ASDrawMd2Frame(pCoinItemModel, 0);
		glDisable(GL_ALPHA_TEST);
	glEndList();
	// Ghost item list:
	iGhostItemList = iCoinItemList+1;
	glNewList(iGhostItemList, GL_COMPILE);
		ASDrawMd2Frame(pGhostItemModel, 0);
	glEndList();
	// Time item list:
	iTimeItemList = iGhostItemList+1;
	glNewList(iTimeItemList, GL_COMPILE);
		ASDrawMd2Frame(pTimeItemModel, 0);
	glEndList();
	// Steps item list:
	iStepsItemList = iTimeItemList+1;
	glNewList(iStepsItemList, GL_COMPILE);
		ASDrawMd2Frame(pStepsItemModel, 0);
	glEndList();
	// Speed item list:
	iSpeedItemList = iStepsItemList+1;
	glNewList(iSpeedItemList, GL_COMPILE);
		ASDrawMd2Frame(pSpeedItemModel, 0);
	glEndList();
	// Wing item list:
	iWingItemList = iSpeedItemList+1;
	glNewList(iWingItemList, GL_COMPILE);
		ASDrawMd2Frame(pWingItemModel, 0);
	glEndList();
	// Shield item list:
	iShieldItemList = iWingItemList+1;
	glNewList(iShieldItemList, GL_COMPILE);
		ASDrawMd2Frame(pShieldItemModel, 0);
	glEndList();
	// Jump item list:
	iJumpItemList = iShieldItemList+1;
	glNewList(iJumpItemList, GL_COMPILE);
		ASDrawMd2Frame(pJumpItemModel, 0);
	glEndList();
	// Air item list:
	iAirItemList = iJumpItemList+1;
	glNewList(iAirItemList, GL_COMPILE);
		ASDrawMd2Frame(pAirItemModel, 0);
	glEndList();
	// Air increase item list:
	iAirIncreaseItemList = iAirItemList+1;
	glNewList(iAirIncreaseItemList, GL_COMPILE);
		ASDrawMd2Frame(pAirIncreaseItemModel, 0);
	glEndList();
	// Throw item list:
	iThrowItemList = iAirIncreaseItemList+1;
	glNewList(iThrowItemList, GL_COMPILE);
		ASDrawMd2Frame(pThrowItemModel, 0);
	glEndList();
	// Kick item list:
	iKickItemList = iThrowItemList+1;
	glNewList(iKickItemList, GL_COMPILE);
		ASDrawMd2Frame(pKickItemModel, 0);
	glEndList();
	// Weapon item list:
	iWeaponItemList = iKickItemList+1;
	glNewList(iWeaponItemList, GL_COMPILE);
		ASDrawMd2Frame(pWeaponItemModel, 0);
	glEndList();
	// Bag item list:
	iBagItemList = iWeaponItemList+1;
	glNewList(iBagItemList, GL_COMPILE);
		ASDrawMd2Frame(pBagItemModel, 0);
	glEndList();
	// Dynamite item list:
	iDynamiteItemList = iBagItemList+1;
	glNewList(iDynamiteItemList, GL_COMPILE);
		ASDrawMd2Frame(pDynamiteItemModel, 0);
	glEndList();

	// Player shot list:
	iPlayerShotItemList = iDynamiteItemList+1;
	glNewList(iPlayerShotItemList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
//		if(pPlayerShot)
//			pPlayerShot->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
	// Particle list:
	iParticleList = iPlayerShotItemList+1;
	glNewList(iParticleList, GL_COMPILE);
		glBegin(GL_QUADS);
			glTexCoord2f(0.0f, 0.0f); glVertex3f(-0.2f, -0.2f, 0.0f);
			glTexCoord2f(1.0f, 0.0f); glVertex3f(0.2f, -0.2f, 0.0f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f(0.2f, 0.2f, 0.0f);
			glTexCoord2f(0.0f, 1.0f); glVertex3f(-0.2f, 0.2f, 0.0f);
		glEnd();
	glEndList();
	_AS->WriteLogMessage("Create game lists: OK");
} // end CreateGameLists()()

void DestroyGameLists(void)
{ // begin DestroyGameLists()
	AS_PROGRESS_WINDOW ProgressWindow;

	ProgressWindow.CreateProgressWindow("Destroy lists");
	ProgressWindow.SetTask("...");
	ProgressWindow.SetProgress(0);
	glDeleteLists(iWaveList, 25);
} // end DestroyeGameLists()()

void InitGameObjects(void)
{ // begin InitGameObjects()
	char byModelFileTemp[MODELS][256] = {"Blibs.md2", "BlibsWeapon.md2", "BlibsEyes.md2",
										 "LuciferHead.md2", "Mobmob.md2", "X3.md2",
										 "Pencil.md2", "Camera.md2", "Lucifer.md2",
										 "Item_Health.md2", "Item_HealthIncrease.md2",
										 "Item_Life.md2", "Item_Pull.md2", "Item_Chest.md2",
										 "Item_Strength.md2", "Item_Coin.md2", "Item_Ghost.md2",
										 "Item_Time.md2", "Item_Steps.md2", "Item_Speed.md2",
										 "Item_Wings.md2", "Item_Shield.md2", "Item_Jump.md2",
										 "Item_Air.md2", "Item_AirIncrease.md2", "Item_Throw.md2",
										 "Item_Kick.md2", "Item_Weapon.md2", "Item_Bag.md2",
										 "Item_Dynamite.md2"};
	int i;
	char byTemp[256], byTemp2[256];
	AS_PROGRESS_WINDOW ProgressWindow;

	ProgressWindow.CreateProgressWindow("Models");
	ProgressWindow.SetTask("Load models...");
	ProgressWindow.SetProgress(0);

	// Load all models:
	_AS->WriteLogMessage("Init game objects");
	for(i = 0; i < MODELS; i++)
	{
		sprintf(byTemp, "%s%s\\%s", _AS->byProgramPath, _AS->byObjectsDirectory, byModelFileTemp[i]);
		ProgressWindow.SetSubTask("%s", byTemp);
		ProgressWindow.SetProgress((UINT) (((float) i/MODELS)*100));
		sprintf(byTemp2, "Load model: %s", byTemp);
		_AS->WriteLogMessage(byTemp2);
		if(!((*pModels[i]) = ASLoadMd2Model(byTemp)))
		{
			_AS->WriteLogMessage("------------------------------------------");
			_AS->WriteLogMessage("Couldn't load: %s   program couldn't run!!", byTemp);
			_AS->WriteLogMessage("------------------------------------------");
			_ASConfig->bError = TRUE;
			_ASConfig->bSetError = TRUE;
			_AS->SetShutDown(TRUE);
			return;
		}
	}
	_AS->WriteLogMessage("Init game objects: OK");
} // end InitGameObjects()

void DestroyGameObjects(void)
{ // begin DestroyGameObjects()
	AS_PROGRESS_WINDOW ProgressWindow;

	ProgressWindow.CreateProgressWindow("Models");
	ProgressWindow.SetTask("Destroy models...");
	ProgressWindow.SetProgress(0);

	// Destroy all game objects:
	for(int i = 0; i < MODELS; i++)
	{
		if(!(*pModels[i]))
			continue;
		ProgressWindow.SetSubTask("%s", (*pModels[i])->byFilename);
		ProgressWindow.SetProgress((UINT) (((float) i/MODELS)*100));
		ASFreeMd2Model(*pModels[i]);
	}
} // end DestroyGameObjects()

void InitGameParticleSystems(void)
{ // begin InitGameParticleSystems()
	AS_PARTICLE_SYSTEM *pSystemT;

	_AS->WriteLogMessage("Init game particle system");

	// PS_PLAYER_SPEED:
	ParticleManager.AddNewSystem(PS_Md2Trace, 2000, pPlayer, &GameTexture[6], NULL);

	// PS_PLAYER_GHOST:
	ParticleManager.AddNewSystem(PS_Md2Trace, 2000, pPlayer, &GameTexture[12], NULL);

	// PS_PLAYER_AUTOSAVE:
	ParticleManager.AddNewSystem(PS_Autosave, 300, pPlayer, &GameTexture[17], NULL);
	pSystemT = &ParticleManager.pSystem[PS_PLAYER_AUTOSAVE];
	pSystemT->bAnimatedParticles = TRUE;
	pSystemT->iAnimationColumns = 2;
	pSystemT->iAnimationRows = 2;
	pSystemT->iTextureWidth = 128;
	pSystemT->iTextureHeight = 128;

	// PS_WATER_BUBBLES:
	ParticleManager.AddNewSystem(PS_Bubbles, 500, NULL, &GameTexture[18], NULL);
	pSystemT = &ParticleManager.pSystem[PS_WATER_BUBBLES];
	pSystemT->bActive = TRUE;
	pSystemT->bAnimatedParticles = TRUE;
	pSystemT->iAnimationColumns = 2;
	pSystemT->iAnimationRows = 2;
	pSystemT->iTextureWidth = 128;
	pSystemT->iTextureHeight = 128;

	// PS_WATER_WAVES:
	ParticleManager.AddNewSystem(PS_WaterWaves, 200, NULL, &GameTexture[14], NULL);
	pSystemT = &ParticleManager.pSystem[PS_WATER_WAVES];
	pSystemT->bActive = TRUE;
	pSystemT->bAnimatedParticles = TRUE;
	pSystemT->iAnimationColumns = 2;
	pSystemT->iAnimationRows = 2;
	pSystemT->iTextureWidth = 256;
	pSystemT->iTextureHeight = 256;

	// PS_EXPLOSION1:
	ParticleManager.AddNewSystem(PS_Explosion1, 200, NULL, &GameTexture[16], NULL);
	pSystemT = &ParticleManager.pSystem[PS_EXPLOSION1];
	pSystemT->bActive = TRUE;
	pSystemT->bAnimatedParticles = TRUE;
	pSystemT->iAnimationColumns = 4;
	pSystemT->iAnimationRows = 4;
	pSystemT->iTextureWidth = 256;
	pSystemT->iTextureHeight = 256;

	// PS_PLAYER_WING_SMOKE:
	ParticleManager.AddNewSystem(PS_WingSmoke, 100, pPlayer, &GameTexture[22], NULL);
	pSystemT = &ParticleManager.pSystem[PS_PLAYER_WING_SMOKE];
	pSystemT->bActive = TRUE;
	pSystemT->bAnimatedParticles = TRUE;
	pSystemT->iAnimationColumns = 4;
	pSystemT->iAnimationRows = 4;
	pSystemT->iTextureWidth = 256;
	pSystemT->iTextureHeight = 256;

	// PS_LIGHTS:
	ParticleManager.AddNewSystem(PS_Lights, 3, pPlayer, &GameTexture[12], NULL);
	ParticleManager.pSystem[PS_LIGHTS].bActive = TRUE;
		// 0 & 1: Blibs blinking feeler
		// 2: Lucifer standby light

	_AS->WriteLogMessage("Init game particle system: OK");
} // end InitGameParticleSystems()

void DestroyGameParticleSystems(void)
{ // begin DestroyGameParticleSystems()
	_AS->WriteLogMessage("Destroy game particle system");
	ParticleManager.Destroy();
	_AS->WriteLogMessage("Destroy game particle system");
} // end DestroyGameParticleSystems()

void CreateWaterWave(float fXPos, float fYPos, float fSize)
{ // begin CreateWaterWave()
	AS_PARTICLE *pParticleT;
	FLOAT4 fColor;
	int i;
	
	i = ParticleManager.pSystem[PS_WATER_WAVES].GetFreeParticle();
	if(i == -1)
		return;
	pParticleT = &ParticleManager.pSystem[PS_WATER_WAVES].pParticle[i];
	pParticleT->bAlive = TRUE;
	pParticleT->fEngine = (float) 1.0;
	pParticleT->fPos[X] = fXPos;
	pParticleT->fPos[Y] = fYPos;
	pLevel->ComputeWaterColor(pParticleT->fPos[X], pParticleT->fPos[Y], &fColor);
	pParticleT->fColor[0] = fColor[R]+0.1f;
	pParticleT->fColor[1] = fColor[G]+0.1f;
	pParticleT->fColor[2] = fColor[B]+0.1f;
	pParticleT->fDensity = fColor[A]+0.2f;
	pParticleT->fFadeSpeed = 0.004f;
	pParticleT->fSize = fSize;
	pParticleT->lLastAnimtationTime = g_lGameTimer;
} // end CreateWaterWave()

void CreateExplosion1(float fXPos, float fYPos, float fZPos, float fSize)
{ // begin CreaterExplosion1()
	AS_PARTICLE *pParticleT;
	int i;
	
	i = ParticleManager.pSystem[PS_EXPLOSION1].GetFreeParticle();
	if(i == -1)
		return;
	pParticleT = &ParticleManager.pSystem[PS_EXPLOSION1].pParticle[i];
	memset(pParticleT, 0, sizeof(AS_PARTICLE));
	pParticleT->bAlive = TRUE;
	pParticleT->fEngine = (float) 1.0;
	pParticleT->fColor[0] = 1.0f;
	pParticleT->fColor[1] = 1.0f;
	pParticleT->fColor[2] = 1.0f;
	pParticleT->fDensity = 0.8f;
	pParticleT->fFadeSpeed = 0.002f+(rand() % 100)/10000;
	pParticleT->fSize = fSize;
	pParticleT->fPos[X] = fXPos;
	pParticleT->fPos[Y] = fYPos;
	pParticleT->fPos[Z] = fZPos;
	pParticleT->lLastAnimtationTime = g_lGameTimer;
} // end CreateExplosion1()

void CalculateCamersSinCos(void)
{ // begin CalculateCamersSinCos()
	// We should be in the range of 0.0 and 360.0:
	for(;;)
	{
		if(_ASCamera->fRot[Z] < 0.0f)
			_ASCamera->fRot[Z] += 360.0f;
		if(_ASCamera->fRot[Z] > 360.0f)
			_ASCamera->fRot[Z] -= 360.0f;
		if(_ASCamera->fRot[Z] >= 0.0f && _ASCamera->fRot[Z] <= 360.0f)
			break;
	}
	// This are the sin/cos depending of the current camera direction:
	fSin = (float) sin(_ASCamera->fRot[Z]*PI180);
	fSin90 = (float) sin((_ASCamera->fRot[Z]+90.0f)*PI180);
	fCos = (float) cos(_ASCamera->fRot[Z]*PI180);
	fCos90 = (float) cos((_ASCamera->fRot[Z]+90.0f)*PI180);
} // end CalculateCamersSinCos()

void CheckCameraKeys(BOOL bEditor)
{ // begin CheckCameraKeys()
	HWND hWnd = hWndEditor;
	
	if(!bEditor && bGameOver)
		return;
	if(bEditor)
	{
		if(ASKeys[157])
		{
			if(hWndEditorShow)
			{
				SetActiveWindow(hWnd);
				SetFocus(hWnd);
			}
			ASKeys[29] = TRUE;
		}
		if(ASKeys[54])
		{
			if(hWndEditorShow)
			{
				SetActiveWindow(hWnd);
				SetFocus(hWnd);
			}
			ASKeys[42] = TRUE;
		}

		if(ASKeys[DIK_RETURN])
		{ // Change FOV:
			if(CHECK_KEY(ASKeys, DIK_UP))
				_ASCamera->fFOV -= (float) g_lDeltatime/50*fCameraVelocity;
			if(CHECK_KEY(ASKeys, _ASConfig->iStandartViewKey[0]))
				_ASCamera->fFOV = 0.0f;
			if(CHECK_KEY(ASKeys, DIK_DOWN))
				_ASCamera->fFOV += (float) g_lDeltatime/50*fCameraVelocity;
		}
		else
		if(ASKeys[DIK_BACK])
		{ // Change stretch:
			if(CHECK_KEY(ASKeys, DIK_LEFT))
				_ASCamera->fStretch[X] -= (float) g_lDeltatime/5*fCameraVelocity;
			if(CHECK_KEY(ASKeys, DIK_UP))
				_ASCamera->fStretch[Y] -= (float) g_lDeltatime/5*fCameraVelocity;
			if(CHECK_KEY(ASKeys, _ASConfig->iStandartViewKey[0]))
			{
				_ASCamera->fStretch[X] = 0.0f;
				_ASCamera->fStretch[Y] = 0.0f;
			}
			if(CHECK_KEY(ASKeys, DIK_RIGHT))
				_ASCamera->fStretch[X] += (float) g_lDeltatime/5*fCameraVelocity;
			if(CHECK_KEY(ASKeys, DIK_DOWN))
				_ASCamera->fStretch[Y] += (float) g_lDeltatime/5*fCameraVelocity;
		}
		else
		{ // Camera movement keys:
			if(!ASKeys[42] && !ASKeys[29])
			{
				if(CHECK_KEY(ASKeys, DIK_LEFT))
				{
					if(hWndEditorShow)
					{
						SetActiveWindow(hWnd);
						SetFocus(hWnd);
					}
					_ASCamera->fPos[X] += fSin90*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
					_ASCamera->fPos[Y] += fCos90*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
					_ASCamera->fPos2[X] += fSin90*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
					_ASCamera->fPos2[Y] += fCos90*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
				}
				if(CHECK_KEY(ASKeys, DIK_RIGHT))
				{
					if(hWndEditorShow)
					{
						SetActiveWindow(hWnd);
						SetFocus(hWnd);
					}
					_ASCamera->fPos[X] -= fSin90*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
					_ASCamera->fPos[Y] -= fCos90*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
					_ASCamera->fPos2[X] -= fSin90*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
					_ASCamera->fPos2[Y] -= fCos90*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
				}
				if(CHECK_KEY(ASKeys, DIK_UP))
				{
					if(hWndEditorShow)
					{
						SetActiveWindow(hWnd);
						SetFocus(hWnd);
					}
					_ASCamera->fPos[X] += fSin*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
					_ASCamera->fPos[Y] += fCos*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
					_ASCamera->fPos2[X] += fSin*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
					_ASCamera->fPos2[Y] += fCos*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
				}
				if(CHECK_KEY(ASKeys, DIK_DOWN))
				{
					if(hWndEditorShow)
					{
						SetActiveWindow(hWnd);
						SetFocus(hWnd);
					}
					_ASCamera->fPos[X] -= fSin*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
					_ASCamera->fPos[Y] -= fCos*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
					_ASCamera->fPos2[X] -= fSin*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
					_ASCamera->fPos2[Y] -= fCos*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
				}
			}
			if(CHECK_KEY(ASKeys, _ASConfig->iStandartViewKey[0]))
				pLevel->SetStandartView();
		}
	}
	else
	{
		// Check the standart view key:
		if(CHECK_KEY(ASKeys, _ASConfig->iStandartViewKey[0]) && (!pPlayer || (pPlayer && !pPlayer->bGoingDeath)))
			pLevel->SetStandartView();
	}

	// Rotate and move the camera:
	if(ASKeys[42] && CHECK_KEY(ASKeys, DIK_RIGHT))
		_ASCamera->fRot[Y] += 0.05f*g_lDeltatime*fCameraVelocity;
	if(ASKeys[42] && CHECK_KEY(ASKeys, DIK_LEFT))
		_ASCamera->fRot[Y] -= 0.05f*g_lDeltatime*fCameraVelocity;
	if(ASKeys[42] && CHECK_KEY(ASKeys, DIK_DOWN))
		_ASCamera->fRot[X] += -_ASCamera->fRot2[X]+0.05f*g_lDeltatime*fCameraVelocity;
	if(ASKeys[42] && CHECK_KEY(ASKeys, DIK_UP))
		_ASCamera->fRot[X] -= 0.05f*g_lDeltatime*fCameraVelocity;

	if(ASKeys[29] && CHECK_KEY(ASKeys, DIK_RIGHT))
		_ASCamera->fRot[Z] -= 0.05f*g_lDeltatime*fCameraVelocity;
	if(ASKeys[29] && CHECK_KEY(ASKeys, DIK_LEFT))
		_ASCamera->fRot[Z] += 0.05f*g_lDeltatime*fCameraVelocity;
	
	// Zoom in and out:
	if(ASKeys[29] && CHECK_KEY(ASKeys, DIK_UP))
		_ASCamera->fZ += 0.01f*g_lDeltatime*fCameraVelocity;
	if(ASKeys[29] && CHECK_KEY(ASKeys, DIK_DOWN))
		_ASCamera->fZ -= 0.01f*g_lDeltatime*fCameraVelocity;
} // end CheckCameraKeys()

BOOL PlayCameraScript(BOOL bLoop)
{ // begin PlayCameraScript()
	AS_CAMERA *pCameraNow, *pCameraNext, *pCameraT1, *pCameraT2, *pCameraT3, *pCameraT4;
	AS_QUATERNION Q, qFrom, qTo, Q1, Q2, Q3, Q4;
	AS_QUATERNION S1, S2;
	float fDeltaT;
	int i, i2, iCurrentStep;

	if(bCameraAnimation && pLevel->pCurrentCameraScript)
	{ // We play a camera script:
		pPlayer->SetAction(AA_STANDING);
		if(bPause && !pLevel->State.bLevelComplete)
			lCameraTimer = g_lGameTimer-lCameraPauseTimerT;
		if(!bPause || pLevel->State.bLevelComplete)
		{
			// Make a smooth camera movement:
			// Get the camera positions:
			pCameraNow = &pLevel->pCurrentCameraScript->pCamera[pLevel->Camera.iCurrentCameraStep];
			i2 = pLevel->Camera.iCurrentCameraStep+1;
			if(i2 >= pLevel->pCurrentCameraScript->iSteps)
				i2 = 0;
			pCameraNext = &pLevel->pCurrentCameraScript->pCamera[i2];
			
			// No division throught zero!!
			if(!pCameraNow->iTimeToNext)
				pCameraNow->iTimeToNext = 1;
			if(!pCameraNext->iTimeToNext)
				pCameraNext->iTimeToNext = 1;

			// Calculate the current camera pos:
			fDeltaT = (float) (g_lGameTimer-lCameraTimer)/(pCameraNow->iTimeToNext);

			iCurrentStep = pLevel->Camera.iCurrentCameraStep-1;
			if(iCurrentStep < 0 || iCurrentStep >= pLevel->pCurrentCameraScript->iSteps)
				iCurrentStep = 0;
			pCameraT1 = &pLevel->pCurrentCameraScript->pCamera[iCurrentStep];

			iCurrentStep = pLevel->Camera.iCurrentCameraStep;
			if(iCurrentStep >= pLevel->pCurrentCameraScript->iSteps)
				iCurrentStep = 0;
			pCameraT2 = &pLevel->pCurrentCameraScript->pCamera[iCurrentStep];

			if(iCurrentStep+1 < pLevel->pCurrentCameraScript->iSteps)
				iCurrentStep++;
			pCameraT3 = &pLevel->pCurrentCameraScript->pCamera[iCurrentStep];

			if(iCurrentStep+1 < pLevel->pCurrentCameraScript->iSteps)
				iCurrentStep++;
			pCameraT4 = &pLevel->pCurrentCameraScript->pCamera[iCurrentStep];

			ASCatmullRom(pCameraT1, pCameraT2, pCameraT3, pCameraT4, fDeltaT, _ASCamera);

			// Check if we have to go to the next camera step:
			if(fDeltaT >= 1.0f)
			{ // Go to the next animation step:
				lCameraTimer = g_lGameTimer;
				pLevel->Camera.iCurrentCameraStep++;
				fDeltaT -= 1.0f;
				if(pLevel->Camera.iCurrentCameraStep >= pLevel->pCurrentCameraScript->iSteps-1 && !bLoop)
				{
					pCamera->fPos2[X] = pCamera->fPos[X]+pPlayer->fWorldPos[X]+0.5f;
					pCamera->fPos2[Y] = pCamera->fPos[Y]+pPlayer->fWorldPos[Y]+0.5f;
					pCamera->fPos2[Z] = (pCamera->fPos[Z]-pPlayer->fWorldPos[Z]);
					bCameraAnimation = FALSE;
					lKeyTimer = g_lNow = g_lLastlooptime = GetTickCount();
					return 0;
				}
				else
				{
					if(pLevel->Camera.iCurrentCameraStep >= pLevel->pCurrentCameraScript->iSteps)
						pLevel->Camera.iCurrentCameraStep = 0;
				}
			}
		}
		if(ASKeyFirst[_ASConfig->iPauseKey[0]] && !pLevel->State.bLevelComplete)
		{
			lPauseTimer = g_lGameTimer;
			bPause = !bPause;
			if(bPause)
				lCameraPauseTimerT = g_lGameTimer-lCameraTimer;
		}
		if(!bLoop && !bPause)
		{
			// Stop the camera script?
			for(i = 0; i < 256; i++)
			{
				if(i == AS_SCREENSHOT_KEY)
					continue;
				if(i == _ASConfig->iPauseKey[0] && !pLevel->State.bLevelComplete)
					continue;
				if(ASKeyFirst[i])
				{
					pLevel->Camera.iCurrentCameraStep = pLevel->pCurrentCameraScript->iSteps-1;
					memcpy(_ASCamera, &pLevel->pCurrentCameraScript->pCamera[pLevel->Camera.iCurrentCameraStep], sizeof(AS_CAMERA));
					bCameraAnimation = FALSE;
					memset(&pCamera->fPos2, 0, sizeof(FLOAT3));
					lKeyTimer = g_lNow = g_lLastlooptime = GetTickCount();
					return 0;
				}
			}
		}
		return 1;
	}

	return 0;
} // end PlayCameraScript()

void SetCameraTranslation(BOOL bOnlyRot)
{ // begin SetCameraTranslation(()
	FLOAT3 fPoint, fPos[5], fRayDirection;
	FLOAT3 fPosT, fPos2;
	float fRotT, fRotCos, fWaterHeight;
	FIELD *pFieldT;
	int i;

	if(!bPlayerCameraView)
		SetPerspective(0.2f*_ASConfig->fVisibility);
	else
		SetPerspective(0.07f*_ASConfig->fVisibility);
	if(bCameraAnimation || _AS->GetModule() == MODULE_EDITOR)
	{
		glLoadIdentity();
		glRotatef(_ASCamera->fRot[X]-_ASCamera->fRot2[X], 1.0f, 0.0f, 0.0f);
		glRotatef(_ASCamera->fRot[Y]+180.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(_ASCamera->fRot[Z]+180.0f, 0.0f, 0.0f, 1.0f);
		if(!bOnlyRot)
			glTranslatef(_ASCamera->fPos[X], _ASCamera->fPos[Y], -_ASCamera->fPos[Z]);
		memcpy(_ASCamera->fWorldPos, _ASCamera->fPos, sizeof(FLOAT3));
		_ASCamera->fWorldPos[X] = -_ASCamera->fWorldPos[X];
		_ASCamera->fWorldPos[Y] = -_ASCamera->fWorldPos[Y];

	    // Check if the camera is under water:
		pFieldT = pLevel->ComputeWaterHeight(_ASCamera->fWorldPos[X], _ASCamera->fWorldPos[Y], &fWaterHeight);
		if(pFieldT && _ASCamera->fWorldPos[Z] >= fWaterHeight-0.1f)
		{ // Yes!:
			if(!bUnderWater)
			{
				WaterEntry();
				bUnderWater = TRUE; // Yes!:
			}
		}
		else
			bUnderWater = FALSE;
	}
	else
	{
		glLoadIdentity();
		if(pPlayer)
		{
			if(!bPlayerCameraView)
			{
				bFreeCamera = TRUE;

 				// Calculate the camera point position in the level:
				fRotCos = (float) cos(-_ASCamera->fRot[X]*PI/180);
				if(fRotCos > 0.0f)
					fRotCos = 1.0f-fRotCos;
				else
					fRotCos = 1.0f;

				if(!pPlayer->bFallIntoHole)
				{
					_ASCamera->fWorldPos[X] = (pPlayer->fWorldPos[X]-_ASCamera->fPos2[X])-fSin*_ASCamera->fPos[Z]*fRotCos;
					_ASCamera->fWorldPos[Y] = (pPlayer->fWorldPos[Y]-_ASCamera->fPos2[Y])-fCos*_ASCamera->fPos[Z]*fRotCos;
					fRotCos = (float) cos(-_ASCamera->fRot[X]*PI/180);
					_ASCamera->fWorldPos[Z] = pPlayer->fWorldPos[Z]+_ASCamera->fPos[Z]*fRotCos;

					if(!bFreeCamera)
					{	// Check the camera height:
						if(_ASCamera->fRot[X] > -5.0f)
							_ASCamera->fRot[X] = -5.0f;
						// Ray direction for the 'normal' test points:
						fRayDirection[X] = 0.0f;
						fRayDirection[Y] = 0.0f;
						fRayDirection[Z] = 1.0f;
						fPoint[X] = fPoint[Y] = fPoint[Z] = 0.0f;
						_ASCamera->fRot2[X] = 0.0f;

						// Calculate an camera rotation angle were the camera isn't in an level polygon:
						ACTOR CameraActor;
						AS_VECTOR3D vEllipsoid;
						float fHeight;
						CameraActor.vCollisionEllipsoid = 1.0f;
						CameraActor.fWorldPos[X] = _ASCamera->fWorldPos[X];
						CameraActor.fWorldPos[Y] = _ASCamera->fWorldPos[Y];
						CameraActor.fWorldPos[Z] = _ASCamera->fWorldPos[Z];

						vEllipsoid = CameraActor.vCollisionEllipsoid*CameraActor.fSize; // Setup collision ellipsoid
						for(i = 0; i < 6; i++)
						{
							pFieldT = pLevel->ComputeHeight(CameraActor.fWorldPos[X], CameraActor.fWorldPos[Y], &fHeight, i, vEllipsoid);
							if(pFieldT)
							{ // Now calculate the rotation angle itself:
								// Update the last check pos: (we only have to check if the position has changed)
								CameraActor.fWorldPos[Z] = fHeight+vEllipsoid.fZ;
								CameraActor.fWorldPos[Z] -= pPlayer->fWorldPos[Z];
								CameraActor.fWorldPos[Z] /= _ASCamera->fPos[Z];
								fRotT = (float) (_ASCamera->fRot[X]-(-acos(CameraActor.fWorldPos[Z])*180/PI));
								if(_ASCamera->fRot2[X] > fRotT)
									_ASCamera->fRot2[X] = fRotT;
							}
						}
					}
					
					// Check if the camera is under water:
					fRotCos = (float) cos(-(_ASCamera->fRot[X])*PI/180);
					pFieldT = pLevel->ComputeWaterHeight(_ASCamera->fWorldPos[X], _ASCamera->fWorldPos[Y], &fWaterHeight);
					if(pFieldT && pPlayer->fWorldPos[Z]+_ASCamera->fPos[Z]*fRotCos >= fWaterHeight+0.6f)
					{
						if(fRotCos > 0.0f)
							fRotCos = 1.0f-fRotCos;
						else
							fRotCos = 1.0f;
						fPos[0][X] = (pPlayer->fWorldPos[X]-_ASCamera->fPos2[X]+0.5f)-fSin*_ASCamera->fPos[Z]*fRotCos;
						fPos[0][Y] = (pPlayer->fWorldPos[Y]-_ASCamera->fPos2[Y]+0.5f)-fCos*_ASCamera->fPos[Z]*fRotCos;
						if(fPos[0][X] >= 0.0f && fPos[0][Y] >= 0.0f && fPos[0][X] <= pLevel->Header.fWholeWidth &&
						   fPos[0][Y] <= pLevel->Header.fWholeHeight)
						{
							if(!bUnderWater)
							{
								WaterEntry();
								bUnderWater = TRUE; // Yes!:
							}
						}
						else
							bUnderWater = FALSE;
					}
					else
						bUnderWater = FALSE;
				}

				// Set camera:
				if(!bOnlyRot)
					glTranslatef(0.0f, 0.0f, _ASCamera->fPos[Z]);
				glRotatef(_ASCamera->fRot[X]-_ASCamera->fRot2[X], 1.0f, 0.0f, 0.0f);
				glRotatef(_ASCamera->fRot[Y]+180.0f, 0.0f, 1.0f, 0.0f);
				glRotatef(_ASCamera->fRot[Z]+180.0f, 0.0f, 0.0f, 1.0f);
				if(!pPlayer->bFallIntoHole)
				{
					ASGetMd2Vertex(pBlibsModel, pPlayer->iAniStep, pPlayer->iNextAniStep, pPlayer->fAniInterpolation,
								   pPlayer->fWorldPos, 0.005f, -90.0f, pPlayer->fRot[Y]+90.0f, 0.0f, 310, &fPosT);
					fPosT[X] -= pPlayer->fWorldPos[X]+0.5f;
					fPosT[Y] -= pPlayer->fWorldPos[Y]+0.5f;
					fPosT[Z] = -fPosT[Z]-0.5f;
					fCameraPosT[X] = fPosT[X];
					fCameraPosT[Y] = fPosT[Y];
					fCameraPosT[Z] = fPosT[Z];
				}
				if(!bOnlyRot)
					glTranslatef(_ASCamera->fPos[X]-fCameraPosT[X],
								 _ASCamera->fPos[Y]-fCameraPosT[Y],
								 fCameraPosT[Z]);
			}
			else
			{ // Player view:
				glRotatef(_ASCamera->fRot[X], 1.0f, 0.0f, 0.0f);
				glRotatef(_ASCamera->fRot[Y], 0.0f, 1.0f, 0.0f);
				glRotatef(_ASCamera->fRot[Z], 0.0f, 0.0f, 1.0f);

				_ASCamera->fWorldPos[X] = fPos2[X] = pPlayer->fWorldPos[X];
				_ASCamera->fWorldPos[Y] = fPos2[Y] = pPlayer->fWorldPos[Y];
				_ASCamera->fWorldPos[Z] = fPos2[Z] = pPlayer->fWorldPos[Z]-0.2f;
				ASGetMd2Vertex(pBlibsModel, pPlayer->iAniStep, pPlayer->iNextAniStep, pPlayer->fAniInterpolation, fPos2, 0.005f,
							   -90.0f, pPlayer->fRot[Y]+90.0f, 0.0f, 43, &fPosT);
				fPosT[Z] -= 0.07f;
				if(!bOnlyRot)
					glTranslatef(-fPosT[X], -fPosT[Y], -fPosT[Z]);

				ASGetMd2Vertex(pBlibsModel, pPlayer->iAniStep, pPlayer->iNextAniStep, pPlayer->fAniInterpolation, fPos2, 0.005f,
							   -90.0f, pPlayer->fRot[Y]+90.0f, 0.0f, 19, &fPosT);
				// Check if the camera is under water:
				pFieldT = pLevel->ComputeWaterHeight(_ASCamera->fWorldPos[X], _ASCamera->fWorldPos[Y], &fWaterHeight);
				if(pFieldT && fPosT[Z] >= fWaterHeight)
				{ // Yes!:
					if(!bUnderWater)
					{
						WaterEntry();
						bUnderWater = TRUE; // Yes!:
					}
				}
				else
					bUnderWater = FALSE;
			}
		}
	}

	if(!bUnderWater)
	{
		for(i = 0; i < 3; i++)
		{
			fWaterScale[i] = fWaterLastScale[i] =
			fWaterToScale[i] = fWaterScaleVelocity[i] = 0.0f;
		}
		return;
	}
	if(bPause)
		return;
	// Create the under water effect:
	if(fWaterLastScale[0] > fWaterToScale[0])
	{
		fWaterScaleVelocity[0] -= (float) g_lDeltatime/100000;
		fWaterScale[0] += fWaterScaleVelocity[0];
		if(fWaterScale[0] <= fWaterToScale[0])
		{
			fWaterScaleVelocity[0] *= 0.6f;
			if(!(rand() % 2))
				fWaterToScale[0] = -(float) (rand() % 1000)/1000;
			else
				fWaterToScale[0] = (float) (rand() % 1000)/1000;
		}
	}
	else
	{
		fWaterScaleVelocity[0] += (float) g_lDeltatime/100000;
		fWaterScale[0] += fWaterScaleVelocity[0];
		if(fWaterScale[0] >= fWaterToScale[0])
		{
			fWaterScaleVelocity[0] *= 0.6f;
			if(!(rand() % 2))
				fWaterToScale[0] = -(float) (rand() % 1000)/1000;
			else
				fWaterToScale[0] = (float) (rand() % 1000)/1000;
		}
	}
	for(i = 1; i < 3; i++)
	{
		if(fWaterLastScale[i] > fWaterToScale[i])
		{
			fWaterScaleVelocity[i] -= (float) g_lDeltatime/10000;
			fWaterScale[i] += fWaterScaleVelocity[i];
			if(fWaterScale[i] <= fWaterToScale[i])
			{
				fWaterScaleVelocity[i] *= 0.8f;
				if(!(rand() % 2))
					fWaterToScale[i] = -(float) (rand() % 1000)/50;
				else
					fWaterToScale[i] = (float) (rand() % 1000)/50;
			}
		}
		else
		{
			fWaterScaleVelocity[i] += (float) g_lDeltatime/10000;
			fWaterScale[i] += fWaterScaleVelocity[i];
			if(fWaterScale[i] >= fWaterToScale[i])
			{
				fWaterScaleVelocity[i] *= 0.8f;
				if(!(rand() % 2))
					fWaterToScale[i] = -(float) (rand() % 1000)/50;
				else
					fWaterToScale[i] = (float) (rand() % 1000)/50;
			}
		}
	}
} // end SetCameraTranslation()

void SetPerspective(float fDistance)
{ // begin SetPerspective()
	float iView;
	RECT Rect;

	if(_AS->GetModule() == MODULE_EDITOR)
	{
		GetWindowRect(hWndEditorShow, &Rect);
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		gluPerspective(45.f+_ASCamera->fFOV+fWaterScale[0],
					   (GLfloat)(Rect.right-Rect.left+fWaterScale[1]+_ASCamera->fStretch[X])/
					   (GLfloat)(Rect.bottom-Rect.top+fWaterScale[2]+_ASCamera->fStretch[Y]),
					   0.1f, 100.0f*fDistance);
		glMatrixMode(GL_MODELVIEW);
	}
	else
	{
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		if(!bPlayerCameraView)
			iView = 45.0f;
		else
			iView = 90.0f;
		gluPerspective(iView+_ASCamera->fFOV+fWaterScale[0],
					   (GLfloat)(_ASConfig->iWindowWidth+fWaterScale[1]+_ASCamera->fStretch[X])/
					   (GLfloat)(_ASConfig->iWindowHeight+fWaterScale[2]+_ASCamera->fStretch[Y]),
					   0.1f, 100.0f*fDistance);
		glMatrixMode(GL_MODELVIEW);
	}
} // end SetPerspective()

void WaterEntry(void)
{ // begin WaterEntry()
	int i;

	if(!(rand() % 2))
	{
		fWaterToScale[0] = -10.0f;
		fWaterScaleVelocity[0] = 0.05f;
	}
	else
	{
		fWaterToScale[0] = 10.0f;
		fWaterScaleVelocity[0] = -0.05f;
	}
	for(i = 1; i < 3; i++)
	{
		if(!(rand() % 2))
		{
			fWaterToScale[i] = -100.0f;
			fWaterScaleVelocity[i] = 0.1f;
		}
		else
		{
			fWaterToScale[i] = 100.0f;
			fWaterScaleVelocity[i] = -0.1f;
		}
	}
} // end WaterEntry()

void InitDisplayActors(void)
{ // begin InitDisplayActors()
	float f;
	int i;

	for(i = 0; i < DISPLAY_ACTORS; i++)
		DisplayActor[i].fSize = 1.0f;

	for(i = 0; i < DISPLAY_ACTORS; i++)
	{
		DisplayActor[i].bActive = TRUE;
		DisplayActor[i].fWorldPos[X] = -7.0f;
		DisplayActor[i].fWorldPos[Y] = 5.0f-i;
		DisplayActor[i].fWorldPos[Z] = -15.0f;
		if(i > 2)
			DisplayActor[i].fWorldPos[Y] -= 2.0f;
	}
	f = DisplayActor[HEALTH_DISPLAY].fWorldPos[Y]; 
	DisplayActor[HEALTH_DISPLAY].fWorldPos[Y] = DisplayActor[LIFE_DISPLAY].fWorldPos[Y];
	DisplayActor[LIFE_DISPLAY].fWorldPos[Y] = f;

	f = DisplayActor[POINT_DISPLAY].fWorldPos[Y]; 
	DisplayActor[POINT_DISPLAY].fWorldPos[Y] = DisplayActor[PULL_DISPLAY].fWorldPos[Y];
	DisplayActor[PULL_DISPLAY].fWorldPos[Y] = f;

	f = DisplayActor[STRENGTH_DISPLAY].fWorldPos[Y]; 
	DisplayActor[STRENGTH_DISPLAY].fWorldPos[Y] = DisplayActor[THROW_DISPLAY].fWorldPos[Y];
	DisplayActor[THROW_DISPLAY].fWorldPos[Y] = f;

	DisplayActor[TIME_DISPLAY].fWorldPos[X] = 6.0f;
	DisplayActor[TIME_DISPLAY].fWorldPos[Y] = 5.0f;
	DisplayActor[STEPS_DISPLAY].fWorldPos[X] = 6.0f;
	DisplayActor[STEPS_DISPLAY].fWorldPos[Y] = 4.0f;

	DisplayActor[WING_DISPLAY].fWorldPos[X] = 6.0f;
	DisplayActor[WING_DISPLAY].fWorldPos[Y] = 0.0f;
	DisplayActor[SHIELD_DISPLAY].fWorldPos[X] = 6.0f;
	DisplayActor[SHIELD_DISPLAY].fWorldPos[Y] = -1.0f;
	DisplayActor[JUMP_DISPLAY].fWorldPos[X] = 6.0f;
	DisplayActor[JUMP_DISPLAY].fWorldPos[Y] = -2.0f;
	DisplayActor[DYNAMITE_DISPLAY].fWorldPos[X] = 6.0f;
	DisplayActor[DYNAMITE_DISPLAY].fWorldPos[Y] = -3.0f;
} // end InitDisplayActors()

void ShowSmallMessage(char *pbyText, long lShowTime)
{ // begin ShowSmallMessage()
	strcpy(bySmallMessageNewText, pbyText);
	lSmallMessageShowTime = lShowTime;
	bSmallMessageShowText = bSmallMessageChangeText = TRUE;
} // end ShowSmallMessage()

void DisplaySmallMessage(AS_WINDOW *pWindow)
{ // begin DisplaySmallMessage()
	if(fSmallMessageBlend <= 0.0f)
		return; // Show no message!
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glColor4f(1.0f, 1.0f, 1.0f, fSmallMessageBlend);
	pWindow->PrintAnimated(10, 450, bySmallMessageText, 0, fSmallMessageBlend*0.7f, fFontAni, 0);
} // end DisplaySmallMessage()

void CheckSmallMessage(void)
{ // begin CheckSmallMessage()
	if(bSmallMessageChangeText)
	{ // Change to the next text:
		fSmallMessageBlend -= (float) g_lDeltatime/300;
		if(fSmallMessageBlend <= 0.0f)
		{ // Show the new text:
			fSmallMessageBlend = 0.0f;
			lSmallMessageTimer = g_lNow;
			bSmallMessageChangeText = FALSE;
			strcpy(bySmallMessageText, bySmallMessageNewText);
		}
		return;
	}
	if(bSmallMessageShowText)
	{ // Blend in/show the text:
		if(fSmallMessageBlend != 1.0f)
		{
			fSmallMessageBlend += (float) g_lDeltatime/((float) (fSmallMessageBlend+0.01f)*4000);
			if(fSmallMessageBlend >= 1.0f)
				fSmallMessageBlend = 1.0f;
		}
		if(g_lNow-lSmallMessageTimer >= lSmallMessageShowTime)
		{ // Time out, disable the text:
			bSmallMessageShowText = FALSE;
		}
	}
	else
	{ // Blend out the text:
		fSmallMessageBlend -= (float) g_lDeltatime/5000;
		if(fSmallMessageBlend <= 0.0f)
		{
			fSmallMessageBlend = 0.0f;
		}
	}
} // end CheckSmallMessage()

void CheckDebugKeys(void)
{ // begin CheckDebugKeys()
	if(!_AS->bDebugMode || !ASKeys[56])
		return;

	if(ASKeyFirst[DIK_M])
		ReloadModels();
	if(ASKeyFirst[DIK_T])
		ReloadTextures();
	if(ASKeyFirst[DIK_S])
		ReloadSounds();
	if(ASKeyFirst[DIK_K])
		ReloadTexts();
} // end CheckDebugKeys()

void ReloadModels(void)
{ // begin ReloadModels()
	DestroyGameLists();
	DestroyGameObjects();
	InitGameObjects();
	CreateGameLists();
} // end ReloadModels()

void ReloadTextures(void)
{ // begin ReloadTextures()
	DestroyCreditsTextures();
	ASDestroyOpenGLTextures(GAME_TEXTURES, GameTexture);
	ASDestroyOpenGLTextures(GAME_MENU_TEXTURES, GameMenuTexture);
	ASDestroyOpenGLTextures(LOGOS_TEXTURES, LogosTexture);
	ASDestroyOpenGLTextures(ACTOR_TEXTURES, ActorTexture);
	ASDestroyOpenGLTextures(1, &PlayerSaveGame.Screenshot);
	DestroyBlurTexture();
	DestroyGameLists();
	if(pLevel)
	{
		if(_AS->GetModule() != MODULE_EDITOR)
			pLevel->DestroyTexturesOpenGL(*_AS->pWindow[GAME_WINDOW_ID].GethDC(), 
										  *_AS->pWindow[GAME_WINDOW_ID].GethRC());
		else
			pLevel->DestroyTexturesOpenGL(hDCEditorShow, hRCEditorShow);
		pLevel->ReloadTextures();
	}

	ASDestroyTextures(GAME_TEXTURES, GameTexture);
	LoadGameTextures();
	ActorDestroyTextures(TRUE);
	ActorLoadTextures(FALSE);

	if(pLevel)
	{
		if(_AS->GetModule() != MODULE_EDITOR)
			pLevel->GenTexturesOpenGL(*_AS->pWindow[GAME_WINDOW_ID].GethDC(), 
									  *_AS->pWindow[GAME_WINDOW_ID].GethRC());
		else
			pLevel->GenTexturesOpenGL(hDCEditorShow, hRCEditorShow);
	}
	ASGenOpenGLTextures(GAME_TEXTURES, GameTexture);
	ASGenOpenGLTextures(GAME_MENU_TEXTURES, GameMenuTexture);
	ASGenOpenGLTextures(LOGOS_TEXTURES, LogosTexture);
	ASGenOpenGLTextures(ACTOR_TEXTURES, ActorTexture);
	ASGenOpenGLTextures(1, &PlayerSaveGame.Screenshot);
	CreateBlurTexture();
} // end ReloadTextures()

void ReloadSounds(void)
{ // begin ReloadSounds()
	ASDestroyFmodSamples(GAME_SAMPLES, GameSample);
	LoadSamples();
} // end ReloadSounds()

void ReloadTexts(void)
{ // begin ReloadTexts()
	SetLanguage(_ASConfig->byLanguage);
	if(pLevel)
	{ // Reload the text scripts:
		pLevel->TextScriptManager.UpdateTextsFromFile();
	}
} // end ReloadTexts()

// This is used for making the flares. It only works on one part of the program.
// fP is the position. 1.0f is where the light is, -1.0f is the opposite side.
// fS is the size. 1.0f will fill the screen when looking right at the light.
// fR, fG, and fB are the colour of the flare.
void MakeFlare(float fP, float fS, float fR, float fG, float fB, float fBrightness,
			   FLOAT3 fSPos)
{ // begin MakeFlare()
	float fLoop;

	glBegin(GL_TRIANGLE_FAN);
		glColor4f(1.0f, 1.0f, 1.0f, fBrightness*0.5f);
		glVertex2f(fSPos[X]*fP, fSPos[Y]*fP);
		glColor4f(fR, fG, fB, 0.0f);
		for(fLoop = 0.0f; fLoop < 6.283185307f; fLoop += 6.283185307f/6.0f)
		{
			 glVertex2f((float) (fSPos[X]*fP+sin(fLoop)*fS*fBrightness),
						(float) (fSPos[Y]*fP+cos(fLoop)*fS*fBrightness));
			_AS->iTriangles++;
		}
	glEnd();
} // end MakeFlare()

// Make the actual flares:
void DrawFlares(AS_VECTOR3D vPos, float fRed, float fGreen, float fBlue, float fDensity, float fRot)
{ // begin DrawFlares();
    GLdouble dModelMatrix[16];
    GLdouble dProjMatrix[16];
    float fBrightness = 0.0f; // How bright the light is
    GLint iViewport[4];
    DOUBLE3 dSPos; // Where on the screen the light is
	FLOAT3 fSPos; // The same as float
    BOOL bBig = TRUE;
    float fDepth; // The depth in the framebuffer
    float fLoop;
    int iX, iY;

	if(!_ASConfig->bHightRenderQuality)
		return;
	// Load the matricies and viewport:
    glGetDoublev(GL_MODELVIEW_MATRIX, dModelMatrix);
    glGetDoublev(GL_PROJECTION_MATRIX, dProjMatrix);
    glGetIntegerv(GL_VIEWPORT, iViewport);
    
	// Find out where the light is on the screen.
	gluProject(vPos.fX, vPos.fY, vPos.fZ, dModelMatrix, dProjMatrix,
				iViewport, &dSPos[X], &dSPos[Y], &dSPos[Z]);

    // Go through some of the points near the light:
	for(iX = -4; iX <= 4; iX++)
        for(iY = -4; iY <= 4; iY++)
        {
            if(iViewport[2]/300.0f*iX+dSPos[X] < iViewport[2] &&
			   iViewport[2]/300.0f*iX+dSPos[X] >= 0 &&
			   iViewport[3]/300.0f*iY+dSPos[Y] < iViewport[3] &&
			   iViewport[3]/300.0f*iY+dSPos[Y] >= 0 )
            { // If the point is on the screen:
                 // Read the depth from the depth buffer:
				glReadPixels((int)(iViewport[2]/300.0f*iX+dSPos[X]),
							 (int)(iViewport[3]/300.0f*iY+dSPos[Y]),
							 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, &fDepth);
                // If the light is infront of what ever was in that spot, increase the brightness:
				if(fDepth >= dSPos[Z])
					fBrightness += 1.0f/81.0f; 
            }
        }
	if(dSPos[X] < iViewport[2] && dSPos[X] >= 0 &&
	   dSPos[Y] < iViewport[3] && dSPos[Y] >= 0 )
    { // If the light is on the screen:
        glReadPixels((int) (dSPos[X]),(int) (dSPos[Y]),
					  1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, &fDepth);
        if(fDepth < dSPos[Z] && dSPos[Z]-fDepth > 0.0002) // It is behind something
            fBrightness = 0.0f; // The light can't be seen
    }
    else // If the light isn't on the screen:
        fBrightness = 0.0f; // The light can't be seen    
	
	// Draw some stuff which has no influence on the flares:

     // Now that we know the brightness, convert:
	dSPos[X] = dSPos[X]/(float) iViewport[2]*2.0f-1.0f;
    // The position to a number between (-1,-1) and (1,1):
	dSPos[Y] = dSPos[Y]/(float) iViewport[2]*2.8f-1.0f;

	// And adjust the brightness so it is brighter at the centre of the screen:
	fBrightness *= (float) ((1.2f-ASFastSqrt((float) (dSPos[X]*dSPos[X]+dSPos[Y]*dSPos[Y])))*fBrightness*0.65f);
	if(fBrightness > fDensity)
		fBrightness = fDensity;
	if(fBrightness <= 0.0f)
		return;
    
	// Draw now the flares:
	glPushMatrix();
    glLoadIdentity();
    glMatrixMode(GL_PROJECTION);
	glEnable(GL_BLEND);
	glPushMatrix();
	glDepthMask(FALSE);

	// Forget about the view and projection. We will be drawing in 2D for the flares:
	glLoadIdentity();
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    glDisable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);

    fSPos[X] = (float) dSPos[X];
    fSPos[Y] = (float) dSPos[Y];
    fSPos[Z] = (float) dSPos[Z];

	glPushMatrix();
	glTranslatef(fSPos[X], fSPos[Y], 0.0f);
	glRotatef(fRot, 0.0f, 0.0f, 1.0f);
    
	 // Make a steak across the screen where the light is:
	glBegin(GL_TRIANGLE_FAN);
		glColor4f(0.9f*fRed, 1.0f*fGreen, 0.9f*fBlue, fBrightness*fDensity/2);
		glVertex2f(0.0f, 0.0f);
		glColor4f(1.0f*fRed, 1.0f*fGreen, 1.0f*fBlue, 0.0f);
		glVertex2f(2.5f*fBrightness, 0.0f);
		glVertex2f(0.0f, 0.1f*fBrightness);
		glVertex2f(-2.5f*fBrightness, 0.0f);
		glVertex2f(0.0f, -0.1f*fBrightness);
		glVertex2f(2.5f*fBrightness, 0.0f);
    glEnd();
	_AS->iTriangles += 4;

    // Draw the main flare:
	glBegin(GL_TRIANGLE_FAN);
		glColor4f(1.0f*fRed, 1.0f*fGreen, 1.0f*fBlue, fBrightness*fDensity/2);
		glVertex2f(0.0f, 0.0f);
		glColor4f(1.0f*fRed, 1.0f*fGreen, 0.5f*fBlue, 0.0f);
		// Make a star
		for(fLoop = 0.0f; fLoop < 6.283185307f; fLoop += 6.283185307f/64.0f)
		{
			glVertex2f((float) (sin(fLoop)*(bBig ? 2.0f*fBrightness : 1.0f*fBrightness)),
					   (float) (cos(fLoop)*(bBig ? 2.0f*fBrightness : 1.0f*fBrightness)));
			bBig = !bBig; // Make the next part of the star the opposite of this part
			_AS->iTriangles++;
		}                    
    glEnd();

    // Brighten the screen:
	glPopMatrix();
	glEnable(GL_BLEND);
	glColor4f(1.0f*fRed, 1.0f*fGreen, 1.0f*fBlue, fBrightness*fDensity/3);
    glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f);
		glVertex2f(fSPos[X]-2, fSPos[Y]-2);
		glTexCoord2f(1.0f, 0.0f);
		glVertex2f(fSPos[X]+2, fSPos[Y]-2);
		glTexCoord2f(1.0f, 1.0f);
		glVertex2f(fSPos[X]+2, fSPos[Y]+2);
		glTexCoord2f(0.0f, 1.0f);
		glVertex2f(fSPos[X]-2, fSPos[Y]+2);
    glEnd();
	_AS->iTriangles += 2;

    // Draw other flares:
    fBrightness *= fDensity;
	MakeFlare(0.7f, 0.2f, 1.0f*fRed, 1.0f*fGreen, 1.0f*fBlue, fBrightness, fSPos);
    MakeFlare(0.6f, 0.3f, 1.0f*fRed, 0.6f*fGreen, 0.6f*fBlue, fBrightness, fSPos);
    MakeFlare(0.4f, 0.4f, 1.0f*fRed, 1.0f*fGreen, 1.0f*fBlue, fBrightness, fSPos);
    MakeFlare(0.3f, 0.6f, 0.8f*fRed, 0.8f*fGreen, 0.6f*fBlue, fBrightness, fSPos);
    MakeFlare(0.2f, 0.5f, 1.0f*fRed, 1.0f*fGreen, 1.0f*fBlue, fBrightness, fSPos);
    MakeFlare(-0.1f, 0.4f, 0.6f*fRed, 1.0f*fGreen, 0.6f*fBlue, fBrightness, fSPos);
    MakeFlare(-0.2f, 0.3f, 1.0f*fRed, 1.0f*fGreen, 1.0f*fBlue, fBrightness, fSPos);
    MakeFlare(-0.4f, 0.2f, 0.6f*fRed, 0.8f*fGreen, 0.8f*fBlue, fBrightness, fSPos);
    MakeFlare(-0.6f, 0.4f, 1.0f*fRed, 1.0f*fGreen, 1.0f*fBlue, fBrightness, fSPos);
    MakeFlare(-0.7f, 0.5f, 0.6f*fRed, 0.6f*fGreen, 1.0f*fBlue, fBrightness, fSPos);
    MakeFlare(-0.8f, 0.6f, 1.0f*fRed, 1.0f*fGreen, 1.0f*fBlue, fBrightness, fSPos);
    MakeFlare(-0.9f, 0.5f, 0.8f*fRed, 0.6f*fGreen, 0.8f*fBlue, fBrightness, fSPos);
    MakeFlare(-1.2f, 0.3f, 1.0f*fRed, 1.0f*fGreen, 1.0f*fBlue, fBrightness, fSPos);

	ASEnableLighting();
    glEnable(GL_CULL_FACE);
    glEnable(GL_DEPTH_TEST);
    glPopMatrix(); 
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
	glDepthMask(TRUE);
} // end DrawFlares()
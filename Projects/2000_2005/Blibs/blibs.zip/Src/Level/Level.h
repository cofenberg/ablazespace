//-----------------------------------------------------------------------------
// File: Level.h
//-----------------------------------------------------------------------------

#ifndef __LEVEL_H__
#define __LEVEL_H__


// Definitions: ***************************************************************
#define LEVEL_VERSION 6		// The level version is responsible to save for crashes if the level is to old or not correct
							// And the users couldn't create with the editor levels for the
							// second demo!!
							// 1 = The first demo
							// 2 = The second demo
							// 3 = The final version
// Calculates the field matrix position of a world position:
#define COMPUTE_FIELD_POS(px, py, ix, iy)  { ix = (int) (px);\
										     iy = (int) (py); }

// Calculates the field ID of field matrix position:
#define GET_FIELD_ID(iX, iY, iID) iID = (iY)*pLevel->Header.iWidth+(iX);
#define GET_FIELD_POINTER(iX, iY, pFieldT) pFieldT = &pLevel->pField[(iY)*pLevel->Header.iWidth+(iX)];

// The six field sides:
enum
{
			   FACE_FLOOR,
			   FACE_TOP,
	FACE_LEFT,				FACE_RIGHT,
			   FACE_BOTTOM,
			   FACE_FRONT,
			   FACE_WATER,
};
#define FACE_ENVIRONMENT 6
enum POINT_TYPE { POINT_FIX, POINT_WATER };
enum WATER_TYPE { WATER_NONE, WATER_NORMAL, WATER_ACID, WATER_LAVA };
///////////////////////////////////////////////////////////////////////////////

// Classes: *******************************************************************
struct FIELD;
class LEVEL;
struct FIELD_SIDE;


// A decoration on a field:
typedef struct FIELD_DECORATION
{
	int iDecorationID; // The decoration number
	FLOAT3 fPos, // The world position of the decoration
		   fRot, // Decoration rotation
		   fSize; // Size of the decoration
	FLOAT4 fColor; // The decoration color
	BOOL bCullFront, bCullBack,
		 bOnScreen;
	int iSpeed; // Animation speed
	int iTexture; // The decoration model texture
	char byTextureFilename[256]; // The filename of the texture
	char byAnimation; // Decoration animation
	FLOAT3 fModelBoundingBox[2]; // The current model bounding box (model*size)

	// Animation:
	BOOL bAnimated; // Should the model be animated?
	float fModelInterpolation;
	long dwAniTime, dwAniDeltaTime;
	int iAniStep, iNextAniStep;

} FIELD_DECORATION;

typedef struct FIELD_SIDE_SURFACE
{
	FIELD_SIDE *pFieldSide; // Pointer to the field side using this surface information

	BOOL bSecondSurface; // Is this an second surface?
	int iSurface; // The surfaces of this side
	SURFACE *pSurface; // Pointer to the surface (for faster access)
	int iSurfaceRotation; // The rotation of each surface
	int iCurrentAniStep; // The animation step of each side
	long dwLastTime; // The last animation step change of each side
	long dwLastChangeTime; // Surface change timer

} FIELD_SIDE_SURFACE;

// A quad of an field side. Each of this field sides has 4 such quads:
typedef struct FIELD_SIDE_QUAD
{
	int iPoint[4]; // Indices to the 4 points of that quad
	AS_VECTOR3D vNormal[2], // Each quad consist of two triangles that there are two normals for each quad
		        // Precomputed right & up vectors:
		        vRightNormal[2],
		        vUpNormal[2];
	AS_PLANE Plane[2]; // The two planes

} FIELD_SIDE_QUAD;

// A field side: (each field has 6 sides)
typedef struct FIELD_SIDE
{
	FIELD *pField; // Pointer to the parent field
	int iSide; // The fields side

	BOOL bFaceActive, // Information about which field side is visible
		 bFaceAlwaysActive, // Information about which field side is always visible
		 bFace2Sides, // Should the face have 2 sides? (backface culling deactivated)
		 bFaceSwapSides, // Should the visible face side be swapped? (reverse backface culling)
		 bDisableWaterSide, // Should the water side be always deactivated on this side??
		 bWallSide, // Is this side a wall?? (impassable)
		 bInvisible; // Is this side invisible?
	FIELD_SIDE_QUAD SideQuad[4]; // The 4 quads of this field side
	FIELD_SIDE_SURFACE Surface[2]; // The surface of this field: (the second is used for multitexturing)
	FLOAT3 fMidPoint; // The point which lies in the middle of your field side (for depth sorting)
	long lDistanceToCamera; // The distance to camera for the polygon sort therefore this must not be the 'real' distance!!

} FIELD_SIDE;

// The field stuff:
typedef struct FIELD
{
	BOOL bActive, // Is this field active?
		 bNoBackfaceCulling, // Should the field have two faces?
		 bWall, // Is there a wall on this field
		 bAlwaysWall, // Is this always wall? (invisible walls possible...)
		 bWallHole, // Is this a hole with walls around it??
 		 bIndestructibleWall, // The wall couldn't be destroyed!
 		 bNoBridgePossible, // There couldn't be a bridge!
		 bActivateWater, // Deactivate the water on this field
		 bActivateWaterBubbles, // Deactivate the water bubbles on this field
		 bForceWaterBubbles; // The water bubbles are always seen. (also under ground)
	int iID; // The field ID
	int iXField, iYField; // The matrix field pos
	float fEditorRot; // For some rotations in the editor
	
	FIELD_SIDE Side[7]; // Six field faces, the sevens is the water surface

	float fBoundingBox[2][3]; // The fields bounding box min/max x/y/z
	BOOL bOnScreen,	// Is this field on the screen?
		 bUpdate; // Should the field be updated? (normales etc.)

	ACTOR *pActor; // The actor on this field:
	ACTOR *pBridgeActor; // The actor which is now used as a bridge
	ACTOR *pItem;	// Is a item on this field? (e.g. health)

	BOOL bSelected; // Is this field selected?
	
	WATER_TYPE WaterType; // The water type (normal water, acid, lava)
	int iCamera; // The camera script which is played on this field (-1 = no camera)
	BOOL bCameraAlways; // Should the camera always occur?

	BOOL bTextScript[5], // Should a text script be player?
		 bTextScriptAlways[5], // Should the text script always occur?
		 bTextScriptActionKey[5]; // Should the text script only be activated if the action key is pressed=
	TEXT_SCRIPT *pTextScript[5];

	BOOL bWaterChangeHeight,
		 bWaterChangePressed,
		 bWaterChangeNotPressed;
	float fWaterChangeHeightTo,
		  fWaterChangeSpeed,
  		  fWaterChangeNotHeightTo,
		  fWaterChangeNotSpeed;
	
	FIELD_DECORATION *pDecoration; // The decoration on this field

	// Beamer:
	float fBeamerPower; // The beamers power, only at 1.0 he could beam!
	int iBeamerRegenerationSpeed; // The beamer regeneration speed
	int iBeamerParticleSystemID; // The ID if the beamers particle system
	int iBeamerTarget; // The target field ID

} FIELD;

// A list of all visible field sides sorted by transparency and textures:
typedef class FIELD_SIDE_LIST
{
	public:
		FIELD_SIDE_SURFACE ***pSolid; // All solid surfaces
		FIELD_SIDE_SURFACE ***pTransparent; // All transparent surfaces

		void Create(LEVEL *);
		void Destroy(LEVEL *);
		void Build(LEVEL *);

} FIELD_SIDE_LIST;

// The quatrees are used to improve the field of view culling:
typedef class QUADTREE
{
	public:
		int iChildren; // The number of children
		QUADTREE *pChild; // The children
		QUADTREE *pParent; // The parent quadtree of this quadtree

		BOOL bInFOV; // Is this quadtree in the field of view?
		float fBoundingBox[2][3]; // The quadtrees bounding box min/max x/y/z

		int iStartX, iStartY, // The start cut position of the fields
			iFieldsX, iFieldsY, // The number of x/y fields
			iFields; // The number of fields in this quadtree

		FIELD **pField; // Pointer to the fields in this quadtree


		QUADTREE(void);
		~QUADTREE(void);
		void Build(void *);
		void Destroy(void);
		void SetNotInFOV(void);
		void CheckInFOV(void);
		void SetFieldsInFOV(void);
		void CheckFieldsInFOV(void);
		void GetBoundingBox(void *);
		void ShowBoundingBox(void);
		
} QUADTREE;

// General level information:
typedef struct LEVEL_HEADER
{
	// General informaiton:
	char byName[256]; // Level name (title)
	char byFilename[MAX_PATH]; // The levels filename ()
	char byAuthor[256]; // The creator of this level
	BOOL bSingle; // Is this level an single and none campaign level?
	BOOL bEndScreen; // Should the end screen appear? (only in campaign levels!!)

	// Keyword:
	BOOL bKeyword; // Has this level an keyword?
	char byKeyword[256]; // The keyword for this level
	
	// Music:
	BOOL bMusic; // Is there music in the level?
	char byMusicFile[256]; // The music file

	// Videos:
	BOOL bStartVideo, bEndVideo; // Should there be an video at the level start/end??
	char byStartVideoFilename[256], byEndVideoFilename[256]; // The filenames of the videos

	// Level size:
	int iWidth, iHeight, // The level size
		iFields, iPoints, // The number of fields and points
		iLevelPoints, // The points of one level
		iXPoints, iYPoints; // The number of x/y points in one level
	float fWholeWidth, fWholeHeight;// The whole size of the level

	// Box information: (for the editor)
	int iBoxSurface[7]; // The box surfaces for each side (6 sides + environment map)
	char byBoxSurfaceRot[7]; // The box surface rotation for each side (6 sides + environment map)

	// General information:
	int iTextures; // The number of textures used in this level
	int iSurfaces; // The number of surfaces used in this level
	int iCameraScripts; // The number of camera scripts

	// Object information:
	int iPointsObj, // The number of points in the level
		iMobmobs, // The number of Mobmobs in the level
		iX3; // The number of X3 in the level
	int iNormalBoxes, // The number of normal boxes in this level
		iRedBoxes, // The number of red boxes in this level
		iGreenBoxes, // The number of green boxes in this level
		iBlueBoxes; // The number of blue boxes in this level
   	int iForAllAnchors, // The number of for all anchors in this level
		iNormalAnchors, // The number of normal anchors in this level
		iRedAnchors, // The number of red anchors in this level
		iGreenAnchors, // The number of green anchors in this level
		iBlueAnchors; // The number of blue anchors in this level

	int iMaxActors; // The number of the maximum actors in that level

} LEVEL_HEADER;

// Information about the levels environment:
typedef struct LEVEL_ENVIRONMENT
{
	float fGravity; // The gravitation (9.81 for earth gravitation)
	FLOAT3 fColor; // The general level light

	// Sky cube:
	BOOL bSkyCube; // Is the sky cube active?
	FLOAT3 fSkyCubeColor, // The color of the sky cube
		   fSkyCubeSize; // The size
	int iSkyCubeSurface[6], // The surface for each side of the sky cube
		iSkyCubeSurfaceRotation[6], // The side surface rotation
		iSkyCubeSurfaceAniStep[6]; // The current animaton step of each side surface
	long dwSkyCubeSurfaceLastTime[6]; // The last animation step change time

	// Fog:
	BOOL bFog; // Is the fog activated?
	float fFogDensity; // The fog density
	FLOAT3 fFogColor; // The color of the fog

	// Shadows:
	FLOAT3 fMoveShadows; // Displace the shadows
	FLOAT3 fShadowsDensity_Size; // The density of the shadows and their size

	// Water:
	float fWaterHeight, // The height of the water (the middle of the amplitude)
		  fWaterActualHeight, // The current height
		  fWaterAmplitude, // The height amplitude
		  fWaterSpeed, // The water height change speed
		  fWaterVar; // Stores the angle for the sin function (for the smooth water change)
	
	float fWaterWaveAmplitude, // The height of the water waves
		  fWaterWaveSpeed, // The speed of the water waves
		  fWaterWaveSize[2]; // The size of the water waves

	FLOAT3 fWaterBubblesColor; // The color of the water bubbles
	float fWaterBubblesDensity, // The density of the water bubbles
		  fWaterBubblesSpeed, // The speed of the water bubbles
		  fWaterBubblesFrequency, // The frequency of the water bubbles
		  fWaterBubblesSize; // The size of the water bubbles

	BOOL bWaterChangeHeight;
	float fWaterChangeHeightTo,
		  fWaterChangeSpeed;
	long lLastWaterNormalUpdateTime;

} LEVEL_ENVIRONMENT;

// All level missions:
typedef class LEVEL_MISSIONS
{
	public:

		// Time:
		BOOL bTimeLimit, // Is there a time limit?
			 bShowTime, // Should the past time be shown??
			 bTimeOkta; // Should the Okta come if the time is out? (if not, the mission is failed!!)
		int iTimeLimit; // The time limit
		long lTimeLimitTime; // Stores the last checked time

		// Steps:
		BOOL bStepsLimit, // Is there a step limit?
			 bShowSteps, // Should the number of steps be shown?
			 bStepsOkta; // Should the Okta come if the steps are out? (if not, the mission is failed!!)
		int iStepsLimit; // The number of steps the player have

		BOOL bExit, // Should be player stand on an exit?
			 bAlcove, // Should be player stand on a alcove?
			 bCollectPoints, // Must the player collect points?
			 bCollectHealth,	// Must the player have an special number of health?
			 bKillMobmobs, // Should the player kill Mobmobs?
			 bKillX3; // Should the player kill X3?

		int iCollectPoints, // The number of points which must be collected
			iCollectHealth, // The total number of heath which the player must have
			iKillMobmobs, // The number of Mobmobs to be killed
			iKillX3; // The number of X3 to be killed
		
		// No free anchor:
		BOOL bNoFreeForAllAnchor, // There should be no free for all anchor
			 bNoFreeNormalAnchor, // There should be no free normal anchor
			 bNoFreeRedAnchor, // There should be no free red anchor
			 bNoFreeGreenAnchor, // There should be no free green anchor
			 bNoFreeBlueAnchor; // There should be no free blue anchor

		// No free box:
		BOOL bNoFreeNormalBox, // There should be no free normal box
			 bNoFreeRedBox, // There should be no free red box
			 bNoFreeGreenBox, // There should be no free green box
			 bNoFreeBlueBox; // There should be no free blue box

		// No box:
		BOOL bNoNormalBox, // There should be no normal box
			 bNoRedBox, // There should be no red box
			 bNoGreenBox, // There should be no green box
			 bNoBlueBox; // There should be no blue box

		
		void CheckTime(void);
		void CheckSteps(void);
		void TimeObj(int);
		void StepsObj(int);
	
} LEVEL_MISSIONS;

typedef struct LEVEL_CAMERA
{
	AS_CAMERA StartCamera; // The level start camera (the last camera position)

	// The possible camera modes:
	BOOL bFreeCamera, // Is it possible to select the 'bird view' camera?
		 bPlayerCamera, // Is it possible to select the player camera?
		 bStandartCamera; // Which camera should be selected at the level start
						  // (0 = 'bird view'  1 = player camera)



//////////////////	
// To delete: (no longer required)
	BOOL bStartCamera, // Should the level have an start camera
		 bEndCamera, // Should the level have an end camera
		 bEndCameraLoop; // Should the end camera be loop indefinitely?

	int iStartCamera, // The start camera ID
		  iEndCamera; // The end camera ID
////////////////////////




	int iCurrentCameraStep;

} LEVEL_CAMERA;

// Level missions state:
typedef class LEVEL_STATE
{
	public:

		BOOL bLevelComplete; // Is the level finished?
		BOOL bLevelJustComplete; // Is the level just finished?
								 // (the fist time, for checking some stuff...)

		BOOL bMissionExitComplete, // The player must be on an 'exit'-field to finish the level
			 bMissionAlcoveComplete; // The player must be on an 'alcove'-field to finish the level

		// Collect objects:
		BOOL bMissionCollectPointsComplete, // Is the collect points mission complete?
			 bMissionCollectHealthComplete, // Is the collect health mission complete?
			 bMissionKillMobmobsComplete, // Is the kill Mobmobs mission complete?
			 bMissionKillX3Complete; // Is the kill Mobmobs X3 complete?
		int iCollectedPoints; // The number of collected points
		int iKilledMobmobs; // The number of killed mobmobs 
		int iKilledX3; // The number of killed X3 

		// Anchors:
		BOOL bMissionNoFreeForAllAnchorComplete,  // Is the no free for all anchors mission complete?
			 bMissionNoFreeNormalAnchorComplete,  // Is the no free normal anchors mission complete?
			 bMissionNoFreeRedAnchorComplete,  // Is the no free red anchors mission complete?
			 bMissionNoFreeGreenAnchorComplete,  // Is the no free green anchors mission complete?
			 bMissionNoFreeBlueAnchorComplete;  // Is the no free blue anchors mission complete?
		int iUsedForAllAnchors, // The number of used for all anchors
			  iUsedNormalAnchors, // The number of used normal anchors
			  iUsedRedAnchors, // The number of used red anchors
			  iUsedGreenAnchors, // The number of used green anchors
			  iUsedBlueAnchors; // The number of used blue anchors

		// Free boxes:
		BOOL bMissionNoFreeNormalBoxesComplete,  // Is the no free normal boxes mission complete?
			 bMissionNoFreeRedBoxesComplete,  // Is the no free red boxes mission complete?
			 bMissionNoFreeGreenBoxesComplete,  // Is the no free green boxes mission complete?
			 bMissionNoFreeBlueBoxesComplete;  // Is the no free blue boxes mission complete?
		int iNoneFreeNormalBoxes, // The number of none free normal boxes
			  iNoneFreeRedBoxes, // The number of none free red boxes
			  iNoneFreeGreenBoxes, // The number of none free green boxes
			  iNoneFreeBlueBoxes; // The number of none free blue boxes

		// Destroyed boxes:
		BOOL bMissionNoNormalBoxesComplete,  // Is the no normal boxes mission complete?
			 bMissionNoRedBoxesComplete,  // Is the no red boxes mission complete?
			 bMissionNoGreenBoxesComplete,  // Is the no green boxes mission complete?
			 bMissionNoBlueBoxesComplete;  // Is the no blue boxes mission complete?
		int iDestroyedNormalBoxes, // The number of destroyed normal boxes
			  iDestroyedRedBoxes, // The number of destroyed red boxes
			  iDestroyedGreenBoxes, // The number of destroyed green boxes
			  iDestroyedBlueBoxes; // The number of destroyed blue boxes


		void Check(void);

} LEVEL_STATE;

// Some additional game information:
typedef struct LEVEL_ADDITIONAL_INFORMATION
{
	int iCampaignLevelID; // The levels campaign ID (level of camaign)
	BOOL bSingleLevel; // The level was started as single level

} LEVEL_ADDITIONAL_INFORMATION;

// The complete level information:
typedef class LEVEL
{
	public:
		int iVersion; // The level version
		LEVEL_ADDITIONAL_INFORMATION AdditionalInformation;

		// General level information:
		LEVEL_HEADER Header; // General information
		LEVEL_ENVIRONMENT Environment; // Environment information
		LEVEL_MISSIONS Missions; // Missions information
		LEVEL_CAMERA Camera; // Camera information
		LEVEL_STATE State; // Information about the level and the missions state
		
		// Actors:
		ACTOR **pActorList, // The list of all actors in that levels
			  **pVisibleActors; // A list of all visible actors

		BOOL bForceVisiblityUpdate;

		// Points:
		FLOAT3 *fPoint, // The level node points
			   *fNormal, // The normal for each point
			   *fWaterPoint, // The water points
			   *fWaterNormal; // The normal for each water point
		FLOAT4 *fColor, // The color value of each node point
			   *fSecondColor, // The color value of each node point of the second surface
			   *fWaterColor, // The second color of each water point
			   *fWaterSecondColor; // The color of each water point
		float *fWaterStandartZ, // The standart height each water point
			  *fWaterAmplitude; // The water wave amplitute for each water point
		int *iVisibleWaterPoints; // A list with the visible water points
		BOOL *bWaterPointVisible, // Is the water point visible?
			 *bPointSelected; // Is the grid point selected??

		float fLowestPoint, fMiddlePoint, fHighestPoint, // The min/middle/max height
		      fWaterWavesTimer; // For the water wave animation

		// Fields:
		FIELD *pField; // The fields the level consist of
		int iCurrentField; // The current field ID
		FIELD *pCurrentField; // Pointer to the current field
		FIELD **pInFOVFields, // Pointer to the fields which are in the FOV
			  **pBeamerFieldList, // A list of all beamer fields
			  **pDecorationFieldList, // A list of all decoration fields
			  **pTriggerFieldList; // A list of all trigger fields
		FIELD_SIDE_SURFACE **pAnimatedSurfacesList; // A list of all animated surfaces

		QUADTREE Quadtree; // The levels quadtree
		FIELD_SIDE_LIST FieldSideList; // A list of all visible field sides

		// Textures:
		AS_TEXTURE *pTexture; // The textures
		int iCurrentTexture; // The current texture ID
		AS_TEXTURE *pCurrentTexture; // Pointer to the current texture

		// Surfaces:
		SURFACE *pSurface; // The surfaces
		int iCurrentSurface; // The current surface ID
		SURFACE *pCurrentSurface; // Pointer to the current surface

		// Camera scipts:
		AS_CAMERA_SCRIPT *pCameraScript; // The camera scripts
		int iCurrentCameraScript; // The current camera script ID
		AS_CAMERA_SCRIPT *pCurrentCameraScript; // Pointer to the current camera script

		// Text scripts:
		TEXT_SCRIPT_MANAGER TextScriptManager;

		// Water bubbles:
		long dwLastWaterBubbleTime, // The time were the last water bubble was created
			 dwWaterBubbleSpeed; // When should the next bubble be created?

		// Functions:	
		LEVEL(void);
		~LEVEL(void);
		void SetLevelStandartValues(void);
		void SetStandartView(void);
		BOOL CheckIfCorrectPos(int, int);
		void GenTexturesOpenGL(HDC, HGLRC);
		void DestroyTexturesOpenGL(HDC, HGLRC);
		void ReloadTextures(void);
		HRESULT CreateSurface(void);
		HRESULT LoadSurface(char *);
		void DestroySurface(int);
		HRESULT LoadTexture(char *);
		void DestroyTexture(int);
		void Create(int, int);
		void Destroy(void);
		void SetFieldWall(int, int, BOOL, BOOL);
		void CalculateFacesMidPoint(BOOL);
		void DisableFieldUpdate(void);
		void CalculateFieldBoundingBoxes(void);
		void GetMinMiddleMax(void);
		void CalculateWaterPoints(BOOL);
		BOOL GetWall(float, float);
		void CreateWaterBubbles(void);
		void GetBeamerList(void);
		void GetDecorationList(void);
		void GetTriggerList(void);
		void GetAnimatedSurfacesList(void);
		void CheckFieldSurface(FIELD_SIDE_SURFACE *);
		void Check(BOOL);
		void TextScriptIsDeleted(TEXT_SCRIPT *, int);

		// LevelDraw:
		void InitLevelDraw(void);
		void DeInitLevelDraw(void);
		void Draw(BOOL);
		void DrawTransparent(void);
		void DrawWater(void);
		void DrawFieldSide(int, FIELD_SIDE *, TEXTURE_POS *);
		void DrawFieldSide(int, FIELD_SIDE *, TEXTURE_POS *, BOOL *, BOOL);
		void SetQuadBlend(FIELD_SIDE_QUAD *, BOOL *, BOOL);
		void SetupSideDraw(FIELD_SIDE_SURFACE *);
		void SetupSideDraw2(FIELD_SIDE_SURFACE *);
		void DrawSkyCube();
		void DrawSkyCubeSide(int, int, int, int, int, TEXTURE_POS *);
		void DrawOther(BOOL);

		// LevelNormals.cpp
		void CalculateFieldNormals(BOOL);
		void CalculateWaterNormals(BOOL);
		void CalculatePointNormals();

		// LevelMissions.cpp
		void InitMissions(void);
		void UpdateMissions(void);
		void CheckMissions(void);
		void ShowMissionState(AS_WINDOW *, float);
		
		// LevelActors.cpp
		ACTOR *FindFreeActor(void);
		int SortActors(void);
		void ResizeActorList(int);
		void DestroyActorList(void);
		void CheckIfActorsOnScreen(void);
		void SetupAllActorLights(void);
		void DrawActors(void);
		void CheckActors(BOOL);
		void DrawActorEffects(void);
		void DrawActorText(AS_WINDOW *);

		// LevelCollision.cpp
		FIELD *ComputeHeight(float, float, float *, char, BOOL);
		FIELD *ComputeHeight(float, float, float *, char, AS_VECTOR3D);
		FIELD *CheckCollision(AS_VECTOR3D, AS_VECTOR3D, AS_VECTOR3D);
		FIELD *ComputeWaterHeight(float, float, float *);
		BOOL ComputeWaterColor(float, float, FLOAT4 *);
		WATER_TYPE GetWaterType(float, float);

		// LevelLoadSave.cpp
		BOOL Load(char *);
		HRESULT Save(char *);

		// LevelOrganisation.cpp
		void UpdateVisibilityInformation(void);

		// LevelLightAndShadow.cpp
		void DrawShadowMaps(void);
		void PerformShadow(AS_DLIGHT, BOOL);
		void DrawLightMaps(void);
		void PerformLight(AS_DLIGHT, BOOL);

} LEVEL;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern AS_CAMERA LevelTempCamera; // Used to find out if the camera has been moved
extern char **pbySingleLevelsList;
extern int iSingleLevelsList;

// LevelActors.cpp
extern AS_TEXTURE ActorTexture[ACTOR_TEXTURES]; // The actor textures
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
// LevelTools.cpp
extern void CreateLevel(LEVEL **);
extern void DestroyLevel(LEVEL **);
extern BOOL GetLevelKeyword(char *, char *);
extern char GetLevelSingle(char *);
extern void GetLevelName(char *, char *);
extern void GetLevelFileName(char *, char *);
extern void StartLevel(char *, BOOL);
extern void StartCurrentLevel(void);
extern void StartLevelMusic(void);
extern void DestroyLevel(void);
extern void EnumerateSingleLevels(void);
extern void DestroySingleLevelList(void);

// LevelActors.cpp
extern void LoadRequiredActorTextues(HDC, HGLRC, BOOL);
extern void ActorGenTexturesOpenGL(HDC, HGLRC, BOOL);
extern void ActorDestroyTexturesOpenGL(HDC, HGLRC, BOOL);
extern void ActorLoadTextures(BOOL);
extern void ActorDestroyTextures(BOOL);
///////////////////////////////////////////////////////////////////////////////


#endif // __LEVEL_H__
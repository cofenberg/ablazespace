//-----------------------------------------------------------------------------
// File: Level.cpp
//-----------------------------------------------------------------------------

#include "..\AS\AS_Engine.h"
#include "..\ModuleHeaders.h"


// Definitions: ***************************************************************
enum { NEW_LEVEL_DIALOG, LEVEL_DIALOG };
enum { TAB_LEVEL_GENERAL, TAB_LEVEL_MISSIONS, TAB_LEVEL_OTHER };
#define LEVEL_TABS 3
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
char byLevelDialogMode;			// In which level dialog we are?
LEVEL *pLevelT; // Level backups
HWND hWndLevel,					// The level dialog handle
	 hWndLevelTab[LEVEL_TABS]; // The tab handles
int iMoveX, iMoveY,			// Move the level
	iCurrentLevelTab; // The current selected level tab
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
LRESULT CALLBACK LevelProc(HWND, UINT, WPARAM, LPARAM);
void NewLevelDialog(void);
void AdjustLevelDialog(void);
LRESULT CALLBACK LevelGeneralProc(HWND, UINT, WPARAM, LPARAM);
void UpdateLevelGeneral(void);
LRESULT CALLBACK LevelMissionsProc(HWND, UINT, WPARAM, LPARAM);
void UpdateLevelMissions(void);
LRESULT CALLBACK LevelOtherProc(HWND, UINT, WPARAM, LPARAM);
void UpdateLevelOther(void);
///////////////////////////////////////////////////////////////////////////////


// Functions: *****************************************************************
LRESULT CALLBACK LevelProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin LevelProc()
	HWND hWndTab;
	TC_ITEM tie; 
    char byTemp[256];
	int i, i2;
	
	switch(iMessage)
    {
        case WM_INITDIALOG:
			_AS->WriteLogMessage("Open level dialog");

			// Texts:
			if(byLevelDialogMode == NEW_LEVEL_DIALOG)
				SetWindowText(hWnd, AS_T(T_CreateANewLevel));
			else
				SetWindowText(hWnd, AS_T(T_AdjustLevel));

			SetDlgItemText(hWnd, ID_LEVEL_CANCEL, AS_T(T_Cancel));
			SetDlgItemText(hWnd, ID_LEVEL_OK, AS_T(T_Ok));

			// Tabs:
			iCurrentLevelTab = -1;
			// Setup editor tabs:
			hWndTab = GetDlgItem(hWnd, IDC_LEVEL_TAB);
			TabCtrl_DeleteAllItems(hWndTab);
			tie.mask = TCIF_TEXT;
			// General:
			tie.pszText	= AS_T(T_General);
			TabCtrl_InsertItem(hWndTab, TAB_LEVEL_GENERAL, &tie);
			if(hWndLevelTab[TAB_LEVEL_GENERAL])
				DestroyWindow(hWndLevelTab[TAB_LEVEL_GENERAL]);
			hWndLevelTab[TAB_LEVEL_GENERAL] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_LEVEL_GENERAL), hWndTab, (DLGPROC) LevelGeneralProc, WM_INITDIALOG);
			// Missions:
			tie.pszText	= AS_T(T_Missions);
			TabCtrl_InsertItem(hWndTab, TAB_LEVEL_MISSIONS, &tie);
			if(hWndLevelTab[TAB_LEVEL_MISSIONS])
				DestroyWindow(hWndLevelTab[TAB_LEVEL_MISSIONS]);
			hWndLevelTab[TAB_LEVEL_MISSIONS] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_LEVEL_MISSIONS), hWndTab, (DLGPROC) LevelMissionsProc, WM_INITDIALOG);
			// Other:
			tie.pszText	= AS_T(T_Other);
			TabCtrl_InsertItem(hWndTab, TAB_LEVEL_OTHER, &tie);
			if(hWndLevelTab[TAB_LEVEL_OTHER])
				DestroyWindow(hWndLevelTab[TAB_LEVEL_OTHER]);
			hWndLevelTab[TAB_LEVEL_OTHER] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_LEVEL_OTHER), hWndTab, (DLGPROC) LevelOtherProc, WM_INITDIALOG);

			TabCtrl_SetCurSel(GetDlgItem(hWnd, IDC_LEVEL_TAB), 0);
			SendMessage(hWnd, WM_NOTIFY, IDC_LEVEL_TAB, 0);
			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
			
			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
			BringWindowToTop(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_LEVEL_OK:
					if(byLevelDialogMode == LEVEL_DIALOG && 
					   (pLevelT->Header.iWidth != pLevel->Header.iWidth || pLevelT->Header.iHeight != pLevel->Header.iHeight))
					{ // Yes the level must be resize inform the user:
						sprintf(byTemp, "%s %dx%d)", AS_M(M_ChangeLevelSize), pLevel->Header.iWidth-1, pLevel->Header.iHeight-1);
						if(MessageBox(hWnd, byTemp, AS_T(T_Question), MB_YESNO | MB_ICONINFORMATION) == IDNO)
							break;
					}
					if(pPlayer)
						pPlayer->SetLevelTools();
					EndDialog(hWnd, TRUE);
					_AS->WriteLogMessage("Close level dialog(OK)");
                return TRUE;

                case ID_LEVEL_CANCEL:
					EndDialog(hWnd, FALSE);
					_AS->WriteLogMessage("Close level dialog(Cancel)");
                return TRUE;
            }
        break;

        case WM_NOTIFY: 
			switch(wParam)
			{
				case IDC_LEVEL_TAB:
					i = TabCtrl_GetCurSel(GetDlgItem(hWnd, IDC_LEVEL_TAB));
					iCurrentLevelTab = i;
					if(iCurrentLevelTab < 0)
						iCurrentLevelTab = 0;
					for(i2 = 0; i2 < LEVEL_TABS; i2++)
					{
						ShowWindow(hWndLevelTab[i2], SW_HIDE);
						UpdateWindow(hWndLevelTab[i2]);
					}
					TabCtrl_SetCurSel(GetDlgItem(hWnd, IDC_LEVEL_TAB), iCurrentLevelTab);
					ShowWindow(hWndLevelTab[iCurrentLevelTab], SW_SHOW);
					UpdateWindow(hWndLevelTab[iCurrentLevelTab]);
					UpdateWindow(hWnd);
					SetFocus(hWndLevelTab[iCurrentLevelTab]);
					SendMessage(hWndLevelTab[iCurrentLevelTab], WM_INITDIALOG, 0, 0);
				break;
			} 
		break; 

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_LEVEL_CANCEL, 0);
		break;
    }
    return FALSE;
} // end LevelProc()

void NewLevelDialog(void)
{ // begin NewLevelDialog()
	_AS->WriteLogMessage("Create a new level");
	pLevelT = new LEVEL;
	byLevelDialogMode = NEW_LEVEL_DIALOG;
	if(!DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_LEVEL), hWndEditor, (DLGPROC) LevelProc))
	{ // The user canceled the creation of a new level:
		_AS->WriteLogMessage("Create a new level is canceled");
		DestroyLevel(&pLevelT);
		return;
	}

	// OK, now destroy the old level and make the new to the current:
	// Now setup the level:
	pPlayer = NULL;
	memcpy(&pLevel->Header, &pLevelT->Header, sizeof(LEVEL_HEADER));
	memcpy(&pLevel->Environment, &pLevelT->Environment, sizeof(LEVEL_ENVIRONMENT));
	memcpy(&pLevel->Missions, &pLevelT->Missions, sizeof(LEVEL_MISSIONS));
	memcpy(&pLevel->Camera, &pLevelT->Camera, sizeof(LEVEL_CAMERA));
	memcpy(&pLevel->State, &pLevelT->State, sizeof(LEVEL_STATE));
	pLevelT->Create(pLevelT->Header.iWidth, pLevelT->Header.iHeight);
	pLevelT->ResizeActorList(pLevel->Header.iMaxActors);
	memcpy(&pLevelT->Header, &pLevel->Header, sizeof(LEVEL_ENVIRONMENT));
	memcpy(&pLevelT->Environment, &pLevel->Environment, sizeof(LEVEL_ENVIRONMENT));
	memcpy(&pLevelT->Missions, &pLevel->Missions, sizeof(LEVEL_MISSIONS));
	memcpy(&pLevelT->Camera, &pLevel->Camera, sizeof(LEVEL_CAMERA));
	memcpy(&pLevelT->State, &pLevel->State, sizeof(LEVEL_STATE));

	wglMakeCurrent(hDCEditorShow, hRCEditorShow);
	pLevel->DestroyTexturesOpenGL(hDCEditorShow, hRCEditorShow);
	DestroyLevel(&pLevel);
	pLevel = pLevelT;
	SetStandartPlayer();
	pLevel->CalculatePointNormals();
	pLevel->GetBeamerList();
	pLevel->GetDecorationList();
	pLevel->GetTriggerList();
	pLevel->GetAnimatedSurfacesList();


	pLevel->GenTexturesOpenGL(hDCEditorShow, hRCEditorShow);
	memset(&LevelTempCamera, 0, sizeof(AS_CAMERA));
} // end NewLevelDialog()

void AdjustLevelDialog(void)
{ // begin AdjustLevelDialog()
	byLevelDialogMode = LEVEL_DIALOG;
	pLevelT = new LEVEL;
	memcpy(pLevelT, pLevel, sizeof(LEVEL)); // Save the old level
	if(!DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_LEVEL), hWndEditor, (DLGPROC) LevelProc))
	{ // The user canceled the changes of the level:
		_AS->WriteLogMessage("Change level attributes is canceled");
		delete pLevelT;
		return;
	}
	
	if(pLevelT->Header.iMaxActors != pLevel->Header.iMaxActors)
		pLevel->ResizeActorList(pLevelT->Header.iMaxActors);

	// Now check if the level points must be updated:
	int i, i2, i3, x, y, iNewPoint, iOldPoint;
	FIELD *pNewFieldT, *pOldFieldT;
	FIELD_SIDE *pNewFieldSideT, *pOldFieldSideT;
	ACTOR *pActorT;

	if(pLevelT->Header.iWidth != pLevel->Header.iWidth ||
	   pLevelT->Header.iHeight != pLevel->Header.iHeight ||
	   iMoveX || iMoveY)
	{ // Yes, the level must be resized:
		LEVEL *pLevelTBackup = new LEVEL;

		// Update the level data:
		memcpy(pLevelTBackup, pLevelT, sizeof(LEVEL));

		// Destroy the temporally data:
		DestroyGameParticleSystems();
		pLevel->Quadtree.Destroy();
		pLevel->FieldSideList.Destroy(pLevel);
		SAFE_FREE(pLevel->fNormal);
		SAFE_FREE(pLevel->fWaterNormal);
		SAFE_FREE(pLevel->iVisibleWaterPoints);
		SAFE_FREE(pLevel->bPointSelected);
		SAFE_DELETE(pLevel->pInFOVFields);
		SAFE_FREE(pLevel->pBeamerFieldList);
		
		// Check if the actors are outside the resized level:
		for(i = 0; i < pLevelTBackup->Header.iMaxActors; i++)
		{
			pActorT = pLevelTBackup->pActorList[i];
			if(pActorT->iFieldPos[X]+iMoveX < 0 ||
			   pActorT->iFieldPos[X]+iMoveY < 0 ||
			   pActorT->iFieldPos[X]+iMoveX >= pLevelT->Header.iWidth-1 ||
			   pActorT->iFieldPos[Y]+iMoveY >= pLevelT->Header.iHeight-1)
				pActorT->bActive = FALSE; // Its outside!
		}

		// Create now a new level with the old information:
		pLevelT->fPoint = NULL; pLevelT->fWaterPoint = NULL;
		pLevelT->fColor = NULL; pLevelT->fSecondColor = NULL;
		pLevelT->fWaterColor = NULL; pLevelT->fWaterSecondColor = NULL;
		pLevelT->fWaterStandartZ = NULL; pLevelT->fWaterAmplitude = NULL;
		pLevelT->pField = NULL;
		pLevelT->Create(pLevelT->Header.iWidth, pLevelT->Header.iHeight);
		pLevelT->FieldSideList.Destroy(pLevelT);
		
		// Setup the data of our new level:
		memcpy(&pLevelT->Header, &pLevelTBackup->Header, sizeof(LEVEL_HEADER));
		pLevelT->Header.iFields = pLevelT->Header.iWidth*pLevelT->Header.iHeight;
		pLevelT->Header.iXPoints = pLevelT->Header.iWidth*2+1;
		pLevelT->Header.iYPoints = pLevelT->Header.iHeight*2+1;
		pLevelT->Header.iLevelPoints = pLevelT->Header.iXPoints*pLevelT->Header.iYPoints;
		pLevelT->Header.iPoints = pLevelT->Header.iLevelPoints*3;
		pLevelT->Header.fWholeWidth = (float) (pLevelT->Header.iWidth-1);
		pLevelT->Header.fWholeHeight = (float) (pLevelT->Header.iHeight-1);
		memcpy(&pLevelT->Environment, &pLevelTBackup->Environment, sizeof(LEVEL_ENVIRONMENT));
		memcpy(&pLevelT->Missions, &pLevelTBackup->Missions, sizeof(LEVEL_MISSIONS));
		memcpy(&pLevelT->Camera, &pLevelTBackup->Camera, sizeof(LEVEL_CAMERA));
		memcpy(&pLevelT->State, &pLevelTBackup->State, sizeof(LEVEL_STATE));
		SAFE_DELETE(pLevelTBackup);

		// Copy the old field infomation into the new level:
		for(y = 0; y < pLevel->Header.iHeight-1; y++)
		{
			if(y+iMoveY > pLevelT->Header.iHeight-1)
				break;
			if(y+iMoveY < 0)
				continue;
			for(x = 0; x < pLevel->Header.iWidth-1; x++)
			{
				if(x+iMoveX > pLevelT->Header.iWidth-1)
					break;
				if(x+iMoveX < 0)
					continue;
				pNewFieldT = &pLevelT->pField[(y+iMoveY)*pLevelT->Header.iWidth+(x+iMoveX)];
				pOldFieldT = &pLevel->pField[y*pLevel->Header.iWidth+x];
				pNewFieldT->bActive = pOldFieldT->bActive;
				pNewFieldT->bNoBackfaceCulling = pOldFieldT->bNoBackfaceCulling;
				pNewFieldT->bWall = pOldFieldT->bWall;
				pNewFieldT->bAlwaysWall = pOldFieldT->bAlwaysWall;
				pNewFieldT->bWallHole = pOldFieldT->bWallHole;
				pNewFieldT->bIndestructibleWall = pOldFieldT->bIndestructibleWall;
				pNewFieldT->bNoBridgePossible = pOldFieldT->bNoBridgePossible;
				pNewFieldT->bActivateWater = pOldFieldT->bActivateWater;
				pNewFieldT->bActivateWaterBubbles = pOldFieldT->bActivateWaterBubbles;
				pNewFieldT->bForceWaterBubbles = pOldFieldT->bForceWaterBubbles;

				// Setup field side information:
				for(i = 0; i < 7; i++)
				{
					pNewFieldSideT = &pNewFieldT->Side[i];
					pOldFieldSideT = &pOldFieldT->Side[i];
					pNewFieldSideT->bFaceActive = pOldFieldSideT->bFaceActive;
					pNewFieldSideT->bFaceAlwaysActive = pOldFieldSideT->bFaceAlwaysActive;
					pNewFieldSideT->bFace2Sides = pOldFieldSideT->bFace2Sides;
					pNewFieldSideT->bFaceSwapSides = pOldFieldSideT->bFaceSwapSides;
					pNewFieldSideT->bDisableWaterSide = pOldFieldSideT->bDisableWaterSide;
					pNewFieldSideT->bWallSide = pOldFieldSideT->bWallSide;
					pNewFieldSideT->bInvisible = pOldFieldSideT->bInvisible;
					memcpy(&pNewFieldSideT->Surface[0], &pOldFieldSideT->Surface[0], sizeof(FIELD_SIDE_SURFACE));
					memcpy(&pNewFieldSideT->Surface[1], &pOldFieldSideT->Surface[1], sizeof(FIELD_SIDE_SURFACE));
					
					// Setup the surface pointers back to the parent side:
					pNewFieldSideT->Surface[0].pFieldSide =
					pNewFieldSideT->Surface[1].pFieldSide = &pNewFieldT->Side[i];
				}
				
				// Copy the points: (some point's are copied more than 1 time... I think that's no problem..
				for(i2 = 0; i2 < 4; i2++)
				{
					for(i = 0; i < 7; i++)
					{
						for(i3 = 0; i3 < 4; i3++)
						{
							iNewPoint = pNewFieldT->Side[i].SideQuad[i2].iPoint[i3];
							iOldPoint = pOldFieldT->Side[i].SideQuad[i2].iPoint[i3];
							memcpy(&pLevelT->fPoint[iNewPoint], &pLevel->fPoint[iOldPoint], sizeof(FLOAT3));
							memcpy(&pLevelT->fColor[iNewPoint], &pLevel->fColor[iOldPoint], sizeof(FLOAT3));
							memcpy(&pLevelT->fSecondColor[iNewPoint], &pLevel->fSecondColor[iOldPoint], sizeof(FLOAT4));
							pLevelT->fPoint[iNewPoint][X] += iMoveX;
							pLevelT->fPoint[iNewPoint][Y] += iMoveY;
						}
					}
					for(i3 = 0; i3 < 4; i3++)
					{
						iNewPoint = pNewFieldT->Side[FACE_FLOOR].SideQuad[i2].iPoint[i3];
						iOldPoint = pOldFieldT->Side[FACE_FLOOR].SideQuad[i2].iPoint[i3];
						memcpy(&pLevelT->fWaterPoint[iNewPoint], &pLevel->fWaterPoint[iOldPoint], sizeof(FLOAT3));
						memcpy(&pLevelT->fWaterColor[iNewPoint], &pLevel->fWaterColor[iOldPoint], sizeof(FLOAT4));
						pLevelT->fWaterStandartZ[iNewPoint] = pLevel->fWaterStandartZ[iOldPoint];

						pLevelT->fWaterPoint[iNewPoint][X] += iMoveX;
						pLevelT->fWaterPoint[iNewPoint][Y] += iMoveY;
					}
				}

				pNewFieldT->WaterType = pOldFieldT->WaterType;
				pNewFieldT->iCamera = pOldFieldT->iCamera;
				pNewFieldT->bCameraAlways = pOldFieldT->bCameraAlways;
				for(i = 0; i < 5; i++)
				{
					pNewFieldT->bTextScript[i] = pOldFieldT->bTextScript[i];
					pNewFieldT->bTextScriptAlways[i] = pOldFieldT->bTextScriptAlways[i];
					pNewFieldT->bTextScriptActionKey[i] = pOldFieldT->bTextScriptActionKey[i];
					pNewFieldT->pTextScript[i] = pOldFieldT->pTextScript[i];
				}

				pNewFieldT->bWaterChangeHeight = pOldFieldT->bWaterChangeHeight;
				pNewFieldT->bWaterChangePressed = pOldFieldT->bWaterChangePressed;
				pNewFieldT->bWaterChangeNotPressed = pOldFieldT->bWaterChangeNotPressed;
				pNewFieldT->fWaterChangeHeightTo = pOldFieldT->fWaterChangeHeightTo;
				pNewFieldT->fWaterChangeSpeed = pOldFieldT->fWaterChangeSpeed;
				pNewFieldT->fWaterChangeNotHeightTo = pOldFieldT->fWaterChangeNotHeightTo;
				pNewFieldT->fWaterChangeNotSpeed = pOldFieldT->fWaterChangeNotSpeed;

				pNewFieldT->pDecoration = pOldFieldT->pDecoration;

				// Beamer:
				pNewFieldT->fBeamerPower = pOldFieldT->fBeamerPower;
				pNewFieldT->iBeamerRegenerationSpeed = pOldFieldT->iBeamerRegenerationSpeed;
				if(pOldFieldT->iBeamerTarget != -1)
				{ // Set the beamer target field:
					if(pLevel->pField[pOldFieldT->iBeamerTarget].iXField+iMoveX > 0 &&
					   pLevel->pField[pOldFieldT->iBeamerTarget].iYField+iMoveY > 0 &&
					   pLevel->pField[pOldFieldT->iBeamerTarget].iXField+iMoveX < pLevelT->Header.iWidth-1 &&
					   pLevel->pField[pOldFieldT->iBeamerTarget].iYField+iMoveY < pLevelT->Header.iHeight-1)
						GET_FIELD_ID(pLevel->pField[pOldFieldT->iBeamerTarget].iXField+iMoveX,
									 pLevel->pField[pOldFieldT->iBeamerTarget].iYField+iMoveY, pNewFieldT->iBeamerTarget);
				}
			}
		}	
		
		// Disable the last column & row of your new level:
		for(x = 0; x < pLevelT->Header.iWidth; x++)
			pLevelT->pField[(pLevelT->Header.iHeight-1)*pLevelT->Header.iWidth+x].bActive = FALSE;
		for(y = 0; y < pLevelT->Header.iHeight; y++)
			pLevelT->pField[y*pLevelT->Header.iWidth+pLevelT->Header.iWidth-1].bActive = FALSE;

		// Destroy the old stuff:
		SAFE_FREE(pLevel->fPoint);
		SAFE_FREE(pLevel->fWaterPoint);
		SAFE_FREE(pLevel->fColor);
		SAFE_FREE(pLevel->fSecondColor);
		SAFE_FREE(pLevel->fWaterColor);
		SAFE_FREE(pLevel->fWaterSecondColor);
		SAFE_FREE(pLevel->fWaterStandartZ);
		SAFE_FREE(pLevel->fWaterAmplitude);
		SAFE_FREE(pLevel->pField);
		SAFE_DELETE(pLevel);
		
		// Set now the standart level pointer to the new level:
		pLevel = pLevelT;

		// Update the actors:
		for(i = 0; i < pLevel->Header.iMaxActors; i++)
		{
			pActorT = pLevel->pActorList[i];
			if(!pActorT->bActive)
				continue;
			pActorT->iFieldPos[X] += iMoveX;
			pActorT->iFieldPos[Y] += iMoveY;
			GET_FIELD_ID(pActorT->iFieldPos[X], pActorT->iFieldPos[Y], pActorT->iFieldID);
			if(pActorT->bBridge)
			{
				pLevel->pField[pActorT->iFieldID].pBridgeActor = pActorT;
				pLevel->pField[pActorT->iFieldID].bActive = FALSE;
			}
			else
			{
				switch(pActorT->Type)
				{
					case AT_HEALTH_ITEM:
					case AT_HEALTH_INCREASE_ITEM:
					case AT_LIFE_ITEM:
					case AT_PULL_ITEM:
					case AT_CHEST_ITEM:
					case AT_STRENGTH_ITEM:
					case AT_WEAPON_ITEM:
					case AT_COIN_ITEM:
					case AT_GHOST_ITEM:
					case AT_TIME_ITEM:
					case AT_STEP_ITEM:
					case AT_SPEED_ITEM:
					case AT_WING_ITEM:
					case AT_SHIELD_ITEM:
					case AT_JUMP_ITEM:
					case AT_AIR_ITEM:
						pLevel->pField[pActorT->iFieldID].pItem = pActorT;
					break;

					default:
						pLevel->pField[pActorT->iFieldID].pActor = pActorT;
					break;
				}
			}
		}

		// Update all walls:
		for(i = 0, y = 0; y < pLevel->Header.iHeight; y++)
			for(x = 0; x < pLevel->Header.iWidth; x++, i++)
			{
				if(pLevelT->pField[i].bWallHole)
					pLevelT->SetFieldWall(pLevelT->pField[i].iXField, pLevelT->pField[i].iYField, TRUE, FALSE);
				if(!pLevel->pField[i].bActive)
					continue;
				if(pLevel->pField[i].pActor)
				{
					pLevel->pField[i].pActor = pLevel->pField[i].pActor;
					pLevelT->SetFieldWall(x, y, FALSE, FALSE);
				}
				else
					pLevelT->SetFieldWall(x, y, pLevel->pField[i].bWall, FALSE);
			}
		InitGameParticleSystems();
		pLevel->FieldSideList.Create(pLevel);
		pLevel->UpdateVisibilityInformation();
		pLevel->CalculateFieldNormals(TRUE);
		pLevel->CalculateWaterNormals(FALSE);
		pLevel->CalculatePointNormals();
		pLevel->CalculateFacesMidPoint(TRUE);
		pLevel->CalculateFieldBoundingBoxes();
		pLevel->CalculateWaterPoints(FALSE);
		pLevel->GetBeamerList();
		pLevel->GetMinMiddleMax();
	}
	else
	{
		memcpy(pLevel, pLevelT, sizeof(LEVEL));
		SAFE_DELETE(pLevelT);
	}

	if(!wglMakeCurrent(hDCEditorShow, hRCEditorShow))
		return;
} // end AdjustLevelDialog()	

LRESULT CALLBACK LevelGeneralProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin LevelGeneralProc()
	char byTemp[256], *pbyTemp;
	int iVisibility, i;

	switch(iMessage)
    {
        case WM_INITDIALOG:
				_AS->WriteLogMessage("Open level general dialog");

				// Icons:				
				SendDlgItemMessage(hWnd, IDC_LEVEL_FIND_FILENAME, BM_SETIMAGE, (WPARAM) IMAGE_ICON,
								   (LPARAM) LoadImage(_AS->GetInstance(), MAKEINTRESOURCE(IDI_AS_OPEN), IMAGE_ICON, 12, 12, LR_DEFAULTCOLOR));
				SendDlgItemMessage(hWnd, IDC_LEVEL_FIND_MUSIC_FILE, BM_SETIMAGE, (WPARAM) IMAGE_ICON,
								   (LPARAM) LoadImage(_AS->GetInstance(), MAKEINTRESOURCE(IDI_AS_OPEN), IMAGE_ICON, 12, 12, LR_DEFAULTCOLOR));								   
				// Texts:
				SetDlgItemText(hWnd, IDC_LEVEL_KEYWORD_CHECKED, AS_T(T_Keyword));
				SetDlgItemText(hWnd, IDC_LEVEL_MUSIC, AS_T(T_Music));
				SetDlgItemText(hWnd, IDC_LEVEL_FILE_T, AS_T(T_File));
				SetDlgItemText(hWnd, IDC_LEVEL_NAME_T, AS_T(T_Name));
				SetDlgItemText(hWnd, IDC_LEVEL_AUTHOR_T, AS_T(T_Author));
				SetDlgItemText(hWnd, IDC_LEVEL_MUSIC_T, AS_T(T_Music));
				SetDlgItemText(hWnd, IDC_LEVEL_WIDTH_T, AS_T(T_Width));
				SetDlgItemText(hWnd, IDC_LEVEL_HEIGHT_T, AS_T(T_Height));
				SetDlgItemText(hWnd, IDC_LEVEL_FREE_CAMERA, AS_T(T_FreeCamera));
				SetDlgItemText(hWnd, IDC_LEVEL_PLAYER_CAMERA, AS_T(T_PlayerCamera));
				SetDlgItemText(hWnd, IDC_LEVEL_STANDART_CAMERA, AS_T(T_StandartCamera));
				SetDlgItemText(hWnd, IDC_LEVEL_MOVE_X_T, AS_T(T_MoveX));
				SetDlgItemText(hWnd, IDC_LEVEL_MOVE_Y_T, AS_T(T_MoveY));
				SetDlgItemText(hWnd, IDC_LEVEL_END_SCREEN, AS_T(T_EndScreen));
				SetDlgItemText(hWnd, IDC_LEVEL_MAX_ACTORS, AS_T(T_MaxActors));
				if(byLevelDialogMode == NEW_LEVEL_DIALOG)
					iVisibility = SW_HIDE;
				else
					iVisibility = SW_SHOW;
				ShowWindow(GetDlgItem(hWnd, IDC_LEVEL_MOVE_X), iVisibility);
				ShowWindow(GetDlgItem(hWnd, IDC_LEVEL_MOVE_X_T), iVisibility);
				ShowWindow(GetDlgItem(hWnd, IDC_LEVEL_MOVE_Y), iVisibility);
				ShowWindow(GetDlgItem(hWnd, IDC_LEVEL_MOVE_Y_T), iVisibility);
				//
				// Level:
				SetDlgItemText(hWnd, IDC_LEVEL_FILENAME, pLevelT->Header.byFilename);
				SetDlgItemText(hWnd, IDC_LEVEL_NAME, pLevelT->Header.byName);
				SetDlgItemText(hWnd, IDC_LEVEL_AUTHOR, pLevelT->Header.byAuthor);
				SetDlgItemText(hWnd, IDC_LEVEL_MUSIC_FILE, pLevelT->Header.byMusicFile);
				sprintf(byTemp, "%d", pLevelT->Header.iWidth-1);
				SetDlgItemText(hWnd, IDC_LEVEL_WIDTH, byTemp);
				sprintf(byTemp, "%d", pLevelT->Header.iHeight-1);
				SetDlgItemText(hWnd, IDC_LEVEL_HEIGHT, byTemp);
				sprintf(byTemp, "%s", pLevelT->Header.byKeyword);
				SetDlgItemText(hWnd, IDC_LEVEL_KEYWORD, byTemp);				
				SetDlgItemText(hWnd, IDC_LEVEL_MOVE_X, "0");
				SetDlgItemText(hWnd, IDC_LEVEL_MOVE_Y, "0");
				sprintf(byTemp, "%d", pLevelT->Header.iMaxActors);
				SetDlgItemText(hWnd, IDC_LEVEL_MAX_ACTORS_NUMBER, byTemp);
				
				iMoveX = iMoveY = 0;
				UpdateLevelGeneral();
				
				ShowWindow(hWnd, _AS->GetCmdShow());
				UpdateWindow(hWnd);
				BringWindowToTop(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_LEVEL_FILENAME: GetDlgItemText(hWnd, IDC_LEVEL_FILENAME, pLevelT->Header.byFilename, 256); break;

				case IDC_LEVEL_SINGLE:
				    pLevelT->Header.bSingle = SendDlgItemMessage(hWnd, IDC_LEVEL_SINGLE, BM_GETCHECK, 0, 0L);
					UpdateLevelGeneral();
				break;

				case IDC_LEVEL_END_SCREEN: pLevelT->Header.bEndScreen = SendDlgItemMessage(hWnd, IDC_LEVEL_END_SCREEN, BM_GETCHECK, 0, 0L); break;

				case IDC_LEVEL_FIND_FILENAME:
					sprintf(byTemp, "%s%s", _AS->byProgramPath, _AS->bySingleLevelsDirectory);
					pbyTemp = ASGetFileName(hWnd, "Get level file name", LEV_FILE, 0, TRUE, byTemp, NULL);
					if(!pbyTemp)
						break;
					if(strlen(pbyTemp) > strlen(_AS->byProgramPath))
						strcpy(pLevelT->Header.byFilename, &pbyTemp[strlen(_AS->byProgramPath)]);
					SetDlgItemText(hWnd, IDC_LEVEL_FILENAME, pLevelT->Header.byFilename);
				break;

				case IDC_LEVEL_NAME: GetDlgItemText(hWnd, IDC_LEVEL_NAME, pLevelT->Header.byName, 256); break;

				case IDC_LEVEL_AUTHOR: GetDlgItemText(hWnd, IDC_LEVEL_AUTHOR, pLevelT->Header.byAuthor, 256); break;

				case IDC_LEVEL_MUSIC:
				    pLevelT->Header.bMusic = SendDlgItemMessage(hWnd, IDC_LEVEL_MUSIC, BM_GETCHECK, 0, 0L);
					UpdateLevelGeneral();
				break;

				case IDC_LEVEL_MUSIC_FILE:
					GetDlgItemText(hWnd, IDC_LEVEL_MUSIC_FILE, pLevelT->Header.byMusicFile, 256);
					UpdateLevelGeneral();
				break;

				case IDC_LEVEL_FIND_MUSIC_FILE:
					sprintf(byTemp, "%s%s", _AS->byProgramPath, _AS->byMusicDirectory);
					pbyTemp = ASGetFileName(hWnd, "Load music", MUSIC_FILES, 0, TRUE, byTemp, NULL);
					if(!pbyTemp)
						break;
					if(strlen(pbyTemp) > strlen(_AS->byProgramPath))
						strcpy(pLevelT->Header.byMusicFile, &pbyTemp[strlen(_AS->byProgramPath)]);
					SetDlgItemText(hWnd, IDC_LEVEL_MUSIC_FILE, pLevelT->Header.byMusicFile);
				break;
				
				case IDC_LEVEL_KEYWORD_CHECKED:
				    pLevelT->Header.bKeyword = SendDlgItemMessage(hWnd, IDC_LEVEL_KEYWORD_CHECKED, BM_GETCHECK, 0, 0L);
					UpdateLevelGeneral();
				break;

				case IDC_LEVEL_KEYWORD: GetDlgItemText(hWnd, IDC_LEVEL_KEYWORD, pLevelT->Header.byKeyword, 256); break;
				
				case IDC_LEVEL_WIDTH:
					GetDlgItemText(hWnd, IDC_LEVEL_WIDTH, byTemp, 256);
					pLevelT->Header.iWidth = atoi(byTemp)+1;
					if(pLevelT->Header.iWidth > _AS->iMaxLevelXSize+1)
						pLevelT->Header.iWidth = _AS->iMaxLevelXSize+1;
				break;

				case IDC_LEVEL_HEIGHT:
					GetDlgItemText(hWnd, IDC_LEVEL_HEIGHT, byTemp, 256);
					pLevelT->Header.iHeight = atoi(byTemp)+1;
					if(pLevelT->Header.iHeight > _AS->iMaxLevelYSize+1)
						pLevelT->Header.iHeight = _AS->iMaxLevelYSize+1;
				break;

				case IDC_LEVEL_MOVE_X:
					GetDlgItemText(hWnd, IDC_LEVEL_MOVE_X, byTemp, 256);
					iMoveX = atoi(byTemp);
				break;

				case IDC_LEVEL_MOVE_Y:
					GetDlgItemText(hWnd, IDC_LEVEL_MOVE_Y, byTemp, 256);
					iMoveY = atoi(byTemp);
				break;

				case IDC_LEVEL_MAX_ACTORS_NUMBER:
					GetDlgItemText(hWnd, IDC_LEVEL_MAX_ACTORS_NUMBER, byTemp, 256);
					i = atoi(byTemp);
					if(i < 1)
						break;
					pLevelT->Header.iMaxActors = i;
				break;

			// Camera:
				case IDC_LEVEL_FREE_CAMERA:
				    pLevelT->Camera.bFreeCamera = SendDlgItemMessage(hWnd, IDC_LEVEL_FREE_CAMERA, BM_GETCHECK, 0, 0L);
					if(!pLevelT->Camera.bFreeCamera && !pLevelT->Camera.bPlayerCamera)
					{
						pLevelT->Camera.bFreeCamera = TRUE;
						SendDlgItemMessage(hWnd, IDC_LEVEL_FREE_CAMERA, BM_SETCHECK, TRUE, 0L);
					}
					UpdateLevelGeneral();
				break;

				case IDC_LEVEL_PLAYER_CAMERA:
				    pLevelT->Camera.bPlayerCamera = SendDlgItemMessage(hWnd, IDC_LEVEL_PLAYER_CAMERA, BM_GETCHECK, 0, 0L);
					if(!pLevelT->Camera.bFreeCamera && !pLevelT->Camera.bPlayerCamera)
					{
						pLevelT->Camera.bPlayerCamera = TRUE;
						SendDlgItemMessage(hWnd, IDC_LEVEL_PLAYER_CAMERA, BM_SETCHECK, TRUE, 0L);
					}
				break;

				case IDC_LEVEL_STANDART_CAMERA: pLevelT->Camera.bStandartCamera = SendDlgItemMessage(hWnd, IDC_LEVEL_STANDART_CAMERA, BM_GETCHECK, 0, 0L); break;
			}
        break;
    }
    return FALSE;
} // end LevelGeneralProc()

void UpdateLevelGeneral(void)
{ // begin UpdateLevelGeneral()
	HWND hWnd = hWndLevelTab[TAB_LEVEL_GENERAL];

	// Music:
    SendDlgItemMessage(hWnd, IDC_LEVEL_MUSIC, BM_SETCHECK, pLevelT->Header.bMusic, 0L);
	EnableWindow(GetDlgItem(hWnd, IDC_LEVEL_MUSIC_FILE), pLevelT->Header.bMusic);
	EnableWindow(GetDlgItem(hWnd, IDC_LEVEL_FIND_MUSIC_FILE), pLevelT->Header.bMusic);
	// Keyword:
    SendDlgItemMessage(hWnd, IDC_LEVEL_KEYWORD_CHECKED, BM_SETCHECK, pLevelT->Header.bKeyword, 0L);
	EnableWindow(GetDlgItem(hWnd, IDC_LEVEL_KEYWORD), pLevelT->Header.bKeyword);
    SendDlgItemMessage(hWnd, IDC_LEVEL_FREE_CAMERA, BM_SETCHECK, pLevelT->Camera.bFreeCamera, 0L);
    SendDlgItemMessage(hWnd, IDC_LEVEL_PLAYER_CAMERA, BM_SETCHECK, pLevelT->Camera.bPlayerCamera, 0L);
    SendDlgItemMessage(hWnd, IDC_LEVEL_STANDART_CAMERA, BM_SETCHECK, pLevelT->Camera.bStandartCamera, 0L);
	EnableWindow(GetDlgItem(hWnd, IDC_LEVEL_STANDART_CAMERA), pLevelT->Camera.bFreeCamera);
    SendDlgItemMessage(hWnd, IDC_LEVEL_SINGLE, BM_SETCHECK, pLevelT->Header.bSingle, 0L);
	if(pLevelT->Header.bSingle)
	{
		EnableWindow(GetDlgItem(hWnd, IDC_LEVEL_END_SCREEN), FALSE);
		pLevelT->Header.bEndScreen = TRUE;
	}
	else
		EnableWindow(GetDlgItem(hWnd, IDC_LEVEL_END_SCREEN), TRUE);
    SendDlgItemMessage(hWnd, IDC_LEVEL_END_SCREEN, BM_SETCHECK, pLevelT->Header.bEndScreen, 0L);
} // end UpdateLevelGeneral()

LRESULT CALLBACK LevelMissionsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin LevelMissionsProc()
	char byTemp[256];
	int i;
	
	switch(iMessage)
    {
        case WM_INITDIALOG:
			pLevelT->UpdateMissions();
			_AS->WriteLogMessage("Open level missions dialog");
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_TIME_LIMIT, AS_T(T_TimeLimit));
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_SHOW_TIME, AS_T(T_ShowTime));
			sprintf(byTemp, "%d", pLevelT->Missions.iTimeLimit);
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_TIME_LIMIT_TIME, byTemp);
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_SHOW_STEPS, AS_T(T_ShowSteps));
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_STEP_LIMIT, AS_T(T_StepsLimit));
			sprintf(byTemp, "%d", pLevelT->Missions.iStepsLimit);
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_STEP_LIMIT_LIMIT, byTemp);
			sprintf(byTemp, "%d", pLevelT->Missions.iCollectPoints);
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_COLLECT_POINTS, byTemp);
			sprintf(byTemp, "%d", pLevelT->Missions.iCollectHealth);
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_COLLECT_HEALTH, byTemp);
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_EXIT, AS_T(T_Exit));
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_ALCOVE, AS_T(T_Alcove));
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_COLLECT_POINTS_CHECKED, AS_T(T_CollectPoints));
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_COLLECT_HEALTH_CHECKED, AS_T(T_CollectHealth));
			sprintf(byTemp, "(%d)", pLevelT->Header.iPointsObj);
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_POINTS, byTemp);
			sprintf(byTemp, "(%d)", pLevelT->Header.iMobmobs);
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_KILL_MOBMOBS_T, byTemp);
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_KILL_MOBMOBS_CHECKED, AS_T(T_KillMobmobs));
			sprintf(byTemp, "%d", pLevelT->Missions.iKillMobmobs);
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_KILL_MOBMOBS, byTemp);
			sprintf(byTemp, "(%d)", pLevelT->Header.iX3);
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_KILL_X3_T, byTemp);
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_KILL_X3_CHECKED, AS_T(T_KillX3));
			sprintf(byTemp, "%d", pLevelT->Missions.iKillX3);
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_KILL_X3, byTemp);
			// No free anchor:
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_ANCHOR, AS_T(T_NoFreeAnchor));
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_FOR_ALL_ANCHOR, AS_T(T_ForAll));
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_RED_ANCHOR, AS_T(T_Red));
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_GREEN_ANCHOR, AS_T(T_Green));
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_BLUE_ANCHOR, AS_T(T_Blue));
			// No free box:
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_BOX, AS_T(T_NoFreeBox));
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_BOX, AS_T(T_Normal));
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_RED_BOX, AS_T(T_Red));
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_GREEN_BOX, AS_T(T_Green));
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_BLUE_BOX, AS_T(T_Blue));
			// No box:
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_BOX, AS_T(T_NoBox));
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_NORMAL_BOX, AS_T(T_Normal));
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_RED_BOX, AS_T(T_Red));
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_GREEN_BOX, AS_T(T_Green));
			SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_BLUE_BOX, AS_T(T_Blue));

			UpdateLevelMissions();
			
			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
			BringWindowToTop(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
			    case IDC_LEVEL_MISSIONS_SHOW_TIME:
					pLevelT->Missions.bShowTime = SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_SHOW_TIME, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_TIME_LIMIT:
					pLevelT->Missions.bTimeLimit = SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_TIME_LIMIT, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_TIME_LIMIT_TIME:
					GetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_TIME_LIMIT_TIME, byTemp, 256);
					i = atoi(byTemp)		;
					if(i < 0)
					{
						i = 0;
						SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_TIME_LIMIT_TIME, "0");
					}
					pLevelT->Missions.iTimeLimit = i;
				break;

			    case IDC_LEVEL_MISSIONS_TIME_OKTA:
					pLevelT->Missions.bTimeOkta = SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_TIME_OKTA, BM_GETCHECK, 0, 0L);
				break;

			    case IDC_LEVEL_MISSIONS_SHOW_STEPS:
					pLevelT->Missions.bShowSteps = SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_SHOW_STEPS, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_STEP_LIMIT:
					pLevelT->Missions.bStepsLimit = SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_STEP_LIMIT, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_STEP_LIMIT_LIMIT:
					GetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_STEP_LIMIT_LIMIT, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
					{
						i = 0;
						SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_STEP_LIMIT_LIMIT, "0");
					}
					pLevelT->Missions.iStepsLimit = i;
				break;

			    case IDC_LEVEL_MISSIONS_STEPS_OKTA:
					pLevelT->Missions.bStepsOkta = SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_STEPS_OKTA, BM_GETCHECK, 0, 0L);
				break;

			    case IDC_LEVEL_MISSIONS_EXIT:
					pLevelT->Missions.bExit = SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_EXIT, BM_GETCHECK, 0, 0L);
					pLevelT->Missions.bAlcove = FALSE;
					UpdateLevelMissions();
				break;
			    
				case IDC_LEVEL_MISSIONS_ALCOVE:
					pLevelT->Missions.bAlcove = SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_ALCOVE, BM_GETCHECK, 0, 0L);
					pLevelT->Missions.bExit = FALSE;
					UpdateLevelMissions();
				break;

				case IDC_LEVEL_MISSIONS_COLLECT_POINTS_CHECKED:
					pLevelT->Missions.bCollectPoints = SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_COLLECT_POINTS_CHECKED, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

				case IDC_LEVEL_MISSIONS_COLLECT_POINTS:
					GetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_COLLECT_POINTS, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
					{
						i = 0;
						SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_COLLECT_POINTS, "0");
					}
					pLevelT->Missions.iCollectPoints = i;
				break;

				case IDC_LEVEL_MISSIONS_COLLECT_HEALTH_CHECKED:
					pLevelT->Missions.bCollectHealth = SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_COLLECT_HEALTH_CHECKED, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

				case IDC_LEVEL_MISSIONS_COLLECT_HEALTH:
					GetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_COLLECT_HEALTH, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
					{
						i = 0;
						SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_COLLECT_HEALTH, "0");
					}
					pLevelT->Missions.iCollectHealth = i;
				break;

				case IDC_LEVEL_MISSIONS_KILL_MOBMOBS_CHECKED:
					pLevelT->Missions.bKillMobmobs = SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_KILL_MOBMOBS_CHECKED, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

				case IDC_LEVEL_MISSIONS_KILL_MOBMOBS:
					GetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_KILL_MOBMOBS, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
					{
						i = 0;
						SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_KILL_MOBMOBS, "0");
					}
					pLevelT->Missions.iKillMobmobs = i;
				break;

				case IDC_LEVEL_MISSIONS_KILL_X3_CHECKED:
					pLevelT->Missions.bKillX3 = SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_KILL_X3_CHECKED, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

				case IDC_LEVEL_MISSIONS_KILL_X3:
					GetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_KILL_X3, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
					{
						i = 0;
						SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_KILL_X3, "0");
					}
					pLevelT->Missions.iKillX3 = i;
				break;

			// No free anchor:
			    case IDC_LEVEL_MISSIONS_NO_FREE_FOR_ALL_ANCHOR:
					pLevelT->Missions.bNoFreeForAllAnchor = SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_FOR_ALL_ANCHOR, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_ANCHOR:
					pLevelT->Missions.bNoFreeNormalAnchor = SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_ANCHOR, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_NO_FREE_RED_ANCHOR:
					pLevelT->Missions.bNoFreeRedAnchor = SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_RED_ANCHOR, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_NO_FREE_GREEN_ANCHOR:
					pLevelT->Missions.bNoFreeGreenAnchor = SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_GREEN_ANCHOR, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_NO_FREE_BLUE_ANCHOR:
					pLevelT->Missions.bNoFreeBlueAnchor = SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_BLUE_ANCHOR, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			// No free box:
			    case IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_BOX:
					pLevelT->Missions.bNoFreeNormalBox = SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_BOX, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_NO_FREE_RED_BOX:
					pLevelT->Missions.bNoFreeRedBox = SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_RED_BOX, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_NO_FREE_GREEN_BOX:
					pLevelT->Missions.bNoFreeGreenBox = SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_GREEN_BOX, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_NO_FREE_BLUE_BOX:
					pLevelT->Missions.bNoFreeBlueBox = SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_BLUE_BOX, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			// No box:
			    case IDC_LEVEL_MISSIONS_NO_NORMAL_BOX:
					pLevelT->Missions.bNoNormalBox = SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_NO_NORMAL_BOX, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_NO_RED_BOX:
					pLevelT->Missions.bNoRedBox = SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_NO_RED_BOX, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_NO_GREEN_BOX:
					pLevelT->Missions.bNoGreenBox = SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_NO_GREEN_BOX, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_NO_BLUE_BOX:
					pLevelT->Missions.bNoBlueBox = SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_NO_BLUE_BOX, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;
			}
        break;
    }
    return FALSE;
} // end LevelMissionsProc()

void UpdateLevelMissions(void)
{ // begin UpdateLevelMissions()
	HWND hWnd = hWndLevelTab[TAB_LEVEL_MISSIONS];

	// Time limit:
	SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_SHOW_TIME, BM_SETCHECK, pLevelT->Missions.bShowTime, 0L);
	EnableWindow(GetDlgItem(hWnd, IDC_LEVEL_MISSIONS_SHOW_TIME), !pLevelT->Missions.bTimeLimit);
	SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_TIME_LIMIT, BM_SETCHECK, pLevelT->Missions.bTimeLimit, 0L);
	EnableWindow(GetDlgItem(hWnd, IDC_LEVEL_MISSIONS_TIME_LIMIT_TIME), pLevelT->Missions.bTimeLimit);
	SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_TIME_OKTA, BM_SETCHECK, pLevelT->Missions.bTimeOkta, 0L);
	EnableWindow(GetDlgItem(hWnd, IDC_LEVEL_MISSIONS_TIME_OKTA), pLevelT->Missions.bTimeLimit);
	// Step limit:
	SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_SHOW_STEPS, BM_SETCHECK, pLevelT->Missions.bShowSteps, 0L);
	EnableWindow(GetDlgItem(hWnd, IDC_LEVEL_MISSIONS_SHOW_STEPS), !pLevelT->Missions.bStepsLimit);
	SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_STEP_LIMIT, BM_SETCHECK, pLevelT->Missions.bStepsLimit, 0L);
	EnableWindow(GetDlgItem(hWnd, IDC_LEVEL_MISSIONS_STEP_LIMIT_LIMIT), pLevelT->Missions.bStepsLimit);
	SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_STEPS_OKTA, BM_SETCHECK, pLevelT->Missions.bStepsOkta, 0L);
	EnableWindow(GetDlgItem(hWnd, IDC_LEVEL_MISSIONS_STEPS_OKTA), pLevelT->Missions.bStepsLimit);
	SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_EXIT, BM_SETCHECK, pLevelT->Missions.bExit, 0L);
	SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_ALCOVE, BM_SETCHECK, pLevelT->Missions.bAlcove, 0L);
	SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_COLLECT_POINTS_CHECKED, BM_SETCHECK, pLevelT->Missions.bCollectPoints, 0L);
	SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_COLLECT_HEALTH_CHECKED, BM_SETCHECK, pLevelT->Missions.bCollectHealth, 0L);
	EnableWindow(GetDlgItem(hWnd, IDC_LEVEL_MISSIONS_COLLECT_POINTS), pLevelT->Missions.bCollectPoints);
	EnableWindow(GetDlgItem(hWnd, IDC_LEVEL_MISSIONS_COLLECT_HEALTH), pLevelT->Missions.bCollectHealth);
	if(pLevelT->Missions.bNoNormalBox && pLevelT->Missions.bNoRedBox && pLevelT->Missions.bNoGreenBox && pLevelT->Missions.bNoBlueBox)
	{
		EnableWindow(GetDlgItem(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_FOR_ALL_ANCHOR), FALSE);
		pLevelT->Missions.bNoFreeForAllAnchor = FALSE;
	}
	else
		EnableWindow(GetDlgItem(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_FOR_ALL_ANCHOR), TRUE);
	EnableWindow(GetDlgItem(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_ANCHOR), !pLevelT->Missions.bNoNormalBox);
	EnableWindow(GetDlgItem(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_BOX), !pLevelT->Missions.bNoNormalBox);
	pLevelT->Missions.bNoFreeNormalAnchor = !pLevelT->Missions.bNoNormalBox;
	pLevelT->Missions.bNoFreeNormalBox = !pLevelT->Missions.bNoNormalBox;
	EnableWindow(GetDlgItem(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_RED_ANCHOR), !pLevelT->Missions.bNoRedBox);
	EnableWindow(GetDlgItem(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_RED_BOX), !pLevelT->Missions.bNoRedBox);
	pLevelT->Missions.bNoFreeRedAnchor = !pLevelT->Missions.bNoRedBox;
	pLevelT->Missions.bNoFreeRedBox = !pLevelT->Missions.bNoRedBox;
	EnableWindow(GetDlgItem(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_GREEN_ANCHOR), !pLevelT->Missions.bNoGreenBox);
	EnableWindow(GetDlgItem(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_GREEN_BOX), !pLevelT->Missions.bNoGreenBox);
	pLevelT->Missions.bNoFreeGreenAnchor = !pLevelT->Missions.bNoGreenBox;
	pLevelT->Missions.bNoFreeGreenBox = !pLevelT->Missions.bNoGreenBox;
	EnableWindow(GetDlgItem(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_BLUE_ANCHOR), !pLevelT->Missions.bNoBlueBox);
	EnableWindow(GetDlgItem(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_BLUE_BOX), !pLevelT->Missions.bNoBlueBox);
	pLevelT->Missions.bNoFreeBlueAnchor = !pLevelT->Missions.bNoBlueBox;
	pLevelT->Missions.bNoFreeBlueBox = !pLevelT->Missions.bNoBlueBox;
	// No free anchor:
	SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_FOR_ALL_ANCHOR, BM_SETCHECK, pLevelT->Missions.bNoFreeForAllAnchor, 0L);
	SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_ANCHOR, BM_SETCHECK, pLevelT->Missions.bNoFreeNormalAnchor, 0L);
	SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_RED_ANCHOR, BM_SETCHECK, pLevelT->Missions.bNoFreeRedAnchor, 0L);
	SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_GREEN_ANCHOR, BM_SETCHECK, pLevelT->Missions.bNoFreeGreenAnchor, 0L);
	SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_BLUE_ANCHOR, BM_SETCHECK, pLevelT->Missions.bNoFreeBlueAnchor, 0L);
	// No free box:
	SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_BOX, BM_SETCHECK, pLevelT->Missions.bNoFreeNormalBox, 0L);
	SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_RED_BOX, BM_SETCHECK, pLevelT->Missions.bNoFreeRedBox, 0L);
	SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_GREEN_BOX, BM_SETCHECK, pLevelT->Missions.bNoFreeGreenBox, 0L);
	SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_BLUE_BOX, BM_SETCHECK, pLevelT->Missions.bNoFreeBlueBox, 0L);
	// No box:
	SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_NO_NORMAL_BOX, BM_SETCHECK, pLevelT->Missions.bNoNormalBox, 0L);
	SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_NO_RED_BOX, BM_SETCHECK, pLevelT->Missions.bNoRedBox, 0L);
	SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_NO_GREEN_BOX, BM_SETCHECK, pLevelT->Missions.bNoGreenBox, 0L);
	SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_NO_BLUE_BOX, BM_SETCHECK, pLevelT->Missions.bNoBlueBox, 0L);
	SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_KILL_MOBMOBS_CHECKED, BM_SETCHECK, pLevelT->Missions.bKillMobmobs, 0L);
	EnableWindow(GetDlgItem(hWnd, IDC_LEVEL_MISSIONS_KILL_MOBMOBS), pLevelT->Missions.bKillMobmobs);
	SendDlgItemMessage(hWnd, IDC_LEVEL_MISSIONS_KILL_X3_CHECKED, BM_SETCHECK, pLevelT->Missions.bKillX3, 0L);
	EnableWindow(GetDlgItem(hWnd, IDC_LEVEL_MISSIONS_KILL_X3), pLevelT->Missions.bKillX3);
} // end UpdateLevelMissions()LRESULT CALLBACK LevelMissionsProc(HWND, UINT, WPARAM, LPARAM);

LRESULT CALLBACK LevelOtherProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin LevelOtherProc()
	char byTemp[256], *pbyTemp;
	
	switch(iMessage)
    {
        case WM_INITDIALOG:
			_AS->WriteLogMessage("Open level other dialog");

			// Icons:				
			SendDlgItemMessage(hWnd, IDC_LEVEL_FIND_VIDEO_START_FILE, BM_SETIMAGE, (WPARAM) IMAGE_ICON,
							   (LPARAM) LoadImage(_AS->GetInstance(), MAKEINTRESOURCE(IDI_AS_OPEN), IMAGE_ICON, 12, 12, LR_DEFAULTCOLOR));
			SendDlgItemMessage(hWnd, IDC_LEVEL_FIND_VIDEO_END_FILE, BM_SETIMAGE, (WPARAM) IMAGE_ICON,
							   (LPARAM) LoadImage(_AS->GetInstance(), MAKEINTRESOURCE(IDI_AS_OPEN), IMAGE_ICON, 12, 12, LR_DEFAULTCOLOR));								   

			SetDlgItemText(hWnd, IDC_LEVEL_CAMERA, AS_T(T_Camera));
			UpdateLevelOther();
			
			// Camera:
			SetDlgItemText(hWnd, IDC_LEVEL_VIDEO, AS_T(T_Video));
			SetDlgItemText(hWnd, IDC_LEVEL_VIDEO_START, AS_T(T_Start));
			SetDlgItemText(hWnd, IDC_LEVEL_VIDEO_END, AS_T(T_End));
			SetDlgItemText(hWnd, IDC_LEVEL_VIDEO_START_FILE, pLevelT->Header.byStartVideoFilename);
			SetDlgItemText(hWnd, IDC_LEVEL_VIDEO_END_FILE, pLevelT->Header.byEndVideoFilename);

			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
			BringWindowToTop(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				// Video:
				case IDC_LEVEL_VIDEO_START:
				    pLevelT->Header.bStartVideo = SendDlgItemMessage(hWnd, IDC_LEVEL_VIDEO_START, BM_GETCHECK, 0, 0L);
					UpdateLevelOther();
				break;

				case IDC_LEVEL_VIDEO_START_FILE:
					GetDlgItemText(hWnd, IDC_LEVEL_VIDEO_START_FILE, pLevelT->Header.byStartVideoFilename, 256);
				break;

				case IDC_LEVEL_FIND_VIDEO_START_FILE:
					sprintf(byTemp, "%s%s", _AS->byProgramPath, _AS->byVideosDirectory);
					pbyTemp = ASGetFileName(hWnd, "Get video file name", VIDEO_FILES, 0, TRUE, byTemp, NULL);
					if(!pbyTemp)
						break;
					if(strlen(pbyTemp) > strlen(_AS->byProgramPath))
						strcpy(pLevelT->Header.byStartVideoFilename, &pbyTemp[strlen(_AS->byProgramPath)]);
					SetDlgItemText(hWnd, IDC_LEVEL_VIDEO_START_FILE, pLevelT->Header.byStartVideoFilename);
				break;

				case IDC_LEVEL_VIDEO_END_FILE:
					GetDlgItemText(hWnd, IDC_LEVEL_VIDEO_END_FILE, pLevelT->Header.byEndVideoFilename, 256);
				break;
								
				case IDC_LEVEL_VIDEO_END:
				    pLevelT->Header.bEndVideo = SendDlgItemMessage(hWnd, IDC_LEVEL_VIDEO_END, BM_GETCHECK, 0, 0L);
					UpdateLevelOther();
				break;

				case IDC_LEVEL_FIND_VIDEO_END_FILE:
					sprintf(byTemp, "%s%s", _AS->byProgramPath, _AS->byVideosDirectory);
					pbyTemp = ASGetFileName(hWnd, "Get video file name", VIDEO_FILES, 0, TRUE, byTemp, NULL);
					if(!pbyTemp)
						break;
					if(strlen(pbyTemp) > strlen(_AS->byProgramPath))
						strcpy(pLevelT->Header.byEndVideoFilename, &pbyTemp[strlen(_AS->byProgramPath)]);
					SetDlgItemText(hWnd, IDC_LEVEL_VIDEO_END_FILE, pLevelT->Header.byEndVideoFilename);
				break;
			}
        break;
    }
    return FALSE;
} // end LevelOtherProc()

void UpdateLevelOther(void)
{ // begin UpdateLevelOther()
	HWND hWnd = hWndLevelTab[TAB_LEVEL_OTHER];

	// Videos:
    SendDlgItemMessage(hWnd, IDC_LEVEL_VIDEO_START, BM_SETCHECK, pLevelT->Header.bStartVideo, 0L);
	EnableWindow(GetDlgItem(hWnd, IDC_LEVEL_VIDEO_START_FILE), pLevelT->Header.bStartVideo);
	EnableWindow(GetDlgItem(hWnd, IDC_LEVEL_FIND_VIDEO_START_FILE), pLevelT->Header.bStartVideo);
    SendDlgItemMessage(hWnd, IDC_LEVEL_VIDEO_END, BM_SETCHECK, pLevelT->Header.bEndVideo, 0L);
	EnableWindow(GetDlgItem(hWnd, IDC_LEVEL_VIDEO_END_FILE), pLevelT->Header.bEndVideo);
	EnableWindow(GetDlgItem(hWnd, IDC_LEVEL_FIND_VIDEO_END_FILE), pLevelT->Header.bEndVideo);
} // end UpdateLevelOther()

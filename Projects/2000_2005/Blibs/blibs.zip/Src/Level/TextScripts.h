//-----------------------------------------------------------------------------
// File: TextScripts.h
//-----------------------------------------------------------------------------

#ifndef __TEXT_SCRIPTS_H__
#define __TEXT_SCRIPTS_H__


// Definitions: ***************************************************************
#define TS_LENGTH 450 // The number of characters of one text script text


// Classes: *******************************************************************
class TEXT_SCRIPT_MANAGER;

// A text script:
typedef class TEXT_SCRIPT
{
	public:
		BOOL bActive, // Is it active at the moment?
			 bDeactivate, // Should it be deactivated after showing?
			 bMovementPossible, // Is it possible to move if that text script is active?
			 bSkipPossible, // Could the text script skipped if movement isn't possible?
			 bChoice, // Could the player choose an question/answer?
					  // (if not, the childs are looped)
			 bRandomChoice, // Should the computer choose an text script (child) by random?
			 bEndDialog, // Should the text dialog be closed? (after waiting)
			 bGoto, // Should we jump tp another text script?  (after waiting)
			 bTalkAnimation, // Should the actor have the talk animation?
			 bCameraScript, // Should a camera script be played?
			 bCameraScriptLoop, // Shoud the camera script be looped?
			 bActorAggressive, // Should the talk to actor now be aggressive?
			 bActorSmall, // Should the talk to actor now be small?
			 bActorGuardian, // Should the talk to actor now be a guardian?
			 bActorMobile, // Should the talk to actor now be mobile?
			 bActorFollow, // Should the talk to actor now follow the player?
			 bTreeViewState; // Is the tree in the editor opend or not?
		int iID, // Its unique ID in the text script manager (sorted)
			iChildID, // The child ID from the parent text script (sorted)
			iText, // The ID of the used text
			iTextScripts, // The number of child text scripts
			iSurface, // The shown surface
			iCameraScript; // The shown camera script
		long lWaitTime; // How long should this text be shown?

		HTREEITEM hItem;

		TEXT_SCRIPT_MANAGER *pManager; // A pointer back to the manager
		TEXT_SCRIPT *pParentTextScript; // The parent of this text script
		TEXT_SCRIPT **pTextScript; // The list af all child text scripts

		TEXT_SCRIPT *pGotoTextScript; // To this text script should be jumped after the current text script
		
		int iActivateTextScripts; // The number of text scripts which should be activated
		TEXT_SCRIPT **pActivateTextScript; // A list of text scripts which should be activated
										   // if this text script is called
		int iDeactivateTextScripts; // The number of text scripts which should be deactivated
		TEXT_SCRIPT **pDeactivateTextScript; // A list of text scripts which should be deactivated
										     // if this text script is called

		ITEM_INFO AddItem[ITEMS]; // The added items
		TEXT_SCRIPT *pGotoAddItemSuccess, // 
					*pGotoAddItemFailed;
		ITEM_INFO TakeItem[ITEMS]; // The taken items
		TEXT_SCRIPT *pGotoTakeItemSuccess, // 
					*pGotoTakeItemFailed;


		void ATextWasDeleted(int);
		void AddTextScript(void);
		TEXT_SCRIPT *DeleteTextScript(int);
		void DeleteTextScripts(void);
		void DestroyTextScript(void);
		void SurfaceIsDeleted(int);
		void FillTreeElement(HWND, HTREEITEM);
		void DeleteTreeElement(HWND);
		void GetTreeElementState(HWND);
		void SetTreeElementState(HWND);
		void SetAllTreeElementState(BOOL, HWND);
		TEXT_SCRIPT *GetTextScriptIDPointer(int);
		void UpdateIDs(void);
		void LoadGeneral(FILE *);
		void SaveGeneral(FILE *);
		void LoadOther(FILE *);
		void SaveOther(FILE *);
		void CheckSettings(TEXT_SCRIPT *);

} TEXT_SCRIPT;

// Manages all text scripts:
typedef class TEXT_SCRIPT_MANAGER
{
	public:
		int iTexts, // The number of texts
			iTextScripts; // The total number of text scripts
		char byTextFilename[256], // The filename of the text file
			 **pbyText; // All texts
		
		TEXT_SCRIPT TextScriptRoot; // The text script root

		// Text script playback information:
		BOOL bPlayTextScript; // Should a text script be played?
		TEXT_SCRIPT *pPlayedTS, // The current played text script (playback start root)
					*pCurrentTS;
		long lPlayedTSStartTime, // The time were the current text script was opend
			 lTSSurfaceAniTime; // Surface animation timer
		int iTSSurfaceAniStep, // The current ani step of the shown surface
			iRows; // The number of rows of the currently shown text
		char byRowText[8][70]; // The hole shown text
		ACTOR *pTalkToActor; // The addressed actor
		BOOL bChoicePossible; // Is it possible to make a choice? (maybe theres first an wait time...)
		TEXT_SCRIPT *pCurrentChoice; // The current selected choice

		
	// Texts:
		TEXT_SCRIPT_MANAGER(void);
		void Init(void);
		void LoadTextsFromFile(char *);
		void UpdateTextsFromFile(void);
		void SaveTexts(char *);
		void AddText(void);
		void DeleteText(int);
		void DestroyTexts(void);
		void FillTreeElement(HWND);
		void DeleteTreeElement(HWND);
		void GetTreeElementState(HWND);
		void SetTreeElementState(HWND);
		void SetAllTreeElementState(BOOL, HWND);
		TEXT_SCRIPT *GetTextScriptIDPointer(int);
		TEXT_SCRIPT *DeleteTextScript(int);
		void DestroyAllTextScripts(void);
		void Destroy(void);
		void UpdateIDs(void);
		void SurfaceIsDeleted(int);
		void Load(FILE *);
		void Save(FILE *);
		void FillTextScriptView(TEXT_SCRIPT *, HWND, int);
		void PlayTextScript(TEXT_SCRIPT *, int);
		BOOL DrawTSPlayback(AS_WINDOW *);
		void SetupRowText(char *, int);
		BOOL CheckTSPlayback(void);

} TEXT_SCRIPT_MANAGER;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern BOOL bGetFieldTextScript, bGetActorTextScript;
extern float fTextScriptBlend;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern void OpenTSE(HWND);
///////////////////////////////////////////////////////////////////////////////


#endif // __TEXT_SCRIPTS_H__
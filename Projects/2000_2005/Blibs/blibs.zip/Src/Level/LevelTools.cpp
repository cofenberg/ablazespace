//-----------------------------------------------------------------------------
// File: LevelTools.cpp
//-----------------------------------------------------------------------------

#include "..\AS\AS_Engine.h"
#include "..\ModuleHeaders.h"


// Variables: *****************************************************************
AS_CAMERA LevelTempCamera; // Used to find out if the camera has been moved
char **pbySingleLevelsList; // The found single level names
int iSingleLevelsList;   // The number of found single player levels
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
void CreateLevel(LEVEL **);
void DestroyLevel(LEVEL **);
BOOL GetLevelKeyword(char *, char *);
char GetLevelSingle(char *);
void GetLevelName(char *, char *);
void GetLevelFileName(char *, char *);
void StartLevel(char *, BOOL);
void StartCurrentLevel(void);
void StartLevelMusic(void);
void DestroyLevel(void);
void EnumerateSingleLevels(void);
void DestroySingleLevelList(void);
///////////////////////////////////////////////////////////////////////////////


void CreateLevel(LEVEL **pLevel)
{ // begin CreateLevel()
} // end CreateLevel()

void DestroyLevel(LEVEL **pLevel)
{ // begin DestroyLevel()
	_AS->WriteLogMessage("Destroy text scripts");
	DestroyAllDecorations();
	_AS->WriteLogMessage("Now destroy level itself");
	(*pLevel)->Destroy();
	delete *pLevel;
	*pLevel = NULL;
} // end DestroyLevel()

BOOL GetLevelKeyword(char *pbyFilename, char *pbyKeyword)
{ // begin GetLevelKeyword()
	LEVEL_HEADER Header;
	int iVersion;
	FILE *fp;

	// Open the level:
	if(!pbyFilename)
		return 0;
	fp = fopen(pbyFilename, "rb");
	if(!fp)
		return 0;

	// First, check if this is an correct level version:
	fread(&iVersion, sizeof(int), 1, fp);
	if(iVersion != LEVEL_VERSION)
	{ // This is an wrong level version!!
		_AS->WriteLogMessage("The level version(%d) is not correct! Couldn't load this level!", iVersion);	
		return 0;
	}

	// Load the general level information:
	fread(&Header, sizeof(LEVEL_HEADER), 1, fp);

	// Check the keyword:
	if(Header.bKeyword)
	{ // Give the keyword back:
		strcpy(pbyKeyword, Header.byKeyword);
		return 1;
	}
	return 0;
} // end GetLevelKeyword()

char GetLevelSingle(char *pbyFilename)
{ // begin GetLevelSingle()
	LEVEL_HEADER Header;
	int iVersion;
	FILE *fp;

	// Open the level:
	if(!pbyFilename)
		return 0;
	fp = fopen(pbyFilename, "rb");
	if(!fp)
		return 0;

	// First, check if this is an correct level version:
	fread(&iVersion, sizeof(int), 1, fp);
	if(iVersion != LEVEL_VERSION)
	{ // This is an wrong level version!!
		_AS->WriteLogMessage("The level version(%d) is not correct! Couldn't load this level!", iVersion);	
		return -1;
	}

	// Load the general level information:
	fread(&Header, sizeof(LEVEL_HEADER), 1, fp);

	return Header.bSingle;
} // end GetLevelSingle()

void GetLevelName(char *pbyFilename, char *pbyName)
{ // begin GetLevelName()
	LEVEL_HEADER Header;
	int iVersion;
	FILE *fp;

	// Open the level:
	if(!pbyFilename)
		return;
	fp = fopen(pbyFilename, "rb");
	if(!fp)
		return;

	// First, check if this is an correct level version:
	fread(&iVersion, sizeof(int), 1, fp);
	if(iVersion != LEVEL_VERSION)
	{ // This is an wrong level version!!
		_AS->WriteLogMessage("The level version(%d) is not correct! Couldn't load this level!", iVersion);	
		return;
	}

	// Load the general level information:
	fread(&Header, sizeof(LEVEL_HEADER), 1, fp);

	strcpy(pbyName, Header.byName);
} // end GetLevelName()

void GetLevelFileName(char *byCompleteName, char *byName)
{ // begin GetLevelFileName()
	int i, i2;

	for(i = strlen(byCompleteName)-1, i2 = 0; ; i--, i2++)
	{
		if(byCompleteName[i] == '\\')
			break;
		byName[i2] = byCompleteName[i];
	}
	byName[i2] = '\0';
	strcpy(byName, _strrev(byName));
} // end GetLevelFileName()

void StartLevel(char *pbyFilename, BOOL bFromLoadGame)
{ // begin StartLevel()
	char byOldMusic[256], byTemp[256];
	ACTOR *pActorT;
	int iX, iY;
	int i;

	_AS->WriteLogMessage("Start level: %s", pbyFilename);
	bGameOver = FALSE;
	byGameMenuSelected = 0;

	// Player game init settings:
	bPlayerCameraView = FALSE;
	if(!_ASConfig->bMusic)
		strcpy(byOldMusic, " ");
	else
		if(pLevel) // Backup the old music file:
			strcpy(byOldMusic, pLevel->Header.byMusicFile);	

	// Destroy the old level:
	if(pLevel)
		DestroyLevel();

	_AS->WriteLogMessage("Restart particle system");
	DestroyGameParticleSystems();

	// Setup the new level:
	_AS->WriteLogMessage("Create new level");
	pLevel = new LEVEL;

	// Load the level:
	if(!pLevel->Load(pbyFilename))
	{ // There was an error!
		sprintf(byTemp, "Couldn't load level: %s", pbyFilename);
		_AS->WriteLogMessage(byTemp);
		ShowSmallMessage(byTemp, 5000);
		if(!bEditorTestLevel)
			SendMessage(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), WM_COMMAND, ID_GAME_GENERAL_MAIN_MENU, 0);
		else
			_AS->SetNextModule(MODULE_EDITOR);
		
		return;
	}
	InitGameParticleSystems();
	if(_AS->GetModule() != MODULE_EDITOR)
	{
		ParticleManager.pSystem[PS_PLAYER_AUTOSAVE].bActive = TRUE;
		ParticleManager.pSystem[PS_PLAYER_AUTOSAVE].bUpdate = TRUE;
	}
	else
		ParticleManager.pSystem[PS_PLAYER_AUTOSAVE].bActive = FALSE;
	pLevel->GenTexturesOpenGL(*_AS->pWindow[GAME_WINDOW_ID].GethDC(), 
							  *_AS->pWindow[GAME_WINDOW_ID].GethRC());
	LoadRequiredActorTextues(*_AS->pWindow[GAME_WINDOW_ID].GethDC(), 
							 *_AS->pWindow[GAME_WINDOW_ID].GethRC(), FALSE);

	// Compare if this music is still running:
	if(strcmp(byOldMusic, pLevel->Header.byMusicFile))
	{ // Nope, start the new level music:	
		StartLevelMusic();
	}
	else
		if(!pLevel->Header.bMusic)
		{
			strcpy(byCurrentMusic, "");	
			ASDestroyFmodMusic(&GameMusic);
		}

	_AS->WriteLogMessage("Setup level stuff");
	if(!bFromLoadGame)
	{
		pLevel->State.bLevelComplete = FALSE;
		if(pPlayer && pPlayer->bActive)
			pPlayer->SetToCheckpoint();
		else
		{ // Set the player per random into the level:
			for(i = 0; i < pLevel->Header.iFields*10; i++)
			{
				iX = rand() % (pLevel->Header.iWidth-1);
				iY = rand() % (pLevel->Header.iHeight-1);
				if(!pLevel->pField[iY*pLevel->Header.iWidth+iX].bActive ||
				   pLevel->pField[iY*pLevel->Header.iWidth+iX].bWall ||
				   pLevel->pField[iY*pLevel->Header.iWidth+iX].pActor)
					continue; // No good start position!!
				pPlayer	= pLevel->FindFreeActor();
				if(!pPlayer)
					break;
				pPlayer->InitBlibs(iX, iY);
				pLevel->pField[pPlayer->iFieldID].pActor = pPlayer;
				pPlayer->iCheckpointFieldID = pPlayer->iFieldID;
				pPlayer->SetToCheckpoint();
			}
		}
		pLevel->AdditionalInformation.bSingleLevel = bSingleLevel;
		pLevel->AdditionalInformation.iCampaignLevelID = PlayerIdentity.iSelectedLevel;
	}
	else
	{
		bSingleLevel = pLevel->AdditionalInformation.bSingleLevel;
		PlayerIdentity.iSelectedLevel = pLevel->AdditionalInformation.iCampaignLevelID;
	}

	// Initalize some other stuff:
	g_lNow = GetTickCount();
	g_lLastlooptime = g_lNow;
	SetCursorPos(X_MOUSE_SCREEN_POS, Y_MOUSE_SCREEN_POS);
	bPause = bLevelPressAnyKey = FALSE;
	fSmallMessageBlend = 0.0f;
	fPauseBlend	= 1.0f;
	fPauseTextBlend	= 1.0f;
	InitDisplayActors();
	OktaActor.bActive = FALSE;

	// Camera:
	pLevel->Camera.iCurrentCameraStep = 0;
	lCameraTimer = g_lGameTimer;
	bCameraAnimation = 0;
	memset(&TempCamera, 0, sizeof(AS_CAMERA));
	if(!bEditorTestLevel && !bSingleLevel && pPlayer && PlayerIdentity.iSelectedLevel > 0)
	{ // Setup the current player stuff: (from the last level)
		if((pActorT = &PlayerIdentity.PlayerBackup[PlayerIdentity.iSelectedLevel-1]))
		{
			for(i = 0; i < ITEMS; i++)
			{
				if(!pPlayer->Item[i].bUnlimited)
					pPlayer->Item[i].bUnlimited = pActorT->Item[i].bUnlimited;
				pPlayer->Item[i].iNumber += pActorT->Item[i].iNumber;
			}
		}
	}
	for(i = 0; i < 256; i++)
	{
		ASKeys[i] = FALSE;
		ASKeyFirst[i] = FALSE;
		ASKeyPressed[i] = TRUE;
	}
	pLevel->CalculateWaterPoints(FALSE);
	lKeyTimer = g_lNow = g_lLastlooptime = GetTickCount();
	_AS->WriteLogMessage("Level successful loaded!");
} // end StartLevel()

void StartCurrentLevel(void)
{ // begin StartCurrentLevel()
	fGameMenuBlend = 1.f;
	byGameMenuMenu = 0;

	// Start the level:
	if(!bEditorTestLevel)
	{
		if(!bSingleLevel)
			sprintf(byCurrentLevelName, "%s%s", _AS->byProgramPath, CurrentCampaign.byLevelFilename[PlayerIdentity.iSelectedLevel-1]);
		else
			sprintf(byCurrentLevelName, "%s%s\\%s", _AS->byProgramPath, _AS->bySingleLevelsDirectory, bySelectedSingleLevel);
	}
	StartLevel(byCurrentLevelName, FALSE);
} // end StartCurrentLevel()

void StartLevelMusic(void)
{ // begin StartLevelMusic()
	sprintf(byCurrentMusic, "%s%s", _AS->byProgramPath, pLevel->Header.byMusicFile);
	if(!_AS->bSoundPossible || !_ASConfig->bMusic)
		return;
	ASDestroyFmodMusic(&GameMusic);

	// Play the menu music:
	_AS->WriteLogMessage("Load music: %s", byCurrentMusic);
	if(ASPlayFmodMusic(&GameMusic, byCurrentMusic))
		_AS->WriteLogMessage("Couldn't load this music!");
} // end StartLevelMusic()

void DestroyLevel(void)
{ // begin DestroyLevel()
	_AS->WriteLogMessage("Destroy old level");
	switch(_AS->GetModule())
	{
		case MODULE_GAME:
			pLevel->DestroyTexturesOpenGL(*_AS->pWindow[GAME_WINDOW_ID].GethDC(), 
										  *_AS->pWindow[GAME_WINDOW_ID].GethRC());
		break;

		case MODULE_EDITOR:
			pLevel->DestroyTexturesOpenGL(hDCEditorShow, hRCEditorShow);
		break;
	}
	DestroyLevel(&pLevel);
} // end DestroyLevel()

void EnumerateSingleLevels(void)
{ // begin EnumerateSingleLevels()
	WIN32_FIND_DATA FindFileData;
	char byTemp[256], byResult;
	HANDLE Find;
	                   
	_AS->WriteLogMessage("Enumerate single player levels");
	DestroySingleLevelList();
	sprintf(byTemp, "%s%s\\*.lev", _AS->byProgramPath, _AS->bySingleLevelsDirectory);
	Find = FindFirstFile(byTemp, &FindFileData);
	for(;;)
	{	// We found a single level:
		// Check if it is an single level:
		sprintf(byTemp, "%s%s\\%s", _AS->byProgramPath, _AS->bySingleLevelsDirectory, FindFileData.cFileName);
		byResult = GetLevelSingle(byTemp);
		if(byResult != 0 && byResult != -1)
		{
			iSingleLevelsList++;
			pbySingleLevelsList = (char **) realloc(pbySingleLevelsList, sizeof(char **)*iSingleLevelsList);
			pbySingleLevelsList[iSingleLevelsList-1] = new char[strlen(FindFileData.cFileName)+1];
			strcpy(pbySingleLevelsList[iSingleLevelsList-1], FindFileData.cFileName);
		}
		if(!FindNextFile(Find, &FindFileData))
			break;
	}
	FindClose(Find);
} // end EnumerateSingleLevels()

void DestroySingleLevelList(void)
{ // begin DestroySingleLevelList()
	if(pbySingleLevelsList)
	{
		for(int i = 0; i < iSingleLevelsList; i++)
			free(pbySingleLevelsList[i]);
		free(pbySingleLevelsList);
		pbySingleLevelsList = NULL;
	}
	iSingleLevelsList = 0;
} // end DestroySingleLevelList()
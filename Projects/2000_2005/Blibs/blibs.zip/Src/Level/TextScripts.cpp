//-----------------------------------------------------------------------------
// File: TextScripts.cpp
//-----------------------------------------------------------------------------

#include "..\AS\AS_Engine.h"
#include "..\ModuleHeaders.h"


// Variables: *****************************************************************
float fTextScriptBlend;
BOOL bRowSelected[8];
///////////////////////////////////////////////////////////////////////////////


// TEXT_SCRIPT functions: *****************************************************
// A text was deleted, therefore we have to update the text id of each text script:
void TEXT_SCRIPT::ATextWasDeleted(int iTextID)
{ // begin TEXT_SCRIPT::ATextWasDeleted()
	int i;
	
	if(iText == iTextID)
		iText = -1;
	else
		if(iText > iTextID)
			iText--;

	// Update the child text scripts:
	if(!pTextScript)
		return;
	for(i = 0; i < iTextScripts; i++)
	{
		if(!pTextScript[i])
			continue;
		pTextScript[i]->ATextWasDeleted(iTextID);
	}
} // end TEXT_SCRIPT::ATextWasDeleted()

// Adds an new text script:
void TEXT_SCRIPT::AddTextScript(void)
{ // begin TEXT_SCRIPT::AddTextScript()
	TEXT_SCRIPT *pTextScriptT;

	iTextScripts++;
	pTextScript = (TEXT_SCRIPT **) realloc(pTextScript, sizeof(TEXT_SCRIPT *)*iTextScripts);
	pTextScript[iTextScripts-1] = (TEXT_SCRIPT *) malloc(sizeof(TEXT_SCRIPT));
	memset(pTextScript[iTextScripts-1], 0, sizeof(TEXT_SCRIPT));
	pTextScriptT = pTextScript[iTextScripts-1];
	pTextScriptT->pParentTextScript = this;
	pTextScriptT->pManager = this->pManager;
	pTextScriptT->iChildID = iTextScripts-1;
	pTextScriptT->iText = pTextScriptT->iSurface = pTextScriptT->iCameraScript = -1;
	pTextScriptT->bActive = pTextScriptT->bSkipPossible = TRUE;
} // end TEXT_SCRIPT::AddTextScript()

// Deletes an text script and give an pointer to its parent back:
TEXT_SCRIPT *TEXT_SCRIPT::DeleteTextScript(int iTextScriptID)
{ // begin TEXT_SCRIPT::DeleteTextScript()
	TEXT_SCRIPT *pTextScriptT;
	
	if(!pTextScript)
		return NULL;
	for(int i = 0; i < iTextScripts; i++)
	{
		if(!pTextScript[i])
			continue;
		if(pTextScript[i]->iID == iTextScriptID)
		{ // We found our text script:
			pTextScript[i]->DestroyTextScript();
			free(pTextScript[i]);
			for(i = iTextScriptID-1; i < iTextScripts-1; i++)
				pTextScript[i] = pTextScript[i+1];
			iTextScripts--;
			pTextScript = (TEXT_SCRIPT **) realloc(pTextScript, sizeof(TEXT_SCRIPT *)*iTextScripts);

			return this;
		}
		if((pTextScriptT = pTextScript[i]->DeleteTextScript(iTextScriptID)))
			return pTextScriptT;
	}

	return NULL;
} // end TEXT_SCRIPT::DeleteTextScript()

// Deletes an text script and give an pointer to its parent back:
void TEXT_SCRIPT::DestroyTextScript(void)
{ // begin TEXT_SCRIPT::DestroyTextScript()
	if(!pTextScript)
		return;
	for(int i = 0; i < iTextScripts; i++)
	{
		if(!pTextScript[i])
			continue;
		pTextScript[i]->DestroyTextScript();
		free(pTextScript[i]);
	}
	free(pTextScript);
} // end TEXT_SCRIPT::DestroyTextScript()

// Deletes the text scripts:
void TEXT_SCRIPT::DeleteTextScripts(void)
{ // begin TEXT_SCRIPT::DeleteTextScripts()
	if(!pTextScript)
		return;
	for(int i = 0; i < iTextScripts; i++)
	{
		if(!pTextScript[i])
			continue;
		pTextScript[i]->DeleteTextScripts();
		free(pTextScript[i]);
	}
	free(pTextScript);
	pTextScript = NULL;
	iTextScripts = 0;
	SAFE_FREE(pActivateTextScript);
	SAFE_FREE(pDeactivateTextScript);
} // end TEXT_SCRIPT::DeleteTextScripts()

void TEXT_SCRIPT::SurfaceIsDeleted(int iSurfaceIDT)
{ // begin TEXT_SCRIPT::SurfaceIsDeleted()
	if(iSurface == iSurfaceIDT)
		iSurface = -1;
	else
		if(iSurface > iSurfaceIDT)
			iSurface--;

	if(!pTextScript)
		return;
	for(int i = 0; i < iTextScripts; i++)
	{
		if(!pTextScript[i])
			continue;
		pTextScript[i]->SurfaceIsDeleted(iSurfaceIDT);
	}
} // end TEXT_SCRIPT::SurfaceIsDeleted()

// Fills a tree element with the text skript information:
void TEXT_SCRIPT::FillTreeElement(HWND hWndTree, HTREEITEM hParentTree)
{ // begin TEXT_SCRIPT::FillTreeElement()
	char byTemp[TS_LENGTH+50];
	int i;

	iID = pManager->iTextScripts;
	if(!iTextScripts)
		i = 0;
	else
		i = 1;
	if(!iID)
		strcpy(byTemp, AS_T(T_TextScripts));
	else
	{
		if(iText == -1)
			sprintf(byTemp, "(%d)  %s", iID, AS_T(T_NoText));
		else
		{
			if(!pManager || !pManager->pbyText || !pManager->pbyText[iText])
				sprintf(byTemp, "(%d)  %s", iID, AS_T(T_Error));
			else
				sprintf(byTemp, "(%d)  %d: %s", iID, iText, pManager->pbyText[iText]);
		}
	}
	hItem = ASTree_AddNode(hWndTree, hParentTree, byTemp, i,
								  NULL, NULL, iID, 0, NULL);
	pManager->iTextScripts++;
	if(!pTextScript)
		return;
	for(i = 0; i < iTextScripts; i++)
	{
		if(!pTextScript[i])
			continue;
		pTextScript[i]->FillTreeElement(hWndTree, hItem);
	}
} // end TEXT_SCRIPT::FillTreeElement()

// Deletes a tree element with the text skript information:
void TEXT_SCRIPT::DeleteTreeElement(HWND hWndTree)
{ // begin TEXT_SCRIPT::DeleteTreeElement()
	if(hItem)
	{
		TreeView_DeleteItem(hWndTree, hItem);
		hItem = NULL;
	}
	if(!pTextScript)
		return;
	for(int i = 0; i < iTextScripts; i++)
	{
		if(!pTextScript[i])
			continue;
		pTextScript[i]->DeleteTreeElement(hWndTree);
	}
} // end TEXT_SCRIPT::DeleteTreeElement()

void TEXT_SCRIPT::GetTreeElementState(HWND hWndTree)
{ // begin TEXT_SCRIPT::GetTreeElementState()
	TV_ITEM tvi;
	
	tvi.hItem = hItem;
	tvi.mask   = TVIF_PARAM;
	tvi.lParam = 0;
	TreeView_GetItem(hWndTree, &tvi);
	if(tvi.state >= 70)
		bTreeViewState = 1;
	else
		bTreeViewState = 0;
	
	if(!pTextScript)
		return;
	for(int i = 0; i < iTextScripts; i++)
	{
		if(!pTextScript[i])
			continue;
		pTextScript[i]->GetTreeElementState(hWndTree);
	}
} // end TEXT_SCRIPT::GetTreeElementState()

void TEXT_SCRIPT::SetTreeElementState(HWND hWndTree)
{ // begin TEXT_SCRIPT::SetTreeElementState()
	if(!bTreeViewState)
		TreeView_Expand(hWndTree, hItem, TVE_COLLAPSE);
	else
		TreeView_Expand(hWndTree, hItem, TVE_EXPAND);
	if(!pTextScript)
		return;
	for(int i = 0; i < iTextScripts; i++)
	{
		if(!pTextScript[i])
			continue;
		pTextScript[i]->SetTreeElementState(hWndTree);
	}
} // end TEXT_SCRIPT::SetTreeElementState()

void TEXT_SCRIPT::SetAllTreeElementState(BOOL bState, HWND hWndTree)
{ // begin TEXT_SCRIPT::SetAllTreeElementState()
	bTreeViewState = bState;
	if(hWndTree)
		if(!bTreeViewState)
			TreeView_Expand(hWndTree, hItem, TVE_COLLAPSE);
		else
			TreeView_Expand(hWndTree, hItem, TVE_EXPAND);

	if(!pTextScript)
		return;
	for(int i = 0; i < iTextScripts; i++)
	{
		if(!pTextScript[i])
			continue;
		pTextScript[i]->SetAllTreeElementState(bState, hWndTree);
	}
} // end TEXT_SCRIPT::SetAllTreeElementState()

// Gets the pointer to an text script:
TEXT_SCRIPT *TEXT_SCRIPT::GetTextScriptIDPointer(int iTextScriptID)
{ // begin TEXT_SCRIPT::GetTextScriptIDPointer()
	TEXT_SCRIPT *pTextScriptT;
	
	if(iID == iTextScriptID)
		return this; // Yeah! We found the text script with this ID!

	if(!pTextScript)
		return NULL;
	for(int i = 0; i < iTextScripts; i++)
	{
		if(!pTextScript[i])
			continue;
		if((pTextScriptT = pTextScript[i]->GetTextScriptIDPointer(iTextScriptID)))
			return pTextScriptT;
	}

	return NULL;
} // end TEXT_SCRIPT::GetTextScriptIDPointer()

void TEXT_SCRIPT::UpdateIDs(void)
{ // begin TEXT_SCRIPT::UpdateIDs()
	iID = pManager->iTextScripts;
	pManager->iTextScripts++;
	if(!pTextScript)
		return;
	for(int i = 0; i < iTextScripts; i++)
	{
		if(!pTextScript[i])
			continue;
		pTextScript[i]->UpdateIDs();
	}
} // end TEXT_SCRIPT::UpdateIDs()

// Fist pass, load all general information:
void TEXT_SCRIPT::LoadGeneral(FILE *fp)
{ // begin TEXT_SCRIPT::LoadGeneral()
	int i;
	
	// Load general information
	fread(&bActive, sizeof(BOOL), 1, fp);
	fread(&bDeactivate, sizeof(BOOL), 1, fp);
	fread(&bMovementPossible, sizeof(BOOL), 1, fp);
	fread(&bSkipPossible, sizeof(BOOL), 1, fp);
	fread(&bChoice, sizeof(BOOL), 1, fp);
	fread(&bRandomChoice, sizeof(BOOL), 1, fp);
	fread(&bEndDialog, sizeof(BOOL), 1, fp);
	fread(&bGoto, sizeof(BOOL), 1, fp);
	fread(&bTreeViewState, sizeof(BOOL), 1, fp);
	fread(&iText, sizeof(int), 1, fp);
	fread(&iTextScripts, sizeof(int), 1, fp);
	fread(&iSurface, sizeof(int), 1, fp);
	fread(&lWaitTime, sizeof(long), 1, fp);
	fread(&bTalkAnimation, sizeof(BOOL), 1, fp);
	fread(&bCameraScript, sizeof(BOOL), 1, fp);
	fread(&bCameraScriptLoop, sizeof(BOOL), 1, fp);
	fread(&iCameraScript, sizeof(int), 1, fp);
	fread(&bActorAggressive, sizeof(BOOL), 1, fp);
	fread(&bActorSmall, sizeof(BOOL), 1, fp);
	fread(&bActorGuardian, sizeof(BOOL), 1, fp);
	fread(&bActorMobile, sizeof(BOOL), 1, fp);
	fread(&bActorFollow, sizeof(BOOL), 1, fp);

	// Setup some stuff:
	iID = pManager->iTextScripts++;
	pTextScript = (TEXT_SCRIPT **) malloc(sizeof(TEXT_SCRIPT **)*iTextScripts);

	// Load all text script information:
	for(i = 0; i < iTextScripts; i++)
	{
		pTextScript[i] = (TEXT_SCRIPT *) malloc(sizeof(TEXT_SCRIPT));
		memset(pTextScript[i], 0, sizeof(TEXT_SCRIPT));
		pTextScript[i]->iChildID = i;
		pTextScript[i]->pManager = pManager;
		pTextScript[i]->pParentTextScript = this;
		pTextScript[i]->LoadGeneral(fp);
	}

	// Other:
	fread(&iActivateTextScripts, sizeof(int), 1, fp);
	pActivateTextScript = (TEXT_SCRIPT **) malloc(sizeof(TEXT_SCRIPT**)*iActivateTextScripts);
	fread(&iDeactivateTextScripts, sizeof(int), 1, fp);
	pDeactivateTextScript = (TEXT_SCRIPT **) malloc(sizeof(TEXT_SCRIPT**)*iDeactivateTextScripts);

	// Items:
	for(i = 0; i < ITEMS; i++)
		fread(&AddItem[i], sizeof(ITEM_INFO), 1, fp);
	for(i = 0; i < ITEMS; i++)
		fread(&TakeItem[i], sizeof(ITEM_INFO), 1, fp);
} // end TEXT_SCRIPT::LoadGeneral()

// Fist pass, save all general information:
void TEXT_SCRIPT::SaveGeneral(FILE *fp)
{ // begin TEXT_SCRIPT::SaveGeneral()
	int i;

	// Save general information
	fwrite(&bActive, sizeof(BOOL), 1, fp);
	fwrite(&bDeactivate, sizeof(BOOL), 1, fp);
	fwrite(&bMovementPossible, sizeof(BOOL), 1, fp);	
	fwrite(&bSkipPossible, sizeof(BOOL), 1, fp);
	fwrite(&bChoice, sizeof(BOOL), 1, fp);
	fwrite(&bRandomChoice, sizeof(BOOL), 1, fp);
	fwrite(&bEndDialog, sizeof(BOOL), 1, fp);
	fwrite(&bGoto, sizeof(BOOL), 1, fp);
	fwrite(&bTreeViewState, sizeof(BOOL), 1, fp);
	fwrite(&iText, sizeof(int), 1, fp);
	fwrite(&iTextScripts, sizeof(int), 1, fp);
	fwrite(&iSurface, sizeof(int), 1, fp);
	fwrite(&lWaitTime, sizeof(long), 1, fp);
	fwrite(&bTalkAnimation, sizeof(BOOL), 1, fp);
	fwrite(&bCameraScript, sizeof(BOOL), 1, fp);
	fwrite(&bCameraScriptLoop, sizeof(BOOL), 1, fp);
	fwrite(&iCameraScript, sizeof(int), 1, fp);
	fwrite(&bActorAggressive, sizeof(BOOL), 1, fp);
	fwrite(&bActorSmall, sizeof(BOOL), 1, fp);
	fwrite(&bActorGuardian, sizeof(BOOL), 1, fp);
	fwrite(&bActorMobile, sizeof(BOOL), 1, fp);
	fwrite(&bActorFollow, sizeof(BOOL), 1, fp);

	// Save all text script information:
	for(i = 0; i < iTextScripts; i++)
		pTextScript[i]->SaveGeneral(fp);

	// Other:
	fwrite(&iActivateTextScripts, sizeof(int), 1, fp);
	fwrite(&iDeactivateTextScripts, sizeof(int), 1, fp);

	// Items:
	for(i = 0; i < ITEMS; i++)
		fwrite(&AddItem[i], sizeof(ITEM_INFO), 1, fp);
	for(i = 0; i < ITEMS; i++)
		fwrite(&TakeItem[i], sizeof(ITEM_INFO), 1, fp);
} // end TEXT_SCRIPT::SaveGeneral()

// Second pass, load all link information:
void TEXT_SCRIPT::LoadOther(FILE *fp)
{ // begin TEXT_SCRIPT::LoadOther()
	int i, iTemp;
	
	fread(&iTemp, sizeof(int), 1, fp);
	if(iTemp != -1)
		pGotoTextScript = pManager->GetTextScriptIDPointer(iTemp);
	for(i = 0; i < iActivateTextScripts; i++)
	{
		fread(&iTemp, sizeof(int), 1, fp);
		if(iTemp == -1)
			continue;
		pActivateTextScript[i] = pManager->GetTextScriptIDPointer(iTemp);
	}
	for(i = 0; i < iDeactivateTextScripts; i++)
	{
		fread(&iTemp, sizeof(int), 1, fp);
		if(iTemp == -1)
			continue;
		pDeactivateTextScript[i] = pManager->GetTextScriptIDPointer(iTemp);
	}
	for(i = 0; i < iTextScripts; i++)
		pTextScript[i]->LoadOther(fp);

	fread(&iTemp, sizeof(int), 1, fp);
	if(iTemp != -1)
		pGotoAddItemSuccess = pManager->GetTextScriptIDPointer(iTemp);
	fread(&iTemp, sizeof(int), 1, fp);
	if(iTemp != -1)
		pGotoAddItemFailed = pManager->GetTextScriptIDPointer(iTemp);
	fread(&iTemp, sizeof(int), 1, fp);
	if(iTemp != -1)
		pGotoTakeItemSuccess = pManager->GetTextScriptIDPointer(iTemp);
	fread(&iTemp, sizeof(int), 1, fp);
	if(iTemp != -1)
		pGotoTakeItemFailed = pManager->GetTextScriptIDPointer(iTemp);
} // end TEXT_SCRIPT::LoadOther()

// Second pass, save all link information:
void TEXT_SCRIPT::SaveOther(FILE *fp)
{ // begin TEXT_SCRIPT::SaveOther()
	int i, iTemp;

	if(pGotoTextScript)
		iTemp = pGotoTextScript->iID;
	else
		iTemp = -1;
	fwrite(&iTemp, sizeof(int), 1, fp);
	for(i = 0; i < iActivateTextScripts; i++)
	{
		if(pActivateTextScript[i])
			iTemp = pActivateTextScript[i]->iID;
		else
			iTemp = -1;
		fwrite(&iTemp, sizeof(int), 1, fp);
	}
	for(i = 0; i < iDeactivateTextScripts; i++)
	{
		if(pDeactivateTextScript[i])
			iTemp = pDeactivateTextScript[i]->iID;
		else
			iTemp = -1;
		fwrite(&iTemp, sizeof(int), 1, fp);
	}
	for(i = 0; i < iTextScripts; i++)
		pTextScript[i]->SaveOther(fp);
	
	if(pGotoAddItemSuccess)
		iTemp = pGotoAddItemSuccess->iID;
	else
		iTemp = -1;
	fwrite(&iTemp, sizeof(int), 1, fp);
	if(pGotoAddItemFailed)
		iTemp = pGotoAddItemFailed->iID;
	else
		iTemp = -1;
	fwrite(&iTemp, sizeof(int), 1, fp);

	if(pGotoTakeItemSuccess)
		iTemp = pGotoTakeItemSuccess->iID;
	else
		iTemp = -1;
	fwrite(&iTemp, sizeof(int), 1, fp);
	if(pGotoTakeItemFailed)
		iTemp = pGotoTakeItemFailed->iID;
	else
		iTemp = -1;
	fwrite(&iTemp, sizeof(int), 1, fp);
} // end TEXT_SCRIPT::SaveOther()

// Some things could be done if an text script is started: (e.g. other could be deactivated)
void TEXT_SCRIPT::CheckSettings(TEXT_SCRIPT *pLastTextScriptT)
{ // begin TEXT_SCRIPT::CheckSettings()
	ACTOR *pActorT;
	int i;

	// Camera script:
	if(bCameraScript)
	{
		bCameraAnimation = TRUE;
//		bLoop = bCameraScriptLoop;
		if(pLevel->pCurrentCameraScript != &pLevel->pCameraScript[iCameraScript])
		{
			pLevel->pCurrentCameraScript = &pLevel->pCameraScript[iCameraScript];
			if(pLevel->pCurrentCameraScript->iSteps)
			{
				memset(&TempCamera, 0, sizeof(AS_CAMERA));
				lCameraTimer = g_lGameTimer;
				pLevel->Camera.iCurrentCameraStep = 0;
			}
		}
	}
	
	// Deactivate:
	if(bDeactivate)
		bActive = FALSE;

	// Activate text scripts:
	for(i = 0; i < iActivateTextScripts; i++)
		pActivateTextScript[i]->bActive = TRUE;

	// Deactivate text scripts:
	for(i = 0; i < iDeactivateTextScripts; i++)
		pDeactivateTextScript[i]->bActive = FALSE;

	pManager->lPlayedTSStartTime = g_lGameTimer;
	if(!lWaitTime && bChoice)
		pManager->bChoicePossible = TRUE;
	else
		pManager->bChoicePossible = FALSE;
	pManager->pCurrentChoice = NULL;

	// Check surface:
	if(!pLastTextScriptT || iSurface != pLastTextScriptT->iSurface)
	{ // We should reset the surface animation:
		pManager->lTSSurfaceAniTime = g_lGameTimer;
		pManager->iTSSurfaceAniStep = 0;
	}

	// Check talk to actor:
	pActorT = pManager->pTalkToActor;
	if(pActorT)
	{
		pActorT->bAggressive = bActorAggressive;
		pActorT->bSmall = bActorSmall;
		pActorT->bGuardian = bActorGuardian;
		pActorT->bMobile = bActorMobile;
		pActorT->bFollow = bActorFollow;
	}
} // end TEXT_SCRIPT::CheckSettings()
///////////////////////////////////////////////////////////////////////////////



// TEXT_SCRIPT_MANAGER functions: *****************************************************
TEXT_SCRIPT_MANAGER::TEXT_SCRIPT_MANAGER(void)
{ // begin TEXT_SCRIPT_MANAGER::TEXT_SCRIPT_MANAGER()
	Init();
} // end TEXT_SCRIPT_MANAGER::TEXT_SCRIPT_MANAGER()

void TEXT_SCRIPT_MANAGER::Init(void)
{ // begin TEXT_SCRIPT_MANAGER::Init()
	memset(this, 0, sizeof(TEXT_SCRIPT_MANAGER));
	TextScriptRoot.pManager = this;
	TextScriptRoot.iText = -1;
	TextScriptRoot.bTreeViewState = 0;
} // end TEXT_SCRIPT_MANAGER::Init()

// Loads the text from a given file:
void TEXT_SCRIPT_MANAGER::LoadTextsFromFile(char *pbyFilename)
{ // begin TEXT_SCRIPT_MANAGER::LoadTextsFromFile()
	char byTemp[TS_LENGTH+50], byFilenameT[256];

	if(!pbyFilename || !pbyFilename[0])
		return;
	strcpy(byTextFilename, pbyFilename);
	sprintf(byFilenameT, "%s%s", _AS->byProgramPath, pbyFilename);
	DestroyTexts();

	// Get the number of texts:
	iTexts = GetPrivateProfileInt("general", "texts", 0, byFilenameT);
	pbyText = (char **) malloc(sizeof(char *)*iTexts);

	// Load now the texts:
	for(int i = 0; i < iTexts; i++)
	{
		sprintf(byTemp, "%d", i);
		GetPrivateProfileString(_ASConfig->byLanguage, byTemp, "", byTemp, TS_LENGTH, byFilenameT);
		pbyText[i] = (char *) malloc(sizeof(char)*strlen(byTemp)+1);
		strcpy(pbyText[i], byTemp);
	}
} // end begin TEXT_SCRIPT_MANAGER::LoadTextsFromFile()

// Reloads the texts of the text file:
void TEXT_SCRIPT_MANAGER::UpdateTextsFromFile(void)
{ // begin TEXT_SCRIPT_MANAGER::UpdateTextsFromFile()
	char byTemp[TS_LENGTH+50], byFilenameT[256];

	if(!pbyText)
		return;
	sprintf(byFilenameT, "%s%s", _AS->byProgramPath, byTextFilename);
	for(int i = 0; i < iTexts; i++)
	{
		if(!pbyText[i])
			continue;
		sprintf(byTemp, "%d", i);
		GetPrivateProfileString(_ASConfig->byLanguage, byTemp, "", byTemp, TS_LENGTH, byFilenameT);
		SAFE_FREE(pbyText[i]);
		pbyText[i] = (char *) malloc(sizeof(char)*strlen(byTemp)+1);
		strcpy(pbyText[i], byTemp);
	}
} // end begin TEXT_SCRIPT_MANAGER::UpdateTextsFromFile()

// Saves the texts in a given file:
void TEXT_SCRIPT_MANAGER::SaveTexts(char *pbyFilename)
{ // begin TEXT_SCRIPT_MANAGER::SaveTexts()
	char byTemp[TS_LENGTH+50], byFilenameT[256];

	strcpy(byTextFilename, pbyFilename);
	sprintf(byFilenameT, "%s%s", _AS->byProgramPath, pbyFilename);

	// Save the number of texts:
	sprintf(byTemp, "%d", iTexts);
	WritePrivateProfileString("general", "texts", byTemp, byFilenameT);

	// Save now the texts:
	for(int i = 0; i < iTexts; i++)
	{
		sprintf(byTemp, "%d", i);
		WritePrivateProfileString(_ASConfig->byLanguage, byTemp, pbyText[i], byFilenameT);
	}
} // end begin TEXT_SCRIPT_MANAGER::SaveTexts()

// Adds a new text:
void TEXT_SCRIPT_MANAGER::AddText(void)
{ // end begin TEXT_SCRIPT_MANAGER::AddText()
	iTexts++;
	pbyText = (char **) realloc(pbyText, sizeof(char *)*iTexts);
	pbyText[iTexts-1] = (char *) malloc(sizeof(char)*TS_LENGTH);
	memset(pbyText[iTexts-1], 0, sizeof(char)*TS_LENGTH);
	strcpy(pbyText[iTexts-1], "Temp");
} // end begin TEXT_SCRIPT_MANAGER::AddText()

// Deletes a text:
void TEXT_SCRIPT_MANAGER::DeleteText(int iID)
{ // end begin TEXT_SCRIPT_MANAGER::DeleteText()
	int i;
	
	SAFE_FREE(pbyText[iID]);

	// Fill the cap:
	for(i = iID; i < iTexts-1; i++)
		pbyText[i] = pbyText[i+1];

	// Resize the text list:
	iTexts--;
	pbyText = (char **) realloc(pbyText, sizeof(char *)*iTexts);

	// Update the text scripts:
	TextScriptRoot.ATextWasDeleted(iID);
} // end begin TEXT_SCRIPT_MANAGER::DeleteText()

// Destroys all texts:
void TEXT_SCRIPT_MANAGER::DestroyTexts(void)
{ // end begin TEXT_SCRIPT_MANAGER::DestroyTexts()
	if(pbyText)
	{
		for(int i = 0; i < iTexts; i++)
			SAFE_FREE(pbyText[i]);
		free(pbyText);
	}
	iTexts = 0;
} // end begin TEXT_SCRIPT_MANAGER::DestroyTexts()

// Fills a tree element with the text skript information:
void TEXT_SCRIPT_MANAGER::FillTreeElement(HWND hWndTree)
{ // begin TEXT_SCRIPT_MANAGER::FillTreeElement()
	iTextScripts = 0;
	TextScriptRoot.FillTreeElement(hWndTree, TVI_ROOT);
	TextScriptRoot.SetTreeElementState(hWndTree);
} // end TEXT_SCRIPT_MANAGER::FillTreeElement()

// Delets the tree element with the text skript information:
void TEXT_SCRIPT_MANAGER::DeleteTreeElement(HWND hWndTree)
{ // begin TEXT_SCRIPT_MANAGER::DeleteTreeElement()
	TextScriptRoot.DeleteTreeElement(hWndTree);
} // end TEXT_SCRIPT_MANAGER::DeleteTreeElement()

void TEXT_SCRIPT_MANAGER::GetTreeElementState(HWND hWndTree)
{ // begin TEXT_SCRIPT_MANAGER::GetTreeElementState()
	TextScriptRoot.GetTreeElementState(hWndTree);
} // end TEXT_SCRIPT_MANAGER::GetTreeElementState()

void TEXT_SCRIPT_MANAGER::SetTreeElementState(HWND hWndTree)
{ // begin TEXT_SCRIPT_MANAGER::SetTreeElementState()
	TextScriptRoot.SetTreeElementState(hWndTree);
} // end TEXT_SCRIPT_MANAGER::SetTreeElementState()

void TEXT_SCRIPT_MANAGER::SetAllTreeElementState(BOOL bState, HWND hWndTree)
{ // begin TEXT_SCRIPT_MANAGER::SetAllTreeElementState()
	TextScriptRoot.SetAllTreeElementState(bState, hWndTree);
} // end TEXT_SCRIPT_MANAGER::SetAllTreeElementState()

// Gets the pointer to an text script:
TEXT_SCRIPT *TEXT_SCRIPT_MANAGER::GetTextScriptIDPointer(int iTextScriptID)
{ // begin TEXT_SCRIPT_MANAGER::GetTextScriptIDPointer()
	return TextScriptRoot.GetTextScriptIDPointer(iTextScriptID);
} // end TEXT_SCRIPT_MANAGER::GetTextScriptIDPointer()

TEXT_SCRIPT *TEXT_SCRIPT_MANAGER::DeleteTextScript(int iTextScriptID)
{ // begin TEXT_SCRIPT_MANAGER::DeleteTextScript()
	TEXT_SCRIPT *pTextScriptT;

	pTextScriptT = TextScriptRoot.DeleteTextScript(iTextScriptID);
	iTextScripts = 0;
	TextScriptRoot.UpdateIDs();
	return pTextScriptT;
} // end TEXT_SCRIPT_MANAGER::DeleteTextScript()

void TEXT_SCRIPT_MANAGER::DestroyAllTextScripts(void)
{ // begin TEXT_SCRIPT_MANAGER::DestroyAllTextScripts()
	TextScriptRoot.DeleteTextScripts();
} // end TEXT_SCRIPT_MANAGER::DestroyAllTextScripts()

void TEXT_SCRIPT_MANAGER::Destroy(void)
{ // begin TEXT_SCRIPT_MANAGER::Destroy()
	DestroyAllTextScripts();
	DestroyTexts();
} // end TEXT_SCRIPT_MANAGER::Destroy()

void TEXT_SCRIPT_MANAGER::UpdateIDs(void)
{ // begin TEXT_SCRIPT_MANAGER::UpdateIDs()
	iTextScripts = 0;
	TextScriptRoot.UpdateIDs();
} // end TEXT_SCRIPT_MANAGER::UpdateIDs()

void TEXT_SCRIPT_MANAGER::SurfaceIsDeleted(int iSurfaceIDT)
{ // begin TEXT_SCRIPT_MANAGER::SurfaceIsDeleted()
	TextScriptRoot.SurfaceIsDeleted(iSurfaceIDT);
} // end TEXT_SCRIPT_MANAGER::SurfaceIsDeleted()

void TEXT_SCRIPT_MANAGER::Load(FILE *fp)
{ // begin TEXT_SCRIPT_MANAGER::Load()
	iTextScripts = 0;

	// Load general information
	fread(&byTextFilename, sizeof(char)*256, 1, fp);
	LoadTextsFromFile(byTextFilename);

	// Load all text script information:
	TextScriptRoot.pManager = this;
	TextScriptRoot.LoadGeneral(fp);
	TextScriptRoot.LoadOther(fp);
} // end TEXT_SCRIPT_MANAGER::Load()

void TEXT_SCRIPT_MANAGER::Save(FILE *fp)
{ // begin TEXT_SCRIPT_MANAGER::Save()
	// Save general information
	fwrite(&byTextFilename, sizeof(char)*256, 1, fp);

	// Save the texts:
	SaveTexts(byTextFilename);

	// Save all text script information:
	TextScriptRoot.SaveGeneral(fp);
	TextScriptRoot.SaveOther(fp);
} // end TEXT_SCRIPT_MANAGER::Save()

void TEXT_SCRIPT_MANAGER::FillTextScriptView(TEXT_SCRIPT *pTextScriptTT, HWND hWnd, int iElementID)
{ // begin TEXT_SCRIPT_MANAGER::FillTextScriptView()
	char byTemp[TS_LENGTH+50];
	
	if(!pTextScriptTT)
	{ // No text scipt selected!
		SetDlgItemText(hWnd, iElementID, " ");
		return;
	}
	if(pTextScriptTT->iText == -1)
		sprintf(byTemp, "(%d)  %s", pTextScriptTT->iID, AS_T(T_NoText));
	else
		sprintf(byTemp, "(%d)  %d: %s", pTextScriptTT->iID, pTextScriptTT->iText, pTextScriptTT->pManager->pbyText[pTextScriptTT->iText]);
	SetDlgItemText(hWnd, iElementID, byTemp);
} // end TEXT_SCRIPT_MANAGER::FillTextScriptView()

// Plays the given text script:
void TEXT_SCRIPT_MANAGER::PlayTextScript(TEXT_SCRIPT *pTextScriptT, int iTextScriptID)
{ // begin TEXT_SCRIPT_MANAGER::PlayTextScript()
	if(!pTextScriptT)
	{
		if(!(pTextScriptT = GetTextScriptIDPointer(iTextScriptID)))
			return;
	}
	bPlayTextScript = TRUE;
	pCurrentTS = pPlayedTS = pTextScriptT;

	// Check now the new text script:
	pCurrentTS->CheckSettings(NULL);
} // end TEXT_SCRIPT_MANAGER::PlayTextScript()

// Draw the text script playback:
BOOL TEXT_SCRIPT_MANAGER::DrawTSPlayback(AS_WINDOW *pWindow)
{ // begin TEXT_SCRIPT_MANAGER::DrawTSPlayback()
	TEXTURE_POS *pTexturePos;
	SURFACE *pSurfaceT;
	char *pbyTextT, byTemp[TS_LENGTH+50];
	int i, i2, iX, iY, iChild, iActiveChild;
	float fBlend;

	if(!fTextScriptBlend || !pCurrentTS)
		return FALSE;

	fBlend = (float) (0.5f-0.5f*cos(sin(fTextScriptBlend*PId2)*PI));
	if(pCurrentTS->iText != -1)
		pbyTextT = pbyText[pCurrentTS->iText];
	else
		pbyTextT = NULL;

	glDisable(GL_LIGHTING);
	glCullFace(GL_BACK);
	glDisable(GL_FOG);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_CULL_FACE);
	glEnable(GL_BLEND);
	glDisable(GL_TEXTURE_2D);
	glBlendFunc(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);
	glColor4f(0.1f, 0.1f, 0.1f, 0.2f+0.8f*(1.0f-fBlend));
	glLoadIdentity();
	glTranslatef(-1.0f, -(1.0f-fBlend)*5, -34.0f);
	glBegin(GL_QUADS);
		glNormal3f(0.0f, 0.0f, 1.0f);
		glVertex3f(-15.0f, -9.0f, 10.0f);
		glVertex3f( 15.0f, -9.0f, 10.0f);
		glVertex3f( 15.0f,  -5.0f, 10.0f);
		glVertex3f(-15.0f,  -5.0f, 10.0f);
	glEnd();
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);

	// Get the number of rows and setup them:
	for(i = 0; i < 8; i++)
	{
		memset(byRowText[i], 0, sizeof(char)*70);
		bRowSelected[i] = FALSE;
	}
	if(pCurrentTS->bChoice && bChoicePossible)
	{
		for(iRows = 0, i2 = 0, iChild = -1, iActiveChild = 0; iChild < pCurrentTS->iTextScripts; iChild++)
		{
			glColor4f(1.0f, 1.0f, 1.0f, 0.95f);
			if(iChild != -1)
			{
				if(!pCurrentTS->pTextScript[iChild]->bActive)
					continue;
				if(pCurrentChoice == pCurrentTS->pTextScript[iChild])
					bRowSelected[iRows] = TRUE;
				if(pCurrentTS->pTextScript[iChild]->iText != -1)
					sprintf(byTemp, "%d. %s", iActiveChild+1, pbyText[pCurrentTS->pTextScript[iChild]->iText]);
				else
					sprintf(byTemp, "%d", iActiveChild+1);
				iActiveChild++;
				pbyTextT = byTemp;
				i2 = 0;
			}
			SetupRowText(pbyTextT, i2);
			if(iChild != -1)
			{
				if(iRows >= 7)
					break;
				iRows++;
			}
		}
	}
	else
	{
		iRows = i2 = 0;
		SetupRowText(pbyTextT, i2);
	}
	

	// Draw each row:
	iY = (int) (((iRows+1)/2)*10+fBlend*100-35);
	if(pCurrentTS->iSurface == -1)
		iX = 320;
	else
		iX = 360;
	for(i = 0; i < iRows+1; i++)
	{
		if(bRowSelected[i])
			glColor4f(1.0f, 0.0f, 0.0f, fBlend);
		else
			glColor4f(1.0f, 1.0f, 1.0f, fBlend);
		pWindow->PrintAnimated(iX, iY-i*12, byRowText[i], 0, 1.0f, fFontAni, 1);
	}
	
	// Draw the surface, if there is one:
	if(pCurrentTS->iSurface == -1)
		return TRUE;
	pSurfaceT = &pLevel->pSurface[pCurrentTS->iSurface];
	pTexturePos = &pSurfaceT->pTexturePos[iTSSurfaceAniStep];

	glColor3f(1.0f, 1.0f, 1.0f);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);

	glBindTexture(GL_TEXTURE_2D, pSurfaceT->pTexture[iTSSurfaceAniStep]->iOpenGLID);
	glLoadIdentity();
	glTranslatef(-6.6f, -4.1f-5.0f*(1.0f-fBlend), -15.0f);
	glBegin(GL_QUADS);
		glTexCoord2f((float) pTexturePos->fPos[6][X], 
					 (float) pTexturePos->fPos[6][Y]);
		glVertex3f(-1.0f,  -1.0f, 1.0f);
		glTexCoord2f((float) pTexturePos->fPos[4][X], 
					 (float) pTexturePos->fPos[4][Y]);
		glVertex3f(1.0f, -1.0f, 1.0f);
		glTexCoord2f((float) pTexturePos->fPos[2][X], 
					 (float) pTexturePos->fPos[2][Y]);
		glVertex3f( 1.0f, 1.0f, 1.0f);
		glTexCoord2f((float) pTexturePos->fPos[0][X], 
					 (float) pTexturePos->fPos[0][Y]);
		glVertex3f( -1.0f,  1.0f, 1.0f);
	glEnd();
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);

	return TRUE;
} // end TEXT_SCRIPT_MANAGER::DrawTSPlayback()

void TEXT_SCRIPT_MANAGER::SetupRowText(char *pbyTextT, int i2)
{ // begin void TEXT_SCRIPT_MANAGER::SetupRowText()
	char byTemp[256], byTemp2[TS_LENGTH+50];
	
	if(!pbyTextT)
		return; // There's no text!
	for(int i = 0; i < (signed) strlen(pbyTextT); i++, i2++)
	{
		// Check if we should go into the next row:
		for(int iCommand = 0; iCommand < 19; iCommand++)
		{
			switch(iCommand)
			{
				case 0: strcpy(byTemp, "/left_key/"); strcpy(byTemp2, AS_DXInputKeys[_ASConfig->iLeftKey[1]].byName); break;
				case 1: strcpy(byTemp, "/right_key/"); strcpy(byTemp2, AS_DXInputKeys[_ASConfig->iRightKey[1]].byName); break;
				case 2: strcpy(byTemp, "/up_key/"); strcpy(byTemp2, AS_DXInputKeys[_ASConfig->iUpKey[1]].byName); break;
				case 3: strcpy(byTemp, "/down_key/"); strcpy(byTemp2, AS_DXInputKeys[_ASConfig->iDownKey[1]].byName); break;
				case 4: strcpy(byTemp, "/shot_key/"); strcpy(byTemp2, AS_DXInputKeys[_ASConfig->iShotKey[1]].byName); break;
				case 5: strcpy(byTemp, "/kick_key/"); strcpy(byTemp2, AS_DXInputKeys[_ASConfig->iKickKey[1]].byName); break;
				case 6: strcpy(byTemp, "/action_key/"); strcpy(byTemp2, AS_DXInputKeys[_ASConfig->iActionKey[1]].byName); break;
				case 7: strcpy(byTemp, "/pull_key/"); strcpy(byTemp2, AS_DXInputKeys[_ASConfig->iPullKey[1]].byName); break;
				case 8: strcpy(byTemp, "/suicide_key/"); strcpy(byTemp2, AS_DXInputKeys[_ASConfig->iSuicideKey[1]].byName); break;
				case 9: strcpy(byTemp, "/jump_key/"); strcpy(byTemp2, AS_DXInputKeys[_ASConfig->iJumpKey[1]].byName); break;
				case 10: strcpy(byTemp, "/change_perspective_key/"); strcpy(byTemp2, AS_DXInputKeys[_ASConfig->iChangePerspectiveKey[1]].byName); break;
				case 11: strcpy(byTemp, "/standart_view_key/"); strcpy(byTemp2, AS_DXInputKeys[_ASConfig->iStandartViewKey[1]].byName); break;
				case 12: strcpy(byTemp, "/pause_key/"); strcpy(byTemp2, AS_DXInputKeys[_ASConfig->iPauseKey[1]].byName); break;
				case 13: strcpy(byTemp, "/quick_load_key/"); strcpy(byTemp2, AS_DXInputKeys[_ASConfig->iQuickLoadKey[1]].byName); break;
				case 14: strcpy(byTemp, "/quick_save_key/"); strcpy(byTemp2, AS_DXInputKeys[_ASConfig->iQuickSaveKey[1]].byName); break;
				case 15: strcpy(byTemp, "/level_restart_key/"); strcpy(byTemp2, AS_DXInputKeys[_ASConfig->iLevelRestartKey[1]].byName); break;
				case 16: strcpy(byTemp, "/show_level_missions_key/"); strcpy(byTemp2, AS_DXInputKeys[_ASConfig->iShowLevelMissionsKey[1]].byName); break;
			}
			if(!_mbsnbicmp((const unsigned char *) &pbyTextT[i], (const unsigned char *) byTemp, strlen(byTemp)))
			{
				strcpy(&byRowText[iRows][i2], byTemp2);
				i += strlen(byTemp);
				i2 += strlen(byTemp2);
			}
		}
		for(;;)
		{
			if(i >= (signed) strlen(pbyTextT))
				break;
			if(!_mbsnbicmp((const unsigned char *) &pbyTextT[i], (const unsigned char *) "/n/", strlen("/n/")))
			{ // Go into the next row:
				i2 = 0;
				if(iRows < 7)
				{
					bRowSelected[iRows+1] = bRowSelected[iRows];
					iRows++;
				}
				else
					break;
				i += 3;
			}
			else
				break;
		}

		// Check if this row is full:
		if(pCurrentTS->iSurface != -1)
		{
			if(i2 >= 52)
			{ // Yea, it's full:
				i2 = 0;
				if(iRows < 7)
				{
					bRowSelected[iRows+1] = bRowSelected[iRows];
					iRows++;
				}
				else
					break;
			}
		}
		else
		{
			if(i2 >= 55)
			{ // Yea, it's full:
				i2 = 0;
				if(iRows < 7)
				{
					bRowSelected[iRows+1] = bRowSelected[iRows];
					iRows++;
				}
				else
					break;
			}
		}
		if(i >= (signed) strlen(pbyTextT))
			break;
		byRowText[iRows][i2] = pbyTextT[i];
	}
} // end void TEXT_SCRIPT_MANAGER::SetupRowText()

// Checks the text script playback:
BOOL TEXT_SCRIPT_MANAGER::CheckTSPlayback(void)
{ // begin TEXT_SCRIPT_MANAGER::CheckTSPlayback()
	TEXT_SCRIPT *pLastTextScriptT;
	SURFACE *pSurfaceT;
	BOOL bBackJump, bNoActiveChild;
	int i;

	if(!bPlayTextScript || !pCurrentTS || !pPlayedTS)
	{
		fTextScriptBlend -= (float) g_lDeltatime/1000;
		if(fTextScriptBlend < 0.0f)
			fTextScriptBlend = 0.0f;
		pTalkToActor = FALSE;
		return FALSE;
	}
	fTextScriptBlend += (float) g_lDeltatime/1000;
	if(fTextScriptBlend > 1.0f)
		fTextScriptBlend = 1.0f;
	if(pPlayer && (pPlayer->bGoingDeath || pPlayer->bDeath || !pPlayer->bActive))
	{ // Oh, no! Your main char dies while a text script is active! (definitively not good...)
		bPlayTextScript = FALSE;
		return TRUE;
	}
	if(!pCurrentTS->bMovementPossible && pCurrentTS->bSkipPossible)
	{ // Check some keys:
		if(ASKeyFirst[DIK_ESCAPE])
		{
			ASKeyFirst[DIK_ESCAPE] = FALSE;
			bPlayTextScript = FALSE;
			return TRUE;
		}
		for(i = 0; i < 256; i++)
		{
			if(i == DIK_ESCAPE || i == AS_SCREENSHOT_KEY)
				continue;
			if(ASKeyFirst[i])
			{
				if(!pCurrentTS->bChoice)
					ASKeyFirst[i] = FALSE;
				lPlayedTSStartTime = g_lGameTimer-pCurrentTS->lWaitTime-100;
				break;
			}
		}
	}

	// Update the current text script:
	if(pCurrentTS->bChoice)
	{ // The player should choose:
		if(ASCheckTimeUpdate(&lPlayedTSStartTime, pCurrentTS->lWaitTime))
		{
			if(!bChoicePossible || !pCurrentChoice)
			{ // Select the first active child:
				for(i = 0; i < pCurrentTS->iTextScripts; i++)
				{
					if(!pCurrentTS->pTextScript[i]->bActive)
						continue;
					pCurrentChoice = pCurrentTS->pTextScript[i];
					break;
				}
				if(!pCurrentChoice)
				{ // Ups, there isn't a active child:
					goto BackJump;
				}
				bChoicePossible = TRUE;
			}
			if(ASKeyFirst[_ASConfig->iUpKey[0]])
			{
				ASKeyFirst[_ASConfig->iUpKey[0]] = FALSE;
				for(;;)
				{
					if(pCurrentChoice->iChildID-1 < 0)
						pCurrentChoice = pCurrentTS->pTextScript[pCurrentTS->iTextScripts-1];
					else
						pCurrentChoice = pCurrentTS->pTextScript[pCurrentChoice->iChildID-1];
					if(pCurrentChoice->bActive)
						break;
				}
			}
			if(ASKeyFirst[_ASConfig->iDownKey[0]])
			{
				ASKeyFirst[_ASConfig->iDownKey[0]] = FALSE;
				for(;;)
				{
					if(pCurrentChoice->iChildID+1 >= pCurrentTS->iTextScripts)
						pCurrentChoice = pCurrentTS->pTextScript[0];
					else
						pCurrentChoice = pCurrentTS->pTextScript[pCurrentChoice->iChildID+1];
					if(pCurrentChoice->bActive)
						break;
				}
			}
			if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
			{ // Select the current choice:
				ASKeyFirst[DIK_SPACE] = ASKeyFirst[DIK_RETURN] = FALSE;
				pLastTextScriptT = pCurrentTS;
				pCurrentTS = pCurrentChoice;

				// Check now the new text script:
				pCurrentTS->CheckSettings(pLastTextScriptT);
				goto Check;
			}
		}
	}
	else
	{
	Check:
		if(ASCheckTimeUpdate(&lPlayedTSStartTime, pCurrentTS->lWaitTime))
		{ // Ok, its time to go to the next text script:
			// Check item taking:
			for(i = 0; i < ITEMS; i++)
			{
				if(!i)
					pPlayer->fHealth -= pCurrentTS->TakeItem[i].iNumber;
				if(pPlayer->Item[i].iNumber-pCurrentTS->TakeItem[i].iNumber < 0)
				{ // The item taking failed!
					if(pCurrentTS->pGotoTakeItemFailed)
					{
						pLastTextScriptT = pCurrentTS;
						pCurrentTS = pCurrentTS->pGotoTakeItemFailed;
					
						// Check now the new text script:
						pCurrentTS->CheckSettings(pLastTextScriptT);
						return TRUE;
					}
					break;
				}
				pPlayer->Item[i].iNumber -= pCurrentTS->TakeItem[i].iNumber;
				if(pCurrentTS->TakeItem[i].bUnlimited)
					pPlayer->Item[i].bUnlimited = FALSE;
			}

			// Check item adding:
			for(i = 0; i < ITEMS; i++)
			{
				if(!i)
					pPlayer->fHealth += pCurrentTS->AddItem[i].iNumber;
				pPlayer->Item[i].iNumber += pCurrentTS->AddItem[i].iNumber;
				if(pCurrentTS->AddItem[i].bUnlimited)
					pPlayer->Item[i].bUnlimited = TRUE;	
			}
			if(pCurrentTS->pGotoAddItemSuccess)
			{
				pLastTextScriptT = pCurrentTS;
				pCurrentTS = pCurrentTS->pGotoAddItemSuccess;
			
				// Check now the new text script:
				pCurrentTS->CheckSettings(pLastTextScriptT);
				return TRUE;
			}


			if(pCurrentTS->bEndDialog)
			{ // The text dialog should now be closed:
				bPlayTextScript = FALSE;
				return TRUE;
			}

			// Get the next text script:
			pLastTextScriptT = pCurrentTS;
			if(pCurrentTS->bGoto)
			{ // The easiest case:
				if(pCurrentTS->pGotoTextScript && pCurrentTS->pGotoTextScript->bActive)
					pCurrentTS = pCurrentTS->pGotoTextScript;
				else
				{ // The target text script isn't active!
					bPlayTextScript = FALSE;
					return TRUE;
				}
			}
			else
			{
				// Go into the children if possible:
				bNoActiveChild = TRUE;
				if(pCurrentTS->iTextScripts)
				{
					if(pCurrentTS->bRandomChoice)
					{ // The computer should give a random answer:
						// First check if there is an active child:
						for(i = 0; i < pCurrentTS->iTextScripts; i++)
						{
							if(!pCurrentTS->pTextScript[i]->bActive)
								continue;
							bNoActiveChild = FALSE;
							break;
						}
						if(!bNoActiveChild)
						{ // Get a random answer:
							for(;;)
							{
								i = rand() % pCurrentTS->iTextScripts;
								if(!pCurrentTS->pTextScript[i]->bActive)
									continue;
								pCurrentTS = pCurrentTS->pTextScript[i];
								break;
							}
						}
					}
					else
					{
						for(i = 0; i < pCurrentTS->iTextScripts; i++)
						{
							if(!pCurrentTS->pTextScript[i]->bActive)
								continue;
							pCurrentTS = pCurrentTS->pTextScript[i];
							bNoActiveChild = FALSE;
							break;
						}
					}
				}
				if(bNoActiveChild)
				{
					bBackJump = TRUE;
					if(!pCurrentTS->pParentTextScript->bRandomChoice)
					{
						if(pCurrentTS->iChildID < pCurrentTS->pParentTextScript->iTextScripts)
						{ // Select the following text script:
							for(i = pCurrentTS->iChildID+1; i < pCurrentTS->pParentTextScript->iTextScripts; i++)
							{
								if(!pCurrentTS->pParentTextScript->pTextScript[i]->bActive)
									continue;
								pCurrentTS = pCurrentTS->pParentTextScript->pTextScript[i];
								bBackJump = FALSE;
								break;
							}
						}
					}
					if(bBackJump)
					{ // Jump back to the parent:
					BackJump:
						for(;;)
						{
							if(pCurrentTS->pParentTextScript && pCurrentTS->pParentTextScript != pPlayedTS &&
							   pCurrentTS->pParentTextScript != &pCurrentTS->pManager->TextScriptRoot)
							{ // Select the next text script under the parent if possible:
								pCurrentTS = pCurrentTS->pParentTextScript;
								if(pCurrentTS->pParentTextScript && pCurrentTS->pParentTextScript->bChoice &&
								   !pCurrentTS->bChoice)
									continue;
								if(pCurrentTS->pParentTextScript &&
								   pCurrentTS->iChildID+1 < pCurrentTS->pParentTextScript->iTextScripts)
								{
									pCurrentTS = pCurrentTS->pParentTextScript->pTextScript[pCurrentTS->iChildID+1];
									break;
								}
							}
							else
							{ // Hm, we don't want to leave your started text script!
								pCurrentTS = pPlayedTS;
								break;
							}
						}
					}
				}
			}

			// Check now the new text script:
			pCurrentTS->CheckSettings(pLastTextScriptT);
		}
	}

	// Animate the text script surface, if there is one:
	if(pCurrentTS->iSurface == -1)
		return TRUE;
	pSurfaceT = &pLevel->pSurface[pCurrentTS->iSurface];
	if(!ASCheckTimeUpdate(&lTSSurfaceAniTime, pSurfaceT->pTexturePos[iTSSurfaceAniStep].iTimeToNext))
		return TRUE;
	iTSSurfaceAniStep++;
	if(iTSSurfaceAniStep >= pSurfaceT->Header.iAniSteps)
		iTSSurfaceAniStep = 0;

	return TRUE;
} // end TEXT_SCRIPT_MANAGER::CheckTSPlayback()
///////////////////////////////////////////////////////////////////////////////
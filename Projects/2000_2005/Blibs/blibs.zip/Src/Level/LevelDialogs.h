//-----------------------------------------------------------------------------
// File: LevelDialogs.h
//-----------------------------------------------------------------------------

#ifndef __LEVEL_DIALOGS_H__
#define __LEVEL_DIALOGS_H__


// Functions: *****************************************************************
extern LRESULT CALLBACK LevelProc(HWND, UINT, WPARAM, LPARAM);
extern void NewLevelDialog(void);
extern void AdjustLevelDialog(void);
extern void SetLevelLanguage(void);
///////////////////////////////////////////////////////////////////////////////


#endif // __LEVEL_DIALOGS_H__
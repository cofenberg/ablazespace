//-----------------------------------------------------------------------------
// File: TextScriptsEditor.cpp
//-----------------------------------------------------------------------------

#include "..\AS\AS_Engine.h"
#include "..\ModuleHeaders.h"


// Definitions: ***************************************************************
enum { TAB_TSE_TEXT, TAB_TSE_GENERAL, TAB_TSE_ACTIVATE, TAB_TSE_ITEMS };
#define TSE_TABS 4
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
TEXT_SCRIPT *pTextScriptT;
HWND hWndTSE, hWndTSETree,
	 hWndTSETab[TSE_TABS]; // The tab handles
int	iCurrentTSETab; // The current selected level tab
TEXT_SCRIPT_MANAGER *pTextScriptManager;
BOOL bGetGotoTextScript, bGetActivateTextScript, bGetDeactivateTextScript,
	 bGetFieldTextScript, bGetActorTextScript, bGetItemSuccessTextScript,
	 bGetItemFailedTextScript;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
void OpenTSE(HWND);
LRESULT CALLBACK TSEProc(HWND, UINT, WPARAM, LPARAM);
void UpdateTextScriptTree(BOOL);
void UpdateTextScriptSelection(void);
void TSEFillTextList(HWND, TEXT_SCRIPT_MANAGER *);
LRESULT CALLBACK TSETextProc(HWND, UINT, WPARAM, LPARAM);
void UpdateTSEText(void);
LRESULT CALLBACK TSEGeneralProc(HWND, UINT, WPARAM, LPARAM);
void UpdateTSEGeneral(void);
LRESULT CALLBACK TSEActivateProc(HWND, UINT, WPARAM, LPARAM);
void UpdateTSEActivate(void);
LRESULT CALLBACK TSEItemsProc(HWND, UINT, WPARAM, LPARAM);
void UpdateTSEItems(void);
///////////////////////////////////////////////////////////////////////////////


void OpenTSE(HWND hWnd)
{ // begin OpenTSE()
	if(!pLevel)
		return;
	DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_TSE), hWnd, (DLGPROC) TSEProc);
} // end OpenTSE()
BOOL bTest;
LRESULT CALLBACK TSEProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin TSEProc()
	pTextScriptManager = &pLevel->TextScriptManager;
	TEXT_SCRIPT *pTextScriptTT, *pTextScriptTTT, *pParentTextScriptT;
    char byTemp[256], *pbyTemp;
	TC_ITEM tie; 
	HWND hWndTab;
	TV_ITEM tvi;
	NODEINFO *pni;
	int i, i2;

	switch(iMessage)
    {
		case WM_INITDIALOG:
				bTest = FALSE;
				_AS->WriteLogMessage("Open text script editor");
				hWndTSE = hWnd;
				pTextScriptT = &pTextScriptManager->TextScriptRoot;
				// Icons:
				// Load:
				SendDlgItemMessage(hWnd, IDC_TSE_LOAD_TEXTS, BM_SETIMAGE, (WPARAM) IMAGE_ICON,
								   (LPARAM) LoadImage(_AS->GetInstance(), MAKEINTRESOURCE(IDI_AS_OPEN), IMAGE_ICON, 12, 12, LR_DEFAULTCOLOR));
				// Save:
				SendDlgItemMessage(hWnd, IDC_TSE_SAVE_TEXTS, BM_SETIMAGE, (WPARAM) IMAGE_ICON,
								   (LPARAM) LoadImage(_AS->GetInstance(), MAKEINTRESOURCE(IDI_AS_SAVE), IMAGE_ICON, 12, 12, LR_DEFAULTCOLOR));
				// Texts:
				SetWindowText(hWnd, AS_T(T_TextScriptEditor));
				
				SetDlgItemText(hWnd, IDC_TSE_TEXT_FILE, AS_T(T_TextFile));
				SetDlgItemText(hWnd, IDC_TSE_OPEN_TEXT_FILE, AS_T(T_Open));
				SetDlgItemText(hWnd, IDC_TSE_UPDATE, AS_T(T_Update));
				SetDlgItemText(hWnd, IDC_TSE_OK, AS_T(T_Ok));
				SetDlgItemText(hWnd, IDC_TSE_OPEN_ALL, AS_T(T_OpenAll));
				SetDlgItemText(hWnd, IDC_TSE_CLOSE_ALL, AS_T(T_CloseAll));
				SetDlgItemText(hWnd, IDC_TSE_ADD, AS_T(T_Add));
				SetDlgItemText(hWnd, IDC_TSE_DELETE, AS_T(T_Delete));
				SetDlgItemText(hWnd, IDC_TSE_MOVE_UP, AS_T(T_Up));
				SetDlgItemText(hWnd, IDC_TSE_MOVE_DOWN, AS_T(T_Down));
				SetDlgItemText(hWnd, IDC_TSE_SELECTED_TEXT_T, AS_T(T_SelectedText));
												
				// Create the text script tree:
				hWndTSETree = CreateWindowEx(WS_EX_CLIENTEDGE, WC_TREEVIEW, "",
											 WS_VISIBLE | WS_CHILD | WS_BORDER | TVS_HASLINES |
											 TVS_HASBUTTONS | TVS_LINESATROOT,
											 2, 40, 730, 290, hWnd, NULL, _AS->GetInstance(), NULL);

				// Setup tabs:
				iCurrentTSETab = -1;
				// Setup editor tabs:
				hWndTab = GetDlgItem(hWnd, IDC_TSE_TAB);
				TabCtrl_DeleteAllItems(hWndTab);
				tie.mask = TCIF_TEXT;
				// Text:
				tie.pszText	= AS_T(T_Text);
				TabCtrl_InsertItem(hWndTab, TAB_TSE_TEXT, &tie);
				if(hWndTSETab[TAB_TSE_TEXT])
					DestroyWindow(hWndTSETab[TAB_TSE_TEXT]);
				hWndTSETab[TAB_TSE_TEXT] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_TSE_TEXT), hWndTab, (DLGPROC) TSETextProc, WM_INITDIALOG);
				
				// General:
				tie.pszText	= AS_T(T_General);
				TabCtrl_InsertItem(hWndTab, TAB_TSE_GENERAL, &tie);
				if(hWndTSETab[TAB_TSE_GENERAL])
					DestroyWindow(hWndTSETab[TAB_TSE_GENERAL]);
				hWndTSETab[TAB_TSE_GENERAL] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_TSE_GENERAL), hWndTab, (DLGPROC) TSEGeneralProc, WM_INITDIALOG);

				// Activate:
				tie.pszText	= AS_T(T_Activate);
				TabCtrl_InsertItem(hWndTab, TAB_TSE_ACTIVATE, &tie);
				if(hWndTSETab[TAB_TSE_ACTIVATE])
					DestroyWindow(hWndTSETab[TAB_TSE_ACTIVATE]);
				hWndTSETab[TAB_TSE_ACTIVATE] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_TSE_ACTIVATE), hWndTab, (DLGPROC) TSEActivateProc, WM_INITDIALOG);
				// Items:
				tie.pszText	= AS_T(T_Items);
				TabCtrl_InsertItem(hWndTab, TAB_TSE_ITEMS, &tie);
				if(hWndTSETab[TAB_TSE_ITEMS])
					DestroyWindow(hWndTSETab[TAB_TSE_ITEMS]);
				hWndTSETab[TAB_TSE_ITEMS] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_TSE_ITEMS), hWndTab, (DLGPROC) TSEItemsProc, WM_INITDIALOG);
				//
				TabCtrl_SetCurSel(GetDlgItem(hWnd, IDC_TSE_TAB), 0);
				SendMessage(hWnd, WM_NOTIFY, IDC_TSE_TAB, 0);

				UpdateTextScriptTree(TRUE);
				UpdateTextScriptSelection();

				ShowWindow(hWnd, _AS->GetCmdShow());
				UpdateWindow(hWnd);
				bTest = TRUE;
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_TSE_OK: SendMessage(hWnd, WM_CLOSE, 0, 0); return TRUE;

				case IDC_TSE_LOAD_TEXTS:
					sprintf(byTemp, "%s%s", _AS->byProgramPath, _AS->bySingleLevelsDirectory);
					pbyTemp = ASGetFileName(hWnd, AS_T(T_LoadTextFile), TXT_FILE, 0, FALSE, byTemp, NULL);
					if(!pbyTemp)
						break;
					// Cut off the main path:
					strcpy(byTemp, &pbyTemp[strlen(_AS->byProgramPath)]);
					pTextScriptManager->LoadTextsFromFile(byTemp);
					TSEFillTextList(hWnd, pTextScriptManager);
					UpdateTextScriptTree(TRUE);
				break;

				case IDC_TSE_SAVE_TEXTS:
					sprintf(byTemp, "%s%s", _AS->byProgramPath, _AS->bySingleLevelsDirectory);
					pbyTemp = ASGetFileName(hWnd, AS_T(T_SaveTextFile), TXT_FILE, 1, FALSE, byTemp, NULL);
					if(!pbyTemp)
						break;
					// Cut off the main path:
					strcpy(byTemp, &pbyTemp[strlen(_AS->byProgramPath)]);
					pTextScriptManager->SaveTexts(byTemp);
				break;
				
				case IDC_TSE_OPEN_TEXT_FILE:
					sprintf(byTemp, "%s%s", _AS->byProgramPath, pTextScriptManager->byTextFilename);
					ShellExecute(0, "open", byTemp, 0, 0, SW_SHOW);
				break;

				case IDC_TSE_UPDATE:
					pTextScriptManager->UpdateTextsFromFile();
					TSEFillTextList(hWnd, pTextScriptManager);
					UpdateTextScriptTree(TRUE);
				break;

				case IDC_TSE_OPEN_ALL: pTextScriptManager->SetAllTreeElementState(TRUE, hWndTSETree); break;
				case IDC_TSE_CLOSE_ALL: pTextScriptManager->SetAllTreeElementState(FALSE, hWndTSETree); break;

				case IDC_TSE_ADD:
					pTextScriptT->AddTextScript();
					pTextScriptManager->UpdateIDs();
					TSEFillTextList(hWnd, pTextScriptManager);
					UpdateTextScriptTree(TRUE);
				break;

				case IDC_TSE_DELETE:
					if(!pTextScriptT)
						break;
					pLevel->TextScriptIsDeleted(pTextScriptT, 0);
					if((pTextScriptTT = pTextScriptManager->DeleteTextScript(pTextScriptT->iID)))
						pTextScriptT = pTextScriptTT;
					UpdateTextScriptTree(TRUE);
				break;

				case IDC_TSE_MOVE_UP:
					if(!pTextScriptT->iChildID)
						break;
					i = pTextScriptT->iChildID;
					pParentTextScriptT = pTextScriptT->pParentTextScript;
					pTextScriptTT = pParentTextScriptT->pTextScript[i-1];
					pParentTextScriptT->pTextScript[i-1] =
					pParentTextScriptT->pTextScript[i];
					pParentTextScriptT->pTextScript[i] = pTextScriptTT;
					pTextScriptT->iChildID--;
					pTextScriptTT->iChildID++;
					UpdateTextScriptTree(TRUE);
				break;

				case IDC_TSE_MOVE_DOWN:
					if(!pTextScriptT->pParentTextScript ||
					   pTextScriptT->iChildID+1 >= pTextScriptT->pParentTextScript->iTextScripts)
						break;
					i = pTextScriptT->iChildID;
					pParentTextScriptT = pTextScriptT->pParentTextScript;
					pTextScriptTT = pParentTextScriptT->pTextScript[i+1];
					pParentTextScriptT->pTextScript[i+1] =
					pParentTextScriptT->pTextScript[i];
					pParentTextScriptT->pTextScript[i] = pTextScriptTT;
					pTextScriptT->iChildID++;
					pTextScriptTT->iChildID--;
					UpdateTextScriptTree(TRUE);
				break;
			}
        break;

        case WM_NOTIFY:
			switch(wParam)
			{
				case IDC_TSE_TAB:
					i = TabCtrl_GetCurSel(GetDlgItem(hWnd, IDC_TSE_TAB));
					iCurrentTSETab = i;
					if(iCurrentTSETab < 0)
						iCurrentTSETab = 0;
					for(i2 = 0; i2 < TSE_TABS; i2++)
					{
						ShowWindow(hWndTSETab[i2], SW_HIDE);
						UpdateWindow(hWndTSETab[i2]);
					}
					TabCtrl_SetCurSel(GetDlgItem(hWnd, IDC_TSE_TAB), iCurrentTSETab);
					ShowWindow(hWndTSETab[iCurrentTSETab], SW_SHOW);
					UpdateWindow(hWndTSETab[iCurrentTSETab]);
					UpdateWindow(hWnd);
					SetFocus(hWndTSETab[iCurrentTSETab]);
					SendMessage(hWndTSETab[iCurrentTSETab], WM_INITDIALOG, 0, 0);
				break;
			} 
            if(!lParam)
				break;
			if(((NMHDR *) lParam)->hwndFrom != hWndTSETree ||
			    ((NMHDR * )lParam)->code != TVN_SELCHANGED)
				break;
			
			// Get lParam of current tree node:
			tvi.hItem  = TreeView_GetSelection(hWndTSETree);
			tvi.mask   = TVIF_PARAM;
			tvi.lParam = 0;
			TreeView_GetItem(hWndTSETree, &tvi);
			pni = (NODEINFO *) tvi.lParam;

			// Get the pointer to the selected text script:
			pTextScriptTTT = pTextScriptT;
			if(pni)
			{
				if(!(pTextScriptTT = pTextScriptManager->GetTextScriptIDPointer(pni->lParam1)))
					pTextScriptTT = &pTextScriptManager->TextScriptRoot; // There was an error!
				if(bGetFieldTextScript && bTest)
				{
					i = SendDlgItemMessage(hWndEditorSelectTab[TAB_EDITOR_SELECT_SCRIPTS], IDD_EDITOR_SELECT_LIST, CB_GETCURSEL, 0, 0L);
					pLevel->pCurrentField->pTextScript[i] = pTextScriptTT;
					bGetFieldTextScript = FALSE;
					SendMessage(hWnd, WM_CLOSE, 0, 0);
					break;
				}
				else
				if(bGetActorTextScript && bTest)
				{
					if(pLevel->pCurrentField->pActor)
					{
						pLevel->pCurrentField->pActor->pTextScript = pTextScriptTT;
						bGetActorTextScript = FALSE;
						SendMessage(hWnd, WM_CLOSE, 0, 0);
						break;
					}
				}
				else
				if(bGetGotoTextScript)
				{
					pTextScriptT->pGotoTextScript = pTextScriptTT;
					bGetGotoTextScript = FALSE;
					UpdateTSEGeneral();
					break;
				}
				else
				if(bGetItemSuccessTextScript)
				{
					if(!SendDlgItemMessage(hWndTSETab[TAB_TSE_ITEMS], IDC_TSE_ITEM_STATE, CB_GETCURSEL, 0, 0L))
						pTextScriptT->pGotoAddItemSuccess = pTextScriptTT;
					else
						pTextScriptT->pGotoTakeItemSuccess = pTextScriptTT;
					bGetItemSuccessTextScript = FALSE;
					UpdateTSEItems();
				}
				else
				if(bGetItemFailedTextScript)
				{
					if(!SendDlgItemMessage(hWndTSETab[TAB_TSE_ITEMS], IDC_TSE_ITEM_STATE, CB_GETCURSEL, 0, 0L))
						pTextScriptT->pGotoAddItemFailed = pTextScriptTT;
					else
						pTextScriptT->pGotoTakeItemFailed = pTextScriptTT;
					bGetItemFailedTextScript = FALSE;
					UpdateTSEItems();
				}
				else
				if(bGetActivateTextScript)
				{
					bGetActivateTextScript = FALSE;
					i = (int) SendDlgItemMessage(hWndTSETab[TAB_TSE_ACTIVATE], IDC_TSE_ACTIVATE_TEXT_LIST, LB_GETCURSEL, 0, 0L);
					if(i < 0 || i > pTextScriptT->iActivateTextScripts)
						break;
					pTextScriptT->pActivateTextScript[i] = pTextScriptTT;
					UpdateTSEActivate();
					break;
				}
				else
				if(bGetDeactivateTextScript)
				{
					bGetDeactivateTextScript = FALSE;
					i = (int) SendDlgItemMessage(hWndTSETab[TAB_TSE_ACTIVATE], IDC_TSE_ACTIVATE_DE_TEXT_LIST, LB_GETCURSEL, 0, 0L);
					if(i < 0 || i > pTextScriptT->iDeactivateTextScripts)
						break;
					pTextScriptT->pDeactivateTextScript[i] = pTextScriptTT;
					UpdateTSEActivate();
					break;
				}
				else
					pTextScriptT = pTextScriptTT;
			}
			if(pTextScriptTTT != pTextScriptT)
				UpdateTextScriptSelection();
		break;

		case WM_CLOSE: case WM_DESTROY:
			_AS->WriteLogMessage("Close text script editor");
			DestroyWindow(hWndTSETree);
			hWndTSETree = hWndTSE = NULL;
			SendMessage(hWndEditorTab[iCurrentEditorTab], WM_INITDIALOG, 0, 0);
			EndDialog(hWnd, FALSE);
		break;
    }

    return FALSE;
} // end TSEProc()

// Create the text script tree:
void UpdateTextScriptTree(BOOL bUpdate)
{ // begin UpdateTextScriptTree()
	pTextScriptManager->GetTreeElementState(hWndTSETree);
	pTextScriptManager->DeleteTreeElement(hWndTSETree);
	pTextScriptManager->FillTreeElement(hWndTSETree);
	TreeView_Select(hWndTSETree, pTextScriptT->hItem, TVGN_CARET);
	if(bUpdate)
		UpdateTextScriptSelection();
} // end UpdateTextScriptTree()

void UpdateTextScriptSelection(void)
{ // begin UpdateTextScriptSelection()
	char byTemp[256];

	UpdateTSEText();
	UpdateTSEGeneral();
	UpdateTSEActivate();
	UpdateTSEItems();

	sprintf(byTemp, "ID: %d", pTextScriptT->iID);
	SetDlgItemText(hWndTSE, IDC_TSE_ID, byTemp);

	sprintf(byTemp, "CID: %d", pTextScriptT->iChildID);
	SetDlgItemText(hWndTSE, IDC_TSE_CID, byTemp);
} // end UpdateTextScriptSelection()

// Fill the text list:
void TSEFillTextList(HWND hWnd, TEXT_SCRIPT_MANAGER *pTextScriptManager)
{ // begin TSEFillTextList()
	char byTemp[TS_LENGTH+50];

	SendDlgItemMessage(hWnd, IDC_TSE_TEXT_LIST, CB_RESETCONTENT , 0, 0L);
	SendDlgItemMessage(hWnd, IDC_TSE_TEXT_LIST, CB_ADDSTRING, 0, (LPARAM) AS_T(T_NoText));
	for(int i = 0; i < pTextScriptManager->iTexts; i++)
	{
		sprintf(byTemp, "%d: %s", i, pTextScriptManager->pbyText[i]);
		SendDlgItemMessage(hWnd, IDC_TSE_TEXT_LIST, CB_ADDSTRING, 0, (LPARAM) byTemp);
	}
	SendDlgItemMessage(hWnd, IDC_TSE_TEXT_LIST, CB_SETCURSEL, 0, 0);
} // end TSEFillTextList()

LRESULT CALLBACK TSETextProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin TSETextProc()
	int i;

	switch(iMessage)
    {
        case WM_INITDIALOG:
			// Texts:
			SetDlgItemText(hWnd, IDC_TSE_TEXT_SET, AS_T(T_Set));
			SetDlgItemText(hWnd, IDC_TSE_TEXT_ADD, AS_T(T_Add));
			SetDlgItemText(hWnd, IDC_TSE_TEXT_DELETE, AS_T(T_Delete));
			SetDlgItemText(hWnd, IDC_TSE_GOTO, AS_T(T_Goto));
			SetDlgItemText(hWnd, IDC_TSE_SET_GOTO, AS_T(T_Set));
			
			UpdateTSEText();

			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
			BringWindowToTop(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_TSE_TEXT_LIST:
					i = (int) SendDlgItemMessage(hWnd, IDC_TSE_TEXT_LIST, CB_GETCURSEL, 0, 0L);
					if(i < 0 || i-1 > pTextScriptManager->iTexts)
						break;
				    pTextScriptT->iText = i-1;
					UpdateTextScriptTree(FALSE);
				break;

				case IDC_TSE_TEXT_ADD: pTextScriptManager->AddText(); TSEFillTextList(hWnd, pTextScriptManager); break;

				case IDC_TSE_TEXT_DELETE:
					i = (int) SendDlgItemMessage(hWnd, IDC_TSE_TEXT_LIST, CB_GETCURSEL, 0, 0L);
					i--;
					if(i < 0 || i > pTextScriptManager->iTexts)
						break;
					pTextScriptManager->DeleteText(i);
					UpdateTextScriptTree(TRUE);
				break;

				case IDC_TSE_TEXT_SET:
					if(pTextScriptT->iText == -1)
						break;
					GetDlgItemText(hWnd, IDC_TSE_TEXT, pTextScriptManager->pbyText[pTextScriptT->iText], TS_LENGTH);
					UpdateTextScriptTree(TRUE);
				break;
			}
        break;
    }
    return FALSE;
} // end TSETextProc()

void UpdateTSEText(void)
{ // begin UpdateTSEText()
	HWND hWnd = hWndTSETab[TAB_TSE_TEXT];

	if(pTextScriptT->iText != -1 && pTextScriptT->iText >= pTextScriptManager->iTexts)
		SetDlgItemText(hWnd, IDC_TSE_TEXT, pTextScriptManager->pbyText[pTextScriptT->iText]);
	TSEFillTextList(hWnd, pTextScriptManager);
	SendDlgItemMessage(hWnd, IDC_TSE_TEXT_LIST, CB_SETCURSEL, pTextScriptT->iText+1, 0);
} // end UpdateTSEText()

LRESULT CALLBACK TSEGeneralProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin TSEGeneralProc()
	char byTemp[256];
	int i;

	switch(iMessage)
    {
        case WM_INITDIALOG:
			// Texts:
			SetDlgItemText(hWnd, IDC_TSE_ACTIVE, AS_T(T_Active));
			SetDlgItemText(hWnd, IDC_TSE_DEACTIVATE, AS_T(T_Deactivate));
			SetDlgItemText(hWnd, IDC_TSE_MOVEMENT_POSSIBLE, AS_T(T_MovementPossible));
			SetDlgItemText(hWnd, IDC_TSE_SKIP_POSSIBLE, AS_T(T_SkipPossible));
			SetDlgItemText(hWnd, IDC_TSE_CHOICE, AS_T(T_Choice));
			SetDlgItemText(hWnd, IDC_TSE_RANDOM_CHOICE, AS_T(T_RandomChoice));
			SetDlgItemText(hWnd, IDC_TSE_WAIT_T, AS_T(T_Wait));
			SetDlgItemText(hWnd, IDC_TSE_END_DIALOG, AS_T(T_EndDialog));

			SetDlgItemText(hWnd, IDC_TSE_CAMERA, AS_T(T_Camera));
			SetDlgItemText(hWnd, IDC_TSE_CAMERA_LOOP, AS_T(T_Loop));

			SetDlgItemText(hWnd, IDC_TSE_TALK_ANIMATION, AS_T(T_TalkAnimation));
			SetDlgItemText(hWnd, IDC_TSE_ACTOR_T, AS_T(T_Actor));
			SetDlgItemText(hWnd, IDC_TSE_ACTOR_AGGRESSIVE, AS_T(T_Aggressive));
			SetDlgItemText(hWnd, IDC_TSE_ACTOR_SMALL, AS_T(T_Small));
			SetDlgItemText(hWnd, IDC_TSE_ACTOR_GUARDIAN, AS_T(T_Guardian));
			SetDlgItemText(hWnd, IDC_TSE_ACTOR_MOBILE, AS_T(T_Mobile));
			SetDlgItemText(hWnd, IDC_TSE_ACTOR_FOLLOW, AS_T(T_Follow));
			
			UpdateTSEGeneral();
			
			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
			BringWindowToTop(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_TSE_ACTIVE: pTextScriptT->bActive = SendDlgItemMessage(hWnd, IDC_TSE_ACTIVE, BM_GETCHECK, 0, 0L); break;
				case IDC_TSE_DEACTIVATE: pTextScriptT->bDeactivate = SendDlgItemMessage(hWnd, IDC_TSE_DEACTIVATE, BM_GETCHECK, 0, 0L); break;
				case IDC_TSE_MOVEMENT_POSSIBLE: pTextScriptT->bMovementPossible = SendDlgItemMessage(hWnd, IDC_TSE_MOVEMENT_POSSIBLE, BM_GETCHECK, 0, 0L); UpdateTSEGeneral(); break;
				case IDC_TSE_SKIP_POSSIBLE: pTextScriptT->bSkipPossible = SendDlgItemMessage(hWnd, IDC_TSE_SKIP_POSSIBLE, BM_GETCHECK, 0, 0L); break;

				case IDC_TSE_CHOICE:
					pTextScriptT->bChoice = SendDlgItemMessage(hWnd, IDC_TSE_CHOICE, BM_GETCHECK, 0, 0L);
					if(pTextScriptT->bChoice)
					{
						pTextScriptT->bRandomChoice = FALSE;
						SendDlgItemMessage(hWnd, IDC_TSE_RANDOM_CHOICE, BM_SETCHECK, pTextScriptT->bRandomChoice, 0L);
					}
				break;

				case IDC_TSE_RANDOM_CHOICE:
					pTextScriptT->bRandomChoice = SendDlgItemMessage(hWnd, IDC_TSE_RANDOM_CHOICE, BM_GETCHECK, 0, 0L);
					if(pTextScriptT->bRandomChoice)
					{
						pTextScriptT->bChoice = FALSE;
						SendDlgItemMessage(hWnd, IDC_TSE_CHOICE, BM_SETCHECK, pTextScriptT->bChoice, 0L);
					}
				break;

				case IDC_TSE_END_DIALOG: pTextScriptT->bEndDialog = SendDlgItemMessage(hWnd, IDC_TSE_END_DIALOG, BM_GETCHECK, 0, 0L); break;

				case IDC_TSE_SURFACE_LIST:
					i = (int) SendDlgItemMessage(hWnd, IDC_TSE_SURFACE_LIST, CB_GETCURSEL, 0, 0L);
					if(i < 0 || i > pLevel->Header.iSurfaces)
						break;
				    pTextScriptT->iSurface = i-1;
				break;

				case IDC_TSE_WAIT:
					GetDlgItemText(hWnd, IDC_TSE_WAIT, byTemp, 256);
					pTextScriptT->lWaitTime = (long) atoi(byTemp);
				break;

				case IDC_TSE_GOTO: pTextScriptT->bGoto = SendDlgItemMessage(hWnd, IDC_TSE_GOTO, BM_GETCHECK, 0, 0L); UpdateTSEGeneral(); break;
				case IDC_TSE_SET_GOTO: bGetGotoTextScript = TRUE; break;
				
				case IDC_TSE_CAMERA_LIST:
					i = (int) SendDlgItemMessage(hWnd, IDC_TSE_CAMERA_LIST, CB_GETCURSEL, 0, 0L);
					if(i < 0 || i >= pLevel->Header.iCameraScripts)
						break;
					pTextScriptT->iCameraScript = i;
				break;
				
				case IDC_TSE_TALK_ANIMATION: pTextScriptT->bTalkAnimation = SendDlgItemMessage(hWnd, IDC_TSE_TALK_ANIMATION, BM_GETCHECK, 0, 0L); break;
				case IDC_TSE_CAMERA: pTextScriptT->bCameraScript = SendDlgItemMessage(hWnd, IDC_TSE_CAMERA, BM_GETCHECK, 0, 0L); break;
				case IDC_TSE_CAMERA_LOOP: pTextScriptT->bCameraScriptLoop = SendDlgItemMessage(hWnd, IDC_TSE_CAMERA_LOOP, BM_GETCHECK, 0, 0L); break;

				case IDC_TSE_ACTOR_AGGRESSIVE: pTextScriptT->bActorAggressive = SendDlgItemMessage(hWnd, IDC_TSE_ACTOR_AGGRESSIVE, BM_GETCHECK, 0, 0L); break;
				case IDC_TSE_ACTOR_SMALL: pTextScriptT->bActorSmall = SendDlgItemMessage(hWnd, IDC_TSE_ACTOR_SMALL, BM_GETCHECK, 0, 0L); break;
				case IDC_TSE_ACTOR_GUARDIAN: pTextScriptT->bActorGuardian = SendDlgItemMessage(hWnd, IDC_TSE_ACTOR_GUARDIAN, BM_GETCHECK, 0, 0L); break;
				case IDC_TSE_ACTOR_MOBILE: pTextScriptT->bActorMobile = SendDlgItemMessage(hWnd, IDC_TSE_ACTOR_MOBILE, BM_GETCHECK, 0, 0L); break;
				case IDC_TSE_ACTOR_FOLLOW: pTextScriptT->bActorFollow = SendDlgItemMessage(hWnd, IDC_TSE_ACTOR_FOLLOW, BM_GETCHECK, 0, 0L); break;
			}
        break;
    }
    return FALSE;
} // end TSEGeneralProc()

void UpdateTSEGeneral(void)
{ // begin UpdateTSEGeneral()
	HWND hWnd = hWndTSETab[TAB_TSE_GENERAL];
	char byTemp[256];
	BOOL bSet;
	int i;

	SendDlgItemMessage(hWnd, IDC_TSE_ACTIVE, BM_SETCHECK, pTextScriptT->bActive, 0L);
	SendDlgItemMessage(hWnd, IDC_TSE_DEACTIVATE, BM_SETCHECK, pTextScriptT->bDeactivate, 0L);
	SendDlgItemMessage(hWnd, IDC_TSE_MOVEMENT_POSSIBLE, BM_SETCHECK, pTextScriptT->bMovementPossible, 0L);
	EnableWindow(GetDlgItem(hWnd, IDC_TSE_SKIP_POSSIBLE), !pTextScriptT->bMovementPossible);
	SendDlgItemMessage(hWnd, IDC_TSE_SKIP_POSSIBLE, BM_SETCHECK, pTextScriptT->bSkipPossible, 0L);
	SendDlgItemMessage(hWnd, IDC_TSE_CHOICE, BM_SETCHECK, pTextScriptT->bChoice, 0L);
	SendDlgItemMessage(hWnd, IDC_TSE_RANDOM_CHOICE, BM_SETCHECK, pTextScriptT->bRandomChoice, 0L);
	SendDlgItemMessage(hWnd, IDC_TSE_END_DIALOG, BM_SETCHECK, pTextScriptT->bEndDialog, 0L);
	
	sprintf(byTemp, "%d", pTextScriptT->lWaitTime);
	SetDlgItemText(hWnd, IDC_TSE_WAIT, byTemp);
	
	// Fill the surfaces list:
	SendDlgItemMessage(hWnd, IDC_TSE_SURFACE_LIST, CB_RESETCONTENT , 0, 0L);
	sprintf(byTemp, " - %s", AS_T(T_NoSurface));
	SendDlgItemMessage(hWnd, IDC_TSE_SURFACE_LIST, CB_ADDSTRING, 0, (LPARAM) byTemp);
	for(i = 0; i < pLevel->Header.iSurfaces; i++)
	{
		sprintf(byTemp, "%s", pLevel->pSurface[i].Header.byName);
		SendDlgItemMessage(hWnd, IDC_TSE_SURFACE_LIST, CB_ADDSTRING, 0, (LPARAM) byTemp);
	}
	if(pTextScriptT->iSurface == -1)
		SendDlgItemMessage(hWnd, IDC_TSE_SURFACE_LIST, CB_SETCURSEL, 0, 0);
	else
		SendDlgItemMessage(hWnd, IDC_TSE_SURFACE_LIST, CB_SETCURSEL, pTextScriptT->iSurface+1, 0);

	// Goto:
	SendDlgItemMessage(hWnd, IDC_TSE_GOTO, BM_SETCHECK, pTextScriptT->bGoto, 0L);
	pTextScriptT->pManager->FillTextScriptView(pTextScriptT->pGotoTextScript, hWnd, IDC_TSE_GOTO_T);
	EnableWindow(GetDlgItem(hWnd, IDC_TSE_SET_GOTO), pTextScriptT->bGoto);

	// Camera:
	SendDlgItemMessage(hWnd, IDC_TSE_CAMERA_LIST, CB_RESETCONTENT, 0, 0L);
	for(i = 0; i < pLevel->Header.iCameraScripts; i++)
	{
		sprintf(byTemp, "%s", pLevel->pCameraScript[i].byName);
		SendDlgItemMessage(hWnd, IDC_TSE_CAMERA_LIST, CB_ADDSTRING, 0, (LPARAM) byTemp);
	}
	SendDlgItemMessage(hWnd, IDC_TSE_CAMERA_LIST, CB_SETCURSEL, pTextScriptT->iCameraScript, 0L);
	if(!pLevel->Header.iCameraScripts)
	{
		bSet = FALSE;
		pTextScriptT->bCameraScript = FALSE;
	}
	else
		bSet = TRUE;
	EnableWindow(GetDlgItem(hWnd, IDC_TSE_CAMERA), bSet);
	EnableWindow(GetDlgItem(hWnd, IDC_TSE_CAMERA_LOOP), bSet);
	EnableWindow(GetDlgItem(hWnd, IDC_TSE_CAMERA_LIST), bSet);

	SendDlgItemMessage(hWnd, IDC_TSE_TALK_ANIMATION, BM_SETCHECK, pTextScriptT->bTalkAnimation, 0L);

	SendDlgItemMessage(hWnd, IDC_TSE_CAMERA, BM_SETCHECK, pTextScriptT->bCameraScript, 0L);
	SendDlgItemMessage(hWnd, IDC_TSE_CAMERA_LOOP, BM_SETCHECK, pTextScriptT->bCameraScriptLoop, 0L);
	SendDlgItemMessage(hWnd, IDC_TSE_ACTOR_AGGRESSIVE, BM_SETCHECK, pTextScriptT->bActorAggressive, 0L);
	SendDlgItemMessage(hWnd, IDC_TSE_ACTOR_SMALL, BM_SETCHECK, pTextScriptT->bActorSmall, 0L);
	SendDlgItemMessage(hWnd, IDC_TSE_ACTOR_GUARDIAN, BM_SETCHECK, pTextScriptT->bActorGuardian, 0L);
	SendDlgItemMessage(hWnd, IDC_TSE_ACTOR_MOBILE, BM_SETCHECK, pTextScriptT->bActorMobile, 0L);
	SendDlgItemMessage(hWnd, IDC_TSE_ACTOR_FOLLOW, BM_SETCHECK, pTextScriptT->bActorFollow, 0L);
} // end UpdateTSEGeneral()

LRESULT CALLBACK TSEActivateProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin TSEActivateProc()
	int i;

	switch(iMessage)
    {
        case WM_INITDIALOG:
			// Texts:
			SetDlgItemText(hWnd, IDC_TSE_ACTIVATE_TEXT_SCRIPT_T, AS_T(T_ActivateTextScript));
			SetDlgItemText(hWnd, IDC_TSE_ACTIVATE_TEXT_ADD, AS_T(T_Add));
			SetDlgItemText(hWnd, IDC_TSE_ACTIVATE_TEXT_DELETE, AS_T(T_Delete));
			SetDlgItemText(hWnd, IDC_TSE_ACTIVATE_TEXT_SET, AS_T(T_Set));

			SetDlgItemText(hWnd, IDC_TSE_ACTIVATE_DE_TEXT_SCRIPT_T, AS_T(T_DeactivateTextScript));
			SetDlgItemText(hWnd, IDC_TSE_ACTIVATE_DE_TEXT_ADD, AS_T(T_Add));
			SetDlgItemText(hWnd, IDC_TSE_ACTIVATE_DE_TEXT_DELETE, AS_T(T_Delete));
			SetDlgItemText(hWnd, IDC_TSE_ACTIVATE_DE_TEXT_SET, AS_T(T_Set));

			UpdateTSEActivate();

			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
			BringWindowToTop(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_TSE_ACTIVATE_TEXT_ADD:
					pTextScriptT->iActivateTextScripts++;
					pTextScriptT->pActivateTextScript = (TEXT_SCRIPT **) realloc(pTextScriptT->pActivateTextScript, sizeof(TEXT_SCRIPT *)*pTextScriptT->iActivateTextScripts);
					pTextScriptT->pActivateTextScript[pTextScriptT->iActivateTextScripts-1] = NULL;
					UpdateTSEActivate();
				break;

				case IDC_TSE_ACTIVATE_TEXT_DELETE:
					i = (int) SendDlgItemMessage(hWnd, IDC_TSE_ACTIVATE_TEXT_LIST, LB_GETCURSEL, 0, 0L);
					if(i < 0 || i > pTextScriptT->iActivateTextScripts)
						break;
					for(; i < pTextScriptT->iActivateTextScripts-1; i++)
						pTextScriptT->pActivateTextScript[i] = pTextScriptT->pActivateTextScript[i+1];
					pTextScriptT->iActivateTextScripts--;
					pTextScriptT->pActivateTextScript = (TEXT_SCRIPT **) realloc(pTextScriptT->pActivateTextScript, sizeof(TEXT_SCRIPT *)*pTextScriptT->iActivateTextScripts);
					UpdateTSEActivate();
				break;

				case IDC_TSE_ACTIVATE_TEXT_SET: bGetActivateTextScript = TRUE; break;


				case IDC_TSE_ACTIVATE_DE_TEXT_ADD:
					pTextScriptT->iDeactivateTextScripts++;
					pTextScriptT->pDeactivateTextScript = (TEXT_SCRIPT **) realloc(pTextScriptT->pDeactivateTextScript, sizeof(TEXT_SCRIPT *)*pTextScriptT->iDeactivateTextScripts);
					pTextScriptT->pDeactivateTextScript[pTextScriptT->iDeactivateTextScripts-1] = NULL;
					UpdateTSEActivate();
				break;

				case IDC_TSE_ACTIVATE_DE_TEXT_DELETE:
					i = (int) SendDlgItemMessage(hWnd, IDC_TSE_ACTIVATE_DE_TEXT_LIST, LB_GETCURSEL, 0, 0L);
					if(i < 0 || i > pTextScriptT->iDeactivateTextScripts)
						break;
					for(; i < pTextScriptT->iDeactivateTextScripts-1; i++)
						pTextScriptT->pDeactivateTextScript[i] = pTextScriptT->pDeactivateTextScript[i+1];
					pTextScriptT->iDeactivateTextScripts--;
					pTextScriptT->pDeactivateTextScript = (TEXT_SCRIPT **) realloc(pTextScriptT->pDeactivateTextScript, sizeof(TEXT_SCRIPT *)*pTextScriptT->iDeactivateTextScripts);
					UpdateTSEActivate();
				break;

				case IDC_TSE_ACTIVATE_DE_TEXT_SET: bGetDeactivateTextScript = TRUE; break;
			}
        break;
    }
    return FALSE;
} // end TSEActivateProc()

void UpdateTSEActivate(void)
{ // begin UpdateTSEActivate()
	HWND hWnd = hWndTSETab[TAB_TSE_ACTIVATE];
	TEXT_SCRIPT *pTextScriptTT;
	char byTemp[TS_LENGTH+50];
	int i, i2;

	// Activate list:
	i2 = (int) SendDlgItemMessage(hWnd, IDC_TSE_ACTIVATE_TEXT_LIST, LB_GETCURSEL, 0, 0L);
	if(i2 < 0 || i2 > pTextScriptT->iActivateTextScripts)
		i2 = 0;
	SendDlgItemMessage(hWnd, IDC_TSE_ACTIVATE_TEXT_LIST, LB_RESETCONTENT, 0, 0L);
	for(i = 0; i < pTextScriptT->iActivateTextScripts; i++)
	{
		pTextScriptTT = pTextScriptT->pActivateTextScript[i];
		if(!pTextScriptTT)
			sprintf(byTemp, "%s", AS_T(T_NoTextScript));
		else
		if(pTextScriptTT->iText == -1)
			sprintf(byTemp, "(%d)  %s", pTextScriptTT->iID, AS_T(T_NoText));
		else
			sprintf(byTemp, "(%d)  %d: %s", pTextScriptTT->iID, pTextScriptTT->iText, pTextScriptManager->pbyText[pTextScriptTT->iText]);
		SendDlgItemMessage(hWnd, IDC_TSE_ACTIVATE_TEXT_LIST, LB_ADDSTRING, 0, (LPARAM) byTemp);
	}
	SendDlgItemMessage(hWnd, IDC_TSE_ACTIVATE_TEXT_LIST, LB_SETCURSEL, i2, 0);

	// Deactivate list:
	i2 = (int) SendDlgItemMessage(hWnd, IDC_TSE_ACTIVATE_DE_TEXT_LIST, LB_GETCURSEL, 0, 0L);
	if(i2 < 0 || i2 > pTextScriptT->iDeactivateTextScripts)
		i2 = 0;
	SendDlgItemMessage(hWnd, IDC_TSE_ACTIVATE_DE_TEXT_LIST, LB_RESETCONTENT, 0, 0L);
	for(i = 0; i < pTextScriptT->iDeactivateTextScripts; i++)
	{
		pTextScriptTT = pTextScriptT->pDeactivateTextScript[i];
		if(!pTextScriptTT)
			sprintf(byTemp, "%s", AS_T(T_NoTextScript));
		else
		if(pTextScriptTT->iText == -1)
			sprintf(byTemp, "(%d)  %s", pTextScriptTT->iID, AS_T(T_NoText));
		else
			sprintf(byTemp, "(%d)  %d: %s", pTextScriptTT->iID, pTextScriptTT->iText, pTextScriptManager->pbyText[pTextScriptTT->iText]);
		SendDlgItemMessage(hWnd, IDC_TSE_ACTIVATE_DE_TEXT_LIST, LB_ADDSTRING, 0, (LPARAM) byTemp);
	}
	SendDlgItemMessage(hWnd, IDC_TSE_ACTIVATE_DE_TEXT_LIST, LB_SETCURSEL, i2, 0);
} // end UpdateTSEActivate()

LRESULT CALLBACK TSEItemsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin TSEItemsProc()
	ITEM_INFO *pItemT;
	char byTemp[256];
	int i;

	i = SendDlgItemMessage(hWnd, IDC_TSE_ITEM_STATE, CB_GETCURSEL, 0, 0L);
	if(!i)
		pItemT = &pTextScriptT->AddItem[0];
	else
		pItemT = &pTextScriptT->TakeItem[0];
	switch(iMessage)
    {
        case WM_INITDIALOG:
			// Texts:
			SetDlgItemText(hWnd, IDC_TSE_GOTO_ITEM_SUCCESS, AS_T(T_Success));
			SetDlgItemText(hWnd, IDC_TSE_SET_GOTO_ITEM_SUCCESS, AS_T(T_Set));
			SetDlgItemText(hWnd, IDC_TSE_GOTO_ITEM_FAILED, AS_T(T_Failed));
			SetDlgItemText(hWnd, IDC_TSE_SET_GOTO_ITEM_FAILED, AS_T(T_Set));

			UpdateTSEItems();

			SendDlgItemMessage(hWnd, IDC_TSE_ITEM_STATE, CB_SETCURSEL, 0, 0L);
			SendDlgItemMessage(hWnd, IDC_TSE_ITEM_LIST, CB_SETCURSEL, 0, 0L);

			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
			BringWindowToTop(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_TSE_ITEM_STATE: case IDC_TSE_ITEM_LIST: UpdateTSEItems();break;

				case IDC_TSE_ITEM_UNLIMITED:
					i = SendDlgItemMessage(hWnd, IDC_TSE_ITEM_LIST, CB_GETCURSEL, 0, 0L);
					i = (int) SendDlgItemMessage(hWnd, IDC_TSE_ITEM_LIST, CB_GETITEMDATA, i, 0L);
					if(i < 0 || i > ITEMS)
						i = 0;
					pItemT[i].bUnlimited = SendDlgItemMessage(hWnd, IDC_TSE_ITEM_UNLIMITED, BM_GETCHECK, 0, 0L);
				break;

				case IDC_TSE_ITEM_NUMBER:
					i = SendDlgItemMessage(hWnd, IDC_TSE_ITEM_LIST, CB_GETCURSEL, 0, 0L);
					i = (int) SendDlgItemMessage(hWnd, IDC_TSE_ITEM_LIST, CB_GETITEMDATA, i, 0L);
					if(i < 0 || i > ITEMS)
						i = 0;
					GetDlgItemText(hWnd, IDC_TSE_ITEM_NUMBER, byTemp, 256);
					pItemT[i].iNumber = (int) atoi(byTemp);
				break;

				case IDC_TSE_SET_GOTO_ITEM_SUCCESS: bGetItemSuccessTextScript = TRUE; break;
				case IDC_TSE_SET_GOTO_ITEM_FAILED: bGetItemFailedTextScript = TRUE; break;
			}
        break;
    }
    return FALSE;
} // end TSEItemsProc()

void UpdateTSEItems(void)
{ // begin UpdateTSEItems()
	HWND hWnd = hWndTSETab[TAB_TSE_ITEMS];
	ITEM_INFO *pItemT;
	char byTemp[256];
	int i;

	i = SendDlgItemMessage(hWnd, IDC_TSE_ITEM_STATE, CB_GETCURSEL, 0, 0L);
	SendDlgItemMessage(hWnd, IDC_TSE_ITEM_STATE, CB_RESETCONTENT, 0, 0L);
	SendDlgItemMessage(hWnd, IDC_TSE_ITEM_STATE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Add));
	SendDlgItemMessage(hWnd, IDC_TSE_ITEM_STATE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Take));
	SendDlgItemMessage(hWnd, IDC_TSE_ITEM_STATE, CB_SETCURSEL, i, 0L);
	if(!i)
	{
		pItemT = &pTextScriptT->AddItem[0];
		pTextScriptT->pManager->FillTextScriptView(pTextScriptT->pGotoAddItemSuccess, hWnd, IDC_TSE_GOTO_ITEM_SUCCESS_T);
		pTextScriptT->pManager->FillTextScriptView(pTextScriptT->pGotoAddItemFailed, hWnd, IDC_TSE_GOTO_ITEM_FAILED_T);
	}
	else
	{
		pItemT = &pTextScriptT->TakeItem[0];
		pTextScriptT->pManager->FillTextScriptView(pTextScriptT->pGotoTakeItemSuccess, hWnd, IDC_TSE_GOTO_ITEM_SUCCESS_T);
		pTextScriptT->pManager->FillTextScriptView(pTextScriptT->pGotoTakeItemFailed, hWnd, IDC_TSE_GOTO_ITEM_FAILED_T);
	}

	i = SendDlgItemMessage(hWnd, IDC_TSE_ITEM_LIST, CB_GETCURSEL, 0, 0L);
	FillItemListElement(hWnd, IDC_TSE_ITEM_LIST);
	SendDlgItemMessage(hWnd, IDC_TSE_ITEM_LIST, CB_SETCURSEL, i, 0L);
	i = (int) SendDlgItemMessage(hWnd, IDC_TSE_ITEM_LIST, CB_GETITEMDATA, i, 0L);
	if(i < 0 || i > ITEMS)
		i = 0;
	SendDlgItemMessage(hWnd, IDC_TSE_ITEM_UNLIMITED, BM_SETCHECK, pItemT[i].bUnlimited, 0L);
	sprintf(byTemp, "%d", pItemT[i].iNumber);
	SetDlgItemText(hWnd, IDC_TSE_ITEM_NUMBER, byTemp);
} // end UpdateTSEItems()
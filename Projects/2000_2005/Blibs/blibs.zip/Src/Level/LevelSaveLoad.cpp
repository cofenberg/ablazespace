//-----------------------------------------------------------------------------
// File: LevelSaveLoad.cpp
//-----------------------------------------------------------------------------

#include "..\AS\AS_Engine.h"
#include "..\ModuleHeaders.h"


// Loads an level:
BOOL LEVEL::Load(char *pbyFilename)
{ // begin LEVEL::Load()
	AS_PROGRESS_WINDOW ProgressWindow;
	LEVEL_HEADER HeaderT;
	SURFACE *pSurfaceT;
	ACTOR *pActorT;
	char byTemp[256];
	int i, i2, i3, iTemp;
	BOOL bTemp;
	FILE *fp;
	FIELD *pFieldT;

	_AS->WriteLogMessage("Load level: %s", pbyFilename);	
	ProgressWindow.CreateProgressWindow("Load World");
	ProgressWindow.SetTask("Load level %s...", pbyFilename);
	ProgressWindow.SetSubTask("Initialize level");
	ProgressWindow.SetProgress(0);
	
	// Open the level:
	if(!pbyFilename)
		return FALSE;
	fp = fopen(pbyFilename, "rb");
	if(!fp)
		return FALSE;

	// First, check if this is an correct level version:
	fread(&iVersion, sizeof(int), 1, fp);
	if(iVersion != LEVEL_VERSION)
	{ // This is an wrong level version!!
		_AS->WriteLogMessage("The level version(%d) is not correct! Couldn't load this level!", iVersion);	
		_AS->WriteLogMessage("The current Blibs level version is %d!", LEVEL_VERSION);
		if(_AS->GetModule() == MODULE_EDITOR)  // Give out an message:
			MessageBox(NULL, AS_M(M_WrongLevelVersion), AS_T(T_Error), MB_OK | MB_ICONINFORMATION);
		fclose(fp);
		return FALSE;
	}

	// Ok, destroy now the old level:
	Destroy(); // Destroy the old level:

	// Load the general level information:
	fread(&HeaderT, sizeof(LEVEL_HEADER), 1, fp);
	fread(&AdditionalInformation, sizeof(LEVEL_ADDITIONAL_INFORMATION), 1, fp);

	// Update the current level filename:
	strcpy(HeaderT.byFilename, pbyFilename);

	// Create the level:
	Create(HeaderT.iWidth, HeaderT.iHeight);
	memcpy(&Header, &HeaderT, sizeof(LEVEL_HEADER));
	ResizeActorList(Header.iMaxActors);

	// Load the other general stuff:
	fread(&Environment, sizeof(LEVEL_ENVIRONMENT), 1, fp);
	fread(&Missions, sizeof(LEVEL_MISSIONS), 1, fp);
	fread(&Camera, sizeof(LEVEL_CAMERA), 1, fp);

	// Load the game timer_
	fread(&g_lGameTimer, sizeof(long), 1, fp);

	Missions.lTimeLimitTime = 0;

	// Load the surfaces:
	_AS->WriteLogMessage("Load surfaces");
	pSurface = (SURFACE *) realloc(pSurface, sizeof(SURFACE)*Header.iSurfaces);
	ProgressWindow.SetTask("Load surfaces");
	for(i = 1; i < Header.iSurfaces; i++)
	{
		pSurfaceT = &pSurface[i];
		ProgressWindow.SetProgress((UINT) (((float) i/Header.iSurfaces)*100));	
		memset(&pSurface[i], 0, sizeof(SURFACE)); 
		
		// Load the general surface information:
		fread(&pSurfaceT->Header, sizeof(SURFACE_HEADER), 1, fp);
		ProgressWindow.SetSubTask("%s", pSurfaceT->Header.byName);
		
		// Update the ID:
		pSurfaceT->Header.iID = i;
		
		// Animation steps:
		pSurfaceT->pTexturePos = (TEXTURE_POS *) malloc(sizeof(TEXTURE_POS)*pSurfaceT->Header.iAniSteps);

		// Texture filename:
		pSurfaceT->byTextureFilename = (char **) malloc(sizeof(char *)*pSurfaceT->Header.iAniSteps);
		pSurfaceT->iTextureID = (int *) malloc(sizeof(int)*pSurfaceT->Header.iAniSteps);
		pSurfaceT->pTexture = (AS_TEXTURE **) malloc(sizeof(AS_TEXTURE *)*pSurfaceT->Header.iAniSteps);
		
		// Load the animation steps of this surface:
		for(i2 = 0; i2 < pSurfaceT->Header.iAniSteps; i2++)
		{
			pSurfaceT->byTextureFilename[i2] = (char *) malloc(sizeof(char)*MAX_PATH);
			fread(pSurfaceT->byTextureFilename[i2], sizeof(char)*MAX_PATH, 1, fp);

			pSurfaceT->iTextureID[i2] = -1;
			pSurfaceT->pTexture[i2] = NULL;

			// Texture positions:
			for(i3 = 0; i3 < 9; i3++)
				fread(&pSurfaceT->pTexturePos[i2].iPos[i3], sizeof(INT2), 1, fp);
			fread(&pSurfaceT->pTexturePos[i2].iTimeToNext, sizeof(long), 1, fp);
		}
	}
	// Now load all surface textures:
	for(i = 1; i < Header.iSurfaces; i++)
	{
		pSurfaceT = &pSurface[i];
		for(i2 = 0; i2 < pSurfaceT->Header.iAniSteps; i2++)
		{
			LoadTexture(pSurfaceT->byTextureFilename[i2]);
			pCurrentTexture->iUsed++;
			pSurfaceT->iTextureID[i2] = iCurrentTexture;
			pSurfaceT->pTexture[i2] = pCurrentTexture;
		}
		// Update the surface:
		pSurfaceT->CalculateFloatTexturePos();
	}

	// Load decorations:
	_AS->WriteLogMessage("Load decorations");
	fread(&iDecorationModels, sizeof(int), 1, fp);
	pDecorationModels = (DECORATION_MODEL *) malloc(sizeof(DECORATION_MODEL)*iDecorationModels);
	for(i = 0; i < iDecorationModels; i++)
	{
		memset(&pDecorationModels[i], 0, sizeof(DECORATION_MODEL));
		fread(pDecorationModels[i].byFilename, sizeof(char)*256, 1, fp);
		sprintf(byTemp, "%s%s", _AS->byProgramPath, pDecorationModels[i].byFilename);
		pDecorationModels[i].pModel = ASLoadMd2Model(byTemp);
	}

	// Load text scripts:
	TextScriptManager.Load(fp);

	ProgressWindow.SetTask("Setup level");
	ProgressWindow.SetSubTask(" ");
	ProgressWindow.SetProgress(0);
	
	// Load point information:
	fread(fPoint, sizeof(FLOAT3)*Header.iPoints, 1, fp);
	// Load color information:
	fread(fColor, sizeof(FLOAT4)*Header.iPoints, 1, fp);
	// Load second color information:
	fread(fSecondColor, sizeof(FLOAT4)*Header.iPoints, 1, fp);
	// Load water point information:
	fread(fWaterPoint, sizeof(FLOAT3)*Header.iLevelPoints, 1, fp);
	for(i = 0; i < Header.iLevelPoints; i++)
		fWaterStandartZ[i] = fWaterPoint[i][Z];
	fread(fWaterColor, sizeof(FLOAT4)*Header.iLevelPoints, 1, fp);
	fread(fWaterSecondColor, sizeof(FLOAT4)*Header.iLevelPoints, 1, fp);
	fread(fWaterAmplitude, sizeof(float)*Header.iLevelPoints, 1, fp);

	// Load field information:
	_AS->WriteLogMessage("Load fields");
	for(i = 0; i < Header.iFields; i++)
	{
		pFieldT = &pField[i];
		// Active:
		fread(&pFieldT->bActive, sizeof(BOOL), 1, fp);
		bTemp = pFieldT->bActive;
		// Wall:
		fread(&pFieldT->bWall, sizeof(BOOL), 1, fp);
		fread(&pFieldT->bWallHole, sizeof(BOOL), 1, fp);
		fread(&pFieldT->bAlwaysWall, sizeof(BOOL), 1, fp);
		fread(&pFieldT->bIndestructibleWall, sizeof(BOOL), 1, fp);
		fread(&pFieldT->bNoBridgePossible, sizeof(BOOL), 1, fp);
		fread(&pFieldT->bActivateWater, sizeof(BOOL), 1, fp);		
		fread(&pFieldT->bActivateWaterBubbles, sizeof(BOOL), 1, fp);		
		fread(&pFieldT->bForceWaterBubbles, sizeof(BOOL), 1, fp);		
		// Beamer:
		fread(&pFieldT->fBeamerPower, sizeof(float), 1, fp);
		fread(&pFieldT->iBeamerRegenerationSpeed, sizeof(int), 1, fp);
		fread(&pFieldT->iBeamerTarget, sizeof(int), 1, fp);
		// No backface culling:
		fread(&pFieldT->bNoBackfaceCulling, sizeof(BOOL), 1, fp);
		// Water type:
		fread(&pFieldT->WaterType, sizeof(WATER_TYPE), 1, fp);
		// Camera script:
		fread(&pFieldT->iCamera, sizeof(int), 1, fp);
		fread(&pFieldT->bCameraAlways, sizeof(BOOL), 1, fp);
		// Text script:
		for(i2 = 0; i2 < 5; i2++)
		{
			fread(&pFieldT->bTextScript[i2], sizeof(BOOL), 1, fp);
			fread(&pFieldT->bTextScriptAlways[i2], sizeof(BOOL), 1, fp);
			fread(&pFieldT->bTextScriptActionKey[i2], sizeof(BOOL), 1, fp);
			fread(&iTemp, sizeof(int), 1, fp);
			if(iTemp != -1)
				pFieldT->pTextScript[i2] = TextScriptManager.GetTextScriptIDPointer(iTemp);
		}

		// Change water height:
		fread(&pFieldT->bWaterChangeHeight, sizeof(BOOL), 1, fp);
		fread(&pFieldT->bWaterChangePressed, sizeof(BOOL), 1, fp);
		fread(&pFieldT->bWaterChangeNotPressed, sizeof(BOOL), 1, fp);
		fread(&pFieldT->fWaterChangeHeightTo, sizeof(float), 1, fp);
		fread(&pFieldT->fWaterChangeSpeed, sizeof(float), 1, fp);
		fread(&pFieldT->fWaterChangeNotHeightTo, sizeof(float), 1, fp);
		fread(&pFieldT->fWaterChangeNotSpeed, sizeof(float), 1, fp);

		pFieldT->bSelected = FALSE;
		// Surfaces:
		for(i2 = 0; i2 < 7; i2++)
		{
			fread(&pFieldT->Side[i2].bFaceAlwaysActive, sizeof(BOOL), 1, fp);
			fread(&pFieldT->Side[i2].bFace2Sides, sizeof(BOOL), 1, fp);
			fread(&pFieldT->Side[i2].bFaceSwapSides, sizeof(BOOL), 1, fp);
			fread(&pFieldT->Side[i2].bDisableWaterSide, sizeof(BOOL), 1, fp);
			fread(&pFieldT->Side[i2].bWallSide, sizeof(BOOL), 1, fp);
			fread(&pFieldT->Side[i2].bInvisible, sizeof(BOOL), 1, fp);
			for(i3 = 0; i3 < 2; i3++)
			{
				fread(&pFieldT->Side[i2].Surface[i3].iSurface, sizeof(int), 1, fp);
				fread(&pFieldT->Side[i2].Surface[i3].iSurfaceRotation, sizeof(int), 1, fp);
				fread(&pFieldT->Side[i2].Surface[i3].iCurrentAniStep, sizeof(int), 1, fp);
				fread(&pFieldT->Side[i2].Surface[i3].dwLastTime, sizeof(long), 1, fp);
				fread(&pFieldT->Side[i2].Surface[i3].dwLastChangeTime, sizeof(long), 1, fp);
			}
		}
		if(pFieldT->bWallHole)
			pFieldT->bWall = TRUE;
		if(pFieldT->bAlwaysWall)
			SetFieldWall(pFieldT->iXField, pFieldT->iYField, FALSE, FALSE);
		else
			SetFieldWall(pFieldT->iXField, pFieldT->iYField, pFieldT->bWall, FALSE);
		pFieldT->bActive = bTemp;
		for(i3 = 0; i3 < 2; i3++)
		{
			for(i2 = 0; i2 < 7; i2++)
			{
				if(pFieldT->Side[i2].Surface[i3].iSurface == -1)
					continue;
				pFieldT->Side[i2].Surface[i3].pSurface = &pSurface[pFieldT->Side[i2].Surface[i3].iSurface];
				if(pFieldT->Side[i2].Surface[i3].pSurface)
					pFieldT->Side[i2].Surface[i3].pSurface->iUsed++;
			}
		}
		pFieldT->pActor = pFieldT->pBridgeActor = pFieldT->pItem = NULL;
		// Decoration;
		fread(&bTemp, sizeof(BOOL), 1, fp);
		if(bTemp)
		{
			pFieldT->pDecoration = (FIELD_DECORATION *) malloc(sizeof(FIELD_DECORATION));
			fread(pFieldT->pDecoration, sizeof(FIELD_DECORATION), 1, fp);
			if(pFieldT->pDecoration->iTexture != -1)
			{
				LoadTexture(pFieldT->pDecoration->byTextureFilename);
				pCurrentTexture->iUsed++;
				pFieldT->pDecoration->iTexture = iCurrentTexture;
			}
		}
	}
	for(i = 0; i < Header.iFields; i++)
	{
		if(!pField[i].bWallHole)
			continue;
		SetFieldWall(pField[i].iXField, pField[i].iYField, TRUE, FALSE);
	}
	
	// Setup the selected stuff to zero:
	if(Header.iFields)
	{
		iCurrentField = 0;
		pCurrentField = &pField[iCurrentField];
	}
	if(Header.iTextures)
	{
		iCurrentTexture = 0;
		pCurrentTexture = &pTexture[iCurrentTexture];
	}
	if(Header.iSurfaces)
	{
		iCurrentSurface = 0;
		pCurrentSurface = &pSurface[iCurrentSurface];
	}
	if(Header.iCameraScripts)
	{
		iCurrentCameraScript = 0;
		pCurrentCameraScript = &pCameraScript[iCurrentCameraScript];
	}

	// Camera scripts:
	_AS->WriteLogMessage("Load camera scripts");
	pCameraScript = (AS_CAMERA_SCRIPT *) malloc(sizeof(AS_CAMERA_SCRIPT)*Header.iCameraScripts);
	for(i = 0; i < Header.iCameraScripts; i++)
	{
		// Name:
		fread(&pCameraScript[i].byName, sizeof(char)*256, 1, fp);
		// Steps:
		fread(&pCameraScript[i].iSteps, sizeof(int), 1, fp);
		// Text script:
		fread(&pCameraScript[i].iTextScript, sizeof(int), 1, fp);
		pCameraScript[i].pCamera = (AS_CAMERA *) malloc(sizeof(AS_CAMERA)*pCameraScript[i].iSteps);
		// Camera steps:
		for(i2 = 0; i2 < pCameraScript[i].iSteps; i2++)
			fread(&pCameraScript[i].pCamera[i2], sizeof(AS_CAMERA), 1, fp);
	}

	_AS->WriteLogMessage("Load actors");

	// Set all actors to zero:
	for(i = 0; i < Header.iMaxActors; i++)
		memset(pActorList[i], 0, sizeof(ACTOR));

	// Number of active actors:
	fread(&i, sizeof(int), 1, fp);
	
	// Load the actors:
	for(i2 = 0; i2 < i; i2++)
	{
		pActorT = pActorList[i2];
		fread(pActorT, sizeof(ACTOR), 1, fp);
		fread(&iTemp, sizeof(int), 1, fp);
		if(iTemp != -1)
			pActorT->pTextScript = TextScriptManager.GetTextScriptIDPointer(iTemp);
		pActorT->iCheckpointFieldID = pActorT->iFieldID;
		if(pActorT->bActive && !pActorT->bGoingDeath && !pActorT->bDeath)
		{
			switch(pActorT->Type)
			{
				case AT_HEALTH_ITEM:
				case AT_HEALTH_INCREASE_ITEM:
				case AT_LIFE_ITEM:
				case AT_PULL_ITEM:
				case AT_CHEST_ITEM:
				case AT_STRENGTH_ITEM:
				case AT_WEAPON_ITEM:
				case AT_COIN_ITEM:
				case AT_GHOST_ITEM:
				case AT_TIME_ITEM:
				case AT_STEP_ITEM:
				case AT_SPEED_ITEM:
				case AT_WING_ITEM:
				case AT_SHIELD_ITEM:
				case AT_JUMP_ITEM:
				case AT_AIR_ITEM:
				case AT_AIR_INCREASE_ITEM:
				case AT_THROW_ITEM:
				case AT_KICK_ITEM:
				case AT_BAG_ITEM:
				case AT_DYNAMITE_ITEM:
					pField[pActorT->iFieldID].pItem = pActorT;
				break;

				default:
					if(pActorT->bBridge)
						pField[pActorT->iFieldID].pBridgeActor = pActorT;
					else
						pField[pActorT->iFieldID].pActor = pActorT;
					if(pActorT->Type == AT_BLIBS && !pActorT->bClone)
						pPlayer = pActorT; // Thats our main Blibs!!
				break;
			}
		}
		pActorT->iID = i2;
		pActorT->iParticleSystemID = -1;
		pActorT->SetAction(AA_NOTHING);
		if(!LoadTexture(pActorT->byTextureFilename))
			pCurrentTexture->iUsed++;
	}
	//

	if(hWndEditor)
	{ // Update the textures if we are in the editor:
		DestroyTexturesOpenGL(hDCEditorShow, hRCEditorShow);
		GenTexturesOpenGL(hDCEditorShow, hRCEditorShow);
	}

	_AS->WriteLogMessage("Setup level");
	
	// Setup the camera:
	memset(&LevelTempCamera, 0, sizeof(AS_CAMERA));
	memcpy(pCamera, &Camera.StartCamera, sizeof(AS_CAMERA));
	pCamera->fPos[Z] = 0.0f;
	if(!Camera.bFreeCamera)
		Camera.bStandartCamera = 0;
	if(!Camera.bStandartCamera)
	{
		pCamera->fRot2[X] = -90.0f;
		bPlayerCameraView = TRUE;
	}
	if(Camera.bStandartCamera)
		bPlayerCameraView = FALSE;
	else
		if(Camera.bPlayerCamera)
			bPlayerCameraView = TRUE;

	bForceVisiblityUpdate = TRUE;
	CalculateFacesMidPoint(TRUE);
	CalculateWaterNormals(FALSE);
	CalculateWaterPoints(FALSE);
	CalculateFieldNormals(TRUE);
	CalculatePointNormals();
	GetBeamerList();
	GetDecorationList();
	GetTriggerList();
	GetAnimatedSurfacesList();
	GetMinMiddleMax();
	CalculateFieldBoundingBoxes();
	Quadtree.GetBoundingBox(pLevel);
	UpdateVisibilityInformation();

	// Update the missions:
	InitMissions();
	UpdateMissions();
	CheckMissions();

	// Get time:
	g_lNow = GetTickCount();

	// Now load the animation time:
	_AS->WriteLogMessage("Load timing stuff");
	fclose(fp);
	_AS->WriteLogMessage("Load level: OK");
	
	return TRUE;
} // end LEVEL::Load()

// Saves an level:
HRESULT LEVEL::Save(char *pbyFilename)
{ // begin LEVEL::Save()
	int i, i2, i3, iVersion, iTemp;
	SURFACE *pSurfaceT;
	FIELD *pFieldT;
	BOOL bTemp;
	FILE *fp;

	_AS->WriteLogMessage("Save level: %s", pbyFilename);	
	if(!pbyFilename)
		return 1;
	remove(pbyFilename); // Delete the old level file
	fp = fopen(pbyFilename, "wb");
	if(!fp)
		return 1;

	// Save the level version:
	iVersion = LEVEL_VERSION;
	fwrite(&iVersion, sizeof(int), 1, fp);

	// Update the current level filename:
	strcpy(Header.byFilename, pbyFilename);

	// Check if every texture is used:
	i2 = Header.iTextures;
	Header.iTextures = 1;

	// Save the general level information:
	fwrite(&Header, sizeof(LEVEL_HEADER), 1, fp);
	fwrite(&AdditionalInformation, sizeof(LEVEL_ADDITIONAL_INFORMATION), 1, fp);
	fwrite(&Environment, sizeof(LEVEL_ENVIRONMENT), 1, fp);
	fwrite(&Missions, sizeof(LEVEL_MISSIONS), 1, fp);
	memcpy(&Camera.StartCamera, pCamera, sizeof(AS_CAMERA));
	fwrite(&Camera, sizeof(LEVEL_CAMERA), 1, fp);

	// Save the game timer_
	fwrite(&g_lGameTimer, sizeof(long), 1, fp);

	Header.iTextures = i2;

	// Save the surfaces:
	for(i = 1; i < Header.iSurfaces; i++)
	{
		pSurfaceT = &pSurface[i];
		fwrite(&pSurfaceT->Header, sizeof(SURFACE_HEADER), 1, fp);
		// Texture positions:
		for(i2 = 0; i2 < pSurfaceT->Header.iAniSteps; i2++)
		{
			// Texture filename:
			fwrite(pSurfaceT->byTextureFilename[i2], sizeof(char)*MAX_PATH, 1, fp);
			for(i3 = 0; i3 < 9; i3++)
				fwrite(&pSurfaceT->pTexturePos[i2].iPos[i3], sizeof(INT2), 1, fp);
			fwrite(&pSurfaceT->pTexturePos[i2].iTimeToNext, sizeof(long), 1, fp);
		}
	}

	// Save decorations:
	fwrite(&iDecorationModels, sizeof(int), 1, fp);
	for(i = 0; i < iDecorationModels; i++)
		fwrite(pDecorationModels[i].byFilename, sizeof(char)*256, 1, fp);

	// Save text scripts:
	TextScriptManager.Save(fp);

	// Point information:
	fwrite(fPoint, sizeof(FLOAT3)*Header.iPoints, 1, fp);
	// Color information:
	fwrite(fColor, sizeof(FLOAT4)*Header.iPoints, 1, fp);
	// Second color information:
	fwrite(fSecondColor, sizeof(FLOAT4)*Header.iPoints, 1, fp);
	// Water point information:
	for(i = 0; i < Header.iLevelPoints; i++)
		fWaterPoint[i][Z] = fWaterStandartZ[i];
	fwrite(fWaterPoint, sizeof(FLOAT3)*Header.iLevelPoints, 1, fp);
	fwrite(fWaterColor, sizeof(FLOAT4)*Header.iLevelPoints, 1, fp);
	fwrite(fWaterSecondColor, sizeof(FLOAT4)*Header.iLevelPoints, 1, fp);
	fwrite(fWaterAmplitude, sizeof(float)*Header.iLevelPoints, 1, fp);

	// Save field information:
	for(i = 0; i < Header.iFields; i++)
	{
		pFieldT = &pField[i];
		// Active:
		i2 = pFieldT->bActive;
		if(pFieldT->pBridgeActor)
			pFieldT->bActive = FALSE;
		fwrite(&pFieldT->bActive, sizeof(BOOL), 1, fp);
		pFieldT->bActive = i2;
		// Wall:
		i2 = pFieldT->bWall;
		if(pFieldT->pActor || pFieldT->bAlwaysWall)
			pFieldT->bWall = 0;
		fwrite(&pFieldT->bWall, sizeof(BOOL), 1, fp);
		fwrite(&pFieldT->bWallHole, sizeof(BOOL), 1, fp);
		fwrite(&pFieldT->bAlwaysWall, sizeof(BOOL), 1, fp);
		fwrite(&pFieldT->bIndestructibleWall, sizeof(BOOL), 1, fp);
		fwrite(&pFieldT->bNoBridgePossible, sizeof(BOOL), 1, fp);
		fwrite(&pFieldT->bActivateWater, sizeof(BOOL), 1, fp);		
		fwrite(&pFieldT->bActivateWaterBubbles, sizeof(BOOL), 1, fp);		
		fwrite(&pFieldT->bForceWaterBubbles, sizeof(BOOL), 1, fp);		
		pFieldT->bWall = i2;
		// Beamer:
		fwrite(&pFieldT->fBeamerPower, sizeof(float), 1, fp);
		fwrite(&pFieldT->iBeamerRegenerationSpeed, sizeof(int), 1, fp);
		fwrite(&pFieldT->iBeamerTarget, sizeof(int), 1, fp);
		// No backface culling:
		fwrite(&pFieldT->bNoBackfaceCulling, sizeof(BOOL), 1, fp);
		// Water type:
		fwrite(&pFieldT->WaterType, sizeof(WATER_TYPE), 1, fp);
		// Camera script:
		fwrite(&pFieldT->iCamera, sizeof(int), 1, fp);
		fwrite(&pFieldT->bCameraAlways, sizeof(BOOL), 1, fp);
		// Text script:
		for(i2 = 0; i2 < 5; i2++)
		{
			fwrite(&pFieldT->bTextScript[i2], sizeof(BOOL), 1, fp);
			fwrite(&pFieldT->bTextScriptAlways[i2], sizeof(BOOL), 1, fp);
			fwrite(&pFieldT->bTextScriptActionKey[i2], sizeof(BOOL), 1, fp);
			if(pFieldT->pTextScript[i2])
				iTemp = pFieldT->pTextScript[i2]->iID;
			else
				iTemp = -1;
			fwrite(&iTemp, sizeof(int), 1, fp);
		}
		// Change water height:
		fwrite(&pFieldT->bWaterChangeHeight, sizeof(BOOL), 1, fp);
		fwrite(&pFieldT->bWaterChangePressed, sizeof(BOOL), 1, fp);
		fwrite(&pFieldT->bWaterChangeNotPressed, sizeof(BOOL), 1, fp);
		fwrite(&pFieldT->fWaterChangeHeightTo, sizeof(float), 1, fp);
		fwrite(&pFieldT->fWaterChangeSpeed, sizeof(float), 1, fp);
		fwrite(&pFieldT->fWaterChangeNotHeightTo, sizeof(float), 1, fp);
		fwrite(&pFieldT->fWaterChangeNotSpeed, sizeof(float), 1, fp);
		// Surfaces:
		for(i2 = 0; i2 < 7; i2++)
		{
			fwrite(&pFieldT->Side[i2].bFaceAlwaysActive, sizeof(BOOL), 1, fp);
			fwrite(&pFieldT->Side[i2].bFace2Sides, sizeof(BOOL), 1, fp);
			fwrite(&pFieldT->Side[i2].bFaceSwapSides, sizeof(BOOL), 1, fp);
			fwrite(&pFieldT->Side[i2].bDisableWaterSide, sizeof(BOOL), 1, fp);
			fwrite(&pFieldT->Side[i2].bWallSide, sizeof(BOOL), 1, fp);
			fwrite(&pFieldT->Side[i2].bInvisible, sizeof(BOOL), 1, fp);
			for(i3 = 0; i3 < 2; i3++)
			{
				fwrite(&pFieldT->Side[i2].Surface[i3].iSurface, sizeof(int), 1, fp);
				fwrite(&pFieldT->Side[i2].Surface[i3].iSurfaceRotation, sizeof(int), 1, fp);
				fwrite(&pFieldT->Side[i2].Surface[i3].iCurrentAniStep, sizeof(int), 1, fp);
				fwrite(&pFieldT->Side[i2].Surface[i3].dwLastTime, sizeof(long), 1, fp);
				fwrite(&pFieldT->Side[i2].Surface[i3].dwLastChangeTime, sizeof(long), 1, fp);
			}
			// Save the time to the next animation step:
		}
		// Decoration;
		if(!pFieldT->pDecoration)
			bTemp = FALSE;
		else
			bTemp = TRUE;
		fwrite(&bTemp, sizeof(BOOL), 1, fp);
		if(bTemp)
			fwrite(pFieldT->pDecoration, sizeof(FIELD_DECORATION), 1, fp);
	}


	// Save the camera scripts:
	for(i = 0; i < Header.iCameraScripts; i++)
	{
		// Name:
		fwrite(&pCameraScript[i].byName, sizeof(char)*256, 1, fp);
		// Steps:
		fwrite(&pCameraScript[i].iSteps, sizeof(int), 1, fp);
		// Text script:
		fwrite(&pCameraScript[i].iTextScript, sizeof(int), 1, fp);
		// Camera steps:
		for(i2 = 0; i2 < pCameraScript[i].iSteps; i2++)
			fwrite(&pCameraScript[i].pCamera[i2], sizeof(AS_CAMERA), 1, fp);
	}

	// Other actors:
	// Sort them to find out which actors we have to save: (makes the levels smaller)
	i = SortActors();
	// Save the number of active actors:
	fwrite(&i, sizeof(int), 1, fp);
	// Save only the active the actors:
	for(i2 = 0; i2 < i; i2++)
	{
		fwrite(pActorList[i2], sizeof(ACTOR), 1, fp);
		if(pActorList[i2]->pTextScript)
			iTemp = pActorList[i2]->pTextScript->iID;
		else
			iTemp = -1;
		fwrite(&iTemp, sizeof(int), 1, fp);
	}
	
	Check(FALSE);

	fclose(fp);
	_AS->WriteLogMessage("OK");
	
	return FALSE;
} // end LEVEL::Save()
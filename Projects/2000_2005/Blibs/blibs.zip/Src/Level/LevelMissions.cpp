//-----------------------------------------------------------------------------
// File: Missions.cpp
//-----------------------------------------------------------------------------

#include "..\AS\AS_Engine.h"
#include "..\ModuleHeaders.h"


void LEVEL::InitMissions(void)
{ // begin LEVEL::InitMissions()
	// Initalize the level missions state:
	State.bLevelComplete = State.bLevelJustComplete = FALSE;
	State.iUsedForAllAnchors = State.iUsedNormalAnchors = State.iUsedRedAnchors = State.iUsedGreenAnchors = State.iUsedBlueAnchors =
	State.iDestroyedNormalBoxes = State.iDestroyedRedBoxes = State.iDestroyedGreenBoxes = State.iDestroyedBlueBoxes = 
	State.iNoneFreeNormalBoxes = State.iNoneFreeRedBoxes = State.iNoneFreeGreenBoxes = State.iNoneFreeBlueBoxes = 0;
	State.iCollectedPoints = State.iKilledMobmobs = State.iKilledX3 = 0;
	if(Missions.bExit)
		State.bMissionExitComplete = FALSE;
	else
		State.bMissionExitComplete = TRUE;
	if(Missions.bAlcove)
		State.bMissionAlcoveComplete = FALSE;
	else
		State.bMissionAlcoveComplete = TRUE;

	// Collect objects:
	if(Missions.bCollectPoints)
		State.bMissionCollectPointsComplete = FALSE;
	else
		State.bMissionCollectPointsComplete = FALSE;
	if(Missions.bCollectHealth)
		State.bMissionCollectHealthComplete = FALSE;
	else
		State.bMissionCollectHealthComplete = FALSE;
	if(Missions.bKillMobmobs)
		State.bMissionKillMobmobsComplete = FALSE;
	else
		State.bMissionKillMobmobsComplete = FALSE;
	if(Missions.bKillX3)
		State.bMissionKillX3Complete = FALSE;
	else
		State.bMissionKillX3Complete = FALSE;
	
	// Anchors:
	if(Missions.bNoFreeForAllAnchor)
		State.bMissionNoFreeForAllAnchorComplete = FALSE;
	else
		State.bMissionNoFreeForAllAnchorComplete = TRUE;
	if(Missions.bNoFreeNormalAnchor)
		State.bMissionNoFreeNormalAnchorComplete = FALSE;
	else
		State.bMissionNoFreeNormalAnchorComplete = TRUE;
	if(Missions.bNoFreeRedAnchor)
		State.bMissionNoFreeRedAnchorComplete = FALSE;
	else
		State.bMissionNoFreeRedAnchorComplete = TRUE;
	if(Missions.bNoFreeGreenAnchor)
		State.bMissionNoFreeGreenAnchorComplete = FALSE;
	else
		State.bMissionNoFreeGreenAnchorComplete = TRUE;
	if(Missions.bNoFreeBlueAnchor)
		State.bMissionNoFreeBlueAnchorComplete = FALSE;
	else
		State.bMissionNoFreeBlueAnchorComplete = TRUE;

	// No free boxes:
	if(Missions.bNoFreeNormalBox)
		State.bMissionNoFreeNormalBoxesComplete = FALSE;
	else
		State.bMissionNoFreeNormalBoxesComplete = TRUE;
	if(Missions.bNoFreeRedBox)
		State.bMissionNoFreeRedBoxesComplete = FALSE;
	else
		State.bMissionNoFreeRedBoxesComplete = TRUE;
	if(Missions.bNoFreeGreenBox)
		State.bMissionNoFreeGreenBoxesComplete = FALSE;
	else
		State.bMissionNoFreeGreenBoxesComplete = TRUE;
	if(Missions.bNoFreeBlueBox)
		State.bMissionNoFreeBlueBoxesComplete = FALSE;
	else
		State.bMissionNoFreeBlueBoxesComplete = TRUE;

	// Destroyed boxes:
	if(Missions.bNoNormalBox)
		State.bMissionNoNormalBoxesComplete = FALSE;
	else
		State.bMissionNoNormalBoxesComplete = TRUE;
	if(Missions.bNoRedBox)
		State.bMissionNoRedBoxesComplete = FALSE;
	else
		State.bMissionNoRedBoxesComplete = TRUE;
	if(Missions.bNoGreenBox)
		State.bMissionNoGreenBoxesComplete = FALSE;
	else
		State.bMissionNoGreenBoxesComplete = TRUE;
	if(Missions.bNoBlueBox)
		State.bMissionNoBlueBoxesComplete = FALSE;
	else
		State.bMissionNoBlueBoxesComplete = TRUE;

} // end LEVEL::InitMissions()

void LEVEL::UpdateMissions(void)
{ // begin LEVEL::UpdateMissions()
	ACTOR *pActorT;
	int i;
	
	Header.iPointsObj = Header.iNormalBoxes = Header.iRedBoxes = Header.iGreenBoxes = Header.iBlueBoxes =
	Header.iForAllAnchors = Header.iNormalAnchors = Header.iRedAnchors = Header.iGreenAnchors =
	Header.iBlueAnchors = Header.iMobmobs = Header.iX3 = 0;
	if(!pActorList)
		return; // Thats probably an new level
	for(i = 0; i < Header.iFields; i++)
	{
		if((pField[i].bWall && !pField[i].pActor) || !pField[i].bActive)
			continue; // This is a wrong mission target!!
		if(pField[i].Side[FACE_FLOOR].Surface[0].iSurface != -1 &&
		   pSurface[pField[i].Side[FACE_FLOOR].Surface[0].iSurface].Header.bAnchor)
		{
			switch(pSurface[pField[i].Side[FACE_FLOOR].Surface[0].iSurface].Header.byAnchorType)
			{
				case 0: Header.iForAllAnchors++; break;
				case 1: Header.iNormalAnchors++; break;
				case 2: Header.iRedAnchors++; break;
				case 3: Header.iGreenAnchors++; break;
				case 4: Header.iBlueAnchors++; break;
			}
		}
	}
	for(i = 0; i < Header.iMaxActors; i++)
	{
		pActorT = pActorList[i];
		if(!pActorT->bActive)
			continue;
		switch(pActorT->Type)
		{
			case AT_BOX_NORMAL: Header.iNormalBoxes++; break;
			case AT_BOX_RED: Header.iRedBoxes++; break;
			case AT_BOX_GREEN: Header.iGreenBoxes++; break;
			case AT_BOX_BLUE: Header.iBlueBoxes++; break;
			case AT_COIN_ITEM: Header.iPointsObj++; break;
			case AT_MOBMOB: Header.iMobmobs++; break;
			case AT_X3: Header.iX3++; break;
		}
		if(pActorT->bDocked || pActorT->bBridge)
		{
			pActorT->SetNoneFreeBox();
			if(pActorT->bDocked)
				pActorT->SetNoneFreeAnchor();
		}
	}
} // end LEVEL::UpdateMissions()

void LEVEL::CheckMissions(void)
{ // begin LEVEL::CheckMissions()
	char byTemp[256];
	int i;

	if(State.bLevelComplete)
		return;
	if(Missions.bExit)
	{
		if(pPlayer &&
		   pField[pPlayer->iFieldID].Side[FACE_FLOOR].Surface[0].pSurface &&
		   pField[pPlayer->iFieldID].Side[FACE_FLOOR].Surface[0].pSurface->Header.bExit && 
		   pPlayer->fFieldPos[X] == 0.0f && pPlayer->fFieldPos[Y] == 0.0f &&
		   pPlayer->Action != AA_JUMPING)
			State.bMissionExitComplete = TRUE;
		else
			State.bMissionExitComplete = FALSE;
	}
	else
		State.bMissionExitComplete = TRUE;
	if(Missions.bAlcove)
	{
		if(pPlayer &&
		   pField[pPlayer->iFieldID].Side[FACE_FLOOR].Surface[0].pSurface &&
		   pField[pPlayer->iFieldID].Side[FACE_FLOOR].Surface[0].pSurface->Header.bAlcove && 
		   pPlayer->fFieldPos[X] == 0.0f && pPlayer->fFieldPos[Y] == 0.0f &&
		   pPlayer->Action != AA_JUMPING)
			State.bMissionAlcoveComplete = TRUE;
		else
			State.bMissionAlcoveComplete = FALSE;
	}
	else
		State.bMissionAlcoveComplete = TRUE;

	// Collect objects:
	if(Missions.bCollectPoints)
	{
		if(State.iCollectedPoints < Missions.iCollectPoints)
		{
			if(State.bMissionCollectPointsComplete)
			{
				sprintf(byTemp, "%s -> %s", AS_T(T_CollectPoints), AS_T(T_Incomplete));
				ShowSmallMessage(byTemp, 2000);
				State.bMissionCollectPointsComplete = FALSE;
			}
		}
		else
		{
			if(!State.bMissionCollectPointsComplete)
			{
				sprintf(byTemp, "%s -> %s", AS_T(T_CollectPoints), AS_T(T_Complete));
				ShowSmallMessage(byTemp, 2000);
				State.bMissionCollectPointsComplete = TRUE;
			}
		}
	}
	else
		State.bMissionCollectPointsComplete = TRUE;
	if(Missions.bCollectHealth)
	{
		if(pPlayer && pPlayer->fHealth < Missions.iCollectHealth)
		{
			if(State.bMissionCollectHealthComplete)
			{
				sprintf(byTemp, "%s -> %s", AS_T(T_CollectHealth), AS_T(T_Incomplete));
				ShowSmallMessage(byTemp, 2000);
				State.bMissionCollectHealthComplete = FALSE;
			}
		}
		else
		{
			if(!State.bMissionCollectHealthComplete)
			{
				sprintf(byTemp, "%s -> %s", AS_T(T_CollectHealth), AS_T(T_Complete));
				ShowSmallMessage(byTemp, 2000);
				State.bMissionCollectHealthComplete = TRUE;
			}
		}
	}
	else
		State.bMissionCollectHealthComplete = TRUE;

	if(Missions.bKillMobmobs)
	{
		if(State.iKilledMobmobs >= Missions.iKillMobmobs && !State.bMissionKillMobmobsComplete)
		{
			sprintf(byTemp, "%s -> %s", AS_T(T_KillMobmobs), AS_T(T_Complete));
			ShowSmallMessage(byTemp, 2000);
			State.bMissionKillMobmobsComplete = TRUE;
		}
	}
	else
		State.bMissionKillMobmobsComplete = TRUE;
	if(Missions.bKillX3)
	{
		if(State.iKilledX3 >= Missions.iKillX3 && !State.bMissionKillX3Complete)
		{
			sprintf(byTemp, "%s -> %s", AS_T(T_KillX3), AS_T(T_Complete));
			ShowSmallMessage(byTemp, 2000);
			State.bMissionKillX3Complete = TRUE;
		}
	}
	else
		State.bMissionKillX3Complete = TRUE;

	// Check anchors:
	if(Missions.bNoFreeForAllAnchor && State.iUsedForAllAnchors == Header.iForAllAnchors)
	{
		if(!State.bMissionNoFreeForAllAnchorComplete)
		{
			sprintf(byTemp, "%s -> %s", AS_T(T_FillAllForAllAnchors), AS_T(T_Complete));
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeForAllAnchorComplete = TRUE;
		}
	}
	else
	{
		if(Missions.bNoFreeForAllAnchor && State.bMissionNoFreeForAllAnchorComplete)
		{
			sprintf(byTemp, "%s -> %s", AS_T(T_FillAllForAllAnchors), AS_T(T_Incomplete));
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeForAllAnchorComplete = FALSE;
		}
	}
	if(Missions.bNoFreeNormalAnchor && State.iUsedNormalAnchors == Header.iNormalAnchors)
	{
		if(!State.bMissionNoFreeNormalAnchorComplete)
		{
			sprintf(byTemp, "%s -> %s", AS_T(T_FillAllNormalAnchors), AS_T(T_Complete));
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeNormalAnchorComplete = TRUE;
		}
	}
	else
	{
		if(Missions.bNoFreeNormalAnchor && State.bMissionNoFreeNormalAnchorComplete)
		{
			sprintf(byTemp, "%s -> %s", AS_T(T_FillAllNormalAnchors), AS_T(T_Incomplete));
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeNormalAnchorComplete = FALSE;
		}
	}
	if(Missions.bNoFreeRedAnchor && State.iUsedRedAnchors == Header.iRedAnchors)
	{
		if(!State.bMissionNoFreeRedAnchorComplete)
		{
			sprintf(byTemp, "%s -> %s", AS_T(T_FillAllRedAnchors), AS_T(T_Complete));
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeRedAnchorComplete = TRUE;
		}
	}
	else
	{
		if(Missions.bNoFreeRedAnchor && State.bMissionNoFreeRedAnchorComplete)
		{
			sprintf(byTemp, "%s -> %s", AS_T(T_FillAllRedAnchors), AS_T(T_Incomplete));
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeRedAnchorComplete = FALSE;
		}
	}
	if(Missions.bNoFreeGreenAnchor && State.iUsedGreenAnchors == Header.iGreenAnchors)
	{
		if(!State.bMissionNoFreeGreenAnchorComplete)
		{
			sprintf(byTemp, "%s -> %s", AS_T(T_FillAllGreenAnchors), AS_T(T_Complete));
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeGreenAnchorComplete = TRUE;
		}
	}
	else
	{
		if(Missions.bNoFreeGreenAnchor && State.bMissionNoFreeGreenAnchorComplete)
		{
			sprintf(byTemp, "%s -> %s", AS_T(T_FillAllGreenAnchors), AS_T(T_Incomplete));
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeGreenAnchorComplete = FALSE;
		}
	}
	if(Missions.bNoFreeBlueAnchor && State.iUsedBlueAnchors == Header.iBlueAnchors)
	{
		if(!State.bMissionNoFreeBlueAnchorComplete)
		{
			sprintf(byTemp, "%s -> %s", AS_T(T_FillAllBlueAnchors), AS_T(T_Complete));
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeBlueAnchorComplete = TRUE;
		}
	}
	else
	{
		if(Missions.bNoFreeBlueAnchor && State.bMissionNoFreeBlueAnchorComplete)
		{
			sprintf(byTemp, "%s -> %s", AS_T(T_FillAllBlueAnchors), AS_T(T_Incomplete));
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeBlueAnchorComplete = FALSE;
		}
	}

	// Check free boxes:
	if(Missions.bNoFreeNormalBox && State.iNoneFreeNormalBoxes == Header.iNormalBoxes)
	{
		if(!State.bMissionNoFreeNormalBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", AS_T(T_NoFreeNormalBox), AS_T(T_Complete));
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeNormalBoxesComplete = TRUE;
		}
	}
	else
	{
		if(Missions.bNoFreeNormalBox && State.bMissionNoFreeNormalBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", AS_T(T_NoFreeNormalBox), AS_T(T_Incomplete));
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeNormalBoxesComplete = FALSE;
		}
	}
	if(Missions.bNoFreeRedBox && State.iNoneFreeRedBoxes == Header.iRedBoxes)
	{
		if(!State.bMissionNoFreeRedBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", AS_T(T_NoFreeRedBox), AS_T(T_Complete));
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeRedBoxesComplete = TRUE;
		}
	}
	else
	{
		if(Missions.bNoFreeRedBox && State.bMissionNoFreeRedBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", AS_T(T_NoFreeRedBox), AS_T(T_Incomplete));
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeRedBoxesComplete = FALSE;
		}
	}
	if(Missions.bNoFreeGreenBox && State.iNoneFreeGreenBoxes == Header.iGreenBoxes)
	{
		if(!State.bMissionNoFreeGreenBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", AS_T(T_NoFreeGreenBox), AS_T(T_Complete));
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeGreenBoxesComplete = TRUE;
		}
	}
	else
	{
		if(Missions.bNoFreeGreenBox && State.bMissionNoFreeGreenBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", AS_T(T_NoFreeGreenBox), AS_T(T_Incomplete));
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeGreenBoxesComplete = FALSE;
		}
	}
	if(Missions.bNoFreeBlueBox && State.iNoneFreeBlueBoxes == Header.iBlueBoxes)
	{
		if(!State.bMissionNoFreeBlueBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", AS_T(T_NoFreeBlueBox), AS_T(T_Complete));
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeBlueBoxesComplete = TRUE;
		}
	}
	else
	{
		if(Missions.bNoFreeBlueBox && State.bMissionNoFreeBlueBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", AS_T(T_NoFreeBlueBox), AS_T(T_Incomplete));
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeBlueBoxesComplete = FALSE;
		}
	}

	// Check destroyed boxes:
	if(Missions.bNoNormalBox && State.iDestroyedNormalBoxes == Header.iNormalBoxes)
	{
		if(!State.bMissionNoNormalBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", AS_T(T_DestroyAllNormalBoxes), AS_T(T_Complete));
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoNormalBoxesComplete = TRUE;
		}
	}
	else
	{
		if(Missions.bNoNormalBox && State.bMissionNoNormalBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", AS_T(T_DestroyAllNormalBoxes), AS_T(T_Incomplete));
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoNormalBoxesComplete = FALSE;
		}
	}
	if(Missions.bNoRedBox && State.iDestroyedRedBoxes == Header.iRedBoxes)
	{
		if(!State.bMissionNoRedBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", AS_T(T_DestroyAllRedBoxes), AS_T(T_Complete));
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoRedBoxesComplete = TRUE;
		}
	}
	else
	{
		if(Missions.bNoRedBox && State.bMissionNoRedBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", AS_T(T_DestroyAllRedBoxes), AS_T(T_Incomplete));
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoRedBoxesComplete = FALSE;
		}
	}
	if(Missions.bNoGreenBox && State.iDestroyedGreenBoxes == Header.iGreenBoxes)
	{
		if(!State.bMissionNoGreenBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", AS_T(T_DestroyAllGreenBoxes), AS_T(T_Complete));
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoGreenBoxesComplete = TRUE;
		}
	}
	else
	{
		if(Missions.bNoGreenBox && State.bMissionNoGreenBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", AS_T(T_DestroyAllGreenBoxes), AS_T(T_Incomplete));
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoGreenBoxesComplete = FALSE;
		}
	}
	if(Missions.bNoBlueBox && State.iDestroyedBlueBoxes == Header.iBlueBoxes)
	{
		if(!State.bMissionNoBlueBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", AS_T(T_DestroyAllBlueBoxes), AS_T(T_Complete));
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoBlueBoxesComplete = TRUE;
		}
	}
	else
	{
		if(Missions.bNoBlueBox && State.bMissionNoBlueBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", AS_T(T_DestroyAllBlueBoxes), AS_T(T_Incomplete));
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoBlueBoxesComplete = FALSE;
		}
	}

	State.Check();
	if(State.bLevelJustComplete && _AS->GetModule() == MODULE_GAME)
	{ // The level is now finished:
		State.bLevelJustComplete = FALSE;
		lPauseTimer = g_lGameTimer;
		bPause = TRUE;
		bLevelPressAnyKey = FALSE;
		lLevelCompleteTimer = g_lGameTimer;
		iLevelCompleteSpeed = 200;
		for(i = 0; i < 256; i++)
			ASKeys[i] = 0;

		if(pPlayer)
		{ // Player stand now:
			pPlayer->Action = AA_STANDING;
			pPlayer->byAnimation = 1;
			pPlayer->iAniStep = 0;
			pPlayer->dwAniTime = g_lGameTimer;
		}
	}

/*	if(!OktaActor.bActive && !State.bLevelComplete && pPlayer && pPlayer->fHealth)
	{
		if((Missions.bTimeLimit && Missions.iTimeLimit <= 0))
		{ // Steps out!
			ShowSmallMessage(AS_M(M_TimeOut), 5000);
			if(Missions.bTimeOkta)
			{ // Wake up the Okta which hunts down the player:
				OktaActor.bActive = TRUE;
				OktaActor.bIsThrown = FALSE;
				OktaActor.fWorldPos[X] = pPlayer->fWorldPos[X];
				OktaActor.fWorldPos[Y] = pPlayer->fWorldPos[Y];
				OktaActor.fWorldPos[Z] = pPlayer->fWorldPos[Z]+pCamera->fZ;
				OktaActor.iAniStep = pOktaModel->Ani.anim[2].firstFrame;
			}
			else
			{ // Mission failed!
				pPlayer->fHealth = 0.0f;
			}
		}
		if((Missions.bStepsLimit && Missions.iStepsLimit <= 0))
		{ // Steps out!
			ShowSmallMessage(AS_M(M_StepsOut), 5000);
			if(Missions.bStepsOkta)
			{ // Wake up the Okta which hunts down the player:
				OktaActor.bActive = TRUE;
				OktaActor.bIsThrown = FALSE;
				OktaActor.fWorldPos[X] = pPlayer->fWorldPos[X];
				OktaActor.fWorldPos[Y] = pPlayer->fWorldPos[Y];
				OktaActor.fWorldPos[Z] = pPlayer->fWorldPos[Z]+pCamera->fZ;
				OktaActor.iAniStep = pOktaModel->Ani.anim[2].firstFrame;
			}
			else
			{ // Mission failed!
				pPlayer->fHealth = 0.0f;
			}
		}
	}*/
} // end LEVEL::CheckMissions()

void LEVEL::ShowMissionState(AS_WINDOW *pWindow, float fBlend)
{ // begin LEVEL::ShowMissionState()
	char byTemp[256];
	int iY = 320;

	if(!fBlend)
		return;
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glColor4f(1.0f, 1.0f, 1.0f, fBlend);
	// Level information:
	if(!State.bLevelComplete)
	{
		pWindow->PrintAnimated(10, 390, Header.byName, 0, 1.0f, fFontAni, 0);
		if(Header.byAuthor[0] != '\0')
		{
			sprintf(byTemp, "%s: %s", AS_T(T_Author), Header.byAuthor);
			pWindow->PrintAnimated(10, 370, byTemp, 0, 1.0f, fFontAni, 0);
		}
	}

	// Show missions state:
	if(State.bLevelComplete)
		pWindow->PrintAnimated(320, 340, AS_T(T_LevelComplete), 0, 1.4f, fFontAni, 1);
	else
		pWindow->PrintAnimated(320, 340, AS_T(T_Missions), 0, 1.4f, fFontAni, 1);
	
	if(Missions.bExit && !State.bMissionExitComplete)
	{
		pWindow->PrintAnimated(320, iY, AS_T(T_GoToExit), 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	if(Missions.bAlcove && !State.bMissionAlcoveComplete)
	{
		pWindow->PrintAnimated(320, iY, AS_T(T_GoToAlcove), 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	// Collect objects:
	if(Missions.bCollectPoints)
	{
	char p[2];
	p[0] = 128;
	p[1] = '\0';
		if(!State.bMissionCollectPointsComplete)
		{
			glColor4f(1.0f, 1.0f, 1.0f, fBlend);
			sprintf(byTemp, "%s (%d)", AS_T(T_CollectPoints), (int) Missions.iCollectPoints-State.iCollectedPoints);
		}
		else
		{
			glColor4f(0.0f, 1.0f, 0.0f, fBlend);
			sprintf(byTemp, "%s %s", p, AS_T(T_CollectPoints));
		}
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	if(Missions.bCollectHealth && !State.bMissionCollectHealthComplete && pPlayer)
	{
		sprintf(byTemp, "%s (%d)", AS_T(T_CollectHealth), (int) (Missions.iCollectHealth-pPlayer->fHealth));
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	if(Missions.bKillMobmobs && !State.bMissionKillMobmobsComplete)
	{
		sprintf(byTemp, "%s (%d)", AS_T(T_KillMobmobs), (int) (Missions.iKillMobmobs-State.iKilledMobmobs));
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	if(Missions.bKillX3 && !State.bMissionKillX3Complete)
	{
		sprintf(byTemp, "%s (%d)", AS_T(T_KillX3), (int) (Missions.iKillX3-State.iKilledX3));
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	// Anchors:
	if(Missions.bNoFreeForAllAnchor && !State.bMissionNoFreeForAllAnchorComplete)
	{
		
		sprintf(byTemp, "%s (%d)", AS_T(T_FillAllForAllAnchors), Header.iForAllAnchors-State.iUsedForAllAnchors);
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	if(Missions.bNoFreeNormalAnchor && !State.bMissionNoFreeNormalAnchorComplete)
	{
		
		sprintf(byTemp, "%s (%d)", AS_T(T_FillAllNormalAnchors), Header.iNormalAnchors-State.iUsedNormalAnchors);
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	if(Missions.bNoFreeRedAnchor &&!State.bMissionNoFreeRedAnchorComplete)
	{
		sprintf(byTemp, "%s (%d)", AS_T(T_FillAllRedAnchors), Header.iRedAnchors-State.iUsedRedAnchors);
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	if(Missions.bNoFreeGreenAnchor &&!State.bMissionNoFreeGreenAnchorComplete)
	{
		sprintf(byTemp, "%s (%d)", AS_T(T_FillAllGreenAnchors), Header.iGreenAnchors-State.iUsedGreenAnchors);
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	if(Missions.bNoFreeBlueAnchor &&!State.bMissionNoFreeBlueAnchorComplete)
	{
		sprintf(byTemp, "%s (%d)", AS_T(T_FillAllBlueAnchors), Header.iBlueAnchors-State.iUsedBlueAnchors);
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}

	// Free boxes:
	if(Missions.bNoFreeNormalBox && !State.bMissionNoFreeNormalBoxesComplete)
	{
		sprintf(byTemp, "%s (%d)", AS_T(T_NoFreeNormalBox), Header.iNormalBoxes-State.iNoneFreeNormalBoxes);
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	if(Missions.bNoFreeRedBox && !State.bMissionNoFreeRedBoxesComplete)
	{
		sprintf(byTemp, "%s (%d)", AS_T(T_NoFreeRedBox), Header.iRedBoxes-State.iNoneFreeRedBoxes);
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	if(Missions.bNoFreeGreenBox && !State.bMissionNoFreeGreenBoxesComplete)
	{
		sprintf(byTemp, "%s (%d)", AS_T(T_NoFreeGreenBox), Header.iGreenBoxes-State.iNoneFreeGreenBoxes);
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	if(Missions.bNoFreeBlueBox && !State.bMissionNoFreeBlueBoxesComplete)
	{
		sprintf(byTemp, "%s (%d)", AS_T(T_NoFreeBlueBox), Header.iBlueBoxes-State.iNoneFreeBlueBoxes);
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}

	// Destroyed boxes:
	if(Missions.bNoNormalBox && !State.bMissionNoNormalBoxesComplete)
	{
		sprintf(byTemp, "%s (%d)", AS_T(T_DestroyAllNormalBoxes), Header.iNormalBoxes-State.iDestroyedNormalBoxes);
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	if(Missions.bNoRedBox && !State.bMissionNoRedBoxesComplete)
	{
		sprintf(byTemp, "%s (%d)", AS_T(T_DestroyAllRedBoxes), Header.iRedBoxes-State.iDestroyedRedBoxes);
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	if(Missions.bNoGreenBox && !State.bMissionNoGreenBoxesComplete)
	{
		sprintf(byTemp, "%s (%d)", AS_T(T_DestroyAllGreenBoxes), Header.iGreenBoxes-State.iDestroyedGreenBoxes);
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	if(Missions.bNoBlueBox && !State.bMissionNoBlueBoxesComplete)
	{
		sprintf(byTemp, "%s (%d)", AS_T(T_DestroyAllBlueBoxes), Header.iBlueBoxes-State.iDestroyedBlueBoxes);
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
} // end LEVEL::ShowMissionState()

void LEVEL_STATE::Check(void)
{ // begin LEVEL_STATE::Check()
	char byTemp[256];
	
	// Check if the mission is complete:
	if(bMissionNoFreeForAllAnchorComplete &&
	   bMissionNoFreeNormalAnchorComplete &&
	   bMissionNoFreeRedAnchorComplete &&
	   bMissionNoFreeGreenAnchorComplete &&
	   bMissionNoFreeBlueAnchorComplete &&
	   bMissionNoNormalBoxesComplete &&
	   bMissionNoRedBoxesComplete &&
	   bMissionNoGreenBoxesComplete &&
	   bMissionNoBlueBoxesComplete &&
	   bMissionNoFreeNormalBoxesComplete &&
	   bMissionNoFreeRedBoxesComplete &&
	   bMissionNoFreeGreenBoxesComplete &&
	   bMissionNoFreeBlueBoxesComplete &&
	   bMissionExitComplete &&
	   bMissionAlcoveComplete &&
	   bMissionCollectPointsComplete &&
	   bMissionCollectHealthComplete &&
	   bMissionKillMobmobsComplete &&
	   bMissionKillX3Complete)
	{ // Yea, the level is complete:
		// Show the level end video if there is one:
		if(pLevel->Header.bStartVideo)
		{
			ASSetPauseFmodMusic(&GameMusic, TRUE);
			ASStopAllFmodSamples(GAME_SAMPLES, GameSample);
			sprintf(byTemp, "%s%s", _AS->byProgramPath, pLevel->Header.byEndVideoFilename);
			ASPlayVideo(GAME_WINDOW_ID, byTemp);
			ASSetPauseFmodMusic(&GameMusic, FALSE);
		}
		bLevelComplete = TRUE;
		bLevelJustComplete = TRUE;
	}
	else
	{
		bLevelComplete = FALSE;
		bLevelJustComplete = FALSE;
	}
} // end LEVEL_STATE::Check()

void LEVEL_MISSIONS::CheckTime(void)
{ // begin LEVEL_MISSIONS::CheckTime()
	if(ASCheckTimeUpdate(&lTimeLimitTime, 1000))
	{
		if(bTimeLimit)
		{
			iTimeLimit--;
			if(iTimeLimit < 0)
				iTimeLimit = 0;
		}
		else
			iTimeLimit++;
	}
} // end LEVEL_MISSIONS::CheckTime()

void LEVEL_MISSIONS::CheckSteps(void)
{ // begin LEVEL_MISSIONS::CheckSteps()
	if(bStepsLimit)
	{
		iStepsLimit--;
		if(iStepsLimit < 0)
			iStepsLimit = 0;
	}
	else
		iStepsLimit++;
} // end LEVEL_MISSIONS::CheckSteps()

void LEVEL_MISSIONS::TimeObj(int iNumber)
{ // begin LEVEL_MISSIONS::TimeObj()
	if(bTimeLimit)
		iTimeLimit += iNumber;
	else
	{
		iTimeLimit -= iNumber;
		if(iTimeLimit < 0)
			iTimeLimit = 0;
	}
} // end LEVEL_MISSIONS::TimeObj()

void LEVEL_MISSIONS::StepsObj(int iNumber)
{ // begin LEVEL_MISSIONS::StepsObj()
	if(pLevel->Missions.bStepsLimit)
		pLevel->Missions.iStepsLimit += iNumber;
	else
	{
		pLevel->Missions.iStepsLimit -= iNumber;
		if(pLevel->Missions.iStepsLimit < 0)
			pLevel->Missions.iStepsLimit = 0;
	}
} // end LEVEL_MISSIONS::StepsObj()

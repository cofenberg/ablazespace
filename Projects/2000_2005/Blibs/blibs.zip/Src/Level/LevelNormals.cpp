//-----------------------------------------------------------------------------
// File: LevelNormals.cpp
//-----------------------------------------------------------------------------

#include "..\AS\AS_Engine.h"
#include "..\ModuleHeaders.h"


// LEVEL functions: ***********************************************************
void LEVEL::CalculateFieldNormals(BOOL bAll)
{ // begin LEVEL::CalculateFieldNormals()
	FIELD_SIDE_QUAD *pFieldSideQuadT;
	int iField, iSide, iQuad;
	FIELD_SIDE *pFieldSideT;
	FIELD *pFieldT;
	int *pPointT;

	// Calculate all normals for the fields:
	for(iField = 0; iField < Header.iFields; iField++)
	{
		pFieldT = &pField[iField];
		if(!bAll && !pFieldT->bUpdate)
			continue;
		for(iSide = 0; iSide < 6; iSide++)
		{
			pFieldSideT = &pFieldT->Side[iSide];
			for(iQuad = 0; iQuad < 4; iQuad++)
			{
				pFieldSideQuadT = &pFieldSideT->SideQuad[iQuad];
				pPointT = &pFieldSideQuadT->iPoint[0];
				NormalizeFace(&pFieldSideQuadT->vNormal[0].fV, fPoint[pPointT[0]],
							  fPoint[pPointT[1]], fPoint[pPointT[3]]);
				NormalizeFace(&pFieldSideQuadT->vNormal[1].fV, fPoint[pPointT[1]],
							  fPoint[pPointT[2]], fPoint[pPointT[3]]);

			    // Find the right and up vectors for each face.
			    // I precomputer them since they are used a lot:
			    pFieldSideQuadT->vNormal[0].GetRightUp(pFieldSideQuadT->vRightNormal[0], pFieldSideQuadT->vUpNormal[0]);
			    pFieldSideQuadT->vNormal[1].GetRightUp(pFieldSideQuadT->vRightNormal[1], pFieldSideQuadT->vUpNormal[1]);

				// Turn the normals, because the level goes to the negative space:
				pFieldSideQuadT->vNormal[0] = -pFieldSideQuadT->vNormal[0];
				pFieldSideQuadT->vNormal[1] = -pFieldSideQuadT->vNormal[1];

				// Get the planes:
				pFieldSideQuadT->Plane[0].ComputeND(fPoint[pPointT[0]], fPoint[pPointT[1]], fPoint[pPointT[3]]);
				pFieldSideQuadT->Plane[1].ComputeND(fPoint[pPointT[1]], fPoint[pPointT[2]], fPoint[pPointT[3]]);
			}
		}
	}
} // end LEVEL::CalculateFieldNormals()

void LEVEL::CalculateWaterNormals(BOOL bOnlyVisible)
{ // begin LEVEL::CalculateWaterNormals()
	int i, iField, iQuad, iElement, *iPointT;
	FIELD_SIDE_QUAD *pFieldSideQuadT, *pFieldSideQuadT1,
					*pFieldSideQuadT2, *pFieldSideQuadT3, *pFieldSideQuadT4;
	FIELD_SIDE *pFieldSideT;
	FIELD **pFieldListT, *pFieldT;
	float fNormalT;

	if(g_lGameTimer-Environment.lLastWaterNormalUpdateTime < 50 &&
	   g_lGameTimer-Environment.lLastWaterNormalUpdateTime > 0)
		return;
	Environment.lLastWaterNormalUpdateTime = g_lGameTimer;
	if(!bOnlyVisible)
	{
		pFieldListT = &pField;
		memset(fWaterNormal, 0, sizeof(FLOAT3)*Header.iLevelPoints);
	}
	else
	{
		pFieldListT = pInFOVFields;
		for(i = 0; i < Header.iLevelPoints; i++)
		{
			if(iVisibleWaterPoints[i] == -1)
				break;
		 	memset(fWaterNormal[iVisibleWaterPoints[i]], 0, sizeof(FLOAT3));
		}
	}
	
	// Calculate all normals for the water fields:
	for(iField = 0; iField < Header.iFields; iField++)
	{
		pFieldT = pFieldListT[iField];
		if(!pFieldT)
			break;
		pFieldSideT = &pFieldT->Side[FACE_WATER];
		if(!pFieldT->bActivateWater)
			continue; // There's no water on that field!
		pFieldSideT->bFaceActive = TRUE;
		for(iQuad = 0; iQuad < 4; iQuad++)
		{
			pFieldSideQuadT = &pFieldSideT->SideQuad[iQuad];
			iPointT = &pFieldSideQuadT->iPoint[0];
			NormalizeFace(&pFieldSideQuadT->vNormal[0].fV, fWaterPoint[iPointT[0]],
						  fWaterPoint[iPointT[1]], fWaterPoint[iPointT[3]]);
			NormalizeFace(&pFieldSideQuadT->vNormal[1].fV, fWaterPoint[iPointT[1]],
						  fWaterPoint[iPointT[2]], fWaterPoint[iPointT[3]]);
			// Turn the normals, because the level goes to the negative space:
			pFieldSideQuadT->vNormal[0] = -pFieldSideQuadT->vNormal[0];
			pFieldSideQuadT->vNormal[1] = -pFieldSideQuadT->vNormal[1];
		}
	}

	// Now calculate each water point normal: 
	for(iField = 0; iField < Header.iFields; iField++)
	{
		pFieldT = pFieldListT[iField];
		if(!pFieldT)
			break;
		pFieldSideT = &pFieldT->Side[FACE_WATER];
		if(!pFieldSideT->bFaceActive)
			continue;
		pFieldSideQuadT1 = &pFieldSideT->SideQuad[0];
		pFieldSideQuadT2 = &pFieldSideT->SideQuad[1];
		pFieldSideQuadT3 = &pFieldSideT->SideQuad[2];
		pFieldSideQuadT4 = &pFieldSideT->SideQuad[3];
		for(iElement = 0; iElement < 3; iElement++)
		{
			// Calculate the left top water normal:
			fNormalT = pFieldSideQuadT1->vNormal[0].fV[iElement];
			if(!fWaterNormal[pFieldSideQuadT1->iPoint[0]][iElement])
				fWaterNormal[pFieldSideQuadT1->iPoint[0]][iElement] = fNormalT;
			else
			{
				fWaterNormal[pFieldSideQuadT1->iPoint[0]][iElement] += fNormalT;
				fWaterNormal[pFieldSideQuadT1->iPoint[0]][iElement] /= 2.0f;
			}
			// Calculate the middle top water normal:
			fNormalT = pFieldSideQuadT1->vNormal[0].fV[iElement]+
					   pFieldSideQuadT1->vNormal[1].fV[iElement]+
					   pFieldSideQuadT2->vNormal[0].fV[iElement];
			fNormalT /= 3;
			if(!fWaterNormal[pFieldSideQuadT1->iPoint[1]][iElement])
				fWaterNormal[pFieldSideQuadT1->iPoint[1]][iElement] = fNormalT;
			else
			{
				fWaterNormal[pFieldSideQuadT1->iPoint[1]][iElement] += fNormalT;
				fWaterNormal[pFieldSideQuadT1->iPoint[1]][iElement] /= 2.0f;
			}
			// Calculate the right top water normal:
			fNormalT = pFieldSideQuadT2->vNormal[0].fV[iElement]+
					   pFieldSideQuadT2->vNormal[1].fV[iElement];
			fNormalT /= 2;
			if(!fWaterNormal[pFieldSideQuadT2->iPoint[1]][iElement])
				fWaterNormal[pFieldSideQuadT2->iPoint[1]][iElement] = fNormalT;
			else
			{
				fWaterNormal[pFieldSideQuadT2->iPoint[1]][iElement] += fNormalT;
				fWaterNormal[pFieldSideQuadT2->iPoint[1]][iElement] /= 2.0f;
			}
			// Calculate the right middle water normal:
			fNormalT = pFieldSideQuadT1->vNormal[1].fV[iElement]+
					   pFieldSideQuadT2->vNormal[0].fV[iElement]+
					   pFieldSideQuadT2->vNormal[1].fV[iElement];
			fNormalT /= 3;
			if(!fWaterNormal[pFieldSideQuadT2->iPoint[2]][iElement])
				fWaterNormal[pFieldSideQuadT2->iPoint[2]][iElement] = fNormalT;
			else
			{
				fWaterNormal[pFieldSideQuadT2->iPoint[2]][iElement] += fNormalT;
				fWaterNormal[pFieldSideQuadT2->iPoint[2]][iElement] /= 2.0f;
			}
			// Calculate the right bottom water normal:
			fNormalT = pFieldSideQuadT3->vNormal[1].fV[iElement];
			if(!fWaterNormal[pFieldSideQuadT3->iPoint[2]][iElement])
				fWaterNormal[pFieldSideQuadT3->iPoint[2]][iElement] = fNormalT;
			else
			{
				fWaterNormal[pFieldSideQuadT3->iPoint[2]][iElement] += fNormalT;
				fWaterNormal[pFieldSideQuadT3->iPoint[2]][iElement] /= 2.0f;
			}
			// Calculate the middle bottom water normal:
			fNormalT = pFieldSideQuadT3->vNormal[0].fV[iElement]+
					   pFieldSideQuadT3->vNormal[1].fV[iElement]+
					   pFieldSideQuadT4->vNormal[1].fV[iElement];
			fNormalT /= 3;
			if(!fWaterNormal[pFieldSideQuadT3->iPoint[3]][iElement])
				fWaterNormal[pFieldSideQuadT3->iPoint[3]][iElement] = fNormalT;
			else
			{
				fWaterNormal[pFieldSideQuadT3->iPoint[3]][iElement] += fNormalT;
				fWaterNormal[pFieldSideQuadT3->iPoint[3]][iElement] /= 2.0f;
			}
			// Calculate the left bottom water normal:
			fNormalT = pFieldSideQuadT4->vNormal[0].fV[iElement]+
					   pFieldSideQuadT4->vNormal[1].fV[iElement];
			fNormalT /= 2;
			if(!fWaterNormal[pFieldSideQuadT4->iPoint[3]][iElement])
				fWaterNormal[pFieldSideQuadT4->iPoint[3]][iElement] = fNormalT;
			else
			{
				fWaterNormal[pFieldSideQuadT4->iPoint[3]][iElement] += fNormalT;
				fWaterNormal[pFieldSideQuadT4->iPoint[3]][iElement] /= 2.0f;
			}
			// Calculate the left middle water normal:
			fNormalT = pFieldSideQuadT4->vNormal[0].fV[iElement]+
					   pFieldSideQuadT1->vNormal[0].fV[iElement]+
					   pFieldSideQuadT1->vNormal[1].fV[iElement];
			fNormalT /= 3;
			if(!fWaterNormal[pFieldSideQuadT4->iPoint[0]][iElement])
				fWaterNormal[pFieldSideQuadT4->iPoint[0]][iElement] = fNormalT;
			else
			{
				fWaterNormal[pFieldSideQuadT4->iPoint[0]][iElement] += fNormalT;
				fWaterNormal[pFieldSideQuadT4->iPoint[0]][iElement] /= 2.0f;
			}
			// Calculate the middle water normal:
			fNormalT = pFieldSideQuadT1->vNormal[1].fV[iElement]+
					   pFieldSideQuadT2->vNormal[0].fV[iElement]+
					   pFieldSideQuadT2->vNormal[1].fV[iElement]+
					   pFieldSideQuadT3->vNormal[0].fV[iElement]+
					   pFieldSideQuadT4->vNormal[0].fV[iElement]+
					   pFieldSideQuadT4->vNormal[1].fV[iElement];
			fNormalT /= 6;
			if(!fWaterNormal[pFieldSideQuadT2->iPoint[2]][iElement])
				fWaterNormal[pFieldSideQuadT2->iPoint[2]][iElement] = fNormalT;
			else
			{
				fWaterNormal[pFieldSideQuadT2->iPoint[2]][iElement] += fNormalT;
				fWaterNormal[pFieldSideQuadT2->iPoint[2]][iElement] /= 2.0f;
			}
		}
	}
} // end LEVEL::CalculateWaterNormals()

void LEVEL::CalculatePointNormals(void)
{ // begin LEVEL::CalculatePointNormals()
	int iField, iElement, iNormals;
	FIELD_SIDE *pSideFloorT, *pSideTopT, *pSideLeftT, *pSideRightT, *pSideBottomT, *pSideFrontT;
	FIELD *pFieldT;
	float fNormalT;

	memset(fNormal, 0, sizeof(FLOAT3)*Header.iPoints);
	// Calculate all normals for the fields:
	for(iField = 0; iField < Header.iFields; iField++)
	{
		pFieldT = &pField[iField];
		pSideFloorT = &pFieldT->Side[FACE_FLOOR];
		pSideTopT = &pFieldT->Side[FACE_TOP];
		pSideLeftT = &pFieldT->Side[FACE_LEFT];
		pSideRightT = &pFieldT->Side[FACE_RIGHT];
		pSideBottomT = &pFieldT->Side[FACE_BOTTOM];
		pSideFrontT = &pFieldT->Side[FACE_FRONT];
		for(iElement = 0; iElement < 3; iElement++)
		{
			// Calculate the left top floor normal:
			iNormals = 0; fNormalT = 0.0f;
			if(pSideFloorT->bFaceActive)
			{
				fNormalT += pSideFloorT->SideQuad[0].vNormal[0].fV[iElement];
				iNormals++;
			}
			if(pSideLeftT->bFaceActive)
			{
				fNormalT += pSideLeftT->SideQuad[3].vNormal[0].fV[iElement]+
							pSideLeftT->SideQuad[3].vNormal[1].fV[iElement];
				iNormals++;
			}
			if(pSideTopT->bFaceActive)
			{
				fNormalT += pSideTopT->SideQuad[2].vNormal[1].fV[iElement];
				iNormals++;
			}
			if(iNormals)
			{
				fNormalT /= iNormals;
				if(!fNormal[pSideFloorT->SideQuad[0].iPoint[0]][iElement])
					fNormal[pSideFloorT->SideQuad[0].iPoint[0]][iElement] = fNormalT;
				else
				{
					fNormal[pSideFloorT->SideQuad[0].iPoint[0]][iElement] += fNormalT;
					fNormal[pSideFloorT->SideQuad[0].iPoint[0]][iElement] /= 2.0f;
				}
			}

			// Calculate the middle top floor normal:
			iNormals = 0; fNormalT = 0.0f;
			if(pSideFloorT->bFaceActive)
			{
				fNormalT += pSideFloorT->SideQuad[0].vNormal[0].fV[iElement]+
							pSideFloorT->SideQuad[0].vNormal[1].fV[iElement]+
							pSideFloorT->SideQuad[1].vNormal[0].fV[iElement];
				iNormals += 3;
			}
			if(pSideTopT->bFaceActive)
			{
				fNormalT += pSideTopT->SideQuad[2].vNormal[0].fV[iElement]+
							pSideTopT->SideQuad[2].vNormal[1].fV[iElement]+
							pSideTopT->SideQuad[3].vNormal[1].fV[iElement];
				iNormals += 3;
			}
			if(iNormals)
			{
				fNormalT /= iNormals;
				if(!fNormal[pSideFloorT->SideQuad[0].iPoint[1]][iElement])
					fNormal[pSideFloorT->SideQuad[0].iPoint[1]][iElement] = fNormalT;
				else
				{
					fNormal[pSideFloorT->SideQuad[0].iPoint[1]][iElement] += fNormalT;
					fNormal[pSideFloorT->SideQuad[0].iPoint[1]][iElement] /= 2.0f;
				}
			}

			// Calculate the right top floor normal:
			iNormals = 0; fNormalT = 0.0f;
			if(pSideFloorT->bFaceActive)
			{
				fNormalT += pSideFloorT->SideQuad[1].vNormal[0].fV[iElement]+
							pSideFloorT->SideQuad[1].vNormal[1].fV[iElement];
				iNormals += 2;
			}
			if(pSideTopT->bFaceActive)
			{
				fNormalT += pSideTopT->SideQuad[3].vNormal[0].fV[iElement]+
							pSideTopT->SideQuad[3].vNormal[1].fV[iElement];
				iNormals += 2;
			}
			if(pSideRightT->bFaceActive)
			{
				fNormalT += pSideRightT->SideQuad[2].vNormal[1].fV[iElement];
				iNormals++;
			}
			if(iNormals)
			{
				fNormalT /= iNormals;
				if(!fNormal[pSideFloorT->SideQuad[1].iPoint[1]][iElement])
					fNormal[pSideFloorT->SideQuad[1].iPoint[1]][iElement] = fNormalT;
				else
				{
					fNormal[pSideFloorT->SideQuad[1].iPoint[1]][iElement] += fNormalT;
					fNormal[pSideFloorT->SideQuad[1].iPoint[1]][iElement] /= 2.0f;
				}
			}

			// Calculate the right middle floor normal:
			iNormals = 0; fNormalT = 0.0f;
			if(pSideFloorT->bFaceActive)
			{
				fNormalT += pSideFloorT->SideQuad[1].vNormal[1].fV[iElement]+
							pSideFloorT->SideQuad[2].vNormal[0].fV[iElement]+
							pSideFloorT->SideQuad[2].vNormal[1].fV[iElement];
				iNormals += 3;
			}
			if(pSideRightT->bFaceActive)
			{
				fNormalT += pSideRightT->SideQuad[2].vNormal[0].fV[iElement]+
							pSideRightT->SideQuad[2].vNormal[1].fV[iElement]+
							pSideRightT->SideQuad[3].vNormal[1].fV[iElement];
				iNormals += 3;
			}
			if(iNormals)
			{
				fNormalT /= iNormals;
				if(!fNormal[pSideFloorT->SideQuad[1].iPoint[2]][iElement])
					fNormal[pSideFloorT->SideQuad[1].iPoint[2]][iElement] = fNormalT;
				else
				{
					fNormal[pSideFloorT->SideQuad[1].iPoint[2]][iElement] += fNormalT;
					fNormal[pSideFloorT->SideQuad[1].iPoint[2]][iElement] /= 2.0f;
				}
			}

			// Calculate the right bottom floor normal:
			iNormals = 0; fNormalT = 0.0f;
			if(pSideFloorT->bFaceActive)
			{
				fNormalT += pSideFloorT->SideQuad[2].vNormal[1].fV[iElement];
				iNormals++;
			}
			if(pSideRightT->bFaceActive)
			{
				fNormalT += pSideRightT->SideQuad[3].vNormal[0].fV[iElement]+
							pSideRightT->SideQuad[3].vNormal[1].fV[iElement];
				iNormals += 2;
			}
			if(pSideBottomT->bFaceActive)
			{
				fNormalT += pSideBottomT->SideQuad[2].vNormal[1].fV[iElement];
				iNormals++;
			}
			if(iNormals)
			{
				fNormalT /= iNormals;
				if(!fNormal[pSideFloorT->SideQuad[2].iPoint[2]][iElement])
					fNormal[pSideFloorT->SideQuad[2].iPoint[2]][iElement] = fNormalT;
				else
				{
					fNormal[pSideFloorT->SideQuad[2].iPoint[2]][iElement] += fNormalT;
					fNormal[pSideFloorT->SideQuad[2].iPoint[2]][iElement] /= 2.0f;
				}
			}

			// Calculate the bottom middle floor normal:
			iNormals = 0; fNormalT = 0.0f;
			if(pSideFloorT->bFaceActive)
			{
				fNormalT += pSideFloorT->SideQuad[3].vNormal[1].fV[iElement]+
							pSideFloorT->SideQuad[2].vNormal[0].fV[iElement]+
							pSideFloorT->SideQuad[2].vNormal[1].fV[iElement];
				iNormals += 3;
			}
			if(pSideBottomT->bFaceActive)
			{
				fNormalT += pSideBottomT->SideQuad[3].vNormal[1].fV[iElement]+
							pSideBottomT->SideQuad[2].vNormal[0].fV[iElement]+
							pSideBottomT->SideQuad[2].vNormal[1].fV[iElement];
				iNormals += 3;
			}
			if(iNormals)
			{
				fNormalT /= iNormals;
				if(!fNormal[pSideFloorT->SideQuad[2].iPoint[3]][iElement])
					fNormal[pSideFloorT->SideQuad[2].iPoint[3]][iElement] = fNormalT;
				else
				{
					fNormal[pSideFloorT->SideQuad[2].iPoint[3]][iElement] += fNormalT;
					fNormal[pSideFloorT->SideQuad[2].iPoint[3]][iElement] /= 2.0f;
				}
			}

			// Calculate the left bottom floor normal:
			iNormals = 0; fNormalT = 0.0f;
			if(pSideFloorT->bFaceActive)
			{
				fNormalT += pSideFloorT->SideQuad[3].vNormal[0].fV[iElement]+
							pSideFloorT->SideQuad[3].vNormal[1].fV[iElement];
				iNormals += 2;
			}
			if(pSideLeftT->bFaceActive)
			{
				fNormalT += pSideLeftT->SideQuad[2].vNormal[1].fV[iElement];
				iNormals++;
			}
			if(pSideBottomT->bFaceActive)
			{
				fNormalT += pSideBottomT->SideQuad[3].vNormal[0].fV[iElement]+
							pSideBottomT->SideQuad[3].vNormal[1].fV[iElement];
				iNormals += 2;
			}
			if(iNormals)
			{
				fNormalT /= iNormals;
				if(!fNormal[pSideFloorT->SideQuad[3].iPoint[3]][iElement])
					fNormal[pSideFloorT->SideQuad[3].iPoint[3]][iElement] = fNormalT;
				else
				{
					fNormal[pSideFloorT->SideQuad[3].iPoint[3]][iElement] += fNormalT;
					fNormal[pSideFloorT->SideQuad[3].iPoint[3]][iElement] /= 2.0f;
				}
			}

			// Calculate the left middle floor normal:
			iNormals = 0; fNormalT = 0.0f;
			if(pSideFloorT->bFaceActive)
			{
				fNormalT += pSideFloorT->SideQuad[0].vNormal[0].fV[iElement]+
							pSideFloorT->SideQuad[0].vNormal[1].fV[iElement]+
							pSideFloorT->SideQuad[3].vNormal[0].fV[iElement];
				iNormals += 3;
			}
			if(pSideLeftT->bFaceActive)
			{
				fNormalT += pSideLeftT->SideQuad[3].vNormal[1].fV[iElement]+
							pSideLeftT->SideQuad[2].vNormal[0].fV[iElement]+
							pSideLeftT->SideQuad[2].vNormal[1].fV[iElement];
				iNormals += 3;
			}
			if(iNormals)
			{
				fNormalT /= iNormals;
				if(!fNormal[pSideFloorT->SideQuad[0].iPoint[3]][iElement])
					fNormal[pSideFloorT->SideQuad[0].iPoint[3]][iElement] = fNormalT;
				else
				{
					fNormal[pSideFloorT->SideQuad[0].iPoint[3]][iElement] += fNormalT;
					fNormal[pSideFloorT->SideQuad[0].iPoint[3]][iElement] /= 2.0f;
				}
			}

			// Calculate the middle floor normal:
			if(pSideFloorT->bFaceActive)
			{
				fNormalT = pSideFloorT->SideQuad[0].vNormal[1].fV[iElement]+
						   pSideFloorT->SideQuad[1].vNormal[0].fV[iElement]+
						   pSideFloorT->SideQuad[1].vNormal[1].fV[iElement]+
						   pSideFloorT->SideQuad[2].vNormal[0].fV[iElement]+
						   pSideFloorT->SideQuad[3].vNormal[0].fV[iElement]+
						   pSideFloorT->SideQuad[3].vNormal[1].fV[iElement];
				fNormalT /= 6.0f;
				if(!fNormal[pSideFloorT->SideQuad[0].iPoint[2]][iElement])
					fNormal[pSideFloorT->SideQuad[0].iPoint[2]][iElement] = fNormalT;
				else
				{
					fNormal[pSideFloorT->SideQuad[0].iPoint[2]][iElement] += fNormalT;
					fNormal[pSideFloorT->SideQuad[0].iPoint[2]][iElement] /= 2.0f;
				}
			}




			// Calculate the left top middle normal:
			iNormals = 0; fNormalT = 0.0f;
			if(pSideLeftT->bFaceActive)
			{
				fNormalT += pSideLeftT->SideQuad[0].vNormal[0].fV[iElement]+
							pSideLeftT->SideQuad[0].vNormal[1].fV[iElement]+
							pSideLeftT->SideQuad[3].vNormal[0].fV[iElement];
				iNormals += 3;
			}
			if(pSideTopT->bFaceActive)
			{
				fNormalT += pSideTopT->SideQuad[1].vNormal[1].fV[iElement]+
							pSideTopT->SideQuad[2].vNormal[0].fV[iElement]+
							pSideTopT->SideQuad[2].vNormal[1].fV[iElement];
				iNormals += 3;
			}
			if(iNormals)
			{
				fNormalT /= iNormals;
				if(!fNormal[pSideLeftT->SideQuad[0].iPoint[3]][iElement])
					fNormal[pSideLeftT->SideQuad[0].iPoint[3]][iElement] = fNormalT;
				else
				{
					fNormal[pSideLeftT->SideQuad[0].iPoint[3]][iElement] += fNormalT;
					fNormal[pSideLeftT->SideQuad[0].iPoint[3]][iElement] /= 2.0f;
				}
			}

			// Calculate the middle top middle normal:
			if(pSideTopT->bFaceActive)
			{
				fNormalT = pSideTopT->SideQuad[0].vNormal[1].fV[iElement]+
						   pSideTopT->SideQuad[1].vNormal[0].fV[iElement]+
						   pSideTopT->SideQuad[1].vNormal[1].fV[iElement]+
						   pSideTopT->SideQuad[2].vNormal[0].fV[iElement]+
						   pSideTopT->SideQuad[3].vNormal[0].fV[iElement]+
						   pSideTopT->SideQuad[3].vNormal[1].fV[iElement];
				fNormalT /= 6.0f;
				if(!fNormal[pSideTopT->SideQuad[0].iPoint[2]][iElement])
					fNormal[pSideTopT->SideQuad[0].iPoint[2]][iElement] = fNormalT;
				else
				{
					fNormal[pSideTopT->SideQuad[0].iPoint[2]][iElement] += fNormalT;
					fNormal[pSideTopT->SideQuad[0].iPoint[2]][iElement] /= 2.0f;
				}
			}

			// Calculate the right top middle normal:
			iNormals = 0; fNormalT = 0.0f;
			if(pSideTopT->bFaceActive)
			{
				fNormalT += pSideTopT->SideQuad[0].vNormal[0].fV[iElement]+
							pSideTopT->SideQuad[0].vNormal[1].fV[iElement]+
							pSideTopT->SideQuad[3].vNormal[0].fV[iElement];
				iNormals += 3;
			}
			if(pSideRightT->bFaceActive)
			{
				fNormalT += pSideRightT->SideQuad[1].vNormal[1].fV[iElement]+
							pSideRightT->SideQuad[2].vNormal[0].fV[iElement]+
							pSideRightT->SideQuad[2].vNormal[1].fV[iElement];
				iNormals += 3;
			}
			if(iNormals)
			{
				fNormalT /= iNormals;
				if(!fNormal[pSideRightT->SideQuad[1].iPoint[2]][iElement])
					fNormal[pSideRightT->SideQuad[1].iPoint[2]][iElement] = fNormalT;
				else
				{
					fNormal[pSideRightT->SideQuad[1].iPoint[2]][iElement] += fNormalT;
					fNormal[pSideRightT->SideQuad[1].iPoint[2]][iElement] /= 2.0f;
				}
			}

			// Calculate the right middle middle normal:
			if(pSideRightT->bFaceActive)
			{
				fNormalT = pSideRightT->SideQuad[0].vNormal[1].fV[iElement]+
						   pSideRightT->SideQuad[1].vNormal[0].fV[iElement]+
						   pSideRightT->SideQuad[1].vNormal[1].fV[iElement]+
						   pSideRightT->SideQuad[2].vNormal[0].fV[iElement]+
						   pSideRightT->SideQuad[3].vNormal[0].fV[iElement]+
						   pSideRightT->SideQuad[3].vNormal[1].fV[iElement];
				fNormalT /= 6.0f;
				if(!fNormal[pSideRightT->SideQuad[0].iPoint[2]][iElement])
					fNormal[pSideRightT->SideQuad[0].iPoint[2]][iElement] = fNormalT;
				else
				{
					fNormal[pSideRightT->SideQuad[0].iPoint[2]][iElement] += fNormalT;
					fNormal[pSideRightT->SideQuad[0].iPoint[2]][iElement] /= 2.0f;
				}
			}

			// Calculate the right bottom middle normal:
			iNormals = 0; fNormalT = 0.0f;
			if(pSideRightT->bFaceActive)
			{
				fNormalT += pSideRightT->SideQuad[0].vNormal[0].fV[iElement]+
							pSideRightT->SideQuad[0].vNormal[1].fV[iElement]+
							pSideRightT->SideQuad[3].vNormal[0].fV[iElement];
				iNormals += 3;
			}
			if(pSideBottomT->bFaceActive)
			{
				fNormalT += pSideBottomT->SideQuad[1].vNormal[1].fV[iElement]+
							pSideBottomT->SideQuad[2].vNormal[0].fV[iElement]+
							pSideBottomT->SideQuad[2].vNormal[1].fV[iElement];
				iNormals += 3;
			}
			if(iNormals)
			{
				fNormalT /= iNormals;
				if(!fNormal[pSideRightT->SideQuad[0].iPoint[3]][iElement])
					fNormal[pSideRightT->SideQuad[0].iPoint[3]][iElement] = fNormalT;
				else
				{
					fNormal[pSideRightT->SideQuad[0].iPoint[3]][iElement] += fNormalT;
					fNormal[pSideRightT->SideQuad[0].iPoint[3]][iElement] /= 2.0f;
				}
			}

			// Calculate the bottom middle middle normal:
			if(pSideBottomT->bFaceActive)
			{
				fNormalT = pSideBottomT->SideQuad[0].vNormal[1].fV[iElement]+
						   pSideBottomT->SideQuad[1].vNormal[0].fV[iElement]+
						   pSideBottomT->SideQuad[1].vNormal[1].fV[iElement]+
						   pSideBottomT->SideQuad[2].vNormal[0].fV[iElement]+
						   pSideBottomT->SideQuad[3].vNormal[0].fV[iElement]+
						   pSideBottomT->SideQuad[3].vNormal[1].fV[iElement];
				fNormalT /= 6.0f;
				if(!fNormal[pSideBottomT->SideQuad[0].iPoint[2]][iElement])
					fNormal[pSideBottomT->SideQuad[0].iPoint[2]][iElement] = fNormalT;
				else
				{
					fNormal[pSideBottomT->SideQuad[0].iPoint[2]][iElement] += fNormalT;
					fNormal[pSideBottomT->SideQuad[0].iPoint[2]][iElement] /= 2.0f;
				}
			}

			// Calculate the left bottom middle normal:
			iNormals = 0; fNormalT = 0.0f;
			if(pSideLeftT->bFaceActive)
			{
				fNormalT += pSideLeftT->SideQuad[1].vNormal[1].fV[iElement]+
							pSideLeftT->SideQuad[2].vNormal[0].fV[iElement]+
							pSideLeftT->SideQuad[2].vNormal[1].fV[iElement];
				iNormals += 3;
			}
			if(pSideBottomT->bFaceActive)
			{
				fNormalT += pSideBottomT->SideQuad[0].vNormal[0].fV[iElement]+
							pSideBottomT->SideQuad[0].vNormal[1].fV[iElement]+
							pSideBottomT->SideQuad[3].vNormal[0].fV[iElement];
				iNormals += 3;
			}
			if(iNormals)
			{
				fNormalT /= iNormals;
				if(!fNormal[pSideLeftT->SideQuad[1].iPoint[2]][iElement])
					fNormal[pSideLeftT->SideQuad[1].iPoint[2]][iElement] = fNormalT;
				else
				{
					fNormal[pSideLeftT->SideQuad[1].iPoint[2]][iElement] += fNormalT;
					fNormal[pSideLeftT->SideQuad[1].iPoint[2]][iElement] /= 2.0f;
				}
			}

			// Calculate the left middle middle normal:
			if(pSideLeftT->bFaceActive)
			{
				fNormalT = pSideLeftT->SideQuad[0].vNormal[1].fV[iElement]+
						   pSideLeftT->SideQuad[1].vNormal[0].fV[iElement]+
						   pSideLeftT->SideQuad[1].vNormal[1].fV[iElement]+
						   pSideLeftT->SideQuad[2].vNormal[0].fV[iElement]+
						   pSideLeftT->SideQuad[3].vNormal[0].fV[iElement]+
						   pSideLeftT->SideQuad[3].vNormal[1].fV[iElement];
				fNormalT /= 6.0f;
				if(!fNormal[pSideLeftT->SideQuad[0].iPoint[2]][iElement])
					fNormal[pSideLeftT->SideQuad[0].iPoint[2]][iElement] = fNormalT;
				else
				{
					fNormal[pSideLeftT->SideQuad[0].iPoint[2]][iElement] += fNormalT;
					fNormal[pSideLeftT->SideQuad[0].iPoint[2]][iElement] /= 2.0f;
				}
			}




			// Calculate the left top front normal:
			iNormals = 0; fNormalT = 0.0f;
			if(pSideFrontT->bFaceActive)
			{
				fNormalT += pSideFrontT->SideQuad[0].vNormal[0].fV[iElement];
				iNormals++;
			}
			if(pSideLeftT->bFaceActive)
			{
				fNormalT += pSideLeftT->SideQuad[0].vNormal[0].fV[iElement];
				iNormals++;
			}
			if(pSideTopT->bFaceActive)
			{
				fNormalT += pSideTopT->SideQuad[1].vNormal[0].fV[iElement]+
							pSideTopT->SideQuad[1].vNormal[1].fV[iElement];
				iNormals += 2;
			}
			if(iNormals)
			{
				fNormalT /= iNormals;
				if(!fNormal[pSideFrontT->SideQuad[0].iPoint[0]][iElement])
					fNormal[pSideFrontT->SideQuad[0].iPoint[0]][iElement] = fNormalT;
				else
				{
					fNormal[pSideFrontT->SideQuad[0].iPoint[0]][iElement] += fNormalT;
					fNormal[pSideFrontT->SideQuad[0].iPoint[0]][iElement] /= 2.0f;
				}
			}

			// Calculate the middle top front normal:
			iNormals = 0; fNormalT = 0.0f;
			if(pSideFrontT->bFaceActive)
			{
				fNormalT += pSideFrontT->SideQuad[0].vNormal[0].fV[iElement]+
							pSideFrontT->SideQuad[0].vNormal[1].fV[iElement]+
							pSideFrontT->SideQuad[1].vNormal[0].fV[iElement];
				iNormals += 3;
			}
			if(pSideTopT->bFaceActive)
			{
				fNormalT += pSideTopT->SideQuad[0].vNormal[0].fV[iElement]+
							pSideTopT->SideQuad[0].vNormal[1].fV[iElement]+
							pSideTopT->SideQuad[1].vNormal[0].fV[iElement];
				iNormals += 3;
			}
			if(iNormals)
			{
				fNormalT /= iNormals;
				if(!fNormal[pSideFrontT->SideQuad[0].iPoint[1]][iElement])
					fNormal[pSideFrontT->SideQuad[0].iPoint[1]][iElement] = fNormalT;
				else
				{
					fNormal[pSideFrontT->SideQuad[0].iPoint[1]][iElement] += fNormalT;
					fNormal[pSideFrontT->SideQuad[0].iPoint[1]][iElement] /= 2.0f;
				}
			}

			// Calculate the right top front normal:
			iNormals = 0; fNormalT = 0.0f;
			if(pSideFrontT->bFaceActive)
			{
				fNormalT += pSideFrontT->SideQuad[1].vNormal[0].fV[iElement]+
							pSideFrontT->SideQuad[1].vNormal[1].fV[iElement];
				iNormals += 2;
			}
			if(pSideTopT->bFaceActive)
			{
				fNormalT += pSideTopT->SideQuad[0].vNormal[0].fV[iElement];
				iNormals++;
			}
			if(pSideRightT->bFaceActive)
			{
				fNormalT += pSideRightT->SideQuad[1].vNormal[0].fV[iElement]+
							pSideRightT->SideQuad[1].vNormal[1].fV[iElement];
				iNormals += 2;
			}
			if(iNormals)
			{
				fNormalT /= iNormals;
				if(!fNormal[pSideFrontT->SideQuad[1].iPoint[1]][iElement])
					fNormal[pSideFrontT->SideQuad[1].iPoint[1]][iElement] = fNormalT;
				else
				{
					fNormal[pSideFrontT->SideQuad[1].iPoint[1]][iElement] += fNormalT;
					fNormal[pSideFrontT->SideQuad[1].iPoint[1]][iElement] /= 2.0f;
				}
			}

			// Calculate the right middle front normal:
			iNormals = 0; fNormalT = 0.0f;
			if(pSideFrontT->bFaceActive)
			{
				fNormalT += pSideFrontT->SideQuad[1].vNormal[1].fV[iElement]+
							pSideFrontT->SideQuad[2].vNormal[0].fV[iElement]+
							pSideFrontT->SideQuad[2].vNormal[1].fV[iElement];
				iNormals += 3;
			}
			if(pSideRightT->bFaceActive)
			{
				fNormalT += pSideRightT->SideQuad[0].vNormal[0].fV[iElement]+
							pSideRightT->SideQuad[0].vNormal[1].fV[iElement]+
							pSideRightT->SideQuad[1].vNormal[0].fV[iElement];
				iNormals += 3;
			}
			if(iNormals)
			{
				fNormalT /= iNormals;
				if(!fNormal[pSideFrontT->SideQuad[1].iPoint[2]][iElement])
					fNormal[pSideFrontT->SideQuad[1].iPoint[2]][iElement] = fNormalT;
				else
				{
					fNormal[pSideFrontT->SideQuad[1].iPoint[2]][iElement] += fNormalT;
					fNormal[pSideFrontT->SideQuad[1].iPoint[2]][iElement] /= 2.0f;
				}
			}

			// Calculate the right bottom front normal:
			iNormals = 0; fNormalT = 0.0f;
			if(pSideFrontT->bFaceActive)
			{
				fNormalT += pSideFrontT->SideQuad[2].vNormal[1].fV[iElement];
				iNormals++;
			}
			if(pSideRightT->bFaceActive)
			{
				fNormalT += pSideRightT->SideQuad[0].vNormal[0].fV[iElement];
				iNormals++;
			}
			if(pSideBottomT->bFaceActive)
			{
				fNormalT += pSideBottomT->SideQuad[1].vNormal[0].fV[iElement]+
							pSideBottomT->SideQuad[1].vNormal[1].fV[iElement];
				iNormals += 2;
			}
			if(iNormals)
			{
				fNormalT /= iNormals;
				if(!fNormal[pSideFrontT->SideQuad[2].iPoint[2]][iElement])
					fNormal[pSideFrontT->SideQuad[2].iPoint[2]][iElement] = fNormalT;
				else
				{
					fNormal[pSideFrontT->SideQuad[2].iPoint[2]][iElement] += fNormalT;
					fNormal[pSideFrontT->SideQuad[2].iPoint[2]][iElement] /= 2.0f;
				}
			}

			// Calculate the bottom middle front normal:
			iNormals = 0; fNormalT = 0.0f;
			if(pSideFrontT->bFaceActive)
			{
				fNormalT += pSideFrontT->SideQuad[2].vNormal[0].fV[iElement]+
							pSideFrontT->SideQuad[2].vNormal[1].fV[iElement]+
							pSideFrontT->SideQuad[3].vNormal[1].fV[iElement];
				iNormals += 3;
			}
			if(pSideBottomT->bFaceActive)
			{
				fNormalT += pSideBottomT->SideQuad[0].vNormal[0].fV[iElement]+
							pSideBottomT->SideQuad[0].vNormal[1].fV[iElement]+
							pSideBottomT->SideQuad[1].vNormal[0].fV[iElement];
				iNormals += 3;
			}
			if(iNormals)
			{
				fNormalT /= iNormals;
				if(!fNormal[pSideFrontT->SideQuad[2].iPoint[3]][iElement])
					fNormal[pSideFrontT->SideQuad[2].iPoint[3]][iElement] = fNormalT;
				else
				{
					fNormal[pSideFrontT->SideQuad[2].iPoint[3]][iElement] += fNormalT;
					fNormal[pSideFrontT->SideQuad[2].iPoint[3]][iElement] /= 2.0f;
				}
			}

			// Calculate the left bottom front normal:
			iNormals = 0; fNormalT = 0.0f;
			if(pSideFrontT->bFaceActive)
			{
				fNormalT += pSideFrontT->SideQuad[3].vNormal[0].fV[iElement]+
							pSideFrontT->SideQuad[3].vNormal[1].fV[iElement];
				iNormals += 2;
			}
			if(pSideLeftT->bFaceActive)
			{
				fNormalT += pSideLeftT->SideQuad[1].vNormal[0].fV[iElement]+
							pSideLeftT->SideQuad[1].vNormal[1].fV[iElement];
				iNormals += 2;
			}
			if(pSideBottomT->bFaceActive)
			{
				fNormalT += pSideBottomT->SideQuad[0].vNormal[0].fV[iElement];
				iNormals++;
			}
			if(iNormals)
			{
				fNormalT /= iNormals;
				if(!fNormal[pSideFrontT->SideQuad[3].iPoint[3]][iElement])
					fNormal[pSideFrontT->SideQuad[3].iPoint[3]][iElement] = fNormalT;
				else
				{
					fNormal[pSideFrontT->SideQuad[3].iPoint[3]][iElement] += fNormalT;
					fNormal[pSideFrontT->SideQuad[3].iPoint[3]][iElement] /= 2.0f;
				}
			}

			// Calculate the left middle front normal:
			iNormals = 0; fNormalT = 0.0f;
			if(pSideFrontT->bFaceActive)
			{
				fNormalT += pSideFrontT->SideQuad[0].vNormal[0].fV[iElement]+
							pSideFrontT->SideQuad[0].vNormal[1].fV[iElement]+
							pSideFrontT->SideQuad[3].vNormal[0].fV[iElement];
				iNormals += 3;
			}
			if(pSideLeftT->bFaceActive)
			{
				fNormalT += pSideLeftT->SideQuad[0].vNormal[0].fV[iElement]+
							pSideLeftT->SideQuad[0].vNormal[1].fV[iElement]+
							pSideLeftT->SideQuad[1].vNormal[0].fV[iElement];
				iNormals += 3;
			}
			if(iNormals)
			{
				fNormalT /= iNormals;
				if(!fNormal[pSideFrontT->SideQuad[0].iPoint[3]][iElement])
					fNormal[pSideFrontT->SideQuad[0].iPoint[3]][iElement] = fNormalT;
				else
				{
					fNormal[pSideFrontT->SideQuad[0].iPoint[3]][iElement] += fNormalT;
					fNormal[pSideFrontT->SideQuad[0].iPoint[3]][iElement] /= 2.0f;
				}
			}

			// Calculate the middle front normal:
			if(pSideFrontT->bFaceActive)
			{
				fNormalT = pSideFrontT->SideQuad[0].vNormal[1].fV[iElement]+
						   pSideFrontT->SideQuad[1].vNormal[0].fV[iElement]+
						   pSideFrontT->SideQuad[1].vNormal[1].fV[iElement]+
						   pSideFrontT->SideQuad[2].vNormal[0].fV[iElement]+
						   pSideFrontT->SideQuad[3].vNormal[0].fV[iElement]+
						   pSideFrontT->SideQuad[3].vNormal[1].fV[iElement];
				fNormalT /= 6.0f;
				if(!fNormal[pSideFrontT->SideQuad[0].iPoint[2]][iElement])
					fNormal[pSideFrontT->SideQuad[0].iPoint[2]][iElement] = fNormalT;
				else
				{
					fNormal[pSideFrontT->SideQuad[0].iPoint[2]][iElement] += fNormalT;
					fNormal[pSideFrontT->SideQuad[0].iPoint[2]][iElement] /= 2.0f;
				}
			}
		}
	}
} // end LEVEL::CalculatePointNormals()
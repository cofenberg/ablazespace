//-----------------------------------------------------------------------------
// File: Level.cpp
//-----------------------------------------------------------------------------

#include "..\AS\AS_Engine.h"
#include "..\ModuleHeaders.h"


// LEVEL functions: ***********************************************************
// Initialize the new level:
LEVEL::LEVEL(void)
{ // begin LEVEL::LEVEL()
	memset(this, 0, sizeof(LEVEL));
	SetLevelStandartValues();
} // end LEVEL::LEVEL()

// Level destructor:
LEVEL::~LEVEL(void)
{ // begin LEVEL::~LEVEL()
} // end LEVEL::~LEVEL()

// Setup the standart level configurations:
void LEVEL::SetLevelStandartValues(void)
{ // begin LEVEL::SetLevelStandartValues()
	int i;
	
	Header.iWidth = 21; 
	Header.iHeight = 21;
	Header.bSingle = TRUE;
	Header.bEndScreen = TRUE;
	strcpy(Header.byName, "Noname");
	Header.iMaxActors = 100;

	for(i = 0; i < 3; i++)
	{
		Environment.fSkyCubeColor[i] = 1.0f;
		Environment.fSkyCubeSize[i] = 1000.0f;
		Environment.fFogColor[i] = 0.0f;
		Environment.fColor[i] = 0.7f;
	}
	Environment.fFogDensity = 0.05f;
	Environment.fShadowsDensity_Size[0] = 0.5f;
	Environment.fShadowsDensity_Size[1] = 1.0f;
	Environment.fWaterHeight = -0.3f;
	Environment.fWaterWaveAmplitude = 1.0f;
	Environment.fWaterWaveSpeed = 1.0f;
	Environment.fWaterWaveSize[X] = 
	Environment.fWaterWaveSize[Y] = 1.0f;
	Environment.fWaterBubblesColor[R] = Environment.fWaterBubblesColor[G] = 
	Environment.fWaterBubblesColor[B] = 1.0f;
	Environment.fWaterBubblesDensity = 0.9f;
	Environment.fWaterBubblesSpeed = 1.0f;
	Environment.fWaterBubblesFrequency = 1.0f;
	Environment.fWaterBubblesSize = 1.0f;

	Missions.bExit = TRUE;

	Camera.bFreeCamera = TRUE;
	Camera.bPlayerCamera = TRUE;
	Camera.bStandartCamera = TRUE;
} // end LEVEL::SetLevelStandartValues()

void LEVEL::SetStandartView(void)
{ // begin LEVEL::SetStandartView()
	memset(pCamera, 0, sizeof(AS_CAMERA));
	pCamera->fPos[X] = -Header.fWholeWidth/2;
	pCamera->fPos[Y] = -Header.fWholeHeight/2-3.0f;
	pCamera->fPos[Z] = -15.0f;
	pCamera->fRot[X] = -30.0f;
	pCamera->fZ = -7.0f;
} // end LEVEL::SetStandartView()

// Checks if the given position is correct: (short: if its in the level)
BOOL LEVEL::CheckIfCorrectPos(int iX, int iY)
{ // begin LEVEL::CheckIfCorrectPos()
	if(iX < 0 || iX >= Header.iWidth-1 ||
	   iY < 0 || iY >= Header.iHeight-1)
		return FALSE; // NO! Its outside our world!!

	return TRUE; // Thats an correct position!
} // end LEVEL::CheckIfCorrectPos()

// Generates the OpenGL level textures:
void LEVEL::GenTexturesOpenGL(HDC hDC, HGLRC hRC)
{ // begin LEVEL::GenTextures()
	AS_PROGRESS_WINDOW ProgressWindow;
	AS_TEXTURE *pTextureT;

	if(!wglMakeCurrent(hDC, hRC))
		return;

	ProgressWindow.CreateProgressWindow("Load world");
	ProgressWindow.SetTask("Generate OpenGL level textures...");
	ProgressWindow.SetProgress(0);

	_AS->WriteLogMessage("Create OpenGL level textures");
	for(int i = 0; i < Header.iTextures; i++)
	{
		pTextureT = &pTexture[i];
		ProgressWindow.SetSubTask("%s", pTextureT->byFilename);
		ProgressWindow.SetProgress((UINT) (((float) i/Header.iTextures)*100));

		// First delete the old textures:
		if(pTextureT->iOpenGLID > 2)
			glDeleteTextures(1, &pTextureT->iOpenGLID);
		_AS->WriteLogMessage(pTextureT->byFilename);

		// Now generate the new:
		glGenTextures(1, &pTextureT->iOpenGLID);
		glBindTexture(GL_TEXTURE_2D, pTextureT->iOpenGLID);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
		if(_ASConfig->bUseMipmaps && !pTextureT->bNoMipmap)
		{
			if(_ASConfig->bFastTexturing)
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST_MIPMAP_NEAREST);
				gluBuild2DMipmaps(GL_TEXTURE_2D, pTextureT->byColorComponents, pTextureT->iWidth,
								  pTextureT->iHeight, pTextureT->iFormat, GL_UNSIGNED_BYTE,
								  pTextureT->pbyData);
			}
			else
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);
				gluBuild2DMipmaps(GL_TEXTURE_2D, pTextureT->byColorComponents, pTextureT->iWidth,
								  pTextureT->iHeight, pTextureT->iFormat, GL_UNSIGNED_BYTE,
								  pTextureT->pbyData);
			}
		}
		else
		{
			if(_ASConfig->bFastTexturing)
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
				glTexImage2D(GL_TEXTURE_2D, 0, pTextureT->byColorComponents, pTextureT->iWidth,
							 pTextureT->iHeight, 0, pTextureT->iFormat, GL_UNSIGNED_BYTE,
							 pTextureT->pbyData);
			}
			else
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
				glTexImage2D(GL_TEXTURE_2D, 0, pTextureT->byColorComponents, pTextureT->iWidth,
							 pTextureT->iHeight, 0, pTextureT->iFormat, GL_UNSIGNED_BYTE,
							 pTextureT->pbyData);
			}
		}
	}
} // end LEVEL::GenTextures()

// Destroys the OpenGL level textures:
void LEVEL::DestroyTexturesOpenGL(HDC hDC, HGLRC hRC)
{ // begin LEVEL::DestroyTexturesOpenGL()
	AS_TEXTURE *pTextureT;

	if(!hDC || !hRC || !wglMakeCurrent(hDC, hRC))
		return;
	AS_PROGRESS_WINDOW ProgressWindow;

	ProgressWindow.CreateProgressWindow("Destroy textures");
	ProgressWindow.SetTask("Destroy OpenGL level textures...");
	ProgressWindow.SetProgress(0);
	_AS->WriteLogMessage("Destroy OpenGL level textures");
	for(int i = 0; i < Header.iTextures; i++)
	{
		pTextureT = &pTexture[i];
		_AS->WriteLogMessage(pTextureT->byFilename);
		ProgressWindow.SetSubTask("%s", pTextureT->byFilename);
		ProgressWindow.SetProgress((UINT) (((float) i/Header.iTextures)*100));
		if(!pTextureT->iOpenGLID)
			continue;
		glDeleteTextures(1, &pTextureT->iOpenGLID);
		pTextureT->iOpenGLID = 0;
	}
} // end LEVEL::DestroyTexturesOpenGL()

// Creates an new surface:
HRESULT LEVEL::CreateSurface(void)
{ // begin LEVEL::CreateSurface()
	FIELD *pFieldT;
	int i, i2, i3;

	Header.iSurfaces++;
	pSurface = (SURFACE *) realloc(pSurface, sizeof(SURFACE)*Header.iSurfaces);
	iCurrentSurface = Header.iSurfaces-1;
	pCurrentSurface = &pSurface[iCurrentSurface];
	memset(pCurrentSurface, 0, sizeof(SURFACE));
	pCurrentSurface->Header.iID = Header.iSurfaces-1;
	pCurrentSurface->Header.iAniSteps = 1;
	pCurrentSurface->Header.fAlcoveSpeed = 1.0f;
	pCurrentSurface->Header.fRadioactiveSpeed = 1.0f;
	pCurrentSurface->Header.fHealthSpeed = 1.0f;
	pCurrentSurface->Header.fFriction = 1.0f;
	pCurrentSurface->pTexturePos = (TEXTURE_POS *) malloc(sizeof(TEXTURE_POS)*pCurrentSurface->Header.iAniSteps);
	pCurrentSurface->byTextureFilename = (char **) malloc(sizeof(char *)*pCurrentSurface->Header.iAniSteps);
	pCurrentSurface->iTextureID = (int *) malloc(sizeof(int)*pCurrentSurface->Header.iAniSteps);
	pCurrentSurface->pTexture = (AS_TEXTURE **) malloc(sizeof(AS_TEXTURE)*pCurrentSurface->Header.iAniSteps);
	for(i = 0; i < pCurrentSurface->Header.iAniSteps; i++)
	{
		pCurrentSurface->byTextureFilename[i] = (char *) malloc(sizeof(char)*MAX_PATH);
		strcpy(pCurrentSurface->byTextureFilename[i], pTexture[0].byFilename);
		pCurrentSurface->iTextureID[i] = 0;
		pCurrentSurface->pTexture[i] = &pTexture[pCurrentSurface->iTextureID[i]];
		pCurrentSurface->pTexture[0]->iUsed++;
	}
	memset(&pCurrentSurface->pTexturePos[0], 0, sizeof(TEXTURE_POS));
	pCurrentSurface->pTexturePos[0].iPos[0][X] = 0;
	pCurrentSurface->pTexturePos[0].iPos[0][Y] = 0;
	pCurrentSurface->pTexturePos[0].iPos[1][X] = pCurrentSurface->pTexture[0]->iWidth/2-1;
	pCurrentSurface->pTexturePos[0].iPos[1][Y] = 0;
	pCurrentSurface->pTexturePos[0].iPos[2][X] = pCurrentSurface->pTexture[0]->iWidth-1;
	pCurrentSurface->pTexturePos[0].iPos[2][Y] = 0;
	pCurrentSurface->pTexturePos[0].iPos[3][X] = pCurrentSurface->pTexture[0]->iWidth-1;
	pCurrentSurface->pTexturePos[0].iPos[3][Y] = pCurrentSurface->pTexture[0]->iHeight/2-2;
	pCurrentSurface->pTexturePos[0].iPos[4][X] = pCurrentSurface->pTexture[0]->iWidth-1;
	pCurrentSurface->pTexturePos[0].iPos[4][Y] = pCurrentSurface->pTexture[0]->iHeight-2;
	pCurrentSurface->pTexturePos[0].iPos[5][X] = pCurrentSurface->pTexture[0]->iWidth/2-1;
	pCurrentSurface->pTexturePos[0].iPos[5][Y] = pCurrentSurface->pTexture[0]->iHeight-2;
	pCurrentSurface->pTexturePos[0].iPos[6][X] = 0;
	pCurrentSurface->pTexturePos[0].iPos[6][Y] = pCurrentSurface->pTexture[0]->iHeight-2;
	pCurrentSurface->pTexturePos[0].iPos[7][X] = 0;
	pCurrentSurface->pTexturePos[0].iPos[7][Y] = pCurrentSurface->pTexture[0]->iHeight/2-2;
	pCurrentSurface->pTexturePos[0].iPos[8][X] = pCurrentSurface->pTexture[0]->iWidth/2-1;
	pCurrentSurface->pTexturePos[0].iPos[8][Y] = pCurrentSurface->pTexture[0]->iHeight/2-2;
	
	// Update the fields:
	if(pField)
	{
		for(i = 0; i < Header.iFields; i++)
		{
			pFieldT = &pField[i];
			// This is required for every field side:
			for(i2 = 0; i2 < 7; i2++)
			{
				for(i3 = 0; i3 < 2; i3++)
				{
					if(pFieldT->Side[i2].Surface[i3].pSurface)
						pFieldT->Side[i2].Surface[i3].pSurface = &pSurface[pFieldT->Side[i2].Surface[i3].iSurface];
				}
			}
		}
	}

	return 0;
} // end LEVEL::CreateSurface()

// Loads an surface:
HRESULT LEVEL::LoadSurface(char *pbyFilename)
{ // begin LEVEL::LoadSurface()
	FIELD *pFieldT;
	int i, i2, i3;

	if(!pbyFilename || CreateSurface())
		return 1;
	
	// Now load the surface:
	if(pCurrentSurface->Load(pbyFilename))
		return 1;
	
	// Update the field pointer the surfaces:
	for(i = 0; i < Header.iFields; i++)
	{
		pFieldT = &pField[i];
		for(i2 = 0; i2 < 7; i2++)
		{
			for(i3 = 0; i3 < 2; i3++)
			{
				if(pFieldT->Side[i2].Surface[i3].iSurface == -1)
					continue;
				pFieldT->Side[i2].Surface[i3].pSurface = &pSurface[pFieldT->Side[i2].Surface[i3].iSurface];
			}
		}
		break;
	}

	return 0;
} // end LEVEL::LoadSurface()

// Destroys an surface:
void LEVEL::DestroySurface(int iSurface)
{ // begin LEVEL::DestroySurface()
	ACTOR *pActorT;
	FIELD *pFieldT;
	int i, i2, i3;

	pSurface[iSurface].Destroy();

	// The given surface is replaced through the next one and so on:
	for(i = iSurface; i < Header.iSurfaces-1; i++)
	{
		memcpy(&pSurface[i], &pSurface[i+1], sizeof(SURFACE));
		pSurface[i].Header.iID--;
		pSurface[i].Header.iChangeOnEnterSurface--;
		pSurface[i].Header.iChangeOnLeaveSurface--;
		pSurface[i].Header.iChangeOnTimeSurface--;
		if(pSurface[i].Header.iChangeOnEnterSurface == iSurface)
			pSurface[i].Header.iChangeOnEnterSurface = 0;
		if(pSurface[i].Header.iChangeOnLeaveSurface == iSurface)
			pSurface[i].Header.iChangeOnLeaveSurface = 0;
		if(pSurface[i].Header.iChangeOnTimeSurface == iSurface)
			pSurface[i].Header.iChangeOnTimeSurface = 0;
	}
	TextScriptManager.SurfaceIsDeleted(iSurface);

	// Reorganize the surfaces:
	Header.iSurfaces--;
	pSurface = (SURFACE *) realloc(pSurface, sizeof(SURFACE)*Header.iSurfaces);
	
	// Update the current surface pointer:
	if(iCurrentSurface >= Header.iSurfaces)
	{
		iCurrentSurface--;
		pCurrentSurface = &pSurface[iCurrentSurface];
	}
	else
		if(!pSurface)
		{ // There are no surfaces:
			iCurrentSurface = -1;
			pCurrentSurface = NULL;
		}
	
	// Update the fields:
	for(i = 0; i < Header.iFields; i++)
	{
		pFieldT = &pField[i];

		// This is required for every field side:
		for(i2 = 0; i2 < 7; i2++)
		{
			for(i3 = 0; i3 < 2; i3++)
			{
				// Update the field pointers:
				if(pFieldT->Side[i2].Surface[i3].iSurface == iSurface)
				{
					// This side has now the default:
					pFieldT->Side[i2].Surface[i3].iSurface = 0;
					pFieldT->Side[i2].Surface[i3].pSurface = &pSurface[0];
					pSurface[0].iUsed++;
					continue;
				}
				if(pFieldT->Side[i2].Surface[i3].iSurface > iSurface)
				{
					pFieldT->Side[i2].Surface[i3].iSurface--;
					pFieldT->Side[i2].Surface[i3].pSurface = &pSurface[pFieldT->Side[i2].Surface[i3].iSurface];
				}
			}
		}
	}

	// Update the sky-cube:
	for(i = 0; i < 6; i++)
	{
		if(Environment.iSkyCubeSurface[i] == iSurface)
			Environment.iSkyCubeSurface[i] = 0; // Set the default surface
		if(Environment.iSkyCubeSurface[i] > iSurface)
			Environment.iSkyCubeSurface[i]--; // Set the new surface
	}

	// Update box surface:
	for(i = 0; i < 7; i++)
	{
		if(Header.iBoxSurface[i] == iSurface)
			Header.iBoxSurface[i] = 0;
		else
			if(Header.iBoxSurface[i] > iSurface)
				Header.iBoxSurface[i]--;
	}

	for(i = 0; i < Header.iMaxActors; i++)
	{
		pActorT = pActorList[i];
		if(!pActorT->bActive)
			continue;
		for(i2 = 0; i2 < 7; i2++)
		{
			if(pActorT->iBoxSurface[i2] == iSurface)
				pActorT->iBoxSurface[i2] = 0;
			else
				if(pActorT->iBoxSurface[i2] > iSurface)
					pActorT->iBoxSurface[i2]--;
		}
	}
} // end LEVEL::DestroySurface()

// Loads an level texture:
HRESULT LEVEL::LoadTexture(char *pbyFilename)
{ // begin LEVEL::LoadTexture()
	char byTemp[MAX_PATH];
	int i, i2;
	FILE *fp;

	if(!pbyFilename)
		return 1;

	// Add the main path:
	sprintf(byTemp, "%s%s", _AS->byProgramPath, pbyFilename);
	
	// Check if the texture is already loaded:
	for(i = 0; i < Header.iTextures; i++)
		if(!strcmp(pTexture[i].byFilename, pbyFilename))
		{
			iCurrentTexture = i;
			pCurrentTexture = &pTexture[iCurrentTexture];
			return 0; // This texture is already loaded:
		}

	// Check if the texture is there:
	fp = fopen(byTemp, "r");
	if(!fp)
	{ // A texture was not found!!
		sprintf(byTemp, "%s: %s ", byTemp, AS_M(M_TextureWasNotFound));
		_AS->WriteLogMessage(byTemp);	
		iCurrentTexture = 0;
		pCurrentTexture = &pTexture[0];
		return 1;
	}
	fclose(fp);

	FieldSideList.Destroy(this);

	// Add the new texture:
	Header.iTextures++;
	pTexture = (AS_TEXTURE *) realloc(pTexture, sizeof(AS_TEXTURE)*Header.iTextures);
	iCurrentTexture = Header.iTextures-1;
	pCurrentTexture = &pTexture[iCurrentTexture];
	memset(pCurrentTexture, 0, sizeof(AS_TEXTURE));
	pCurrentTexture->iID = Header.iTextures-1;
	strcpy(pCurrentTexture->byFilename, pbyFilename);
	
	// Now load the texture:
	if(ASCheckStringEnding(byTemp, "jpg"))
		ASLoadJpegRGB(pCurrentTexture, byTemp);
	else
	if(ASCheckStringEnding(byTemp, "bmp"))
		ASLoadBmp(pCurrentTexture, byTemp);
	else
	if(ASCheckStringEnding(byTemp, "ppm"))
		ASLoadPpm(pCurrentTexture, byTemp);
	else
	if(ASCheckStringEnding(byTemp, "tga"))
		ASLoadTga(pCurrentTexture, byTemp);
	
	// Update the surfaces:
	for(i = 0; i < Header.iSurfaces; i++)
	{
		if(!pSurface[i].iTextureID)
			continue;
		for(i2 = 0; i2 < pSurface[i].Header.iAniSteps; i2++)
		{
			if(pSurface[i].iTextureID[i2] == -1)
				continue;
			pSurface[i].pTexture[i2] = &pTexture[pSurface[i].iTextureID[i2]];
		}
	}
	FieldSideList.Create(this);
	LevelTempCamera.fPos[X] = -1;

	return 0;
} // end LEVEL::LoadTexture()

// Destroys an level texture:
void LEVEL::DestroyTexture(int iTexture)
{ // begin LEVEL::DestroyTexture()
	ACTOR *pActorT;
	int i, i2;

	FieldSideList.Destroy(this);

	// The given texture is replaced through the next one and so on:
	for(i = iTexture; i < Header.iTextures-1; i++)
	{
		memcpy(&pTexture[i], &pTexture[i+1], sizeof(AS_TEXTURE));
		pTexture[i].iID--;
	
	}
	// Reorganize the textures:
	Header.iTextures--;
	pTexture = (AS_TEXTURE *) realloc(pTexture, sizeof(AS_TEXTURE)*Header.iTextures);
	
	// Update the current texture pointer:
	if(iCurrentTexture >= Header.iTextures)
	{
		iCurrentTexture--;
		pCurrentTexture = &pTexture[iCurrentTexture];
	}
	else
		if(!pTexture)
		{ // There are no textures:
			iCurrentTexture = -1;
			pCurrentTexture = NULL;
		}

	// Update the surface pointers:
	for(i = 0; i < Header.iSurfaces; i++)
	{
		for(i2 = 0; i2 < pSurface[i].Header.iAniSteps; i2++)
		{
			if(pSurface[i].iTextureID[i2] == iTexture)
			{ // Give this surface the default texture:
				pSurface[i].iTextureID[i2] = 0;
				pSurface[i].pTexture[i2] = &pTexture[0];
				continue;
			}
			if(pSurface[i].iTextureID[i2] > iTexture)
			{
				pSurface[i].iTextureID[i2]--;
				pSurface[i].pTexture[i2] = &pTexture[pSurface[i].iTextureID[i2]];
			}
		}
	}
	for(i = 0; i < Header.iFields; i++)
	{
		if(!pField[i].pDecoration)
			continue;
		if(pField[i].pDecoration->iTexture > iTexture)
			pField[i].pDecoration->iTexture--;
		if(pField[i].pDecoration->iTexture == iTexture)
			pField[i].pDecoration->iTexture = -1;
	}
	for(i = 0; i < Header.iMaxActors; i++)
	{
		pActorT = pActorList[i];
		if(pActorT->iTexture == -1)
			continue;
		if(pActorT->iTexture == iTexture)
			pActorT->iTexture = -1;
		else
			if(pActorT->iTexture > iTexture)
				pActorT->iTexture--;
	}
	FieldSideList.Create(this);
} // end LEVEL::DestroyTexture()

void LEVEL::ReloadTextures(void)
{ // begin LEVEL::ReloadTextures()
	AS_TEXTURE *pTextureT;
	char byTemp[256];
	int i;
	
	// Destroy old level bitmaps:
	DestroyTexturesOpenGL(hDCEditorShow, hRCEditorShow);
	for(i = 0; i < Header.iTextures; i++)
		if(pTexture[i].pbyData)
			SAFE_FREE(pTexture[i].pbyData);

	// Load new level bitmaps:
	for(i = 0; i < Header.iTextures; i++)
	{
		pTextureT = &pTexture[i];
		// Add the main path:
		sprintf(byTemp, "%s%s", _AS->byProgramPath, pTextureT->byFilename);
		
		// Now load the texture:
		if(ASCheckStringEnding(byTemp, "jpg"))
			ASLoadJpegRGB(pTextureT, byTemp);
		else
		if(ASCheckStringEnding(byTemp, "bmp"))
			ASLoadBmp(pTextureT, byTemp);
		else
		if(ASCheckStringEnding(byTemp, "tga"))
			ASLoadTga(pTextureT, byTemp);
	}
} // end LEVEL::ReloadTextures()
					
// Creates an new level:
void LEVEL::Create(int iWidthT, int iHeightT)
{ // begin LEVEL::Create()
	int i, i2, x, y, iSide, iField, iPoint, iMaxActorsT;
	FIELD_SIDE_QUAD *pFieldSideQuadT;
	FIELD_SIDE *pFieldSideT;
	char byTemp[256];

	// Setup the general level information:
	memset(&Header, 0, sizeof(LEVEL_HEADER));
	memset(&Environment, 0, sizeof(LEVEL_ENVIRONMENT));
	memset(&Missions, 0, sizeof(LEVEL_MISSIONS));
	memset(&Camera, 0, sizeof(LEVEL_CAMERA));
	memset(&State, 0, sizeof(LEVEL_STATE));
	TextScriptManager.Init();

	SetLevelStandartValues();
	Header.iWidth = iWidthT;
	Header.iHeight = iHeightT;
	Header.iFields = Header.iWidth*Header.iHeight;
	Header.fWholeWidth = (float) (Header.iWidth-1);
	Header.fWholeHeight = (float) (Header.iHeight-1);
	
	Header.iBoxSurface[6] = -1; // Disable the standart environment mapping for the boxes

	if(!pActorList)
	{
		iMaxActorsT = Header.iMaxActors;
		Header.iMaxActors = 0;
		ResizeActorList(iMaxActorsT); // // Create the actor list
	}
	
	if(!pTexture)
	{ // Load default texture:
		sprintf(byTemp, "%s\\FieldTemp.jpg", _AS->byBitmapsDirectory);
		LoadTexture(byTemp);
	}
	if(!pSurface)
	{ // Create the default surface:
		CreateSurface();
		strcpy(pCurrentSurface->Header.byName, "Default");
		strcpy(pCurrentSurface->byTextureFilename[0], byTemp);		
		pCurrentSurface->iTextureID[0] = 0;
		pCurrentSurface->pTexture[0] = &pTexture[0];
		pCurrentSurface->pTexturePos->iPos[0][X] = 0;
		pCurrentSurface->pTexturePos->iPos[0][Y] = 0;
		pCurrentSurface->pTexturePos->iPos[1][X] = 32;
		pCurrentSurface->pTexturePos->iPos[1][Y] = 0;
		pCurrentSurface->pTexturePos->iPos[2][X] = 64;
		pCurrentSurface->pTexturePos->iPos[2][Y] = 0;
		pCurrentSurface->pTexturePos->iPos[3][X] = 64;
		pCurrentSurface->pTexturePos->iPos[3][Y] = 32;
		pCurrentSurface->pTexturePos->iPos[4][X] = 64;
		pCurrentSurface->pTexturePos->iPos[4][Y] = 64;
		pCurrentSurface->pTexturePos->iPos[5][X] = 32;
		pCurrentSurface->pTexturePos->iPos[5][Y] = 64;
		pCurrentSurface->pTexturePos->iPos[6][X] = 0;
		pCurrentSurface->pTexturePos->iPos[6][Y] = 64;
		pCurrentSurface->pTexturePos->iPos[7][X] = 0;
		pCurrentSurface->pTexturePos->iPos[7][Y] = 32;
		pCurrentSurface->pTexturePos->iPos[8][X] = 32;
		pCurrentSurface->pTexturePos->iPos[8][Y] = 32;
		pCurrentSurface->CalculateFloatTexturePos();
	}
	pCurrentSurface = &pSurface[0];

	// Create the level vertices:
	Header.iXPoints = Header.iWidth*2+1;
	Header.iYPoints = Header.iHeight*2+1;
	Header.iLevelPoints = Header.iXPoints*Header.iYPoints;
	Header.iPoints = Header.iLevelPoints*3;
	fPoint = new FLOAT3[Header.iPoints];
	fNormal = new FLOAT3[Header.iPoints];
	fColor = new FLOAT4[Header.iPoints];
	fSecondColor = new FLOAT4[Header.iPoints];
	fWaterPoint = new FLOAT3[Header.iLevelPoints];
	memset(fWaterPoint, 0, sizeof(FLOAT3)*Header.iLevelPoints);
	fWaterNormal = new FLOAT3[Header.iLevelPoints];
	memset(fWaterNormal, 0, sizeof(FLOAT3)*Header.iLevelPoints);
	fWaterColor = new FLOAT4[Header.iLevelPoints];
	memset(fWaterColor, 0, sizeof(FLOAT4)*Header.iLevelPoints);
	fWaterSecondColor = new FLOAT4[Header.iLevelPoints];
	memset(fWaterSecondColor, 0, sizeof(FLOAT4)*Header.iLevelPoints);
	fWaterStandartZ = new float[Header.iLevelPoints];
	memset(fWaterStandartZ, 0, sizeof(float)*Header.iLevelPoints);
	fWaterAmplitude = new float[Header.iLevelPoints];
	memset(fWaterAmplitude, 0, sizeof(float)*Header.iLevelPoints);
	iVisibleWaterPoints = new int[Header.iLevelPoints];
	memset(iVisibleWaterPoints, 0, sizeof(int)*Header.iLevelPoints);
	bWaterPointVisible = new BOOL[Header.iLevelPoints];
	memset(bWaterPointVisible, 0, sizeof(BOOL)*Header.iLevelPoints);
	bPointSelected = new BOOL[Header.iPoints+Header.iLevelPoints];
	memset(bPointSelected, 0, sizeof(BOOL)*Header.iPoints+Header.iLevelPoints);
	
	// Setup the level vertices:
	for(i = 0, y = 0; y < Header.iYPoints; y++)
		for(x = 0; x < Header.iXPoints; x++, i++)
		{
			// Floor point:
			fPoint[i][X] = (float) x/2;
			fPoint[i][Y] = (float) y/2;
			fPoint[i][Z] = 0.0f;
			fColor[i][R] = 1.0f;
			fColor[i][G] = 1.0f;
			fColor[i][B] = 1.0f;
			fColor[i][A] = 1.0f;
			fSecondColor[i][R] = 0.9f;
			fSecondColor[i][G] = 0.9f;
			fSecondColor[i][B] = 0.9f;
			fSecondColor[i][A] = 0.9f;

			// Water point:
			fWaterPoint[i][X] = (float) x/2;
			fWaterPoint[i][Y] = (float) y/2;
			fWaterPoint[i][Z] = 0.3f;
			fWaterStandartZ[i] = 0.0f;
			fWaterAmplitude[i] = 1.0f;
			fWaterColor[i][R] = 0.5f;
			fWaterColor[i][G] = 0.5f;
			fWaterColor[i][B] = 1.0f;
			fWaterColor[i][A] = 0.9f;
			fWaterSecondColor[i][R] = 1.0f;
			fWaterSecondColor[i][G] = 1.0f;
			fWaterSecondColor[i][B] = 1.0f;
			fWaterSecondColor[i][A] = 0.9f;

			// Middle point:
			i2 = Header.iLevelPoints+i;
			fPoint[i2][X] = (float) x/2;
			fPoint[i2][Y] = (float) y/2;
			fPoint[i2][Z] = -1.0f;
			fColor[i2][R] = 1.0f;
			fColor[i2][G] = 1.0f;
			fColor[i2][B] = 1.0f;
			fColor[i2][A] = 1.0f;
			fSecondColor[i2][R] = 0.9f;
			fSecondColor[i2][G] = 0.9f;
			fSecondColor[i2][B] = 0.9f;
			fSecondColor[i2][A] = 0.9f;

			// Front point:
			i2 = Header.iLevelPoints*2+i;
			fPoint[i2][X] = (float) x/2;
			fPoint[i2][Y] = (float) y/2;
			fPoint[i2][Z] = -2.0f;
			fColor[i2][R] = 1.0f;
			fColor[i2][G] = 1.0f;
			fColor[i2][B] = 1.0f;
			fColor[i2][A] = 1.0f;
			fSecondColor[i2][R] = 0.9f;
			fSecondColor[i2][G] = 0.9f;
			fSecondColor[i2][B] = 0.9f;
			fSecondColor[i2][A] = 0.9f;
		}

	// Create the fields:
	pField = new FIELD[Header.iFields];
	memset(pField, 0, sizeof(FIELD)*Header.iFields);

	// Create the beamer field list:
	pBeamerFieldList = (FIELD **) malloc(sizeof(FIELD *)*(Header.iFields+1));
	memset(pBeamerFieldList, 0, sizeof(FIELD *)*(Header.iFields+1));

	// Create the decoration field list:
	pDecorationFieldList = (FIELD **) malloc(sizeof(FIELD *)*(Header.iFields+1));
	memset(pDecorationFieldList, 0, sizeof(FIELD *)*(Header.iFields+1));

	// Create the trigger field list:
	pTriggerFieldList = (FIELD **) malloc(sizeof(FIELD *)*(Header.iFields+1));
	memset(pTriggerFieldList, 0, sizeof(FIELD *)*(Header.iFields+1));

	// Create the animated surfaces list:
	pAnimatedSurfacesList = (FIELD_SIDE_SURFACE **) malloc(sizeof(FIELD_SIDE_SURFACE *)*(Header.iFields*14+1));
	memset(pAnimatedSurfacesList, 0, sizeof(FIELD_SIDE_SURFACE *)*(Header.iFields+1));

	for(iField = 0, iPoint = 0, y = 0; y < Header.iHeight; y++)
	{
		for(x = 0; x < Header.iWidth; x++, iField++, iPoint += 2)
		{
			pCurrentField = &pField[iField];
			pCurrentField->iID = iField;
			pCurrentField->iXField = x;
			pCurrentField->iYField = y;
			for(iSide = 0; iSide < 7; iSide++)
			{
				pFieldSideT = &pCurrentField->Side[iSide];

				// Set the default surface:
				pFieldSideT->pField = pCurrentField;
				pFieldSideT->iSide = iSide;
				pFieldSideT->Surface[0].pSurface = pCurrentSurface;
				pCurrentSurface->iUsed++;
				pFieldSideT->Surface[0].dwLastTime = g_lGameTimer;
				pFieldSideT->Surface[1].iSurface = -1;
				pFieldSideT->Surface[1].dwLastTime = g_lGameTimer;
				pFieldSideT->Surface[0].bSecondSurface = FALSE;
				pFieldSideT->Surface[1].bSecondSurface = TRUE;
										
				// Setup the surface pointers back to the parent side:
				pFieldSideT->Surface[0].pFieldSide =
				pFieldSideT->Surface[1].pFieldSide = &pCurrentField->Side[iSide];
			}

			// Setup the field faces;
			// Floor face:
			pFieldSideT = &pCurrentField->Side[FACE_FLOOR];
			// Quad 0:
			pFieldSideQuadT = &pFieldSideT->SideQuad[0];
			pFieldSideQuadT->iPoint[0] = iPoint;
			pFieldSideQuadT->iPoint[1] = iPoint+1;
			pFieldSideQuadT->iPoint[2] = iPoint+Header.iXPoints+1;
			pFieldSideQuadT->iPoint[3] = iPoint+Header.iXPoints;
			// Quad 1:
			pFieldSideQuadT = &pFieldSideT->SideQuad[1];
			pFieldSideQuadT->iPoint[0] = iPoint+1;
			pFieldSideQuadT->iPoint[1] = iPoint+2;
			pFieldSideQuadT->iPoint[2] = iPoint+Header.iXPoints+2;
			pFieldSideQuadT->iPoint[3] = iPoint+Header.iXPoints+1;
			// Quad 2:
			pFieldSideQuadT = &pFieldSideT->SideQuad[2];
			pFieldSideQuadT->iPoint[0] = iPoint+Header.iXPoints+1;
			pFieldSideQuadT->iPoint[1] = iPoint+Header.iXPoints+2;
			pFieldSideQuadT->iPoint[2] = iPoint+Header.iXPoints*2+2;
			pFieldSideQuadT->iPoint[3] = iPoint+Header.iXPoints*2+1;
			// Quad 3:
			pFieldSideQuadT = &pFieldSideT->SideQuad[3];
			pFieldSideQuadT->iPoint[0] = iPoint+Header.iXPoints;
			pFieldSideQuadT->iPoint[1] = iPoint+Header.iXPoints+1;
			pFieldSideQuadT->iPoint[2] = iPoint+Header.iXPoints*2+1;
			pFieldSideQuadT->iPoint[3] = iPoint+Header.iXPoints*2;

			// Top face:
			pFieldSideT = &pCurrentField->Side[FACE_TOP];
			// Quad 0:
			pFieldSideQuadT = &pFieldSideT->SideQuad[0];
			pFieldSideQuadT->iPoint[0] = iPoint+Header.iLevelPoints*2+2;
			pFieldSideQuadT->iPoint[1] = iPoint+Header.iLevelPoints*2+1;
			pFieldSideQuadT->iPoint[2] = iPoint+Header.iLevelPoints+1;
			pFieldSideQuadT->iPoint[3] = iPoint+Header.iLevelPoints+2;
			// Quad 1:
			pFieldSideQuadT = &pFieldSideT->SideQuad[1];
			pFieldSideQuadT->iPoint[0] = iPoint+Header.iLevelPoints*2+1;
			pFieldSideQuadT->iPoint[1] = iPoint+Header.iLevelPoints*2;
			pFieldSideQuadT->iPoint[2] = iPoint+Header.iLevelPoints;
			pFieldSideQuadT->iPoint[3] = iPoint+Header.iLevelPoints+1;
			// Quad 2:
			pFieldSideQuadT = &pFieldSideT->SideQuad[2];
			pFieldSideQuadT->iPoint[0] = iPoint+Header.iLevelPoints+1;
			pFieldSideQuadT->iPoint[1] = iPoint+Header.iLevelPoints;
			pFieldSideQuadT->iPoint[2] = iPoint;
			pFieldSideQuadT->iPoint[3] = iPoint+1;
			// Quad 3:
			pFieldSideQuadT = &pFieldSideT->SideQuad[3];
			pFieldSideQuadT->iPoint[0] = iPoint+Header.iLevelPoints+2;
			pFieldSideQuadT->iPoint[1] = iPoint+Header.iLevelPoints+1;
			pFieldSideQuadT->iPoint[2] = iPoint+1;
			pFieldSideQuadT->iPoint[3] = iPoint+2;

			// Left face:
			pFieldSideT = &pCurrentField->Side[FACE_LEFT];
			// Quad 0:
			pFieldSideQuadT = &pFieldSideT->SideQuad[0];
			pFieldSideQuadT->iPoint[0] = iPoint+Header.iLevelPoints*2;
			pFieldSideQuadT->iPoint[1] = iPoint+Header.iLevelPoints*2+Header.iXPoints;
			pFieldSideQuadT->iPoint[2] = iPoint+Header.iLevelPoints+Header.iXPoints;
			pFieldSideQuadT->iPoint[3] = iPoint+Header.iLevelPoints;
			// Quad 1:
			pFieldSideQuadT = &pFieldSideT->SideQuad[1];
			pFieldSideQuadT->iPoint[0] = iPoint+Header.iLevelPoints*2+Header.iXPoints;
			pFieldSideQuadT->iPoint[1] = iPoint+Header.iLevelPoints*2+Header.iXPoints*2;
			pFieldSideQuadT->iPoint[2] = iPoint+Header.iLevelPoints+Header.iXPoints*2;
			pFieldSideQuadT->iPoint[3] = iPoint+Header.iLevelPoints+Header.iXPoints;
			// Quad 2:
			pFieldSideQuadT = &pFieldSideT->SideQuad[2];
			pFieldSideQuadT->iPoint[0] = iPoint+Header.iLevelPoints+Header.iXPoints;
			pFieldSideQuadT->iPoint[1] = iPoint+Header.iLevelPoints+Header.iXPoints*2;
			pFieldSideQuadT->iPoint[2] = iPoint+Header.iXPoints*2;
			pFieldSideQuadT->iPoint[3] = iPoint+Header.iXPoints;
			// Quad 3:
			pFieldSideQuadT = &pFieldSideT->SideQuad[3];
			pFieldSideQuadT->iPoint[0] = iPoint+Header.iLevelPoints;
			pFieldSideQuadT->iPoint[1] = iPoint+Header.iLevelPoints+Header.iXPoints;
			pFieldSideQuadT->iPoint[2] = iPoint+Header.iXPoints;
			pFieldSideQuadT->iPoint[3] = iPoint;

			// Right face:
			pFieldSideT = &pCurrentField->Side[FACE_RIGHT];
			// Quad 0:
			pFieldSideQuadT = &pFieldSideT->SideQuad[0];
			pFieldSideQuadT->iPoint[0] = iPoint+2+Header.iLevelPoints*2+Header.iXPoints*2;
			pFieldSideQuadT->iPoint[1] = iPoint+2+Header.iLevelPoints*2+Header.iXPoints;
			pFieldSideQuadT->iPoint[2] = iPoint+2+Header.iLevelPoints+Header.iXPoints;
			pFieldSideQuadT->iPoint[3] = iPoint+2+Header.iLevelPoints+Header.iXPoints*2;
			// Quad 1:
			pFieldSideQuadT = &pFieldSideT->SideQuad[1];
			pFieldSideQuadT->iPoint[0] = iPoint+2+Header.iLevelPoints*2+Header.iXPoints;
			pFieldSideQuadT->iPoint[1] = iPoint+2+Header.iLevelPoints*2;
			pFieldSideQuadT->iPoint[2] = iPoint+2+Header.iLevelPoints;
			pFieldSideQuadT->iPoint[3] = iPoint+2+Header.iLevelPoints+Header.iXPoints;
			// Quad 2:
			pFieldSideQuadT = &pFieldSideT->SideQuad[2];
			pFieldSideQuadT->iPoint[0] = iPoint+2+Header.iLevelPoints+Header.iXPoints;
			pFieldSideQuadT->iPoint[1] = iPoint+2+Header.iLevelPoints;
			pFieldSideQuadT->iPoint[2] = iPoint+2;
			pFieldSideQuadT->iPoint[3] = iPoint+2+Header.iXPoints;
			// Quad 3:
			pFieldSideQuadT = &pFieldSideT->SideQuad[3];
			pFieldSideQuadT->iPoint[0] = iPoint+2+Header.iLevelPoints+Header.iXPoints*2;
			pFieldSideQuadT->iPoint[1] = iPoint+2+Header.iLevelPoints+Header.iXPoints;
			pFieldSideQuadT->iPoint[2] = iPoint+2+Header.iXPoints;
			pFieldSideQuadT->iPoint[3] = iPoint+2+Header.iXPoints*2;

			// Bottom face:
			pFieldSideT = &pCurrentField->Side[FACE_BOTTOM];
			// Quad 0:
			pFieldSideQuadT = &pFieldSideT->SideQuad[0];
			pFieldSideQuadT->iPoint[0] = iPoint+Header.iXPoints*2+Header.iLevelPoints*2;
			pFieldSideQuadT->iPoint[1] = iPoint+Header.iXPoints*2+Header.iLevelPoints*2+1;
			pFieldSideQuadT->iPoint[2] = iPoint+Header.iXPoints*2+Header.iLevelPoints+1;
			pFieldSideQuadT->iPoint[3] = iPoint+Header.iXPoints*2+Header.iLevelPoints;
			// Quad 1:
			pFieldSideQuadT = &pFieldSideT->SideQuad[1];
			pFieldSideQuadT->iPoint[0] = iPoint+Header.iXPoints*2+Header.iLevelPoints*2+1;
			pFieldSideQuadT->iPoint[1] = iPoint+Header.iXPoints*2+Header.iLevelPoints*2+2;
			pFieldSideQuadT->iPoint[2] = iPoint+Header.iXPoints*2+Header.iLevelPoints+2;
			pFieldSideQuadT->iPoint[3] = iPoint+Header.iXPoints*2+Header.iLevelPoints+1;
			// Quad 2:
			pFieldSideQuadT = &pFieldSideT->SideQuad[2];
			pFieldSideQuadT->iPoint[0] = iPoint+Header.iXPoints*2+Header.iLevelPoints+1;
			pFieldSideQuadT->iPoint[1] = iPoint+Header.iXPoints*2+Header.iLevelPoints+2;
			pFieldSideQuadT->iPoint[2] = iPoint+Header.iXPoints*2+2;
			pFieldSideQuadT->iPoint[3] = iPoint+Header.iXPoints*2+1;
			// Quad 3:
			pFieldSideQuadT = &pFieldSideT->SideQuad[3];
			pFieldSideQuadT->iPoint[0] = iPoint+Header.iXPoints*2+Header.iLevelPoints;
			pFieldSideQuadT->iPoint[1] = iPoint+Header.iXPoints*2+Header.iLevelPoints+1;
			pFieldSideQuadT->iPoint[2] = iPoint+Header.iXPoints*2+1;
			pFieldSideQuadT->iPoint[3] = iPoint+Header.iXPoints*2;
			
			// Front face:
			pFieldSideT = &pCurrentField->Side[FACE_FRONT];
			// Quad 0:
			pFieldSideQuadT = &pFieldSideT->SideQuad[0];
			pFieldSideQuadT->iPoint[0] = iPoint+Header.iLevelPoints*2;
			pFieldSideQuadT->iPoint[1] = iPoint+Header.iLevelPoints*2+1;
			pFieldSideQuadT->iPoint[2] = iPoint+Header.iLevelPoints*2+Header.iXPoints+1;
			pFieldSideQuadT->iPoint[3] = iPoint+Header.iLevelPoints*2+Header.iXPoints;
			// Quad 1:
			pFieldSideQuadT = &pFieldSideT->SideQuad[1];
			pFieldSideQuadT->iPoint[0] = iPoint+Header.iLevelPoints*2+1;
			pFieldSideQuadT->iPoint[1] = iPoint+Header.iLevelPoints*2+2;
			pFieldSideQuadT->iPoint[2] = iPoint+Header.iLevelPoints*2+Header.iXPoints+2;
			pFieldSideQuadT->iPoint[3] = iPoint+Header.iLevelPoints*2+Header.iXPoints+1;
			// Quad 2:
			pFieldSideQuadT = &pFieldSideT->SideQuad[2];
			pFieldSideQuadT->iPoint[0] = iPoint+Header.iLevelPoints*2+Header.iXPoints+1;
			pFieldSideQuadT->iPoint[1] = iPoint+Header.iLevelPoints*2+Header.iXPoints+2;
			pFieldSideQuadT->iPoint[2] = iPoint+Header.iLevelPoints*2+Header.iXPoints*2+2;
			pFieldSideQuadT->iPoint[3] = iPoint+Header.iLevelPoints*2+Header.iXPoints*2+1;
			// Quad 3:
			pFieldSideQuadT = &pFieldSideT->SideQuad[3];
			pFieldSideQuadT->iPoint[0] = iPoint+Header.iLevelPoints*2+Header.iXPoints;
			pFieldSideQuadT->iPoint[1] = iPoint+Header.iLevelPoints*2+Header.iXPoints+1;
			pFieldSideQuadT->iPoint[2] = iPoint+Header.iLevelPoints*2+Header.iXPoints*2+1;
			pFieldSideQuadT->iPoint[3] = iPoint+Header.iLevelPoints*2+Header.iXPoints*2;

			// Water face:
			pFieldSideT = &pCurrentField->Side[FACE_WATER];
			// Quad 0:
			pFieldSideQuadT = &pFieldSideT->SideQuad[0];
			pFieldSideQuadT->iPoint[0] = iPoint;
			pFieldSideQuadT->iPoint[1] = iPoint+1;
			pFieldSideQuadT->iPoint[2] = iPoint+Header.iXPoints+1;
			pFieldSideQuadT->iPoint[3] = iPoint+Header.iXPoints;
			// Quad 1:
			pFieldSideQuadT = &pFieldSideT->SideQuad[1];
			pFieldSideQuadT->iPoint[0] = iPoint+1;
			pFieldSideQuadT->iPoint[1] = iPoint+2;
			pFieldSideQuadT->iPoint[2] = iPoint+Header.iXPoints+2;
			pFieldSideQuadT->iPoint[3] = iPoint+Header.iXPoints+1;
			// Quad 2:
			pFieldSideQuadT = &pFieldSideT->SideQuad[2];
			pFieldSideQuadT->iPoint[0] = iPoint+Header.iXPoints+1;
			pFieldSideQuadT->iPoint[1] = iPoint+Header.iXPoints+2;
			pFieldSideQuadT->iPoint[2] = iPoint+Header.iXPoints*2+2;
			pFieldSideQuadT->iPoint[3] = iPoint+Header.iXPoints*2+1;
			// Quad 3:
			pFieldSideQuadT = &pFieldSideT->SideQuad[3];
			pFieldSideQuadT->iPoint[0] = iPoint+Header.iXPoints;
			pFieldSideQuadT->iPoint[1] = iPoint+Header.iXPoints+1;
			pFieldSideQuadT->iPoint[2] = iPoint+Header.iXPoints*2+1;
			pFieldSideQuadT->iPoint[3] = iPoint+Header.iXPoints*2;

			// Is this field active?
			if(x != Header.iWidth-1 && y != Header.iHeight-1)
				pCurrentField->bActive = TRUE; // Yes, it's no temp field!
			pCurrentField->Side[FACE_FLOOR].bFaceActive = TRUE;
			pCurrentField->WaterType = WATER_NORMAL;
			pCurrentField->iCamera = -1;
			pCurrentField->fBeamerPower = 1.0f;
			pCurrentField->iBeamerRegenerationSpeed = 10000;
			pCurrentField->iBeamerParticleSystemID = -1;
			pCurrentField->iBeamerTarget = -1;
			pCurrentField->fWaterChangeSpeed = 1.0f;
			pCurrentField->fWaterChangeNotSpeed = 1.0f;
		}
		iPoint += Header.iXPoints+1;
	}
	pCurrentField = &pField[0];

	// Level outline
	for(y = 0; y < Header.iHeight-1; y++)
		SetFieldWall(0, y, TRUE, FALSE);
	for(x = 0; x < Header.iWidth-1; x++)
		SetFieldWall(x, 0, TRUE, FALSE);
	for(y = 0; y < Header.iHeight-1; y++)
		SetFieldWall(Header.iWidth-2, y, TRUE, FALSE);
	for(x = 0; x < Header.iWidth-1; x++)
		SetFieldWall(x, Header.iHeight-2, TRUE, FALSE);
	
	SetStandartView();

	// Update level:
	memset(&LevelTempCamera, 0, sizeof(AS_CAMERA));
	CalculateFieldNormals(TRUE);
	CalculateWaterNormals(FALSE);
	CalculatePointNormals();
	CalculateFacesMidPoint(TRUE);
	CalculateFieldBoundingBoxes();
	CalculateWaterPoints(FALSE);
	Quadtree.Build(this);
	GetMinMiddleMax();
	Quadtree.GetBoundingBox(this);
	FieldSideList.Create(this);
	pInFOVFields = (FIELD **) malloc(sizeof(FIELD *)*(Header.iFields+1));
} // end LEVEL::Create()

// Destroy an level:
void LEVEL::Destroy(void)
{ // begin LEVEL::Destroy()
	int i;

	Quadtree.Destroy();
	FieldSideList.Destroy(this);
	SAFE_DELETE(pInFOVFields);
	SAFE_FREE(pBeamerFieldList);
	SAFE_FREE(pDecorationFieldList);
	SAFE_FREE(pTriggerFieldList);
	SAFE_FREE(pAnimatedSurfacesList);
	if(pField)
	{
		for(i = 0; i < Header.iFields; i++)
			SAFE_FREE(pField[i].pDecoration);
		SAFE_FREE(pField);
	}
	SAFE_FREE(fPoint);
	SAFE_FREE(fNormal);
	SAFE_FREE(fColor);
	SAFE_FREE(fSecondColor);
	SAFE_FREE(fWaterPoint);
	SAFE_FREE(fWaterNormal);
	SAFE_FREE(fWaterColor);
	SAFE_FREE(fWaterSecondColor);
	SAFE_FREE(fWaterStandartZ);
	SAFE_FREE(fWaterAmplitude);	
	SAFE_FREE(iVisibleWaterPoints);
	SAFE_FREE(bWaterPointVisible);
	SAFE_FREE(bPointSelected);
	if(pSurface)
	{
		for(i = 0; i < Header.iSurfaces; i++)
			pSurface[i].Destroy();
		SAFE_FREE(pSurface);
	}
	if(pTexture)
	{
		for(i = 0; i < Header.iTextures; i++)
			SAFE_FREE(pTexture[i].pbyData);
		SAFE_FREE(pTexture);
	}
	for(i = 0; i < Header.iCameraScripts; i++)
		SAFE_FREE(pCameraScript[i].pCamera);
	SAFE_FREE(pCameraScript);
	TextScriptManager.Destroy();
	DestroyActorList();
	memset(this, 0, sizeof(LEVEL));
	bCameraAnimation = FALSE;
} // end LEVEL::Destroy()

void LEVEL::SetFieldWall(int x, int y, BOOL bStatus, BOOL bOnlyCheck)
{ // begin LEVEL::SetFieldWall()
	int i, i2, iXStart, iYStart, iXEnd, iYEnd;

	if(x < 0 || x > Header.iWidth-2 || y < 0 || y > Header.iHeight-2)
		return;
	i = y*Header.iWidth+x;
	if(!bOnlyCheck)
	{
		if(!pField[i].bWallHole)
			pField[i].bActive = TRUE;
		pField[i].bWall = bStatus;
		if(pField[i].pActor)
		{
			for(i2 = 0; i2 < 6; i2++)
				pField[i].Side[i2].bFaceActive = FALSE;
		}
		else
		{
			for(i2 = 0; i2 < 6; i2++)
				pField[i].Side[i2].bFaceActive = bStatus;
		}
		if(pField[i].bWallHole)
			pField[i].Side[FACE_FRONT].bFaceActive = TRUE;
	}
	else
	{
		if(!pField[i].bActive)
			bStatus = FALSE;
		else
			bStatus = pField[i].bWall;
	}
	// Activate/Deactivate the field sides around this field:
	if(bStatus)
	{ // Check if the sides of the other walls around this are visible:
		pField[i].Side[FACE_FLOOR].bFaceActive = FALSE;
		if(!pField[i].bWallHole)
		{
			if(x > 0 && pField[i-1].bWall && pField[i-1].bActive && !pField[i-1].pActor)
			{ // Check left wall:
				pField[i-1].Side[FACE_RIGHT].bFaceActive = FALSE;
				pField[i].Side[FACE_LEFT].bFaceActive = FALSE;
			}
			if(x < Header.iWidth-1 && pField[i+1].bWall && pField[i+1].bActive && !pField[i+1].pActor)
			{ // Check right wall:
				pField[i+1].Side[FACE_LEFT].bFaceActive = FALSE;
				pField[i].Side[FACE_RIGHT].bFaceActive = FALSE;
			}
			if(y > 0 && pField[i-Header.iWidth].bWall && pField[i-Header.iWidth].bActive && !pField[i-Header.iWidth].pActor)
			{ // Check top wall:
				pField[i-Header.iWidth].Side[FACE_BOTTOM].bFaceActive = FALSE;
				pField[i].Side[FACE_TOP].bFaceActive = FALSE;
			}
			if(y < Header.iHeight-1 && pField[i+Header.iWidth].bWall && pField[i+Header.iWidth].bActive && !pField[i+Header.iWidth].pActor)
			{ // Check bottom wall:
				pField[i+Header.iWidth].Side[FACE_TOP].bFaceActive = FALSE;
				pField[i].Side[FACE_BOTTOM].bFaceActive = FALSE;
			}
		}
		else
		{
			if(!x)
				pField[i].Side[FACE_LEFT].bFaceActive = FALSE;
			if(x == Header.iWidth-2)
				pField[i].Side[FACE_RIGHT].bFaceActive = FALSE;
			if(!y)
				pField[i].Side[FACE_TOP].bFaceActive = FALSE;
			if(y == Header.iHeight-2)
				pField[i].Side[FACE_BOTTOM].bFaceActive = FALSE;
			if(x > 0 && (!pField[i-1].bActive || pField[i-1].pBridgeActor))
			{ // Check left wall:
				pField[i-1].Side[FACE_RIGHT].bFaceActive = FALSE;
				pField[i].Side[FACE_LEFT].bFaceActive = FALSE;
			}
			if(x < Header.iWidth-1 && (!pField[i+1].bActive || pField[i+1].pBridgeActor))
			{ // Check right wall
				pField[i+1].Side[FACE_LEFT].bFaceActive = FALSE;
				pField[i].Side[FACE_RIGHT].bFaceActive = FALSE;
			}
			if(y > 0 && (!pField[i-Header.iWidth].bActive || pField[i-Header.iWidth].pBridgeActor))
			{ // Check top wall:
				pField[i-Header.iWidth].Side[FACE_BOTTOM].bFaceActive = FALSE;
				pField[i].Side[FACE_TOP].bFaceActive = FALSE;
			}
			if(y < Header.iHeight-1 && (!pField[i+Header.iWidth].bActive || pField[i+Header.iWidth].pBridgeActor))
			{ // Check bottom wall:
				pField[i+Header.iWidth].Side[FACE_TOP].bFaceActive = FALSE;
				pField[i].Side[FACE_BOTTOM].bFaceActive = FALSE;
			}
		}
	}
	else
	{ // Check if the sides of the other walls around this are visible:
		pField[i].Side[FACE_FLOOR].bFaceActive = TRUE;
		if(x > 0 && ((pField[i-1].bActive && pField[i-1].bWall && !pField[i-1].pActor) || pField[i-1].bWallHole))
		{ // Check left wall:
			pField[i-1].Side[FACE_RIGHT].bFaceActive = TRUE;
		}
		if(x < Header.iWidth-1 && ((pField[i+1].bActive && pField[i+1].bWall && !pField[i+1].pActor) || pField[i+1].bWallHole))
		{ // Check right wall:
			pField[i+1].Side[FACE_LEFT].bFaceActive = TRUE;
		}
		if(y > 0 && ((pField[i-Header.iWidth].bActive && pField[i-Header.iWidth].bWall && !pField[i-Header.iWidth].pActor) || pField[i-Header.iWidth].bWallHole))
		{ // Check top wall:
			pField[i-Header.iWidth].Side[FACE_BOTTOM].bFaceActive = TRUE;
		}
		if(y < Header.iHeight-1 && ((pField[i+Header.iWidth].bActive && pField[i+Header.iWidth].bWall && !pField[i+Header.iWidth].pActor) || pField[i+Header.iWidth].bWallHole))
		{ // Check bottom wall:
			pField[i+Header.iWidth].Side[FACE_TOP].bFaceActive = TRUE;
		}
	}
	
	// Setup always active wall sides:
	iXStart = x-1;
	if(iXStart < 0)
		iXStart = 0;
	iYStart = y-1;
	if(iYStart < 0)
		iYStart = 0;
	iXEnd = x+1;
	if(iXEnd > Header.iWidth-2)
		iXEnd = Header.iWidth-2;
	iYEnd = y+1;
	if(iYEnd > Header.iHeight-2)
		iYEnd = Header.iHeight-2;
	for(y = iYStart; y < iYEnd; y++)
	{
		for(x = iXStart; x < iXEnd; x++)
		{
			i = y*Header.iWidth+x;
			for(i2 = 0; i2 < 7; i2++)
				if(pField[i].Side[i2].bFaceAlwaysActive)
					pField[i].Side[i2].bFaceActive = TRUE;
		}
	}
} // end LEVEL::SetFieldWall()

void LEVEL::CalculateFacesMidPoint(BOOL bAll)
{ // begin LEVEL::CalculateFacesMidPoint()
	FIELD_SIDE_QUAD *pFieldSideQuadT;
	int iField, iSide, iQuad, i;
	FIELD_SIDE *pFieldSideT;
	FIELD *pFieldT;

	// Calculate all mid points of all field sides:
	for(iField = 0; iField < Header.iFields; iField++)
	{
		pFieldT = &pField[iField];
		if(!bAll && !pFieldT->bUpdate)
			continue;
		for(iSide = 0; iSide < 7; iSide++)
		{
			pFieldSideT = &pFieldT->Side[iSide];
			for(i = 0; i < 3; i++)
				pFieldSideT->fMidPoint[i] = 0.0f;
			for(iQuad = 0; iQuad < 4; iQuad++)
			{
				pFieldSideQuadT = &pFieldSideT->SideQuad[iQuad];
				for(i = 0; i < 3; i++)
					pFieldSideT->fMidPoint[i] += fPoint[pFieldSideQuadT->iPoint[0]][i]+
												 fPoint[pFieldSideQuadT->iPoint[1]][i]+
												 fPoint[pFieldSideQuadT->iPoint[2]][i]+
												 fPoint[pFieldSideQuadT->iPoint[3]][i];
			}
			for(i = 0; i < 3; i++)
				pFieldSideT->fMidPoint[i] /= 9.0f;
		}
	}
} // end LEVEL::CalculateFacesMidPoint()

void LEVEL::DisableFieldUpdate(void)
{ // begin LEVEL::DisableFieldUpdate()
	for(int iField = 0; iField < Header.iFields; iField++)
		pField[iField].bUpdate = FALSE;
} // end LEVEL::DisableFieldUpdate()

void LEVEL::CalculateFieldBoundingBoxes(void)
{ // begin LEVEL::CalculateFieldBoundingBoxes()
	FIELD_SIDE_QUAD *pFieldSideQuadT;
	FIELD_SIDE *pFieldSideT;
	int iField, i, iPoint, iSide, iQuad;
	FLOAT3 *pfPointT;
	FIELD *pFieldT;

	// Calculate the field bounding boxes: (for frustum culling)
	// This technique is not the best, but it is good and fast enought for this game world:
	for(iField = 0; iField < Header.iFields; iField++)
	{
		pFieldT = &pField[iField];
		
		// Initialize bounding box:
		for(i = 0; i < 3; i++)
		{
			pFieldT->fBoundingBox[MIN][i] = (float) (Header.iWidth+Header.iHeight);
			pFieldT->fBoundingBox[MAX][i] = (float) -(Header.iWidth+Header.iHeight);
		}
		
		// Get the bounding box of this field:
		for(iSide = 0; iSide < 7; iSide++)
		{ // Go through each field side:
			pFieldSideT = &pFieldT->Side[iSide];
			for(iQuad = 0; iQuad < 4; iQuad++)
			{
				pFieldSideQuadT = &pFieldSideT->SideQuad[iQuad];
				for(iPoint = 0; iPoint < 4; iPoint++)
				{ // Go through each point of this field side:
					if(iSide == 6)
						pfPointT = &fWaterPoint[pFieldSideQuadT->iPoint[iPoint]];
					else
						pfPointT = &fPoint[pFieldSideQuadT->iPoint[iPoint]];
					// Check now each coordinate:
					for(i = 0; i < 3; i++)
					{
						if((*pfPointT)[i] < pFieldT->fBoundingBox[MIN][i])
							pFieldT->fBoundingBox[MIN][i] = (*pfPointT)[i];
						if((*pfPointT)[i] > pFieldT->fBoundingBox[MAX][i])
							pFieldT->fBoundingBox[MAX][i] = (*pfPointT)[i];
					}
				}
			}
		}
	}
} // end LEVEL::CalculateFieldBoundingBoxes()

void LEVEL::GetMinMiddleMax(void)
{ // begin LEVEL::GetMinMiddleMax()
	float fHeight;

	fLowestPoint = -2000.0f;
	fHighestPoint = 2000.0f;
	for(int i = 0; i < Header.iPoints; i++) 
	{
		fHeight = fPoint[i][Z];
		if(fHeight > fLowestPoint)
			fLowestPoint = fHeight;
		if(fHeight < fHighestPoint)
			fHighestPoint = fHeight;
	}
	fMiddlePoint = (fLowestPoint+fHighestPoint)/2;
} // end LEVEL::GetMinMiddleMax()

void LEVEL::CalculateWaterPoints(BOOL bOnlyVisible)
{ // begin CalculateWaterPoints()
	int i, iPoint;

	// Animate the water:
	if((500+Environment.fWaterWaveSpeed))
		fWaterWavesTimer += (float) g_lDeltatime/(500+Environment.fWaterWaveSpeed);
	if(bOnlyVisible)
	{
		for(i = 0; i < Header.iLevelPoints; i++)
		{
			if(iVisibleWaterPoints[i] == -1)
				break;
			iPoint = iVisibleWaterPoints[i];
			fWaterPoint[iPoint][Z] = (float) (fWaterStandartZ[iPoint]+
											  Environment.fWaterActualHeight+
											  fWaterAmplitude[iPoint]*
											  (0.07f*Environment.fWaterWaveAmplitude*((sin((fWaterPoint[iPoint][X]+fWaterWavesTimer)*Environment.fWaterWaveSize[X])+
											  sin((fWaterPoint[iPoint][Y]+fWaterWavesTimer)*Environment.fWaterWaveSize[Y])))));
		}
	}
	else
		for(i = 0; i < Header.iLevelPoints; i++)
			fWaterPoint[i][Z] = (float) (fWaterStandartZ[i]+
									     Environment.fWaterActualHeight+
										 fWaterAmplitude[i]*
										 (0.07f*Environment.fWaterWaveAmplitude*((sin((fWaterPoint[i][X]+fWaterWavesTimer)*Environment.fWaterWaveSize[X])+
										 sin((fWaterPoint[i][Y]+fWaterWavesTimer)*Environment.fWaterWaveSize[Y])))));
	CalculateWaterNormals(bOnlyVisible);
} // end CalculateWaterPoints()

WATER_TYPE LEVEL::GetWaterType(float fX, float fY)
{ // begin LEVEL::GetWaterType()
	int iXFieldPos, iYFieldPos, iFieldID;
	FIELD *pFieldT;

	if(fX < 0.0f || fY < 0.0f ||
	   fX >= Header.fWholeWidth || fY >= Header.fWholeHeight)
		return WATER_NONE;

	// Compute the current field we are on:
	COMPUTE_FIELD_POS(fX, fY, iXFieldPos, iYFieldPos);

	// Get a pointer to this field:
	GET_FIELD_ID(iXFieldPos, iYFieldPos, iFieldID);
	pFieldT = &pField[iFieldID];

	// Get a pointer to the field points:
	if(!pFieldT->bActivateWater)
		return WATER_NONE;

	return pFieldT->WaterType;
} // end LEVEL::GetWaterType()

BOOL LEVEL::GetWall(float fX, float fY)
{ // begin LEVEL::GetWall()
	int iXFieldPos, iYFieldPos;

	COMPUTE_FIELD_POS(fX, fY, iXFieldPos, iYFieldPos);
	if(iXFieldPos < 0 || iYFieldPos < 0 || iXFieldPos >= Header.iWidth ||
		iYFieldPos >= Header.iHeight)
		return 0;

	return pField[iYFieldPos*Header.iWidth+iXFieldPos].bWall;
} // end LEVEL::GetWall()

void LEVEL::CreateWaterBubbles(void)
{ // begin LEVEL::CreateWaterBubbles()
	AS_PARTICLE_SYSTEM *pSystemT;
	AS_PARTICLE *pParticleT;
	FIELD *pFieldT;
	int i, i2, iXFieldPos, iYFieldPos, iFieldID;
	
	if(!ASCheckTimeUpdate(&dwLastWaterBubbleTime, dwWaterBubbleSpeed))
		return;
	dwWaterBubbleSpeed = rand() % 3;
	pSystemT = &ParticleManager.pSystem[PS_WATER_BUBBLES];
	for(i2 = 0; i2 < 5*Environment.fWaterBubblesFrequency; i2++)
	{
		i = pSystemT->GetFreeParticle();
		if(i == -1)
			return;

		pParticleT = &pSystemT->pParticle[i];
		pParticleT->fPos[X] = pSystemT->fStartPos[X] = ((float) (rand() % (int) ((Header.fWholeWidth-1.0f)*100))/100);
		pParticleT->fPos[Y] = pSystemT->fStartPos[Y] = ((float) (rand() % (int) ((Header.fWholeHeight-1.0f)*100))/100);

		// Check if the bubble is visible:
		COMPUTE_FIELD_POS(pParticleT->fPos[X], pParticleT->fPos[Y], iXFieldPos, iYFieldPos);
		GET_FIELD_ID(iXFieldPos, iYFieldPos, iFieldID);
		pFieldT = &pField[iFieldID];
		if(!pFieldT->bOnScreen || !pFieldT->bActivateWater || !pFieldT->bActivateWaterBubbles)
			continue;

		pFieldT = ComputeHeight(pParticleT->fPos[X], pParticleT->fPos[Y], &pParticleT->fPos[Z], FACE_FLOOR, FALSE);
		if(!pFieldT)
		{
			pParticleT->bAlive = FALSE; // Theres no field!:
			continue;
		}
		if(!pFieldT->bForceWaterBubbles)
		{
			pFieldT = ComputeWaterHeight(pParticleT->fPos[X], pParticleT->fPos[Y], &pParticleT->fLastTestedHeight);
			if(pFieldT && pParticleT->fPos[Z]+pParticleT->fSize/8 <= pParticleT->fLastTestedHeight)
			{
				pParticleT->bAlive = FALSE; // No bubbles on land, please:
				continue;
			}
			ComputeWaterHeight(pParticleT->fPos[X], pParticleT->fPos[Y], &pParticleT->fLastTestedHeight);
		}
		else
		{
			pFieldT = ComputeWaterHeight(pParticleT->fPos[X], pParticleT->fPos[Y], &pParticleT->fLastTestedHeight);
			if(!pFieldT)
				pParticleT->fLastTestedHeight = 0.0f;
			pParticleT->fPos[Z]	= pParticleT->fLastTestedHeight+1.0f;
		}
		pParticleT->fPos[Z] += pParticleT->fSize/8;

		pParticleT->bAlive = TRUE;
		pParticleT->fEngine = 1.0f;
		pParticleT->fDensity = Environment.fWaterBubblesDensity;
		pParticleT->fColor[0] = Environment.fWaterBubblesColor[R];
		pParticleT->fColor[1] = Environment.fWaterBubblesColor[G];
		pParticleT->fColor[2] = Environment.fWaterBubblesColor[B];
		pParticleT->fFadeSpeed = 0.005f;
		pParticleT->fSize = (float) (rand() % 1000)/2000*Environment.fWaterBubblesSize;
		pParticleT->lLastHeightTestTime = g_lGameTimer;
		if(pParticleT->fSize < 0.1f)
			pParticleT->fSize = 0.1f;
		if(!(rand() % 2))
			pParticleT->fVelocity[X] = (float) (rand() % 1000)/2000;
		else
			pParticleT->fVelocity[X] = (float) -(rand() % 1000)/2000;
		if(!(rand() % 2))
			pParticleT->fVelocity[Y] = (float) (rand() % 1000)/2000;
		else
			pParticleT->fVelocity[Y] = (float) -(rand() % 1000)/2000;
		pParticleT->fVelocity[Z] = (float) -(rand() % 100)/1000;
		if(!pParticleT->fVelocity[Z])
			pParticleT->fVelocity[Z] = -0.01f;		
	}
} // end LEVEL::CreateWaterBubbles()

// Get an list of all beamer fields:
void LEVEL::GetBeamerList(void)
{ // begin LEVEL::GetBeamerList()
	int i, iBeamer = 0;
	FIELD *pFieldT;

	memset(pBeamerFieldList, 0, sizeof(FIELD *)*(Header.iFields+1));
	for(i = 0; i < Header.iFields; i++)
	{
		pFieldT = &pField[i];
		if(!pFieldT->Side[FACE_FLOOR].Surface[0].pSurface->Header.bBeamer ||
		   !pFieldT->bActive)
			continue;
		pBeamerFieldList[iBeamer++] = pFieldT;
	}
} // end LEVEL::GetBeamerList()

// Get an list of all decoration fields:
void LEVEL::GetDecorationList(void)
{ // begin LEVEL::GetDecorationList()
	int i, iDecoration = 0;
	FIELD *pFieldT;

	memset(pDecorationFieldList, 0, sizeof(FIELD *)*(Header.iFields+1));
	for(i = 0; i < Header.iFields; i++)
	{
		pFieldT = &pField[i];
		if(!pFieldT->pDecoration || pFieldT->pDecoration->iDecorationID < 0)
			continue;
		pDecorationFieldList[iDecoration++] = pFieldT;
	}
} // end LEVEL::GetDecorationList()

// Get an list of all trigger fields:
void LEVEL::GetTriggerList(void)
{ // begin LEVEL::GetTriggerList()
	int i, iDecoration = 0;
	FIELD *pFieldT;

	memset(pTriggerFieldList, 0, sizeof(FIELD *)*(Header.iFields+1));
	for(i = 0; i < Header.iFields; i++)
	{
		pFieldT = &pField[i];
		if(!pFieldT->bWaterChangeHeight || !pFieldT->bWaterChangeNotPressed)
			continue;
		pTriggerFieldList[iDecoration++] = pFieldT;
	}
} // end LEVEL::GetBeamerList()

// Get an list of all animated sides:
void LEVEL::GetAnimatedSurfacesList(void)
{ // begin LEVEL::GetAnimatedSurfacesList()
	int iField, iSide, iSurface, iSurfaces = 0;
	SURFACE *pSurfaceT;
	FIELD *pFieldT;

	memset(pAnimatedSurfacesList, 0, sizeof(FIELD_SIDE *)*(Header.iFields*14+1));
	for(iField = 0; iField < Header.iFields; iField++)
	{
		if(!(pFieldT = &pField[iField]))
			break;
		for(iSide = 0; iSide < 6+pFieldT->bActivateWater; iSide++)
		{
			if(!pFieldT->Side[iSide].bFaceActive)
				continue;
			for(iSurface = 0; iSurface < 2; iSurface++)
			{
				if(!(pSurfaceT = pFieldT->Side[iSide].Surface[iSurface].pSurface))
					continue;
				if(pSurfaceT->Header.iAniSteps == 1 && !pSurfaceT->Header.bChangeOnTime)
					continue;
				pAnimatedSurfacesList[iSurfaces++] = &pFieldT->Side[iSide].Surface[iSurface];
			}
		}
	}
} // end LEVEL::GetAnimatedSurfacesList()

void LEVEL::CheckFieldSurface(FIELD_SIDE_SURFACE *pFieldSurfaceT)
{ // begin LEVEL::CheckFieldSurface()
	SURFACE *pSurfaceT;
	
	if(!(pSurfaceT = pFieldSurfaceT->pSurface))
		return; // There is no surface!
	
	// Check surface animation:
	if(pSurfaceT->Header.iAniSteps != 1 && 
	   g_lGameTimer >= pFieldSurfaceT->dwLastTime+pSurfaceT->pTexturePos[pFieldSurfaceT->iCurrentAniStep].iTimeToNext)
	{ // It's time for an update:
		for(;;)
		{
			pFieldSurfaceT->dwLastTime += pSurfaceT->pTexturePos[pFieldSurfaceT->iCurrentAniStep].iTimeToNext;
			pFieldSurfaceT->iCurrentAniStep++;
			if(pFieldSurfaceT->iCurrentAniStep >= pSurfaceT->Header.iAniSteps)
			{
				pFieldSurfaceT->iCurrentAniStep = 0;
				if(pSurfaceT->Header.bChangeOnAnimationEnd)
				{
					pFieldSurfaceT->iSurface = pSurfaceT->Header.iChangeOnAnimationEndSurface;
					pFieldSurfaceT->pSurface = &pSurface[pFieldSurfaceT->iSurface];
					pFieldSurfaceT->dwLastChangeTime = pFieldSurfaceT->dwLastTime;
					break;
				}
			}
			if(pFieldSurfaceT->dwLastTime+pSurfaceT->pTexturePos[pFieldSurfaceT->iCurrentAniStep].iTimeToNext >= g_lGameTimer)
				break;
		}
	}

	// Check surface change:
	if(pSurfaceT->Header.bChangeOnTime &&
	   g_lGameTimer >= pFieldSurfaceT->dwLastChangeTime+pSurfaceT->Header.lChangeTime)
	{ // We have to change the surface:
		for(;;)
		{
			pFieldSurfaceT->dwLastChangeTime += pSurfaceT->Header.lChangeTime;
			pFieldSurfaceT->iSurface = pSurfaceT->Header.iChangeOnTimeSurface;
			pFieldSurfaceT->pSurface = &pSurface[pFieldSurfaceT->iSurface];
			pFieldSurfaceT->dwLastTime = pFieldSurfaceT->dwLastChangeTime;
			if(pFieldSurfaceT->pFieldSide->pField->pActor)
			{ // The actor should check its height:
				pFieldSurfaceT->pFieldSide->pField->pActor->fLastHeightCheckWorldPos[X] = -1.0f;
			}
			if(!pSurfaceT->Header.lChangeTime)
				pSurfaceT->Header.lChangeTime = 1;
			if(!pSurfaceT->Header.bChangeOnTime ||
			   g_lGameTimer < pFieldSurfaceT->dwLastChangeTime+pSurfaceT->Header.lChangeTime)
				break;
		}
	}
} // end LEVEL::CheckFieldSurface()

void LEVEL::Check(BOOL bOnlyVisible)
{ // begin LEVEL::Check()
	FIELD_SIDE_SURFACE *pSideSurfaceT;
	FIELD_DECORATION *pDecorationT;
	AS_PARTICLE_SYSTEM *pSystemT;
	AS_MD2_MODEL *pModelT;	
	FIELD *pFieldT;
	FLOAT3 fPointT;
	int i;

	// Animate:
	if(bPause && !State.bLevelComplete || !pInFOVFields)
		return;
	CalculateWaterPoints(TRUE);

	// Check if the water height should be changed:
	if(Environment.bWaterChangeHeight)
	{
		if(Environment.fWaterHeight < Environment.fWaterChangeHeightTo)
		{
			Environment.fWaterHeight += ((float) g_lDeltatime/5000)*Environment.fWaterChangeSpeed;
			if(Environment.fWaterHeight > Environment.fWaterChangeHeightTo)
			{
				Environment.fWaterHeight = Environment.fWaterChangeHeightTo;
				Environment.bWaterChangeHeight = FALSE;
			}
		}
		else
		{
			Environment.fWaterHeight -= ((float) g_lDeltatime/5000)*Environment.fWaterChangeSpeed;
			if(Environment.fWaterHeight < Environment.fWaterChangeHeightTo)
			{
				Environment.fWaterHeight = Environment.fWaterChangeHeightTo;
				Environment.bWaterChangeHeight = FALSE;
			}
		}
	}

	// Check the beamer fields:
	for(i = 0; ; i++)
	{
		if(!(pFieldT = pBeamerFieldList[i]))
			break;
		if(!pFieldT->bActive || !pFieldT->Side[FACE_FLOOR].Surface[0].pSurface->Header.bBeamer)
		{ // The beamer is no longer! Update the beamer list:
			pFieldT->iBeamerParticleSystemID = -1;
			GetBeamerList();
			continue;
		}
		if(pFieldT->fBeamerPower != 1.0f)
		{
			pFieldT->fBeamerPower += (float) g_lDeltatime/(pFieldT->iBeamerRegenerationSpeed+100);
			if(pFieldT->fBeamerPower > 1.0f)
				pFieldT->fBeamerPower = 1.0f;
		}
		if(pFieldT->iBeamerParticleSystemID == -1 && pFieldT->iBeamerTarget != -1)
		{ // Create an new particle system for this beamer:
			pFieldT->iBeamerParticleSystemID = ParticleManager.AddNewSystem(PS_Beamer, 50, NULL, &GameTexture[9], NULL);
			pSystemT = &ParticleManager.pSystem[pFieldT->iBeamerParticleSystemID];
			pSystemT->bActive = TRUE;
			pSystemT->fStartPos[X] = pFieldT->iXField+0.5f;
			pSystemT->fStartPos[Y] = pFieldT->iYField+0.5f;
			fPointT[X] = fPointT[Y] = 0.0f;
			fPointT[Z] = 0.0f;
			pFieldT = ComputeHeight(pSystemT->fStartPos[X], pSystemT->fStartPos[Y], &pSystemT->fStartPos[Z], FACE_FLOOR, FALSE);
			pSystemT->iVertex = pFieldT->iID;
			pSystemT->bAnimatedParticles = TRUE;
			pSystemT->iAnimationColumns = 2;
			pSystemT->iAnimationRows = 2;
			pSystemT->iTextureWidth = 128;
			pSystemT->iTextureHeight = 128;
		}
	}

	// Check the decoration fields:
	for(i = 0; ; i++)
	{
		if(!(pFieldT = pDecorationFieldList[i]))
			break;
		if(!(pDecorationT = pFieldT->pDecoration))
		{ // Refresh the decoration field list:
			GetBeamerList();
			continue;
		}
		if(!(pModelT = pDecorationModels[pDecorationT->iDecorationID].pModel))
			continue;

		if(!pDecorationT->bAnimated)
		{
			pDecorationT->dwAniTime = g_lGameTimer;
			pDecorationT->fModelInterpolation = (float) (g_lGameTimer-pDecorationT->dwAniTime)/(float) pDecorationT->iSpeed;
		}
		else
		{
			pDecorationT->dwAniDeltaTime = g_lGameTimer-pDecorationT->dwAniTime;
			pDecorationT->iNextAniStep = pDecorationT->iAniStep+1;
			if(pDecorationT->iNextAniStep >= pModelT->Ani.anim[pDecorationT->byAnimation].lastFrame)
				pDecorationT->iNextAniStep = pModelT->Ani.anim[pDecorationT->byAnimation].firstFrame;
			if(ASCheckTimeUpdate(&pDecorationT->dwAniTime, pDecorationT->iSpeed))
			{
				pDecorationT->iAniStep++;
				if(pDecorationT->iAniStep >= pModelT->Ani.anim[pDecorationT->byAnimation].lastFrame)
					pDecorationT->iAniStep = pModelT->Ani.anim[pDecorationT->byAnimation].firstFrame;
			}
			pDecorationT->fModelInterpolation = (float) (g_lGameTimer-pDecorationT->dwAniTime)/(float) pDecorationT->iSpeed;
			if(pDecorationT->iAniStep < 0 || pDecorationT->iAniStep >= pModelT->header.numFrames ||
			   pDecorationT->iNextAniStep < 0 || pDecorationT->iNextAniStep >= pModelT->header.numFrames)
			{
				pDecorationT->iAniStep = 0;
				pDecorationT->iNextAniStep = 1;
			}
		}
	}

	// Check the trigger fields:
	for(i = 0; ; i++)
	{
		if(!(pFieldT = pTriggerFieldList[i]) || !pFieldT->bWaterChangeNotPressed)
			break;
		if(Environment.fWaterHeight < pFieldT->fWaterChangeNotHeightTo)
		{
			Environment.fWaterHeight += ((float) g_lDeltatime/5000)*pFieldT->fWaterChangeNotSpeed;
			if(Environment.fWaterHeight > pFieldT->fWaterChangeNotHeightTo)
				Environment.fWaterHeight = pFieldT->fWaterChangeNotHeightTo;
		}
		else
		{
			Environment.fWaterHeight -= ((float) g_lDeltatime/5000)*pFieldT->fWaterChangeNotSpeed;
			if(Environment.fWaterHeight < pFieldT->fWaterChangeNotHeightTo)
				Environment.fWaterHeight = pFieldT->fWaterChangeNotHeightTo;
		}
	}

	// Check the animated sides:
	for(i = 0; ; i++)
	{
		if(!(pSideSurfaceT = pAnimatedSurfacesList[i]))
			break;
		if(!pSideSurfaceT->pFieldSide->bFaceActive)
		{ // We have to update the list!!
			GetAnimatedSurfacesList();
			break;
		}
		CheckFieldSurface(pSideSurfaceT);
	}
} // end LEVEL::Check()

void LEVEL::TextScriptIsDeleted(TEXT_SCRIPT *pTextScriptT, int iTextScriptID)
{ // begin LEVEL::TextScriptIsDeleted()
	ACTOR *pActorT;
	FIELD *pFieldT;
	int i, i2;

	if(!pTextScriptT)
	{
		if(!(pTextScriptT = TextScriptManager.GetTextScriptIDPointer(iTextScriptID)))
			return;
	}

	for(i = 0; i < Header.iFields; i++)
	{
		pFieldT = &pField[i];
		for(i2 = 0; i2 < 5; i2++)
		{
			if(pFieldT->pTextScript[i2] != pTextScriptT)
				continue;
			pFieldT->bTextScript[i2] = FALSE;
			pFieldT->pTextScript[i2] = NULL;
		}
	}

	for(i = 0; i < Header.iMaxActors; i++)
	{
		pActorT = pActorList[i];
		if(pActorT->pTextScript != pTextScriptT)
			continue;
		pActorT->bTextScript = FALSE;
		pActorT->pTextScript = NULL;
	}
} // end LEVEL::TextScriptIsDeleted()
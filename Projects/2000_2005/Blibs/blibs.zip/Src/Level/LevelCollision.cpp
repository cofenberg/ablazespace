//-----------------------------------------------------------------------------
// File: LevelCollision.cpp
//-----------------------------------------------------------------------------

#include "..\AS\AS_Engine.h"
#include "..\ModuleHeaders.h"


// LEVEL functions: ***********************************************************
// Computes the height of a given position in the level:
FIELD *LEVEL::ComputeHeight(float fX, float fY, float *pfHeight, char bySide, BOOL bInactiveToo)
{ // begin LEVEL::ComputeHeight()
	AS_VECTOR3D vStartPoint, // The ray start point
			    vRayDirection, // The ray direction (normalized)
			    vIntersectionPoint, // The found triangle intersection point
				vPoint1, vPoint2, vPoint3, vPoint4, vNormal1, vNormal2;
	int iXPos, iYPos, // Counter variables
		iXFieldPos, iYFieldPos, // Field x/y position in the level matrix
		iFieldID, // The field ID
		iQuad, // The currend checked field quad
		*piTempP;
	FIELD *pFieldT, // A pointer to the current field:
		  *pLastCollisionField = NULL; // Pointer to the field were the last collision
									   // was found
	char bySideT;
	ACTOR *pActorT;

	// Check if this is a correct point:
	if(fX < 0.0f || fY < 0.0f ||
	   fX >= Header.fWholeWidth || fY >= Header.fWholeHeight)
		return NULL;

	// Set the start point of the ray:
	vStartPoint.fX = fX;
	vStartPoint.fY = fY;
	*pfHeight = vStartPoint.fZ = -15.0f;

	// Set the ray direction:
	vRayDirection.fZ = 1.0f;

	// Compute the current field the given point is on:
	COMPUTE_FIELD_POS(fX, fY, iXFieldPos, iYFieldPos);

	// Check the field and the fields around:
	for(iYPos = iYFieldPos-1; iYPos < iYFieldPos+1; iYPos++)
	{
		// Check if this coordinate is a correct one:
		if(iYPos < 0 || iYPos > Header.iHeight-2)
			continue; // No correct field!
		for(iXPos = iXFieldPos-1; iXPos < iXFieldPos+1; iXPos++)
		{
			// Check if this coordinate is a correct one:
			if(iXPos < 0 || iXPos > Header.iWidth-2)
				continue; // No correct field!

			// Get a pointer to this field:
			GET_FIELD_ID(iXPos, iYPos, iFieldID);
			pFieldT = &pLevel->pField[iFieldID];
			if(!bInactiveToo)
			{
				if(!pFieldT->bActive && pFieldT->bWallHole)
				{
					bySideT = bySide;
					if(bySideT == FACE_FLOOR)
						bySideT = FACE_FRONT;
					if(!pFieldT->Side[bySideT].bFaceActive)
						continue;
				}
				else
				if(!pFieldT->bActive || !pFieldT->Side[bySide].bFaceActive)
					continue;
			}
			if(!pFieldT->pBridgeActor || pFieldT->pBridgeActor->bBridgeMovement)
			{ // Check all 4 quads of this field:
				for(iQuad = 0; iQuad < 4; iQuad++)
				{
					piTempP = &pFieldT->Side[bySide].SideQuad[iQuad].iPoint[0];
					vPoint1 = fPoint[piTempP[0]];
					vPoint2 = fPoint[piTempP[1]];
					vPoint3 = fPoint[piTempP[2]];
					vPoint4 = fPoint[piTempP[3]];
					vNormal1 = pFieldT->Side[bySide].SideQuad[iQuad].vNormal[0];
					vNormal2 = pFieldT->Side[bySide].SideQuad[iQuad].vNormal[1];
					if(ASCheckTriangleCollision(vStartPoint, vRayDirection, &vIntersectionPoint,
											    vPoint1, vPoint2, vPoint4, vNormal1) ||
					   ASCheckTriangleCollision(vStartPoint, vRayDirection, &vIntersectionPoint,
											    vPoint2, vPoint3, vPoint4, vNormal2))
					{
						if(vIntersectionPoint.fZ > *pfHeight)
						{
							*pfHeight = vIntersectionPoint.fZ;
							pLastCollisionField = pFieldT;
						}
					}
				}
				continue;
			}
			
			pActorT = pFieldT->pBridgeActor;
			if(pActorT && !pActorT->bGoingDeath && !pActorT->bBridgeMovement)
			{ // There is a bridge, check it too:
				vPoint1 = vPoint2 = vPoint3 = vPoint4 = pActorT->fWorldPos;
				vPoint1.fX -= 0.5f;
				vPoint1.fY -= 0.5f;
				vPoint1.fZ -= 1.0f;
				vPoint2.fX += 0.5f;
				vPoint2.fY -= 0.5f;
				vPoint2.fZ -= 1.0f;
				vPoint3.fX += 0.5f;
				vPoint3.fY += 0.5f;
				vPoint3.fZ -= 1.0f;
				vPoint4.fX -= 0.5f;
				vPoint4.fY += 0.5f;
				vPoint4.fZ -= 1.0f;
				vNormal1.fX = 0.0f;
				vNormal1.fY = 0.0f;
				vNormal1.fZ = -1.0f;
				if(ASCheckTriangleCollision(vStartPoint, vRayDirection, &vIntersectionPoint,
									        vPoint1, vPoint2, vPoint3, vNormal1) ||
				   ASCheckTriangleCollision(vStartPoint, vRayDirection, &vIntersectionPoint,
									        vPoint1, vPoint3, vPoint4, vNormal1))
				{
					if(*pfHeight < vIntersectionPoint.fZ)
					{
						*pfHeight = vIntersectionPoint.fZ;
						pLastCollisionField = pFieldT;
					}
				}
			}
		}
	}
	
	return pLastCollisionField;
} // end LEVEL::ComputeHeight()

FIELD *LEVEL::ComputeHeight(float fX, float fY, float *pfHeight, char bySide, AS_VECTOR3D vERadius)
{ // begin LEVEL::ComputeHeight()
	AS_VECTOR3D vIntersectionPoint, // The found triangle intersection point
				vPoint1, vPoint2, vPoint3, vPoint4,
				vSIPoint, vPIPoint, vPolyIPoint, vPNormal,
				vSourcePoint, // The point were we started
			    vVelocity, // The current velocity
				vNormalizedVelocity;
	BOOL bFoundCollision = FALSE;
	int iXPos, iYPos, // Counter variables
		iXFieldPos, iYFieldPos, // Field x/y position in the level matrix
		iFieldID, // The field ID
		iQuad, // The currend checked field quad
		*piTempP, i;
	double dDistanceToTravel,
		   dDistToPlaneIntersection,
		   dDistToEllipsoidIntersection,
		   dNearestDistance = -1;
	FIELD *pFieldT, // A pointer to the current field:
		  *pLastCollisionField = NULL; // Pointer to the field were the last collision
									   // was found

	// Check if this is a correct point:
	if(fX < 0.0f || fY < 0.0f ||
	   fX >= Header.fWholeWidth || fY >= Header.fWholeHeight)
		return NULL;
	
	// Setup our collision data:
	vSourcePoint.fX = fX;
	vSourcePoint.fY = fY;
	vSourcePoint.fZ = -15.0f;
	vVelocity.fZ = 30.0f;
	vSourcePoint /= vERadius;
	vVelocity /= vERadius;
	vNormalizedVelocity = vVelocity.GetNormalized();
	dDistanceToTravel = vVelocity.GetLength(); // How long is our velocity?

	// Compute the current field the given point is on:
	COMPUTE_FIELD_POS(fX, fY, iXFieldPos, iYFieldPos);

	AS_VECTOR3D vV, vNewSourcePoint;
	vNewSourcePoint.fZ = -15;
	ACTOR *pActorT;

	// Check the field and the fields around:
	for(iYPos = iYFieldPos-1; iYPos < iYFieldPos+1; iYPos++)
	{
		// Check if this coordinate is a correct one:
		if(iYPos < 0 || iYPos > Header.iHeight-2)
			continue; // No correct field!
		for(iXPos = iXFieldPos-1; iXPos < iXFieldPos+1; iXPos++)
		{
			// Check if this coordinate is a correct one:
			if(iXPos < 0 || iXPos > Header.iWidth-2)
				continue; // No correct field!

			// Get a pointer to this field:
			GET_FIELD_ID(iXPos, iYPos, iFieldID);
			pFieldT = &pLevel->pField[iFieldID];
			if(pFieldT->bActive && (!pFieldT->pBridgeActor || pFieldT->pBridgeActor->bBridgeMovement))
			{ // Check all 4 quads of this field:
				for(iQuad = 0; iQuad < 4; iQuad++)
				{
					piTempP = &pFieldT->Side[bySide].SideQuad[iQuad].iPoint[0];
					for(i = 0; i < 2; i++)
					{ // Get the data for the triangle in question and scale to ellipsoid space:
						vPoint1 = fPoint[piTempP[0+i]];
						vPoint2 = fPoint[piTempP[1+i]];
						vPoint3 = fPoint[piTempP[3]];
						vPoint1 /= vERadius;
						vPoint2 /= vERadius;
						vPoint3 /= vERadius;
						vPNormal = pFieldT->Side[bySide].SideQuad[iQuad].vNormal[i];

						// Ignore backfaces. What we cannot see we cannot collide with ;)
						if(vPNormal.DotProduct(vNormalizedVelocity) <= 1.0f)
						{ 
							// Calculate sphere intersection point:
							vSIPoint = vSourcePoint-vPNormal;     

							// Classify point to determine if ellipsoid span the plane:
							DWORD pClass = ASClassifyPoint(vSIPoint, vPoint1, vPNormal);

							// Find the plane intersection point:
							if(pClass == PLANE_BACKSIDE)
							{ // Plane is embedded in ellipsoid:
								// Find plane intersection point by shooting a ray from the 
								// sphere intersection point along the planes normal:
								dDistToPlaneIntersection = ASIntersectRayPlane(vSIPoint, vPNormal, vPoint1, vPNormal);

								// Calculate plane intersection point:
								vPIPoint.fX = (float) (vSIPoint.fX+dDistToPlaneIntersection*vPNormal.fX); 
								vPIPoint.fY = (float) (vSIPoint.fY+dDistToPlaneIntersection*vPNormal.fY); 
								vPIPoint.fZ = (float) (vSIPoint.fZ+dDistToPlaneIntersection*vPNormal.fZ); 	
							} 
							else
							{
								// Shoot ray along the velocity vector:
								dDistToPlaneIntersection = ASIntersectRayPlane(vSIPoint, vNormalizedVelocity, vPoint1, vPNormal);

								if(dDistToPlaneIntersection < EPSILON && dDistToPlaneIntersection > 0.0f)
									dDistToPlaneIntersection = dDistToPlaneIntersection;
								// Calculate plane intersection point:
								vPIPoint.fX = (float) (vSIPoint.fX+dDistToPlaneIntersection*vNormalizedVelocity.fX);
								vPIPoint.fY = (float) (vSIPoint.fY+dDistToPlaneIntersection*vNormalizedVelocity.fY);
								vPIPoint.fZ = (float) (vSIPoint.fZ+dDistToPlaneIntersection*vNormalizedVelocity.fZ);
							}

							// Find polygon intersection point. By default we assume its equal to the 
							// plane intersection point:
							vPolyIPoint = vPIPoint;
							dDistToEllipsoidIntersection = dDistToPlaneIntersection;

							if(!ASCheckPointInTriangle(vPIPoint, vPNormal, vPoint1, vPoint2, vPoint3))
							{ // If not in triangle:
								vPolyIPoint = ASClosestPointOnTriangle(vPoint1, vPoint2, vPoint3, vPIPoint);	
								dDistToEllipsoidIntersection = ASIntersectRaySphere(vPolyIPoint, -vNormalizedVelocity, vSourcePoint, 1.0f);

								if(dDistToEllipsoidIntersection > 0)
								{ // Calculate true sphere intersection point:
     								vSIPoint.fX = (float) (vPolyIPoint.fX+dDistToEllipsoidIntersection*(-vNormalizedVelocity.fX));
     								vSIPoint.fY = (float) (vPolyIPoint.fY+dDistToEllipsoidIntersection*(-vNormalizedVelocity.fY));
     								vSIPoint.fZ = (float) (vPolyIPoint.fZ+dDistToEllipsoidIntersection*(-vNormalizedVelocity.fZ));
								}
							}
							if(((dDistToEllipsoidIntersection > 0) && (dDistToEllipsoidIntersection <= dDistanceToTravel)) &&
							   (!bFoundCollision || (dDistToEllipsoidIntersection < dNearestDistance)))
							{  // If we are hit we have a closest hit so far. We save the information:
								dNearestDistance = dDistToEllipsoidIntersection;
								bFoundCollision = TRUE;
								pLastCollisionField = pFieldT;
								// Now calculate the real collision point and get it's height:
								vV = vVelocity;
								vV.SetLength((float) (dNearestDistance-EPSILON));
								vNewSourcePoint = vSourcePoint+vV;
								vNewSourcePoint *= vERadius;
							} 
						}
					}
				}
			}
			pActorT = pFieldT->pBridgeActor;
			if(pActorT && !pActorT->bGoingDeath && !pActorT->bBridgeMovement)
			{ // There is a bridge, check it too:
				// Set the ray direction:
				AS_VECTOR3D vRayDirection;
				vRayDirection.fZ = 1.0f;
				vPoint1 = vPoint2 = vPoint3 = vPoint4 = pActorT->fWorldPos;
				vPoint1.fX -= 0.5f;
				vPoint1.fY -= 0.5f;
				vPoint1.fZ -= 1.0f;
				vPoint2.fX += 0.5f;
				vPoint2.fY -= 0.5f;
				vPoint2.fZ -= 1.0f;
				vPoint3.fX += 0.5f;
				vPoint3.fY += 0.5f;
				vPoint3.fZ -= 1.0f;
				vPoint4.fX -= 0.5f;
				vPoint4.fY += 0.5f;
				vPoint4.fZ -= 1.0f;
				vPoint1 /= vERadius;
				vPoint2 /= vERadius;
				vPoint3 /= vERadius;
				vPoint4 /= vERadius;
				vPNormal.fX = 0.0f;
				vPNormal.fY = 0.0f;
				vPNormal.fZ = -1.0f;
				if(ASCheckTriangleCollision(vSourcePoint, vRayDirection, &vIntersectionPoint,
									        vPoint1, vPoint2, vPoint3, vPNormal) ||
				   ASCheckTriangleCollision(vSourcePoint, vRayDirection, &vIntersectionPoint,
									        vPoint1, vPoint3, vPoint4, vPNormal))
				{
					vIntersectionPoint *= vERadius;
					if(vNewSourcePoint.fZ < vIntersectionPoint.fZ-vERadius.fZ)
					{
						vNewSourcePoint.fZ = vIntersectionPoint.fZ-vERadius.fZ;
						pLastCollisionField = pFieldT;
					}
				}
			}
		}
	}
	
	*pfHeight = vNewSourcePoint.fZ;

	return pLastCollisionField;
} // end LEVEL::ComputeHeight()

FIELD *LEVEL::CheckCollision(AS_VECTOR3D vSourcePoint, AS_VECTOR3D vERadius, AS_VECTOR3D vVelocity)
{ // begin LEVEL::CheckCollision()
	AS_VECTOR3D vIntersectionPoint, // The found triangle intersection point
				vPoint1, vPoint2, vPoint3, vPoint4,
				vSIPoint, vPIPoint, vPolyIPoint, vPNormal,
				vNormalizedVelocity;
	BOOL bFoundCollision = FALSE;
	int iXPos, iYPos, // Counter variables
		iXFieldPos, iYFieldPos, // Field x/y position in the level matrix
		iFieldID, // The field ID
		iQuad, // The currend checked field quad
		*piTempP, i;
	char bySide;
	double dDistanceToTravel,
		   dDistToPlaneIntersection,
		   dDistToEllipsoidIntersection,
		   dNearestDistance = -1;
	FIELD *pFieldT, // A pointer to the current field:
		  *pLastCollisionField = NULL; // Pointer to the field were the last collision
									   // was found

	// Compute the current field the given point is on:
	COMPUTE_FIELD_POS(vSourcePoint.fX, vSourcePoint.fY, iXFieldPos, iYFieldPos);

	// Setup our collision data:
	vSourcePoint /= vERadius;
	vVelocity /= vERadius;
	vNormalizedVelocity = vVelocity.GetNormalized();
	dDistanceToTravel = vVelocity.GetLength(); // How long is our velocity?

	// Check the field and the fields around:
	for(iYPos = iYFieldPos-1; iYPos < iYFieldPos+1; iYPos++)
	{
		// Check if this coordinate is a correct one:
		if(iYPos < 0 || iYPos > Header.iHeight-2)
			continue; // No correct field!
		for(iXPos = iXFieldPos-1; iXPos < iXFieldPos+1; iXPos++)
		{
			// Check if this coordinate is a correct one:
			if(iXPos < 0 || iXPos > Header.iWidth-2)
				continue; // No correct field!

			// Get a pointer to this field:
			GET_FIELD_ID(iXPos, iYPos, iFieldID);
			pFieldT = &pLevel->pField[iFieldID];
			if(!pFieldT->bActive)
				continue;
			for(bySide = 0; bySide < 6; bySide++)
			{
				if(!pFieldT->Side[bySide].bFaceActive)
					continue; // This field side isn't active!
				// Check all 4 quads of this field:
				for(iQuad = 0; iQuad < 4; iQuad++)
				{
					piTempP = &pFieldT->Side[bySide].SideQuad[iQuad].iPoint[0];
					for(i = 0; i < 2; i++)
					{ // Get the data for the triangle in question and scale to ellipsoid space:
						vPoint1 = fPoint[piTempP[0+i]];
						vPoint2 = fPoint[piTempP[1+i]];
						vPoint3 = fPoint[piTempP[3]];
						vPoint1 /= vERadius;
						vPoint2 /= vERadius;
						vPoint3 /= vERadius;
						vPNormal = pFieldT->Side[bySide].SideQuad[iQuad].vNormal[i];

						// Ignore backfaces. What we cannot see we cannot collide with ;)
						if(vPNormal.DotProduct(vNormalizedVelocity) <= 1.0f)
						{ 
							// Calculate sphere intersection point:
							vSIPoint = vSourcePoint-vPNormal;     

							// Classify point to determine if ellipsoid span the plane:
							DWORD pClass = ASClassifyPoint(vSIPoint, vPoint1, vPNormal);

							// Find the plane intersection point:
							if(pClass == PLANE_BACKSIDE)
							{ // Plane is embedded in ellipsoid:
								// Find plane intersection point by shooting a ray from the 
								// sphere intersection point along the planes normal:
								dDistToPlaneIntersection = ASIntersectRayPlane(vSIPoint, vPNormal, vPoint1, vPNormal);

								// Calculate plane intersection point:
								vPIPoint.fX = (float) (vSIPoint.fX+dDistToPlaneIntersection*vPNormal.fX); 
								vPIPoint.fY = (float) (vSIPoint.fY+dDistToPlaneIntersection*vPNormal.fY); 
								vPIPoint.fZ = (float) (vSIPoint.fZ+dDistToPlaneIntersection*vPNormal.fZ); 	
							} 
							else
							{
								// Shoot ray along the velocity vector:
								dDistToPlaneIntersection = ASIntersectRayPlane(vSIPoint, vNormalizedVelocity, vPoint1, vPNormal);

								if(dDistToPlaneIntersection < EPSILON && dDistToPlaneIntersection > 0.0f)
									dDistToPlaneIntersection = dDistToPlaneIntersection;
								// Calculate plane intersection point:
								vPIPoint.fX = (float) (vSIPoint.fX+dDistToPlaneIntersection*vNormalizedVelocity.fX);
								vPIPoint.fY = (float) (vSIPoint.fY+dDistToPlaneIntersection*vNormalizedVelocity.fY);
								vPIPoint.fZ = (float) (vSIPoint.fZ+dDistToPlaneIntersection*vNormalizedVelocity.fZ);
							}

							// Find polygon intersection point. By default we assume its equal to the 
							// plane intersection point:
							vPolyIPoint = vPIPoint;
							dDistToEllipsoidIntersection = dDistToPlaneIntersection;

							if(!ASCheckPointInTriangle(vPIPoint, vPNormal, vPoint1, vPoint2, vPoint3))
							{ // If not in triangle:
								vPolyIPoint = ASClosestPointOnTriangle(vPoint1, vPoint2, vPoint3, vPIPoint);	
								dDistToEllipsoidIntersection = ASIntersectRaySphere(vPolyIPoint, -vNormalizedVelocity, vSourcePoint, 1.0f);

								if(dDistToEllipsoidIntersection > 0)
								{ // Calculate true sphere intersection point:
     								vSIPoint.fX = (float) (vPolyIPoint.fX+dDistToEllipsoidIntersection*(-vNormalizedVelocity.fX));
     								vSIPoint.fY = (float) (vPolyIPoint.fY+dDistToEllipsoidIntersection*(-vNormalizedVelocity.fY));
     								vSIPoint.fZ = (float) (vPolyIPoint.fZ+dDistToEllipsoidIntersection*(-vNormalizedVelocity.fZ));
								}
							}
							if(((dDistToEllipsoidIntersection > 0) && (dDistToEllipsoidIntersection <= dDistanceToTravel)) &&
							   (!bFoundCollision || (dDistToEllipsoidIntersection < dNearestDistance)))
							{  // If we are hit we have a closest hit so far. We save the information:
								dNearestDistance = dDistToEllipsoidIntersection;
								bFoundCollision = TRUE;
								pLastCollisionField = pFieldT;
								return pLastCollisionField; // We found an collision!
							} 
						}
					}
				}
			}
		}
	}
	
	return pLastCollisionField;
} // end LEVEL::CheckCollision()

// Computes the water height of a given position in the level:
FIELD *LEVEL::ComputeWaterHeight(float fX, float fY, float *pfHeight)
{ // begin LEVEL::ComputeWaterHeight()
	AS_VECTOR3D vStartPoint, // The ray start point
			    vRayDirection, // The ray direction (normalized)
			    vIntersectionPoint, // The found triangle intersection point
			    vPoint1, vPoint2, vPoint3, vPoint4, vNormal1, vNormal2;
	int iXPos, iYPos, // Counter variables
		iXFieldPos, iYFieldPos, // Field x/y position in the level matrix
		iFieldID, // The field ID
		iQuad, // The currend checked field quad
		*piTempP;
	FIELD *pFieldT, // A pointer to the current field:
		  *pLastCollisionField = NULL; // Pointer to the field were the last collision

	// Check if this is a correct point:
	if(fX < 0.0f || fY < 0.0f ||
	   fX >= Header.fWholeWidth || fY >= Header.fWholeHeight)
		return NULL;

	// Set the start point of the ray:
	vStartPoint.fX = fX;
	vStartPoint.fY = fY;
	*pfHeight = vStartPoint.fZ = 15.0f;

	// Set the ray direction:
	vRayDirection.fZ = -1.0f;

	// Compute the current field the given point is on:
	COMPUTE_FIELD_POS(fX, fY, iXFieldPos, iYFieldPos);

	// Check the field and the fields around:
	for(iYPos = iYFieldPos; iYPos < iYFieldPos+1; iYPos++)
	{
		// Check if this coordinate is a correct one:
		if(iYPos < 0 || iYPos > Header.iHeight-2)
			continue; // No correct field!
		for(iXPos = iXFieldPos; iXPos < iXFieldPos+1; iXPos++)
		{
			// Check if this coordinate is a correct one:
			if(iXPos < 0 || iXPos > Header.iWidth-2)
				continue; // No correct field!

			// Get a pointer to this field:
			GET_FIELD_ID(iXPos, iYPos, iFieldID);
			pFieldT = &pLevel->pField[iFieldID];
			if(!pFieldT->bActivateWater)
				continue;
			// Check all 4 quads of this field:
			for(iQuad = 0; iQuad < 4; iQuad++)
			{
				piTempP = &pFieldT->Side[FACE_WATER].SideQuad[iQuad].iPoint[0];
				vPoint1 = fWaterPoint[piTempP[0]];
				vPoint2 = fWaterPoint[piTempP[1]];
				vPoint3 = fWaterPoint[piTempP[2]];
				vPoint4 = fWaterPoint[piTempP[3]];
				vNormal1 = pFieldT->Side[FACE_WATER].SideQuad[iQuad].vNormal[0];
				vNormal2 = pFieldT->Side[FACE_WATER].SideQuad[iQuad].vNormal[1];
				if(ASCheckTriangleCollision(vStartPoint, vRayDirection, &vIntersectionPoint,
										    vPoint1, vPoint2, vPoint4, vNormal1) ||
				   ASCheckTriangleCollision(vStartPoint, vRayDirection, &vIntersectionPoint,
										    vPoint2, vPoint3, vPoint4, vNormal2))
				{
					if(*pfHeight > vIntersectionPoint.fZ)
					{
						*pfHeight = vIntersectionPoint.fZ;
						pLastCollisionField = pFieldT;
					}
				}
			}
		}
	}
	
	return pLastCollisionField;
} // end LEVEL::ComputeWaterHeight()

// An not exact but fast technique to compute the water color at an given point:
BOOL LEVEL::ComputeWaterColor(float fX, float fY, FLOAT4 *pfWaterColor)
{ // begin LEVEL::ComputeWaterColor()
	int iXFieldPos, iYFieldPos, iColor, iQuad;
	float fFieldXPos, fFieldYPos,
	      fLeftFieldColor, fRightFieldColor,
		  fLTPoint, fRTPoint, fRBPoint, fLBPoint;
	FIELD *pFieldT;
	FLOAT4 pLTPoint, pRTPoint, pRBPoint, pLBPoint;
	FIELD_SIDE_QUAD *pFieldQuadT;
	FIELD_SIDE *pFieldSideT;

	if(fX < 0.0f || fY < 0.0f ||
	   fX >= Header.fWholeWidth || fY >= Header.fWholeHeight)
	{
		(*pfWaterColor)[R] = (*pfWaterColor)[G] = (*pfWaterColor)[B] = 0.0f;
		return FALSE;
	}
	
	// Compute the current field we are on:
	COMPUTE_FIELD_POS(fX, fY, iXFieldPos, iYFieldPos);
	
	// Get a pointer to this field:
	GET_FIELD_POINTER(iXFieldPos, iYFieldPos, pFieldT);
	
	// Get a pointer to the field points:
	if(!pFieldT->bActivateWater)
	{
		(*pfWaterColor)[R] = (*pfWaterColor)[G] =
		(*pfWaterColor)[B] = (*pfWaterColor)[A] = 0.0f;
		return FALSE; // The water is deactivated on this field!
	}

	// Compute the x and y position in the field:
	fFieldXPos = fX-pFieldT->iXField;
	fFieldYPos = fY-pFieldT->iYField;

	// Get current field quad:
	if(fFieldXPos < 0.5f && fFieldYPos < 0.5f)
		iQuad = 0;
	else
	if(fFieldXPos >= 0.5f && fFieldYPos < 0.5f)
		iQuad = 1;
	else
	if(fFieldXPos >= 0.5f && fFieldYPos >= 0.5f)
		iQuad = 2;
	else
	if(fFieldXPos < 0.5f && fFieldYPos >= 0.5f)
		iQuad = 3;
	pFieldSideT = &pFieldT->Side[FACE_WATER];

	// Now calculate the current water color:
	for(iColor = 0; iColor < 4; iColor++)
	{
		pFieldQuadT	= &pFieldSideT->SideQuad[iQuad];
		fLTPoint = fWaterColor[pFieldQuadT->iPoint[0]][iColor];
		fRTPoint = fWaterColor[pFieldQuadT->iPoint[1]][iColor];
		fRBPoint = fWaterColor[pFieldQuadT->iPoint[2]][iColor];
		fLBPoint = fWaterColor[pFieldQuadT->iPoint[3]][iColor];
		memcpy(&pLTPoint, fWaterPoint[pFieldQuadT->iPoint[0]], sizeof(FLOAT3));
		memcpy(&pRTPoint, fWaterPoint[pFieldQuadT->iPoint[1]], sizeof(FLOAT3));
		memcpy(&pRBPoint, fWaterPoint[pFieldQuadT->iPoint[2]], sizeof(FLOAT3));
		memcpy(&pLBPoint, fWaterPoint[pFieldQuadT->iPoint[3]], sizeof(FLOAT3));

		// Now compute the heigt on this field position:
		// First we compute the left and right field height on this field y pos:
		if(!(fLBPoint-fLTPoint))
			fLeftFieldColor = fLTPoint;
		else
			fLeftFieldColor = fLTPoint+(fLBPoint-fLTPoint)/(pLBPoint[Y]-pLTPoint[Y])*fFieldYPos;
		if(!(fRBPoint-fRTPoint))
			fRightFieldColor = fRTPoint;
		else
			fRightFieldColor = fRTPoint+(fRBPoint-fRTPoint)/(pRBPoint[Y]-pRTPoint[Y])*fFieldYPos;
		// Compute now the hight on the x positon on the field:
		if(!(fLeftFieldColor-fRightFieldColor))
			(*pfWaterColor)[iColor] = fLeftFieldColor;
		else
			(*pfWaterColor)[iColor] = fRightFieldColor+(fLeftFieldColor-fRightFieldColor)/(pRTPoint[X]-pLTPoint[X])*fFieldXPos;
	}

	// Yea, we calculated the corresponding color of this x and y position in the level!!
	return TRUE;
} // end LEVEL::ComputeWaterColor()
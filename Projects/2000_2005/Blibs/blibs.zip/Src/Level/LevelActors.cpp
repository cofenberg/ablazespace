//-----------------------------------------------------------------------------
// File: LevelActors.cpp
//-----------------------------------------------------------------------------

#include "..\AS\AS_Engine.h"
#include "..\ModuleHeaders.h"


// Variables: *****************************************************************
AS_TEXTURE ActorTexture[ACTOR_TEXTURES]; // The actor textures
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
void LoadRequiredActorTextues(HDC hDC, HGLRC hRC, BOOL);
void ActorGenTexturesOpenGL(HDC, HGLRC, BOOL);
void ActorDestroyTexturesOpenGL(HDC, HGLRC, BOOL);
void ActorLoadTextures(BOOL);
void ActorDestroyTextures(BOOL);
///////////////////////////////////////////////////////////////////////////////


void LoadRequiredActorTextues(HDC hDC, HGLRC hRC, BOOL bAll)
{ // begin LoadRequiredActorTextues()
	AS_PROGRESS_WINDOW ProgressWindow;
	ACTOR *pActorT;
	int i;

	if(!pLevel || !hDC || !hRC || !wglMakeCurrent(hDC, hRC))
		return;
	_AS->WriteLogMessage("Load all required actor textures");
	ProgressWindow.CreateProgressWindow("Load required actor textures");
	ProgressWindow.SetTask("Check texture usage...");
	ProgressWindow.SetProgress(0);

	if(!bAll)
	{ // Check which actor textures are required:
		for(i = 0; i < ACTOR_TEXTURES; i++)
			ActorTexture[i].iUsed = 0;
		for(i = 0; i < pLevel->Header.iMaxActors; i++)
		{
			pActorT = pLevel->pActorList[i];
			if(!pActorT->bActive || (pActorT->iTexture != -1 && pActorT->Type != AT_BLIBS))
				continue;
			switch(pActorT->Type)
			{
				case AT_BLIBS:
					ActorTexture[RAMBO_BLIBS_TEXTURE].iUsed++;
					if(pActorT->iTexture != -1)
						break;
					ActorTexture[BLIBS_TEXTURE].iUsed++;
				break;

				case AT_MOBMOB: ActorTexture[MOBMOB_TEXTURE].iUsed++; break;
				case AT_X3: ActorTexture[X3_TEXTURE].iUsed++; break;
				case AT_LUCIFER_HEAD: ActorTexture[LUCIFER_TEXTURE].iUsed++; break;
				case AT_LUCIFER: ActorTexture[LUCIFER_TEXTURE].iUsed++; break;
			}
		}
	}
	else
	{ // Load in all actor textures:
		for(i = 0; i < ACTOR_TEXTURES; i++)
			ActorTexture[i].iUsed = 1;
	}

	// Now unload all none required textures:
	ActorDestroyTexturesOpenGL(hDC, hRC, FALSE);
	ActorDestroyTextures(FALSE);

	// Now load and setup all required actor textures:
	ActorLoadTextures(FALSE);
	ActorGenTexturesOpenGL(hDC, hRC, FALSE);
} // end LoadRequiredActorTextues()

void ActorGenTexturesOpenGL(HDC hDC, HGLRC hRC, BOOL bAll)
{ // begin ActorGenTextures()
	AS_PROGRESS_WINDOW ProgressWindow;
	AS_TEXTURE *pTextureT;

	if(!hDC || !hRC || !wglMakeCurrent(hDC, hRC))
		return;

	ProgressWindow.CreateProgressWindow("Load textures");
	ProgressWindow.SetTask("Generate OpenGL actor textures...");
	ProgressWindow.SetProgress(0);

	_AS->WriteLogMessage("Create OpenGL actor textures");
	for(int i = 0; i < ACTOR_TEXTURES; i++)
	{
		pTextureT = &ActorTexture[i];
		ProgressWindow.SetSubTask("%s", pTextureT->byFilename);
		ProgressWindow.SetProgress((UINT) (((float) i/ACTOR_TEXTURES)*100));
		if(!pTextureT->pbyData || ((!pTextureT->iUsed || pTextureT->iOpenGLID) && !bAll))
			continue;

		// First delete the old textures:
		if(pTextureT->iOpenGLID)
			glDeleteTextures(1, &pTextureT->iOpenGLID);
		_AS->WriteLogMessage(pTextureT->byFilename);

		// Now generate the new:
		glGenTextures(1, &pTextureT->iOpenGLID);
		glBindTexture(GL_TEXTURE_2D, pTextureT->iOpenGLID);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
		if(_ASConfig->bUseMipmaps && !pTextureT->bNoMipmap)
		{
			if(_ASConfig->bFastTexturing)
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST_MIPMAP_NEAREST);
				gluBuild2DMipmaps(GL_TEXTURE_2D, pTextureT->byColorComponents, pTextureT->iWidth,
								  pTextureT->iHeight, pTextureT->iFormat, GL_UNSIGNED_BYTE,
								  pTextureT->pbyData);
			}
			else
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);
				gluBuild2DMipmaps(GL_TEXTURE_2D, pTextureT->byColorComponents, pTextureT->iWidth,
								  pTextureT->iHeight, pTextureT->iFormat, GL_UNSIGNED_BYTE,
								  pTextureT->pbyData);
			}
		}
		else
		{
			if(_ASConfig->bFastTexturing)
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
				glTexImage2D(GL_TEXTURE_2D, 0, pTextureT->byColorComponents, pTextureT->iWidth,
							 pTextureT->iHeight, 0, pTextureT->iFormat, GL_UNSIGNED_BYTE,
							 pTextureT->pbyData);
			}
			else
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
				glTexImage2D(GL_TEXTURE_2D, 0, pTextureT->byColorComponents, pTextureT->iWidth,
							 pTextureT->iHeight, 0, pTextureT->iFormat, GL_UNSIGNED_BYTE,
							 pTextureT->pbyData);
			}
		}
	}
} // end ActorGenTextures()

void ActorDestroyTexturesOpenGL(HDC hDC, HGLRC hRC, BOOL bAll)
{ // begin ActorDestroyTexturesOpenGL()
	AS_TEXTURE *pTextureT;

	if(!hDC || !hRC || !wglMakeCurrent(hDC, hRC))
		return;
	AS_PROGRESS_WINDOW ProgressWindow;

	ProgressWindow.CreateProgressWindow("Destroy textures");
	ProgressWindow.SetTask("Destroy OpenGL actor textures...");
	ProgressWindow.SetProgress(0);
	_AS->WriteLogMessage("Destroy OpenGL actor textures");
	for(int i = 0; i < ACTOR_TEXTURES; i++)
	{
		pTextureT = &ActorTexture[i];
		_AS->WriteLogMessage(pTextureT->byFilename);
		ProgressWindow.SetSubTask("%s", pTextureT->byFilename);
		ProgressWindow.SetProgress((UINT) (((float) i/ACTOR_TEXTURES)*100));
		if(!pTextureT->iOpenGLID || (!bAll && pTextureT->iUsed))
			continue;
		glDeleteTextures(1, &pTextureT->iOpenGLID);
		pTextureT->iOpenGLID = 0;
	}
} // end ActorDestroyTexturesOpenGL()

void ActorLoadTextures(BOOL bAll)
{ // begin ActorLoadTextures()
	AS_PROGRESS_WINDOW ProgressWindow;
	AS_TEXTURE *pTextureT;
	char byTemp[256];

	ProgressWindow.CreateProgressWindow("Load textures");
	ProgressWindow.SetTask("Load actor textures...");
	ProgressWindow.SetProgress(0);
	_AS->WriteLogMessage("Load actor textures");
	for(int i = 0; i < ACTOR_TEXTURES; i++)
	{
		pTextureT = &ActorTexture[i];
		if(pTextureT->pbyData || (!bAll && !pTextureT->iUsed))
			continue;
		switch(i)
		{
			case BLIBS_TEXTURE: strcpy(pTextureT->byFilename, "Blibs.jpg"); break;
			case RAMBO_BLIBS_TEXTURE: strcpy(pTextureT->byFilename, "BlibsRambo.jpg"); break;
			case MOBMOB_TEXTURE: strcpy(pTextureT->byFilename, "Mobmob.jpg"); break;
			case X3_TEXTURE: strcpy(pTextureT->byFilename, "X3.jpg"); break;
			case LUCIFER_TEXTURE: strcpy(pTextureT->byFilename, "Lucifer.jpg"); break;
		}
		sprintf(byTemp, "%s%s\\%s", _AS->byProgramPath, _AS->byBitmapsDirectory, pTextureT->byFilename);
		_AS->WriteLogMessage(pTextureT->byFilename);
		ProgressWindow.SetSubTask("%s", pTextureT->byFilename);
		ProgressWindow.SetProgress((UINT) (((float) i/ACTOR_TEXTURES)*100));
		ASLoadTexture(pTextureT, byTemp);
	}
} // end ActorLoadTextures()

void ActorDestroyTextures(BOOL bAll)
{ // begin ActorDestroyTextures()
	AS_PROGRESS_WINDOW ProgressWindow;
	AS_TEXTURE *pTextureT;

	ProgressWindow.CreateProgressWindow("Destroy textures");
	ProgressWindow.SetTask("Destroy actor textures...");
	ProgressWindow.SetProgress(0);
	_AS->WriteLogMessage("Destroy actor textures");
	for(int i = 0; i < ACTOR_TEXTURES; i++)
	{
		pTextureT = &ActorTexture[i];
		_AS->WriteLogMessage(pTextureT->byFilename);
		ProgressWindow.SetSubTask("%s", pTextureT->byFilename);
		ProgressWindow.SetProgress((UINT) (((float) i/ACTOR_TEXTURES)*100));
		if(!pTextureT->pbyData || (!bAll && pTextureT->iUsed))
			continue;
		SAFE_FREE(pTextureT->pbyData);
	}
} // end ActorDestroyTextures()
///////////////////////////////////////////////////////////////////////////////



// ACTOR functions: ***********************************************************
// Finds an free actor in the actor list:
ACTOR *LEVEL::FindFreeActor(void)
{ // begin FindFreeActor()
	ACTOR *pActorT;

	// Find a none active actor and give a pointer to it back:
	for(int i = 0; i < Header.iMaxActors; i++)
	{
		pActorT = pActorList[i];
		if(pActorT->bActive)
			continue;
		memset(pActorT, 0, sizeof(ACTOR));	
		pActorT->iID = i;
		pActorT->dwAniTime = g_lGameTimer;
		pActorT->fColor[0] = pActorT->fColor[1] = pActorT->fColor[2] = 1.0f;
		pActorT->fAir = 1.0f;
		pActorT->iTempFieldID = -1;
		pActorT->iParticleSystemID = -1;
		pActorT->bTextScriptAlways = TRUE;
		pActorT->bShadow = TRUE;
		pActorT->iTexture = -1;
		return pActorT;
	}
	
	return FALSE;
} // end LEVEL::FindFreeActor()

// Sort all actors so that all active are on the top, and
// give the number of active actors back:
int LEVEL::SortActors(void)
{ // begin LEVEL::SortActors()
	ACTOR **pActorListT, *pActorT;
	int i, i2, i3;
	
	pActorListT = (ACTOR **) malloc(sizeof(ACTOR)*Header.iMaxActors);
	memset(pActorListT, 0, sizeof(ACTOR *)*Header.iMaxActors);

	// Get all active actors an set them on the top:
	for(i = 0, i2 = 0; i < Header.iMaxActors; i++)
	{
		pActorT = pActorList[i];
		if(!pActorT->bActive)
			continue;
		pActorListT[i2] = pActorT;
		i2++;
	}

	// Now get all inactive actors an set them after the active ones:
	for(i = 0, i3 = i2; i < Header.iMaxActors; i++)
	{
		pActorT = pActorList[i];
		if(pActorT->bActive)
			continue;
		pActorListT[i3] = pActorT;
		i3++;
	}

	// Update our actor list:
	memcpy(pActorList, pActorListT, sizeof(ACTOR *)*Header.iMaxActors);
	
	SAFE_FREE(pActorListT);

	return i2;
} // end LEVEL::SortActors()

// Resizes the actor list:
void LEVEL::ResizeActorList(int iNewMaxActors)
{ // begin LEVEL::ResizeActorList()
	int i;
	
	// Delete the actors which are too much:
	if(Header.iMaxActors > iNewMaxActors)
		for(i = iNewMaxActors; i < Header.iMaxActors; i++)
		{
			pActorList[i]->RemoveFromFields();
			if(pPlayer == pActorList[i])
				pPlayer = NULL;
			SAFE_FREE(pActorList[i]);
		}
		
	// Now resize the list itself:
	pActorList = (ACTOR **) realloc(pActorList, sizeof(ACTOR *)*iNewMaxActors);
	pVisibleActors = (ACTOR **) realloc(pVisibleActors, sizeof(ACTOR *)*iNewMaxActors+1);
	
	// Get memory for the new actors:
	for(i = Header.iMaxActors; i < iNewMaxActors; i++)
	{
		pActorList[i] = (ACTOR *) malloc(sizeof(ACTOR));
		memset(pActorList[i], 0, sizeof(ACTOR));
	}
	
	Header.iMaxActors = iNewMaxActors;
} // end LEVEL::ResizeActorList()

// Destroys the actor list:
void LEVEL::DestroyActorList(void)
{ // begin LEVEL::DestroyActorList()
	SAFE_FREE(pVisibleActors);
	if(!pActorList)
		return; // Theres no actor list!
	for(int i = 0; i < Header.iMaxActors; i++)
		SAFE_FREE(pActorList[i]);
	SAFE_FREE(pActorList);
	pPlayer = NULL;
} // end LEVEL::DestroyActorList()

// Check, if the actors on the screen:
void LEVEL::CheckIfActorsOnScreen(void)
{ // begin LEVEL::CheckIfActorsOnScreen()
	ACTOR *pActorT;
	int i, i2;

	if(!pActorList || !pVisibleActors)
		return;
	for(i = 0, i2 = 0; i < Header.iMaxActors; i++)
	{
		pActorT = pActorList[i];
		if(!pActorT->bActive || !pField[pActorT->iFieldID].bOnScreen)
			pActorT->bOnScreen = FALSE;
		else
		{
			pActorT->bOnScreen = TRUE;
			pVisibleActors[i2++] = pActorList[i];
		}
	}
	pVisibleActors[i2] = NULL;
} // end LEVEL::CheckIfActorsOnScreen()

// Setups the lights of all actors:
void LEVEL::SetupAllActorLights(void)
{ // begin LEVEL::SetupAllActorLights()
	for(int i = 0; i < Header.iMaxActors; i++)
		pActorList[i]->SetupLighting();
} // end LEVEL::SetupAllActorLights()

// Draws all level actors:
void LEVEL::DrawActors(void)
{ // begin LEVEL::DrawActors()
	FLOAT3 fBoxPoints[8] = 
	{
		{-0.5f, -0.5f, 0.0f}, // 0
		{0.5f, -0.5f, 0.0f}, // 1
		{0.5f, 0.5f, 0.0f}, // 2
		{-0.5f, 0.5f, 0.0f}, // 3
		{-0.5f, -0.5f, -1.0f}, // 4
		{0.5f, -0.5f, -1.0f}, // 5
		{0.5f, 0.5f, -1.0f}, // 6
		{-0.5f, 0.5f, -1.0f}, // 7
	};
	int iActor;
	ACTOR *pActorT;

	if(!pVisibleActors)
		return;
	
	// First, draw all boxes:
	glEnable(GL_TEXTURE_2D);
	glCullFace(GL_BACK);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);
	glDisableClientState(GL_COLOR_ARRAY);
	glDisableClientState(GL_NORMAL_ARRAY);
	glEnableClientState(GL_VERTEX_ARRAY);
	glVertexPointer(3, GL_FLOAT, 0, fBoxPoints);
	if(_AS->bCompiledVertexArraySupported)
		glLockArraysEXT(0, 8);

	_AS->iCurrentTexture = -1;
	for(iActor = 0; iActor < Header.iMaxActors; iActor++)
	{
		if(!(pActorT = pVisibleActors[iActor]))
			break;
		switch(pActorT->Type)
		{				
			case AT_BOX_NORMAL:
			case AT_BOX_RED:
			case AT_BOX_GREEN:
			case AT_BOX_BLUE:
				pActorT->DrawBox();
			break;
		}
	}

	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);
	if(_AS->bCompiledVertexArraySupported)
		glUnlockArraysEXT();

	// Draw all items with the first item texture:
	_AS->iCurrentTexture = -1;
	glBindTexture(GL_TEXTURE_2D, GameTexture[24].iOpenGLID);
	for(iActor = 0; iActor < Header.iMaxActors; iActor++)
	{
		if(!(pActorT = pVisibleActors[iActor]))
			break;
		switch(pActorT->Type)
		{
			case AT_HEALTH_ITEM:
			case AT_HEALTH_INCREASE_ITEM:
			case AT_LIFE_ITEM:
			case AT_PULL_ITEM:
			case AT_STRENGTH_ITEM:
			case AT_WEAPON_ITEM:
			case AT_COIN_ITEM:
			case AT_TIME_ITEM:
			case AT_STEP_ITEM:
			case AT_SPEED_ITEM:
			case AT_WING_ITEM:
			case AT_JUMP_ITEM:
			case AT_AIR_ITEM:
			case AT_AIR_INCREASE_ITEM:
			case AT_THROW_ITEM:
			case AT_KICK_ITEM:
			case AT_BAG_ITEM:
				pActorT->DrawItem();
			break;
		}
	}

	// Draw all items with the second item texture:
	glBindTexture(GL_TEXTURE_2D, GameTexture[25].iOpenGLID);
	for(iActor = 0; iActor < Header.iMaxActors; iActor++)
	{
		if(!(pActorT = pVisibleActors[iActor]))
			break;
		switch(pActorT->Type)
		{
			case AT_CHEST_ITEM:
			case AT_GHOST_ITEM:
			case AT_SHIELD_ITEM:
			case AT_DYNAMITE_ITEM:
				pActorT->DrawItem();
			break;
		}
	}

	// Now draw all other actors:
	for(iActor = 0; iActor < Header.iMaxActors; iActor++)
	{
		if(!(pActorT = pVisibleActors[iActor]))
			break;
		switch(pActorT->Type)
		{
			case AT_BLIBS: pActorT->DrawBlibs(); break;
			case AT_MOBMOB: pActorT->DrawMobmob(); break;
			case AT_X3: pActorT->DrawX3(); break;
			case AT_LUCIFER_HEAD: pActorT->DrawLuciferHead(); break;
			case AT_LUCIFER: pActorT->DrawLucifer(); break;
			case AT_SHOT_1: pActorT->DrawShot1(); break;
		}
	}
} // end LEVEL::DrawActors()

// Checks all level actors:
void LEVEL::CheckActors(BOOL bEditor)
{ // begin LEVEL::CheckActors()
	ACTOR *pActorT;
	int i;
	
	if(!pActorList)
		return;
	for(i = 0; i < Header.iMaxActors; i++)
	{
		pActorT = pActorList[i];
		if(!pActorT->bActive)
			continue;

		// Check the actor:
		switch(pActorT->Type)
		{
			case AT_BLIBS: pActorT->CheckBlibs(bEditor); break;
			case AT_MOBMOB: pActorT->CheckMobmob(bEditor); break;
			case AT_X3: pActorT->CheckX3(bEditor); break;
			case AT_LUCIFER_HEAD: pActorT->CheckLuciferHead(bEditor); break;
			case AT_LUCIFER: pActorT->CheckLucifer(bEditor); break;

			case AT_BOX_NORMAL:
			case AT_BOX_RED:
			case AT_BOX_GREEN:
			case AT_BOX_BLUE:
				pActorT->CheckBox(bEditor);
			break;

			case AT_HEALTH_ITEM:
			case AT_HEALTH_INCREASE_ITEM:
			case AT_LIFE_ITEM:
			case AT_PULL_ITEM:
			case AT_CHEST_ITEM:
			case AT_STRENGTH_ITEM:
			case AT_WEAPON_ITEM:
			case AT_COIN_ITEM:
			case AT_GHOST_ITEM:
			case AT_TIME_ITEM:
			case AT_STEP_ITEM:
			case AT_SPEED_ITEM:
			case AT_WING_ITEM:
			case AT_SHIELD_ITEM:
			case AT_JUMP_ITEM:
			case AT_AIR_ITEM:
			case AT_AIR_INCREASE_ITEM:
			case AT_THROW_ITEM:
			case AT_KICK_ITEM:
			case AT_BAG_ITEM:
			case AT_DYNAMITE_ITEM:
				pActorT->CheckItem();
			break;

			case AT_SHOT_1:
				pActorT->CheckShot1();
			break;
		}
	}

	if(bEditor)
	{
		OktaActor.bActive = FALSE;
		return;
	}
} // end LEVEL::CheckActors()

void LEVEL::DrawActorEffects(void)
{ // begin LEVEL::DrawActorEffects()
	ACTOR *pActorT;
	AS_VECTOR3D vPos;
	FLOAT3 fPos, fPos2;
	float fScale;
	int i, i2;

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_CULL_FACE);
	glDepthMask(FALSE);
	glDisable(GL_FOG);
	glDisable(GL_LIGHTING);

	// Effects are drawn over the complete scene:
	for(i2 = 0; i2 < Header.iMaxActors; i2++)
	{
		pActorT = pVisibleActors[i2];
		if(!pActorT)
			break;

		if(pActorT->Type == AT_SHOT_1)
		{ // Draw the shot flares:
			vPos = pActorT->fWorldPos;
			DrawFlares(vPos, 1.0f, 0.6f, 0.6f, 0.8f*pActorT->fSize, fFlareRot);
		}

		if(pActorT->bGoingDeath && pActorT->bOnScreen)
		{ // Draw the dead wave:
			glDepthMask(FALSE);
			glDisable(GL_CULL_FACE);
			glEnable(GL_TEXTURE_2D);
			glPushMatrix();
			if(pActorT->Type == AT_SHOT_1)
				glTranslatef(pActorT->fWorldPos[X],
							 pActorT->fWorldPos[Y],
							 pActorT->fWorldPos[Z]);
			else
				glTranslatef(pActorT->fWorldPos[X]+pActorT->fPosTemp[X],
							 pActorT->fWorldPos[Y]+pActorT->fPosTemp[Y],
							 pActorT->fWorldPos[Z]+pActorT->fPosTemp[Z]-0.5f);
			glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
			glRotatef(pActorT->fRot[X], 0.0f, 1.0f, 0.0f);
			glRotatef(pActorT->fRot[Y], 0.0f, 1.0f, 0.0f);
			glRotatef(pActorT->fRot[Z], 0.0f, 1.0f, 0.0f);
			if(pActorT->Type == AT_BOX_NORMAL ||
			   pActorT->Type == AT_BOX_RED ||
			   pActorT->Type == AT_BOX_GREEN ||
			   pActorT->Type == AT_BOX_BLUE)
			{
				glScalef(pActorT->fSize*0.4f, pActorT->fSize*0.4f, pActorT->fSize*0.4f);
				glColor4f(pActorT->fColor[0]+0.1f, pActorT->fColor[1]+0.1f, pActorT->fColor[2]+0.1f, pActorT->fSize);
			}
			else
			{
				glScalef(pActorT->fSize*0.2f, pActorT->fSize*0.2f, pActorT->fSize*0.2f);
				glColor4f(1.0f, 1.0f, 1.0f, pActorT->fSize);
			}
			fScale = (1.0f-pActorT->fSize)/0.3f*10.0f;
			glScalef(fScale, fScale, fScale);
			glCallList(iWaveList);
			glRotatef(45.0f, 1.0f, 0.0f, 0.0f);
			glCallList(iWaveList);
			glRotatef(45.0f, 1.0f, 0.0f, 0.0f);
			glCallList(iWaveList);
			glRotatef(45.0f, 1.0f, 0.0f, 0.0f);
			glCallList(iWaveList);
			glPopMatrix();
			_AS->iTriangles += 8;
		}

		// Draw the actors shield:
		if((pActorT->bShieldMode || pActorT->Type == AT_SHIELD_ITEM) && pActorT->bOnScreen)
		{		
			glDepthMask(FALSE);
			glDisable(GL_CULL_FACE);
			glEnable(GL_TEXTURE_2D);

			// Get the right vertex for the shield pos:
			fPos2[X] = pActorT->fWorldPos[X];
			fPos2[Y] = pActorT->fWorldPos[Y];
			fPos2[Z] = pActorT->fWorldPos[Z]+0.6f;
			switch(pActorT->Type)
			{
				case AT_BLIBS:
					ASGetMd2Vertex(pBlibsModel, pActorT->iAniStep, pActorT->iNextAniStep, pActorT->fAniInterpolation, fPos2, 0.005f,
								   -90.0f, -pActorT->fRot[Y]-180.0f, 0.0f, 310, &fPos);
				break;

				case AT_LUCIFER:
					fPos[X] = pActorT->fWorldPos[X]+pActorT->fPosTemp[X];
					fPos[Y] = pActorT->fWorldPos[Y]+pActorT->fPosTemp[Y];
					fPos[Z] = pActorT->fWorldPos[Z]+pActorT->fPosTemp[Z]-1.5f;
				break;
				
				default:
					fPos[X] = pActorT->fWorldPos[X];
					fPos[Y] = pActorT->fWorldPos[Y];
					fPos[Z] = pActorT->fWorldPos[Z]-0.5f;
				break;
			}
			glColor4f(0.5f, 1.0f, 0.5f, 0.99f*pActorT->fBlendDensity);
			glPushMatrix();
			glTranslatef(fPos[X], fPos[Y], fPos[Z]);
			if(pActorT->Type == AT_SHIELD_ITEM)
				glScalef(0.65f, 0.6f, 0.6f);
			else
				glScalef(0.85f, 0.85f, 0.85f);
			if(pActorT->Type != AT_LUCIFER)
			{
				for(i = 0; i < 8; i++)
				{
					glPushMatrix();
					glColor4f(0.5f+((float) (i+1)/20.0f), 1.0f, 0.5f, (0.99f-((float) (i+1)/20.0f))*pActorT->fBlendDensity);
					glRotatef(pActorT->fShieldRot[X][i], 1.0f, 0.0f, 0.0f);
					glRotatef(pActorT->fShieldRot[Y][i], 0.0f, 1.0f, 0.0f);
					glRotatef(pActorT->fShieldRot[Z][i], 0.0f, 0.0f, 1.0f);
					glScalef(1.0f+((i+1)/30.0f), 1.0f+((i+1)/30.0f), 1.0f+((i+1)/30.0f));
					glCallList(iShieldList);
					glPopMatrix();
				}
			}
			for(i = 0; i < 8; i++)
			{
				glPushMatrix();
				glColor4f(0.5f+((float) (i+1)/20.0f), 1.0f, 0.5f, (0.5f-((float) (i+1)/60.0f))*pActorT->fBlendDensity);
				glRotatef(pActorT->fShieldRot[X][i], 1.0f, 0.0f, 0.0f);
				glRotatef(pActorT->fShieldRot[Y][i], 0.0f, 1.0f, 0.0f);
				glRotatef(pActorT->fShieldRot[Z][i], 0.0f, 0.0f, 1.0f);
				glScalef(1.001f*((i+1)*100.0f), 1.001f*((i+1)/100.0f), 1.001f*((i+1)/100.0f));
				glCallList(iShieldList);
				glPopMatrix();
			}
			_AS->iTriangles += 32;
			glPopMatrix();
		}
	}
	
	// Draw players transparent weapon:
	if(pPlayer && pPlayer->bWeapon && (pPlayer->Action == AA_PULL_WEAPON ||
	   pPlayer->Action == AA_POUCH_WEAPON))
	{
		glEnable(GL_TEXTURE_2D);
		glPushMatrix();
		glTranslatef(pPlayer->fWorldPos[X], pPlayer->fWorldPos[Y], pPlayer->fWorldPos[Z]);
		glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(90.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-pPlayer->fRot[Y]-180.0f, 0.0f, 1.0f, 0.0f);
		glScalef(0.005f, 0.005f, 0.005f);
		
		if(pPlayer->Action == AA_PULL_WEAPON)
			glColor4f(pPlayer->fColor[0], pPlayer->fColor[1], pPlayer->fColor[2], pPlayer->fAniInterpolation*pPlayer->fBlendDensity);
		else
			glColor4f(pPlayer->fColor[0], pPlayer->fColor[1], pPlayer->fColor[2], (1.0f-pPlayer->fAniInterpolation)*pPlayer->fBlendDensity);
			
		glBindTexture(GL_TEXTURE_2D, GameTexture[19].iOpenGLID);
		ASDrawMd2FrameInt(pBlibsWeaponModel, pPlayer->iAniStep, pPlayer->iNextAniStep,
		                  pPlayer->fAniInterpolation);
		glPopMatrix();
	}

	ASEnableLighting();
	glDepthMask(TRUE);
	glDisable(GL_BLEND);
	glEnable(GL_CULL_FACE);
} // end LEVEL::DrawActorEffects()

void LEVEL::DrawActorText(AS_WINDOW *pWindow)
{ // begin LEVEL::DrawActorText()
	double fModelViewMatrix[16], fProjectionMatrix[16], dWinX, dWinY, dWinZ;
	char byTemp[256];
	ACTOR *pActorT;
	int iViewport[4];
	float fHeight;
	int i;

	SetCameraTranslation(FALSE);
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glGetDoublev(GL_MODELVIEW_MATRIX, fModelViewMatrix);
	glGetDoublev(GL_PROJECTION_MATRIX, fProjectionMatrix);
	iViewport[0] = iViewport[1] = 0;
	iViewport[2] = 640;
	iViewport[3] = 480;

	if(!pActorList)
		return;
	for(i = 0; i < Header.iMaxActors; i++)
	{
		pActorT = pVisibleActors[i];
		if(!pActorT)
			break;
		if(!pActorT->fShowInfoTextBlend)
			continue;
		switch(pActorT->Type)
		{
			case AT_BLIBS: fHeight = 1.4f; break;
			case AT_MOBMOB: fHeight = 1.5f; break;
			
			case AT_X3:
				if(!pActorT->bSmall)
					fHeight = 1.0f;
				else
					fHeight = 0.7f;
			break;

			case AT_LUCIFER: fHeight = 3.2f; break;

			default: fHeight = 1.1f; break;
		}
		glColor4f(1.0f, 1.0f, 1.0f, pActorT->fShowInfoTextBlend);
		gluProject(pActorT->fWorldPos[X], pActorT->fWorldPos[Y], pActorT->fWorldPos[Z]-fHeight, fModelViewMatrix, fProjectionMatrix, iViewport, &dWinX, &dWinY, &dWinZ);
		sprintf(byTemp, "%0.0f/%0.0f", pActorT->fHealth, pActorT->fMaxHealth);
		pWindow->PrintAnimated((int) dWinX, (int) dWinY, byTemp, 0, 1.0f, fFontAni, 1);
	}
} // end LEVEL::DrawActorText()
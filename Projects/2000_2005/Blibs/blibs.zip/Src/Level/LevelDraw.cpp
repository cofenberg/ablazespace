//-----------------------------------------------------------------------------
// File: LevelDraw.cpp
//-----------------------------------------------------------------------------

#include "..\AS\AS_Engine.h"
#include "..\ModuleHeaders.h"


void LEVEL::InitLevelDraw(void)
{ // begin LEVEL::InitLevelDraw()
    GLfloat	fogColor[4] = {Environment.fFogColor[R], Environment.fFogColor[G], Environment.fFogColor[B], 1.0f};
	GLfloat afLightData[4]  = {0.0f, 0.0f, 0.0f, 0.0f};
	int iLightID;
	
 	// Setup the fog in the level:
	if(Environment.bFog)
	{
		glFogfv(GL_FOG_COLOR, fogColor);
		glFogf(GL_FOG_DENSITY, Environment.fFogDensity);
		glFogf(GL_FOG_START, 0.0f);
		glFogf(GL_FOG_END, 10.0f);
		glEnable(GL_FOG);
		glClearColor(Environment.fFogColor[R], Environment.fFogColor[G], Environment.fFogColor[B], 1.0f);
	}
	else
	{
		glDisable(GL_FOG);
		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	}

	if(_ASConfig->byLight)
	{ // Lighting should be used!
		// Setup the levels primary light:
		iLightID = GL_LIGHT0+_AS->iActiveLights;
		afLightData[0] = Header.fWholeWidth/2;
		afLightData[1] = Header.fWholeHeight/2;
		afLightData[3] = -1.0f;
		glLightfv(iLightID, GL_POSITION, afLightData);
		afLightData[0] = Environment.fColor[R];
		afLightData[1] = Environment.fColor[G];
		afLightData[2] = Environment.fColor[B];
		afLightData[3] = 1.0f;
		glLightfv(iLightID, GL_AMBIENT, afLightData);
		glEnable(iLightID);
		_AS->iActiveLights++;

		iLightID = GL_LIGHT0+_AS->iActiveLights;
		afLightData[0] = Header.fWholeWidth/2;
		afLightData[1] = Header.fWholeHeight/2;
		afLightData[3] = -100.0f;
		glLightfv(iLightID, GL_POSITION, afLightData);
		afLightData[0] = Environment.fColor[R];
		afLightData[1] = Environment.fColor[G];
		afLightData[2] = Environment.fColor[B];
		afLightData[3] = 1.0f;
		glLightfv(iLightID, GL_DIFFUSE, afLightData);
		glEnable(iLightID);
		_AS->iActiveLights++;

		SetupAllActorLights(); // Setup the lights of all actors
	}
} // end LEVEL::InitLevelDraw()

void LEVEL::DeInitLevelDraw(void)
{ // begin LEVEL::DeInitLevelDraw()
	GLfloat afLightData[4]  = {0.0f, 0.0f, 0.0f, 0.0f};

	glDisable(GL_FOG);
	afLightData[0] = 0.0f;
	afLightData[1] = 0.0f;
	afLightData[2] = 0.0f;
	afLightData[3] = 1.0f;
	glLightfv(GL_LIGHT1, GL_POSITION, afLightData);
	afLightData[0] = 1.0f;
	afLightData[1] = 1.0f;
	afLightData[2] = 1.0f;
	afLightData[3] = 1.0f;
	glLightfv(GL_LIGHT1, GL_AMBIENT, afLightData);
	glEnable(GL_LIGHT1);
} // end LEVEL::DeInitLevelDraw()

void LEVEL::Draw(BOOL bTempBackground)
{ // begin LEVEL::Draw()
	FIELD_SIDE_SURFACE **pFieldSurfaceTextureT, *pFieldSurfaceT;
	int i, iAniStep = 0, iTexture, iSide;
	FIELD_DECORATION *pDecorationT;
	TEXTURE_POS *pTexturePos;
	FIELD_SIDE *pFieldSideT;
	AS_MD2_MODEL *pModelT;	
	FLOAT3 fRayDirection;
	FIELD *pFieldT;
	BOOL bBlendMode = FALSE;

	if(!pInFOVFields)
		return;

	// Setup OpenGL stuff:
	glColor3f(1.0f, 1.0f, 1.0f);
	glLineWidth(3.0f);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);
	if(!_ASConfig->bUseLevelVertexColor || !_ASConfig->bHightRenderQuality)
		glDisableClientState(GL_COLOR_ARRAY);
	else
	{
		glEnableClientState(GL_COLOR_ARRAY);
		glColorPointer(4, GL_FLOAT, 0, fColor);
	}
	glVertexPointer(3, GL_FLOAT, 0, fPoint);
	if(!_ASConfig->byLight)
		glDisableClientState(GL_NORMAL_ARRAY);
	else
		glEnableClientState(GL_NORMAL_ARRAY);
	glNormalPointer(GL_FLOAT, 0, fNormal);
	if(_AS->bCompiledVertexArraySupported)
		glLockArraysEXT(0, Header.iPoints);
	glEnable(GL_TEXTURE_2D);

	// Draw all solid sides:
	_AS->EnableCullFace(TRUE);
	_AS->SetCullFaceMode(GL_FRONT);	
	glAlphaFunc(GL_GEQUAL, 0.5f);
	for(iTexture = 0; iTexture < Header.iTextures; iTexture++)
	{
		if(pTexture[iTexture].iFormat == GL_RGBA)
			glEnable(GL_ALPHA_TEST);
		else
			glDisable(GL_ALPHA_TEST);
		if(!(pFieldSurfaceTextureT = FieldSideList.pSolid[iTexture]))
			continue; // There's no side using this texture!
		glBindTexture(GL_TEXTURE_2D, pTexture[iTexture].iOpenGLID);
		glBegin(GL_QUADS);
			for(iSide = 0; iSide < Header.iFields*12; iSide++)
			{
				if(!(pFieldSurfaceT = pFieldSurfaceTextureT[iSide]))
					break;
				SetupSideDraw(pFieldSurfaceT);
				pFieldSideT = pFieldSurfaceT->pFieldSide;
				pTexturePos = &pFieldSurfaceT->pSurface->pTexturePos[pFieldSurfaceT->iCurrentAniStep];
				DrawFieldSide(pFieldSurfaceT->iSurfaceRotation, pFieldSideT, pTexturePos, &bBlendMode, FALSE);
			}
		glEnd();
	}
	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);

	if(_AS->bCompiledVertexArraySupported)
		glUnlockArraysEXT();
	glEnable(GL_CULL_FACE);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	glDisable(GL_TEXTURE_2D);	
	glColor3f(1.0f, 1.0f, 1.0f);
	glLineWidth(1.0f);
	glPointSize(5.0f);
	fRayDirection[X] = 0.0f;
	fRayDirection[Y] = 0.0f;
	fRayDirection[Z] = 1.0f;
	glCullFace(GL_FRONT);
	
	// Draw none transparent decoration:
	for(i = 0; ; i++)
	{
		if(!(pFieldT = pDecorationFieldList[i]))
			break;
		if(!(pDecorationT = pFieldT->pDecoration) || !pDecorationT->bOnScreen)
			continue;
		if(pDecorationT->fColor[A] != 1.0f)
			continue;
		if(pLevel->pTexture[pDecorationT->iTexture].iFormat == GL_RGBA)
			glEnable(GL_ALPHA_TEST);
		else
			glDisable(GL_ALPHA_TEST);
		if(!(pModelT = pDecorationModels[pDecorationT->iDecorationID].pModel))
			continue;
		glPushMatrix();
		if(pDecorationT->iTexture == -1)
		{
			glDisable(GL_TEXTURE_2D);
			glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
		}
		else
		{
			glEnable(GL_TEXTURE_2D);
			ASSetFillMode();
			glBindTexture(GL_TEXTURE_2D, pTexture[pDecorationT->iTexture].iOpenGLID);
		}
		if(pDecorationT->bCullFront && pDecorationT->bCullBack)
		{
			glPopMatrix();
			continue;
		}
		else
		if(!pDecorationT->bCullFront && !pDecorationT->bCullBack)
			glDisable(GL_CULL_FACE);
		else
		{
			glEnable(GL_CULL_FACE);
			if(pDecorationT->bCullFront)
				glCullFace(GL_BACK);
			else
				glCullFace(GL_FRONT);
		}
		glTranslatef(pDecorationT->fPos[X], pDecorationT->fPos[Y], pDecorationT->fPos[Z]);
		glRotatef(pDecorationT->fRot[X], 1.0f, 0.0f, 0.0f);
		glRotatef(pDecorationT->fRot[Y], 0.0f, 1.0f, 0.0f);
		glRotatef(pDecorationT->fRot[Z], 0.0f, 0.0f, 1.0f);
		glScalef(pDecorationT->fSize[X], pDecorationT->fSize[Z], pDecorationT->fSize[Y]);
		glColor4fv(pDecorationT->fColor);
		glColor4f(pDecorationT->fColor[R], pDecorationT->fColor[G], pDecorationT->fColor[B], 1.0f);

		
		ASPrecomputeMd2FrameInt(pModelT,
								pDecorationT->iAniStep, pDecorationT->iNextAniStep,
								pDecorationT->fModelInterpolation);
		AS_Md2_GetCurrentBoundingBox(pModelT,
									 pDecorationT->iAniStep, pDecorationT->iNextAniStep,
									 pDecorationT->fModelInterpolation, &pDecorationT->fModelBoundingBox);
		ASDrawPrecomputedMd2Frame(pModelT);

		
		if(_ASConfig->bDrawBounding)
		{
			glColor3f(1.0f, 1.0f, 1.0f);
			ASDrawBoundingBox(pDecorationT->fModelBoundingBox);
		}
		glPopMatrix();
	}

	ASSetFillMode();
	glEnable(GL_CULL_FACE);
	glEnable(GL_TEXTURE_2D);
	glCullFace(GL_BACK);
} // end LEVEL::Draw()

void LEVEL::DrawTransparent(void)
{ // begin LEVEL::DrawTransparent()
	FIELD_DECORATION *pDecorationT;
	FIELD_SIDE_SURFACE **pFieldSurfaceTextureT, *pFieldSurfaceT;
	int iTexture, iSide, iAniStep = 0;
	TEXTURE_POS *pTexturePos;
	FIELD_SIDE *pFieldSideT;
	AS_MD2_MODEL *pModelT;	
	FIELD *pFieldT;

	if(!pInFOVFields)
		return;

	// Draw the transparent stuff:
	glColor4f(1.0f, 1.0f, 1.0f, 0.9f);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);
	if(!_ASConfig->bUseLevelVertexColor || !_ASConfig->bHightRenderQuality)
		glDisableClientState(GL_COLOR_ARRAY);
	else
	{
		glEnableClientState(GL_COLOR_ARRAY);
		glColorPointer(4, GL_FLOAT, 0, fColor);
	}
	glVertexPointer(3, GL_FLOAT, 0, fPoint);
	if(!_ASConfig->byLight)
		glDisableClientState(GL_NORMAL_ARRAY);
	else
	{
		glEnableClientState(GL_NORMAL_ARRAY);
		glNormalPointer(GL_FLOAT, 0, fNormal);
	}
	if(_AS->bCompiledVertexArraySupported)
		glLockArraysEXT(0, Header.iPoints);
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);

	// Draw all transparent first sides:
 	if(Environment.bFog)
		glEnable(GL_FOG);
	glDepthMask(FALSE);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	ASEnableLighting();
	_AS->EnableCullFace(TRUE);
	_AS->SetCullFaceMode(GL_FRONT);
	for(iTexture = 0; iTexture < Header.iTextures; iTexture++)
	{
		if(!(pFieldSurfaceTextureT = FieldSideList.pTransparent[iTexture]))
			continue; // There's no side using this texture!
		if(pTexture[iTexture].iFormat == GL_RGBA)
		{
			glEnable(GL_ALPHA_TEST);
			glAlphaFunc(GL_GEQUAL, 0.0f);
		}
		else
		{
			glDisable(GL_ALPHA_TEST);
			glAlphaFunc(GL_GEQUAL, 1.0f);
		}
		glBindTexture(GL_TEXTURE_2D, pTexture[iTexture].iOpenGLID);
		glBegin(GL_QUADS);
			for(iSide = 0; iSide < Header.iFields*12; iSide++)
			{
				if(!(pFieldSurfaceT = pFieldSurfaceTextureT[iSide]))
					break;
				if(pFieldSurfaceT->bSecondSurface)
					continue;
				SetupSideDraw(pFieldSurfaceT);
				pFieldSideT = pFieldSurfaceT->pFieldSide;
				pTexturePos = &pFieldSurfaceT->pSurface->pTexturePos[pFieldSurfaceT->iCurrentAniStep];
				DrawFieldSide(pFieldSurfaceT->iSurfaceRotation, pFieldSideT, pTexturePos);
			}
		glEnd();
	}
	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);

	// Draw all transparent second sides:
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glDepthFunc(GL_EQUAL);
	if(_AS->bCompiledVertexArraySupported)
		glUnlockArraysEXT();
	glColorPointer(4, GL_FLOAT, 0, fSecondColor);
	if(_AS->bCompiledVertexArraySupported)
		glLockArraysEXT(0, Header.iPoints);
	for(iTexture = 0; iTexture < Header.iTextures; iTexture++)
	{
		if(!(pFieldSurfaceTextureT = FieldSideList.pTransparent[iTexture]))
			continue; // There's no side using this texture!
		if(pTexture[iTexture].iFormat == GL_RGBA)
		{
			glEnable(GL_ALPHA_TEST);
			glAlphaFunc(GL_GEQUAL, 0.0f);
		}
		else
		{
			glDisable(GL_ALPHA_TEST);
			glAlphaFunc(GL_GEQUAL, 1.0f);
		}
		glBindTexture(GL_TEXTURE_2D, pTexture[iTexture].iOpenGLID);
		glBegin(GL_QUADS);
			for(iSide = 0; iSide < Header.iFields*12; iSide++)
			{
				if(!(pFieldSurfaceT = pFieldSurfaceTextureT[iSide]))
					break;
				if(!pFieldSurfaceT->bSecondSurface)
					continue;
				SetupSideDraw(pFieldSurfaceT);
				pFieldSideT = pFieldSurfaceT->pFieldSide;
				pTexturePos = &pFieldSurfaceT->pSurface->pTexturePos[pFieldSurfaceT->iCurrentAniStep];
				DrawFieldSide(pFieldSurfaceT->iSurfaceRotation, pFieldSideT, pTexturePos);
			}
		glEnd();
	}
	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);
	glDepthMask(TRUE);
	_AS->SetNormalDepthFunc();
	if(_AS->bCompiledVertexArraySupported)
		glUnlockArraysEXT();
	glCullFace(GL_FRONT);
	glEnable(GL_CULL_FACE);

	// Draw transparent decoration:
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	for(int i = 0; ; i++)
	{
		if(!(pFieldT = pDecorationFieldList[i]))
			break;
		if(!(pDecorationT = pFieldT->pDecoration) || !pDecorationT->bOnScreen)
			continue;
		if(pDecorationT->fColor[A] == 1.0f)
			continue;
		if(pLevel->pTexture[pDecorationT->iTexture].iFormat == GL_RGBA)
		{
			glEnable(GL_ALPHA_TEST);
			glAlphaFunc(GL_GEQUAL, 0.0f);
		}
		else
		{
			glDisable(GL_ALPHA_TEST);
			glAlphaFunc(GL_GEQUAL, 1.0f);
		}
		if(!(pModelT = pDecorationModels[pDecorationT->iDecorationID].pModel))
			continue;
		glPushMatrix();
		if(pDecorationT->iTexture == -1)
		{
			glDisable(GL_TEXTURE_2D);
			glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
		}
		else
		{
			glEnable(GL_TEXTURE_2D);
			ASSetFillMode();
			glBindTexture(GL_TEXTURE_2D, pTexture[pDecorationT->iTexture].iOpenGLID);
		}
		if(pDecorationT->bCullFront && pDecorationT->bCullBack)
		{
			glPopMatrix();
			continue;
		}
		else
		if(!pDecorationT->bCullFront && !pDecorationT->bCullBack)
			glDisable(GL_CULL_FACE);
		else
		{
			glEnable(GL_CULL_FACE);
			if(pDecorationT->bCullFront)
				glCullFace(GL_BACK);
			else
				glCullFace(GL_FRONT);
		}
		glTranslatef(pDecorationT->fPos[X], pDecorationT->fPos[Y], pDecorationT->fPos[Z]);
		glRotatef(pDecorationT->fRot[X], 1.0f, 0.0f, 0.0f);
		glRotatef(pDecorationT->fRot[Y], 0.0f, 1.0f, 0.0f);
		glRotatef(pDecorationT->fRot[Z], 0.0f, 0.0f, 1.0f);
		glScalef(pDecorationT->fSize[X], pDecorationT->fSize[Z], pDecorationT->fSize[Y]);
		glColor4fv(pDecorationT->fColor);


		ASPrecomputeMd2FrameInt(pModelT,
								pDecorationT->iAniStep, pDecorationT->iNextAniStep,
								pDecorationT->fModelInterpolation);
		AS_Md2_GetCurrentBoundingBox(pModelT,
									 pDecorationT->iAniStep, pDecorationT->iNextAniStep,
									 pDecorationT->fModelInterpolation, &pDecorationT->fModelBoundingBox);
		ASDrawPrecomputedMd2Frame(pModelT);


		if(_ASConfig->bDrawBounding)
		{
			glColor3f(1.0f, 1.0f, 1.0f);
			ASDrawBoundingBox(pDecorationT->fModelBoundingBox);
		}
		glPopMatrix();
	}
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	glDepthMask(TRUE);
	glDisable(GL_ALPHA_TEST);
	glEnable(GL_CULL_FACE);
	glDisable(GL_BLEND);
	glCullFace(GL_BACK);
} // end LEVEL::DrawTransparent()

void LEVEL::DrawWater(void)
{ // begin LEVEL::DrawWater()
	FIELD_SIDE *pFieldSideT;
	TEXTURE_POS *pTexturePos;
	FIELD_SIDE_SURFACE *pFieldSurfaceT;
	int i, iX, iY, iFieldID, iPoint1, iPoint2, iTexture;
	FIELD *pFieldT, *pFieldT2;
	FIELD_SIDE *pSideT;
	BOOL bBlendMode;

	if(!pInFOVFields)
		return;

	if(!bPause || State.bLevelComplete)
	{
		Environment.fWaterVar += 0.005f*g_lDeltatime*Environment.fWaterSpeed;
		Environment.fWaterActualHeight = (float) (sin(Environment.fWaterVar)/50.0f)*Environment.fWaterAmplitude+Environment.fWaterHeight;
	}

 	if(Environment.bFog)
		glEnable(GL_FOG);
	glCullFace(GL_FRONT);

	// Setup vertex array:
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);
	glEnableClientState(GL_VERTEX_ARRAY);
	glVertexPointer(3, GL_FLOAT, 0, fWaterPoint);
	glEnableClientState(GL_COLOR_ARRAY);
	glColorPointer(4, GL_FLOAT, 0, fWaterColor);
	if(!_ASConfig->byLight)
		glDisableClientState(GL_NORMAL_ARRAY);
	else
		glEnableClientState(GL_NORMAL_ARRAY);
	glNormalPointer(GL_FLOAT, 0, fWaterNormal);
	if(_AS->bCompiledVertexArraySupported)
		glLockArraysEXT(0, Header.iLevelPoints);

	// Draw the water:
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_DEPTH_TEST);
	glDepthMask(FALSE);
	glEnable(GL_BLEND);
	glEnable(GL_TEXTURE_2D);
	bBlendMode = TRUE;
	for(iTexture = 0; iTexture < Header.iTextures; iTexture++)
	{
		if(pTexture[iTexture].iFormat == GL_RGBA)
		{
			glEnable(GL_ALPHA_TEST);
			glAlphaFunc(GL_GEQUAL, 0.0f);
		}
		else
		{
			glDisable(GL_ALPHA_TEST);
			glAlphaFunc(GL_GEQUAL, 1.0f);
		}
		glBindTexture(GL_TEXTURE_2D, pTexture[iTexture].iOpenGLID);
		glBegin(GL_QUADS);
			for(i = 0; i < Header.iFields; i++)
			{
				pFieldT = pInFOVFields[i];
				if(!pFieldT)
					break;
				if(!pFieldT->bActivateWater)
					continue;

				// Draw the water quads:
				pFieldSideT = &pFieldT->Side[FACE_WATER];
				pFieldSurfaceT = &pFieldSideT->Surface[0];
				SetupSideDraw(pFieldSurfaceT);
				if(pFieldSurfaceT->pSurface->iTextureID[pFieldSurfaceT->iCurrentAniStep] == iTexture)
				{
					pTexturePos = &pFieldSurfaceT->pSurface->pTexturePos[pFieldSurfaceT->iCurrentAniStep];
					DrawFieldSide(pFieldSurfaceT->iSurfaceRotation, pFieldSideT, pTexturePos, &bBlendMode, TRUE);
				}
			}
		glEnd();
	}
	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);

	glDisable(GL_TEXTURE_2D);
	glDepthMask(FALSE);
	glEnable(GL_BLEND);
	bBlendMode = TRUE;
	// Draw the water sides if an field isn't active:
	glBegin(GL_QUADS);			
		for(i = 0; i < Header.iFields; i++)
		{
			pFieldT = pInFOVFields[i];
			if(!pFieldT)
				break;
			if(!pFieldT->bActivateWater)
				continue; // There isn't water on this field:
			// Check/draw the water sides:				
			// Left:
			iX = pFieldT->iXField-1;
			iY = pFieldT->iYField;
			if(iX >= -1 && iY >= 0 && iX < Header.iWidth && iY < Header.iHeight-1)
			{ // Correct field:
				if(iX >= 0)
				{
					GET_FIELD_ID(iX, iY, iFieldID);
					pFieldT2 = &pField[iFieldID];
				}
				else
					pFieldT2 = NULL;
				if((!pFieldT2 || (!pFieldT2->bActivateWater && pFieldT2->bOnScreen)) && 
				   !pFieldT->Side[FACE_LEFT].bDisableWaterSide)
				{ // Theres no water on this field, and therefore we have to draw an water side:
					pSideT = &pFieldT->Side[FACE_LEFT];
					iPoint1 = pSideT->SideQuad[3].iPoint[2];
					iPoint2 = pSideT->SideQuad[3].iPoint[3];
					SetQuadBlend(&pSideT->SideQuad[3], &bBlendMode, TRUE);
					glColor4f(fWaterColor[iPoint1][R], fWaterColor[iPoint1][G], fWaterColor[iPoint1][B], fWaterColor[iPoint1][A]);
					glVertex3f(fWaterPoint[iPoint1][X], fWaterPoint[iPoint1][Y], fLowestPoint);
					glColor4f(fWaterColor[iPoint2][R], fWaterColor[iPoint2][G], fWaterColor[iPoint2][B], fWaterColor[iPoint1][A]);
					glVertex3f(fWaterPoint[iPoint2][X], fWaterPoint[iPoint2][Y], fLowestPoint);
					glArrayElement(iPoint2);
					glArrayElement(iPoint1);
					iPoint1 = pSideT->SideQuad[2].iPoint[2];
					iPoint2 = pSideT->SideQuad[2].iPoint[3];
					SetQuadBlend(&pSideT->SideQuad[2], &bBlendMode, TRUE);
					glColor4f(fWaterColor[iPoint1][R], fWaterColor[iPoint1][G], fWaterColor[iPoint1][B], fWaterColor[iPoint1][A]);
					glVertex3f(fWaterPoint[iPoint1][X], fWaterPoint[iPoint1][Y], fLowestPoint);
					glColor4f(fWaterColor[iPoint2][R], fWaterColor[iPoint2][G], fWaterColor[iPoint2][B], fWaterColor[iPoint2][A]);
					glVertex3f(fWaterPoint[iPoint2][X], fWaterPoint[iPoint2][Y], fLowestPoint);
					glArrayElement(iPoint2);
					glArrayElement(iPoint1);
					_AS->iTriangles += 4;
				}
			}
			// Top:
			iX = pFieldT->iXField;
			iY = pFieldT->iYField-1;
			if(iX >= 0 && iY >= -1 && iX < Header.iWidth-1 && iY < Header.iHeight)
			{ // Correct field:
				if(iY >= 0)
				{
					GET_FIELD_ID(iX, iY, iFieldID);
					pFieldT2 = &pField[iFieldID];
				}
				else
					pFieldT2 = NULL;
				if((!pFieldT2 || (!pFieldT2->bActivateWater && pFieldT2->bOnScreen)) &&
					!pFieldT->Side[FACE_TOP].bDisableWaterSide)
				{ // Theres no water on this field, and therefore we have to draw an water side:
					pSideT = &pFieldT->Side[FACE_TOP];
					iPoint1 = pSideT->SideQuad[3].iPoint[2];
					iPoint2 = pSideT->SideQuad[3].iPoint[3];
					SetQuadBlend(&pSideT->SideQuad[3], &bBlendMode, TRUE);
					glColor4f(fWaterColor[iPoint1][R], fWaterColor[iPoint1][G], fWaterColor[iPoint1][B], fWaterColor[iPoint2][A]);
					glVertex3f(fWaterPoint[iPoint1][X], fWaterPoint[iPoint1][Y], fLowestPoint);
					glColor4f(fWaterColor[iPoint2][R], fWaterColor[iPoint2][G], fWaterColor[iPoint2][B], fWaterColor[iPoint2][A]);
					glVertex3f(fWaterPoint[iPoint2][X], fWaterPoint[iPoint2][Y], fLowestPoint);
					glArrayElement(iPoint2);
					glArrayElement(iPoint1);
					iPoint1 = pSideT->SideQuad[2].iPoint[2];
					iPoint2 = pSideT->SideQuad[2].iPoint[3];
					SetQuadBlend(&pSideT->SideQuad[2], &bBlendMode, TRUE);
					glColor4f(fWaterColor[iPoint1][R], fWaterColor[iPoint1][G], fWaterColor[iPoint1][B], fWaterColor[iPoint1][A]);
					glVertex3f(fWaterPoint[iPoint1][X], fWaterPoint[iPoint1][Y], fLowestPoint);
					glColor4f(fWaterColor[iPoint2][R], fWaterColor[iPoint2][G], fWaterColor[iPoint2][B], fWaterColor[iPoint2][A]);
					glVertex3f(fWaterPoint[iPoint2][X], fWaterPoint[iPoint2][Y], fLowestPoint);
					glArrayElement(iPoint2);
					glArrayElement(iPoint1);
					_AS->iTriangles += 4;
				}
			}
			// Right:
			iX = pFieldT->iXField+1;
			iY = pFieldT->iYField;
			if(iX >= 0 && iY >= 0 && iX < Header.iWidth && iY < Header.iHeight-1)
			{ // Correct field:
				if(iX < Header.iWidth-1)
				{
					GET_FIELD_ID(iX, iY, iFieldID);
					pFieldT2 = &pField[iFieldID];
				}
				else
					pFieldT2 = NULL;
				if((!pFieldT2 || (!pFieldT2->bActivateWater && pFieldT2->bOnScreen)) &&
				   !pFieldT->Side[FACE_RIGHT].bDisableWaterSide)
				{ // Theres no water on this field, and therefore we have to draw an water side:
					pSideT = &pFieldT->Side[FACE_RIGHT];
					iPoint1 = pSideT->SideQuad[3].iPoint[2];
					iPoint2 = pSideT->SideQuad[3].iPoint[3];
					SetQuadBlend(&pSideT->SideQuad[3], &bBlendMode, TRUE);
					glColor4f(fWaterColor[iPoint1][R], fWaterColor[iPoint1][G], fWaterColor[iPoint1][B], fWaterColor[iPoint1][A]);
					glVertex3f(fWaterPoint[iPoint1][X], fWaterPoint[iPoint1][Y], fLowestPoint);
					glColor4f(fWaterColor[iPoint2][R], fWaterColor[iPoint2][G], fWaterColor[iPoint2][B], fWaterColor[iPoint2][A]);
					glVertex3f(fWaterPoint[iPoint2][X], fWaterPoint[iPoint2][Y], fLowestPoint);
					glArrayElement(iPoint2);
					glArrayElement(iPoint1);
					iPoint1 = pSideT->SideQuad[2].iPoint[2];
					iPoint2 = pSideT->SideQuad[2].iPoint[3];
					SetQuadBlend(&pSideT->SideQuad[2], &bBlendMode, TRUE);
					glColor4f(fWaterColor[iPoint1][R], fWaterColor[iPoint1][G], fWaterColor[iPoint1][B], fWaterColor[iPoint1][A]);
					glVertex3f(fWaterPoint[iPoint1][X], fWaterPoint[iPoint1][Y], fLowestPoint);
					glColor4f(fWaterColor[iPoint2][R], fWaterColor[iPoint2][G], fWaterColor[iPoint2][B], fWaterColor[iPoint2][A]);
					glVertex3f(fWaterPoint[iPoint2][X], fWaterPoint[iPoint2][Y], fLowestPoint);
					glArrayElement(iPoint2);
					glArrayElement(iPoint1);
					_AS->iTriangles += 4;
				}
			}
			// Bottom:
			iX = pFieldT->iXField;
			iY = pFieldT->iYField+1;
			if(iX >= 0 && iY >= 0 && iX < Header.iWidth-1 && iY < Header.iHeight)
			{ // Correct field:
				if(iY < Header.iHeight-1)
				{
					GET_FIELD_ID(iX, iY, iFieldID);
					pFieldT2 = &pField[iFieldID];
				}
				else
					pFieldT2 = NULL;
				if((!pFieldT2 || (!pFieldT2->bActivateWater && pFieldT2->bOnScreen)) &&
	               !pFieldT->Side[FACE_BOTTOM].bDisableWaterSide)
				{ // Theres no water on this field, and therefore we have to draw an water side:
					pSideT = &pFieldT->Side[FACE_BOTTOM];
					iPoint1 = pSideT->SideQuad[3].iPoint[2];
					iPoint2 = pSideT->SideQuad[3].iPoint[3];
					SetQuadBlend(&pSideT->SideQuad[3], &bBlendMode, TRUE);
					glColor4f(fWaterColor[iPoint1][R], fWaterColor[iPoint1][G], fWaterColor[iPoint1][B], fWaterColor[iPoint1][A]);
					glVertex3f(fWaterPoint[iPoint1][X], fWaterPoint[iPoint1][Y], fLowestPoint);
					glColor4f(fWaterColor[iPoint2][R], fWaterColor[iPoint2][G], fWaterColor[iPoint2][B], fWaterColor[iPoint2][A]);
					glVertex3f(fWaterPoint[iPoint2][X], fWaterPoint[iPoint2][Y], fLowestPoint);
					glArrayElement(iPoint2);
					glArrayElement(iPoint1);
					iPoint1 = pSideT->SideQuad[2].iPoint[2];
					iPoint2 = pSideT->SideQuad[2].iPoint[3];
					SetQuadBlend(&pSideT->SideQuad[2], &bBlendMode, TRUE);
					glColor4f(fWaterColor[iPoint1][R], fWaterColor[iPoint1][G], fWaterColor[iPoint1][B], fWaterColor[iPoint1][A]);
					glVertex3f(fWaterPoint[iPoint1][X], fWaterPoint[iPoint1][Y], fLowestPoint);
					glColor4f(fWaterColor[iPoint2][R], fWaterColor[iPoint2][G], fWaterColor[iPoint2][B], fWaterColor[iPoint2][A]);
					glVertex3f(fWaterPoint[iPoint2][X], fWaterPoint[iPoint2][Y], fLowestPoint);
					glArrayElement(iPoint2);
					glArrayElement(iPoint1);
					_AS->iTriangles += 4;
				}
			}
		}
	glEnd();
	glEnable(GL_CULL_FACE);

	// Draw the second water surface:
	if(_AS->bCompiledVertexArraySupported)
		glUnlockArraysEXT();
	glColorPointer(4, GL_FLOAT, 0, fWaterSecondColor);
	if(_AS->bCompiledVertexArraySupported)
		glLockArraysEXT(0, Header.iLevelPoints);
	glDepthMask(FALSE);
	glDepthFunc(GL_EQUAL);
	glEnable(GL_BLEND);
	glEnable(GL_TEXTURE_2D);
	for(iTexture = 0; iTexture < Header.iTextures; iTexture++)
	{
		if(pTexture[iTexture].iFormat == GL_RGBA)
		{
			glEnable(GL_ALPHA_TEST);
			glAlphaFunc(GL_GEQUAL, 0.0f);
		}
		else
		{
			glDisable(GL_ALPHA_TEST);
			glAlphaFunc(GL_GEQUAL, 1.0f);
		}
		glBindTexture(GL_TEXTURE_2D, pTexture[iTexture].iOpenGLID);
		glBegin(GL_QUADS);
			for(i = 0; i < Header.iFields; i++)
			{
				pFieldT = pInFOVFields[i];
				if(!pFieldT)
					break;
				if(!pFieldT->bActive || !pFieldT->bActivateWater)
					continue;

				// Draw the water quads:
				pFieldSideT = &pFieldT->Side[FACE_WATER];
				pFieldSurfaceT = &pFieldSideT->Surface[1];
				if(!pFieldSurfaceT->pSurface)
					continue;
				SetupSideDraw(pFieldSurfaceT);
				if(pFieldSurfaceT->pSurface->iTextureID[pFieldSurfaceT->iCurrentAniStep] == iTexture)
				{
					pTexturePos = &pFieldSurfaceT->pSurface->pTexturePos[pFieldSurfaceT->iCurrentAniStep];
					DrawFieldSide(pFieldSurfaceT->iSurfaceRotation, pFieldSideT, pTexturePos);
				}
			}
		glEnd();
	}
	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);
	_AS->SetNormalDepthFunc();
	glDepthMask(TRUE);
	glCullFace(GL_BACK);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	if(_AS->bCompiledVertexArraySupported)
		glUnlockArraysEXT();
} // end LEVEL::DrawWater()

// Draws an field side:
void LEVEL::DrawFieldSide(int iRot, FIELD_SIDE *pFieldSideT, TEXTURE_POS *pTexturePos)
{ // begin LEVEL::DrawFieldSide()
	FIELD_SIDE_QUAD *pFieldSideQuadT;

	switch(iRot)
	{
		case 0: // 0
			// Quad 0:
			pFieldSideQuadT = &pFieldSideT->SideQuad[0];
			glTexCoord2fv(pTexturePos->fPos[0]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[1]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[7]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);

			// Quad 1:
			pFieldSideQuadT = &pFieldSideT->SideQuad[1];
			glTexCoord2fv(pTexturePos->fPos[1]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[2]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[3]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);

			// Quad 2:
			pFieldSideQuadT = &pFieldSideT->SideQuad[2];
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[3]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[4]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[5]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);
			
			// Quad 3:
			pFieldSideQuadT = &pFieldSideT->SideQuad[3];
			glTexCoord2fv(pTexturePos->fPos[7]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[5]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[6]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);
		break;

		case 1: // 90
			// Quad 0:
			pFieldSideQuadT = &pFieldSideT->SideQuad[0];
			glTexCoord2fv(pTexturePos->fPos[6]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[7]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[5]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);

			// Quad 1:
			pFieldSideQuadT = &pFieldSideT->SideQuad[1];
			glTexCoord2fv(pTexturePos->fPos[7]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[0]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[1]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);

			// Quad 2:
			pFieldSideQuadT = &pFieldSideT->SideQuad[2];
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[1]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[2]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[3]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);
			
			// Quad 3:
			pFieldSideQuadT = &pFieldSideT->SideQuad[3];
			glTexCoord2fv(pTexturePos->fPos[5]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[3]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[4]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);
		break;

		case 2: // 180
			// Quad 0:
			pFieldSideQuadT = &pFieldSideT->SideQuad[0];
			glTexCoord2fv(pTexturePos->fPos[4]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[5]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[3]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);

			// Quad 1:
			pFieldSideQuadT = &pFieldSideT->SideQuad[1];
			glTexCoord2fv(pTexturePos->fPos[5]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[6]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[7]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);

			// Quad 2:
			pFieldSideQuadT = &pFieldSideT->SideQuad[2];
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[7]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[0]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[1]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);
			
			// Quad 3:
			pFieldSideQuadT = &pFieldSideT->SideQuad[3];
			glTexCoord2fv(pTexturePos->fPos[3]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[1]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[2]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);
		break;

		case 3: // 270
			// Quad 0:
			pFieldSideQuadT = &pFieldSideT->SideQuad[0];
			glTexCoord2fv(pTexturePos->fPos[2]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[3]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[1]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);

			// Quad 1:
			pFieldSideQuadT = &pFieldSideT->SideQuad[1];
			glTexCoord2fv(pTexturePos->fPos[3]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[4]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[5]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);

			// Quad 2:
			pFieldSideQuadT = &pFieldSideT->SideQuad[2];
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[5]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[6]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[7]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);
			
			// Quad 3:
			pFieldSideQuadT = &pFieldSideT->SideQuad[3];
			glTexCoord2fv(pTexturePos->fPos[1]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[7]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[0]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);
		break;
	}
	_AS->iTriangles += 8;
} // end LEVEL::DrawFieldSide()

// Draws an field side and also checks if it should be blended:
void LEVEL::DrawFieldSide(int iRot, FIELD_SIDE *pFieldSideT, TEXTURE_POS *pTexturePos, BOOL *bBlendMode, BOOL bWater)
{ // begin LEVEL::DrawFieldSide()
	FIELD_SIDE_QUAD *pFieldSideQuadT;

	switch(iRot)
	{
		case 0: // 0
			// Quad 0:
			pFieldSideQuadT = &pFieldSideT->SideQuad[0];
			SetQuadBlend(pFieldSideQuadT, bBlendMode, bWater);
			glTexCoord2fv(pTexturePos->fPos[0]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[1]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[7]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);

			// Quad 1:
			pFieldSideQuadT = &pFieldSideT->SideQuad[1];
			SetQuadBlend(pFieldSideQuadT, bBlendMode, bWater);
			glTexCoord2fv(pTexturePos->fPos[1]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[2]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[3]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);

			// Quad 2:
			pFieldSideQuadT = &pFieldSideT->SideQuad[2];
			SetQuadBlend(pFieldSideQuadT, bBlendMode, bWater);
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[3]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[4]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[5]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);
			
			// Quad 3:
			pFieldSideQuadT = &pFieldSideT->SideQuad[3];
			SetQuadBlend(pFieldSideQuadT, bBlendMode, bWater);
			glTexCoord2fv(pTexturePos->fPos[7]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[5]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[6]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);
		break;

		case 1: // 90
			// Quad 0:
			pFieldSideQuadT = &pFieldSideT->SideQuad[0];
			SetQuadBlend(pFieldSideQuadT, bBlendMode, bWater);
			glTexCoord2fv(pTexturePos->fPos[6]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[7]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[5]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);

			// Quad 1:
			pFieldSideQuadT = &pFieldSideT->SideQuad[1];
			SetQuadBlend(pFieldSideQuadT, bBlendMode, bWater);
			glTexCoord2fv(pTexturePos->fPos[7]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[0]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[1]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);

			// Quad 2:
			pFieldSideQuadT = &pFieldSideT->SideQuad[2];
			SetQuadBlend(pFieldSideQuadT, bBlendMode, bWater);
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[1]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[2]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[3]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);
			
			// Quad 3:
			pFieldSideQuadT = &pFieldSideT->SideQuad[3];
			SetQuadBlend(pFieldSideQuadT, bBlendMode, bWater);
			glTexCoord2fv(pTexturePos->fPos[5]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[3]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[4]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);
		break;

		case 2: // 180
			// Quad 0:
			pFieldSideQuadT = &pFieldSideT->SideQuad[0];
			SetQuadBlend(pFieldSideQuadT, bBlendMode, bWater);
			glTexCoord2fv(pTexturePos->fPos[4]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[5]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[3]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);

			// Quad 1:
			pFieldSideQuadT = &pFieldSideT->SideQuad[1];
			SetQuadBlend(pFieldSideQuadT, bBlendMode, bWater);
			glTexCoord2fv(pTexturePos->fPos[5]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[6]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[7]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);

			// Quad 2:
			pFieldSideQuadT = &pFieldSideT->SideQuad[2];
			SetQuadBlend(pFieldSideQuadT, bBlendMode, bWater);
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[7]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[0]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[1]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);
			
			// Quad 3:
			pFieldSideQuadT = &pFieldSideT->SideQuad[3];
			SetQuadBlend(pFieldSideQuadT, bBlendMode, bWater);
			glTexCoord2fv(pTexturePos->fPos[3]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[1]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[2]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);
		break;

		case 3: // 270
			// Quad 0:
			pFieldSideQuadT = &pFieldSideT->SideQuad[0];
			SetQuadBlend(pFieldSideQuadT, bBlendMode, bWater);
			glTexCoord2fv(pTexturePos->fPos[2]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[3]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[1]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);

			// Quad 1:
			pFieldSideQuadT = &pFieldSideT->SideQuad[1];
			SetQuadBlend(pFieldSideQuadT, bBlendMode, bWater);
			glTexCoord2fv(pTexturePos->fPos[3]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[4]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[5]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);

			// Quad 2:
			pFieldSideQuadT = &pFieldSideT->SideQuad[2];
			SetQuadBlend(pFieldSideQuadT, bBlendMode, bWater);
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[5]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[6]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[7]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);
			
			// Quad 3:
			pFieldSideQuadT = &pFieldSideT->SideQuad[3];
			SetQuadBlend(pFieldSideQuadT, bBlendMode, bWater);
			glTexCoord2fv(pTexturePos->fPos[1]);
			glArrayElement(pFieldSideQuadT->iPoint[0]);
			glTexCoord2fv(pTexturePos->fPos[8]);
			glArrayElement(pFieldSideQuadT->iPoint[1]);
			glTexCoord2fv(pTexturePos->fPos[7]);
			glArrayElement(pFieldSideQuadT->iPoint[2]);
			glTexCoord2fv(pTexturePos->fPos[0]);
			glArrayElement(pFieldSideQuadT->iPoint[3]);
		break;
	}
	_AS->iTriangles += 8;
} // end LEVEL::DrawFieldSide()

void LEVEL::SetQuadBlend(FIELD_SIDE_QUAD *pFieldSideQuadT, BOOL *bBlendMode, BOOL bWater)
{ // begin LEVEL::SetQuadBlend()
	BOOL bActivateBlendMode = FALSE;
	
	// Check, if the blending should be deactivated:
	if(bWater)
	{
		for(int i = 0; i < 4; i++)
		{
			
			if(pFieldSideQuadT->iPoint[i] < Header.iLevelPoints &&
			   fWaterColor[pFieldSideQuadT->iPoint[i]][A] != 1.0f)
			{
				bActivateBlendMode = TRUE;
				break;
			}
		}
	}
	else
	{
		for(int i = 0; i < 4; i++)
		{
			
			if(fColor[pFieldSideQuadT->iPoint[i]][A] != 1.0f)
			{
				bActivateBlendMode = TRUE;
				break;
			}
		}
	}
	if(bActivateBlendMode)
	{
		if(!*bBlendMode)
		{
			glEnd();
			glDepthMask(FALSE);
			glEnable(GL_BLEND);
			*bBlendMode = TRUE;
			glBegin(GL_QUADS);
		}
	}
	else
	{
		if(*bBlendMode)
		{
			glEnd();
			glDisable(GL_BLEND);
			glDepthMask(TRUE);
			*bBlendMode = FALSE;
			glBegin(GL_QUADS);
		}
	}
} // end LEVEL::SetQuadBlend()

void LEVEL::SetupSideDraw(FIELD_SIDE_SURFACE *pSideSurfaceT)
{ // begin LEVEL::SetupSideDraw()
	FIELD_SIDE *pFieldSideT = pSideSurfaceT->pFieldSide;
	SURFACE *pSurfaceT = pSideSurfaceT->pSurface;
	BOOL bRestart = FALSE;

	if((pFieldSideT->bFaceSwapSides && _AS->iCullFaceMode == GL_FRONT) || 
	   (!pFieldSideT->bFaceSwapSides && _AS->iCullFaceMode == GL_BACK) ||
	   (pFieldSideT->bFace2Sides && _AS->bCullFace) ||
	   (!pFieldSideT->bFace2Sides && !_AS->bCullFace) ||
	   (pSurfaceT->Header.bEnvironmentMappingS != _AS->bEnvironmentMappingS) ||
	   (pSurfaceT->Header.bEnvironmentMappingT != _AS->bEnvironmentMappingT))
		bRestart = TRUE;
	if(bRestart)
	{
		glEnd();
		_AS->EnableCullFace(!pFieldSideT->bFace2Sides);
		if(pFieldSideT->bFaceSwapSides)
			_AS->SetCullFaceMode(GL_BACK);
		else
			_AS->SetCullFaceMode(GL_FRONT);
		if(pSurfaceT &&
		   (pSurfaceT->Header.bEnvironmentMappingS != _AS->bEnvironmentMappingS) ||
		   (pSurfaceT->Header.bEnvironmentMappingT != _AS->bEnvironmentMappingT))
		{
			_AS->EnableEnvironmentMappingS(pSurfaceT->Header.bEnvironmentMappingS);
			_AS->EnableEnvironmentMappingT(pSurfaceT->Header.bEnvironmentMappingT);
		}
		glBegin(GL_QUADS);
	}
} // end LEVEL::SetupSideDraw()

void LEVEL::SetupSideDraw2(FIELD_SIDE_SURFACE *pSideSurfaceT)
{ // begin LEVEL::SetupSideDraw()
	FIELD_SIDE *pFieldSideT = pSideSurfaceT->pFieldSide;
	SURFACE *pSurfaceT = pSideSurfaceT->pSurface;
	BOOL bRestart = FALSE;

	if((pFieldSideT->bFaceSwapSides && _AS->iCullFaceMode == GL_FRONT) || 
	   (!pFieldSideT->bFaceSwapSides && _AS->iCullFaceMode == GL_BACK) ||
	   (pFieldSideT->bFace2Sides && _AS->bCullFace) ||
	   (!pFieldSideT->bFace2Sides && !_AS->bCullFace) ||
	   (pSurfaceT->Header.bEnvironmentMappingS != _AS->bEnvironmentMappingS) ||
	   (pSurfaceT->Header.bEnvironmentMappingT != _AS->bEnvironmentMappingT))
		bRestart = TRUE;
	if(bRestart)
	{
		glEnd();
		_AS->EnableCullFace(!pFieldSideT->bFace2Sides);
		if(pFieldSideT->bFaceSwapSides)
			_AS->SetCullFaceMode(GL_BACK);
		else
			_AS->SetCullFaceMode(GL_FRONT);
		if(pSurfaceT &&
		   (pSurfaceT->Header.bEnvironmentMappingS != _AS->bEnvironmentMappingS) ||
		   (pSurfaceT->Header.bEnvironmentMappingT != _AS->bEnvironmentMappingT))
		{
			_AS->EnableEnvironmentMappingS(pSurfaceT->Header.bEnvironmentMappingS);
			_AS->EnableEnvironmentMappingT(pSurfaceT->Header.bEnvironmentMappingT);
		}
		glBegin(GL_TRIANGLES);
	}
} // end LEVEL::SetupSideDraw2()

void LEVEL::DrawSkyCube(void)
{ // begin LEVEL::DrawSkyCube();
	TEXTURE_POS *pTexturePos;
	SURFACE *pSurfaceT;
	int i;

	if(!Environment.bSkyCube)
		return;

	SetPerspective(1.0f);
	// Animate the sky cube:
	for(i = 0; i < 6; i++)
	{
		if(Environment.iSkyCubeSurface[i] >= Header.iSurfaces)
			Environment.iSkyCubeSurface[i] = 0;
		if(ASCheckTimeUpdate(&Environment.dwSkyCubeSurfaceLastTime[i],
		   pSurface[Environment.iSkyCubeSurface[i]].pTexturePos[Environment.iSkyCubeSurfaceAniStep[i]].iTimeToNext))
		{ // It's time for a animation frame update:
			Environment.iSkyCubeSurfaceAniStep[i]++;
		}
	    // Go sure that the animation step is a correct one:
		if(Environment.iSkyCubeSurfaceAniStep[i] >= pSurface[Environment.iSkyCubeSurface[i]].Header.iAniSteps)
			Environment.iSkyCubeSurfaceAniStep[i] = 0;
	}

	// Draw the sky cube:
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_LIGHTING);
	glDisable(GL_CULL_FACE);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);
	glDisable(GL_FOG);
	glColor3fv(Environment.fSkyCubeColor);

	glDisableClientState(GL_TEXTURE_COORD_ARRAY);
	glDisableClientState(GL_COLOR_ARRAY);
	glDisableClientState(GL_NORMAL_ARRAY);

	FLOAT3 fSkyPoints[8] = 
	{
		{-1.0f, -1.0f, -1.0f}, // 0
		{1.0f, -1.0f, -1.0f}, // 1
		{1.0f, 1.0f, -1.0f}, // 2
		{-1.0f, 1.0f, -1.0f}, // 3
		{-1.0f, -1.0f, 1.0f}, // 4
		{1.0f, -1.0f, 1.0f}, // 5
		{1.0f, 1.0f, 1.0f}, // 6
		{-1.0f, 1.0f, 1.0f}, // 7
	};
	glVertexPointer(3, GL_FLOAT, 0, fSkyPoints);

	glScalef(Environment.fSkyCubeSize[0], Environment.fSkyCubeSize[1], Environment.fSkyCubeSize[2]);
	glScalef(0.01f, 0.01f, 0.01f);
	ASSetFillMode();
	
	// Floor face
	for(i = FACE_FLOOR; i < FACE_FRONT+1; i++)
	{
		glBindTexture(GL_TEXTURE_2D, pSurface[Environment.iSkyCubeSurface[i]].pTexture[Environment.iSkyCubeSurfaceAniStep[i]]->iOpenGLID);
		pSurfaceT = &pSurface[Environment.iSkyCubeSurface[i]];
		pTexturePos = &pSurfaceT->pTexturePos[Environment.iSkyCubeSurfaceAniStep[i]];
		if(pSurfaceT->Header.bEnvironmentMappingS)
			glEnable(GL_TEXTURE_GEN_S);
		else
			glDisable(GL_TEXTURE_GEN_S);
		if(pSurfaceT->Header.bEnvironmentMappingT)
			glEnable(GL_TEXTURE_GEN_T);
		else
			glDisable(GL_TEXTURE_GEN_T);
		glBegin(GL_QUADS);
			switch(i)
			{
				case FACE_FLOOR: DrawSkyCubeSide(5, 4, 7, 6, (Environment.iSkyCubeSurfaceRotation[i]+2) % 4, pTexturePos); break;
				case FACE_TOP: DrawSkyCubeSide(1, 0, 4, 5, (Environment.iSkyCubeSurfaceRotation[i]+2) % 4, pTexturePos); break;
				case FACE_LEFT: DrawSkyCubeSide(4, 0, 3, 7, (Environment.iSkyCubeSurfaceRotation[i]+1) % 4, pTexturePos); break;
				case FACE_RIGHT: DrawSkyCubeSide(2, 1, 5, 6, (Environment.iSkyCubeSurfaceRotation[i]+2) % 4, pTexturePos); break;
				case FACE_BOTTOM: DrawSkyCubeSide(7, 3, 2, 6, (Environment.iSkyCubeSurfaceRotation[i]+1) % 4, pTexturePos); break;
				case FACE_FRONT: DrawSkyCubeSide(3, 0, 1, 2, (Environment.iSkyCubeSurfaceRotation[i]+2) % 4, pTexturePos); break;
			}
		glEnd();
	}
	glEnable(GL_CULL_FACE);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_FOG);
	ASEnableLighting();
} // end LEVEL::DrawSkyCube()

void LEVEL::DrawSkyCubeSide(int iV1, int iV2, int iV3, int iV4, int iRot, TEXTURE_POS *pTexturePosT)
{ // begin LEVEL::DrawSkyCubeSide()
	switch(iRot)
	{
		case 0: // 0
			glTexCoord2fv(pTexturePosT->fPos[6]); glArrayElement(iV1);
			glTexCoord2fv(pTexturePosT->fPos[4]); glArrayElement(iV2);
			glTexCoord2fv(pTexturePosT->fPos[2]); glArrayElement(iV3);
			glTexCoord2fv(pTexturePosT->fPos[0]); glArrayElement(iV4);
			_AS->iTriangles += 2;
		break;

		case 1: // 90
			glTexCoord2fv(pTexturePosT->fPos[4]); glArrayElement(iV1);
			glTexCoord2fv(pTexturePosT->fPos[2]); glArrayElement(iV2);
			glTexCoord2fv(pTexturePosT->fPos[0]); glArrayElement(iV3);
			glTexCoord2fv(pTexturePosT->fPos[6]); glArrayElement(iV4);
			_AS->iTriangles += 2;
		break;

		case 2: // 180
			glTexCoord2fv(pTexturePosT->fPos[2]); glArrayElement(iV1);
			glTexCoord2fv(pTexturePosT->fPos[0]); glArrayElement(iV2);
			glTexCoord2fv(pTexturePosT->fPos[6]); glArrayElement(iV3);
			glTexCoord2fv(pTexturePosT->fPos[4]); glArrayElement(iV4);
			_AS->iTriangles += 2;
		break;

		case 3: // 270
			glTexCoord2fv(pTexturePosT->fPos[0]); glArrayElement(iV1);
			glTexCoord2fv(pTexturePosT->fPos[6]); glArrayElement(iV2);
			glTexCoord2fv(pTexturePosT->fPos[4]); glArrayElement(iV3);
			glTexCoord2fv(pTexturePosT->fPos[2]); glArrayElement(iV4);
			_AS->iTriangles += 2;
		break;
	}
} // end LEVEL::DrawSkyCubeSide()

void LEVEL::DrawOther(BOOL bTempBackground)
{ // begin LEVEL::DrawOther()
	FIELD_SIDE *pFieldSideT;
	int i, iSurface, iField, iSide, iPoint, iFace;
	BOOL bTextScript;
	FLOAT3 *fPosT;
	FIELD *pFieldT;
	HWND hWndT;

	hWndT = hWndEditorTab[TAB_EDITOR_SURFACES];
	BOOL bCheckSurfaceAlwaysActive = SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_ALWAYS_ACTIVE, BM_GETCHECK, 0, 0L),
		 bCheckSurface2Sides = SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_2_SIDES, BM_GETCHECK, 0, 0L),
		 bCheckSurfaceSwapSides = SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_SWAP_SIDES, BM_GETCHECK, 0, 0L),
		 bCheckSurfaceDisableWaterSide = SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_DISABLE_WATER_SIDE, BM_GETCHECK, 0, 0L),
		 bCheckSurfaceWallSide = SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_WALL_SIDE, BM_GETCHECK, 0, 0L),
		 bCheckSurfaceInvisible = SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_INVISIBLE, BM_GETCHECK, 0, 0L);

	ASSetFillMode();
	glLineWidth(4.0f);
	glPointSize(10.0f);
	glDisable(GL_LIGHTING);
	Quadtree.ShowBoundingBox();
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_FOG);
	glDisable(GL_BLEND);
	glDisable(GL_LINE_SMOOTH);
	glDisable(GL_POINT_SMOOTH);
	
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	glColor3f(1.0f, 1.0f, 1.0f);

	if(_ASConfig->bShowFieldInfo)
	{ // Show some field information:
		glPointSize(15.0f);
		for(i = 0; i < Header.iFields; i++)
		{
			pFieldT = &pField[i];
			if(pFieldT->iXField == Header.iWidth-1 || pFieldT->iYField == Header.iHeight-1)
				continue; 

			if(pFieldT->pBridgeActor || pFieldT->bWall)
			{
				glColor3f(0.0f, 1.0f, 1.0f);
				glBegin(GL_POINTS);
					glVertex3f(pFieldT->iXField+0.5f, pFieldT->iYField+0.5f,
							   fPoint[pFieldT->Side[FACE_FLOOR].SideQuad[0].iPoint[2]][Z]-1.5f);
				glEnd();
				if(pFieldT->pBridgeActor && pFieldT->pBridgeActor->bBridgeMovement)
				{
				glColor3f(0.0f, 0.0f, 1.0f);
				glBegin(GL_POINTS);
					glVertex3f(pFieldT->iXField+0.5f, pFieldT->iYField+0.5f,
							   fPoint[pFieldT->Side[FACE_FLOOR].SideQuad[0].iPoint[2]][Z]-1.0f);
				glEnd();
				}
			}

			if(!pFieldT->pActor)
				continue;
			glColor3f(1.0f, 1.0f, 1.0f);
			glBegin(GL_POINTS);
				glVertex3f(pFieldT->iXField+0.5f, pFieldT->iYField+0.5f,
						   fPoint[pFieldT->Side[FACE_FLOOR].SideQuad[0].iPoint[2]][Z]);
			glEnd();
			
			glColor3f(1.0f, 0.0f, 0.0f);
			glBegin(GL_LINES);
				glVertex3f(pFieldT->iXField+0.5f, pFieldT->iYField+0.5f,
						   fPoint[pFieldT->Side[FACE_FLOOR].SideQuad[0].iPoint[2]][Z]);
				glVertex3f(pFieldT->pActor->fWorldPos[X], pFieldT->pActor->fWorldPos[Y],
						   fPoint[pFieldT->Side[FACE_FLOOR].SideQuad[0].iPoint[2]][Z]-1.0f);
			glEnd();
		}
	}


	glColor3f(1.0f, 1.0f, 1.0f);
	glPointSize(10.0f);
	if(bTempBackground)
	{ // Draw draw the selection around the fields:
		switch(byEditorMenu)
		{
			case EDITOR_TERRAIN_MENU:
				glBegin(GL_POINTS);
					for(iPoint = 0; iPoint < Header.iPoints; iPoint++)
					{
						if(!bPointSelected[iPoint])
							continue;
						glVertex3fv(fPoint[iPoint]);
					}
					for(iPoint = 0; iPoint < Header.iLevelPoints; iPoint++)
					{
						if(!bPointSelected[Header.iPoints+iPoint])
							continue;
						glVertex3fv(fWaterPoint[iPoint]);
					}
				glEnd();
			break;

			case EDITOR_SURFACE_MENU:
				hWndT = hWndEditorTab[TAB_EDITOR_SURFACES];
				for(iField = 0; iField < Header.iFields; iField++)
				{
					pFieldT = pInFOVFields[iField];
					if(!pFieldT)
						break;
					if(pFieldT->iXField == Header.iWidth-1 || pFieldT->iYField == Header.iHeight-1)
						continue; 
					for(iSide = 0; iSide < 7; iSide++)
					{
						pFieldSideT = &pFieldT->Side[iSide];
						iSurface = -1;
						if(pFieldT->bSelected)
						{
							if(iSide == FACE_FLOOR && SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_FLOOR, BM_GETCHECK, 0, 0L))
								iSurface = FACE_FLOOR;
							if(iSide == FACE_TOP && SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_TOP, BM_GETCHECK, 0, 0L))
								iSurface = FACE_TOP;
							if(iSide == FACE_LEFT && SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_LEFT, BM_GETCHECK, 0, 0L))
								iSurface = FACE_LEFT;
							if(iSide == FACE_RIGHT && SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_RIGHT, BM_GETCHECK, 0, 0L))
								iSurface = FACE_RIGHT;
							if(iSide == FACE_BOTTOM && SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_BOTTOM, BM_GETCHECK, 0, 0L))
								iSurface = FACE_BOTTOM;
							if(iSide == FACE_FRONT && SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_FRONT, BM_GETCHECK, 0, 0L))
								iSurface = FACE_FRONT;
							if(iSide == FACE_WATER && SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_WATER, BM_GETCHECK, 0, 0L))
								iSurface = FACE_WATER;
						}
						
						// Check if we should show the field side attributes:
						if(SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_SET_ONLY_ATTRIBUTES, BM_GETCHECK, 0, 0L))
						{ // YEP!
							if(bCheckSurfaceAlwaysActive && pFieldSideT->bFaceAlwaysActive)
								iSurface = iSide;
							if(bCheckSurface2Sides && pFieldSideT->bFace2Sides)
								iSurface = iSide;
							if(bCheckSurfaceSwapSides && pFieldSideT->bFaceSwapSides)
								iSurface = iSide;
							if(bCheckSurfaceDisableWaterSide && pFieldSideT->bDisableWaterSide)
								iSurface = iSide;
							if(bCheckSurfaceInvisible && pFieldSideT->bInvisible)
								iSurface = iSide;
							if(bCheckSurfaceWallSide && pFieldSideT->bWallSide)
							{
								iSurface = iSide;
								
								// Show the direction in which it is not possible to walk through:
								fPosT = &fPoint[pFieldSideT->SideQuad[0].iPoint[2]];
								glBegin(GL_LINES);
									glVertex3f((*fPosT)[X], (*fPosT)[Y], (*fPosT)[Z]);
									switch(iSide)
									{
										case FACE_LEFT: glVertex3f((*fPosT)[X]-0.5f, (*fPosT)[Y], (*fPosT)[Z]); break;
										case FACE_TOP: glVertex3f((*fPosT)[X], (*fPosT)[Y]-0.5f, (*fPosT)[Z]); break;
										case FACE_RIGHT: glVertex3f((*fPosT)[X]+0.5f, (*fPosT)[Y], (*fPosT)[Z]); break;
										case FACE_BOTTOM: glVertex3f((*fPosT)[X], (*fPosT)[Y]+0.5f, (*fPosT)[Z]); break;
									}
								glEnd();
							}
						}


						if(iSurface == -1)
							continue;
						if(iSurface == FACE_WATER)
						{
							glBegin(GL_LINE_LOOP);
								glVertex3fv(fWaterPoint[pFieldSideT->SideQuad[0].iPoint[0]]);
								glVertex3fv(fWaterPoint[pFieldSideT->SideQuad[1].iPoint[0]]);
								glVertex3fv(fWaterPoint[pFieldSideT->SideQuad[1].iPoint[1]]);
								glVertex3fv(fWaterPoint[pFieldSideT->SideQuad[1].iPoint[2]]);
								glVertex3fv(fWaterPoint[pFieldSideT->SideQuad[2].iPoint[2]]);
								glVertex3fv(fWaterPoint[pFieldSideT->SideQuad[2].iPoint[3]]);
								glVertex3fv(fWaterPoint[pFieldSideT->SideQuad[3].iPoint[3]]);
								glVertex3fv(fWaterPoint[pFieldSideT->SideQuad[3].iPoint[0]]);
							glEnd();
						}
						else
						{
							glBegin(GL_LINE_LOOP);
								glVertex3fv(fPoint[pFieldSideT->SideQuad[0].iPoint[0]]);
								glVertex3fv(fPoint[pFieldSideT->SideQuad[1].iPoint[0]]);
								glVertex3fv(fPoint[pFieldSideT->SideQuad[1].iPoint[1]]);
								glVertex3fv(fPoint[pFieldSideT->SideQuad[1].iPoint[2]]);
								glVertex3fv(fPoint[pFieldSideT->SideQuad[2].iPoint[2]]);
								glVertex3fv(fPoint[pFieldSideT->SideQuad[2].iPoint[3]]);
								glVertex3fv(fPoint[pFieldSideT->SideQuad[3].iPoint[3]]);
								glVertex3fv(fPoint[pFieldSideT->SideQuad[3].iPoint[0]]);
							glEnd();
						}
					}
				}
			break;

			default:
				// Show beamer target:
				glColor3f(1.0f, 0.5f, 0.5f);
				if(pCurrentField->Side[FACE_FLOOR].Surface[0].pSurface->Header.bBeamer &&
				   pCurrentField->iBeamerTarget != -1)
				{
					glBegin(GL_LINES);
						glVertex3f(pCurrentField->iXField+0.5f, pCurrentField->iYField+0.5f,
								   fPoint[pCurrentField->Side[FACE_FLOOR].SideQuad[0].iPoint[2]][Z]);
						glVertex3f(pField[pCurrentField->iBeamerTarget].iXField+0.5f,
								   pField[pCurrentField->iBeamerTarget].iYField+0.5f,
								   fPoint[pField[pCurrentField->iBeamerTarget].Side[FACE_FLOOR].SideQuad[0].iPoint[2]][Z]);
					glEnd();
				}
				// Check the fields:
				for(i = 0; i < Header.iFields; i++)
				{
					pFieldT = &pField[i];
					if(pFieldT->iXField == Header.iWidth-1 || pFieldT->iYField == Header.iHeight-1)
						continue; 

					pFieldT->fEditorRot += (float) g_lDeltatime/100;

					if(byEditorSelected == EDITOR_SELECTED_WATER_TYPE)
					{
						switch(pFieldT->WaterType)
						{
							case WATER_NORMAL: glColor3f(0.0f, 0.0f, 1.0f); break;
							case WATER_ACID: glColor3f(0.0f, 1.0f, 0.0f); break;
							case WATER_LAVA: glColor3f(1.0f, 0.0f, 0.0f); break;
						}
						glBegin(GL_POINTS);
							glVertex3f(pFieldT->iXField+0.5f, pFieldT->iYField+0.5f,
									   fPoint[pFieldT->Side[FACE_FLOOR].SideQuad[0].iPoint[2]][Z]);
						glEnd();
					}
					else
					if((byEditorMenu == EDITOR_BRUSH_MENU &&
						((byEditorSelected == EDITOR_SELECTED_ALWAYS_WALL &&  
						  pFieldT->bAlwaysWall) ||
						(byEditorSelected == EDITOR_SELECTED_INDESTRUCTIBLE_WALL &&  
						 pFieldT->bIndestructibleWall) ||
						(byEditorSelected == EDITOR_SELECTED_NO_BRIDGE_POSSIBLE &&  
						 pFieldT->bNoBridgePossible) ||
						(byEditorSelected == EDITOR_SELECTED_ACTIVATE_WATER &&
						 pFieldT->bActivateWater) ||
						(byEditorSelected == EDITOR_SELECTED_ACTIVATE_WATER_BUBBLES &&
 						 pFieldT->bActivateWaterBubbles) ||
						(byEditorSelected == EDITOR_SELECTED_FORCE_WATER_BUBBLES &&
 						 pFieldT->bForceWaterBubbles) ||
						(byEditorSelected == EDITOR_SELECTED_WALL &&
						 pFieldT->bWall && !pFieldT->pActor && !pFieldT->bWallHole) ||
						(byEditorSelected == EDITOR_SELECTED_WALL_HOLE &&
						 pFieldT->bWallHole) ||
						(byEditorSelected == EDITOR_SELECTED_DEACTIVATE_FIELD &&
						 !pFieldT->bActive && !pFieldT->bWallHole))) ||
					   (byEditorMenu == EDITOR_DECORATION_MENU && pFieldT->pDecoration))
					{
						glColor3f(1.0f, 1.0f, 1.0f);
						glBegin(GL_POINTS);
							glVertex3f(pFieldT->iXField+0.5f, pFieldT->iYField+0.5f,
									   fPoint[pFieldT->Side[FACE_FLOOR].SideQuad[0].iPoint[2]][Z]);
						glEnd();
					}
					
					for(bTextScript = FALSE, iFace = 0; iFace < 5; iFace++)
					{
						if(pFieldT->bTextScript[iFace])
						{
							bTextScript = TRUE;
							break;
						}
					}
					if(pFieldT->iCamera != -1 || bTextScript)
					{
						glPushMatrix();			
						glTranslatef(pFieldT->iXField+0.5f, pFieldT->iYField+0.5f,
									 fPoint[pFieldT->Side[FACE_FLOOR].SideQuad[0].iPoint[2]][Z]-0.5f);
						if(byEditorMenu == EDITOR_SELECT_MENU)
						{
							glScalef(0.008f, 0.008f, 0.008f);
							glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);						
							ASEnableLighting();
							glColor3f(1.0f, 1.0f, 1.0f);
							if(pFieldT->iCamera != -1)
							{
								glRotatef(pFieldT->fEditorRot, 0.0f, 1.0f, 0.0f);
								ASDrawMd2Frame(pCameraModel, 0);
							}
							glScalef(0.3f, 0.3f, 0.3f);
							if(bTextScript)
							{
								glRotatef(-pFieldT->fEditorRot*2, 0.0f, 1.0f, 0.0f);
								ASDrawMd2Frame(pPencilModel, 0);
							}
							glDisable(GL_LIGHTING);
						}
						glPopMatrix();
					}

					if(!pFieldT->bSelected)
						continue; // This field isn't selected!
					if(pFieldT == pCurrentField)
						glColor3f(1.0f, 0.0f, 0.0f);
					else
						glColor3f(1.0f, 1.0f, 1.0f);
					
					glBegin(GL_LINE_LOOP);
						pFieldSideT = &pFieldT->Side[FACE_FLOOR];
						glVertex3fv(fPoint[pFieldSideT->SideQuad[0].iPoint[0]]);
						glVertex3fv(fPoint[pFieldSideT->SideQuad[1].iPoint[0]]);
						glVertex3fv(fPoint[pFieldSideT->SideQuad[1].iPoint[1]]);
						glVertex3fv(fPoint[pFieldSideT->SideQuad[1].iPoint[2]]);
						glVertex3fv(fPoint[pFieldSideT->SideQuad[2].iPoint[2]]);
						glVertex3fv(fPoint[pFieldSideT->SideQuad[2].iPoint[3]]);
						glVertex3fv(fPoint[pFieldSideT->SideQuad[3].iPoint[3]]);
						glVertex3fv(fPoint[pFieldSideT->SideQuad[3].iPoint[0]]);
					glEnd();
					glBegin(GL_LINE_LOOP);
						pFieldSideT = &pFieldT->Side[FACE_FRONT];
						glVertex3fv(fPoint[pFieldSideT->SideQuad[0].iPoint[0]]);
						glVertex3fv(fPoint[pFieldSideT->SideQuad[1].iPoint[0]]);
						glVertex3fv(fPoint[pFieldSideT->SideQuad[1].iPoint[1]]);
						glVertex3fv(fPoint[pFieldSideT->SideQuad[1].iPoint[2]]);
						glVertex3fv(fPoint[pFieldSideT->SideQuad[2].iPoint[2]]);
						glVertex3fv(fPoint[pFieldSideT->SideQuad[2].iPoint[3]]);
						glVertex3fv(fPoint[pFieldSideT->SideQuad[3].iPoint[3]]);
						glVertex3fv(fPoint[pFieldSideT->SideQuad[3].iPoint[0]]);
					glEnd();
					glBegin(GL_LINES);
						glVertex3fv(fPoint[pFieldT->Side[FACE_FRONT].SideQuad[0].iPoint[0]]);
						glVertex3fv(fPoint[pFieldT->Side[FACE_LEFT].SideQuad[0].iPoint[3]]);
						glVertex3fv(fPoint[pFieldT->Side[FACE_LEFT].SideQuad[0].iPoint[3]]);
						glVertex3fv(fPoint[pFieldT->Side[FACE_FLOOR].SideQuad[0].iPoint[0]]);

						glVertex3fv(fPoint[pFieldT->Side[FACE_FRONT].SideQuad[1].iPoint[1]]);
						glVertex3fv(fPoint[pFieldT->Side[FACE_RIGHT].SideQuad[1].iPoint[2]]);
						glVertex3fv(fPoint[pFieldT->Side[FACE_RIGHT].SideQuad[1].iPoint[2]]);
						glVertex3fv(fPoint[pFieldT->Side[FACE_FLOOR].SideQuad[1].iPoint[1]]);

						glVertex3fv(fPoint[pFieldT->Side[FACE_FRONT].SideQuad[2].iPoint[2]]);
						glVertex3fv(fPoint[pFieldT->Side[FACE_RIGHT].SideQuad[0].iPoint[3]]);
						glVertex3fv(fPoint[pFieldT->Side[FACE_RIGHT].SideQuad[0].iPoint[3]]);
						glVertex3fv(fPoint[pFieldT->Side[FACE_FLOOR].SideQuad[2].iPoint[2]]);

						glVertex3fv(fPoint[pFieldT->Side[FACE_FRONT].SideQuad[3].iPoint[3]]);
						glVertex3fv(fPoint[pFieldT->Side[FACE_LEFT].SideQuad[1].iPoint[2]]);
						glVertex3fv(fPoint[pFieldT->Side[FACE_LEFT].SideQuad[1].iPoint[2]]);
						glVertex3fv(fPoint[pFieldT->Side[FACE_FLOOR].SideQuad[3].iPoint[3]]);
					glEnd();
				}
			break;
		}
	}

 	if(Environment.bFog)
		glEnable(GL_FOG);
	glDisable(GL_BLEND);
	glEnable(GL_DEPTH_TEST);
	ASEnableLighting();
} // end LEVEL::DrawOther()
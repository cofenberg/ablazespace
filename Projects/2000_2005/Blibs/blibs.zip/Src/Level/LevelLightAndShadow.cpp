//-----------------------------------------------------------------------------
// File: LevelLightAndShadow.cpp
//-----------------------------------------------------------------------------

#include "..\AS\AS_Engine.h"
#include "..\ModuleHeaders.h"


void LEVEL::DrawShadowMaps(void)
{ // begin LEVEL::DrawShadowMaps()
	AS_DLIGHT Light1;
	ACTOR *pActorT;

	if(!_ASConfig->bShadowmaps)
		return;
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glDepthMask(FALSE);
	glBindTexture(GL_TEXTURE_2D, GameTexture[15].iOpenGLID);
	glDisable(GL_LIGHTING);
	glDisable(GL_FOG);
	_AS->EnableCullFace(TRUE);
	_AS->SetCullFaceMode(GL_FRONT);
	
	glDepthFunc(GL_EQUAL);
	glBlendFunc(GL_DST_COLOR, GL_ZERO);
	Light1.vColor.fX = 1.0f;
	Light1.vColor.fY = 1.0f;
	Light1.vColor.fZ = 1.0f;
	Light1.fDensity = 1.0f;
	for(int i = 0; i < Header.iMaxActors; i++)
	{
		if(!(pActorT = pVisibleActors[i]))
			break;
		if(pActorT->bGhostMode || !pActorT->bShadow)
			continue;
		switch(pActorT->Type)
		{
			case AT_BLIBS:
				Light1.fRadius = 0.6f;
				ASGetMd2Vertex(pBlibsModel, pActorT->iAniStep, pActorT->iNextAniStep, pActorT->fAniInterpolation, pActorT->fWorldPos,
							   0.005f, -90.0f, pActorT->fRot[Y]+90, 0.0f, 367, &Light1.vPos.fV);
				PerformShadow(Light1, TRUE);

				ASGetMd2Vertex(pBlibsModel, pActorT->iAniStep, pActorT->iNextAniStep, pActorT->fAniInterpolation, pActorT->fWorldPos,
							   0.005f, -90.0f, pActorT->fRot[Y]+90, 0.0f, 793, &Light1.vPos.fV);
				PerformShadow(Light1, TRUE);
			break;

			case AT_BOX_NORMAL:
			case AT_BOX_RED:
			case AT_BOX_GREEN:
			case AT_BOX_BLUE:
				if(pActorT->bGoingDeath)
					break;
				Light1.fRadius = pActorT->fSize;
				Light1.vPos = pActorT->fWorldPos;
				if(!pActorT->bBridge)
					PerformShadow(Light1, !pActorT->bBridge);
			break;

			case AT_MOBMOB: case AT_X3: case AT_LUCIFER_HEAD:
				Light1.fRadius = 0.4f;
				Light1.vPos = pActorT->fWorldPos;
				PerformShadow(Light1, TRUE);
			break;

			case AT_LUCIFER:
				Light1.fRadius = 1.5f;
				Light1.vPos = pActorT->fWorldPos;
				Light1.vPos += pActorT->fPosTemp;
				PerformShadow(Light1, TRUE);
			break;

			case AT_HEALTH_ITEM:
			case AT_HEALTH_INCREASE_ITEM:
			case AT_LIFE_ITEM:
			case AT_PULL_ITEM:
			case AT_CHEST_ITEM:
			case AT_STRENGTH_ITEM:
			case AT_WEAPON_ITEM:
			case AT_COIN_ITEM:
			case AT_GHOST_ITEM:
			case AT_TIME_ITEM:
			case AT_STEP_ITEM:
			case AT_SPEED_ITEM:
			case AT_WING_ITEM:
			case AT_SHIELD_ITEM:
			case AT_JUMP_ITEM:
			case AT_AIR_ITEM:
			case AT_AIR_INCREASE_ITEM:
			case AT_THROW_ITEM:
			case AT_KICK_ITEM:
			case AT_BAG_ITEM:
			case AT_DYNAMITE_ITEM:
				if(pActorT->fSize < 0.1f)
					break;
				if(pActorT->Type == AT_CHEST_ITEM)
					Light1.fRadius = 0.8f*pActorT->fSize;
				else
					Light1.fRadius = 0.4f*pActorT->fSize;
				if(Light1.fRadius < 0.0f)
					break;
				Light1.vPos = pActorT->fWorldPos;
				Light1.vPos += pActorT->fPosTemp;
				PerformShadow(Light1, TRUE);
			break;
		}
	}
	_AS->SetNormalDepthFunc();
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	glDepthMask(TRUE);
	if(Environment.bFog)
		glEnable(GL_FOG);
} // end LEVEL::DrawShadowMaps()

void LEVEL::PerformShadow(AS_DLIGHT Light, BOOL bBridgesToo)
{ // begin LEVEL::PerformShadow()
	AS_VECTOR3D vPoint1, vPoint2, vPoint3, vPoint4, vRight, vUp;
	int iXStart, iYStart, iXEnd, iYEnd, iX, iY, iQuad, iSide;
	FIELD_SIDE_QUAD	*pSideQuadT;
	AS_PLANE Plane;
	ACTOR *pActorT;
	FIELD *pFieldT;
	int	*piTempP;
	
	Light.vPos.fX += Environment.fMoveShadows[X];
	Light.vPos.fY += Environment.fMoveShadows[Y];
	Light.vPos.fZ += Environment.fMoveShadows[Z];
	Light.fDensity *= Environment.fShadowsDensity_Size[0];
	Light.fRadius *= Environment.fShadowsDensity_Size[1];
	if(!Light.fDensity)
		return;
	
	iXStart = (int) (Light.vPos.fX-Light.fRadius);
	iXEnd = (int) (Light.vPos.fX+Light.fRadius);
	iYStart = (int) (Light.vPos.fY-Light.fRadius);
	iYEnd = (int) (Light.vPos.fY+Light.fRadius);
	if(iXStart < 0)
		iXStart = 0;
	if(iYStart < 0)
		iYStart = 0;
	if(iXEnd >= Header.iWidth-1)
	   iXEnd = Header.iWidth-2;
	if(iYEnd >= Header.iHeight-1)
	   iYEnd = Header.iHeight-2;

	vRight.fX = 1.0f;
	vUp.fY = -1.0f;
	Plane.vN.fX = 0.0f;
	Plane.vN.fY = 0.0f;
	Plane.vN.fZ = -1.0f;
	glBegin(GL_TRIANGLES);
		// Loop through all faces:
		for(iY = iYStart; iY <= iYEnd; iY++)
		{
			for(iX = iXStart; iX <= iXEnd; iX++)
			{
				// Get a pointer to this field:
				GET_FIELD_POINTER(iX, iY, pFieldT);
				if(!pFieldT->bOnScreen)
					continue; // The field isn't visible!
				if(pFieldT->bActive)
				{ // All 6 sides:
					for(iSide = 0; iSide < 6; iSide++)
					{ // All 4 quads of this field:
						if(!pFieldT->Side[iSide].bFaceActive || pFieldT->Side[iSide].bInvisible)
							continue;
						SetupSideDraw2(&pFieldT->Side[iSide].Surface[0]);
						for(iQuad = 0; iQuad < 4; iQuad++)
						{
							pSideQuadT = &pFieldT->Side[iSide].SideQuad[iQuad];
							piTempP = &pSideQuadT->iPoint[0];
							Light.Light(fPoint[piTempP[0]], fPoint[piTempP[1]], fPoint[piTempP[3]], pSideQuadT->vRightNormal[0], pSideQuadT->vUpNormal[0], pSideQuadT->Plane[0], FALSE);
							Light.Light(fPoint[piTempP[1]], fPoint[piTempP[2]], fPoint[piTempP[3]], pSideQuadT->vRightNormal[1], pSideQuadT->vUpNormal[1], pSideQuadT->Plane[1], FALSE);
						}
					}
				}
				if(!bBridgesToo)
					continue;
				pActorT = pFieldT->pBridgeActor;
				if(pActorT && !pActorT->bBridgeMovement)
				{ // There is a bridge, check it too:
					// Set the ray direction:
					vPoint1 = vPoint2 = vPoint3 = vPoint4 = pActorT->fWorldPos;
					vPoint1.fX -= 0.5f;
					vPoint1.fY -= 0.5f;
					vPoint1.fZ -= 1.0f;
					vPoint2.fX += 0.5f;
					vPoint2.fY -= 0.5f;
					vPoint2.fZ -= 1.0f;
					vPoint3.fX += 0.5f;
					vPoint3.fY += 0.5f;
					vPoint3.fZ -= 1.0f;
					vPoint4.fX -= 0.5f;
					vPoint4.fY += 0.5f;
					vPoint4.fZ -= 1.0f;
					Plane.vN.fZ = pActorT->fWorldPos[Z];
					Light.Light(vPoint1, vPoint2, vPoint3, vRight, vUp, Plane, FALSE);
					Light.Light(vPoint1, vPoint3, vPoint4, vRight, vUp, Plane, FALSE);
				}
			}
		}
	glEnd();
} // end LEVEL::PerformShadow()

void LEVEL::DrawLightMaps(void)
{ // begin LEVEL::DrawLightMaps()
	AS_DLIGHT Light1;
	ACTOR *pActorT;

	if(!_ASConfig->bLightmaps)
		return;
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glDepthMask(FALSE);
	glBindTexture(GL_TEXTURE_2D, GameTexture[13].iOpenGLID);
	glDisable(GL_LIGHTING);
	glDepthFunc(GL_EQUAL);
	if(Environment.bFog)
		glEnable(GL_FOG);
	_AS->EnableCullFace(TRUE);
	_AS->SetCullFaceMode(GL_FRONT);

	Light1.fDensity = 1.0f;
	for(int i = 0; i < Header.iMaxActors; i++)
	{
		if(!(pActorT = pVisibleActors[i]))
			break;
		if(pActorT->bGhostMode || !pActorT->bTorch)
			continue;
		Light1.vPos = pActorT->fWorldPos;
		Light1.vPos.fZ -= 0.6f;
		if(pActorT->Type == AT_LUCIFER)
			Light1.fRadius = 3.0;
		else
			Light1.fRadius = 2.0;
		Light1.vColor.fX = pActorT->fShieldLighting*0.8f;
		if(Light1.vColor.fX < 0.4f)
			Light1.vColor.fX = 0.4f;
		Light1.vColor.fY = pActorT->fShieldLighting*0.6f;
		if(Light1.vColor.fY < 0.4f)
			Light1.vColor.fY = 0.4f;
		Light1.vColor.fZ = pActorT->fShieldLighting*0.6f;
		if(Light1.vColor.fZ < 0.4f)
			Light1.vColor.fZ = 0.4f;
		
		PerformLight(Light1, TRUE);
	}
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	glDepthMask(TRUE);
	_AS->SetNormalDepthFunc();
} // end LEVEL::DrawLightMaps()

void LEVEL::PerformLight(AS_DLIGHT Light, BOOL bBridgesToo)
{ // begin LEVEL::PerformLight()
	AS_VECTOR3D vPoint1, vPoint2, vPoint3, vPoint4, vRight, vUp;
	int iXStart, iYStart, iXEnd, iYEnd, iX, iY, iQuad, iSide;
	FIELD_SIDE_QUAD	*pSideQuadT;
	AS_PLANE Plane;
	ACTOR *pActorT;
	FIELD *pFieldT;
	int	*piTempP;
	
	iXStart = (int) (Light.vPos.fX-Light.fRadius-1);
	iXEnd = (int) (Light.vPos.fX+Light.fRadius+1);
	iYStart = (int) (Light.vPos.fY-Light.fRadius-1);
	iYEnd = (int) (Light.vPos.fY+Light.fRadius+1);
	if(iXStart < 0)
		iXStart = 0;
	if(iYStart < 0)
		iYStart = 0;
	if(iXEnd >= Header.iWidth-1)
	   iXEnd = Header.iWidth-2;
	if(iYEnd >= Header.iHeight-1)
	   iYEnd = Header.iHeight-2;

	vRight.fX = 1.0f;
	vUp.fY = -1.0f;
	Plane.vN.fX = 0.0f;
	Plane.vN.fY = 0.0f;
	Plane.vN.fZ = -1.0f;
	glBegin(GL_TRIANGLES);
		// Loop through all faces:
		for(iY = iYStart; iY <= iYEnd; iY++)
		{
			for(iX = iXStart; iX <= iXEnd; iX++)
			{
				// Get a pointer to this field:
				GET_FIELD_POINTER(iX, iY, pFieldT);
				if(!pFieldT->bOnScreen)
					continue; // The field isn't visible!

				if(pFieldT->bActive)
				{ // All 6 sides:
					for(iSide = 0; iSide < 6; iSide++)
					{ // All 4 quads of this field:
						if(!pFieldT->Side[iSide].bFaceActive || pFieldT->Side[iSide].bInvisible)
							continue;
						for(iQuad = 0; iQuad < 4; iQuad++)
						{
							pSideQuadT = &pFieldT->Side[iSide].SideQuad[iQuad];
							piTempP = &pSideQuadT->iPoint[0];
							Light.Light(fPoint[piTempP[0]], fPoint[piTempP[1]], fPoint[piTempP[3]], pSideQuadT->vRightNormal[0], pSideQuadT->vUpNormal[0], pSideQuadT->Plane[0], TRUE);
							Light.Light(fPoint[piTempP[1]], fPoint[piTempP[2]], fPoint[piTempP[3]], pSideQuadT->vRightNormal[1], pSideQuadT->vUpNormal[1], pSideQuadT->Plane[1], TRUE);
						}
					}
				}
				if(!bBridgesToo)
					continue;
				pActorT = pFieldT->pBridgeActor;
				if(pActorT && !pActorT->bBridgeMovement)
				{ // There is a bridge, check it too:
					// Set the ray direction:
					vPoint1 = vPoint2 = vPoint3 = vPoint4 = pActorT->fWorldPos;
					vPoint1.fX -= 0.5f;
					vPoint1.fY -= 0.5f;
					vPoint1.fZ -= 1.0f;
					vPoint2.fX += 0.5f;
					vPoint2.fY -= 0.5f;
					vPoint2.fZ -= 1.0f;
					vPoint3.fX += 0.5f;
					vPoint3.fY += 0.5f;
					vPoint3.fZ -= 1.0f;
					vPoint4.fX -= 0.5f;
					vPoint4.fY += 0.5f;
					vPoint4.fZ -= 1.0f;
					Light.Light(vPoint1, vPoint2, vPoint3, vRight, vUp, Plane, TRUE);
					Light.Light(vPoint1, vPoint3, vPoint4, vRight, vUp, Plane, TRUE);
				}
			}
		}
	glEnd();
} // end LEVEL::PerformLight()

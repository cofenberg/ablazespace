//-----------------------------------------------------------------------------
// File: LevelOrganisation.cpp
//-----------------------------------------------------------------------------

#include "..\AS\AS_Engine.h"
#include "..\ModuleHeaders.h"


// FIELD_SIDE_LIST functions: *************************************************
// Get memory for the field side lists:
void FIELD_SIDE_LIST::Create(LEVEL *pLevel)
{ // begin FIELD_SIDE_LIST::Create()
    int i;
	
	// Textures:
	pSolid = (FIELD_SIDE_SURFACE ***) malloc(sizeof(FIELD_SIDE_SURFACE *)*pLevel->Header.iTextures);
	if(!pSolid)
		return;
	// Field side pointers:
	for(i = 0; i < pLevel->Header.iTextures; i++)
	{
		pSolid[i] = (FIELD_SIDE_SURFACE **) malloc(sizeof(FIELD_SIDE_SURFACE *)*pLevel->Header.iFields*12);
		if(!pSolid[i])
			return;
	}

	// Textures:
	pTransparent = (FIELD_SIDE_SURFACE ***) malloc(sizeof(FIELD_SIDE_SURFACE *)*pLevel->Header.iTextures);
	if(!pTransparent)
		return;
	// Field side pointers:
	for(i = 0; i < pLevel->Header.iTextures; i++)
	{
		pTransparent[i] = (FIELD_SIDE_SURFACE **) malloc(sizeof(FIELD_SIDE_SURFACE *)*pLevel->Header.iFields*12);
		if(!pTransparent[i])
			return;
	}
} // end FIELD_SIDE_LIST::Create()

// Free the memory for the field side lists:
void FIELD_SIDE_LIST::Destroy(LEVEL *pLevel)
{ // begin FIELD_SIDE_LIST::Destroy()
	int i;

	if(pSolid)
	{
		for(i = 0; i < pLevel->Header.iTextures; i++)
			SAFE_DELETE(pSolid[i]);
		SAFE_DELETE(pSolid);
	}
	if(pTransparent)
	{
		for(i = 0; i < pLevel->Header.iTextures; i++)
			SAFE_DELETE(pTransparent[i]);
		SAFE_DELETE(pTransparent);
	}
} // end FIELD_SIDE_LIST::Destroy()

// Build the field side list:
void FIELD_SIDE_LIST::Build(LEVEL *pLevel)
{ // begin FIELD_SIDE_LIST::Build()
	FIELD_SIDE_SURFACE **pFieldSurfaceTextureT, *pFieldSurfaceT;
	int iTexture, iField, iSide, i, iQuad;
	FIELD_SIDE *pFieldSideT;
	FIELD_SIDE_QUAD *pFieldSideQuadT;
	BOOL bBlended;
	FIELD *pFieldT;

	// Solid surfaces list:
	for(iTexture = 0; iTexture < pLevel->Header.iTextures; iTexture++)
	{
		pFieldSurfaceTextureT = pSolid[iTexture];
		pFieldSurfaceTextureT[0] = NULL;
		for(iField = 0; iField < pLevel->Header.iFields; iField++)
		{
			if(!(pFieldT = pLevel->pInFOVFields[iField]))
				break;
			if((!pFieldT->bActive && !pFieldT->bWallHole) || (pFieldT->pBridgeActor && !pFieldT->bWallHole))
				continue;
			pFieldSideT = &pFieldT->Side[FACE_FLOOR];
			pFieldSurfaceT = &pFieldSideT->Surface[0];
			if(pFieldSideT->bFaceActive && !pFieldT->bWallHole &&
			   pFieldSurfaceT->pSurface && !pFieldSideT->bInvisible &&
			   pFieldSurfaceT->pSurface->iTextureID[pFieldSurfaceT->iCurrentAniStep] == iTexture)
			{
				bBlended = FALSE;
				for(iQuad = 0; iQuad < 4; iQuad++)
				{
					pFieldSideQuadT = &pFieldSideT->SideQuad[iQuad];
					for(i = 0; i < 4; i++)
					{
						if(pLevel->fColor[pFieldSideQuadT->iPoint[i]][A] != 1.0f)
						{
							bBlended = TRUE;
							break;
						}
					}
				}
				if(!bBlended)
					*(pFieldSurfaceTextureT++) = pFieldSurfaceT; // Add this side:
			}

			for(iSide = FACE_TOP; iSide < FACE_FRONT+1; iSide++)
			{
				pFieldSideT = &pFieldT->Side[iSide];
				pFieldSurfaceT = &pFieldSideT->Surface[0];
				if(!pFieldSideT->bFaceActive || pFieldSideT->bInvisible ||
				   !pFieldSurfaceT->pSurface ||
				   pFieldSurfaceT->pSurface->iTextureID[pFieldSurfaceT->iCurrentAniStep] != iTexture)
					continue;
				bBlended = FALSE;
				for(iQuad = 0; iQuad < 4; iQuad++)
				{
					pFieldSideQuadT = &pFieldSideT->SideQuad[iQuad];
					for(i = 0; i < 4; i++)
					{
						if(pLevel->fColor[pFieldSideQuadT->iPoint[i]][A] != 1.0f)
						{
							bBlended = TRUE;
							break;
						}
					}
				}
				if(!bBlended)
					*(pFieldSurfaceTextureT++) = pFieldSurfaceT; // Add this side;
			}
		}
		*(pFieldSurfaceTextureT) = NULL;
	}

	// Transparent surfaces list:
	for(iTexture = 0; iTexture < pLevel->Header.iTextures; iTexture++)
	{
		pFieldSurfaceTextureT = pTransparent[iTexture];
		pFieldSurfaceTextureT[0] = NULL;
		for(iField = 0; iField < pLevel->Header.iFields; iField++)
		{
			if(!(pFieldT = pLevel->pInFOVFields[iField]))
				break;
			if((!pFieldT->bActive && !pFieldT->bWallHole) || (pFieldT->pBridgeActor && !pFieldT->bWallHole))
				continue;
			pFieldSideT = &pFieldT->Side[FACE_FLOOR];
			pFieldSurfaceT = &pFieldSideT->Surface[0];
			if(pFieldSideT->bFaceActive && !pFieldT->bWallHole && !pFieldSideT->bInvisible)
			{
				bBlended = FALSE;
				for(iQuad = 0; iQuad < 4; iQuad++)
				{
					pFieldSideQuadT = &pFieldSideT->SideQuad[iQuad];
					for(i = 0; i < 4; i++)
					{
						if(pLevel->fColor[pFieldSideQuadT->iPoint[i]][A] != 1.0f)
						{
							bBlended = TRUE;
							break;
						}
					}
				}
				if(pFieldSurfaceT->pSurface &&
				   pFieldSurfaceT->pSurface->iTextureID[pFieldSurfaceT->iCurrentAniStep] == iTexture &&
				   bBlended)
					*(pFieldSurfaceTextureT++) = pFieldSurfaceT; // Add this side:
				pFieldSurfaceT = &pFieldSideT->Surface[1];
				if(_ASConfig->bMultitexturing && pFieldSurfaceT->pSurface &&
				   pFieldSurfaceT->pSurface->iTextureID[pFieldSurfaceT->iCurrentAniStep] == iTexture)
					*(pFieldSurfaceTextureT++) = pFieldSurfaceT; // Add this side:
			}

			for(iSide = 1; iSide < 6; iSide++)
			{
				pFieldSideT = &pFieldT->Side[iSide];
				if(!pFieldSideT->bFaceActive || pFieldSideT->bInvisible)
					continue;
				pFieldSurfaceT = &pFieldSideT->Surface[0];
				bBlended = FALSE;
				for(iQuad = 0; iQuad < 4; iQuad++)
				{
					pFieldSideQuadT = &pFieldSideT->SideQuad[iQuad];
					for(i = 0; i < 4; i++)
					{
						if(pLevel->fColor[pFieldSideQuadT->iPoint[i]][A] != 1.0f)
						{
							bBlended = TRUE;
							break;
						}
					}
				}
				if(pFieldSurfaceT->pSurface &&
				   pFieldSurfaceT->pSurface->iTextureID[pFieldSurfaceT->iCurrentAniStep] == iTexture &&
				   bBlended)
					*(pFieldSurfaceTextureT++) = pFieldSurfaceT; // Add this side:
				pFieldSurfaceT = &pFieldSideT->Surface[1];
				if(_ASConfig->bMultitexturing && pFieldSurfaceT->pSurface &&
				   pFieldSurfaceT->pSurface->iTextureID[pFieldSurfaceT->iCurrentAniStep] == iTexture)
					*(pFieldSurfaceTextureT++) = pFieldSurfaceT; // Add this side:
			}
		}
		*(pFieldSurfaceTextureT++) = NULL;
	}
} // end FIELD_SIDE_LIST::Build()
///////////////////////////////////////////////////////////////////////////////


// QUADTREE functions: ********************************************************
QUADTREE::QUADTREE(void)
{ // begin QUADTREE::QUADTREE()
	memset(this, 0, sizeof(QUADTREE));
} // end QUADTREE::QUADTREE()

QUADTREE::~QUADTREE(void)
{ // begin QUADTREE::~QUADTREE()
} // end QUADTREE::~QUADTREE()

// Create the quatree for a level:
void QUADTREE::Build(void *pLevelT)
{ // begin QUADTREE::Build()
	LEVEL *pLevel = (LEVEL *) pLevelT;
	QUADTREE *pChildT;
	int iX, iY, iChild, iCurrentChild,
		iHalfFieldsX, iHalfFieldsY;
	float fHalfFieldsX, fHalfFieldsY;

	// Setup quadtree information:
	if(!pParent)
	{ // That's the topmost quadtree:
		iStartX = iStartY = 0;
		iFieldsX = pLevel->Header.iWidth-1;
		iFieldsY = pLevel->Header.iHeight-1;
		iFields = iFieldsX*iFieldsY;
		pField = (FIELD **) malloc(sizeof(FIELD)*iFields);
		memset(pField, 0, sizeof(FIELD)*iFields);
	}

	// Setup field pointers:
	for(iY = 0; iY < iFieldsY; iY++)
		for(iX = 0; iX < iFieldsX; iX++)
			pField[iX+iY*iFieldsX] = &pLevel->pField[(iStartX+iX)+(iStartY+iY)*pLevel->Header.iWidth];

	iChildren = 0;
	if(iFieldsX > 3)
		iChildren += 2;
	if(iFieldsY > 3)
		iChildren += 2;
	if(iChildren)
	{
		pChild = (QUADTREE *) malloc(sizeof(QUADTREE)*iChildren);
		memset(pChild, 0, sizeof(QUADTREE)*iChildren);
		
		// Create the children:
		if(iFieldsX > 3)
		{
			iHalfFieldsX = iFieldsX/2;
			fHalfFieldsX = (float) iFieldsX/2;
		}
		else
		{
			iHalfFieldsX = iFieldsX;
			fHalfFieldsX = (float) iFieldsX;
		}
		if(iFieldsY > 3)
		{
			iHalfFieldsY = iFieldsY/2;
			fHalfFieldsY = (float) iFieldsY/2;
		}
		else
		{
			iHalfFieldsY = iFieldsY;
			fHalfFieldsY = (float) iFieldsY;
		}
		iCurrentChild = 0;
		pChildT = &pChild[iCurrentChild];
		pChildT->pParent = this;
		pChildT->iStartX = iStartX;
		pChildT->iStartY = iStartY;
		pChildT->iFieldsX = iHalfFieldsX;
		pChildT->iFieldsY = iHalfFieldsY;
		iCurrentChild++;
		if(iFieldsX > 3)
		{
			pChildT = &pChild[iCurrentChild];
			pChildT->pParent = this;
			pChildT->iStartX = iStartX+iHalfFieldsX;
			pChildT->iStartY = iStartY;
			pChildT->iFieldsX = iFieldsX-iHalfFieldsX;
			pChildT->iFieldsY = iHalfFieldsY;
			iCurrentChild++;
		}
		if(iFieldsY > 3)
		{
			if(iFieldsX > 3)
			{
				pChildT = &pChild[iCurrentChild];
				pChildT->pParent = this;
				pChildT->iStartX = iStartX+iHalfFieldsX;
				pChildT->iStartY = iStartY+iHalfFieldsY;
				pChildT->iFieldsX = iFieldsX-iHalfFieldsX;
				pChildT->iFieldsY = iFieldsY-iHalfFieldsY;
				iCurrentChild++;
			}
			pChildT = &pChild[iCurrentChild];
			pChildT->pParent = this;
			pChildT->iStartX = iStartX;
			pChildT->iStartY = iStartY+iHalfFieldsY;
			pChildT->iFieldsX = iHalfFieldsX;
			pChildT->iFieldsY = iFieldsY-iHalfFieldsY;
		}

		// Setup children:
		for(iChild = 0; iChild < iChildren; iChild++)		
		{
			pChildT = &pChild[iChild];
			if(pChildT->iStartX+pChildT->iFieldsX > pLevel->Header.iWidth-1)
				pChildT->iFieldsX = pChildT->iStartX+pChildT->iFieldsX-pLevel->Header.iWidth-1;
			if(pChildT->iStartY+pChildT->iFieldsY > pLevel->Header.iHeight-1)
				pChildT->iFieldsY = pChildT->iStartY+pChildT->iFieldsY-pLevel->Header.iHeight-1;
			pChildT->iFields = pChildT->iFieldsX*pChildT->iFieldsY;
			pChildT->pField = (FIELD **) malloc(sizeof(FIELD)*pChildT->iFields);
			memset(pChildT->pField, 0, sizeof(FIELD)*pChildT->iFields);
						
			// Build child quadtrees of this child quadtree:
			pChildT->Build(pLevelT);
		}
	}
	else
		iChildren = 0;
	if(!pParent)
	{
		GetBoundingBox(pLevelT);
		SetNotInFOV();
	}
} // end QUADTREE::Build()

void QUADTREE::Destroy(void)
{ // begin QUADTREE::Destroy()
	SAFE_DELETE(pField);
	for(int iChild = 0; iChild < iChildren; iChild++)
		pChild[iChild].Destroy();
	SAFE_DELETE(pChild);
	memset(this, 0, sizeof(QUADTREE));
} // end QUADTREE::Destroy()

void QUADTREE::SetNotInFOV(void)
{ // begin QUADTREE::SetNotInFOV()
	bInFOV = FALSE;
	for(int iChild = 0; iChild < iChildren; iChild++)
		pChild[iChild].SetNotInFOV();
} // end QUADTREE::SetNotInFOV()

void QUADTREE::CheckInFOV(void)
{ // begin QUADTREE::CheckInFOV()
	if(!pParent) // Topmost quadtree:
		SetNotInFOV();

	// Check if this quadtree is in the FOV:
	if(!ASCubeInFrustum(fBoundingBox[MIN][X], fBoundingBox[MAX][X],
						fBoundingBox[MIN][Y], fBoundingBox[MAX][Y],
						fBoundingBox[MIN][Z], fBoundingBox[MAX][Z]))
		return; // Not visible!
	
	// It's visible, check now the child quadtrees:
	bInFOV = TRUE;
	for(int iChild = 0; iChild < iChildren; iChild++)
		pChild[iChild].CheckInFOV();
} // end QUADTREE::CheckInFOV()

void QUADTREE::SetFieldsInFOV(void)
{ // begin QUADTREE::SetFieldsInFOV()
	for(int i = 0; i < iFields; i++)
		pField[i]->bOnScreen = TRUE;
} // end QUADTREE::SetFieldsInFOV()

void QUADTREE::CheckFieldsInFOV(void)
{ // begin QUADTREE::CheckFieldsInFOV()
	if(!pParent) // Main quadtree:
		SetFieldsInFOV();

	// Is this quadtree invisible?
	if(!bInFOV)
	{ // Nope, all fields in it are not visible:
		for(int i = 0; i < iFields; i++)
		{
			if(!pField[i])
				continue;
			pField[i]->bOnScreen = FALSE;
		}
		return;
	}

	// Check, if it's complete in the field of view:
	if(ASPointInFrustum(fBoundingBox[MIN][X], fBoundingBox[MIN][Y], fBoundingBox[MIN][Z]) &&
	   ASPointInFrustum(fBoundingBox[MAX][X], fBoundingBox[MIN][Y], fBoundingBox[MIN][Z]) &&
	   ASPointInFrustum(fBoundingBox[MAX][X], fBoundingBox[MAX][Y], fBoundingBox[MIN][Z]) &&
	   ASPointInFrustum(fBoundingBox[MIN][X], fBoundingBox[MAX][Y], fBoundingBox[MIN][Z]) &&
	   ASPointInFrustum(fBoundingBox[MIN][X], fBoundingBox[MIN][Y], fBoundingBox[MAX][Z]) &&
	   ASPointInFrustum(fBoundingBox[MAX][X], fBoundingBox[MIN][Y], fBoundingBox[MAX][Z]) &&
	   ASPointInFrustum(fBoundingBox[MAX][X], fBoundingBox[MAX][Y], fBoundingBox[MAX][Z]) &&
	   ASPointInFrustum(fBoundingBox[MIN][X], fBoundingBox[MAX][Y], fBoundingBox[MAX][Z]))
		return;  // Yep, it's complete in the FOV:
		
	if(!iChildren)
	{ // There are no children, check now each field itself:
		FIELD *pFieldT;
		
		for(int i = 0; i < iFields; i++)
		{
			pFieldT = pField[i];
			if(!pFieldT)
				continue;
			if(!ASCubeInFrustum(pFieldT->fBoundingBox[MIN][X], pFieldT->fBoundingBox[MAX][X],
							    pFieldT->fBoundingBox[MIN][Y], pFieldT->fBoundingBox[MAX][Y],
							    pFieldT->fBoundingBox[MIN][Z], pFieldT->fBoundingBox[MAX][Z]))
				pField[i]->bOnScreen = FALSE;
		}
		return;
	}

	for(int iChild = 0; iChild < iChildren; iChild++)
		pChild[iChild].CheckFieldsInFOV();
} // end QUADTREE::CheckFieldsInFOV()

// Get's the bounding box of the quadtree:
void QUADTREE::GetBoundingBox(void *pLevelT)
{ // begin QUADTREE::GetBoundingBox()
	LEVEL *pLevel = (LEVEL *) pLevelT;
	FIELD *pFieldT;
	int i, iField;

	if(!pField)
		return;

	// Initialize bounding box:
	fBoundingBox[MIN][X] = fBoundingBox[MIN][Y] = fBoundingBox[MIN][Z] = 1000.0f;
	fBoundingBox[MAX][X] = fBoundingBox[MAX][Y] = fBoundingBox[MAX][Z] = -1000.0f;

	// Get bounding box:
	for(iField = 0; iField < iFields; iField++)
	{
		if(!(pFieldT = pField[iField]))
			continue;
		for(i = 0; i < 3; i++)
		{
			if(fBoundingBox[MIN][i] > pFieldT->fBoundingBox[MIN][i])
				fBoundingBox[MIN][i] = pFieldT->fBoundingBox[MIN][i];
			if(fBoundingBox[MAX][i] < pFieldT->fBoundingBox[MAX][i])
				fBoundingBox[MAX][i] = pFieldT->fBoundingBox[MAX][i];
		}
	}

	// Get children bounding boxes:
	for(int iChild = 0; iChild < iChildren; iChild++)
		pChild[iChild].GetBoundingBox(pLevelT);
} // end QUADTREE::GetBoundingBox()

// Draw the bounding boxes:
void QUADTREE::ShowBoundingBox(void)
{ // begin QUADTREE::ShowBoundingBox()
	if(!_ASConfig->bShowQuadtrees)
		return;

	// Draw children bounding boxes:
	for(int iChild = 0; iChild < iChildren; iChild++)
		pChild[iChild].ShowBoundingBox();

	if(!pParent)
		glColor3f(1.0f, 0.0f, 1.0f);
	else
		glColor3f(1.0f, 1.0f, 1.0f);

	ASDrawBoundingBox(fBoundingBox);
} // end QUADTREE::ShowBoundingBox()
///////////////////////////////////////////////////////////////////////////////


// LEVEL functions: ***********************************************************
// Checks whats on screen and what not:
void LEVEL::UpdateVisibilityInformation(void)
{ // begin LEVEL::UpdateVisibilityInformation()
	int i, i2, iField, iQuad, iPoint, iCurrentPointT;
	FIELD_SIDE_QUAD *pFieldSideQuadT;
	FIELD_DECORATION *pDecorationT;
	FIELD_SIDE *pFieldSideT;
	AS_MD2_MODEL *pModelT;	
	BOOL bUpdateT = FALSE;
	FIELD *pFieldT;

	if(_ASConfig->bFrustumCulling)
	{ // Check if the camera has been changed:
		if(bForceVisiblityUpdate || 
		   pCamera->fPos[X] != LevelTempCamera.fPos[X] ||
		   pCamera->fPos[Y] != LevelTempCamera.fPos[Y] ||
		   pCamera->fPos[Z] != LevelTempCamera.fPos[Z] ||
		   pCamera->fRot[X] != LevelTempCamera.fRot[X] ||
		   pCamera->fRot[Y] != LevelTempCamera.fRot[Y] ||
		   pCamera->fRot[Z] != LevelTempCamera.fRot[Z] ||
		   pCamera->fStretch[X] != LevelTempCamera.fStretch[X] ||
		   pCamera->fStretch[Y] != LevelTempCamera.fStretch[Y] ||
		   pCamera->fFOV != LevelTempCamera.fFOV ||
		   (pPlayer && pPlayer->fWorldPos[Z] != fPlayerTempZPos) ||
		   bUnderWater)
		{
			bForceVisiblityUpdate = FALSE;
			for(i = 0; i < 3; i++)
			{
				LevelTempCamera.fPos[i] = pCamera->fPos[i];
				LevelTempCamera.fRot[i] = pCamera->fRot[i];
			}
			LevelTempCamera.fStretch[X] = pCamera->fStretch[X];
			LevelTempCamera.fStretch[Y] = pCamera->fStretch[Y];
			LevelTempCamera.fFOV = pCamera->fFOV;
			if(pPlayer)
				fPlayerTempZPos = pPlayer->fWorldPos[Z];
			Quadtree.CheckInFOV();
			Quadtree.CheckFieldsInFOV();
			bUpdateT = TRUE;
		}
	}
	else
	{
		for(i = 0; i < Header.iFields; i++)
			pField[i].bOnScreen = TRUE;
		bUpdateT = TRUE;
	}
	CheckIfActorsOnScreen();

	if(!bUpdateT)
		return;

	// Get the pointers to the visible fields and points:
	memset(bWaterPointVisible, 0, sizeof(BOOL)*Header.iLevelPoints);
	for(iField = i = iPoint = 0; iField < Header.iFields; iField++)
	{
		pFieldT = &pField[iField];
		if(!pFieldT || !pFieldT->bOnScreen || pFieldT->iXField == Header.iWidth-1 ||
		   pFieldT->iYField == Header.iHeight-1)
			continue;
		pInFOVFields[i++] = pFieldT;
		if(!pFieldT->bActivateWater)
			continue;
		pFieldSideT = &pFieldT->Side[FACE_FLOOR];
		for(iQuad = 0; iQuad < 4; iQuad++)
		{
			pFieldSideQuadT = &pFieldSideT->SideQuad[iQuad];
			for(i2 = 0; i2 < 4; i2++)
			{
				iCurrentPointT = pFieldSideQuadT->iPoint[i2];
				if(bWaterPointVisible[iCurrentPointT])
					continue;
				bWaterPointVisible[iCurrentPointT] = TRUE;
				iVisibleWaterPoints[iPoint] = iCurrentPointT;
				iPoint++;
			}
		}
	}
	pInFOVFields[i] = NULL;
	iVisibleWaterPoints[iPoint] = -1;

	FieldSideList.Build(this);

	// Check which decorations are in the FOV:
	for(i = 0; i < Header.iFields; i++)
	{
		if(!(pFieldT = pDecorationFieldList[i]))
			break;
		if(!(pDecorationT = pFieldT->pDecoration))
			continue;
		if(!(pModelT = pDecorationModels[pDecorationT->iDecorationID].pModel))
			continue;
		if(!ASCubeInFrustum(pDecorationT->fModelBoundingBox[MIN][X]+pDecorationT->fPos[X], pDecorationT->fModelBoundingBox[MAX][X]+pDecorationT->fPos[X],
							pDecorationT->fModelBoundingBox[MIN][Y]+pDecorationT->fPos[Y], pDecorationT->fModelBoundingBox[MAX][Y]+pDecorationT->fPos[Y],
							pDecorationT->fModelBoundingBox[MIN][Z]+pDecorationT->fPos[Z], pDecorationT->fModelBoundingBox[MAX][Z]+pDecorationT->fPos[Z]))
			pDecorationT->bOnScreen = FALSE;
		else
			pDecorationT->bOnScreen = TRUE;
	}
} // end LEVEL::UpdateVisibilityInformation()
///////////////////////////////////////////////////////////////////////////////
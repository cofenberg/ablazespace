//-----------------------------------------------------------------------------
// File: Decoration.h
//-----------------------------------------------------------------------------

#ifndef __DECORATION_H__
#define __DECORATION_H__


// Structures: ****************************************************************
typedef struct DECORATION_INFO
{
	int iModel; // The ID of the used model
	int iTexture; // The ID of the used texture
	int iAnimation; // The used animation of the model

} DECORATION_INFO;

typedef struct DECORATION_MODEL
{
	char byFilename[256];
	AS_MD2_MODEL *pModel;

} DECORATION_MODEL;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern DECORATION_MODEL *pDecorationModels;
extern int iDecorationModels;
extern int iCurrentDecorationModel,
		   iCurrentModelTexture,
		   iCurrentDecorationModelAnimation,
		   iDecorationCurrentAniStep,
		   iDecorationModelSpeed;
extern BOOL bDecorationModelAnimated;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern void DestroyAllDecorations(void);
extern LRESULT CALLBACK DecorationProc(HWND, UINT, WPARAM, LPARAM);
///////////////////////////////////////////////////////////////////////////////


#endif // __DECORATION_H__
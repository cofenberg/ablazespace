//-----------------------------------------------------------------------------
// File: EditorSelection.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
HWND hWndEditorSelectTab[EDITOR_SELECT_TABS]; // The tab handles
int iCurrentEditorSelectTab;	 // The current selected tab
int TAB_EDITOR_SELECT_SCRIPTS = -1,
	TAB_EDITOR_SELECT_BEAMER = -1,
	TAB_EDITOR_SELECT_DECORATION = -1,
	TAB_EDITOR_SELECT_ITEM = -1,
	TAB_EDITOR_SELECT_BOX = -1,
	TAB_EDITOR_SELECT_ACTOR = -1,
	TAB_EDITOR_SELECT_BLIBS = -1,
	TAB_EDITOR_SELECT_ENEMY = -1;
int *iEditorSelectTabsPointer[EDITOR_SELECT_TABS] =
{
	&TAB_EDITOR_SELECT_SCRIPTS,
	&TAB_EDITOR_SELECT_BEAMER,
	&TAB_EDITOR_SELECT_DECORATION,
	&TAB_EDITOR_SELECT_ITEM,
	&TAB_EDITOR_SELECT_BOX,
	&TAB_EDITOR_SELECT_ACTOR,
	&TAB_EDITOR_SELECT_BLIBS,
	&TAB_EDITOR_SELECT_ENEMY,
};
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
LRESULT CALLBACK EditorSelectScriptsProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditorSelectBeamerProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditorSelectDecorationProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditorSelectItemProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditorSelectBoxProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditorSelectActorProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditorSelectBlibsProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditorSelectEnemyProc(HWND, UINT, WPARAM, LPARAM);
void SetupEditorSelectTabs(void);
///////////////////////////////////////////////////////////////////////////////


LRESULT CALLBACK EditorSelectScriptsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorSelectScriptsProc()
	char byTemp[256];
	FIELD *pFieldT;
	int i;
	
	if(!pLevel)
		return 0;
	pFieldT = pLevel->pCurrentField;
	if(pFieldLast != pFieldT)
	{
		pFieldLast = pFieldT;
		goto Init;
	}
	if(!pFieldT)
		return 0;
	switch(iMessage)
    {
        case WM_INITDIALOG:
		// Texts:
			SetDlgItemText(hWnd, IDD_EDITOR_SELECT_CAMERA, AS_T(T_Camera));
			SetDlgItemText(hWnd, IDD_EDITOR_SELECT_CAMERA_ALWAYS, AS_T(T_Always));
			SetDlgItemText(hWnd, IDD_EDITOR_SELECT_TEXT_SCRIPT, AS_T(T_TextScript));
			SetDlgItemText(hWnd, IDD_EDITOR_SELECT_TEXT_SCRIPT_ALWAYS, AS_T(T_Always));
			SetDlgItemText(hWnd, IDD_EDITOR_SELECT_TEXT_SCRIPT_SET, AS_T(T_Set));
			SetDlgItemText(hWnd, IDD_EDITOR_SELECT_TEXT_SCRIPT_ACTION_KEY, AS_T(T_ActionKey));
			SetDlgItemText(hWnd, IDD_EDITOR_SELECT_CHANGE_WATER_HEIGHT, AS_T(T_ChangeWaterHeight));
			SetDlgItemText(hWnd, IDD_EDITOR_SELECT_CHANGE_WATER_PRESSED, AS_T(T_Pressed));
			SetDlgItemText(hWnd, IDD_EDITOR_SELECT_CHANGE_WATER_NOT_PRESSED, AS_T(T_NotPressed));

			SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_LIST, CB_RESETCONTENT, 0, 0L);
			SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_LIST, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Floor));
			SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_LIST, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Top));
			SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_LIST, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Left));
			SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_LIST, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Right));
			SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_LIST, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Bottom));
			SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_LIST, CB_SETCURSEL, 0, 0L);

  		Init:
			SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_CAMERA_LIST, CB_RESETCONTENT, 0, 0L);
			for(i = 0; i < pLevel->Header.iCameraScripts; i++)
			{
				sprintf(byTemp, "%s", pLevel->pCameraScript[i].byName);
				SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_CAMERA_LIST, CB_ADDSTRING, 0, (LPARAM) byTemp);
			}
			SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_CAMERA_LIST, CB_SETCURSEL, pFieldT->iCamera, 0L);
			if(pFieldT->iCamera == -1)
			{
				SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_CAMERA, BM_SETCHECK, FALSE, 0L);
				EnableWindow(GetDlgItem(hWnd, IDD_EDITOR_SELECT_CAMERA_ALWAYS), FALSE);
				EnableWindow(GetDlgItem(hWnd, IDD_EDITOR_SELECT_CAMERA_LIST), FALSE);
			}
			else
			{
				SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_CAMERA, BM_SETCHECK, TRUE, 0L);
				EnableWindow(GetDlgItem(hWnd, IDD_EDITOR_SELECT_CAMERA_ALWAYS), TRUE);
				EnableWindow(GetDlgItem(hWnd, IDD_EDITOR_SELECT_CAMERA_LIST), TRUE);
			}
			SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_CAMERA_ALWAYS, BM_SETCHECK, pFieldT->bCameraAlways, 0L);
			
			// Text script:
			i = SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_LIST, CB_GETCURSEL, 0, 0L);
			if(i < 0 || i > 5)
				i = 0;
			SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_TEXT_SCRIPT, BM_SETCHECK, pFieldT->bTextScript[i], 0L);
			SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_TEXT_SCRIPT_ALWAYS, BM_SETCHECK, pFieldT->bTextScriptAlways[i], 0L);
			SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_TEXT_SCRIPT_ACTION_KEY, BM_SETCHECK, pFieldT->bTextScriptActionKey[i], 0L);
			pLevel->TextScriptManager.FillTextScriptView(pFieldT->pTextScript[i], hWnd, IDD_EDITOR_SELECT_TEXT_SCRIPT_T);

			SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_CHANGE_WATER_HEIGHT, BM_SETCHECK, pFieldT->bWaterChangeHeight, 0L);
			SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_CHANGE_WATER_PRESSED, BM_SETCHECK, pFieldT->bWaterChangePressed, 0L);
			sprintf(byTemp, "%f", pFieldT->fWaterChangeHeightTo);
			SetDlgItemText(hWnd, IDD_EDITOR_SELECT_CHANGE_WATER_HEIGHT_TO, byTemp);
			sprintf(byTemp, "%f", pFieldT->fWaterChangeSpeed);
			SetDlgItemText(hWnd, IDD_EDITOR_SELECT_CHANGE_WATER_HEIGHT_SPEED, byTemp);

			SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_CHANGE_WATER_NOT_PRESSED, BM_SETCHECK, pFieldT->bWaterChangeNotPressed, 0L);
			sprintf(byTemp, "%f", pFieldT->fWaterChangeNotHeightTo);
			SetDlgItemText(hWnd, IDD_EDITOR_SELECT_CHANGE_WATER_NOT_HEIGHT_TO, byTemp);
			sprintf(byTemp, "%f", pFieldT->fWaterChangeNotSpeed);
			SetDlgItemText(hWnd, IDD_EDITOR_SELECT_CHANGE_WATER_NOT_HEIGHT_SPEED, byTemp);

			BringWindowToTop(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDD_EDITOR_SELECT_CAMERA_LIST:
					i = (int) SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_CAMERA_LIST, CB_GETCURSEL, 0, 0L);
					if(i < 0 || i >= pLevel->Header.iCameraScripts)
						break;
					pFieldT->iCamera = i;
				break;
				
				case IDD_EDITOR_SELECT_CAMERA:
					i = (int) SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_CAMERA, BM_GETCHECK, 0, 0L);
					if(!i)
						pFieldT->iCamera = -1;
					else
					{
						if(pLevel->Header.iCameraScripts >= 1)
							pFieldT->iCamera = 0;
						else
							pFieldT->iCamera = -1;
					}
					goto Init;

				case IDD_EDITOR_SELECT_CAMERA_ALWAYS: pFieldT->bCameraAlways = SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_CAMERA_ALWAYS, BM_GETCHECK, 0, 0L); break;

				case IDD_EDITOR_SELECT_LIST: goto Init;

				case IDD_EDITOR_SELECT_TEXT_SCRIPT:
					i = SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_LIST, CB_GETCURSEL, 0, 0L);
					if(i < 0 || i > 5)
						break;
					pFieldT->bTextScript[i] = SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_TEXT_SCRIPT, BM_GETCHECK, 0, 0L);
				break;

				case IDD_EDITOR_SELECT_TEXT_SCRIPT_ALWAYS:
					i = SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_LIST, CB_GETCURSEL, 0, 0L);
					if(i < 0 || i > 5)
						break;
					pFieldT->bTextScriptAlways[i] = SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_TEXT_SCRIPT_ALWAYS, BM_GETCHECK, 0, 0L);
				break;

				case IDD_EDITOR_SELECT_TEXT_SCRIPT_ACTION_KEY:
					i = SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_LIST, CB_GETCURSEL, 0, 0L);
					if(i < 0 || i > 5)
						break;
					pFieldT->bTextScriptActionKey[i] = SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_TEXT_SCRIPT_ACTION_KEY, BM_GETCHECK, 0, 0L);
				break;
				
				case IDD_EDITOR_SELECT_TEXT_SCRIPT_SET:
					bGetFieldTextScript = TRUE;
					OpenTSE(hWndEditor);
				break;

				case IDD_EDITOR_SELECT_CHANGE_WATER_HEIGHT: pFieldT->bWaterChangeHeight = SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_CHANGE_WATER_HEIGHT, BM_GETCHECK, 0, 0L); break;

				case IDD_EDITOR_SELECT_CHANGE_WATER_PRESSED:
					pFieldT->bWaterChangePressed = SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_CHANGE_WATER_PRESSED, BM_GETCHECK, 0, 0L);
					pLevel->GetTriggerList();
				break;

				case IDD_EDITOR_SELECT_CHANGE_WATER_HEIGHT_TO:
					GetDlgItemText(hWnd, IDD_EDITOR_SELECT_CHANGE_WATER_HEIGHT_TO, byTemp, 256);
					pFieldT->fWaterChangeHeightTo = (float) atof(byTemp);
				break;

				case IDD_EDITOR_SELECT_CHANGE_WATER_HEIGHT_SPEED:
					GetDlgItemText(hWnd, IDD_EDITOR_SELECT_CHANGE_WATER_HEIGHT_SPEED, byTemp, 256);
					pFieldT->fWaterChangeSpeed = (float) atof(byTemp);
				break;

				case IDD_EDITOR_SELECT_CHANGE_WATER_NOT_PRESSED:
					pFieldT->bWaterChangeNotPressed = SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_CHANGE_WATER_NOT_PRESSED, BM_GETCHECK, 0, 0L);
					pLevel->GetTriggerList();
				break;

				case IDD_EDITOR_SELECT_CHANGE_WATER_NOT_HEIGHT_TO:
					GetDlgItemText(hWnd, IDD_EDITOR_SELECT_CHANGE_WATER_NOT_HEIGHT_TO, byTemp, 256);
					pFieldT->fWaterChangeNotHeightTo = (float) atof(byTemp);
				break;

				case IDD_EDITOR_SELECT_CHANGE_WATER_NOT_HEIGHT_SPEED:
					GetDlgItemText(hWnd, IDD_EDITOR_SELECT_CHANGE_WATER_NOT_HEIGHT_SPEED, byTemp, 256);
					pFieldT->fWaterChangeNotSpeed = (float) atof(byTemp);
				break;
            }
            break;
    }
    return FALSE;
} // end EditorSelectScriptsProc()

LRESULT CALLBACK EditorSelectBeamerProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorSelectBeamerProc()
	char byTemp[256];
	FIELD *pFieldT;
	
	if(!pLevel)
		return 0;
	pFieldT = pLevel->pCurrentField;
	if(pFieldLast != pFieldT)
	{
		pFieldLast = pFieldT;
		goto Init;
	}
	if(!pFieldT)
		return 0;
	switch(iMessage)
    {
        case WM_INITDIALOG:
		// Texts:
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_BEAMER_ENERGY_T, AS_T(T_Energy));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_BEAMER_SPEED_T, AS_T(T_Speed));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_BEAMER_TARGET, AS_T(T_Target));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_BEAMER_T, AS_T(T_Beamer));

  		Init:
			sprintf(byTemp, "%f", pFieldT->fBeamerPower);
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_BEAMER_ENERGY, byTemp);
			sprintf(byTemp, "%d", pFieldT->iBeamerRegenerationSpeed);
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_BEAMER_SPEED, byTemp);

			BringWindowToTop(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_EDITOR_SELECT_BEAMER_ENERGY:
					GetDlgItemText(hWnd, IDC_EDITOR_SELECT_BEAMER_ENERGY, byTemp, 256);
					pFieldT->fBeamerPower = (float) atof(byTemp);
				break;

				case IDC_EDITOR_SELECT_BEAMER_SPEED:
					GetDlgItemText(hWnd, IDC_EDITOR_SELECT_BEAMER_SPEED, byTemp, 256);
					pFieldT->iBeamerRegenerationSpeed = atoi(byTemp);
				break;

				case IDC_EDITOR_SELECT_BEAMER_TARGET: byEditorSelected = EDITOR_SELECTED_BEAMER_TARGET; break;
            }
            break;
    }
    return FALSE;
} // end EditorSelectBeamerProc()

LRESULT CALLBACK EditorSelectDecorationProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorSelectDecorationProc()
	FIELD *pFieldT;
	
	if(!pLevel)
		return 0;
	pFieldT = pLevel->pCurrentField;
	if(pFieldLast != pFieldT)
	{
		pFieldLast = pFieldT;
		goto Init;
	}
	if(!pFieldT)
		return 0;

	switch(iMessage)
    {
        case WM_INITDIALOG:
		// Texts:
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_DECORATION_POSITION, AS_T(T_Position));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_DECORATION_ROTATION, AS_T(T_Rotation));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_DECORATION_COLOR, AS_T(T_Color));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_DECORATION_DENSITY, AS_T(T_Density));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_DECORATION_SIZE, AS_T(T_Size));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_DECORATION_MODEL_T, AS_T(T_Model));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_DECORATION_MODEL_INVISIBLE_T, AS_T(T_Invisible));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_DECORATION_MODEL_VISIBLE_FRONT, AS_T(T_Front));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_DECORATION_MODEL_VISIBLE_BACK, AS_T(T_Back));

  		Init:
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_DECORATION_MODEL_VISIBLE_FRONT, BM_SETCHECK, pFieldT->pDecoration->bCullFront, 0L);
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_DECORATION_MODEL_VISIBLE_BACK, BM_SETCHECK, pFieldT->pDecoration->bCullBack, 0L);

			BringWindowToTop(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_EDITOR_SELECT_DECORATION_POSITION: byEditorSelected = EDITOR_SELECTED_DECORATION_POSITION; break;
				case IDC_EDITOR_SELECT_DECORATION_ROTATION: byEditorSelected = EDITOR_SELECTED_DECORATION_ROTATION; break;
				case IDC_EDITOR_SELECT_DECORATION_COLOR: byEditorSelected = EDITOR_SELECTED_DECORATION_COLOR; break;
				case IDC_EDITOR_SELECT_DECORATION_DENSITY: byEditorSelected = EDITOR_SELECTED_DECORATION_DENSITY; break;
				case IDC_EDITOR_SELECT_DECORATION_SIZE: byEditorSelected = EDITOR_SELECTED_DECORATION_SIZE; break;
				case IDC_EDITOR_SELECT_DECORATION_MODEL_VISIBLE_FRONT: pFieldT->pDecoration->bCullFront = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_DECORATION_MODEL_VISIBLE_FRONT, BM_GETCHECK, 0, 0L); break;
				case IDC_EDITOR_SELECT_DECORATION_MODEL_VISIBLE_BACK: pFieldT->pDecoration->bCullBack = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_DECORATION_MODEL_VISIBLE_BACK, BM_GETCHECK, 0, 0L); break;
            }
            break;
    }
    return FALSE;
} // end EditorSelectDecorationProc()

LRESULT CALLBACK EditorSelectItemProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorSelectItemProc()
	ITEM_INFO *pItemT = NULL;
	char byTemp[256];
	FIELD *pFieldT;
	ACTOR *pActorT;
	int i;
	
	if(!pLevel)
		return 0;
	pFieldT = pLevel->pCurrentField;
	if(pFieldLast != pFieldT)
	{
		if(!(pActorT = pFieldT->pActor))
			return 0;
		if(pActorT->Type == AT_CHEST_ITEM)
			pItemT = &pActorT->Item[0];
		pFieldLast = pFieldT;
		goto Init;
	}
	if(!pFieldT || !(pActorT = pFieldT->pItem))
		return 0;
	if(pActorT->Type == AT_CHEST_ITEM)
		pItemT = &pActorT->Item[0];
	switch(iMessage)
    {
        case WM_INITDIALOG:
		// Texts:
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_ITEM_NAME_T, AS_T(T_Name));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_ITEM_NUMBER_T, AS_T(T_Number));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_ITEM_MOVE, AS_T(T_Move));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_ITEM_ROTATION, AS_T(T_Rotation));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_ITEM_COLOR, AS_T(T_Color));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_ITEM_NUMBER_UNLIMITED, AS_T(T_Unlimited));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_ITEM_SHADOW, AS_T(T_Shadow));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_ITEM_TORCH, AS_T(T_Torch));
			if(pItemT)
			{
				ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_ITEM_LIST), TRUE);
				FillItemListElement(hWnd, IDC_EDITOR_SELECT_ITEM_LIST);
			}
			else
				ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_ITEM_LIST), FALSE);

  		Init:
			sprintf(byTemp, "%s", pActorT->byName);
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_ITEM_NAME, byTemp);

			i = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ITEM_LIST, CB_GETCURSEL, 0, 0L);
			i = (int) SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ITEM_LIST, CB_GETITEMDATA, i, 0L);
			if(i < 0 || i > ITEMS)
				i = 0;
			if(!pItemT)
				sprintf(byTemp, "%d", pActorT->iNumber);
			else
				sprintf(byTemp, "%d", pItemT[i].iNumber);
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_ITEM_NUMBER, byTemp);
			if(!pItemT)
				SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ITEM_NUMBER_UNLIMITED, BM_SETCHECK, pActorT->bNumberUnlimited, 0L);
			else
				SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ITEM_NUMBER_UNLIMITED, BM_SETCHECK, pItemT[i].bUnlimited, 0L);
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ITEM_SHADOW, BM_SETCHECK, pActorT->bShadow, 0L);
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ITEM_TORCH, BM_SETCHECK, pActorT->bTorch, 0L);

			BringWindowToTop(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_EDITOR_SELECT_ITEM_LIST: goto Init;

				case IDC_EDITOR_SELECT_ITEM_NUMBER:
					i = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ITEM_LIST, CB_GETCURSEL, 0, 0L);
					i = (int) SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ITEM_LIST, CB_GETITEMDATA, i, 0L);
					if(i < 0 || i > ITEMS)
						i = 0;
					GetDlgItemText(hWnd, IDC_EDITOR_SELECT_ITEM_NUMBER, byTemp, 256);
					if(!pItemT)
						pActorT->iNumber = atoi(byTemp);
					else
						pItemT[i].iNumber = atoi(byTemp);
				break;

				case IDC_EDITOR_SELECT_ITEM_NUMBER_UNLIMITED:
					i = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ITEM_LIST, CB_GETCURSEL, 0, 0L);
					i = (int) SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ITEM_LIST, CB_GETITEMDATA, i, 0L);
					if(i < 0 || i > ITEMS)
						i = 0;
					if(!pItemT)
						pActorT->bNumberUnlimited = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ITEM_NUMBER_UNLIMITED, BM_GETCHECK, 0, 0L);
					else
						pItemT[i].bUnlimited = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ITEM_NUMBER_UNLIMITED, BM_GETCHECK, 0, 0L);
				break;

				case IDC_EDITOR_SELECT_ITEM_MOVE: byEditorSelected = EDITOR_SELECTED_ITEM_MOVE; break;
				case IDC_EDITOR_SELECT_ITEM_ROTATION: byEditorSelected = EDITOR_SELECTED_ITEM_ROTATION; break;
				case IDC_EDITOR_SELECT_ITEM_COLOR: byEditorSelected = EDITOR_SELECTED_ITEM_COLOR; break;
				case IDC_EDITOR_SELECT_ITEM_SHADOW: pActorT->bShadow = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ITEM_SHADOW, BM_GETCHECK, 0, 0L); break;
				case IDC_EDITOR_SELECT_ITEM_TORCH: pActorT->bTorch = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ITEM_TORCH, BM_GETCHECK, 0, 0L); break;
			}
            break;
    }

    return FALSE;
} // end EditorSelectItemProc()

LRESULT CALLBACK EditorSelectBoxProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorSelectBoxProc()
	char byTemp[256];
	FIELD *pFieldT;
	ACTOR *pActorT;
	char bySelecedSide;
	int i, iRotT, iShow;
	
	if(!pLevel)
		return 0;
	pFieldT = pLevel->pCurrentField;
	if(pFieldLast != pFieldT)
	{
		if(!(pActorT = pFieldT->pActor))
			return 0;
		pFieldLast = pFieldT;
		goto Init;
	}
	if(!pFieldT || !(pActorT = pFieldT->pActor))
		return 0;

	switch(iMessage)
    {
        case WM_INITDIALOG:
		// Texts:
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_BOX_SURFACES_T, AS_T(T_BoxSurfaces));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_BOX_SURFACE_ROTATION_T, AS_T(T_SurfaceRotation));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_BOX_SURFACE_ALL, AS_T(T_All));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_BOX_WEIGHT_T, AS_T(T_Weight));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_BOX_TYPE_T, AS_T(T_Type));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_BOX_ENVIRONMENT, AS_T(T_Environment));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_BOX_ENVIRONMENT_COLOR, AS_T(T_Color));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_BOX_ENVIRONMENT_DENSITY, AS_T(T_Density));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_BOX_USE_BOX_COLOR, AS_T(T_UseBoxColor));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_BOX_INDESTRUCTIBLE, AS_T(T_Indestructible));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_BOX_NITROGLYCERIN, AS_T(T_Nitroglycerin));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_BOX_COLLISION_DAMAGE, AS_T(T_CollisionDamage));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_BOX_THROWABLE, AS_T(T_Throwable));

			// Box sides:
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_SIDE, CB_RESETCONTENT, 0, 0L);
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_SIDE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Floor));
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_SIDE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Top));
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_SIDE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Left));
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_SIDE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Right));
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_SIDE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Bottom));
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_SIDE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Front));
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_SIDE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Environment));
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_SIDE, CB_SETCURSEL, 0, 0L);

  		Init:
			if(pActorT->iBoxSurface[6] == -1)
				SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_ENVIRONMENT, BM_SETCHECK, FALSE, 0L);
			else
				SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_ENVIRONMENT, BM_SETCHECK, TRUE, 0L);

			// Box:
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_BOX_SURFACE_ROTATION_T, AS_T(T_Box));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_BOX_SURFACE_ROTATION_T, AS_T(T_Rotation));
			sprintf(byTemp, "%d", pActorT->byBoxSurfaceRot[0]*90);
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_BOX_SURFACE_ROTATION, byTemp);

			// Box surfaces:
			bySelecedSide = (int) SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_SIDE, CB_GETCURSEL, 0, 0L);
			if(bySelecedSide == -1 || bySelecedSide > 6)
				break;
			if(bySelecedSide == 6)
			{
				EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_BOX_SIDE_SURFACE), SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_ENVIRONMENT, BM_GETCHECK, 0, 0L));
				iShow = SW_SHOW;
			}
			else
			{
				EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_BOX_SIDE_SURFACE), TRUE);
				iShow = SW_HIDE;
			}
			ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_BOX_ENVIRONMENT), iShow);
			ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_BOX_ENVIRONMENT_COLOR), iShow);
			ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_BOX_ENVIRONMENT_DENSITY), iShow);

			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_SIDE_SURFACE, CB_RESETCONTENT, 0, 0L);
			for(i = 0; i < pLevel->Header.iSurfaces; i++)
			{
				sprintf(byTemp, "%s", pLevel->pSurface[i].Header.byName, pLevel->pSurface[i].iUsed);
				SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_SIDE_SURFACE, CB_ADDSTRING, 0, (LPARAM) byTemp);
			}
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_SIDE_SURFACE, CB_SETCURSEL, pActorT->iBoxSurface[bySelecedSide], 0L);

			// Weight:
			sprintf(byTemp, "%f", pActorT->fWeight);
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_BOX_WEIGHT, byTemp);

			// Type:
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_TYPE, CB_RESETCONTENT , 0, 0L);
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_TYPE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_BoxNormal));
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_TYPE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_BoxRed));
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_TYPE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_BoxGreen));
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_TYPE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_BoxBlue));
			switch(pActorT->Type)
			{
				case AT_BOX_NORMAL: i = 0; break;
				case AT_BOX_RED: i = 1; break;
				case AT_BOX_GREEN: i = 2; break;
				case AT_BOX_BLUE: i = 3; break;
			}
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_TYPE, CB_SETCURSEL, i, 0L);
				
			// Use box color:
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_USE_BOX_COLOR, BM_SETCHECK, pActorT->bUseBoxColor, 0L);
			
			// Indesctuctible:
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_INDESTRUCTIBLE, BM_SETCHECK, pActorT->bIndestructible, 0L);

			// Nitroglycerin:
			if(pActorT->Type == AT_BOX_RED)
				ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_BOX_NITROGLYCERIN), SW_SHOW);
			else
				ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_BOX_NITROGLYCERIN), SW_HIDE);
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_NITROGLYCERIN, BM_SETCHECK, pActorT->bNitroglycerin, 0L);

			// Collision damage:
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_COLLISION_DAMAGE, BM_SETCHECK, pActorT->bCollisionDamage, 0L);
			
			// Throwable:
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_THROWABLE, BM_SETCHECK, pActorT->bThrowable, 0L);

			BringWindowToTop(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_EDITOR_SELECT_BOX_SIDE:
					goto Init;

				case IDC_EDITOR_SELECT_BOX_SIDE_SURFACE:
					i = (int) SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_SIDE_SURFACE, CB_GETCURSEL, 0, 0L);
					if(i == -1 || i >= pLevel->Header.iSurfaces)
						break;
					bySelecedSide = (int) SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_SIDE, CB_GETCURSEL, 0, 0L);
					if(bySelecedSide == -1 || bySelecedSide > 6)
						break;
					pActorT->iBoxSurface[bySelecedSide] = i;
				break;

				case IDC_EDITOR_SELECT_BOX_SURFACE_ALL:
					i = (int) SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_SIDE_SURFACE, CB_GETCURSEL, 0, 0L);
					if(i == -1 || i >= pLevel->Header.iSurfaces)
						break;
					GetDlgItemText(hWnd, IDC_EDITOR_SELECT_BOX_SURFACE_ROTATION, byTemp, 256);
					iRotT = atoi(byTemp);
					for(bySelecedSide = 0; bySelecedSide < 6; bySelecedSide++)
					{
						pActorT->iBoxSurface[bySelecedSide] = i;
						pActorT->byBoxSurfaceRot[bySelecedSide] = iRotT;
					}
				break;

				case IDC_EDITOR_SELECT_BOX_SURFACE_ROTATION_PLUS:
					bySelecedSide = (int) SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_SIDE, CB_GETCURSEL, 0, 0L);
					if(bySelecedSide == -1 || bySelecedSide > 6)
						break;
					pActorT->byBoxSurfaceRot[bySelecedSide]--;
					if(pActorT->byBoxSurfaceRot[bySelecedSide] < 0)
						pActorT->byBoxSurfaceRot[bySelecedSide] = 3;
					sprintf(byTemp, "%d", pActorT->byBoxSurfaceRot[bySelecedSide]*90);
					SetDlgItemText(hWnd, IDC_EDITOR_SELECT_BOX_SURFACE_ROTATION, byTemp);
				break;

				case IDC_EDITOR_SELECT_BOX_SURFACE_ROTATION_MINUS:
					bySelecedSide = (int) SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_SIDE, CB_GETCURSEL, 0, 0L);
					if(bySelecedSide == -1 || bySelecedSide > 6)
						break;
					pActorT->byBoxSurfaceRot[bySelecedSide]++;
					if(pActorT->byBoxSurfaceRot[bySelecedSide] > 3)
						pActorT->byBoxSurfaceRot[bySelecedSide] = 0;
					sprintf(byTemp, "%d", pActorT->byBoxSurfaceRot[bySelecedSide]*90);
					SetDlgItemText(hWnd, IDC_EDITOR_SELECT_BOX_SURFACE_ROTATION, byTemp);
				break;

				case IDC_EDITOR_SELECT_BOX_ENVIRONMENT:
					i = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_ENVIRONMENT, BM_GETCHECK, 0, 0L);
					if(pActorT->iBoxSurface[6] == -1 || i)
						pActorT->iBoxSurface[6] = 0; // Enable
					else
						pActorT->iBoxSurface[6] = -1; // Disable
					goto Init;

				case IDC_EDITOR_SELECT_BOX_ENVIRONMENT_COLOR: byEditorSelected = EDITOR_SELECTED_BOX_ENVIRONMENT_COLOR; break;
				case IDC_EDITOR_SELECT_BOX_ENVIRONMENT_DENSITY: byEditorSelected = EDITOR_SELECTED_BOX_ENVIRONMENT_DENSITY; break;

				case IDC_EDITOR_SELECT_BOX_WEIGHT:
					GetDlgItemText(hWnd, IDC_EDITOR_SELECT_BOX_WEIGHT, byTemp, 256);
					pActorT->fWeight = (float) atof(byTemp);
				break;

				case IDC_EDITOR_SELECT_BOX_TYPE:
					i = (int) SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_TYPE, CB_GETCURSEL, 0, 0L);
					if(i < 0)
						i = 0;
					if(i > 3)
						i = 3;
					switch(i)
					{
						case 0: pActorT->Type = AT_BOX_NORMAL; break;
						case 1: pActorT->Type = AT_BOX_RED; break;
						case 2: pActorT->Type = AT_BOX_GREEN; break;
						case 3: pActorT->Type = AT_BOX_BLUE; break;
					}
					goto Init;


				case IDC_EDITOR_SELECT_BOX_USE_BOX_COLOR: pActorT->bUseBoxColor = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_USE_BOX_COLOR, BM_GETCHECK, 0, 0L); break;
				case IDC_EDITOR_SELECT_BOX_INDESTRUCTIBLE: pActorT->bIndestructible = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_INDESTRUCTIBLE, BM_GETCHECK, 0, 0L); break;
				case IDC_EDITOR_SELECT_BOX_NITROGLYCERIN: pActorT->bNitroglycerin = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_NITROGLYCERIN, BM_GETCHECK, 0, 0L); break;
				case IDC_EDITOR_SELECT_BOX_COLLISION_DAMAGE: pActorT->bCollisionDamage = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_COLLISION_DAMAGE, BM_GETCHECK, 0, 0L); break;
				case IDC_EDITOR_SELECT_BOX_THROWABLE: pActorT->bThrowable = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_BOX_THROWABLE, BM_GETCHECK, 0, 0L); break;
            }
            break;
    }
    return FALSE;
} // end EditorSelectBoxProc()

LRESULT CALLBACK EditorSelectActorProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorSelectActorProc()
	char byTemp[256];
	FIELD *pFieldT;
	ACTOR *pActorT;
	BOOL bShowT;
	int i;
	
	if(!pLevel)
		return 0;
	pFieldT = pLevel->pCurrentField;
	if(pFieldLast != pFieldT)
	{
		if(!(pActorT = pFieldT->pActor))
			return 0;
		pFieldLast = pFieldT;
		goto Init;
	}
	if(!pFieldT || !(pActorT = pFieldT->pActor))
		return 0;

	switch(iMessage)
    {
        case WM_INITDIALOG:
		// Texts:
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_ACTOR_ITEMS_T, AS_T(T_Items));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_ACTOR_ITEM_UNLIMITED, AS_T(T_Unlimited));
			FillItemListElement(hWnd, IDC_EDITOR_SELECT_ACTOR_ITEM_LIST);
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ACTOR_ITEM_LIST, CB_SETCURSEL, 0, 0L);
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_ACTOR_REINCARNATION_SHIELD, AS_T(T_ReincarnationShield));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_ACTOR_SHADOW, AS_T(T_Shadow));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_ACTOR_TORCH, AS_T(T_Torch));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_ACTOR_ITEM_DELIVER, AS_T(T_Deliver));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_ACTOR_ITEM_KEEP, AS_T(T_Keep));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_ACTOR_COLOR, AS_T(T_Color));
			SetDlgItemText(hWnd, IDD_EDITOR_SELECT_ACTOR_TEXT_SCRIPT, AS_T(T_TextScript));
			SetDlgItemText(hWnd, IDD_EDITOR_SELECT_ACTOR_TEXT_SCRIPT_ALWAYS, AS_T(T_Always));
			SetDlgItemText(hWnd, IDD_EDITOR_SELECT_ACTOR_TEXT_SCRIPT_SET, AS_T(T_Set));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_ACTOR_HEALTH_T, AS_T(T_Health));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_ACTOR_MAX_HEALTH_T, AS_T(T_MaxHealth));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_ACTOR_TEXTURE_T, AS_T(T_Texture));

  		Init:
			i = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ACTOR_ITEM_LIST, CB_GETCURSEL, 0, 0L);
			i = (int) SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ACTOR_ITEM_LIST, CB_GETITEMDATA, i, 0L);
			if(i < 0 || i > ITEMS)
				i = 0;
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ACTOR_ITEM_UNLIMITED, BM_SETCHECK, pActorT->Item[i].bUnlimited, 0L);
			sprintf(byTemp, "%d", pActorT->Item[i].iNumber);
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_ACTOR_ITEM_NUMBER, byTemp);
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ACTOR_ITEM_DELIVER, BM_SETCHECK, pActorT->Item[i].bDeliver, 0L);
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ACTOR_ITEM_KEEP, BM_SETCHECK, pActorT->Item[i].bKeep, 0L);
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ACTOR_REINCARNATION_SHIELD, BM_SETCHECK, pActorT->bReincarnationShield, 0L);
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ACTOR_SHADOW, BM_SETCHECK, pActorT->bShadow, 0L);
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ACTOR_TORCH, BM_SETCHECK, pActorT->bTorch, 0L);
			SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_ACTOR_TEXT_SCRIPT, BM_SETCHECK, pActorT->bTextScript, 0L);
			SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_ACTOR_TEXT_SCRIPT_ALWAYS, BM_SETCHECK, pActorT->bTextScriptAlways, 0L);
			pLevel->TextScriptManager.FillTextScriptView(pActorT->pTextScript, hWnd, IDD_EDITOR_SELECT_ACTOR_TEXT_SCRIPT_T);
			sprintf(byTemp, "%f", pActorT->fHealth);
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_ACTOR_HEALTH, byTemp);
			sprintf(byTemp, "%f", pActorT->fMaxHealth);
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_ACTOR_MAX_HEALTH, byTemp);

			if(pActorT->Type == AT_BOX_NORMAL || pActorT->Type == AT_BOX_RED ||
			   pActorT->Type == AT_BOX_GREEN || pActorT->Type == AT_BOX_BLUE)
			   bShowT = FALSE;
			else
			   bShowT = TRUE;
			ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_ACTOR_TEXTURE_T), bShowT);
			ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_ACTOR_TEXTURE), bShowT);
			if(bShowT)
			{
				SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ACTOR_TEXTURE, CB_RESETCONTENT , 0, 0L);
				SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ACTOR_TEXTURE, CB_ADDSTRING, 0, (LPARAM) AS_T(T_Standart));
				for(i = 0; i < pLevel->Header.iTextures; i++)
				{
					sprintf(byTemp, "%s (Used:%d)", pLevel->pTexture[i].byFilename, pLevel->pTexture[i].iUsed);
					SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ACTOR_TEXTURE, CB_ADDSTRING, 0, (LPARAM) byTemp);
				}
				SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ACTOR_TEXTURE, CB_SETCURSEL, pActorT->iTexture+1, 0L);
			}

			BringWindowToTop(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_EDITOR_SELECT_ACTOR_ITEM_LIST:
					goto Init;

				case IDC_EDITOR_SELECT_ACTOR_ITEM_UNLIMITED:
					i = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ACTOR_ITEM_LIST, CB_GETCURSEL, 0, 0L);
					i = (int) SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ACTOR_ITEM_LIST, CB_GETITEMDATA, i, 0L);
					if(i < 0 || i > ITEMS)
						i = 0;
					pActorT->Item[i].bUnlimited = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ACTOR_ITEM_UNLIMITED, BM_GETCHECK, 0, 0L);
				break;

				case IDC_EDITOR_SELECT_ACTOR_ITEM_NUMBER:
					i = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ACTOR_ITEM_LIST, CB_GETCURSEL, 0, 0L);
					i = (int) SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ACTOR_ITEM_LIST, CB_GETITEMDATA, i, 0L);
					if(i < 0 || i > ITEMS)
						i = 0;
					GetDlgItemText(hWnd, IDC_EDITOR_SELECT_ACTOR_ITEM_NUMBER, byTemp, 256);
					pActorT->Item[i].iNumber = (int) atoi(byTemp);
				break;

				case IDC_EDITOR_SELECT_ACTOR_ITEM_DELIVER:
					i = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ACTOR_ITEM_LIST, CB_GETCURSEL, 0, 0L);
					i = (int) SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ACTOR_ITEM_LIST, CB_GETITEMDATA, i, 0L);
					if(i < 0 || i > ITEMS)
						i = 0;
					pActorT->Item[i].bDeliver = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ACTOR_ITEM_DELIVER, BM_GETCHECK, 0, 0L);
				break;

				case IDC_EDITOR_SELECT_ACTOR_ITEM_KEEP:
					i = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ACTOR_ITEM_LIST, CB_GETCURSEL, 0, 0L);
					i = (int) SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ACTOR_ITEM_LIST, CB_GETITEMDATA, i, 0L);
					if(i < 0 || i > ITEMS)
						i = 0;
					pActorT->Item[i].bKeep = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ACTOR_ITEM_KEEP, BM_GETCHECK, 0, 0L);
				break;

				case IDC_EDITOR_SELECT_ACTOR_REINCARNATION_SHIELD: pActorT->bReincarnationShield = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ACTOR_REINCARNATION_SHIELD, BM_GETCHECK, 0, 0L); break;
				case IDC_EDITOR_SELECT_ACTOR_SHADOW: pActorT->bShadow = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ACTOR_SHADOW, BM_GETCHECK, 0, 0L); break;
				case IDC_EDITOR_SELECT_ACTOR_TORCH: pActorT->bTorch = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ACTOR_TORCH, BM_GETCHECK, 0, 0L); break;

				case IDC_EDITOR_SELECT_ACTOR_COLOR: byEditorSelected = EDITOR_SELECTED_ACTOR_COLOR; break;
				case IDD_EDITOR_SELECT_ACTOR_TEXT_SCRIPT: pActorT->bTextScript = SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_ACTOR_TEXT_SCRIPT, BM_GETCHECK, 0, 0L); break;
				case IDD_EDITOR_SELECT_ACTOR_TEXT_SCRIPT_ALWAYS: pActorT->bTextScriptAlways = SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_ACTOR_TEXT_SCRIPT_ALWAYS, BM_GETCHECK, 0, 0L); break;
				
				case IDD_EDITOR_SELECT_ACTOR_TEXT_SCRIPT_SET:
					bGetActorTextScript = TRUE;
					OpenTSE(hWndEditor);
				break;

				case IDC_EDITOR_SELECT_ACTOR_HEALTH:
					GetDlgItemText(hWnd, IDC_EDITOR_SELECT_ACTOR_HEALTH, byTemp, 256);
					pActorT->fHealth = (float) atof(byTemp);
				break;

				case IDC_EDITOR_SELECT_ACTOR_MAX_HEALTH:
					GetDlgItemText(hWnd, IDC_EDITOR_SELECT_ACTOR_MAX_HEALTH, byTemp, 256);
					pActorT->fMaxHealth = (float) atof(byTemp);
				break;

				case IDC_EDITOR_SELECT_ACTOR_TEXTURE:
					if(!pLevel->Header.iTextures)
						break;
					if(pActorT->iTexture != -1)
						pLevel->pTexture[pActorT->iTexture].iUsed--;
					i = (int) SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ACTOR_TEXTURE, CB_GETCURSEL, 0, 0L);
					if(i < 0 || i > pLevel->Header.iTextures)
						break;
					pActorT->iTexture = i-1;
					if(pActorT->iTexture != -1)
					{
						pLevel->pTexture[pActorT->iTexture].iUsed++;
						strcpy(pActorT->byTextureFilename, pLevel->pTexture[pActorT->iTexture].byFilename);
					}
					else
						strcpy(pActorT->byTextureFilename, "");
				break;
			}
            break;
    }
    return FALSE;
} // end EditorSelectActorProc()

LRESULT CALLBACK EditorSelectBlibsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorSelectBlibsProc()
	FIELD *pFieldT;
	ACTOR *pActorT;
	
	if(!pLevel)
		return 0;
	pFieldT = pLevel->pCurrentField;
	if(pFieldLast != pFieldT)
	{
		if(!(pActorT = pFieldT->pActor))
			return 0;
		pFieldLast = pFieldT;
		goto Init;
	}
	if(!pFieldT || !(pActorT = pFieldT->pActor))
		return 0;

	switch(iMessage)
    {
        case WM_INITDIALOG:
		// Texts:

  		Init:
//			iItemID = (int) SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ACTOR_ITEM_LIST, CB_GETCURSEL, 0, 0L);
//			if(iItemID < 0 || iItemID >= ITEMS)
//				iItemID = 0;



			BringWindowToTop(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case 0:
				break;
            }
            break;
    }
    return FALSE;
} // end EditorSelectBlibsProc()

LRESULT CALLBACK EditorSelectEnemyProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorSelectEnemyProc()
	FIELD *pFieldT;
	ACTOR *pActorT;
	
	if(!pLevel)
		return 0;
	pFieldT = pLevel->pCurrentField;
	if(pFieldLast != pFieldT)
	{
		if(!(pActorT = pFieldT->pActor))
			return 0;
		pFieldLast = pFieldT;
		goto Init;
	}
	if(!pFieldT || !(pActorT = pFieldT->pActor))
		return 0;

	switch(iMessage)
    {
        case WM_INITDIALOG:
		// Texts:
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_ENEMY_AGGRESSIVE, AS_T(T_Aggressive));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_ENEMY_SMALL, AS_T(T_Small));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_ENEMY_GUARDIAN, AS_T(T_Guardian));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_ENEMY_MOBILE, AS_T(T_Mobile));
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_ENEMY_FOLLOW, AS_T(T_Follow));

  		Init:
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ENEMY_AGGRESSIVE, BM_SETCHECK, pActorT->bAggressive, 0L);
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ENEMY_SMALL, BM_SETCHECK, pActorT->bSmall, 0L);
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ENEMY_GUARDIAN, BM_SETCHECK, pActorT->bGuardian, 0L);
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ENEMY_MOBILE, BM_SETCHECK, pActorT->bMobile, 0L);
			SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ENEMY_FOLLOW, BM_SETCHECK, pActorT->bFollow, 0L);

			BringWindowToTop(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_EDITOR_SELECT_ENEMY_AGGRESSIVE: pActorT->bAggressive = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ENEMY_AGGRESSIVE, BM_GETCHECK, 0, 0L); break;

				case IDC_EDITOR_SELECT_ENEMY_SMALL:
					pActorT->bSmall = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ENEMY_SMALL, BM_GETCHECK, 0, 0L);
					pActorT->SetAction(AA_NOTHING);
				break;

				case IDC_EDITOR_SELECT_ENEMY_GUARDIAN: pActorT->bGuardian = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ENEMY_GUARDIAN, BM_GETCHECK, 0, 0L); break;
				case IDC_EDITOR_SELECT_ENEMY_MOBILE: pActorT->bMobile = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ENEMY_MOBILE, BM_GETCHECK, 0, 0L); break;
				case IDC_EDITOR_SELECT_ENEMY_FOLLOW: pActorT->bFollow = SendDlgItemMessage(hWnd, IDC_EDITOR_SELECT_ENEMY_FOLLOW, BM_GETCHECK, 0, 0L); break;
            }
            break;
    }
    return FALSE;
} // end EditorSelectEnemyProc()

void SetupEditorSelectTabs(void)
{ // begin SetupEditorSelectTabs()
	HWND hWndTab;
	TC_ITEM tie; 
	FIELD *pFieldT;
	int i, iTab = 0, iTabID;
	
	if(!pLevel)
		return;
	pFieldT = pLevel->pCurrentField;
	if(!pFieldT)
		return;

	// Destroy the old select tabs:
	for(i = 0; i < EDITOR_SELECT_TABS; i++)
	{
		iTabID = (*iEditorSelectTabsPointer)[i];
		if(iTabID != -1 && hWndEditorSelectTab[iTabID])
		{
			ShowWindow(hWndEditorSelectTab[iTabID], SW_HIDE);
			UpdateWindow(hWndEditorSelectTab[iTabID]);
			DestroyWindow(hWndEditorSelectTab[iTabID]);
			hWndEditorSelectTab[iTabID] = NULL;
		}
		(*iEditorSelectTabsPointer)[i] = -1;
	}

	// Setup editor tabs:
	hWndTab = GetDlgItem(hWndEditorTab[TAB_EDITOR_SELECT], IDD_EDITOR_SELECT_TAB);
	TabCtrl_DeleteAllItems(hWndTab);
	tie.mask = TCIF_TEXT;

	// Scripts:
	TAB_EDITOR_SELECT_SCRIPTS = iTab++;
	tie.pszText	= AS_T(T_Scripts);
	TabCtrl_InsertItem(hWndTab, TAB_EDITOR_SELECT_SCRIPTS, &tie);
	if(hWndEditorSelectTab[TAB_EDITOR_SELECT_SCRIPTS])
		DestroyWindow(hWndEditorSelectTab[TAB_EDITOR_SELECT_SCRIPTS]);
	hWndEditorSelectTab[TAB_EDITOR_SELECT_SCRIPTS] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_SELECT_SCRIPTS), hWndTab, (DLGPROC) EditorSelectScriptsProc, WM_INITDIALOG);

	if(pFieldT->Side[FACE_FLOOR].Surface[0].pSurface->Header.bBeamer && pFieldT->bActive)
	{  // Beamer:
		TAB_EDITOR_SELECT_BEAMER = iTab++;
		tie.pszText	= AS_T(T_Beamer);
		TabCtrl_InsertItem(hWndTab, TAB_EDITOR_SELECT_BEAMER, &tie);
		if(hWndEditorSelectTab[TAB_EDITOR_SELECT_BEAMER])
			DestroyWindow(hWndEditorSelectTab[TAB_EDITOR_SELECT_BEAMER]);
		hWndEditorSelectTab[TAB_EDITOR_SELECT_BEAMER] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_SELECT_BEAMER), hWndTab, (DLGPROC) EditorSelectBeamerProc, WM_INITDIALOG);
	}

	if(pFieldT->pDecoration)
	{ // Decoration:
		TAB_EDITOR_SELECT_DECORATION = iTab++;
		tie.pszText	= AS_T(T_Decoration);
		TabCtrl_InsertItem(hWndTab, TAB_EDITOR_SELECT_DECORATION, &tie);
		if(hWndEditorSelectTab[TAB_EDITOR_SELECT_DECORATION])
			DestroyWindow(hWndEditorSelectTab[TAB_EDITOR_SELECT_DECORATION]);
		hWndEditorSelectTab[TAB_EDITOR_SELECT_DECORATION] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_SELECT_DECORATION), hWndTab, (DLGPROC) EditorSelectDecorationProc, WM_INITDIALOG);
	}

	if(pFieldT->pItem)
	{ // Item:
		TAB_EDITOR_SELECT_ITEM = iTab++;
		tie.pszText	= AS_T(T_Item);
		TabCtrl_InsertItem(hWndTab, TAB_EDITOR_SELECT_ITEM, &tie);
		if(hWndEditorSelectTab[TAB_EDITOR_SELECT_ITEM])
			DestroyWindow(hWndEditorSelectTab[TAB_EDITOR_SELECT_ITEM]);
		hWndEditorSelectTab[TAB_EDITOR_SELECT_ITEM] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_SELECT_ITEM), hWndTab, (DLGPROC) EditorSelectItemProc, WM_INITDIALOG);
	}

	if(pFieldT->pActor)
	{ // Actor:
		switch(pFieldT->pActor->Type)
		{
			case AT_BOX_NORMAL:
			case AT_BOX_RED:
			case AT_BOX_GREEN:
			case AT_BOX_BLUE:
				TAB_EDITOR_SELECT_BOX = iTab++;
				tie.pszText	= AS_T(T_Box);
				TabCtrl_InsertItem(hWndTab, TAB_EDITOR_SELECT_BOX, &tie);
				if(hWndEditorSelectTab[TAB_EDITOR_SELECT_BOX])
					DestroyWindow(hWndEditorSelectTab[TAB_EDITOR_SELECT_BOX]);
				hWndEditorSelectTab[TAB_EDITOR_SELECT_BOX] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_SELECT_BOX), hWndTab, (DLGPROC) EditorSelectBoxProc, WM_INITDIALOG);
			
			default:
				TAB_EDITOR_SELECT_ACTOR = iTab++;
				tie.pszText	= AS_T(T_Actor);
				TabCtrl_InsertItem(hWndTab, TAB_EDITOR_SELECT_ACTOR, &tie);
				if(hWndEditorSelectTab[TAB_EDITOR_SELECT_ACTOR])
					DestroyWindow(hWndEditorSelectTab[TAB_EDITOR_SELECT_ACTOR]);
				hWndEditorSelectTab[TAB_EDITOR_SELECT_ACTOR] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_SELECT_ACTOR), hWndTab, (DLGPROC) EditorSelectActorProc, WM_INITDIALOG);
			break;
		}
		switch(pFieldT->pActor->Type)
		{
			case AT_BLIBS:
				TAB_EDITOR_SELECT_BLIBS = iTab++;
				tie.pszText	= "Blibs";
				TabCtrl_InsertItem(hWndTab, TAB_EDITOR_SELECT_BLIBS, &tie);
				if(hWndEditorSelectTab[TAB_EDITOR_SELECT_BLIBS])
					DestroyWindow(hWndEditorSelectTab[TAB_EDITOR_SELECT_BLIBS]);
				hWndEditorSelectTab[TAB_EDITOR_SELECT_BLIBS] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_SELECT_BLIBS), hWndTab, (DLGPROC) EditorSelectBlibsProc, WM_INITDIALOG);
			break;

			case AT_MOBMOB:
			case AT_X3:
			case AT_LUCIFER_HEAD:
			case AT_LUCIFER:
				TAB_EDITOR_SELECT_ENEMY = iTab++;
				tie.pszText	= AS_T(T_Enemy);
				TabCtrl_InsertItem(hWndTab, TAB_EDITOR_SELECT_ENEMY, &tie);
				if(hWndEditorSelectTab[TAB_EDITOR_SELECT_ENEMY])
					DestroyWindow(hWndEditorSelectTab[TAB_EDITOR_SELECT_ENEMY]);
				hWndEditorSelectTab[TAB_EDITOR_SELECT_ENEMY] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_SELECT_ENEMY), hWndTab, (DLGPROC) EditorSelectEnemyProc, WM_INITDIALOG);
			break;
		}
	}

	//
	for(i = 0; i < EDITOR_SELECT_TABS; i++)
	{
		iTabID = (*iEditorSelectTabsPointer)[i];
		if(iTabID != -1 && hWndEditorSelectTab[iTabID])
		{
			ShowWindow(hWndEditorSelectTab[iTabID], SW_HIDE);
			UpdateWindow(hWndEditorSelectTab[iTabID]);
		}
	}

	if(iCurrentEditorSelectTab != -1 && iCurrentEditorSelectTab < iTab)
	{
		TabCtrl_SetCurSel(hWndTab, iCurrentEditorSelectTab);
		ShowWindow(hWndEditorSelectTab[iCurrentEditorSelectTab], SW_SHOW);
		UpdateWindow(hWndEditorSelectTab[iCurrentEditorSelectTab]);
	}
	else
		TabCtrl_SetCurSel(hWndTab, 0);
	SendMessage(hWndEditor, WM_NOTIFY, IDD_EDITOR_SELECT_TAB, 0);
} // end SetupEditorSelectTabs()
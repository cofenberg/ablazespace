Ein Text Eintrag darf nicht l�nger als 450 Zeichen lang sein.
Es k�nnen maximal acht Textzeilen auf einmal dargestellt werden.
Ist ein Bild bei dem Text, so passen 52 Zeichen in eine Zeile.
Ist kein ein Bild bei dem Text, so passen 60 Zeichen in eine Zeile.



/n/   - Neue Zeile Anfangen

Aktuelle Tastenbelegung einsetzen:
/left_key/
/right_key/
/up_key/
/down_key/
/shot_key/
/kick_key/
/action_key/
/pull_key/
/suicide_key/
/jump_key/
/change_perspective_key/
/standart_view_key/
/pause_key/
/quick_load_key/
/quick_save_key/
/level_restart_key/
/show_level_missions_key/


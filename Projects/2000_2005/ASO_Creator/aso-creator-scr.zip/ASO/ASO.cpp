/* ASO - Creator (Ablaze Space Object)
 * Programmed by Christian Ofenberg 2000
 * Homepage: www.ablazespace.de
 * E-Mail: mail@AblazeSpace.de
 *
 * When you use this editor or parts from it don't forget to say in you program
 * from were you have this stuff! Use this all on your own risk!
*/
#include "ASO.h"


// Variables: *****************************************************************
HINSTANCE hInstance;
int iCmdShow;
AS_OBJECT *Object;
AS_OBJECT *pObjectT;
short iObjects; // The number of object which are in the main object
BOOL bFirst;
HWND hWndASO;
HWND hWndTV;
HWND hWndGeneral;
HWND  hWndFrameView;
HDC	  hDCFrameView;
HGLRC hRCFrameView;
HWND  hWndAnimationView;
HDC	  hDCAnimationView;
HGLRC hRCAnimationView;
FLOAT3 fFrameViewPos, fFrameViewRot;
FLOAT3 fAnimationViewPos, fAnimationViewRot;
GLfloat LightDiffuse[]	= { 0.01f, 0.01f, 0.01f, 1.0f }; 
GLfloat LightAmbient[]	= { 0.5f, 0.5f, 0.5f, 1.0f };
GLfloat LightPosition[]	= { 10.0f, 10.0f, 10.0f, 1.0f };
AS_OBJECT *CurrentObj;
BOOL bExpectingNumbers;
int iDefinitions, iExpectedNumbers;
int iSize;
char *pbyGlobalFilename;
char byTemp2[256];
MATRIX Matrix, SceneMatrix;
///////////////////////////////////////////////////////////////////////////////
// Functions: *****************************************************************
int PASCAL WinMain(HINSTANCE, HINSTANCE, LPSTR, int);
LRESULT CALLBACK WinProc(HWND, unsigned, WPARAM, LPARAM);
LRESULT CALLBACK CreditsProc(HWND, unsigned, WPARAM, LPARAM);
LRESULT CALLBACK GeneralProc(HWND, unsigned, WPARAM, LPARAM);
void InsertFrame(char *, HWND);
void LoadFrameMessage(void);
void SetObjectViewPropertysView(void);
void ObjectViewOnTreeSelect(HWND, NM_TREEVIEW *);
void ObjectViewFillTree(HWND);
HTREEITEM TVAddNode(HTREEITEM, LPSTR, BOOL, int, SELCALLBACK, LPARAM, LPARAM, PRINTCALLBACK);
void AddCapsToTV(HTREEITEM, CAPDEFS *, LPARAM);
HRESULT InsertFrameWrl(char *, AS_OBJECT *);
HRESULT WrlParseStatement(FILE *);
char *GetFileName(HWND,  char *, char *, BOOL, BOOL);
HRESULT InitOpenGL(HWND, HDC *, HGLRC *);
HRESULT DestroyOpenGL(HWND, HDC, HGLRC);
void ConfigOpenGL(int, int);
void NormalizeFace(FLOAT3 *, FLOAT3, FLOAT3, FLOAT3);
///////////////////////////////////////////////////////////////////////////////


int PASCAL WinMain(HINSTANCE hInstanceT, HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine, int iCmdShowT)
{ // begin WinMain()
	hInstance = hInstanceT;
	iCmdShow = iCmdShowT;
	Object = new AS_OBJECT;
	strcpy(Object->Header.byName, "Noname");
	DialogBox(hInstance, MAKEINTRESOURCE(IDD_ASO), NULL, (DLGPROC) WinProc);
	Object->Destroy();
	delete Object;
	return 0;
} // end WinMain()

LRESULT CALLBACK WinProc(HWND hWnd, unsigned uMsg, WPARAM wParam, LPARAM lParam)
{ // begin WinProc()
	AS_OBJECT_ANIMATION_STEP *pTempAniStep;
	DWORD dwInterpolateTime;
	char *pbyTemp;
	char byTemp[256], byTemp2[256], byTemp3[256];
	int i, i2;
	FILE *fp;
	RECT Rect;
	FLOAT3 *pFloat, *pFloat2;
    static POINT MousePos, OldMousePos;

	switch(uMsg)
    {
        case WM_INITDIALOG:
			hWndASO = hWnd;
			// Init the view windows:
			for(i = 0; i < 3; i++)
				fFrameViewRot[i] = fAnimationViewRot[i] = 0.0f;
			fFrameViewPos[X] = fAnimationViewPos[X] = 
			fFrameViewPos[Y] = fAnimationViewPos[Y] = 0.0f;
			fFrameViewPos[Z] = fAnimationViewPos[Z] = -30.0f;
			hWndAnimationView = GetDlgItem(hWnd, IDC_ANIMATION_VIEW);
			InitOpenGL(hWndAnimationView, &hDCAnimationView, &hRCAnimationView);
			hWndFrameView = GetDlgItem(hWnd, IDC_FRAME_VIEW);
			InitOpenGL(hWndFrameView, &hDCFrameView, &hRCFrameView);
			SetTimer(hWnd, 1, 10, NULL);				
			//
			if(Object->Header.iFrames)
				Object->pFrameT = &Object->pFrame[0];
			else
				Object->pFrameT = NULL;
			if(Object->Header.iAnimations)
				Object->pAnimationT = &Object->pAnimation[0];
			else
				Object->pAnimationT = NULL;
			bFirst = TRUE;
			SendDlgItemMessage(hWnd, IDC_ANIMATIONS, CB_RESETCONTENT, 0, 0L);
			for(i2 = 0; i2 < Object->Header.iAnimations; i2++)
			{
   				SendDlgItemMessage(hWnd, IDC_ANIMATIONS, CB_ADDSTRING, 0, (LONG)(LPSTR) Object->pAnimation[i2].byName);
     			SendDlgItemMessage(hWnd, IDC_ANIMATIONS, CB_SETITEMDATA,i2, 0);
			}
		Init:
			// Frames:
			EnableWindow(GetDlgItem(hWnd, IDC_FRAME_NAME), FALSE);
			EnableWindow(GetDlgItem(hWnd, IDC_DELETE_FRAME), FALSE);
			EnableWindow(GetDlgItem(hWnd, IDC_FRAME_MOVE_UP), FALSE);
			EnableWindow(GetDlgItem(hWnd, IDC_FRAME_MOVE_DOWN), FALSE);	
			EnableWindow(GetDlgItem(hWnd, IDC_INSERT_FRAME_TO_ANIMATION), FALSE);
			EnableWindow(GetDlgItem(hWnd, IDC_NEW_ANIMATION), FALSE);
			SendDlgItemMessage(hWnd, IDC_FRAMES, LB_RESETCONTENT , 0, 0L);
			for(i2 = 0; i2 < Object->Header.iFrames; i2++)
			{
				sprintf(byTemp, "%s (Used:%d)", Object->pFrame[i2].byName, Object->pFrame[i2].iUsed);
				SendDlgItemMessage(hWnd, IDC_FRAMES, LB_ADDSTRING, 0, (LPARAM) byTemp);
			}
			if(Object->pFrameT)
			{
				EnableWindow(GetDlgItem(hWnd, IDC_NEW_ANIMATION), TRUE);
				SendDlgItemMessage(hWnd, IDC_FRAMES, LB_SETCURSEL, Object->pFrameT->iID, 0L);
				EnableWindow(GetDlgItem(hWnd, IDC_FRAME_NAME), TRUE);
				EnableWindow(GetDlgItem(hWnd, IDC_DELETE_FRAME), TRUE);
				EnableWindow(GetDlgItem(hWnd, IDC_INSERT_FRAME_TO_ANIMATION), TRUE);			
				SetDlgItemText(hWnd, IDC_FRAME_NAME, Object->pFrameT->byName);
				sprintf(byTemp, "%d", Object->pFrameT->iUsed);
				if(Object->pFrameT->iID > 0)
					EnableWindow(GetDlgItem(hWnd, IDC_FRAME_MOVE_UP), TRUE);
				if(Object->pFrameT->iID < Object->Header.iFrames-1)
					EnableWindow(GetDlgItem(hWnd, IDC_FRAME_MOVE_DOWN), TRUE);
			}
			else
				SendDlgItemMessage(hWnd, IDC_FRAMES, LB_SETCURSEL, 0, 0L);
			// Animations:
			SendDlgItemMessage(hWnd, IDC_ANIMATION_STEPS, LB_RESETCONTENT, 0, 0L);
			EnableWindow(GetDlgItem(hWnd, IDC_ANIMATION_NAME), FALSE);
			EnableWindow(GetDlgItem(hWnd, IDC_DELETE_ANIMATION), FALSE);
			EnableWindow(GetDlgItem(hWnd, IDC_INSERT_FRAME_TO_ANIMATION), FALSE);
			EnableWindow(GetDlgItem(hWnd, IDC_DELETE_ANIMATION_STEP), FALSE);
			EnableWindow(GetDlgItem(hWnd, IDC_ANIMATION_MOVE_UP), FALSE);
			EnableWindow(GetDlgItem(hWnd, IDC_ANIMATION_MOVE_DOWN), FALSE);
			EnableWindow(GetDlgItem(hWnd, IDC_ANIMATION_STEP_MOVE_UP), FALSE);
			EnableWindow(GetDlgItem(hWnd, IDC_ANIMATION_STEP_MOVE_DOWN), FALSE);
			EnableWindow(GetDlgItem(hWnd, IDC_ANIMATION_FRAME_INTERPOLATE_TIME), FALSE);
			EnableWindow(GetDlgItem(hWnd, IDC_ANIMATION_FRAME_INTERPOLATE_TIME_ALL), FALSE);
			EnableWindow(GetDlgItem(hWnd, IDC_ANIMATION_PLAY), FALSE);
			if(Object->Header.iAnimations)
				EnableWindow(GetDlgItem(hWnd, IDC_ANIMATIONS), TRUE);
			else
				EnableWindow(GetDlgItem(hWnd, IDC_ANIMATIONS), FALSE);
			if(Object->pAnimationT)
			{
				SendDlgItemMessage(hWnd, IDC_ANIMATIONS, CB_SETCURSEL, Object->pAnimationT->iID, 0L);
				if(Object->pAnimationT->iSteps >= 2)
					EnableWindow(GetDlgItem(hWnd, IDC_ANIMATION_PLAY), TRUE);				
				EnableWindow(GetDlgItem(hWnd, IDC_DELETE_ANIMATION), TRUE);
				if(Object->pAnimationT->iID > 0)
					EnableWindow(GetDlgItem(hWnd, IDC_ANIMATION_MOVE_UP), TRUE);
				if(Object->pAnimationT->iID < Object->Header.iAnimations-1)
					EnableWindow(GetDlgItem(hWnd, IDC_ANIMATION_MOVE_DOWN), TRUE);
				SetDlgItemText(hWnd, IDC_ANIMATION_NAME, Object->pAnimationT->byName);
				EnableWindow(GetDlgItem(hWnd, IDC_ANIMATION_NAME), TRUE);
				if(Object->pFrameT)
					EnableWindow(GetDlgItem(hWnd, IDC_INSERT_FRAME_TO_ANIMATION), TRUE);
				for(i2 = 0; i2 < Object->pAnimationT->iSteps; i2++)
   				{
					sprintf(byTemp, "%s(%d)", Object->pAnimationT->pStep[i2].pFrame->byName, Object->pAnimationT->pStep[i2].iID);
					SendDlgItemMessage(hWnd, IDC_ANIMATION_STEPS, LB_ADDSTRING, 0, (LONG)(LPSTR) byTemp);
				}
				if(Object->pAnimationT->pStepT)
				{
					sprintf(byTemp, "%d", Object->pAnimationT->pStepT->dwInterpolateTime);
					SetDlgItemText(hWnd, IDC_ANIMATION_FRAME_INTERPOLATE_TIME, byTemp);
					SendDlgItemMessage(hWnd, IDC_ANIMATION_STEPS, LB_SETCURSEL, Object->pAnimationT->pStepT->iID, 0L);
					EnableWindow(GetDlgItem(hWnd, IDC_DELETE_ANIMATION_STEP), TRUE);
					if(Object->pAnimationT->pStepT->iID > 0)
						EnableWindow(GetDlgItem(hWnd, IDC_ANIMATION_STEP_MOVE_UP), TRUE);
					if(Object->pAnimationT->pStepT->iID < Object->pAnimationT->iSteps-1)					
						EnableWindow(GetDlgItem(hWnd, IDC_ANIMATION_STEP_MOVE_DOWN), TRUE);
					EnableWindow(GetDlgItem(hWnd, IDC_ANIMATION_FRAME_INTERPOLATE_TIME), TRUE);
					EnableWindow(GetDlgItem(hWnd, IDC_ANIMATION_FRAME_INTERPOLATE_TIME_ALL), TRUE);
				}
			}
			ShowWindow(hWnd, iCmdShow);
			UpdateWindow(hWnd);
		break;

        case WM_LBUTTONDOWN: case WM_LBUTTONUP: case WM_RBUTTONDOWN:
        case WM_RBUTTONUP: case WM_MOUSEMOVE:
            // Check the mouse:
			i = wParam;
			memcpy(&OldMousePos, &MousePos, sizeof(POINT));
			GetCursorPos(&MousePos);
			GetWindowRect(hWnd, &Rect);
			// Check the view windows:
			for(i2 = 0; i2 < 2; i2++)
			{
				if(!i2)
				{
					GetWindowRect(hWndAnimationView, &Rect);
					pFloat = &fAnimationViewPos;
					pFloat2 = &fAnimationViewRot;
				}
				else			
				{
					GetWindowRect(hWndFrameView, &Rect);
					pFloat = &fFrameViewPos;
					pFloat2 = &fFrameViewRot;
				}
				if(MousePos.x > Rect.left && MousePos.x < Rect.right &&
				   MousePos.y > Rect.top && MousePos.y < Rect.bottom)
				{ // The mouse is over the window enable view control:
					if(i & MK_MBUTTON || (i & MK_SHIFT && i & MK_RBUTTON))
						(*pFloat)[Z] -= (MousePos.x-OldMousePos.x+MousePos.y-OldMousePos.y)/2;
					else
					if(i & MK_SHIFT && i & MK_LBUTTON)
						(*pFloat2)[Y] -= (MousePos.x-OldMousePos.x+MousePos.y-OldMousePos.y)/2;
					else
					if(i & MK_LBUTTON)
					{
						(*pFloat2)[X] -= OldMousePos.y-MousePos.y;
						(*pFloat2)[Z] -= OldMousePos.x-MousePos.x;
					}
					else
					if(i & MK_RBUTTON)
					{
						(*pFloat)[X] -= (float) (OldMousePos.x-MousePos.x)/10;
						(*pFloat)[Y] -= (float) (MousePos.y-OldMousePos.y)/10;
					}
				}
			}
        break;

		case WM_PAINT: case WM_TIMER:
			// Draws the animation view:
			if(Object->pAnimationT && Object->pAnimationT->pStepT)
			{
				GetDlgItemText(hWnd, IDC_ANIMATION_PLAY, byTemp, 256);
				if(!wglMakeCurrent(hDCAnimationView, hRCAnimationView))
					return 0;
				glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
				if(!strcmp(byTemp, "&Stop"))
				{
					EnableWindow(GetDlgItem(hWnd, IDC_INSERT_FRAME_TO_ANIMATION), FALSE);
					EnableWindow(GetDlgItem(hWnd, IDC_DELETE_ANIMATION_STEP), FALSE);
					EnableWindow(GetDlgItem(hWnd, IDC_ANIMATION_STEP_MOVE_UP), FALSE);
					EnableWindow(GetDlgItem(hWnd, IDC_ANIMATION_STEP_MOVE_DOWN), FALSE);
					glLoadIdentity();
					glTranslatef(fAnimationViewPos[X], fAnimationViewPos[Y], fAnimationViewPos[Z]);
					glMultMatrixf(Object->Matrix[0]);
					glRotatef(fAnimationViewRot[Z], 0.0f, 0.0f, 1.0f);
					glRotatef(fAnimationViewRot[X], 1.0f, 0.0f, 0.0f);
					glRotatef(fAnimationViewRot[Y], 0.0f, 1.0f, 0.0f);
					i = Object->pAnimationT->pStepT->iID;
					Object->Draw(TRUE);
					if(i != Object->pAnimationT->pStepT->iID)
					{
						SendDlgItemMessage(hWnd, IDC_ANIMATION_STEPS, LB_SETCURSEL, Object->pAnimationT->pStepT->iID, 0L);
						SendDlgItemMessage(hWnd, IDC_FRAMES, LB_SETCURSEL, Object->pAnimationT->pStepT->iFrameID, 0L);
						sprintf(byTemp, "%d", Object->pAnimationT->pStepT->dwInterpolateTime);
						SetDlgItemText(hWnd, IDC_ANIMATION_FRAME_INTERPOLATE_TIME, byTemp);
						// Set the selected frame to the same as the selected animation step:
						Object->SetFrameT(Object->pAnimationT->pStepT->iFrameID);
						SendDlgItemMessage(hWnd, IDC_FRAMES, LB_SETCURSEL, Object->pAnimationT->pStepT->iFrameID, 0L);
					}
				}
				else
				{
					EnableWindow(GetDlgItem(hWnd, IDC_INSERT_FRAME_TO_ANIMATION), TRUE);
					EnableWindow(GetDlgItem(hWnd, IDC_DELETE_ANIMATION_STEP), TRUE);
					EnableWindow(GetDlgItem(hWnd, IDC_ANIMATION_STEP_MOVE_UP), TRUE);
					EnableWindow(GetDlgItem(hWnd, IDC_ANIMATION_STEP_MOVE_DOWN), TRUE);
				}
				SwapBuffers(hDCAnimationView);
			}
			else
			{
				GetDlgItemText(hWnd, IDC_ANIMATION_PLAY, byTemp, 256);
				if(!strcmp(byTemp, "&Stop"))
					SetDlgItemText(hWnd, IDC_ANIMATION_PLAY, "&Start");
			}
			// Draws the frame view:
			if(!wglMakeCurrent(hDCFrameView, hRCFrameView))
				return 0;
			glMatrixMode(GL_MODELVIEW);
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
			glLoadIdentity();
			glTranslatef(fFrameViewPos[X], fFrameViewPos[Y], fFrameViewPos[Z]);
			glMultMatrixf(Object->Matrix[0]);
			glRotatef(fFrameViewRot[Z], 0.0f, 0.0f, 1.0f);
			glRotatef(fFrameViewRot[X], 1.0f, 0.0f, 0.0f);
			glRotatef(fFrameViewRot[Y], 0.0f, 1.0f, 0.0f);
			Object->Draw(FALSE);
			SwapBuffers(hDCFrameView);
		break;

		case WM_KEYDOWN: case WM_KEYUP:
			switch(wParam)
			{
				case VK_ESCAPE:
					EndDialog(hWnd, FALSE);
				break;
			}
		break;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case ID_FILE_NEW_OBJECT:
					if(MessageBox(hWnd, "Really create a new object?", "Question", MB_YESNO | MB_ICONINFORMATION) == IDNO)
						break;
					Object->Destroy();
					memset(Object, 0, sizeof(AS_OBJECT));
					SetDlgItemText(hWnd, IDC_ANIMATION_PLAY, "&Start");
					strcpy(Object->Header.byName, "Noname");
					bFirst = TRUE;
					goto Init;
				
				case ID_FILE_SAVE_OBJECT:
					if(bFirst)
					{
						LoadFrameMessage();
						break;
					}
					if(!Object->pbyFilename)
						goto SaveAs;
					Object->Save(Object->pbyFilename);
				break;
				
				case ID_FILE_SAVE_AS_OBJECT:
					if(bFirst)
					{
						LoadFrameMessage();
						break;
					}
				SaveAs:
					pbyTemp = GetFileName(hWnd, "Save object", ASO_FILE, 1, FALSE);
					Object->Save(pbyTemp);
				break;
				
				case ID_FILE_LOAD_OBJECT:
					pbyTemp = GetFileName(hWnd, "Load object", ASO_FILE, 0, FALSE);
					if(MessageBox(hWnd, "Really load a new object?", "Question", MB_YESNO | MB_ICONINFORMATION) == IDNO)
						break;
					Object->Destroy();
					memset(Object, 0, sizeof(AS_OBJECT));
					iObjects = (short) Object->Load(pbyTemp);
					SetDlgItemText(hWnd, IDC_ANIMATION_PLAY, "&Start");
					SendDlgItemMessage(hWnd, IDC_ANIMATIONS, CB_RESETCONTENT, 0, 0L);
					for(i2 = 0; i2 < Object->Header.iAnimations; i2++)
					{
   						SendDlgItemMessage(hWnd, IDC_ANIMATIONS, CB_ADDSTRING, 0, (LONG)(LPSTR) Object->pAnimation[i2].byName);
     					SendDlgItemMessage(hWnd, IDC_ANIMATIONS, CB_SETITEMDATA,i2, 0);
					}
					if(Object->Header.iFrames)
						bFirst = FALSE;
					else
						bFirst = TRUE;
					goto Init;

				case ID_OBJECT_GENERAL:
					if(bFirst)
					{
						LoadFrameMessage();
						break;
					}
					DialogBox(hInstance, MAKEINTRESOURCE(IDD_GENERAL), hWnd, (DLGPROC) GeneralProc);
				break;

			// Frames:
				case IDC_RESET_FRAME_VIEW:
					for(i = 0; i < 3; i++)
						fFrameViewRot[i] = 0.0f;
					fFrameViewPos[X] = 
					fFrameViewPos[Y] = 0.0f;
					fFrameViewPos[Z] = -30.0f;
				break;

				case IDC_INSERT_FRAME:
					if(bFirst)
						MessageBox(hWnd, "You insert now the first frame.\nAll other frames must have the same base.\n",
								   "Info", MB_OK | MB_ICONINFORMATION);
					pbyTemp = GetFileName(hWnd, "Insert frame", WRL_FILE, 0, TRUE);
					if(!pbyTemp)
						break;
					// 	
					fp = fopen(pbyTemp, "rb");
					if(fp) // It's only oen file:
					{
						fclose(fp);
						InsertFrame(pbyTemp, hWnd);
						goto Init;
					}
					//
					sscanf(pbyTemp, "%s", byTemp); // Read the path
					pbyTemp += strlen(byTemp)+1;
					// Load the selected files:
					for(;;)
					{
						if(sscanf(pbyTemp, "%s", byTemp2) == EOF)
							break;
						if(byTemp[strlen(byTemp)-1] != '\\')
							sprintf(byTemp3, "%s\\%s", byTemp, byTemp2);
						else
							sprintf(byTemp3, "%s%s", byTemp, byTemp2);
						InsertFrame(byTemp3, hWnd);
						if(*(pbyTemp+strlen(byTemp2)) == 0)
							break;
						pbyTemp += strlen(byTemp2)+1;
					}
					goto Init;

				case IDC_DELETE_FRAME:
					if(Object->pFrameT->iUsed)
					{
						sprintf(byTemp, "This key-frame is %d times used by animation steps.\nThe animation steps using this key-frame will be deleted too.\nDelete now?", Object->pFrameT->iUsed);
						if(MessageBox(hWnd, byTemp, "Question", MB_YESNO | MB_ICONINFORMATION) == IDNO)
							break;
					}
					Object->DestroyFrame(Object->pFrameT->iID, TRUE);
					goto Init;
				
				case IDC_FRAME_MOVE_UP:
					if(!Object->pFrameT || Object->pFrameT->iID <= 0)
						break;
					Object->SwitchFrames(Object->pFrameT->iID, Object->pFrameT->iID-1, TRUE);
					goto Init;

				case IDC_FRAME_MOVE_DOWN:
					if(!Object->pFrameT || Object->pFrameT->iID >= Object->Header.iFrames-1)
						break;
					Object->SwitchFrames(Object->pFrameT->iID, Object->pFrameT->iID+1, TRUE);
					goto Init;

				case IDC_FRAME_NAME:
					i = SendDlgItemMessage(hWnd, IDC_FRAMES, LB_GETCURSEL, 0, 0L);
					GetDlgItemText(hWnd, IDC_FRAME_NAME, Object->pFrameT->byName, 256);
					SendDlgItemMessage(hWnd, IDC_FRAMES, LB_RESETCONTENT , 0, 0L);
					for(i2 = 0; i2 < Object->Header.iFrames; i2++)
					{
						sprintf(byTemp, "%s (Used:%d)", Object->pFrame[i2].byName, Object->pFrame[i2].iUsed);
						SendDlgItemMessage(hWnd, IDC_FRAMES, LB_ADDSTRING, 0, (LPARAM) byTemp);
					}
					SendDlgItemMessage(hWnd, IDC_FRAMES, LB_SETCURSEL, i, 0L);
					// Update the animation step list:
					if(!Object->pAnimationT || !Object->pAnimationT->pStepT)
						break;
					SendDlgItemMessage(hWnd, IDC_ANIMATION_STEPS, LB_RESETCONTENT , 0, 0L);
					for(i2 = 0; i2 < Object->pAnimationT->iSteps; i2++)
   					{
						sprintf(byTemp, "%s(%d)", Object->pAnimationT->pStep[i2].pFrame->byName, Object->pAnimationT->pStep[i2].iID);
						SendDlgItemMessage(hWnd, IDC_ANIMATION_STEPS, LB_ADDSTRING, 0, (LONG)(LPSTR) byTemp);
					}
					if(!Object->pAnimationT->pStepT)
						SendDlgItemMessage(hWnd, IDC_ANIMATION_STEPS, LB_SETCURSEL, 0, 0L);
					else
						SendDlgItemMessage(hWnd, IDC_ANIMATION_STEPS, LB_SETCURSEL, Object->pAnimationT->pStepT->iID, 0L);
				break;
				
				case IDC_FRAMES:
				Frames:
					if(!Object->Header.iFrames)
						break;
					i = SendDlgItemMessage(hWnd, IDC_FRAMES, LB_GETCURSEL, 0, 0L);
					if(i >= 0 && i < Object->Header.iFrames)
					{
						Object->SetFrameT(i);
						SetDlgItemText(hWnd, IDC_FRAME_NAME, Object->pFrameT->byName);
						sprintf(byTemp, "%d", Object->pFrameT->iUsed);
					}
					// Set move buttons:
					EnableWindow(GetDlgItem(hWnd, IDC_FRAME_MOVE_UP), TRUE);
					EnableWindow(GetDlgItem(hWnd, IDC_FRAME_MOVE_DOWN), TRUE);
					if(Object->pFrameT->iID <= 0)
						EnableWindow(GetDlgItem(hWnd, IDC_FRAME_MOVE_UP), FALSE);
					if(Object->pFrameT->iID >= Object->Header.iFrames-1)
						EnableWindow(GetDlgItem(hWnd, IDC_FRAME_MOVE_DOWN), FALSE);
				break;

			// Animations:
				case IDC_RESET_ANIMATION_VIEW:
					for(i = 0; i < 3; i++)
						fAnimationViewRot[i] = 0.0f;
					fAnimationViewPos[X] = 
					fAnimationViewPos[Y] = 0.0f;
					fAnimationViewPos[Z] = -30.0f;
				break;

				case IDC_NEW_ANIMATION:
					Object->AddAnimation(TRUE);
					SetDlgItemText(hWnd, IDC_ANIMATION_NAME, Object->pAnimationT->byName);
					SendDlgItemMessage(hWnd, IDC_ANIMATIONS, CB_RESETCONTENT, 0, 0L);
					for(i2 = 0; i2 < Object->Header.iAnimations; i2++)
					{
   						SendDlgItemMessage(hWnd, IDC_ANIMATIONS, CB_ADDSTRING, 0, (LONG)(LPSTR) Object->pAnimation[i2].byName);
     					SendDlgItemMessage(hWnd, IDC_ANIMATIONS, CB_SETITEMDATA,i2, 0);
					}
					if(Object->pAnimationT)
						 SendDlgItemMessage(hWnd, IDC_ANIMATIONS, CB_SETCURSEL, Object->pAnimationT->iID, 0L);
					EnableWindow(GetDlgItem(hWnd, IDC_ANIMATIONS), TRUE);
					EnableWindow(GetDlgItem(hWnd, IDC_ANIMATION_NAME), TRUE);
					EnableWindow(GetDlgItem(hWnd, IDC_INSERT_FRAME_TO_ANIMATION), TRUE);
					break;
				
				case IDC_ANIMATION_MOVE_UP:
					if(!Object->pAnimationT || Object->pAnimationT->iID <= 0)
						break;
					Object->SwitchAnimations(Object->pAnimationT->iID, Object->pAnimationT->iID-1, TRUE);
					SendDlgItemMessage(hWnd, IDC_ANIMATIONS, CB_RESETCONTENT, 0, 0L);
					for(i2 = 0; i2 < Object->Header.iAnimations; i2++)
					{
   						SendDlgItemMessage(hWnd, IDC_ANIMATIONS, CB_ADDSTRING, 0, (LONG)(LPSTR) Object->pAnimation[i2].byName);
     					SendDlgItemMessage(hWnd, IDC_ANIMATIONS, CB_SETITEMDATA,i2, 0);
					}
					if(Object->pAnimationT)
						 SendDlgItemMessage(hWnd, IDC_ANIMATIONS, CB_SETCURSEL, Object->pAnimationT->iID, 0L);
				break;

				case IDC_ANIMATION_MOVE_DOWN:
					if(!Object->pAnimationT || Object->pAnimationT->iID >= Object->Header.iAnimations-1)
						break;
					Object->SwitchAnimations(Object->pAnimationT->iID, Object->pAnimationT->iID+1, TRUE);
					SendDlgItemMessage(hWnd, IDC_ANIMATIONS, CB_RESETCONTENT, 0, 0L);
					for(i2 = 0; i2 < Object->Header.iAnimations; i2++)
					{
   						SendDlgItemMessage(hWnd, IDC_ANIMATIONS, CB_ADDSTRING, 0, (LONG)(LPSTR) Object->pAnimation[i2].byName);
     					SendDlgItemMessage(hWnd, IDC_ANIMATIONS, CB_SETITEMDATA,i2, 0);
					}
					if(Object->pAnimationT)
						 SendDlgItemMessage(hWnd, IDC_ANIMATIONS, CB_SETCURSEL, Object->pAnimationT->iID, 0L);
				break;

				case IDC_ANIMATIONS:
					i = SendDlgItemMessage(hWnd, IDC_ANIMATIONS, CB_GETCURSEL, 0, 0L);
					if(i >= 0 && i < Object->Header.iAnimations)
					{
						Object->SetAnimationT(i);
						SetDlgItemText(hWnd, IDC_ANIMATION_NAME, Object->pAnimationT->byName);
					}
					goto Init;
				
				case IDC_DELETE_ANIMATION:
					if(!Object->pAnimationT)
						break;
					Object->DestroyAnimation(Object->pAnimationT->iID, TRUE);
					SendDlgItemMessage(hWnd, IDC_ANIMATIONS, CB_RESETCONTENT, 0, 0L);
					for(i2 = 0; i2 < Object->Header.iAnimations; i2++)
					{
   						SendDlgItemMessage(hWnd, IDC_ANIMATIONS, CB_ADDSTRING, 0, (LONG)(LPSTR) Object->pAnimation[i2].byName);
     					SendDlgItemMessage(hWnd, IDC_ANIMATIONS, CB_SETITEMDATA,i2, 0);
					}
					if(Object->pAnimationT)
						 SendDlgItemMessage(hWnd, IDC_ANIMATIONS, CB_SETCURSEL, Object->pAnimationT->iID, 0L);
					goto Init;

				case IDC_ANIMATION_NAME:
					i = SendDlgItemMessage(hWnd, IDC_ANIMATIONS, CB_GETCURSEL, 0, 0L);
					GetDlgItemText(hWnd, IDC_ANIMATION_NAME, Object->pAnimationT->byName, 256);
					SendDlgItemMessage(hWnd, IDC_ANIMATIONS, CB_RESETCONTENT , 0, 0L);
					for(i2 = 0; i2 < Object->Header.iAnimations; i2++)
   						SendDlgItemMessage(hWnd, IDC_ANIMATIONS, CB_ADDSTRING, 0, (LONG)(LPSTR) Object->pAnimation[i2].byName);
					SendDlgItemMessage(hWnd, IDC_ANIMATIONS, CB_SETCURSEL, i, 0L);
				break;

				case IDC_ANIMATION_STEPS:
					if(!Object->pAnimationT || !Object->pAnimationT->iSteps)
						break;
					i = SendDlgItemMessage(hWnd, IDC_ANIMATION_STEPS, LB_GETCURSEL, 0, 0L);
					if(i >= 0 && i < Object->pAnimationT->iSteps)
					{
						Object->SetAnimationStepT(i);
						sprintf(byTemp, "%d", Object->pAnimationT->pStepT->dwInterpolateTime);
						SetDlgItemText(hWnd, IDC_ANIMATION_FRAME_INTERPOLATE_TIME, byTemp);
					}
					EnableWindow(GetDlgItem(hWnd, IDC_ANIMATION_FRAME_INTERPOLATE_TIME), TRUE);
					EnableWindow(GetDlgItem(hWnd, IDC_ANIMATION_FRAME_INTERPOLATE_TIME_ALL), TRUE);
					EnableWindow(GetDlgItem(hWnd, IDC_DELETE_ANIMATION_STEP), TRUE);
					// Set move buttons:
					EnableWindow(GetDlgItem(hWnd, IDC_ANIMATION_STEP_MOVE_UP), TRUE);
					EnableWindow(GetDlgItem(hWnd, IDC_ANIMATION_STEP_MOVE_DOWN), TRUE);
					// Set the selected frame to the same as the selected animation step:
					if(Object->pAnimationT && Object->pAnimationT->pStepT)
					{
						if(Object->pAnimationT->pStepT->iID <= 0)
							EnableWindow(GetDlgItem(hWnd, IDC_ANIMATION_STEP_MOVE_UP), FALSE);
						if(Object->pAnimationT->pStepT->iID >= Object->pAnimationT->iSteps-1)
							EnableWindow(GetDlgItem(hWnd, IDC_ANIMATION_STEP_MOVE_DOWN), FALSE);
						Object->pFrameT = Object->pAnimationT->pStepT->pFrame;
						SendDlgItemMessage(hWnd, IDC_FRAMES, LB_SETCURSEL, Object->pAnimationT->pStepT->iFrameID, 0L);
					}
					goto Frames;

				case IDC_DELETE_ANIMATION_STEP:
					if(!Object->pAnimationT || !Object->pAnimationT->pStep)
						break;
					Object->pAnimationT->pStepT->pFrame->iUsed--;
					Object->DestroyAnimationStep(Object->pAnimationT->iID, Object->pAnimationT->pStepT->iID, TRUE);
					goto Init;

				case IDC_INSERT_FRAME_TO_ANIMATION:
					if(!Object->pAnimationT || !Object->pFrameT)
						break;
					Object->AddAnimationStep(Object->pAnimationT->iID, TRUE);
					Object->SetAnimationStepFrame(Object->pAnimationT->iID, Object->pAnimationT->pStepT->iID, Object->pFrameT->iID, TRUE);
					Object->pAnimationT->pStepT->dwInterpolateTime = 1000;
					Object->SetInterpolateTime(Object->pAnimationT->pStepT->dwInterpolateTime);
					Object->pFrameT->iUsed++;
					goto Init;

				case IDC_ANIMATION_STEP_MOVE_UP:
					if(!Object->pAnimationT || !Object->pAnimationT->pStepT || Object->pAnimationT->pStepT->iID <= 0)
						break;
					Object->SwitchAnimationSteps(Object->pAnimationT->iID, Object->pAnimationT->pStepT->iID, Object->pAnimationT->pStepT->iID-1, TRUE);
					goto Init;

				case IDC_ANIMATION_STEP_MOVE_DOWN:
					if(!Object->pAnimationT || !Object->pAnimationT->pStepT ||
					   Object->pAnimationT->pStepT->iID >= Object->pAnimationT->iSteps-1)
						break;
					Object->SwitchAnimationSteps(Object->pAnimationT->iID, Object->pAnimationT->pStepT->iID, Object->pAnimationT->pStepT->iID+1, TRUE);
					goto Init;

				case IDC_ANIMATION_FRAME_INTERPOLATE_TIME:
					if(!Object->pAnimationT || !Object->pAnimationT->pStepT)
						break;
					GetDlgItemText(hWnd, IDC_ANIMATION_FRAME_INTERPOLATE_TIME, byTemp, 256);
					Object->pAnimationT->pStepT->dwInterpolateTime = atoi(byTemp);
					if(Object->pAnimationT->pStepT->dwInterpolateTime < 1)
					{	
						Object->pAnimationT->pStepT->dwInterpolateTime = 1;
						sprintf(byTemp, "%d", Object->pAnimationT->pStepT->dwInterpolateTime);
						SetDlgItemText(hWnd, IDC_ANIMATION_FRAME_INTERPOLATE_TIME, byTemp);
					}
					Object->SetInterpolateTime(Object->pAnimationT->pStepT->dwInterpolateTime);
					GetDlgItemText(hWnd, IDC_ANIMATION_PLAY, byTemp, 256);
					Object->CalculateInterpolations();
				break;

				case IDC_ANIMATION_FRAME_INTERPOLATE_TIME_ALL:
					if(!Object->pAnimationT || !Object->pAnimationT->pStepT)
						break;
					GetDlgItemText(hWnd, IDC_ANIMATION_FRAME_INTERPOLATE_TIME, byTemp, 256);
					Object->pAnimationT->pStepT->dwInterpolateTime = atoi(byTemp);
					if(Object->pAnimationT->pStepT->dwInterpolateTime < 1)
					{	
						Object->pAnimationT->pStepT->dwInterpolateTime = 1;
						sprintf(byTemp, "%d", Object->pAnimationT->pStepT->dwInterpolateTime);
						SetDlgItemText(hWnd, IDC_ANIMATION_FRAME_INTERPOLATE_TIME, byTemp);
					}
					pTempAniStep = Object->pAnimationT->pStepT;
					dwInterpolateTime = Object->pAnimationT->pStepT->dwInterpolateTime;
					for(i = 0; i < Object->pAnimationT->iSteps; i++)
					{
						Object->pAnimationT->pStepT = &Object->pAnimationT->pStep[i];
						Object->SetInterpolateTime(dwInterpolateTime);
					}
					Object->pAnimationT->pStepT = pTempAniStep;
					GetDlgItemText(hWnd, IDC_ANIMATION_PLAY, byTemp, 256);
					Object->CalculateInterpolations();
				break;

				case IDC_ANIMATION_PLAY:
				// Start or stop animation play:
					if(!Object->pAnimationT)
						break;
					GetDlgItemText(hWnd, IDC_ANIMATION_PLAY, byTemp, 256);
					if(!strcmp(byTemp, "&Start"))
					{ // Start the animation:
						if(!Object->pAnimationT->iSteps)
							break; // There is no animation!
						Object->SetupAnimationData(TRUE);
						SetDlgItemText(hWnd, IDC_ANIMATION_PLAY, "&Stop");
					}
					else
						if(!strcmp(byTemp, "&Stop"))
						{ // Stop the animation:
							SetDlgItemText(hWnd, IDC_ANIMATION_PLAY, "&Start");
						}
				break;

				// Help:
				case ID_FILE_QUIT:
				Quit:
					if(MessageBox(hWnd, "Really quit?", "Question", MB_YESNO | MB_ICONINFORMATION) == IDYES)
						EndDialog(hWnd, FALSE);
	 				KillTimer(hWnd, 1);
					DestroyOpenGL(hWndAnimationView, hDCAnimationView, hRCAnimationView);
					DestroyOpenGL(hWndFrameView, hDCFrameView, hRCFrameView);
					hWndASO = NULL;
				break;

				case ID_HELP_HELP:
					ShellExecute(0, "open", "help.html", 0, 0, SW_SHOW);
				break;
				
				case ID_HELP_HOMEPAGE:
					ShellExecute(0, "open", "http://www.ablazespace.de/", 0, 0, SW_SHOW);
				break;

				case ID_HELP_CREDITS:
					DialogBox(hInstance, MAKEINTRESOURCE(IDD_CREDITS), hWnd, (DLGPROC) CreditsProc);
				break;
				
				case ID_HELP_BLENDER_HOMEPAGE:
					ShellExecute(0, "open", "http://www.blender.nl/", 0, 0, SW_SHOW);
				break;

				case ID_HELP_NEHE_HOMEPAGE:
					ShellExecute(0, "open", "http://nehe.gamedev.net/", 0, 0, SW_SHOW);
				break;
			}
		break;

		case WM_CLOSE:
			goto Quit;
    }
    return FALSE;
} // end WinProc()

LRESULT CALLBACK CreditsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin CreditsProc()
    switch(iMessage)
    {
        case WM_INITDIALOG:
           	SetDlgItemText(hWnd, IDC_CREDITS_VERSION, PROGRAM_VERSION);
           	SetDlgItemText(hWnd, IDC_CREDITS_BUILD_TIME, __TIME__);
           	SetDlgItemText(hWnd, IDC_CREDITS_BUILD_DATE, __DATE__);
		    ShowWindow(hWnd, iCmdShow);
			UpdateWindow(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_CREDITS_OK:
				OK:
					EndDialog(hWnd, FALSE);
				break;
            }
        break;

		case WM_CLOSE:
			goto OK;
    }
    return FALSE;
} // end CreditsProc()

LRESULT CALLBACK GeneralProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin GeneralProc()
	switch(iMessage)
    {
        case WM_INITDIALOG:
           	hWndGeneral = hWnd;
			SetDlgItemText(hWnd, IDC_GENERAL_OBJECT_NAME, Object->Header.byName);
			SendDlgItemMessage(hWnd, IDC_GENERAL_VERTEX_COLOR, BM_SETCHECK, Object->Header.bUseVertexColorData, 0L);
			SendDlgItemMessage(hWnd, IDC_GENERAL_VERTEX__TEXTURE_POS, BM_SETCHECK, Object->Header.bUseVertexTexturePosData, 0L);		    
			// Shows the object tree:
			hWndTV = CreateWindowEx(WS_EX_CLIENTEDGE, WC_TREEVIEW, "",
									WS_VISIBLE | WS_CHILD | WS_BORDER | TVS_HASLINES |
									TVS_HASBUTTONS | TVS_LINESATROOT,
									20, 80, 350, 300, hWnd, NULL, hInstance, NULL);
		    ObjectViewFillTree(hWndTV);
			pObjectT = Object;
			SetObjectViewPropertysView();
			ShowWindow(hWnd, iCmdShow);
			UpdateWindow(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_GENERAL_OK:
				OK:
					EndDialog(hWnd, FALSE);
				break;

				case IDC_GENERAL_OBJECT_NAME:
					GetDlgItemText(hWnd, IDC_GENERAL_OBJECT_NAME, Object->Header.byName, 256);
				break;

				case IDC_GENERAL_VERTEX_COLOR:
				    Object->Header.bUseVertexColorData = SendDlgItemMessage(hWnd, IDC_GENERAL_VERTEX_COLOR, BM_GETCHECK, 0, 0L);
				break;

				case IDC_GENERAL_VERTEX__TEXTURE_POS:
				    Object->Header.bUseVertexTexturePosData = SendDlgItemMessage(hWnd, IDC_GENERAL_VERTEX__TEXTURE_POS, BM_GETCHECK, 0, 0L);
				break;

				case IDC_GENERAL_OBJECT_ACTIVE:
					if(!pObjectT)
						break;
					pObjectT->Header.bActive = SendDlgItemMessage(hWnd, IDC_GENERAL_OBJECT_ACTIVE, BM_GETCHECK, 0, 0L);
				break;

				case IDC_GENERAL_OBJECT_CHILDREN_ACTIVE:
					if(!pObjectT)
						break;
					pObjectT->Header.bChildrenActive = SendDlgItemMessage(hWnd, IDC_GENERAL_OBJECT_CHILDREN_ACTIVE, BM_GETCHECK, 0, 0L);
				break;
            }
        break;

        case WM_NOTIFY:
            if (((NMHDR*)lParam)->hwndFrom == hWndTV)
            {
                if (((NMHDR*)lParam)->code == TVN_SELCHANGED)
                    ObjectViewOnTreeSelect(hWndTV, (NM_TREEVIEW*)lParam);
            }
		break;

		case WM_CLOSE:
			goto OK;
    }
    return FALSE;
} // end GeneralProc()

void InsertFrame(char *pbyFilename, HWND hWnd)
{ // begin InsertFrame()
	Object->AddFrame(FALSE);
	Object->iID = 0;
	Object->Header.bActive = Object->Header.bChildrenActive = TRUE;
	Object->Header.bUseVertexColorData = TRUE;
	Object->Header.bUseVertexTexturePosData = TRUE;
	if(bFirst)
		iObjects = 1;
	if(InsertFrameWrl(pbyFilename, Object))
	{ // There was an error destroy the frame:
		Object->CutFrames(Object->Header.iFrames-1, TRUE);
		MessageBox(hWnd, byTemp2, "ERROR", MB_OK | MB_ICONINFORMATION);
		return;
	}
	memcpy(Object->Matrix, SceneMatrix, sizeof(MATRIX));
	bFirst = FALSE;
} // end InsertFrame()

void LoadFrameMessage(void)
{ // begin LoadFrameMessage()
	MessageBox(hWndASO, "There is no frame! Load anyone to do this action.", "Info", MB_OK | MB_ICONINFORMATION);
} // end LoadFrameMessage()

void SetObjectViewPropertysView(void)
{ // begin SetObjectViewPropertysView()
	char byTemp[256];

	if(!pObjectT)
	{
		EnableWindow(GetDlgItem(hWndGeneral, IDC_GENERAL_OBJECT_ACTIVE), FALSE);
		EnableWindow(GetDlgItem(hWndGeneral, IDC_GENERAL_OBJECT_CHILDREN_ACTIVE), FALSE);
		return;
	}
	EnableWindow(GetDlgItem(hWndGeneral, IDC_GENERAL_OBJECT_ACTIVE), TRUE);
	EnableWindow(GetDlgItem(hWndGeneral, IDC_GENERAL_OBJECT_CHILDREN_ACTIVE), TRUE);
	SendDlgItemMessage(hWndGeneral, IDC_GENERAL_OBJECT_ACTIVE, BM_SETCHECK, pObjectT->Header.bActive, 0L);
    SendDlgItemMessage(hWndGeneral, IDC_GENERAL_OBJECT_CHILDREN_ACTIVE, BM_SETCHECK, pObjectT->Header.bChildrenActive, 0L);
	// Infos:
	sprintf(byTemp, "%d", pObjectT->pFrame[0].iVertices);
	SetDlgItemText(hWndGeneral, IDC_GENERAL_VERTICES, byTemp);
	sprintf(byTemp, "%d", pObjectT->pFrame[0].iTextureCoords);
	SetDlgItemText(hWndGeneral, IDC_GENERAL_TEXTURE_COORDS, byTemp);
	sprintf(byTemp, "%d", pObjectT->pFrame[0].iDiffuseColors);
	SetDlgItemText(hWndGeneral, IDC_GENERAL_COLOR_VERTICES, byTemp);
	sprintf(byTemp, "%d", pObjectT->pFrame[0].iNormals);
	SetDlgItemText(hWndGeneral, IDC_GENERAL_NORMALS, byTemp);
	sprintf(byTemp, "%d", pObjectT->pFrame[0].iFaces);
	SetDlgItemText(hWndGeneral, IDC_GENERAL_FACES, byTemp);
} // end SetObjectViewPropertysView()

void ObjectViewOnTreeSelect(HWND hWndTV, NM_TREEVIEW *ptv)
{ // begin ObjectViewOnTreeSelect()
    NODEINFO *pni;
	int iCounter, iCounter2;
    int *i;

	if(!ptv)
    {
        TV_ITEM tvi;
        // get lParam of current tree node
        tvi.hItem  = TreeView_GetSelection(hWndTV);
        tvi.mask   = TVIF_PARAM;
        tvi.lParam = 0;
        TreeView_GetItem(hWndTV, &tvi);
        pni = (NODEINFO*)tvi.lParam;
    }
    else
    {
        pni = (NODEINFO*)ptv->itemNew.lParam;
    }
	// Find now the object:
	if(pni->lParam1 == -1)
	{
		pObjectT = NULL;
		SetObjectViewPropertysView();
		return;
	}
	pObjectT = Object;
	iCounter = iCounter2 = 0;
	i = new int[iObjects];
	memset(i, 0, sizeof(int)*iObjects);
	for(;;)
	{
		if(pni->lParam1 == iCounter)
			break;
		if(!pObjectT->Header.iChildren)
		{
			if(!pObjectT->pParent)
				break;
			pObjectT = pObjectT->pParent;
			iCounter2--;
			continue;
		}
		if(i[iCounter2] < pObjectT->Header.iChildren)
		{
			pObjectT = pObjectT->pChild[i[iCounter2]];
			iCounter++;
			i[iCounter2]++;
			iCounter2++;
			goto IntoChild;
		}
		// All children from this child are now checked:
		if(!pObjectT->pParent)
			break;
		pObjectT = pObjectT->pParent;
		iCounter2--;
		continue;
	IntoChild:
		continue;
	}
	delete i;
	SetObjectViewPropertysView();
	// Now show the object property's:
} // end ObjectViewOnTreeSelect()

void ObjectViewFillTree(HWND hwndTV)
{ // begin ObjectViewFillTree()
    HTREEITEM hTree;
	
    hTree = TVAddNode(TVI_ROOT, "Object", TRUE, NULL, NULL, -1, 0, NULL);
    Object->InsertObjectIntoObjectView(hTree);
} // end ObjectViewFillTree()

HTREEITEM TVAddNode(
    HTREEITEM       hParent, 
    LPSTR           szText, 
    BOOL            fKids, 
    int             iImage, 
    SELCALLBACK     Callback, 
    LPARAM          lParam1, 
    LPARAM          lParam2,
    PRINTCALLBACK   printCallback)
{ // begin TVAddNode()
    TV_INSERTSTRUCT tvi;
    NODEINFO *pni;

    pni = (NODEINFO *)LocalAlloc(LPTR, sizeof(NODEINFO));
    if (pni == NULL)
        return NULL;
    pni->lParam1        = lParam1;
    pni->lParam2        = lParam2;
    pni->Callback       = Callback;
    pni->printCallback  = printCallback;
    // Add Node to treeview
    tvi.hParent             = hParent;
    tvi.hInsertAfter        = TVI_LAST;
    tvi.item.mask           = TVIF_TEXT | TVIF_IMAGE | TVIF_SELECTEDIMAGE | TVIF_PARAM | TVIF_CHILDREN;
    tvi.item.iImage         = iImage;// - IDI_FIRSTIMAGE;
    tvi.item.iSelectedImage = iImage;// - IDI_FIRSTIMAGE;
    tvi.item.lParam         = (LPARAM)pni;
    tvi.item.cChildren      = fKids;
    tvi.item.pszText        = szText;
    return TreeView_InsertItem(hWndTV, &tvi);
} // end TVAddNode()

void AddCapsToTV(HTREEITEM hRoot, CAPDEFS *pcds, LPARAM lParam1)
{ // begin AddCapsToTV()
    HTREEITEM hTree;
    HTREEITEM hParent[20];
    char *name;
    int level=0;
    BOOL fRoot = TRUE; // the first one is always a root

    hParent[0] = hRoot;
    while (name = pcds->szName)
    {
        if (*name == '-')
        {
            level--;
            name++;
        }
        if (*name == '+')
        {
            fRoot = TRUE;
            name++;
        }
        if (*name)
        {
            hTree = TVAddNode(hParent[level], name, fRoot, NULL,
                              pcds->Callback, lParam1,
                              pcds->lParam2, pcds->printCallback);
            if (fRoot)
            {
                level++;
                hParent[level] = hTree;
                fRoot = FALSE;
            }
        }
        pcds++;  // Get next Cap bit definition
    }
} // end AddCapsToTV()

char *GetFileName(HWND hWnd,  char *pbyTitle, char *pbyFilter, BOOL bMode, BOOL bMultiSelect)
{ // begin GetFileName()
    static char file[256];
    static char fileTitle[256];
    OPENFILENAME ofn;

    lstrcpy( file, "");
    lstrcpy( fileTitle, "");

    ofn.lStructSize       = sizeof(OPENFILENAME);
    ofn.hwndOwner         = hWnd;
#ifdef WIN32
    ofn.hInstance         = (HINSTANCE) GetWindowLong(hWnd, GWL_HINSTANCE);
#else
    ofn.hInstance         = (HINSTANCE) GetWindowWord(hWnd, GWW_HINSTANCE);
#endif
    ofn.lpstrFilter       = pbyFilter;
    ofn.lpstrCustomFilter = (LPSTR) NULL;
    ofn.nMaxCustFilter    = 0L;
    ofn.nFilterIndex      = 1L;
    ofn.lpstrFile         = file;
    ofn.nMaxFile          = sizeof(file);
    ofn.lpstrFileTitle    = fileTitle;
    ofn.nMaxFileTitle     = sizeof(fileTitle);
    ofn.lpstrInitialDir   = "d:\\";
    ofn.lpstrTitle        = pbyTitle;
    ofn.nFileOffset       = 0;
    ofn.nFileExtension    = 0;
    ofn.lpstrDefExt       = pbyFilter;
	ofn.lCustData         = 0;

	ofn.Flags = OFN_PATHMUSTEXIST | OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_NONETWORKBUTTON;
    if(!bMode) // We loads a file...
		ofn.Flags |= OFN_FILEMUSTEXIST;
	if(bMultiSelect)
		ofn.Flags |= OFN_ALLOWMULTISELECT;
    if (GetOpenFileName(&ofn))
	    return (char*)ofn.lpstrFile;
	return NULL;
} // end GetFileName()

HRESULT InsertFrameWrl(char *pbyFilenameT, AS_OBJECT *pObject)
{ // begin InsertFrameWrl()
	char *pstr = NULL;
	FILE *pFile;
	int i;

	if(!pbyFilenameT)
		return 1;
	pFile = fopen(pbyFilenameT, "rt");
	if(!pFile)
		return 1;
	pbyGlobalFilename = pbyFilenameT;
	CurrentObj = pObject;
	iDefinitions = GENERAL;
	bExpectingNumbers = FALSE;
	iExpectedNumbers = NONE;
	iSize = 500;
	memset(SceneMatrix, 0, sizeof(MATRIX));
	for(;;)
	{
		if((i = WrlParseStatement(pFile)))
			break;
	}
	fclose(pFile);
	if(i != 0 && i != 1)
		return 1;
	return 0;
} // end InsertFrameWrl()

HRESULT WrlParseStatement(FILE *fp)
{ // begin WrlParseStatement()
	char str[256], byTemp[256];
	char *pstr;
	int i, x, y, iCounter, iCounter2;
	int *iTemp, *iOCounter;

	if(fscanf(fp, "%s", str) == EOF)
		return 1;
	if (str[0] == '#') 
		return 0;
	if(bExpectingNumbers)
	{ // We read a set of numbers:
		if(str[0] == ']') 
		{ // We have read all required numbers:
		EndExpectedNumbers:
			bExpectingNumbers = FALSE;
			iExpectedNumbers = NONE;
			return 0;
		}
		switch(iExpectedNumbers)
		{
			case MATERIAL_DIFFUSECOLOR:
				for(CurrentObj->pFrameT->iDiffuseColors = 0;; CurrentObj->pFrameT->iDiffuseColors++)
				{
					if(CurrentObj->pFrameT->iDiffuseColors == iSize)
					{ // Increase the reserved memory:
						iSize += START_SIZE;
						CurrentObj->pFrameT->fDiffuseColor = (FLOAT3 *) realloc(CurrentObj->pFrameT->fDiffuseColor, sizeof(FLOAT3)*iSize);
					}
					fscanf(fp, "%s", str);
					pstr = strtok(str, AS_FORMAT_TOKENS);					
					if(strchr(pstr, ']')) 
						break;
					CurrentObj->pFrameT->fDiffuseColor[CurrentObj->pFrameT->iDiffuseColors][0] = (float) atof(str);
					fscanf(fp, "%s", str);
					CurrentObj->pFrameT->fDiffuseColor[CurrentObj->pFrameT->iDiffuseColors][1] = (float) atof(str);
					fscanf(fp, "%s", str);
					CurrentObj->pFrameT->fDiffuseColor[CurrentObj->pFrameT->iDiffuseColors][2] = (float) atof(str);
				}
				CurrentObj->pFrameT->fDiffuseColor = (FLOAT3 *) realloc(CurrentObj->pFrameT->fDiffuseColor, sizeof(FLOAT3)*CurrentObj->pFrameT->iDiffuseColors);
				goto EndExpectedNumbers;

			case COORDINATE3_POINT:
				for(CurrentObj->pFrameT->iVertices = 0;; CurrentObj->pFrameT->iVertices++)
				{
					if(CurrentObj->pFrameT->iVertices == iSize)
					{ // Increase the reserved memory:
						iSize += START_SIZE;
						CurrentObj->pFrameT->fVertex = (FLOAT3 *) realloc(CurrentObj->pFrameT->fVertex, sizeof(FLOAT3)*iSize);
					}
					fscanf(fp, "%s", str);
					pstr = strtok(str, AS_FORMAT_TOKENS);					
					if(strchr(pstr, ']')) 
						break;
					CurrentObj->pFrameT->fVertex[CurrentObj->pFrameT->iVertices][0] = (float) atof(str);
					fscanf(fp, "%s", str);
					CurrentObj->pFrameT->fVertex[CurrentObj->pFrameT->iVertices][1] = (float) atof(str);
					fscanf(fp, "%s", str);
					CurrentObj->pFrameT->fVertex[CurrentObj->pFrameT->iVertices][2] = (float) atof(str);
				}
				CurrentObj->pFrameT->fVertex = (FLOAT3 *) realloc(CurrentObj->pFrameT->fVertex, sizeof(FLOAT3)*CurrentObj->pFrameT->iVertices);
				goto EndExpectedNumbers;

			case TEXTURECOOREDIATE2_POINT:
				for(CurrentObj->pFrameT->iTextureCoords = 0;; CurrentObj->pFrameT->iTextureCoords++)
				{
					if(CurrentObj->pFrameT->iTextureCoords == iSize)
					{ // Increase the reserved memory:
						iSize += START_SIZE;
						CurrentObj->pFrameT->fTextureCoord = (FLOAT2 *) realloc(CurrentObj->pFrameT->fTextureCoord, sizeof(FLOAT2)*iSize);
					}
					fscanf(fp, "%s", str);
					pstr = strtok(str, AS_FORMAT_TOKENS);					
					if(strchr(pstr, ']')) 
						break;
					CurrentObj->pFrameT->fTextureCoord[CurrentObj->pFrameT->iTextureCoords][0] = (float) atof(str);
					fscanf(fp, "%s", str);
					CurrentObj->pFrameT->fTextureCoord[CurrentObj->pFrameT->iTextureCoords][1] = (float) atof(str);
				}
				CurrentObj->pFrameT->fTextureCoord = (FLOAT2 *) realloc(CurrentObj->pFrameT->fTextureCoord, sizeof(FLOAT2)*CurrentObj->pFrameT->iTextureCoords);
				goto EndExpectedNumbers;

			case INDEXEDFACESET_COODNINDEX:
				for(CurrentObj->pFrameT->iFaces = 0;; CurrentObj->pFrameT->iFaces++)
				{
					if(CurrentObj->pFrameT->iFaces == iSize)
					{ // Increase the reserved memory:
						iSize += START_SIZE;
						CurrentObj->pFrameT->iFace = (INT3 *) realloc(CurrentObj->pFrameT->iFace, sizeof(INT3)*iSize);
					}
					for(i = 0; i < 5; i++)
					{
						fscanf(fp, "%s", str);
						if(((int) atoi(str)) == -1)
							break;
						if(i >= 3)
						{
							sprintf(byTemp2, "In the object %s from file %s are more than three vertices per face!\nThis frame couldn't insert to the object!",
									CurrentObj->Header.byName, pbyGlobalFilename);
							return 2;
						}
						pstr = strtok(str, AS_FORMAT_TOKENS);
						if(strchr(pstr, ']')) 
							goto End;
						CurrentObj->pFrameT->iFace[CurrentObj->pFrameT->iFaces][i] = (int) atoi(str);
					}
				}
			End:
				CurrentObj->pFrameT->iFace = (INT3 *) realloc(CurrentObj->pFrameT->iFace, sizeof(INT3)*CurrentObj->pFrameT->iFaces);
				goto EndExpectedNumbers;

			case MATRIXTRANSFORMATION_DATA:
				for(y = 0; y < 4; y++)
				{
					for(x = 0; x < 4; x++)
					{
						Matrix[y][x] = (float) atof(str);
						if(y == 3 && x == 3)
							continue;
						fscanf(fp, "%s", str);
					}
				}
				goto EndExpectedNumbers;
		}
	}
	if(iDefinitions == GENERAL)
	{ // We will collect general information:
		if(!strcmp(str, "DEF")) 
		{
			fscanf(fp, "%s", byTemp); // Get the name
			fscanf(fp, "%s", str);
			if(!strcmp(str, "Separator")) 
			{	// Create a new object:
				if(bFirst)
				{ // This is the first frame, so this is the base:
					AS_OBJECT *pTempObj = new AS_OBJECT;
					pTempObj->AddFrame(FALSE);
					pTempObj->iID = iObjects++;
					pTempObj->Header.bActive = pTempObj->Header.bChildrenActive = TRUE;
					pTempObj->Header.bUseVertexColorData = TRUE;
					pTempObj->Header.bUseVertexTexturePosData = TRUE;
					CurrentObj->Header.iChildren++;
					CurrentObj->pChild = (AS_OBJECT **) realloc(CurrentObj->pChild,
															   sizeof(AS_OBJECT)*CurrentObj->Header.iChildren);
					CurrentObj->pChild[CurrentObj->Header.iChildren-1] = pTempObj;
					pTempObj->pParent = CurrentObj;
					pTempObj->Header.iNestLevel = CurrentObj->Header.iNestLevel+1;
					CurrentObj = pTempObj;
					strcpy(CurrentObj->Header.byName, byTemp);
				}
				else
				{ // Add new frame:
					pObjectT = CurrentObj;
					iCounter = iCounter2 = 0;
					iOCounter = new int[iObjects];
					memset(iOCounter, 0, sizeof(int)*iObjects);
					for(;;)
					{
						if(!strcmp(byTemp, pObjectT->Header.byName))
						{ // We found the child:
							CurrentObj = pObjectT;
							CurrentObj->AddFrame(FALSE);
							goto SetDefaults;
						}
						if(!pObjectT->Header.iChildren)
						{
							if(!pObjectT->pParent)
								break;
							pObjectT = pObjectT->pParent;
							iCounter2--;
							continue;
						}
						if(iOCounter[iCounter2] < pObjectT->Header.iChildren)
						{
							pObjectT = pObjectT->pChild[iOCounter[iCounter2]];
							iCounter++;
							iOCounter[iCounter2]++;
							iCounter2++;
							goto IntoChild;
						}
						// All children from this child are now checked:
						if(!pObjectT->pParent)
							break;
						pObjectT = pObjectT->pParent;
						iCounter2--;
						continue;
					IntoChild:
						continue;
					}
					delete iOCounter;			
					// The child couldn't found -> this object is not the same as the base!
					sprintf(byTemp2, "The object %s from file %s isn't a part from the base object!\nThis frame couldn't insert to the object!", 
							byTemp, pbyGlobalFilename);
					return 2;
				}
			SetDefaults:
				CurrentObj->fScale[X] = CurrentObj->fScale[Y] = CurrentObj->fScale[Z] = 1.0f;
				return 0;
			}
			return 0;
		}
		else if(!strcmp(str, "Texture2")) {
			// Now we read texture information:
			iDefinitions = TEXTURE2;
			return 0;
		}
		else if(!strcmp(str, "Material")) {
			// Now we read material information:
			iDefinitions = MATERIAL;
			return 0;
		}
		else if(!strcmp(str, "Coordinate3")) {
			// Now we read vertex coordinate information:
			iDefinitions = COORDINATE3;
			return 0;
		}
		else if(!strcmp(str, "TextureCoordinate2")) {
			// Now we read texture coordinate information:
			iDefinitions = TEXTURECOORDINATE2;
			return 0;
		}
		else if(!strcmp(str, "IndexedFaceSet")) {
			// Now we read face information:
			iDefinitions = INDEXEDFACESET;
			return 0;
		}
		else if(!strcmp(str, "MaterialBinding")) {
			// Now we read material binding information:
			iDefinitions = MATERIALBINDING;
			return 0;
		}
		else if(str[0] == '}') {
			// Check this frame whith the first frame:
			if(!bFirst)
			{
				if(CurrentObj->pFrame[0].iDiffuseColors != CurrentObj->pFrameT->iDiffuseColors)
				{
					sprintf(byTemp2, "The object %s from file %s has not the same number of diffuse colors(%d)\nas the first frame(%d)!\nThis frame couldn't insert to the object!",
							CurrentObj->Header.byName, pbyGlobalFilename, CurrentObj->pFrameT->iDiffuseColors, CurrentObj->pFrame[0].iDiffuseColors);
					return 2;
				}
				if(CurrentObj->pFrame[0].iVertices!= CurrentObj->pFrameT->iVertices)
				{
					sprintf(byTemp2, "The object %s from file %s has not the same number of vertices(%d)\nas the first frame(%d)!\nThis frame couldn't insert to the object!",
							CurrentObj->Header.byName, pbyGlobalFilename, CurrentObj->pFrameT->iVertices, CurrentObj->pFrame[0].iVertices);
					return 2;
				}
				if(CurrentObj->pFrame[0].iTextureCoords != CurrentObj->pFrameT->iTextureCoords)
				{
					sprintf(byTemp2, "The object %s from file %s has not the same number of texture coordinates(%d)\nas the first frame(%d)!\nThis frame couldn't insert to the object!",
							CurrentObj->Header.byName, pbyGlobalFilename, CurrentObj->pFrameT->iTextureCoords, CurrentObj->pFrame[0].iTextureCoords);
					return 2;
				}
				if(CurrentObj->pFrame[0].iFaces != CurrentObj->pFrameT->iFaces)
				{
					sprintf(byTemp2, "The object %s from file %s has not the same number of faces(%d)\nas the first frame(%d)!\nThis frame couldn't insert to the object!",
							CurrentObj->Header.byName, pbyGlobalFilename, CurrentObj->pFrameT->iFaces, CurrentObj->pFrame[0].iFaces);
					return 2;
				}
			}
			// Calculate normals:
			CurrentObj->pFrameT->iNormals = CurrentObj->pFrameT->iFaces;
			CurrentObj->pFrameT->fNormal = new FLOAT3[CurrentObj->pFrameT->iNormals];
			for(i = 0; i < CurrentObj->pFrameT->iFaces; i++)
				NormalizeFace(&CurrentObj->pFrameT->fNormal[i], CurrentObj->pFrameT->fVertex[CurrentObj->pFrameT->iFace[i][0]],
							  CurrentObj->pFrameT->fVertex[CurrentObj->pFrameT->iFace[i][1]],
							  CurrentObj->pFrameT->fVertex[CurrentObj->pFrameT->iFace[i][2]]);
			if(!CurrentObj->pParent)
				return 0; // The object is complete
			CurrentObj = CurrentObj->pParent;
		}
		else if(!strcmp(str, "MatrixTransform")) {
			// Read a object matrix:
			iDefinitions = MATRIXTRANSFORM;
			return 0;
		}
		else if(!strcmp(str, "PerspectiveCamera")) {
			memcpy(SceneMatrix, Matrix, sizeof(MATRIX));
		}
		else
			if(!strcmp(str, "USE")) {
			// The read data should is the data from this object:
			fscanf(fp, "%s", byTemp); // Get the object name
			// Now find the object:
			pObjectT = Object;
			iCounter = 0;
			iTemp = new int[iObjects];
			memset(iTemp, 0, sizeof(int)*iObjects);
			for(;;)
			{
				if(!strcmp(byTemp, pObjectT->Header.byName))
					break;
				if(!pObjectT->Header.iChildren)
				{
					if(!pObjectT->pParent)
						break;
					pObjectT = pObjectT->pParent;
					iCounter--;
					continue;
				}
				if(iTemp[iCounter] < pObjectT->Header.iChildren)
				{
					pObjectT = pObjectT->pChild[iTemp[iCounter]];
					iTemp[iCounter]++;
					iCounter++;
					goto IntoChild3;
				}
				// All children from this child are now checked:
				if(!pObjectT->pParent)
					break;
				pObjectT = pObjectT->pParent;
				iCounter--;
				continue;
			IntoChild3:
				continue;
			}
			delete iTemp;
			// Now give the object the data:
			memcpy(pObjectT->pFrameT->Matrix, Matrix, sizeof(MATRIX));
			return 0;
		}
		return 0;
	}
	if(!strcmp(str, "}"))
	{ // The information is now complete:
		iDefinitions = GENERAL;
		return 0;
	}
	// Show what information we will receive:
	switch(iDefinitions)
	{
		case TEXTURE2:
			if(!strcmp(str, "filename")) {
			// Store the texture filename:
				fscanf(fp, "%s", str);
				CurrentObj->pbyTextureFilename = new char[strlen(str)+1];
				strcpy(CurrentObj->pbyTextureFilename, str);
			}
			else
			if(!strcmp(str, "wrapS")) {
			}
			else
			if(!strcmp(str, "wrapT")) {
			}
		break;

		case MATERIAL:
			if(!strcmp(str, "diffuseColor")) {
				bExpectingNumbers = TRUE;
				iExpectedNumbers = MATERIAL_DIFFUSECOLOR;
				// Reserve temp memory:
				iSize = START_SIZE;
				CurrentObj->pFrameT->fDiffuseColor = (FLOAT3 *) malloc(sizeof(FLOAT3)*iSize);
			}		
		break;

		case COORDINATE3:
			if(!strcmp(str, "point")) {
				bExpectingNumbers = TRUE;
				iExpectedNumbers = COORDINATE3_POINT;
				// Reserve temp memory:
				iSize = START_SIZE;
				CurrentObj->pFrameT->fVertex = (FLOAT3 *) malloc(sizeof(FLOAT3)*iSize);
			}		
		break;
		
		case TEXTURECOORDINATE2:
			if(!strcmp(str, "point")) {
				bExpectingNumbers = TRUE;
				iExpectedNumbers = TEXTURECOOREDIATE2_POINT;
				// Reserve temp memory:
				iSize = START_SIZE;
				CurrentObj->pFrameT->fTextureCoord = (FLOAT2 *) malloc(sizeof(FLOAT2)*iSize);
			}		
		break;
		
		case INDEXEDFACESET:
			if(!strcmp(str, "coordIndex")) {
				bExpectingNumbers = TRUE;
				iExpectedNumbers = INDEXEDFACESET_COODNINDEX;
				// Reserve temp memory:
				iSize = START_SIZE;
				CurrentObj->pFrameT->iFace = (INT3 *) malloc(sizeof(INT3)*iSize);
			}		
		break;
	
		case MATERIALBINDING:
		break;

		case MATRIXTRANSFORM:
			if(!strcmp(str, "matrix")) {
				bExpectingNumbers = TRUE;
				iExpectedNumbers = MATRIXTRANSFORMATION_DATA;
			}		
		break;
	}
	return 0;
} // end WrlParseStatement()

HRESULT InitOpenGL(HWND hWnd, HDC *hDC, HGLRC *hRC)
{ // begin InitOpenGL()
	GLuint PixelFormat;
	RECT Rect;

	static PIXELFORMATDESCRIPTOR pfd =				// pfd Tells Windows How We Want Things To Be
	{
		sizeof(PIXELFORMATDESCRIPTOR),				// Size Of This Pixel Format Descriptor
		1,											// Version Number
		PFD_DRAW_TO_WINDOW |						// Format Must Support Window
		PFD_SUPPORT_OPENGL |						// Format Must Support OpenGL
		PFD_DOUBLEBUFFER,							// Must Support Double Buffering
		PFD_TYPE_RGBA,								// Request An RGBA Format
		(UCHAR) 16,              // Select Our Color Depth
		0, 0, 0, 0, 0, 0,							// Color Bits Ignored
		0,											// No Alpha Buffer
		0,											// Shift Bit Ignored
		0,											// No Accumulation Buffer
		0, 0, 0, 0,									// Accumulation Bits Ignored
		16,											// 16Bit Z-Buffer (Depth Buffer)  
		0,											// No Stencil Buffer
		0,											// No Auxiliary Buffer
		PFD_MAIN_PLANE,								// Main Drawing Layer
		0,											// Reserved
		0, 0, 0										// Layer Masks Ignored
	};
	if(!(*hDC = GetDC(hWnd)))							// Did We Get A Device Context?
	{
		MessageBox(hWnd,"Can't Create A GL Device Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		DestroyOpenGL(hWnd, *hDC, *hRC);
		return 1;
	}
	if(!(PixelFormat = ChoosePixelFormat(*hDC, &pfd)))	// Did Windows Find A Matching Pixel Format?
	{
		MessageBox(hWnd,"Can't Find A Suitable PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		DestroyOpenGL(hWnd, *hDC, *hRC);
		return 1;
	}
	if(!SetPixelFormat(*hDC, PixelFormat, &pfd))		// Are We Able To Set The Pixel Format?
	{
		MessageBox(hWnd,"Can't Set The PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		DestroyOpenGL(hWnd, *hDC, *hRC);
		return 1;
	}
	if(!(*hRC = wglCreateContext(*hDC)))				// Are We Able To Get A Rendering Context?
	{
		MessageBox(hWnd,"Can't Create A GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		DestroyOpenGL(hWnd, *hDC, *hRC);
		return 1;
	}
	if(!wglMakeCurrent(*hDC, *hRC))
		return 0;
	GetWindowRect(hWnd, &Rect);
	ConfigOpenGL(Rect.right-Rect.left, Rect.bottom-Rect.top);
	return 0;
} // end ASInitOpenGL()
		
HRESULT DestroyOpenGL(HWND hWnd, HDC hDC, HGLRC hRC)
{ // begin DestroyOpenGL()
	if(hRC)											// Do We Have A Rendering Context?
	{
		if(!wglMakeCurrent(NULL, NULL))					// Are We Able To Release The DC And RC Contexts?
			MessageBox(hWnd,"Release Of DC And RC Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		if(!wglDeleteContext(hRC))						// Are We Able To Delete The RC?
			MessageBox(hWnd,"Release Rendering Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hRC = NULL;										// Set RC To NULL
	}
	if(hDC && !ReleaseDC(hWnd, hDC))					// Are We Able To Release The DC
	{
		MessageBox(hWnd,"Release Device Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hDC = NULL;										// Set DC To NULL
	}
	return 0;
} // DestroyOpenGL()

void ConfigOpenGL(int iWidth, int iHeight)
{ // begin ConfigOpenGL()
	glViewport(0, 0, iWidth, iHeight);
	glLoadIdentity();
	glMatrixMode(GL_PROJECTION);
	gluPerspective(45.0f, (GLfloat)iWidth/(GLfloat)iHeight, 0.1f, 10000.0f);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glPolygonMode(GL_FRONT, GL_FILL);
	glPolygonMode(GL_BACK, GL_LINE);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_FASTEST);
	glHint(GL_LINE_SMOOTH_HINT, GL_FASTEST);
	glHint(GL_FOG_HINT, GL_FASTEST);
	glHint(GL_POINT_SMOOTH_HINT, GL_FASTEST);
	glHint(GL_POLYGON_SMOOTH_HINT, GL_FASTEST);
	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);		
	glShadeModel(GL_SMOOTH);
	glColor4f(1.0f, 1.0f, 1.0f, 1.0);
	glEnable(GL_COLOR_MATERIAL);
	glEnable(GL_COLOR_MATERIAL_FACE);
	glColorMaterial(GL_FRONT,GL_AMBIENT_AND_DIFFUSE);
	glMateriali(GL_FRONT,GL_SHININESS,128);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);					// Set The Blending Function For Translucency
	glEnable(GL_TEXTURE_2D);

	glLightfv(GL_LIGHT1, GL_AMBIENT, LightAmbient);		// Setup The Ambient Light
//	glLightfv(GL_LIGHT1, GL_DIFFUSE, LightDiffuse);		// Setup The Diffuse Light
	glLightfv(GL_LIGHT1, GL_POSITION,LightPosition);	// Position The Light
	glEnable(GL_LIGHT1);								// Enable Light One
	glEnable(GL_LIGHTING);
} // end ConfigOpenGL()

void NormalizeFace(FLOAT3 *ResultV, FLOAT3 V1, FLOAT3 V2, FLOAT3 V3)
{ // begin NormalizeFace()
	FLOAT3 V1_V2, V1_V3;
	float fLength;

	SubtVer(V1_V2, V1, V2);
	SubtVer(V1_V3, V1, V3);
	CrossProductVer(*ResultV, V1_V2, V1_V3);
	fLength = (float) sqrt((*ResultV)[X]*(*ResultV)[X]+(*ResultV)[Y]*(*ResultV)[Y]+(*ResultV)[Z]*(*ResultV)[Z]);
	(*ResultV)[X] /= fLength;
	(*ResultV)[Y] /= fLength;
	(*ResultV)[Z] /= fLength;
} // end NormalizeFace()

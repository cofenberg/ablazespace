//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDD_ASO                         101
#define IDR_MENU                        102
#define IDD_CREDITS                     103
#define IDD_GENERAL                     107
#define ID_CREDITS_OK                   1000
#define IDC_CREDITS_VERSION             1001
#define IDC_CREDITS_BUILD_TIME          1002
#define IDC_CREDITS_BUILD_DATE          1003
#define IDC_FRAMES                      1005
#define IDC_INSERT_FRAME                1006
#define IDC_GENERAL_OBJECT_NAME         1007
#define IDC_FRAME_NAME                  1009
#define IDC_ANIMATION_FRAME_INTERPOLATE_TIME 1011
#define IDC_ANIMATIONS                  1020
#define IDC_ANIMATION_STEPS             1021
#define IDC_FRAME_MOVE_UP               1023
#define IDC_FRAME_MOVE_DOWN             1024
#define IDC_DELETE_FRAME                1025
#define IDC_ANIMATION_STEP_MOVE_UP      1026
#define IDC_ANIMATION_STEP_MOVE_DOWN    1027
#define IDC_DELETE_ANIMATION_STEP       1028
#define IDC_INSERT_FRAME_TO_ANIMATION   1029
#define IDC_GENERAL_VERTEX_COLOR        1030
#define IDC_GENERAL_VERTEX__TEXTURE_POS 1031
#define ID_GENERAL_OK                   1032
#define IDC_ANIMATION_NAME              1033
#define IDC_NEW_ANIMATION               1034
#define IDC_ANIMATION_PLAY              1037
#define IDC_ANIMATION_VIEW              1038
#define IDC_FRAME_VIEW                  1039
#define IDC_DELETE_ANIMATION            1042
#define IDC_ANIMATION_MOVE_UP           1044
#define IDC_ANIMATION_MOVE_DOWN         1045
#define IDC_GENERAL_OBJECT_ACTIVE       1045
#define IDC_GENERAL_OBJECT_CHILDREN_ACTIVE 1046
#define IDC_GENERAL_VERTICES            1047
#define IDC_GENERAL_TEXTURE_COORDS      1048
#define IDC_GENERAL_COLOR_VERTICES      1049
#define IDC_GENERAL_NORMALS             1050
#define IDC_GENERAL_FACES               1051
#define IDC_RESET_ANIMATION_VIEW        1052
#define IDC_RESET_FRAME_VIEW            1053
#define IDC_ANIMATION_FRAME_INTERPOLATE_TIME_ALL 1054
#define ID_FILE_QUIT                    40001
#define ID_HELP_CREDITS                 40002
#define ID_HELP_HOMEPAGE                40003
#define ID_HELP_HELP                    40004
#define ID_FILE_LOAD_OBJECT             40006
#define ID_FILE_SAVE_OBJECT             40007
#define ID_FILE_NEW_OBJECT              40009
#define ID_OBJECT_GENERAL               40010
#define ID_FILE_SAVE_AS_OBJECT          40011
#define ID_HELP_BLENDER_HOMEPAGE        40012
#define ID_HELP_NEHE_HOMEPAGE           40013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40014
#define _APS_NEXT_CONTROL_VALUE         1055
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

#ifndef __ASO_H__
#define __ASO_H__


// Includes: ******************************************************************
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <math.h>
#include <winuser.h>
#include <commctrl.h>
#include <gl\gl.h>
#include <gl\glu.h>
#include <gl\glaux.h>
///////////////////////////////////////////////////////////////////////////////


// Definitions: ***************************************************************
#define PROGRAM_VERSION "V1.0"
enum {X, Y, Z};
#define ASO_FILE "Object files (*.aso)\0*.aso\0"
#define WRL_FILE "VRML files (*.wrl)\0*.wrl\0"
#define SubtVer(AB, a, b)\
	((AB)[X] = (b)[X]-(a)[X],\
     (AB)[Y] = (b)[Y]-(a)[Y],\
     (AB)[Z] = (b)[Z]-(a)[Z])
#define CrossProductVer(AB, a, b)\
	((AB)[X] = (a)[Y]*(b)[Z]-(a)[Z]*(b)[Y],\
     (AB)[Y] = (a)[Z]*(b)[X]-(a)[X]*(b)[Z],\
     (AB)[Z] = (a)[X]*(b)[Y]-(a)[Y]*(b)[X])
#define AS_FORMAT_TOKENS " ,\t\r\n"
enum {GENERAL, TEXTURE2, MATERIAL, COORDINATE3, TEXTURECOORDINATE2, INDEXEDFACESET, MATERIALBINDING, MATRIXTRANSFORM};
enum {NONE, MATERIAL_DIFFUSECOLOR, COORDINATE3_POINT, TEXTURECOOREDIATE2_POINT, INDEXEDFACESET_COODNINDEX, MATRIXTRANSFORMATION_DATA};
#define START_SIZE 500
typedef float FLOAT3[3];
typedef float FLOAT2[2];
typedef int INT3[3];
typedef int SHORT3[3];
typedef float MATRIX[4][4];
///////////////////////////////////////////////////////////////////////////////
// Structures: ****************************************************************
typedef struct 
{
    HDC         hdcPrint;       // In:      Printer DC
    HWND        hTreeWnd;       // In:      tree window
    HTREEITEM   hCurrTree;      // In:      current tree item handle
    DWORD       dwCharWidth;    // In:      average char width
    DWORD       dwLineHeight;   // In:      max line height
    DWORD       dwCurrLine;     // In/Out:  curr line position on page
    DWORD       dwCharsPerLine; // In:      maximum chars per line (based on avg. char width)
    DWORD       dwLinesPerPage; // In:      maximum lines per page
    DWORD       dwCurrIndent;   // In:      Current tab setting
    BOOL        fStartPage;     // In/Out:  need to a start new page ?!?
} PRINTCBINFO;
typedef void (*SELCALLBACK)(LPARAM, LPARAM);
typedef BOOL (*PRINTCALLBACK)(LPARAM, LPARAM, PRINTCBINFO *);
typedef struct
{
    SELCALLBACK     Callback;
    LPARAM          lParam1;
    LPARAM          lParam2;
    PRINTCALLBACK   printCallback;
} NODEINFO;
typedef struct
{
    char *szName;         // name of cap
    SELCALLBACK     Callback;
    LPARAM          lParam2;
    PRINTCALLBACK   printCallback;
} CAPDEFS;
///////////////////////////////////////////////////////////////////////////////
#include "resource.h"
#include "AS_Object.h"
///////////////////////////////////////////////////////////////////////////////
// Variables: *****************************************************************
extern HINSTANCE hInstance;
extern int iCmdShow;
extern AS_OBJECT *Object;
extern AS_OBJECT *pObjectT;
extern short iObjects; // The number of object which are in the main object
extern BOOL bFirst;
extern HWND hWndTV;
extern HWND hWndGeneral;
extern HWND  hWndFrameView;
extern HDC	  hDCFrameView;
extern HGLRC hRCFrameView;
extern HWND  hWndAnimationView;
extern HDC	  hDCAnimationView;
extern HGLRC hRCAnimationView;
extern FLOAT3 fFrameViewPos, fFrameViewRot;
extern FLOAT3 fAnimationViewPos, fAnimationViewRot;
extern GLfloat LightDiffuse[];
extern GLfloat LightAmbient[];
extern GLfloat LightPosition[];
extern AS_OBJECT *CurrentObj;
extern BOOL bExpectingNumbers;
extern int iDefinitions, iExpectedNumbers;
extern int iSize;
extern char *pbyGlobalFilename;
extern MATRIX Matrix, SceneMatrix;
///////////////////////////////////////////////////////////////////////////////
// Functions: *****************************************************************
extern int PASCAL WinMain(HINSTANCE, HINSTANCE, LPSTR, int);
extern LRESULT CALLBACK WinProc(HWND, unsigned, WPARAM, LPARAM);
extern LRESULT CALLBACK CreditsProc(HWND, unsigned, WPARAM, LPARAM);
extern LRESULT CALLBACK GeneralProc(HWND, unsigned, WPARAM, LPARAM);
extern void InsertFrame(char *, HWND);
extern void LoadFrameMessage(void);
extern void SetObjectViewPropertysView(void);
extern void ObjectViewOnTreeSelect(HWND, NM_TREEVIEW *);
extern void ObjectViewFillTree(HWND);
extern HTREEITEM TVAddNode(HTREEITEM, LPSTR, BOOL, int, SELCALLBACK, LPARAM, LPARAM, PRINTCALLBACK);
extern void AddCapsToTV(HTREEITEM, CAPDEFS *, LPARAM);
extern HRESULT InsertFrameWrl(char *, AS_OBJECT *);
extern HRESULT WrlParseStatement(FILE *);
extern char *GetFileName(HWND,  char *, char *, BOOL, BOOL);
extern HRESULT InitOpenGL(HWND, HDC *, HGLRC *);
extern HRESULT DestroyOpenGL(HWND, HDC, HGLRC);
extern void ConfigOpenGL(int, int);
extern void NormalizeFace(FLOAT3 *, FLOAT3, FLOAT3, FLOAT3);
///////////////////////////////////////////////////////////////////////////////


#endif // __ASO_H__
#include "ASO.h"


int iObjectsT = 0;

////////////////////////////////////////////////////////
// This function is only required for this program!
void AS_OBJECT::InsertObjectIntoObjectView(HTREEITEM hParentTree)
{ // begin  AS_OBJECT::InsertObjectIntoObjectView()
    HTREEITEM hTreeSubNode;
	short i;

	if(!Header.iChildren)
		i = 0;
	else
		i = 1;
	hTreeSubNode = TVAddNode(hParentTree, Header.byName, i,
							 NULL, NULL, iID, 0, NULL);
	for(i = 0; i < Header.iChildren; i++)
		pChild[i]->InsertObjectIntoObjectView(hTreeSubNode);
} // end  AS_OBJECT::InsertObjectIntoObjectView()
///////////////////////////////////////////////////////////////////////////////


AS_OBJECT::AS_OBJECT(void)
{ // begin AS_OBJECT::AS_OBJECT()
	memset(this, 0, sizeof(AS_OBJECT));
} // end AS_OBJECT::AS_OBJECT()

AS_OBJECT::~AS_OBJECT(void)
{ // begin AS_OBJECT::~AS_OBJECT()
} // end AS_OBJECT::~AS_OBJECT()

void AS_OBJECT::SetFrameT(short iID)
{ // begin AS_OBJECT::SetFrameT()
	int i;

	for(i = 0; i < Header.iChildren; i++)
		pChild[i]->SetFrameT(iID);
	if(iID < 0 || iID >= Header.iFrames)
		pFrameT = NULL;
	else
		pFrameT = &pFrame[iID];
} // end AS_OBJECT::SetFrameT()

void AS_OBJECT::SetAnimationT(short iID)
{ // begin AS_OBJECT::SetAnimationT()
	int i;

	for(i = 0; i < Header.iChildren; i++)
		pChild[i]->SetAnimationT(iID);
	if(iID < 0 || iID >= Header.iAnimations)
		pAnimationT = NULL;
	else
		pAnimationT = &pAnimation[iID];
} // end AS_OBJECT::SetAnimationT()

void AS_OBJECT::SetAnimationStepT(short iID)
{ // begin AS_OBJECT::SetAnimationStepT()
	int i;
	
	if(!pAnimationT)
		return;
	for(i = 0; i < Header.iChildren; i++)
		pChild[i]->SetAnimationStepT(iID);
	if(iID < 0 || iID >= pAnimationT->iSteps)
		pAnimationT->pStepT = NULL;
	else
		pAnimationT->pStepT = &pAnimationT->pStep[iID];
} // end AS_OBJECT::SetAnimationStepT()

void AS_OBJECT::SetInterpolateTime(DWORD dwTime)
{ // begin AS_OBJECT::SetInterpolateTime()
	int i;

	for(i = 0; i < Header.iChildren; i++)
		pChild[i]->SetInterpolateTime(dwTime);
	if(!pAnimationT || !pAnimationT->pStepT)
		return;
	pAnimationT->pStepT->dwInterpolateTime = dwTime;
} // end AS_OBJECT::SetInterpolateTime()

void AS_OBJECT::CalculateInterpolations(void)
{ // begin AS_OBJECT::CalculateInterpolations()
	AS_OBJECT_ANIMATION_STEP *pAniStepTemp, *pNextAniStepTemp;
	int i, i2, i3, i4;

	// Precalculate the constant interpolation data:
	for(i3 = 0; i3 < Header.iAnimations; i3++)
	{
		for(i4 = 0; i4 < pAnimation[i3].iSteps; i4++)
		{
			pAniStepTemp = &pAnimation[i3].pStep[i4];
			if(i4 >= pAnimation[i3].iSteps-1)
				pNextAniStepTemp = &pAnimation[i3].pStep[0];
			else
				pNextAniStepTemp = &pAnimation[i3].pStep[i4+1];
			if(!pAniStepTemp->pFrame)
				continue;
			for(i = 0; i < pAniStepTemp->pFrame->iTextureCoords; i++)
				for(i2 = 0; i2 < 2; i2++)
					pAniStepTemp->fTextureCoordIncreasePos[i][i2] = (pNextAniStepTemp->pFrame->fTextureCoord[i][i2]-pAniStepTemp->pFrame->fTextureCoord[i][i2])/pAniStepTemp->dwInterpolateTime;
			for(i2 = 0; i2 < 3; i2++)
			{
				for(i = 0; i < pAniStepTemp->pFrame->iDiffuseColors; i++)
					pAniStepTemp->fDiffuseColorIncreasePos[i][i2] = (pNextAniStepTemp->pFrame->fDiffuseColor[i][i2]-pAniStepTemp->pFrame->fDiffuseColor[i][i2])/pAniStepTemp->dwInterpolateTime;
				for(i = 0; i < pAniStepTemp->pFrame->iNormals; i++)
					pAniStepTemp->fNormalIncreasePos[i][i2] = (pNextAniStepTemp->pFrame->fNormal[i][i2]-pAniStepTemp->pFrame->fNormal[i][i2])/pAniStepTemp->dwInterpolateTime;
				for(i = 0; i < pAniStepTemp->pFrame->iVertices; i++)
					pAniStepTemp->fVertexIncreasePos[i][i2] = (pNextAniStepTemp->pFrame->fVertex[i][i2]-pAniStepTemp->pFrame->fVertex[i][i2])/pAniStepTemp->dwInterpolateTime;
			}
			// Now calculate the matrix:
			for(i2 = 0; i2 < 4; i2++)
				for(i = 0; i < 4; i++)
					pAniStepTemp->MatrixIncrease[i][i2] = (pNextAniStepTemp->pFrame->Matrix[i][i2]-pAniStepTemp->pFrame->Matrix[i][i2])/pAniStepTemp->dwInterpolateTime;
		}
	}
} // end AS_OBJECT::CalculateInterpolations()

void AS_OBJECT::CalculateCurrentFrame(void)
{ // begin AS_OBJECT::CalculateCurrentFrame()
	short i, i2;
	AS_OBJECT_ANIMATION_STEP *pCurrentAniStep;
	AS_OBJECT_ANIMATION_STEP *pNextAniStep;
	AS_OBJECT_FRAME *pFrameTemp;
	
	// Calculates the current frame:
	pCurrentAniStep = pAnimationT->pStepT;
	dwCurrentTime = GetTickCount();
	dwTimeDifference = dwCurrentTime-dwLastTime;
	if(pCurrentAniStep->dwInterpolateTime < dwTimeDifference)
		dwTimeDifference = pCurrentAniStep->dwInterpolateTime;
	if(pCurrentAniStep->dwInterpolateTime == dwTimeDifference)
	{ // Go to the next frame:
		dwTimeDifference = 0;
		dwCurrentTime = dwLastTime = GetTickCount();
		if(pCurrentAniStep->iID >= pAnimationT->iSteps-1)
			pCurrentAniStep = &pAnimationT->pStep[0];
		else
			pCurrentAniStep = &pAnimationT->pStep[pCurrentAniStep->iID+1];
		pAnimationT->pStepT = pCurrentAniStep;
	}
	pFrameTemp = pCurrentAniStep->pFrame;
	CurrentFrame.iFace = pFrameTemp->iFace;
	if(pCurrentAniStep->iID >= pAnimationT->iSteps-1)
		pNextAniStep = &pAnimationT->pStep[0];
	else
		pNextAniStep = &pAnimationT->pStep[pCurrentAniStep->iID+1];
	if(!pCurrentAniStep || !pNextAniStep)
		return;
	if(CurrentFrame.fDiffuseColor)
		for(i2 = 0; i2 < 3; i2++)
			for(i = 0; i < pFrameTemp->iDiffuseColors; i++)
				CurrentFrame.fDiffuseColor[i][i2] = pFrameTemp->fDiffuseColor[i][i2]+(pCurrentAniStep->fDiffuseColorIncreasePos[i][i2]*dwTimeDifference);
	if(CurrentFrame.fNormal)
		for(i2 = 0; i2 < 3; i2++)
			for(i = 0; i < pFrameTemp->iNormals; i++)
				CurrentFrame.fNormal[i][i2] = pFrameTemp->fNormal[i][i2]+(pCurrentAniStep->fNormalIncreasePos[i][i2]*dwTimeDifference);
	if(CurrentFrame.fVertex)
		for(i2 = 0; i2 < 3; i2++)
			for(i = 0; i < pFrameTemp->iVertices; i++)
				CurrentFrame.fVertex[i][i2] = pFrameTemp->fVertex[i][i2]+(pCurrentAniStep->fVertexIncreasePos[i][i2]*dwTimeDifference);
	for(i = 0; i < pFrameTemp->iTextureCoords; i++)
		for(i2 = 0; i2 < 2; i2++)
			CurrentFrame.fTextureCoord[i][i2] = pFrameTemp->fTextureCoord[i][i2]+(pCurrentAniStep->fTextureCoordIncreasePos[i][i2]*dwTimeDifference);
	// Now calculate the current matrix:
	for(i = 0; i < 4; i++)
		for(i2 = 0; i2 < 4; i2++)
			CurrentFrame.Matrix[i][i2] = pFrameTemp->Matrix[i][i2]+(pCurrentAniStep->MatrixIncrease[i][i2]*dwTimeDifference);
} // end AS_OBJECT::CalculateCurrentFrame()

void AS_OBJECT::Draw(BOOL bAnimation)
{ // begin AS_OBJECT::Draw()
	int i, i2;
	AS_OBJECT_FRAME *pFrameTemp;
	
	if(!pAnimationT && bAnimation)
		return;
	if(!bAnimation && !pFrameT)
		return;
	if(bAnimation && !pAnimationT->pStepT)
	{
		if(!pAnimationT->iSteps)
			return;
		pAnimationT->pStepT = &pAnimationT->pStep[0];
	}

	if(Header.bChildrenActive && pChild)
	{
		for(i = 0; i < Header.iChildren; i++)
		{
			if(!pChild[i])
				continue;
			pChild[i]->Draw(bAnimation);
		}
	}
	if(!Header.bActive)
		return;
	if(bAnimation)
	{
		CalculateCurrentFrame();
		pFrameTemp = &CurrentFrame;
	}
	else
		pFrameTemp = pFrameT;
	glPushMatrix();
	glMultMatrixf(pFrameTemp->Matrix[0]);
//	glBindTexture(GL_TEXTURE_2D, iTexture[0]);
	glBegin(GL_TRIANGLES);
		for(i = 0, i2 = 0; i < pFrameTemp->iFaces; i++)
		{
			glColor3f(pFrameTemp->fDiffuseColor[pFrameTemp->iFace[i][0]][0], pFrameTemp->fDiffuseColor[pFrameTemp->iFace[i][0]][1], pFrameTemp->fDiffuseColor[pFrameTemp->iFace[i][0]][2]);
			glNormal3f(pFrameTemp->fNormal[pFrameTemp->iFace[i][0]][0], pFrameTemp->fNormal[pFrameTemp->iFace[i][0]][1], pFrameTemp->fNormal[pFrameTemp->iFace[i][0]][2]);
//			glTexCoord2f(pFrameTemp->fTextureCoord[i2][0], pFrameTemp->fTextureCoord[i2][1]);
			glVertex3f(pFrameTemp->fVertex[pFrameTemp->iFace[i][0]][X], pFrameTemp->fVertex[pFrameTemp->iFace[i][0]][Y], pFrameTemp->fVertex[pFrameTemp->iFace[i][0]][Z]);
			i2++;
			glColor3f(pFrameTemp->fDiffuseColor[pFrameTemp->iFace[i][1]][0], pFrameTemp->fDiffuseColor[pFrameTemp->iFace[i][1]][1], pFrameTemp->fDiffuseColor[pFrameTemp->iFace[i][1]][2]);
			glNormal3f(pFrameTemp->fNormal[pFrameTemp->iFace[i][1]][0], pFrameTemp->fNormal[pFrameTemp->iFace[i][1]][1], pFrameTemp->fNormal[pFrameTemp->iFace[i][1]][2]);
//			glTexCoord2f(pFrameTemp->fTextureCoord[i2][0], pFrameTemp->fTextureCoord[i2][1]);
			glVertex3f(pFrameTemp->fVertex[pFrameTemp->iFace[i][1]][X], pFrameTemp->fVertex[pFrameTemp->iFace[i][1]][Y], pFrameTemp->fVertex[pFrameTemp->iFace[i][1]][Z]);
			i2++;
			glColor3f(pFrameTemp->fDiffuseColor[pFrameTemp->iFace[i][2]][0], pFrameTemp->fDiffuseColor[pFrameTemp->iFace[i][2]][1], pFrameTemp->fDiffuseColor[pFrameTemp->iFace[i][2]][2]);
			glNormal3f(pFrameTemp->fNormal[pFrameTemp->iFace[i][2]][0], pFrameTemp->fNormal[pFrameTemp->iFace[i][2]][1], pFrameTemp->fNormal[pFrameTemp->iFace[i][2]][2]);
//			glTexCoord2f(pFrameTemp->fTextureCoord[i2][0], pFrameTemp->fTextureCoord[i2][1]);
			glVertex3f(pFrameTemp->fVertex[pFrameTemp->iFace[i][2]][X], pFrameTemp->fVertex[pFrameTemp->iFace[i][2]][Y], pFrameTemp->fVertex[pFrameTemp->iFace[i][2]][Z]);
			i2++;
		}
	glEnd();
	glPopMatrix();
} // end AS_OBJECT::Draw()

void AS_OBJECT::Destroy(void)
{ // begin AS_OBJECT::Destroy()
	int i, i2;
	AS_OBJECT_FRAME *pFrameT;
	AS_OBJECT_ANIMATION_STEP *pStepT;

	if(pbyFilename)
		delete pbyFilename;
	if(pChild)
	{
		for(i = 0; i < Header.iChildren; i++)
		{
			if(!pChild[i])
				continue;
			pChild[i]->Destroy();	
			free(pChild[i]);
		}
		free(pChild);
	}
	if(pAnimation)
	{
		for(i = 0; i < Header.iAnimations; i++)
		{
			pAnimationT = &pAnimation[i];
			for(i2 = 0; i2 < pAnimationT->iSteps; i2++)
			{
				pStepT = &pAnimationT->pStep[i2];
/*				if(pStepT->fDiffuseColorIncreasePos)
					free(pStepT->fDiffuseColorIncreasePos);
				if(pStepT->fVertexIncreasePos)
					free(pStepT->fVertexIncreasePos);
				if(pStepT->fNormalIncreasePos)
					free(pStepT->fNormalIncreasePos);
				if(pStepT->fTextureCoordIncreasePos)
					free(pStepT->fTextureCoordIncreasePos);*/
			}
			if(pAnimationT->pStep)
				free(pAnimationT->pStep);
		}
		free(pAnimation);
	}
	if(pFrame)
	{
		for(i = 0; i < Header.iFrames; i++)
		{
			pFrameT = &pFrame[i];
			if(pFrameT->fDiffuseColor)
				free(pFrameT->fDiffuseColor);
			if(pFrameT->fVertex)
				free(pFrameT->fVertex);
			if(pFrameT->fNormal)
				free(pFrameT->fNormal);
			if(pFrameT->fTextureCoord)
				free(pFrameT->fTextureCoord);
			if(pFrameT->iFace)
				free(pFrameT->iFace);
		}
		free(pFrame);
	}
} // end AS_OBJECT::Destroy()

HRESULT AS_OBJECT::Load(char *pbyFilenameT)
{ // begin AS_OBJECT::Load()
	FILE *fp;

	if(!pbyFilenameT)
		return 1;
	fp = fopen(pbyFilenameT, "rb");
	if(!fp)
		return 1;
	pbyFilename	= new char[strlen(pbyFilenameT)+1];
	strcpy(pbyFilename, pbyFilenameT);
	iObjectsT = LoadPart(fp); // Load now the object
	fclose(fp);
	SetupAnimationData(TRUE);
	SetFrameT(0);
	SetAnimationT(0);
	SetAnimationStepT(0);
	return iObjectsT;
} // end AS_OBJECT::Load()

HRESULT AS_OBJECT::LoadPart(FILE *fp)
{ // begin AS_OBJECT::LoadPart()
	int i, i2;

	// Read the header:
	fread(&Header, sizeof(AS_OBJECT_HEADER), 1, fp);
	iID = iObjectsT;
	// Read the main matrix:
	fread(&Matrix, sizeof(MATRIX), 1, fp);
	// Read the object:
	if(Header.iFrames)
	{
		// Read the frames:
		pFrame = new AS_OBJECT_FRAME[Header.iFrames];
		memset(pFrame, 0, sizeof(AS_OBJECT_FRAME)*Header.iFrames);
		for(i = 0; i < Header.iFrames; i++)
		{
			pFrameT = &pFrame[i];
			// Name:
			fread(&pFrameT->byName, sizeof(char)*256, 1, fp);
			// ID:
			pFrameT->iID = i;
			// Transformation matrix:
			fread(&pFrameT->Matrix, sizeof(MATRIX), 1, fp);
			// Diffuse colors:
			if(Header.bUseVertexColorData)
			{
				fread(&pFrameT->iDiffuseColors, sizeof(short), 1, fp);
				pFrameT->fDiffuseColor = new FLOAT3[pFrameT->iDiffuseColors];
				for(i2 = 0; i2 < pFrameT->iDiffuseColors; i2++)
					fread(&pFrameT->fDiffuseColor[i2], sizeof(FLOAT3), 1, fp);
			}
			// Vertices:
			fread(&pFrameT->iVertices, sizeof(short), 1, fp);
			pFrameT->fVertex = new FLOAT3[pFrameT->iVertices];
			for(i2 = 0; i2 < pFrameT->iVertices; i2++)
				fread(&pFrameT->fVertex[i2], sizeof(FLOAT3), 1, fp);
			// Texture coords:
			if(Header.bUseVertexTexturePosData)
			{
				fread(&pFrameT->iTextureCoords, sizeof(short), 1, fp);
				pFrameT->fTextureCoord = new FLOAT2[pFrameT->iTextureCoords];
				for(i2 = 0; i2 < pFrameT->iTextureCoords; i2++)
					fread(&pFrameT->fTextureCoord[i2], sizeof(FLOAT2), 1, fp);
			}
			// Faces:
			fread(&pFrameT->iFaces, sizeof(short), 1, fp);
			pFrameT->iFace = new SHORT3[pFrameT->iFaces];
			for(i2 = 0; i2 < pFrameT->iFaces; i2++)
				fread(&pFrameT->iFace[i2], sizeof(SHORT3), 1, fp);
			// Calculate normals:
			pFrameT->iNormals = pFrameT->iFaces;
			pFrameT->fNormal = new FLOAT3[pFrameT->iNormals];
			for(i2 = 0; i2 < pFrameT->iFaces; i2++)
				NormalizeFace(&pFrameT->fNormal[i2], pFrameT->fVertex[pFrameT->iFace[i2][0]],
							  pFrameT->fVertex[pFrameT->iFace[i2][1]],
							  pFrameT->fVertex[pFrameT->iFace[i2][2]]);
		}
		// Read the animations:
		if(Header.iAnimations)
		{
			pAnimation = new AS_OBJECT_ANIMATION[Header.iAnimations];
			memset(pAnimation, 0, sizeof(AS_OBJECT_ANIMATION)*Header.iAnimations);
			for(i = 0; i < Header.iAnimations; i++)
			{
				pAnimationT = &pAnimation[i];
				// Name:
				fread(&pAnimationT->byName, sizeof(char)*256, 1, fp);
				// ID:
				pAnimationT->iID = i;
				// Animation steps:
				fread(&pAnimationT->iSteps, sizeof(short), 1, fp);
				// Read the animation steps:
				pAnimationT->pStep = new AS_OBJECT_ANIMATION_STEP[pAnimationT->iSteps];
				memset(pAnimationT->pStep, 0, sizeof(AS_OBJECT_ANIMATION_STEP)*pAnimationT->iSteps);
				for(i2 = 0; i2 < pAnimationT->iSteps; i2++)
				{
					// Interpolation time:
					fread(&pAnimationT->pStep[i2].dwInterpolateTime, sizeof(DWORD), 1, fp);
					// Step ID;
					pAnimationT->pStep[i2].iID = i2;
					// Frame ID:
					fread(&pAnimationT->pStep[i2].iFrameID, sizeof(short), 1, fp);
					pAnimationT->pStep[i2].pFrame = &pFrame[pAnimationT->pStep[i2].iFrameID];
					pAnimationT->pStep[i2].pFrame->iUsed++;
					// Precalculated data:
					pAnimationT->pStep[i2].fDiffuseColorIncreasePos = new FLOAT3[pFrameT->iDiffuseColors];
					pAnimationT->pStep[i2].fVertexIncreasePos = new FLOAT3[pFrameT->iVertices];
					pAnimationT->pStep[i2].fNormalIncreasePos = new FLOAT3[pFrameT->iNormals];
					pAnimationT->pStep[i2].fTextureCoordIncreasePos = new FLOAT2[pFrameT->iTextureCoords];
				}
			}
		}
	}
	// Read now all the children whith their children:
	if(!Header.iChildren)
		return 0;
	pChild = (AS_OBJECT **) malloc(sizeof(AS_OBJECT)*Header.iChildren);
	for(i = 0; i < Header.iChildren; i++)
	{
		pChild[i] = new AS_OBJECT;
		memset(pChild[i], 0, sizeof(AS_OBJECT));
		pChild[i]->pParent = (this);
		iObjectsT++;
		pChild[i]->LoadPart(fp);
	}
	return iObjectsT;
} // end AS_OBJECT::LoadPart()

HRESULT AS_OBJECT::Save(char *pbyFilenameT)
{ // begin AS_OBJECT::Save()
	FILE *fp;

	if(!pbyFilenameT)
		return 1;
	fp = fopen(pbyFilenameT, "wb");
	if(!fp)
		return 1;
	if(pbyFilename)
		free(pbyFilename);
	pbyFilename	= new char[strlen(pbyFilenameT)+1];
	strcpy(pbyFilename, pbyFilenameT);
	SavePart(fp); // Save now the object
	fclose(fp);
	return 0;
} // end AS_OBJECT::Save()

HRESULT AS_OBJECT::SavePart(FILE *fp)
{ // begin AS_OBJECT::SavePart()
	int i, i2;

	// Write the header:
	fwrite(&Header, sizeof(AS_OBJECT_HEADER), 1, fp);
	// Write the main matrix:
	fwrite(&Matrix, sizeof(MATRIX), 1, fp);
	// Write the frames:
	for(i = 0; i < Header.iFrames; i++)
	{
		pFrameT = &pFrame[i];
		// Name:
		fwrite(&pFrameT->byName, sizeof(char)*256, 1, fp);
		// Transformation matrix:
		fwrite(&pFrameT->Matrix, sizeof(MATRIX), 1, fp);
		// Diffuse colors:
		if(Header.bUseVertexColorData)
		{
			fwrite(&pFrameT->iDiffuseColors, sizeof(short), 1, fp);
			for(i2 = 0; i2 < pFrameT->iDiffuseColors; i2++)
				fwrite(&pFrameT->fDiffuseColor[i2], sizeof(FLOAT3), 1, fp);
		}
		// Vertices:
		fwrite(&pFrameT->iVertices, sizeof(short), 1, fp);
		for(i2 = 0; i2 < pFrameT->iVertices; i2++)
			fwrite(&pFrameT->fVertex[i2], sizeof(FLOAT3), 1, fp);
		// Texture coords:
		if(Header.bUseVertexTexturePosData)
		{
			fwrite(&pFrameT->iTextureCoords, sizeof(short), 1, fp);
			for(i2 = 0; i2 < pFrameT->iTextureCoords; i2++)
				fwrite(&pFrameT->fTextureCoord[i2], sizeof(FLOAT2), 1, fp);
		}
		// Faces:
		fwrite(&pFrameT->iFaces, sizeof(short), 1, fp);
		for(i2 = 0; i2 < pFrameT->iFaces; i2++)
			fwrite(&pFrameT->iFace[i2], sizeof(SHORT3), 1, fp);
	}
	// Write the animations:
	for(i = 0; i < Header.iAnimations; i++)
	{
		pAnimationT = &pAnimation[i];
		// Name:
		fwrite(&pAnimationT->byName, sizeof(char)*256, 1, fp);
		// Animation steps:
		fwrite(&pAnimationT->iSteps, sizeof(short), 1, fp);
		// Write the animation steps:
		for(i2 = 0; i2 < pAnimationT->iSteps; i2++)
		{
			// Interpolation time:
			fwrite(&pAnimationT->pStep[i2].dwInterpolateTime, sizeof(DWORD), 1, fp);
			// Frame ID:
			fwrite(&pAnimationT->pStep[i2].iFrameID, sizeof(short), 1, fp);
		}
	}
	// Save now all the children whith their children:
	for(i = 0; i < Header.iChildren; i++)
		pChild[i]->SavePart(fp);
	return 0;
} // end AS_OBJECT::SavePart()

void AS_OBJECT::AddFrame(BOOL bChildrenToo)
{ // begin AS_OBJECT::AddFrame()
	int i;

	if(bChildrenToo)
		for(i = 0; i < Header.iChildren; i++)
			pChild[i]->AddFrame(bChildrenToo);
	Header.iFrames++;
	pFrame = (AS_OBJECT_FRAME *) realloc(pFrame, sizeof(AS_OBJECT_FRAME)*Header.iFrames);
	pFrameT = &pFrame[Header.iFrames-1];
	memset(pFrameT, 0, sizeof(AS_OBJECT_FRAME));
	pFrameT->iID = Header.iFrames-1;
	sprintf(pFrameT->byName, "Frame%d", pFrameT->iID);
} // end AS_OBJECT::AddFrame()

void AS_OBJECT::DestroyLastFrame(BOOL bChildrenToo)
{ // begin AS_OBJECT::DestroyLastFrame()
	int i;

	if(bChildrenToo)
		for(i = 0; i < Header.iChildren; i++)
			pChild[i]->DestroyLastFrame(bChildrenToo);
	if(Header.iFrames <= 0)
		return;
	i = pFrameT->iID;
	pFrameT = &pFrame[Header.iFrames-1];
	if(pFrameT->fDiffuseColor)
		free(pFrameT->fDiffuseColor);
	if(pFrameT->fVertex)
		free(pFrameT->fVertex);
	if(pFrameT->fTextureCoord)
		free(pFrameT->fTextureCoord);
	if(pFrameT->iFace)
		free(pFrameT->iFace);
	Header.iFrames--;
	pFrame = (AS_OBJECT_FRAME *) realloc(pFrame, sizeof(AS_OBJECT_FRAME)*Header.iFrames);
	if(!pFrame)
	{
		pFrameT = NULL;
		return;
	}
	if(i >= Header.iFrames)
		pFrameT = &pFrame[Header.iFrames-1];
	else
		pFrameT = &pFrame[i];
} // end AS_OBJECT::DestroyLastFrame()

// Destroys the frame and fill the empty entry with the frames above
void AS_OBJECT::DestroyFrame(short iID, BOOL bChildrenToo)
{ // begin AS_OBJECT::DestroyFrame()
	if(iID < 0 || iID >= Header.iFrames)
		return;
	
	short i, i2, iTempID;
	AS_OBJECT_ANIMATION *pAnimationTemp;
	AS_OBJECT_ANIMATION_STEP *pStepTemp;

	if(bChildrenToo)
		for(i = 0; i < Header.iChildren; i++)
			pChild[i]->DestroyFrame(iID, bChildrenToo);
	iTempID = pFrameT->iID;
	if(iID >= Header.iFrames-1)
	{ // This is the last frame that's easy to destroy:
		DestroyLastFrame(FALSE);
		goto Update;
	}
	for(i = iID; i < Header.iFrames-1; i++)
	{
		memcpy(&pFrame[i], &pFrame[i+1], sizeof(AS_OBJECT_FRAME));
		pFrame[i].iID--;
	}
	Header.iFrames--;
	pFrame = (AS_OBJECT_FRAME *) realloc(pFrame, sizeof(AS_OBJECT_FRAME)*Header.iFrames);
Update:
	// Update the animation steps:
	for(i = 0; i < Header.iAnimations; i++)
	{
		pAnimationTemp = &pAnimation[i];
		for(i2 = 0; i2 < pAnimationTemp->iSteps; i2++)
		{
			pStepTemp = &pAnimationTemp->pStep[i2];
			if(pStepTemp->iFrameID == iID)
			{ // Destroy this animation step:
				DestroyAnimationStep(i, i2, FALSE);
				i2--;
				continue;
			}
			if(!pFrame)	
				continue;
			if(pStepTemp->iFrameID > iID)
			{
				pStepTemp->iFrameID--;
				pStepTemp->pFrame = &pFrame[pStepTemp->iFrameID];
			}
		}
	}
	if(!Header.iFrames)
	{
		pFrameT = NULL;
		return;
	}
	if(iTempID >= Header.iFrames)
		pFrameT = &pFrame[Header.iFrames-1];
	else
		pFrameT = &pFrame[iTempID];
} // end AS_OBJECT::DestroyFrame()

// Destroys all frames which are about the given frame number
void AS_OBJECT::CutFrames(short iID, BOOL bChildrenToo)
{ // begin AS_OBJECT::CutFrames()
	if(bChildrenToo)
		for(int i = 0; i < Header.iChildren; i++)
			pChild[i]->CutFrames(iID, bChildrenToo);
	for(;;)
	{
		if(Header.iFrames <= iID)
			break;
		DestroyLastFrame(FALSE);
	}
} // end AS_OBJECT::CutFrames()

void AS_OBJECT::SwitchFrames(short iID1, short iID2, BOOL bChildrenToo)
{ // begin AS_OBJECT::SwitchFrames()
	if(iID1 < 0 || iID2 < 0 || iID1 >= Header.iFrames || iID2 >= Header.iFrames)
		return;
	
	AS_OBJECT_FRAME TempFrame;
	AS_OBJECT_ANIMATION *pAnimationTemp;
	AS_OBJECT_ANIMATION_STEP *pStepTemp;
	int iTempID, i, i2;

	if(bChildrenToo)
		for(i = 0; i < Header.iChildren; i++)
			pChild[i]->SwitchFrames(iID1, iID2, bChildrenToo);
	// Switch the frames:
	iTempID = pFrameT->iID;
	memcpy(&TempFrame, &pFrame[iID1], sizeof(AS_OBJECT_FRAME));
	memcpy(&pFrame[iID1], &pFrame[iID2], sizeof(AS_OBJECT_FRAME));
	pFrame[iID1].iID = TempFrame.iID;
	TempFrame.iID = pFrame[iID2].iID;
	memcpy(&pFrame[iID2], &TempFrame, sizeof(AS_OBJECT_FRAME));
	if(iTempID == iID1)
		pFrameT = &pFrame[iID2];
	else
		pFrameT = &pFrame[iTempID];
	// Update the animation steps:
	for(i = 0; i < Header.iAnimations; i++)
	{
		pAnimationTemp = &pAnimation[i];
		for(i2 = 0; i2 < pAnimationTemp->iSteps; i2++)
		{
			pStepTemp = &pAnimationTemp->pStep[i2];
			if(pStepTemp->iFrameID == iID1)
			{
				pStepTemp->iFrameID = iID2;
				pStepTemp->pFrame = &pFrame[iID2];
				continue;
			}
			if(pStepTemp->iFrameID == iID2)
			{
				pStepTemp->iFrameID = iID1;
				pStepTemp->pFrame = &pFrame[iID1];
			}
		}
	}
} // end AS_OBJECT::SwitchFrames()

void AS_OBJECT::AddAnimation(BOOL bChildrenToo)
{ // begin AS_OBJECT::AddAnimation()
	short i;

	if(bChildrenToo)
		for(i = 0; i < Header.iChildren; i++)
			pChild[i]->AddAnimation(bChildrenToo);
	Header.iAnimations++;
	pAnimation = (AS_OBJECT_ANIMATION *) realloc(pAnimation, sizeof(AS_OBJECT_ANIMATION)*Header.iAnimations);
	pAnimationT = &pAnimation[Header.iAnimations-1];
	memset(pAnimationT, 0, sizeof(AS_OBJECT_ANIMATION));
	pAnimationT->iID = Header.iAnimations-1;
	sprintf(pAnimationT->byName, "Animation%d", pAnimationT->iID);
} // end AS_OBJECT::AddAnimation()

void AS_OBJECT::DestroyLastAnimation(BOOL bChildrenToo)
{ // begin AS_OBJECT::DestroyLastAnimation()
	int i;

	if(bChildrenToo)
		for(i = 0; i < Header.iChildren; i++)
			pChild[i]->DestroyLastAnimation(bChildrenToo);
	if(Header.iAnimations <= 0)
		return;
	DestroyAnimationSteps(&pAnimation[Header.iAnimations-1], FALSE);
	i = pAnimationT->iID;
	Header.iAnimations--;
	pAnimation = (AS_OBJECT_ANIMATION *) realloc(pAnimation, sizeof(AS_OBJECT_ANIMATION)*Header.iAnimations);
	if(!pAnimation)
	{
		pAnimationT = NULL;
		return;
	}
	if(i >= Header.iAnimations)
		pAnimationT = &pAnimation[Header.iAnimations-1];
	else
		pAnimationT = &pAnimation[i];
} // end DestroyLastAnimation()

// Destroys the animtion and fill the empty entry with the animtions above
void AS_OBJECT::DestroyAnimation(short iID, BOOL bChildrenToo)
{ // begin AS_OBJECT::DestroyAnimation()
	short i;

	if(iID < 0 || iID >= Header.iAnimations)
		return;
	if(bChildrenToo)
		for(i = 0; i < Header.iChildren; i++)
			pChild[i]->DestroyAnimation(iID, bChildrenToo);
	DestroyAnimationSteps(&pAnimation[iID], FALSE);
	for(i = iID; i < Header.iAnimations-1; i++)
	{
		memcpy(&pAnimation[i], &pAnimation[i+1], sizeof(AS_OBJECT_ANIMATION));
		pAnimation[i].iID--;
	}
	i = pAnimation->iID;
	Header.iAnimations--;
	pAnimation = (AS_OBJECT_ANIMATION *) realloc(pAnimation, sizeof(AS_OBJECT_ANIMATION)*Header.iAnimations);
	if(!pAnimation)
	{
		pAnimationT = NULL;
		return;
	}
	if(i >= Header.iAnimations)
		pAnimationT = &pAnimation[Header.iAnimations-1];
	else
		pAnimationT = &pAnimation[i];
} // end AS_OBJECT::DestroyAnimation()

void AS_OBJECT::SwitchAnimations(short iID1, short iID2, BOOL bChildrenToo)
{ // begin AS_OBJECT::SwitchAnimations()
	if(iID1 < 0 || iID2 < 0 || iID1 >= Header.iAnimations || iID2 >= Header.iAnimations)
		return;
	
	AS_OBJECT_ANIMATION TempAnimation;
	int i;

	if(bChildrenToo)
		for(i = 0; i < Header.iChildren; i++)
			pChild[i]->SwitchAnimations(iID1, iID2, bChildrenToo);
	// Switch the animations:
	i = pAnimationT->iID;
	memcpy(&TempAnimation, &pAnimation[iID1], sizeof(AS_OBJECT_ANIMATION));
	memcpy(&pAnimation[iID1], &pAnimation[iID2], sizeof(AS_OBJECT_ANIMATION));
	pAnimation[iID1].iID = TempAnimation.iID;
	TempAnimation.iID = pAnimation[iID2].iID;
	memcpy(&pAnimation[iID2], &TempAnimation, sizeof(AS_OBJECT_ANIMATION));
	if(i == iID1)
		pAnimationT = &pAnimation[iID2];
	else
		pAnimationT = &pAnimation[i];
} // end AS_OBJECT::SwitchAnimations()

void AS_OBJECT::DestroyAnimationSteps(AS_OBJECT_ANIMATION *pAniT, BOOL bChildrenToo)
{ // begin AS_OBJECT::DestroyAnimationSteps()
	AS_OBJECT_ANIMATION_STEP *pTempObjAnimationStep;
	short i;

	if(bChildrenToo)
		for(i = 0; i < Header.iChildren; i++)
			pChild[i]->DestroyAnimationSteps(pAniT, bChildrenToo);
	if(!pAniT->pStepT)
		return;
	for(i = 0; i < pAniT->iSteps; i++)
	{
		pAnimationT->pStep[i].pFrame->iUsed--;
		pTempObjAnimationStep = &pAniT->pStep[i];
		if(pTempObjAnimationStep->fDiffuseColorIncreasePos)
			free(pTempObjAnimationStep->fDiffuseColorIncreasePos);
		if(pTempObjAnimationStep->fVertexIncreasePos)
			free(pTempObjAnimationStep->fVertexIncreasePos);
		if(pTempObjAnimationStep->fNormalIncreasePos)
			free(pTempObjAnimationStep->fNormalIncreasePos);
		if(pTempObjAnimationStep->fTextureCoordIncreasePos)
			free(pTempObjAnimationStep->fTextureCoordIncreasePos);
	}
	if(pAnimationT->pStep)
		free(pAnimationT->pStep);
} // end AS_OBJECT::DestroyAnimationSteps()


void AS_OBJECT::AddAnimationStep(short iAnimation, BOOL bChildrenToo)
{ // begin AS_OBJECT::AddAnimationStep()
	int i;
	AS_OBJECT_ANIMATION *pAniT;

	if(bChildrenToo)
		for(i = 0; i < Header.iChildren; i++)
			pChild[i]->AddAnimationStep(iAnimation, bChildrenToo);
	pAniT = &pAnimation[iAnimation];
	pAniT->iSteps++;
	pAniT->pStep = (AS_OBJECT_ANIMATION_STEP *) realloc(pAniT->pStep, sizeof(AS_OBJECT_ANIMATION_STEP)*pAniT->iSteps);
	pAniT->pStepT = &pAniT->pStep[pAniT->iSteps-1];
	memset(pAniT->pStepT, 0, sizeof(AS_OBJECT_ANIMATION_STEP));
	pAniT->pStepT->iID = pAniT->iSteps-1;
} // end AS_OBJECT::AddAnimationStep()

void AS_OBJECT::SetAnimationStepFrame(short iAnimation, short iStepID, short iID, BOOL bChildrenToo)
{
	AS_OBJECT_ANIMATION *pAniT;
	short i;

	if(bChildrenToo)
		for(i = 0; i < Header.iChildren; i++)
			pChild[i]->SetAnimationStepFrame(iAnimation, iStepID, iID, bChildrenToo);
	pAniT = &pAnimation[iAnimation];
	pAniT->pStep[iStepID].iFrameID = iID;
	pAniT->pStep[iStepID].pFrame = &pFrame[iID];
}

void AS_OBJECT::DestroyLastAnimationStep(short iAnimation, BOOL bChildrenToo)
{ // begin AS_OBJECT::DestroyLastAnimationStep()
	AS_OBJECT_ANIMATION *pAniT;
	short i;

	pAniT = &pAnimation[iAnimation];
	if(bChildrenToo)
		for(i = 0; i < Header.iChildren; i++)
			pChild[i]->DestroyLastAnimationStep(iAnimation, bChildrenToo);
	if(pAniT->iSteps <= 0)
		return;
	i = pAniT->pStepT->iID;
	DestroyAnimationStepData(iAnimation, pAniT->iSteps-1, FALSE);
	pAniT->iSteps--;
	pAniT->pStep = (AS_OBJECT_ANIMATION_STEP *) realloc(pAniT->pStep, sizeof(AS_OBJECT_ANIMATION_STEP)*pAniT->iSteps);
	if(!pAniT->pStep)
	{
		pAniT->pStepT = NULL;
		return;
	}
	if(i >= pAniT->iSteps)
		pAniT->pStepT = &pAniT->pStep[pAniT->iSteps-1];
	else
		pAniT->pStepT = &pAniT->pStep[i];
} // end AS_OBJECT::DestroyLastAnimationStep()

// Destroys the animation step and fill the empty entry with the animation steps above
void AS_OBJECT::DestroyAnimationStep(short iAnimation, short iID, BOOL bChildrenToo)
{ // begin AS_OBJECT::DestroyAnimationStep)
	AS_OBJECT_ANIMATION *pAniT;
	short i, i2;

	pAniT = &pAnimation[iAnimation];
	if(iID < 0 || iID >= pAniT->iSteps)
		return;
	if(bChildrenToo)
		for(i = 0; i < Header.iChildren; i++)
			pChild[i]->DestroyAnimationStep(iAnimation, iID, bChildrenToo);
	if(iID >= pAniT->iSteps-1)
	{ // This is the last animation step that's easy to destroy:
		DestroyLastAnimationStep(iAnimation, FALSE);
		return;
	}
	i2 = pAniT->pStepT->iID;
	DestroyAnimationStepData(iAnimation, iID, FALSE);
	for(i = iID; i < pAniT->iSteps-1; i++)
	{
		memcpy(&pAniT->pStep[i], &pAniT->pStep[i+1], sizeof(AS_OBJECT_ANIMATION_STEP));
		pAniT->pStep[i].iID--;
	}
	pAniT->iSteps--;
	pAniT->pStep = (AS_OBJECT_ANIMATION_STEP *) realloc(pAniT->pStep, sizeof(AS_OBJECT_ANIMATION_STEP)*pAniT->iSteps);
	if(i2 >= pAniT->iSteps)
		pAniT->pStepT = &pAniT->pStep[pAniT->iSteps-1];
	else
		pAniT->pStepT = &pAniT->pStep[i2];
} // end AS_OBJECT::DestroyAnimationStep()

void AS_OBJECT::SwitchAnimationSteps(short iAnimation, short iID1, short iID2, BOOL bChildrenToo)
{ // begin AS_OBJECT::SwitchAnimationSteps()
	AS_OBJECT_ANIMATION *pAniT;
	AS_OBJECT_ANIMATION_STEP TempAnimationStep;
	int iTempID, i;

	pAniT = &pAnimation[iAnimation];
	if(iID1 < 0 || iID2 < 0 || iID1 >= pAniT->iSteps || iID2 >= pAniT->iSteps)
		return;
	if(bChildrenToo)
		for(i = 0; i < Header.iChildren; i++)
			pChild[i]->SwitchAnimationSteps(iAnimation, iID1, iID2, bChildrenToo);
	// Switch the animation steps:
	iTempID = pAniT->pStepT->iID;
	memcpy(&TempAnimationStep, &pAniT->pStep[iID1], sizeof(AS_OBJECT_ANIMATION_STEP));
	memcpy(&pAniT->pStep[iID1], &pAniT->pStep[iID2], sizeof(AS_OBJECT_ANIMATION_STEP));
	pAniT->pStep[iID1].iID = TempAnimationStep.iID;
	TempAnimationStep.iID = pAniT->pStep[iID2].iID;
	memcpy(&pAniT->pStep[iID2], &TempAnimationStep, sizeof(AS_OBJECT_ANIMATION_STEP));
	if(iTempID == iID1)
		pAniT->pStepT = &pAniT->pStep[iID2];
	else
		pAniT->pStepT = &pAniT->pStep[iTempID];
} // end AS_OBJECT::SwitchAnimationSteps()

void AS_OBJECT::DestroyAnimationStepData(short iAnimation, short iID, BOOL bChildrenToo)
{ // begin AS_OBJECT::DestroyAnimationStepData()
	AS_OBJECT_ANIMATION_STEP *pStepT;
	AS_OBJECT_ANIMATION *pAniT;
	short i;

	pAniT = &pAnimation[iAnimation];
	if(!pAniT || iID < 0 || iID >= pAniT->iSteps)
		return;
	if(bChildrenToo)
		for(i = 0; i < Header.iChildren; i++)
			pChild[i]->DestroyAnimationStepData(iAnimation, iID, bChildrenToo);
	pStepT = &pAniT->pStep[iID];
	if(pStepT->fDiffuseColorIncreasePos)
		free(pStepT->fDiffuseColorIncreasePos);
	if(pStepT->fVertexIncreasePos)
		free(pStepT->fVertexIncreasePos);
	if(pStepT->fNormalIncreasePos)
		free(pStepT->fNormalIncreasePos);
	if(pStepT->fTextureCoordIncreasePos)
		free(pStepT->fTextureCoordIncreasePos);
} // end AS_OBJECT::DestroyAnimationStepData()

void AS_OBJECT::SetupAnimationData(BOOL bChildrenToo)
{ // begin AS_OBJECT::SetupAnimationData()
	AS_OBJECT_ANIMATION *pTempAnimation;
	AS_OBJECT_ANIMATION_STEP *pTempObjAnimationStep;
	int i, i2;

	if(bChildrenToo)
		for(i = 0; i < Header.iChildren; i++)
			pChild[i]->SetupAnimationData(bChildrenToo);
	// Setup precalculated data:
	for(i2 = 0; i2 < Header.iAnimations; i2++)
	{
		pTempAnimation = &pAnimation[i2];
		for(i = 0; i < pTempAnimation->iSteps; i++)
		{
			pTempObjAnimationStep = &pTempAnimation->pStep[i];
			if(!pTempObjAnimationStep->pFrame)
				continue;
			if(!pTempObjAnimationStep->fDiffuseColorIncreasePos)
				pTempObjAnimationStep->fDiffuseColorIncreasePos = new FLOAT3[pTempObjAnimationStep->pFrame->iDiffuseColors];
			if(!pTempObjAnimationStep->fVertexIncreasePos)
				pTempObjAnimationStep->fVertexIncreasePos = new FLOAT3[pTempObjAnimationStep->pFrame->iVertices];
			if(!pTempObjAnimationStep->fNormalIncreasePos)
				pTempObjAnimationStep->fNormalIncreasePos = new FLOAT3[pTempObjAnimationStep->pFrame->iNormals];
			if(!pTempObjAnimationStep->fTextureCoordIncreasePos)
				pTempObjAnimationStep->fTextureCoordIncreasePos = new FLOAT2[pTempObjAnimationStep->pFrame->iTextureCoords];
		}
	}
	// Setup current frame info:
	if(!Header.iFrames)
		return;
	// Each frame has the same number of elements...
	CurrentFrame.iDiffuseColors = pFrame[0].iDiffuseColors;
	CurrentFrame.iVertices = pFrame[0].iVertices;
	CurrentFrame.iTextureCoords = pFrame[0].iTextureCoords;
	CurrentFrame.iNormals = pFrame[0].iNormals;
	CurrentFrame.iFaces = pFrame[0].iFaces;
	if(!CurrentFrame.fDiffuseColor)
		CurrentFrame.fDiffuseColor = new FLOAT3[CurrentFrame.iDiffuseColors];
	if(!CurrentFrame.fVertex)
		CurrentFrame.fVertex = new FLOAT3[CurrentFrame.iVertices];
	if(!CurrentFrame.fTextureCoord)
		CurrentFrame.fTextureCoord = new FLOAT2[CurrentFrame.iTextureCoords];
	if(!CurrentFrame.fNormal)
		CurrentFrame.fNormal = new FLOAT3[CurrentFrame.iNormals];
	CalculateInterpolations();
} // end AS_OBJECT::SetupAnimationData()
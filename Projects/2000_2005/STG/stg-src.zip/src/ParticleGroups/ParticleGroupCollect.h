/*
	File: ParticleGroupCollect.h

	Description: Collect particle group
*/

#ifndef __PARTICLEGROUPCOLLECT_H__
#define __PARTICLEGROUPCOLLECT_H__


// Classes
typedef class TParticleGroupCollect : public ASTParticleGroup {

	public:
		struct SInitData {
			ASTModelHandler *pModelHandler; // Pointer to the resource model
		};
		

		/*
			Initializes the particle group

			Parameters:
				int   iParticles		 -> Number of particles
				char* pszTextureFilename -> Filename of the particle texture
				void* pData				 -> Additional data

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/	
		bool InitParticleGroup(const int iParticles, const char* pszTextureFilename = ASSTANDARDPARTICLETEXTURE,
							   const void* pData = NULL);


	private:
		/*
			Virtual entity functions
		*/
		virtual void CustomUpdateFunction();


} TParticleGroupCollect;


#endif // __PARTICLEGROUPCOLLECT_H__
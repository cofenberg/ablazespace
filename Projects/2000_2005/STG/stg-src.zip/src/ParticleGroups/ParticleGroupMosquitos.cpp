/*
	File: ParticleGroupMosquitos.cpp
*/

#include <ASEngine.h>
#include "ParticleGroupMosquitos.h"
#include "..\Game.h"


/*
	Initializes the particle group
*/	
bool TParticleGroupMosquitos::InitParticleGroup(const int iParticles, const char* pszTextureFilename, const void* pData)
{
	// Initialize the particles
	if (InitParticles(iParticles, pszTextureFilename)) return true;

	{ // Initialize particles
		ASTParticle* pSParticle     = GetParticle(),
				   * pSLastParticle = GetParticle(GetParticles());
		int i;

		for (; pSParticle < pSLastParticle; pSParticle++) {
			pSParticle->bActive   = true;
			pSParticle->fSize	  = 10 + (float) (rand() % 200) / 20.f;
			pSParticle->fColor[R] = 1.f;
			pSParticle->fColor[G] = 1.f;
			pSParticle->fColor[B] = 1.f;
			pSParticle->fColor[A] = 1.f;
			pSParticle->fEnergie = 0.5f + ((float) (rand() % 100) / 200.f);
			for (i = 0; i < 2; i++) {
				if (!(rand() % 2))
					pSParticle->vPos.fV[i] = pSParticle->vFixPos.fV[i] = GetPos().fV[i] + ((float) (rand() % 16000) / 100);
				else
					pSParticle->vPos.fV[i] = pSParticle->vFixPos.fV[i] = GetPos().fV[i] - ((float) (rand() % 16000) / 100);
			}
			pSParticle->vPos.fV[i] = pSParticle->vFixPos.fV[i] = GetPos().fV[Z] - ((float) (rand() % 1000) / 100);
		}
	}

	// Load sounds
	  m_CHuntSound.Load("mosquitos_hunt.mp3");
	m_CAttackSound.Load("mosquitos_attack.mp3");
	  m_CBurnSound.Load("mosquitos_burn.mp3");
	 m_CDeathSound.Load("mosquitos_death.mp3");

	// Increase level mosquitos counter
	CGame.pCLevel->iMosquitos += iParticles;

	return false;
}

/*
	De-initialize particle group
*/
void TParticleGroupMosquitos::CustomParticleDeInitFunction()
{
	// Unload sounds
	  m_CHuntSound.Unload();
	m_CAttackSound.Unload();
 	  m_CBurnSound.Unload();
	 m_CDeathSound.Unload();
}

/*
	Particle group entity update function
*/
void TParticleGroupMosquitos::CustomUpdateFunction()
{
	if (!InFrustum()) return;

	ASTParticle* pSParticle     = GetParticle(),
			   * pSLastParticle = GetParticle(GetParticles());
	float fTimeDiff = _AS::CTimer.GetTimeDifference(), fZ, fDistance, fAggressive, fAggressiveT;
	int i;

	if (!pSParticle || !pSLastParticle) return;
	TActorUrl* pCUrlEntity = CGame.pCUrlActor;

	fAggressive = CGame.GetPlayTimer() / 40;
	if (fAggressive > 15.f) fAggressive = 15.f;

	for (; pSParticle < pSLastParticle; pSParticle++) {
		if (!pSParticle->bActive) continue;

		fDistance = pSParticle->vPos.fX * pSParticle->vPos.fX + pSParticle->vPos.fY * pSParticle->vPos.fY;
		for (i = 0; i < 3; i++) {
			// Update velocity
			if (pSParticle->vPos.fV[i] < pSParticle->vFixPos.fV[i])
				pSParticle->vVelocity.fV[i]  += _AS::CTimer.GetTimeDifference() * 9;
			else pSParticle->vVelocity.fV[i] -= _AS::CTimer.GetTimeDifference() * 9;
			pSParticle->vVelocity.fV[i] -= pSParticle->vVelocity.fV[i] * _AS::CTimer.GetTimeDifference();

			// Update position
			pSParticle->vPos.fV[i] += pSParticle->vVelocity.fV[i] * _AS::CTimer.GetTimeDifference() * 3;

			// Check for next position
			if (ASAbs(pSParticle->vPos.fV[i] - pSParticle->vFixPos.fV[i]) < 2.f && fDistance >= 50.f) {
				if (i != 2) {
					if (!(rand() % 2))
						pSParticle->vFixPos.fV[i] = GetPos().fV[i] + ((float) (rand() % 16000) / 100);
					else
						pSParticle->vFixPos.fV[i] = GetPos().fV[i] - ((float) (rand() % 16000) / 100);
				} else pSParticle->vFixPos.fV[i] = GetPos().fV[i] - ((float) (rand() % 1000) / 500);
			}
		}
		CGame.pCLevel->GetHeight(pSParticle->vPos.fX, pSParticle->vPos.fY, fZ, true);
		if (pSParticle->vPos.fZ > fZ - 1.f) {
			pSParticle->vFixPos.fV[Z] = fZ - 1.f;
			pSParticle->vPos.fZ -= _AS::CTimer.GetTimeDifference() * 10;
		}

		// Hunt url
		fAggressiveT = fAggressive +  pSParticle->fSize / 2;
		if (pSParticle->iCustom2) fAggressiveT *= 2.f;
		if (fDistance >= 50.f) {
			if (pCUrlEntity &&
				ASAbs(pCUrlEntity->GetPos().fX - pSParticle->vPos.fX) < fAggressiveT &&
				ASAbs(pCUrlEntity->GetPos().fY - pSParticle->vPos.fY) < fAggressiveT &&
				ASAbs(pCUrlEntity->GetPos().fZ - pSParticle->vPos.fZ) < fAggressiveT) {
				if (!pSParticle->iCustom1) { // Start hunt
					pSParticle->iCustom1 = 1;
					m_CHuntSound.SetPos(pSParticle->vPos);
					m_CHuntSound.Play();
				}
				if (fDistance < 200) pSParticle->vFixPos = ASTVector3D(0.f, 0.f, -12.f);
				else				 pSParticle->vFixPos = pCUrlEntity->GetPos();

				// Attack
				if (!pSParticle->fCustom1 &&
					ASAbs(pCUrlEntity->GetPos().fX - pSParticle->vPos.fX) < pSParticle->fSize / 8 &&
					ASAbs(pCUrlEntity->GetPos().fY - pSParticle->vPos.fY) < pSParticle->fSize / 8 &&
					ASAbs(pCUrlEntity->GetPos().fZ - pSParticle->vPos.fZ) < pSParticle->fSize / 8) {
					pSParticle->fCustom1 = 0.5f;
					m_CAttackSound.SetPos(pSParticle->vPos);
					m_CAttackSound.Play();
					SendMessage(pCUrlEntity, eActorMessageHit, (int) -pSParticle->fSize / 5);
					pSParticle->iCustom2 = 1;
				}
				pSParticle->fCustom1 -= fTimeDiff;
				if (pSParticle->fCustom1 < 0.f) pSParticle->fCustom1 = 0.f;

			} else {
				pSParticle->iCustom1 = 0;
				pSParticle->iCustom2 = 0;
			}

			// Check distance to vortex
			if (!pSParticle->iCustom2 && fDistance < 400) {
				if (pSParticle->vPos.fX > 0) pSParticle->vFixPos.fV[X] = 20 + ((float) (rand() % 16000) / 200);
				if (pSParticle->vPos.fX < 0) pSParticle->vFixPos.fV[X] = -(20 + ((float) (rand() % 16000) / 200));
				if (pSParticle->vPos.fY > 0) pSParticle->vFixPos.fV[Y] = 20 + ((float) (rand() % 16000) / 200);
				if (pSParticle->vPos.fY < 0) pSParticle->vFixPos.fV[Y] = -(20 + ((float) (rand() % 16000) / 200));
			}
			pSParticle->fSize += _AS::CTimer.GetTimeDifference();
			if (pSParticle->fSize > 30) pSParticle->fSize = 30;
		} else { // Burn the mosquitos
			pSParticle->fSize -= _AS::CTimer.GetTimeDifference() * 5;
			m_CBurnSound.SetPos(pSParticle->vPos);
			m_CBurnSound.Play();
			if (pSParticle->fSize < 5.f) {
				pSParticle->bActive = false;
				m_CDeathSound.SetPos(pSParticle->vPos);
				m_CDeathSound.Play();
				pCUrlEntity->IncScore(100);
				CGame.pCLevel->fTime += 5.f;

				// Decrease level mosquitos counter
				CGame.pCLevel->iMosquitos--;
			}
		}

		// Texture animation
		pSParticle->fAnimationTimer += fTimeDiff;
		if (pSParticle->fAnimationTimer > 0.05f) {
			pSParticle->fAnimationTimer = 0.f;
			pSParticle->iAnimationStep++;
			if (pSParticle->iAnimationStep >= GetTextureAnimationSteps())
				pSParticle->iAnimationStep = 0;
		}
	}
}
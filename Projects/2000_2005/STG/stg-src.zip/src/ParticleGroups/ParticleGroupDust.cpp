/*
	File: ParticleGroupDust.cpp
*/

#include <ASEngine.h>
#include "ParticleGroupDust.h"
#include "..\Main.h"
#include "..\Game.h"


/*
	Initializes the particle group
*/	
bool TParticleGroupDust::InitParticleGroup(const int iParticles, const char* pszTextureFilename, const void* pData)
{
	// Initialize the particles
	if (InitParticles(iParticles, pszTextureFilename)) return true;

	return false;
}

/*
	Adds a new particle
*/
bool TParticleGroupDust::AddParticle(const ASTParticle& pSParticleT)
{
	ASTParticle* pSParticle = GetFreeParticle();

	if (!pSParticle) return false;
	memcpy(pSParticle, &pSParticleT, sizeof(ASTParticle));

	return true;
}

/*
	Particle group entity update function
*/
void TParticleGroupDust::CustomUpdateFunction()
{
	ASTParticle* pSParticle     = GetParticle(),
			   * pSLastParticle = GetParticle(GetParticles());
	float fTimeDiff = _AS::CTimer.GetTimeDifference(), fZ;

	if (!pSParticle || !pSLastParticle) return;

	for (; pSParticle < pSLastParticle; pSParticle++) {
		if (!pSParticle->bActive) continue;

		pSParticle->fEnergie -= fTimeDiff;
		if (pSParticle->fEnergie < 0.f) {
			pSParticle->bActive = false;
			continue;
		}
		pSParticle->fSize += fTimeDiff * 10;
		pSParticle->fColor[A] = pSParticle->fEnergie;

		pSParticle->vVelocity += _AS::CPhysics.GetGravity() * fTimeDiff * 5;

		pSParticle->vPos += pSParticle->vVelocity * fTimeDiff;

		CGame.pCLevel->GetHeight(pSParticle->vPos.fX, pSParticle->vPos.fY, fZ);
		if (pSParticle->vPos.fZ > fZ) pSParticle->vVelocity.fZ = -pSParticle->vVelocity.fZ;

		// Texture animation
		pSParticle->fAnimationTimer += fTimeDiff;
		if (pSParticle->fAnimationTimer > 0.05f) {
			pSParticle->fAnimationTimer = 0.f;
			pSParticle->iAnimationStep++;
			if (pSParticle->iAnimationStep >= GetTextureAnimationSteps())
				pSParticle->iAnimationStep = 0;
		}
	}
	AutoBoundingBox();
}
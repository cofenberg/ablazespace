/*
	File: ParticleGroupCollect.cpp
*/

#include <ASEngine.h>
#include "ParticleGroupCollect.h"
#include "..\Main.h"
#include "..\Game.h"


/*
	Initializes the particle group
*/	
bool TParticleGroupCollect::InitParticleGroup(const int iParticles, const char* pszTextureFilename, const void* pData)
{
	// Get number of particles
	int iParticlesT = (int) (iParticles * _AS::CConfig.GetParticleDensity());

	// Initialize the particles
	if (InitParticles(iParticlesT, pszTextureFilename)) return true;

	{ // Initialize particles
		ASTParticle* pSParticle     = GetParticle(),
				   * pSLastParticle = GetParticle(GetParticles());
		SInitData* pSInitData = (SInitData*) pData;

		if (!pSInitData->pModelHandler) return false;

		for (int i = 0; pSParticle < pSLastParticle; pSParticle++, i++) {
			if (pSInitData->pModelHandler->GetVertex(i, pSParticle->vPos)) continue;

			pSParticle->bActive  = true;
			pSParticle->fSize	 = 1 + (float) (rand() % 100) / 100.f;
			pSParticle->fEnergie = 0.8f + (float) (rand() % 100) / 500.f;

			pSParticle->vVelocity.fX = (float) (rand() % 200) / 100.f;
			if (!(rand() % 2)) pSParticle->vVelocity.fX = -pSParticle->vVelocity.fX;
			pSParticle->vVelocity.fY = (float) (rand() % 200) / 100.f;
			if (!(rand() % 2)) pSParticle->vVelocity.fY = -pSParticle->vVelocity.fY;
			pSParticle->vVelocity.fZ = -10.f - ((float) (rand() % 200) / 20.f);

			pSParticle->fColor[R] = pSParticle->fColor[G] = pSParticle->fEnergie / 2;
			pSParticle->fColor[B] = 0.8f + (float) (rand() % 100) / 500.f;

			pSParticle->iAnimationStep = rand() % 16;
		}
	}

	RemoveAutomatically();

	return false;
}

/*
	Particle group entity update function
*/
void TParticleGroupCollect::CustomUpdateFunction()
{
	ASTParticle* pSParticle     = GetParticle(),
			   * pSLastParticle = GetParticle(GetParticles());
	float fTimeDiff = _AS::CTimer.GetTimeDifference(), fZ;
	int iActiveParticles = 0;

	if (!pSParticle || !pSLastParticle) return;

	for (; pSParticle < pSLastParticle; pSParticle++) {
		if (!pSParticle->bActive) continue;
		iActiveParticles++;

		pSParticle->fEnergie -= fTimeDiff / 2;
		if (pSParticle->fEnergie < 0.f) {
			pSParticle->bActive = false;
			continue;
		}
		pSParticle->fSize += fTimeDiff * 2;
		pSParticle->fColor[A] = pSParticle->fEnergie;

		pSParticle->vVelocity += _AS::CPhysics.GetGravity() * fTimeDiff * 10;

		pSParticle->vPos += pSParticle->vVelocity * fTimeDiff * 2;

		CGame.pCLevel->GetHeight(pSParticle->vPos.fX, pSParticle->vPos.fY, fZ);
		if (pSParticle->vPos.fZ > fZ) pSParticle->vVelocity = -pSParticle->vVelocity;

		// Texture animation
		pSParticle->fAnimationTimer += fTimeDiff;
		if (pSParticle->fAnimationTimer > 0.05f) {
			pSParticle->fAnimationTimer = 0.f;
			pSParticle->iAnimationStep++;
			if (pSParticle->iAnimationStep >= GetTextureAnimationSteps())
				pSParticle->iAnimationStep = 0;
		}
	}

	AutoBoundingBox();

	if (RemoveAutomatically() && !iActiveParticles) Remove();
}
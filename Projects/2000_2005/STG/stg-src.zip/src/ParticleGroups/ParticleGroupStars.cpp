/*
	File: ParticleGroupStars.cpp
*/

#include <ASEngine.h>
#include "..\Game.h"
#include "ParticleGroupStars.h"


/*
	Initializes the particle group
*/	
bool TParticleGroupStars::InitParticleGroup(const int iParticles, const char* pszTextureFilename, const void* pData)
{
	// Get number of particles
	int iParticlesT = (int) (iParticles * _AS::CConfig.GetParticleDensity());

	// Initialize the particles
	if (InitParticles(iParticlesT, pszTextureFilename)) return true;

	{ // Initialize particles
		ASTParticle* pSParticle     = GetParticle(),
				   * pSLastParticle = GetParticle(GetParticles());

		for (int i = 0; pSParticle < pSLastParticle; pSParticle++, i++) {
			pSParticle->bActive  = true;
			pSParticle->fSize	 = 1.f + (float) (rand() % 100) / 50.f;
			pSParticle->vPos	 = GetPos();
			pSParticle->fEnergie = 0.8f + (float) (rand() % 100) / 500.f;

			pSParticle->vVelocity.fX = (float) (rand() % 200) / 50.f;
			if (!(rand() % 2)) pSParticle->vVelocity.fX = -pSParticle->vVelocity.fX;
			pSParticle->vVelocity.fY = (float) (rand() % 200) / 50.f;
			if (!(rand() % 2)) pSParticle->vVelocity.fY = -pSParticle->vVelocity.fY;
			pSParticle->vVelocity.fZ = -15.f - ((float) (rand() % 200) / 15.f);
			pSParticle->fColor[R] = pSParticle->fColor[G] = pSParticle->fColor[B] = pSParticle->fColor[A] = 1.f;
			pSParticle->iAnimationStep = rand() % 16;
		}
	}

	RemoveAutomatically();

	return false;
}

/*
	Particle group entity update function
*/
void TParticleGroupStars::CustomUpdateFunction()
{
	ASTParticle* pSParticle     = GetParticle(),
			   * pSLastParticle = GetParticle(GetParticles());
	float fTimeDiff = _AS::CTimer.GetTimeDifference(), fZ;
	int iActiveParticles = 0;

	if (!pSParticle || !pSLastParticle) return;

	for (; pSParticle < pSLastParticle; pSParticle++) {
		if (!pSParticle->bActive) continue;
		iActiveParticles++;

		pSParticle->fSize -= fTimeDiff * 1.2f;
		if (pSParticle->fSize < 0.f) {
			pSParticle->bActive = false;
			continue;
		}

		pSParticle->vVelocity += _AS::CPhysics.GetGravity() * fTimeDiff * 10;

		pSParticle->vPos += pSParticle->vVelocity * fTimeDiff * 2;

		CGame.pCLevel->GetHeight(pSParticle->vPos.fX, pSParticle->vPos.fY, fZ);
		if (pSParticle->vPos.fZ > fZ) pSParticle->vVelocity.fZ = -pSParticle->vVelocity.fZ;

		// Texture animation
		pSParticle->fAnimationTimer += fTimeDiff;
		if (pSParticle->fAnimationTimer > 0.1f) {
			pSParticle->fAnimationTimer = 0.f;
			pSParticle->iAnimationStep++;
			if (pSParticle->iAnimationStep >= GetTextureAnimationSteps())
				pSParticle->iAnimationStep = 0;
		}
	}

	AutoBoundingBox();

	if (RemoveAutomatically() && !iActiveParticles) Remove();
}
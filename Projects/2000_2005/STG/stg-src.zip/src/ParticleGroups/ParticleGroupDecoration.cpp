/*
	File: ParticleGroupDecoration.cpp
*/

#include <ASEngine.h>
#include "ParticleGroupDecoration.h"
#include "..\Game.h"


/*
	Initializes the particle group
*/	
bool TParticleGroupDecoration::InitParticleGroup(const int iParticles, const char* pszTextureFilename, const void* pData)
{
	// Initialize the particles
	if (InitParticles(iParticles, pszTextureFilename)) return true;

	{ // Initialize particles
		ASTParticle* pSParticle     = GetParticle(),
				   * pSLastParticle = GetParticle(GetParticles());
		float fX, fY, fZ;

		for (; pSParticle < pSLastParticle; pSParticle++) {
			pSParticle->bActive   = true;
			pSParticle->fSize	  = 1 + (float) (rand() % 100) / 50.f;
			pSParticle->fColor[R] = 1.f;
			pSParticle->fColor[G] = 1.f;
			pSParticle->fColor[B] = 1.f;
			pSParticle->fColor[A] = 1.f;
			pSParticle->fEnergie  = 1.f;
			for (;;) {
				fX = (float) (rand() % 16000) / 100;
				if ((rand() % 2)) fX = -fX;
				fY = (float) (rand() % 16000) / 100;
				if ((rand() % 2)) fY = -fY;
				if (CGame.pCLevel->GetHeight(fX, fY, fZ)) break;
			}
			pSParticle->vPos.fX = fX;
			pSParticle->vPos.fY = fY;
			pSParticle->vPos.fZ = fZ - pSParticle->fSize / 5;
		}
	}

	return false;
}
/*
	File: ParticleGroupDecoration.h

	Description: Decoration particle group
*/

#ifndef __PARTICLEGROUPDECORATION_H__
#define __PARTICLEGROUPDECORATION_H__


// Classes
typedef class TParticleGroupDecoration : public ASTParticleGroup {

	public:
		/*
			Initializes the particle group

			Parameters:
				int   iParticles		 -> Number of particles
				char* pszTextureFilename -> Filename of the particle texture
				void* pData				 -> Additional data

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/	
		bool InitParticleGroup(const int iParticles, const char* pszTextureFilename = ASSTANDARDPARTICLETEXTURE,
							   const void* pData = NULL);


	private:


} TParticleGroupDecoration;


#endif // __PARTICLEGROUPDECORATION_H__
/*
	File: ParticleGroupSpring.cpp
*/

#include <ASEngine.h>
#include "ParticleGroupSpring.h"


/*
	Initializes the particle group
*/	
bool TParticleGroupSpring::InitParticleGroup(const int iParticles, const char* pszTextureFilename, const void* pData)
{
	// Initialize the particles
	if (InitParticles(iParticles, pszTextureFilename)) return true;

	return false;
}

/*
	Particle group entity update function
*/
void TParticleGroupSpring::CustomUpdateFunction()
{
	if (!InFrustum()) return;

	ASTParticle* pSParticle     = GetParticle(),
			   * pSLastParticle = GetParticle(GetParticles());
	float fTimeDiff = _AS::CTimer.GetTimeDifference();

	if (!pSParticle || !pSLastParticle) return;

	for (; pSParticle < pSLastParticle; pSParticle++) {
		if (!pSParticle->bActive) {
			pSParticle->bActive   = true;
			if (!(rand () % 3)) pSParticle->fSize = 7 + (float) (rand() % 130) / 5.f;
			else				pSParticle->fSize = 2 + (float) (rand() % 130) / 5.f;
			pSParticle->fColor[A] = (float) (rand() % 100) / 100.f;
			pSParticle->vPos	  = GetPos();
			pSParticle->fEnergie  = 0.2f + (float) (rand() % 60) / 100.f;

			pSParticle->vVelocity.fX = (float) (rand() % 200) / 100.f;
			if (!(rand() % 2)) pSParticle->vVelocity.fX = -pSParticle->vVelocity.fX;
			pSParticle->vVelocity.fY = (float) (rand() % 200) / 100.f;
			if (!(rand() % 2)) pSParticle->vVelocity.fY = -pSParticle->vVelocity.fY;
			pSParticle->vVelocity.fZ = -20.f - ((float) (rand() % 500) / 10.f);

			pSParticle->fColor[R] = pSParticle->fColor[G] = pSParticle->fColor[B] = pSParticle->fEnergie;
			continue;
		}

		pSParticle->fEnergie -= fTimeDiff * 3;
		if (pSParticle->fEnergie < 0.f) {
			pSParticle->bActive = false;
			continue;
		}
		pSParticle->fSize += fTimeDiff * 20;
		pSParticle->fColor[R] = pSParticle->fColor[G] = pSParticle->fColor[B] = pSParticle->fEnergie;

		pSParticle->vVelocity += _AS::CPhysics.GetGravity() * fTimeDiff / 20;

		pSParticle->vPos += pSParticle->vVelocity * fTimeDiff / 2;

		// Texture animation
		pSParticle->fAnimationTimer += fTimeDiff;
		if (pSParticle->fAnimationTimer > 0.2f) {
			pSParticle->fAnimationTimer = 0.f;
			pSParticle->iAnimationStep++;
			if (pSParticle->iAnimationStep >= GetTextureAnimationSteps())
				pSParticle->iAnimationStep = 0;
		}
	}
	AutoBoundingBox();
}
/*
	File: ParticleGroupDust.h

	Description: Dust particle group
*/

#ifndef __PARTICLEGROUPDUST_H__
#define __PARTICLEGROUPDUST_H__


// Classes
typedef class TParticleGroupDust : public ASTParticleGroup {

	public:
		/*
			Initializes the particle group

			Parameters:
				int   iParticles		 -> Number of particles
				char* pszTextureFilename -> Filename of the particle texture
				void* pData				 -> Additional data

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/	
		bool InitParticleGroup(const int iParticles, const char* pszTextureFilename = ASSTANDARDPARTICLETEXTURE,
							   const void* pData = NULL);

		/*
			Adds a new particle

			Parameters:
				ASTParticle& pSParticleT -> Particle which should be added

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool AddParticle(const ASTParticle& pSParticleT);


	private:
		/*
			Virtual entity functions
		*/
		virtual void CustomUpdateFunction();


} TParticleGroupDust;


#endif // __PARTICLEGROUPDUST_H__
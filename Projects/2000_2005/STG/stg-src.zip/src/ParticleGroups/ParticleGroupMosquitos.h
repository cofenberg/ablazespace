/*
	File: ParticleGroupMosquitos.h

	Description: Mosquitos particle group
*/

#ifndef __PARTICLEGROUPMOSQUITOS_H__
#define __PARTICLEGROUPMOSQUITOS_H__


// Classes
typedef class TParticleGroupMosquitos : public ASTParticleGroup {

	public:
		/*
			Initializes the particle group

			Parameters:
				int   iParticles		 -> Number of particles
				char* pszTextureFilename -> Filename of the particle texture
				void* pData				 -> Additional data

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/	
		bool InitParticleGroup(const int iParticles, const char* pszTextureFilename = ASSTANDARDPARTICLETEXTURE,
							   const void* pData = NULL);


	private:
		// Sounds
		ASTSoundHandler m_CHuntSound;
		ASTSoundHandler m_CAttackSound;
		ASTSoundHandler m_CBurnSound;
		ASTSoundHandler m_CDeathSound;


		/*
			Virtual particle group functions
		*/
		virtual void CustomParticleDeInitFunction();

		/*
			Virtual entity functions
		*/
		virtual void CustomUpdateFunction();


} TParticleGroupMosquitos;


#endif // __PARTICLEGROUPMOSQUITOS_H__
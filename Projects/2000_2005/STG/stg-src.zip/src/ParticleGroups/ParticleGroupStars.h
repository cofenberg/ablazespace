/*
	File: ParticleGroupStars.h

	Description: Stars particle group
*/

#ifndef __PARTICLEGROUPSTARS_H__
#define __PARTICLEGROUPSTARS_H__


// Classes
typedef class TParticleGroupStars : public ASTParticleGroup {

	public:
		/*
			Initializes the particle group

			Parameters:
				int   iParticles		 -> Number of particles
				char* pszTextureFilename -> Filename of the particle texture
				void* pData				 -> Additional data

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/	
		bool InitParticleGroup(const int iParticles, const char* pszTextureFilename = ASSTANDARDPARTICLETEXTURE,
							   const void* pData = NULL);


	private:
		/*
			Virtual entity functions
		*/
		virtual void CustomUpdateFunction();


} TParticleGroupStars;


#endif // __PARTICLEGROUPSTARS_H__
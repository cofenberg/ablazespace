/*
	File: Language.cpp
*/

#include <ASEngine.h>


// Variables
ASTLanguageHandler CText; // Game texts
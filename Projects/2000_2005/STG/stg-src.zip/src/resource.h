//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDC_CREDITS_VERSION_TEXT        1
#define IDD_CONFIG                      3
#define IDD_CREDITS                     4
#define IDD_CONFIG_GENERAL              8
#define ID_SOFTGAMES_HOMEPAGE3          19
#define IDC_CONFIG_DEBUG_SHOW_QUADTREES 29
#define IDC_CONFIG_DEBUG_SHOW_VERTICES  30
#define IDC_CONFIG_DEBUG_SHOW_NORMALS   31
#define IDC_CONFIG_OK                   32
#define IDC_CONFIG_CANCEL               34
#define IDC_CREDITS_BUILD_DATE          35
#define IDC_CONFIG_QUIT                 36
#define IDC_CONFIG_STANDARD             37
#define IDC_CREDITS_BUILD_TIME          37
#define IDC_CREDITS_OK                  38
#define IDC_CREDITS_VERSION             40
#define IDC_CONFIG_CREDITS              42
#define IDC_CREDITS_BUILD               51
#define IDC_CONFIG_TAB                  55
#define IDC_CONFIG_GENERAL_PLANTS_T     68
#define IDC_CONFIG_GENERAL_LEVELDETAIL_T 69
#define IDC_CONFIG_GENERAL_PLANTS       70
#define IDC_CONFIG_GENERAL_LEVELDETAIL  71
#define IDC_CONFIG_GENERAL_PLANTS_P     78
#define IDC_CONFIG_GENERAL_LEVELDETAIL_P 79
#define IDD_CONFIG_DEBUG                101
#define IDR_GAME                        104
#define IDI_ICON                        130
#define IDC_CREDITS_PROGRAMMING         1475
#define IDC_CREDITS_GRAPHIC             1476
#define IDC_CREDITS_MUSIC               1477
#define ID_SOFTGAMES_HOMEPAGE           40001
#define ID_HAPPYGRAFIX_HOMEPAGE         40002
#define ID_GENERAL_QUIT                 40003
#define ID_OPTIONS_CONFIG               40004
#define ID_SECONDEVOLUTION_HOMEPAGE     40005
#define ID_3DIMENSIONEN_HOMEPAGE        40006
#define ID_TOXEEN_HOMEPAGE              40007
#define ID_HELP_CREDITS                 40008
#define ID_HELP_HELP                    40010
#define ID_OPTIONS_OPENLOG              40012
#define ID_GENERAL_MAINMENU             40036
#define ID_ABLAZESPACE_HOMEPAGE         40039

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40008
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

/*
	File: Main.h

	Description: Main file
*/

#ifndef __MAIN_H__
#define __MAIN_H__


// Variables
extern bool bCheatsActivated;
extern bool bCheatImmotral;
extern bool bCheatNoMosquitos;
extern bool bCheatNoTurtles;
extern bool bCheatUnlimitedLives;
extern bool bCheatNoScoreDecrease;
extern bool bCheatNoTimeLimit;
extern bool bCheatQuick;


#endif // __MAIN_H__

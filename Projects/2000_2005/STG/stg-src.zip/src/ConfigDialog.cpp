/*
	File: ConfigDialog.cpp
*/

#include <ASEngine.h>
#include "Game.h"
#include "resource.h"
#include <commctrl.h>


// Definations
#define CONFIG_TABS 2
enum {TAB_CONFIG_GENERAL, TAB_CONFIG_DEBUG};

// Variables
TConfig CConfigT;
int		  iCurrentConfigTab;
HWND	  hWndConfig, hWndConfigTab[CONFIG_TABS];


/*
	Opens the configuration dialog
*/
bool TConfig::OpenDialog(const HWND hWnd)
{
	bool bError = false;

	// Minimize the window
	if (hWnd) SendMessage(hWnd, WM_SYSCOMMAND, SC_MINIMIZE, 0);

	// Make a backup of our current configuration
	memcpy(&CConfigT, &CConfig, sizeof(TConfig));

	// Add the text update function to the language handler
	CText.AddCustomUpdateFunction(ProcTextUpdate);

	if(DialogBox(GetModuleHandle(GAMEMODULENAME), MAKEINTRESOURCE(IDD_CONFIG), hWnd, (DLGPROC) ConfigProc) == -1)
		bError = true;
	hWndConfig = NULL;

	// Remove the text update function to the language handler
	CText.RemoveCustomUpdateFunction(ProcTextUpdate);
	
	// Normalize the window
	if (hWnd) SendMessage(hWnd, WM_SIZE, SIZE_RESTORED, 0);

	return bError;
}

/*
	Opens the credits dialog
*/
bool TConfig::OpenCreditsDialog(const HWND hWnd)
{
	bool bError = false;

	if(DialogBox(GetModuleHandle(GAMEMODULENAME), MAKEINTRESOURCE(IDD_CREDITS), hWnd, (DLGPROC) CreditsProc) == -1)
		bError = true;
	
	return bError;
}

/*
	The text update function
*/
void TConfig::ProcTextUpdate()
{
	SendMessage(hWndConfig, WM_INITDIALOG, 0, 0);
}

/*
	Main configuration procedure
*/
LRESULT CALLBACK TConfig::ConfigProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	return CConfig.Proc(hWnd, iMessage, wParam, lParam);
}

LRESULT TConfig::Proc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HWND hWndTab;
	TC_ITEM tie;
	int i;

	switch (iMessage) {
        case WM_INITDIALOG:			
			_AS::CLog.Output("Open configuration dialog");
			hWndConfig = hWnd;

			// Texts
			SetWindowText( hWnd,					  CText.Get(_T_Configurations));
  			SetDlgItemText(hWnd, IDC_CONFIG_OK,		  CText.Get(_T_Ok));
  			SetDlgItemText(hWnd, IDC_CONFIG_CANCEL,	  CText.Get(_T_Cancel));
  			SetDlgItemText(hWnd, IDC_CONFIG_STANDARD, CText.Get(_T_Standard));
  			SetDlgItemText(hWnd, IDC_CONFIG_QUIT,	  CText.Get(_T_Quit));
  			SetDlgItemText(hWnd, IDC_CONFIG_CREDITS,  CText.Get(_T_Credits));

			// Setup config tabs
			hWndTab = GetDlgItem(hWnd, IDC_CONFIG_TAB);
			TabCtrl_DeleteAllItems(hWndTab);
			tie.mask = TCIF_TEXT;

			// General
			tie.pszText	= (char*) CText.Get(_T_General);
			TabCtrl_InsertItem(hWndTab, TAB_CONFIG_GENERAL, &tie);
			if (hWndConfigTab[TAB_CONFIG_GENERAL]) DestroyWindow(hWndConfigTab[TAB_CONFIG_GENERAL]);
			hWndConfigTab[TAB_CONFIG_GENERAL] = CreateDialogParam(GetModuleHandle(GAMEMODULENAME), MAKEINTRESOURCE(IDD_CONFIG_GENERAL), hWndTab, (DLGPROC) ConfigGeneralProc, WM_INITDIALOG);

			// Debug
			if (_AS::CConfig.IsDebugMode()) {
				tie.pszText	= (char*) CText.Get(_T_Debug);
				TabCtrl_InsertItem(hWndTab, TAB_CONFIG_DEBUG, &tie);
				if (hWndConfigTab[TAB_CONFIG_DEBUG]) DestroyWindow(hWndConfigTab[TAB_CONFIG_DEBUG]);
				hWndConfigTab[TAB_CONFIG_DEBUG] = CreateDialogParam(GetModuleHandle(GAMEMODULENAME), MAKEINTRESOURCE(IDD_CONFIG_DEBUG), hWndTab, (DLGPROC) ConfigDebugProc, WM_INITDIALOG);
			}

			iCurrentConfigTab = -1;
			SendMessage(hWnd, WM_NOTIFY, IDC_CONFIG_TAB, 0);

			UpdateWindow(hWnd);
			BringWindowToTop(hWnd);
			return true;

        case WM_COMMAND:
            switch (LOWORD(wParam)) {
                case IDC_CONFIG_OK:
					_AS::CLog.Output("Close configuration dialog (ok)");
					Save();
					EndDialog(hWnd, false);
					return true;

				case IDC_CONFIG_CANCEL:
					_AS::CLog.Output("Close configuration dialog (cancel)");
					memcpy(&CConfig, &CConfigT, sizeof(TConfig));
					EndDialog(hWnd, false);
					break;

				case IDC_CONFIG_STANDARD:
					if (MessageBox(hWnd, CText.Get(_T_AreYouSure), CText.Get(_T_Question), MB_YESNO | MB_ICONQUESTION) == IDNO)
						break;
					Reset();
					SendMessage(hWnd, WM_INITDIALOG, 0, 0);
					break;

				case IDC_CONFIG_QUIT:
					_AS::CLog.Output("Close configuration dialog (quit)");
					_AS::ShutDown();
					EndDialog(hWnd, false);
					break;

				case IDC_CONFIG_CREDITS: DialogBox(GetModuleHandle(GAMEMODULENAME), MAKEINTRESOURCE(IDD_CREDITS), hWnd, (DLGPROC) CreditsProc); break;

			// Homepages
				case ID_ABLAZESPACE_HOMEPAGE:	  _AS::CFileSystem.Open("http://www.ablazespace.de"); break;
				case ID_3DIMENSIONEN_HOMEPAGE:	  _AS::CFileSystem.Open("http://www.3dimensionen.de"); break;
				case ID_TOXEEN_HOMEPAGE:		  _AS::CFileSystem.Open("http://www.toxeen.de"); break;
				case ID_SOFTGAMES_HOMEPAGE:		  _AS::CFileSystem.Open("http://www.softgames.de"); break;
				case ID_HAPPYGRAFIX_HOMEPAGE:	  _AS::CFileSystem.Open("http://www.happy-grafix.de"); break;
				case ID_SECONDEVOLUTION_HOMEPAGE: _AS::CFileSystem.Open("http://www.second-evolution.de"); break;
            }
            break;

        case WM_NOTIFY: 
			switch (wParam) {
				case IDC_CONFIG_TAB:
					i = TabCtrl_GetCurSel(GetDlgItem(hWnd, IDC_CONFIG_TAB));
					if (i == iCurrentConfigTab) break; // This tab is already opend
					iCurrentConfigTab = i;
					if (iCurrentConfigTab < 0) iCurrentConfigTab = 0;
					for (i = 0; i < CONFIG_TABS; i++) ShowWindow(hWndConfigTab[i], SW_HIDE);
					UpdateWindow(hWndConfigTab[iCurrentConfigTab]);
					ShowWindow(hWndConfigTab[iCurrentConfigTab], SW_SHOW);
					SetFocus(hWndConfigTab[iCurrentConfigTab]);
					SendMessage(hWndConfigTab[iCurrentConfigTab], WM_INITDIALOG, 0, 0);
					break;
			} 
			break;

		case WM_CLOSE: SendMessage(hWnd, WM_COMMAND, IDC_CONFIG_OK, 0); break;
		case WM_DESTROY: for(i = 0; i < CONFIG_TABS; i++) hWndConfigTab[i] = NULL; break;

    }

    return false;
}

/*
	General task procedure
*/
LRESULT CALLBACK TConfig::ConfigGeneralProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	return CConfig.GeneralProc(hWnd, iMessage, wParam, lParam);
}

LRESULT TConfig::GeneralProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	char szTemp[256];
	int i;

	switch (iMessage) {
        case WM_INITDIALOG:
			// Texts
  			SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_LEVELDETAIL_T, CText.Get(_T_LevelDetail));
  			SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_PLANTS_T, CText.Get(_T_Plants));

			// Setup the level detail configuration
		    SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LEVELDETAIL, TBM_SETRANGE, false, MAKELONG(1, 100));
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LEVELDETAIL, TBM_SETTIC,   true, 50);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LEVELDETAIL, TBM_SETPOS,   true, (long) (m_fLevelDetail * 100));
  			sprintf(szTemp, "%0.1f%%", m_fLevelDetail * 100);
			SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_LEVELDETAIL_P, szTemp);

			// Setup the plants configuration
		    SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_PLANTS, TBM_SETRANGE, false, MAKELONG(1, 100));
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_PLANTS, TBM_SETTIC,   true, 50);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_PLANTS, TBM_SETPOS,   true, (long) (m_fPlants * 100));
  			sprintf(szTemp, "%0.1f%%", m_fPlants * 100);
			SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_PLANTS_P, szTemp);

			SetFocus(hWnd);
			UpdateWindow(hWnd);
			return true;

        case WM_NOTIFY:
            switch (wParam) {
				case IDC_CONFIG_GENERAL_LEVELDETAIL:
					i = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LEVELDETAIL, TBM_GETPOS, 0, 0);
					m_fLevelDetail = (float) i / 100;
  					sprintf(szTemp, "%0.1f%%", m_fLevelDetail * 100);
					SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_LEVELDETAIL_P, szTemp);
					break;

				case IDC_CONFIG_GENERAL_PLANTS:
					i = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_PLANTS, TBM_GETPOS, 0, 0);
					m_fPlants = (float) i / 100;
  					sprintf(szTemp, "%0.1f%%", m_fPlants * 100);
					SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_PLANTS_P, szTemp);
					break;
			}
			break;

        case WM_COMMAND:
            switch (LOWORD(wParam)) {
				case 0: break;
            }
            break;
    }

    return false;
}

/*
	Debug task procedure
*/
LRESULT CALLBACK TConfig::ConfigDebugProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	return CConfig.DebugProc(hWnd, iMessage, wParam, lParam);
}

LRESULT TConfig::DebugProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	switch (iMessage) {
        case WM_INITDIALOG:
			// Texts
			SetDlgItemText(hWnd, IDC_CONFIG_DEBUG_SHOW_QUADTREES, CText.Get(_T_ShowQuadtrees));
			SetDlgItemText(hWnd, IDC_CONFIG_DEBUG_SHOW_VERTICES,  CText.Get(_T_ShowVertices));
			SetDlgItemText(hWnd, IDC_CONFIG_DEBUG_SHOW_NORMALS,   CText.Get(_T_ShowNormals));

			// Setup check buttons
			SendDlgItemMessage(hWnd, IDC_CONFIG_DEBUG_SHOW_QUADTREES, BM_SETCHECK, m_bShowQuadtrees, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_DEBUG_SHOW_VERTICES,  BM_SETCHECK, m_bShowVertices, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_DEBUG_SHOW_NORMALS,   BM_SETCHECK, m_bShowNormals, 0L);

			SetFocus(hWnd);
			UpdateWindow(hWnd);
			return true;

		case WM_COMMAND:
            switch (LOWORD(wParam)) {
				case IDC_CONFIG_DEBUG_SHOW_QUADTREES: m_bShowQuadtrees = SendDlgItemMessage(hWnd, IDC_CONFIG_DEBUG_SHOW_QUADTREES, BM_GETCHECK, 0, 0L) != 0; break;
				case IDC_CONFIG_DEBUG_SHOW_VERTICES:  m_bShowVertices  = SendDlgItemMessage(hWnd, IDC_CONFIG_DEBUG_SHOW_VERTICES,  BM_GETCHECK, 0, 0L) != 0; break;
				case IDC_CONFIG_DEBUG_SHOW_NORMALS:   m_bShowNormals   = SendDlgItemMessage(hWnd, IDC_CONFIG_DEBUG_SHOW_NORMALS,   BM_GETCHECK, 0, 0L) != 0; break;
            }
            break;
    }

    return false;
}

/*
	Credits procedure
*/
LRESULT CALLBACK TConfig::CreditsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	char szTemp[256];

	switch (iMessage) {
        case WM_INITDIALOG:
			_AS::CLog.Output("Open credits dialog");
            SetDlgItemText(hWnd, IDC_CREDITS_VERSION,    GAMEVERSION);
            SetDlgItemText(hWnd, IDC_CREDITS_BUILD_DATE, __DATE__);
            SetDlgItemText(hWnd, IDC_CREDITS_BUILD_TIME, __TIME__);

			// Texts
  			SetDlgItemText(hWnd, IDC_CREDITS_OK,		   CText.Get(_T_Ok));
  			SetDlgItemText(hWnd, IDC_CREDITS_VERSION_TEXT, CText.Get(_T_Version));
  			SetDlgItemText(hWnd, IDC_CREDITS_BUILD,		   CText.Get(_T_Build));
			sprintf(szTemp, "%s:", CText.Get(_T_Programming));
  			SetDlgItemText(hWnd, IDC_CREDITS_PROGRAMMING,  szTemp);
			sprintf(szTemp, "%s:", CText.Get(_T_Graphic));
  			SetDlgItemText(hWnd, IDC_CREDITS_GRAPHIC,  szTemp);
			sprintf(szTemp, "%s:", CText.Get(_T_Music));
  			SetDlgItemText(hWnd, IDC_CREDITS_MUSIC,  szTemp);
			return true;

        case WM_COMMAND:
            switch (LOWORD(wParam)) {
                case IDC_CREDITS_OK:
					_AS::CLog.Output("Close engine credits dialog");
					EndDialog(hWnd, false);
					return true;
            }
			break;

		case WM_CLOSE: SendMessage(hWnd, WM_COMMAND, IDC_CREDITS_OK, 0); break;
    }

    return false;
}
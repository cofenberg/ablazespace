/*
	File: Menus.cpp
*/

#include <ASEngine.h>
#include "Game.h"


// Variables
TMenus CMenus;
TMenuPoint MenuPoint[MENU_POINTS];
TMenuPoint 
		// Main menu
		   *pMP_MainMenu_ContinueGame			= &MenuPoint[ 0],
		   *pMP_MainMenu_StartGame				= &MenuPoint[ 1],
		   *pMP_MainMenu_Highscore				= &MenuPoint[ 2],
		   *pMP_MainMenu_Options				= &MenuPoint[ 3],
		   *pMP_MainMenu_Help					= &MenuPoint[ 4],
		   *pMP_MainMenu_Credits				= &MenuPoint[ 5],
		   *pMP_MainMenu_Quit					= &MenuPoint[ 6],

		// Options
		   *pMP_Options_KeysSetup				= &MenuPoint[ 7],
		   *pMP_Options_GameOptions				= &MenuPoint[ 8],
		   *pMP_Options_EngineOptions			= &MenuPoint[ 9],
		   *pMP_Options_Back					= &MenuPoint[10],
		   
		// Keys setup:
		   *pMP_KeysSetup_Left					= &MenuPoint[11],
		   *pMP_KeysSetup_Right					= &MenuPoint[12],
		   *pMP_KeysSetup_Up					= &MenuPoint[13],
		   *pMP_KeysSetup_Down					= &MenuPoint[14],
		   *pMP_KeysSetup_Run					= &MenuPoint[15],
		   *pMP_KeysSetup_Jump					= &MenuPoint[16],
		   *pMP_KeysSetup_Attack				= &MenuPoint[17],
		   *pMP_KeysSetup_Pause				    = &MenuPoint[18],
		   *pMP_KeysSetup_StandardConfiguration = &MenuPoint[19],
		   *pMP_KeysSetup_Back					= &MenuPoint[20],
		
		// Are you sure
		   *pMP_AreYouSure_Yes					= &MenuPoint[21],
		   *pMP_AreYouSure_No					= &MenuPoint[22];

extern float fFontAni[4][2]; // The current vertex position


/*
	The text update function
*/
void TMenus::ProcTextUpdate()
{
	char szFilename[256], szTemp[256];
	int i;

	if (CMenus.m_pszCreditsText) {
		for (i = 0; i < CMenus.m_iCreditsTexts; i++)
			if (CMenus.m_pszCreditsText[i]) free(CMenus.m_pszCreditsText[i]);
		free(CMenus.m_pszCreditsText);
	}

	// Setup filename information
	sprintf(szFilename, "%s\\%s\\credits.cre", _AS::CFileSystem.GetLanguagesDirectory(),
											   _AS::CConfig.GetLanguageName());
	_AS::CFileSystem.GetFullFilename(szFilename);

	// Load texts
	CMenus.m_iCreditsTexts  = GetPrivateProfileInt("general", "texts", 0, szFilename);
	CMenus.m_pszCreditsText = (char**) malloc(sizeof(char*) * CMenus.m_iCreditsTexts);
	for (i = 0; i < CMenus.m_iCreditsTexts; i++) {
		sprintf(szTemp, "%d", i);
		GetPrivateProfileString("texts", szTemp, "", szTemp, MAX_PATH, szFilename);
		CMenus.m_pszCreditsText[i] = (char*) malloc(strlen(szTemp) + 1);
		strcpy(CMenus.m_pszCreditsText[i], szTemp);
	}
}

/*
	Initializes the menu
*/
void TMenus::Init()
{
	char szFilename[256], szTemp[256];
	int i;

	// Load textures
			   m_CTitleTexture.Load("title.tga");
	 m_CAblazeSpaceLogoTexture.Load("ablazespace-logo.jpg");
	m_C3DimensionenLogoTexture.Load("3dimensionen-logo.jpg");
		  m_CToxeenLogoTexture.Load("toxeen-logo.jpg");
			 m_CSTGLogoTexture.Load("stg-logo.jpg");

	// Load sounds
	 m_CChangeSound.Load("change.mp3");
	  m_CEnterSound.Load("enter.mp3");
	  m_CLeaveSound.Load("leave.mp3");
       m_CMainMusic.Load("Toxeen - Softgames the Game - Menu.mp3");

	// Initialize data
	InitTitle();
	InitMenuPoints();
	m_CMainMusic.Play();
	m_CMainMusic.SetVolume(0.f);

	m_bIsInitialized = true;

	m_bMainMenu = true;
	m_iMenuPoint = pMP_MainMenu_StartGame->iID;

	m_fLogoWait		= 0.f;
	m_fNextLogoWait = 0.25;
	#ifdef NOLOGOS
		m_fLogosPercentage = 1.25f;
	#else
		m_fLogosPercentage = 0.f;
	#endif
	m_bFastLogos = false;

	m_fFOV		 = 45.f;
	m_bGetNewKey = false;
	m_fMenuTimer = 0.f;

	// Create highscore
	m_pCHighscore = new THighscore;

	// Load credits
	ASTEntity* pCEntity;
	ASCreateEntity(pCEntity, ASTEntity, "Credits Url");
	pCEntity->SetProtected(true);
	pCEntity->IncPos(-17.f, 10.f, -40.f);
	pCEntity->SetRot(-40.f, 70.f, 0.f);
	m_CUrlEntity.Load(pCEntity);
	m_CUrlModel.Load("url.md2");
	m_CUrlModel.SetActive();
	m_CUrlModel.SetEntity(pCEntity);
    m_CUrlModel.SetAnimationFlags(ASeModelAniFlagPlay | ASeModelAniFlagLoop);

	// Add the text update function to the language handler
	CText.AddCustomUpdateFunction(ProcTextUpdate);
	ProcTextUpdate();

	// Setup filename information
	sprintf(szFilename, "%s\\%s\\credits.cre", _AS::CFileSystem.GetLanguagesDirectory(),
											   _AS::CConfig.GetLanguageName());
	_AS::CFileSystem.GetFullFilename(szFilename);

	// Load textures
	m_iCreditsTextures  = GetPrivateProfileInt("general", "textures", 0, szFilename);
	m_pszCreditsTexture = (char**) malloc(sizeof(char*) * m_iCreditsTextures);
	for (i = 0; i < m_iCreditsTextures; i++) {
		sprintf(szTemp, "%d", i);
		GetPrivateProfileString("textures", szTemp, "", szTemp, MAX_PATH, szFilename);
		m_pszCreditsTexture[i] = (char*) malloc(strlen(szTemp) + 1);
		strcpy(m_pszCreditsTexture[i], szTemp);
		_AS::CTextureManager.PreLoad(m_pszCreditsTexture[i]);
	}

	m_fCreditsTextY = 0.f;

	#ifdef STARTINGAME
		m_bMenuActive = false;
		m_bMainMenu   = false;
		m_fMenuBlend  = 0.f;
		CGame.CreateNewLevel();
		_AS::CTimer.Pause(false);
	#else
		m_bMenuActive = true;
		m_fMenuBlend  = 0.01f;
	#endif
}

/*
	De-initializes the menu
*/
void TMenus::DeInit()
{
	int i;

	if (!m_bIsInitialized) return;

	// Remove the text update function to the language handler
	CText.RemoveCustomUpdateFunction(ProcTextUpdate);

	// Destroy credits
	m_CUrlEntity.Unload();
	m_CUrlModel.Unload();
	for (i = 0; i < m_iCreditsTexts; i++)
		if (m_pszCreditsText[i]) free(m_pszCreditsText[i]);
	if (m_pszCreditsText) free(m_pszCreditsText);
	for (i = 0; i < m_iCreditsTextures; i++)
		if (m_pszCreditsTexture[i]) free(m_pszCreditsTexture[i]);
	if (m_pszCreditsTexture) free(m_pszCreditsTexture);

	// Destroy highscore
	if (m_pCHighscore) {
		delete m_pCHighscore;
		m_pCHighscore = NULL;
	}

	// Unload textures
			   m_CTitleTexture.Unload();
	 m_CAblazeSpaceLogoTexture.Unload();
	m_C3DimensionenLogoTexture.Unload();
		  m_CToxeenLogoTexture.Unload();
		     m_CSTGLogoTexture.Unload();

	// Unload sounds
	 m_CChangeSound.Unload();
	  m_CEnterSound.Unload();
	  m_CLeaveSound.Unload();
       m_CMainMusic.Unload();

	m_bIsInitialized = false;
}

/*
	Draws the menus
*/
bool TMenus::Draw()
{
	if (!m_bIsInitialized) return false;

	if (!m_fMenuBlend) return false;

	glClearColor(m_fMenuBlend, m_fMenuBlend, m_fMenuBlend, 1.f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	_AS::CRenderer.SetCamera();
	if (_AS::CRenderer.GetRendererHandler() && _AS::CRenderer.GetRendererHandler()->IsInitialized()) {
		int iWidth, iHeight;
		RECT Rect;

		// Get window size	
		GetWindowRect(_AS::CRenderer.GetRendererHandler()->GetWnd(), &Rect);
		iWidth  = Rect.right  - Rect.left;
		iHeight = Rect.bottom - Rect.top;

		// Reset the scene
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		glViewport(0, 0, iWidth, iHeight);
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		gluPerspective(m_fFOV, (float) iWidth / (float) iHeight, 0.1f, 100.f);
		glMatrixMode(GL_MODELVIEW);
	}
	
	DrawCredits();
	DrawTitle();
	DrawMain();
	DrawHighscore();
	DrawOptions();
	DrawKeys();

	// For smooth blend in and out
	glClear(GL_DEPTH_BUFFER_BIT);
	glEnable(GL_BLEND);
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_DEPTH_TEST);
	glBlendFunc(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);
	glColor4f(0.f, 0.f, 0.f, m_fMenuBlend);
	glDisable(GL_CULL_FACE);
	glLoadIdentity();
	glTranslatef(0.f, 0.f, -24.f);
	glBegin(GL_QUADS);
		glVertex2f(-15.f, -12.f);
		glVertex2f( 15.f, -12.f);
		glVertex2f( 15.f,  12.f);
		glVertex2f(-15.f,  12.f);
	glEnd();
	_AS::CRenderer.AddTriangles(2);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);

	{ // Draw logos 
		float fAlpha;

		glEnable(GL_TEXTURE_2D);
		glLoadIdentity();
		glTranslatef(0.f, 0.f, -15.f);

		for (int i = 0; i < 4; i++) {
			fAlpha = (m_fLogosPercentage - ((float) i * 0.25f)) / 0.25f;
			if (fAlpha > 1.f) fAlpha = 1.f - (m_fLogosPercentage - (0.25f * (float) (i + 1))) / 0.25f;	
			if (fAlpha < 0.f)  continue;
			glColor4f(1.f, 1.f, 1.f, fAlpha);
			switch (i) {
				case 0:// AblazeSpace logo
					m_CAblazeSpaceLogoTexture.GetTexture()->BindOpenGLTexture();
					glBegin(GL_QUADS);
						glTexCoord2f(0.f, 0.f); glVertex2f(-5.f, -5.f);
						glTexCoord2f(1.f, 0.f); glVertex2f( 5.f, -5.f);
						glTexCoord2f(1.f, 1.f); glVertex2f( 5.f,  5.f);
						glTexCoord2f(0.f, 1.f); glVertex2f(-5.f,  5.f);
					glEnd();
					break;

				case 1: // 3Dimensionen logo
					m_C3DimensionenLogoTexture.GetTexture()->BindOpenGLTexture();
					glBegin(GL_QUADS);
						glTexCoord2f(0.f, 0.f); glVertex2f(-5.f, -5.f);
						glTexCoord2f(1.f, 0.f); glVertex2f( 5.f, -5.f);
						glTexCoord2f(1.f, 1.f); glVertex2f( 5.f,  5.f);
						glTexCoord2f(0.f, 1.f); glVertex2f(-5.f,  5.f);
					glEnd();
					break;

				case 2: // Toxeen logo
					m_CToxeenLogoTexture.GetTexture()->BindOpenGLTexture();
					glBegin(GL_QUADS);
						glTexCoord2f(0.f, 0.f); glVertex2f(-5.f, -5.f);
						glTexCoord2f(1.f, 0.f); glVertex2f( 5.f, -5.f);
						glTexCoord2f(1.f, 1.f); glVertex2f( 5.f,  5.f);
						glTexCoord2f(0.f, 1.f); glVertex2f(-5.f,  5.f);
					glEnd();
					break;

				case 3: // Softgames - The Game logo
					m_CSTGLogoTexture.GetTexture()->BindOpenGLTexture();
					glBegin(GL_QUADS);
						glTexCoord2f(0.f, 0.f); glVertex2f(-5.f, -5.f);
						glTexCoord2f(1.f, 0.f); glVertex2f( 5.f, -5.f);
						glTexCoord2f(1.f, 1.f); glVertex2f( 5.f,  5.f);
						glTexCoord2f(0.f, 1.f); glVertex2f(-5.f,  5.f);
					glEnd();
					break;
			}
		}
	}

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);

	return true;
}

/*
	Updates the menus
*/
bool TMenus::Update()
{
	if (!m_bIsInitialized) return false;

	// Setup music
	if (CGame.IsLevel() && m_fLogosPercentage >= 1.25f) {
		if (!m_fMenuBlend) m_CMainMusic.Stop();
		else {
			if (!m_CMainMusic.IsPlaying()) m_CMainMusic.Play();
		}
		m_CMainMusic.SetVolume(m_fMenuBlend);
	} else {
		if (!m_CMainMusic.IsPlaying()) m_CMainMusic.Play();
		m_CMainMusic.SetVolume(1.f);
	}

	// Update logos
	if (m_fLogosPercentage >= 1.25f) m_fLogosPercentage = 1.25f;
	else if (m_fLogosPercentage < 1.25f) {
		if (m_fLogoWait > 0.f) {
			if (m_bFastLogos) m_fLogoWait -= _AS::CTimer.GetTimeDifference() * 10;
			else			  m_fLogoWait -= _AS::CTimer.GetTimeDifference();
			if (m_fLogoWait < 0.f) m_fLogoWait = 0.f;
		} else {
			if (m_bFastLogos) m_fLogosPercentage += _AS::CTimer.GetTimeDifference();
			else			  m_fLogosPercentage += _AS::CTimer.GetTimeDifference() / 10;
			if (m_fLogosPercentage >= m_fNextLogoWait) {
				m_fLogosPercentage  = m_fNextLogoWait;
				m_fNextLogoWait	   += 0.25f;
				m_fLogoWait		    = 3.f;
			}
		}
		if (_AS::CInput.IsKeyHit() >= 0) m_bFastLogos = true;

		return true;
	}

	// Update fov
	if (m_fFOV != 45.f) {
		if (m_fFOV < 45.f) {
			m_fFOV +=_AS::CTimer.GetTimeDifference() * 10;
			if (m_fFOV > 45.f) m_fFOV = 45.f;
		} else {
			m_fFOV -=_AS::CTimer.GetTimeDifference() * 10;
			if (m_fFOV < 45.f) m_fFOV = 45.f;
		}
	}

	// Check menu blending
	if (!m_bMenuActive) {
		if (m_fMenuBlend > 0.f) {
			m_fMenuBlend -= _AS::CTimer.GetTimeDifference() * 2;
			if (m_fMenuBlend < 0.f) m_fMenuBlend = 0.f;

			return true;
		}

		return false;
	} else {
		_AS::CTimer.Pause();
		m_fMenuBlend += _AS::CTimer.GetTimeDifference() * 2;
		if (m_fMenuBlend > 1.f) m_fMenuBlend = 1.f;
	}
	
	UpdateTitle();
	UpdateMain();	
	UpdateOptions();
	UpdateKeys();
	UpdateCredits();
	UpdateMenuPoints();

	{ // Update highscore
		bool bTemp = m_bHighscoreMenu;
		m_bHighscoreMenu = m_pCHighscore->Update();
		if (bTemp && !m_bHighscoreMenu) m_bMainMenu = true;
	}

	return true;
}

/*
	Returns the menu blending
*/
float TMenus::GetBlending() const
{
	return m_fMenuBlend;
}

/*
	Activates the menu
*/
void TMenus::Activate()
{
	m_bMenuActive = true;
	m_bMainMenu	  = true;
	m_fMenuTimer  = 0.f;
    m_CMainMusic.SetVolume(0.f);
	_AS::CSoundManager.StopSounds();

	if (!CGame.IsLevel()) m_iMenuPoint = pMP_MainMenu_StartGame->iID;
	else				  m_iMenuPoint = pMP_MainMenu_ContinueGame->iID;
}

/*
	Goes after the game into the highscore
*/
void TMenus::EnterHighscore(const int iScore, const bool bGameWon)
{
	CGame.DestroyLevel();
	m_bMenuActive = true;
	_AS::CLog.Output("open high");
	m_pCHighscore->Open(iScore, bGameWon);
	_AS::CLog.Output("open high done");

}

/*
	Are the logos currently shown?
*/
bool TMenus::IsLogos() const
{
	if (m_fLogosPercentage >= 1.25f) return false;
	else							 return true;
}

/*
	Draws the menu background
*/
void TMenus::DrawBackground(float fZ, float fLeft, float fTop, float fRight, float fBottom, float fDensity)
{
	glDisable(GL_CULL_FACE);
	glColor4f(0.f, 0.f, 0.f, fDensity);
	glBegin(GL_QUADS);
		glVertex3f(fLeft,  fTop,	fZ);
		glVertex3f(fRight, fTop,	fZ);
		glVertex3f(fRight, fBottom, fZ);
		glVertex3f(fLeft,  fBottom, fZ);
	glEnd();

	// Create a smooth bounding
	glBegin(GL_QUADS);
		// Left
		glColor4f(0.f, 0.f, 0.f, fDensity);
		glVertex3d(fRight, fBottom, fZ);
		glVertex3d(fRight, fTop,	fZ);
		glColor4f(0.f, 0.f, 0.f, 1.f);
		glVertex3d(fRight+0.1f, fTop-0.1f, fZ+1.0f);
		glVertex3d(fRight+0.1f, fBottom+0.1f, fZ+1.0f);

		// Top
		glColor4f(0.f, 0.f, 0.f, 1.f);
		glVertex3d(fLeft-0.1f, fBottom+0.1f, fZ+1.0f);
		glColor4f(0.f, 0.f, 0.f, fDensity);
		glVertex3d(fLeft, fBottom, fZ);
		glVertex3d(fRight, fBottom, fZ);
		glColor4f(0.f, 0.f, 0.f, 1.f);
		glVertex3d(fRight+0.1f, fBottom+0.1f, fZ+1.0f);

		// Right
		glColor4f(0.f, 0.f, 0.f, 1.f);
		glVertex3d(fLeft-0.1f, fTop-0.1f, fZ+1.0f);
		glVertex3d(fLeft-0.1f, fBottom+0.1f, fZ+1.0f);
		glColor4f(0.f, 0.f, 0.f, fDensity);
		glVertex3d(fLeft, fBottom, fZ);
		glVertex3d(fLeft, fTop, fZ);

		// Bottom
		glColor4f(0.f, 0.f, 0.f, 1.f);
		glVertex3d(fLeft-0.1f, fTop-0.1f, fZ+1.0f);
		glColor4f(0.f, 0.f, 0.f, fDensity);
		glVertex3d(fLeft, fTop, fZ);
		glVertex3d(fRight, fTop, fZ);
		glColor4f(0.f, 0.f, 0.f, 1.f);
		glVertex3d(fRight+0.1f, fTop-0.1f, fZ+1.0f);
	glEnd();

	_AS::CRenderer.AddTriangles(10);
	glEnable(GL_CULL_FACE);
}

/*
	Draws the main menu
*/
void TMenus::DrawMain()
{
	if (!m_fMainBlend) return;

	glLoadIdentity();
	glTranslatef(0.f, 0.f, -24.f * m_fMenuBlend - 10.f);
	glBlendFunc(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);
	glEnable(GL_BLEND);
	glDisable(GL_TEXTURE_2D);
	
	float fBackAni[4][2];
	int i, i2;

	for(i = 0; i < 4; i++)
		for(i2 = 0; i2 < 2; i2++)
			fBackAni[i][i2] = -fFontAni[i][i2] * 0.2f;

	// Menu background
	DrawBackground(10.f, -4.5f + fBackAni[0][0], -7.4f + fBackAni[1][1],
					   5.f + fBackAni[2][0], 1.5f + fBackAni[3][1],
					   1.5f - m_fMainBlend);
	// The info bar
	DrawBackground(10.f, -14.f, -9.f, 14.f, -12.f, 1.5f - m_fMainBlend);

	glColor4f(1.f, 1.f, 1.f, m_fMainBlend);
	int iMove = (int) ((1.f - m_fMainBlend) * 100.f);
	_AS::CRenderer.Print(510, 330, 0, GAMEVERSION);
	_AS::CRenderer.Print(0, 5 - iMove, 0, "    A game by AblazeSpace 2002            All rights reserved!");
	_AS::CRenderer.SetFontSize(1.5f);
	_AS::CRenderer.Print(400 - iMove, 300, 1, CText.Get(_T_MainMenu));
	_AS::CRenderer.SetFontSize();

	if (CGame.IsLevel()) {
		// Continue game
		SetMenuPointColor(pMP_MainMenu_ContinueGame, m_fMainBlend);
		_AS::CRenderer.Print(400 - iMove, 260, 1, CText.Get(_T_ContinueGame));
	}

	// Start game
	SetMenuPointColor(pMP_MainMenu_StartGame, m_fMainBlend);
	_AS::CRenderer.Print(400 - iMove, 240, 1, CText.Get(_T_StartGame));
	// Highscore
	SetMenuPointColor(pMP_MainMenu_Highscore, m_fMainBlend);
	_AS::CRenderer.Print(400 - iMove, 220, 1, CText.Get(_T_Highscore));
	// Options
	SetMenuPointColor(pMP_MainMenu_Options, m_fMainBlend);
	_AS::CRenderer.Print(400 - iMove, 200, 1, CText.Get(_T_Options));
	// Help
	SetMenuPointColor(pMP_MainMenu_Help, m_fMainBlend);
	_AS::CRenderer.Print(400 - iMove, 180, 1, CText.Get(_T_Help));
	// Credits
	SetMenuPointColor(pMP_MainMenu_Credits, m_fMainBlend);
	_AS::CRenderer.Print(400 - iMove, 160, 1, CText.Get(_T_Credits));
	// Quit
	SetMenuPointColor(pMP_MainMenu_Quit, m_fMainBlend);
	_AS::CRenderer.Print(400 - iMove, 140, 1, CText.Get(_T_Quit));
	_AS::CRenderer.SetFontSize();
}

/*
	Updates the main menu
*/
void TMenus::UpdateMain()
{	
	if (!m_bMainMenu) {
		m_fMainBlend -= _AS::CTimer.GetTimeDifference() * 2;
		if (m_fMainBlend < 0.f) m_fMainBlend = 0.f;
		m_fMenuTimer = 0.f;

		return;
	} else {
		m_fMainBlend += _AS::CTimer.GetTimeDifference() * 2;
		if (m_fMainBlend > 1.f) m_fMainBlend = 1.f;
	}

	m_fMenuTimer += _AS::CTimer.GetTimeDifference();
	if (m_fMenuTimer > 12.f) {
		if (rand() % 3) { // Open highscore
			m_bMainMenu	= false;
			m_pCHighscore->Open();
		} else { // Open credits
			m_bMainMenu	    = false;
			m_bCreditsMenu  = true;
			m_fCreditsTextY = 0.f;
		}
	}

	MenuPoint[m_iMenuPoint].bSelected = false;
	if (_AS::CInput.IsKeyHit(CControl.GetUpKey())) {
		m_iMenuPoint--;
		m_CChangeSound.Play();
		m_fFOV       = 44.f;
		m_fMenuTimer = 0.f;
	}
	if (_AS::CInput.IsKeyHit(CControl.GetDownKey())) {
		m_iMenuPoint++;
		m_CChangeSound.Play();
		m_fFOV = 44.f;
		m_fMenuTimer = 0.f;
	}

	// Check wrapping
	if (CGame.IsLevel()) {
		if (m_iMenuPoint < pMP_MainMenu_ContinueGame->iID) m_iMenuPoint = pMP_MainMenu_Quit->iID;
		if (m_iMenuPoint > pMP_MainMenu_Quit->iID)		   m_iMenuPoint = pMP_MainMenu_ContinueGame->iID;
	} else {
		if (m_iMenuPoint < pMP_MainMenu_StartGame->iID) m_iMenuPoint = pMP_MainMenu_Quit->iID;
		if (m_iMenuPoint > pMP_MainMenu_Quit->iID)		m_iMenuPoint = pMP_MainMenu_StartGame->iID;
	}

	MenuPoint[m_iMenuPoint].bSelected = true;

	if (_AS::CInput.IsKeyHit(CControl.GetJumpKey())) {
		m_fFOV = 46.f;
		_AS::CInput.Reset();
		m_CEnterSound.Play();
		if (pMP_MainMenu_ContinueGame->bSelected) {
			m_bMenuActive = false;
			m_bMainMenu   = false;
			_AS::CTimer.Pause(false);
		} else
		if (pMP_MainMenu_StartGame->bSelected) {
			m_bMenuActive = false;
			m_bMainMenu   = false;
			CGame.CreateNewLevel();
			_AS::CTimer.Pause(false);
		} else
		if (pMP_MainMenu_Highscore->bSelected) {
			m_bMainMenu	= false;
			m_pCHighscore->Open();
		} else
		if (pMP_MainMenu_Options->bSelected) {
			m_bMainMenu	   = false;
			m_bOptionsMenu = true;
			m_iMenuPoint   = pMP_Options_KeysSetup->iID;
		} else
		if (pMP_MainMenu_Help->bSelected) {
			_AS::CFileSystem.OpenHelp();
		} else
		if (pMP_MainMenu_Credits->bSelected) {
			m_bMainMenu	    = false;
			m_bCreditsMenu  = true;
			m_fCreditsTextY = 0.f;
		} else
		if (pMP_MainMenu_Quit->bSelected) {
			m_CLeaveSound.Play();
			_AS::ShutDown();
		}
	}
}

/*
	Draws the highscore menu
*/
void TMenus::DrawHighscore()
{
	if (!m_pCHighscore->GetBlending()) return;

	glLoadIdentity();
	glTranslatef(0.f, 0.f, -24.f * m_pCHighscore->GetBlending() - 10.f);
	glBlendFunc(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);
	glEnable(GL_BLEND);
	glDisable(GL_TEXTURE_2D);
	
	float fBackAni[4][2];
	int i, i2;

	for(i = 0; i < 4; i++)
		for(i2 = 0; i2 < 2; i2++)
			fBackAni[i][i2] = -fFontAni[i][i2] * 0.2f;

	// Menu background
	DrawBackground(10.f, -12.f + fBackAni[0][0], -9.f + fBackAni[1][1],
				   12.f + fBackAni[2][0], 2.f + fBackAni[3][1],
				   1.5f - m_pCHighscore->GetBlending());

	m_pCHighscore->Draw();
}

/*
	Draws the options menu
*/
void TMenus::DrawOptions()
{
	if (!m_fOptionsBlend) return;

	
	glLoadIdentity();
	glTranslatef(0.f, 0.f, -24.f * m_fOptionsBlend - 10.f);
	glBlendFunc(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);
	glEnable(GL_BLEND);
	glDisable(GL_TEXTURE_2D);
	
	float fBackAni[4][2];
	int i, i2;

	for(i = 0; i < 4; i++)
		for(i2 = 0; i2 < 2; i2++)
			fBackAni[i][i2] = -fFontAni[i][i2] * 0.2f;

	// Menu background
	DrawBackground(10.f, -5.f + fBackAni[0][0], -4.f + fBackAni[1][1],
				   5.f + fBackAni[2][0], 1.5f + fBackAni[3][1],
				   1.5f - m_fOptionsBlend);


	glColor4f(1.f, 1.f, 1.f, m_fOptionsBlend);
	int iMove = (int) ((1.f - m_fOptionsBlend) * 100.f);
	_AS::CRenderer.SetFontSize(1.5f);
	_AS::CRenderer.Print(400 - iMove, 300, 1, CText.Get(_T_Options));
	_AS::CRenderer.SetFontSize();

	// Keys setup
	SetMenuPointColor(pMP_Options_KeysSetup, m_fOptionsBlend);
	_AS::CRenderer.Print(400 - iMove, 260, 1, CText.Get(_T_Keys));
	// Game options
	SetMenuPointColor(pMP_Options_GameOptions, m_fOptionsBlend);
	_AS::CRenderer.Print(400 - iMove, 240, 1, CText.Get(_T_Game));
	// Engine options
	SetMenuPointColor(pMP_Options_EngineOptions, m_fOptionsBlend);
	_AS::CRenderer.Print(400 - iMove, 220, 1, CText.Get(_T_Engine));
	// Back
	SetMenuPointColor(pMP_Options_Back, m_fOptionsBlend);
	_AS::CRenderer.Print(400 - iMove, 190, 1, CText.Get(_T_Back));
	_AS::CRenderer.SetFontSize();
}

/*
	Updates the options menu
*/
void TMenus::UpdateOptions()
{
	if (!m_bOptionsMenu) {
		m_fOptionsBlend -= _AS::CTimer.GetTimeDifference() * 2;
		if (m_fOptionsBlend < 0.f) m_fOptionsBlend = 0.f;

		return;
	} else {
		m_fOptionsBlend += _AS::CTimer.GetTimeDifference() * 2;
		if (m_fOptionsBlend > 1.f) m_fOptionsBlend = 1.f;
	}

	MenuPoint[m_iMenuPoint].bSelected = false;
	if (_AS::CInput.IsKeyHit(CControl.GetUpKey())) {
		m_iMenuPoint--;
		m_CChangeSound.Play();
		m_fFOV = 44.f;
	}
	if (_AS::CInput.IsKeyHit(CControl.GetDownKey())) {
		m_iMenuPoint++;
		m_CChangeSound.Play();
		m_fFOV = 44.f;
	}

	// Check wrapping
	if (m_iMenuPoint < pMP_Options_KeysSetup->iID) m_iMenuPoint = pMP_Options_Back->iID;
	if (m_iMenuPoint > pMP_Options_Back->iID)	   m_iMenuPoint = pMP_Options_KeysSetup->iID;

	MenuPoint[m_iMenuPoint].bSelected = true;

	if (_AS::CInput.IsKeyHit(CControl.GetJumpKey())) {
		m_fFOV = 46.f;
		_AS::CInput.Reset();
		m_CEnterSound.Play();
		if (pMP_Options_KeysSetup->bSelected) {
			m_bOptionsMenu = false;
			m_bKeysMenu	   = true;
			m_iMenuPoint   = pMP_KeysSetup_Back->iID;
		} else
		if (pMP_Options_GameOptions->bSelected) {
			SendMessage(_AS::CWindowManager.GetMainWindow()->GetWnd(), WM_SYSCOMMAND, SC_MINIMIZE, 0);
			CConfig.OpenDialog(_AS::CWindowManager.GetMainWindow()->GetWnd());
			SendMessage(_AS::CWindowManager.GetMainWindow()->GetWnd(), WM_SIZE, SIZE_RESTORED, 0);
		} else
		if (pMP_Options_EngineOptions->bSelected) {
			SendMessage(_AS::CWindowManager.GetMainWindow()->GetWnd(), WM_SYSCOMMAND, SC_MINIMIZE, 0);
			_AS::CConfig.OpenDialog(_AS::CWindowManager.GetMainWindow()->GetWnd());
			SendMessage(_AS::CWindowManager.GetMainWindow()->GetWnd(), WM_SIZE, SIZE_RESTORED, 0);
		} else
		if (pMP_Options_Back->bSelected) {
			m_bOptionsMenu = false;
			m_bMainMenu	   = true;
			m_iMenuPoint   = pMP_MainMenu_Options->iID;
			m_CLeaveSound.Play();
		}
	}
}

/*
	Draws the menu
*/
void TMenus::DrawKeys()
{
	// Is the menu visible?
	if (!m_fKeysBlend) return;

	glLoadIdentity();
	glTranslatef(0.f, 0.f, -24.f * m_fKeysBlend - 10.f);
	glBlendFunc(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);
	glEnable(GL_BLEND);
	glDisable(GL_TEXTURE_2D);
	
	float fBackAni[4][2];
	int i, i2;

	for(i = 0; i < 4; i++)
		for(i2 = 0; i2 < 2; i2++)
			fBackAni[i][i2] = -fFontAni[i][i2] * 0.2f;

	// Menu background
	DrawBackground(10.f, -8.f + fBackAni[0][0], -9.f + fBackAni[1][1],
				   8.f + fBackAni[2][0], 1.5f + fBackAni[3][1],
				   1.5f - m_fKeysBlend);


	glColor4f(1.f, 1.f, 1.f, m_fKeysBlend);
	int iMove = (int) ((1.f - m_fKeysBlend) * 100.f);
	_AS::CRenderer.SetFontSize(1.5f);
	_AS::CRenderer.Print(400 - iMove, 300, 1, CText.Get(_T_Keys));
	_AS::CRenderer.SetFontSize();

	char szTemp[256];

	// Keys setup
	// Left
	SetMenuPointColor(pMP_KeysSetup_Left, m_fKeysBlend, CControl.GetLeftKey());
	_AS::CRenderer.Print(300 - iMove, 260, 1, CText.Get(_T_Left));
	_AS::CInput.GetKeyName(CControl.GetLeftKey(), szTemp);
	_AS::CRenderer.Print(500 - iMove, 260, 1, szTemp);
	// Right
	SetMenuPointColor(pMP_KeysSetup_Right, m_fKeysBlend, CControl.GetRightKey());
	_AS::CRenderer.Print(300 - iMove, 240, 1, CText.Get(_T_Right));
	_AS::CInput.GetKeyName(CControl.GetRightKey(), szTemp);
	_AS::CRenderer.Print(500 - iMove, 240, 1, szTemp);
	// Up
	SetMenuPointColor(pMP_KeysSetup_Up, m_fKeysBlend, CControl.GetUpKey());
	_AS::CRenderer.Print(300 - iMove, 220, 1, CText.Get(_T_Up));
	_AS::CInput.GetKeyName(CControl.GetUpKey(), szTemp);
	_AS::CRenderer.Print(500 - iMove, 220, 1, szTemp);
	// Down
	SetMenuPointColor(pMP_KeysSetup_Down, m_fKeysBlend, CControl.GetDownKey());
	_AS::CRenderer.Print(300 - iMove, 200, 1, CText.Get(_T_Down));
	_AS::CInput.GetKeyName(CControl.GetDownKey(), szTemp);
	_AS::CRenderer.Print(500 - iMove, 200, 1, szTemp);
	// Run
	SetMenuPointColor(pMP_KeysSetup_Run, m_fKeysBlend, CControl.GetRunKey());
	_AS::CRenderer.Print(300 - iMove, 180, 1, CText.Get(_T_Run));
	_AS::CInput.GetKeyName(CControl.GetRunKey(), szTemp);
	_AS::CRenderer.Print(500 - iMove, 180, 1, szTemp);
	// Jump
	SetMenuPointColor(pMP_KeysSetup_Jump, m_fKeysBlend, CControl.GetJumpKey());
	_AS::CRenderer.Print(300 - iMove, 160, 1, CText.Get(_T_Jump));
	_AS::CInput.GetKeyName(CControl.GetJumpKey(), szTemp);
	_AS::CRenderer.Print(500 - iMove, 160, 1, szTemp);
	// Attack
	SetMenuPointColor(pMP_KeysSetup_Attack, m_fKeysBlend, CControl.GetAttackKey());
	_AS::CRenderer.Print(300 - iMove, 140, 1, CText.Get(_T_Attack));
	_AS::CInput.GetKeyName(CControl.GetAttackKey(), szTemp);
	_AS::CRenderer.Print(500 - iMove, 140, 1, szTemp);
	// Pause
	SetMenuPointColor(pMP_KeysSetup_Pause, m_fKeysBlend, CControl.GetPauseKey());
	_AS::CRenderer.Print(300 - iMove, 120, 1, CText.Get(_T_Pause));
	_AS::CInput.GetKeyName(CControl.GetPauseKey(), szTemp);
	_AS::CRenderer.Print(500 - iMove, 120, 1, szTemp);
	// Standard configuration
	SetMenuPointColor(pMP_KeysSetup_StandardConfiguration, m_fKeysBlend);
	_AS::CRenderer.Print(400 - iMove, 80, 1, CText.Get(_T_Standard));
	// Back
	SetMenuPointColor(pMP_KeysSetup_Back, m_fKeysBlend);
	_AS::CRenderer.Print(400 - iMove, 60, 1, CText.Get(_T_Back));
	_AS::CRenderer.SetFontSize();

	// Press new key message
	if (m_bGetNewKey && (_AS::CTimer.GetPastTime() / 1000) % 2)
		_AS::CRenderer.Print(400 - iMove, 40, 1, CText.Get(_T_PressNewKey));
}

/*
	Updates the keys menu
*/
void TMenus::UpdateKeys()
{
	if (!m_bKeysMenu) {
		m_fKeysBlend -= _AS::CTimer.GetTimeDifference() * 2;
		if (m_fKeysBlend < 0.f) m_fKeysBlend = 0.f;

		return;
	} else {
		m_fKeysBlend += _AS::CTimer.GetTimeDifference() * 2;
		if (m_fKeysBlend > 1.f) m_fKeysBlend = 1.f;
	}

	MenuPoint[m_iMenuPoint].bSelected = false;
	if (_AS::CInput.IsKeyHit(CControl.GetUpKey())) {
		m_iMenuPoint--;
		m_CChangeSound.Play();
		m_fFOV = 44.f;
	}
	if (_AS::CInput.IsKeyHit(CControl.GetDownKey())) {
		m_iMenuPoint++;
		m_CChangeSound.Play();
		m_fFOV = 44.f;
	}

	// Check wrapping
	if (m_iMenuPoint < pMP_KeysSetup_Left->iID) m_iMenuPoint = pMP_KeysSetup_Back->iID;
	if (m_iMenuPoint > pMP_KeysSetup_Back->iID)	m_iMenuPoint = pMP_KeysSetup_Left->iID;

	MenuPoint[m_iMenuPoint].bSelected = true;

	if (!m_bGetNewKey) {
		if (_AS::CInput.IsKeyHit(CControl.GetJumpKey())) {
			m_fFOV = 46.f;
			_AS::CInput.Reset();
			m_CEnterSound.Play();
			if (pMP_KeysSetup_StandardConfiguration->bSelected) {
				CControl.Reset();
			} else
			if (pMP_KeysSetup_Back->bSelected) {
				m_bKeysMenu    = false;
				m_bOptionsMenu = true;
				m_iMenuPoint   = pMP_Options_KeysSetup->iID;
				m_CLeaveSound.Play();
			} else {
				m_bGetNewKey = true;
			}
		}
	} else {
		int iKey;

		if (_AS::CInput.IsKeyHit(DIK_ESCAPE)) {
			m_CLeaveSound.Play();
			m_bGetNewKey = false;

			return;
		}

		// Get the pressed key
		if ((iKey = _AS::CInput.IsKeyHit()) < 0) return;
		m_bGetNewKey = false;

		// Set the new key
		if (pMP_KeysSetup_Left->bSelected) CControl.SetLeftKey(iKey);
		else
		if (pMP_KeysSetup_Right->bSelected) CControl.SetRightKey(iKey);
		else
		if (pMP_KeysSetup_Up->bSelected) CControl.SetUpKey(iKey);
		else
		if (pMP_KeysSetup_Down->bSelected) CControl.SetDownKey(iKey);
		else
		if (pMP_KeysSetup_Run->bSelected) CControl.SetRunKey(iKey);
		else
		if (pMP_KeysSetup_Jump->bSelected) CControl.SetJumpKey(iKey);
		else
		if (pMP_KeysSetup_Attack->bSelected) CControl.SetAttackKey(iKey);
		else
		if (pMP_KeysSetup_Pause->bSelected) CControl.SetPauseKey(iKey);
	}
}

/*
	Draws the credits menu
*/
void TMenus::DrawCredits()
{
	// Is the menu visible?
	if (!m_fCreditsBlend) return;

	glLoadIdentity();
	glTranslatef(0.f, 0.f, -24.f * m_fCreditsBlend - 10.f);
	glBlendFunc(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);
	glEnable(GL_BLEND);
	glDisable(GL_TEXTURE_2D);
	
	float fBackAni[4][2];
	int i, i2, iY;

	for(i = 0; i < 4; i++)
		for(i2 = 0; i2 < 2; i2++)
			fBackAni[i][i2] = -fFontAni[i][i2] * 0.2f;

	// Menu background
	DrawBackground(10.f, -12.f + fBackAni[0][0], -9.f + fBackAni[1][1],
				   0.f + fBackAni[2][0], 2.5f + fBackAni[3][1],
				   1.5f - m_fCreditsBlend);

	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	glColor4f(1.f, 1.f, 1.f, m_fCreditsBlend);
	for(i = 0; i < 4; i++)
		for(i2 = 0; i2 < 2; i2++)
			fBackAni[i][i2] = -fFontAni[i][i2]*0.5f;
	for (i = 0, iY = (int) m_fCreditsTextY; i < m_iCreditsTexts; i++, iY -= 25) {
		if(m_pszCreditsText[i][0] == '[' &&
		   m_pszCreditsText[i][1] == '-' &&
		   m_pszCreditsText[i][2] == 't') { // Draw a texture
			i2 = atoi(&m_pszCreditsText[i][3]);
			if (i2 < 0 || i2 >= m_iCreditsTextures) continue;
			ASTTexture* pCTexture = _AS::CTextureManager.GetTexture(m_pszCreditsTexture[i2]);
			if (!pCTexture) continue;

			glMatrixMode(GL_PROJECTION);
			glPushMatrix();
			glLoadIdentity();
			glEnable(GL_BLEND);
			glOrtho(0, 800, 0, 600, -100, 100);
			glMatrixMode(GL_MODELVIEW);
			glDisable(GL_CULL_FACE);
			glPushMatrix();
			glLoadIdentity();
			glTranslated(200, iY - 50, 0);
			pCTexture->BindOpenGLTexture();
			glBegin(GL_QUADS);
				glTexCoord2f(0.f, 0.f); glVertex2f(-70.f, -70.f);
				glTexCoord2f(1.f, 0.f); glVertex2f( 70.f, -70.f);
				glTexCoord2f(1.f, 1.f); glVertex2f( 70.f,  70.f);
				glTexCoord2f(0.f, 1.f); glVertex2f(-70.f,  70.f);
			glEnd();
			glEnable(GL_CULL_FACE);
			glMatrixMode(GL_PROJECTION);
			glPopMatrix();
			glMatrixMode(GL_MODELVIEW);
			glPopMatrix();
			glDisable(GL_ALPHA_TEST);
			glEnable(GL_BLEND);

			iY -= 120;
		} else _AS::CRenderer.Print(200, iY, 1, m_pszCreditsText[i]);
	}
	m_iWholeCreditsTextY = iY - ((int) m_fCreditsTextY);

	// Draw url
	glLoadIdentity();
	glColor4f(1.f, 1.f, 1.f, 0.f);
	m_CUrlModel.UpdateVisibility(true);
	m_CUrlModel.Draw(true, false);
}

/*
	Updates the credits menu
*/
void TMenus::UpdateCredits()
{
	if (!m_bCreditsMenu && m_fCreditsBlend || m_bCreditsMenu) {
		m_fCreditsTextY += _AS::CTimer.GetTimeDifference() * 50;
		if(m_fCreditsTextY >= -m_iWholeCreditsTextY + 430) {
			m_fLogosPercentage = 0.f;
			m_fLogoWait		   = 0.f;
			m_fNextLogoWait	   = 0.25;
			m_bFastLogos	   = false;
			m_bCreditsMenu     = false;
			m_bMainMenu	       = true;
			m_fCreditsBlend	   = 0.f;
			m_fMenuBlend	   = 0.01f;
			m_fTitleTimer	   = 0.f;
			m_fTitleIn    	   = 0.f;
			InitTitle();

			return;
		}

		// Update url
		m_CUrlModel.Animate();

		ASTEntity* pCEntity = m_CUrlEntity.GetEntity();
		if (pCEntity) {
			pCEntity->SetPos(12.5f - 9 * m_fCreditsBlend, -3.f, -15.f);
			pCEntity->SetRot(-40.f, 70.f + m_fCreditsTextY / 2, 0.f);
		}
	}

	if (!m_bCreditsMenu) {
		m_fCreditsBlend -= _AS::CTimer.GetTimeDifference();
		if (m_fCreditsBlend < 0.f) m_fCreditsBlend = 0.f;

		return;
	} else {
		m_fCreditsBlend += _AS::CTimer.GetTimeDifference();
		if (m_fCreditsBlend > 1.f) m_fCreditsBlend = 1.f;
	}

	if (_AS::CInput.IsKeyHit() >= 0) {
		m_bMainMenu	   = true;
		m_bCreditsMenu = false;
		m_CLeaveSound.Play();
	}
}

/*
	Initializes the title
*/
void TMenus::InitTitle()
{
	int iX, iY;

	// Setup the grid
	for (iY = 0; iY < TITEL_GRID_Y_SIZE; iY++) {
		for (iX = 0; iX < TITEL_GRID_X_SIZE; iX++) { // Set the coordinates
			m_fTitelGridTexture[iX + iY * TITEL_GRID_X_SIZE][X] = (float) iX / (TITEL_GRID_X_SIZE - 2);
			m_fTitelGridTexture[iX + iY * TITEL_GRID_X_SIZE][Y] = 1 - ((float) iY / (TITEL_GRID_Y_SIZE - 1));

			m_fTitelGridPoint[iX + iY * TITEL_GRID_X_SIZE][X] = (float) iX * 1.3f;
			m_fTitelGridPoint[iX + iY * TITEL_GRID_X_SIZE][Y] = (float) iY / 1.5f;
			m_fTitelGridPoint[iX + iY * TITEL_GRID_X_SIZE][Z] = (float) (0.2f * ASSin((float) iX + m_fTitleTimer)+
																		 0.2f * ASSin((float) iY + m_fTitleTimer));
		}
	}
	UpdateTitle();
}

/*
	Draws the title
*/
void TMenus::DrawTitle()
{
	int iX, iY;
	
	// Draw the grid
	glLoadIdentity();
	glRotatef(180.f, 0.f, 0.f, 1.f);
	glTranslatef(12.f, -9.f, -25.f);
	glRotatef(180.f, 0.f, 1.f, 0.f);
	glDisable(GL_CULL_FACE);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_FOG);
	glDisable(GL_LIGHTING);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	glDisable(GL_BLEND);
	glEnable(GL_TEXTURE_2D);
	glColor3f(1.f, 1.f, 1.f);
	m_CTitleTexture.GetTexture()->BindOpenGLTexture();
	
	glDisableClientState(GL_NORMAL_ARRAY);
	glDisableClientState(GL_COLOR_ARRAY);

	
	glEnableClientState(GL_VERTEX_ARRAY);
	glEnableClientState(GL_TEXTURE_COORD_ARRAY);
	glVertexPointer(3,   GL_FLOAT, 0, m_fTitelGridPoint);
	glTexCoordPointer(2, GL_FLOAT, 0, m_fTitelGridTexture);

	glBegin(GL_TRIANGLES);
		for (iY = 0; iY < TITEL_GRID_Y_SIZE-1; iY++) {
			for (iX = 1; iX < TITEL_GRID_X_SIZE-1; iX++) {
				// Draw the first triangle of the quad
				glArrayElement((iX - 1) + iY * TITEL_GRID_X_SIZE);
				glArrayElement(iX + iY * TITEL_GRID_X_SIZE);
				glArrayElement(iX + (iY + 1) * TITEL_GRID_X_SIZE);

				// Draw the second triangle of the quad
				glArrayElement(iX + (iY + 1) * TITEL_GRID_X_SIZE);
				glArrayElement((iX - 1) + (iY + 1) * TITEL_GRID_X_SIZE);
				glArrayElement((iX - 1) + iY * TITEL_GRID_X_SIZE);
			}
		}
	glEnd();
	_AS::CRenderer.AddTriangles(TITEL_GRID_X_SIZE * TITEL_GRID_Y_SIZE * 2);

	glDisableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);
}

/*
	Updates the title
*/
void TMenus::UpdateTitle()
{
	int iX, iY;

	// Update timer
	m_fTitleTimer += (float) _AS::CTimer.GetTimeDifference() * 2;
	m_fTitleIn    += (float) _AS::CTimer.GetTimeDifference() / 2;
	if (m_fTitleIn > 1.f) m_fTitleIn = 1.f;

	// Setup the grid
	float fTitle = 0.5f - 0.5f * ASCos((float) (ASSin((float) (m_fTitleIn * AS_PI_2)) * AS_PI));
	for(iY = 0; iY < TITEL_GRID_Y_SIZE; iY++) {
		for(iX = 0; iX < TITEL_GRID_X_SIZE; iX++) { // Set the z coordinate
			m_fTitelGridPoint[iX + iY * TITEL_GRID_X_SIZE][X] = (float) iX * 1.3f + (300 - iX * iX * iX * fTitle) * (1.f - fTitle);
			m_fTitelGridPoint[iX + iY * TITEL_GRID_X_SIZE][Y] = (float) iY * fTitle / 1.5f + (10 * (iY * iY * fTitle)) * (1.f - fTitle);
			m_fTitelGridPoint[iX + iY * TITEL_GRID_X_SIZE][Z] = (float) (0.2f * ASSin((float) iX + m_fTitleTimer)+
																	     0.2f * ASSin((float) iY + m_fTitleTimer));
		}
	}
}

/*
	Initializes all menu points
*/
void TMenus::InitMenuPoints()
{
	TMenuPoint* pMPT;
	int i, i2;
	
	for (i = 0; i < MENU_POINTS; i++) {
		pMPT = &MenuPoint[i];
		pMPT->iID = i;
		pMPT->fSize = 1.f;
		for (i2 = 0; i2 < 3; i2++) pMPT->fColor[i2] = 1.f;
	}
}

/*
	Updates all menu points
*/
void TMenus::UpdateMenuPoints()
{
	float fTimeDiff  = _AS::CTimer.GetTimeDifference();
	float fTimeDiff2 = _AS::CTimer.GetTimeDifference() * 5;
	TMenuPoint *pMPT;

	for (int i = 0; i < MENU_POINTS; i++) {
		pMPT = &MenuPoint[i];
		if (pMPT->bSelected) {
			if (pMPT->fColor[R] > 0.f) {
				pMPT->fColor[R] -= fTimeDiff2;
				if (pMPT->fColor[R] < 0.f) pMPT->fColor[R] = 0.f;
			}
			if (pMPT->fColor[G] < 1.f) {
				pMPT->fColor[G] += fTimeDiff2;
				if (pMPT->fColor[G] > 1.f) pMPT->fColor[G] = 1.f;
			}
			if (pMPT->fColor[B] > 0.f) {
				pMPT->fColor[B] -= fTimeDiff2;
				if (pMPT->fColor[B] < 0.f) pMPT->fColor[B] = 0.f;
			}
			if (!pMPT->bSize) {
				pMPT->fSize += fTimeDiff;
				if (pMPT->fSize > 1.2f) {
					pMPT->fSize = 1.2f;
					pMPT->bSize = true;
				}
			} else {
				pMPT->fSize -= fTimeDiff;
				if (pMPT->fSize < 0.8f) {
					pMPT->fSize = 0.8f;
					pMPT->bSize = false;
				}
			}
		} else {
			if (pMPT->fColor[R] < 1.f) {
				pMPT->fColor[R] += fTimeDiff2;
				if (pMPT->fColor[R] > 1.f) pMPT->fColor[R] = 1.f;
			}
			if (pMPT->fColor[G] < 1.f) {
				pMPT->fColor[G] += fTimeDiff2;
				if (pMPT->fColor[G] > 1.f) pMPT->fColor[G] = 1.f;
			}
			if (pMPT->fColor[B] < 1.f) {
				pMPT->fColor[B] += fTimeDiff2;
				if (pMPT->fColor[B] > 1.f) pMPT->fColor[B] = 1.f;
			}
			if (pMPT->fSize > 1.f) {
				pMPT->fSize -= fTimeDiff;
				if (pMPT->fSize < 1.f) pMPT->fSize = 1.f;
			}
			if (pMPT->fSize < 1.f) {
				pMPT->fSize += fTimeDiff;
				if(pMPT->fSize > 1.f) pMPT->fSize = 1.f;
			}
		}
		pMPT->bSelected = false;
	}
}

/*
	Sets the color of a menu point
*/
void TMenus::SetMenuPointColor(TMenuPoint* pMenuPointT, float fBlend, int iKeyCode)
{
	if (iKeyCode == -1 || CControl.EnumerateKeyUsage(iKeyCode) <= 1 || ((_AS::CTimer.GetPastTime() / 500) % 2))
		glColor4f(pMenuPointT->fColor[R], pMenuPointT->fColor[G], pMenuPointT->fColor[B], fBlend);
	else {
		glColor4f(1.f, 0.f, 0.f, fBlend);
		pMenuPointT->fColor[R] += _AS::CTimer.GetTimeDifference();
	}
	_AS::CRenderer.SetFontSize(pMenuPointT->fSize);
}
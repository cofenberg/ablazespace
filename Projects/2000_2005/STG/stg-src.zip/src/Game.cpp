/*
	File: Game.cpp
*/

#include <ASEngine.h>
#include "Game.h"
#include "resource.h"


// Variables
TGame CGame;
float fLightTimer;

// For the animated font in the main menu:
float fFontAni[4][2]; // The current vertex position
float fFontAniLast[4][2]; // The last vertex position
float fFontAniT[4][2]; // The vertex target position
float fFontAniV[4][2]; // The vertex velocity


/*
	Window message function
*/
long WindowProcedure(HWND hWnd, unsigned uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg) {
        case WM_COMMAND:
            switch (LOWORD(wParam)) {
			// General
				case ID_GENERAL_QUIT: _AS::ShutDown(); break;

			// Options
				case ID_OPTIONS_CONFIG:  _AS::CConfig.OpenDialog(hWnd); break;
				case ID_OPTIONS_OPENLOG: _AS::CLog.Open(); break;

			// Help
				case ID_HELP_HELP:    _AS::CFileSystem.OpenHelp(); break;
				case ID_HELP_CREDITS: CConfig.OpenCreditsDialog(hWnd); break;
				
			// Homepages
				case ID_ABLAZESPACE_HOMEPAGE:	  _AS::CFileSystem.Open("http://www.ablazespace.de"); break;
				case ID_3DIMENSIONEN_HOMEPAGE:	  _AS::CFileSystem.Open("http://www.3dimensionen.de"); break;
				case ID_TOXEEN_HOMEPAGE:		  _AS::CFileSystem.Open("http://www.toxeen.de"); break;
				case ID_SOFTGAMES_HOMEPAGE:	      _AS::CFileSystem.Open("http://www.softgames.de"); break;
				case ID_HAPPYGRAFIX_HOMEPAGE:	  _AS::CFileSystem.Open("http://www.happy-grafix.de"); break;
				case ID_SECONDEVOLUTION_HOMEPAGE: _AS::CFileSystem.Open("http://www.second-evolution.de"); break;
			}
		break;
    }

    return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

/*
	Initializes the game
*/
void TGame::Init()
{
	ASTLight* pCAmbientLight;
	ASTLight* pCDiffuseLight;

	// Setup draw & update functions
	_AS::CWindowManager.GetMainWindow()->SetCustomFunctions(GameDraw, GameUpdate, WindowProcedure);

	// Add renderer 
	_AS::CRenderer.AddCustomInitFunction(GameRendererInit);
	_AS::CRenderer.AddCustomDeInitFunction(GameRendererDeInit);

	pCLevel = NULL;

	// Camera
	ASCreateEntity(m_pCCamera, TEntityCamera, "Camera");
	m_pCCamera->SetProtected(true);
	m_pCCamera->SetPos(20.f, -35.f, -50.f);
	m_pCCamera->SetRot(-120, 0, 180);
	m_pCCamera->SetFlags(ASeCameraFlagFree);
//	((ASTEntity*) m_pCCamera)->SetFlags(ASeEntityFlagDebug);
	m_pCCamera->SetFlags(ASeCameraFlagThirdPersonFlag);


	// Ambient light
	ASCreateEntity(pCAmbientLight, ASTLight, "Ambient light");
	pCAmbientLight->SetFlags(ASELightFlagAmbient | ASeLightFlagOpenGL | ASeLightFlagCelShading);
	pCAmbientLight->SetProtected(true);
	pCAmbientLight->SetPos(0.f, 0.f, -50.f);
	pCAmbientLight->SetBrightness(0.4f);

	// Diffuse light
	ASCreateEntity(pCDiffuseLight, ASTLight, "Diffuse light");
	pCDiffuseLight->SetFlags(ASELightFlagDiffuse | ASeLightFlagOpenGL | ASeLightFlagCelShading);
	pCDiffuseLight->SetProtected(true);
	pCDiffuseLight->SetPos(0.f, 0.f, -50.f);
	pCDiffuseLight->SetBrightness(0.5f);
	pCDiffuseLight->SetCoronaSize(20.f);
	pCDiffuseLight->SetFlareSize(5.f);
	m_CLightEntity.Load(pCDiffuseLight);

	// Load textures
	m_CGameOverTexture.Load("gameover.tga");
	m_CGameWonTexture.Load("gamewon.tga");

	// Load music
	m_CMusic.Load("Toxeen - Softgames the Game - Adventure Island.mp3");
	m_CMusic.SetVolume(0.f);

	// Load sounds
	m_CGameOverSound.Load("gameover.mp3");
	m_CGameWonSound.Load("gamewon.mp3");
	
	// Initialize menu
	CMenus.Init();
}

/*
	De-initializes the game
*/
void TGame::DeInit()
{
	m_CLightEntity.Unload();

	// De-initialize the menus
	CMenus.DeInit();

	// Unload textures
	m_CGameOverTexture.Unload();
	m_CGameWonTexture.Unload();

	// Unload music
	m_CMusic.Unload();
	
	// Unload sounds
	m_CGameOverSound.Unload();
	m_CGameWonSound.Unload();

	// Setup draw & update functions
	_AS::CWindowManager.GetMainWindow()->SetCustomFunctions(NULL, NULL);

	// Remove renderer 
	_AS::CRenderer.RemoveCustomInitFunction(GameRendererInit);
	_AS::CRenderer.RemoveCustomDeInitFunction(GameRendererDeInit);

	// Destroy level
	DestroyLevel();

	// Clear entity manager
	_AS::CEntityManager.Clear(true);
}

/*
	Creates a new level
*/
void TGame::CreateNewLevel()
{
	// Destroy old level
	DestroyLevel();

	// Create new level
	pCLevel = new TLevel;
	_AS::CPhysics.SetGravity(ASTVector3D(0.f, 0.f, 5.f));
	m_fPlayTime = 0.f;
}

/*
	Destroys the level
*/
void TGame::DestroyLevel()
{
	if (!pCLevel) return;

	delete pCLevel;
	pCLevel = NULL;
	m_bGameOver = false;
	m_bGameWon  = false;
}

/*
	Returns if there's a level
*/
bool TGame::IsLevel() const
{
	if (pCLevel) return true;
	else		 return false;
}

/*
	Game over
*/
void TGame::GameOver()
{
	m_bGameOver = true;
	m_CGameOverSound.Play();
}

/*
	Game won
*/
void TGame::GameWon()
{
	m_bGameWon = true;
	m_CGameWonSound.Play();
	if (pCUrlActor) {
		pCUrlActor->IncScore(pCUrlActor->GetLives() * 200);
		pCUrlActor->IncScore((int) (pCLevel->fTime * 10));
		pCUrlActor->IncScore(500);
	}
}

/*
	Returns the play timer
*/
float TGame::GetPlayTimer() const
{
	return m_fPlayTime;
}

/*
	Game renderer initialization function
*/
void TGame::GameRendererInit()
{
	CGame.RendererInit();
}

void TGame::RendererInit()
{
	_AS::CLog.Output("Create game display lists");

	if (pCLevel) pCLevel->RendererInit();
}

/*
	Game renderer de-initialization function
*/
void TGame::GameRendererDeInit()
{
	CGame.RendererDeInit();
}

void TGame::RendererDeInit()
{
	_AS::CLog.Output("Delete game display lists");

	if (pCLevel) pCLevel->RendererDeInit();
}

/*
	Game draw function
*/
bool TGame::GameDraw(ASTWindow* pCWindow)
{
	return CGame.Draw(pCWindow);
}

bool TGame::Draw(ASTWindow* pCWindow)
{
	_AS::CRenderer.SetFontDistortion(true);
	_AS::CRenderer.SetFontDistortion(fFontAni);

	glCullFace(GL_FRONT);
	glDisable(GL_BLEND);
	glDisable(GL_LIGHTING);

	// Draw the menus
	if (CMenus.Draw()) return false;

	glClear(GL_DEPTH_BUFFER_BIT);

	// Is there a level?
	if (!pCLevel) return false;

	// Draw the level
	m_pCCamera->Set(false);
	pCLevel->CEnvironment.Draw();

	// Place the camera
	_AS::CRenderer.SetCamera(m_pCCamera);
	m_pCCamera->Set();

	pCLevel->Draw();

	// Draw all entities
	glDisable(GL_LIGHTING);
	_AS::CEntityManager.DrawSolid();
	_AS::CEntityManager.DrawTransparent();

	glColor3f(1.f, 1.f, 1.f);
	


	// Draw the hud
	int iWidth, iHeight;

	iWidth  = _AS::CWindowManager.GetMainWindow()->GetWidth();
	iHeight = _AS::CWindowManager.GetMainWindow()->GetHeight();
	_AS::CRenderer.SetCamera();

	glClear(GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glViewport(0, 0, iWidth, iHeight);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.f, (float) iWidth / (float) iHeight, 0.1f, 1000.f);
	glMatrixMode(GL_MODELVIEW);
	if (CGame.pCUrlActor) CGame.pCUrlActor->DrawHud();
	_AS::CRenderer.SetCamera(m_pCCamera);

	// Draw game over text
	glColor3f(1.f, 1.f, 1.f);
	if (m_bGameOver || m_bGameWon) {
		if (_AS::CRenderer.GetRendererHandler() && _AS::CRenderer.GetRendererHandler()->IsInitialized()) {
			int iWidth, iHeight;
			RECT Rect;

			// Get window size	
			GetWindowRect(_AS::CRenderer.GetRendererHandler()->GetWnd(), &Rect);
			iWidth  = Rect.right  - Rect.left;
			iHeight = Rect.bottom - Rect.top;

			// Reset the scene
			glMatrixMode(GL_MODELVIEW);
			glLoadIdentity();
			glViewport(0, 0, iWidth, iHeight);
			glMatrixMode(GL_PROJECTION);
			glLoadIdentity();
			gluPerspective(45.f, (float) iWidth / (float) iHeight, 0.1f, 100.f);
			glMatrixMode(GL_MODELVIEW);
		}

		glClear(GL_DEPTH_BUFFER_BIT);
		glDisable(GL_DEPTH_TEST);
		glDisable(GL_CULL_FACE);
		glLoadIdentity();
		glTranslatef(0.f, 0.f, -24.f);
		glBlendFunc(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);
		glColor4f(0.f, 0.f, 0.f, 0.2f);
		glBegin(GL_QUADS);
			glVertex2f(-15.f, -12.f);
			glVertex2f( 15.f, -12.f);
			glVertex2f( 15.f,  12.f);
			glVertex2f(-15.f,  12.f);
		glEnd();
		_AS::CRenderer.AddTriangles(2);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);
		glEnable(GL_TEXTURE_2D);
		glDisable(GL_BLEND);
		if (m_bGameOver) m_CGameOverTexture.GetTexture()->BindOpenGLTexture();
		else			  m_CGameWonTexture.GetTexture()->BindOpenGLTexture();
		glColor3f(1.f, 1.f, 1.f);
		glBegin(GL_QUADS);
			glTexCoord2f(0.f, 0.f); glVertex2f(-9.f, -4.f);
			glTexCoord2f(1.f, 0.f); glVertex2f( 9.f, -4.f);
			glTexCoord2f(1.f, 1.f); glVertex2f( 9.f,  4.f);
			glTexCoord2f(0.f, 1.f); glVertex2f(-9.f,  4.f);
		glEnd();
		_AS::CRenderer.AddTriangles(2);
		glEnable(GL_CULL_FACE);
		if ((_AS::CTimer.GetPastTime() / 1000) % 2) {
			_AS::CRenderer.SetFontSize(1.5f);
			_AS::CRenderer.Print(400, 150, 1, CText.Get(_T_PressAnyKeyToContinue));
			_AS::CRenderer.SetFontSize();
		}
	} else {
		// Draw pause text
		if (_AS::CTimer.IsPaused() && ((_AS::CTimer.GetPastTime() / 1000) % 2))
			_AS::CRenderer.Print(400, 300, 1, CText.Get(_T_Pause));

		if (!bCheatNoTimeLimit) {
			_AS::CRenderer.SetFontSize(1.5f);
			if (pCLevel->fTime < 5.f && ((_AS::CTimer.GetPastTime() / 300) % 2))
				glColor3f(1.f, 0.f, 0.f);
			else
				glColor3f(1.f, 1.f, 1.f);
			_AS::CRenderer.Print(400, 5, 1, "%.0f", pCLevel->fTime);
			_AS::CRenderer.SetFontSize();
		}
	}


	return false;
}

/*
	Game update function
*/
bool TGame::GameUpdate(ASTWindow* pCWindow)
{
	return CGame.Update(pCWindow);
}

bool TGame::Update(ASTWindow* pCWindow)
{
	int i, i2;

	for (i = 0; i < 4; i++)
		for (i2 = 0; i2 < 2; i2++) {
			fFontAni[i][i2] += fFontAniV[i][i2]*_AS::CTimer.GetTimeDifference() * 2;
			if (fFontAniLast[i][i2] >= fFontAniT[i][i2]) {
				fFontAniV[i][i2] -= _AS::CTimer.GetTimeDifference() * 2;
				if(fFontAniV[i][i2] < -1.2f)
					fFontAniV[i][i2] = -1.2f;
				if(fFontAni[i][i2] <= fFontAniT[i][i2])
				{
					fFontAniLast[i][i2] = fFontAni[i][i2];
					if(!(rand() % 2))
						fFontAniT[i][i2] = ((float) (rand() % 10)/8);
					else
						fFontAniT[i][i2] = -((float) (rand() % 10)/8);
				}
			}
			if(fFontAniLast[i][i2] < fFontAniT[i][i2])
			{
				fFontAniV[i][i2] += _AS::CTimer.GetTimeDifference() * 2;
				if(fFontAniV[i][i2] > 1.2f)
					fFontAniV[i][i2] = 1.2f;
				if(fFontAni[i][i2] >= fFontAniT[i][i2])
				{
					fFontAniLast[i][i2] = fFontAni[i][i2];
					if(!(rand() % 2))
						fFontAniT[i][i2] = ((float) (rand() % 10)/8);
					else
						fFontAniT[i][i2] = -((float) (rand() % 10)/8);
				}
			}
		}

	// Shut down the game?
	if (_AS::IsShutDown()) CGame.DeInit();

	// Update configuration
	CConfig.Update();

	// Check screenshot taking
	if (_AS::CInput.IsKeyHit(ASPRINTKEY)) _AS::CRenderer.TakeScreenshot();

	// Update the menus
	if (!CMenus.IsLogos() && IsLevel()) {
		if (!m_CMusic.IsPlaying()) m_CMusic.Play();
		m_CMusic.SetVolume(1 - CMenus.GetBlending());
	} else m_CMusic.Stop();
	if (CMenus.Update()) return false;
	
	// Game over
	if (m_bGameOver) {
		_AS::CTimer.Pause();
		if (_AS::CInput.IsKeyHit() >= 0) {
			if (CGame.pCUrlActor) CMenus.EnterHighscore(CGame.pCUrlActor->GetScore());
			else				  CMenus.EnterHighscore();
		}

		return false;
	}
	// Game won
	if (m_bGameWon) {
		_AS::CTimer.Pause();
		if (_AS::CInput.IsKeyHit() >= 0) {
			if (CGame.pCUrlActor) CMenus.EnterHighscore(CGame.pCUrlActor->GetScore(), true);
			else				  CMenus.EnterHighscore(0, true);
		}

		return false;
	}

	// Is there a level?
	if (!pCLevel) return false;

	// Check keys
	if (_AS::CInput.IsKeyHit(CControl.GetPauseKey())) _AS::CTimer.Pause(!_AS::CTimer.IsPaused());
	if (_AS::CInput.IsKeyHit(DIK_ESCAPE)) {
		CMenus.Activate();

		return false;
	}

	// Check if the camera mode should be chanded (Strg-c)
	if (_AS::CConfig.IsDebugMode() && _AS::CInput.IsKeyHit(DIK_C) && _AS::CInput.IsKeyPressed(29) && m_pCCamera) {
		if (m_pCCamera->GetFlags() & ASeCameraFlagFree)
			m_pCCamera->SetFlags(ASeCameraFlagThirdPersonFlag);
		else m_pCCamera->SetFlags(ASeCameraFlagFree);
	}

	// Set the cameras target entity
	if (!m_pCCamera->GetTarget()) m_pCCamera->SetTarget(CGame.pCUrlActor);

	if (!_AS::CTimer.IsPaused()) { // Update light
		ASTLight* pCLight = (ASTLight*) m_CLightEntity.GetEntity();
		if (pCLight) {
			pCLight->SetPos(ASCos(fLightTimer)*100, ASCos(fLightTimer)*100+4, -30-ASSin(fLightTimer)*20);
			fLightTimer += _AS::CTimer.GetTimeDifference()/10;
		}
	}

	// Update play timer
	if (!_AS::CTimer.IsPaused()) m_fPlayTime += _AS::CTimer.GetTimeDifference();

	// Update the level
	pCLevel->Update();

	return false;
}
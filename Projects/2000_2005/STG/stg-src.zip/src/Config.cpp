/*
	File: Config.cpp
*/

#include <ASEngine.h>
#include "Config.h"


// Variables
TConfig CConfig;


/*
	Initialize the configuration
*/
bool TConfig::Init()
{
	m_bLoaded = false;

	return Load();
}

/*
	Load configuration
*/
bool TConfig::Load(const char* pszFilename)
{
	char szTemp[256];

	// Check pointer
	if (!pszFilename) return true;

	// Save the preview configuration
	if (m_bLoaded) Save(m_szFilename);

	// Setup filename information
	strcpy(m_szFilename, pszFilename);
	_AS::CFileSystem.GetFullFilename(m_szFilename, ASCONFIG_FILE);
	_AS::CLog.Output("Load configuration '%s'", m_szFilename);

	// Load the configurations
	// Graphic
	GetPrivateProfileString("graphic", "level_detail", "1", szTemp, 256, m_szFilename);
	m_fLevelDetail = (float) atof(szTemp);
	GetPrivateProfileString("graphic", "plants",	   "1", szTemp, 256, m_szFilename);
	m_fPlants	   = (float) atof(szTemp);

	// Debug configurations
	if (_AS::CConfig.IsDebugMode()) {
		m_bShowQuadtrees = GetPrivateProfileInt("debug", "showquadtrees",  0, m_szFilename) != 0;
		m_bShowVertices  = GetPrivateProfileInt("debug", "showvertices",  0, m_szFilename) != 0;
		m_bShowNormals   = GetPrivateProfileInt("debug", "shownormals",   0, m_szFilename) != 0;
	}

	m_bLoaded = true;
	Check();

	return false;
}

/*
	Save configuration
*/
bool TConfig::Save(const char* pszFilename)
{
	// Check pointer
	if (!pszFilename) return true;

	// Setup filename information
	strcpy(m_szFilename, pszFilename);
	_AS::CFileSystem.GetFullFilename(m_szFilename, ASCONFIG_FILE);
	_AS::CLog.Output("Save configuration '%s'", m_szFilename);

	// Save the configurations
	// Graphic
	_AS::CFileSystem.WritePrivateProfileEString("graphic", "level_detail",  m_szFilename, "%.2f", m_fLevelDetail);
	_AS::CFileSystem.WritePrivateProfileEString("graphic", "plants",		m_szFilename, "%.2f", m_fPlants);

	// Debug
	if (_AS::CConfig.IsDebugMode()) {
		_AS::CFileSystem.WritePrivateProfileEString("debug", "showquadtrees", m_szFilename, "%d", m_bShowQuadtrees);
		_AS::CFileSystem.WritePrivateProfileEString("debug", "showvertices",  m_szFilename, "%d", m_bShowVertices);
		_AS::CFileSystem.WritePrivateProfileEString("debug", "shownormals",   m_szFilename, "%d", m_bShowNormals);
	}

	return false;
}

/*
	Check if the configurations are valid
*/
bool TConfig::Check()
{
	if (m_fLevelDetail < 0.f) m_fLevelDetail = 0.f;
	if (m_fLevelDetail > 1.f) m_fLevelDetail = 1.f;
	if (m_fPlants < 0.f) m_fPlants = 0.f;
	if (m_fPlants > 1.f) m_fPlants = 1.f;

	return false;
}

/*
	Functions to get the configuration states
*/
float TConfig::GetLevelDetail() const { return m_fLevelDetail; }
float TConfig::GetPlants()      const { return m_fPlants; }
bool  TConfig::ShowQuadtrees()  const { return m_bShowQuadtrees; }
bool  TConfig::ShowVertices()   const { return m_bShowVertices; }
bool  TConfig::ShowNormals()    const { return m_bShowNormals; }

/*
	Updates all configuration relevant stuff
*/
void TConfig::Update()
{
	// Check if the engine configuration dialog should be opened
	if (_AS::CInput.IsKeyHit(DIK_F11)) {
		SendMessage(_AS::CWindowManager.GetMainWindow()->GetWnd(), WM_SYSCOMMAND, SC_MINIMIZE, 0);
		OpenDialog(_AS::CWindowManager.GetMainWindow()->GetWnd());
		SendMessage(_AS::CWindowManager.GetMainWindow()->GetWnd(), WM_SIZE, SIZE_RESTORED, 0);
	}
}

/*
	Updates the settings of a model handler
*/
void TConfig::Update(ASTModelHandler& pCModelHandler)
{
	if (CConfig.ShowVertices())
		pCModelHandler.SetFlags(pCModelHandler.GetFlags() | ASeModelHandlerFlagShowVertices);
	else pCModelHandler.SetFlags(pCModelHandler.GetFlags() & ~ASeModelHandlerFlagShowVertices);

	if (CConfig.ShowNormals()) pCModelHandler.SetFlags(pCModelHandler.GetFlags() | ASeModelHandlerFlagShowNormals);
	else pCModelHandler.SetFlags(pCModelHandler.GetFlags() & ~ASeModelHandlerFlagShowNormals);
}

/*
	Resets the configurations
*/
void TConfig::Reset()
{
	// Remove the old configuration file
	_AS::CFileSystem.RemoveFile(m_szFilename);

	// Create a new one
	m_bLoaded = false;
	Load(m_szFilename);
}
/*
	File: LevelGeometry.cpp
*/

#include <ASEngine.h>
#include "Level.h"


/*
	Calculates the vertex ID of a given vertex position
*/
int TLevelGeometry::GetID(const int iX, const int iY) const
{
	// Check if the position if valid
	if (!IsValid(iX, iY)) return -1;

	return iX + iY * m_iSize[X];
}

/*
	Calculates the vertex ID of a given vertex position
*/
int TLevelGeometry::GetID(const float fX, const float fY) const
{
	int iX, iY;

	GetPos(fX, fY, &iX, &iY);

	return GetID(iX, iY);
}

/*
	Calculates the vertex position of a level position
*/
bool TLevelGeometry::GetPos(const float fX, const float fY, int* iX, int* iY) const
{
	*iX = (int) ((fX + m_fTranslate[X]) / FIELDSIZE_X);
	*iY = (int) ((fY + m_fTranslate[Y]) / FIELDSIZE_Y);

	if (IsValid(*iX, *iY)) return true;
	else				   return false;
}

/*
	Calculates the level position of a vertex position
*/
bool TLevelGeometry::GetLevelPos(const int iX, const int iY, float* fX, float* fY) const
{
	if (IsValid(iX, iY)) return true;

	*fX = (float) (iX * FIELDSIZE_X - m_fTranslate[X]);
	*fY = (float) (iY * FIELDSIZE_Y - m_fTranslate[Y]);

	return false;
}

/*
	Checks if the given ID is valid
*/
bool TLevelGeometry::IsValid(const int iID) const
{
	if (iID < 0 || iID >= m_iVertices) return false;
	else							   return true;
}

/*
	Checks if the given position is valid
*/
bool TLevelGeometry::IsValid(const int iX, const int iY) const
{
	if (iX < 0 || iX > m_iSize[X] ||
	    iY < 0 || iY > m_iSize[Y])
		return false; // NO! Its outside the level!!

	return true;
}

/*
	Checks if the given position is valid
*/
bool TLevelGeometry::IsValid(const float fX, const float fY) const
{
	// Compute the vertex position
	int iX = (int) ((fX + m_fTranslate[X]) / FIELDSIZE_X);
	int iY = (int) ((fY + m_fTranslate[Y]) / FIELDSIZE_Y);

	return IsValid(iX, iY);
}

/*
	Performs the level cel-shading
*/
void TLevelGeometry::PerformCelShading()
{
	if (!_AS::CConfig.IsComicStyle() || !_AS::CConfig.IsComicCelShading())
		return;

	ASTVector3D vLightDir;
	ASTLight* pCLight;
	float* pfTextureCoordinateT,
		 * pfLastTextureCoordinateT;
	int* piVisibleVertices;

	// Reset texture coordinates
	pfTextureCoordinateT     = &m_pfSecondaryTexCoord[0];
	pfLastTextureCoordinateT = &m_pfSecondaryTexCoord[m_iVertices];
	for (; pfTextureCoordinateT < pfLastTextureCoordinateT; pfTextureCoordinateT++)
		*pfTextureCoordinateT = 0.f;

	// Lighting
	pCLight = _AS::CEntityManager.FindFirstLight();
	while (pCLight) {
		// Does the light influences the cel shading?
		if (pCLight->GetFlags() & ASeLightFlagCelShading) {
			// Ambiente light
			if (pCLight->GetFlags() & ASELightFlagAmbient) {
				piVisibleVertices = m_piVisibleVertices;
				for (; *piVisibleVertices >= 0; piVisibleVertices++) {
					pfTextureCoordinateT = &m_pfSecondaryTexCoord[*piVisibleVertices];
					*pfTextureCoordinateT += pCLight->GetBrightness();

					// Couldn't it get brighter?
					if (*pfTextureCoordinateT >= 1.f) {
						*pfTextureCoordinateT = 1.f;

						break;
					}
				}
			}

			// Diffuse light
			if (pCLight->GetFlags() & ASELightFlagDiffuse) {
				piVisibleVertices = m_piVisibleVertices;
				for (; *piVisibleVertices >= 0; piVisibleVertices++) {
					pfTextureCoordinateT = &m_pfSecondaryTexCoord[*piVisibleVertices];

					// Get light direction
					vLightDir = (pCLight->GetPos() - ASTVector3D(m_pfVertex[*piVisibleVertices])).Normalize();

					*pfTextureCoordinateT += ASDotProduct(m_pfNormal[*piVisibleVertices], vLightDir.fV) * pCLight->GetBrightness();

					// Couldn't it get brighter?
					if (*pfTextureCoordinateT >= 1.f) {
						*pfTextureCoordinateT = 1.f;

						break;
					}
				}
			}
		}
		pCLight = _AS::CEntityManager.FindNextLight();
	}
}

/*
	Initializes the level geometry
*/
bool TLevelGeometry::Init(TLevel* pCLevel, const int iXSize, const int iYSize)
{
	ASFLOAT3* pfVertex, *pfNormal;
	ASFLOAT2* pfPrimaryTexCoord;
	float* pfSecondaryTexCoord;
	int iX, iY;
	
	// Check pointer
	if (!pCLevel) return true;

	_AS::CLog.Output("Initialize level geometry");

	// Setup data
	m_pCLevel		 = pCLevel;
	m_iSize[X]		 = iXSize;
	m_iSize[Y]	     = iYSize;
	m_iLevelVertices = iXSize * iYSize;
	m_iVertices		 = m_iLevelVertices * 2;
	m_fTranslate[X]  = (m_iSize[X] / 2) * FIELDSIZE_X + FIELDSIZE_X / 2;
	m_fTranslate[Y]  = (m_iSize[Y] / 2) * FIELDSIZE_Y + FIELDSIZE_X / 2;
	m_fTranslate[Z]  = 0.f;

	// Allocate memory
	m_bUsingHardwareVertexArray = false;
	if (_AS::CRenderer.CExtensions.IsVertexArraySupported()) {
		if (!(m_pfVertex = (ASFLOAT3*) wglAllocateMemoryNV(sizeof(float) * m_iVertices * 3, 0.2f, 0.2f, 0.26f)))
			m_pfVertex  = new ASFLOAT3[m_iVertices];
		else {
			m_bUsingHardwareVertexArray = true;
			glVertexArrayRangeNV(m_iVertices, m_pfVertex);
		}
	} else m_pfVertex = new ASFLOAT3[m_iVertices];
	m_pfVertex			  = new ASFLOAT3[m_iVertices];
	m_pfNormal		      = new ASFLOAT3[m_iVertices];
	m_pfPrimaryTexCoord   = new ASFLOAT2[m_iLevelVertices];
	m_pfSecondaryTexCoord = new float[m_iVertices];
	m_pbVertexVisible	  = new bool[m_iVertices];
	m_piVisibleVertices	  = new int[m_iVertices + 1];

	// Setup the vertices
	pfVertex		    = m_pfVertex;
	pfNormal		    = m_pfNormal;
	pfPrimaryTexCoord   = m_pfPrimaryTexCoord;
	pfSecondaryTexCoord = m_pfSecondaryTexCoord;
	for (iY = 0; iY < m_iSize[Y]; iY++)
		for (iX = 0; iX < m_iSize[X]; iX++, pfVertex++, pfNormal++,
									  pfPrimaryTexCoord++, pfSecondaryTexCoord++) {
			// Vertex position
			(*pfVertex)[X] = (*(pfVertex + m_iLevelVertices))[X] = (float) (iX * FIELDSIZE_X - m_fTranslate[X]);
			(*pfVertex)[Y] = (*(pfVertex + m_iLevelVertices))[Y] = (float) (iY * FIELDSIZE_Y - m_fTranslate[Y]);
			(*pfVertex)[Z] = (*(pfVertex + m_iLevelVertices))[Z] = 0.f;

			// Vertex texture coordinate
			(*pfPrimaryTexCoord)[X] = (float) iX / m_iSize[X];
			(*pfPrimaryTexCoord)[Y] = (float) iY / m_iSize[Y];
			*pfSecondaryTexCoord    = 1.f;
		}

	// Create a random terrain
	CreateRandomTerrain();

	if (m_bUsingHardwareVertexArray) glVertexArrayRangeNV(m_iVertices, m_pfVertex);
	ComputeBoundingBox();

	return false;
}

/*
	De-initializes the level geometry
*/
bool TLevelGeometry::DeInit()
{
	_AS::CLog.Output("De-initialize level geometry");

	// Destroy additional model information
	if (m_bUsingHardwareVertexArray) {
		if (m_pfVertex) wglFreeMemoryNV(m_pfVertex);
	} else {
		if (m_pfVertex) delete [] m_pfVertex;
	}
	if (m_pfNormal)			   delete [] m_pfNormal;
	if (m_pfPrimaryTexCoord)   delete [] m_pfPrimaryTexCoord;
	if (m_pfSecondaryTexCoord) delete [] m_pfSecondaryTexCoord;
	if (m_pbVertexVisible)	   delete [] m_pbVertexVisible;
	if (m_piVisibleVertices)   delete [] m_piVisibleVertices;

	return false;
}

/*
	Computes the levels bounding box
*/
void TLevelGeometry::ComputeBoundingBox()
{
	ASFLOAT3* pfVertex, *pfVertexLast;
	int i, iSize;

	// Initialize bounding box:
	iSize = m_iSize[X] + m_iSize[Y] + m_iSize[Z];
	for (i = 0; i < 3; i++) {
		m_fBoundingBox[0][i] = (float)  iSize;
		m_fBoundingBox[1][i] = (float) -iSize;
	}

	// Compute the bounding box
	pfVertex     = m_pfVertex;
	pfVertexLast = pfVertex + m_iVertices;
	for (; pfVertex < pfVertexLast; pfVertex++) {
		for (i = 0; i < 3; i++) {
			if (m_fBoundingBox[0][i] > (*pfVertex)[i]) m_fBoundingBox[0][i] = (*pfVertex)[i];
			if (m_fBoundingBox[1][i] < (*pfVertex)[i]) m_fBoundingBox[1][i] = (*pfVertex)[i];
		}
	}
}

/*
	Updates the visibility information
*/
void TLevelGeometry::UpdateVisibility()
{
	bool* pbVertexVisible, *pbVertexVisibleLast;
	int *piVisibleVertices, i;
	TLevelField** pCField;

	// Reset vertices visibility state
	memset(m_pbVertexVisible, 0, sizeof(bool) * m_iVertices);

	// Get vertices visibility state
	pCField = m_pCLevel->CFieldManager.m_pCFrustumFields;
	while (*pCField) {
		for (i = 0; i < 4; i++) {
			m_pbVertexVisible[(*pCField)->m_iVertex[i]] = 
			m_pbVertexVisible[(*pCField)->m_iVertex[i] + m_iLevelVertices] = true;
		}
		pCField++;
	}

	// Get a list of all visible vertices
	pbVertexVisible     = m_pbVertexVisible;
	pbVertexVisibleLast = pbVertexVisible + m_iVertices;
	piVisibleVertices   = m_piVisibleVertices;
	for (m_iFrustumVertices = 0; pbVertexVisible < pbVertexVisibleLast; m_iFrustumVertices++, pbVertexVisible++) {
		if (!*pbVertexVisible) continue;
		*piVisibleVertices = m_iFrustumVertices;
		piVisibleVertices++;
	}
	*piVisibleVertices = -1;
}
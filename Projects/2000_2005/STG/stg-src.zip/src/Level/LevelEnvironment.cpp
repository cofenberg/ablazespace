/*
	File: LevelEnvironment.cpp
*/

#include <ASEngine.h>
#include "Level.h"


/*
	Draws the environment
*/
void TLevelEnvironment::Draw()
{
	m_CSkyCube.Draw();
}

/*
	Initializes the levels environment
*/
void TLevelEnvironment::Init()
{
	// Initialize the sky cube
	m_CSkyCube.Init();
}

/*
	De-initializes the levels environment
*/
void TLevelEnvironment::DeInit()
{
	// De-initialize the sky cube
	m_CSkyCube.Init();
}
/*
	File: LevelFieldManager.h
	Description: Field manager
*/

#ifndef __LEVELFIELDMANAGER_H__
#define __LEVELFIELDMANAGER_H__


// Includes
#include "LevelField.h"
#include "LevelQuadtrees.h"


// Definitions
#define MAXFIELDSX 64 // Maximum X fields
#define MAXFIELDSY 64 // Maximum Y fields


// Classes
typedef class TLevelFieldManager {

	friend TLevel;
	friend TLevelField;
	friend TLevelQuadtree;
	friend TLevelGeometry;

	public:
		/*
			Calculates the field ID of a given field position

			Parameters:
				int iX & iY -> Matrix field position

			Returns:
				int -> The field ID. '-1' if the position is invalid
		*/
		int GetID(const int iX, const int iY) const;

		/*
			Calculates the field ID of a given field position

			Parameters:
				float fX & fY -> Matrix field position

			Returns:
				int -> The field ID. '-1' if the position is invalid
		*/
		int GetID(const float fX, const float fY) const;

		/*
			Calculates the field position of a level position

			Parameters:
				float fX & fY -> Level position
				int*  iX & iY -> The field matrix position

			Returns:
				bool -> 'false' if all went fine else 'true' (invalid position)
		*/
		bool GetPos(const float fX, const float fY, int* iX, int* iY) const;

		/*
			Calculates the level position of a field position

			Parameters:
				int    iX & iY -> Matrix field position
				float* fX & fY -> The level position

			Returns:
				bool -> 'false' if all went fine else 'true' (invalid position)
		*/
		bool GetLevelPos(const int iX, const int iY, float* fX, float* fY) const;

		/*
			Checks if the given ID is valid

			Parameters:
				int iID -> Matrix field ID

			Returns:
				bool -> 'true' if the ID is valid (inside the level) else 'false'
		*/
		bool IsValid(const int iID) const;

		/*
			Checks if the given position is valid

			Parameters:
				int iX & iY -> Matrix field position

			Returns:
				bool -> 'true' if the position is valid (inside the level) else 'false'
		*/
		bool IsValid(const int iX, const int iY) const;

		/*
			Checks if the given position is valid

			Parameters:
				float fX & fY -> Matrix field position

			Returns:
				bool -> 'true' if the position is valid (inside the level) else 'false'
		*/
		bool IsValid(const float fX, const float fY) const;


	private:
		TLevel* m_pCLevel;	// Pointer to the owner level

		ASINT2 m_iSize;		// The field matrix size
		int	   m_iFields;	// Total number of fields in the level

		TLevelField*   m_pCField;			// All fields
	 	TLevelField**  m_pCFrustumFields;	// Pointer to the fields which are in the frustum
		TLevelQuadtree m_CQuadtree;			// Quadtrees


		/*
			Initializes the field manager
			
			Parameters:
				TLevel* pCLevel		    -> Pointer to the owner level
				int		iXSize & iYSize -> Field grind size

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Init(TLevel* pCLevel, const int iXSize, const int iYSize);

		/*
			De-initializes the field manager
		*/
		bool DeInit();

		/*
			Calculate the planes of all fields

			Parameters:
				bool bForceAll -> Should the calculation be forced?
		*/
		void CalculatePlanes(const bool bForceAll = false) const;

		/*
			Calculate the normals of all vertices
		*/
		void CalculateVerticesNormals() const;

		/*
			Calculates the bounding boxes of all fields

			Parameters:
				bool bForceAll -> Should the calculation be forced?
		*/
		void CalculateBoundingBoxes(const bool bForceAll = false) const;

		/*
			Disables the field update flag
		*/
		void DisableFieldUpdate() const;

		/*
			Update the field manager

			Parameters:
		*/
		void Update();

		/*
			Updates the field visibility information
		*/
		void UpdateVisibility();

		/*
			Builds the cliff
		*/
		void BuildCliff();

		/*
			Creates a plateau

			Parameters:
				int iXPos & iYPos	 -> Center position of the plateau
				int iWidth & iHeight -> Plateau dimension
				float fHeight		 -> Plateau height
		*/
		void CreatePlateau(const int iXPos, const int iYPos, const int iWidth, const int iHeight, const float fHeight);

		/*
			Create the random level alpha map

			Notes:
				- This function activates / deactivates fields
		*/
		void CreateRandomAlpha();


} TLevelFieldManager;


#endif // __LEVELFIELDMANAGER_H__
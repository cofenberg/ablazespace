/*
	File: LevelQuadtrees.h
	Description: The quatrees are used to improve the field of view culling
*/

#ifndef __LEVELQUADTREES_H__
#define __LEVELQUADTREES_H__


// Classes
typedef class TLevelQuadtree {
	
	public:
		/*
			Create the quadtrees for a level

			Parameters:
				TLevelFieldManager* pCFieldManager -> Pointer to the owner field manager

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Build(TLevelFieldManager* pCFieldManager);

		/*
			Destroy the quadtrees

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		void Destroy();

		/*
			Updates the visibility
		*/
		void UpdateVisibility();

		/*
			Draw the quadtrees bounding boxes
		*/
		void ShowBoundingBox();


	private:
		TLevelFieldManager* m_pCFieldManager;	// Pointer to the owner field manager

		int				m_iChildren;	// Number of children
		TLevelQuadtree* m_pCChild;		// Children
		TLevelQuadtree* m_pCParent;		// Parent quadtree of this quadtree

		bool		  m_bInFrustum;		// Is this quadtree in the frustum?
		ASBOUNDINGBOX m_fBoundingBox;	// Quadtrees bounding box

		ASINT2 m_iStartPos;		// Start cut position of the fields
		ASINT2 m_iSize;			// Field size
		int    m_iFields;		// Number of fields in this quadtree

		TLevelField** m_pCField;	// Pointer to the fields in this quadtree


		/*
			Initializes a quadtree

			Parameters:
				TLevelQuadtree* pCParent				-> Pointer to the parent quadtree
				int				iStartPosX & iStartPosY -> The field matrix start position
				int				iSizeX & iSizeY		    -> The field matrix size

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Init(TLevelQuadtree* pCParent, const int iStartPosX, const int iStartPosY, const int iSizeX, const int iSizeY);

		/*
			Update the visibility state of all fields
		*/
		void CheckFieldsInFrustum();

		void SetNotInFrustum();
		void CheckInFrustum();
		void SetFieldsInFrustum();

		/*
			Computes the bounding box of the quadtree
		*/
		void ComputeBoundingBox();
		

} TLevelQuadtree;


#endif // __LEVELQUADTREES_H__
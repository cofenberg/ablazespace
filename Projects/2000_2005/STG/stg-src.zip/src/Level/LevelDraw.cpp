/*
	File: Level.cpp
*/

#include <ASEngine.h>
#include "..\Config.h"
#include "..\Game.h"
#include "Level.h"


/*
	Draws the level
*/
bool TLevel::Draw()
{
	ASFLOAT2 fTexCoord1, fTexCoord2, fTexCoord3, fTexCoord4;
	TLevelField** pCField, *pCFieldT;
	ASFLOAT3* pfVertex, *pfNormal;
	int* piVisibleVertices;
	int i;

	// Update visibility
	UpdateVisibility();

	// Setup texture coordinates
	fTexCoord1[X] = 0.f;
	fTexCoord1[Y] = 0.f;
	fTexCoord2[X] = 1.f;
	fTexCoord2[Y] = 0.f;
	fTexCoord3[X] = 1.f;
	fTexCoord3[Y] = 1.f;
	fTexCoord4[X] = 0.f;
	fTexCoord4[Y] = 1.f;
	
	CGeometry.PerformCelShading();

	glDisable(GL_LIGHTING);
	
	// Initialize render states
	if (CGeometry.m_bUsingHardwareVertexArray) glEnableClientState(GL_VERTEX_ARRAY_RANGE_NV);
	glDisableClientState(GL_COLOR_ARRAY);
	glDisableClientState(GL_NORMAL_ARRAY);

	glEnableClientState(GL_VERTEX_ARRAY);
	glEnableClientState(GL_TEXTURE_COORD_ARRAY);
	glVertexPointer(  3, GL_FLOAT, 0, CGeometry.m_pfVertex);
	glTexCoordPointer(2, GL_FLOAT, 0, CGeometry.m_pfPrimaryTexCoord);
	if (_AS::CRenderer.CExtensions.IsCompiledVertexArraySupported()) glLockArraysEXT(0,  CGeometry.m_iVertices);

	// Activate second texture
	if (_AS::CConfig.IsComicCelShading()) {
		glActiveTextureARB(GL_TEXTURE1_ARB);
		glClientActiveTextureARB(GL_TEXTURE1_ARB);
		glEnableClientState(GL_TEXTURE_COORD_ARRAY);
		glEnable(GL_TEXTURE_1D);
		_AS::CTextureManager.GetCelShadingTexture()->BindOpenGLTexture();
		glTexCoordPointer(1, GL_FLOAT, 0, CGeometry.m_pfSecondaryTexCoord);
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE); 
		glActiveTextureARB(GL_TEXTURE0_ARB);
		glClientActiveTextureARB(GL_TEXTURE0_ARB);
	}

	// Draw the fields
	glDisable(GL_CULL_FACE);
	m_CTerrainTexture.GetTexture()->BindOpenGLTexture();
	glEnable(GL_TEXTURE_2D);
	glCullFace(GL_FRONT);
	pCField	= CFieldManager.m_pCFrustumFields;
	glBegin(GL_QUADS);
		while (*pCField) {
			pCFieldT = *pCField;
			glArrayElement(pCFieldT->m_iVertex[3]);
			glArrayElement(pCFieldT->m_iVertex[2]);
			glArrayElement(pCFieldT->m_iVertex[1]);
			glArrayElement(pCFieldT->m_iVertex[0]);
			_AS::CRenderer.AddTriangles(2);
			pCField++;
		}
	glEnd();

	// Draw the field cliffs
	if (_AS::CConfig.IsHighRenderQuality()) {
		m_CCliffTexture.GetTexture()->BindOpenGLTexture();
		glDisableClientState(GL_TEXTURE_COORD_ARRAY);
		pCField	= CFieldManager.m_pCFrustumFields;
		glBegin(GL_QUADS);
			while (*pCField) {
				pCFieldT = *pCField;
				for (i = 0; i < 4; i++) {
					if (!pCFieldT->m_bCliffActive[i]) continue;
					glTexCoord2fv(fTexCoord4);
					glArrayElement(pCFieldT->m_iCliffVertex[i][0]);
					glTexCoord2fv(fTexCoord3);
					glArrayElement(pCFieldT->m_iCliffVertex[i][1]);
					glTexCoord2fv(fTexCoord2);
					glArrayElement(pCFieldT->m_iCliffVertex[i][2]);
					glTexCoord2fv(fTexCoord1);
					glArrayElement(pCFieldT->m_iCliffVertex[i][3]);
				}
				pCField++;
			}
		glEnd();
	}
	glEnable(GL_CULL_FACE);

	// Deactivate second texture
	if (_AS::CConfig.IsComicCelShading()) {
		glActiveTextureARB(GL_TEXTURE1_ARB);
		glClientActiveTextureARB(GL_TEXTURE1_ARB);
		glDisableClientState(GL_TEXTURE_COORD_ARRAY);
		glDisable(GL_TEXTURE_1D);
		glActiveTextureARB(GL_TEXTURE0_ARB);
		glClientActiveTextureARB(GL_TEXTURE0_ARB);
	}

	// Should silhouettes be drawn?
	if (_AS::CConfig.IsComicSilhouettes() && !_AS::CConfig.IsWireframeMode() && !_AS::CConfig.IsPointMode()) {
		glDisable(GL_TEXTURE_2D);
		glDisable(GL_BLEND);
		glPolygonMode(GL_FRONT, GL_LINE);
		glCullFace(GL_BACK);
		glLineWidth(_AS::CConfig.GetComicSilhouettesWidth());
		glDepthFunc(GL_LEQUAL);
		glColor3f(0.f, 0.f, 0.f);

		// Draw the fields
		pCField	= CFieldManager.m_pCFrustumFields;
		glBegin(GL_TRIANGLES);
			while (*pCField) {
				pCFieldT = *pCField;
				glArrayElement(pCFieldT->m_iVertex[0]);
				glArrayElement(pCFieldT->m_iVertex[1]);
				glArrayElement(pCFieldT->m_iVertex[3]);
				glArrayElement(pCFieldT->m_iVertex[1]);
				glArrayElement(pCFieldT->m_iVertex[2]);
				glArrayElement(pCFieldT->m_iVertex[3]);
				_AS::CRenderer.AddTriangles(2);
				pCField++;
			}
		glEnd();

		glDepthFunc(GL_LESS);
		glPolygonMode(GL_FRONT, GL_FILL);
		glColor3f(1.f, 1.f, 1.f);
		glEnable(GL_TEXTURE_2D);
	}

	// Show vertices
	if (CConfig.ShowVertices()) {
		glColor3f(1.f, 1.f, 1.f);
		glPointSize(5.f);
		piVisibleVertices = CGeometry.m_piVisibleVertices;
		glBegin(GL_POINTS);
			while (*piVisibleVertices >= 0) {
				glArrayElement(*piVisibleVertices);
				piVisibleVertices++;
			}
		glEnd();
	}

	// Show normals
	if (CConfig.ShowNormals()) {
		glColor3f(1.f, 1.f, 1.f);
		glLineWidth(3.f);
		piVisibleVertices = CGeometry.m_piVisibleVertices;
		glBegin(GL_LINES);
			while (*piVisibleVertices >= 0) {
				pfVertex = &CGeometry.m_pfVertex[*piVisibleVertices];
				pfNormal = &CGeometry.m_pfNormal[*piVisibleVertices];
				glVertex3fv(*pfVertex);
				glVertex3f((*pfVertex)[X] + (*pfNormal)[X] * 2,
						   (*pfVertex)[Y] + (*pfNormal)[Y] * 2,
						   (*pfVertex)[Z] + (*pfNormal)[Z] * 2);
				piVisibleVertices++;
			}
		glEnd();
	}

	// De-initialize render states
	if (_AS::CRenderer.CExtensions.IsCompiledVertexArraySupported()) glUnlockArraysEXT();
	glDisableClientState(GL_VERTEX_ARRAY);
	if (CGeometry.m_bUsingHardwareVertexArray) glDisableClientState(GL_VERTEX_ARRAY_RANGE_NV);

	{ // Draw plants
		TLevelPlant* pSPlant;

		glColor3f(1.f, 1.f, 1.f);
		glDisable(GL_CULL_FACE);
		glDisable(GL_BLEND);

		m_CPlantTexture.GetTexture()->BindOpenGLTexture();
		for (i = 0; i < m_iPlants * CConfig.GetPlants(); i++) {
			pSPlant = &m_pSPlants[i];
			if (!pSPlant->pCField->m_bInFrustum) continue;
			glPushMatrix();
			glTranslatef(pSPlant->fPosX, pSPlant->fPosY, pSPlant->fPosZ);
			glScalef(pSPlant->fScaleX, pSPlant->fScaleY, pSPlant->fScaleZ);
			glCallList(m_iPlantList);
			glPopMatrix();
			_AS::CRenderer.AddTriangles(4);
		}

		glEnable(GL_CULL_FACE);
	}

	// Draw quadtrees
	if (CConfig.ShowQuadtrees()) CFieldManager.m_CQuadtree.ShowBoundingBox();
		
	return false;
}

void TLevel::DrawShadow(const ASTVector3D& vPos, const float fSize)
{
	if (!_AS::CConfig.DrawShadowmaps()) return;

	m_CShadowTexture.GetTexture()->BindOpenGLTexture();
	glEnable(GL_BLEND);
	glDepthMask(false);
	glDisable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_FOG);
	glDepthFunc(GL_EQUAL);
	glBlendFunc(GL_DST_COLOR, GL_ZERO);
	glCullFace(GL_FRONT);

	glDisable(GL_CULL_FACE);

	ASTProjectedLight CLight(vPos, ASTVector3D(1.f, 1.f, 1.f), fSize, 1.f, false);

	TLevelField *pCFieldT;
	int iX, iY, i, iID, iXStart, iYStart, iXEnd, iYEnd;

	// Get the current field position the source point is on
	CFieldManager.GetPos(vPos.fX, vPos.fY, &iXStart, &iYStart);

	// Get the field which have to be checked
	iXEnd	 = (int) (iXStart + fSize / FIELDSIZE_X) + 1;
	iXStart -= (int) (fSize / FIELDSIZE_X) + 1;
	iYEnd	 = (int) (iYStart + fSize / FIELDSIZE_Y) + 1;
	iYStart -= (int) (fSize / FIELDSIZE_Y) + 1;
	if (iXStart < 0) iXStart = 0;
	if (iYStart < 0) iYStart = 0;
	if (iXEnd >= CFieldManager.m_iSize[X]) iXEnd = CFieldManager.m_iSize[X] - 1;
	if (iYEnd >= CFieldManager.m_iSize[Y]) iYEnd = CFieldManager.m_iSize[Y] - 1;

//	glEnable(GL_POLYGON_OFFSET_FILL);
//	glPolygonOffset(-1.f, -1.f);
	
	// Loop through all faces in mesh
	glBegin(GL_TRIANGLES);
		for (iY = iYStart; iY <= iYEnd; iY++) {
			for (iX = iXStart; iX <= iXEnd; iX++) {
				if ((iID = CFieldManager.GetID(iX, iY)) < 0) continue;
				pCFieldT = &CFieldManager.m_pCField[iID];
				if (!pCFieldT->m_bActive) continue;
				for (i = 0; i < 2; i++) CLight.DrawTriangle(pCFieldT->m_CPlane[i]);
			}
		}
	glEnd();

//	glDisable(GL_POLYGON_OFFSET_FILL);
	glDepthFunc(GL_LEQUAL);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	glDepthMask(true);
	glDisable(GL_BLEND);
}
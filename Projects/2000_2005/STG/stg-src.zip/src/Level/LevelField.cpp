/*
	File: LevelField.cpp
*/

#include <ASEngine.h>
#include "Level.h"


/*
	Activates / deactivates the field
*/
void TLevelField::SetActive(const bool bActive)
{
	m_bActive = bActive;
}

/*
	Calculate the field planes
*/
void TLevelField::CalculatePlanes()
{
	ASFLOAT3* pfVertex = m_pCFieldManager->m_pCLevel->CGeometry.m_pfVertex;

	m_CPlane[0].ComputeND(pfVertex[m_iVertex[0]], pfVertex[m_iVertex[1]], pfVertex[m_iVertex[3]]);
	m_CPlane[1].ComputeND(pfVertex[m_iVertex[1]], pfVertex[m_iVertex[2]], pfVertex[m_iVertex[3]]);
}

/*
	Calculate the normals of all field vertices
*/
void TLevelField::CalculateVerticesNormals()
{
	ASFLOAT3* pfNormal = m_pCFieldManager->m_pCLevel->CGeometry.m_pfNormal,
			* pfNormalT;

	for (int i = 0; i < 3; i++) {
		// Vertex 0
		pfNormalT = &pfNormal[m_iVertex[0]];
		if (!(*pfNormalT)[i]) (*pfNormalT)[i] = (m_CPlane[0].vN.fV[i] + m_CPlane[1].vN.fV[i]) / 2;
		else {
			(*pfNormalT)[i] += m_CPlane[0].vN.fV[i] + m_CPlane[1].vN.fV[i];
			if ((*pfNormalT)[i]) (*pfNormalT)[i] /= 3;
		}

		// Vertex 1
		pfNormalT = &pfNormal[m_iVertex[1]];
		if (!(*pfNormalT)[i]) (*pfNormalT)[i] = m_CPlane[0].vN.fV[i];
		else {
			(*pfNormalT)[i] += m_CPlane[0].vN.fV[i];
			if ((*pfNormalT)[i]) (*pfNormalT)[i] /= 2;
		}

		// Vertex 2
		pfNormalT = &pfNormal[m_iVertex[2]];
		if (!(*pfNormalT)[i]) (*pfNormalT)[i] = (m_CPlane[0].vN.fV[i] + m_CPlane[1].vN.fV[i]) / 2;
		else {
			(*pfNormalT)[i] += m_CPlane[0].vN.fV[i] + m_CPlane[1].vN.fV[i];
			if ((*pfNormalT)[i]) (*pfNormalT)[i] /= 3;
		}

		// Vertex 3
		pfNormalT = &pfNormal[m_iVertex[3]];
		if (!(*pfNormalT)[i]) (*pfNormalT)[i] = m_CPlane[1].vN.fV[i];
		else {
			(*pfNormalT)[i] += m_CPlane[1].vN.fV[i];
			if ((*pfNormalT)[i]) (*pfNormalT)[i] /= 2;
		}
	}
}

/*
	Calculates the bounding boxes of the field
*/
void TLevelField::CalculateBoundingBox()
{
	ASFLOAT3* pfVertex, *pfVertexT;
	int i, iSize, iVertex;

	// Initialize bounding box:
	iSize = m_pCFieldManager->m_iSize[X] + m_pCFieldManager->m_iSize[Y] + m_pCFieldManager->m_iSize[Z];
	for (i = 0; i < 3; i++) {
		m_fBoundingBox[0][i] = (float)  iSize;
		m_fBoundingBox[1][i] = (float) -iSize;
	}
	
	pfVertex = m_pCFieldManager->m_pCLevel->CGeometry.m_pfVertex;
	for (iVertex = 0; iVertex < 4; iVertex++) {
		pfVertexT = &pfVertex[m_iVertex[iVertex]];
		for (i = 0; i < 3; i++) {
			float f = (*pfVertexT)[i];
			if (f < m_fBoundingBox[0][i])
				m_fBoundingBox[0][i] = f;
			if (f > m_fBoundingBox[1][i])
				m_fBoundingBox[1][i] = f;
		}
	}
	iSize = m_pCFieldManager->m_pCLevel->CGeometry.m_iLevelVertices;
	for (iVertex = 0; iVertex < 4; iVertex++) {
		pfVertexT = &pfVertex[m_iVertex[iVertex] + iSize];
		for (i = 0; i < 3; i++) {
			float f = (*pfVertexT)[i];
			if (f < m_fBoundingBox[0][i])
				m_fBoundingBox[0][i] = f;
			if (f > m_fBoundingBox[1][i])
				m_fBoundingBox[1][i] = f;
		}
	}
}

/*
	Updates the field
*/
void TLevelField::Update()
{
}
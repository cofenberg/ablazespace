/*
	File: LevelCollision.cpp
*/

#include <ASEngine.h>
#include "Level.h"


/*
	Gets the height at the given position
*/
TLevelField* TLevel::GetHeight(const float fX, const float fY, float& pfHeight,
							   const bool bInActiveToo, const bool bNoCollisionMesh)
{
	ASTVector3D vStartPoint, vRayDirection, vIntersectionPoint;
	TLevelField* pCField, *pCFieldT, *pCLastCollisionField;
	int i, iXPos, iYPos, iXFieldPos, iYFieldPos, iID;
	ASTCollisionMesh* pSCollMesh;

	pfHeight = 10.f;

	// Check the collision mesh
	for (i = 0; i < m_lstCollisionMesh.GetElements(); i++) {
		pSCollMesh = m_lstCollisionMesh[i];
		if (fX > pSCollMesh->fBoundingBox[1][X] ||
			fX < pSCollMesh->fBoundingBox[0][X] ||
		    fY > pSCollMesh->fBoundingBox[1][Y] ||
		 	fY < pSCollMesh->fBoundingBox[0][Y])
			continue;
		if (bNoCollisionMesh) return NULL;
		if (pSCollMesh->fBoundingBox[0][Z] < pfHeight)
			pfHeight = pSCollMesh->fBoundingBox[0][Z];
	}

	// Compute the current field the given point is on
	if ((iID = CFieldManager.GetID(fX, fY)) < 0) return NULL;

	pCField = CFieldManager.m_pCField;
	iXFieldPos = pCField[iID].m_iPos[X];
	iYFieldPos = pCField[iID].m_iPos[Y];
	pCLastCollisionField = NULL;

	// Set the start point of the ray
	vStartPoint.fX = fX;
	vStartPoint.fY = fY;

	// Set the ray direction
	vRayDirection.fZ = -1.f;

	// Check the fields
	for (iYPos = iYFieldPos - 1; iYPos < iYFieldPos + 1; iYPos++) {
		// Check if this coordinate is a correct one
		if (iYPos < 0) continue;
		if (iYPos >= CFieldManager.m_iSize[Y]) break;
		for (iXPos = iXFieldPos - 1; iXPos < iXFieldPos + 1; iXPos++) {
			// Check if this coordinate is a correct one
			if (iXPos < 0) continue;
			if (iXPos >= CFieldManager.m_iSize[X]) break;

			// Get a pointer to this field
			pCFieldT = &pCField[CFieldManager.GetID(iXPos, iYPos)];
			if (!bInActiveToo && !pCFieldT->m_bActive) continue;
			if (_AS::CCollision.IsTriangleCollision(vStartPoint, vRayDirection, &vIntersectionPoint,
													pCFieldT->m_CPlane[0]) ||
				_AS::CCollision.IsTriangleCollision(vStartPoint, vRayDirection, &vIntersectionPoint,
													pCFieldT->m_CPlane[1])) {
				if (vIntersectionPoint.fZ < pfHeight) {
					pfHeight = vIntersectionPoint.fZ;
					pCLastCollisionField = pCFieldT;
				}
			}
		}
	}

	return pCLastCollisionField;
}

/*
	Performs movement with collision detection
*/
ASTVector3D TLevel::Move(ASTCollisionPacked& CCollisionPacked, ASTVector3D& vPosition, ASTVector3D& vERadius,
						 ASTVector3D& vVelocity, const bool bSlide, const bool bInactiveToo)
{	
	ASTVector3D vScaledPosition, vScaledVelocity;

	// Setup the collision package
	CCollisionPacked.vERadius		  = vERadius;
	CCollisionPacked.bSlide	          = bSlide;
	CCollisionPacked.bFoundACollision = false;
	CCollisionPacked.bCustom1		  = bInactiveToo;

	// The first thing we do is scale the player and his velocity to
	// ellipsoid space
	vScaledPosition = vPosition / vERadius;
	vScaledVelocity = vVelocity / vERadius;	

	// Call the recursive collision response function	
	CCollisionPacked.vFinalPosition = CollideWithWorld(vScaledPosition, vScaledVelocity, CCollisionPacked);

	// When the function returns the result is still in ellipsoid space, so
	// we have to scale it back to R3 before we return it 	
	CCollisionPacked.vFinalPosition *= vERadius;

	return CCollisionPacked.vFinalPosition;
}

/*
	Performs the collision detection
*/
ASTVector3D TLevel::CollideWithWorld(ASTVector3D& vPosition, ASTVector3D& vVelocity, ASTCollisionPacked& CCollisionPacked)
{
	// Do we need to worry?
	if (vVelocity.GetLength() < AS_EPSILON) return vPosition;

	ASTVector3D vPos;
	ASTVector3D vDestinationPoint = vPosition + vVelocity;

	// Reset the collision package we send to the mesh
	CCollisionPacked.vSourcePoint      = vPosition;
	CCollisionPacked.vVelocity         = vVelocity;
	CCollisionPacked.vLastSafePosition = vPosition;
	CCollisionPacked.bFoundCollision   = false;
	CCollisionPacked.bStuck            = false;
	CCollisionPacked.dNearestDistance  = -1;
 
	// Check all meshes
	CheckCollision(CCollisionPacked);	

	// Check return value here, and possibly call recursively
	if (!CCollisionPacked.bFoundCollision) {  // If no collision move very close to the desired destination
		ASTVector3D vV = vVelocity;
		
		vV.SetLength((float) (vV.GetLength() - AS_EPSILON));

		// Update the last safe position for future error recovery
		CCollisionPacked.vLastSafePosition = vPosition;      

		// Return the final position
		return vPosition + vV;
	} else { // There was a collision
		// If we are stuck, we just back up to last safe position
		if (CCollisionPacked.bStuck) {
			// Okay, sometimes we end up inside our sphere, and we're stuck.
			// That's because this collision detection is designed to be in full
			// 3D, and in a normal stuck situation, we would not have this problem
			// because it would be a backface.

			// We can probably get stuck in any wedge... but the dangerous one is
			// when we are stuck in the ground.			
			return CCollisionPacked.vLastSafePosition;
		}

		// OK, first task is to move close to where we hit something
		ASTVector3D vNewSourcePoint;
               
		// Only update if we are not already very close:
		if (CCollisionPacked.dNearestDistance >= AS_EPSILON2 + 2.f) {
			ASTVector3D vV = vVelocity;
			vV.SetLength((float) (CCollisionPacked.dNearestDistance - AS_EPSILON2));
			vNewSourcePoint = CCollisionPacked.vSourcePoint + vV;
		} else vNewSourcePoint = CCollisionPacked.vSourcePoint;

		if (!CCollisionPacked.bSlide) return vNewSourcePoint;

		// Now we must calculate the sliding plane
		ASTVector3D vSlidePlaneOrigin = CCollisionPacked.vNearestPolygonIntersectionPoint;
		ASTVector3D vSlidePlaneNormal = vNewSourcePoint - CCollisionPacked.vNearestPolygonIntersectionPoint;
  
		// We now project the destination point onto the sliding plane
		double dL = _AS::CCollision.IntersectRayPlane(vDestinationPoint, vSlidePlaneNormal, 
													  vSlidePlaneOrigin, vSlidePlaneNormal); 

		// We can now calculate a new destination point on the sliding plane
		ASTVector3D vNewDestinationPoint;
		vNewDestinationPoint.fX = (float) (vDestinationPoint.fX + dL * vSlidePlaneNormal.fX);
		vNewDestinationPoint.fY = (float) (vDestinationPoint.fY + dL * vSlidePlaneNormal.fY);
		vNewDestinationPoint.fZ = (float) (vDestinationPoint.fZ + dL * vSlidePlaneNormal.fZ);

		// Generate the slide vector, which will become our new velocity vector
		// for the next iteration
		ASTVector3D vNewVelocityVector = vNewDestinationPoint - CCollisionPacked.vNearestPolygonIntersectionPoint;
   
		// Now we recursively call the function with the new position and velocity
		CCollisionPacked.vLastSafePosition = vPosition;
		return CollideWithWorld(vNewSourcePoint, vNewVelocityVector, CCollisionPacked);
	}
}

/*
	Performs the collision detection
*/
void TLevel::CheckCollision(ASTCollisionPacked& CCollisionPacked)
{
	TLevelField *pCFieldT;
	int iX, iY, i, iID, iXStart, iYStart, iXEnd, iYEnd;
	
	// Plane data
	ASTPlane CPlane;
	ASTVector3D vPOrigin;
	ASTVector3D vV1, vV2;
	ASTVector3D vP1 = vV1, vP2 = vV1, vP3 = vV1;
	ASTVector3D vPNormal = vV1;

	// From package
	ASTVector3D vSource   = CCollisionPacked.vSourcePoint;
	ASTVector3D vERadius  = CCollisionPacked.vERadius;
	ASTVector3D vSourceT  = CCollisionPacked.vSourcePoint * vERadius;
	ASTVector3D vVelocity = CCollisionPacked.vVelocity;

	// Keep a copy of this as it's needed a few times
	ASTVector3D vNormalizedVelocity = vVelocity;
	vNormalizedVelocity.Normalize();

	// Intersection data
	ASTVector3D vSIPoint;		// Sphere intersection point
	ASTVector3D vPIPoint;		// Plane intersection point
	ASTVector3D vPolyIPoint;	// Polygon intersection point

	// How long is our velocity?
	double dDistanceToTravel = vVelocity.GetLength(),
		   dDistToPlaneIntersection,
		   dDistToEllipsoidIntersection;
	
	
	// Get the current field position the source point is on
	CFieldManager.GetPos(vSource.fX * vERadius.fX, vSource.fY * vERadius.fY, &iXStart, &iYStart);

	// Get the field which have to be checked
	iXEnd	 = (int) (iXStart + vERadius.fX / FIELDSIZE_X);
	iXStart -= (int) (vERadius.fX / FIELDSIZE_X);
	iYEnd	 = (int) (iYStart + vERadius.fY / FIELDSIZE_Y);
	iYStart -= (int) (vERadius.fY / FIELDSIZE_Y);
	iXStart -= 2;
	iYStart -= 2;
	iXEnd += 2;
	iYEnd += 2;
	if (iXStart < 0) iXStart = 0;
	if (iYStart < 0) iYStart = 0;
	if (iXEnd >= CFieldManager.m_iSize[X]) iXEnd = CFieldManager.m_iSize[X] - 1;
	if (iYEnd >= CFieldManager.m_iSize[Y]) iYEnd = CFieldManager.m_iSize[Y] - 1;

	// Loop through all faces in mesh
	for (iY = iYStart; iY <= iYEnd; iY++) {
		for (iX = iXStart; iX <= iXEnd; iX++) {
			if ((iID = CFieldManager.GetID(iX, iY)) < 0) continue;
			pCFieldT = &CFieldManager.m_pCField[iID];
			if (!CCollisionPacked.bCustom1 && !pCFieldT->m_bActive) continue;

			for (i = 0; i < 2; i++) {
				vPNormal = pCFieldT->m_CPlane[i].vN;

				// Ignore backfaces. What we cannot see we cannot collide with ;)
				if (ASDotProduct(vPNormal.fV, vNormalizedVelocity.fV) <= 1.f) { 
					CPlane = pCFieldT->m_CPlane[i];

					// Get the data for the triangle in question and scale to ellipsoid space
					CPlane.vV1 /= vERadius;
					CPlane.vV2 /= vERadius;
					CPlane.vV3 /= vERadius;
					
					// Get plane information
					vP1 = CPlane.vV1;
					vP2 = CPlane.vV2;
					vP3 = CPlane.vV3;

					// Make the plane containing this triangle
					vPOrigin = vP1;
					vV1		 = vP2 - vP1;
					vV2		 = vP3 - vP1;

					// Calculate sphere intersection point
					vSIPoint = vSource - vPNormal;     

					// Classify point to determine if ellipsoid span the plane
					if (_AS::CCollision.ClassifyPoint(vSIPoint, vPOrigin, vPNormal) == ASeOnPlaneBackside) { // Plane is embedded in ellipsoid
						// Find plane intersection point by shooting a ray from the 
						// sphere intersection point along the planes normal
						dDistToPlaneIntersection = _AS::CCollision.IntersectRayPlane(vSIPoint, vPNormal, vPOrigin, vPNormal);

						// Calculate plane intersection point:
						vPIPoint.fX = (float) (vSIPoint.fX + dDistToPlaneIntersection * vPNormal.fX); 
						vPIPoint.fY = (float) (vSIPoint.fY + dDistToPlaneIntersection * vPNormal.fY); 
						vPIPoint.fZ = (float) (vSIPoint.fZ + dDistToPlaneIntersection * vPNormal.fZ); 	
					} else {
						// Shoot ray along the velocity vector
						dDistToPlaneIntersection = _AS::CCollision.IntersectRayPlane(vSIPoint, vNormalizedVelocity, vPOrigin, vPNormal);

						if (dDistToPlaneIntersection < AS_EPSILON && dDistToPlaneIntersection > 0.f)
							dDistToPlaneIntersection = dDistToPlaneIntersection;
						// Calculate plane intersection point
						vPIPoint.fX = (float) (vSIPoint.fX + dDistToPlaneIntersection * vNormalizedVelocity.fX);
						vPIPoint.fY = (float) (vSIPoint.fY + dDistToPlaneIntersection * vNormalizedVelocity.fY);
						vPIPoint.fZ = (float) (vSIPoint.fZ + dDistToPlaneIntersection * vNormalizedVelocity.fZ);
					}

					// Find polygon intersection point. By default we assume its equal to the 
					// plane intersection point
					vPolyIPoint = vPIPoint;
					dDistToEllipsoidIntersection = dDistToPlaneIntersection;

					if (!_AS::CCollision.IsPointInTriangle(vPIPoint, CPlane)) { // If not in triangle
						vPolyIPoint = _AS::CCollision.ClosestPointOnTriangle(vP1, vP2, vP3, vPIPoint);	
						dDistToEllipsoidIntersection = _AS::CCollision.IntersectRaySphere(vPolyIPoint, -vNormalizedVelocity, vSource, 1.f);

						if (dDistToEllipsoidIntersection > 0) { // Calculate true sphere intersection point
     						vSIPoint.fX = (float) (vPolyIPoint.fX + dDistToEllipsoidIntersection * (-vNormalizedVelocity.fX));
     						vSIPoint.fY = (float) (vPolyIPoint.fY + dDistToEllipsoidIntersection * (-vNormalizedVelocity.fY));
     						vSIPoint.fZ = (float) (vPolyIPoint.fZ + dDistToEllipsoidIntersection * (-vNormalizedVelocity.fZ));
						}
					} 

  					// Here we do the error checking to see if we got ourself stuck last frame
   					if (_AS::CCollision.IsPointInSphere(vPolyIPoint, vSource, 1.f))  {
						CCollisionPacked.vLastSphereCollisionPoint = vSIPoint;
						CCollisionPacked.bStuck = true;
					}
					
					// Ok, now we might update the collision data if we hit something
					if ((dDistToEllipsoidIntersection > 0) && (dDistToEllipsoidIntersection <= dDistanceToTravel)) {
						if ((!CCollisionPacked.bFoundCollision) || (dDistToEllipsoidIntersection < CCollisionPacked.dNearestDistance)) {
							// If we are hit we have a closest hit so far. We save the information
							CCollisionPacked.dNearestDistance				  = dDistToEllipsoidIntersection;
							CCollisionPacked.vNearestIntersectionPoint		  = vSIPoint;
							CCollisionPacked.vNearestPolygonIntersectionPoint = vPolyIPoint;
							CCollisionPacked.bFoundCollision				  = CCollisionPacked.bFoundACollision = true;
							CCollisionPacked.vLastSphereCollisionPoint		  = vSIPoint;
						}
					} 
				}
			}
		}
	}

	ASTVector3D vDelta;
	ASTCollisionMesh* pSCollMesh;
	int iPlane;


	// Check the collision mesh
	float fXMin = vSourceT.fV[X] - vERadius.fV[X];
	float fYMin = vSourceT.fV[Y] - vERadius.fV[Y];
	float fZMin = vSourceT.fV[Z] - vERadius.fV[Z];
	float fXMax = vSourceT.fV[X] + vERadius.fV[X];
	float fYMax = vSourceT.fV[Y] + vERadius.fV[Y];
	float fZMax = vSourceT.fV[Z] + vERadius.fV[Z];
	for (i = 0; i < m_lstCollisionMesh.GetElements(); i++) {
		pSCollMesh = m_lstCollisionMesh[i];
		if (fXMin > pSCollMesh->fBoundingBox[1][X] ||
			fXMax < pSCollMesh->fBoundingBox[0][X] ||
		    fYMin > pSCollMesh->fBoundingBox[1][Y] ||
		 	fYMax < pSCollMesh->fBoundingBox[0][Y] ||
		    fZMin > pSCollMesh->fBoundingBox[1][Z] ||
			fZMax < pSCollMesh->fBoundingBox[0][Z])
			continue;

		for (iPlane = 0; iPlane < pSCollMesh->iPlanes; iPlane++) {
			vPNormal = pSCollMesh->pCPlane[iPlane].vN;

			// Ignore backfaces. What we cannot see we cannot collide with ;)
			if (ASDotProduct(vPNormal.fV, vNormalizedVelocity.fV) <= 1.f) { 
				CPlane = pSCollMesh->pCPlane[iPlane];

				// Get the data for the triangle in question and scale to ellipsoid space
				CPlane.vV1 /= vERadius;
				CPlane.vV2 /= vERadius;
				CPlane.vV3 /= vERadius;
				
				// Get plane information
				vP1 = CPlane.vV1;
				vP2 = CPlane.vV2;
				vP3 = CPlane.vV3;

				// Make the plane containing this triangle
				vPOrigin = vP1;
				vV1		 = vP2 - vP1;
				vV2		 = vP3 - vP1;

				// Calculate sphere intersection point
				vSIPoint = vSource - vPNormal;     

				// Classify point to determine if ellipsoid span the plane
				if (_AS::CCollision.ClassifyPoint(vSIPoint, vPOrigin, vPNormal) == ASeOnPlaneBackside) { // Plane is embedded in ellipsoid
					// Find plane intersection point by shooting a ray from the 
					// sphere intersection point along the planes normal
					dDistToPlaneIntersection = _AS::CCollision.IntersectRayPlane(vSIPoint, vPNormal, vPOrigin, vPNormal);

					// Calculate plane intersection point:
					vPIPoint.fX = (float) (vSIPoint.fX + dDistToPlaneIntersection * vPNormal.fX); 
					vPIPoint.fY = (float) (vSIPoint.fY + dDistToPlaneIntersection * vPNormal.fY); 
					vPIPoint.fZ = (float) (vSIPoint.fZ + dDistToPlaneIntersection * vPNormal.fZ); 	
				} else {
					// Shoot ray along the velocity vector
					dDistToPlaneIntersection = _AS::CCollision.IntersectRayPlane(vSIPoint, vNormalizedVelocity, vPOrigin, vPNormal);

					if (dDistToPlaneIntersection < AS_EPSILON && dDistToPlaneIntersection > 0.f)
						dDistToPlaneIntersection = dDistToPlaneIntersection;
					// Calculate plane intersection point
					vPIPoint.fX = (float) (vSIPoint.fX + dDistToPlaneIntersection * vNormalizedVelocity.fX);
					vPIPoint.fY = (float) (vSIPoint.fY + dDistToPlaneIntersection * vNormalizedVelocity.fY);
					vPIPoint.fZ = (float) (vSIPoint.fZ + dDistToPlaneIntersection * vNormalizedVelocity.fZ);
				}

				// Find polygon intersection point. By default we assume its equal to the 
				// plane intersection point
				vPolyIPoint = vPIPoint;
				dDistToEllipsoidIntersection = dDistToPlaneIntersection;

				if (!_AS::CCollision.IsPointInTriangle(vPIPoint, CPlane)) { // If not in triangle
					vPolyIPoint = _AS::CCollision.ClosestPointOnTriangle(vP1, vP2, vP3, vPIPoint);	
					dDistToEllipsoidIntersection = _AS::CCollision.IntersectRaySphere(vPolyIPoint, -vNormalizedVelocity, vSource, 1.f);

					if (dDistToEllipsoidIntersection > 0) { // Calculate true sphere intersection point
     					vSIPoint.fX = (float) (vPolyIPoint.fX + dDistToEllipsoidIntersection * (-vNormalizedVelocity.fX));
     					vSIPoint.fY = (float) (vPolyIPoint.fY + dDistToEllipsoidIntersection * (-vNormalizedVelocity.fY));
     					vSIPoint.fZ = (float) (vPolyIPoint.fZ + dDistToEllipsoidIntersection * (-vNormalizedVelocity.fZ));
					}
				} 

  				// Here we do the error checking to see if we got ourself stuck last frame
   				if (_AS::CCollision.IsPointInSphere(vPolyIPoint, vSource, 1.f))  {
					CCollisionPacked.vLastSphereCollisionPoint = vSIPoint;
					CCollisionPacked.bStuck = true;
				}
				
				// Ok, now we might update the collision data if we hit something
				if ((dDistToEllipsoidIntersection > 0) && (dDistToEllipsoidIntersection <= dDistanceToTravel)) {
					if ((!CCollisionPacked.bFoundCollision) || (dDistToEllipsoidIntersection < CCollisionPacked.dNearestDistance)) {
						// If we are hit we have a closest hit so far. We save the information
						CCollisionPacked.dNearestDistance				  = dDistToEllipsoidIntersection;
						CCollisionPacked.vNearestIntersectionPoint		  = vSIPoint;
						CCollisionPacked.vNearestPolygonIntersectionPoint = vPolyIPoint;
						CCollisionPacked.bFoundCollision				  = CCollisionPacked.bFoundACollision = true;
						CCollisionPacked.vLastSphereCollisionPoint		  = vSIPoint;
					}
				} 
			}
		}
	}
}
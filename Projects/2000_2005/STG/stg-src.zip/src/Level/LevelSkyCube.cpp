/*
	File: LevelSkyCube.cpp
*/

#include <ASEngine.h>
#include "Level.h"


/*
	Initializes the sky cube
*/
void TLevelSkyCube::Init()
{
	m_bActive = true;
	m_fColor[R] = m_fColor[G] = m_fColor[B] = 1.f;
	m_fSize[X] = m_fSize[Y] = m_fSize[Z] = 1.f;

	// Load sky cube textures
	m_pCTextureLeft.Load("sky_left.jpg");
	m_pCTextureTop.Load("sky_top.jpg");
	m_pCTextureRight.Load("sky_right.jpg");
	m_pCTextureBottom.Load("sky_bottom.jpg");
	m_pCTextureFloor.Load("sky_floor.jpg");
	m_pCTextureFront.Load("sky_front.jpg");
}

/*
	De-initializes the sky cube
*/
void TLevelSkyCube::DeInit()
{
	// Unload sky cube textures
	m_pCTextureLeft.Unload();
	m_pCTextureTop.Unload();
	m_pCTextureRight.Unload();
	m_pCTextureBottom.Unload();
	m_pCTextureFloor.Unload();
	m_pCTextureFront.Unload();
}

/*
	Draws the sky cube
*/
void TLevelSkyCube::Draw()
{
	if (!m_bActive) return;

	glColor3fv(m_fColor);
	glScalef(m_fSize[X] * 10, m_fSize[Y] * 10, m_fSize[Z] * 10);
	glCallList(m_iSkyCubeList);
}
/*
	File: LevelField.h
	Description: Field management
*/

#ifndef __LEVELFIELD_H__
#define __LEVELFIELD_H__


// Predefinitions
typedef class TLevelQuadtree TLevelQuadtree;


// Definitions
#define FIELDSIZE_X 10.f
#define FIELDSIZE_Y 10.f


// Classes
typedef class TLevelField {

	friend TLevel;
	friend TLevelFieldManager;
	friend TLevelQuadtree;
	friend TLevelGeometry;

	public:
		/*
			Activates / deactivates the field

			Parameters:
				bool bActive -> Should the field be active?
		*/
		void SetActive(const bool bActive = true);


	private:
		TLevelFieldManager* m_pCFieldManager;	// Pointer to the owner field manager

		int    m_iID;		// The field ID
		ASINT2 m_iPos;		// The field position in the level matrix 
		bool   m_bActive;	// Is this field active?
		bool   m_bUpdate;	// Should the field be updated?

		ASINT4	 m_iVertex;		// Indices to the 4 vertices of the field
		ASTPlane m_CPlane[2];	// The two field planes

		// Visiblity
		bool	 m_bInFrustum;		// Is this field in the frustum?
		ASFLOAT3 m_fBoundingBox[2]; // The fields bounding box min/max

		// Cliff (left, top, right, bottom)
		bool m_bCliffActive[4];		// Is the cliff active?
		int  m_iCliffVertex[4][4];	// Cliff vertex indices


		/*
			Calculate the field planes
		*/
		void CalculatePlanes();

		/*
			Calculate the normals of all field vertices
		*/
		void CalculateVerticesNormals();

		/*
			Calculates the bounding boxes of the field
		*/
		void CalculateBoundingBox();

		/*
			Updates the field
		*/
		void Update();


} TLevelField;


#endif // __LEVELFIELD_H__
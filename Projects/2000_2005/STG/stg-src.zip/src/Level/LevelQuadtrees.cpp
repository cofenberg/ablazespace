/*
	File: LevelQuadtrees.cpp
*/

#include <ASEngine.h>
#include "Level.h"


/*
	Create the quadtrees for a level
*/
bool TLevelQuadtree::Build(TLevelFieldManager* pCFieldManager)
{
	TLevelQuadtree* pCQuadtree;
	TLevelField* pCField;
	int i, iX, iY;
	ASINT2 iHalfSize;

	// Check pointer
	if (!pCFieldManager) return true;

	// Setup data
	m_pCFieldManager = pCFieldManager;

	// Setup quadtree information
	if (!m_pCParent)  // That's the topmost quadtree
		Init(NULL, 0, 0, m_pCFieldManager->m_iSize[X], m_pCFieldManager->m_iSize[Y]);

	// Setup field pointers
	pCField = m_pCFieldManager->m_pCField;
	for (iY = 0; iY < m_iSize[Y]; iY++)
		for (iX = 0; iX < m_iSize[X]; iX++)
			m_pCField[iX + iY * m_iSize[X]] = &pCField[pCFieldManager->GetID(m_iStartPos[X] + iX, m_iStartPos[Y] + iY)];
	
	// Get the number of children
	if (m_iSize[X] > 3) m_iChildren += 2;
	if (m_iSize[Y] > 3) m_iChildren += 2;
	
	// Setup children
	if (m_iChildren) {
		// Allocate memory
		m_pCChild = new TLevelQuadtree[m_iChildren];
		
		// Get the half fields size
		for (i = 0; i < 2; i++) {
			if (m_iSize[i] > 3) iHalfSize[i] = m_iSize[i] / 2;
			else iHalfSize[i] = m_iSize[i];
		}

		pCQuadtree = &m_pCChild[0];
		pCQuadtree->Init(this, m_iStartPos[X], m_iStartPos[Y], iHalfSize[X], iHalfSize[Y]);
		pCQuadtree->Build(m_pCFieldManager);
		pCQuadtree++;
		if (m_iSize[X] > 3) {
			pCQuadtree->Init(this, m_iStartPos[X] + iHalfSize[X], m_iStartPos[Y], m_iSize[X] - iHalfSize[X], iHalfSize[Y]);
			pCQuadtree->Build(m_pCFieldManager);
			pCQuadtree++;
		}
		if (m_iSize[Y] > 3) {
			pCQuadtree->Init(this, m_iStartPos[X] + iHalfSize[X], m_iStartPos[Y] + iHalfSize[Y], m_iSize[X] - iHalfSize[X], m_iSize[Y] - iHalfSize[Y]);
			pCQuadtree->Build(m_pCFieldManager);
			pCQuadtree++;
			if (m_iSize[X] > 3) {
				pCQuadtree->Init(this, m_iStartPos[X], m_iStartPos[Y] + iHalfSize[Y], iHalfSize[X], m_iSize[Y] - iHalfSize[Y]);
				pCQuadtree->Build(m_pCFieldManager);
			}
		}
	}

	if (!m_pCParent) {
		ComputeBoundingBox();
		SetNotInFrustum();
	}

	return false;
}

/*
	Destroy the quadtrees
*/
void TLevelQuadtree::Destroy()
{
	for (int iChild = 0; iChild < m_iChildren; iChild++) m_pCChild[iChild].Destroy();
	if (m_pCChild) {
		delete [] m_pCChild;
		m_pCChild = NULL;
	}
	m_iChildren	= 0;

	if (m_pCField) {
		delete [] m_pCField;
		m_pCField = NULL;
	}
}

/*
	Updates the visibility
*/
void TLevelQuadtree::UpdateVisibility()
{
	// Update quadtrees visibility
	CheckInFrustum();
	
	// Update fields visibility
	CheckFieldsInFrustum();
}

/*
	Draw the quadtrees bounding boxes
*/
void TLevelQuadtree::ShowBoundingBox()
{
	// Draw children bounding boxes
	for (int iChild = 0; iChild < m_iChildren; iChild++) m_pCChild[iChild].ShowBoundingBox();

	if (!m_pCParent) glColor3f(1.0f, 0.0f, 1.0f);
	else glColor3f(1.0f, 1.0f, 1.0f);

	_AS::CRenderer.ShowBoundingBox(m_fBoundingBox);
}

/*
	Initializes a quadtree
*/
bool TLevelQuadtree::Init(TLevelQuadtree* pCParent, const int iStartPosX, const int iStartPosY, const int iSizeX, const int iSizeY)
{
	m_iChildren    = 0;
	m_pCChild	   = NULL;
	m_pCParent	   = pCParent;

	m_bInFrustum = false;
	memset(&m_fBoundingBox, 0, sizeof(ASBOUNDINGBOX));

	m_iStartPos[X] = iStartPosX;
	m_iStartPos[Y] = iStartPosY;
	m_iSize[X]	   = iSizeX;
	m_iSize[Y]	   = iSizeY;
	m_iFields	   = m_iSize[X] * m_iSize[Y];

	// Allocate memory
	if (!(m_pCField = (TLevelField**) malloc(sizeof(TLevelField*) * m_iFields)))
		return true;

	return false;
}

/*
	Update the visibility state of all fields
*/
void TLevelQuadtree::CheckFieldsInFrustum()
{
	// Main quadtree
	if (!m_pCParent) SetFieldsInFrustum();

	// Is this quadtree invisible?
	if (!m_bInFrustum) { // Nope, all fields in it are not visible
		for (int i = 0; i < m_iFields; i++) m_pCField[i]->m_bInFrustum = false;

		return;
	}

	// Check, if it's complete in the field of view:
	if(_AS::CFrustum.IsPointIn(m_fBoundingBox[0][X], m_fBoundingBox[0][Y], m_fBoundingBox[0][Z]) &&
	   _AS::CFrustum.IsPointIn(m_fBoundingBox[1][X], m_fBoundingBox[0][Y], m_fBoundingBox[0][Z]) &&
	   _AS::CFrustum.IsPointIn(m_fBoundingBox[1][X], m_fBoundingBox[1][Y], m_fBoundingBox[0][Z]) &&
	   _AS::CFrustum.IsPointIn(m_fBoundingBox[0][X], m_fBoundingBox[1][Y], m_fBoundingBox[0][Z]) &&
	   _AS::CFrustum.IsPointIn(m_fBoundingBox[0][X], m_fBoundingBox[0][Y], m_fBoundingBox[1][Z]) &&
	   _AS::CFrustum.IsPointIn(m_fBoundingBox[1][X], m_fBoundingBox[0][Y], m_fBoundingBox[1][Z]) &&
	   _AS::CFrustum.IsPointIn(m_fBoundingBox[1][X], m_fBoundingBox[1][Y], m_fBoundingBox[1][Z]) &&
	   _AS::CFrustum.IsPointIn(m_fBoundingBox[0][X], m_fBoundingBox[1][Y], m_fBoundingBox[1][Z]))
		return;  // Yep, it's complete in the Frustum
		
	if (!m_iChildren) { // There are no children, check now each field itself
		TLevelField *pCFieldT;
		
		for (int i = 0; i < m_iFields; i++) {
			pCFieldT = m_pCField[i];
			if (!_AS::CFrustum.IsCubeIn(pCFieldT->m_fBoundingBox))
				pCFieldT->m_bInFrustum = false;
		}

		return;
	}

	for (int iChild = 0; iChild < m_iChildren; iChild++) m_pCChild[iChild].CheckFieldsInFrustum();
}

/*
	All child quadtrees are not in the frustum
*/
void TLevelQuadtree::SetNotInFrustum()
{
	m_bInFrustum = false;
	for(int iChild = 0; iChild < m_iChildren; iChild++) m_pCChild[iChild].SetNotInFrustum();
}

/*
	All child quadtrees are in the frustum
*/
void TLevelQuadtree::SetFieldsInFrustum()
{
	for (int i = 0; i < m_iFields; i++) m_pCField[i]->m_bInFrustum = true;
}

void TLevelQuadtree::CheckInFrustum()
{
	if (!m_pCParent) SetNotInFrustum(); // Topmost quadtree:

	// Check if this quadtree is in the Frustum
	if (!(_AS::CFrustum.IsCubeIn(m_fBoundingBox)))
		return; // Not visible!
	
	// It's visible, check now the child quadtrees:
	m_bInFrustum = true;
	for (int iChild = 0; iChild < m_iChildren; iChild++)
		m_pCChild[iChild].CheckInFrustum();
}

/*
	Computes the bounding box of the quadtree
*/
void TLevelQuadtree::ComputeBoundingBox()
{
	TLevelField *pCFieldT;
	int i, iField;

	if (!m_pCField) return;

	// Initialize bounding box:
	m_fBoundingBox[0][X] = m_fBoundingBox[0][Y] = m_fBoundingBox[0][Z] = 10000.0f;
	m_fBoundingBox[1][X] = m_fBoundingBox[1][Y] = m_fBoundingBox[1][Z] = -10000.0f;

	// Get bounding box
	for (iField = 0; iField < m_iFields; iField++) {
		pCFieldT = m_pCField[iField];

		for (i = 0; i < 3; i++) {
			if (m_fBoundingBox[0][i] > pCFieldT->m_fBoundingBox[0][i])
				m_fBoundingBox[0][i] = pCFieldT->m_fBoundingBox[0][i];
			if (m_fBoundingBox[1][i] < pCFieldT->m_fBoundingBox[1][i])
				m_fBoundingBox[1][i] = pCFieldT->m_fBoundingBox[1][i];
		}
	}

	// Get children bounding boxes
	for (int iChild = 0; iChild < m_iChildren; iChild++) m_pCChild[iChild].ComputeBoundingBox();
}
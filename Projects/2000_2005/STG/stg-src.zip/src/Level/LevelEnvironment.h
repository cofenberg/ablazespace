/*
	File: LevelEnvironment.h
	Description: The level environment
*/

#ifndef __LEVELENVIRONMENT_H__
#define __LEVELENVIRONMENT_H__


// Predefinitions
typedef class TLevelEnvironment TLevelEnvironment;


// Includes
#include "LevelSkyCube.h"


// Classes
typedef class TLevelEnvironment {

	friend TLevel;

	public:
		/*
			Draws the environment
		*/
		void Draw();


	private:
		TLevelSkyCube m_CSkyCube;		// Envionment sky cube


		/*
			Initializes the levels environment
		*/
		void Init();

		/*
			De-initializes the levels environment
		*/
		void DeInit();


} TLevelEnvironment;


#endif // __LEVELENVIRONMENT_H__
//-----------------------------------------------------------------------------
// File: Terrain.h
//-----------------------------------------------------------------------------

#ifndef __TERRAIN_H__
#define __TERRAIN_H__


// Definitions: ***************************************************************
#define WRAP_INDEX	256
#define MOD_MASK	255
#define MAX			4096
///////////////////////////////////////////////////////////////////////////////


/*	Definition of Terms: (cf. Matt Zucker; Ken Perlin)

	Noise Function: a function that takes a coordinate in some space and maps
	it to a real number between -1 and 1 (or between 0 and 1).

	Wavelet: a functions which drops off to zero outside of some region, and
	which integrates to zero. The radius of a wavelet simply refers to the
	distance in its domain space from the wavelet center to where its value
	drops off to zero.

	Perlin Noise: a function for generating coherent noise over a space. Coherent
	noise means that for any two points in the space, the value of the noise
	function changes smoothly as you move from one point to the other--no 
	discontinuities. The key to understanding the algorithm is to think of
	space as being divided into a regular lattice of cubical cels, with one
	pseudorandom wavelet per lattice point. 

*/

// Classes: *******************************************************************
class PERLIN_NOISE
{
	public:
		BOOL m_bInitialized;
		unsigned m_iPermutation[WRAP_INDEX * 2 + 2];	// Lattice table
		float m_fGradient1D[WRAP_INDEX * 2 + 2]; // Gradient tables
		ASTVector2D m_fGradient2D[WRAP_INDEX * 2 + 2];
		ASTVector3D m_fGradient3D[WRAP_INDEX * 2 + 2];


		PERLIN_NOISE(void);
		~PERLIN_NOISE(void);
		float RandomPNFloat(void); // Range [-1,1]
		void GenerateLookupTables(void);
		void ReSeed(void);
		float SCurve(float);
		float LinearInterpolation(float, float, float);
		void ComputeDistanceToLatticePoints(float, int &, int &, float &, float &);
		float PNoise1D(float);
		float PNoise2D(ASTVector2D);
		float PNoise3D(ASTVector3D);

};
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern PERLIN_NOISE PerlinNoise;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern float fBm(ASTVector3D, float, float, float);
extern float fBmTurbulence(ASTVector3D, float, float, float);
extern float HeteroMultiFractal(ASTVector3D, float, float, float, float);
extern float HybridMultiFractal(ASTVector3D, float, float, float, float);
extern float RidgedMultiFractal(ASTVector3D, float, float, float, float, float);
extern float MultiFractal(ASTVector3D, float, float, float, float);
///////////////////////////////////////////////////////////////////////////////


#endif // __TERRAIN_H__
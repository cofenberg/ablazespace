/*
	File: Level.cpp
*/

#include <ASEngine.h>
#include "Level.h"
#include "..\Game.h"
#include "..\ParticleGroups\ParticleGroupDecoration.h"


/*
	Constructor
*/
TLevel::TLevel(const int iXSize, const int iYSize)
{
	Init();
	Create(iXSize, iYSize);
}

/*
	Destructor
*/
TLevel::~TLevel()
{
	Destroy();
}

/*
	Creates a level
*/
bool TLevel::Create(const int iXSize, const int iYSize)
{
	ASTProgressWindow CProgressWindow;
	ASTEntity* pCEntityT[5];
	ASTEntity* pCEntity;
	bool bError = false;
	int i = 0;

	// Setup progress window
	CProgressWindow.Create("Create level");
	CProgressWindow.SetTask("Initializing");
	CProgressWindow.SetProgress(0);

	// Destroy old level
	Destroy();
	Init();

	CGame.pCLevel = this;
	fTime = 15.f;

	// Create new one
	_AS::CLog.Output("Create level");
	CProgressWindow.SetTask("Create data");
	CProgressWindow.SetProgress(5);
	if (CFieldManager.Init(this, iXSize, iYSize)) return true;

	// Load sounds
    m_CTime1Sound.Load("lowscore_1.mp3");
    m_CTime2Sound.Load("lowscore_2.mp3");

	// Load level textures
	CProgressWindow.SetTask("Load textures");
	CProgressWindow.SetProgress(60);
	m_CTerrainTexture.Load(STANDARDTERRAINTEXTURE);
	  m_CCliffTexture.Load("cliff.tga");
	 m_CShadowTexture.Load("shadowmap.jpg");
	  m_CPlantTexture.Load("plant.tga");

	// Initialize environment
	CEnvironment.Init();

	// Initialize actors
	iCrystals  = 0;
	iTurtles    = 0;
	iMosquitos = 0;
	CProgressWindow.SetTask("Create entities");
	CProgressWindow.SetProgress(70);

	// Url actor
	ASCreateEntity(pCEntity, TActorUrl, "Url");
//	pCEntity->SetFlags(ASeEntityFlagDebug);

	// Vortex entity
	ASCreateEntity(pCEntity, TEntityVortex, "Vortex");

	// Get game relevant entities
	pCEntityT[0] = pCEntity;
	pCEntityT[1] = _AS::CEntityManager.Get("Tester_1.jpg");
	pCEntityT[2] = _AS::CEntityManager.Get("Tester_2.jpg");
	pCEntityT[3] = _AS::CEntityManager.Get("Tester_3.jpg");
	pCEntityT[4] = _AS::CEntityManager.Get("Tester_4.jpg");

	// Moskito entity
	if (!bCheatNoMosquitos) ASCreateEntity(pCEntity, TEntityMosquitos, "Mosquitos");

	{ // Create decoration particles
		TParticleGroupDecoration* pCEntity;

		// Initialize particle systems
		ASCreateEntity(pCEntity, TParticleGroupDecoration, "Fungus particles");
		pCEntity->InitParticleGroup(20 + rand() % 20, "fungus.tga");
		pCEntity->SetBlending(false);
	}

	{ // Create planes
		float fX, fY, fZ, fScale;
		TLevelPlant* pSPlant;
		int i, i2;

		m_iPlants  = 350 + rand() % 100;
		m_pSPlants = new TLevelPlant[m_iPlants];
		for (i = 0; i < m_iPlants; i++) {
			pSPlant = &m_pSPlants[i];
			for (;;) {
				fX = (float) (rand() % 16000) / 100;
				if ((rand() % 2)) fX = -fX;
				fY = (float) (rand() % 16000) / 100;
				if ((rand() % 2)) fY = -fY;
				for (i2 = 0; i2 < 5; i2++) {
					if (fX < pCEntityT[i2]->GetPos().fX - pCEntityT[i2]->GetCollisionRadius() ||
						fX > pCEntityT[i2]->GetPos().fX + pCEntityT[i2]->GetCollisionRadius() ||
						fY < pCEntityT[i2]->GetPos().fY - pCEntityT[i2]->GetCollisionRadius() ||
						fY > pCEntityT[i2]->GetPos().fY + pCEntityT[i2]->GetCollisionRadius() ||
						fZ < pCEntityT[i2]->GetPos().fZ - pCEntityT[i2]->GetCollisionRadius() ||
						fZ > pCEntityT[i2]->GetPos().fZ + pCEntityT[i2]->GetCollisionRadius())
						continue;
					break;
				}
				if (i2 != 5) continue;
				if ((pSPlant->pCField = GetHeight(fX, fY, fZ))) break;
			}
			pSPlant->fPosX = fX;
			pSPlant->fPosY = fY;
			fScale = 0.8f + (float) (rand() % 100) / 40;
			if (!(rand() % 2)) {
				pSPlant->fScaleX = 0.4f + ((float) (rand() % 100) / 90 * fScale);
				pSPlant->fScaleY = 0.4f + ((float) (rand() % 100) / 90 * fScale);
				pSPlant->fScaleZ = 0.3f + ((float) (rand() % 100) / 80 * fScale);
			} else {
				pSPlant->fScaleX = 0.6f + ((float) (rand() % 100) / 70 * fScale);
				pSPlant->fScaleY = 0.6f + ((float) (rand() % 100) / 70 * fScale);
				pSPlant->fScaleZ = 0.5f + ((float) (rand() % 100) / 50 * fScale);
			}
			pSPlant->fPosZ = fZ + pSPlant->fScaleZ / 2;
		}
	}

	{ // Create funguses
		int i, i2, iNumber = (int) ((15 + rand() % 15) * CConfig.GetLevelDetail());
		float fX, fY, fZ, fScale;

		for (i = 0; i < iNumber; i++) {
			for (;;) {
				fX = (float) (rand() % 16000) / 100;
				if ((rand() % 2)) fX = -fX;
				fY = (float) (rand() % 16000) / 100;
				if ((rand() % 2)) fY = -fY;
				for (i2 = 0; i2 < 5; i2++) {
					if (fX < pCEntityT[i2]->GetPos().fX - pCEntityT[i2]->GetCollisionRadius() ||
						fX > pCEntityT[i2]->GetPos().fX + pCEntityT[i2]->GetCollisionRadius() ||
						fY < pCEntityT[i2]->GetPos().fY - pCEntityT[i2]->GetCollisionRadius() ||
						fY > pCEntityT[i2]->GetPos().fY + pCEntityT[i2]->GetCollisionRadius() ||
						fZ < pCEntityT[i2]->GetPos().fZ - pCEntityT[i2]->GetCollisionRadius() ||
						fZ > pCEntityT[i2]->GetPos().fZ + pCEntityT[i2]->GetCollisionRadius())
						continue;
					break;
				}
				if (i2 != 5) continue;
				if (GetHeight(fX, fY, fZ)) break;
			}
			i2 = rand() % 3;
			switch (i2) {
				case 0: ASCreateEntity(pCEntity, TEntityDecoration, "fungus_1.md2"); break;
				case 1: ASCreateEntity(pCEntity, TEntityDecoration, "fungus_2.md2"); break;
				case 2: ASCreateEntity(pCEntity, TEntityDecoration, "funguses.md2"); break;
			}
			pCEntity->SetPos(fX, fY, fZ);
			fScale = 0.8f + (float) (rand() % 100) / 40;
			if (!i2) fScale *= 4;
			pCEntity->SetScale((0.9f + (float) (rand() % 100) / 90) * fScale,
							   (0.9f + (float) (rand() % 100) / 90) * fScale,
							   (0.8f + (float) (rand() % 100) / 80) * fScale);
			((TEntityDecoration*) pCEntity)->AddModelMeshToLevel();
		}
	}

	{ // Create stones
		int i, i2, iNumber = (int) ((30 + rand() % 10) * CConfig.GetLevelDetail());
		float fX, fY, fZ;

		for (i = 0; i < iNumber; i++) {
			for (;;) {
				fX = (float) (rand() % 16000) / 100;
				if ((rand() % 2)) fX = -fX;
				fY = (float) (rand() % 16000) / 100;
				if ((rand() % 2)) fY = -fY;
				for (i2 = 0; i2 < 5; i2++) {
					if (fX < pCEntityT[i2]->GetPos().fX - pCEntityT[i2]->GetCollisionRadius() * 10 ||
						fX > pCEntityT[i2]->GetPos().fX + pCEntityT[i2]->GetCollisionRadius() * 10 ||
						fY < pCEntityT[i2]->GetPos().fY - pCEntityT[i2]->GetCollisionRadius() * 10 ||
						fY > pCEntityT[i2]->GetPos().fY + pCEntityT[i2]->GetCollisionRadius() * 10 ||
						fZ < pCEntityT[i2]->GetPos().fZ - pCEntityT[i2]->GetCollisionRadius() * 10 ||
						fZ > pCEntityT[i2]->GetPos().fZ + pCEntityT[i2]->GetCollisionRadius() * 10)
						continue;
					break;
				}
				if (i2 != 5)
					continue;
				if (GetHeight(fX, fY, fZ)) break;
			}
			ASCreateEntity(pCEntity, TEntityDecoration, "stone.md2");
			pCEntity->SetPos(fX, fY, fZ);
			if (!(rand() % 2))
				pCEntity->SetScale(0.2f + (float) (rand() % 100) / 60,
								   0.2f + (float) (rand() % 100) / 60,
								   0.2f + (float) (rand() % 100) / 60);
			else
				pCEntity->SetScale(0.7f + (float) (rand() % 100) / 20,
								   0.7f + (float) (rand() % 100) / 20,
								   0.7f + (float) (rand() % 100) / 20);
			((TEntityDecoration*) pCEntity)->AddModelMeshToLevel();
		}
	}

	{ // Create crystals
		float fX, fY, fZ;
		int i, i2, iNumber;

		if (bCheatQuick) iNumber = 10;
		else			 iNumber = 30;
		for (i = 0; i < iNumber; i++) {
			for (;;) {
				fX = (float) (rand() % 16000) / 100;
				if ((rand() % 2)) fX = -fX;
				fY = (float) (rand() % 16000) / 100;
				if ((rand() % 2)) fY = -fY;
				for (i2 = 0; i2 < 5; i2++) {
					if (fX < pCEntityT[i2]->GetPos().fX - pCEntityT[i2]->GetCollisionRadius() ||
						fX > pCEntityT[i2]->GetPos().fX + pCEntityT[i2]->GetCollisionRadius() ||
						fY < pCEntityT[i2]->GetPos().fY - pCEntityT[i2]->GetCollisionRadius() ||
						fY > pCEntityT[i2]->GetPos().fY + pCEntityT[i2]->GetCollisionRadius() ||
						fZ < pCEntityT[i2]->GetPos().fZ - pCEntityT[i2]->GetCollisionRadius() ||
						fZ > pCEntityT[i2]->GetPos().fZ + pCEntityT[i2]->GetCollisionRadius())
						continue;
					break;
				}
				if (i2 != 5) continue;
				if (GetHeight(fX, fY, fZ)) break;
			}
			fZ -= 4 + ((float) (rand() % 1000) / 100);
			ASCreateEntity(pCEntity, TEntityCrystal, "Crystal");
			pCEntity->SetPos(fX, fY, fZ);
		}
	}

	{ // Create butterflys
		int i, i2, iNumber = (int) ((35 + rand() % 25) * CConfig.GetLevelDetail());
		float fX, fY, fZ;

		for (i = 0; i < iNumber; i++) {
			for (;;) {
				fX = (float) (rand() % 16000) / 100;
				if ((rand() % 2)) fX = -fX;
				fY = (float) (rand() % 16000) / 100;
				if ((rand() % 2)) fY = -fY;
				for (i2 = 0; i2 < 5; i2++) {
					if (fX < pCEntityT[i2]->GetPos().fX - pCEntityT[i2]->GetCollisionRadius() ||
						fX > pCEntityT[i2]->GetPos().fX + pCEntityT[i2]->GetCollisionRadius() ||
						fY < pCEntityT[i2]->GetPos().fY - pCEntityT[i2]->GetCollisionRadius() ||
						fY > pCEntityT[i2]->GetPos().fY + pCEntityT[i2]->GetCollisionRadius() ||
						fZ < pCEntityT[i2]->GetPos().fZ - pCEntityT[i2]->GetCollisionRadius() ||
						fZ > pCEntityT[i2]->GetPos().fZ + pCEntityT[i2]->GetCollisionRadius())
						continue;
					break;
				}
				if (i2 != 5) continue;
				if (GetHeight(fX, fY, fZ)) break;
			}
			ASCreateEntity(pCEntity, TEntityButterfly, "Butterfly");
			fZ -= 4 + ((float) (rand() % 1000) / 100);
			pCEntity->SetPos(fX, fY, fZ);
			pCEntity->SetScale(0.4f + (float) (rand() % 100) / 200,
							   0.4f + (float) (rand() % 100) / 200,
							   0.4f + (float) (rand() % 100) / 200);
		}
	}

	if (!bCheatNoTurtles) { // Create turtles
		float fX, fY, fZ;
		int i, i2, iNumber;

		if (bCheatQuick) iNumber = 5;
		else			 iNumber = 10;
		for (i = 0; i < iNumber; i++) {
			for (;;) {
				fX = (float) (rand() % 16000) / 100;
				if ((rand() % 2)) fX = -fX;
				fY = (float) (rand() % 16000) / 100;
				if ((rand() % 2)) fY = -fY;
				for (i2 = 0; i2 < 5; i2++) {
					if (fX < pCEntityT[i2]->GetPos().fX - pCEntityT[i2]->GetCollisionRadius() ||
						fX > pCEntityT[i2]->GetPos().fX + pCEntityT[i2]->GetCollisionRadius() ||
						fY < pCEntityT[i2]->GetPos().fY - pCEntityT[i2]->GetCollisionRadius() ||
						fY > pCEntityT[i2]->GetPos().fY + pCEntityT[i2]->GetCollisionRadius() ||
						fZ < pCEntityT[i2]->GetPos().fZ - pCEntityT[i2]->GetCollisionRadius() ||
						fZ > pCEntityT[i2]->GetPos().fZ + pCEntityT[i2]->GetCollisionRadius())
						continue;
					break;
				}
				if (i2 != 5) continue;
				if (GetHeight(fX, fY, fZ, false, true)) break;
			}
			ASCreateEntity(pCEntity, TActorTurtle, "Turtle");
			pCEntity->SetPos(fX, fY, fZ);
		}
	}
	
	{ // Create dust particle group
		TParticleGroupDust* pCEntity;

		// Initialize particle systems
		ASCreateEntity(pCEntity, TParticleGroupDust, "Dust particles");
		pCEntity->InitParticleGroup(100, "particle_dust.jpg");
		pCEntity->SetupTextureAnimation(4, 4);
		CParticleGroupDust.Load(pCEntity);
	}

	// Initialize renderer stuff
	CProgressWindow.SetTask("Initialize renderer stuff");
	CProgressWindow.SetProgress(90);
	RendererInit();

	CProgressWindow.SetTask("Done");
	CProgressWindow.SetProgress(100);

	return false;
}

/*
	Destroys a level
*/
bool TLevel::Destroy()
{
	_AS::CLog.Output("Destroy level");

	// De-initialize renderer stuff
	RendererDeInit();

	// Destroy collision mesh
	m_lstCollisionMesh.Clear();

	// Unload particle groups
	CParticleGroupDust.Unload();

	// Clear entity manager
	_AS::CEntityManager.Clear();

	// Unload sounds
    m_CTime1Sound.Unload();
    m_CTime2Sound.Unload();

	// Destroy plants
	if (m_pSPlants) {
		delete m_pSPlants;
		m_pSPlants = NULL;
	}

	// De-initialize field manager
	if (CFieldManager.DeInit()) return true;

	// Unload level textures
	_AS::CLog.Output("10");
	m_CTerrainTexture.Unload();
	  m_CCliffTexture.Unload();
	 m_CShadowTexture.Unload();
	  m_CPlantTexture.Unload();

	_AS::CLog.Output("11");
	// De-initialize environment
	CEnvironment.DeInit();
	_AS::CLog.Output("12");

	return false;
}

/*
	Updates the level
*/
void TLevel::Update()
{
	if (!bCheatNoTimeLimit && !_AS::CTimer.IsPaused()) {
		// Decrease time
		fTime -= _AS::CTimer.GetTimeDifference();
		if (fTime < 0.f) {
			fTime = 0.f;
			CGame.GameOver();
		}
		if (fTime < 2.f)	  m_CTime2Sound.Play();
		else if (fTime < 4.f) m_CTime1Sound.Play();
	}
}

/*
	Level renderer initialization function
*/
void TLevel::RendererInit()
{
	m_iPlantList = glGenLists(2);
	glNewList(m_iPlantList, GL_COMPILE);
		glBegin(GL_QUADS);
			glTexCoord2f(1.f, 1.f);
			glVertex3f(-1.f, 0.f, -2.f);
			glTexCoord2f(0.f, 1.f);
			glVertex3f(1.f, 0.f,-2.f);
			glTexCoord2f(0.f, 0.f);
			glVertex3f(1.f, 0.f, 0.f);
			glTexCoord2f(1.f, 0.f);
			glVertex3f(-1.f, 0.f, 0.f);

			glTexCoord2f(1.f, 1.f);
			glVertex3f(0.f, -1.f, -2.f);
			glTexCoord2f(0.f, 1.f);
			glVertex3f(0.f, 1.f, -2.f);
			glTexCoord2f(0.f, 0.f);
			glVertex3f(0.f, 1.f, 0.f);
			glTexCoord2f(1.f, 0.f);
			glVertex3f(0.f, -1.f, 0.f);
		glEnd();
	glEndList();
	CEnvironment.m_CSkyCube.m_iSkyCubeList = m_iPlantList + 1;
	glNewList(CEnvironment.m_CSkyCube.m_iSkyCubeList, GL_COMPILE);
	{
		// Setup texture coordinates
		ASFLOAT3 fSkyPoints[8] = 
		{
			{-1.f, -1.f, -1.f}, // 0
			{ 1.f, -1.f, -1.f}, // 1
			{ 1.f,  1.f, -1.f}, // 2
			{-1.f,  1.f, -1.f}, // 3
			{-1.f, -1.f,  1.f}, // 4
			{ 1.f, -1.f,  1.f}, // 5
			{ 1.f,  1.f,  1.f}, // 6
			{-1.f,  1.f,  1.f}, // 7
		};
		ASFLOAT2 fTexCoord1, fTexCoord2, fTexCoord3, fTexCoord4;

		fTexCoord1[X] = 0.f;
		fTexCoord1[Y] = 0.f;
		fTexCoord2[X] = 1.f;
		fTexCoord2[Y] = 0.f;
		fTexCoord3[X] = 1.f;
		fTexCoord3[Y] = 1.f;
		fTexCoord4[X] = 0.f;
		fTexCoord4[Y] = 1.f;

		glEnable(GL_TEXTURE_2D);
		glDisable(GL_LIGHTING);
		glDisable(GL_CULL_FACE);
		glDisable(GL_DEPTH_TEST);
		glDisable(GL_BLEND);
		glDisable(GL_FOG);
		glEnableClientState(GL_VERTEX_ARRAY);
		glDisableClientState(GL_NORMAL_ARRAY);
		glDisableClientState(GL_COLOR_ARRAY);
		glDisableClientState(GL_TEXTURE_COORD_ARRAY);

		glVertexPointer(3, GL_FLOAT, 0, fSkyPoints);
		// Left
		CEnvironment.m_CSkyCube.m_pCTextureLeft.GetTexture()->BindOpenGLTexture();
		glBegin(GL_QUADS);
			glTexCoord2fv(fTexCoord1); glArrayElement(7);
			glTexCoord2fv(fTexCoord2); glArrayElement(4);
			glTexCoord2fv(fTexCoord3); glArrayElement(0);
			glTexCoord2fv(fTexCoord4); glArrayElement(3);
		glEnd();

		// Top
		CEnvironment.m_CSkyCube.m_pCTextureTop.GetTexture()->BindOpenGLTexture();
		glBegin(GL_QUADS);
			glTexCoord2fv(fTexCoord4); glArrayElement(0);
			glTexCoord2fv(fTexCoord3); glArrayElement(1);
			glTexCoord2fv(fTexCoord2); glArrayElement(5);
			glTexCoord2fv(fTexCoord1); glArrayElement(4);
		glEnd();

		// Right
		CEnvironment.m_CSkyCube.m_pCTextureRight.GetTexture()->BindOpenGLTexture();
		glBegin(GL_QUADS);
			glTexCoord2fv(fTexCoord1); glArrayElement(5);
			glTexCoord2fv(fTexCoord2); glArrayElement(6);
			glTexCoord2fv(fTexCoord3); glArrayElement(2);
			glTexCoord2fv(fTexCoord4); glArrayElement(1);
		glEnd();

		// Bottom
		CEnvironment.m_CSkyCube.m_pCTextureBottom.GetTexture()->BindOpenGLTexture();
		glBegin(GL_QUADS);
			glTexCoord2fv(fTexCoord1); glArrayElement(6);
			glTexCoord2fv(fTexCoord2); glArrayElement(7);
			glTexCoord2fv(fTexCoord3); glArrayElement(3);
			glTexCoord2fv(fTexCoord4); glArrayElement(2);
		glEnd();

		// Floor
		CEnvironment.m_CSkyCube.m_pCTextureFloor.GetTexture()->BindOpenGLTexture();
		glBegin(GL_QUADS);
			glTexCoord2fv(fTexCoord1); glArrayElement(7);
			glTexCoord2fv(fTexCoord2); glArrayElement(6);
			glTexCoord2fv(fTexCoord3); glArrayElement(5);
			glTexCoord2fv(fTexCoord4); glArrayElement(4);
		glEnd();

		// Front
		CEnvironment.m_CSkyCube.m_pCTextureFront.GetTexture()->BindOpenGLTexture();
		glBegin(GL_QUADS);
			glTexCoord2fv(fTexCoord1); glArrayElement(2);
			glTexCoord2fv(fTexCoord2); glArrayElement(3);
			glTexCoord2fv(fTexCoord3); glArrayElement(0);
			glTexCoord2fv(fTexCoord4); glArrayElement(1);
		glEnd();

		glEnable(GL_CULL_FACE);
		glEnable(GL_DEPTH_TEST);
		glEnable(GL_FOG);
		glDisableClientState(GL_VERTEX_ARRAY);
	}
	glEndList();
}

/*
	Level renderer de-initialization function
*/
void TLevel::RendererDeInit()
{
	glDeleteLists(m_iPlantList, 2);
}

/*
	Updates the visibility information
*/
void TLevel::UpdateVisibility()
{
	// Update the field visibility
	CFieldManager.UpdateVisibility();

	// Update the geometry visibility
	CGeometry.UpdateVisibility();
}

/*
	Initializes the level
*/
void TLevel::Init()
{
	memset(&CHeader,       0, sizeof(TLevelHeader));
	memset(&CGeometry,     0, sizeof(TLevelGeometry));
	memset(&CFieldManager, 0, sizeof(TLevelFieldManager));
	m_CTerrainTexture.Load();
	  m_CCliffTexture.Load();
	 m_CShadowTexture.Load();
	  m_CPlantTexture.Load();
	m_iPlants  = 0;
	m_pSPlants = NULL;
}
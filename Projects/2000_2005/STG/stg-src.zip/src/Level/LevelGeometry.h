/*
	File: LevelGeometry.h
	Description: Level geometry management
*/

#ifndef __LEVELGEOMETRY_H__
#define __LEVELGEOMETRY_H__


// Definitions
enum EVertexType { // Type of a vertex
	eVertexGeometry, eVertexWater
};


// Classes
typedef class TLevelGeometry {

	friend TLevel;
	friend TLevelFieldManager;
	friend TLevelField;

	public:
		/*
			Calculates the vertex ID of a given vertex position

			Parameters:
				int iX & iY -> Matrix vertex position

			Returns:
				int -> The vertex ID. '-1' if the position is invalid
		*/
		int GetID(const int iX, const int iY) const;

		/*
			Calculates the vertex ID of a given vertex position

			Parameters:
				float fX & fY -> Matrix vertex position

			Returns:
				int -> The vertex ID. '-1' if the position is invalid
		*/
		int GetID(const float fX, const float fY) const;

		/*
			Calculates the vertex position of a level position

			Parameters:
				float fX & fY -> Level position
				int*  iX & iY -> The vertex matrix position

			Returns:
				bool -> 'false' if all went fine else 'true' (invalid position)
		*/
		bool GetPos(const float fX, const float fY, int* iX, int* iY) const;

		/*
			Calculates the level position of a vertex position

			Parameters:
				int    iX & iY -> Matrix vertex position
				float* fX & fY -> The level position

			Returns:
				bool -> 'false' if all went fine else 'true' (invalid position)
		*/
		bool GetLevelPos(const int iX, const int iY, float* fX, float* fY) const;

		/*
			Checks if the given ID is valid

			Parameters:
				int iID-> Matrix vertex ID

			Returns:
				bool -> 'true' if the ID is valid (inside the level) else 'false'
		*/
		bool IsValid(const int iID) const;

		/*
			Checks if the given position is valid

			Parameters:
				int iX & iY -> Matrix vertex position

			Returns:
				bool -> 'true' if the position is valid (inside the level) else 'false'
		*/
		bool IsValid(const int iX, const int iY) const;

		/*
			Checks if the given position is valid

			Parameters:
				float fX & fY -> Matrix vertex position

			Returns:
				bool -> 'true' if the position is valid (inside the level) else 'false'
		*/
		bool IsValid(const float fX, const float fY) const;

		/*
			Performs the level cel-shading
		*/
		void PerformCelShading();


	private:
		TLevel* m_pCLevel;	// Pointer to the owner level

		ASINT2	 m_iSize;			// Vertex grid size
		int		 m_iLevelVertices;	// Number of grid points in one high layer
		int		 m_iVertices;		// Total number of vertices in the grid
		ASFLOAT3 m_fTranslate;		// Vertex translation
		ASFLOAT3 m_fBoundingBox[2];	// Level bounding box

		bool	  m_bUsingHardwareVertexArray;	// Is the hardware vertex array used?
		ASFLOAT3* m_pfVertex;					// Level vertices
		ASFLOAT3* m_pfNormal;					// Normal of each vertex
		ASFLOAT2* m_pfPrimaryTexCoord;			// Primary texture coordinate of each vertex
		float*    m_pfSecondaryTexCoord;		// Secondary texture coordinate of each vertex (for cel shading)

		int	  m_iFrustumVertices;	// Number of vertices which are in the frustum
		bool* m_pbVertexVisible;	// Is the vertex visible or not?
		int*  m_piVisibleVertices;	// A list of all visible vertices (vertex ID's)
		

		/*
			Initializes the level geometry

			Parameters:
				TLevel* pCLevel			-> Pointer to the owner level
				int		iXSize & iYSize -> Vertex grind size

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Init(TLevel* pCLevel, const int iXSize, const int iYSize);

		/*
			De-initializes the level geometry

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool DeInit();
		
		/*
			Computes the levels bounding box
		*/
		void ComputeBoundingBox();

		/*
			Creates a random terrain
		*/
		void CreateRandomTerrain();

		/*
			Computes the cliffs
		*/
		void ComputeCliffs();

		/*
			Updates the visibility information
		*/
		void UpdateVisibility();


} TLevelGeometry;


#endif // __LEVELGEOMETRY_H__
/*
	File: LevelSkyCube.h
	Description: Environment sky cube
*/

#ifndef __LEVELSKYCUBE_H__
#define __LEVELSKYCUBE_H__


// Classes
typedef class TLevelSkyCube {

	friend TLevelEnvironment;
	friend TLevel;

	public:


	private:
		bool     m_bActive;	// Is the sky cube active?
		ASFLOAT3 m_fColor;	// Sky cube color
		ASFLOAT3 m_fSize;	// Size

		ASTTextureHandler m_pCTextureLeft;		// Left sky cube texture
		ASTTextureHandler m_pCTextureTop;		// Top sky cube texture
		ASTTextureHandler m_pCTextureRight;		// Right sky cube texture
		ASTTextureHandler m_pCTextureBottom;	// Bottom sky cube texture
		ASTTextureHandler m_pCTextureFloor;		// Floor sky cube texture
		ASTTextureHandler m_pCTextureFront;		// Front sky cube texture

		int m_iSkyCubeList;	// Sky cube display list


		/*
			Initializes the sky cube
		*/
		void Init();

		/*
			De-initializes the sky cube
		*/
		void DeInit();

		/*
			Draws the sky cube
		*/
		void Draw();


} TLevelSkyCube;


#endif // __LEVELSKYCUBE_H__
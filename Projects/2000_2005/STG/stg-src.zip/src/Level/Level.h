/*
	File: Level.h
	Description: Level management
*/

#ifndef __LEVEL_H__
#define __LEVEL_H__


// Predefinitions
typedef class TLevel TLevel;
typedef class TLevelField TLevelField;
typedef class TLevelFieldManager TLevelFieldManager;


// Definitions
#define STANDARDTERRAINTEXTURE "terraintexture.tga"
enum {
	LEFT, TOP, RIGHT, BOTTOM,
};


// Includes
#include "LevelEnvironment.h"
#include "LevelGeometry.h"
#include "LevelTerrain.h"
#include "LevelFieldManager.h"

#include "..\Entities\ActorUrl.h"
#include "..\Entities\ActorTester.h"
#include "..\Entities\ActorTurtle.h"
#include "..\Entities\EntityVortex.h"
#include "..\Entities\EntityCrystal.h"
#include "..\Entities\EntityMosquitos.h"
#include "..\Entities\EntityButterfly.h"
#include "..\Entities\EntityDecoration.h"

#include "..\ParticleGroups\ParticleGroupDust.h"


// Structures
typedef struct TLevelHeader {

	char m_szFilename[MAX_PATH];	// The level filename
	char m_szName[256];				// Level name (title)

} TLevelHeader;

typedef struct TLevelPlant {
	float fPosX, fPosY, fPosZ;			// Plant position
	float fScaleX, fScaleY, fScaleZ;	// Plant scale
	TLevelField* pCField;				// Field the plant is on

} TLevelPlant;

// Classes
typedef class TLevel {

	friend TLevelFieldManager;
	friend TLevelField;

	public:
		TLevelHeader	    CHeader;		// Level header
		TLevelEnvironment   CEnvironment;	// Environment information
		TLevelGeometry	    CGeometry;		// Geometry
		TLevelFieldManager  CFieldManager;	// Field manager

		ASTEntityHandler CParticleGroupDust;

		int   iCrystals, iTurtles, iMosquitos;
		float fTime;


		/*
			Constructor
		*/
		TLevel(const int iXSize = 32, const int iYSize = 32);

		/*
			Destructor
		*/
		~TLevel();

		/*
			Creates the level

			Parameters:
				int iXSize & iYSize -> Dimension of the level

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Create(const int iXSize = 32, const int iYSize = 32);

		/*
			Destroys the level

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Destroy();

		/*
			Draws the level

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Draw();

		/*
			Draws a shadow

			Parameters:
				ASTVector3D& vPos -> Caster position
				float fSize	   	  -> Shadow size
		*/
		void DrawShadow(const ASTVector3D& vPos, const float fSize);

		/*
			Updates the level
		*/
		void Update();

		/*
			Level renderer initialization function
		*/
		void RendererInit();

		/*
			Level renderer de-initialization function
		*/
		void RendererDeInit();

		/*
			Gets the height at the given position

			Parameters:
				float& pfHeight			-> Stores the height at the given position
				bool   bInActiveToo		-> Check inactive fields, too??
				bool   bNoCollisionMesh -> Isn't it allowed to be in a collision mesh?

			Returns:
				TLevelField* -> Pointer to the field were the given height was found.
								NULL if there is no height
		*/
		TLevelField* GetHeight(const float fX, const float fY, float& pfHeight, const bool bInActiveToo = false,
							   const bool bNoCollisionMesh = false);

		/*
			Performs movement with collision detection

			Parameters:
				ASTCollisionPacked& CCollisionPacked -> Collision packed which holds the collision information
				ASTVector3D&		vPosition		 -> Start position
				ASTVector3D&		vERadius		 -> Collision ellipsoid radius
				ASTVector3D&		vVelocity		 -> Velocity
				bool				bSlide			 -> Is sliding allowed?
				bool				bInactiveToo	 -> Should inactive fields be checked, too?
		*/
		ASTVector3D Move(ASTCollisionPacked& CCollisionPacked, ASTVector3D& vPosition,
						 ASTVector3D& vERadius, ASTVector3D& vVelocity, const bool bSlide = true,
						 const bool bInactiveToo = false);

		ASTLinkedList<ASTCollisionMesh*> m_lstCollisionMesh;


	private:
		ASTTextureHandler m_CTerrainTexture;	// Terrain texture
		ASTTextureHandler m_CCliffTexture;		// Cliff texture
		ASTTextureHandler m_CShadowTexture;		// Shadow texture
		ASTTextureHandler m_CPlantTexture;		// Plant texture

		ASTSoundHandler m_CTime1Sound;
		ASTSoundHandler m_CTime2Sound;

		int			 m_iPlants;			// Number of plants in the level
		TLevelPlant* m_pSPlants;		// Plants
		int			 m_iPlantList;		// Plant display list
		

		/*
			Updates the visibility information
		*/
		void UpdateVisibility();

		/*
			Initializes the level
		*/
		void Init();

		/*
			Performs the collision detection

			Parameters:
				ASTVector3D& vPosition	->
				ASTVector3D& vVelocity	->
		*/
		ASTVector3D CollideWithWorld(ASTVector3D& vPosition, ASTVector3D& vVelocity, ASTCollisionPacked& SCollPacked);

		/*
			Performs the collision detection
		*/
		void CheckCollision(ASTCollisionPacked& SCollPacked);


} TLevel;


#endif // __LEVEL_H__
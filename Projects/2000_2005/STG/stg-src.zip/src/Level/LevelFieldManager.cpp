/*
	File: LevelFieldManager.cpp
*/

#include <ASEngine.h>
#include "Level.h"


/*
	Calculates the field ID of a given field position
*/
int TLevelFieldManager::GetID(const int iX, const int iY) const
{
	// Check if the position if valid
	if (!IsValid(iX, iY)) return -1;

	return iX + iY * m_iSize[X];
}

/*
	Calculates the field ID of a given field position
*/
int TLevelFieldManager::GetID(const float fX, const float fY) const
{
	int iX, iY;

	GetPos(fX, fY, &iX, &iY);

	return GetID(iX, iY);
}

/*
	Calculates the field position of a level position
*/
bool TLevelFieldManager::GetPos(const float fX, const float fY, int* iX, int* iY) const
{
	*iX = (int) ((fX + m_pCLevel->CGeometry.m_fTranslate[X]) / FIELDSIZE_X);
	*iY = (int) ((fY + m_pCLevel->CGeometry.m_fTranslate[Y]) / FIELDSIZE_Y);

	if (IsValid(*iX, *iY)) return true;
	else					  return false;
}

/*
	Calculates the level position of a field position
*/
bool TLevelFieldManager::GetLevelPos(const int iX, const int iY, float* fX, float* fY) const
{
	if (IsValid(iX, iY)) return true;

	*fX = (float) (iX * FIELDSIZE_X - m_pCLevel->CGeometry.m_fTranslate[X]);
	*fY = (float) (iY * FIELDSIZE_Y - m_pCLevel->CGeometry.m_fTranslate[Y]);

	return false;
}

/*
	Checks if the given ID is valid
*/
bool TLevelFieldManager::IsValid(const int iID) const
{
	if (iID < 0 || iID >= m_iFields) return false;
	else							 return true;
}

/*
	Checks if the given position is valid
*/
bool TLevelFieldManager::IsValid(const int iX, const int iY) const
{
	if (iX < 0 || iX > m_iSize[X] ||
	    iY < 0 || iY > m_iSize[Y])
		return false; // NO! Its outside the level!!

	return true;
}

/*
	Checks if the given position is valid
*/
bool TLevelFieldManager::IsValid(const float fX, const float fY) const
{
	// Compute the field position
	int iX = (int) ((fX + m_pCLevel->CGeometry.m_fTranslate[X]) / FIELDSIZE_X);
	int iY = (int) ((fY + m_pCLevel->CGeometry.m_fTranslate[Y]) / FIELDSIZE_Y);

	return IsValid(iX, iY);
}

/*
	Initializes the field manager
*/
bool TLevelFieldManager::Init(TLevel* pCLevel, const int iXSize, const int iYSize)
{
	TLevelField* pCField, *pCFieldLast;
	ASINT4* piVertex;
	int i, iX, iY, iID, iLevelVertices;
	ASFLOAT3* pfVertex;
	ASINT2 iMid;

	// Check pointer
	if (!pCLevel) return true;

	// Check if the field matrix size is valid
	if (iXSize < 0 || iXSize > MAXFIELDSX ||
		iYSize < 0 || iYSize > MAXFIELDSY)
		return true;

	// Setup data
	m_pCLevel  = pCLevel;
	m_iSize[X] = iXSize;
	m_iSize[Y] = iYSize;
	m_iFields  = m_iSize[X] * m_iSize[Y];
	
	// Initialize the level geometry	
	if (m_pCLevel->CGeometry.Init(m_pCLevel, iXSize + 1, iYSize + 1)) return true;

	// Allocate memory
	m_pCField = new TLevelField[m_iFields];
	m_pCFrustumFields = (TLevelField**) malloc(sizeof(TLevelField) * (m_iFields + 1));
	memset(m_pCFrustumFields, 0, sizeof(TLevelField**) * (m_iFields + 1));

	// Setup fields
	for (iID = 0, pCField = &m_pCField[0], iY = 0; iY < m_iSize[Y]; iY++)
		for (iX = 0; iX < m_iSize[X]; iX++, iID++, pCField++) {
			// Setup field data
			pCField->m_pCFieldManager = this;
			pCField->m_iID		      = iID;
			pCField->m_iPos[X]        = iX;
			pCField->m_iPos[Y]		  = iY;
			pCField->m_bActive	      = true;
			pCField->m_bUpdate		  = false;
			pCField->m_bInFrustum	  = true;

			// Setup field vertices
			piVertex = &pCField->m_iVertex;
			(*piVertex)[0] = m_pCLevel->CGeometry.GetID(iX    , iY    );
			(*piVertex)[1] = m_pCLevel->CGeometry.GetID(iX + 1, iY    );
			(*piVertex)[2] = m_pCLevel->CGeometry.GetID(iX + 1, iY + 1);
			(*piVertex)[3] = m_pCLevel->CGeometry.GetID(iX    , iY + 1);

			// Setup cliffs
			pCField->m_bCliffActive[LEFT] = false;
			pCField->m_iCliffVertex[LEFT][0] = m_pCLevel->CGeometry.GetID(iX    , iY    );
			pCField->m_iCliffVertex[LEFT][1] = m_pCLevel->CGeometry.GetID(iX    , iY + 1);
			pCField->m_iCliffVertex[LEFT][2] = m_pCLevel->CGeometry.GetID(iX    , iY + 1) + m_pCLevel->CGeometry.m_iLevelVertices;
			pCField->m_iCliffVertex[LEFT][3] = m_pCLevel->CGeometry.GetID(iX    , iY    ) + m_pCLevel->CGeometry.m_iLevelVertices;

			pCField->m_bCliffActive[TOP] = false;
			pCField->m_iCliffVertex[TOP][0] = m_pCLevel->CGeometry.GetID(iX + 1, iY    );
			pCField->m_iCliffVertex[TOP][1] = m_pCLevel->CGeometry.GetID(iX    , iY    );
			pCField->m_iCliffVertex[TOP][2] = m_pCLevel->CGeometry.GetID(iX    , iY    ) + m_pCLevel->CGeometry.m_iLevelVertices;
			pCField->m_iCliffVertex[TOP][3] = m_pCLevel->CGeometry.GetID(iX + 1, iY    ) + m_pCLevel->CGeometry.m_iLevelVertices;

			pCField->m_bCliffActive[RIGHT] = false;
			pCField->m_iCliffVertex[RIGHT][0] = m_pCLevel->CGeometry.GetID(iX + 1, iY + 1);
			pCField->m_iCliffVertex[RIGHT][1] = m_pCLevel->CGeometry.GetID(iX + 1, iY    );
			pCField->m_iCliffVertex[RIGHT][2] = m_pCLevel->CGeometry.GetID(iX + 1, iY    ) + m_pCLevel->CGeometry.m_iLevelVertices;
			pCField->m_iCliffVertex[RIGHT][3] = m_pCLevel->CGeometry.GetID(iX + 1, iY + 1) + m_pCLevel->CGeometry.m_iLevelVertices;

			pCField->m_bCliffActive[BOTTOM] = false;
			pCField->m_iCliffVertex[BOTTOM][0] = m_pCLevel->CGeometry.GetID(iX    , iY + 1);
			pCField->m_iCliffVertex[BOTTOM][1] = m_pCLevel->CGeometry.GetID(iX + 1, iY + 1);
			pCField->m_iCliffVertex[BOTTOM][2] = m_pCLevel->CGeometry.GetID(iX + 1, iY + 1) + m_pCLevel->CGeometry.m_iLevelVertices;
			pCField->m_iCliffVertex[BOTTOM][3] = m_pCLevel->CGeometry.GetID(iX    , iY + 1) + m_pCLevel->CGeometry.m_iLevelVertices;
		}

	// Create random alpha map
	CreateRandomAlpha();

	// Setup some temp data
	_AS::CLog.Output("Process level");
	iMid[X]		   = m_iSize[X] / 2;
	iMid[Y]		   = m_iSize[Y] / 2;
	pfVertex	   = m_pCLevel->CGeometry.m_pfVertex;
	iLevelVertices = m_pCLevel->CGeometry.m_iLevelVertices;

	// Build the vortex place
	CreatePlateau(iMid[X], iMid[Y], 2, 2, 0.f);
	
	// Gaps around the vortex
	for (iY = iMid[Y] - 2; iY < iMid[Y] + 2; iY++) {
		pCField = &m_pCField[GetID(iMid[X] - 2, iY)];
		pCField->m_bActive = false;
		pCField = &m_pCField[GetID(iMid[X] + 2, iY)];
		pCField->m_bActive = false;
	}
	for (iX = iMid[X] - 2; iX < iMid[X] + 2; iX++) {
		pCField = &m_pCField[GetID(iX, iMid[Y] - 2)];
		pCField->m_bActive = false;
		pCField = &m_pCField[GetID(iX, iMid[Y] + 2)];
		pCField->m_bActive = false;
	}
	pCField = &m_pCField[GetID(iMid[X] + 2, iMid[Y] + 2)];
	pCField->m_bActive = false;

	// Ways to the players
	for (iX = iMid[X] - 15; iX < iMid[X] + 15; iX++) {
		pCField = &m_pCField[GetID(iX, iMid[Y])];
		pCField->m_bActive = true;
	}
	for (iY = iMid[Y] - 15; iY < iMid[Y] + 15; iY++) {
		pCField = &m_pCField[GetID(iMid[X], iY)];
		pCField->m_bActive = true;
	}

	// Left top
	pCField = &m_pCField[GetID(iMid[X] - 1, iMid[Y] - 1)];
	pfVertex[pCField->m_iVertex[0]][Z] -= 5;
	pfVertex[pCField->m_iVertex[0] + iLevelVertices][Z] -= 5;
	// Right top
	pCField = &m_pCField[GetID(iMid[X] + 1, iMid[Y] - 1)];
	pfVertex[pCField->m_iVertex[1]][Z] -= 5;
	pfVertex[pCField->m_iVertex[1] + iLevelVertices][Z] -= 5;
	// Right bottom
	pCField = &m_pCField[GetID(iMid[X] + 1, iMid[Y] + 1)];
	pfVertex[pCField->m_iVertex[2]][Z] -= 5;
	pfVertex[pCField->m_iVertex[2] + iLevelVertices][Z] -= 5;
	// Left bottom
	pCField = &m_pCField[GetID(iMid[X] - 1, iMid[Y] + 1)];
	pfVertex[pCField->m_iVertex[3]][Z] -= 5;
	pfVertex[pCField->m_iVertex[3] + iLevelVertices][Z] -= 5;

	CalculatePlanes(true);

	// Create testers
	float fX, fY, fZ, fRot;
	ASTEntity* pCEntity;
	char szTemp[256];

	for (i = 0; i < 4; i++) {
		// Create entity
		sprintf(szTemp, "Tester_%d.jpg", i + 1);
		ASCreateEntity(pCEntity, TActorTester, szTemp);
	
		// Set position
		switch (i) {
			case 0: fX = -135.f; fY =    0.f; fRot =   90.f; break;
			case 1: fX =    0.f; fY = -135.f; fRot =    0.f; break;
			case 2: fX =  135.f; fY =    0.f; fRot =  -90.f; break;
			case 3: fX =    0.f; fY =  135.f; fRot = -180.f; break;
		}

		m_pCLevel->GetHeight(fX, fY, fZ, true);
		GetPos(fX, fY, &iX, &iY);
		CreatePlateau(iX, iY, 2, 2, fZ);
		pCEntity->SetPos(fX, fY, fZ);
		pCEntity->SetRot(0.f, 0.f, fRot - 20);
		((TActorTester*) pCEntity)->AddModelMeshToLevel();
	}

	// Smooth edges
	pCField		= &m_pCField[0];
	pCFieldLast = pCField + m_iFields;
	for(; pCField < pCFieldLast; pCField++) {
		if (!pCField->m_bActive) continue;

		// Left top
		i = GetID(pCField->m_iPos[X] - 1, pCField->m_iPos[Y] - 1);
		if (!IsValid(i) || !m_pCField[i].m_bActive) {
			pfVertex[pCField->m_iCliffVertex[LEFT][0]][X] += 1.f + (float) (rand() % 100)/100;
			pfVertex[pCField->m_iCliffVertex[LEFT][3]][X] += 1.f + (float) (rand() % 100)/100;
			pfVertex[pCField->m_iCliffVertex[LEFT][0]][Y] += 1.f + (float) (rand() % 100)/100;
			pfVertex[pCField->m_iCliffVertex[LEFT][3]][Y] += 1.f + (float) (rand() % 100)/100;
		}

		// Right top
		i = GetID(pCField->m_iPos[X] + 1, pCField->m_iPos[Y] - 1);
		if (!IsValid(i) || !m_pCField[i].m_bActive) {
			pCField->m_bCliffActive[TOP] = true;
			pfVertex[pCField->m_iCliffVertex[TOP][0]][X] -= 1.f + (float) (rand() % 100)/100;
			pfVertex[pCField->m_iCliffVertex[TOP][3]][X] -= 1.f + (float) (rand() % 100)/100;
			pfVertex[pCField->m_iCliffVertex[TOP][0]][Y] += 1.f + (float) (rand() % 100)/100;
			pfVertex[pCField->m_iCliffVertex[TOP][3]][Y] += 1.f + (float) (rand() % 100)/100;
		} else pCField->m_bCliffActive[TOP] = false;

		// Right bottom
		i = GetID(pCField->m_iPos[X] + 1, pCField->m_iPos[Y] + 1);
		if (!IsValid(i) || !m_pCField[i].m_bActive) {
			pCField->m_bCliffActive[RIGHT] = true;
			pfVertex[pCField->m_iCliffVertex[RIGHT][0]][X] -= 1.f + (float) (rand() % 100)/100;
			pfVertex[pCField->m_iCliffVertex[RIGHT][3]][X] -= 1.f + (float) (rand() % 100)/100;
			pfVertex[pCField->m_iCliffVertex[RIGHT][0]][Y] -= 1.f + (float) (rand() % 100)/100;
			pfVertex[pCField->m_iCliffVertex[RIGHT][3]][Y] -= 1.f + (float) (rand() % 100)/100;
		} else pCField->m_bCliffActive[RIGHT] = false;

		// Left bottom
		i = GetID(pCField->m_iPos[X] - 1, pCField->m_iPos[Y] + 1);
		if (!IsValid(i) || !m_pCField[i].m_bActive) {
			pCField->m_bCliffActive[BOTTOM] = true;
			pfVertex[pCField->m_iCliffVertex[BOTTOM][0]][X] += 1.f + (float) (rand() % 100)/100;
			pfVertex[pCField->m_iCliffVertex[BOTTOM][3]][X] += 1.f + (float) (rand() % 100)/100;
			pfVertex[pCField->m_iCliffVertex[BOTTOM][0]][Y] -= 1.f + (float) (rand() % 100)/100;
			pfVertex[pCField->m_iCliffVertex[BOTTOM][3]][Y] -= 1.f + (float) (rand() % 100)/100;
		} else pCField->m_bCliffActive[BOTTOM] = false;
	}

	// Compute different level data
	m_pCLevel->CGeometry.ComputeCliffs();
	BuildCliff();
	CalculatePlanes(true);
	CalculateVerticesNormals();
	CalculateBoundingBoxes(true);

	// Build the quadtree
	m_CQuadtree.Build(this);

	return false;
}

/*
	De-initializes the field manager
*/
bool TLevelFieldManager::DeInit()
{
	if (!m_pCLevel) return false;

	// Destroy the quadtree
	m_CQuadtree.Destroy();

	// De-initialize the level geometry	
	if (m_pCLevel->CGeometry.DeInit()) return true;

	// De-initialize the rest
	if (m_pCField) delete [] m_pCField;
	if (m_pCFrustumFields) free(m_pCFrustumFields);

	return false;
}

/*
	Calculate the planes of all fields
*/
void TLevelFieldManager::CalculatePlanes(const bool bForceAll) const
{
	TLevelField* pCField, *pCFieldLast;

	pCField		= &m_pCField[0];
	pCFieldLast = pCField + m_iFields;
	for(; pCField < pCFieldLast; pCField++) {
		if (!bForceAll && !pCField->m_bUpdate) continue;
		pCField->CalculatePlanes();
	}
}

/*
	Calculate the normals of all vertices
*/
void TLevelFieldManager::CalculateVerticesNormals() const
{
	TLevelField* pCField, *pCFieldLast;

	memset(m_pCLevel->CGeometry.m_pfNormal, 0, sizeof(ASFLOAT3) * m_pCLevel->CGeometry.m_iVertices);
	pCField		= &m_pCField[0];
	pCFieldLast = pCField + m_iFields;
	for(; pCField < pCFieldLast; pCField++) pCField->CalculateVerticesNormals();
}

/*
	Calculates the bounding boxes of all fields
*/
void TLevelFieldManager::CalculateBoundingBoxes(const bool bForceAll) const
{
	TLevelField* pCField, *pCFieldLast;

	pCField		= &m_pCField[0];
	pCFieldLast = pCField + m_iFields;
	for(; pCField < pCFieldLast; pCField++) {
		if (!bForceAll && !pCField->m_bUpdate) continue;
		pCField->CalculateBoundingBox();
	}
}

/*
	Disables the field update flag
*/
void TLevelFieldManager::DisableFieldUpdate() const
{
	TLevelField* pCField, *pCFieldLast;

	pCField		= &m_pCField[0];
	pCFieldLast = pCField + m_iFields;
	for(; pCField < pCFieldLast; pCField++) pCField->m_bUpdate = false;
}

/*
	Update the field manager
*/
void TLevelFieldManager::Update()
{
	TLevelField* pCField, *pCFieldLast;

	DisableFieldUpdate();

	// Update all fields
	pCField		= &m_pCField[0];
	pCFieldLast = pCField + m_iFields;
	for(; pCField < pCFieldLast; pCField++) pCField->Update();
}

/*
	Updates the field visibility information
*/
void TLevelFieldManager::UpdateVisibility()
{
	TLevelField* pCField, *pCFieldLast, **pCFrustumFields;

	// Update quadtrees visibility
	m_CQuadtree.UpdateVisibility();

	// Get a list of all visible fields
	pCField			= &m_pCField[0];
	pCFieldLast		= pCField + m_iFields;
	pCFrustumFields = m_pCFrustumFields;
	for(; pCField < pCFieldLast; pCField++) {
		if (!pCField->m_bInFrustum || !pCField->m_bActive) continue;
		(*pCFrustumFields) = pCField;
		pCFrustumFields++;
	}
	(*pCFrustumFields) = NULL;
}

/*
	Builds the cliff
*/
void TLevelFieldManager::BuildCliff()
{
	TLevelField* pCField, *pCFieldLast;
	ASFLOAT3* pfVertex;
	int i;

	// Determe the field cliff side states
	pfVertex    = m_pCLevel->CGeometry.m_pfVertex;
	pCField		= &m_pCField[0];
	pCFieldLast = pCField + m_iFields;
	for(; pCField < pCFieldLast; pCField++) {
		if (!pCField->m_bActive) {
			memset(&pCField->m_bCliffActive, 0, sizeof(bool) * 4);
			continue;
		}

		// Left
		i = GetID(pCField->m_iPos[X] - 1, pCField->m_iPos[Y]);
		if (!IsValid(i) || !m_pCField[i].m_bActive) {
			pCField->m_bCliffActive[LEFT] = true;
			pfVertex[pCField->m_iCliffVertex[LEFT][2]][X] -= 1.f + (float) (rand() % 100)/100;
			pfVertex[pCField->m_iCliffVertex[LEFT][3]][X] -= 1.f + (float) (rand() % 100)/100;
		} else pCField->m_bCliffActive[LEFT] = false;

		// Top
		i = GetID(pCField->m_iPos[X], pCField->m_iPos[Y] - 1);
		if (!IsValid(i) || !m_pCField[i].m_bActive) {
			pCField->m_bCliffActive[TOP] = true;
			pfVertex[pCField->m_iCliffVertex[TOP][2]][Y] -= 1.f + (float) (rand() % 100)/100;
			pfVertex[pCField->m_iCliffVertex[TOP][3]][Y] -= 1.f + (float) (rand() % 100)/100;
		} else pCField->m_bCliffActive[TOP] = false;

		// Right
		i = GetID(pCField->m_iPos[X] + 1, pCField->m_iPos[Y]);
		if (!IsValid(i) || !m_pCField[i].m_bActive) {
			pCField->m_bCliffActive[RIGHT] = true;
			pfVertex[pCField->m_iCliffVertex[RIGHT][2]][X] += 1.f + (float) (rand() % 100)/100;
			pfVertex[pCField->m_iCliffVertex[RIGHT][3]][X] += 1.f + (float) (rand() % 100)/100;
		} else pCField->m_bCliffActive[RIGHT] = false;

		// Bottom
		i = GetID(pCField->m_iPos[X], pCField->m_iPos[Y] + 1);
		if (!IsValid(i) || !m_pCField[i].m_bActive) {
			pCField->m_bCliffActive[BOTTOM] = true;
			pfVertex[pCField->m_iCliffVertex[BOTTOM][2]][Y] += 1.f + (float) (rand() % 100)/100;
			pfVertex[pCField->m_iCliffVertex[BOTTOM][3]][Y] += 1.f + (float) (rand() % 100)/100;
		} else pCField->m_bCliffActive[BOTTOM] = false;
	}
}

/*
	Creates a plateau
*/
void TLevelFieldManager::CreatePlateau(const int iXPos, const int iYPos, const int iWidth, const int iHeight, const float fHeight)
{
	int iLevelVertices, iX, iY, i;
	TLevelField* pCField;
	ASFLOAT3* pfVertex;

	pfVertex	   = m_pCLevel->CGeometry.m_pfVertex;
	iLevelVertices = m_pCLevel->CGeometry.m_iLevelVertices;
	
	for (iY = iYPos - iHeight; iY < iYPos + iHeight; iY++) {
		if (iY < 0 || iY >= m_iSize[Y]) continue;
		for (iX = iXPos - iWidth; iX < iXPos + iWidth; iX++) {
			if (iX < 0 || iX >= m_iSize[X]) continue;
			pCField = &m_pCField[GetID(iX, iY)];
			pCField->m_bActive = true;
			for (i = 0; i < 4; i++) {
				pfVertex[pCField->m_iVertex[i] + iLevelVertices][Z] -= pfVertex[pCField->m_iVertex[i]][Z];
				pfVertex[pCField->m_iVertex[i]][Z] = fHeight;
			}
		}
	}
}
/*
	File: Control.cpp
*/

#include <ASEngine.h>
#include "Control.h"


// Definitions
#define	STANDARD_LEFT_KEY    30 // a
#define	STANDARD_RIGHT_KEY   32	// d
#define	STANDARD_UP_KEY      17	// w
#define	STANDARD_DOWN_KEY    31	// s
#define	STANDARD_RUN_KEY     42	// Left shift
#define	STANDARD_JUMP_KEY    57	// Space
#define	STANDARD_ATTACK_KEY  29	// Left strg
#define	STANDARD_PAUSE_KEY   25	// p


// Variables
TControl CControl;


/*
	Initialize the configuration
*/
bool TControl::Init()
{
	m_bLoaded = false;

	return Load();
}

/*
	Load control configuration
*/
bool TControl::Load(const char* pszFilename)
{
	// Check pointer
	if (!pszFilename) return true;

	// Setup filename information
	strcpy(m_szFilename, pszFilename);
	_AS::CFileSystem.GetFullFilename(m_szFilename, ASCONFIG_FILE);

	// Save the preview configuration
	if (m_bLoaded) Save(m_szFilename);
	_AS::CLog.Output("Load control configuration '%s'", m_szFilename);

	// Load the control configurations

	// Keys
	m_iLeftKey   = GetPrivateProfileInt("keys", "left",   STANDARD_LEFT_KEY,   m_szFilename);
	m_iRightKey  = GetPrivateProfileInt("keys", "right",  STANDARD_RIGHT_KEY,  m_szFilename);
	m_iUpKey     = GetPrivateProfileInt("keys", "top",    STANDARD_UP_KEY,     m_szFilename);
	m_iDownKey   = GetPrivateProfileInt("keys", "down",   STANDARD_DOWN_KEY,   m_szFilename);
	m_iRunKey    = GetPrivateProfileInt("keys", "run",    STANDARD_RUN_KEY,    m_szFilename);
	m_iJumpKey   = GetPrivateProfileInt("keys", "jump",   STANDARD_JUMP_KEY,   m_szFilename);
	m_iAttackKey = GetPrivateProfileInt("keys", "attack", STANDARD_ATTACK_KEY, m_szFilename);
	m_iPauseKey  = GetPrivateProfileInt("keys", "pause",  STANDARD_PAUSE_KEY,  m_szFilename);

	m_bLoaded = true;
	Check();

	return false;
}

/*
	Save control configuration
*/
bool TControl::Save(const char* pszFilename)
{
	// Check pointer
	if (!pszFilename) return true;

	// Setup filename information
	strcpy(m_szFilename, pszFilename);
	_AS::CFileSystem.GetFullFilename(m_szFilename, ASCONFIG_FILE);
	_AS::CLog.Output("Save control configuration '%s'", m_szFilename);

	// Save the control configurations

	// Keys
	_AS::CFileSystem.WritePrivateProfileEString("keys", "left",   m_szFilename, "%d", m_iLeftKey);
	_AS::CFileSystem.WritePrivateProfileEString("keys", "right",  m_szFilename, "%d", m_iRightKey);
	_AS::CFileSystem.WritePrivateProfileEString("keys", "up",     m_szFilename, "%d", m_iUpKey);
	_AS::CFileSystem.WritePrivateProfileEString("keys", "down",   m_szFilename, "%d", m_iDownKey);
	_AS::CFileSystem.WritePrivateProfileEString("keys", "run",    m_szFilename, "%d", m_iRunKey);
	_AS::CFileSystem.WritePrivateProfileEString("keys", "jump",   m_szFilename, "%d", m_iJumpKey);
	_AS::CFileSystem.WritePrivateProfileEString("keys", "attack", m_szFilename, "%d", m_iAttackKey);
	_AS::CFileSystem.WritePrivateProfileEString("keys", "pause",  m_szFilename, "%d", m_iPauseKey);

	return false;
}

/*
	Check if the configurations are valid
*/
bool TControl::Check()
{

	return false;
}

/*
	Enumerates how often a key is binded
*/
int TControl::EnumerateKeyUsage(const int iKey)
{
	int iCounter = 0;

	if (m_iLeftKey   == iKey) iCounter++;
	if (m_iRightKey  == iKey) iCounter++;
	if (m_iUpKey     == iKey) iCounter++;
	if (m_iDownKey   == iKey) iCounter++;
	if (m_iRunKey    == iKey) iCounter++;
	if (m_iJumpKey   == iKey) iCounter++;
	if (m_iAttackKey == iKey) iCounter++;
	if (m_iPauseKey  == iKey) iCounter++;

	return iCounter;
}

/*
	Resets the configurations
*/
void TControl::Reset()
{
	// Remove the old configuration file
	_AS::CFileSystem.RemoveFile(m_szFilename);

	// Create a new one
	m_bLoaded = false;
	Load(m_szFilename);
}

/*
	Returns the given keys
*/
int TControl::GetLeftKey() const
{
	return m_iLeftKey;
}

int TControl::GetRightKey() const
{
	return m_iRightKey;
}

int TControl::GetUpKey() const
{
	return m_iUpKey;
}

int TControl::GetDownKey() const
{
	return m_iDownKey;
}

int TControl::GetRunKey() const
{
	return m_iRunKey;
}

int TControl::GetJumpKey() const
{
	return m_iJumpKey;
}

int TControl::GetAttackKey() const
{
	return m_iAttackKey;
}

int TControl::GetPauseKey() const
{
	return m_iPauseKey;
}

/*
	Sets the given keys
*/
void TControl::SetLeftKey(const int iKey)
{
	m_iLeftKey = iKey;
}

void TControl::SetRightKey(const int iKey)
{
	m_iRightKey = iKey;
}

void TControl::SetUpKey(const int iKey)
{
	m_iUpKey = iKey;
}

void TControl::SetDownKey(const int iKey)
{
	m_iDownKey = iKey;
}

void TControl::SetRunKey(const int iKey)
{
	m_iRunKey = iKey;
}

void TControl::SetJumpKey(const int iKey)
{
	m_iJumpKey = iKey;
}

void TControl::SetAttackKey(const int iKey)
{
	m_iAttackKey = iKey;
}

void TControl::SetPauseKey(const int iKey)
{
	m_iPauseKey = iKey;
}
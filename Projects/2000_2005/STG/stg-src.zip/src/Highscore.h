/*
	File: Highscore.h

	Description: Highscore stuff
*/

#ifndef __HIGHSCORE_H__
#define __HIGHSCORE_H__


// Definitions
#define HIGHSCORE_FILE			   "hig"		// Highscore file
#define HIGHSCOREFILE			   "highscore"	// Name of the standard highscore file
#define HIGHSCORE_ENTRIES          10			// Standard number of highscore entries
#define HIGHSCORE_NAME_LENGTH	   39			// Max length of a player name
#define HIGHSCORE_IMPRESSIVE_SCORE 7000			// An impressive score


// Structures
typedef struct THighscoreEntry {
	char szName[HIGHSCORE_NAME_LENGTH];	// Player name
	int  iScore;						// Player score

} THighscoreEntry;


// Classes
typedef class THighscore {

	public:
		/*
			Constructor
		*/
		THighscore();

		/*
			Destructor
		*/
		~THighscore();

		/*
			Load a highscore

			Parameters:
				char* pszFilename -> Highscore filename

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Load(const char* pszFilename = HIGHSCOREFILE);

		/*
			Unloads the highscore

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Unload();

		/*
			Save the highscore

			Parameters:
				char* pszFilename -> Highscore filename

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Save(const char* pszFilename = HIGHSCOREFILE);

		/*
			Open the highscore

			Parameters:
				int  iScore   -> Score that should be inserted
				bool bGameWon -> Is the game won?

			Notes:
				- If iScore = -1 the highscore will only be shown, else the player could
				  enter his name
		*/
		void Open(const int iScore = -1, const bool bGameWon = false);

		/*
			Checks whether and were a new score goes into the highscore

			Parameters:
				int iScore -> Score that should be checked

			Returns:
				int -> The scores place in the highscore. If its not in the highscore '-1'.
		*/
		int GetScorePlace(const int iScore);

		/*
			Returns the highscore blending

			Returns:
				float -> Highscore blending
		*/
		float GetBlending() const;

		/*
			Draws the highscore

			Returns:
				bool -> 'true' if the highscore is visible else 'false'
		*/
		bool Draw();

		/*
			Updates the highscore

			Returns:
				bool -> 'true' if the highscore is active else 'false'
		*/
		bool Update();


	private:
		char  m_szFilename[256];	// Highscore filename
		bool  m_bLoaded;			// Is a highscore loaded?
		bool  m_bActive;			// Is the highscore active?
		float m_fAlpha;				// Transparency
		float m_fTimer;

		bool			 m_bGameWon;		// Is the game won?
		bool			 m_bEnterName;		// Does the player enters his name at the moment?
		THighscoreEntry* m_pSScoreEntry;	// The current selected highscore entry

		ASTDynamicLinkedList<THighscoreEntry> m_lstEntryList;	// All highscore entries

		// Sounds
		ASTSoundHandler m_CInputSound;
		ASTSoundHandler m_CEnterSound;
		ASTSoundHandler m_CInvalidSound;
		ASTSoundHandler m_CChangeSound;
		ASTSoundHandler m_CBackSound;
		ASTSoundHandler m_CWinnerSound;
		ASTSoundHandler m_CLooserSound;
		ASTSoundHandler m_CNewHighscoreSound;


} THighscore;


#endif // __HIGHSCORE_H__
/*
	File: Game.h

	Description: Game file
*/

#ifndef __ASGAME_H__
#define __ASGAME_H__


// Definitions
#define GAMENAME	   "Softgames.de - The Game"	// Game title
#define GAMEVERSION    "v1.0"						// Game version
#define GAMEMODULENAME "stg.exe"					// Game filename

// For debugging
#ifdef _DEBUG
	#define STARTINGAME // Skip the main menu at start
	#define NOLOGOS
#endif


// Includes
#include "Main.h"
#include "Config.h"
#include "Menus.h"
#include "Control.h"
#include "Language.h"
#include "Entities\Entities.h"
#include "Entities\EntityCamera.h"
#include "Level\Level.h"


typedef class TGame {

	public:
		TLevel*	   pCLevel;		// Current level
		TActorUrl* pCUrlActor;	// Pointer to url	

		/*
			Initializes the game
		*/
		void Init();

		/*
			Creates a new level
		*/
		void CreateNewLevel();

		/*
			Destroys the level
		*/
		void DestroyLevel();

		/*
			Returns if there's a level

			Returns:
				bool -> 'true' if theres a level else 'false'
		*/
		bool IsLevel() const;

		/*
			Game over
		*/
		void GameOver();

		/*
			Game won
		*/
		void GameWon();

		/*
			Returns the play timer
		*/
		float GetPlayTimer() const;


	private:
		TEntityCamera*   m_pCCamera;			// The current used camera
		ASTEntityHandler m_CLightEntity;		// Moving Light
		bool			 m_bGameOver;			// Game over
		bool			 m_bGameWon;			// Game won
		float			 m_fPlayTime;			// Play timer

		// Sounds
		ASTSoundHandler m_CMusic;			// In-game background music
		ASTSoundHandler m_CGameOverSound;	// Game over sound
		ASTSoundHandler m_CGameWonSound;	// Game won sound

		// Textures
		ASTTextureHandler m_CGameOverTexture;
		ASTTextureHandler m_CGameWonTexture;


		/*
			De-initializes the game
		*/
		void DeInit();

		/*
			Game renderer initialization function
		*/
		static void GameRendererInit();
		void RendererInit();

		/*
			Game renderer de-initialization function
		*/
		static void GameRendererDeInit();
		void RendererDeInit();

		/*
			Game draw function
		*/
		static bool GameDraw(ASTWindow* pCWindow);
		bool Draw(ASTWindow* pCWindow);

		/*
			Game update function
		*/
		static bool GameUpdate(ASTWindow* pCWindow);
		bool Update(ASTWindow* pCWindow);
	

} TGame;


// Variables
extern TGame CGame;


#endif // __ASGAME_H__

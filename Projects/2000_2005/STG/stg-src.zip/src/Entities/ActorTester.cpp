/*
	File: ActorTester.cpp
*/

#include <ASEngine.h>
#include "..\Game.h"


/*
	Adds the model mesh to the level
*/
void TActorTester::AddModelMeshToLevel()
{
	// Add the models collision mesh
	if (CGame.pCLevel) CGame.pCLevel->m_lstCollisionMesh.Add(m_CCollisionModel.GetCollisionMesh());
}

/*
	Tester actor initialisation function
*/
void TActorTester::InitFunction()
{
	// Load model
	m_CModel.Load("tester.md2");
	m_CModel.SetActive();
	m_CModel.SetEntity(this);
	m_CModel.SetAnimationFlags(ASeModelAniFlagPlay | ASeModelAniFlagLoop);
	SetCollisionRadius(m_CModel.GetRadius());

	m_CCollisionModel.Load("tester_collision.md2");
	m_CCollisionModel.SetEntity(this);

	// Get animations
	ANIMATION_TESTING = m_CModel.GetAnimationID("testing");
	ANIMATION_BORING  = m_CModel.GetAnimationID("boring");
	ANIMATION_ANGRY   = m_CModel.GetAnimationID("angry");

	// Load texture
	m_CTexture.Load(GetName());

	// Load sounds
	   m_CStartTestingSound.Load("tester_start_testing.mp3");
	m_CTestingFinishedSound.Load("tester_testing_finished.wav");
			   m_CHit1Sound.Load("tester_hit_1.mp3");
			   m_CHit2Sound.Load("tester_hit_2.mp3");
			   m_CHit3Sound.Load("tester_hit_3.mp3");
			 m_CAngry1Sound.Load("tester_angry_1.mp3");
			 m_CAngry2Sound.Load("tester_angry_2.mp3");

	// Setup data
	SetFlags(eActorFlagImmortal);
	m_fTestingTimer	   = 0.f;
	m_fAngryTimer	   = 0.f;
	m_bAngryDemolition = false;
	m_fTestingSpeed	   = 1.f;
	m_CModel.SetAnimation(ANIMATION_BORING);

	// Activate and setup collision detection
	SetCollisionFlags(ASeCollisionFlagEntities | ASeCollisionFlagSphere);
	SetCollisionRadius(m_CModel.GetRadius());
}

/*
	Tester entity de-initialisation function
*/
void TActorTester::CustomDeInitFunction()
{
	// Remove the models collision mesh
	if (CGame.pCLevel) CGame.pCLevel->m_lstCollisionMesh.Remove(m_CCollisionModel.GetCollisionMesh());

	// Unload model
	         m_CModel.Unload();
	m_CCollisionModel.Unload();

	// Unload texture
	m_CTexture.Unload();

	// Unload sounds
	   m_CStartTestingSound.Unload();
	m_CTestingFinishedSound.Unload();
			   m_CHit1Sound.Unload();
			   m_CHit2Sound.Unload();
			   m_CHit3Sound.Unload();
			 m_CAngry1Sound.Unload();
			 m_CAngry2Sound.Unload();
}

/*
	Checks whether the Tester entity is in the frustum or not
*/
bool TActorTester::CustomFrustumFunction()
{
	if (m_CModel.UpdateVisibility()) return true;

	return false;
}

/*
	Tester entity draw function
*/
void TActorTester::CustomDrawSolidFunction()
{
	// Draw model
	glColor3f(1.f, 1.f, 1.f);
	m_CTexture.GetTexture()->BindOpenGLTexture();
	m_CModel.Draw(false);

	// Draw shadow
	CGame.pCLevel->DrawShadow(m_vPos, 4.5f);
}

/*
	Tester entity update function
*/
void TActorTester::CustomUpdateFunction()
{
	// Update model settings
	CConfig.Update(m_CModel);

	// Animate model
	m_CModel.Animate();

	// Check testing
	if (m_fTestingTimer > 0.f) {
		m_CModel.SetAnimation(ANIMATION_TESTING);
		m_fTestingTimer -= _AS::CTimer.GetTimeDifference() * m_fTestingSpeed;
		if (m_fTestingTimer <= 0.f) {
			m_fTestingTimer = 0.f;
			CGame.pCLevel->fTime += 7.f;
			m_CModel.SetAnimation(ANIMATION_BORING);
			m_CModel.SetAnimationSpeed();
			PlaySound(m_CTestingFinishedSound);

			// Give player some points
			if (CGame.pCUrlActor) CGame.pCUrlActor->IncScore(400);
		}
	}

	if (m_fAngryTimer > 0.f) { // The tester is angry
		m_fAngryTimer -= _AS::CTimer.GetTimeDifference();
		if (m_fAngryTimer <= 0.f) {
			if (m_CModel.GetAnimation() == ANIMATION_ANGRY && m_CModel.IsLastAnimationFrame()) {
				m_fAngryTimer = 0.f;
				m_fTestingSpeed = 0.5f;
				m_CModel.SetAnimation(ANIMATION_BORING);
				m_CModel.SetAnimationSpeed();
			} else m_fAngryTimer = 0.01f;
		}
		m_CModel.SetAnimationSpeed(1 + m_fAngryTimer / 10);
	}
	
	// Normalize testing speed
	if (m_fTestingSpeed > 1.f) {
		m_fTestingSpeed -= _AS::CTimer.GetTimeDifference() / 50;
		if (m_fTestingSpeed < 1.f) m_fTestingSpeed = 1.f;
	} else
	if (m_fTestingSpeed < 1.f) {
		m_fTestingSpeed += _AS::CTimer.GetTimeDifference() / 50;
		if (m_fTestingSpeed > 1.f) m_fTestingSpeed = 1.f;
	}
	if (m_CModel.GetAnimation() == ANIMATION_TESTING) m_CModel.SetAnimationSpeed(m_fTestingSpeed * 2);

	// Angry demolition
	if (m_CModel.GetAnimation() == ANIMATION_ANGRY) {
		if (m_CModel.GetAnimationFrame(false) == 140 || m_CModel.GetAnimationFrame(false) == 173) {
			if (!m_bAngryDemolition) {
				m_bAngryDemolition = true;
				if (rand() % 2) PlaySound(m_CAngry2Sound);
				else			PlaySound(m_CAngry2Sound);
			}
		} else m_bAngryDemolition = false;
	}
}

/*
	Tester entity collision function
*/
void TActorTester::CustomCollisionFunction(const ASTCollisionPacked& pCCollPacked)
{
	// Start testing
	if (pCCollPacked.pCEntity == CGame.pCUrlActor && m_CModel.GetAnimation() != ANIMATION_ANGRY) {
		TActorUrl* pCUrlActor = (TActorUrl*) pCCollPacked.pCEntity;
		
		if (m_fTestingTimer <= 0.f && pCUrlActor->GetGames() > 0) {
			CGame.pCLevel->fTime += 2.f;
			pCUrlActor->IncGames(-1);
			m_fTestingTimer = 80.f + ((float) (rand() % 3000) / 80.f);
			m_CModel.SetAnimation(ANIMATION_TESTING);
			PlaySound(m_CStartTestingSound);

			// Give player some points
			if (pCCollPacked.pCEntity) pCUrlActor->IncScore(20);
		} else MakeAngry();
	}
}

/*
	Process messages
*/
bool TActorTester::ProcessMessage(const int iMessage, const int iParameter, const void* pData)
{
	switch (iMessage) {
		case eActorMessageHit:
			switch (rand() % 3) {
				case 0: PlaySound(m_CHit1Sound); break;
				case 1: PlaySound(m_CHit2Sound); break;
				case 2: PlaySound(m_CHit3Sound); break;
			}
			m_fTestingSpeed += 0.5f;
			m_fAngryTimer += 1.f;
			MakeAngry();
		break;

		default: break;
	}

	return false;
}

/*
	Make the tester angry
*/
void TActorTester::MakeAngry()
{
	m_fAngryTimer += _AS::CTimer.GetTimeDifference() * 1.2f; 
	if (m_fAngryTimer > 5.f) {
		m_fAngryTimer = 50.f;
		m_fTestingTimer = 0.f;
		m_CModel.SetAnimation(ANIMATION_ANGRY);
		m_CModel.SetAnimationSpeed(1.5f);
	}
}
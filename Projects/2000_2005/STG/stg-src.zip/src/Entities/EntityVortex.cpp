/*
	File: EntityVortex.cpp
*/

#include <ASEngine.h>
#include "..\Game.h"
#include "..\ParticleGroups\ParticleGroupSpring.h"


/*
	Vortex entity initialisation function
*/
void TEntityVortex::CustomInitFunction()
{
	ASTEntity* pCEntity;
	ASTLight*  pCLight;

	IncPos(0.f, 0.f, -3.f);

	// Create the top entity
	ASCreateEntity(pCEntity, TEntityVortexTop, "Vortex top entity");
	m_CTopEntity.Load(pCEntity);
	pCEntity->SetPos(GetPos());
	((TEntityVortexTop*) pCEntity)->m_vNextPos = pCEntity->GetPos();
	((TEntityVortexTop*) pCEntity)->m_vFixPos  = pCEntity->GetPos();

	// Create light in the middle
	ASCreateEntity(pCLight, ASTLight, "Vortex light");
	m_CLightEntity.Load(pCLight);
	pCLight->SetFlags(ASeLightFlagFlares | ASeLightFlagCorona | ASeLightFlagBlend);
	pCLight->SetPos(0.f, 0.f, -6.f);
	m_vNextLightPos = pCLight->GetPos();
	m_vFixLightPos  = pCLight->GetPos();
	pCLight->SetBrightness(1.f);

	// Load model
	m_CModel.Load("vortex_bottom.md2");
    m_CModel.SetActive();
	m_CModel.SetEntity(this);
	SetCollisionRadius(m_CModel.GetRadius());
	m_CCollisionModel.Load("vortex_bottom_collision.md2");
    m_CCollisionModel.SetEntity(this);

	// Add the models collision mesh
	if (CGame.pCLevel) CGame.pCLevel->m_lstCollisionMesh.Add(m_CCollisionModel.GetCollisionMesh());

	// Initialize particle system
	ASCreateEntity(pCEntity, TParticleGroupSpring, "Vortex spring particles");
	pCEntity->IncPos(0.f, 0.f, -5.f);
	((TParticleGroupSpring*) pCEntity)->InitParticleGroup(70, "particle_vortex.jpg");
	((TParticleGroupSpring*) pCEntity)->SetupTextureAnimation(2, 2);
	m_pCSpringParticleEntity.Load(pCEntity);

	// Load sound
	m_CSound.Load("vortex.mp3");
}

/*
	Vortex entity de-initialisation function
*/
void TEntityVortex::CustomDeInitFunction()
{
	// Remove the models collision mesh
	if (CGame.pCLevel) CGame.pCLevel->m_lstCollisionMesh.Remove(m_CCollisionModel.GetCollisionMesh());

	// Unload entities
	m_CTopEntity.Unload(true);
	m_CLightEntity.Unload(true);
	m_pCSpringParticleEntity.Unload(true);

	// Unload model
	m_CModel.Unload();
	m_CCollisionModel.Unload();

	// Unload sound
	m_CSound.Unload();
}

/*
	Checks whether the vortex entity is in the frustum or not
*/
bool TEntityVortex::CustomFrustumFunction()
{
	return m_CModel.UpdateVisibility();
}

/*
	Vortex entity draw function
*/
void TEntityVortex::CustomDrawSolidFunction()
{
	// Draw model
	glColor3f(1.f, 1.f, 1.f);
	m_CModel.Draw();

	// Draw shadow
	CGame.pCLevel->DrawShadow(m_vPos, 9.f);
}

/*
	Vortex entity update function
*/
void TEntityVortex::CustomUpdateFunction()
{
	TActorUrl* pCActorUrl = CGame.pCUrlActor;
	ASTVector3D vPos, vVelocity;
	ASTLight* pCLight;
	int i;

	// Update model settings
	CConfig.Update(m_CModel);

	// Move light
	if (pCLight = (ASTLight*) m_CLightEntity.GetEntity()) {
		vPos      = pCLight->GetPos();
		vVelocity = pCLight->GetVelocityVector();
		for (i = 0; i < 3; i++) {
			// Update velocity
			if (vPos.fV[i] < m_vNextLightPos.fV[i])
				vVelocity.fV[i] += _AS::CTimer.GetTimeDifference() * 10;
			else vVelocity.fV[i] -= _AS::CTimer.GetTimeDifference() * 10;

			// Update position
			vPos.fV[i] += vVelocity.fV[i] * _AS::CTimer.GetTimeDifference() * 5;

			// Check for next position
			if (ASAbs(vPos.fV[i] - m_vNextLightPos.fV[i]) < 2.f) {
				if (!(rand() % 2))
					m_vNextLightPos.fV[i] = m_vFixLightPos.fV[i] + (float) (rand() % 100) / 40;
				else
					m_vNextLightPos.fV[i] = m_vFixLightPos.fV[i] - (float) (rand() % 100) / 40;
			}
		}
		vVelocity -= vVelocity * _AS::CPhysics.GetFriction() * _AS::CTimer.GetTimeDifference();
		pCLight->SetPos(vPos);
		pCLight->SetVelocityVector(vVelocity);
	}

	if (pCActorUrl) {
		float fX, fY, fDistance;

		fX = m_vPos.fX - pCActorUrl->GetPos().fX;
		fY = m_vPos.fY - pCActorUrl->GetPos().fY;
		fDistance = ASSqrt(fX * fX + fY * fY);
		if (fDistance > 40.f) fDistance = 40.f;
		if (fDistance < 5.f && pCActorUrl->GetPos().fZ > -15.f) {
			pCActorUrl->IncHealth(_AS::CTimer.GetTimeDifference() * (5 - fDistance) * 4);
			pCActorUrl->IncGames(1);

			// Check whether the game is finished or not
			if (!CGame.pCLevel->iCrystals && !CGame.pCLevel->iTurtles && !CGame.pCLevel->iMosquitos)
				CGame.GameWon();
		}
	}

	if (!m_CSound.IsPlaying()) PlaySound(m_CSound);
}

/*
	Process messages
*/
bool TEntityVortex::CustomProcessMessage(const int iMessage, const int iParameter, const void* pData)
{
	switch (iMessage) {
		case 0: break;
		default: break;
	}

	return false;
}
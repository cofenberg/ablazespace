/*
	File: EntityVortexTop.cpp
*/

#include <ASEngine.h>
#include "..\Game.h"


/*
	Vortex top entity initialisation function
*/
void TEntityVortexTop::CustomInitFunction()
{
	// Load model
	m_CModel.Load("vortex_top.md2");
    m_CModel.SetActive();
	m_CModel.SetEntity(this);
}

/*
	Vortex top entity de-initialisation function
*/
void TEntityVortexTop::CustomDeInitFunction()
{
	// Unload models
	m_CModel.Unload();
}

/*
	Checks whether the vortex top entity is in the frustum or not
*/
bool TEntityVortexTop::CustomFrustumFunction()
{
	return m_CModel.UpdateVisibility();
}

/*
	Vortex top entity draw function
*/
void TEntityVortexTop::CustomDrawSolidFunction()
{
	// Draw model
	glColor3f(1.f, 1.f, 1.f);
	m_CModel.Draw();
}

/*
	Vortex entity update function
*/
void TEntityVortexTop::CustomUpdateFunction()
{
	TActorUrl* pCActorUrl = CGame.pCUrlActor;
	int i;

	// Update model settings
	CConfig.Update(m_CModel);

	// Move
	for (i = 0; i < 2; i++) {
		// Update velocity
		if (m_vPos.fV[i] < m_vNextPos.fV[i])
			m_vVelocity.fV[i] += _AS::CTimer.GetTimeDifference() * 5;
		else m_vVelocity.fV[i] -= _AS::CTimer.GetTimeDifference() * 5;

		// Update position
		m_vPos.fV[i] += m_vVelocity.fV[i] * _AS::CTimer.GetTimeDifference() * 2;

		// Check for next position
		if (ASAbs(m_vPos.fV[i] - m_vNextPos.fV[i]) < 2.f) {
			if (!(rand() % 2)) m_vNextPos.fV[i] = m_vFixPos.fV[i] + (float) (rand() % 100) / 40;
			else			   m_vNextPos.fV[i] = m_vFixPos.fV[i] - (float) (rand() % 100) / 40;
		}
	}

	if (pCActorUrl) {
		float fX, fY, fDistance;

		fX = m_vPos.fX - pCActorUrl->GetPos().fX;
		fY = m_vPos.fY - pCActorUrl->GetPos().fY;
		fDistance = ASSqrt(fX * fX + fY * fY);
		if (fDistance > 40.f) fDistance = 40.f;
		m_vPos.fZ = -12.f -(40 - fDistance);
	}

	// Perform friction
	PerformFriction();

	// Rotate
	IncRot(0.f, 0.f, -_AS::CTimer.GetTimeDifference() * 100);
}

/*
	Process messages
*/
bool TEntityVortexTop::ProcessMessage(const int iMessage, const int iParameter, const void* pData)
{
	switch (iMessage) {
		case 0: break;
		default: break;
	}

	return false;
}
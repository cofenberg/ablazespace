/*
	File: EntityButterfly.cpp
*/

#include <ASEngine.h>
#include "..\Game.h"


/*
	Butterfly entity initialisation function
*/
void TEntityButterfly::CustomInitFunction()
{
	// Load model
	m_CModel.Load("butterfly_1.md2");
	m_CModel.SetActive();
	m_CModel.SetEntity(this);
    m_CModel.SetAnimationFlags(ASeModelAniFlagPlay | ASeModelAniFlagLoop);
	m_CModel.SetAnimationSpeed(5);
	m_CModel.SetAnimationFrame(rand() % m_CModel.GetAnimaionFrames());
}

/*
	Butterfly entity de-initialisation function
*/
void TEntityButterfly::CustomDeInitFunction()
{
	// Unload model
	m_CModel.Unload();
}

/*
	Checks whether the crystal entity is in the frustum or not
*/
bool TEntityButterfly::CustomFrustumFunction()
{
	return m_CModel.UpdateVisibility();
}

/*
	Butterfly entity draw solid function
*/
void TEntityButterfly::CustomDrawSolidFunction()
{
	// Draw model
	glColor3f(1.f, 1.f, 1.f);
	m_CModel.Draw();
}

/*
	Butterfly entity update function
*/
void TEntityButterfly::CustomUpdateFunction()
{
	float fTimeDiff = _AS::CTimer.GetTimeDifference(), fZ;

	// Update model settings
	CConfig.Update(m_CModel);

	// Animate the model
	m_CModel.Animate();

	// Move
	for (int i = 0; i < 3; i++) {
		// Update velocity
		if (m_vPos.fV[i] < m_vNextPos.fV[i])
			m_vVelocity.fV[i] += fTimeDiff * 5;
		else m_vVelocity.fV[i] -= fTimeDiff * 5;

		// Update position
		m_vPos.fV[i] += m_vVelocity.fV[i] * fTimeDiff * 2;

		// Check for next position
		if (ASAbs(m_vPos.fV[i] - m_vNextPos.fV[i]) < 2.f) {
			if (i != 2) {
				if (!(rand() % 2))
					m_vNextPos.fV[i] = ((float) (rand() % 16000) / 100);
				else
					m_vNextPos.fV[i] = -((float) (rand() % 16000) / 100);
			} else
				m_vNextPos.fV[i] = -((float) (rand() % 1000) / 200);
		}
	}

	// Perform friction
	PerformFriction();

	// Check height
	CGame.pCLevel->GetHeight(m_vPos.fX, m_vPos.fY, fZ, true);
	if (m_vPos.fZ > fZ - 2.5f) {
		m_vNextPos.fZ = fZ - 2.5f;
		m_vPos.fZ -= fTimeDiff * 10;
	}

	{ // Setup rotation
		float fAngle = (float) (atan((m_vPos.fY - m_vNextPos.fY) / (m_vPos.fX - m_vNextPos.fX)) * AS_RAD_TO_DEG);
		ASTVector3D vRot = GetRot();

		vRot.fX = -m_vVelocity.fZ * 10;
		if (vRot.fZ < fAngle) vRot.fZ += fTimeDiff * 40;
		else				  vRot.fZ -= fTimeDiff * 40;
		SetRot(vRot);
	}
}
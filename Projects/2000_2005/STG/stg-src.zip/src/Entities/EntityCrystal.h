/*
	File: EntityCrystal.h

	Description: Crystal entity
*/

#ifndef __ENTITYCRYSTAL_H__
#define __ENTITYCRYSTAL_H__


// Classes
typedef class TEntityCrystal : public ASTEntity {

	public:


	private:
		ASTModelHandler m_CModel;
		ASTSoundHandler m_CCollectedSound;	// Collected sound


		/*
			Virtual entity functions
		*/
		virtual void CustomInitFunction();
		virtual void CustomDeInitFunction();
		virtual bool CustomFrustumFunction();
		virtual void CustomDrawTransparentFunction();
		virtual void CustomUpdateFunction();
		virtual void CustomCollisionFunction(const ASTCollisionPacked& pCCollPacked);
		virtual bool CustomProcessMessage(const int iMessage, const int iParameter, const void* pData);


} TEntityCrystal;


#endif // __ENTITYCRYSTAL_H__
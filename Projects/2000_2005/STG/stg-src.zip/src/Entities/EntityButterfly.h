/*
	File: EntityButterfly.h

	Description: Butterfly entity
*/

#ifndef __ENTITYBUTTERFLY_H__
#define __ENTITYBUTTERFLY_H__


// Classes
typedef class TEntityButterfly : public ASTEntity {

	public:


	private:
		ASTModelHandler m_CModel;

		ASTVector3D	m_vNextPos;	// Position were the entity should go


		/*
			Virtual entity functions
		*/
		virtual void CustomInitFunction();
		virtual void CustomDeInitFunction();
		virtual bool CustomFrustumFunction();
		virtual void CustomDrawSolidFunction();
		virtual void CustomUpdateFunction();


} TEntityButterfly;


#endif // __ENTITYBUTTERFLY_H__
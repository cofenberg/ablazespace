/*
	File: EntityDecoration.cpp
*/

#include <ASEngine.h>
#include "..\Game.h"


/*
	Adds the model mesh to the level
*/
void TEntityDecoration::AddModelMeshToLevel()
{
	// Add the models collision mesh
	if (CGame.pCLevel) CGame.pCLevel->m_lstCollisionMesh.Add(m_CModel.GetCollisionMesh());
}

/*
	Decoration entity initialisation function
*/
void TEntityDecoration::CustomInitFunction()
{
	// Load model
	m_CModel.Load(GetName());
    m_CModel.SetActive();
	m_CModel.SetEntity(this);
    m_CModel.SetAnimationFlags(ASeModelAniFlagPlay | ASeModelAniFlagLoop);
	m_CModel.SetAnimationFrame(rand() % m_CModel.GetAnimaionFrames());
}

/*
	Decoration entity de-initialisation function
*/
void TEntityDecoration::CustomDeInitFunction()
{
	// Remove the models collision mesh
	if (CGame.pCLevel) CGame.pCLevel->m_lstCollisionMesh.Remove(m_CModel.GetCollisionMesh());

	// Unload model
	m_CModel.Unload();
}

/*
	Checks whether the decoration entity is in the frustum or not
*/
bool TEntityDecoration::CustomFrustumFunction()
{
	return m_CModel.UpdateVisibility();
}

/*
	Decoration entity draw solid function
*/
void TEntityDecoration::CustomDrawSolidFunction()
{
	// Draw model
	glColor4f(1.f, 1.f, 1.f, 1.f);
	m_CModel.Draw();
}

/*
	Decoration entity update function
*/
void TEntityDecoration::CustomUpdateFunction()
{
	// Update model settings
	CConfig.Update(m_CModel);

	// Animate model
	m_CModel.Animate();
}

/*
	Decoration entity collision function
*/
void TEntityDecoration::CustomCollisionFunction(const ASTCollisionPacked& pCCollPacked)
{
}

/*
	Process messages
*/
bool TEntityDecoration::CustomProcessMessage(const int iMessage, const int iParameter, const void* pData)
{
	switch (iMessage) {
		case 0: break;
		default: break;
	}

	return false;
}
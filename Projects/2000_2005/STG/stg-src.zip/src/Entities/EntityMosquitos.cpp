/*
	File: EntityMosquitos.cpp
*/

#include <ASEngine.h>
#include "..\Game.h"
#include "..\ParticleGroups\ParticleGroupMosquitos.h"


/*
	Mosquitos entity initialisation function
*/
void TEntityMosquitos::CustomInitFunction()
{
	TParticleGroupMosquitos* pCEntity;

	// Initialize particle systems
	ASCreateEntity(pCEntity, TParticleGroupMosquitos, "Mosquitos particles");
	if (bCheatQuick) pCEntity->InitParticleGroup(2, "particle_mosquitos.tga");
	else			 pCEntity->InitParticleGroup(5, "particle_mosquitos.tga");
	pCEntity->SetupTextureAnimation(4, 4);
	pCEntity->SetBlendFunction(GL_DST_COLOR, GL_ZERO);
	m_CParticleEntity.Load(pCEntity);
}

/*
	Mosquitos entity de-initialisation function
*/
void TEntityMosquitos::CustomDeInitFunction()
{
	m_CParticleEntity.Unload(true);
}

/*
	Mosquitos entity update function
*/
void TEntityMosquitos::CustomUpdateFunction()
{
}

/*
	Process messages
*/
bool TEntityMosquitos::CustomProcessMessage(const int iMessage, const int iParameter, const void* pData)
{
	switch (iMessage) {
		case 0: break;
		default: break;
	}

	return false;
}
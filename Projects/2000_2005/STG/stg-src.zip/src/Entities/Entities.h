/*
	File: Entities.h

	Description: Entities
*/

#ifndef __ASENTITIES_H__
#define __ASENTITIES_H__


// Definitions
// Custom entity flags
enum EEntityFlag {
	eEntityFlagDie = 1, // Should the entity die?
};

// Messages
enum EEntityMessages {
	eEntityMessageCollected,	// The entity was collected
};


#endif // __ASENTITIES_H__
/*
	File: ActorUrl.h

	Description: Url actor
*/

#ifndef __ACTORURL_H__
#define __ACTORURL_H__


// Includes
#include "EntityActor.h"


// Classes
typedef class TActorUrl : public TEntityActor {

	public:
		/*
			Draws the hud
		*/
		void DrawHud();

		/*
			Returns the score
		*/
		int GetScore() const;

		/*
			Increases the score
		*/
		void IncScore(const int iScore);

		/*
			Returns the number of games
		*/
		int GetGames() const;

		/*
			Increases the number of games
		*/
		void IncGames(const int iGames);


	private:
		int   m_iScore;			// Score
		float m_fScoreTimer;	// Score decrease timer
		float m_fStandTimer;	// Stand timer
		bool  m_bAttackFrame;	// Attack frame
		bool  m_bAttack;		// Attack
		int   m_iCrystals;		// Number of collected crystals
		int   m_iGames;			// Number of games
		float m_fDustTimer;		// Dust timer

		bool	    m_bMoveCrystal;
		ASTVector3D m_vCrystalPos;

		ASTVector3D m_vShadowPos;		// Shadow position
		ASTVector3D m_vShadowVelocity;	// Shadow velocity

		// Models
		ASTEntityHandler m_CHeadEntity;
		ASTModelHandler  m_CHeadModel;
		ASTEntityHandler m_CCrystalEntity;
		ASTModelHandler  m_CCrystalModel;

		// Sounds
		ASTSoundHandler m_CAttackSound;
		ASTSoundHandler m_CJumpSound;
		ASTSoundHandler m_CPainSound;
		ASTSoundHandler m_CShockSound;
		ASTSoundHandler m_CFallingSound;
		ASTSoundHandler m_CRebirthSound;
		ASTSoundHandler m_CExtraLifeSound;
		ASTSoundHandler m_CReceiveGameSound;
		ASTSoundHandler m_CLowScore1Sound;
		ASTSoundHandler m_CLowScore2Sound;

		// Animations
		int ANIMATION_STAND;
		int ANIMATION_STAND2;
		int ANIMATION_BORING;
		int ANIMATION_BORING2;
		int ANIMATION_WALK;
		int ANIMATION_RUN;
		int ANIMATION_JUMP;
		int ANIMATION_ATTACK;
		int ANIMATION_PAIN;
		int ANIMATION_SHOCK;
		int ANIMATION_DIE;

		
		/*
			Virtual entity functions
		*/
		virtual void CustomDeInitFunction();
		virtual bool CustomFrustumFunction();
		virtual void CustomDrawSolidFunction();
		virtual void CustomDrawTransparentFunction();
		virtual void CustomUpdateFunction();
		virtual void CustomCollisionFunction(const ASTCollisionPacked& pCCollPacked);

		/*
			Virtual actor functions
		*/
		virtual void InitFunction();
		virtual bool ProcessMessage(const int iMessage, const int iParameter, const void* pData);

		/*
			Set stand animation
		*/
		void SetStandAnimation();

		/*
			Set boring animation
		*/
		void SetBoringAnimation();

		/*
			Set attack animation
		*/
		void SetAttackAnimation();

		/*
			Check boring
		*/
		void CheckBoring();

		/*
			Check the animations
		*/
		void CheckAnimations();

		/*
			Url is death
		*/
		void Death();

		/*
			Stops jumping
		*/
		void StopJumping();


} TActorUrl;


#endif // __ACTORURL_H__
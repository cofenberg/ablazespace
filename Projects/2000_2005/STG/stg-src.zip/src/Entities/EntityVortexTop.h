/*
	File: EntityVortexTop.h

	Description: Vortex top entity
*/

#ifndef __ENTITYVORTEXTOP_H__
#define __ENTITYVORTEXTOP_H__


// Classes
typedef class TEntityVortexTop : public ASTEntity {

	friend TEntityVortex;

	public:


	private:
		ASTModelHandler m_CModel;

		ASTVector3D m_vFixPos;	// Fixed position
		ASTVector3D m_vNextPos;	// Position were the entity should go


		/*
			Virtual entity functions
		*/
		virtual void CustomInitFunction();
		virtual void CustomDeInitFunction();
		virtual bool CustomFrustumFunction();
		virtual void CustomDrawSolidFunction();
		virtual void CustomUpdateFunction();

		/*
			Virtual actor functions
		*/
		virtual bool ProcessMessage(const int iMessage, const int iParameter, const void* pData);


} TEntityVortexTop;


#endif // __ENTITYVORTEXTOP_H__
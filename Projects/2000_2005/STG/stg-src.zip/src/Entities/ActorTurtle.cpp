/*
	File: ActorTurtle.cpp
*/

#include <ASEngine.h>
#include "..\Game.h"
#include "..\ParticleGroups\ParticleGroupStars.h"


/*
	Turtle actor initialisation function
*/
void TActorTurtle::InitFunction()
{
	// Load model
	m_CModel.Load("turtle.md2");
	m_CModel.SetActive();
	m_CModel.SetEntity(this);
	m_CModel.SetAnimationFlags(ASeModelAniFlagPlay | ASeModelAniFlagLoop);
	SetCollisionRadius(m_CModel.GetRadius());

	// Get animations
	ANIMATION_STAND = m_CModel.GetAnimationID("stand");
	ANIMATION_WALK  = m_CModel.GetAnimationID("walk");
	ANIMATION_RUN   = m_CModel.GetAnimationID("run");
	ANIMATION_BITE  = m_CModel.GetAnimationID("bite");
	ANIMATION_HUNT  = m_CModel.GetAnimationID("hunt");
	ANIMATION_DIE   = m_CModel.GetAnimationID("die");

	// Load sound
	 m_CAttackSound.Load("turtle_attack.mp3");
	m_CCrushedSound.Load("turtle_crushed.mp3");

	// Activate and setup collision detection
	SetCollisionFlags(ASeCollisionFlagEntities | ASeCollisionFlagSphere | ASeCollisionFlagSphereResponse);
	SetCollisionRadius(m_CModel.GetRadius());

	// Setup data
	SetRot(-90.f, 0.f, 0.f);
	m_bAttackFrame = false;
	m_bAttack	   = false;
	m_CModel.SetAnimationSpeed();
	m_CModel.SetAnimationFlags(ASeModelAniFlagPlay | ASeModelAniFlagLoop);
	m_CModel.SetAnimation(ANIMATION_STAND);

	// Increase level turtle counter
	CGame.pCLevel->iTurtles++;
}

/*
	Turtle entity de-initialisation function
*/
void TActorTurtle::CustomDeInitFunction()
{
	// Unload model
	m_CModel.Unload();

	// Unload sounds
	 m_CAttackSound.Unload();
	m_CCrushedSound.Unload();
}

/*
	Checks whether the Turtle entity is in the frustum or not
*/
bool TActorTurtle::CustomFrustumFunction()
{
	if (m_CModel.UpdateVisibility()) return true;

	return false;
}

/*
	Turtle entity draw function
*/
void TActorTurtle::CustomDrawSolidFunction()
{
	// Draw model
	glColor3f(1.f, 1.f, 1.f);
	m_CModel.Draw();

	// Draw shadow
	CGame.pCLevel->DrawShadow(m_vPos, m_vScale.GetLength() * 2);
}

/*
	Turtle entity update function
*/
void TActorTurtle::CustomUpdateFunction()
{
	float fTimeDiff = _AS::CTimer.GetTimeDifference();

	// Update model settings
	CConfig.Update(m_CModel);

	// Animate model
	m_CModel.Animate();

	if (!(GetFlags() & eActorFlagDeath)) {
		SetRot(-90.f, 0.f, 0.f);
	} else {
		if (m_CModel.GetAnimation() == ANIMATION_DIE && m_CModel.IsLastAnimationFrame()) {
			m_vPos.fZ	  += fTimeDiff / 20;
			m_vScale      -= fTimeDiff / 20;
			if (m_vScale.fX < 0.f && m_vScale.fY < 0.f && m_vScale.fZ < 0.f) Remove();
		}
	}

	CheckAnimations();
}

/*
	Turtle entity collision function
*/
void TActorTurtle::CustomCollisionFunction(const ASTCollisionPacked& pCCollPacked)
{
	if (GetFlags() & eActorFlagDeath) return;

	if (pCCollPacked.pCEntity == CGame.pCUrlActor) {
		TActorUrl* pCUrlActor = (TActorUrl*) pCCollPacked.pCEntity;
	
		// Is Url death?	
		if (pCUrlActor->GetFlags() & eActorFlagDeath) return;

		// Check if the turtle should bite
		if (m_CModel.GetAnimation() != ANIMATION_BITE) {
			ASBOUNDINGBOX fBoundingBox;
			ASTVector3D vPos;
			
			vPos = m_vPos;
			vPos.fZ -= 2;
			if (pCUrlActor->GetModelHandler()) pCUrlActor->GetModelHandler()->GetBoundingBox(fBoundingBox);
			if (_AS::CCollision.IsLineInBox(vPos, vPos + m_vDirVector * 1000, fBoundingBox)) 
				SetAttackAnimation();
		} else SetAttackAnimation();

		// Perform biting
		if (m_bAttack) {
			{ // Create stars
				TParticleGroupStars* pCEntity;

				// Initialize particle systems
				ASCreateEntity(pCEntity, TParticleGroupStars, "Stars particles");
				pCEntity->SetPos(pCUrlActor->GetPos());
				pCEntity->InitParticleGroup(2, "particle_star.tga");
				pCEntity->SetupTextureAnimation(4, 4);
				pCEntity->SetBlending(false);
			}

			SendMessage(pCUrlActor, eActorMessageHit, -10);
		}

		if (pCUrlActor->GetGravityVector().fZ > 1.f) { // Crush the turtle
			ASTVector3D vVel = pCUrlActor->GetVelocityVector();
			ASTEntity* pCEntity;
			float fX, fY, fZ;

			pCUrlActor->SetVelocityVector(ASTVector3D(vVel.fX, vVel.fY, -vVel.fZ));
			pCUrlActor->SetGravityVector(-pCUrlActor->GetGravityVector() / 2);
			SendMessage(pCUrlActor, eActorMessageHit, 0);
			PlaySound(m_CCrushedSound);
			m_CModel.SetAnimationSpeed(0.8f);
			m_CModel.SetAnimationFlags(ASeModelAniFlagPlay);
			m_CModel.SetAnimation(ANIMATION_DIE);
			SetFlags(GetFlags() | eActorFlagDeath);
			SetCollisionFlags(0);

			// Decrease level turtle counter
			CGame.pCLevel->iTurtles--;

			// Give player some points and bonus time
			if (CGame.pCUrlActor) {
				CGame.pCUrlActor->IncScore(100);
				CGame.pCLevel->fTime += 2.f;
			}

			// Create crystals
			for (int i = 0; i < 3; i++) {
				ASCreateEntity(pCEntity, TEntityCrystal, "Crystal");
				pCEntity->SetPos(GetPos());
				fX = (float) (rand() % 200) / 50.f;
				if (!(rand() % 2)) fX = -fX;
				fY = (float) (rand() % 200) / 50.f;
				if (!(rand() % 2)) fY = -fY;
				fZ = -3.f - ((float) (rand() % 200) / 50.f);
				pCEntity->SetVelocityVector(ASTVector3D(fX, fY, fZ));
				pCEntity->SetScale(0.01f, 0.01f, 0.01f);
			}

			{ // Create stars
				TParticleGroupStars* pCEntity;

				// Initialize particle systems
				ASCreateEntity(pCEntity, TParticleGroupStars, "Stars particles");
				pCEntity->SetPos(m_vPos);
				pCEntity->InitParticleGroup(20, "particle_star.tga");
				pCEntity->SetupTextureAnimation(4, 4);
				pCEntity->SetBlending(false);
			}

		}
	}
}

/*
	Process messages
*/
bool TActorTurtle::ProcessMessage(const int iMessage, const int iParameter, const void* pData)
{
	switch (iMessage) {
		case 0: break;
		default: break;
	}

	return false;
}

/*
	Set attack animation
*/
void TActorTurtle::SetAttackAnimation()
{
	if (m_CModel.GetAnimation() != ANIMATION_BITE) m_CAttackSound.Play();
	m_CModel.SetAnimationFlags(ASeModelAniFlagPlay | ASeModelAniFlagLoop);
	m_CModel.SetAnimation(ANIMATION_BITE);
	m_CModel.SetAnimationSpeed(2);
	if (m_CModel.GetAnimationFrame(false) == 35) {
		if (!m_bAttackFrame) {
			m_bAttack = true;
			m_bAttackFrame = true;
		} else m_bAttack = false;
	} else {
		m_bAttackFrame = false;
		m_bAttack	   = false;
	}
}

/*
	Check the animations
*/
void TActorTurtle::CheckAnimations()
{
	if (m_CModel.GetAnimation() != ANIMATION_BITE) m_bAttackFrame = false;
	else {
		if (m_CModel.IsLastAnimationFrame()) m_CModel.SetAnimation(ANIMATION_STAND);
	}
	if (!m_bAttackFrame) m_bAttack = false;
}
/*
	File: EntityMosquitos.h

	Description: Mosquitos entity
*/

#ifndef __ENTITYMOSQUITOS_H__
#define __ENTITYMOSQUITOS_H__


// Classes
typedef class TEntityMosquitos : public ASTEntity {

	public:


	private:
		ASTEntityHandler m_CParticleEntity;	// Mosquitos particles

		/*
			Virtual entity functions
		*/
		virtual void CustomInitFunction();
		virtual void CustomDeInitFunction();
		virtual void CustomUpdateFunction();
		virtual bool CustomProcessMessage(const int iMessage, const int iParameter, const void* pData);


} TEntityMosquitos;


#endif // __ENTITYMOSQUITOS_H__
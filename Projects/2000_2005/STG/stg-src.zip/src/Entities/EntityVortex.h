/*
	File: EntityVortex.h

	Description: Vortex entity
*/

#ifndef __ENTITYVORTEX_H__
#define __ENTITYVORTEX_H__


// Classes
typedef class TEntityVortex : public ASTEntity {

	public:


	private:
		ASTModelHandler m_CModel;
		ASTModelHandler m_CCollisionModel;

		ASTEntityHandler m_CLightEntity;	// Light entity
		ASTVector3D		 m_vFixLightPos;	// Fixed position
		ASTVector3D		 m_vNextLightPos;	// Position were the entity should go

		ASTEntityHandler m_CTopEntity;				// Top vortex entity
		ASTEntityHandler m_pCSpringParticleEntity;  // Spring particle entity

		ASTSoundHandler m_CSound;
		
		/*
			Virtual entity functions
		*/
		virtual void CustomInitFunction();
		virtual void CustomDeInitFunction();
		virtual bool CustomFrustumFunction();
		virtual void CustomDrawSolidFunction();
		virtual void CustomUpdateFunction();
		virtual bool CustomProcessMessage(const int iMessage, const int iParameter, const void* pData);


} TEntityVortex;


// Includes
#include "EntityVortexTop.h"


#endif // __ENTITYVORTEX_H__
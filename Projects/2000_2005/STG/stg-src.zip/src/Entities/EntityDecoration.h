/*
	File: EntityDecoration.h

	Description: Decoration entity
*/

#ifndef __ENTITYPLANT_H__
#define __ENTITYPLANT_H__


// Classes
typedef class TEntityDecoration : public ASTEntity {

	public:
		/*
			Adds the model mesh to the level
		*/
		void AddModelMeshToLevel();


	private:
		ASTModelHandler m_CModel;


		/*
			Virtual entity functions
		*/
		virtual void CustomInitFunction();
		virtual void CustomDeInitFunction();
		virtual bool CustomFrustumFunction();
		virtual void CustomDrawSolidFunction();
		virtual void CustomUpdateFunction();
		virtual void CustomCollisionFunction(const ASTCollisionPacked& pCCollPacked);
		virtual bool CustomProcessMessage(const int iMessage, const int iParameter, const void* pData);


} TEntityDecoration;


#endif // __ENTITYPLANT_H__
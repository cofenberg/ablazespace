/*
	File: EntityCrystal.cpp
*/

#include <ASEngine.h>
#include "..\Game.h"
#include "..\ParticleGroups\ParticleGroupCollect.h"


/*
	Crystal entity initialisation function
*/
void TEntityCrystal::CustomInitFunction()
{
	// Load model
	m_CModel.Load("crystal.md2");
    m_CModel.SetActive();
	m_CModel.SetEntity(this);

	// Load sound
	m_CCollectedSound.Load("crystal_collected.mp3");

	// Activate and setup collision detection
	SetCollisionFlags(ASeCollisionFlagEntities | ASeCollisionFlagSphere);
	SetCollisionRadius(m_CModel.GetRadius());

	// Increase level crystal counter
	CGame.pCLevel->iCrystals++;
}

/*
	Crystal entity de-initialisation function
*/
void TEntityCrystal::CustomDeInitFunction()
{
	// Unload model
	m_CModel.Unload();

	// Unload sound
	m_CCollectedSound.Unload();
}

/*
	Checks whether the crystal entity is in the frustum or not
*/
bool TEntityCrystal::CustomFrustumFunction()
{
	return m_CModel.UpdateVisibility();
}

/*
	Crystal entity draw transparent function
*/
void TEntityCrystal::CustomDrawTransparentFunction()
{
	// Draw model
	glColor4f(1.f, 1.f, 1.f, 0.9f);
	glEnable(GL_BLEND);
	m_CModel.Draw();

	// Draw shadow
	CGame.pCLevel->DrawShadow(m_vPos, 3.f);
}

/*
	Crystal entity update function
*/
void TEntityCrystal::CustomUpdateFunction()
{
	float fTimeDiff = _AS::CTimer.GetTimeDifference();
	int i;

	// Update model settings
	CConfig.Update(m_CModel);

	// Check movement
	m_vPos += m_vVelocity * fTimeDiff;
	PerformFriction();

	// Check death
	if (GetCustomFlags() & eEntityFlagDie) {
		m_vVelocity.fZ -= fTimeDiff * 20;
		m_vScale -= fTimeDiff;
		if (m_vScale.fX <= 0.f && m_vScale.fY <= 0.f && m_vScale.fZ <= 0.f) {
			m_vScale = 0.f;
			Remove();
		}
		IncRot(0.f, 0.f, -fTimeDiff * 50 - m_vVelocity.GetLength() * fTimeDiff * 100);
		m_vPos += m_vVelocity * fTimeDiff;
	} else {
		// Check scale
		for (i = 0; i < 3; i++) {
			m_vScale.fV[i] += fTimeDiff;
			if (m_vScale.fV[i] > 1.f) m_vScale.fV[i] = 1.f;
		}

		IncRot(0.f, 0.f, -fTimeDiff * 50);
	}
}

/*
	Crystal entity collision function
*/
void TEntityCrystal::CustomCollisionFunction(const ASTCollisionPacked& pCCollPacked)
{
}

/*
	Process messages
*/
bool TEntityCrystal::CustomProcessMessage(const int iMessage, const int iParameter, const void* pData)
{
	switch (iMessage) {
		case eEntityMessageCollected:
			if (m_vScale != 1.f) break;

			PlaySound(m_CCollectedSound);
			SetCustomFlags(GetCustomFlags() | eEntityFlagDie);

			// Decrease level crystal counter
			CGame.pCLevel->iCrystals--;

			{ // Create collect particle group
				TParticleGroupCollect* pCEntity;
				TParticleGroupCollect::SInitData SInitData;

				// Initialize particle systems
				ASCreateEntity(pCEntity, TParticleGroupCollect, "Collect particles");
				SInitData.pModelHandler = &m_CModel;			
				pCEntity->InitParticleGroup(6, "particle_collect.jpg", &SInitData);
				pCEntity->SetupTextureAnimation(4, 4);
			}
			break;

		default: break;
	}

	return false;
}
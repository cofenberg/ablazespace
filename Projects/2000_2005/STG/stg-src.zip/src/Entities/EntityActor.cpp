/*
	File: Actor.cpp
*/

#include <ASEngine.h>
#include "EntityActor.h"


/*
	Gets the actor flags
*/
int TEntityActor::GetFlags() const
{
	return m_iFlags;
}

/*
	Sets the actor flags
*/
void TEntityActor::SetFlags(const int iFlags)
{
	m_iFlags = iFlags;
}

/*
	Returns the number of maximum lifes
*/
int TEntityActor::GetMaxLives() const
{
	return m_iMaxLives;
}

/*
	Sets the number of maximum lives
*/
void TEntityActor::SetMaxLives(const int iMaxLives)
{
	m_iMaxLives = iMaxLives;
	if (m_iMaxLives < 0) m_iMaxLives = 0;
}

/*
	Returns the number of lifes
*/
int TEntityActor::GetLives() const
{
	return m_iLives;
}

/*
	Sets the number of lives
*/
void TEntityActor::SetLives(const int iLives)
{
	if (iLives == -1) m_iLives = m_iMaxLives;
	else {
		m_iLives = iLives;
		if (m_iLives < 0)			m_iLives = 0;
		if (m_iLives > m_iMaxLives) m_iLives = m_iMaxLives;
	}
}

/*
	Increases the number of lives
*/
void TEntityActor::IncLives(const int iLives)
{
	// Is the actor immortal?
	if (m_iFlags & eActorFlagImmortal && iLives < 0) return;

	m_iLives += iLives;
	if (m_iLives < 0)			m_iLives = 0;
	if (m_iLives > m_iMaxLives) m_iLives = m_iMaxLives;
}

/*
	Returns the maximum health
*/
float TEntityActor::GetMaxHealth() const
{
	return m_fMaxHealth;
}

/*
	Sets the maximum health
*/
void TEntityActor::SetMaxHealth(const float fMaxHealth)
{
	m_fMaxHealth = fMaxHealth;
	if (m_fMaxHealth < 0.f)	m_fMaxHealth = 0.f;
}

/*
	Returns the health
*/
float TEntityActor::GetHealth() const
{
	return m_fHealth;
}

/*
	Sets the health
*/
void TEntityActor::SetHealth(const float fHealth)
{
	if (fHealth == -1.f) m_fHealth = m_fMaxHealth;
	else {
		m_fHealth = fHealth;
		if (m_fHealth < 0.f) {
			m_fHealth = 0.f;
			SendMessage(this, eActorMessageDie);
		}
		if (m_fHealth > m_fMaxHealth) m_fHealth = m_fMaxHealth;
	}
}

/*
	Increases the health
*/
void TEntityActor::IncHealth(const float fHealth)
{
	// Is the actor immortal?
	if (m_iFlags & eActorFlagImmortal && fHealth < 0.f) return;

	m_fHealth += fHealth;
	if (m_fHealth < 0.f) {
		m_fHealth = 0.f;
		SendMessage(this, eActorMessageDie);
	}
	if (m_fHealth > m_fMaxHealth) m_fHealth = m_fMaxHealth;
}

/*
	Returns a pointer to the entities model handler
*/
ASTModelHandler* TEntityActor::GetModelHandler()
{
	return &m_CModel;
}

/*
	Actor initialization function
*/
void TEntityActor::CustomInitFunction()
{
	m_iFlags	  = 0;
	m_iLives	  = 1;
	m_iMaxLives   = 1;
	m_fHealth	  = 100.f;
	m_fMaxHealth  = 100.f;
	m_fDeathTimer = 0.f;

	// Call the actor specific initialization function
	InitFunction();
}

/*
	Actor process messages
*/
bool TEntityActor::CustomProcessMessage(const int iMessage, const int iParameter, const void* pData)
{
	switch (iMessage) {
		case eActorMessageHit: IncHealth((float) iParameter); break;
		case eActorMessageDie: m_iFlags |= eActorFlagDeath;  break;

		default: break;
	}

	return ProcessMessage(iMessage, iParameter, pData);
}

/*
	Actor specific initialization
*/
void TEntityActor::InitFunction()
{
}

/*
	Process messages
*/
bool TEntityActor::ProcessMessage(const int iMessage, const int iParameter, const void* pData)
{
	switch (iMessage) {
		case 0: break;
		default: break;
	}

	return false;
}
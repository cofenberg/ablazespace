/*
	File: EntityCamera.cpp
*/

#include <ASEngine.h>
#include "..\Game.h"


/*
	Camera update function
*/
void TEntityCamera::CustomCameraUpdateFunction()
{
}
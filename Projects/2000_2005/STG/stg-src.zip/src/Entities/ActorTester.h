/*
	File: ActorTester.h

	Description: Tester actor
*/

#ifndef __ACTORTESTER_H__
#define __ACTORTESTER_H__


// Includes
#include "EntityActor.h"


// Classes
typedef class TActorTester : public TEntityActor {

	public:
		/*
			Adds the model mesh to the level
		*/
		void AddModelMeshToLevel();


	private:
		ASTTextureHandler m_CTexture;	// Tester texture

		ASTModelHandler m_CCollisionModel;

		
		// Sounds
		ASTSoundHandler m_CStartTestingSound;
		ASTSoundHandler m_CTestingFinishedSound;
		ASTSoundHandler m_CHit1Sound;
		ASTSoundHandler m_CHit2Sound;
		ASTSoundHandler m_CHit3Sound;
		ASTSoundHandler m_CAngry1Sound;
		ASTSoundHandler m_CAngry2Sound;

		float m_fTestingTimer;
		float m_fAngryTimer;
		bool  m_bAngryDemolition;
		float m_fTestingSpeed;

		// Animations
		int ANIMATION_TESTING;
		int ANIMATION_BORING;
		int ANIMATION_ANGRY;

		
		/*
			Virtual entity functions
		*/
		virtual void CustomDeInitFunction();
		virtual bool CustomFrustumFunction();
		virtual void CustomDrawSolidFunction();
		virtual void CustomUpdateFunction();
		virtual void CustomCollisionFunction(const ASTCollisionPacked& pCCollPacked);

		/*
			Virtual actor functions
		*/
		virtual void InitFunction();
		virtual bool ProcessMessage(const int iMessage, const int iParameter, const void* pData);

		/*
			Make the tester angry
		*/
		void MakeAngry();


} TActorTester;


#endif // __ACTORTESTER_H__
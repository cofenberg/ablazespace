/*
	File: ActorTurtle.h

	Description: Turtle actor
*/

#ifndef __ACTORTURTLE_H__
#define __ACTORTURTLE_H__


// Includes
#include "EntityActor.h"


// Classes
typedef class TActorTurtle : public TEntityActor {

	public:


	private:
		// Animations
		int ANIMATION_STAND;
		int ANIMATION_WALK;
		int ANIMATION_RUN;
		int ANIMATION_BITE;
		int ANIMATION_HUNT;
		int ANIMATION_DIE;

		bool m_bAttackFrame;
		bool m_bAttack;

		// Sounds
		ASTSoundHandler m_CAttackSound;
		ASTSoundHandler m_CCrushedSound;


		/*
			Virtual entity functions
		*/
		virtual void CustomDeInitFunction();
		virtual bool CustomFrustumFunction();
		virtual void CustomDrawSolidFunction();
		virtual void CustomUpdateFunction();
		virtual void CustomCollisionFunction(const ASTCollisionPacked& pCCollPacked);

		/*
			Virtual actor functions
		*/
		virtual void InitFunction();
		virtual bool ProcessMessage(const int iMessage, const int iParameter, const void* pData);

		/*
			Set attack animation
		*/
		void SetAttackAnimation();

		/*
			Check the animations
		*/
		void CheckAnimations();


} TActorTurtle;


#endif // __ACTORTURTLE_H__
/*
	File: EntityUrl.h

	Description: Actor entity
*/

#ifndef __ENTITYACTOR_H__
#define __ENTITYACTOR_H__


// Definitions
// Actor flags
enum EActorFlags {
	eActorFlagImmortal = 1, // Actor couldn't die
	eActorFlagDeath    = 2,	// The actor is death
	eActorFlagFalling  = 4,	// The actor falls down
};

// Messages
enum EActorMessages {
	eActorMessageHit,	// The actor was hit
	eActorMessageDie,	// The actor dies
};


// Classes
typedef class TEntityActor : public ASTEntity {

	public:
		/*
			Gets the actor flags

			Returns:
				int -> Actor flags
		*/
		int GetFlags() const;
		
		/*
			Sets the actor flags

			Parameters:
				int iFlags -> Actor flags which should be set
		*/
		void SetFlags(const int EFlags);

		/*
			Returns the maximum number of lifes

			Returns:
				int -> Maximum number of lives
		*/
		int GetMaxLives() const;

		/*
			Sets the maximum number of lives

			Parameters:
				int iMaxLives -> Maximum number of lives
		*/
		void SetMaxLives(const int iMaxLives);

		/*
			Returns the number of lifes

			Returns:
				int -> Number of lives
		*/
		int GetLives() const;

		/*
			Sets the number of lives

			Parameters:
				int iLives -> Number of lives, if '-1' the maximum lives will be set
		*/
		void SetLives(const int iLives = -1);

		/*
			Increases the number of lives

			Parameters:
				int iLives -> Number of lives which should be added
		*/
		void IncLives(const int iLives);

		/*
			Returns the maximum health

			Returns:
				float -> Maximum health
		*/
		float GetMaxHealth() const;

		/*
			Sets the maximum health

			Parameters:
				float fMaxHealth -> Maximum health
		*/
		void SetMaxHealth(const float fMaxHealth);

		/*
			Returns the health

			Returns:
				float -> Health
		*/
		float GetHealth() const;

		/*
			Sets the health

			Parameters:
				float fHealth -> Health, if '-1' the maximum health will be set
		*/
		void SetHealth(const float fHealth = -1.f);

		/*
			Increases the health

			Parameters:
				float fHealth -> Health which should be added
		*/
		void IncHealth(const float fHealth);

		/*
			Returns a pointer to the entities model handler

			Returns:
				ASTModelHandler* -> Pointer to the entities model handler
		*/
		virtual ASTModelHandler* GetModelHandler();


	public:
		ASTModelHandler m_CModel;		// Actors model
		float			m_fDeathTimer;	// Death delay timer


	private:
		int	  m_iFlags;			// Actor flags
		int   m_iLives;			// Number of lives
		int	  m_iMaxLives;		// Maximum number of lives
		float m_fHealth;		// Health
		float m_fMaxHealth;		// Maximum health


		/*
			Virtual entity functions

			Notes:
				- You shouldn't overload this virtual functions
		*/
		virtual void CustomInitFunction();
		virtual bool CustomProcessMessage(const int iMessage, const int iParameter = 0, const void* pData = NULL);

		/*
			Virtual actor functions
		*/
		virtual void InitFunction();
		virtual bool ProcessMessage(const int iMessage, const int iParameter, const void* pData);


} TEntityActor;


#endif // __ENTITYACTOR_H__
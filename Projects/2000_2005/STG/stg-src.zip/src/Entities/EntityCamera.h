/*
	File: EntityCamera.h

	Description: Camera entity
*/

#ifndef __ENTITYCAMERA_H__
#define __ENTITYCAMERA_H__


// Includes
#include "EntityCamera.h"


// Classes
typedef class TEntityCamera : public ASTCamera {

	public:


	private:
		/*
			Virtual camera functions
		*/
		virtual void CustomCameraUpdateFunction();


} TEntityCamera;


#endif // __ENTITYCAMERA_H__
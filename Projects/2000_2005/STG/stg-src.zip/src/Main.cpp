/*
	File: Main.cpp
*/

#include <ASEngine.h>
#include "Game.h"


// Variables
bool bCheatsActivated;
bool bCheatImmotral;
bool bCheatNoMosquitos;
bool bCheatNoTurtles;
bool bCheatUnlimitedLives;
bool bCheatNoScoreDecrease;
bool bCheatNoTimeLimit;
bool bCheatQuick;


/*
	Application main function
*/
int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	char szTemp[MAX_PATH];
	LPSTR lpTemp;

	// Evaluate commando line
	bCheatsActivated      = false;
	bCheatImmotral        = false;
	bCheatNoMosquitos     = false;
	bCheatNoTurtles       = false;
	bCheatUnlimitedLives  = false;
	bCheatNoScoreDecrease = false;
	bCheatNoTimeLimit	  = false;
	bCheatQuick			  = false;
	lpTemp = lpCmdLine;
	for (;;) {
		if (sscanf(lpTemp, "%s", szTemp) == EOF) break;

		// Check program parameter
		if (!strcmp(szTemp, "-cheats")) {
			_AS::CLog.Output("Cheats activated");
			bCheatsActivated = true;
		}

		// Check cheats
		if (bCheatsActivated) {
			if (!strcmp(szTemp, "-immortal"))		 bCheatImmotral		   = true;
			if (!strcmp(szTemp, "-nomosquitos"))	 bCheatNoMosquitos	   = true;
			if (!strcmp(szTemp, "-noturtles"))		 bCheatNoTurtles 	   = true;
			if (!strcmp(szTemp, "-unlimitedlives"))  bCheatUnlimitedLives  = true;
			if (!strcmp(szTemp, "-noscoredecrease")) bCheatNoScoreDecrease = true;
			if (!strcmp(szTemp, "-notimelimit"))	 bCheatNoTimeLimit     = true;
			if (!strcmp(szTemp, "-quick"))			 bCheatQuick		   = true;
		}

		if (!*(lpTemp + strlen(szTemp))) break;
		lpTemp += strlen(szTemp) + 1;
	}

	#ifdef _DEBUG
//		bCheatsActivated      = true;
//		bCheatImmotral        = true;
//		bCheatNoMosquitos     = true;
//		bCheatNoTurtles       = true;
		bCheatUnlimitedLives  = true;
		bCheatNoScoreDecrease = true;
		bCheatNoTimeLimit     = true;
		bCheatQuick			  = true;
	#endif

	// Initialize AS-Engine
	if (_AS::Init()) return 1;

	// Load game texts
	CText.Load(LANGUAGETEXTFILE);

	// Load the configurations
	CConfig.Load();

	// Load the control configurations
	CControl.Load();

	// Initialize the game
	CGame.Init();

	// Go into the engines main loop
	_AS::MainLoop();

	// Save the control configurations
	CControl.Save();

	// Save the configurations
	CConfig.Save();

	// De-initialize AS-Engine
	if (_AS::DeInit()) return 1; // It wasn't possible to de-initialize the engine!

	// That's all! ;-)
	return 0;
}
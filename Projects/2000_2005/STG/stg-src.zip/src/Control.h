/*
	File: Control.h

	Description: Control stuff
*/


#ifndef __CONTROL_H__
#define __CONTROL_H__


// Inlcudes
#include "Menus.h"


// Definitions
#define CONTROLFILE "control"	// Name of the standard control configuration file


// Classes
typedef class TControl {

	friend TMenus;
	
	public:
		/*
			Initialize the configuration

			Returns:
				bool -> 'false' if all went fine else 'true'

			Notes:
				- Loads automatically the standard config file 'control.ini' 
		*/
		bool Init();

		/*
			Load a configuration

			Parameters:
				char* pszFilename -> Filename of the configuration file

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Load(const char* pszFilename = CONTROLFILE);

		/*
			Save the configuration

			Parameters:
				char* pszFilename -> Filename of the configuration file

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Save(const char* pszFilename = CONTROLFILE);

		/*
			Check if the configurations are valid

			Returns:
				bool -> 'false' if all configurations were valid else 'true'

			Notes:
				- You should check the configurations if you want to go sure that
				  all settings are valid
		*/
		bool Check();

		/*
			Enumerates how often a key is binded

			Parameters:
				int iKey -> Key that should be enumerated

			Returns:
				int -> The number of key bindings using this key

			Notes:
				- Use this function to avoid that a key is binded more than one time
		*/
		int EnumerateKeyUsage(const int iKey);

		/*
			Resets the configurations
		*/
		void Reset();

		/*
			Returns the given keys
		*/
		int GetLeftKey() const;
		int GetRightKey() const;
		int GetUpKey() const;
		int GetDownKey() const;
		int GetRunKey() const;
		int GetJumpKey() const;
		int GetAttackKey() const;
		int GetPauseKey() const;
		
		/*
			Sets the given keys
		*/
		void SetLeftKey(const int iKey);
		void SetRightKey(const int iKey);
		void SetUpKey(const int iKey);
		void SetDownKey(const int iKey);
		void SetRunKey(const int iKey);
		void SetJumpKey(const int iKey);
		void SetAttackKey(const int iKey);
		void SetPauseKey(const int iKey);


	private:
		char m_szFilename[256];	// Configuration filename
		bool m_bLoaded;			// Is a configuration already loaded?

		int m_iLeftKey, m_iRightKey, m_iUpKey, m_iDownKey,
			m_iRunKey, m_iJumpKey, m_iAttackKey, m_iPauseKey;


} TControl;


// Variables
extern TControl CControl;


#endif // __CONTROL_H__
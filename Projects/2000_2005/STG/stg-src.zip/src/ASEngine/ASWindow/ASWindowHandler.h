/*
	File: ASWindowHandler.h

	Description: User window devise
*/


#ifndef __ASWINDOWHANDLER_H__
#define __ASWINDOWHANDLER_H__


// Classes
typedef class ASTWindowHandler {

	friend ASTWindow;


	public:
		/*
			Constructor
		*/
		AS_API ASTWindowHandler();

		/*
			Destructor
		*/
		AS_API ~ASTWindowHandler();

		/*
			Creates a window

			Parameters:
			    *pCustomDrawFunction		-> Pointer to a custom draw function
			    *pCustomUpdateFunction		-> Pointer to a custom draw function
				(*pCustomMessagesProcedure) -> Pointer to a cutom message procedure
				HMENU hMenu					-> A window menu
			    char* pszTitle				-> Title of the window
				int   iWidth & iHeight		-> New window size. If it's less than 0 the size will be
											   set to configuration standard
				char* pszClassName			-> The window class name

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Create(bool (*pCustomDrawFunction)(ASTWindow* pCWindow) = NULL,
						   bool (*pCustomUpdateFunction)(ASTWindow* pCWindow) = NULL,
						   long (*pCustomMessagesProcedure)(HWND hWnd, unsigned uMsg,
														    WPARAM wParam, LPARAM lParam) = NULL,
			   			   HMENU hMenu = NULL,
						   const char* pszTitle = ASENGINE,
						   int iWidth = -1, int iHeight = -1,
						   const char* pszClassName = NULL);

		/*
			Returns if the window is created or not

			Returns:
				bool -> 'true' if the window is created else 'false'
		*/
		AS_API bool IsCreated() const;

		/*
			Destroys the window

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Destroy();


		/*
			Returns the window handlers window

			Returns:
				ASTWindow* -> Pointer to the window handlers window
		*/
		AS_API ASTWindow* GetWindow() const;


	private:
		ASTWindow* m_pCWindow; // Pointer to the window this handler uses


} ASTWindowHandler;


#endif // __ASWINDOWHANDLER_H__
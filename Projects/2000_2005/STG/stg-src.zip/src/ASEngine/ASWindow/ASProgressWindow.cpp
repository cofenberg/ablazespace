/*
	File: ASProgressWindow.cpp
*/

#include <ASEngineDll.h>
#include <commctrl.h>


/*
	Constructor
*/
ASTProgressWindow::ASTProgressWindow()
{
	memset(this, 0, sizeof(ASTProgressWindow));
}

/*
	Destructor
*/
ASTProgressWindow::~ASTProgressWindow()
{
	Destroy();
}

/*
	Creates the progress window
*/
bool ASTProgressWindow::Create(const char* pszTitle)
{
	WNDCLASSEX wcex;	// Window class structure
	HFONT hFont;
	
	// Register the window class
	wcex.cbSize			= sizeof(WNDCLASSEX); 
	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC) ProgressWndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= GetModuleHandle(NULL);
	wcex.hIcon			= NULL;
	wcex.hCursor		= NULL;
	wcex.hbrBackground	= (HBRUSH) GetSysColorBrush(COLOR_MENU);
	wcex.lpszMenuName	= NULL;
	wcex.lpszClassName	= "ProgressWindowClass";
	wcex.hIconSm		= NULL;
	if (!RegisterClassEx(&wcex)) return true;

	// Create the window and center it on the screen
	if (!(m_hWndProgress = CreateWindowEx(WS_EX_TOOLWINDOW, "ProgressWindowClass", 
									      pszTitle, WS_POPUP | WS_CLIPCHILDREN | WS_CAPTION, 
										  GetSystemMetrics(SM_CXSCREEN) / 2 - 300, 
										  GetSystemMetrics(SM_CYSCREEN) / 2 - 55, 
										  600, 110, NULL, NULL, GetModuleHandle(NULL), NULL)))
		return true;

	// Init the common controls libary
	InitCommonControls();

	// Create the progress bar control
	if (!(m_hWndProgressBar = CreateWindowEx(0, PROGRESS_CLASS, (LPSTR) NULL, 
											 WS_CHILD | WS_VISIBLE | PBS_SMOOTH, 10, 10, 575, 22,
											 m_hWndProgress, (HMENU) 0, GetModuleHandle(NULL), NULL)))
		return true;

	// Set range to 0 - 100
	SendMessage(m_hWndProgressBar, PBM_SETRANGE, 0, MAKELPARAM(0, 100));

	// Create the static control
	if (!(m_hWndStatic = CreateWindow("STATIC", (LPSTR) 0, SS_CENTER |
									  WS_VISIBLE | WS_CHILD, 10, 42, 575, 50, m_hWndProgress,
									  (HMENU) 0, GetModuleHandle(NULL), NULL)))
		return true;

	// Set the static control's font
	hFont = CreateFont(-11 , 0, 0, 0, FW_NORMAL,
					   0, 0, 0, 0, 0, 0, 0, 0, "MS Sans Serif");
	SendMessage(m_hWndStatic, WM_SETFONT, (WPARAM) hFont, MAKELPARAM(FALSE, 0));

	// Create the static control
	if (!(m_hWndStatic2 = CreateWindow("STATIC", (LPSTR) 0, SS_CENTER |
									   WS_VISIBLE | WS_CHILD, 5, 62, 575, 50, m_hWndProgress,
									   (HMENU) 0, GetModuleHandle(NULL), NULL)))
		return true;

	// Set the static control's font
	hFont = CreateFont(-11 , 0, 0, 0, FW_NORMAL,
					   0, 0, 0, 0, 0, 0, 0, 0, "MS Sans Serif");
	SendMessage(m_hWndStatic2, WM_SETFONT, (WPARAM) hFont, MAKELPARAM(FALSE, 0));
	
	// Show the window
	ShowWindow(m_hWndProgress, SW_SHOW);
	UpdateWindow(m_hWndProgress);

	return false;
}

/*
	Destroys the progress window
*/
bool ASTProgressWindow::Destroy()
{
	if (!m_hWndProgress) return true;
	
	// Destroy the static control's font:
	DeleteObject((HFONT) SendMessage(m_hWndStatic, WM_GETFONT, 0, 0));

	// Destroy the progress window:
	DestroyWindow(m_hWndProgress);
	UnregisterClass("ProgressWindowClass", GetModuleHandle(NULL));

	return false;
}

/*
	Change the progress window task
*/
bool ASTProgressWindow::SetTask(const char* pszTaskDescription, ...)
{
	char szText[1000];
	va_list	List;

	if (!m_hWndProgressBar) return true;

	va_start(List, pszTaskDescription);
		vsprintf(szText, pszTaskDescription, List);
	va_end(List);
	SetWindowText(m_hWndStatic, szText);

	return false;
}

/*
	Change the progress window sub task
*/
bool ASTProgressWindow::SetSubTask(const char* pszTaskDescription, ...)
{
	char szText[1000];
	va_list	List;

	if (!m_hWndProgressBar) return true;

	va_start(List, pszTaskDescription);
		vsprintf(szText, pszTaskDescription, List);
	va_end(List);
	SetWindowText(m_hWndStatic2, szText);

	return false;
}

/*
	Set the progress of the progress bar
*/
bool ASTProgressWindow::SetProgress(const unsigned int iProgress)
{
	if (!m_hWndProgressBar) return true;
	
	SendMessage(m_hWndProgressBar, PBM_SETPOS, iProgress, 0);

	return false;
}
/*
	File: ASWindowManager.h

	Description: Window manager
*/


#ifndef __ASWINDOWMANAGER_H__
#define __ASWINDOWMANAGER_H__


// Predefinitions
typedef class ASTWindowHandler ASTWindowHandler;
typedef class ASTWindowManager ASTWindowManager;


// Includes
#include "ASWindow.h"
#include "ASWindowHandler.h"
#include "ASProgressWindow.h"


// Classes
typedef class ASTWindowManager {

	friend ASTWindowHandler;
	friend _AS;


	public:
		/*
			Constructor
		*/
		AS_API ASTWindowManager();

		/*
			Destructor
		*/
		AS_API ~ASTWindowManager();

		/*
			Creates the window

			Parameters:
				ASTWindowHandler* pCWindowHandler -> Pointer to the window handler
			    *pCustomDrawFunction		-> Pointer to a custom draw function
			    *pCustomUpdateFunction		-> Pointer to a custom draw function
				(*pCustomMessagesProcedure) -> Pointer to a cutom message procedure
				HMENU hMenu					-> A window menu
			    char* pszTitle				-> Title of the window
				int   iWidth & iHeight		-> New window size. If it's less than 0 the size will be
											   set to configuration standard
				char* pszClassName			-> The window class name

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Create(ASTWindowHandler* pCWindowHandler,
					bool (*pCustomDrawFunction)(ASTWindow* pCWindow) = NULL,
					bool (*pCustomUpdateFunction)(ASTWindow* pCWindow) = NULL,
					long (*pCustomMessagesProcedure)(HWND hWnd, unsigned uMsg,
													 WPARAM wParam, LPARAM lParam) = NULL,
			   		HMENU hMenu = NULL,
					const char* pszTitle = "AS-Engine",
					int iWidth = -1, int iHeight = -1,
					const char* pszClassName = NULL);

		/*
			Destroys a window hanlders window

			Parameters:
				ASTWindowHandler* pCWindowHandler -> Pointer to the window handler

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Destroy(ASTWindowHandler* pCWindowHandler);

		/*
			Destroys all windows

			Notes:
				- All window handlers will loose their windows
				- Use this function only if you really want to destroy all window
		*/
		AS_API void Clear();

		/*
			Returns if unused windows should be destroyed

			Returns:
				bool -> 'true' if unused windows are destroyed else 'false'
		*/
		AS_API bool GetDestroyUnusedWindows() const;

		/*
			Sets if unused windows should be destroyed

			Parameters:
				bool bDestroyUnusedWindows -> Should unused windows be destroy?
		*/
		AS_API void SetDestroyUnusedWindows(const bool bDestroyUnusedWindows = true);

		/*
			Returns a pointer to the main window

			Returns:
				ASTWindow* -> Pointer to the main window
		*/
		AS_API ASTWindow* GetMainWindow();

		/*
			Checks if the given window is the main window

			Returns:
				bool -> 'true' if the window is the main window else 'false'
		*/
		AS_API bool IsMainWindow(const ASTWindow* pCWindow);

		/*
			Checks if the given window is the main window

			Returns:
				bool -> 'true' if the window is the main window else 'false'
		*/
		AS_API bool IsMainWindow(const HWND hWnd);

		/*
			Returns a pointer to a window

			Parameters:
				HWND hWnd -> The handle of the window

			Returns:
				ASTWindow* -> Pointer to the window
		*/
		AS_API ASTWindow* GetWindow(const HWND hWnd);

		/*
			Returns the number of windows in the window manager

			Returns:
				int -> Returns the number of windows
		*/
		AS_API int GetWindows() const;

		
	private:
		ASTLinkedList<ASTWindow *> m_lstWindowList;			// Linked list of all windows
		bool					   m_bDestroyUnusedWindows;	// Should unused windows be killed?


		/*
			Updates all windows relevant stuff
		*/
		void Update();


} ASTWindowManager;


#endif // __ASWINDOWMANAGER_H__
/*
	File: ASWindow.h

	Description: Windows management
*/


#ifndef __ASWINDOW_H__
#define __ASWINDOW_H__


#define ASMAINWINDOWCLASSNAME "AS-Engine" // The window class name of the main window


// Classes
typedef class ASTWindow {

	friend ASTWindowManager;
	friend ASTRenderer;
	friend _AS;
	friend ASTFileSystem;


	public:
		/*
			Constructor
		*/
		AS_API ASTWindow();

		/*
			Destructor
		*/
		AS_API ~ASTWindow();

		/*
			Returns the window handler

			Returns:
				HWND -> Window handler
		*/
		AS_API HWND GetWnd() const;

		/*
			Returns the window width

			Returns:
				int -> Window width
		*/
		AS_API int GetWidth() const;

		/*
			Returns the window width

			Returns:
				int -> Window width
		*/
		AS_API int GetHeight() const;

		/*
			Returns a pointer to the renderer handler

			Returns:
				ASTRendererHandler* -> Pointer to the windows renderer handler
		*/
		AS_API ASTRendererHandler* GetRendererHandler();

		/*
			Returns a pointer to the input handler

			Returns:
				ASTInputHandler* -> Pointer to the windows input handler
		*/
		AS_API const ASTInputHandler* GetInputHandler() const;

		/*
			Change the window size

			Parameters:
				int iWidth & iHeight -> New window size. If it's less than 0 the size will be
										set to configuration standard

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Resize();

		/*
			Sets custom functions

			Parameters:
			    *pCustomDrawFunction		-> Pointer to a custom draw function
			    *pCustomUpdateFunction		-> Pointer to a custom draw function
				(*pCustomMessagesProcedure) -> Pointer to a cutom message procedure
		*/
		AS_API void SetCustomFunctions(bool (*pCustomDrawFunction)(ASTWindow *) = NULL,
									   bool (*pCustomUpdateFunction)(ASTWindow *) = NULL,
									   long (*pCustomMessagesProcedure)(HWND hWnd, unsigned uMsg,
																		WPARAM wParam, LPARAM lParam) = NULL);

		/*
			Handles custom window message function
		*/
		AS_API long CustomMessagesProcedure(HWND hWnd, unsigned uMsg, WPARAM wParam, LPARAM lParam) const;

		/*
			Sets the custom menu

			Parameters:
				HMENU hMenu -> Menu
		*/
		AS_API void SetCustomMenu(const HMENU hMenu = NULL);


	private:
		HWND			   m_hWnd;				// Window handler
		HMENU			   m_hMenu;				// Window menu backup
		HMENU			   m_hCustomMenu;		// Custom menu
		ASTRendererHandler m_CRendererHandler;	// The renderer handler
		ASTInputHandler	   m_CInputHandler;		// The input handler
		bool			   m_bActive;			// Is the window active?
		bool			   m_bFullScreen;		// Is the window in fullscreen mode?

		bool (*m_pCustomDrawFunction)(ASTWindow *);						// Custom draw function
		bool (*m_pCustomUpdateFunction)(ASTWindow *);					// Custom update function
		long (*m_pCustomMessagesProcedure)(HWND hWnd, unsigned uMsg,	// Custom window messages procedure
										   WPARAM wParam, LPARAM lParam);

		ASTLinkedList<ASTWindowHandler*> m_lstHandler;	// Linked list of all window handlers
														// using this window


		/*
			Creates the window

			Parameters:
				ASTWindowHandler* pCWindowHandler -> Pointer to the window handler
			    *pCustomDrawFunction		-> Pointer to a custom draw function
			    *pCustomUpdateFunction		-> Pointer to a custom draw function
				(*pCustomMessagesProcedure) -> Pointer to a cutom message procedure
				HMENU hMenu					-> A window menu
			    char* pszTitle				-> Title of the window
				int   iWidth & iHeight		-> New window size. If it's less than 0 the size will be
											   set to configuration standard
				char* pszClassName			-> The window class name

			Returns:
				int -> The number of window handlers using this window
		*/
		int Create(ASTWindowHandler* pCWindowHandler,
				   bool (*pCustomDrawFunction)(ASTWindow* pCWindow) = NULL,
				   bool (*pCustomUpdateFunction)(ASTWindow* pCWindow) = NULL,
				   long (*pCustomMessagesProcedure)(HWND hWnd, unsigned uMsg,
												    WPARAM wParam, LPARAM lParam) = NULL,
			   	   HMENU hMenu = NULL,
				   const char* pszTitle = "AS-Engine",
				   int iWidth = -1, int iHeight = -1,
				   const char* pszClassName = NULL);

		/*
			Destroy the window

			Parameters:
				ASTWindowHandler* pSWindowHandler -> Pointer to the window handler using this window

			Returns:
				int -> The number of window handlers using this window.
					   If it is '-1' the given window handler wasn't listed in the windows window handler list.
		*/
		int Destroy(ASTWindowHandler* pSWindowHandler);

		/*
			Rebuild the window

			Returns:
				bool -> 'false' if all went fine else 'true'

			Notes:
				- E.g. used if the fullscreen mode is changed
		*/
		bool Rebuild();

		/*
			Destroy the window immediately

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Clear();

		/*
			Destroy the windows data

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool DestroyData();

		/*
			Draw the window

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Draw();

		/*
			Update the window

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Update();

		/*
			Handle window messages
		*/
		static long CALLBACK WindowMessagesProcedure(HWND hWnd, unsigned uMsg, WPARAM wParam, LPARAM lParam);
		long MessagesProcedure(HWND hWnd, unsigned uMsg, WPARAM wParam, LPARAM lParam);


} ASTWindow;


#endif // __ASWINDOW_H__
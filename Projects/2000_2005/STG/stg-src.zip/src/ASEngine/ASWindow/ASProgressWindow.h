/*
	File: ASProgressWindow.cpp
*/

#ifndef __ASPROGRESSWINDOW_H__
#define __ASPROGRESSWINDOW_H__


typedef class ASTProgressWindow {

	public:
		/*
			Constructor
		*/
		AS_API ASTProgressWindow();

		/*
			Destructor
		*/
		AS_API ~ASTProgressWindow();

		/*
			Creates the progress window

			Parameters:
				char* pszTitle -> Titel bar text

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Create(const char* pszTitle);

		/*
			Destroys the progress window

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Destroy();

		/*
			Change the progress window task

			Parameters:
				char* pszTaskDescription -> Task description

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool SetTask(const char* pszTaskDescription, ...);

		/*
			Change the progress window sub task

			Parameters:
				char* pszTaskDescription -> Task description

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool SetSubTask(const char* pszTaskDescription, ...);

		/*
			Set the progress of the progress bar

			Parameters:
				unsigned int iProgress -> Progress (0 - 100)

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool SetProgress(const unsigned int iProgress);


	private:
		HWND m_hWndProgress;
		HWND m_hWndProgressBar;
		HWND m_hWndStatic, m_hWndStatic2;


		// Dummy window procedure
		static friend LRESULT CALLBACK ProgressWndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
			{   return DefWindowProc(hWnd, iMessage, wParam, lParam);	}


} ASTProgressWindow;


#endif // __ASPROGRESSWINDOW_H__
/*
	File: ASWindow.cpp
*/

#include <ASEngineDll.h>
#include "..\resource.h"


/*
	Constructor
*/
ASTWindow::ASTWindow()
{
	memset(this, 0, sizeof(ASTWindow));
}

/*
	Destructor
*/
ASTWindow::~ASTWindow()
{
	Clear();
}

/*
	Returns the window handler
*/
HWND ASTWindow::GetWnd() const
{
	return m_hWnd;
}

/*
	Returns the window width
*/
int ASTWindow::GetWidth() const
{
	RECT Rect;
	
	GetWindowRect(m_hWnd, &Rect);

	return Rect.right - Rect.left;
}

/*
	Returns the window width
*/
int ASTWindow::GetHeight() const
{
	RECT Rect;
	
	GetWindowRect(m_hWnd, &Rect);

	return Rect.bottom - Rect.top;
}

/*
	Returns a pointer to the renderer handler
*/
ASTRendererHandler* ASTWindow::GetRendererHandler()
{
	return &m_CRendererHandler;
}

/*
	Returns a pointer to the input handler
*/
const ASTInputHandler* ASTWindow::GetInputHandler() const
{
	return &m_CInputHandler;
}

/*
	Change the window size
*/
bool ASTWindow::Resize()
{
	// Set window rendering device
	if (_AS::CRenderer.SetRenderingDevice(&m_CRendererHandler)) return true;
	m_CRendererHandler.Config();

	return false;
}

/*
	Sets custom functions
*/
void ASTWindow::SetCustomFunctions(bool (*pCustomDrawFunction)(ASTWindow *),
								   bool (*pCustomUpdateFunction)(ASTWindow *),
								   long (*pCustomMessagesProcedure)(HWND hWnd, unsigned uMsg,
															  	    WPARAM wParam, LPARAM lParam))
{
	// Setup window update functions
	m_pCustomDrawFunction      = pCustomDrawFunction;
	m_pCustomUpdateFunction    = pCustomUpdateFunction;
	m_pCustomMessagesProcedure = pCustomMessagesProcedure;
}

/*
	Handles custom window message function
*/
long ASTWindow::CustomMessagesProcedure(HWND hWnd, unsigned uMsg, WPARAM wParam, LPARAM lParam) const
{
	if (!m_pCustomMessagesProcedure) return 0;
	return m_pCustomMessagesProcedure(hWnd, uMsg, wParam, lParam);
}

/*
	Sets the custom menu
*/
void ASTWindow::SetCustomMenu(const HMENU hMenu)
{
	m_hMenu = m_hCustomMenu = hMenu;
	SetMenu(m_hWnd, hMenu);
}

/*
	Creates the window
*/
int ASTWindow::Create(ASTWindowHandler* pSWindowHandler,
					  bool (*pCustomDrawFunction)(ASTWindow* pCWindow),
					  bool (*pCustomUpdateFunction)(ASTWindow* pCWindow),
					  long (*pCustomMessagesProcedure)(HWND hWnd, unsigned uMsg,
													   WPARAM wParam, LPARAM lParam),
			   		  HMENU hMenu,
					  const char* pszTitle,
					  int iWidth, int iHeight,
					  const char* pszClassName)
{
	DWORD dwStyle = 0, dwExStyle = 0;
	char szClassName[256];
    WNDCLASS wc;

	// Check pointer
	if (!pSWindowHandler) return true;

	// Check if the window is already created
	if (m_hWnd) {
		pSWindowHandler->m_pCWindow = this;
		m_lstHandler.Add(pSWindowHandler);

		return m_lstHandler.GetElements();
	}

	// Setup window update functions
	m_pCustomDrawFunction      = pCustomDrawFunction;
	m_pCustomUpdateFunction    = pCustomUpdateFunction;
	m_pCustomMessagesProcedure = pCustomMessagesProcedure;

	if (m_hCustomMenu) m_hMenu = m_hCustomMenu;
	else			   m_hMenu = hMenu;

	// Setup window mode
	if (_AS::CConfig.IsFullscreen()) {
		dwExStyle = WS_EX_APPWINDOW;
		dwStyle   = WS_POPUP;
		hMenu     = NULL;
		iWidth    = _AS::CConfig.GetDisplayWidth();
		iHeight   = _AS::CConfig.GetDisplayHeight();
	} else {
		dwExStyle = WS_EX_APPWINDOW | WS_EX_WINDOWEDGE | WS_EX_DLGMODALFRAME;
		dwStyle   = WS_OVERLAPPEDWINDOW;

		// Check if the window size should be set to configuration standard
		if (iWidth  < 0) iWidth  = _AS::CConfig.GetDisplayWidth();
		if (iHeight < 0) iHeight = _AS::CConfig.GetDisplayHeight();
	}


	// Set a unique window class name
	if (pszClassName) strcpy(szClassName, pszClassName);
	else sprintf(szClassName, "%d", GetTickCount());
	_AS::CLog.Output("Create a new window '%s'", szClassName);

	// Set up and register window class
    wc.style	     = CS_HREDRAW | CS_VREDRAW | CS_OWNDC | CS_PARENTDC;
    wc.lpfnWndProc   = WindowMessagesProcedure;
    wc.cbClsExtra    = 0;
    wc.cbWndExtra    = 0;
    wc.hInstance     = GetModuleHandle(NULL);
    wc.hIcon	     = LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON));
    wc.hCursor	     = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = NULL;
    wc.lpszMenuName  = NULL;
    wc.lpszClassName = szClassName;
    if (!RegisterClass(&wc)) {
		_AS::CLog.Output("Couldn't register new window class!");

		return true;
	}

	// Create the window
	if (!(m_hWnd = CreateWindowEx(dwExStyle, szClassName, pszTitle,
								  dwStyle | WS_CLIPSIBLINGS | WS_CLIPCHILDREN,
								  0, 0, iWidth, iHeight, NULL, hMenu,
								  GetModuleHandle(NULL), NULL)))
		return true;

	// Initialize the renderer handler
	m_CRendererHandler.Init(m_hWnd);

	// Initialize the input handler
	m_CInputHandler.Init(m_hWnd);

    // Set the icon for this dialog
    HICON hIcon = LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON));
	if (hIcon) {
		PostMessage(m_hWnd, WM_SETICON, ICON_BIG,   (LPARAM) hIcon);  // Set big icon
		PostMessage(m_hWnd, WM_SETICON, ICON_SMALL, (LPARAM) hIcon);  // Set small icon
	}

	// Send the WM_INITDIALOG message
	SendMessage(m_hWnd, WM_INITDIALOG, 0, 0);

	// Setup the focus to this window
	m_bActive = true;
	ShowWindow(m_hWnd, SW_SHOWNORMAL);
	if(_AS::CConfig.IsFullscreen()) {
		SetFocus(m_hWnd);
		SetForegroundWindow(m_hWnd);
	}
	UpdateWindow(m_hWnd);
	
	// Add the window handler
	pSWindowHandler->m_pCWindow = this;
	m_lstHandler.Add(pSWindowHandler);

	m_CRendererHandler.Clear();

	return m_lstHandler.GetElements();
}

/*
	Destroy the window
*/
int ASTWindow::Destroy(ASTWindowHandler* pSWindowHandler)
{
	if (!pSWindowHandler || !m_hWnd) return 0;

	// Check if this window handler is listed in this window
	if (m_lstHandler.Remove(pSWindowHandler)) return -1;

	// Set the window handlers window to NULL
	pSWindowHandler->m_pCWindow = NULL;

	// Is the window now unused?
	if (!m_lstHandler.IsEmpty()) return m_lstHandler.GetElements();

	// Setup window data
	DestroyData();

	return 0;
}

/*
	Rebuild the window
*/
bool ASTWindow::Rebuild()
{
	DWORD dwStyle = 0, dwExStyle = 0;
	char szClassName[256], szTitle[256];
	int iWidth, iHeight;
    WNDCLASS wc;
	HMENU hMenu;
	RECT Rect;

	if (!m_hWnd) return true;

	// Backup some information about our old window
	GetClassName(m_hWnd, szClassName, 256);
	GetClassInfo(GetModuleHandle(NULL), szClassName, &wc);
	GetWindowText(m_hWnd, szTitle, 256);
	if (m_hCustomMenu) hMenu = m_hCustomMenu;
	else			   hMenu = m_hMenu;
	GetWindowRect(m_hWnd, &Rect);
	iWidth  = Rect.right-Rect.left;
	iHeight = Rect.bottom-Rect.top;
	_AS::CLog.Output("Rebuild window '%s'", szClassName);

	// Destroy old window
	_AS::CLog.Output("Destroy old window");
	DestroyData();

	// Create new window
	// Setup window mode
	if (_AS::CConfig.IsFullscreen()) {
		dwExStyle = WS_EX_APPWINDOW;
		dwStyle   = WS_POPUP;
		hMenu     = NULL;
		iWidth    = _AS::CConfig.GetDisplayWidth();
		iHeight   = _AS::CConfig.GetDisplayHeight();
	} else {
		dwExStyle = WS_EX_APPWINDOW | WS_EX_WINDOWEDGE | WS_EX_DLGMODALFRAME;
		dwStyle   = WS_OVERLAPPEDWINDOW;

		// Check if the window size should be set to configuration standard
		if (iWidth  < 0) iWidth  = _AS::CConfig.GetDisplayWidth();
		if (iHeight < 0) iHeight = _AS::CConfig.GetDisplayHeight();
	}
	_AS::CLog.Output("Create a new window '%s'", szClassName);

	// Set up and register window class
    if (!RegisterClass(&wc)) {
		_AS::CLog.Output("Couldn't register new window class!");

		return true;
	}

	// Create the window
	if (!(m_hWnd = CreateWindowEx(dwExStyle, szClassName, szTitle,
								  dwStyle | WS_CLIPSIBLINGS | WS_CLIPCHILDREN,
								  0, 0, iWidth, iHeight, NULL, hMenu,
								  GetModuleHandle(NULL), NULL)))
		return true;

	// Initialize the renderer handler
	m_CRendererHandler.Init(m_hWnd);

	// Initialize the input handler
	m_CInputHandler.Init(m_hWnd);

    // Set the icon for this dialog
    HICON hIcon = LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON));
	if (hIcon) {
		PostMessage(m_hWnd, WM_SETICON, ICON_BIG,   (LPARAM) hIcon);  // Set big icon
		PostMessage(m_hWnd, WM_SETICON, ICON_SMALL, (LPARAM) hIcon);  // Set small icon
	}

	// Send the WM_INITDIALOG message
	SendMessage(m_hWnd, WM_INITDIALOG, 0, 0);

	// Setup the focus to this window
	ShowWindow(m_hWnd, SW_SHOWNORMAL);
	if(_AS::CConfig.IsFullscreen()) SetFocus(m_hWnd);
	BringWindowToTop(m_hWnd);
	UpdateWindow(m_hWnd);

	m_CRendererHandler.Clear();

	return false;
}

/*
	Destroy the window immediately
*/
bool ASTWindow::Clear()
{
	ASTLinkedListElement<ASTWindowHandler*>* pListElement;

	// Update window handlers using this window
	pListElement = m_lstHandler.FindFirst();
	while (pListElement) {
		pListElement->Data->m_pCWindow = NULL;
		pListElement = m_lstHandler.FindNext();
	}
	m_lstHandler.Clear();

	// Setup window data
	return DestroyData();
}

/*
	Destroy the windows data
*/
bool ASTWindow::DestroyData()
{
	char szClassName[256];

	if (!m_hWnd) return true;

	// Get windows class name
	GetClassName(m_hWnd, szClassName, 256);
	_AS::CLog.Output("Destroy window '%s'", szClassName);

	// Deinitialize the input handler
	m_CInputHandler.DeInit();

	// Deinitialize the renderer in this window
	m_CRendererHandler.DeInit();

	// Destroy the window
	if (!DestroyWindow(m_hWnd)) {
		_AS::CLog.Output("Couldn't destroy window!");

		return true;
	}
	m_hWnd = NULL;

	// Unregister window class
	if (!UnregisterClass(szClassName, GetModuleHandle(NULL))) {
		_AS::CLog.Output("Couldn't unregister window class");

		return true;
 	}

	return false;
}

/*
	Draw the window
*/
bool ASTWindow::Draw()
{
	if (!m_bActive)	return true;

	// Set window rendering device
	_AS::CRenderer.SetRenderingDevice(&m_CRendererHandler);

	// Initialize the szene
	m_CRendererHandler.InitSzene();

	// Perform the custom draw function
	if (m_pCustomDrawFunction && m_pCustomDrawFunction(this)) return true;

	// Do the last stuff and update the window content
	m_CRendererHandler.Update();

	return false;
}

/*
	Update the window
*/
bool ASTWindow::Update()
{
	if (!m_bActive)	return true;

	// Update the input handler
	m_CInputHandler.Update();

	// Set window input handler
	_AS::CInput.SetInputHandler(&m_CInputHandler);

	// Set window rendering device
	_AS::CRenderer.SetRenderingDevice(&m_CRendererHandler);

	// Check if there's a custom update function
	if (!m_pCustomUpdateFunction) return false;

	// Perform the custom update function
	return m_pCustomUpdateFunction(this);
}

/*
	Handle window messages
*/
long CALLBACK ASTWindow::WindowMessagesProcedure(HWND hWnd, unsigned uMsg, WPARAM wParam, LPARAM lParam)
{
	ASTWindow* pCWindow;

	// Find our current window
	if (!(pCWindow = _AS::CWindowManager.GetWindow(hWnd))) return DefWindowProc(hWnd, uMsg, wParam, lParam);

	return pCWindow->MessagesProcedure(hWnd, uMsg, wParam, lParam);
}

long ASTWindow::MessagesProcedure(HWND hWnd, unsigned uMsg, WPARAM wParam, LPARAM lParam)
{
	// Handle general messages
	switch(uMsg) {
        case WM_SIZE:
			// We change the size of our window:
			if (wParam == SIZE_MINIMIZED) {
				InvalidateRect(hWnd, NULL, TRUE);
				m_bActive = false;
				if (m_bFullScreen && _AS::CConfig.IsFullscreen()) {
					_AS::CConfig.ToggleFullscreen();
					_AS::CConfig.m_bFullscreen = true;
					SendMessage(m_hWnd, WM_SYSCOMMAND, SC_MINIMIZE, 0);
					break;
				}
			} else {
				if (!m_bActive && !_AS::IsShutDown()) {
					m_bActive = true;
					if (!m_bFullScreen && _AS::CConfig.IsFullscreen()) {
						_AS::CConfig.m_bFullscreen = false;
						_AS::CConfig.ToggleFullscreen();
						SetFocus(m_hWnd);
					}
					ShowWindow(m_hWnd, SW_SHOWNORMAL);
					UpdateWindow(m_hWnd);
				} else Resize();
			}
			break;

		case WM_ACTIVATE:
			if (LOWORD(wParam) == WA_INACTIVE || ((bool) (HIWORD(wParam) != 0))) break;
			Resize();
			break;

		case WM_SYSKEYUP:
			switch(wParam) {
				case VK_RETURN: _AS::CConfig.ToggleFullscreen(); break;
			}
			break;

		case WM_CLOSE: _AS::ShutDown(); return 0;
    }

	// Handle custom window message function
	CustomMessagesProcedure(hWnd, uMsg, wParam, lParam);

    return DefWindowProc(hWnd, uMsg, wParam, lParam);
}
/*
	File: ASWindowHandler.cpp
*/

#include <ASEngineDll.h>


/*
	Constructor
*/
ASTWindowHandler::ASTWindowHandler()
{
	memset(this, 0, sizeof(ASTWindowHandler));
	m_pCWindow = _AS::CWindowManager.GetMainWindow();
}

/*
	Destructor
*/
ASTWindowHandler::~ASTWindowHandler()
{
	Destroy();
}

/*
	Creates the window
*/
bool ASTWindowHandler::Create(bool (*pCustomDrawFunction)(ASTWindow* pCWindow),
							  bool (*pCustomUpdateFunction)(ASTWindow* pCWindow),
							  long (*pCustomMessagesProcedure)(HWND hWnd, unsigned uMsg,
														       WPARAM wParam, LPARAM lParam),
			   				  HMENU hMenu,
							  const char* pszTitle,
							  int iWidth, int iHeight,
							  const char* pszClassName)
{
	return _AS::CWindowManager.Create(this, pCustomDrawFunction, pCustomUpdateFunction, pCustomMessagesProcedure,
									  hMenu, pszTitle, iWidth, iHeight, pszClassName);
}

/*
	Returns if the window is created or not
*/
bool ASTWindowHandler::IsCreated() const
{
	if (m_pCWindow) return true;
	else return false;
}

/*
	Destroys the window
*/
bool ASTWindowHandler::Destroy()
{
	// Does the window handler has a window?
	if (!m_pCWindow) return true;

	// Destroy this window
	return _AS::CWindowManager.Destroy(this);
}

/*
	Returns the window handlers window
*/
ASTWindow* ASTWindowHandler::GetWindow() const
{
	return m_pCWindow;
}
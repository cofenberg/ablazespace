/*
	File: ASWindowManager.cpp
*/

#include <ASEngineDll.h>


/*
	Constructor
*/
ASTWindowManager::ASTWindowManager()
{
	m_bDestroyUnusedWindows = true;
}

/*
	Destructor
*/
ASTWindowManager::~ASTWindowManager()
{
	Clear();
}

/*
	Creates a window
*/
bool ASTWindowManager::Create(ASTWindowHandler* pSWindowHandler,
							  bool (*pCustomDrawFunction)(ASTWindow* pCWindow),
							  bool (*pCustomUpdateFunction)(ASTWindow* pCWindow),
							  long (*pCustomMessagesProcedure)(HWND hWnd, unsigned uMsg,
															   WPARAM wParam, LPARAM lParam),
			   				  HMENU hMenu,
							  const char* pszTitle,
							  int iWidth, int iHeight,
							  const char* pszClassName)
{
	ASTLinkedListElement<ASTWindow*>* pSListElement;
	ASTWindow* pCWindowT;
	char szClassName[256];

	// Check pointers
	if (!pSWindowHandler) return false;
	
	// First check if the window is already created
	if (pszClassName) {
		pSListElement = m_lstWindowList.FindFirst();
		while (pSListElement) {
			pCWindowT = pSListElement->Data;
			GetClassName(pCWindowT->GetWnd(), szClassName, 256);
			if (!stricmp(pszClassName, szClassName)) { // The window is already created
				pCWindowT->Create(pSWindowHandler, pCustomDrawFunction, pCustomUpdateFunction, pCustomMessagesProcedure,
								  hMenu, pszTitle, iWidth, iHeight, pszClassName);

				return true;
			}
			pSListElement = m_lstWindowList.FindNext();
		}
	}

	// Create the new window
	pCWindowT = new ASTWindow;
	m_lstWindowList.Add(pCWindowT);
	if (pCWindowT->Create(pSWindowHandler, pCustomDrawFunction, pCustomUpdateFunction, pCustomMessagesProcedure,
						  hMenu, pszTitle, iWidth, iHeight, pszClassName) < 0) {
		// The window couldn't be created!
		m_lstWindowList.Remove(pCWindowT);
		if (pCWindowT) delete pCWindowT;

		return true;
	}

	return false;
}

/*
	Destroys a window hanlders window
*/
bool ASTWindowManager::Destroy(ASTWindowHandler* pSWindowHandler)
{
	ASTLinkedListElement<ASTWindow*>* pSListElement;
	ASTWindow* pCWindowT;

	if (!pSWindowHandler) return true;

	// Find the window
	pSListElement = m_lstWindowList.FindFirst();
	while (pSListElement) {
		if (!pSListElement->Data->Destroy(pSWindowHandler)) { // The window is no longer used!
			// Should the unused window be destroyed?
			if (m_bDestroyUnusedWindows) {
				pCWindowT = pSListElement->Data;
				m_lstWindowList.Remove(pCWindowT);
				delete pCWindowT;
			}
		}
		pSListElement = m_lstWindowList.FindNext();
	}

	return false;
}

/*
	Destroys all windows
*/
void ASTWindowManager::Clear()
{
	ASTLinkedListElement<ASTWindow*>* pSListElement;

	_AS::CLog.Output("Clear windows manager");

	// Destroy all windows
	pSListElement = m_lstWindowList.FindFirst();
	while (pSListElement) {
		delete pSListElement->Data;
		pSListElement = m_lstWindowList.FindNext();
	}
	m_lstWindowList.Clear();
}

/*
	Returns if unused windows should be destroyed
*/
bool ASTWindowManager::GetDestroyUnusedWindows() const
{
	return m_bDestroyUnusedWindows;
}

/*
	Sets if unused windows should be destroyed
*/
void ASTWindowManager::SetDestroyUnusedWindows(const bool bDestroyUnusedWindows)
{
	m_bDestroyUnusedWindows = bDestroyUnusedWindows;
}

/*
	Returns a pointer to the main window
*/
ASTWindow* ASTWindowManager::GetMainWindow()
{
	ASTLinkedListElement<ASTWindow*>* pSListElement;
	char szClassName[256];

	// Find the standard texture
	pSListElement = m_lstWindowList.FindFirst();
	while (pSListElement) {
		GetClassName(pSListElement->Data->GetWnd(), szClassName, 256);
		if (!stricmp(szClassName, ASMAINWINDOWCLASSNAME)) { // We found the main window
			return pSListElement->Data;
		}
		pSListElement = m_lstWindowList.FindNext();
	}

	return NULL;
}

/*
	Checks if the given window is the main window
*/
bool ASTWindowManager::IsMainWindow(const ASTWindow* pCWindow)
{
	if (pCWindow == GetMainWindow()) return true;
	else return false;
}

/*
	Checks if the given window is the main window
*/
bool ASTWindowManager::IsMainWindow(const HWND hWnd)
{
	if (GetWindow(hWnd) == GetMainWindow()) return true;
	else return false;
}

/*
	Returns a pointer to a window
*/
ASTWindow* ASTWindowManager::GetWindow(const HWND hWnd)
{
	ASTLinkedListElement<ASTWindow*>* pSListElement;

	// Find the standard texture
	pSListElement = m_lstWindowList.FindFirst();
	while (pSListElement) {
		if (pSListElement->Data->GetWnd() == hWnd) return pSListElement->Data;
		pSListElement = m_lstWindowList.FindNext();
	}

	return NULL;
}

/*
	Returns the number of windows in the window manager
*/
int ASTWindowManager::GetWindows() const
{
	return m_lstWindowList.GetElements();
}

/*
	Updates all windows relevant stuff
*/
void ASTWindowManager::Update()
{
	ASTLinkedListElement<ASTWindow*>* pSListElement;

	// First update all windows
	pSListElement = m_lstWindowList.FindFirst();
	while (pSListElement) {
		pSListElement->Data->Update();
		pSListElement = m_lstWindowList.FindNext();
	}

	// Now draw all windows
	pSListElement = m_lstWindowList.FindFirst();
	while (pSListElement) {
		pSListElement->Data->Draw();
		pSListElement = m_lstWindowList.FindNext();
	}
}
/*
	File: ASLanguage.h

	Description: Texts for the engine
*/

#ifdef ASENGINE_EXPORTS
#ifndef __ASLANGUAGE_H__
#define __ASLANGUAGE_H__


// Definitions
#define ASLANGUAGETEXTFILE "asengine"


// Texts
enum {
	_T_Ok, _T_Cancel, _T_Build, _T_Version, _T_Quit, _T_Credits, _T_Language,
	_T_WireframeMode, _T_PointMode, _T_ShowFPS, _T_ShowTriangles, _T_ShowBoundingBoxes,
	_T_Configurations, _T_General, _T_Graphic, _T_Sound, _T_Control, _T_Lighting, _T_None,
	_T_Flat, _T_Smooth, _T_TextureFiltering, _T_UseMipmaps, _T_Multitexturing, _T_HighRenderQuality,
	_T_Lightmaps, _T_Shadowmaps, _T_DisplayMode, _T_Fullscreen, _T_ParticleDensity,
	_T_Low, _T_Medium, _T_All, _T_Visiblity, _T_High, _T_ZBufferBits, _T_Music, _T_MusicVolume,
	_T_SoundVolume, _T_Sensibility, _T_Normal, _T_SmoothLines, _T_Silhouettes, _T_CelShading,
	_T_ComicStyle, _T_Programming, _T_FirstApplicationStart, _T_ApplicationWasNotSutDownCorrectlyAtLastTime,
	_T_TextureManager, _T_Load, _T_Unload, _T_Update, _T_Reset, _T_TextureIsStillUsed, _T_Question, _T_ContinueQuestionMark,
	_T_LoadTexture, _T_Used, _T_ModelManager, _T_LoadModel, _T_ModelIsStillUsed, _T_ShaderManager, _T_LoadShader,
	_T_ShaderIsStillUsed, _T_Open, _T_Edit, _T_TextureCompression, _T_ShaderEditor, _T_SourceTexture, _T_Texture,
	_T_Animation, _T_Add, _T_Delete, _T_Copy, _T_Up, _T_Down, _T_Play, _T_AnimationTool, _T_Coordinate,
	_T_Advanced, _T_Attributes, _T_EnvironmentMapping, _T_Name, _T_New, _T_Error, _T_ShaderEditorMenu, _T_ShaderEditorNew,
	_T_TextureCoordinates, _T_Editor, _T_TextureQuality, _T_Triangles, _T_UnloadUnused, _T_Mouse, _T_InvertYAxe,
	_T_OutputDriver, _T_SoundDriver, _T_MixingDriver, _T_OutputRate, _T_FModError, _T_IncorrectDLLVersion,
	_T_Channels, _T_Standart, _T_AreYouSure, _T_SoundManager, _T_SoundIsStillUsed, _T_LoadSound, _T_PlayBack,
	_T_Debug, _T_ShowCoordinateAxes, _T_SoundSystem, 
};


// Variables
extern ASTLanguageHandler CText; // Engine texts


#endif // __ASLANGUAGE_H__
#endif
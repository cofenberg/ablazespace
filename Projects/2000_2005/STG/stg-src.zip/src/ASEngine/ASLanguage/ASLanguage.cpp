/*
	File: ASLanguage.cpp
*/

#include <ASEngineDll.h>


// Variables
ASTLanguageHandler CText; // Engine texts
/*
	File: ASLanguageHandler.cpp
*/

#include <ASEngineDll.h>


/*
	Constructor
*/
ASTLanguageHandler::ASTLanguageHandler()
{
	memset(this, 0, sizeof(ASTLanguageHandler));

	// Check in into the language manager
	_AS::CLanguageManager.m_lstLanguageHandlerList.Add(this);
}

/*
	Destructor
*/
ASTLanguageHandler::~ASTLanguageHandler()
{
	Unload();

	// Destroy the list of custom update function
	m_lstCustomUpdateFunction.Clear();

	// Check in out from the language manager
	_AS::CLanguageManager.m_lstLanguageHandlerList.Remove(this);
}

/*
	Loads all texts from a given language text file
*/
int ASTLanguageHandler::Load(const char* pszFilename)
{
	char szFilename[256], szTemp[256], szTextT[1000], *pszText;
	ASTLinkedListElement<void (*)()>* pSListElement;
    int i = 0;

	// Check pointer
	if (!pszFilename) return 0;

	// Setup filename information
	strcpy(m_szFilename, pszFilename);
	sprintf(szFilename, "%s\\%s\\%s", _AS::CFileSystem.GetLanguagesDirectory(),
									  _AS::CConfig.GetLanguageName(), m_szFilename);
	_AS::CFileSystem.GetFullFilename(szFilename, ASTEXT_FILE);
	_AS::CLog.Output("Load language text file '%s'", szFilename);

	// Unload the old texts
	Unload();

	// Get help file
	GetPrivateProfileString("help", "file", CText.GetHelpFilename(), m_szHelpFilename, 256, szFilename);
	_AS::CFileSystem.SetCustomHelpFile(m_szHelpFilename);
	
	// Load all texts:
	while (1) {
		sprintf(szTemp, "%d", i++);
		if (!GetPrivateProfileString("texts", szTemp, "", szTextT, MAX_PATH, szFilename)) break;
		pszText = new char[strlen(szTextT) + 1];
		strcpy(pszText, szTextT);
		m_lstTextList.Add(pszText);
	}

	// Is there any text??
	if (m_lstTextList.IsEmpty()) {
		pszText = new char[strlen("empty") + 1];
		strcpy(pszText, "empty");
		m_lstTextList.Add(pszText);
	}

	// Call the custom update functions
	pSListElement = m_lstCustomUpdateFunction.FindFirst();
	while (pSListElement) {
		if (pSListElement->Data) pSListElement->Data();
		pSListElement = m_lstCustomUpdateFunction.FindNext();
	}

	return m_lstTextList.GetElements();
}

/*
	Unloads all texts from the given language text file
*/
bool ASTLanguageHandler::Unload()
{
	ASTLinkedListElement<char*>* pSListElement;

	// Destroy all texts
	pSListElement = m_lstTextList.FindFirst();
	while (pSListElement) {
		if (pSListElement->Data) delete pSListElement->Data;
		pSListElement = m_lstTextList.FindNext();
	}
	m_lstTextList.Clear();

	return false;
}

/*
	Returns the filename of the language handlers text file
*/
const char* ASTLanguageHandler::GetFilename() const
{
	return m_szFilename;
}

/*
	Returns the languages help filename
*/
const char* ASTLanguageHandler::GetHelpFilename() const
{
	return m_szHelpFilename;
}

/*
	Gets a text
*/
const char* ASTLanguageHandler::Get(const int iTextID)
{
	return m_lstTextList[iTextID];
}

/*
	Add's a custom update function to the language handlers update functions list
*/	
bool ASTLanguageHandler::AddCustomUpdateFunction(void (*pCustomUpdateFunction)())
{
	return m_lstCustomUpdateFunction.Add(pCustomUpdateFunction);
}

/*
	Remove's a custom update function to the language handlers update functions list
*/	
bool ASTLanguageHandler::RemoveCustomUpdateFunction(void (*pCustomUpdateFunction)())
{
	return m_lstCustomUpdateFunction.Remove(pCustomUpdateFunction);
}
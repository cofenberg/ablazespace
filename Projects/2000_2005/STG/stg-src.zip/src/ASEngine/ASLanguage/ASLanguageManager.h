/*
	File: ASLanguageManager.h

	Description: Multi language manager
*/


#ifndef __ASLANGUAGEMANAGER_H__
#define __ASLANGUAGEMANAGER_H__


// Predefinitions
typedef class ASTLanguageManager ASTLanguageManager;


// Includes
#include "ASLanguageHandler.h"


// Classes
typedef class ASTLanguageManager {

	friend _AS;
	friend ASTConfig;
	friend ASTLanguageHandler;


	public:
		/*
			Constructor
		*/
		AS_API ASTLanguageManager();
	
		/*
			Destructor
		*/
		AS_API ~ASTLanguageManager();

		/*
			Sets the language system to the given language

			Parameters:
				char* pszLanguage -> The language name of the language which should be used
	
			Returns:
				bool -> 'false' if all went fine else 'true'

			Notes:
				- All language handlers will automatically load the new language texts
				- Use the language handler custom function to update some other element using this texts
				  (e.g. windows buttons)
		*/
		AS_API bool SetLanguage(const char* pszLanguage);


	private:
		ASTLinkedList<char*>			   m_lstLanguageList;			// A list of all available languages
		ASTLinkedList<ASTLanguageHandler*> m_lstLanguageHandlerList;	// A list of all language handlers


		/*
			Generates a list of all available languages

			Returns:
				int -> The number of found languages

			Notes:
				- The sub directories in the language directory are defined as different languages
		*/
		int GenerateLanguageList();

		/*
			Destroys the list of all available languages

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool DestroyLanguageList();


} ASTLanguageManager;


// Variables
extern ASTLanguageHandler CASText; // Engine texts


#endif // __ASLANGUAGEMANAGER_H__
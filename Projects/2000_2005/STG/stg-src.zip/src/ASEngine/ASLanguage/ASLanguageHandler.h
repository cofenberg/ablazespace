/*
	File: ASLanguageHandler.h

	Description: Functions for multi language support
*/


#ifndef __ASLANGUAGEHANDLER_H__
#define __ASLANGUAGEHANDLER_H__


// Classes
typedef class ASTLanguageHandler {

	friend ASTLanguageManager;


	public:
		/*
			Constructor
		*/
		AS_API ASTLanguageHandler();
	
		/*
			Destructor
		*/
		AS_API ~ASTLanguageHandler();

		/*
			Loads all texts from a given language text file

			Parameters:
				char* pszFilename -> The filename of the text file

			Returns:
				int -> The number of loaded texts
		*/
		AS_API int Load(const char* pszFilename);

		/*
			Unloads all texts from the given language text file

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Unload();

		/*
			Returns the filename of the language handlers text file

			Returns:
				char* -> The filename of the language handlers text file
		*/
		AS_API const char* GetFilename() const;

		/*
			Returns the languages help filename
		*/
		AS_API const char* GetHelpFilename() const;

		/*
			Gets a text

			Parameters:
				int iTextID -> The text ID

			Returns:
				char* -> Returns the text with the given ID
		*/
		AS_API const char* Get(const int iTextID);

		/*
			Add's a custom update function to the language handlers update functions list

			Prameters:
				void (*pCustomUpdateFunction)() -> Pointer to the custom update function

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/	
		AS_API bool AddCustomUpdateFunction(void (*pCustomUpdateFunction)());

		/*
			Remove's a custom update function to the language handlers update functions list

			Prameters:
				void (*pCustomUpdateFunction)() -> Pointer to the custom update function

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/	
		AS_API bool RemoveCustomUpdateFunction(void (*pCustomUpdateFunction)());


	private:
		char				 m_szFilename[256];		// The filename of the text file
		char				 m_szHelpFilename[256]; // The help filename
		ASTLinkedList<char*> m_lstTextList;			// A list of all texts
		ASTLinkedList<void (*)()> m_lstCustomUpdateFunction; // The custom function which should be called
															 // if the language was changed


} ASTLanguageHandler;


#endif // __ASLANGUAGEHANDLER_H__
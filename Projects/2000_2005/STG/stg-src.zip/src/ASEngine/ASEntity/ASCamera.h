/*
	File: ASCamera.h

	Description: Camera entity
*/


#ifndef __ASCAMERA_H__
#define __ASCAMERA_H__


// Definitions
enum ASECameraFlags {
	ASeCameraFlagFree			 = 1,	// Free moveable camera
	ASeCameraFlagThirdPersonFlag = 2,	// Third person camera
};


// Classes
typedef class ASTCamera : public ASTEntity {

	public:
		/*
			Sets the camera

			Parameters:
				bool bTranslate -> Should the position also be set?

			Returns:
				bool -> 'false' is all went fine else 'true'

			Notes:
				- Do not set the position translation if you want to draw e.g. a sky cube!
		*/
		AS_API bool Set(const bool bTranslate = true);

		/*
			Gets the camera flags

			Returns:
				int -> Camera flags
		*/
		AS_API int GetFlags() const;
		
		/*
			Sets the camera flags

			Parameters:
				int iFlags -> Camera flags which should be set
		*/
		AS_API void SetFlags(const int EFlags);

		/*
			Sets the camera target entity

			Parameters:
				ASTEntity* pCEntity -> Camera target entity
		*/
		AS_API void SetTarget(ASTEntity* pCEntity);

		/*
			Gets the camera target entity

			Returns:
				ASTEntity* -> Camera target entity
		*/
		AS_API ASTEntity* GetTarget() const;

		/*
			Sets the FOV
		*/
		AS_API void SetFOV(const float fFOV = 45.f);

		/*
			Returns the FOV
		*/
		AS_API float GetFOV() const;


	protected:
		float	 m_fFOV;		// Field of view
		float	 m_fAspect;	// Aspect factor
		float	 m_fZNear;		// Z near clipping plane
		float	 m_fZFar;		// Z far clipping plane
		ASFLOAT3 m_fRotT;
		float	 m_fZoom;


	private:
		int	  m_iFlags;		// Camera flags

		ASTEntityHandler m_CTargetEntity; // Target entity


		/*
			Virtual entity functions

			Notes:
				- You shouldn't overload this virtual functions
		*/
		AS_API virtual void CustomInitFunction();
		AS_API virtual bool CustomFrustumFunction();
		AS_API virtual void CustomUpdateFunction();

		/*
			Virtual camera functions
		*/
		AS_API virtual void CustomCameraUpdateFunction();


} ASTCamera;


#endif // __ASCAMERA_H__
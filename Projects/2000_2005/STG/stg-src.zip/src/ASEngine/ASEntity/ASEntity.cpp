/*
	File: ASEntity.cpp
*/

#include <ASEngineDll.h>


/*
	Remove the entity
*/
void ASTEntity::Remove()
{
	m_bRemove = true;
}

/*
	Translate the entity in OpenGL to its position
*/
void ASTEntity::TranslateGL()
{
	glTranslatef(m_vPos.fX, m_vPos.fY, m_vPos.fZ);
}

/*
	Returns the position
*/
ASTVector3D ASTEntity::GetPos() const
{
	return m_vPos;
}

/*
	Sets the entities position
*/
void ASTEntity::SetPos(const float fX, const float fY, const float fZ)
{
	m_vPos.SetXYZ(fX, fY, fZ);
}

/*
	Sets the entities position
*/
void ASTEntity::SetPos(const ASTVector3D& vPos)
{
	m_vPos = vPos;
}

/*
	Increase the entities position
*/
void ASTEntity::IncPos(const float fX, const float fY, const float fZ)
{
	m_vPos.fX += fX;
	m_vPos.fY += fY;
	m_vPos.fZ += fZ;
}

/*
	Increase the entities position
*/
void ASTEntity::IncPos(const ASTVector3D& vPos)
{
	m_vPos += vPos;
}

/*
	Returns the scale
*/
ASTVector3D ASTEntity::GetScale() const
{
	return m_vScale;
}

/*
	Sets the entities scale
*/
void ASTEntity::SetScale(const float fX, const float fY, const float fZ)
{
	m_vScale.SetXYZ(fX, fY, fZ);
}

/*
	Sets the entities scale
*/
void ASTEntity::SetScale(const ASTVector3D& vScale)
{
	m_vScale = vScale;
}

/*
	Rotate the entity in OpenGL corresponding to its rotation
*/
void ASTEntity::RotateGL() const
{
	float fAxisX, fAxisY, fAxisZ, fRotAngle;
	
	m_qRot.GetAxisAngle(fAxisX, fAxisY, fAxisZ, fRotAngle);
	glRotatef(fRotAngle, fAxisX, fAxisY, fAxisZ);
}

/*
	Returns the rotation
*/
ASTVector3D ASTEntity::GetRot() const
{
	ASTVector3D vRot;

	m_qRot.GetEulerAngles(vRot.fX, vRot.fY, vRot.fZ);

	return vRot;
}

/*
	Returns the rotation matrix
*/
ASTMatrix4x4 ASTEntity::GetRotMatrix() const
{
	ASTMatrix4x4 mM;

	glPushMatrix();
	glLoadIdentity();
	RotateGL();
	glGetFloatv (GL_MODELVIEW_MATRIX, mM.fM);
	glPopMatrix();

/* ERROR: There's something wrong!
	ASTMatrix4x4 mM;

	m_qRot.GetMatrix(&mM);*/

	return mM;
}

/*
	Returns the inverted rotation matrix
*/
ASTMatrix4x4 ASTEntity::GetInvertedRotMatrix() const
{
	ASTMatrix4x4 mM;

	glPushMatrix();
	glLoadIdentity();
	RotateGL();
	glGetFloatv (GL_MODELVIEW_MATRIX, mM.fM);
	mM.Invert();
	glPopMatrix();

/* ERROR: There's something wrong!
	ASTMatrix4x4 mM;

	m_qRot.GetInvertedMatrix(&mM);*/

	return mM;
}

/*
	Sets the entities rotation
*/
void ASTEntity::SetRot(const float fX, const float fY, const float fZ)
{
	m_qRot.Set(fX, fY, fZ);
	ComputeDirectionVectors();
}

/*
	Sets the entities rotation
*/
void ASTEntity::SetRot(const ASTVector3D& vRot)
{
	m_qRot.Set(vRot.fX, vRot.fY, vRot.fZ);
	ComputeDirectionVectors();
}

/*
	Increase the entities rotation
*/
void ASTEntity::IncRot(const float fX, const float fY, const float fZ)
{
	m_qRot.PostMult(ASTQuaternion(fX, fY, fZ));
	ComputeDirectionVectors();
}

/*
	Increase the entities rotation
*/
void ASTEntity::IncRot(const ASTVector3D& vRot)
{
	m_qRot.PostMult(ASTQuaternion(vRot.fX, vRot.fY, vRot.fZ));
	ComputeDirectionVectors();
}

/*
	Returns the direction vector
*/
ASTVector3D ASTEntity::GetDirVector() const
{
	return m_vDirVector;
}

/*
	Returns the direction right vector
*/
ASTVector3D ASTEntity::GetDirRightVector() const
{
	return m_vDirRightVector;
}

/*
	Returns the direction up vector
*/
ASTVector3D ASTEntity::GetDirUpVector() const
{
	return m_vDirUpVector;
}

/*
	Stops the entity
*/
void ASTEntity::StopMovement()
{
	m_vVelocity = 0.f;
	m_vGravity  = 0.f;
}

/*
	Returns the resulting velocity
*/
ASTVector3D ASTEntity::GetVelocity() const
{
	if (m_iFlags & ASeEntityFlagPhysics) return m_vVelocity + m_vGravity;
	else								 return m_vVelocity;
}

/*
	Returns the velocity vector
*/
ASTVector3D ASTEntity::GetVelocityVector() const
{
	return m_vVelocity;
}

/*
	Sets the velocity vector
*/
void ASTEntity::SetVelocityVector(const ASTVector3D &vVelocity)
{
	m_vVelocity = vVelocity;
}

/*
	Returns the gravity vector
*/
ASTVector3D ASTEntity::GetGravityVector() const
{
	return m_vGravity;
}

/*
	Sets the gravity vector
*/
void ASTEntity::SetGravityVector(const ASTVector3D& vGravity)
{
	m_vGravity = vGravity;
}

/*
	Sets whether the entity is active or not
*/
void ASTEntity::SetActive(const bool bActive)
{
	m_bActive = bActive;
}

/*
	Returns whether the entity is active or not
*/
bool ASTEntity::IsActive() const
{
	return m_bActive;
}

/*
	Sets whether the entity is visible or not
*/
void ASTEntity::SetVisible(const bool bVisible)
{
	m_bVisible = bVisible;
}

/*
	Returns whether the entity is visible or not
*/
bool ASTEntity::IsVisible() const
{
	return m_bVisible;
}

/*
	Returns whether the entity is in the frustrum or not
*/
bool ASTEntity::InFrustum() const
{
	return m_bInFrustum;
}

/*
	Gets the entity flags
*/
int ASTEntity::GetFlags() const
{
	return m_iFlags;
}

/*
	Sets the entity flags
*/
void ASTEntity::SetFlags(const int iFlags)
{
	m_iFlags = iFlags;
}

/*
	Gets the entity collision flags
*/
int ASTEntity::GetCollisionFlags() const
{
	return m_iCollisionFlags;
}

/*
	Sets the entity collision flags
*/
void ASTEntity::SetCollisionFlags(const int iCollisionFlags)
{
	m_iCollisionFlags = iCollisionFlags;

	// Check the entity managers entity collision list
	if (m_iCollisionFlags & ASeCollisionFlagEntities)
		_AS::CEntityManager.m_lstEntityCollisionList.Add(this);
	else _AS::CEntityManager.m_lstEntityCollisionList.Remove(this);
}

/*
	Gets the entity custom flags
*/
int ASTEntity::GetCustomFlags() const
{
	return m_iCustomFlags;
}

/*
	Sets the entity custom flags
*/
void ASTEntity::SetCustomFlags(const int iFlags)
{
	m_iCustomFlags = iFlags;
}

/*
	Sends a message and data to another entity
*/
bool ASTEntity::SendMessage(ASTEntity* pCEntity, const int iMessage, const int iParameter, const void* pData)
{
	// Is the receiver a valid entity?
	if (!_AS::CEntityManager.m_lstEntityList.IsElement(pCEntity)) return true;

	pCEntity->CustomProcessMessage(iMessage, iParameter, pData);

	return false;
}

/*
	Sets the entity protection state
*/
void ASTEntity::SetProtected(const bool bProtected)
{
	m_bProtected = bProtected;
}

/*
	Returns whether the entity is protected or not
*/
bool ASTEntity::IsProtected() const
{
	return m_bProtected;
}

/*
	Gets the entity name
*/
const char* ASTEntity::GetName() const
{
	return m_szName;
}

/*
	Returns whether the entity is on the floor or not
*/
bool ASTEntity::IsOnFloor() const
{
	if (m_vGravity.IsNull()) return true;
	else					 return false;
}

/*
	Let the entity jump
*/
void ASTEntity::Jump(const float fVelocity)
{
	if (!(m_iFlags & ASeEntityFlagJump)) {
		m_iFlags |= ASeEntityFlagJump;
		m_fJumpTimer = 0.f;
	} else m_fJumpTimer += _AS::CTimer.GetTimeDifference();
	m_vJump = -_AS::CPhysics.GetGravity().GetNormalized() * fVelocity;
}

/*
	Returns whether the entity jumps at the moment or not
*/
bool ASTEntity::IsJumping() const
{
	if (m_iFlags & ASeEntityFlagJump) return true;
	else							  return false;
}

/*
	Stops the jump
*/
void ASTEntity::StopJump()
{
	m_vJump -= m_vJump * _AS::CPhysics.GetFriction() * 10 * _AS::CTimer.GetTimeDifference();
	if (!(m_iFlags & ASeEntityFlagJump)) return;
	m_iFlags	&= ~ASeEntityFlagJump;
	m_fJumpTimer = 0.f;
	m_vJump = 0.f;
}

/*
	Performs friction to the entities velocity
*/
void ASTEntity::PerformFriction(const float fFactor)
{
	m_vVelocity -= m_vVelocity * _AS::CPhysics.GetFriction() * fFactor * _AS::CTimer.GetTimeDifference();
}

/*
	Returns the collision radius
*/
float ASTEntity::GetCollisionRadius() const
{
	return m_fCollisionRadius;
}

/*
	Sets the collision radius
*/
void ASTEntity::SetCollisionRadius(const float fCollisionRadius)
{
	m_fCollisionRadius = fCollisionRadius;
}

/*
	Returns a pointer to the entities model handler
*/
ASTModelHandler* ASTEntity::GetModelHandler()
{
	return NULL;
}

/*
	Plays a sound
*/
bool ASTEntity::PlaySound(ASTSoundHandler& pCSoundHandler) const
{
	pCSoundHandler.SetPos(m_vPos);

	return pCSoundHandler.Play();
}

/*
	Sets the entities mass
*/
void ASTEntity::SetMass(const float fMass)
{
	m_fMass = fMass;
}

/*
	Returns the entities mass
*/
float ASTEntity::GetMass() const
{
	return m_fMass;
}

/*
	This function is called if the entity is initialized
*/
void ASTEntity::CustomInitFunction()
{
}

/*
	This function is called if the entity is de-initialized
*/
void ASTEntity::CustomDeInitFunction()
{
}

/*
	This function is called if the entity is checked whether it is in the frustum or not
*/
bool ASTEntity::CustomFrustumFunction()
{
	return _AS::CFrustum.IsPointIn(m_vPos);
}

/*
	This function is called if the solid parts of the entity are drawn
*/
void ASTEntity::CustomDrawSolidFunction()
{
}

/*
	This function is called if the transparent parts of the entity are drawn
*/
void ASTEntity::CustomDrawTransparentFunction()
{
}

/*
	This function is called if the entity is updated
*/
void ASTEntity::CustomUpdateFunction()
{
}

/*
	This function is called if the entity detects a collision
*/
void ASTEntity::CustomCollisionFunction(const ASTCollisionPacked& pCCollPacked)
{
}

/*
	Process messages which were send to the entity
*/
bool ASTEntity::CustomProcessMessage(const int iMessage, const int iParameter, const void* pData)
{
	return false;
}

/*
	This function is called if the entity is initialized
*/
void ASTEntity::Init()
{
	m_bProtected	   = false;
	m_bActive		   = true;
	m_bVisible		   = true;
	m_bInFrustum	   = true;
	m_bRemove		   = false;
	m_vPos			   = 0.f;
	m_vScale		   = 1.f;
	m_qRot.Set(0.f, 0.f, 0.f);
	m_vDirVector	   = 0.f;
	m_vDirRightVector  = 0.f;
	m_vDirUpVector	   = 0.f;
	m_vVelocity		   = 0.f;
	m_vGravity		   = 0.f;
	m_iFlags		   = 0;
	m_iCollisionFlags  = 0;
	m_iCustomFlags	   = 0;
	m_fCollisionRadius = 0.f;
	m_fMass			   = 1.f;

	// Call the custom initialization function
	CustomInitFunction();
}

/*
	This function is called if the entity is de-initialized
*/
void ASTEntity::DeInit()
{
	ASTLinkedListElement<ASTEntityHandler*>* pSListElement;

	// Call the custom de-initialization function
	CustomDeInitFunction();

	// Clear all entity handlers using this entity
	pSListElement = m_lstHandler.FindFirst();
	while (pSListElement) {
		pSListElement->Data->Unload();
		pSListElement = m_lstHandler.FindNext();
	}
}

/*
	Draws the solid parts of the entity
*/
void ASTEntity::DrawSolid()
{
	// Check if the entity should be rendered
	m_bInFrustum = false;
	if (!m_bActive || !m_bVisible) return;
	
	// Check if the entity is in the frustum
	if (!CustomFrustumFunction()) {
		glPopMatrix();

		return;
	} else m_bInFrustum = true;

	// Call the custom draw solid function
	CustomDrawSolidFunction();
	
	// Debug information
	if (m_iFlags & ASeEntityFlagDebug) {
		glDisable(GL_TEXTURE_2D);
		glColor3f(1.f, 1.f, 1.f);
		glPointSize(10.f);
		glBegin(GL_POINTS);
			glVertex3fv(m_vPos.fV);
		glEnd();
		glBegin(GL_LINES);
			glVertex3fv(m_vPos.fV);
			glVertex3f(m_vPos.fX + m_vDirVector.fX * 20,
					   m_vPos.fY + m_vDirVector.fY * 20,
					   m_vPos.fZ + m_vDirVector.fZ * 20);
			glColor3f(1.f, 0.f, 0.f);
			glVertex3fv(m_vPos.fV);
			glVertex3f(m_vPos.fX + m_vDirRightVector.fX * 10,
					   m_vPos.fY + m_vDirRightVector.fY * 10,
					   m_vPos.fZ + m_vDirRightVector.fZ * 10);
			glColor3f(0.f, 1.f, 0.f);
			glVertex3fv(m_vPos.fV);
			glVertex3f(m_vPos.fX + m_vDirUpVector.fX * 10,
					   m_vPos.fY + m_vDirUpVector.fY * 10,
					   m_vPos.fZ + m_vDirUpVector.fZ * 10);
		glEnd();
	}
}

/*
	Draws the transparent parts of the entity
*/
void ASTEntity::DrawTransparent()
{
	// Check if the entity is in debug mode
	if (m_iFlags & ASeEntityFlagDebug) {
		float fX, fY, fZ;

		glColor4f(1.f, 1.f, 1.f, 1.f);

		// General
		_AS::CRenderer.Print(10, 10, false, "active: %d  visible: %d  frustum: %d",
							 m_bActive, m_bVisible, m_bInFrustum);

		// Position
		_AS::CRenderer.Print(10, 30, false, "pos: %.2f %.2f %.2f",
							 m_vPos.fX, m_vPos.fY, m_vPos.fZ);

		// Rotation
		m_qRot.GetEulerAngles(fX, fY, fZ);
		_AS::CRenderer.Print(10, 50, false, "rot: %.2f %.2f %.2f", fX, fY, fZ);		
	}

	// Check if the entity should be rendered
	m_bInFrustum = false;
	if (!m_bActive || !m_bVisible) return;
	
	// Check if the entity is in the frustum
	if (!CustomFrustumFunction()) return;
	else m_bInFrustum = true;

	// Call the custom draw transparent function
	CustomDrawTransparentFunction();
}

/*
	Updates the entity
*/
void ASTEntity::Update()
{
	if (!m_bActive) {
		return;
	}

	// Check free movement
	if (m_iFlags & ASeEntityFlagFreeMovement) {
		// Rotate
		if (_AS::CInput.IsMouseButtonPressed(2)) IncRot(0.f, 0.f, -_AS::CInput.GetMouseDelta());
		else IncRot(-_AS::CInput.GetMouseDeltaY(), _AS::CInput.GetMouseDeltaX(), 0.f);

		// Move forward
		if (_AS::CInput.IsMouseButtonPressed(0))
			IncPos(GetDirVector() * _AS::CTimer.GetTimeDifference() * 10);

		// Move backward
		if (_AS::CInput.IsMouseButtonPressed(1))
			IncPos(-GetDirVector() * _AS::CTimer.GetTimeDifference() * 10);

		// Slide
		if (_AS::CInput.IsKeyPressed(DIK_UP))
			IncPos(GetDirUpVector() * _AS::CTimer.GetTimeDifference() * 10);
		if (_AS::CInput.IsKeyPressed(DIK_DOWN))
			IncPos(-GetDirUpVector() * _AS::CTimer.GetTimeDifference() * 10);
		if (_AS::CInput.IsKeyPressed(DIK_LEFT))
			IncPos(GetDirRightVector() * _AS::CTimer.GetTimeDifference() * 10);
		if (_AS::CInput.IsKeyPressed(DIK_RIGHT))
			IncPos(-GetDirRightVector() * _AS::CTimer.GetTimeDifference() * 10);
	}

	// Physics
	if (m_iFlags & ASeEntityFlagPhysics) {
		// Add gravity
		if (m_iFlags & ASeEntityFlagGravitation) {
			m_vGravity += _AS::CPhysics.GetGravity() * _AS::CTimer.GetTimeDifference();
			if (m_vGravity.GetLength() > _AS::CPhysics.GetGravity().GetLength())
				m_vGravity = _AS::CPhysics.GetGravity();
		}

		// Perform friction
		if (m_iFlags & ASeEntityFlagGravitation) {
			m_vGravity  -= m_vGravity  * _AS::CPhysics.GetFriction() * _AS::CTimer.GetTimeDifference();
			m_vVelocity -= m_vVelocity * _AS::CPhysics.GetFriction() * _AS::CTimer.GetTimeDifference();
		}
	}

	// Check if the collision detection is activated
	if (m_iCollisionFlags & ASeCollisionFlagEntities) {// Perform collision detection
		if (m_iCollisionFlags & ASeCollisionFlagSphere) {
			ASTLinkedListElement<ASTEntity*>* pListElement;

			pListElement = _AS::CEntityManager.m_lstEntityCollisionList.FindFirst();
			while (pListElement) {
				if (pListElement->Data != this) PerformEntitySphereCollision(pListElement->Data);
				pListElement = _AS::CEntityManager.m_lstEntityCollisionList.FindNext();
			}
		}
	}

	// Call the custom update function
	CustomUpdateFunction();
}

/*
	Computes the direction vectors corresponding to the rotation
*/
void ASTEntity::ComputeDirectionVectors()
{
	ASTQuaternion qT;

	// Direction vector:
	m_qRot.GetDirectionVector(&m_vDirVector);

	// Right vector
	qT = m_qRot;
	qT.PostMult(ASTQuaternion(0.f, -90.f, 0.f));
	qT.GetDirectionVector(&m_vDirRightVector);

	// Up vector
	qT = m_qRot;
	qT.PostMult(ASTQuaternion(90.f, 0.f, 0.f));
	qT.GetDirectionVector(&m_vDirUpVector);
}

/*
	Adds an entity handler
*/
bool ASTEntity::AddHander(ASTEntityHandler* pCHandler)
{
	if (m_lstHandler.Add(pCHandler)) return true;

	return false;
}

/*
	Remove an entity handler
*/
bool ASTEntity::RemoveHander(ASTEntityHandler* pCHandler)
{
	if (m_lstHandler.Remove(pCHandler)) return true;

	return false;
}

/*
	Performs spherical collision detection with other entity
*/
bool ASTEntity::PerformEntitySphereCollision(ASTEntity* pCEntity)
{
	ASTVector3D vDelta;
	float fDistance;

	// Check if the other entity has also the collision detection activated
	if (pCEntity->GetCollisionFlags() & ASeCollisionFlagEntities & ASeCollisionFlagSphere) return false;

	// Check the distance between the two entities
	vDelta    = m_vPos - pCEntity->GetPos();
	fDistance = vDelta.DotProduct();
	if (fDistance > (m_fCollisionRadius + pCEntity->GetCollisionRadius()) * (m_fCollisionRadius + pCEntity->GetCollisionRadius())) {
//		if ((m_iCollisionFlags & ASeCollisionFlagSphereResponse) && 
//			(pCEntity->m_iCollisionFlags & ASeCollisionFlagSphereResponse))
//			m_vLastPos = m_vPos;
			
		return false;
	}

	// Call custom collision detection function
	{
		ASTCollisionPacked CColPacked;

		CColPacked.bFoundCollision = CColPacked.bFoundACollision = true;
		CColPacked.pCEntity = pCEntity;
		CustomCollisionFunction(CColPacked);
	}

	if ((m_iCollisionFlags & ASeCollisionFlagSphereResponse) && 
		(pCEntity->GetCollisionFlags() & ASeCollisionFlagSphereResponse)) {
//		m_vPos = m_vLastPos;
		SphereCollisionResponse(pCEntity);
	}

	return true;
}

/*
	Spherical collision response

	Remark: Only two dimensional ball check!!
*/
void ASTEntity::SphereCollisionResponse(ASTEntity* pCEntity)
{
	if (!pCEntity) return;

	m_vVelocity = _AS::CCollision.Reflect(m_vVelocity, pCEntity->GetPos() - m_vPos) / 70;
}
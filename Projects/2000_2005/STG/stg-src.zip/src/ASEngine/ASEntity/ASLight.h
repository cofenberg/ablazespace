/*
	File: ASLight.h

	Description: Light entity
*/


#ifndef __ASLIGHT_H__
#define __ASLIGHT_H__


// Predefinitions
typedef class ASTModelHandler ASTModelHandler;


// Definitions
enum ASELightFlags {
	ASeLightFlagOpenGL     =    1,	// OpenGL light
	ASeLightFlagCelShading =    4,	// Influences the cel shading
	ASeLightFlagFlares     =    8,	// Lens flares
	ASeLightFlagCorona     =   16,	// Corona around the light
	ASeLightFlagBlend      =   32,	// Brighten the screen (blend effect)
	ASELightFlagAmbient	   =   64,	// Ambient light source
	ASELightFlagDiffuse    =  128,	// Diffuse light source
};
#define ASSTANDARDCORONATEXTURE "standardcorona.jpg"
#define ASSTANDARDFLARETEXTURE  "standardflare.jpg"


// Classes
typedef class ASTLight : public ASTEntity {

	friend ASTRendererHandler;


	public:
		/*
			Gets the light flags

			Returns:
				int -> Light flags
		*/
		AS_API int GetFlags() const;
		
		/*
			Sets the light flags

			Parameters:
				int iFlags -> Light flags which should be set
		*/
		AS_API void SetFlags(const int EFlags);

		/*
			Sets the light color

			Parameters:
				float fRed & fGreen & fBlue -> Light color (RGB)
		*/
		AS_API void SetColor(const float fRed = 1.f, const float fGreen = 1.f, const float fBlue = 1.f);

		/*
			Returns the light color

			Parameters:
				float& fRed & fGreen & fBlue -> Light color (RGB)
		*/
		AS_API void GetColor(float& fRed, float& fGreen, float& fBlue) const;

		/*
			Sets the light brightness

			Parameters:
				float fBrightness -> The lights brightness
		*/
		AS_API void SetBrightness(const float fBrightness = 1.f);

		/*
			Returns the light brightness

			Returns:
				float -> The lights brightness
		*/
		AS_API float GetBrightness() const;

		/*
			Sets the corona size
			
			Parameters:
				float fSize -> Corona size
		*/
		AS_API void SetCoronaSize(const float fSize = 10.f);

		/*
			Returns the corona size
			
			Returns:
				float -> Corona size
		*/
		AS_API float GetCoronaSize() const;

		/*
			Sets the flare size
			
			Parameters:
				float fSize -> Flare size
		*/
		AS_API void SetFlareSize(const float fSize = 2.f);

		/*
			Returns the flare size
			
			Returns:
				float -> Flare size
		*/
		AS_API float GetFlareSize() const;


	private:
		ASFLOAT4 m_fColor;			// The color of the light
		int		 m_iFlags;			// Light flags
		float	 m_fCoronaRot;		// Corona rotation
		float	 m_fCoronaSize;		// Corona size
		float	 m_fFlareSize;		// Flare size
		float    m_fScreenBrighten; // Screen brighten factor
		int		 m_iOpenGLID;		// The OpenGL light ID

		ASTTextureHandler m_CCoronaTexture;	// Corona texture
		ASTTextureHandler m_CFlareTexture;	// Flare texture


		/*
			Virtual entity functions
		*/
		AS_API virtual void CustomInitFunction();
		AS_API virtual void CustomDeInitFunction();
		AS_API virtual bool CustomFrustumFunction();
		AS_API virtual void CustomDrawTransparentFunction();
		AS_API virtual void CustomUpdateFunction();

		/*
			Initializes the render light

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool InitRenderLight();

		/*
			De-initializes the render light

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool DeInitRenderLight();

		/*
			Draw flares

			Returns:
				bool -> 'false' if all went fine else 'true' (no flares are drawn)
		*/
		bool DrawFlares() const;

		/*
			This is used for making the flares.
			
			fP is the position. 1.f is where the light is, -1.f is the opposite side.
			fS is the size. 1.f will fill the screen when looking right at the light.
			fR, fG, and fB are the colour of the flare.
		*/
		void MakeFlare(float fP, float fS, float fR, float fG, float fB, float fBrightness, ASFLOAT3 fSPos) const;


} ASTLight;


#endif // __ASLIGHT_H__

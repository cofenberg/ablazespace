/*
	File: ASEntity.h

	Description: A entity is every dynamic element in your application.
				 An actor is the best ecample for an entity.
*/


#ifndef __ASENTITY_H__
#define __ASENTITY_H__


// Predefinitions
typedef class ASTSoundHandler ASTSoundHandler;


// Definitions
// Entity flags
enum ASEEntityFlags {
	ASeEntityFlagDebug           =   1,	// Debug mode
	ASeEntityFlagPhysics	     =   4,	// Physics will be performed
	ASeEntityFlagGravitation     =   8,	// Perform gravitation
	ASeEntityFlagFriction        =  16,	// Perform friction
	ASeEntityFlagJump		     =  32,	// Does the entity jump at the moment?
	ASeEntityFlagFreeMovement    =  64,	// Could the entity be moved freely?
};

// Collision flags
enum ASECollisionFlags {
	ASeCollisionFlagEntities	   = 1,	// Is it possible to collide with entities?
	ASeCollisionFlagSphere		   = 4,	// Should the entity radius be used for collision detection?
	ASeCollisionFlagSphereResponse = 8,	// Spherical collision response?
};


// Classes
typedef class ASTEntity {

	friend ASTEntityManager;
	friend ASTEntityHandler;


	public:					   
		/*
			Remove the entity

			Notes:
				- The will be removed if the entity manager call its update function
		*/
		AS_API void Remove();

		/*
			Translate the entity in OpenGL to its position
		*/
		AS_API void TranslateGL();

		/*
			Returns the position

			Returns:
				ASTVector3D -> Entity position
		*/
		AS_API ASTVector3D GetPos() const;

		/*
			Sets the entities position

			Parameters:
				float fX & fY & fZ -> The world position
		*/
		AS_API void SetPos(const float fX = 0.f, const float fY = 0.f, const float fZ = 0.f);

		/*
			Sets the entities position

			Parameters:
				ASTVector3D vPos -> The world position
		*/
		AS_API void SetPos(const ASTVector3D& vPos);

		/*
			Increase the entities position

			Parameters:
				float fX & fY & fZ -> The world position increase
		*/
		AS_API void IncPos(const float fX, const float fY, const float fZ);

		/*
			Increase the entities position

			Parameters:
				ASTVector3D vPos -> The world position increase
		*/
		AS_API void IncPos(const ASTVector3D& vPos);

		/*
			Returns the scale

			Returns:
				ASTVector3D -> Entity scale
		*/
		AS_API ASTVector3D GetScale() const;

		/*
			Sets the entities scale

			Parameters:
				float fX & fY & fZ -> The scale
		*/
		AS_API void SetScale(const float fX = 1.f, const float fY = 1.f, const float fZ = 1.f);

		/*
			Sets the entities scale

			Parameters:
				ASTVector3D vPos -> The scale
		*/
		AS_API void SetScale(const ASTVector3D& vScale);

		/*
			Rotate the entity in OpenGL corresponding to its rotation
		*/
		AS_API void RotateGL() const;

		/*
			Returns the rotation

			Returns:
				ASTVector3D -> Entity rotation
		*/
		AS_API ASTVector3D GetRot() const;

		/*
			Returns the rotation matrix

			Returns:
				ASTMatrix4x4 -> Entity rotation matrix
		*/
		AS_API ASTMatrix4x4 GetRotMatrix() const;

		/*
			Returns the inverted rotation matrix

			Returns:
				ASTMatrix4x4 -> Entity inverted rotation matrix
		*/
		AS_API ASTMatrix4x4 GetInvertedRotMatrix() const;

		/*
			Sets the entities rotation

			Parameters:
				float fX & fY & fZ -> The rotation for each axe
		*/
		AS_API void SetRot(const float fX = 0.f, const float fY = 0.f, const float fZ = 0.f);

		/*
			Sets the entities rotation

			Parameters:
				ASTVector3D vRot -> The rotation vector
		*/
		AS_API void SetRot(const ASTVector3D& vRot);

		/*
			Increase the entities rotation

			Parameters:
				float fX & fY & fZ -> The rotation increase for each axe
		*/
		AS_API void IncRot(const float fX, const float fY, const float fZ);

		/*
			Increase the entities rotation

			Parameters:
				ASTVector3D vRot -> The rotation increase vector
		*/
		AS_API void IncRot(const ASTVector3D& vRot);

		/*
			Returns the direction vector

			Returns:
				ASTVector3D -> The entities direction vector
		*/
		AS_API ASTVector3D GetDirVector() const;
		
		/*
			Returns the direction right vector

			Returns:
				ASTVector3D -> The entities direction right vector
		*/
		AS_API ASTVector3D GetDirRightVector() const;

		/*
			Returns the direction up vector

			Returns:
				ASTVector3D -> The entities direction up vector
		*/
		AS_API ASTVector3D GetDirUpVector() const;

		/*
			Stops the entity

			Notes:
				- All movement relevent values will be reset
		*/
		AS_API void StopMovement();

		/*
			Returns the resulting velocity

			Returns:
				ASTVector3D -> The entities resulting velocity

			Notes:
				- The resulting velocity depends on the velcity vector, gravity vector etc.
		*/
		AS_API ASTVector3D GetVelocity() const;

		/*
			Returns the velocity vector

			Returns:
				ASTVector3D -> The entities velocity vector
		*/
		AS_API ASTVector3D GetVelocityVector() const;

		/*
			Sets the velocity vector

			Parameters:
				ASTVector3D vVelocity -> The entities velocity vector
		*/
		AS_API void SetVelocityVector(const ASTVector3D &vVelocity);

		/*
			Returns the gravity vector

			Returns:
				ASTVector3D -> The entities gravity vector
		*/
		AS_API ASTVector3D GetGravityVector() const;

		/*
			Sets the gravity vector

			Parameters:
				ASTVector3D& vGravity -> The entities gravity vector
		*/
		AS_API void SetGravityVector(const ASTVector3D& vGravity);

		/*
			Sets whether the entity is active or not

			Parameters:
				bool bActive -> Should the entity be active?

			Notes:
				- If the entity is not active its automatically invisible
		*/
		AS_API void SetActive(const bool bActive = true);

		/*
			Returns whether the entity is active or not

			Returns:
				bool -> 'true' if the entity is active else 'false'
		*/
		AS_API bool IsActive() const;

		/*
			Sets whether the entity is visible or not

			Parameters:
				bool bVisible -> Should the entity be visible?
		*/
		AS_API void SetVisible(const bool bVisible = true);

		/*
			Returns whether the entity is visible or not

			Returns:
				bool -> 'true' if the entity is visible else 'false'

			Notes:
				- Returns the real visibility state which is independent from the active state
		*/
		AS_API bool IsVisible() const;

		/*
			Returns whether the entity is in the frustrum or not

			Returns:
				bool -> 'true' if the entity is in the frustum else 'false'

			Notes:
				- If the entity is invisible its automatically not in the frustrum
				- The state will be updated by the renderer
		*/
		AS_API bool InFrustum() const;
		
		/*
			Gets the entity flags

			Returns:
				int -> Entity flags
		*/
		AS_API int GetFlags() const;
		
		/*
			Sets the entity flags

			Parameters:
				int iFlags -> Entity flags which should be set
		*/
		AS_API void SetFlags(const int iFlags = 0);

		/*
			Gets the entity collision flags

			Returns:
				int -> Entity collision flags
		*/
		AS_API int GetCollisionFlags() const;
		
		/*
			Sets the entity collision flags

			Parameters:
				int iFlags -> Entity collision flags which should be set
		*/
		AS_API void SetCollisionFlags(const int iCollisionFlags = 0);

		/*
			Gets the entity custom flags

			Returns:
				int -> Entity custom flags

			Notes:
				- The engine doesn't use this flags, they are only for custom purposes
		*/
		AS_API int GetCustomFlags() const;
		
		/*
			Sets the entity custom flags

			Parameters:
				int iFlags -> Entity custom flags which should be set

			Notes:
				- The engine doesn't use this flags, they are only for custom purposes
		*/
		AS_API void SetCustomFlags(const int iFlags = 0);

		/*
			Sends a message and data to another entity

			Parameters:
				ASTEntity* pCEntity   -> Receiver entity
				int		   iMessage   -> Message
				int		   iParameter -> Message parameter
				void*	   pData	  -> Additional data

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool SendMessage(ASTEntity* pCEntity, const int iMessage, const int iParameter = 0, const void* pData = NULL);

		/*
			Sets the entity protection state

			Parameters:
				bool bProtected -> Should the entity be protected or not?

			Notes:
				- If the entity is protected it will not be removed if the entity manager
				  tries it (it's only removed if the application is shut down :)
		*/
		AS_API void SetProtected(const bool bProtected = false);

		/*
			Returns whether the entity is protected or not

			Returns:
				bool -> 'true' if the entity is protected else 'false'
		*/
		AS_API bool IsProtected() const;

		/*
			Gets the entity name

			Returns:
				char* -> Entity name
		*/
		AS_API const char* GetName() const;

		/*
			Returns whether the entity is on the floor or not
			
			Returns:
				bool -> 'true' if the entity is on the floor else 'false'
		*/
		AS_API bool IsOnFloor() const;

		/*
			Let the entity jump

			Parameters:
				float fVelocity -> Jump velocity (against the gravitation)
		*/
		AS_API void Jump(const float fVelocity = 0.f);

		/*
			Returns whether the entity jumps at the moment or not

			Returns:
				bool -> 'true' if the entity jumps at the moment else 'false'
		*/
		AS_API bool IsJumping() const;

		/*
			Stops the jump
		*/
		AS_API void StopJump();

		/*
			Performs friction to the entities velocity

			Parameters:
				float fFactor -> Friction factor

			Notes:
				- The friction could be setup in the physics class
		*/
		AS_API void PerformFriction(const float fFactor = 1.f);

		/*
			Returns the collision radius

			Returns:
				float -> Collision radius
		*/
		AS_API float GetCollisionRadius() const;

		/*
			Sets the collision radius

			Parameters:
				float fCollisionRadius -> Collision radius
		*/
		AS_API void SetCollisionRadius(const float fCollisionRadius = 1.f);

		/*
			Returns a pointer to the entities model handler

			Returns:
				ASTModelHandler* -> Pointer to the entities model handler
		*/
		AS_API virtual ASTModelHandler* GetModelHandler();

		/*
			Plays a sound

			Notes:
				- The sound will automatically have the entities position

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool PlaySound(ASTSoundHandler& pCSoundHandler) const;

		/*
			Sets the entities mass

			Parameters:
				float fMass -> The entities mass
		*/
		AS_API void SetMass(const float fMass);

		/*
			Returns the entities mass

			Returns:
				float -> The entities mass
		*/
		AS_API float GetMass() const;


	protected:
		ASTVector3D	    m_vPos;				// World position
		ASTVector3D	    m_vScale;			// Scale
		ASTQuaternion   m_qRot;				// Rotation quaternion
		ASTVector3D	    m_vDirVector;		// Direction vector corresponding to the rotation
		ASTVector3D	    m_vDirRightVector;	// Right vector of the direction vector
		ASTVector3D	    m_vDirUpVector;		// Up vector of the direction vector
		ASTVector3D	    m_vVelocity;		// Velocity vector
		ASTVector3D	    m_vGravity;			// Gravitation vector
		ASTVector3D	    m_vJump;			// Jumping vector
		float		    m_fJumpTimer;		// Jump timer
		float			m_fMass;			// The entities mass

		ASTVector3D m_vLastPos;


	private:
		char		  m_szName[256];		// Entity name
		bool		  m_bProtected;			// Is this entity protected (its handled by the entity manager in another way)
		bool		  m_bActive;			// Is the entity active?
		bool		  m_bVisible;			// Is it visible?
		bool		  m_bInFrustum;			// Is it in the frustum?
		bool		  m_bRemove;			// Should the entity be removed?
		int			  m_iFlags;				// Entity flags
		int			  m_iCollisionFlags;	// Entity collision flags
		int			  m_iCustomFlags;		// Entity custom flags
		float		  m_fCollisionRadius;	// Collision radius

		ASTLinkedList<ASTEntityHandler*> m_lstHandler; // A list of all entity handlers using this entity


		/*
			This function is called if the entity is initialized
		*/
		AS_API virtual void CustomInitFunction();

		/*
			This function is called if the entity is de-initialized
		*/
		AS_API virtual void CustomDeInitFunction();

		/*
			This function is called if the entity is checked whether it is in the frustum or not

			Returns:
				bool -> 'true' if the entity is in the frustum else 'false'
		*/
		AS_API virtual bool CustomFrustumFunction();

		/*
			This function is called if the solid parts of the entity are drawn
		*/
		AS_API virtual void CustomDrawSolidFunction();

		/*
			This function is called if the transparent parts of the entity are drawn
		*/
		AS_API virtual void CustomDrawTransparentFunction();

		/*
			This function is called if the entity is updated
		*/
		AS_API virtual void CustomUpdateFunction();

		/*
			This function is called if the entity detects a collision

			Parameters:
				ASTCollisionPacked& pCCollPacked -> Information about the collision
		*/
		AS_API virtual void CustomCollisionFunction(const ASTCollisionPacked& pCCollPacked);

		/*
			Process messages which were send to the entity

			Parameters:
				int		   iMessage   -> Message
				int		   iParameter -> Message parameter
				void*	   pData	  -> Additional data

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API virtual bool CustomProcessMessage(const int iMessage, const int iParameter = 0, const void* pData = NULL);

		/*
			This function is called if the entity is initialized
		*/
		void Init();

		/*
			This function is called if the entity is de-initialized
		*/
		void DeInit();

		/*
			Draws the entity solid parts
		*/
		void DrawSolid();

		/*
			Draws the entity transparent parts
		*/
		void DrawTransparent();

		/*
			Updates the entity
		*/
		void Update();

		/*
			Computes the direction vectors corresponding to the rotation
		*/
		void ComputeDirectionVectors();

		/*
			Adds an entity handler

			Parameters:
				ASTEntityHandler* pCHander -> Pointer to the entity handler which should be added

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool AddHander(ASTEntityHandler* pCHandler);

		/*
			Remove an entity handler

			Parameters:
				ASTEntityHandler* pCHander -> Pointer to the entity handler which should be removed

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool RemoveHander(ASTEntityHandler* pCHandler);

		/*
			Performs spherical collision detection with other entity

			Parameter:
				ASTEntity* pCEntity -> The potential other entity

			Returns:
				bool -> 'true' if there's a collision else 'false'
		*/
		bool PerformEntitySphereCollision(ASTEntity* pCEntity);

		/*
			Spherical collision response

			Parameters:
				ASTEntity* pCEntity -> The other entity we collided with
		*/
		void SphereCollisionResponse(ASTEntity* pCEntity);


} ASTEntity;


#endif // __ASENTITY_H__
/*
	File: ASEntityManager.cpp
*/

#include <ASEngineDll.h>


/*
	Constructor
*/
ASTEntityManager::ASTEntityManager()
{
}

/*
	Destructor
*/
ASTEntityManager::~ASTEntityManager()
{
	Clear();
}

/*
	Adds an entity
*/
bool ASTEntityManager::Add(ASTEntity* pCEntity, const char* pszName)
{
	// Check pointer
	if (!pCEntity) return true;
	
	bool bError = m_lstEntityList.Add(pCEntity);
	strcpy(pCEntity->m_szName, pszName);
	pCEntity->Init();

	return bError;
}

/*
	Removes an entity
*/
bool ASTEntityManager::Remove(ASTEntity* pCEntity)
{
	// Check pointer
	if (!pCEntity) return true;

	pCEntity->DeInit();
	bool bError = m_lstEntityList.Remove(pCEntity);
	m_lstEntityCollisionList.Remove(pCEntity);

	return bError;
}

/*
	Unload all entitys
*/
void ASTEntityManager::Clear(const bool bProtectedToo)
{
	ASTEntity* pCEntity;

	_AS::CLog.Output("Clear entity manager");

	// Remove entities
	for (int i = 0; i < m_lstEntityList.GetElements(); i++) {
		if (!(pCEntity = m_lstEntityList[i])) break;
		if (!pCEntity->IsProtected() || bProtectedToo) {
			Remove(pCEntity);
			delete pCEntity;
			i--;
		}
	}
}

/*
	Draws all visible entities (solid and transparent)
*/
void ASTEntityManager::Draw()
{
	for (int i = 0; i < m_lstEntityList.GetElements(); i++) {
		m_lstEntityList[i]->DrawSolid();
		m_lstEntityList[i]->DrawTransparent();
	}
}

/*
	Draws all visible solid entities
*/
void ASTEntityManager::DrawSolid()
{
	glDisable(GL_BLEND);
	for (int i = 0; i < m_lstEntityList.GetElements(); i++) m_lstEntityList[i]->DrawSolid();
}

/*
	Draws all visible transparent entities
*/
void ASTEntityManager::DrawTransparent()
{
	glEnable(GL_BLEND);
	for (int i = 0; i < m_lstEntityList.GetElements(); i++) m_lstEntityList[i]->DrawTransparent();
}

/*
	Returns the entity with the given name
*/
ASTEntity* ASTEntityManager::Get(const char* pszName)
{
	ASTLinkedListElement<ASTEntity*>* pSListElement;

	if (!pszName) return NULL;

	pSListElement = m_lstEntityList.FindFirst();
	while (pSListElement) {
		if (!stricmp(pSListElement->Data->m_szName, pszName))
			return pSListElement->Data;
		pSListElement = m_lstEntityList.FindNext();
	}

	return NULL;
}

/*
	Returns the first light entity
*/
ASTLight* ASTEntityManager::FindFirstLight()
{
	ASTLinkedListElement<ASTLight*>* pListElement;
	
	if (!(pListElement = m_lstLightList.FindFirst())) return NULL;

	return pListElement->Data;
}

/*
	Returns the next light entity
*/
ASTLight* ASTEntityManager::FindNextLight()
{
	ASTLinkedListElement<ASTLight*>* pListElement;
	
	if (!(pListElement = m_lstLightList.FindNext())) return NULL;

	return pListElement->Data;
}

/*
	Initialize the entity manager
*/
bool ASTEntityManager::Init()
{
	// Load the standard entity
	_AS::CLog.Output("Initialize entity manager");
	
	return false;
}

/*
	Updates all entity relevant stuff
*/
void ASTEntityManager::Update()
{
	ASTEntity* pCEntity;

	// Remove entities
	for (int i = 0; i < m_lstEntityList.GetElements(); i++) {
		if (m_lstEntityList[i]->m_bRemove) {
			pCEntity = m_lstEntityList[i];
			Remove(pCEntity);
			delete pCEntity;
		}
	}

	// Is the engine paused?
	if (_AS::CTimer.IsPaused()) return;

	// Update all entities
	for (i = 0; i < m_lstEntityList.GetElements(); i++) m_lstEntityList[i]->Update();
}
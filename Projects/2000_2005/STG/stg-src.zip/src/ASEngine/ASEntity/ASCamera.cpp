/*
	File: ASCamera.cpp
*/

#include <ASEngineDll.h>


/*
	Sets the camera
*/
bool ASTCamera::Set(const bool bTranslate)
{
	int iWidth, iHeight;
	RECT Rect;

	if (!_AS::CRenderer.GetRendererHandler() || !_AS::CRenderer.GetRendererHandler()->IsInitialized())
		return true;

	// Get window size	
	GetWindowRect(_AS::CRenderer.GetRendererHandler()->GetWnd(), &Rect);
	iWidth  = Rect.right  - Rect.left;
	iHeight = Rect.bottom - Rect.top;

	// Reset the scene
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glViewport(0, 0, iWidth, iHeight);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(m_fFOV,
				   (float) iWidth / (float) iHeight * m_fAspect,
				   m_fZNear, m_fZFar * _AS::CConfig.GetVisibility());
	glMatrixMode(GL_MODELVIEW);

	// Translate & rotate the camera
	if (m_iFlags & ASeCameraFlagThirdPersonFlag && m_CTargetEntity.IsLoaded()) {
		ASTEntity* pCEntity = m_CTargetEntity.GetEntity();
		if (!bTranslate) {
			glRotatef(180.f, 0.f, 0.f, 1.f);
			glRotatef(m_fRotT[Z], 0.f, 1.f, 0.f);
			glRotatef(-205.f + m_fRotT[X], 1.f, 0.f, 0.f);
			pCEntity->RotateGL();
		} else {
			glTranslatef(0.f, 0.f, m_fZoom);			
			glRotatef(180.f, 0.f, 0.f, 1.f);
			glRotatef(m_fRotT[Z], 0.f, 1.f, 0.f);
			glRotatef(-205.f + m_fRotT[X], 1.f, 0.f, 0.f);
			pCEntity->RotateGL();
			glTranslatef(-pCEntity->GetPos().fX + m_vVelocity.fX, -pCEntity->GetPos().fY + m_vVelocity.fY, -pCEntity->GetPos().fZ + m_vVelocity.fZ + 5);

			m_vPos = pCEntity->GetPos();
			m_vPos.fZ -= 10;
		}
	} else {
		if (!bTranslate) {
			RotateGL();
		} else {
			RotateGL();
			glTranslatef(-m_vPos.fX + m_vVelocity.fX, -m_vPos.fY + m_vVelocity.fY, -m_vPos.fZ + m_vVelocity.fZ);
		}
	}

	// Extract the new frustum
	_AS::CFrustum.Update();

	return false;
}

/*
	Gets the camera flags
*/
int ASTCamera::GetFlags() const
{
	return m_iFlags;
}

/*
	Sets the camera flags
*/
void ASTCamera::SetFlags(const int iFlags)
{
	m_iFlags = iFlags;
}

/*
	Sets the camera target entity
*/
void ASTCamera::SetTarget(ASTEntity* pCEntity)
{
	m_CTargetEntity.Load(pCEntity);
}

/*
	Gets the camera target entity
*/
ASTEntity* ASTCamera::GetTarget() const
{
	return m_CTargetEntity.GetEntity();
}

/*
	Sets the FOV
*/
void ASTCamera::SetFOV(const float fFOV)
{
	m_fFOV = fFOV;
}

/*
	Returns the FOV
*/
float ASTCamera::GetFOV() const
{
	return m_fFOV;
}

/*
	This function is called if the camera entity is initialized
*/
void ASTCamera::CustomInitFunction()
{
	SetVisible(false);
	m_iFlags  = 0;
	m_fFOV	  = 45.f;
	m_fAspect = 1.f;
	m_fZNear  = 1.f;
	m_fZFar	  = 350.f;

	m_fZoom = -20;
	m_fRotT[X] = m_fRotT[Y] = m_fRotT[Z] = 0.f;
}

/*
	Checks whether the camera is in the frustum or not
*/
bool ASTCamera::CustomFrustumFunction()
{
	return _AS::CFrustum.IsPointIn(GetPos());
}

/*
	This function is called if the camera entity is updated
*/
void ASTCamera::CustomUpdateFunction()
{
	// Is the camera free moveable?
	if (m_iFlags & ASeCameraFlagFree) {
		// Rotate
		if (_AS::CInput.IsMouseButtonPressed(2)) IncRot(0.f, 0.f, _AS::CInput.GetMouseDelta());
		else IncRot(_AS::CInput.GetMouseDeltaY(), _AS::CInput.GetMouseDeltaX(), 0.f);

		// Move forward
		if (_AS::CInput.IsMouseButtonPressed(0))
			IncPos(-GetDirVector() * _AS::CTimer.GetTimeDifference() * 100);

		// Move backward
		if (_AS::CInput.IsMouseButtonPressed(1))
			IncPos(GetDirVector() * _AS::CTimer.GetTimeDifference() * 100);

		// Slide
		if (_AS::CInput.IsKeyPressed(DIK_UP))
			IncPos(GetDirUpVector() * _AS::CTimer.GetTimeDifference() * 100);
		if (_AS::CInput.IsKeyPressed(DIK_DOWN))
			IncPos(-GetDirUpVector() * _AS::CTimer.GetTimeDifference() * 100);
		if (_AS::CInput.IsKeyPressed(DIK_LEFT))
			IncPos(-GetDirRightVector() * _AS::CTimer.GetTimeDifference() * 100);
		if (_AS::CInput.IsKeyPressed(DIK_RIGHT))
			IncPos(GetDirRightVector() * _AS::CTimer.GetTimeDifference() * 100);
	} else
	if (m_iFlags & ASeCameraFlagThirdPersonFlag && m_CTargetEntity.IsLoaded()) {
		m_fRotT[X] -= _AS::CInput.GetMouseDeltaY() / 5;
		if (m_fRotT[X] > 50.f) m_fRotT[X] = 50.f;
		if (m_fRotT[X] < -50.f) m_fRotT[X] = -50.f;
		m_fRotT[Z] += _AS::CInput.GetMouseDeltaX() / 2;
		if (m_fRotT[Z] > 50.f) m_fRotT[Z] = 50.f;
		if (m_fRotT[Z] < -50.f) m_fRotT[Z] = -50.f;
		for (int i = 0; i < 3; i++)
			m_fRotT[i] -= m_fRotT[i] * _AS::CPhysics.GetFriction().fV[i] * _AS::CTimer.GetTimeDifference();
	}

	// Call the custom camera update function
	CustomCameraUpdateFunction();
}

/*
	Custom camera update function
*/
void ASTCamera::CustomCameraUpdateFunction()
{
}
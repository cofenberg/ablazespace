/*
	File: ASLight.cpp
*/

#include <ASEngineDll.h>


// Variables
int ASiLighFlareList;	// Light flare display list
int ASiLightBrightList;	// Light screen brighten display list


/*
	Custum light renderer initialization function
*/
void ASLightRendererInit()
{
	_AS::CLog.Output("Create engine light display lists");

	ASiLighFlareList = glGenLists(2);
	glNewList(ASiLighFlareList, GL_COMPILE);
		glBegin(GL_QUADS);
			glTexCoord2f(0.f, 0.f);
			glVertex2f(-0.1f, -0.1f);
			glTexCoord2f(1.f, 0.f);
			glVertex2f(0.1f, -0.1f);
			glTexCoord2f(1.f, 1.f);
			glVertex2f(0.1f, 0.1f);
			glTexCoord2f(0.f, 1.f);
			glVertex2f(-0.1f, 0.1f);
		glEnd();
	glEndList();

	ASiLightBrightList = ASiLighFlareList + 1;
	glNewList(ASiLightBrightList, GL_COMPILE);
		glBegin(GL_QUADS);
			glVertex2f(-2.f, -2.f);
			glVertex2f(2.f, -2.f);
			glVertex2f(2.f, 2.f);
			glVertex2f(-2.f, 2.f);
		glEnd();
	glEndList();
}

/*
	Custum light renderer de-initialization function
*/
void ASLightRendererDeInit()
{
	_AS::CLog.Output("Delete engine light display lists");

	glDeleteLists(ASiLighFlareList, 2);
}

/*
	Gets the light flags
*/
int ASTLight::GetFlags() const
{
	return m_iFlags;
}

/*
	Sets the light flags
*/
void ASTLight::SetFlags(const int iFlags)
{
	m_iFlags = iFlags;
}

/*
	Sets the light color
*/
void ASTLight::SetColor(const float fRed, const float fGreen, const float fBlue)
{
	m_fColor[R] = fRed;
	m_fColor[G] = fGreen;
	m_fColor[B] = fBlue;
}

/*
	Returns the light color
*/
void ASTLight::GetColor(float& fRed, float& fGreen, float& fBlue) const
{
	fRed   = m_fColor[R];
	fGreen = m_fColor[G];
	fBlue  = m_fColor[B];
}

/*
	Sets the light brightness
*/
void ASTLight::SetBrightness(const float fBrightness)
{
	m_fColor[A] = fBrightness;
}

/*
	Returns the light brightness
*/
float ASTLight::GetBrightness() const
{
	return m_fColor[A];
}

/*
	Sets the corona size
*/
void ASTLight::SetCoronaSize(const float fSize)
{
	m_fCoronaSize = fSize;
}

/*
	Returns the corona size
*/
float ASTLight::GetCoronaSize() const
{
	return m_fCoronaSize;
}

/*
	Sets the flare size
*/
void ASTLight::SetFlareSize(const float fSize)
{
	m_fFlareSize = fSize;
}

/*
	Returns the flare size
*/
float ASTLight::GetFlareSize() const
{
	return m_fFlareSize;
}

/*
	This function is called if the light entity is initialized
*/
void ASTLight::CustomInitFunction()
{
	m_fColor[R] = m_fColor[G] = m_fColor[B] = m_fColor[A] = 1.f;
	m_iFlags		   = ASELightFlagAmbient;
	m_fCoronaRot	   = 0.f;
	m_fCoronaSize      = 10.f;
	m_fFlareSize       = 2.f;
	m_fScreenBrighten  = 0.2f;
	m_iOpenGLID		   = 0;

	// Add the light to the entity managers light list
	_AS::CEntityManager.m_lstLightList.Add(this);

	// Load light textures
	m_CCoronaTexture.Load(ASSTANDARDCORONATEXTURE);
	m_CFlareTexture.Load(ASSTANDARDFLARETEXTURE);
}

/*
	This function is called if the light entity is de-initialized
*/
void ASTLight::CustomDeInitFunction()
{
	// Remove the light from the entity managers light list
	_AS::CEntityManager.m_lstLightList.Remove(this);

	// Unload light textures
	m_CCoronaTexture.Unload();
	m_CFlareTexture.Unload();
}

/*
	This function is called if the light entity is drawn
*/
void ASTLight::CustomDrawTransparentFunction()
{
	DrawFlares();
}

/*
	This function is called if the light entity is updated
*/
void ASTLight::CustomUpdateFunction()
{
	// Is the light visible?
	if (!InFrustum()) return;

	// Rotate the corona
	if (m_iFlags & ASeLightFlagCorona) m_fCoronaRot += _AS::CTimer.GetTimeDifference() * 10;
}

/*
	Checks whether the light is in the frustum or not
*/
bool ASTLight::CustomFrustumFunction()
{
	return true;
//	return _AS::CRenderer.IsPointInFrustum(GetPos());
}

/*
	Initialize the render light
*/
bool ASTLight::InitRenderLight()
{
	if (!(m_iFlags & ASeLightFlagOpenGL)) return false;

	// Check OpenGL light
	if (!m_iOpenGLID) { // Get a unused OpenGL light
		GLboolean bLightState;
		GLint iLights;

		glGetIntegerv(GL_MAX_LIGHTS, &iLights);
		for (int i = 1; i < iLights; i++) {
			glGetBooleanv(GL_LIGHT0 + i, &bLightState);
			if (!bLightState) {
				m_iOpenGLID = i;
				break;
			}
		}
	}

	// Check OpenGL light
	if (!m_iOpenGLID) return true;

/*
	glLightfv(GL_LIGHT0 + m_iOpenGLID, GL_AMBIENT,  m_fAmbientColor);
	glLightfv(GL_LIGHT0 + m_iOpenGLID, GL_DIFFUSE,  m_fDiffuseColor);
	glLightfv(GL_LIGHT0 + m_iOpenGLID, GL_POSITION, GetPos().fV);
	glEnable( GL_LIGHT0 + m_iOpenGLID);
*/
	return false;
}

/*
	De-initialize the render light
*/
bool ASTLight::DeInitRenderLight()
{
	// Check OpenGL light
	if (!m_iOpenGLID) return true;

	glDisable(GL_LIGHT0 + m_iOpenGLID);
	m_iOpenGLID = 0;

	return false;
}

/*
	Draw flares
*/
bool ASTLight::DrawFlares() const
{
    GLdouble dModelMatrix[16];
    GLdouble dProjMatrix[16];
    float fBrightness = 0.f, fBrightnessT; // How bright the light is
    GLint iViewport[4];
    ASDOUBLE3 dSPos; // Where on the screen the light is
	ASFLOAT3 fSPos; // The same as float
    bool bBig = true;
    float fDepth; // The depth in the framebuffer
    int iX, iY;

	// Check if high render quality is activated
	if (!_AS::CConfig.IsHighRenderQuality()) return true;

	float fFactor;
	if (_AS::CRenderer.GetCamera()) {
		fFactor = 20 / (_AS::CRenderer.GetCamera()->GetPos() - GetPos()).GetLength();
		if (fFactor > 1.f) fFactor = 1.f;
		if (fFactor < 0.f) fFactor = 0.f;
	} else fFactor = 1.f;

	// Load the matricies and viewport
    glGetDoublev(GL_MODELVIEW_MATRIX,  dModelMatrix);
    glGetDoublev(GL_PROJECTION_MATRIX, dProjMatrix);
    glGetIntegerv(GL_VIEWPORT, iViewport);
    
	// Find out where the light is on the screen
	gluProject(GetPos().fX, GetPos().fY, GetPos().fZ, dModelMatrix, dProjMatrix,
			   iViewport, &dSPos[X], &dSPos[Y], &dSPos[Z]);

    // Go through some of the points near the light
    for (iY = -4; iY <= 4; iY++) {
		for (iX = -4; iX <= 4; iX++)
            if (iViewport[2] / 300.f * iX + dSPos[X] < iViewport[2] &&
			    iViewport[2] / 300.f * iX + dSPos[X] >= 0 &&
			    iViewport[3] / 300.f * iY + dSPos[Y] < iViewport[3] &&
			    iViewport[3] / 300.f * iY + dSPos[Y] >= 0 ) { // If the point is on the screen

                // Read the depth from the depth buffer
				glReadPixels((int) (iViewport[2] / 300.f * iX + dSPos[X]),
							 (int) (iViewport[3] / 300.f * iY + dSPos[Y]),
							 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, &fDepth);

                // If the light is infront of what ever was in that spot, increase the brightness
				if (fDepth >= dSPos[Z]) fBrightness += 1.f / 81.f; 
            }
        }

	if (dSPos[X] < iViewport[2] && dSPos[X] >= 0 &&
	    dSPos[Y] < iViewport[3] && dSPos[Y] >= 0) { // If the light is on the screen

        glReadPixels((int) (dSPos[X]),(int) (dSPos[Y]), 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, &fDepth);
        if (fDepth < dSPos[Z] && dSPos[Z] - fDepth > 0.0002f) // It is behind something
            fBrightness = 0.f; // The light can't be seen
    } else fBrightness = 0.f; // The light can't be seen    
	
     // Now that we know the brightness, convert
	dSPos[X] = dSPos[X] / (float) iViewport[2] * 2.f - 1.f;
    // The position to a number between (-1, -1) and (1, 1)
	dSPos[Y] = dSPos[Y] / (float) iViewport[2] * 2.8f - 1.f;

	// Adjust the brightness so it is brighter at the centre of the screen
	fBrightness *= 1.f - ASSqrt((float) (dSPos[X] * dSPos[X] + dSPos[Y] * dSPos[Y]));

	if (fBrightness > m_fColor[A]) fBrightness = m_fColor[A];
	if (fBrightness <= 0.f) return true;
    
	// Draw now the flares
	glPushMatrix();
    glLoadIdentity();
    glMatrixMode(GL_PROJECTION);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	glPushMatrix();
	glDepthMask(FALSE);

	// Forget about the view and projection. We will be drawing in 2D for the flares
	glLoadIdentity();
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    glDisable(GL_LIGHTING);
    glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);

    fSPos[X] = (float) dSPos[X];
    fSPos[Y] = (float) dSPos[Y];
    fSPos[Z] = (float) dSPos[Z];

	// Draw corona
	if (m_iFlags & ASeLightFlagCorona) {
		// Draw the corona
		glPushMatrix();
		glTranslatef(fSPos[X], fSPos[Y], 0.f);
		glRotatef(m_fCoronaRot, 0.f, 0.f, 1.f);
		glScalef(m_fCoronaSize * fFactor, m_fCoronaSize * fFactor, m_fCoronaSize * fFactor);
		glColor4f(m_fColor[R], m_fColor[G], m_fColor[B], fBrightness * m_fColor[A]);
		m_CCoronaTexture.GetTexture()->BindOpenGLTexture();
		glCallList(ASiLighFlareList);
		_AS::CRenderer.AddTriangles(2);
		glPopMatrix();
	}
 
	if (fFactor * 10 <= 1.f)
		fBrightnessT = fBrightness * fFactor * 10;
	else fBrightnessT = fBrightness;

    // Draw other flares
	if (m_iFlags & ASeLightFlagFlares) {
		m_CFlareTexture.GetTexture()->BindOpenGLTexture();
		MakeFlare(0.7f,  0.2f * fFactor,	    m_fColor[R],		m_fColor[G],	    m_fColor[B], fBrightnessT, fSPos);
		MakeFlare(0.6f,  0.3f * fFactor,	    m_fColor[R], 0.6f * m_fColor[G], 0.6f * m_fColor[B], fBrightnessT, fSPos);
		MakeFlare(0.4f,  0.4f * fFactor,        m_fColor[R],		m_fColor[G],		m_fColor[B], fBrightnessT, fSPos);
		MakeFlare(0.3f,  0.6f * fFactor, 0.8f * m_fColor[R], 0.8f * m_fColor[G], 0.6f * m_fColor[B], fBrightnessT, fSPos);
		MakeFlare(0.2f,  0.5f * fFactor,		m_fColor[R],		m_fColor[G],		m_fColor[B], fBrightnessT, fSPos);
		MakeFlare(-0.1f, 0.4f * fFactor, 0.6f * m_fColor[R],		m_fColor[G], 0.6f * m_fColor[B], fBrightnessT, fSPos);
		MakeFlare(-0.2f, 0.3f * fFactor,		m_fColor[R],		m_fColor[G],		m_fColor[B], fBrightnessT, fSPos);
		MakeFlare(-0.4f, 0.2f * fFactor, 0.6f * m_fColor[R], 0.8f * m_fColor[G], 0.8f * m_fColor[B], fBrightnessT, fSPos);
		MakeFlare(-0.6f, 0.4f * fFactor,	    m_fColor[R],		m_fColor[G],		m_fColor[B], fBrightnessT, fSPos);
		MakeFlare(-0.7f, 0.5f * fFactor, 0.6f * m_fColor[R], 0.6f * m_fColor[G],		m_fColor[B], fBrightnessT, fSPos);
		MakeFlare(-0.8f, 0.6f * fFactor,		m_fColor[R],		m_fColor[G],		m_fColor[B], fBrightnessT, fSPos);
		MakeFlare(-0.9f, 0.5f * fFactor, 0.8f * m_fColor[R], 0.6f * m_fColor[G], 0.8f * m_fColor[B], fBrightnessT, fSPos);
		MakeFlare(-1.2f, 0.3f * fFactor,	    m_fColor[R],		m_fColor[G],		m_fColor[B], fBrightnessT, fSPos);
		_AS::CRenderer.AddTriangles(2);
		fBrightness *= m_fColor[A];

	}

    // Brighten the screen
	if (m_iFlags & ASeLightFlagBlend) {
	    glDisable(GL_TEXTURE_2D);
		glColor4f(m_fColor[R], m_fColor[G], m_fColor[B], fBrightness * fFactor * m_fColor[A] * m_fScreenBrighten);
		glCallList(ASiLightBrightList);
		_AS::CRenderer.AddTriangles(2);
		_AS::CRenderer.AddTriangles(2);
	}

    glEnable(GL_CULL_FACE);
    glEnable(GL_DEPTH_TEST);
    glPopMatrix(); 
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
	glDepthMask(TRUE);

	return false;
}

/*
	This is used for making the flares
*/
void ASTLight::MakeFlare(float fP, float fS, float fR, float fG, float fB, float fBrightness,
						 ASFLOAT3 fSPos) const
{
	glPushMatrix();
	glTranslatef(fSPos[X] * fP, fSPos[Y] * fP, 0.f);
	glColor4f(fR, fG, fB, fBrightness * m_fColor[A] * 0.5f);
	glScalef(m_fFlareSize * fS, m_fFlareSize * fS, m_fFlareSize * fS);
	glCallList(ASiLighFlareList);
	glPopMatrix();
}
/*
	File: ASEntityManager.h

	Description: Manages all your entities.
*/


#ifndef __ASENTITYMANAGER_H__
#define __ASENTITYMANAGER_H__


// Predefinitions
typedef class ASTEntity ASTEntity;
typedef class ASTEntityManager ASTEntityManager;
typedef class ASTRendererHandler ASTRendererHandler;


// Inludes
#include "ASEntityHandler.h"
#include "ASEntity.h"
#include "ASCamera.h"
#include "ASLight.h"


// Macros
/*
	Creates an new entity

	Parameters:
		pCEntityT -> Entity pointer (ASTEntity*)
		TEntityT  -> The entity type (e.g. ASTEntity)
		szName	  -> Entity name

	Notes:
		- After the entity is created you should 'forget' the entity pointer because
		  its the best to let the entity manager to the work
		- It's the best to remove the entity through its Remove() function
*/
#define ASCreateEntity(pCEntityT, TEntityT, szName) \
{ \
	TEntityT* pCEntityTT = new TEntityT; \
	_AS::CEntityManager.Add(pCEntityTT, szName); \
	pCEntityT = pCEntityTT; \
}

/*
	Deletes an entity

	Parameters:
		pCEntityT -> Entity pointer

	Notes:
		- Try to avoid this function, use the entities Remove() function instead
*/
#define ASDeleteEntity(pCEntityT) \
	if (pCEntityT) { \
		_AS::CEntityManager.Remove(pCEntityT); \
		delete pCEntityT; \
		pCEntityT = NULL; \
	}


// Classes
typedef class ASTEntityManager {

	friend _AS;
	friend ASTEntity;
	friend ASTLight;


	public:
		/*
			Constructor
		*/
		AS_API ASTEntityManager();

		/*
			Destructor
		*/
		AS_API ~ASTEntityManager();

		/*
			Adds an entity

			Parameters:
				ASTEntity* pCEntity	-> Pointer to the entity that should be added
				char*	   pszName  -> Entity name

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Add(ASTEntity* pCEntity, const char* pszName = "");

		/*
			Removes an entity

			Parameters:
				ASTEntity* pCEntity	-> Pointer to the entity that should be removed

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Remove(ASTEntity* pCEntity);

		/*
			Unload all entitys

			Parameters:
				bool bProtectedToo -> Should the protected entities be deleted, too?
  
			Notes:
				- Use this function only if you really want to unload all entitys
		*/
		AS_API void Clear(const bool bProtectedToo = false);

		/*
			Draws all visible entities (solid and transparent)

			Notes:
				- You shouldn't use the function if you use transparent stuff, too.
				- Draw solid stuff first, draw the transparent stuff at last
		*/
		AS_API void Draw();

		/*
			Draws all visible and solid entities
		*/
		AS_API void DrawSolid();

		/*
			Draws all visible and transparent entities
		*/
		AS_API void DrawTransparent();

		/*
			Returns the entity with the given name

			Parameters:
				char* pszName -> Entity name

			Returns:
				ASTEntity* -> Pointer to the entity with the given name

			Notes:
				- Its possible that more entities have the same name, in this case
				  the first found entity with this name will be returned
		*/
		AS_API ASTEntity* Get(const char* pszName);

		/*
			Returns the first light entity
			
			Returns:
				ASTLight* -> The first found light entity
		*/
		AS_API ASTLight* FindFirstLight();

		/*
			Returns the next light entity
			
			Returns:
				ASTLight* -> The next found light entity
		*/
		AS_API ASTLight* FindNextLight();


	private:
		ASTLinkedList<ASTEntity*> m_lstEntityList;			// Linked list of all entitys

		ASTLinkedList<ASTLight*>  m_lstLightList;			// Linked list of all lights
		ASTLinkedList<ASTEntity*> m_lstEntityCollisionList;	// Linked list of all entities with collision detection to other entities


		/*
			Initialize the entity manager

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Init();

		/*
			Updates all entity relevant stuff
		*/
		AS_API void Update();


} ASTEntityManager;


#endif // __ASENTITYMANAGER_H__
/*
	File: ASEntityHandler.cpp
*/

#include <ASEngineDll.h>


/*
	Constructor
*/
ASTEntityHandler::ASTEntityHandler()
{
	m_pCEntity = NULL;
}

/*
	Destructor
*/
ASTEntityHandler::~ASTEntityHandler()
{
	Unload();
}

/*
	Loads the entity handler which an enitity
*/
bool ASTEntityHandler::Load(ASTEntity* pCEntity)
{
	Unload();

	// Check poiner
	if (!pCEntity) return true;
	if (pCEntity->AddHander(this)) return true;
	m_pCEntity = pCEntity;

	return false;
}

/*
	Returns whether the entity handler is loaded or not
*/
bool ASTEntityHandler::IsLoaded() const
{
	if (!m_pCEntity) return false;
	else		     return true;
}

/*
	Unloads the entity handler
*/
bool ASTEntityHandler::Unload(const bool bRemoveEntity)
{
	if (!m_pCEntity) return true;

	if (m_pCEntity->RemoveHander(this)) return true;
	if (bRemoveEntity) m_pCEntity->Remove();
	m_pCEntity = NULL;

	return false;
}

/*
	Returns the entity the entity handler is loaded with
*/
ASTEntity* ASTEntityHandler::GetEntity() const
{
	return m_pCEntity;
}
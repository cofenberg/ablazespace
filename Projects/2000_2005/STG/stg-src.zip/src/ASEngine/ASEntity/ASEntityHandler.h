/*
	File: ASEntityHandler.h

	Description: Entity handler
				 You should always use an entity handler if you want to use a pointer to a entity.
				 The entity handler will be informed if the entity is deleted and in this case you
				 are able to avoid accessing a deleted entity! :)
*/


#ifndef __ASENTITYHANDLER_H__
#define __ASENTITYHANDLER_H__


// Classes
typedef class ASTEntityHandler {

	public:
		/*
			Constructor
		*/
		AS_API ASTEntityHandler();

		/*
			Destructor
		*/
		AS_API ~ASTEntityHandler();

		/*
			Loads the entity handler which an enitity

			Parameters:
				ASTEntity* pCEntity	-> Pointer to the entity the entity handler should be loaded with

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Load(ASTEntity* pCEntity);
	
		/*
			Returns whether the entity handler is loaded or not

			Returns:
				bool -> 'true' if the entity handler is loaded else 'false'
		*/
		AS_API bool IsLoaded() const;

		/*
			Unloads the entity handler

			Parameters:
				bool bRemoveEntity -> Should the entity be removed?

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Unload(const bool bRemoveEntity = false);

		/*
			Returns the entity the entity handler is loaded with

			Returns:
				ASTEntity* -> The entity handlers entity

			Notes:
				- You should always check if the handler has an entity before you use it!!
		*/
		AS_API ASTEntity* GetEntity() const;


	private:
		ASTEntity* m_pCEntity;	// The entity handlers entity


} ASTEntityHandler;


#endif // __ASENTITYHANDLER_H__
/*
	File: ASEngine.cpp
*/

#include "ASEngineDll.h"


// Static member variables
ASTMath				_AS::CMath;
ASTTools			_AS::CTools;
ASTCollision		_AS::CCollision;
ASTTextureManager	_AS::CTextureManager;
ASTModelManager		_AS::CModelManager;
ASTEntityManager	_AS::CEntityManager;
ASTFrustum			_AS::CFrustum;
ASTRenderer			_AS::CRenderer;
ASTInput			_AS::CInput;
ASTLanguageManager	_AS::CLanguageManager;
ASTFileSystem		_AS::CFileSystem;
ASTWindowManager	_AS::CWindowManager;
ASTTimer			_AS::CTimer;
ASTConfig			_AS::CConfig;
ASTLog				_AS::CLog;
ASTConsole			_AS::CConsole;
ASTParser			_AS::CParser;
ASTPhysics			_AS::CPhysics;
ASTParticleManager	_AS::CParticleManager;
ASTSoundManager		_AS::CSoundManager;

SYSTEMTIME			_AS::m_SInitTime;
bool				_AS::m_bLeaveMainLoop;
bool				_AS::m_bShutDown;


/*
	Initialize the engine
*/
bool _AS::Init()
{
	if (InitEngine()) {
		DeInit();

		return true;
	} else return false;
}

/*
	Deinitialize the engine
*/
bool _AS::DeInit()
{
	CLog.Output("\n\n");	

	CLog.Output("Shut down AS-Engine");

	// Save the configuration
	CConfig.Save(ASCONFIGFILE);

	// Cleanup the entity manager
	CEntityManager.Clear();	

	// Cleanup the model manager
	CModelManager.Cleanup();	

	// Cleanup the texture manager
	CTextureManager.Cleanup();

	// Cleanup the window manager
	CWindowManager.Clear();

	// De-initialize the sound manager
	CSoundManager.DeInit();

	// De-initialize the renderer
	CRenderer.DeInit();

	// De-initialize the tools
	CTools.DeInit();

	return false;
}

/*
	Update all engine stuff
*/
void _AS::Update()
{
	// Update the log
	CLog.Update();

	// Update the timer
	CTimer.Update();

	// Update file system
	CFileSystem.Update();

	// Update configuration
	CConfig.Update();

	// Update texture manager
	CTextureManager.Update();

	// Update model manager
	CModelManager.Update();

	// Update entity manager
	CEntityManager.Update();

	// Update sound manager
	CSoundManager.Update();

	// Update windows
	CWindowManager.Update();
}

/*
	Engine main loop
*/
void _AS::MainLoop()
{
	MSG Msg;

	while (!IsShutDown() && !m_bLeaveMainLoop) {
		if (PeekMessage(&Msg, NULL, 0, 0, PM_NOREMOVE)) {
        	if (!GetMessage(&Msg, NULL, 0, 0)) break;
        	TranslateMessage(&Msg);
        	DispatchMessage(&Msg);
    	} else Update();
	}
	Update();
	m_bLeaveMainLoop = false;
}

/*
	Leave engine main loop 
*/
void _AS::LeaveMainLoop()
{
	m_bLeaveMainLoop = true;
}

/*
	Shut down the application
*/
void _AS::ShutDown()
{
	m_bShutDown = true;
}

/*
	Returns if the application should be shut down
*/
bool _AS::IsShutDown()
{
	return m_bShutDown;
}

/*
	Preloads data
*/
void _AS::PreloadData(char *pszFilename)
{
	ASTProgressWindow CProgressWindow;
	char szTemp[256], szText[256];
	int i, iNumber;

	if (!pszFilename) pszFilename = CFileSystem.m_szPreloadFile;

	// Is there a preload file?
	if (!CFileSystem.IsFilenameValid(pszFilename)) return;
	_AS::CLog.Output("Preload data '%s'", pszFilename);
	CProgressWindow.Create("Preload data");

	// Get number of textures
	CProgressWindow.SetTask("Load textures");
	for (iNumber = 0; ; iNumber++) {
		sprintf(szTemp, "%d", iNumber);
		if (!GetPrivateProfileString("textures", szTemp, "", szText, 256, pszFilename)) break;
	}

	// Preload textures
	for (i = 0; i < iNumber; i++) {
		sprintf(szTemp, "%d", i);
		if (!GetPrivateProfileString("textures", szTemp, "", szText, 256, pszFilename)) break;
		CProgressWindow.SetSubTask("%s", szText);
		CProgressWindow.SetProgress((int) ((float) i / iNumber * 100));
		CTextureManager.PreLoad(szText);
	}	

	// Get number of models
	CProgressWindow.SetTask("Load models");
	for (iNumber = 0; ; iNumber++) {
		sprintf(szTemp, "%d", iNumber);
		if (!GetPrivateProfileString("models", szTemp, "", szText, 256, pszFilename)) break;
	}

	// Preload models
	for (i = 0; i < iNumber; i++) {
		sprintf(szTemp, "%d", i);
		if (!GetPrivateProfileString("models", szTemp, "", szText, 256, pszFilename)) break;
		CProgressWindow.SetSubTask("%s", szText);
		CProgressWindow.SetProgress((int) ((float) i / iNumber * 100));
		CModelManager.PreLoad(szText);
	}	

	// Get number of sounds
	CProgressWindow.SetTask("Load sounds");
	for (iNumber = 0; ; iNumber++) {
		sprintf(szTemp, "%d", iNumber);
		if (!GetPrivateProfileString("sounds", szTemp, "", szText, 256, pszFilename)) break;
	}

	// Preload sounds
	for (i = 0; i < iNumber; i++) {
		sprintf(szTemp, "%d", i);
		if (!GetPrivateProfileString("sounds", szTemp, "", szText, 256, pszFilename)) break;
		CProgressWindow.SetSubTask("%s", szText);
		CProgressWindow.SetProgress((int) ((float) i / iNumber * 100));
		CSoundManager.PreLoad(szText);
	}

	CProgressWindow.SetTask("Done");
	CProgressWindow.SetSubTask("");
	CProgressWindow.SetProgress(100);
}

/*
	Initialize the engine
*/
bool _AS::InitEngine()
{
	// Get engine initializion time
	GetLocalTime(&m_SInitTime);

	// Setup a high priority
	SetPriorityClass(GetModuleHandle(NULL),  HIGH_PRIORITY_CLASS);
	SetThreadPriority(GetModuleHandle(NULL), THREAD_PRIORITY_HIGHEST);

	// Initalize the random generator
	srand((unsigned) GetTickCount());

	// Initialize the file system
	CFileSystem.Init();

	// Initialize the log
	CLog.Init();
	CLog.Output("Application start time: Date: %d.%d.%d - Time: %d:%d:%d:%d", m_SInitTime.wMonth,  m_SInitTime.wDay, m_SInitTime.wYear, 
																			  m_SInitTime.wHour,   m_SInitTime.wMinute, 
																			  m_SInitTime.wSecond, m_SInitTime.wMilliseconds);
	// Initialize the tools
	CTools.Init();

	// Initialize the math system
	CMath.Init();

	// Initialize the configuration
	CConfig.Init();

	// Enumerate all available languages
	if (!CLanguageManager.GenerateLanguageList()) return true; // There was a heavy error!
		
	// Load engine texts
	CText.Load(ASLANGUAGETEXTFILE);

	// Is this the first program start?
	if (_AS::CConfig.IsFirstRun()) {
		CLog.Output("First application start detected");
		MessageBox(NULL, CText.Get(_T_FirstApplicationStart), ASENGINE, MB_OK | MB_ICONINFORMATION);
	}

	// Is an error detected? (from the last run)
	if (_AS::CConfig.IsLastCrashed()) {
		CLog.Output("Application wasn't shut down correctly at the last time");
		MessageBox(NULL, CText.Get(_T_ApplicationWasNotSutDownCorrectlyAtLastTime), ASENGINE, MB_OK | MB_ICONINFORMATION);
	}

	// Initialize the sound manager
	if (CSoundManager.Init()) return true; // There was a heavy error!

	// Initialize the renderer
	if (CRenderer.Init()) return true; // There was a heavy error!

	// Get main window
	ASTWindow* pCWindow = CWindowManager.GetMainWindow();
	if (!pCWindow) return true; // There was a heavy error!

	// Minimize main window
	SetWindowPos(pCWindow->GetWnd(), HWND_NOTOPMOST, 0, 0, 150, 20, 0);

	// Should the configuration dialog be shown?
	if (_AS::CConfig.IsFirstRun() || _AS::CConfig.IsLastCrashed()) 
		_AS::CConfig.OpenDialog(pCWindow->GetWnd());

	// Initialize the texture manager
	if (CTextureManager.Init()) return true; // There was a heavy error!

	// Initialize the model manager
	if (CModelManager.Init()) return true; // There was a heavy error!

	// Preload data
	PreloadData();

	// Now the window should get into its right mode
	SetWindowPos(pCWindow->GetWnd(), HWND_NOTOPMOST, 0, 0, _AS::CConfig.GetDisplayWidth(), _AS::CConfig.GetDisplayHeight(), 0);
	CRenderer.Restart();

	// Reset the timer
	CTimer.Reset();

	CLog.Output("\n\n");	

	return false;
}
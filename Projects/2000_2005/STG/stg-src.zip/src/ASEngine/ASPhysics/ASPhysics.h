/*
	File: ASPhysics.h

	Description: Physics code
*/


#ifndef __ASPHYSICS_H__
#define __ASPHYSICS_H__


// Classes
typedef class ASTPhysics {

	public:
		/*
			Constructor
		*/
		AS_API ASTPhysics();

		/*
			Destructor
		*/
		AS_API ~ASTPhysics();

		/*
			Sets the standard gravitation vector
		*/
		AS_API void SetStandardGravity();

		/*
			Sets the gravitation vector

			Parameters:
				ASTVector3D& vGravity -> Gravitation vector
		*/
		AS_API void SetGravity(const ASTVector3D& vGravity);

		/*
			Returns the gravitation vector

			Returns:
				ASTVector3D -> Gravitation vector
		*/
		AS_API ASTVector3D GetGravity() const;

		/*
			Sets the standard friction vector
		*/
		AS_API void SetStandardFriction();

		/*
			Sets the friction vector

			Parameters:
				ASTVector3D& vFriction -> Friction vector
		*/
		AS_API void SetFriction(const ASTVector3D& vFriction);

		/*
			Returns the friction vector

			Returns:
				ASTVector3D -> Friction vector
		*/
		AS_API ASTVector3D GetFriction() const;


	private:
		ASTVector3D m_vGravity;  // Gravitation vector
		ASTVector3D m_vFriction; // Friction vector



} ASTPhysics;


#endif // __ASPHYSICS_H__
/*
	File: ASPhysics.cpp
*/

#include <ASEngineDll.h>


/*
	Constructor
*/
ASTPhysics::ASTPhysics()
{
	SetStandardGravity();
	SetStandardFriction();
}

/*
	Destructor
*/
ASTPhysics::~ASTPhysics()
{
}

/*
	Sets the standard gravitation vector
*/
void ASTPhysics::SetStandardGravity()
{
	m_vGravity.fX = 0.f;
	m_vGravity.fY = 0.f;
	m_vGravity.fZ = 9.81f;
}

/*
	Sets the gravitation vector
*/
void ASTPhysics::SetGravity(const ASTVector3D& vGravity)
{
	m_vGravity = vGravity;
}

/*
	Returns the gravitation vector
*/
ASTVector3D ASTPhysics::GetGravity() const
{
	return m_vGravity;
}

/*
	Sets the standard friction vector
*/
void ASTPhysics::SetStandardFriction()
{
	m_vFriction = 1.f;
}

/*
	Sets the friction vector
*/
void ASTPhysics::SetFriction(const ASTVector3D& vFriction)
{
	m_vFriction = vFriction;
}

/*
	Returns the friction vector
*/
ASTVector3D ASTPhysics::GetFriction() const
{
	return m_vFriction;
}
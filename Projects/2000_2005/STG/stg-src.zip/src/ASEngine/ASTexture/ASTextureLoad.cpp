/*
	File: ASTextureLoad.cpp
*/

#include <ASEngineDll.h>
#include <jpeglib.h>


/*
	Loads a bmp texture
*/
bool ASTTexture::LoadBmp()
{
	AUX_RGBImageRec *pImage;

	if (!(pImage = auxDIBImageLoad(m_szFilename))) return true;

	// Get texture dimension
	m_iOrginalWidth  = m_iWidth  = pImage->sizeX;
	m_iOrginalHeight = m_iHeight = pImage->sizeY;

	// Get the texture type
	if (m_iHeight == 1) m_iTextureType = GL_TEXTURE_1D;
	else				m_iTextureType = GL_TEXTURE_2D;

	// Setup texture information
	m_iType				= GL_UNSIGNED_BYTE;
	m_iFormat			= GL_RGB;
	m_iImageBits		= 24;
	m_szColorComponents = 3;

	// Get the texture data
	m_pszData = pImage->data;

	// Go sure that the texture dimension is correct
	IsDimensionCorrect(true, true);

	return false;
}

/*
	Loads a ppm texture
*/
bool ASTTexture::LoadPpm()
{
	FILE *pFile;
	int iX, iY;
	
	if (!(pFile = fopen(m_szFilename, "rb"))) return true;
	
	// Get the PPM bitmap size
	fscanf(pFile, "P6\n%d %d\n255\n", &m_iWidth, &m_iHeight);
	m_iOrginalWidth  = m_iWidth;
	m_iOrginalHeight = m_iHeight;

	m_iType				= GL_UNSIGNED_BYTE;
	m_iFormat			= GL_RGB;
	m_iImageBits		= 16;
	m_szColorComponents = 3;

	// Get the texture type
	if (m_iHeight == 1) m_iTextureType = GL_TEXTURE_1D;
	else				m_iTextureType = GL_TEXTURE_2D;

	// Get memory
	if (!(m_pszData = new unsigned char[m_iWidth * m_iHeight * m_szColorComponents])) {
		fclose(pFile);

		return true;
	}

	// Now load the bitmap
	for (iY = 0; iY < m_iHeight; iY++) {
		for (iX = 0; iX < m_iWidth; iX++) {
			m_pszData[(iY * m_iWidth + iX) * m_szColorComponents]	  = fgetc(pFile);
			m_pszData[(iY * m_iWidth + iX) * m_szColorComponents + 1] = fgetc(pFile);
			m_pszData[(iY * m_iWidth + iX) * m_szColorComponents + 2] = fgetc(pFile);
		}
	}

	fclose(pFile);

	// Go sure that the texture dimension is correct
	IsDimensionCorrect(true, true);

	return false;
}

/*
	Loads a tex texture
*/
bool ASTTexture::LoadTex()
{
	FILE* pFile;
	BYTE  Header[19];
	DWORD dwSize;

	// Open file
	if (!(pFile = fopen(m_szFilename, "rb"))) return true;

	// Get file size
	fseek(pFile, 0, SEEK_END);
	dwSize = ftell(pFile) - 19;
	fseek(pFile, 0, SEEK_SET);

	//read file
	m_pszData = new unsigned char[dwSize];
	fread(&Header, 19, 1, pFile);
	fread(m_pszData, dwSize, 1, pFile);

	// Close file
	fclose(pFile);

	// Get texture info
	m_iOrginalWidth  = m_iWidth  = ((WORD*) Header)[0];
	m_iOrginalHeight = m_iHeight = ((WORD*) Header)[1];

	m_iType				= GL_UNSIGNED_BYTE;
	m_iFormat			= GL_RGB;
	m_iImageBits		= 16;
	m_szColorComponents = 3;

	return false;
}

/*
	Loads a pcx file
*/
bool ASTTexture::LoadPcx()
{
	int iX1, iX2, iY1, iY2, iRep, iOff = 0, i;
	unsigned char* pszPal, *pszPalT, *pszTemp, *pszDataT, c;
	FILE* pFile;

    if (!(pFile = fopen(m_szFilename, "r+bt"))) return true;

	if (fgetc(pFile) != 0x0A) {
		fclose(pFile);

		return true;
	}

	if (fgetc(pFile) != 5) {
		fclose(pFile);

		return true;
	}

	c = (unsigned char) fgetc(pFile);
	c = (unsigned char) fgetc(pFile);

	// Get dimensions
	iX1  = fgetc(pFile);
	iX1 |= fgetc(pFile) << 8;
	iY1  = fgetc(pFile);
	iY1 |= fgetc(pFile) << 8;
	iX2  = fgetc(pFile);
	iX2 |= fgetc(pFile) << 8;
	iY2  = fgetc(pFile);
	iY2 |= fgetc(pFile) << 8;
	m_iOrginalWidth  = m_iWidth  = iX2 - iX1 + 1;
	m_iOrginalHeight = m_iHeight = iY2 - iY1 + 1;

	m_iType				= GL_UNSIGNED_BYTE;
	m_iFormat			= GL_RGB;
	m_iImageBits		= 24;
	m_szColorComponents = 3;

	// Get the texture type
	if (m_iHeight == 1) m_iTextureType = GL_TEXTURE_1D;
	else				m_iTextureType = GL_TEXTURE_2D;

	// Go get the palette
	fseek(pFile, -769L, SEEK_END);

	// Check palette bit and read it in
	if (fgetc(pFile) != 0xC) {
		fclose(pFile);

		return true;
	}
	pszPal = new unsigned char[768];
	for (pszPalT = pszPal; pszPalT < pszPal + 768; pszPalT++)
		*pszPalT = (unsigned char) getc(pFile);

	// Go to encoded data
	fseek(pFile, 128L, SEEK_SET);

	// Alloc temp space for holding decoded data
	if (!(pszTemp = new unsigned char [m_iWidth * m_iHeight])) {
		fclose(pFile);

		return true;
	}

	// Decode
	while (iOff < (m_iWidth * m_iHeight)) {
		c = (unsigned char) fgetc(pFile);
		if (c == EOF) {
			fclose(pFile);
			delete pszTemp;
			delete pszPal;

			return true;
		}

		if ((c & 0xC0) == 0xC0) {
			iRep = c & 0x3f;
			c = (unsigned char) fgetc(pFile);
			if (c == EOF) {
				fclose(pFile);
				delete pszTemp;
				delete pszPal;

				return true;
			}

			for (int i = 0; i < iRep; i++)
				pszTemp[iOff++] = c;
		} else pszTemp[iOff++] = c;
	}

	// Get memory
	if (!(pszDataT = new unsigned char[m_iWidth * m_iHeight * m_szColorComponents])) {
		fclose(pFile);

		return true;
	}

	// Do conversion now
	for(i = 0; i < m_iWidth * m_iHeight; i++) {
		pszDataT[i * 3]     = pszPal[pszTemp[i] * 3];		// Red
		pszDataT[i * 3 + 1] = pszPal[pszTemp[i] * 3 + 1];	// Green
		pszDataT[i * 3 + 2] = pszPal[pszTemp[i] * 3 + 2];	// Blue
	}

	// Flip texture data
	if (!(m_pszData = new unsigned char[m_iWidth * m_iHeight * m_szColorComponents])) return true;
	for (i = 0; i < m_iHeight; i++)
		memcpy(&m_pszData[m_szColorComponents * i * m_iWidth],
			   &pszDataT[m_szColorComponents * (m_iHeight - i - 1) * m_iWidth],
			   m_szColorComponents * m_iWidth);
	delete pszDataT;

	fclose(pFile);
	delete pszTemp;
	delete pszPal;

	// Go sure that the texture dimension is correct
	IsDimensionCorrect(true, true);

    return false;
}

/*
	Loads a targa file
*/
bool ASTTexture::LoadTga()
{
	int i, j, iSize, iBread, iCurrentPixel = 0;
    unsigned char szType[4], szInfo[7];
	unsigned char szTemp, szTemp2, szBuffer[1000];
    FILE *pFile;

    if (!(pFile = fopen(m_szFilename, "r+bt"))) return true;
        
    fread(&szType, sizeof(char), 3, pFile); // Read in colormap info and image type, byte 0 ignored
    fseek(pFile, 12, SEEK_SET);				// Seek past the header and useless info
    fread(&szInfo, sizeof(char), 6, pFile);

    if (szType[1] != 0 || (szType[2] != 2 && szType[2] != 3 && szType[2] != 10)) {
		_AS::CLog.Output("Wrong TGA type!");
		fclose(pFile);

        return true;
	}
	
    m_iOrginalWidth  = m_iWidth  = szInfo[0] + szInfo[1] * 256; 
    m_iOrginalHeight = m_iHeight = szInfo[2] + szInfo[3] * 256;

	// Get the texture type
	if (m_iHeight == 1) m_iTextureType = GL_TEXTURE_1D;
	else				m_iTextureType = GL_TEXTURE_2D;

	m_iType		 = GL_UNSIGNED_BYTE;
    m_iImageBits = szInfo[4];
    iSize	     = m_iWidth * m_iHeight;

    // Make sure we are loading a supported type
    if(m_iImageBits != 32 && m_iImageBits != 24 && m_iImageBits != 8) {
		_AS::CLog.Output("Unsupported color depth!");
		fclose(pFile);

		return true;
	}
	m_szColorComponents = (char) m_iImageBits / 8;

	// Check alpha depth
    if (!(!(szInfo[5] & 15) || (szInfo[5] & 15) == 8)) {
		_AS::CLog.Output("Unsupported alpha depth!");
		fclose(pFile);

		return true;
	}
	
	// Get memory
	if (!(m_pszData = new unsigned char[iSize * m_szColorComponents])) {
		fclose(pFile);

		return true;
	}

	if (szType[2] == 10) { // Compressed
        while (iCurrentPixel < m_iWidth * m_iHeight -1) {
			fread(&szTemp, sizeof(unsigned char), 1, pFile); 
            if ((szTemp & 128) == 128) { // This is an rle packet
                szTemp2 = (unsigned char) ((szTemp & 127) + 1); // How many pixels are encoded using this packet
				fread(szBuffer, sizeof(unsigned char) * m_szColorComponents, 1, pFile); 
                for (i = iCurrentPixel; i < iCurrentPixel + szTemp2; i++)
                    for (j = 0; j < m_szColorComponents; j++)
                        m_pszData[i * m_szColorComponents + j] = szBuffer[j];
                iCurrentPixel += szTemp2;
            } else { // This is a raw packet
                szTemp2 = (unsigned char) ((szTemp & 127) + 1);
				fread(szBuffer, sizeof(unsigned char) * m_szColorComponents * szTemp2, 1, pFile); 
                for (i = iCurrentPixel; i < iCurrentPixel + szTemp2; i++)
                    for (j = 0; j < m_szColorComponents; j++)
                        m_pszData[i * m_szColorComponents + j] =  szBuffer[(i - iCurrentPixel) * m_szColorComponents + j];
                iCurrentPixel += szTemp2;
            }
        }
	} else { // Uncompressed
		// Get texture data
		iBread = fread(m_pszData, sizeof(char), iSize * m_szColorComponents, pFile); 

		// TGA is stored in BGR:
		if (iBread != iSize * m_szColorComponents) {
			_AS::CLog.Output("TGA is stored in BGRA, that's not supported!");
			if (m_pszData) delete m_pszData;
			fclose(pFile);

			return true;
		}
	}

	if (m_iImageBits == 32 || m_iImageBits == 24) {
		for (i = 0; i < iSize * m_szColorComponents; i += m_szColorComponents) {
			szTemp = m_pszData[i];
			m_pszData[i    ] = m_pszData[i + 2];
			m_pszData[i + 2] = szTemp;
		}
	}

	// Get texture format
    switch (m_iImageBits) {
		case 32: m_iFormat = GL_RGBA; break;
		case 24: m_iFormat = GL_RGB; break;
		case  8: m_iFormat = GL_LUMINANCE; break;
	}

    fclose(pFile);
    
	// Go sure that the texture dimension is correct
	IsDimensionCorrect(true, true);

	return false;
}

/*
	Loads an jpg texture
*/
bool ASTTexture::LoadJpg()
{
	jpeg_decompress_struct jpgInfo;
	tImageJPG*			   pJpgImage = NULL;
	FILE*				   pFile;

	// Open a file pointer to the jpeg file and check if it was found and opened 
	if (!(pFile = fopen(m_szFilename, "rb"))) return true;

	// Create an error handler
	jpeg_error_mgr jerr;

	// Have our compression info object point to the error handler address
	jpgInfo.err = jpeg_std_error(&jerr);

	// Initialize the decompression object
	jpeg_create_decompress(&jpgInfo);

	// Specify the data source (Our file pointer)	
	jpeg_stdio_src(&jpgInfo, pFile);

	// Allocate the structure that will hold our eventual jpeg data (must free it!)
	pJpgImage = (tImageJPG*) malloc(sizeof(tImageJPG));

	// Decode the jpeg file and fill in the image data structure to pass back
	{
		// Read in the header of the jpeg file
		jpeg_read_header(&jpgInfo, TRUE);
		
		// Start to decompress the jpeg file with our compression info
		jpeg_start_decompress(&jpgInfo);

		// Get the image dimensions and row span to read in the pixel data
		pJpgImage->rowSpan = jpgInfo.image_width * jpgInfo.num_components;
		pJpgImage->sizeX   = jpgInfo.image_width;
		pJpgImage->sizeY   = jpgInfo.image_height;
		
		// Allocate memory for the pixel buffer
		pJpgImage->data = new unsigned char[pJpgImage->rowSpan * pJpgImage->sizeY];
			
		// Here we use the library's state variable cinfo.output_scanline as the
		// loop counter, so that we don't have to keep track ourselves.
		
		// Create an array of row pointers
		unsigned char** rowPtr = new unsigned char*[pJpgImage->sizeY];
		for (int i = 0; i < pJpgImage->sizeY; i++)
			rowPtr[i] = &(pJpgImage->data[i*pJpgImage->rowSpan]);

		// Now comes the juice of our work, here we extract all the pixel data
		int rowsRead = 0;
		while (jpgInfo.output_scanline < jpgInfo.output_height) 
		{
			// Read in the current row of pixels and increase the rowsRead count
			rowsRead += jpeg_read_scanlines(&jpgInfo, &rowPtr[rowsRead], jpgInfo.output_height - rowsRead);
		}
		
		// Delete the temporary row pointers
		delete [] rowPtr;

		// Finish decompressing the data
		jpeg_finish_decompress(&jpgInfo);
	}

	// This releases all the stored memory for reading and decoding the jpeg
	jpeg_destroy_decompress(&jpgInfo);

	// Close the file pointer that opened the file
	fclose(pFile);

	// Get texture dimension
	m_iOrginalWidth =  m_iWidth  = pJpgImage->sizeX;
	m_iOrginalHeight = m_iHeight = pJpgImage->sizeY;

	// Get the texture type
	if (m_iHeight == 1) m_iTextureType = GL_TEXTURE_1D;
	else				m_iTextureType = GL_TEXTURE_2D;

	// Check if the texture could be loaded
	if (!m_iWidth) return true;

	// Setup texture information
	m_iType				= GL_UNSIGNED_BYTE;
	m_iFormat			= GL_RGB;
	m_iImageBits		= 24;
	m_szColorComponents = 3;

	unsigned char* pszData = pJpgImage->data;

	// Get memory
	if (!(m_pszData = new unsigned char[m_iWidth * m_iHeight * m_szColorComponents])) return true;

	// Flip texture data
	for (int i = 0; i < m_iHeight; i++)
		memcpy(&m_pszData[m_szColorComponents * i * m_iWidth],
			   &pszData[m_szColorComponents * (m_iHeight - i - 1) * m_iWidth],
			   m_szColorComponents * m_iWidth);

	// Cleanup
	delete pszData;
	delete pJpgImage;

	return false;
}
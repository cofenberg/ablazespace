/*
	File: ASTextureManager.cpp
*/

#include <ASEngineDll.h>


/*
	Constructor
*/
ASTTextureManager::ASTTextureManager()
{
}

/*
	Destructor
*/
ASTTextureManager::~ASTTextureManager()
{
	Cleanup();
}

/*
	Returns if unused textures should be removed automatically
*/
bool ASTTextureManager::GetUnloadUnusedTextures() const
{
	return m_bUnloadUnusedTextures;
}

/*
	Sets if unused textures should be removed automatically
*/
void ASTTextureManager::SetUnloadUnusedTextures(const bool bUnloadUnusedTextures)
{
	m_bUnloadUnusedTextures = bUnloadUnusedTextures;
}

/*
	Unload all unused textures
*/
void ASTTextureManager::UnloadUnusedTextures()
{
	ASTLinkedListElement<ASTTexture*>* pSListElement;
	ASTTexture* pCTextureT;

	// Find the texture
	pSListElement = m_lstTextureList.FindFirst();
	while (pSListElement) {
		if (!pSListElement->Data->IsProtected() &&
			!pSListElement->Data->m_lstHandler.GetElements()) {
			pCTextureT = pSListElement->Data;
			m_lstTextureList.Remove(pCTextureT);
			delete pCTextureT;
		}
		pSListElement = m_lstTextureList.FindNext();
	}
}

/*
	Returns a pointer to the texture with the given ID
*/
ASTTexture* ASTTextureManager::GetTexture(const int iTextureID)
{
	if (iTextureID < 0 || iTextureID > m_lstTextureList.GetElements()) return NULL;
	else return m_lstTextureList[iTextureID];
}

/*
	Returns a pointer to the texture with the given filename
*/
ASTTexture* ASTTextureManager::GetTexture(const char* pszFilename)
{
	ASTLinkedListElement<ASTTexture*>* pSListElement;
	char szFilename[256];

	GetValidFilename(pszFilename, &szFilename[0]);
	pSListElement = m_lstTextureList.FindFirst();
	while (pSListElement) {
		if (!stricmp(pSListElement->Data->GetFilename(), szFilename)) return pSListElement->Data;
		pSListElement = m_lstTextureList.FindNext();
	}

	return NULL;
}

/*
	Returns a pointer to the standard texture
*/
ASTTexture* ASTTextureManager::GetStandardTexture()
{
	return m_CStandardTexture.GetTexture();
}

/*
	Returns a pointer to the cel shading texture
*/
ASTTexture* ASTTextureManager::GetCelShadingTexture()
{
	return m_CCelShadingTexture.GetTexture();
}

/*
	Unload all textures
*/
void ASTTextureManager::Clear()
{
	ASTLinkedListElement<ASTTexture*>* pSListElement;
	ASTTexture* pCTextureT;

	// Remove all textures
	pSListElement = m_lstTextureList.FindFirst();
	while (pSListElement) {
		if (!pSListElement->Data->IsProtected()) {
			pCTextureT = pSListElement->Data;
			m_lstTextureList.Remove(pCTextureT);
			delete pCTextureT;
		}
		pSListElement = m_lstTextureList.FindNext();
	}
}

/*
	Pre-loads a texture with the given filename
*/
bool ASTTextureManager::PreLoad(const char* pszFilename)
{
	return Load(NULL, pszFilename);
}

/*
	Reloads all textures

	Returns:
		bool -> 'false' if all went fine else 'true'
*/
bool ASTTextureManager::ReloadTextures()
{
	ASTLinkedListElement<ASTTexture*>* pSListElement;
	ASTProgressWindow CProgressWindow;
	bool bError = false;
	int i = 0;

	CProgressWindow.Create("Reload textures");
	pSListElement = m_lstTextureList.FindFirst();
	while (pSListElement) {
		if (pSListElement->Data) {
			CProgressWindow.SetTask("Texture: %s", pSListElement->Data->GetFilename());
			CProgressWindow.SetProgress((int) ((float) i / m_lstTextureList.GetElements() * 100));
			if (pSListElement->Data->Reload()) bError = true;
		}
		pSListElement = m_lstTextureList.FindNext();
		i++;
	}

	return bError;
}

/*
	Rebuilds all OpenGL textures
*/
bool ASTTextureManager::RebuildOpenGLTextures()
{
	bool bError = DeleteOpenGLTextures();
	if (GenerateOpenGLTextures()) bError = true;

	return bError;
}

/*
	Gets the valid texture filename
*/
void ASTTextureManager::GetValidFilename(const char* pszFilename, char* pszValidFilename) const
{
	if (!pszFilename) {
		sprintf(pszValidFilename, "%s\\"ASSTANDARDTEXTURE, _AS::CFileSystem.GetTexturesDirectory());
		_AS::CFileSystem.GetFullFilename(pszValidFilename);
	} else {
		// Check if this texture could be loaded
		strcpy(pszValidFilename, pszFilename);
		_AS::CFileSystem.GetFullFilename(pszValidFilename);
		if (!_AS::CFileSystem.IsFilenameValid(pszValidFilename)) { // The file wasn't found!
			// Try to use the standard texture directory
			sprintf(pszValidFilename, "%s\\%s", _AS::CFileSystem.GetTexturesDirectory(), pszFilename);
			_AS::CFileSystem.GetFullFilename(pszValidFilename);
		}
	}
}

/*
	Initialize the texture manager
*/
bool ASTTextureManager::Init()
{
	bool bError;
	
	// Load the standard texture
	_AS::CLog.Output("Initialize texture manager");
	
	if (!(bError = m_CStandardTexture.Load()))
		m_CStandardTexture.GetTexture()->m_bProtected = true;

	// Load the comic style cel shading texture
	if (_AS::CConfig.IsComicStyle()) {
		if (!(bError = m_CCelShadingTexture.Load("celshading.bmp", false, false, false, false)))
			m_CCelShadingTexture.GetTexture()->m_bProtected = true;
	}

	return bError;
}

/*
	Loads a texture with the given filename
*/
bool ASTTextureManager::Load(ASTTextureHandler* pCTextureHandler, const char* pszFilename, const bool bAllowMipmaps,
							 const bool bAllowFiltering, const bool bAllowCompression,
							 const bool bAllowResize)
{
	ASTLinkedListElement<ASTTexture*>* pSListElement;
	ASTTexture* pCTextureT;
	char szFilename[256];

	// Get valid filename
	GetValidFilename(pszFilename, szFilename);

	// First check if the texture is already loaded
	pSListElement = m_lstTextureList.FindFirst();
	while (pSListElement) {
		pCTextureT = pSListElement->Data;
		if (!stricmp(pCTextureT->GetFilename(), szFilename)) { // The texture is already loaded
			if (pCTextureHandler)
				pCTextureT->Load(pCTextureHandler, pszFilename, bAllowMipmaps, bAllowFiltering,
								 bAllowCompression, bAllowResize);

			return false;
		}
		pSListElement = m_lstTextureList.FindNext();
	}

	// Load the new texture
	pCTextureT = new ASTTexture;
	if (pCTextureT->Load(pCTextureHandler, pszFilename, bAllowMipmaps, bAllowFiltering,
						 bAllowCompression, bAllowResize) == -1) { // The texture couldn't be loaded!
		if (pCTextureT) delete pCTextureT;
		if (!pCTextureHandler) return true;
		if (m_CStandardTexture.IsLoaded()) return pCTextureHandler->Load();
		else							   return true;
	}

	// Add the new texture to the managers texture list
	m_lstTextureList.Add(pCTextureT);

	return false;
}

/*
	Unloads a texture
*/
bool ASTTextureManager::Unload(ASTTextureHandler* pCTextureHandler)
{
	ASTLinkedListElement<ASTTexture*>* pSListElement;
	ASTTexture* pCTextureT;
	int i;

	if (!pCTextureHandler) return true;

	// Find the texture
	pSListElement = m_lstTextureList.FindFirst();
	while (pSListElement) {
		i = pSListElement->Data->Unload(pCTextureHandler);
		if (i >= 0) return false;
		if (i == -2) { // Should the unused texture be removed?
			pCTextureT = pSListElement->Data;
			m_lstTextureList.Remove(pCTextureT);
			delete pCTextureT;

			return false;
		}
		pSListElement = m_lstTextureList.FindNext();
	}

	return false;
}

/*
	Unloads a texture
*/
bool ASTTextureManager::Unload(ASTTexture* pCTexture)
{
	if (pCTexture->IsProtected() || m_lstTextureList.IsElement(pCTexture) < 0) return true;

	m_lstTextureList.Remove(pCTexture);
	delete pCTexture;

	return false;
}

/*
	Unload all textures
*/
void ASTTextureManager::Cleanup()
{
	ASTLinkedListElement<ASTTexture*>* pSListElement;
	ASTTexture* pCTextureT;

	_AS::CLog.Output("Cleanup texture manager");

	// Remove all textures
	pSListElement = m_lstTextureList.FindFirst();
	while (pSListElement) {
		pCTextureT = pSListElement->Data;
		m_lstTextureList.Remove(pCTextureT);
		if (pCTextureT) delete pCTextureT;
		pSListElement = m_lstTextureList.FindNext();
	}
	m_lstTextureList.Clear();
}

/*
	Generates all OpenGL textures
*/
bool ASTTextureManager::GenerateOpenGLTextures()
{
	ASTLinkedListElement<ASTTexture*>* pSListElement;
	bool bError = false;

	pSListElement = m_lstTextureList.FindFirst();
	while (pSListElement) {
		if (pSListElement->Data->GenerateOpenGLTexture()) bError = true;		
		pSListElement = m_lstTextureList.FindNext();
	}

	return bError;
}

/*
	Deletes all OpenGL textures
*/
bool ASTTextureManager::DeleteOpenGLTextures()
{
	ASTLinkedListElement<ASTTexture*>* pSListElement;
	bool bError = false;

	pSListElement = m_lstTextureList.FindFirst();
	while (pSListElement) {
		if (pSListElement->Data->DeleteOpenGLTexture()) bError = true;		
		pSListElement = m_lstTextureList.FindNext();
	}

	return bError;
}

/*
	Updates all texture stuff
*/
void ASTTextureManager::Update()
{
	// Check if the texture manager dialog should be opened (Strg-t)
	if (_AS::CConfig.IsDebugMode() && _AS::CInput.IsKeyPressed(29) && 
		_AS::CInput.IsKeyHit(DIK_T))
		OpenDialog(_AS::CWindowManager.GetMainWindow()->GetWnd());
}
/*
	File: ASTextureManagerDialog.cpp
*/

#include <ASEngineDll.h>
#include "..\resource.h"


// Variables
HWND hWndTextureDialog;
ASTRendererHandler CTexturePreviewRendererHandler;
ASTTexture* pCSelectedTexture;
ASTTextureHandler* pCTextureHandler;
ASFLOAT3 fTextureViewPos;


/*
	Opens the texture manager dialog
*/
bool ASTTextureManager::OpenDialog(const HWND hWnd)
{
	bool bError = false;

	if (hWndTextureDialog) return true;

	// Minimize the window
	if (hWnd) SendMessage(hWnd, WM_SYSCOMMAND, SC_MINIMIZE, 0);

	if(DialogBox(GetModuleHandle(ASMODULENAME), MAKEINTRESOURCE(IDD_TEXTUREMANAGER), hWnd, (DLGPROC) DialogProc) == -1)
		bError = true;
	
	// Normalize the window
	if (hWnd) SendMessage(hWnd, WM_SIZE, SIZE_RESTORED, 0);

	return bError;
}

/*
	Texture manager dialog procedure
*/
LRESULT CALLBACK ASTTextureManager::DialogProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	return _AS::CTextureManager.Proc(hWnd, iMessage, wParam, lParam);
}

LRESULT ASTTextureManager::Proc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	ASTLinkedListElement<ASTTexture*>* pSListElement;
	static POINT MousePos, OldMousePos;
    char *pszTemp, szTemp[256];
	ASTTexture* pCTexture;
	ASFLOAT2 fSize;
	RECT Rect;
	int i;

	switch (iMessage) {
        case WM_INITDIALOG:
			_AS::CLog.Output("Open texture manager dialog");
			hWndTextureDialog = hWnd;

			// Init renderer handler
			CTexturePreviewRendererHandler.Init(GetDlgItem(hWnd, ID_TEXTUREMANAGER_VIEW), false);

			// Texts
			SetWindowText( hWnd,								   CText.Get(_T_TextureManager));
			SetDlgItemText(hWnd, IDC_TEXTUREMANAGER_OK,			   CText.Get(_T_Ok));
			SetDlgItemText(hWnd, IDC_TEXTUREMANAGER_LOAD,		   CText.Get(_T_Load));
			SetDlgItemText(hWnd, IDC_TEXTUREMANAGER_UNLOAD,		   CText.Get(_T_Unload));
			SetDlgItemText(hWnd, IDC_TEXTUREMANAGER_UNLOAD_UNUSED, CText.Get(_T_UnloadUnused));
			SetDlgItemText(hWnd, IDC_TEXTUREMANAGER_UPDATE,        CText.Get(_T_Update));
			SetDlgItemText(hWnd, IDC_TEXTUREMANAGER_RESET_VIEW,    CText.Get(_T_Reset));

			// Setup data
			SetTimer(hWnd, 1, 1, NULL);
			fTextureViewPos[X] = fTextureViewPos[Y] = 0.f;
			fTextureViewPos[Z] = -5.f;
			pCSelectedTexture = NULL;
			pCTextureHandler = new ASTTextureHandler;

		Init:
			if (!pCTextureHandler) break;
			if (pCSelectedTexture) {
				EnableWindow(GetDlgItem(hWnd, IDC_TEXTUREMANAGER_UNLOAD), !pCSelectedTexture->m_bProtected);
				pCTextureHandler->Load(pCSelectedTexture->m_szFilename);
			}
			else EnableWindow(GetDlgItem(hWnd, IDC_TEXTUREMANAGER_UNLOAD), false);
			EnableWindow(GetDlgItem(hWnd, IDC_TEXTUREMANAGER_UNLOAD_UNUSED), !GetUnloadUnusedTextures());

			// Setup the texture list
			SendDlgItemMessage(hWnd, ID_TEXTUREMANAGER_LIST, LB_RESETCONTENT , 0, 0L);
			pSListElement = m_lstTextureList.FindFirst();
			i = 0;
			while (pSListElement) {
				sprintf(szTemp, "%s (%s: %d)", pSListElement->Data->m_szFilename,
											   CText.Get(_T_Used),
											   pSListElement->Data->m_lstHandler.GetElements());
				SendDlgItemMessage(hWnd, ID_TEXTUREMANAGER_LIST, LB_ADDSTRING, 0, (LPARAM) szTemp);
				if (pSListElement->Data == pCSelectedTexture)
					SendDlgItemMessage(hWnd, ID_TEXTUREMANAGER_LIST, LB_SETCURSEL, i, 0L);
				pSListElement = m_lstTextureList.FindNext();
				i++;
			}

			BringWindowToTop(hWnd);
			UpdateWindow(hWnd);
			return true;

		case WM_TIMER:
			if (_AS::CRenderer.SetRenderingDevice(&CTexturePreviewRendererHandler)) break;

			glDisable(GL_CULL_FACE);
			glDisable(GL_LIGHTING);
			glDisable(GL_FOG);
			glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

			if (pCSelectedTexture) {
				glLoadIdentity();
				glTranslatef(fTextureViewPos[X], fTextureViewPos[Y], fTextureViewPos[Z]);
				pCTextureHandler->GetTexture()->BindOpenGLTexture();
				fSize[X] = (float) pCTextureHandler->GetTexture()->m_iWidth / 256;
				fSize[Y] = (float) pCTextureHandler->GetTexture()->m_iHeight / 256;
				switch (pCTextureHandler->GetTexture()->m_iTextureType) {
					case GL_TEXTURE_1D:
						glDisable(GL_TEXTURE_2D);
						glEnable(GL_TEXTURE_1D);
						glBegin(GL_QUADS);
							glTexCoord1f(0.f); glVertex3f(-fSize[X],  fSize[Y],  1.f);
							glTexCoord1f(1.f); glVertex3f( fSize[X],  fSize[Y],  1.f);
							glTexCoord1f(1.f); glVertex3f( fSize[X], -fSize[Y],  1.f);
							glTexCoord1f(0.f); glVertex3f(-fSize[X], -fSize[Y],  1.f);
						glEnd();
						break;

					case GL_TEXTURE_2D:
						glDisable(GL_TEXTURE_1D);
						glEnable(GL_TEXTURE_2D);
						glBegin(GL_QUADS);
							glTexCoord2f(0.f, 1.f); glVertex3f(-fSize[X],  fSize[Y],  1.f);
							glTexCoord2f(1.f, 1.f); glVertex3f( fSize[X],  fSize[Y],  1.f);
							glTexCoord2f(1.f, 0.f); glVertex3f( fSize[X], -fSize[Y],  1.f);
							glTexCoord2f(0.f, 0.f); glVertex3f(-fSize[X], -fSize[Y],  1.f);
						glEnd();
						break;
				}
			}

			CTexturePreviewRendererHandler.Update();
			_AS::Update();
			break;

        case WM_LBUTTONDOWN: case WM_LBUTTONUP: case WM_RBUTTONDOWN:
        case WM_RBUTTONUP:   case WM_MOUSEMOVE:
			i = wParam;
			memcpy(&OldMousePos, &MousePos, sizeof(POINT));

			GetCursorPos(&MousePos);
			GetWindowRect(hWnd, &Rect);
			GetWindowRect(CTexturePreviewRendererHandler.GetWnd(), &Rect);

			if (MousePos.x > Rect.left && MousePos.x < Rect.right &&
			    MousePos.y > Rect.top  && MousePos.y < Rect.bottom) {
				// The mouse is over the window enable view control
				if (i & MK_LBUTTON && i & MK_RBUTTON)
					fTextureViewPos[Z] -= (float) (MousePos.x - OldMousePos.x + MousePos.y - OldMousePos.y) / 20;
				else if(i & MK_RBUTTON) {
						fTextureViewPos[X] -= (float) (OldMousePos.x - MousePos.x)    / 100;
						fTextureViewPos[Y] -= (float) (MousePos.y    - OldMousePos.y) / 100;
					 }
			}
			break;

        case WM_COMMAND:
            switch (LOWORD(wParam)) {
                case IDC_TEXTUREMANAGER_OK:
					if (!hWndTextureDialog) break;
					_AS::CLog.Output("Close texture manager dialog");
					hWndTextureDialog = NULL;
					KillTimer(hWnd, 1);
					if (pCTextureHandler) {
						delete pCTextureHandler;
						pCTextureHandler = NULL;
					}
					pCSelectedTexture = NULL;
					CTexturePreviewRendererHandler.DeInit();
					EndDialog(hWnd, false);

					return true;
				
				case IDC_TEXTUREMANAGER_LOAD:
					KillTimer(hWnd, 1);
					strcpy(szTemp, _AS::CFileSystem.GetTexturesDirectory());
					_AS::CFileSystem.GetFullFilename(szTemp);
					pszTemp = _AS::CFileSystem.GetFilenameDialog(hWnd, CText.Get(_T_LoadTexture), ASTEXTURE_FILES, szTemp, true, true, NULL);
					SetTimer(hWnd, 1, 1, NULL);
					_AS::CFileSystem.InitGetFilename(&pszTemp);
					while (!_AS::CFileSystem.GetNextFilename(&pszTemp, szTemp))
						_AS::CTextureManager.PreLoad(szTemp);
					goto Init;

				case IDC_TEXTUREMANAGER_UNLOAD:
					if (!pCSelectedTexture) break;
					if (pCSelectedTexture->m_lstHandler.GetElements()) {
						KillTimer(hWnd, 1);
						sprintf(szTemp, "'%s': %s (%d)\n%s", pCSelectedTexture->m_szFilename,
															 CText.Get(_T_TextureIsStillUsed),
															 pCSelectedTexture->m_lstHandler.GetElements(),
															 CText.Get(_T_ContinueQuestionMark));
						if(MessageBox(hWnd, szTemp, CText.Get(_T_Question), MB_YESNO | MB_ICONINFORMATION) == IDNO) {
							SetTimer(hWnd, 1, 1, NULL);
							break;
						}
						SetTimer(hWnd, 1, 1, NULL);
					}
					Unload(pCSelectedTexture);
					pCSelectedTexture = NULL;
					goto Init;

				case IDC_TEXTUREMANAGER_UNLOAD_UNUSED: UnloadUnusedTextures(); goto Init;
				case IDC_TEXTUREMANAGER_UPDATE: ReloadTextures(); goto Init;

				case ID_TEXTUREMANAGER_LIST:
					i = (int) SendDlgItemMessage(hWnd, ID_TEXTUREMANAGER_LIST, LB_GETCURSEL, 0, 0L);
					if (!(pCTexture = GetTexture(i))) break;
					pCSelectedTexture = pCTexture;
					goto Init;

				case IDC_TEXTUREMANAGER_RESET_VIEW:
					fTextureViewPos[X] = fTextureViewPos[Y] = 0.f;
					fTextureViewPos[Z] = -5.f;
					break;
			}
        break;

		case WM_CLOSE: case WM_DESTROY: SendMessage(hWnd, WM_COMMAND, IDC_TEXTUREMANAGER_OK, 0); break;
    }

    return false;
}
/*
	File: ASTexture.h

	Description: A texture
*/


#ifndef __ASTEXTURE_H__
#define __ASTEXTURE_H__


// Classes
typedef class ASTTexture {

	friend ASTTextureManager;
	friend ASTRenderer;


	public:
		/*
			Constructor
		*/
		AS_API ASTTexture();
		/*
			Parameters:
				ASTTextureHandler* pSTextureHandler	 -> Pointer to the texture handler using this texture
				char*			   pszFilename		 -> The filename of the texture
				bool			   bAllowMipmaps	 -> Are mipmaps allowed?
				bool			   bAllowFiltering	 -> Is texture filtering allowed?
				bool			   bAllowCompression -> Is texture compression allowed?
				bool			   bAllowResize		 -> Is texture resizing allowed?

			Notes:
				- Filename: The standard texture directory will be used normally but you
							are also allowed to use your own directories
				- If a 'ast'-file for the texture filename exist some parameters are writen over
		*/
		AS_API ASTTexture(ASTTextureHandler* pSTextureHandler, const char* pszFilename = NULL, const bool bAllowMipmaps = true,
						  const bool bAllowFiltering = true, const bool bAllowCompression = true,
						  const bool bAllowResize = true);

		/*
			Destructor
		*/
		AS_API ~ASTTexture();

		/*
			Returns the texture name

			Returns:
				char* -> Pointer to the texture filename
		*/
		AS_API const char* GetFilename() const;

		/*
			Binds the OpenGL texture

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool BindOpenGLTexture();

		/*
			Returns the width of the texture

			Returns:
				int -> Width of the texture
		*/
		AS_API int GetWidth() const;

		/*
			Returns the height of the texture

			Returns:
				int -> Height of the texture
		*/
		AS_API int GetHeight() const;

		/*
			Returns the orginal width of the texture

			Returns:
				int -> Orginal width of the texture
		*/
		AS_API int GetOrginalWidth() const;

		/*
			Returns the orginal height of the texture

			Returns:
				int -> Orginal height of the texture
		*/
		AS_API int GetOrginalHeight() const;

		/*
			Sets the texture protection state

			Parameters:
				bool bProtected -> Should the texture be protected or not?

			Notes:
				- If the texture is protected it will not be removed if the texture manager
				  tries it (it's only removed if the application is shut down :)
				- The standard texture is always protected because there must be at least one
				  texture in the texture manager
		*/
		AS_API void SetProtected(const bool bProtected = false);

		/*
			Returns whether the texture is protected or not

			Returns:
				bool -> 'true' if the texture is protected else 'false'
		*/
		AS_API bool IsProtected() const;

		/*
			Reloads the texture

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Reload();

		/*
			Rebuilds the OpenGL texture

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool RebuildOpenGLTexture();


	private:
		char		   m_szFilename[256];		// Filename of the texture
		bool		   m_bLoaded;				// Is the texture loaded?
		bool		   m_bProtected;			// Is this texture protected (couldn't be unloaded with normal functions)
		int			   m_iOrginalWidth;			// Orginal texture width
		int			   m_iOrginalHeight;		// Orginal texture height
		int			   m_iWidth, m_iHeight;		// Size of the texture (could be different to the textures orginal size)
		int			   m_iImageBits;			// Image bit depth
		char		   m_szColorComponents;		// Number of color components
		int			   m_iType;					// Type of texture data (normaly GL_UNSIGNED_BYTE)
		int			   m_iFormat;				// Texture format RGB or RGBA
		unsigned char* m_pszData;				// Texture data
		unsigned int   m_iOpenGLID;				// ID of the OpenGL texture
		int			   m_iTextureType;			// Texture type (GL_TEXTURE_1D, GL_TEXTURE_2D)

		bool   m_bAllowMipmaps;			// Are mipmaps allowed?
		bool   m_bAllowFiltering;		// Is texture filtering allowed?
		bool   m_bAllowCompression;		// Is texture compression allowed?
		bool   m_bAllowResize;			// Is it allowed to resizing the texture?
		bool   m_bClampX, m_bClampY;	// Clamp texture (texture wrapping)
		ASINT2 m_iMinTextureSize;		// The minimum allowed size for this texture (resizing)
		bool   m_bUseAlpha;				// Should the alpha map be used? (tga -> RGBA)
		float  m_fAlphaReference;		// Alpha reference value
		bool   m_bEnvironmentMappingX;	// Environment mapping for x coordinate?
		bool   m_bEnvironmentMappingY;	// Environment mapping for y coordinate?

		ASTLinkedList<ASTTextureHandler*> m_lstHandler; // Linked list of all texture handlers
														// using this texture


		/*
			Loads the texture data depending of the texture type

			Parameters:
				ASTTextureHandler* pSTextureHandler	 -> Pointer to the texture handler using this texture
				char*			   pszFilename		 -> The filename of the texture
				bool			   bAllowMipmaps	 -> Are mipmaps allowed?
				bool			   bAllowFiltering   -> Is texture filtering allowed?
				bool			   bAllowCompression -> Is texture compression allowed?
				bool			   bAllowResize		 -> Is texture resizing allowed?

			Returns:
				int -> The number of texture handlers using this texture

			Notes:
				- Filename: The standard texture directory will be used normally but you
							are also allowed to use your own directories
				- If a 'ast'-file for the texture filename exist some parameters are writen over
		*/
		int Load(ASTTextureHandler* pSTextureHandler, const char* pszFilename = NULL, const bool bAllowMipmaps = true,
				 const bool bAllowFilterung = true, const bool bAllowCompression = true,
				 const bool bAllowResize = true);

		/*
			Saves the texture

			Parameters:
				char* pszFilename -> Texture filename

			Returns:
				bool -> 'false' if all went file else 'true'
		*/
		bool Save(const char* pszFilename);

		/*
			Unload the texture

			Parameters:
				ASTTextureHandler* pSTextureHandler -> Pointer to the texture handler using this texture

			Returns:
				int -> The number of texture handlers using this texture.
					   If it is '-1' the given texture handler wasn't listed in the textures texture handler list.
					   '-2' if the texture is now unused..
		*/
		int Unload(ASTTextureHandler* pSTextureHandler);

		/*
			Unload the texture immediately
		*/
		void Clear();

		/*
			Unload the texture data
		*/
		void UnloadData();

		/*
			Checks if the texture dimension is correct

			Parameters;
				- bool bLogMessage  -> Should a log message be print if the texture dimension
									   isn't correct?
				- bool bAutoCorrect -> Should the texture be scaled to a valid size?

			Returns:
				bool -> 'true' if the texture dimension is correct else 'false'
		*/
		bool IsDimensionCorrect(const bool bLogMessage = false, const bool bAutoCorrect = false);

		/*
			Scales the texture data

			Parameters:
				int iWidth  -> New texture width
				int iHeight -> New texture height

			Returns:
				bool -> 'false' if all went fine else 'true'

			Notes:
				- If the width or the height is less or equal 0 the correct texture size
				  corresponding to the configuration is calculated
		*/
		bool ScaleImage(int iWidth = -1, int iHeight = -1);

		/*
			Generate the OpenGL texture	

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool GenerateOpenGLTexture();

		/*
			Delete the OpenGL texture

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool DeleteOpenGLTexture();

		/*
			Loads a bmp texture

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool LoadBmp();

		/*
			Loads a ppm texture

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool LoadPpm();

		/*
			Loads a tex texture

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool LoadTex();

		/*
			Loads a pcx texture

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool LoadPcx();

		/*
			Loads up a targa file

			Returns:
				bool -> 'false' if all went fine else 'true'

			Notes:
				- Supported types are 8,24 and 32 uncompressed images
		*/
		bool LoadTga();

		/*
			Loads an jpg texture

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool LoadJpg();

		/*
			Saves the texture as tga

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool SaveTGA() const;

		/*
			Saves the texture as ppm

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool SavePPM() const;



} ASTTexture;


#endif // __ASTEXTURE_H__
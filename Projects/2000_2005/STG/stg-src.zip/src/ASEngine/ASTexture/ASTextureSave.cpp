/*
	File: ASTextureSave.cpp
*/

#include <ASEngineDll.h>


/*
	Saves the texture as tga
*/
bool ASTTexture::SaveTGA() const
{
    FILE *pFile;

    struct TGAHeader {
        unsigned char idfield_len;
        unsigned char cmap_type;
        unsigned char image_type;
        unsigned char cmap_spec[5];
        unsigned char x_orig[2];
        unsigned char y_orig[2];
        unsigned char width[2];
        unsigned char height[2];
        unsigned char pixel_size;
        unsigned char image_desc;
    } SHeader;

    // Open file
    if (!(pFile = fopen(m_szFilename, "wb"))) return true;

    // Construct header
    SHeader.idfield_len = 0;
    SHeader.cmap_type   = 0;
    SHeader.image_type  = 2;
	memset(&SHeader.cmap_spec, 0, sizeof(unsigned char) * 5);
	memset(&SHeader.x_orig,	   0, sizeof(unsigned char) * 2);
	memset(&SHeader.y_orig,	   0, sizeof(unsigned char) * 2);

    // Lo bits
    SHeader.width[0] = m_iWidth & 0xFF;

    // Hi bits 
    SHeader.width[1]   = (m_iWidth >> 8) & 0xFF;
    SHeader.height[0]  = m_iHeight & 0xFF;
    SHeader.height[1]  = (m_iHeight >> 8) & 0xFF;
    SHeader.pixel_size = 24;
    SHeader.image_desc = 0;

    // Output header
    fwrite(&SHeader, sizeof(SHeader), 1, pFile);
    
    // Output image
    fwrite(m_pszData, sizeof(unsigned char), m_iWidth * m_iHeight * 3, pFile);

    fclose(pFile);

    return false;
}

/*
	Saves the texture as ppm
*/
bool ASTTexture::SavePPM() const
{
    FILE *pFile;

    // Open file
    if (!(pFile = fopen(m_szFilename, "wb"))) return true;

	// Output header
    fprintf(pFile, 
            "P6\n#Screenshot %s\n%d %d\n%d\n",
            m_szFilename, m_iWidth, m_iHeight, 255);
    
    // GL returns the data upside down
    for (int i = m_iHeight - 1; i >= 0; i--)
        fwrite((unsigned char*) m_pszData + m_iWidth * i * 3, sizeof(unsigned char), m_iWidth * 3, pFile);

    fclose(pFile);

    return false;
}
/*
	File: ASTextureHandler.cpp
*/

#include <ASEngineDll.h>


/*
	Constructor
*/
ASTTextureHandler::ASTTextureHandler(const char* pszFilename, const bool bAllowMipmaps,
									 const bool bAllowFiltering, const bool bAllowCompression,
									 const bool bAllowResize)
{
	Init();
	Load(pszFilename, bAllowMipmaps, bAllowFiltering, bAllowCompression, bAllowResize);
}

/*
	Destructor
*/
ASTTextureHandler::~ASTTextureHandler()
{
	Unload();
}

/*
	Loads a texture
*/
bool ASTTextureHandler::Load(const char* pszFilename, const bool bAllowMipmaps,
							 const bool bAllowFiltering, const bool bAllowCompression,
							 const bool bAllowResize)
{
	// Check if the handler already uses this object
	if (m_pCTexture && !stricmp(m_pCTexture->GetFilename(), pszFilename)) return false;

	Unload();
	if (_AS::CTextureManager.Load(this, pszFilename, bAllowMipmaps, bAllowFiltering, bAllowCompression, bAllowResize)) return true;

	return false;
}

/*
	Returns if the texture handler has a texture or not	
*/
bool ASTTextureHandler::IsLoaded() const
{
	if (m_pCTexture) return true;
	else			 return false;
}

/*
	Unloads the texture
*/
bool ASTTextureHandler::Unload()
{
	bool bError;

	// Does the texture handler has a texture?
	if (!m_pCTexture) return true;

	// Unload this texture
	bError = _AS::CTextureManager.Unload(this);

	Init();

	return bError;
}

/*
	Returns the texture handlers texture
*/
ASTTexture* ASTTextureHandler::GetTexture() const
{
	return m_pCTexture;
}

/*
	Initializes the texture handler
*/
void ASTTextureHandler::Init()
{
	m_pCTexture = NULL;
}
/*
	File: ASTexture.cpp
*/

#include <ASEngineDll.h>


/*
	Constructor
*/
ASTTexture::ASTTexture()
{
	memset(this, 0, sizeof(ASTTexture));
}

ASTTexture::ASTTexture(ASTTextureHandler* pSTextureHandler, const char* pszFilename, const bool bAllowMipmaps,
					   const bool bAllowFiltering, const bool bAllowCompression,
					   const bool bAllowResize)
{
	memset(this, 0, sizeof(ASTTexture));
	Load(pSTextureHandler, pszFilename, bAllowMipmaps, bAllowFiltering, bAllowCompression, bAllowResize);
}

/*
	Destructor
*/
ASTTexture::~ASTTexture()
{
	Clear();
}

/*
	Returns the texture name
*/
const char* ASTTexture::GetFilename() const
{
	return m_szFilename;
}

/*
	Binds the OpenGL texture
*/
bool ASTTexture::BindOpenGLTexture()
{
	if(!m_bLoaded || !m_iOpenGLID || !_AS::CRenderer.IsInitialized()) return true;

	// Check if this texture is already banded
	if (_AS::CRenderer.m_pCurrentTexture == this) return true;
	
	// Bind texture
	_AS::CRenderer.m_pCurrentTexture = this;
	glBindTexture(m_iTextureType, m_iOpenGLID);

	// Setup alpha test
	if (m_bUseAlpha) {
		glEnable(GL_ALPHA_TEST);
		glAlphaFunc(GL_GEQUAL, m_fAlphaReference);
	} else {
		glDisable(GL_ALPHA_TEST);
		glAlphaFunc(GL_GEQUAL, 1.f);
	}

	// Setup environment mapping
	if (m_bEnvironmentMappingX) glEnable(GL_TEXTURE_GEN_S);
	else						glDisable(GL_TEXTURE_GEN_S);
	if (m_bEnvironmentMappingY) glEnable(GL_TEXTURE_GEN_T);
	else						glDisable(GL_TEXTURE_GEN_T);

	return false;
}

/*
	Returns the width of the texture
*/
int ASTTexture::GetWidth() const
{
	return m_iWidth;
}

/*
	Returns the height of the texture
*/
int ASTTexture::GetHeight() const
{
	return m_iHeight;
}

/*
	Returns the orginal width of the texture
*/
int ASTTexture::GetOrginalWidth() const
{
	return m_iOrginalWidth;
}

/*
	Returns the orginal height of the texture
*/
int ASTTexture::GetOrginalHeight() const
{
	return m_iOrginalHeight;
}

/*
	Sets the texture protection state
*/
void ASTTexture::SetProtected(const bool bProtected)
{
	if (_AS::CTextureManager.GetStandardTexture() == this) return;
	m_bProtected = bProtected;
}

/*
	Returns whether the texture is protected or not
*/
bool ASTTexture::IsProtected() const
{
	return m_bProtected;
}

/*
	Reloads the texture
*/
bool ASTTexture::Reload()
{
	bool bError = false;

	UnloadData();
	if (Load(NULL, m_szFilename, m_bAllowMipmaps, m_bAllowFiltering, m_bAllowCompression, m_bAllowResize))
		bError = true;

	return bError;
}

/*
	Rebuilds the OpenGL texture
*/
bool ASTTexture::RebuildOpenGLTexture()
{
	bool bError = DeleteOpenGLTexture();
	if (GenerateOpenGLTexture()) bError = true;

	return bError;
}

/*
	Loads the texture data depending of the texture type
*/
int ASTTexture::Load(ASTTextureHandler* pSTextureHandler, const char* pszFilename, const bool bAllowMipmaps,
					 const bool bAllowFiltering, const bool bAllowCompression, const bool bAllowResize)
{
	char szFilename[256], szTemp[256];
	bool bError;
	int  i;

	// Check if the texture is already loaded
	if (m_bLoaded) {
		if (pSTextureHandler) {
			pSTextureHandler->m_pCTexture = this;
			m_lstHandler.Add(pSTextureHandler);
		}

		return m_lstHandler.GetElements();
	}

	// Get valid filename
	_AS::CTextureManager.GetValidFilename(pszFilename, m_szFilename);

	_AS::CLog.Output("Load texture: %s", m_szFilename);

	// Find out the type of the texture and load it
		 if (_AS::CFileSystem.IsFilenameEnding(m_szFilename, ASBMP_FILE)) bError = LoadBmp();
	else if (_AS::CFileSystem.IsFilenameEnding(m_szFilename, ASPPM_FILE)) bError = LoadPpm();
	else if (_AS::CFileSystem.IsFilenameEnding(m_szFilename, ASTEX_FILE)) bError = LoadTex();
	else if (_AS::CFileSystem.IsFilenameEnding(m_szFilename, ASPCX_FILE)) bError = LoadPcx();
	else if (_AS::CFileSystem.IsFilenameEnding(m_szFilename, ASTGA_FILE)) bError = LoadTga();
	else if (_AS::CFileSystem.IsFilenameEnding(m_szFilename, ASJPG_FILE)) bError = LoadJpg();
	else {
		char szFilenameEnding[256];

		if (_AS::CFileSystem.GetFilenameEnding(m_szFilename, szFilenameEnding))
			_AS::CLog.Output("'%s' is an unkown texture format!", szFilenameEnding);
		else _AS::CLog.Output("Unkown texture format!");
		if (pSTextureHandler) pSTextureHandler->m_pCTexture = _AS::CTextureManager.GetStandardTexture();

		return -1;
	}

	// Check if there was an error
	if (bError) {
		_AS::CLog.Output("Couldn't load this texture!");
		 if (pSTextureHandler) pSTextureHandler->m_pCTexture = _AS::CTextureManager.GetStandardTexture();

		return -1;
	}

	m_bLoaded = true;

	// Setup texture attributes
	if (m_iTextureType == GL_TEXTURE_1D) m_bAllowCompression = false;
	else								 m_bAllowCompression = bAllowCompression;

	// Load 'ast'-file
	strcpy(szFilename, m_szFilename);
	_AS::CFileSystem.CutFilenameEnding(szFilename);
	_AS::CFileSystem.GetFullFilename(szFilename, ASTEXTURE_FILE);
	m_bAllowMipmaps   = GetPrivateProfileInt("general", "mipmaps",   bAllowMipmaps,   szFilename) != 0;
	m_bAllowFiltering = GetPrivateProfileInt("general", "filtering", bAllowFiltering, szFilename) != 0;
	m_bAllowResize    = GetPrivateProfileInt("general", "resize",	 bAllowResize,    szFilename) != 0;
	if (m_bAllowCompression)
		m_bAllowCompression = GetPrivateProfileInt("general", "compression", m_bAllowCompression, szFilename) != 0;
	if (m_iFormat == GL_RGBA) m_bUseAlpha = GetPrivateProfileInt("general", "usealpha",	true, szFilename) != 0;
	else					  m_bUseAlpha = false;
	GetPrivateProfileString("general", "alphareference", "0.5", szTemp, 256, szFilename);
	m_fAlphaReference = (float) atof(szTemp);

	// Minimum texture size
	m_iMinTextureSize[X] = GetPrivateProfileInt("general", "minsize_x", 2, szFilename);
	if (m_iMinTextureSize[X] < 2) m_iMinTextureSize[X] = 2;
	i = _AS::CMath.GetNearestPowerOfTwo(m_iMinTextureSize[X]);
	if (i != m_iMinTextureSize[X]) {
		_AS::CLog.Output("%d is an invalid minimum texture width! %d will be used instead.", m_iMinTextureSize[X], i);
		m_iMinTextureSize[X] = i;
	}
	m_iMinTextureSize[Y] = GetPrivateProfileInt("general", "minsize_y", 2, szFilename);
	if (m_iMinTextureSize[Y] < 2) m_iMinTextureSize[Y] = 2;
	i = _AS::CMath.GetNearestPowerOfTwo(m_iMinTextureSize[Y]);
	if (i != m_iMinTextureSize[Y]) {
		_AS::CLog.Output("%d is an invalid minimum texture height! %d will be used instead.", m_iMinTextureSize[Y], i);
		m_iMinTextureSize[Y] = i;
	}

	// Get texture wrapping
	m_bClampX = GetPrivateProfileInt("wrapping", "clamp_x", true, szFilename) != 0;
	m_bClampY = GetPrivateProfileInt("wrapping", "clamp_y", true, szFilename) != 0;		

	// Get environment mapping
	m_bEnvironmentMappingX = GetPrivateProfileInt("environment_mapping", "x", false, szFilename) != 0;
	m_bEnvironmentMappingY = GetPrivateProfileInt("environment_mapping", "y", false, szFilename) != 0;

	// Scale the texture image
	if (GetPrivateProfileInt("forcesize", "active", 0, szFilename) != 0) {
		m_bAllowResize = true;
		ScaleImage(GetPrivateProfileInt("forcesize", "width",  m_iWidth,  szFilename),
				   GetPrivateProfileInt("forcesize", "height", m_iHeight, szFilename));
	} else ScaleImage();

	// Generate the OpenGL texture
	GenerateOpenGLTexture();
	
	// Add the texture handler
	if (pSTextureHandler) {
		pSTextureHandler->m_pCTexture = this;
		m_lstHandler.Add(pSTextureHandler);
	}

	return m_lstHandler.GetElements();
}

/*
	Saves the texture
*/
bool ASTTexture::Save(const char* pszFilename)
{
	bool bError = false;

	if (!m_pszData || !pszFilename) return true;

	// Get valid filename
	strcpy(m_szFilename, pszFilename);
	_AS::CFileSystem.GetFullFilename(m_szFilename);
	_AS::CLog.Output("Save texture: %s", m_szFilename);

	// Find out the type of the texture and save it
		 if (_AS::CFileSystem.IsFilenameEnding(m_szFilename, ASPPM_FILE)) bError = SavePPM();
	else if (_AS::CFileSystem.IsFilenameEnding(m_szFilename, ASTGA_FILE)) bError = SaveTGA();
	else {
		_AS::CLog.Output("Invalid file type! Couldn't save texture!");

		return true;
	}

	return false;
}

/*
	Unload the texture
*/
int ASTTexture::Unload(ASTTextureHandler* pSTextureHandler)
{
	// Check if this texture handler is listed in this texture
	if (m_lstHandler.Remove(pSTextureHandler)) return -1;

	// Set the texture handlers texture to NULL
	pSTextureHandler->m_pCTexture = NULL;

	// Is the texture now unused?
	if (!_AS::CTextureManager.GetUnloadUnusedTextures() ||
		m_bProtected || !m_lstHandler.IsEmpty())
		return m_lstHandler.GetElements();

	// Setup texture data
	UnloadData();

	return -2;
}

/*
	Unload the texture immediately
*/
void ASTTexture::Clear()
{
	ASTLinkedListElement<ASTTextureHandler*>* pListElement;

	if (!m_bLoaded) return;

	// Unload texture data
	UnloadData();

	// Update texture handlers using this texture
	pListElement = m_lstHandler.FindFirst();
	while (pListElement) {
		if (_AS::CTextureManager.GetStandardTexture() &&
			_AS::CTextureManager.GetStandardTexture() != this)
			pListElement->Data->Load(_AS::CTextureManager.GetStandardTexture()->GetFilename());
		else {
			pListElement->Data->m_pCTexture = NULL;
			pListElement->Data->Unload();
		}
		pListElement = m_lstHandler.FindNext();
	}
	m_lstHandler.Clear();
}

/*
	Unload the texture data
*/
void ASTTexture::UnloadData()
{
	if (!m_bLoaded) return;

	_AS::CLog.Output("Delete texture '%s'", m_szFilename);

	// Delete the OpenGL texture
	DeleteOpenGLTexture();
	if (_AS::CRenderer.m_pCurrentTexture == this)
		_AS::CRenderer.m_pCurrentTexture = NULL;

	// Setup texture data
	if (m_pszData) {
		delete m_pszData;
		m_pszData = NULL;
	}

	m_bLoaded = false;
}

/*
	Checks if the texture dimension is correct
*/
bool ASTTexture::IsDimensionCorrect(const bool bLogMessage, const bool bAutoCorrect)
{
	// Check if the texture dimension is a power of 2
	if (!_AS::CMath.IsPowerOfTwo(m_iWidth) || (m_iTextureType != GL_TEXTURE_1D && !_AS::CMath.IsPowerOfTwo(m_iHeight))) {
		if (bLogMessage) _AS::CLog.Output("Texture dimension (%dx%d) must be a power of 2 (e.g. 64, 128...)!", m_iWidth, m_iHeight);

		if (bAutoCorrect) { // Correct texture size
			int iWidth, iHeight;

			if (!_AS::CMath.IsPowerOfTwo(m_iWidth))  iWidth = _AS::CMath.GetNearestPowerOfTwo(m_iWidth);
			else									 iWidth = m_iWidth;
			if (!_AS::CMath.IsPowerOfTwo(m_iHeight)) iHeight = _AS::CMath.GetNearestPowerOfTwo(m_iHeight);
			else									 iHeight = m_iHeight;
			_AS::CLog.Output("Scale texture dimension to %dx%d", iWidth, iHeight);
			ScaleImage(iWidth, iHeight);			
		}
	}

	// Check if the texture size is to large
	{
		int iMaxTextureSize = 0;

		glGetIntegerv(GL_MAX_TEXTURE_SIZE, &iMaxTextureSize);
		if (m_iWidth > iMaxTextureSize || m_iHeight > iMaxTextureSize) {
			if (bLogMessage) _AS::CLog.Output("Texture size is to large for that system! (max: %dx%d)", iMaxTextureSize, iMaxTextureSize);
			return false;
		}
	}

	return true;
}

/*
	Scales the texture data
*/
bool ASTTexture::ScaleImage(int iWidth, int iHeight)
{
	unsigned char* pszDataT;
	int iType;

	// Is it allowed to scale the texture image?
	if (!m_bAllowResize) return true;

	// Get the correct with and height
	if (iWidth < 0) {
		iWidth = (int) (m_iWidth  * _AS::CConfig.GetTextureQuality());
		iWidth = _AS::CMath.GetNearestPowerOfTwo(iWidth);
		if (iWidth < m_iMinTextureSize[X]) iWidth = m_iMinTextureSize[X];
	}
	if (iHeight < 0) {
		iHeight = (int) (m_iHeight * _AS::CConfig.GetTextureQuality());
		iHeight = _AS::CMath.GetNearestPowerOfTwo(iHeight);
		if (iHeight < m_iMinTextureSize[Y]) iHeight = m_iMinTextureSize[Y];
	}

	// Check if the texture image should be scaled
	if (iWidth == m_iWidth && iHeight == m_iHeight) return false;

	// Scale the texture image
	if (!(pszDataT = new unsigned char[iWidth * iHeight * m_szColorComponents])) return true;
	if (m_szColorComponents == 4) iType = GL_RGBA;
	else						  iType = GL_RGB;
	gluScaleImage(iType,
				 m_iWidth,
				 m_iHeight,
				 GL_UNSIGNED_BYTE,
				 m_pszData,
				 iWidth,
				 iHeight,
				 GL_UNSIGNED_BYTE,
				 pszDataT
	);
	m_iWidth  = iWidth;
	m_iHeight = iHeight;
	delete m_pszData;
	m_pszData = pszDataT;
	
	return false;
}

/*
	Generate the OpenGL texture	
*/
bool ASTTexture::GenerateOpenGLTexture()
{
	// Is this OpenGL texture already generated?
	if (m_iOpenGLID) return false;
	
	// Check if the texture data is loaded
	if (!m_bLoaded) return true;

	_AS::CLog.Output("Generate OpenGL texture: %s", m_szFilename);
	glGenTextures(1, &m_iOpenGLID);
	glBindTexture(m_iTextureType, m_iOpenGLID);
	if (_AS::CRenderer.m_pCurrentTexture == this) _AS::CRenderer.m_pCurrentTexture = NULL;

	// Setup texture wrapping
	if (m_bClampX) glTexParameteri(m_iTextureType, GL_TEXTURE_WRAP_S, GL_CLAMP);
	else		   glTexParameteri(m_iTextureType, GL_TEXTURE_WRAP_S, GL_REPEAT);
	if (m_bClampY) glTexParameteri(m_iTextureType, GL_TEXTURE_WRAP_T, GL_CLAMP);
	else		   glTexParameteri(m_iTextureType, GL_TEXTURE_WRAP_T, GL_REPEAT);

	if (_AS::CConfig.UseMipmaps() && m_bAllowMipmaps) {
		if (_AS::CConfig.UseTextureFiltering() && m_bAllowFiltering) {
			glTexParameteri(m_iTextureType, GL_TEXTURE_MAG_FILTER, GL_LINEAR_MIPMAP_LINEAR);
			glTexParameteri(m_iTextureType, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
			if (m_iTextureType == GL_TEXTURE_1D)
				gluBuild1DMipmaps(GL_TEXTURE_1D, _AS::CConfig.GetTextureCompressionMode(m_bAllowCompression), m_iWidth, m_iFormat,
								  m_iType, m_pszData);
			else
				gluBuild2DMipmaps(GL_TEXTURE_2D, _AS::CConfig.GetTextureCompressionMode(m_bAllowCompression), m_iWidth, m_iHeight, m_iFormat,
								  m_iType, m_pszData);
		} else {
			glTexParameteri(m_iTextureType, GL_TEXTURE_MAG_FILTER, GL_NEAREST_MIPMAP_NEAREST);
			glTexParameteri(m_iTextureType, GL_TEXTURE_MIN_FILTER, GL_NEAREST_MIPMAP_NEAREST);
			if (m_iTextureType == GL_TEXTURE_1D)
				gluBuild1DMipmaps(GL_TEXTURE_1D, _AS::CConfig.GetTextureCompressionMode(m_bAllowCompression), m_iWidth, m_iFormat,
								  m_iType, m_pszData);
			else
				gluBuild2DMipmaps(GL_TEXTURE_2D, _AS::CConfig.GetTextureCompressionMode(m_bAllowCompression), m_iWidth, m_iHeight, m_iFormat,
								  m_iType, m_pszData);
		}
	} else {
		if (_AS::CConfig.UseTextureFiltering() && m_bAllowFiltering) {
			glTexParameteri(m_iTextureType, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
			glTexParameteri(m_iTextureType, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
			if (m_iTextureType == GL_TEXTURE_1D)
				glTexImage1D(GL_TEXTURE_1D, 0, _AS::CConfig.GetTextureCompressionMode(m_bAllowCompression), m_iWidth, 0, m_iFormat,
							 m_iType, m_pszData);
			else
				glTexImage2D(GL_TEXTURE_2D, 0, _AS::CConfig.GetTextureCompressionMode(m_bAllowCompression), m_iWidth, m_iHeight, 0, m_iFormat,
							 m_iType, m_pszData);
		} else {
			glTexParameteri(m_iTextureType, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
			glTexParameteri(m_iTextureType, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
			if (m_iTextureType == GL_TEXTURE_1D)
				glTexImage1D(GL_TEXTURE_1D, 0, _AS::CConfig.GetTextureCompressionMode(m_bAllowCompression), m_iWidth, 0, m_iFormat,
							 m_iType, m_pszData);
			else
				glTexImage2D(GL_TEXTURE_2D, 0, _AS::CConfig.GetTextureCompressionMode(m_bAllowCompression), m_iWidth, m_iHeight, 0, m_iFormat,
							 m_iType, m_pszData);
		}
	}

	return false;
}

/*
	Delete the OpenGL texture
*/
bool ASTTexture::DeleteOpenGLTexture()
{
	// Is there a OpenGL texture for this texture?
	if (!m_iOpenGLID) return false;

	_AS::CLog.Output("Delete OpenGL texture: %s", m_szFilename);
	glDeleteTextures(1, &m_iOpenGLID);
	m_iOpenGLID = 0;

	return false;
}
/*
	File: ASTextureManager.h

	Description: Manages the textures
*/


#ifndef __ASTEXTUREMANAGER_H__
#define __ASTEXTUREMANAGER_H__


// Definitions
#define ASSTANDARDTEXTURE "standard.jpg" // The standard texture


// Predefinitions
typedef class ASTRenderer ASTRenderer;
typedef class ASTTexture ASTTexture;
typedef class ASTTextureHandler ASTTextureHandler;
typedef class ASTTextureManager ASTTextureManager;


// Includes
#include "ASTexture.h"
#include "ASTextureHandler.h"


// Classes
typedef class ASTTextureManager {

	friend _AS;
	friend ASTTextureHandler;
	friend ASTRenderer;


	public:
		/*
			Constructor
		*/
		AS_API ASTTextureManager();

		/*
			Destructor
		*/
		AS_API ~ASTTextureManager();

		/*
			Returns if unused textures should be removed automatically

			Returns:
				bool -> 'true' if unused textures are unloaded automatically else 'false'
		*/
		AS_API bool GetUnloadUnusedTextures() const;

		/*
			Sets if unused textures should be removed automatically

			Parameters:
				bool bUnloadUnusedTextures -> Should unused textures be removed automatically?
		*/
		AS_API void SetUnloadUnusedTextures(const bool bUnloadUnusedTextures = true);

		/*
			Unload all unused textures
		*/
		AS_API void UnloadUnusedTextures();

		/*
			Returns a pointer to the texture with the given ID
		
			Parameters:
				int iTextureID -> The texture ID

			Returns:
				ASTTexture* -> Pointer to the texture
		*/
		AS_API ASTTexture* GetTexture(const int iTextureID);

		/*
			Returns a pointer to the texture with the given filename
		
			Parameters:
				char* pszFilename -> Texture filename

			Returns:
				ASTTexture* -> Pointer to the texture
		*/
		AS_API ASTTexture* GetTexture(const char* pszFilename);

		/*
			Returns a pointer to the standard texture
		
			Returns:
				ASTTexture* -> Pointer to the standard texture
		*/
		AS_API ASTTexture* GetStandardTexture();

		/*
			Returns a pointer to the cel shading texture
		
			Returns:
				ASTTexture* -> Pointer to the cel shading texture
		*/
		AS_API ASTTexture* GetCelShadingTexture();
		
		/*
			Unload all textures

			Notes:
				- All texture handlers will loose their textures
				- Use this function only if you really want to unload all textures
				- The standard texture will stay alive
		*/
		AS_API void Clear();

		/*
			Pre-loads a texture with the given filename

			Parameters:
				char* pszFilename   -> The filename of the texture

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool PreLoad(const char* pszFilename = NULL);

		/*
			Reloads all textures

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool ReloadTextures();

		/*
			Rebuilds all OpenGL textures

			Returns:
				bool -> 'false' if all went fine else 'true'

			Notes:
				- You should rebuild all OpenGL textures after you changed e.g. the mipmapping mode
		*/
		AS_API bool RebuildOpenGLTextures();

		/*
			Gets the valid texture filename

			Parameters:
				char* pszFilename      -> Pointer to the source filename
				char* pszValidFilename -> Pointer to the falid filename

			Notes:
				- If 'pszFilename' is NULL the filename of the standard texture will be returned
				- If the texture isn't found in the given directory it will be searched in the
				  standard texture directory
		*/
		AS_API void GetValidFilename(const char* pszFilename, char* pszValidFilename) const;

		/*
			Opens the texture manager dialog

			Parameters:
				HWND hWnd -> Parent window handler

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool OpenDialog(const HWND hWnd);


	private:
		ASTTextureHandler		   m_CStandardTexture;		// The standard texture
		ASTTextureHandler		   m_CCelShadingTexture;	// The cel shading texture
		ASTLinkedList<ASTTexture*> m_lstTextureList;		// Linked list of all textures
		bool					   m_bUnloadUnusedTextures; // Should unused textures be removed automatically?


		/*
			Initialize the texture manager

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Init();

		/*
			Loads a texture with the given filename

			Parameters:
				ASTTextureHandler* pCTextureHandler	 -> Pointer to the texture handler using this texture
				char*			   pszFilename		 -> The filename of the texture
				bool			   bAllowMipmaps	 -> Are mipmaps allowed?
				bool			   bAllowFiltering   -> Is texture filtering allowed?
				bool			   bAllowCompression -> Is texture compression allowed?
				bool			   bAllowResize		 -> Is texture resizing allowed?

			Returns:
				bool -> 'false' if all went fine else 'true'

			Notes:
				- Filename: The standard texture directory will be used normally but you
							are also allowed to use your own directories
				- If a 'ast'-file for the texture filename exist some parameters are writen over
				- If 'pCTextureHandler' is NULL the texture will be pre-loaded
		*/
		bool Load(ASTTextureHandler* pCTextureHandler, const char* pszFilename = NULL, const bool bAllowMipmaps = true,
				  const bool bAllowFiltering = true, const bool bAllowCompression = true,
				  const bool bAllowResize = true);

		/*
			Unloads a texture

			Parameters:
				ASTTextureHandler* pTextureHandler -> Pointer to the texture handler using this texture

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Unload(ASTTextureHandler* pCTextureHandler);

		/*
			Unloads a texture

			Parameters:
				ASTTexture* pTexture -> Pointer to the texture

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Unload(ASTTexture* pCTexture);

		/*
			Unload all textures

			Notes:
				- All texture handlers will loose their textures
				- Use this function only if you really want to unload all textures
				- The standard texture will be unloaded, too!
		*/
		void Cleanup();

		/*
			Creates all OpenGL textures

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool GenerateOpenGLTextures();

		/*
			Deletes all OpenGL textures

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool DeleteOpenGLTextures();

		/*
			Texture manager dialog procedure
		*/
		static LRESULT CALLBACK DialogProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);
		LRESULT Proc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);

		/*
			Updates all texture stuff
		*/
		void Update();


} ASTTextureManager;


#endif // __ASTEXTUREMANAGER_H__
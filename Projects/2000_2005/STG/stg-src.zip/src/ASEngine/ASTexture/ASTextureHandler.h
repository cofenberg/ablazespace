/*
	File: ASTextureHandler.h

	Description: User texture device
*/


#ifndef __ASTEXTUREHANDLER_H__
#define __ASTEXTUREHANDLER_H__


// Classes
typedef class ASTTextureHandler {

	friend ASTTexture;


	public:
		/*
			Constructor

			Parameters:
				char* pszFilename		-> Texture filename
				bool  bAllowMipmaps		-> Are mipmaps allowed?
				bool  bAllowFiltering   -> Is texture filtering allowed?
				bool  bAllowCompression -> Is texture compression allowed?
				bool  bAllowResize		-> Is texture resizing allowed?

			Notes:
				- Filename: The standard texture directory will be used normally but you
							are also allowed to use your own directories
				- If a 'ast'-file for the texture filename exist some parameters are writen over
		*/
		AS_API ASTTextureHandler(const char* pszFilename = ASSTANDARDTEXTURE, const bool bAllowMipmaps = true,
								 const bool bAllowFiltering = true, const bool bAllowCompression = true,
								 const bool bAllowResize = true);

		/*
			Destructor
		*/
		AS_API ~ASTTextureHandler();

		/*
			Loads a texture

			Parameters:
				char* pszFilename		-> Texture filename
				bool  bAllowMipmaps		-> Are mipmaps allowed?
				bool  bAllowFiltering   -> Is texture filtering allowed?
				bool  bAllowCompression -> Is texture compression allowed?
				bool  bAllowResize		-> Is texture resizing allowed?

			Returns:
				bool -> 'false' if all went fine else 'true'

			Notes:
				- Filename: The standard texture directory will be used normally but you
							are also allowed to use your own directories
				- If a 'ast'-file for the texture filename exist some parameters are writen over
		*/
		AS_API bool Load(const char* pszFilename = ASSTANDARDTEXTURE, const bool bAllowMipmaps = true,
						 const bool bAllowFiltering = true, const bool bAllowCompression = true,
						 const bool bAllowResize = true);

		/*
			Returns if the texture handler has a texture or not	

			Returns:
				bool -> 'true' if the texture handler has a texture else 'false'
		*/
		AS_API bool IsLoaded() const;

		/*
			Unloads the texture

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Unload();

		/*
			Returns the texture handler texture

			Returns:
				ASTTexture* -> Pointer to the texture handlers texture
		*/
		AS_API ASTTexture* GetTexture() const;


	private:
		ASTTexture* m_pCTexture;	// Pointer to the texture this handler uses


		/*
			Initializes the texture handler
		*/
		void Init();


} ASTTextureHandler;


#endif // __ASTEXTUREHANDLER_H__
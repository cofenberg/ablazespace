/*
	File: ASDataSet.h

	Description: Class for creating a data set
*/


#ifndef __ASDATASET_H__
#define __ASDATASET_H__


template <class AType> class CDataSet
{
	public:
		/*
			Constructor
		*/
		AS_API CDataSet();

		/*
			Constructor

			Parameters:
				int iSize -> Size which should be allocated
		*/
		AS_API CDataSet(const int iSize);

		/*
			Destructor
		*/
		AS_API ~CDataSet();

		/*
			Allocate memory

			Parameters:
				int iSize -> Size which should be allocated
		*/
		AS_API void Allocate(const int iSize);

		/*
			Clear the data set
		*/
		AS_API void Clear();

		/*
			Add new data

			Parameters:
				AType &Data -> Data which should be added
		*/
		AS_API void Add(const AType &Data);

		/*
			Return data

			Parameters:
				int iPos -> Data index

			Returns:
				AType* -> Pointer to the data if all went fine, else 'NULL'
		*/
		AS_API AType* Get(const int iPos) const;

		/*
			Returns the size of the data set

			Returns:
				int -> The size of the data set
		*/
		AS_API int GetSize() const;

		/*
			Returns the used size of the data set

			Returns:
				int -> The used size of the data set
		*/
		AS_API int GetUsedSize() const;

		/*
			Returns a pointer to the data

			Returns:
				AType* -> Pointer to the data
		*/
		AS_API AType* GetPointer() const;

	private:
		AType* m_pData;
		int    m_iAllocated;
		int    m_iSize;
};

/*
	Constructor
*/
template <class AType> CDataSet<AType>::CDataSet()
{
	m_pData		 = NULL;
	m_iAllocated = 0;
	m_iSize		 = 0;
}

/*
	Constructor
*/
template <class AType> CDataSet<AType>::CDataSet(const int iSize)
{
	m_pData		 = new AType[iSize];
	m_iAllocated = iSize;
	m_iSize		 = 0;
}

/*
	Destructor
*/
template <class AType> CDataSet<AType>::~CDataSet()
{
	if (m_pData) delete [] m_pData;
}

/*
	Allocate memory
*/
template <class AType> void CDataSet<AType>::Allocate(const int iSize)
{
	// Delete old data
	if (m_pData) delete [] m_pData;

	// Allocate space
	m_pData		 = new AType[iSize];
	m_iAllocated = iSize;
	m_iSize		 = 0;
}

/*
	Clear the data set
*/
template <class AType> void CDataSet<AType>::Clear()
{
	// Delete data
	if (m_pData) {
		delete [] m_pData;
		m_pData = NULL;
	}

	// Reset counters
	m_iAllocated = 0;
	m_iSize      = 0;
}

/*
	Add new data
*/
template <class AType> void CDataSet<AType>::Add(const AType &Data)
{
	if (m_pData && m_iSize < m_iAllocated) {
		m_pData[m_iSize] = Data;
		m_iSize++;
	}
}

/*
	Return data
*/
template <class AType> Data* CDataSet<AType>::Get(const int iPos) const
{
	if (m_pData && iPos < m_iSize) return &m_pData[iPos];
	else						   return NULL;
}

/*
	Returns the used size of the data set
*/
template <class AType> int CDataSet<AType>::GetSize() const
{
	return m_iAllocated;
}

/*
	Returns the used size of the data set
*/
template <class AType> int CDataSet<AType>::GetUsedSize() const
{
	return m_iSize;
}

/*
	Returns a pointer to the data
*/
template <class AType> AType* CDataSet<AType>::GetPointer() const
{
	return m_pData;
}


#endif // __ASDATASET_H__
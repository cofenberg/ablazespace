/*
	File: ASTools.cpp
*/

#include <ASEngineDll.h>


/*
	Get the CPU mhz
*/
DWORD ASTTools::GetCpuMhz() const
{
	unsigned long lStartTicks = 0;
	unsigned long lEndTicks   = 0;
	unsigned long lTotalTicks;
	int iTimeStart, iTimeStop;

	iTimeStart = GetTickCount();
	while (1) {
		iTimeStop = GetTickCount();
		if (iTimeStop - iTimeStart > 1) { // Rollover past 1
			__asm {
				xor eax, eax
				xor ebx, ebx
				xor ecx, ecx
				xor edx, edx
				_emit 0x0f // CPUID
				_emit 0xa2
				_emit 0x0f // RTDSC
				_emit 0x31
				mov [lStartTicks], eax // Tick counter starts here
			}
			break;
		}
	}

	iTimeStart = iTimeStop;
	
	while (1) {
		iTimeStop = GetTickCount();
		if (iTimeStop - iTimeStart > 1000) { // One second
			__asm {
				xor eax, eax
				xor ebx, ebx
				xor ecx, ecx
				xor edx, edx
				_emit 0x0f
				_emit 0xa2
				_emit 0x0f
				_emit 0x31
				mov [lEndTicks], eax
			}
			break;
		}
	}

	lTotalTicks = lEndTicks - lStartTicks; // Total

	return (DWORD) lTotalTicks / 1000000;   // Speed;
}

/*
	Returns a positive random number
*/
inline int ASTTools::GetRand()
{
	return rand();
}

/*
	Returns a positive or negative random number
*/
inline int ASTTools::GetRandNeg()
{
	if (GetRand() % 2) return  GetRand();
	else			   return -GetRand();
}

/*
	Returns a positive float random number
*/
inline float ASTTools::GetRandFloat()
{
	return float (GetRand() % 10000) / 10000.f;
}

/*
	Returns a positive or negative float random number
*/
inline float ASTTools::GetRandNegFloat()
{
	return float (GetRandNeg() % 10000) / 10000.f;
}

/*
	Initializes the tools
*/
void ASTTools::Init()
{
}

/*
	De-initializes the tools
*/
void ASTTools::DeInit()
{
}
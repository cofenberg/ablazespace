/*
	File: ASTools.h

	Description: Some usefull tools
*/


#ifndef __ASTOOLS_H__
#define __ASTOOLS_H__


// Includes
#include "ASLinkedList.h"
#include "ASDynamicLinkedList.h"
#include "ASStack.h"
#include "ASParser.h"


// Classes
typedef class ASTTools {

	friend _AS;


	public:
		/*
			Get the CPU mhz

			Returns:
				DWORD -> CPU mhz
		*/
		AS_API DWORD GetCpuMhz() const;

		/*
			Returns a positive random number

			Returns:
				int -> A positive random number
		*/
		AS_API int GetRand();

		/*
			Returns a positive or negative random number

			Returns:
				int -> A positive or negative random number
		*/
		AS_API int GetRandNeg();

		/*
			Returns a positive float random number

			Returns:
				float -> A positive float random number (0.f - 1.f)
		*/
		AS_API float GetRandFloat();

		/*
			Returns a positive or negative float random number

			Returns:
			  float -> A positive or negative float random number (-1.f - 1.f)
		*/
		AS_API float GetRandNegFloat();


	private:
		/*
			Initializes the tools
		*/
		void Init();

		/*
			De-initializes the tools
		*/
		void DeInit();



} ASTTools;


#endif // __ASTOOLS_H__
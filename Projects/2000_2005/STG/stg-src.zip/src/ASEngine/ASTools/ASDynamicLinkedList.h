/*
	File: ASDynamicLinkedList.h

	Description: Dynamic linked list
				 Gets memory for the data and hold a own copy of it.
*/


#ifndef __ASDYNAMICLINKEDLIST_H__
#define __ASDYNAMICLINKEDLIST_H__


// Structures
template <class AType>
struct ASTDynamicLinkedListElement {
	ASTDynamicLinkedListElement* pNextElement;		// Pointer to the next element in the list
	ASTDynamicLinkedListElement* pPreviousElement;	// Pointer to the previous element in the list
	AType* pData;									// The stored data

};


// Classes
template <class AType>
class ASTDynamicLinkedList {

	public:
		/*
			Constructor
		*/
		ASTDynamicLinkedList();
		ASTDynamicLinkedList(const AType& pNewElementData);

		/*
			Destructor
		*/
		~ASTDynamicLinkedList();
		
		/*
			Checks whether the list is complete empty

			Returns:
				bool -> 'true' if the list is empty else 'false'
		*/
		bool IsEmpty() const;
		
		/*
			Returns the number of list elements
			
			Returns:
				int -> number of list elements
		*/
		int GetElements() const;

		/*
			Adds a new element to the list

			Parameters:
				AType& pNewElementData -> The data of the new list element
		*/
		bool Add(const AType& pNewElementData);

		/*
			Checks whether the data is an element of the list or not

			Parameters:
				AType* pElementData -> The data which should be checked

			Returns:
				int -> The ID of the list element. '-1' if it's no a list entry
		*/
		int IsElement(const AType* pElementData);

		/*
			Get the element data from the given index

			Parameters:
				int iIndex -> Index of the element
		*/
		AType* operator [] (const int iIndex);

		/*
			Returns a pointer to the first list element

			Returns:
				- Pointer to the first element in the list

			Notes:
				- Use the functions 'FindFirst' & 'FindNext' for faster enumeration
				- Use 'FindFirst'to find the first list element. If you use 'FindNext'
				  first it's possible that a crash occurs!
		*/
		ASTDynamicLinkedListElement<AType>* FindFirst();

		/*
			Returns a pointer to the next list element

			Returns:
				- Pointer to the next element in the list

			Notes:
				- Use the functions 'FindFirst' & 'FindNext' for faster enumeration
				- Use 'FindFirst'to find the first list element. If you use 'FindNext'
				  first it's possible that a crash occurs!
		*/
		ASTDynamicLinkedListElement<AType>* FindNext();

		/*
			Removes a element from the list

			Parameters:
				AType& pElementData -> The element that should be removed from the list

			Returns:
				bool -> 'false' if the element was found and removed else 'true'
		*/
		bool Remove(const AType& pElementData);

		/*
			Clears the whole list
		*/
		void Clear();


	private:
		int m_iElements;										// Number of elements
		ASTDynamicLinkedListElement<AType>* m_pFirstElement;	// Pointer to first list element
		ASTDynamicLinkedListElement<AType>* m_pLastElement;		// Pointer to last list element
		ASTDynamicLinkedListElement<AType>* m_pFoundElement;	// Pointer to the current found element
		ASTDynamicLinkedListElement<AType>* m_pCurrentElement;	// Pointer to the current found element (used for 'FindFirst' & 'FindNext')

		AType** m_pPointer;	// Pointer to all elements for faster access

};


/*
	Constructor
*/
template <class AType>
ASTDynamicLinkedList<AType>::ASTDynamicLinkedList()
{
	memset(this, 0, sizeof(ASTDynamicLinkedList));
}

template <class AType>
ASTDynamicLinkedList<AType>::ASTDynamicLinkedList(const AType& pNewElementData)
{
	memset(this, 0, sizeof(ASTDynamicLinkedList));
	Add(pNewElementData);
}

/*
	Destructor
*/
template <class AType>
ASTDynamicLinkedList<AType>::~ASTDynamicLinkedList()
{
	Clear();
}

/*
	Checks whether the list is complete empty
*/
template <class AType>
bool ASTDynamicLinkedList<AType>::IsEmpty() const
{
	if (!m_iElements) return true;
	return false;
}

/*
	Returns the number of list elements
*/
template <class AType>
int ASTDynamicLinkedList<AType>::GetElements() const
{
	return m_iElements;
}

/*
	Adds a new element to the list
*/
template <class AType>
bool ASTDynamicLinkedList<AType>::Add(const AType& pNewElementData)
{
	// Add the new element
	ASTDynamicLinkedListElement<AType>* pNewElement = new ASTDynamicLinkedListElement<AType>;
	pNewElement->pNextElement     = NULL;
	pNewElement->pPreviousElement = m_pLastElement;
	pNewElement->pData			  = new AType;
	memcpy(pNewElement->pData, &pNewElementData, sizeof(AType));
	
	// Update the old last element
	if (m_pLastElement)	m_pLastElement->pNextElement = pNewElement;

	// Update list
	m_iElements++;
	if (!m_pFirstElement) m_pFirstElement = pNewElement;
	m_pLastElement = pNewElement;

	m_pPointer = (AType**) realloc(m_pPointer, sizeof(AType*) * m_iElements);
	m_pPointer[m_iElements - 1] = pNewElement->pData;

	return false;
}

/*
	Checks whether the data is an element of the list or not
*/
template <class AType>
int ASTDynamicLinkedList<AType>::IsElement(const AType* pElementData)
{
	int i = 0;

	m_pFoundElement = m_pFirstElement;
	while (m_pFoundElement) {
		if (m_pFoundElement->pData == pElementData) return i;
		m_pFoundElement = m_pFoundElement->pNextElement;
		i++;
	}

	return -1;
}

/*
	Get the element data from the given index
*/
template <class AType>
AType* ASTDynamicLinkedList<AType>::operator [] (const int iIndex)
{
	if (iIndex < 0 || iIndex >= m_iElements) return NULL;

	return m_pPointer[iIndex];
}

/*
	Returns a pointer to the first list element
*/
template <class AType>
ASTDynamicLinkedListElement<AType>* ASTDynamicLinkedList<AType>::FindFirst()
{
	m_pCurrentElement = m_pFirstElement;

	return m_pCurrentElement;
}

/*
	Returns a pointer to the next list element
*/
template <class AType>
ASTDynamicLinkedListElement<AType>* ASTDynamicLinkedList<AType>::FindNext()
{
	if (m_pCurrentElement) m_pCurrentElement = m_pCurrentElement->pNextElement;
	else FindFirst();

	return m_pCurrentElement;
}

/*
	Removes a element from the list
*/
template <class AType>
bool ASTDynamicLinkedList<AType>::Remove(const AType& pElementData)
{
	int iElement;

	if ((iElement = IsElement(pElementData)) < 0) return true;

	// Update fast pointer
	for (int i = iElement; i < m_iElements - 1; i++)
		m_pPointer[i] = m_pPointer[i + 1];
	m_pPointer = (AType**) realloc(m_pPointer, sizeof(AType*) * m_iElements);

	// Update current element pointer
	if (m_pCurrentElement == m_pFoundElement) m_pCurrentElement = m_pFoundElement->pPreviousElement;

	// Update previous and next element
	if (m_pFoundElement->pNextElement)     m_pFoundElement->pNextElement->pPreviousElement = m_pFoundElement->pPreviousElement;
	if (m_pFoundElement->pPreviousElement) m_pFoundElement->pPreviousElement->pNextElement = m_pFoundElement->pNextElement;

	// Update list
	if (m_pFirstElement == m_pFoundElement) m_pFirstElement = m_pFoundElement->pNextElement;
	if (m_pLastElement == m_pFoundElement)  m_pLastElement  = m_pFoundElement->pPreviousElement;
	m_iElements--;

	// Delete the element
	if (m_pFoundElement) {
		if (m_pFoundElement->pData) delete m_pFoundElement->pData;
		delete m_pFoundElement;
		m_pFoundElement = NULL;
	}

	return false;
}

/*
	Clears the whole list
*/
template <class AType>
void ASTDynamicLinkedList<AType>::Clear()
{
	ASTDynamicLinkedListElement<AType>* pTempElement;
	
	m_pFoundElement = m_pFirstElement;
	while (m_pFoundElement) {
		pTempElement = m_pFoundElement;
		m_pFoundElement = m_pFoundElement->pNextElement;
		if (pTempElement->pData) delete pTempElement->pData;
		if (pTempElement) delete pTempElement;
	}

	// Update list
	m_iElements       = 0;
	m_pFirstElement   = NULL;
	m_pLastElement    = NULL;
	m_pFoundElement	  = NULL;
	m_pCurrentElement = NULL;
	if (m_pPointer) {
		free(m_pPointer);
		m_pPointer = NULL;
	}
}


#endif // __ASDYNAMICLINKEDLIST_H__
/*
	File: ASParser.cpp
*/

#include <ASEngineDll.h>


/*
	Starts the parsing of a buffer
*/
void ASTParser::StartParseBuffer(const unsigned char* pszBuffer, const long iSize)
{
	m_pszBufferStart = m_pszBuffer = pszBuffer;
	m_pszBufferEnd   = pszBuffer + iSize;
	m_iScriptLine    = 0;
	strcpy(m_szTokens, "");
}

/*
	Starts the parsing of a string
*/
void ASTParser::StartParseString(const char* pszString)
{
	m_pszBufferStart = m_pszBuffer = (unsigned char*) pszString;
	m_pszBufferEnd	 = (unsigned char*) pszString + strlen(pszString);
	m_iScriptLine    = 0;
	strcpy(m_szTokens, "");
}

/*
	Resets the parser
*/
void ASTParser::Reset()
{
	memset(this, 0, sizeof(ASTParser));
}

/*
	Get the next vaild tokens
*/
bool ASTParser::GetNextTokens(const bool bCrossLine)
{
	// Check pointer
	if (!m_pszBuffer || m_pszBuffer >= m_pszBufferEnd) return false;

	// Skip invalid tokens
	while (1) {
		// Check special tokens
		while (*m_pszBuffer <= 32 || *m_pszBuffer == '\n' || *m_pszBuffer == ';') {
			if (*m_pszBuffer == '\n') m_iScriptLine++;
			if (!bCrossLine && (*m_pszBuffer == '\n' || *m_pszBuffer == ';')) return false;
			m_pszBuffer++;
			if (m_pszBuffer >= m_pszBufferEnd) return false;
		}

		// # // Comments
		if (*m_pszBuffer == '#' || (m_pszBuffer[0] == '/' && m_pszBuffer[1] == '/')) {
			while (*m_pszBuffer++ != '\n') if (m_pszBuffer >= m_pszBufferEnd) return false;
			m_iScriptLine++;
			if (!bCrossLine) return false;
		} else break;

		// /* */ Comments
		if (m_pszBuffer[0] == '/' && m_pszBuffer[1] == '*') {
			m_pszBuffer += 2;
			while (m_pszBuffer[0] != '*' && m_pszBuffer[1] != '/') {
				m_pszBuffer++;
				if (m_pszBuffer >= m_pszBufferEnd) return false;
				if (*m_pszBuffer == '\n') m_iScriptLine++;
			}
			m_pszBuffer += 2;
		} else break;
	}

	// Copy vaild tokens
	char* pszTokens = m_szTokens;

	if (*m_pszBuffer == '"') { // Quoted token
		m_pszBuffer++;
		while (*m_pszBuffer != '"') {
			*pszTokens++ = *m_pszBuffer++;
			if (m_pszBuffer >= m_pszBufferEnd) break;
			if (pszTokens == &m_szTokens[ASPARSERMAXTOKENS]) break;
		}
		m_pszBuffer++;
	} else {	// Regular token
		if (*m_pszBuffer == '{' || *m_pszBuffer == '}') {
			*pszTokens++ = *m_pszBuffer++;

			return true;
		}
		while (*m_pszBuffer > 32 && *m_pszBuffer != '\n' &&
			   *m_pszBuffer != ';' && *m_pszBuffer !='{' && *m_pszBuffer !='}') {
			*pszTokens++ = *m_pszBuffer++;
			if (m_pszBuffer >= m_pszBufferEnd) break;
			if (pszTokens == &m_szTokens[ASPARSERMAXTOKENS]) break;
		}
	}

	return true;
}

/*
	Gets current found tokens
*/
const char* ASTParser::GetTokens() const
{
	return m_szTokens;
}

/*
	Returns the current script line
*/
int ASTParser::GetScriptLine() const
{
	return m_iScriptLine;
}
/*
	File: ASParser.h

	Description: Parser
*/


#ifndef __ASPARSER_H__
#define __ASPARSER_H__


// Definitions
#define ASPARSERMAXTOKENS 1024 // Maximum number of parser tokens


// Classes
typedef class ASTParser {

	public:

		/*
			Starts the parsing of a buffer

			Parameters:
				unsigned char* pszBuffer -> Pointer to the buffer
				int			   iSize	 -> Size of the buffer
		*/
		AS_API void StartParseBuffer(const unsigned char* pszBuffer, const long iSize);

		/*
			Starts the parsing of a string
		
			Parameters:
				char *pszString -> String that should be parsed
		*/
		AS_API void StartParseString(const char *pszString);

		/*
			Resets the parser
		*/
		AS_API void Reset();

		/*
			Get the next vaild tokens

			Parameters:
				bool bCrossLine -> If 'false' the parser will return 'false' when a line break was found

			Returns:
				bool -> 'true' if tokens were found else 'false' (buffer end or line break if bCrossLine is 'false')
		*/
		AS_API bool GetNextTokens(const bool bCrossLine = true);

		/*
			Gets current found tokens

			Returns:
				unsigned char* -> Pointer to the current found parser tokens
		*/
		AS_API const char* GetTokens() const;

		/*
			Returns the current script line

			Returns:
				int -> The current script line
		*/
		AS_API int GetScriptLine() const;


	private:
		const unsigned char* m_pszBuffer;		// Current buffer position pointer
		const unsigned char* m_pszBufferStart;	// Buffer start pointer
		const unsigned char* m_pszBufferEnd;	// Buffer end pointer

		char m_szTokens[ASPARSERMAXTOKENS];		// Buffer for tokens
		int  m_iScriptLine;						// The current script line


} ASTParser;


#endif // __ASPARSER_H__


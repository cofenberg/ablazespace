/*
	File: ASStack.h

	Description: Stack
				 You could set the stack size at its creation. If the stack is to small for a new
				 entry it will be expand automatically.
*/


#ifndef __ASSTACK_H__
#define __ASSTACK_H__


// Structures
template <class AType>
struct ASTStackElement {
	ASTStackElement* pNextElement;		// Pointer to the next element in the stack list
	ASTStackElement* pPreviousElement;	// Pointer to the previous element in the stack list
	AType* pData;						// The stored data

};


// Classes
template <class AType>
class ASTStack {

	public:
		/*
			Constructor
		*/
		ASTStack();
		ASTStack(const int iSize);

		/*
			Destructor
		*/
		~ASTStack();
		
		/*
			Push a new entry on the stack

			Parameters:
				AType& pData -> New stack entry
		*/
		bool Push(const AType& pData);

		/*
			Pops a the last entry from the stack

			Returns:
				AType -> Last stack entry
		*/
		AType Pop();

		/*
			Returns the number of stack elements
			
			Returns:
				int -> number of stack elements
		*/
		int GetElements() const;

		/*
			Get the element data from the given index

			Parameters:
				int iIndex -> Index of the element
		*/
		AType* operator [] (const int iIndex);

		/*
			Returns a pointer to the first stack element

			Returns:
				- Pointer to the first element in the stck

			Notes:
				- Use the functions 'FindFirst' & 'FindNext' for faster enumeration
				- Use 'FindFirst'to find the first stack element. If you use 'FindNext'
				  first it's possible that a crash occurs!
		*/
		ASTStackElement<AType>* FindFirst();

		/*
			Returns a pointer to the next stack element

			Returns:
				- Pointer to the next element in the stack

			Notes:
				- Use the functions 'FindFirst' & 'FindNext' for faster enumeration
				- Use 'FindFirst'to find the first stack element. If you use 'FindNext'
				  first it's possible that a crash occurs!
		*/
		ASTStackElement<AType>* FindNext();

		/*
			Clears the whole stack
		*/
		void Clear();


	private:
		int m_iElements;							// Number of elements
		ASTStackElement<AType>* m_pFirstElement;	// Pointer to first stack list element
		ASTStackElement<AType>* m_pLastElement;		// Pointer to last stack list element
		ASTStackElement<AType>* m_pFoundElement;	// Pointer to the current found element
		ASTStackElement<AType>* m_pCurrentElement;	// Pointer to the current found element (used for 'FindFirst' & 'FindNext')

		AType** m_pPointer;	// Pointer to all elements for faster access

		int m_iUsed;	// Number of used stack elements


		/*
			Adds a new element to the stack

			Parameters:
				AType& pNewElementData -> The data of the new stack element
		*/
		bool Add(const AType& pNewElementData);


};


/*
	Constructor
*/
template <class AType>
ASTStack<AType>::ASTStack()
{
	AType Temp;

	memset(this, 0, sizeof(ASTStack));
	Add(Temp)
}

template <class AType>
ASTStack<AType>::ASTStack(const int iSize)
{
	AType Temp;

	memset(this, 0, sizeof(ASTStack));
	for (int i = 0; i < iSize; i++) Add(Temp);
}

/*
	Destructor
*/
template <class AType>
ASTStack<AType>::~ASTStack()
{
	Clear();
}

/*
	Push a new entry on the stack
*/
template <class AType>
bool ASTStack<AType>::Push(const AType& pData)
{
	if (m_iUsed >= GetElements()) Add(pData);
	else						  memcpy(m_pPointer[m_iUsed], &pData, sizeof(AType));
	m_iUsed++;

	return false;
}

/*
	Pops a the last entry from the stack
*/
template <class AType>
AType ASTStack<AType>::Pop()
{
	m_iUsed--;
	
	if (m_iUsed < 0) {
		m_iUsed = 0;

		return *m_pPointer[0];
	}

	return *m_pPointer[m_iUsed];
}

/*
	Returns the number of stack elements
*/
template <class AType>
int ASTStack<AType>::GetElements() const
{
	return m_iElements;
}

/*
	Get the element data from the given index
*/
template <class AType>
AType* ASTStack<AType>::operator [] (const int iIndex)
{
	if (iIndex < 0 || iIndex >= m_iElements) return NULL;

	return m_pPointer[iIndex];
}

/*
	Returns a pointer to the first stack element
*/
template <class AType>
ASTStackElement<AType>* ASTStack<AType>::FindFirst()
{
	m_pCurrentElement = m_pFirstElement;

	return m_pCurrentElement;
}

/*
	Returns a pointer to the next stack element
*/
template <class AType>
ASTStackElement<AType>* ASTStack<AType>::FindNext()
{
	if (m_pCurrentElement) m_pCurrentElement = m_pCurrentElement->pNextElement;
	else FindFirst();

	return m_pCurrentElement;
}

/*
	Clears the whole stack
*/
template <class AType>
void ASTStack<AType>::Clear()
{
	ASTStackElement<AType>* pTempElement;
	
	m_pFoundElement = m_pFirstElement;
	while (m_pFoundElement) {
		pTempElement = m_pFoundElement;
		m_pFoundElement = m_pFoundElement->pNextElement;
		if (pTempElement->pData) delete pTempElement->pData;
		if (pTempElement) delete pTempElement;
	}

	// Update stack list
	m_iElements       = 0;
	m_pFirstElement   = NULL;
	m_pLastElement    = NULL;
	m_pFoundElement	  = NULL;
	m_pCurrentElement = NULL;
	if (m_pPointer) {
		free(m_pPointer);
		m_pPointer = NULL;
	}
	m_iUsed			  = 0;
}

/*
	Adds a new element to the stack
*/
template <class AType>
bool ASTStack<AType>::Add(const AType& pNewElementData)
{
	// Add the new element
	ASTStackElement<AType>* pNewElement = new ASTStackElement<AType>;
	pNewElement->pNextElement     = NULL;
	pNewElement->pPreviousElement = m_pLastElement;
	pNewElement->pData			  = new AType;
	memcpy(pNewElement->pData, &pNewElementData, sizeof(AType));
	
	// Update the old last element
	if (m_pLastElement)	m_pLastElement->pNextElement = pNewElement;

	// Update stack list
	m_iElements++;
	if (!m_pFirstElement) m_pFirstElement = pNewElement;
	m_pLastElement = pNewElement;

	m_pPointer = (AType**) realloc(m_pPointer, sizeof(AType*) * m_iElements);
	m_pPointer[m_iElements - 1] = pNewElement->pData;

	return false;
}


#endif // __ASSTACK_H__
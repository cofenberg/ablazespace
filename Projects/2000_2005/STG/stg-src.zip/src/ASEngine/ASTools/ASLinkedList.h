/*
	File: ASLinkedList.h

	Description: Linked list
				 Uses only pointers to existing data.
*/


#ifndef __ASLINKEDLIST_H__
#define __ASLINKEDLIST_H__


// Structures
template <class AType>
struct ASTLinkedListElement {
public:
	ASTLinkedListElement* pNextElement;		// Pointer to the next element in the list
	ASTLinkedListElement* pPreviousElement; // Pointer to the previous element in the list
	AType Data;								// The stored data

};


// Classes
template <class AType>
class ASTLinkedList {

	public:
		/*
			Constructor
		*/
		ASTLinkedList();
		ASTLinkedList(const AType& pNewElementData);

		/*
			Destructor
		*/
		~ASTLinkedList();
		
		/*
			Checks whether the list is complete empty

			Returns:
				bool -> 'true' if the list is empty else 'false'
		*/
		bool IsEmpty() const;
		
		/*
			Returns the number of list elements
			
			Returns:
				int -> number of list elements
		*/
		int GetElements() const;

		/*
			Adds a new element to the list

			Parameters:
				AType& pNewElementData -> The data of the new list element
		*/
		bool Add(const AType& pNewElementData);

		/*
			Checks whether the data is an element of the list or not

			Parameters:
				AType& pElementData -> The data which should be checked

			Returns:
				int -> The ID of the list element. '-1' if it's no a list entry
		*/
		int IsElement(const AType& pElementData);

		/*
			Get the element data from the given index

			Parameters:
				int iIndex -> Index of the element
		*/
		AType& operator [] (const int iIndex);

		/*
			Returns a pointer to the first list element

			Returns:
				- Pointer to the first element in the list

			Notes:
				- Use the functions 'FindFirst' & 'FindNext' for faster enumeration
				- Use 'FindFirst'to find the first list element. If you use 'FindNext'
				  first it's possible that a crash occurs!
		*/
		ASTLinkedListElement<AType>* FindFirst();

		/*
			Returns a pointer to the next list element

			Returns:
				- Pointer to the next element in the list

			Notes:
				- Use the functions 'FindFirst' & 'FindNext' for faster enumeration
				- Use 'FindFirst'to find the first list element. If you use 'FindNext'
				  first it's possible that a crash occurs!
		*/
		ASTLinkedListElement<AType>* FindNext();

		/*
			Removes a element from the list

			Parameters:
				AType& pElementData -> The element that should be removed from the list

			Returns:
				bool -> 'false' if the element was found and removed else 'true'
		*/
		bool Remove(const AType& pElementData);

		/*
			Clears the whole list
		*/
		void Clear();


	private:
		int m_iElements;							    // Number of elements
		ASTLinkedListElement<AType>* m_pFirstElement;   // Pointer to first list element
		ASTLinkedListElement<AType>* m_pLastElement;    // Pointer to last list element
		ASTLinkedListElement<AType>* m_pFoundElement;	// Pointer to the current found element
		ASTLinkedListElement<AType>* m_pCurrentElement;	// Pointer to the current found element (used for 'FindFirst' & 'FindNext')

		AType* m_pPointer;	// Pointer to all elements for faster access


};


/*
	Constructor
*/
template <class AType>
ASTLinkedList<AType>::ASTLinkedList()
{
	memset(this, 0, sizeof(ASTLinkedList));
}

template <class AType>
ASTLinkedList<AType>::ASTLinkedList(const AType& pNewElementData)
{
	memset(this, 0, sizeof(ASTLinkedList));
	Add(pNewElementData);
}

/*
	Destructor
*/
template <class AType>
ASTLinkedList<AType>::~ASTLinkedList()
{
	Clear();
}

/*
	Checks whether the list is complete empty
*/
template <class AType>
bool ASTLinkedList<AType>::IsEmpty() const
{
	if (!m_iElements) return true;
	return false;
}

/*
	Returns the number of list elements
*/
template <class AType>
int ASTLinkedList<AType>::GetElements() const
{
	return m_iElements;
}

/*
	Adds a new element to the list
*/
template <class AType>
bool ASTLinkedList<AType>::Add(const AType& pNewElementData)
{
	// Check if this is already an element
	if (IsElement(pNewElementData) >= 0) return true;
	
	// Add the new element
	ASTLinkedListElement<AType>* pNewElement = new ASTLinkedListElement<AType>;
	pNewElement->pNextElement     = NULL;
	pNewElement->pPreviousElement = m_pLastElement;
	pNewElement->Data			  = pNewElementData;
	
	// Update the old last element
	if (m_pLastElement)	m_pLastElement->pNextElement = pNewElement;

	// Update list
	m_iElements++;
	if (!m_pFirstElement) m_pFirstElement = pNewElement;
	m_pLastElement = pNewElement;

	m_pPointer = (AType*) realloc(m_pPointer, sizeof(AType*) * m_iElements);
	m_pPointer[m_iElements - 1] = pNewElement->Data;

	return false;
}

/*
	Checks whether the data is an element of the list or not
*/
template <class AType>
int ASTLinkedList<AType>::IsElement(const AType& pElementData)
{
	int i = 0;

	m_pFoundElement = m_pFirstElement;
	while (m_pFoundElement) {
		if (m_pFoundElement->Data == pElementData) return i;
		m_pFoundElement = m_pFoundElement->pNextElement;
		i++;
	}

	return -1;
}

/*
	Get the element data from the given index
*/
template <class AType>
AType& ASTLinkedList<AType>:: operator [] (const int iIndex)
{
	if (iIndex < 0 || iIndex >= m_iElements) return m_pFirstElement->Data;

	return m_pPointer[iIndex];
}

/*
	Returns a pointer to the first list element
*/
template <class AType>
ASTLinkedListElement<AType>* ASTLinkedList<AType>::FindFirst()
{
	m_pCurrentElement = m_pFirstElement;

	return m_pCurrentElement;
}

/*
	Returns a pointer to the next list element
*/
template <class AType>
ASTLinkedListElement<AType>* ASTLinkedList<AType>::FindNext()
{
	if (m_pCurrentElement) m_pCurrentElement = m_pCurrentElement->pNextElement;
	else FindFirst();

	return m_pCurrentElement;
}

/*
	Removes a element from the list
*/
template <class AType>
bool ASTLinkedList<AType>::Remove(const AType& pElementData)
{
	int iElement;

	if ((iElement = IsElement(pElementData)) < 0) return true;

	// Update fast pointer
	for (int i = iElement; i < m_iElements - 1; i++)
		m_pPointer[i] = m_pPointer[i + 1];
	m_pPointer = (AType*) realloc(m_pPointer, sizeof(AType*) * m_iElements);

	// Update current element pointer
	if (m_pCurrentElement == m_pFoundElement) m_pCurrentElement = m_pFoundElement->pPreviousElement;

	// Update previous and next element
	if (m_pFoundElement->pNextElement)     m_pFoundElement->pNextElement->pPreviousElement = m_pFoundElement->pPreviousElement;
	if (m_pFoundElement->pPreviousElement) m_pFoundElement->pPreviousElement->pNextElement = m_pFoundElement->pNextElement;

	// Update list
	if (m_pFirstElement == m_pFoundElement) m_pFirstElement = m_pFoundElement->pNextElement;
	if (m_pLastElement == m_pFoundElement)  m_pLastElement  = m_pFoundElement->pPreviousElement;
	m_iElements--;

	// Delete the element
	if (m_pFoundElement) {
		delete m_pFoundElement;
		m_pFoundElement = NULL;
	}

	return false;
}

/*
	Clears the whole list
*/
template <class AType>
void ASTLinkedList<AType>::Clear()
{
	ASTLinkedListElement<AType>* pTempElement;
	
	m_pFoundElement = m_pFirstElement;
	while (m_pFoundElement) {
		pTempElement = m_pFoundElement;
		m_pFoundElement = m_pFoundElement->pNextElement;
		if (pTempElement) delete pTempElement;
	}

	// Update list
	m_iElements		  = 0;
	m_pFirstElement   = NULL;
	m_pLastElement    = NULL;
	m_pFoundElement   = NULL;
	m_pCurrentElement = NULL;

	if (m_pPointer) {
		free(m_pPointer);
		m_pPointer = NULL;
	}
}


#endif // __ASLINKEDLIST_H__
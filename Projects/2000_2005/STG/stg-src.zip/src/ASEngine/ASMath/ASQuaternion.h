/*
	File: ASQuaternion.h

	Description: Quaternion stuff
*/

#ifndef __ASQUATERNION_H_
#define __ASQUATERNION_H_


// Classes
typedef class ASTQuaternion {

	public:
		enum { W, X, Y, Z };

		union {
			float fQ[4];
			struct {
				float fW, fX, fY, fZ;
			};
		};


		// Constructor
		AS_API ASTQuaternion();
		AS_API ASTQuaternion(const ASTQuaternion& qCopyFrom);
		AS_API ASTQuaternion(const float& fXT, const float& fYT, const float& fZT);
		AS_API ASTQuaternion(const float& fAngle, const float& fXT, const float& fYT, const float& fZT);

		// Quaternion
		AS_API ASTQuaternion operator + (const ASTQuaternion& qQ) const;
		AS_API ASTQuaternion operator * (const float& f) const;
		AS_API ASTQuaternion operator * (const ASTQuaternion& qQ) const;

		// Misc
		AS_API ASTQuaternion& Reset();
		AS_API ASTQuaternion& Set(const ASTQuaternion& qCopyFrom);
		AS_API ASTQuaternion& Set(const float& fXT, const float& fYT, const float& fZT);
		AS_API ASTQuaternion& Set(const float& fAngle, const float& fXT, const float& fYT, const float& fZT);
		AS_API ASTQuaternion& PostMult(const ASTQuaternion& qQ);
		AS_API float DotProduct() const;
		AS_API float DotProduct(const ASTQuaternion& qQ) const;
		AS_API float GetLength() const;
		AS_API ASTQuaternion& MultAndSet(const ASTQuaternion& qQ1, const ASTQuaternion& qQ2);
		AS_API ASTQuaternion& Normalize();
		AS_API ASTQuaternion Inversed();
		AS_API void GetMatrix(ASTMatrix4x4* pmM) const;
		AS_API void GetInvertedMatrix(ASTMatrix4x4* pmM) const;
		AS_API void SetMatrix(ASTMatrix4x4& mM);
		AS_API void GetAxisAngle(float& fAxisX, float& fAxisY, float& fAxisZ, float& fRotAngle) const;
		AS_API void GetDirectionVector(ASTVector3D* vDir);
		AS_API void EulerToQuat(const float& fEX, const float& fEY, const float& fEZ);
		AS_API void GetEulerAngles(float &fX, float &fY, float &fZ) const;
		AS_API void Slerp(const ASTQuaternion& qQ1, const ASTQuaternion& qQ2, const float& fTime);
		AS_API void SquadSlerp(const ASTQuaternion& qA, const ASTQuaternion& qP, const ASTQuaternion& qQ, ASTQuaternion& qB, float& fTime);
		AS_API void Invert();
		AS_API void Mult(const ASTQuaternion& qA, const ASTQuaternion& qB);
		AS_API void Ln();
		AS_API void LnDif(const ASTQuaternion& qA, const ASTQuaternion& qB);
		AS_API void Exp();
		AS_API void InnerPoint(const ASTQuaternion& qP, const ASTQuaternion& qQ, const ASTQuaternion& qN);


} ASTQuaternion;


#endif	// __ASQUATERNION_H_
/*
	File: ASMath.h

	Description: Math stuff
*/


#ifndef __ASMATH_H__
#define __ASMATH_H__


// Definitions
#define AS_PI		  3.14159265358979
#define AS_PI_2		  1.57079632679489661923
#define AS_DEG_TO_RAD 0.0174532925199432957692369076848861
#define AS_RAD_TO_DEG 57.29577951
#define AS_EPSILON	  1e-12
#define AS_EPSILON2	  0.05f
enum {X, Y, Z};
enum {R, G, B, A};


// Macros
#define AS_MAX(a, b) (a > b ? a : b)
#define AS_SWAP(a, b) { float fTmp = a; a = b; b = fTmp; }


// Includes
#include <math.h>


// Classes
typedef class ASTMath {

	friend _AS;


	public:
		/*
			Check if the number of a power of 2

			Parameters:
				int iDimension -> number that should be checked

			Returns:
				bool -> 'true' if the number is a power of 2 else 'false'
		*/
		AS_API bool IsPowerOfTwo(const int iNumber) const;

		/*
			Returns the nearest power of 2

			Parameters:
				int iDimension -> number that should be checked

			Returns:
				int -> The nearest power of 2, if it couldn't be found 'iNumber'
		*/
		AS_API int GetNearestPowerOfTwo(const int iNumber) const;


	private:
		/*
			Initialize the math stuff

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Init();

		/*
			Builds the square root table

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool BuildSqrtTable();


} ASTMath;


/////////////////////////////////////////////////////////////////////////////////////////
// Some auxiliary functions.
// They are inlined because they should be that fast as possible.
// Use them especally in bottle necks!
/////////////////////////////////////////////////////////////////////////////////////////
/*	
	Optimized dot product

	Parameters:
		ASFLOAT3 fV1 & vV2 -> The two vectors

	Returns:
		float -> The dot product of the two vectors

	Notes:
		- This function is quite faster as the other vector class dot product
*/
AS_API extern float inline __cdecl ASDotProduct(const ASFLOAT3 fV1, const ASFLOAT3 fV2);
AS_API extern float inline __cdecl ASDotProduct(const float f1, const float f2);

/*	
	Optimized cross product

	Parameters:
		ASFLOAT3 fV1 & vV2 -> The two vectors
		ASFLOAT3 fRes	   -> The cross product of the two vectors

	Notes:
		- This function is quite faster as the other vector class cross product
*/
AS_API extern void inline __cdecl ASCrossProduct(const ASFLOAT3 fV1, const ASFLOAT3 fV2, ASFLOAT3& fRes);

/*
	Fast fabs funtion

	Parameters:
		float fNumber -> Number from which the absolut value should be returned

	Returns:
		float -> Absolut value of the given number
*/
AS_API extern float inline __fastcall ASAbs(const float fNumber);

/*
	Fast sin function

	Parameters:
		float fNumber -> angle in radians

	Returns:
		float -> Sinus of the given angle
*/
AS_API extern float inline __fastcall ASSin(const float fNumber);

/*
	Fast asin function

	Parameters:
		float fNumber -> angle in radians

	Returns:
		float -> Arcos sinus of the given angle
*/
AS_API extern float inline __fastcall ASASin(const float fNumber);

/*
	Fast cos function

	Parameters:
		float fNumber -> angle in radians

	Returns:
		float -> Cosinus of the given angle
*/
AS_API extern float inline __fastcall ASCos(const float fNumber);

/*
	Fast square root computation

	Parameters:
		float f -> The number from which the square root should be computed

	Returns:
		float -> The square root of the number

	Notes:
		- This function is a litte bit faster as the normal sqrt function
		- Use it in bottle necks
*/
AS_API extern inline float ASSqrt(const float f);

/*
	Adds two vectors

	Parameters:
		ASFLOAT3& fV1 & fV1 -> The two vectors which should be added
		ASFLOAT3& pfRes		-> Resulting vector
*/
AS_API extern inline void ASAddVector(const ASFLOAT3& fV1, const ASFLOAT3& fV2, ASFLOAT3& pfRes);

/*
	Subtracts two vectors

	Parameters:
		ASFLOAT3& fV1 & fV1 -> The two vectors which should be subtracted
		ASFLOAT3& pfRes		-> Resulting vector
*/
AS_API extern inline void ASSubVector(const ASFLOAT3& fV1, const ASFLOAT3& fV2, ASFLOAT3& pfRes);

/*
	Multiplies to vectors

	Parameters:
		ASFLOAT3& fV1 & fV1 -> The two vectors which should be multiplied
		ASFLOAT3& pfRes		-> Resulting vector
*/
AS_API extern inline void ASMulVector(const ASFLOAT3& fV1, const ASFLOAT3& fV2, ASFLOAT3& pfRes);

/*
	Scales a vector

	Parameters:
		ASFLOAT3& fV1   -> The vector which should scale
		ASFLOAT3& pfRes -> Resulting vector
*/
AS_API extern inline void ASScaleVector(const ASFLOAT3& fV, const float& fScale, ASFLOAT3& pfRes);

/*
	Inverts a vector

	Parameters:
		ASFLOAT3& fV1   -> The vector which should be inverted
		ASFLOAT3& pfRes -> Resulting vector
*/
AS_API extern inline void ASInvertVector(const ASFLOAT3& fV, ASFLOAT3& pfRes);

/*
	Computes the normal of a given triangle

	Parameters:
		ASFLOAT3& fV1 & fV1 & fV1 -> The three vectors describing the triangle
		ASFLOAT3& pfRes			  -> Normalized triangle normal
*/
AS_API inline void ASNormalizeTriangle(const ASFLOAT3& fV1, const ASFLOAT3& fV2, const ASFLOAT3& fV3, ASFLOAT3& pfRes);


// Other math includes
#include "ASMatrix4x4.h"
#include "ASVector2D.h"
#include "ASVector3D.h"
#include "ASPlane.h"
#include "ASQuaternion.h"


#endif // __ASMATH_H__
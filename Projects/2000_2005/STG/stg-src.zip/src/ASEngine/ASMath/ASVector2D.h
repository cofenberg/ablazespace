/*
	File: ASVector2D.h

	Description: 2D vector
*/


#ifndef __ASVECTOR2D_H__
#define __ASVECTOR2D_H__


// Classes
typedef class ASTVector2D {

	public:
		enum { X, Y };

		union {
			float fV[2];
			struct {
				float fX, fY;
			};
		};


		// Constructor
		AS_API ASTVector2D();
		AS_API ASTVector2D(const float& fXT, const float& fYT);
		AS_API ASTVector2D(const float* fV);
		AS_API ASTVector2D(const ASTVector2D& vV);

		// Assignment operators
		AS_API ASTVector2D& operator = (const float* fV);
		AS_API ASTVector2D& operator = (const ASTVector2D& vV);
		AS_API ASTVector2D& operator = (const float& fD);

		// Comparison
		AS_API bool operator == (const ASTVector2D& vV) const;
		AS_API bool operator != (const ASTVector2D& vV) const;
		AS_API bool operator == (const float& f) const;
		AS_API bool operator != (const float& f) const;

		// Vector
		AS_API ASTVector2D  operator +  (const ASTVector2D& vV) const;
		AS_API ASTVector2D  operator +  (const float& fN) const;
		AS_API ASTVector2D& operator += (const ASTVector2D& vV);
		AS_API ASTVector2D& operator += (const float& fN);
	    AS_API ASTVector2D  operator -  () const;
		AS_API ASTVector2D  operator -  (const float& fN) const;
		AS_API ASTVector2D  operator -  (const ASTVector2D& vV) const;
		AS_API ASTVector2D& operator -= (const ASTVector2D& vV);
		AS_API ASTVector2D& operator -= (const float& fN);
		AS_API ASTVector2D  operator *  (const ASTVector2D& vV) const;
		AS_API ASTVector2D  operator *  (const float& fS) const;
		AS_API ASTVector2D& operator *= (const ASTVector2D& vV);
		AS_API ASTVector2D& operator *= (const float& fS);
		AS_API ASTVector2D  operator /  (const ASTVector2D& vV) const;
		AS_API ASTVector2D  operator /  (const float& fS) const;
		AS_API ASTVector2D& operator /= (const ASTVector2D& vV);
		AS_API ASTVector2D& operator /= (const float& fS);

		// Misc
		AS_API float GetX() const;
		AS_API float GetY() const;
		AS_API void SetXY(const float& fXT, const float& fYT);
		AS_API float GetLength() const;
		AS_API void SetLength(const float& fL);
		AS_API ASTVector2D& Normalize();
		AS_API ASTVector2D GetNormalized() const;
		AS_API void Invert();
		AS_API float DotProduct() const;
		AS_API float DotProduct(const ASTVector2D& vV) const;
		AS_API bool IsNull() const;


} ASTVector2D;


#endif // __ASVECTOR2D_H__
/*
	File: ASVector3D.cpp
*/

#include <ASEngineDll.h>


// Constructor
ASTVector3D::ASTVector3D()
{
	fX = fY = fZ = 0.f;
}

ASTVector3D::ASTVector3D(const float& fXT, const float& fYT, const float& fZT)
{
	fX = fXT, fY = fYT, fZ = fZT;
}

ASTVector3D::ASTVector3D(const float* fV)
{
	*this = fV;
}

ASTVector3D::ASTVector3D(const ASTVector3D& vV)
{
	*this = vV;
}

// Assignment operators
ASTVector3D& ASTVector3D::operator = (const ASTVector3D& vV)
{
	fX = vV.fX, fY = vV.fY, fZ = vV.fZ;

	return *this;
}

ASTVector3D& ASTVector3D::operator = (const float* fV)
{
	fX = *fV++, fY = *fV++, fZ = *fV;

	return *this;
}

ASTVector3D& ASTVector3D::operator = (const float& fD)
{
	fX = fY = fZ = fD;

	return *this;
}

// Comparison
bool ASTVector3D::operator == (const ASTVector3D& vV) const
{
	return fX == vV.fX && fY == vV.fY && fZ == vV.fZ;
}

bool ASTVector3D::operator != (const ASTVector3D& vV) const
{
	return !(*this == vV);
}

bool ASTVector3D::operator == (const float& f) const
{
	return fX == f && fY == f && fZ == f;
}

bool ASTVector3D::operator != (const float& f) const
{
	return !(*this == f);
}

// Vector
ASTVector3D ASTVector3D::operator + (const ASTVector3D& vV) const
{
	return ASTVector3D(fX + vV.fX, fY + vV.fY, fZ + vV.fZ);
}

ASTVector3D ASTVector3D::operator + (const float& fN) const
{
	return ASTVector3D(fX + fN, fY + fN, fZ + fN);
}

ASTVector3D& ASTVector3D::operator += (const ASTVector3D& vV)
{
	fX += vV.fX, fY += vV.fY, fZ += vV.fZ;

	return *this;
}

ASTVector3D& ASTVector3D::operator += (const float& fN)
{
	fX += fN, fY += fN, fZ += fN;

	return *this;
}

ASTVector3D ASTVector3D::operator - () const
{
	return ASTVector3D(-fX, -fY, -fZ);
}

ASTVector3D ASTVector3D::operator - (const ASTVector3D& vV) const
{
	return ASTVector3D(fX - vV.fX, fY - vV.fY, fZ - vV.fZ);
}

ASTVector3D ASTVector3D::operator - (const float& fN) const
{
	return ASTVector3D(fX - fN, fY - fN, fZ - fN);
}

ASTVector3D& ASTVector3D::operator -= (const ASTVector3D& vV)
{
	fX -= vV.fX, fY -= vV.fY, fZ -= vV.fZ;

	return *this;
}

ASTVector3D& ASTVector3D::operator -= (const float& fN)
{
	fX -= fN, fY -= fN, fZ -= fN;

	return *this;
}

ASTVector3D ASTVector3D::operator * (const ASTVector3D& vV) const 
{
	return ASTVector3D(fX * vV.fX, fY * vV.fY, fZ * vV.fZ);
}

ASTVector3D ASTVector3D::operator * (const float& fS) const
{
	return ASTVector3D(fX * fS, fY * fS, fZ * fS);
}

ASTVector3D& ASTVector3D::operator *= (const ASTVector3D& vV)
{
	fX *= vV.fX, fY *= vV.fY, fZ *= vV.fZ;

	return *this;
}

ASTVector3D& ASTVector3D::operator *= (const float& fS)
{
	fX *= fS, fY *= fS, fZ *= fS;

	return *this;
}

ASTVector3D ASTVector3D::operator / (const ASTVector3D& vV) const
{
	return ASTVector3D(fX / vV.fX, fY / vV.fY, fZ / vV.fZ);
}

ASTVector3D ASTVector3D::operator / (const float& fS) const
{
	return operator * (1.f / fS);
}

ASTVector3D& ASTVector3D::operator /= (const ASTVector3D& vV)
{
	fX /= vV.fX, fY /= vV.fY, fZ /= vV.fZ;

	return *this;
}

ASTVector3D& ASTVector3D::operator /= (const float& fS)
{
	*this *= 1.f / fS;

	return *this;
}

// Misc
float ASTVector3D::GetX() const
{
	return fX;
}

float ASTVector3D::GetY() const
{
	return fY;
}

float ASTVector3D::GetZ() const
{
	return fZ;
}

void ASTVector3D::SetXYZ(const float& fXT, const float& fYT, const float& fZT)
{
	fX = fXT; fY = fYT; fZ = fZT;
}

float ASTVector3D::GetLength() const
{
	return (float) ASSqrt(fX * fX + fY * fY + fZ * fZ);
}

void ASTVector3D::SetLength(const float& fL)
{
	*this *= fL / (float) ASSqrt(fX * fX + fY * fY + fZ * fZ);
}

ASTVector3D& ASTVector3D::Normalize()
{
	float fU = fX * fX + fY * fY + fZ * fZ;
	if (fabs(fU - 1.f) < AS_EPSILON) return *this;
	fU = 1.f / (float) ASSqrt(fU);
	*this *= fU;

	return *this;
}

ASTVector3D ASTVector3D::GetNormalized() const
{
	return ASTVector3D(*this).Normalize();
}

ASTVector3D ASTVector3D::CrossProduct(const ASTVector3D& vV) const
{
	return ASTVector3D((fY * vV.fZ) - (fZ * vV.fY),
					   (fZ * vV.fX) - (fX * vV.fZ),
					   (fX * vV.fY) - (fY * vV.fX));
}

void ASTVector3D::CrossProduct(const ASTVector3D& vV1, const ASTVector3D& vV2)
{
	fX = (vV1.fY * vV2.fZ) - (vV1.fZ * vV2.fY);
	fY = (vV1.fZ * vV2.fX) - (vV1.fX * vV2.fZ);
	fZ = (vV1.fX * vV2.fY) - (vV1.fY * vV2.fX);
}

void ASTVector3D::GetFaceNormal(const ASTVector3D& vV1, const ASTVector3D& vV2, const ASTVector3D& vV3)
{
	CrossProduct(vV1 - vV2, vV1 - vV3);
	Normalize();
}

void ASTVector3D::GetRightUp(ASTVector3D& vRight, ASTVector3D& vUp) const
{ // Get the right and up vectors of a given normal
	ASTVector3D vFN((float) ASAbs(fX), (float) ASAbs(fY), (float) ASAbs(fZ));
	if (vFN.fX > 1.f) vFN.fZ = 1.f;
	if (vFN.fY > 1.f) vFN.fY = 1.f;
	if (vFN.fZ > 1.f) vFN.fZ = 1.f;
	int iMajor = 0;
	ASTVector3D vAxis[3] = {
	   ASTVector3D(1.f, 0.f, 0.f),
	   ASTVector3D(0.f, 1.f, 0.f),
	   ASTVector3D(0.f, 0.f, 1.f)
	};

	// Find the major axis:
	if (vFN.fY > vFN.fV[iMajor]) iMajor = Y;
	if (vFN.fZ > vFN.fV[iMajor]) iMajor = Z;

	// Build right vector by hand: (faster)
	if (vFN.fX == 1.f || vFN.fY == 1.f || vFN.fZ == 1.f) {
		if (!iMajor && fX > 0.f) vRight.SetXYZ(0.f, 0.f, -1.f);
		else if (!iMajor) vRight.SetXYZ(0.f, 0.f, 1.f);

	  if (iMajor == 1 || (iMajor == 2 && fZ > 0.f)) vRight.SetXYZ(1.f, 0.f, 0.f);
	  if (iMajor == 2 && fZ < 0.f) vRight.SetXYZ(-1.f, 0.f, 0.f);
	}
	else vRight.CrossProduct(vAxis[iMajor], *this);
	vUp.CrossProduct(*this, vRight);
	vRight.Normalize();
	vUp.Normalize();
}

void ASTVector3D::ProjectVector(const ASTVector3D& vV, ASTVector3D& vRes) const
{ // Project the vector onto the vector 'vV'
   vRes = vV;
   vRes *= ((vV.DotProduct(*this)) / (vV.DotProduct()));
}

void ASTVector3D::ProjectPlane(const ASTVector3D& vV1, const ASTVector3D& vV2, ASTVector3D& vRes) const
{ // Project the vector on to the plane created by 'vV1' and 'vV2'. 'vV1' and
  // 'vV2' MUST be perpindicular to eachother!
   ASTVector3D vT1, vT2;
   ProjectVector(vV1, vT1);
   ProjectVector(vV2, vT2);
   vRes = vT1 + vT2;
}

float ASTVector3D::AngleBetween(const ASTVector3D& vV) const
{
	return (DotProduct(vV) / (GetLength() * vV.GetLength()));
}

void ASTVector3D::Invert()
{
	fX = -fX; fY = -fY; fZ = -fZ;
}

float ASTVector3D::DotProduct() const
{
	return fX * fX + fY * fY + fZ * fZ;
}

float ASTVector3D::DotProduct(const ASTVector3D& vV) const
{
	return fX * vV.fX + fY * vV.fY + fZ * vV.fZ;
}

bool ASTVector3D::IsNull() const
{
	if(!fX && !fY && !fZ) return true;
	else return false;
}

void ASTVector3D::Rotate(ASTMatrix4x4& mM, ASTVector3D& vV)
{
	fX = (mM.fM[0] * vV.fX) + (mM.fM[4] * vV.fY) + (mM.fM[ 8]  * vV.fZ); // Rotate around the x axis
	fY = (mM.fM[1] * vV.fX) + (mM.fM[5] * vV.fY) + (mM.fM[ 9]  * vV.fZ); // Rotate around the y axis
	fZ = (mM.fM[2] * vV.fX) + (mM.fM[6] * vV.fY) + (mM.fM[10]  * vV.fZ); // Rotate around the z axis
}
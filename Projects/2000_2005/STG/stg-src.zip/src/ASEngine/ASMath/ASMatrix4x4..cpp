/*
	File: ASMatrix4x4.cpp
*/

#include <ASEngineDll.h>


ASTMatrix4x4::ASTMatrix4x4()
{
	LoadIdentity();
}

ASTMatrix4x4::ASTMatrix4x4(const float* fS)
{
	*this = fS;
}

ASTMatrix4x4::ASTMatrix4x4(const ASTMatrix4x4& mM)
{
	*this = mM;
}

ASTMatrix4x4& ASTMatrix4x4::operator = (const ASTMatrix4x4& mM)
{
	fXX = mM.fXX, fXY = mM.fXY, fXZ = mM.fXZ, fXW = mM.fXW;
	fYX = mM.fYX, fYY = mM.fYY, fYZ = mM.fYZ, fYW = mM.fYW;
	fZX = mM.fZX, fZY = mM.fZY, fZZ = mM.fZZ, fZW = mM.fZW;
	fWX = mM.fWX, fWY = mM.fWY, fWZ = mM.fWZ, fWW = mM.fWW;

	return *this;
}

ASTVector3D ASTMatrix4x4::operator * (const ASTVector3D& vV) const
{
	return ASTVector3D(vV.fX * fXX + vV.fY * fXY + vV.fZ * fXZ + fXW,
					   vV.fX * fYX + vV.fY * fYY + vV.fZ * fYZ + fYW,
					   vV.fX * fZX + vV.fY * fZY + vV.fZ * fZZ + fZW);
}

ASTMatrix4x4 ASTMatrix4x4::operator * (const ASTMatrix4x4& mM) const
{
	ASTMatrix4x4 mMT;

	mMT.fM[ 0] = fM[0] * mM.fM[ 0] + fM[4] * mM.fM[ 1] + fM[ 8] * mM.fM[ 2] + fM[12] * mM.fM[ 3];
	mMT.fM[ 1] = fM[1] * mM.fM[ 0] + fM[5] * mM.fM[ 1] + fM[ 9] * mM.fM[ 2] + fM[13] * mM.fM[ 3];
	mMT.fM[ 2] = fM[2] * mM.fM[ 0] + fM[6] * mM.fM[ 1] + fM[10] * mM.fM[ 2] + fM[14] * mM.fM[ 3];
	mMT.fM[ 3] = fM[3] * mM.fM[ 0] + fM[7] * mM.fM[ 1] + fM[11] * mM.fM[ 2] + fM[15] * mM.fM[ 3];
	mMT.fM[ 4] = fM[0] * mM.fM[ 4] + fM[4] * mM.fM[ 5] + fM[ 8] * mM.fM[ 6] + fM[12] * mM.fM[ 7];
	mMT.fM[ 5] = fM[1] * mM.fM[ 4] + fM[5] * mM.fM[ 5] + fM[ 9] * mM.fM[ 6] + fM[13] * mM.fM[ 7];
	mMT.fM[ 6] = fM[2] * mM.fM[ 4] + fM[6] * mM.fM[ 5] + fM[10] * mM.fM[ 6] + fM[14] * mM.fM[ 7];
	mMT.fM[ 7] = fM[3] * mM.fM[ 4] + fM[7] * mM.fM[ 5] + fM[11] * mM.fM[ 6] + fM[15] * mM.fM[ 7];
	mMT.fM[ 8] = fM[0] * mM.fM[ 8] + fM[4] * mM.fM[ 9] + fM[ 8] * mM.fM[10] + fM[12] * mM.fM[11];
	mMT.fM[ 9] = fM[1] * mM.fM[ 8] + fM[5] * mM.fM[ 9] + fM[ 9] * mM.fM[10] + fM[13] * mM.fM[11];
	mMT.fM[10] = fM[2] * mM.fM[ 8] + fM[6] * mM.fM[ 9] + fM[10] * mM.fM[10] + fM[14] * mM.fM[11];
	mMT.fM[11] = fM[3] * mM.fM[ 8] + fM[7] * mM.fM[ 9] + fM[11] * mM.fM[10] + fM[15] * mM.fM[11];
	mMT.fM[12] = fM[0] * mM.fM[12] + fM[4] * mM.fM[13] + fM[ 8] * mM.fM[14] + fM[12] * mM.fM[15];
	mMT.fM[13] = fM[1] * mM.fM[12] + fM[5] * mM.fM[13] + fM[ 9] * mM.fM[14] + fM[13] * mM.fM[15];
	mMT.fM[14] = fM[2] * mM.fM[12] + fM[6] * mM.fM[13] + fM[10] * mM.fM[14] + fM[14] * mM.fM[15];
	mMT.fM[15] = fM[3] * mM.fM[12] + fM[7] * mM.fM[13] + fM[11] * mM.fM[14] + fM[15] * mM.fM[15];
	
	return mMT;
}

void ASTMatrix4x4::operator *= (const ASTMatrix4x4& mM)
{
	*this = *this * mM;
}

void ASTMatrix4x4::LoadIdentity()
{
	fXX = 1.f, fXY = 0.f, fXZ = 0.f, fXW = 0.f;
	fYX = 0.f, fYY = 1.f, fYZ = 0.f, fYW = 0.f;
	fZX = 0.f, fZY = 0.f, fZZ = 1.f, fZW = 0.f;
	fWX = 0.f, fWY = 0.f, fWZ = 0.f, fWW = 1.f;
}

void ASTMatrix4x4::XRot(const float& fAngle)
{
    const float fC = (float) ASCos((float) (fAngle * AS_DEG_TO_RAD));
	const float fS = (float) ASSin((float) (fAngle * AS_DEG_TO_RAD));
	fYY = fC; fYZ = fS; fZY = -fS; fZZ = fC;
}

void ASTMatrix4x4::YRot(const float& fAngle)
{
    const float fC = (float) ASCos((float) (fAngle * AS_DEG_TO_RAD));
	const float fS = (float) ASSin((float) (fAngle * AS_DEG_TO_RAD));
	fXX = fC; fXZ = -fS; fZX = fS; fZZ = fC;
}

void ASTMatrix4x4::ZRot(const float& fAngle)
{
    const float fC = (float) ASCos((float) (fAngle * AS_DEG_TO_RAD));
	const float fS = (float) ASSin((float) (fAngle * AS_DEG_TO_RAD));
	fXX = fC; fXY = fS; fYX = -fS; fYY = fC;
}

void ASTMatrix4x4::Rotate(float fAX, float fAY, float fAZ)
{
	ASTMatrix4x4 mX, mY, mZ, mT;

	mZ.ZRot(fAZ);
	mY.YRot(fAY);
	mX.XRot(fAX);

    mT    = mZ * mY;
	*this = mT * mX;
}

void ASTMatrix4x4::Scale(const float& fX, const float& fY, const float& fZ)
{
	fXX = fX; fYY = fY; fZZ = fZ;
}

void ASTMatrix4x4::Scale(const ASTVector3D& vV)
{
	Scale(vV.fX, vV.fY, vV.fZ);
}

void ASTMatrix4x4::Scale(const float* fV)
{
	Scale(*fV++, *fV++, *fV);
}

void ASTMatrix4x4::Translate(const float& fX, const float& fY, const float& fZ)
{
	fWX += fXX * fX + fYX * fY + fZX * fZ;
	fWY += fXY * fX + fYY * fY + fZY * fZ;
	fWZ += fXZ * fX + fYZ * fY + fZZ * fZ;
	fWW += fXW * fX + fYW * fY + fZW * fZ;
}

void ASTMatrix4x4::Translate(const ASTVector3D& vV)
{
	Translate(vV.fX, vV.fY, vV.fZ);
}

void ASTMatrix4x4::Translate(const float* fV)
{
	Translate(*fV++, *fV++, *fV);
}

void ASTMatrix4x4::Transpose()
{
    AS_SWAP(fXY, fYX);
    AS_SWAP(fXZ, fZX);
    AS_SWAP(fXW, fWX);
    AS_SWAP(fYZ, fZY);
    AS_SWAP(fYW, fWY);
    AS_SWAP(fZW, fWZ);
}

ASTVector3D ASTMatrix4x4::Transform(const ASTVector3D& vV)
{
    float fW = vV.fX * fWX + vV.fY * fWY + vV.fZ * fWZ + fWW;

    return ASTVector3D((vV.fX * fXX + vV.fY * fXY + vV.fZ * fXZ + fXW) / fW,
					   (vV.fX * fYX + vV.fY * fYY + vV.fZ * fYZ + fYW) / fW,
					   (vV.fX * fZX + vV.fY * fZY + vV.fZ * fZZ + fZW) / fW);
}

void ASTMatrix4x4::Invert()
{
    ASTMatrix4x4 mMT;
    
	mMT.fXX = fXX;
    mMT.fXY = fYX;
    mMT.fXZ = fZX;
    mMT.fYX = fXY;
    mMT.fYY = fYY;
    mMT.fYZ = fZY;
    mMT.fZX = fXZ;
    mMT.fZY = fYZ;
    mMT.fZZ = fZZ;
  
    // The new displacement vector is given by:  d' = -(R^-1) * d
    mMT.fWX = -(fWX * mMT.fXX + fWY * mMT.fYX + fWZ * mMT.fZX);
    mMT.fWY = -(fWX * mMT.fXY + fWY * mMT.fYY + fWZ * mMT.fZY);
    mMT.fWZ = -(fWX * mMT.fXZ + fWY * mMT.fYZ + fWZ * mMT.fZZ);
  
    // The rest stfAYs the same
    mMT.fXW = mMT.fYW = mMT.fZW = 0.f;
    mMT.fWW = 1.f;

    *this = mMT;
}

ASTMatrix4x4 ASTMatrix4x4::GetInverted()
{
    ASTMatrix4x4 mMT;
    
	mMT.fXX = fXX;
    mMT.fXY = fYX;
    mMT.fXZ = fZX;
    mMT.fYX = fXY;
    mMT.fYY = fYY;
    mMT.fYZ = fZY;
    mMT.fZX = fXZ;
    mMT.fZY = fYZ;
    mMT.fZZ = fZZ;
  
    // The new displacement vector is given by:  d' = -(R^-1) * d
    mMT.fWX = -(fWX * mMT.fXX + fWY * mMT.fYX + fWZ * mMT.fZX);
    mMT.fWY = -(fWX * mMT.fXY + fWY * mMT.fYY + fWZ * mMT.fZY);
    mMT.fWZ = -(fWX * mMT.fXZ + fWY * mMT.fYZ + fWZ * mMT.fZZ);
  
    // The rest stfAYs the same
    mMT.fXW = mMT.fYW = mMT.fZW = 0.f;
    mMT.fWW = 1.f;

    return mMT;
}

void ASTMatrix4x4::GetEulerAngles(float& fX, float& fY, float& fZ) const
{
	double dAngleX, dAngleY, dAngleZ;

	dAngleY = atan2(fZX, ASSqrt(fZY * fZY + fZZ * fZZ));
	float fCosangleY = ASCos((float) dAngleY);

	if (fabs(fCosangleY) > AS_EPSILON) {
		dAngleZ = atan2(-fYX / fCosangleY, fXX / fCosangleY);
		dAngleX = atan2(-fZY / fCosangleY, fZZ / fCosangleY);
	}
	else {
		if (fabs(AS_PI_2 - dAngleY) < AS_EPSILON) {
			dAngleX = atan2(fXY , fYY);
			dAngleY = AS_PI_2;
			dAngleZ = 0.f;
		}
		else {
			dAngleX = atan2(-fXY , fYY);
			dAngleY = -AS_PI_2;
			dAngleZ = 0.f;
		}
	}

	// We set the result
	fX = (float) (-dAngleX * AS_RAD_TO_DEG);
	fY = (float) (-dAngleY * AS_RAD_TO_DEG);
	fZ = (float) (-dAngleZ * AS_RAD_TO_DEG);
}






/*
matrix set_rotations(matrix m, vector d, vector u){
	float t;
	vector D,U,R;
	D.x = d.x;
	D.y = d.y;
	D.z = d.z;
	NormalizeVector(&D);
	U.x = u.x;
	U.y = u.y;
	U.z = u.z;
	t = U.x * D.x+U.y * D.y+U.z * D.z;
	U.x -= D.x *t;
	U.y -= D.y *t;
	U.z -= D.y *t;
	NormalizeVector(&U);
	VectorCrossProduct(&R,&U,&D);
	m._11 = R.x;
	m._12 = R.y;
	m._21 = U.x;
	m._22 = U.y;
	m._31 = D.x;
	m._32 = D.y;
	m._33 = D.z;
	m._13 = R.z;
	m._23 = U.z;
	return m;
}
*/

/*
	File: ASPlane.cpp
*/

#include <ASEngineDll.h>


// Constructor
ASTPlane::ASTPlane()
{
	vV1 = 0.f; vV2 = 0.f; vV3 = 0.f;
	vN = ASTVector3D(1.f, 0.f, 0.f).Normalize();
	fD = 0.f;
}

ASTPlane::ASTPlane(const float& fA, const float& fB, const float& fC, const float& fD1)
{
	vV1 = 0.f; vV2 = 0.f; vV3 = 0.f;
	vN = ASTVector3D(fA, fB, fC).Normalize();
	fD = fD1;
}

ASTPlane::ASTPlane(const ASFLOAT3& fV1T, const ASFLOAT3& fV2T, const ASFLOAT3& fV3T)
{
	ComputeND(fV1T, fV2T, fV3T);
}

ASTPlane::ASTPlane(const ASTVector3D& vV1T, const ASTVector3D& vV2T, const ASTVector3D& vV3T)
{
	ComputeND(vV1, vV2, vV3);
}

// Assignment operators
ASTPlane& ASTPlane::operator = (const ASTPlane& pPlane)
{
	memcpy(this, &pPlane, sizeof(ASTPlane));
	
	return *this;
}

// Comparison
bool ASTPlane::operator == (const ASTPlane& pPlane) const
{
	return vN == pPlane.vN && fD == pPlane.fD;
}

bool ASTPlane::operator != (const ASTPlane& pPlane) const
{
	return !(*this == pPlane);
}

// Misc
void ASTPlane::ComputeND(const ASFLOAT3& fV1T, const ASFLOAT3& fV2T, const ASFLOAT3& fV3T)
{
	ComputeND(ASTVector3D(fV1T), ASTVector3D(fV2T), ASTVector3D(fV3T));
}

void ASTPlane::ComputeND(const ASTVector3D& vV1T, const ASTVector3D& vV2T, const ASTVector3D& vV3T)
{
	vV1 = vV1T; vV2 = vV2T; vV3 = vV3T;
	ASTVector3D vN1 = ((vV2 - vV1).Normalize());
	ASTVector3D vN2 = ((vV2 - vV3).Normalize());
	vN = (vN1.CrossProduct(vN2)).Normalize();
	vN.GetRightUp(vRight, vUp);
	fD = -ASDotProduct(vV1.fV, vN.fV);
}

bool ASTPlane::PointOnPlane(const ASTVector3D& vPoint) const
{
	return !DistanceToPlane(vPoint);
}

float ASTPlane::DistanceToPlane(const ASTVector3D& vPoint) const
{
	return (ASDotProduct(vN.fV, vPoint.fV) + fD);
}

ASTVector3D ASTPlane::RayIntersection(const ASTVector3D& vRayPos, const ASTVector3D& vRayDir) const
{
	float fA = ASDotProduct(vN.fV, vRayDir.fV);
	if(!fA) return vRayPos;	// Error line parallel to plane
	return vRayPos - vRayDir * (DistanceToPlane(vRayPos) / fA);
}
/*
	File: ASMatrix4x4.h

	Description: 4x4 matrix
*/

#ifndef __ASMATRIX4X4_H__
#define __ASMATRIX4X4_H__


// Predefinitions
typedef class ASTVector3D ASTVector3D;


// Classes
typedef class ASTMatrix4x4 {

	public:
		union {
			float fM[16];
			struct {
				float fXX, fXY, fXZ, fXW;
				float fYX, fYY, fYZ, fYW;
				float fZX, fZY, fZZ, fZW;
				float fWX, fWY, fWZ, fWW;
			};
			struct {
				float fM44[4][4];
			};
		};


		// Constructor
		AS_API ASTMatrix4x4();
		AS_API ASTMatrix4x4(const float* fS);
		AS_API ASTMatrix4x4(const ASTMatrix4x4& mM);

		// Assignment operators
		AS_API ASTMatrix4x4& operator = (const ASTMatrix4x4& mM);

		// Matrix
		AS_API ASTVector3D operator * (const ASTVector3D& vV) const;
		AS_API ASTMatrix4x4 operator * (const ASTMatrix4x4& mM) const;
		AS_API void operator *= (const ASTMatrix4x4& mM);

		// Misc
		AS_API void LoadIdentity();
		AS_API void XRot(const float& fAngle);
		AS_API void YRot(const float& fAngle);
		AS_API void ZRot(const float& fAngle);
		AS_API void Rotate(float fAX, float fAY, float fAZ);
		AS_API void Scale(const float& fX, const float& fY, const float& fZ);
		AS_API void Scale(const ASTVector3D& vV);
		AS_API void Scale(const float* fV);
		AS_API void Translate(const float& fX, const float& fY, const float& fZ);
		AS_API void Translate(const ASTVector3D& vV);
		AS_API void Translate(const float* fV);
		AS_API void Transpose();
		AS_API ASTVector3D Transform(const ASTVector3D& vV);
		AS_API void Invert();
		AS_API ASTMatrix4x4 GetInverted();
		AS_API void GetEulerAngles(float& fX, float& fY, float& fZ) const;


} ASTMatrix4x4;


#endif // __ASMATRIX4X4_H__
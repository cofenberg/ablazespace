/*
	File: ASMath.cpp

	TODO: Some assembler improvements! (ASAddVector etc.)
*/

#include <ASEngineDll.h>


// Definitions
#define FP_BITS(fp) (*(DWORD *)&(fp))


// Types
typedef union ASFastSqrtUnion {
	float f;
	unsigned int i;

} ASFastSqrtUnion;


// Variables
unsigned int ASFastSqrtTable[0x10000]; // Declare table of square roots


/*
	Check if the number of a power of 2
*/
bool ASTMath::IsPowerOfTwo(const int iNumber) const
{
	for (int i = 1; i < 15; i++)
		if (iNumber == pow(2, i)) return true;
	
	return false;
}

/*
	Returns the nearest power of 2
*/
int ASTMath::GetNearestPowerOfTwo(const int iNumber) const
{
	int iNumberT, iLast;

	if (IsPowerOfTwo(iNumber)) return iNumber;

	iLast = 1;
	for (int i = 1; i < 15; i++) {
		iNumberT = (int) pow(2, i);
		if (iNumber < iNumberT) return iLast;
		iLast = iNumberT;
	}

	return iNumber;
}

/*
	Initialize the math stuff
*/
bool ASTMath::Init()
{
	_AS::CLog.Output("Initialize math system");	
	BuildSqrtTable();

	return false;
}

/*
	Builds the square root table
*/
bool ASTMath::BuildSqrtTable()
{
	ASFastSqrtUnion s;
	unsigned int i;

	_AS::CLog.Output("Build square root table");	
	for (i = 0; i <= 0x7FFF; i++) {
		// Build a float with the bit pattern i as mantissa
		// and an exponent of 0, stored as 127
		s.i = (i << 8) | (0x7F << 23);
		s.f = (float) sqrt(s.f);

		// Take the square root then strip the first 7 bits of
		// the mantissa into the table
		ASFastSqrtTable[i + 0x8000] = (s.i & 0x7FFFFF);

		// Repeat the process, this time with an exponent of 1, 
		// stored as 128
		s.i = (i << 8) | (0x80 << 23);
		s.f = (float)sqrt(s.f);

		ASFastSqrtTable[i] = (s.i & 0x7FFFFF);
	}

	return false;
}

/*	
	Optimized dot product
*/
float inline __cdecl ASDotProduct(const ASFLOAT3 fV1, const ASFLOAT3 fV2)
{
	float fDotRet;
	_asm {
		mov     ecx, fV1
		mov     eax, fV2

		;optimized dot product; 15 cycles
		fld  dword ptr  [eax+0]     ;starts & ends on cycle 0
		fmul dword ptr  [ecx+0]     ;starts on cycle 1
		fld  dword ptr  [eax+4]     ;starts & ends on cycle 2
		fmul dword ptr  [ecx+4]     ;starts on cycle 3
		fld  dword ptr  [eax+8]     ;starts & ends on cycle 4
		fmul dword ptr  [ecx+8]     ;starts on cycle 5
		fxch            st(1)       ;no cost
		faddp           st(2),st(0) ;starts on cycle 6, stalls for cycles 7-8
		faddp           st(1),st(0) ;starts on cycle 9, stalls for cycles 10-12
		fstp dword ptr  [fDotRet]    ;starts on cycle 13, ends on cycle 14
	}

	return fDotRet;
}

/*	
	Optimized dot product
*/
float inline __cdecl ASDotProduct(const float f1, const float f2)
{
	return f1 * f1 + f2 * f2;
}

/*	
	Optimized cross product
*/
void inline __cdecl ASCrossProduct(const ASFLOAT3 fV1, const ASFLOAT3 fV2, ASFLOAT3& fRes)
{
	fRes[X] = fV1[Y] * fV2[Z] - fV1[Z] * fV2[Y];
    fRes[Y] = fV1[Z] * fV2[X] - fV1[X] * fV2[Z];
    fRes[Z] = fV1[X] * fV2[Y] - fV1[Y] * fV2[X];
}

/*
	Fast fabs funtion
*/
__declspec(naked) float inline __fastcall ASAbs(const float fNumber)
{
	__asm {
		fld	 DWORD PTR [esp+4] 
		fabs
		ret  4
	}
}

/*
	Fast sin function
*/
__declspec(naked) float inline __fastcall ASSin(const float fNumber)
{
	__asm {
		fld	 DWORD PTR [esp+4] 
		fsin
		ret  4
	}
}

/*
	Fast cos function
*/
__declspec(naked) float inline __fastcall ASCos(const float fNumber)
{
	__asm {
		fld	 DWORD PTR [esp+4] 
		fcos
		ret  4
	}
}

/*
	Fast square root computation
*/
inline float ASSqrt(const float f)
{
	if (!FP_BITS(f)) return 0.f; // Check for square root of 0

	FP_BITS(f) = ASFastSqrtTable[(FP_BITS(f) >> 8) & 0xFFFF] | ((((FP_BITS(f) - 0x3F800000) >> 1) + 0x3F800000) & 0x7F800000);

	return f;
}

/*
	Adds two vectors
*/
inline void ASAddVector(const ASFLOAT3& fV1, const ASFLOAT3& fV2, ASFLOAT3& pfRes)
{
	pfRes[0] = fV1[0] + fV2[0];
	pfRes[1] = fV1[1] + fV2[1];
	pfRes[2] = fV1[2] + fV2[2];
}

/*
	Subtracts two vectors
*/
inline void ASSubVector(const ASFLOAT3& fV1, const ASFLOAT3& fV2, ASFLOAT3& pfRes)
{
	pfRes[0] = fV1[0] - fV2[0];
	pfRes[1] = fV1[1] - fV2[1];
	pfRes[2] = fV1[2] - fV2[2];
}

/*
	Multiplies to vectors
*/
inline void ASMulVector(const ASFLOAT3& fV1, const ASFLOAT3& fV2, ASFLOAT3& pfRes)
{
	pfRes[0] = fV1[0] * fV2[0];
	pfRes[1] = fV1[1] * fV2[1];
	pfRes[2] = fV1[2] * fV2[2];
}

/*
	Scales a vector
*/
inline void ASScaleVector(const ASFLOAT3& fV, const float& fScale, ASFLOAT3& pfRes)
{
	pfRes[0] = fV[0] * fScale;
	pfRes[1] = fV[1] * fScale;
	pfRes[2] = fV[2] * fScale;
}

/*
	Inverts a vector
*/
inline void ASInvertVector(const ASFLOAT3& fV, ASFLOAT3& pfRes)
{
	pfRes[0] = -fV[0];
	pfRes[1] = -fV[1];
	pfRes[2] = -fV[2];
}

/*
	Computes the normal of a given triangle
*/
inline void ASNormalizeTriangle(const ASFLOAT3& fV1, const ASFLOAT3& fV2, const ASFLOAT3& fV3, ASFLOAT3& pfRes)
{
	ASFLOAT3 fV1_V2, fV1_V3;
	float fLength;

	ASSubVector(fV1, fV2, fV1_V2);
	ASSubVector(fV1, fV3, fV1_V3);
	ASCrossProduct(fV1_V2, fV1_V3, pfRes);
	fLength = (float) ASSqrt(ASDotProduct(pfRes, pfRes));
	pfRes[X] /= fLength;
	pfRes[Y] /= fLength;
	pfRes[Z] /= fLength;
}
/*
	File: ASVector3D.h

	Description: 3D vector
*/


#ifndef __ASVECTOR3D_H__
#define __ASVECTOR3D_H__


// Classes
typedef class ASTVector3D {

	public:
		enum { X, Y, Z };

		union {
			float fV[3];
			struct {
				float fX, fY, fZ;
			};
			struct {
				float fR, fG, fB;
			};
			struct {
				float fHeading, fPitch, fRoll;
			};
		};


		// Constructor
		AS_API ASTVector3D();
		AS_API ASTVector3D(const float& fXT, const float& fYT, const float& fZT);
		AS_API ASTVector3D(const float* fV);
		AS_API ASTVector3D(const ASTVector3D& vV);

		// Assignment operators
		AS_API ASTVector3D& operator = (const ASTVector3D& vV);
		AS_API ASTVector3D& operator = (const float* fV);
		AS_API ASTVector3D& operator = (const float& fD);

		// Comparison
		AS_API bool operator == (const ASTVector3D& vV) const;
		AS_API bool operator != (const ASTVector3D& vV) const;
		AS_API bool operator == (const float& f) const;
		AS_API bool operator != (const float& f) const;

		// Vector
		AS_API ASTVector3D  operator +  (const ASTVector3D& vV) const;
		AS_API ASTVector3D  operator +  (const float& fN) const;
		AS_API ASTVector3D& operator += (const ASTVector3D& vV);
		AS_API ASTVector3D& operator += (const float& fN);
	    AS_API ASTVector3D  operator -  () const;
		AS_API ASTVector3D  operator -  (const ASTVector3D& vV) const;
		AS_API ASTVector3D  operator -  (const float& fN) const;
		AS_API ASTVector3D& operator -= (const ASTVector3D& vV);
		AS_API ASTVector3D& operator -= (const float& fN);
		AS_API ASTVector3D  operator *  (const ASTVector3D& vV) const;
//		AS_API float	    operator *  (const ASTVector3D& vV) const;
		AS_API ASTVector3D  operator *  (const float& fS) const;
		AS_API ASTVector3D& operator *= (const ASTVector3D& vV);
		AS_API ASTVector3D& operator *= (const float& fS);
		AS_API ASTVector3D  operator /  (const ASTVector3D& vV) const;
		AS_API ASTVector3D  operator /  (const float& fS) const;
		AS_API ASTVector3D& operator /= (const ASTVector3D& vV);
		AS_API ASTVector3D& operator /= (const float& fS);

		// Misc
		AS_API float GetX() const;
		AS_API float GetY() const;
		AS_API float GetZ() const;
		AS_API void SetXYZ(const float& fXT, const float& fYT, const float& fZT);
		AS_API float GetLength() const;
		AS_API void SetLength(const float& fL);
		AS_API ASTVector3D& Normalize();
		AS_API ASTVector3D GetNormalized() const;
		AS_API ASTVector3D CrossProduct(const ASTVector3D& vV) const;
		AS_API void CrossProduct(const ASTVector3D& vV1, const ASTVector3D& vV2);
		AS_API void GetFaceNormal(const ASTVector3D& vV1, const ASTVector3D& vV2, const ASTVector3D& vV3);
		AS_API void GetRightUp(ASTVector3D& vRight, ASTVector3D& vUp) const;
		AS_API void ProjectVector(const ASTVector3D& vV, ASTVector3D& vRes) const;
		AS_API void ProjectPlane(const ASTVector3D& vV1, const ASTVector3D& vV2, ASTVector3D& vRes) const;
		AS_API float AngleBetween(const ASTVector3D& vV) const;
		AS_API void Invert();
		AS_API float DotProduct() const;
		AS_API float DotProduct(const ASTVector3D& vV) const;
		AS_API bool IsNull() const;
		AS_API void Rotate(ASTMatrix4x4& mM, ASTVector3D& vV);


} ASTVector3D;


#endif // __ASVECTOR3D_H__
/*
	File: ASPlane.h

	Description: Plane stuff
*/

#ifndef __ASPLANE_H__
#define __ASPLANE_H__


// Classes
typedef class ASTPlane {

	public:
		ASTVector3D vN,				// Plane normal
					vRight, vUp;	// Up and right vector of the plane normal
		ASTVector3D vV1, vV2, vV3;	// The three vertices which descripes the plane (if given)
		float fD;


		// Constructor
		AS_API ASTPlane();
		AS_API ASTPlane(const float& fA, const float& fB, const float& fC, const float& fD1);
		AS_API ASTPlane(const ASFLOAT3& fV1T, const ASFLOAT3& fV2T, const ASFLOAT3& fV3T);
		AS_API ASTPlane(const ASTVector3D& vV1T, const ASTVector3D& vV2T, const ASTVector3D& vV3T);

		// Assignment operators
		AS_API ASTPlane& operator = (const ASTPlane& pPlane);

		// Comparison
		AS_API bool operator == (const ASTPlane& pPlane) const;
		AS_API bool operator != (const ASTPlane& pPlane) const;

		// Misc
		AS_API void ComputeND(const ASFLOAT3& fV1T, const ASFLOAT3& fV2T, const ASFLOAT3& fV3T);
		AS_API void ComputeND(const ASTVector3D& vV1T, const ASTVector3D& vV2T, const ASTVector3D& vV3T);
		AS_API bool PointOnPlane(const ASTVector3D& vPoint) const;
		AS_API float DistanceToPlane(const ASTVector3D& vPoint) const;
		AS_API ASTVector3D RayIntersection(const ASTVector3D& vRayPos, const ASTVector3D& vRayDir) const;


} ASTPlane;


#endif // __ASPLANE_H__
/*
	File: ASVector2D.cpp
*/

#include <ASEngineDll.h>


// Constructor
ASTVector2D::ASTVector2D()
{
	fX = fY = 0.f;
}

ASTVector2D::ASTVector2D(const float& fXT, const float& fYT)
{
	fY = fXT, fY = fYT;
}

ASTVector2D::ASTVector2D(const float* fV)
{
	*this = fV;
}

ASTVector2D::ASTVector2D(const ASTVector2D& vV)
{
	*this = vV;
}

// Assignment operators
ASTVector2D& ASTVector2D::operator = (const float* fV)
{
	fX = *fV++, fY = *fV;

	return  *this;
}

ASTVector2D& ASTVector2D::operator = (const ASTVector2D& vV)
{
	fX = vV.fX, fY = vV.fY;

	return *this;
}

ASTVector2D& ASTVector2D::operator = (const float& fD)
{
	fX = fY = fD;

	return *this;
}

// Comparison
bool ASTVector2D::operator == (const ASTVector2D& vV) const
{
	return fX == vV.fX && fY == vV.fY;
}

bool ASTVector2D::operator != (const ASTVector2D& vV) const
{
	return !(*this == vV);
}

bool ASTVector2D::operator == (const float& f) const
{
	return fX == f && fY == f;
}

bool ASTVector2D::operator != (const float& f) const
{
	return !(*this == f);
}

// Vector
ASTVector2D ASTVector2D::operator + (const ASTVector2D& vV) const
{
	return ASTVector2D(fX + vV.fX, fY + vV.fY);
}

ASTVector2D ASTVector2D::operator + (const float& fN) const
{
	return ASTVector2D(fX + fN, fY + fN);
}

ASTVector2D& ASTVector2D::operator += (const ASTVector2D& vV)
{
	fX += vV.fX, fY += vV.fY;
	return *this;
}

ASTVector2D& ASTVector2D::operator += (const float& fN)
{
	fX += fN, fY += fN;
	return *this;
}

ASTVector2D ASTVector2D::operator - () const
{
	return ASTVector2D(-fX, -fY);
}

ASTVector2D ASTVector2D::operator - (const float& fN) const
{
	return ASTVector2D(fX - fN, fY - fN);
}

ASTVector2D ASTVector2D::operator - (const ASTVector2D& vV) const
{
	return ASTVector2D(fX - vV.fX, fY - vV.fY);
}

ASTVector2D& ASTVector2D::operator -= (const ASTVector2D& vV)
{
	fX -= vV.fX, fY -= vV.fY;

	return *this;
}

ASTVector2D& ASTVector2D::operator -= (const float& fN)
{
	fX -= fN, fY -= fN;

	return *this;
}

ASTVector2D ASTVector2D::operator * (const ASTVector2D& vV) const
{
	return ASTVector2D(fX * vV.fX, fY * vV.fY);
}

ASTVector2D ASTVector2D::operator * (const float& fS) const
{
	return ASTVector2D(fX * fS, fY * fS);
}

ASTVector2D& ASTVector2D::operator *= (const ASTVector2D& vV)
{
	fX *= vV.fX, fY *= vV.fY;
	return *this;
}

ASTVector2D& ASTVector2D::operator *= (const float& fS)
{
	fX *= fS, fY *= fS;
	return *this;
}

ASTVector2D ASTVector2D::operator / (const ASTVector2D& vV) const
{
	return ASTVector2D(fX / vV.fX, fY / vV.fY);
}

ASTVector2D ASTVector2D::operator / (const float& fS) const
{
	return ASTVector2D(fX / fS, fY / fS);
}

ASTVector2D& ASTVector2D::operator /= (const ASTVector2D& vV)
{
	fX /= vV.fX, fY /= vV.fY;

	return *this;
}

ASTVector2D& ASTVector2D::operator /= (const float& fS)
{
	fX /= fS, fY /= fS;

	return *this;
}

// Misc
float ASTVector2D::GetX() const
{
	return fX;
}

float ASTVector2D::GetY() const
{
	return fY;
}

void ASTVector2D::SetXY(const float& fXT, const float& fYT)
{
	fX = fXT; fY = fYT;
}

float ASTVector2D::GetLength() const
{
	return (float) ASSqrt(fX * fX + fY * fY);
}

void ASTVector2D::SetLength(const float& fL)
{
	*this *= fL / (float) ASSqrt(fX * fX + fY * fY);
}

ASTVector2D& ASTVector2D::Normalize()
{
	float fU = fX * fX + fY * fY;
	if (fabs(fU - 1.f) < AS_EPSILON) return *this;
	fU = 1.f / (float) ASSqrt(fU);
	*this *= fU;

	return *this;
}

ASTVector2D ASTVector2D::GetNormalized() const
{
	return ASTVector2D(*this).Normalize();
}

void ASTVector2D::Invert()
{
	fX = -fX; fY = -fY;
}

float ASTVector2D::DotProduct() const
{
	return fX * fX + fY * fY;
}

float ASTVector2D::DotProduct(const ASTVector2D& vV) const
{
	return fX * vV.fX + fY * vV.fY;
}

bool ASTVector2D::IsNull() const
{
	if(!fX && !fY) return true;
	else return false;
}
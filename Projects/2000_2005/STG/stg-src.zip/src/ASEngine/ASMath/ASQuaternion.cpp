/*
	File: ASQuaternion.cpp
*/

#include <ASEngineDll.h>


// Constructor
ASTQuaternion::ASTQuaternion()
{
	Reset();
}

ASTQuaternion::ASTQuaternion(const ASTQuaternion& qCopyFrom)
{
	Set(qCopyFrom);
}

ASTQuaternion::ASTQuaternion(const float& fXT, const float& fYT, const float& fZT)
{
	Set(fXT, fYT, fZT);
}

ASTQuaternion::ASTQuaternion(const float& fAngle, const float& fXT, const float& fYT, const float& fZT)
{
	Set(fAngle, fXT, fYT, fZT);
}

// Quaternion
ASTQuaternion ASTQuaternion::operator + (const ASTQuaternion& qQ) const
{
	return ASTQuaternion(fX + qQ.fX, fY + qQ.fY, fZ + qQ.fZ);
}

ASTQuaternion ASTQuaternion::operator * (const float& f) const
{
	return ASTQuaternion(fX * f, fY * f, fZ * f);
}

ASTQuaternion ASTQuaternion::operator * (const ASTQuaternion& qQ) const
{
	return ASTQuaternion(fX * qQ.fX, fY * qQ.fY, fZ * qQ.fZ);
}

// Misc
ASTQuaternion& ASTQuaternion::Reset()
{
	fW = 1.f; fX = 0.f; fY = 0.f; fZ = 0.f; return *this;
}

ASTQuaternion& ASTQuaternion::Set(const ASTQuaternion& qCopyFrom)
{
	fW = qCopyFrom.fW;
	fX = qCopyFrom.fX;
	fY = qCopyFrom.fY;
	fZ = qCopyFrom.fZ;

	return *this;
}

ASTQuaternion& ASTQuaternion::Set(const float& fXT, const float& fYT, const float& fZT)
{
	ASTQuaternion qX(fXT, 1.f, 0.f, 0.f);
	ASTQuaternion qY(fYT, 0.f, 1.f, 0.f);
	ASTQuaternion qZ(fZT, 0.f, 0.f, 1.f);

	Set(qX);
	PostMult(qY);
	PostMult(qZ);

	return *this;
}

ASTQuaternion& ASTQuaternion::Set(const float& fAngle, const float& fXT, const float& fYT, const float& fZT)
{
	// Cache fAngle / 2.f
	fW = fAngle / 2.f * (float) AS_DEG_TO_RAD;

	// Cache ASSin(fAngle / 2.f)
	fX  = ASSin(fW);
	fY  = fX * fYT;
	fZ  = fX * fZT;
	fX *= fXT;

	// Store ASCos(fAngle / 2.f)
	fW = ASCos(fW);

	return *this;
}

ASTQuaternion& ASTQuaternion::PostMult(const ASTQuaternion& qQ)
{
	ASTQuaternion qTemp(*this);
	MultAndSet(qTemp, qQ);

	return *this;
}

float ASTQuaternion::DotProduct() const
{
	return fX * fX + fY * fY + fZ * fZ + fW * fW;
}

float ASTQuaternion::DotProduct(const ASTQuaternion& qQ) const
{
	return fX * qQ.fX + fY * qQ.fY + fZ * qQ.fZ + fW * qQ.fW;
}

float ASTQuaternion::GetLength() const
{
	return ASSqrt(fX * fX + fY * fY + fZ * fZ + fW * fW);
}

ASTQuaternion& ASTQuaternion::MultAndSet(const ASTQuaternion& qQ1, const ASTQuaternion& qQ2)
{
	fW =   qQ2.fW * qQ1.fW
		 - qQ2.fX * qQ1.fX
		 - qQ2.fY * qQ1.fY
		 - qQ2.fZ * qQ1.fZ;

	fX =   qQ2.fW * qQ1.fX
		 + qQ2.fX * qQ1.fW
		 + qQ2.fY * qQ1.fZ
		 - qQ2.fZ * qQ1.fY;

	fY =   qQ2.fW * qQ1.fY
		 - qQ2.fX * qQ1.fZ
		 + qQ2.fY * qQ1.fW
		 + qQ2.fZ * qQ1.fX;

	fZ =   qQ2.fW * qQ1.fZ
		 + qQ2.fX * qQ1.fY
		 - qQ2.fY * qQ1.fX
		 + qQ2.fZ * qQ1.fW;
	
	return *this;
}

ASTQuaternion& ASTQuaternion::Normalize()
{
	float fFactor = fW * fW +
					fX * fX +
					fY * fY +
					fZ * fZ;
	float fScaleBy = 1.f / ASSqrt(fFactor);

	fW = fW * fScaleBy;
	fX = fX * fScaleBy;
	fY = fY * fScaleBy;
	fZ = fZ * fScaleBy;

	return *this;
}

ASTQuaternion ASTQuaternion::Inversed()
{
	ASTQuaternion qT;
	
	qT.fX = -fX;
	qT.fY = -fY;
	qT.fZ = -fZ;

	return qT;
}

/*
	Note: The quaternion must be normalized!
*/
void ASTQuaternion::GetMatrix(ASTMatrix4x4* pmM) const
{
	float fXX = fX * fX;
	float fYY = fY * fY;
	float fZZ = fZ * fZ;

	pmM->fXX = 1.f - 2.f * (fYY + fZZ);
	pmM->fYX =		 2.f * (fX * fY + fW * fZ);
	pmM->fZX =		 2.f * (fX * fZ - fW * fY);
	pmM->fWX = 0.f;

	pmM->fXY =		 2.f * (fX * fY - fW * fZ);
	pmM->fYY = 1.f - 2.f * (fXX + fZZ);
	pmM->fZY =		 2.f * (fY * fZ + fW * fX);
	pmM->fWY = 0.f;

	pmM->fXZ =		 2.f * (fX * fZ + fW * fY);
	pmM->fYZ =		 2.f * (fY * fZ - fW * fX);
	pmM->fZZ = 1.f - 2.f * (fXX + fYY);
	pmM->fWZ = 0.f;

	pmM->fXW = 0.f;
	pmM->fYW = 0.f;
	pmM->fZW = 0.f;
	pmM->fWW = 1.f;
}

/*
	Note: The quaternion must be normalized!
*/
void ASTQuaternion::GetInvertedMatrix(ASTMatrix4x4* pmM) const
{
	float fXX = fX * fX;
	float fYY = fY * fY;
	float fZZ = fZ * fZ;

	pmM->fXX = -(1.f - 2.f * (fYY + fZZ));
	pmM->fYX = -(2.f * (fX * fY + fW * fZ));
	pmM->fZX = -(2.f * (fX * fZ - fW * fY));
	pmM->fWX = 0.f;

	pmM->fXY = 2.f * (fX * fY - fW * fZ);
	pmM->fYY = 1.f - 2.f * (fXX + fZZ);
	pmM->fZY = 2.f * (fY * fZ  +fW * fX);
	pmM->fWY = 0.f;

	pmM->fXZ = 2.f * (fX * fZ + fW * fY);
	pmM->fYZ = 2.f * (fY * fZ - fW * fX);
	pmM->fZZ = 1.f - 2.f * (fXX + fYY);
	pmM->fWZ = 0.f;

	pmM->fXW = 0.f;
	pmM->fYW = 0.f;
	pmM->fZW = 0.f;
	pmM->fWW = 1.f;
}

void ASTQuaternion::SetMatrix(ASTMatrix4x4& mM)
{
	float fTr, fS, fQ[4];
    int i, j, k;
	int iNxt[3] = {1, 2, 0};

	fTr = mM.fXX + mM.fYY + mM.fZZ;

	// Check the diagonal
	if (fTr > 0.f) {
		fS = ASSqrt(fTr + 1.f);
		fW = fS / 2.f;
		fS = 0.5f / fS;
		fX = (mM.fZY - mM.fYZ) * fS;
		fY = (mM.fXZ - mM.fZX) * fS;
		fZ = (mM.fYX - mM.fXY) * fS;
	}
	else { // Diagonal is negative
		i = 0;
		if (mM.fYY > mM.fXX) i = 1;
		if (mM.fZZ > mM.fM44[i][i]) i = 2;
		
		j = iNxt[i];
		k = iNxt[j];

		fS = ASSqrt((mM.fM44[i][i] - (mM.fM44[j][j] + mM.fM44[k][k])) + 1.f);
		fQ[i] = fS * 0.5f;
		if(fS != 0.) fS = 0.5f / fS;

		fZ = (mM.fM44[j][k] - mM.fM44[k][j]) * fS;
		fQ[j] = (mM.fM44[i][j] + mM.fM44[j][i]) * fS;
		fQ[k] = (mM.fM44[i][k] + mM.fM44[k][i]) * fS;

		fX = fW;
		fY = fX;
		fZ = fY;
		fW = fZ;
	}
}

void ASTQuaternion::GetAxisAngle(float& fAxisX, float& fAxisY, float& fAxisZ, float& fRotAngle) const
{
	float fLenOfVector = fX * fX + fY * fY + fZ * fZ;

	if (fLenOfVector < AS_EPSILON) {
		fAxisX = 1.f;
		fAxisY = 0.f;
		fAxisZ = 0.f;
		fRotAngle = 0.f;
	}
	else {
		float fInvLen = 1.f / ASSqrt(fLenOfVector);
		fAxisX = fX * fInvLen;
		fAxisY = fY * fInvLen;
		fAxisZ = fZ * fInvLen;
		fRotAngle = (float) (2.f * acos(fW));
	}
	fRotAngle = (float) (fRotAngle * AS_RAD_TO_DEG);
}

/*
	Note: The quaternion must be normalized!
*/
void ASTQuaternion::GetDirectionVector(ASTVector3D* vDir)
{
	Normalize();
	(*vDir).fX = 2.f * (fX * fZ - fW * fY);
	(*vDir).fY = 2.f * (fY * fZ + fW * fX);
	(*vDir).fZ = 1.f - 2.f * (fX * fX + fY * fY);
}

void ASTQuaternion::EulerToQuat(const float& fEX, const float& fEY, const float& fEZ)
{
	float fEXT, fEYT, fEZT; // Temp half euler angles
	float fCR, fCP, fCY, fSR, fSP, fSY, fCPCY, fSPSY; // Temp vars in roll, pitch and yaw

	// Convert to rads and half them
	fEXT = (float) AS_DEG_TO_RAD * fEX / 2.f;
	fEYT = (float) AS_DEG_TO_RAD * fEY / 2.f;
	fEZT = (float) AS_DEG_TO_RAD * fEZ / 2.f;

	fCR = ASCos(fEXT);
	fCP = ASCos(fEYT);
	fCY = ASCos(fEZT);

	fSR = ASSin(fEXT);
	fSP = ASSin(fEYT);
	fSY = ASSin(fEZT);

	fCPCY = fCP * fCY;
	fSPSY = fSP * fSY;

	fW = float (fCR * fCPCY + fSR * fSPSY);

	fX = float (fSR * fCPCY - fCR * fSPSY);
	fY = float (fCR * fSP * fSY + fSR * fCP * fSY);
	fZ = float (fCR * fCP * fSY - fSR * fSP * fCY);

	Normalize();
}

void ASTQuaternion::GetEulerAngles(float &fX, float &fY, float &fZ) const
{
	ASTMatrix4x4 Matrix;

	GetMatrix(&Matrix);
	Matrix.GetEulerAngles(fX, fY, fZ);
}

/*
	Computes spherical linear interpolation between qQ1 and qQ2 with time 0-1
*/
void ASTQuaternion::Slerp(const ASTQuaternion& qQ1, const ASTQuaternion& qQ2, const float& fTime)
{
	float fOmega, fCosom, fSinom, fScale0, fScale1;
	ASFLOAT4 fFrom, fTo, fTo1;

	memcpy(&fFrom, qQ1.fQ, sizeof(ASFLOAT4));
	memcpy(&fTo, qQ2.fQ, sizeof(ASFLOAT4));

	// Calc cosine:
	fCosom = fFrom[X] * fTo[X] + fFrom[Y] * fTo[Y] + fFrom[Z] * fTo[Z] + fFrom[W] * fTo[W];

	// Adjust signs: (if necessary)
	if (fCosom < 0.f) { 
		  fCosom  = -fCosom; 
		  fTo1[0] = -fTo[X];
          fTo1[1] = -fTo[Y];
          fTo1[2] = -fTo[Z];
          fTo1[3] = -fTo[W];
	} 
	else {
          fTo1[0] = fTo[X];
          fTo1[1] = fTo[Y];
          fTo1[2] = fTo[Z];
          fTo1[3] = fTo[W];
	}

	// Calculate coefficients
	if ((1.0f-fCosom) > AS_EPSILON) { // Standard case (slerp)
		fOmega  = (float) acos(fCosom);
        fSinom  = ASSin(fOmega);
        fScale0 = ASSin((1.f - fTime) * fOmega) / fSinom;
        fScale1 = ASSin(fTime * fOmega) / fSinom;
	} 
	else { 
		// "fFrom" and "tTo" quaternions are very close 
		//  ... so we can do a linear interpolation:
		fScale0 = 1.f - fTime;
        fScale1 = fTime;
	}

	// Calculate final values:
	fQ[X] = fScale0 * fFrom[X] + fScale1 * fTo1[0];
	fQ[Y] = fScale0 * fFrom[Y] + fScale1 * fTo1[1];
	fQ[Z] = fScale0 * fFrom[Z] + fScale1 * fTo1[2];
	fQ[W] = fScale0 * fFrom[W] + fScale1 * fTo1[3];
}

void ASTQuaternion::SquadSlerp(const ASTQuaternion& qA, const ASTQuaternion& qP,
							   const ASTQuaternion& qQ, ASTQuaternion& qB, float& fTime)
{
	ASTQuaternion qAB;
	ASTQuaternion qPQ;

	qAB.Slerp(qA, qB, fTime);
	qPQ.Slerp(qP, qQ, fTime);
	Slerp(qAB, qPQ, 2 * fTime * (1 - fTime));
}

void ASTQuaternion::Invert()
{
	float l, m;

	l = GetLength();
	if (fabs(l) < AS_EPSILON) {
		fX = fY = fZ = 0.f;
		fW = 1.f;
	}
	else {  
		m = 1.f / l;
		fX = -fX * m;
		fY = -fY * m;
		fZ = -fZ * m;
		fW = fW * m;
	}
}

void ASTQuaternion::Mult(const ASTQuaternion& qA, const ASTQuaternion& qB)
{
	fX = qA.fW * qB.fX + qA.fX * qB.fW + qA.fY * qB.fZ - qA.fZ * qB.fY;
	fY = qA.fW * qB.fY + qA.fY * qB.fW + qA.fZ * qB.fX - qA.fX * qB.fZ;
	fZ = qA.fW * qB.fZ + qA.fZ * qB.fW + qA.fX * qB.fY - qA.fY * qB.fX;
	fW = qA.fW * qB.fW - qA.fX * qB.fX - qA.fY * qB.fY - qA.fZ * qB.fZ;
}

void ASTQuaternion::Ln()
{
	float fOm, fS, fT;

	fS = ASSqrt(fX * fX + fY * fY + fZ * fZ);
	fOm = (float) atan2(fS, fW);
	if (fabs(fS) < AS_EPSILON) fT = 0.f;
	else fT = fOm / fS;
	for (int i = 1; i < 4; ++i) fQ[i] = fQ[i] * fT;
	fW = 0.f;
}

void ASTQuaternion::LnDif(const ASTQuaternion& qA, const ASTQuaternion& qB)
{
	ASTQuaternion qInvp;

	for (int i = 0; i < 4; i++) qInvp.fQ[i] = qA.fQ[i];
	qInvp.Invert();
	Mult(qInvp, qB);
	Ln();
}

void ASTQuaternion::Exp()
{
	float fOm, fSinom;

	fOm = ASSqrt(fX * fX + fY * fY + fZ * fZ);
	if (fabs(fOm) < AS_EPSILON) fSinom = 1.f;
	else fSinom = ASSin(fOm) / fOm;
	for (int i = 1; i < 4; ++i) fQ[i] = fQ[i] * fSinom;
	fW = ASCos(fOm);
}

void ASTQuaternion::InnerPoint(const ASTQuaternion& qP, const ASTQuaternion& qQ, const ASTQuaternion& qN)
{
	ASTQuaternion qDN, qDP, qX;

	qDN.LnDif(qQ, qN);
	qDP.LnDif(qQ, qP);
	for (int i = 0; i < 4; i++) qX.fQ[i] = -1.f / 4.f * (qDN.fQ[i] + qDP.fQ[i]);
	qX.Exp();
	Mult(qQ, qX);
}
/*
	File: ASTimer.h

	Description: Timing stuff. Use it for instance to create timed movement.
*/


#ifndef __ASTIMER_H__
#define __ASTIMER_H__


// Classes
typedef class ASTTimer {
	
	friend	_AS;


	public:
		/*
			Constructor
		*/
		AS_API ASTTimer();

		/*
			Enables the timer

			Notes:
				- The timer is enables as default
		*/
		AS_API void Enable();

		/*
			Disables the timer

			Notes:
				- If the timer is disables the time differece between two frames will be always
				  the maximum time difference
				- Use it only for testing
		*/
		AS_API void Disable();
		
		/*
			Resets the timer
		*/
		AS_API void Reset();

		/*
			Returns the past time since last frame (in milliseconds)

			Returns:
				float -> Past time since last frame (in milliseconds)
		*/
		AS_API float GetTimeDifference() const;

		/*
			Sets the maximum time difference.
			This will avoid a too hight time difference value which would probably end in undefined problems.

			Parameters:
				float fMaxTimeDifference -> The maximum time difference since the last frame

			Notes:
				- A maximum time difference of 0.025 is a good value
		*/
		AS_API void SetMaxTimeDifference(const float fMaxTimeDifference = 0.025f);


		/*
			Returns the current frames per second (FPS)

			Returns:
				float -> Current frames per second (FPS)
		*/
		AS_API float GetFramesPerSecond() const;

		/*
			Returns if the timer is currently freezed or not

			Returns:
				bool -> 'true' if the timer is freezed at the moment else 'false'

			Notes:
				- Freeze your application if you are not in rendering mode (e.g. you load something)
		*/
		AS_API bool IsFreezed() const;

		/*
			Set freezed mode

			Parameters:
				bool bFreeze -> Should the timer be freezed or not?
		*/
		AS_API void Freeze(const bool bFreeze = true);

		/*
			Returns whether the engine is paused of not

			Returns:
				bool -> 'true' if the engine is paused else 'false'

			Notes:
				- If the engine is paused entities, particles etc. are not updated
				- The timer will still be updated
		*/
		AS_API bool IsPaused() const;

		/*
			Set pause mode

			Parameters:
				bool bPause -> Should the engine be paused or not?
		*/
		AS_API void Pause(const bool bPause = true);

		/*
			Activates / deactivates the slow motion mode

			Parameters:
				bool bSlowMotion -> Should the slow motion mode be activated?
		*/
		AS_API void SetSlowMotion(const bool bSlowMotion = false);

		/*
			Returns if the slow motion is activated or not

			Returns:
				bool -> 'true' is the slow motion mode is activated else 'false'
		*/
		AS_API bool IsSlowMotion() const;

		/*
			Sets the slow motion factor

			Parameters:
				float fSlowMotionFactor -> The slow motion factor

			Notes:
				- The slow motion mode must be activated that this factor changes the game speed
				- Use this function to change the speed in general
		*/
		AS_API void SetSlowMotionFactor(const float fSlowMotionFactor = 1.f);

		/*
			Returns the slow motion factor

			Parameters:
				bool bRealUsed -> The real used slow motion factor will be returned.
								  If the slow motion mode is deactivated this will be 1!

			Returns:
				float -> The current slow motion factor

			Notes:
				- The slow motion mode must be activated that this factor changes the game speed
				- Use this function to change the speed in general
		*/
		AS_API float GetSlowMotionFactor(const bool bRealUsed = true) const;

		/*
			Sets the custom slow motion factor

			Parameters:
				float fSlowMotionFactor -> The slow motion factor

			Notes:
				- The slow motion mode must be activated that this factor changes the game speed
				- Use this factor to temporal slow motion effects
		*/
		AS_API void SetCustomSlowMotionFactor(const float fSlowMotionFactor = 1.f);

		/*
			Returns the custom slow motion factor

			Parameters:
				bool bRealUsed -> The real used slow motion factor will be returned.
								  If the slow motion mode is deactivated this will be 1!

			Returns:
				float -> The current slow motion factor

			Notes:
				- The slow motion mode must be activated that this factor changes the game speed
				- Use this factor to temporal slow motion effects
		*/
		AS_API float GetCustomSlowMotionFactor(const bool bRealUsed = true) const;

		/*
			Returns the past time in milliseconds since the application start

			Returns:
				DWORT -> Past time in milliseconds since the application start
		*/
		AS_API DWORD GetPastTime() const;


	private:
		bool	m_bActive;					// Is the timer active?
		DWORD	m_dwTimeStart;				// The start system time
		DWORD	m_dwTimeNow;				// Current system time
		DWORD	m_dwTimeLast;				// System time of the last frame
		DWORD   m_dwFrequency;				// Performance counter frequency
		float	m_fTimeDifference;			// The past time since last frame (in milliseconds)
		float	m_fMaxTimeDifference;		// The maximum possible time difference
		float	m_fFramesPerSecond;			// Current frames per second (FPS... hopefully not SPS... Seconds Per Frame ;)
		int		m_iFramesSinceCheck;		// Number of frames since last FPS update
		DWORD	m_dwLastFPSUpdateTime;		// The time were the last FPS update was done
		float	m_fFPSUpdateTimer;			// Timer for updating FPS (only each second)
		bool	m_bFreezed;					// Is the application currently freezed?
		DWORD	m_dwFreezeTime;				// The time were the application was frozen
		bool	m_bPause;					// Is the engine paused?
		bool	m_bSlowMotion;				// Is the slow motion modus activated?
		float	m_fSlowMotionFactor;		// The slow motion factor
		float	m_fCustomSlowMotionFactor;	// The custom slow motion factor


		/*
			Updates all time relevant stuff
		*/
		void Update();


} ASTTimer;


#endif // __ASTIMER_H__
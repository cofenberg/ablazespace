/*
	File: ASTimer.cpp
*/

#include <ASEngineDll.h>


/*
	Constructor
*/
ASTTimer::ASTTimer()
{
	LARGE_INTEGER lpPerformanceFrequency;

	QueryPerformanceFrequency(&lpPerformanceFrequency);
	m_bActive				  = true;
	m_fMaxTimeDifference	  = 0.025f;
	m_dwFrequency			  = (DWORD) lpPerformanceFrequency.QuadPart;
	m_dwTimeStart			  = GetTickCount();
	m_bFreezed				  = false;
	m_bPause				  = false;
	m_bSlowMotion			  = true;
	m_fSlowMotionFactor		  = 1.f;
	m_fCustomSlowMotionFactor = 1.f;

	Reset();
}

/*
	Enables the timer
*/
void ASTTimer::Enable()
{
	m_bActive = true;
}

/*
	Disables the timer
*/
void ASTTimer::Disable()
{
	m_bActive = false;
}

/*
	Resets the timer
*/
void ASTTimer::Reset()
{
	m_dwLastFPSUpdateTime = m_dwTimeLast = m_dwTimeNow = GetTickCount();
}

/*
	Returns the past time since last frame (in milliseconds)
*/
float ASTTimer::GetTimeDifference() const
{
	if (m_bFreezed) return 0.f;

	return m_fTimeDifference;
}

/*
	Sets the maximum time difference
*/
void ASTTimer::SetMaxTimeDifference(const float fMaxTimeDifference)
{
	m_fMaxTimeDifference = fMaxTimeDifference;
}

/*
	Returns the current frames per second (FPS)
*/
float ASTTimer::GetFramesPerSecond() const
{
	return m_fFramesPerSecond;
}

/*
	Returns if the timer is currently freezed or not
*/
bool ASTTimer::IsFreezed() const
{
	return m_bFreezed;
}

/*
	Set freezed mode
*/
void ASTTimer::Freeze(const bool bFreeze)
{
	if (bFreeze) {
		if (m_bFreezed) return;
		m_bFreezed = true;
		m_dwFreezeTime = m_dwTimeNow;
	} else {
		if (m_bFreezed) { // Update timer
			DWORD dwTimeDifference = GetTickCount() - m_dwFreezeTime;
			m_dwTimeLast += dwTimeDifference;
			m_dwLastFPSUpdateTime += dwTimeDifference;
		}
		m_bFreezed = false;
	}
}

/*
	Returns whether the engine is paused of not
*/
bool ASTTimer::IsPaused() const
{
	return m_bPause;
}

/*
	Set pause mode
*/
void ASTTimer::Pause(const bool bPause)
{
	m_bPause = bPause;
}

/*
	Activates / deactivates the slow motion mode
*/
void ASTTimer::SetSlowMotion(const bool bSlowMotion)
{
	m_bSlowMotion = bSlowMotion;
}

/*
	Returns if the slow motion is activated or not
*/
bool ASTTimer::IsSlowMotion() const
{
	return m_bSlowMotion;
}

/*
	Sets the slow motion factor
*/
void ASTTimer::SetSlowMotionFactor(const float fSlowMotionFactor)
{
	m_fSlowMotionFactor = fSlowMotionFactor;
}

/*
	Returns the slow motion factor
*/		
float ASTTimer::GetSlowMotionFactor(const bool bRealUsed) const
{
	if (bRealUsed && !m_bSlowMotion) return 1.f;
	return m_fSlowMotionFactor;
}

/*
	Sets the custom slow motion factor
*/
void ASTTimer::SetCustomSlowMotionFactor(const float fSlowMotionFactor)
{
	m_fCustomSlowMotionFactor = fSlowMotionFactor;
}

/*
	Returns the custom slow motion factor
*/		
float ASTTimer::GetCustomSlowMotionFactor(const bool bRealUsed) const
{
	if (bRealUsed && !m_bSlowMotion) return 1.f;
	return m_fCustomSlowMotionFactor;
}

/*
	Returns the past time in milliseconds since the application start
*/
DWORD ASTTimer::GetPastTime() const
{
	return (GetTickCount() - m_dwTimeStart);
}

/*
	Updates all time relevant stuff
*/
void ASTTimer::Update()
{
	LARGE_INTEGER lpPerformanceCount;

	// Is the timer currently freezed?
	if (m_bFreezed) return;

	// Get time difference
	QueryPerformanceCounter(&lpPerformanceCount);
	m_dwTimeNow = (DWORD) lpPerformanceCount.QuadPart;
	m_fTimeDifference = (m_dwTimeNow - m_dwTimeLast) / (float) m_dwFrequency;
	if (!m_bActive || m_fTimeDifference > m_fMaxTimeDifference) m_fTimeDifference = m_fMaxTimeDifference;
	m_dwTimeLast = m_dwTimeNow;

	// Perform slow motion
	if (m_bSlowMotion) m_fTimeDifference *= m_fSlowMotionFactor * m_fCustomSlowMotionFactor;

	// Calculate the current FPS
	m_iFramesSinceCheck++;
	m_fFPSUpdateTimer += m_fTimeDifference;
	if (m_fFPSUpdateTimer > 1.f) {
		m_fFPSUpdateTimer = 0.f;
		m_fFramesPerSecond = (float) m_iFramesSinceCheck * m_dwFrequency / (m_dwTimeNow - m_dwLastFPSUpdateTime);
		if (m_fFramesPerSecond < 0.f) m_fFramesPerSecond = 0.f;
		m_iFramesSinceCheck = 0;
		m_dwLastFPSUpdateTime = m_dwTimeNow;
	}
}
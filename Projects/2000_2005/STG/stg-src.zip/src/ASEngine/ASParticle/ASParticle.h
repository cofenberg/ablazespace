/*
	File: ASParticle.h

	Description: Particle
*/


#ifndef __ASPARTICLE_H__
#define __ASPARTICLE_H__


// Classes
typedef struct ASTParticle {

	bool		bActive;		// Is the particle active?
	
	ASTVector3D vPos;			// Position
	ASTVector3D vFixPos;		// Fixed position
	ASTVector3D vVelocity;		// Velocity
	ASFLOAT4	fColor;			// Color (RGBA)
	float		fEnergie;		// Energie
	float		fSize;			// Size

	int	  iAnimationStep;	// Texture animation step
	float fAnimationTimer;	// Animation timer

	bool		bUseNormal;		// Should the normal be used? (no billbording)
	ASTVector3D	vNormal;		// Distortion

	bool		bDistorted;		// Distorted
	ASTVector3D	vDistortion;	// Distortion

	int   iCustom1;
	int   iCustom2;
	float fCustom1;
	float fCustom2;

} ASTParticle;


#endif // __ASPARTICLE_H__
/*
	File: ASParticleManager.cpp
*/

#include <ASEngineDll.h>


/*
	Constructor
*/
ASTParticleManager::ASTParticleManager()
{
}

/*
	Destructor
*/
ASTParticleManager::~ASTParticleManager()
{
	Cleanup();
}

/*
	Unload all particles
*/
void ASTParticleManager::Clear()
{
	ASTLinkedListElement<ASTParticleGroup*>* pSListElement;
	ASTParticleGroup* pCParticleGroupT;

	// Remove all particles
	pSListElement = m_lstParticleGroupList.FindFirst();
	while (pSListElement) {
		pCParticleGroupT = pSListElement->Data;
		m_lstParticleGroupList.Remove(pCParticleGroupT);
		if (pCParticleGroupT) delete pCParticleGroupT;
		pSListElement = m_lstParticleGroupList.FindNext();
	}
}

/*
	Get the billboard information
*/
void ASTParticleManager::GetBillboardInfo()
{	
	ASFLOAT3 fX, fY;
	float fM[16];

	glGetFloatv(GL_MODELVIEW_MATRIX, fM);
	fX[X] = fM[0];
	fX[Y] = fM[4];
	fX[Z] = fM[8];
	fY[X] = fM[1];
	fY[Y] = fM[5];
	fY[Z] = fM[9];
	ASSubVector(fX, fY, m_fTopLeft);
	ASAddVector(fX, fY, m_fTopRight);
	ASInvertVector(fX, fX);
	ASAddVector(fX, fY, m_fBottomRight);
	ASSubVector(fX, fY, m_fBottomLeft);
	ASScaleVector(m_fTopLeft,     0.2f, m_fTopLeft);
	ASScaleVector(m_fTopRight,    0.2f, m_fTopRight);
	ASScaleVector(m_fBottomRight, 0.2f, m_fBottomRight);
	ASScaleVector(m_fBottomLeft,  0.2f, m_fBottomLeft);
}

/*
	Initialize the particle manager
*/
bool ASTParticleManager::Init()
{
	// Load the standard particle
	_AS::CLog.Output("Initialize particle manager");
	
	return false;
}

/*
	Unload all particles
*/
void ASTParticleManager::Cleanup()
{
	ASTLinkedListElement<ASTParticleGroup*>* pSListElement;

	// Remove all particles
	pSListElement = m_lstParticleGroupList.FindFirst();
	while (pSListElement) {
		if (pSListElement->Data) delete pSListElement->Data;
		pSListElement = m_lstParticleGroupList.FindNext();
	}
	m_lstParticleGroupList.Clear();
}
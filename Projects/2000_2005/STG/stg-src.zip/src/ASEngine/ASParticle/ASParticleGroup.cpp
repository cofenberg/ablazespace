/*
	File: ASParticleGroup.cpp
*/

#include <ASEngineDll.h>


/*
	Initializes the particles
*/	
bool ASTParticleGroup::InitParticles(const int iParticles, const char* pszTextureFilename)
{
	// Delete the old particles
	if (m_pSParticle) {
		delete m_pSParticle;
		m_iParticles = 0;
	}

	// Create the new particles
	if (iParticles <= 0 || !(m_pSParticle = new ASTParticle[iParticles])) return true;
	m_iParticles = iParticles;

	// Load the particle texture
	m_CTexture.Load(pszTextureFilename);

	// Initialize particles
	memset(m_pSParticle, 0, sizeof(ASTParticle) * iParticles);

	SetupTextureAnimation();

	return false;
}

/*
	Activates / deactivates blending
*/
void ASTParticleGroup::SetBlending(const bool bBlending)
{
	m_bBlending = bBlending;
}

/*
	Returns whether blending is active or not
*/
bool ASTParticleGroup::GetBlending() const
{
	return m_bBlending;
}

/*
	Sets the blend function
*/
void ASTParticleGroup::SetBlendFunction(const int iBlendFunctionS, const int iBlendFunctionD)
{
	m_iBlendFunctionS = iBlendFunctionS;
	m_iBlendFunctionD = iBlendFunctionD;
}

/*
	Sets the bounding box
*/
void ASTParticleGroup::SetBoundingBox(const ASFLOAT3 fBoundingBox)
{
	memcpy(&m_fBoundingBox, fBoundingBox, sizeof(ASFLOAT3));
	m_bBoundingBox = true;
}

/*
	Returns the number of particles in the particle group
*/
int ASTParticleGroup::GetParticles() const
{
	return m_iParticles;
}

/*
	Returns a pointer to a particle
*/
ASTParticle* ASTParticleGroup::GetParticle(const int iParticle) const
{
	if (iParticle > m_iParticles) return NULL;

	return &m_pSParticle[iParticle];
}

/*
	Returns a pointer to a free particle
*/
ASTParticle* ASTParticleGroup::GetFreeParticle() const
{
	ASTParticle* pSParticle     = &m_pSParticle[0],
			   * pSLastParticle = &m_pSParticle[m_iParticles];

	for(; pSParticle < pSLastParticle; pSParticle++)
		if (!pSParticle->bActive) return pSParticle;

	return NULL;
}

/*
	Configures the texture animation
*/
void ASTParticleGroup::SetupTextureAnimation(const int iColumns, const int iRows)
{
	ASTParticleTexCoord STexCoord;

	m_lstTexCoord.Clear();
	if (iColumns == -1 || iRows == -1 || !m_CTexture.GetTexture()) {
		m_bTextureAnimation		   = false;
		m_iTextureAnimationColumns = 0;
		m_iTextureAnimationRows    = 0;
		STexCoord.fTexCoord[0][X]  = 1.f;
		STexCoord.fTexCoord[0][Y]  = 0.f;
		STexCoord.fTexCoord[1][X]  = 1.f;
		STexCoord.fTexCoord[1][Y]  = 1.f;
		STexCoord.fTexCoord[2][X]  = 0.f;
		STexCoord.fTexCoord[2][Y]  = 1.f;
		STexCoord.fTexCoord[3][X]  = 0.f;
		STexCoord.fTexCoord[3][Y]  = 0.f;
		m_lstTexCoord.Add(STexCoord);
	} else {
		float fX, fY, fWidth, fHeight;
		int iX, iY;

		m_bTextureAnimation		   = true;
		m_iTextureAnimationColumns = iColumns;
		m_iTextureAnimationRows    = iRows;

		// Create the list of texture coordinates
		for (int i = 0; i < iColumns * iRows; i++) {
			iY		= (int) i / m_iTextureAnimationColumns;
			iX	    = i - iY * m_iTextureAnimationColumns;
			fWidth  = (float) m_CTexture.GetTexture()->GetWidth() / m_iTextureAnimationColumns / m_CTexture.GetTexture()->GetHeight();
			fHeight = (float) m_CTexture.GetTexture()->GetWidth() / m_iTextureAnimationRows    / m_CTexture.GetTexture()->GetHeight();
			fX		= fWidth  * iX;
			fY		= fHeight * iY;

			// Setup texture coordinates
			STexCoord.fTexCoord[0][X] = fX + fWidth;
			STexCoord.fTexCoord[0][Y] = fY - fHeight;
			STexCoord.fTexCoord[1][X] = fX + fWidth;
			STexCoord.fTexCoord[1][Y] = fY;
			STexCoord.fTexCoord[2][X] = fX;
			STexCoord.fTexCoord[2][Y] = fY;
			STexCoord.fTexCoord[3][X] = fX;
			STexCoord.fTexCoord[3][Y] = fY - fHeight;
			m_lstTexCoord.Add(STexCoord);
		}
	}
}

/*
	Returns the number of texture animation steps
*/
int ASTParticleGroup::GetTextureAnimationSteps()
{
	return m_lstTexCoord.GetElements();
}

/*
	Gets the bounding box automatically
*/
void ASTParticleGroup::AutoBoundingBox()
{
	ASTParticle* pSParticle     = &m_pSParticle[0],
			   * pSLastParticle = &m_pSParticle[m_iParticles];
	int i;

	if (!pSParticle || !pSLastParticle) return;

	// Get the bounding box
	memset(&m_fBoundingBox, 0, sizeof(ASBOUNDINGBOX));
	for(; pSParticle < pSLastParticle; pSParticle++) {
		if (!pSParticle->bActive) continue;

		for (i = 0; i < 3; i++) {
			if (pSParticle->vPos.fV[i] - pSParticle->fSize / 20 < m_fBoundingBox[0][i])
				m_fBoundingBox[0][i] = pSParticle->vPos.fV[i] - pSParticle->fSize / 20;
			if (pSParticle->vPos.fV[i] + pSParticle->fSize / 20 > m_fBoundingBox[1][i])
				m_fBoundingBox[1][i] = pSParticle->vPos.fV[i] + pSParticle->fSize / 20;
		}
	}

	// Avoids an invalid bounding box
	if (!(m_fBoundingBox[0][X] + m_fBoundingBox[0][Y] + m_fBoundingBox[0][Z] +
		  m_fBoundingBox[1][X] + m_fBoundingBox[1][Y] + m_fBoundingBox[1][Z])) {
		m_fBoundingBox[0][X] = GetPos().fX - 1.f;
		m_fBoundingBox[0][Y] = GetPos().fY - 1.f;
		m_fBoundingBox[0][Z] = GetPos().fZ - 1.f;
		m_fBoundingBox[1][X] = GetPos().fX + 1.f;
		m_fBoundingBox[1][Y] = GetPos().fY + 1.f;
		m_fBoundingBox[1][Z] = GetPos().fZ * 1.f;
	}
	m_bBoundingBox = true;
}

/*
	Should the particle group be removed automatically after all particles are inactive?
*/
void ASTParticleGroup::RemoveAutomatically(const bool bRemoveAutomatically)
{
	m_bRemoveAutomatically = bRemoveAutomatically;
}

/*
	Returns whether the particle group should be removed automatically after all particles are inactive or not
*/
bool ASTParticleGroup::RemoveAutomatically() const
{
	return m_bRemoveAutomatically;
}

/*
	This function is called if the particle group is initialized
*/
void ASTParticleGroup::CustomInitFunction()
{
	SetBlending();
	SetBlendFunction();
	m_iParticles			   = 0;
	m_pSParticle			   = NULL;
	m_bTextureAnimation		   = false;
	m_iTextureAnimationColumns = 0;
	m_iTextureAnimationRows    = 0;

	// Initialize the bounding box
	m_bBoundingBox = false;
	memset(&m_fBoundingBox, 0, sizeof(ASBOUNDINGBOX));
}

/*
	This function is called if the particle group is de-initialized
*/
void ASTParticleGroup::CustomDeInitFunction()
{
	// Call custum particle de-initialization function
	CustomParticleDeInitFunction();

	// Destroy particles
	if (m_pSParticle) {
		delete m_pSParticle;
		m_pSParticle = NULL;
	}

	// Clear texture coordinate list
	m_lstTexCoord.Clear();

	// Unload the particle texture
	m_CTexture.Unload();
}

/*
	Checks whether the particle group is in the frustum or not
*/
bool ASTParticleGroup::CustomFrustumFunction()
{
	if (m_bBoundingBox && !_AS::CFrustum.IsCubeIn(m_fBoundingBox)) return false;
	else																   return true;

}

/*
	This function is called if the particle group is drawn
*/
void ASTParticleGroup::CustomDrawSolidFunction()
{
	if (m_bBlending) return;

	// Show particle?
	if (!_AS::CConfig.DrawParticles()) return;

	// Is the particle group visible?
	if (!InFrustum()) return;
	
	glDisable(GL_BLEND);
	glDisable(GL_CULL_FACE);
	glDisable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_DEPTH_TEST);

	Draw();

	glDisable(GL_BLEND);
	glEnable(GL_CULL_FACE);

	if (_AS::CConfig.ShowBoundingBoxes() && m_bBoundingBox)
		_AS::CRenderer.ShowBoundingBox(m_fBoundingBox);
}

/*
	This function is called if the particle group is drawn transparent
*/
void ASTParticleGroup::CustomDrawTransparentFunction()
{
	if (!m_bBlending) return;

	// Show particle?
	if (!_AS::CConfig.DrawParticles()) return;

	// Is the particle group visible?
	if (!InFrustum()) return;

	glEnable(GL_BLEND);
	glDisable(GL_CULL_FACE);
	glDisable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);
	glDepthMask(FALSE);
	glEnable(GL_DEPTH_TEST);
	glBlendFunc(m_iBlendFunctionS, m_iBlendFunctionD);

	Draw();

	glDepthMask(TRUE);
	glDisable(GL_BLEND);
	glEnable(GL_CULL_FACE);

	if (_AS::CConfig.ShowBoundingBoxes() && m_bBoundingBox)
		_AS::CRenderer.ShowBoundingBox(m_fBoundingBox);
}

/*
	This function is called if the particle group is updated
*/
void ASTParticleGroup::CustomUpdateFunction()
{
	// Is the light visible?
	if (!InFrustum()) return;
}

/*
	Is called if the particle group is de-initialized
*/
void ASTParticleGroup::CustomParticleDeInitFunction()
{
}

/*
	Draws the particles
*/
void ASTParticleGroup::Draw()
{
	ASTParticle* pSParticle     = &m_pSParticle[0],
			   * pSLastParticle = &m_pSParticle[m_iParticles];

	if (!pSParticle || !pSLastParticle) return;

	// Get billboard information
	_AS::CParticleManager.GetBillboardInfo();

	// Pointer to billboard information (faster access :)
	ASFLOAT3* pfTopLeft     = &_AS::CParticleManager.m_fTopLeft,
			* pfTopRight    = &_AS::CParticleManager.m_fTopRight,
			* pfBottomRight = &_AS::CParticleManager.m_fBottomRight,
			* pfBottomLeft  = &_AS::CParticleManager.m_fBottomLeft;
	ASFLOAT3 fTopLeft, fTopRight, fBottomLeft, fBottomRight;

	// Bind particle texture
	m_CTexture.GetTexture()->BindOpenGLTexture();

	// Draw the particles
	glBegin(GL_QUADS);
		for(; pSParticle < pSLastParticle; pSParticle++) {
			if (!pSParticle->bActive) continue;

			if (!m_bBoundingBox && !_AS::CFrustum.IsPointIn(pSParticle->vPos)) continue;

			// Compute particle position
			ASScaleVector(*pfTopLeft,     pSParticle->fSize, fTopLeft);
			ASScaleVector(*pfTopRight,    pSParticle->fSize, fTopRight);
			ASScaleVector(*pfBottomRight, pSParticle->fSize, fBottomRight);
			ASScaleVector(*pfBottomLeft,  pSParticle->fSize, fBottomLeft);
			ASAddVector(pSParticle->vPos.fV, fTopLeft,     fTopLeft);
			ASAddVector(pSParticle->vPos.fV, fTopRight,    fTopRight);
			ASAddVector(pSParticle->vPos.fV, fBottomRight, fBottomRight);
			ASAddVector(pSParticle->vPos.fV, fBottomLeft,  fBottomLeft);

			// Draw the particle:
			glColor4fv(pSParticle->fColor);
			glTexCoord2fv(m_lstTexCoord[pSParticle->iAnimationStep]->fTexCoord[0]);
			glVertex3fv(fTopLeft);
			glTexCoord2fv(m_lstTexCoord[pSParticle->iAnimationStep]->fTexCoord[1]);
			glVertex3fv(fTopRight);
			glTexCoord2fv(m_lstTexCoord[pSParticle->iAnimationStep]->fTexCoord[2]);
			glVertex3fv(fBottomRight);
			glTexCoord2fv(m_lstTexCoord[pSParticle->iAnimationStep]->fTexCoord[3]);
			glVertex3fv(fBottomLeft);

			_AS::CRenderer.AddTriangles(2);
		}
	glEnd();
}
/*
	File: ASParticleManager.h

	Description: Particle manager
*/


#ifndef __ASPARTICLEMANAGER_H__
#define __ASPARTICLEMANAGER_H__


// Predefinitions
typedef class ASTParticleManager ASTParticleManager;


// Definitions
#define ASSTANDARDPARTICLETEXTURE "standardparticle.jpg" // The standard particle texture


// Inludes
#include "ASParticle.h"
#include "ASParticleGroup.h"


// Classes
typedef class ASTParticleManager {

	friend _AS;
	friend ASTParticleGroup;


	public:
		/*
			Constructor
		*/
		AS_API ASTParticleManager();

		/*
			Destructor
		*/
		AS_API ~ASTParticleManager();

		/*
			Unload all particles

			Notes:
				- All particle handlers will loose their particles
				- Use this function only if you really want to unload all particles
				- The standard particle will stay alive
		*/
		AS_API void Clear();


	private:
		ASTLinkedList<ASTParticleGroup*> m_lstParticleGroupList;			// Linked list of all particle groups
	
		// Billboard information
		ASFLOAT3 m_fTopLeft, m_fTopRight, m_fBottomRight, m_fBottomLeft;


		/*
			Get the billboard information
		*/
		void GetBillboardInfo();

		/*
			Initialize the particle manager

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Init();

		/*
			Unload all particles

			Notes:
				- All particle handlers will loose their particles
				- Use this function only if you really want to unload all particles
				- The standard particle will be unloaded, too!
		*/
		void Cleanup();


} ASTParticleManager;


#endif // __ASPARTICLEMANAGER_H__
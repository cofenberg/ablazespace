/*
	File: ASParticleGroup.h

	Description: ParticleGroup
*/


#ifndef __ASPARTICLEGROUP_H__
#define __ASPARTICLEGROUP_H__


// Structures
typedef struct ASTParticleTexCoord {
	ASFLOAT2 fTexCoord[4];

} ASTParticleTexCoord;


// Classes
typedef class ASTParticleGroup : public ASTEntity {

	friend ASTParticleManager;


	public:
		/*
			Initializes the particles

			Parameters:
				int   iParticles		 -> Number of particles
				char* pszTextureFilename -> Filename of the particle texture

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/	
		AS_API bool InitParticles(const int iParticles, const char* pszTextureFilename);

		/*
			Activates / deactivates blending

			Parameters:
				bool bBlending -> Should the blending be active?
		*/
		AS_API void SetBlending(const bool bBlending = true);

		/*
			Returns whether blending is active or not

			Returns:
				bool -> 'true' if the blending is active else 'false'
		*/
		AS_API bool GetBlending() const;

		/*
			Sets the blend function

			Parameters:
				int iBlendFunctionS -> Source blending factor
				int iBlendFunctionD -> Destination blending factor

		*/
		AS_API void SetBlendFunction(const int iBlendFunctionS = GL_SRC_ALPHA, const int iBlendFunctionD = GL_ONE);

		/*
			Sets the bounding box
		*/
		AS_API void SetBoundingBox(const ASFLOAT3 fBoundingBox);

		/*
			Returns the number of particles in the particle group

			Returns:
				int -> Number of particles in the particle group
		*/
		AS_API int GetParticles() const;

		/*
			Returns a pointer to a particle

			Parameters:
				int iParticle -> Particle ID
			
			Returns:
				ASTParticle* -> Pointer to the particle
		*/
		AS_API ASTParticle* GetParticle(const int iParticle = 0) const;

		/*
			Returns a pointer to a free particle
			
			Returns:
				ASTParticle* -> Pointer to a free particle
		*/
		AS_API ASTParticle* GetFreeParticle() const;

		/*
			Configures the texture animation

			Parameters:
				int iColumns -> Number of animation frame columns in the texture
				int iRows    -> Number of animation frame rows in the texture

			Notes:
				- If 'iColumns' or / and 'iRows' is '-1' there will be no texture animation
		*/
		AS_API void SetupTextureAnimation(const int iColumns = -1, const int iRows = -1);

		/*
			Returns the number of texture animation steps

			Returns:
				int -> The number of texture animation steps
		*/
		AS_API int GetTextureAnimationSteps();

		/*
			Gets the bounding box automatically

			Notes:
				- Gets the current bounding box by checking each particle
				- Try to avoid calling this function each frame (performance)
		*/
		AS_API void AutoBoundingBox();

		/*
			Should the particle group be removed automatically after all particles are inactive?

			Parameters:
				bool bRemoveAutomatically -> Should the particle group be removed automatically?
		*/
		AS_API void RemoveAutomatically(const bool bRemoveAutomatically);

		/*
			Returns whether the particle group should be removed automatically after all particles are inactive or not

			Returns:
				bool -> 'true' if the particle group should be removed automatically else 'false'
		*/
		AS_API bool RemoveAutomatically() const;


	private:
		bool	 m_bBoundingBox;	// Does the particle group have a bounding box?
		ASFLOAT3 m_fBoundingBox[2];	// Bounding box

		bool m_bRemoveAutomatically; // Should the particle group be removed automatically?

		bool m_bBlending;		// Use blending?
		int  m_iBlendFunctionS; // Source blending factor
		int  m_iBlendFunctionD; // Destination blending factor

		int			 m_iParticles; // Number of particles
		ASTParticle* m_pSParticle; // The particles

		ASTTextureHandler m_CTexture;					// Particle texture
		bool			  m_bTextureAnimation;			// Is there a texture animation?
		int				  m_iTextureAnimationColumns;	// Number of animation frame columns in the texture
		int				  m_iTextureAnimationRows;		// Number of animation frame rows in the texture

		ASTDynamicLinkedList<ASTParticleTexCoord> m_lstTexCoord;	// A list of all texture coordinates


		/*
			Virtual entity functions
		*/
		AS_API virtual void CustomInitFunction();
		AS_API virtual void CustomDeInitFunction();
		AS_API virtual bool CustomFrustumFunction();
		AS_API virtual void CustomDrawSolidFunction();
		AS_API virtual void CustomDrawTransparentFunction();
		AS_API virtual void CustomUpdateFunction();

		/*
			Is called if the particle group is de-initialized
		*/
		AS_API virtual void CustomParticleDeInitFunction();

		/*
			Draws the particles
		*/
		AS_API void Draw();
	

} ASTParticleGroup;


#endif // __ASPARTICLEGROUP_H__
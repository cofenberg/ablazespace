/*
	File: ASLog.h

	Description: Log code
*/


#ifndef __ASLOG_H__
#define __ASLOG_H__


// Definitions
#define ASLOGFILE "aslog"	// Name of the standard log file


// Classes
typedef class ASTLog {

	friend _AS;
	

	public:
		/*
			Destructor
		*/
		AS_API ~ASTLog();

		/*
			Writes a normal string into the log

			Parameters:
				char* pszText -> Text which should be written into the log

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool OutputString(const char* pszText);

		/*
			Writes a string into the log

			Parameters:
				char* pszText -> Text which should be written into the log

			Returns:
				bool -> 'false' if all went fine else 'true'

			Notes:
				- The length of the possible output string is limited. In some cases it
				  is isn't long enough and the operation will fail. Use the other output
				  function for long output strings
		*/
		AS_API bool Output(const char* pszText, ...);

		/*
			Opens the log file
		*/
		AS_API void Open();


	private:
		char  m_szFilename[256];	// The log filename
		FILE* m_pFile;				// Pointer to the log file


		/*
			Initializes the log

			Returns:
				bool -> 'false' if all went fine else 'true'

			Parameters:
				char*	   pszFilename -> The logs filename
		*/
		bool Init(const char* pszFilename = ASLOGFILE);

		/*
			Shutdown the log

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Shutdown();

		/*
			Updates all log relevant stuff
		*/
		void Update();


} ASTLog;


#endif // __ASLOG_H__
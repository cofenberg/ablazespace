/*
	File: ASLog.cpp
*/

#include <ASEngineDll.h>


/*
	Destructor
*/
ASTLog::~ASTLog()
{
	Shutdown();
}

/*
	Writes a normal string into the log
*/
bool ASTLog::OutputString(const char* pszText)
{
	// Could we write into the log?
	if (!_AS::CConfig.IsLogActivated() || !m_pFile) return true; // Nope!
	
	// Write the text and a newline
	fprintf(m_pFile, pszText);
	putc('\n', m_pFile);
	fflush(m_pFile);

	return false;
}

/*
	Writes a string into the log
*/
bool ASTLog::Output(const char* pszText, ...)
{
	va_list arg_list;

	// Could we write into the log?
	if (!_AS::CConfig.IsLogActivated() || !m_pFile) return true; // Nope!
	
	// Initialize variable argument list
	va_start(arg_list, pszText);

	// Write the text and a newline
	vfprintf(m_pFile, pszText, arg_list);
	putc('\n', m_pFile);
	fflush(m_pFile);

	va_end(arg_list);

	return false;
}

/*
	Opens the log file
*/
void ASTLog::Open()
{
	_AS::CFileSystem.Open(m_szFilename);
}

/*
	Initializes the log
*/
bool ASTLog::Init(const char* pszFilename)
{
	char szTemp[256];

	// Check pointer
	if (!pszFilename) return true;

	// Setup filename information
	strcpy(m_szFilename, pszFilename);
	_AS::CFileSystem.GetFullFilename(m_szFilename, ASLOG_FILE);

	// Create the log
	if (!(m_pFile = fopen(m_szFilename, "wt"))) {
		// Give out an error message
		sprintf(szTemp, "Couldn't open the log (%s)\nGo sure that this file is writable!", m_szFilename);
		MessageBox(NULL, szTemp, "Error", MB_OK | MB_ICONINFORMATION);

		return true;
	}

	// Create the log header:
	Output("Log-system started");
	Output("\n");
	Output("< AS-Engine "ASENGINEVERSION" >");
	Output("Build: "__DATE__" "__TIME__"");
	Output("\n");

	// Print out the general system info:
	Output("General system info:");
	{
		unsigned long i = 256;
		char szUserName[256];

		GetUserName(szUserName, &i);
		Output("User name: %s", szUserName);
	}
	Output("CPU: %d Mhz", _AS::CTools.GetCpuMhz());
	if (GetSystemMetrics(SM_MOUSEPRESENT)) Output("There is a mouse");
	else Output("There is no mouse");
	Output("Number of mouse buttons: %d", GetSystemMetrics(SM_CMOUSEBUTTONS));
	Output("Desktop resolution: %dx%d", GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN));

	// Print out path information:
	Output("Application path: %s", _AS::CFileSystem.GetApplicationPath());

	// Start enumerate messages
	Output("\n\n");
	Output("Messages:");

	return false;
}

/*
	Shutdown the log
*/
bool ASTLog::Shutdown()
{
	Output("Close log");
	if (m_pFile) {
		fclose(m_pFile);

		return false;
	}

	return true;
}

/*
	Updates all log relevant stuff
*/
void ASTLog::Update()
{
	// Check if the log should be opened (Strg-l)
	if (_AS::CConfig.IsDebugMode() && _AS::CInput.IsKeyPressed(29) && 
		_AS::CInput.IsKeyHit(DIK_L))
		Open();
}

/*
	File: ASSound.h

	Description: Sound code
*/


#ifndef __ASSOUND_H__
#define __ASSOUND_H__


// Classes
typedef class ASTSound {
	
	friend ASTSoundManager;
	friend ASTSoundHandler;


	public:
		/*
			Constructor
		*/
		AS_API ASTSound();
		/*
			Parameters:
				ASTSoundHandler* pSSoundHandler -> Pointer to the sound handler using this sound
				char*			 pszFilename    -> The filename of the sound

			Notes:
				- Filename: The standard sound directory will be used normally but you
							are also allowed to use your own directories
		*/
		AS_API ASTSound(ASTSoundHandler* pSSoundHandler, const char* pszFilename = NULL);

		/*
			Destructor
		*/
		AS_API ~ASTSound();

		/*
			Returns the sound name

			Returns:
				char* -> Pointer to the sound filename
		*/
		AS_API const char* GetFilename() const;

		/*
			Sets the sound protection state

			Parameters:
				bool bProtected -> Should the sound be protected or not?

			Notes:
				- If the sound is protected it will not be removed if the sound manager
				  tries it (it's only removed if the application is shut down :)
				- The standard sound is always protected because there must be at least one
				  sound in the sound manager
		*/
		AS_API void SetProtected(const bool bProtected = false);

		/*
			Returns whether the sound is protected or not

			Returns:
				bool -> 'true' if the sound is protected else 'false'
		*/
		AS_API bool IsProtected() const;

		/*
			Reloads the sound

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Reload();

		/*
			Plays the sound

			Returns:
				int -> The channel were the sound is played

			Notes:
				- In some chases (e.g. mods) no channels are used (-1)
		*/
		AS_API int Play();

		/*
			Stops the sound

			Parameters:
				int iChannel -> Sound channel

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Stop(const int iChannel);

		/*
			Stops the sound (for all sound handlers)
		*/
		AS_API bool Stop();

		/*
			Stops the sound (for all sound handlers)

			Notes:
				- Stops only sound effects
		*/
		AS_API bool StopSound();

		/*
			Stops the sound (for all sound handlers)

			Notes:
				- Stops only music
		*/
		AS_API bool StopMusic();


	private:
		char		   m_szFilename[256];		// Filename of the sound
		bool		   m_bLoaded;				// Is the sound loaded?
		bool		   m_bProtected;			// Is this sound protected (couldn't be unloaded with normal functions)

		bool  m_bStreaming;		// Should the sound be streamed?
		bool  m_b2D;			// Is this a 2D sound? (else its a 3D sound)
		bool  m_bLoop;			// Should the sound be looped?
		float m_fDistanceMin;	// Minimum distance (3D)
		float m_fDistanceMax;	// Maximum distance (3D)

		FMUSIC_MODULE* m_pMod;		// Mod pointer
		FSOUND_SAMPLE* m_pSample;	// Sample pointer
		FSOUND_STREAM* m_pStream;	// Stream pointer

		ASTLinkedList<ASTSoundHandler*> m_lstHandler; // Linked list of all sound handlers
													  // using this sound


		/*
			Loads the sound data depending of the sound type

			Parameters:
				ASTSoundHandler* pSSoundHandler -> Pointer to the sound handler using this sound
				char*			 pszFilename    -> The filename of the sound

			Returns:
				int -> The number of sound handlers using this sound

			Notes:
				- Filename: The standard sound directory will be used normally but you
							are also allowed to use your own directories
				- If a 'ast'-file for the sound filename exist some parameters are writen over
		*/
		int Load(ASTSoundHandler* pSSoundHandler, const char* pszFilename = NULL);

		/*
			Unload the sound

			Parameters:
				ASTSoundHandler* pSSoundHandler -> Pointer to the sound handler using this sound

			Returns:
				int -> The number of sound handlers using this sound.
					   If it is '-1' the given sound handler wasn't listed in the sounds sound handler list.
					   '-2' if the sound is now unused..
		*/
		int Unload(ASTSoundHandler* pSSoundHandler);

		/*
			Could the sound be played more as once at the same time? 
			
			Returns:
				bool -> 'true' if the sound could be played more that once at the same time else 'false'
		*/
		bool IsMultiple();

		/*
			Updates the sound volume
		*/
		void UpdateVolume();

		/*
			Unload the sound immediately
		*/
		void Clear();

		/*
			Unload the sound data
		*/
		void UnloadData();


} ASTSound;


#endif // __ASSOUND_H__
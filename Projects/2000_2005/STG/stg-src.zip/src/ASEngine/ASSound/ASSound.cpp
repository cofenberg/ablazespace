/*
	File: ASSound.cpp
*/

#include <ASEngineDll.h>


/*
	Constructor
*/
ASTSound::ASTSound()
{
	memset(this, 0, sizeof(ASTSound));
}

ASTSound::ASTSound(ASTSoundHandler* pSSoundHandler, const char* pszFilename)
{
	memset(this, 0, sizeof(ASTSound));
	Load(pSSoundHandler, pszFilename);
}

/*
	Destructor
*/
ASTSound::~ASTSound()
{
	Clear();
}

/*
	Returns the sound name
*/
const char* ASTSound::GetFilename() const
{
	return m_szFilename;
}

/*
	Sets the sound protection state
*/
void ASTSound::SetProtected(const bool bProtected)
{
	if (_AS::CSoundManager.GetStandardSound() == this) return;
	m_bProtected = bProtected;
}

/*
	Returns whether the sound is protected or not
*/
bool ASTSound::IsProtected() const
{
	return m_bProtected;
}

/*
	Reloads the sound
*/
bool ASTSound::Reload()
{
	bool bError = false;

	UnloadData();
	if (Load(NULL, m_szFilename))
		bError = true;

	return bError;
}

/*
	Plays the sound
*/
int ASTSound::Play()
{
	int iChannel;

	if (m_pMod) {
	    FMUSIC_PlaySong(m_pMod);
	} else {
		if (m_pSample) {
          	iChannel = FSOUND_PlaySound(FSOUND_FREE, m_pSample);
		} else if (m_pStream) {
			iChannel = FSOUND_Stream_Play(FSOUND_FREE, m_pStream);
		} else return -1;
	}

	return iChannel;
}

/*
	Stops the sound
*/
bool ASTSound::Stop(const int iChannel)
{
	if (m_pMod) {
	    FMUSIC_StopSong(m_pMod);
	} else {
		if (m_pSample) {
			if (iChannel >= 0) FSOUND_StopSound(iChannel);
		} else if (m_pStream) {
			FSOUND_Stream_Stop(m_pStream);
		} else return true;
	}

	return false;
}

/*
	Stops the sound (for all sound handlers)
*/
bool ASTSound::Stop()
{
	ASTLinkedListElement<ASTSoundHandler*>* pListElement;

	// Update sound handlers using this sound
	pListElement = m_lstHandler.FindFirst();
	while (pListElement) {
		pListElement->Data->Stop();
		pListElement = m_lstHandler.FindNext();
	}

	return false;
}

/*
	Stops the sound (for all sound handlers)
*/
bool ASTSound::StopSound()
{
	ASTLinkedListElement<ASTSoundHandler*>* pListElement;

	// Update sound handlers using this sound
	pListElement = m_lstHandler.FindFirst();
	while (pListElement) {
		if (!pListElement->Data->IsMusic()) pListElement->Data->Stop();
		pListElement = m_lstHandler.FindNext();
	}

	return false;
}

/*
	Stops the sound (for all sound handlers)
*/
bool ASTSound::StopMusic()
{
	ASTLinkedListElement<ASTSoundHandler*>* pListElement;

	// Update sound handlers using this sound
	pListElement = m_lstHandler.FindFirst();
	while (pListElement) {
		if (pListElement->Data->IsMusic()) pListElement->Data->Stop();
		pListElement = m_lstHandler.FindNext();
	}

	return false;
}

/*
	Could the sound be played more as once at the same time? 
*/
bool ASTSound::IsMultiple()
{
	if (m_pMod || m_pStream) return false;
	else				 	 return true;
}

/*
	Loads the sound data depending of the sound type
*/
int ASTSound::Load(ASTSoundHandler* pSSoundHandler, const char* pszFilename)
{
	char szTemp[256], szFilename[256];
	bool bError = false;

	// Check if the sound is already loaded
	if (m_bLoaded) {
		if (pSSoundHandler) {
			if (!IsMultiple()) return -1;
			pSSoundHandler->m_pCSound = this;
			m_lstHandler.Add(pSSoundHandler);
		}

		return m_lstHandler.GetElements();
	}

	// Get valid filename
	_AS::CSoundManager.GetValidFilename(pszFilename, m_szFilename);

	_AS::CLog.Output("Load sound: %s", m_szFilename);

	// Load 'ass'-file
	strcpy(szFilename, m_szFilename);
	_AS::CFileSystem.CutFilenameEnding(szFilename);
	_AS::CFileSystem.GetFullFilename(szFilename, ASSOUND_FILE);

	m_bStreaming   = GetPrivateProfileInt("general", "streaming",       0, szFilename) != 0;
	m_b2D		   = GetPrivateProfileInt("general", "2d",		        0, szFilename) != 0;
	m_bLoop		   = GetPrivateProfileInt("general", "loop",		    0, szFilename) != 0;
	GetPrivateProfileString("general", "distance_min", "5", szTemp, 256, szFilename);
	m_fDistanceMin = (float) atof(szTemp);
	GetPrivateProfileString("general", "distance_max", "10000", szTemp, 256, szFilename);
	m_fDistanceMax = (float) atof(szTemp);

	// Load the sound
	if (!(m_pMod = FMUSIC_LoadSong(m_szFilename))) {
		int iFlag;

		if (m_b2D) iFlag = FSOUND_HW2D;
		else	   iFlag = FSOUND_HW3D;
		if (!m_bStreaming) {
			if (!(m_pSample = FSOUND_Sample_Load(FSOUND_FREE, m_szFilename, FSOUND_NORMAL | iFlag, 0)))
				bError = true;
			else {
				if (!m_b2D)  FSOUND_Sample_SetMinMaxDistance(m_pSample, m_fDistanceMin, m_fDistanceMax);
				if (m_bLoop) FSOUND_Sample_SetMode(m_pSample, FSOUND_LOOP_NORMAL);
				else		 FSOUND_Sample_SetMode(m_pSample, FSOUND_LOOP_OFF);
			}
		} else {
			if (m_bLoop) {
				if (!(m_pStream = FSOUND_Stream_OpenFile(m_szFilename, FSOUND_LOOP_NORMAL | FSOUND_MPEGACCURATE | iFlag, 0)))
					bError = true;
			} else {
				if (!(m_pStream = FSOUND_Stream_OpenFile(m_szFilename, FSOUND_LOOP_OFF | FSOUND_MPEGACCURATE | iFlag, 0)))
					bError = true;
			}
		}
	} else {
		m_b2D = true;
		if (FMUSIC_GetType(m_pMod) == FMUSIC_TYPE_MOD ||
			FMUSIC_GetType(m_pMod) == FMUSIC_TYPE_S3M)
			FMUSIC_SetPanSeperation(m_pMod, 0.85f); // 15% crossover
	}

	// Check if there was an error
	if (bError) {
		_AS::CLog.Output("Couldn't load sound. Error: %s", FMOD_ErrorString(FSOUND_GetError()));
		if (pSSoundHandler) pSSoundHandler->m_pCSound = _AS::CSoundManager.GetStandardSound();

		return -1;
	}

	m_bLoaded = true;

	// Add the sound handler
	if (pSSoundHandler) {
		pSSoundHandler->m_pCSound = this;
		m_lstHandler.Add(pSSoundHandler);
	}

	return m_lstHandler.GetElements();
}

/*
	Unload the sound
*/
int ASTSound::Unload(ASTSoundHandler* pSSoundHandler)
{
	// Check if this sound handler is listed in this sound
	if (m_lstHandler.Remove(pSSoundHandler)) return -1;

	// Set the sound handlers sound to NULL
	pSSoundHandler->m_pCSound = NULL;

	// Is the sound now unused?
	if (!_AS::CSoundManager.GetUnloadUnusedSounds() ||
		m_bProtected || !m_lstHandler.IsEmpty())
		return m_lstHandler.GetElements();

	// Setup sound data
	UnloadData();

	return -2;
}

/*
	Updates the sound volume
*/
void ASTSound::UpdateVolume()
{
	ASTLinkedListElement<ASTSoundHandler*>* pListElement;

	// Update sound handlers using this sound
	pListElement = m_lstHandler.FindFirst();
	while (pListElement) {
		pListElement->Data->UpdateSoundVolume();
		pListElement = m_lstHandler.FindNext();
	}
}

/*
	Unload the sound immediately
*/
void ASTSound::Clear()
{
	ASTLinkedListElement<ASTSoundHandler*>* pListElement;

	if (!m_bLoaded) return;

	// Unload sound data
	UnloadData();

	// Update sound handlers using this sound
	pListElement = m_lstHandler.FindFirst();
	while (pListElement) {
		if (_AS::CSoundManager.GetStandardSound() &&
			_AS::CSoundManager.GetStandardSound() != this)
			pListElement->Data->Load(_AS::CSoundManager.GetStandardSound()->GetFilename());
		else {
			pListElement->Data->m_pCSound = NULL;
			pListElement->Data->Unload();
		}
		pListElement = m_lstHandler.FindNext();
	}
	m_lstHandler.Clear();
}

/*
	Unload the sound data
*/
void ASTSound::UnloadData()
{
	if (!m_bLoaded) return;

	_AS::CLog.Output("Delete sound '%s'", m_szFilename);
	Stop(-1);

	if (m_pMod) {
		FMUSIC_FreeSong(m_pMod);
		m_pMod = NULL;
	} else {
		if (m_pSample) {
			FSOUND_Sample_Free(m_pSample);
			m_pSample = NULL;
		} else if (m_pStream) {
			FSOUND_Stream_Close(m_pStream);
			m_pStream = NULL;
			m_bStreaming = false;
		}
	}

	m_bLoaded = false;
}
/*
	File: ASSoundHandler.h

	Description: Sound handler code
*/


#ifndef __ASSOUNDHANDLER_H__
#define __ASSOUNDHANDLER_H__


// Classes
typedef class ASTSoundHandler : public ASTEntity {
	
	friend ASTSoundManager;
	friend ASTSound;


	public:
		/*
			Constructor

			Parameters:
				char* pszFilename -> Sound filename

			Notes:
				- Filename: The standard sound directory will be used normally but you
							are also allowed to use your own directories
		*/
		AS_API ASTSoundHandler(const char* pszFilename = ASSTANDARDSOUND);

		/*
			Destructor
		*/
		AS_API ~ASTSoundHandler();

		/*
			Loads a sound

			Parameters:
				char* pszFilename -> Sound filename

			Returns:
				bool -> 'false' if all went fine else 'true'

			Notes:
				- Filename: The standard sound directory will be used normally but you
							are also allowed to use your own directories
		*/
		AS_API bool Load(const char* pszFilename = ASSTANDARDSOUND);

		/*
			Returns if the sound handler has a sound or not	

			Returns:
				bool -> 'true' if the sound handler has a sound else 'false'
		*/
		AS_API bool IsLoaded() const;

		/*
			Unloads the sound

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Unload();

		/*
			Returns the sound handler sound

			Returns:
				ASTSound* -> Pointer to the sound handlers sound
		*/
		AS_API ASTSound* GetSound() const;

		/*
			Plays the sound

			Parameters:
				bool bStopLast -> Should the last sound playback be stopped?
								  (use it especially for looped sounds!)

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Play(const bool bStopLast = true);

		/*
			Stops the sound

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Stop();

		/*
			Checks wether the sound is played or not

			Returns:
				bool -> 'true' if the sound is played at the moment else 'false'
		*/
		AS_API bool IsPlaying();

		/*
			Sets the volume

			Parameters:
				float fVolume -> Volume factor (0 - 1)
		*/
		AS_API void SetVolume(const float fVolume);

		/*
			Returns the volume

			Returns:
				float -> Volume factor
		*/
		AS_API float GetVolume() const;

		/*
			Returns whether this sound is music or not

			Returns:
				bool -> 'true' if this sound is music else 'false'
		*/
		AS_API bool IsMusic() const;


	private:
		ASTSound*  m_pCSound;	// Pointer to the sound this handler uses
		int		   m_iChannel;	// The channel were the sound is played

		float m_fCustomVolume;	// Custom volume factor 
		int   m_iVolume;		// Sound volume (0 - 255)
		bool  m_bMusic;			// Is this sound a music?


		/*
			Virtual entity functions
		*/
		AS_API virtual void CustomDelete();
		AS_API virtual void CustomInitFunction();
		AS_API virtual void CustomDeInitFunction();
		AS_API virtual void CustomUpdateFunction();

		/*
			Updates the sound position
		*/
		void UpdateSoundPosition() const;

		/*
			Updates the sound volume
		*/
		void UpdateSoundVolume() const;

		/*
			Initializes the sound handler
		*/
		void InitSound();


} ASTSoundHandler;


#endif // __ASSOUNDHANDLER_H__
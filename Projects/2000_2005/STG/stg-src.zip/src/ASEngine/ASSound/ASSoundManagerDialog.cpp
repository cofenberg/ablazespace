/*
	File: ASSoundManagerDialog.cpp
*/

#include <ASEngineDll.h>
#include "..\resource.h"


// Variables
HWND hWndSoundDialog;
ASTSound* pCSelectedSound;
ASTSoundHandler* pCSoundHandler;


/*
	Opens the sound manager dialog
*/
bool ASTSoundManager::OpenDialog(const HWND hWnd)
{
	bool bError = false;

	if (hWndSoundDialog) return true;

	// Show mouse cursor
	if (_AS::CConfig.IsFullscreen()) _AS::CInput.ShowWindowsMouseCursor(true);

	if(DialogBox(GetModuleHandle(ASMODULENAME), MAKEINTRESOURCE(IDD_SOUNDMANAGER), hWnd, (DLGPROC) DialogProc) == -1)
		bError = true;
	
	// Hide mouse cursor
	if (_AS::CConfig.IsFullscreen()) _AS::CInput.ShowWindowsMouseCursor(false);

	return bError;
}

/*
	Sound manager dialog procedure
*/
LRESULT CALLBACK ASTSoundManager::DialogProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	return _AS::CSoundManager.Proc(hWnd, iMessage, wParam, lParam);
}

LRESULT ASTSoundManager::Proc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	ASTLinkedListElement<ASTSound*>* pSListElement;
	static POINT MousePos, OldMousePos;
    char *pszTemp, szTemp[256];
	ASTSound* pCSound;
	int i;

	switch (iMessage) {
        case WM_INITDIALOG:
			_AS::CLog.Output("Open sound manager dialog");
			hWndSoundDialog = hWnd;

			// Texts
			SetWindowText( hWnd,								 CText.Get(_T_SoundManager));
			SetDlgItemText(hWnd, IDC_SOUNDMANAGER_OK,			 CText.Get(_T_Ok));
			SetDlgItemText(hWnd, IDC_SOUNDMANAGER_LOAD,		     CText.Get(_T_Load));
			SetDlgItemText(hWnd, IDC_SOUNDMANAGER_UNLOAD,		 CText.Get(_T_Unload));
			SetDlgItemText(hWnd, IDC_SOUNDMANAGER_PLAYBACK,		 CText.Get(_T_PlayBack));
			SetDlgItemText(hWnd, IDC_SOUNDMANAGER_UNLOAD_UNUSED, CText.Get(_T_UnloadUnused));
			SetDlgItemText(hWnd, IDC_SOUNDMANAGER_UPDATE,        CText.Get(_T_Update));

			// Setup data
			SetTimer(hWnd, 1, 1, NULL);
			pCSelectedSound = NULL;
			pCSoundHandler = new ASTSoundHandler;

		Init:
			if (!pCSoundHandler) break;
			if (pCSelectedSound) {
				pCSoundHandler->Load(pCSelectedSound->m_szFilename);
				EnableWindow(GetDlgItem(hWnd, IDC_SOUNDMANAGER_UNLOAD), !pCSelectedSound->m_bProtected);
			} else EnableWindow(GetDlgItem(hWnd, IDC_SOUNDMANAGER_UNLOAD), false);
			if (!pCSelectedSound || !pCSoundHandler->IsLoaded())
				EnableWindow(GetDlgItem(hWnd, IDC_SOUNDMANAGER_PLAYBACK), false);
			else EnableWindow(GetDlgItem(hWnd, IDC_SOUNDMANAGER_PLAYBACK), true);

			EnableWindow(GetDlgItem(hWnd, IDC_SOUNDMANAGER_UNLOAD_UNUSED), !GetUnloadUnusedSounds());

			// Setup the sound list
			SendDlgItemMessage(hWnd, ID_SOUNDMANAGER_LIST, LB_RESETCONTENT , 0, 0L);
			pSListElement = m_lstSoundList.FindFirst();
			i = 0;
			while (pSListElement) {
				if (pSListElement->Data->IsMultiple())
					sprintf(szTemp, "%s (%s: %d)", pSListElement->Data->m_szFilename,
												   CText.Get(_T_Used),
												   pSListElement->Data->m_lstHandler.GetElements());
				else
					sprintf(szTemp, "%s (%s: %d (!))", pSListElement->Data->m_szFilename,
												       CText.Get(_T_Used),
												       pSListElement->Data->m_lstHandler.GetElements());
				SendDlgItemMessage(hWnd, ID_SOUNDMANAGER_LIST, LB_ADDSTRING, 0, (LPARAM) szTemp);
				if (pSListElement->Data == pCSelectedSound)
					SendDlgItemMessage(hWnd, ID_SOUNDMANAGER_LIST, LB_SETCURSEL, i, 0L);
				pSListElement = m_lstSoundList.FindNext();
				i++;
			}

			BringWindowToTop(hWnd);
			UpdateWindow(hWnd);
			return true;

		case WM_TIMER:
			_AS::Update();
			break;

        case WM_COMMAND:
            switch (LOWORD(wParam)) {
                case IDC_SOUNDMANAGER_OK:
					if (!hWndSoundDialog) break;
					_AS::CLog.Output("Close sound manager dialog");
					hWndSoundDialog = NULL;
					KillTimer(hWnd, 1);
					if (pCSoundHandler) {
						delete pCSoundHandler;
						pCSoundHandler = NULL;
					}
					pCSelectedSound = NULL;
					EndDialog(hWnd, false);

					return true;
				
				case IDC_SOUNDMANAGER_LOAD:
					KillTimer(hWnd, 1);
					strcpy(szTemp, _AS::CFileSystem.GetSoundsDirectory());
					_AS::CFileSystem.GetFullFilename(szTemp);
					pszTemp = _AS::CFileSystem.GetFilenameDialog(hWnd, CText.Get(_T_LoadSound), ASSOUND_FILES, szTemp, true, true, NULL);
					SetTimer(hWnd, 1, 1, NULL);
					_AS::CFileSystem.InitGetFilename(&pszTemp);
					while (!_AS::CFileSystem.GetNextFilename(&pszTemp, szTemp))
						_AS::CSoundManager.PreLoad(szTemp);
					goto Init;

				case IDC_SOUNDMANAGER_UNLOAD:
					if (!pCSelectedSound) break;
					if (pCSelectedSound->m_lstHandler.GetElements()) {
						KillTimer(hWnd, 1);
						sprintf(szTemp, "'%s': %s (%d)\n%s", pCSelectedSound->m_szFilename,
															 CText.Get(_T_SoundIsStillUsed),
															 pCSelectedSound->m_lstHandler.GetElements(),
															 CText.Get(_T_ContinueQuestionMark));
						if(MessageBox(hWnd, szTemp, CText.Get(_T_Question), MB_YESNO | MB_ICONINFORMATION) == IDNO) {
							SetTimer(hWnd, 1, 1, NULL);
							break;
						}
						SetTimer(hWnd, 1, 1, NULL);
					}
					Unload(pCSelectedSound);
					pCSelectedSound = NULL;
					goto Init;

				case IDC_SOUNDMANAGER_PLAYBACK: {
					pCSoundHandler->Play(); break;
					if (_AS::CRenderer.GetCamera())
						pCSoundHandler->SetPos(_AS::CRenderer.GetCamera()->GetPos());
				}

				case IDC_SOUNDMANAGER_UNLOAD_UNUSED: UnloadUnusedSounds(); goto Init;
				case IDC_SOUNDMANAGER_UPDATE: ReloadSounds(); goto Init;

				case ID_SOUNDMANAGER_LIST:
					i = (int) SendDlgItemMessage(hWnd, ID_SOUNDMANAGER_LIST, LB_GETCURSEL, 0, 0L);
					if (!(pCSound = GetSound(i))) break;
					pCSelectedSound = pCSound;
					goto Init;
			}
        break;

		case WM_CLOSE: case WM_DESTROY: SendMessage(hWnd, WM_COMMAND, IDC_SOUNDMANAGER_OK, 0); break;
    }

    return false;
}
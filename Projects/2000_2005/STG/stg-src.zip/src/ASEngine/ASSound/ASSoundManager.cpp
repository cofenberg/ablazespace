/*
	File: ASSoundManager.cpp
*/

#include <ASEngineDll.h>


// Definitions
#define FSOUND_BUFFERSIZE 200 // Millisecond value for FMOD buffersize


/*
	Constructor
*/
ASTSoundManager::ASTSoundManager()
{
}

/*
	Destructor
*/
ASTSoundManager::~ASTSoundManager()
{
	Cleanup();
}

/*
	Returns whether the sound manager is initializes or not
*/
bool ASTSoundManager::IsInitialized()
{
	return m_bInitialized;
}

/*
	Restarts the sound system
*/
bool ASTSoundManager::Restart()
{
	// Is the sound manager initialized?
	if (!m_bInitialized) return false;

	_AS::CLog.Output("Restart sound manager");

// TODO


	return false;
}

/*
	Returns if unused sounds should be removed automatically
*/
bool ASTSoundManager::GetUnloadUnusedSounds() const
{
	return m_bUnloadUnusedSounds;
}

/*
	Sets if unused sounds should be removed automatically
*/
void ASTSoundManager::SetUnloadUnusedSounds(const bool bUnloadUnusedSounds)
{
	m_bUnloadUnusedSounds = bUnloadUnusedSounds;
}

/*
	Unload all unused sounds
*/
void ASTSoundManager::UnloadUnusedSounds()
{
	// Is the sound manager initialized?
	if (!m_bInitialized) return;

	ASTLinkedListElement<ASTSound*>* pSListElement;
	ASTSound* pCSoundT;

	// Find the sound
	pSListElement = m_lstSoundList.FindFirst();
	while (pSListElement) {
		if (!pSListElement->Data->IsProtected() &&
			!pSListElement->Data->m_lstHandler.GetElements()) {
			pCSoundT = pSListElement->Data;
			m_lstSoundList.Remove(pCSoundT);
			delete pCSoundT;
		}
		pSListElement = m_lstSoundList.FindNext();
	}
}

/*
	Returns a pointer to the sound with the given ID
*/
ASTSound* ASTSoundManager::GetSound(const int iSoundID)
{
	if (iSoundID < 0 || iSoundID > m_lstSoundList.GetElements()) return NULL;
	else return m_lstSoundList[iSoundID];
}

/*
	Returns a pointer to the sound with the given filename
*/
ASTSound* ASTSoundManager::GetSound(const char* pszFilename)
{
	ASTLinkedListElement<ASTSound*>* pSListElement;
	char szFilename[256];

	GetValidFilename(pszFilename, &szFilename[0]);
	pSListElement = m_lstSoundList.FindFirst();
	while (pSListElement) {
		if (!stricmp(pSListElement->Data->GetFilename(), szFilename)) return pSListElement->Data;
		pSListElement = m_lstSoundList.FindNext();
	}

	return NULL;
}

/*
	Returns a pointer to the standard sound
*/
ASTSound* ASTSoundManager::GetStandardSound()
{
	return m_CStandardSound.GetSound();
}

/*
	Stops all sounds
*/
void ASTSoundManager::Stop()
{
	ASTLinkedListElement<ASTSound*>* pSListElement;

	pSListElement = m_lstSoundList.FindFirst();
	while (pSListElement) {
		pSListElement->Data->Stop();
		pSListElement = m_lstSoundList.FindNext();
	}
}

/*
	Stops all sounds
*/
void ASTSoundManager::StopSounds()
{
	ASTLinkedListElement<ASTSound*>* pSListElement;

	pSListElement = m_lstSoundList.FindFirst();
	while (pSListElement) {
		pSListElement->Data->StopSound();
		pSListElement = m_lstSoundList.FindNext();
	}
}

/*
	Stops all music
*/
void ASTSoundManager::StopMusic()
{
	ASTLinkedListElement<ASTSound*>* pSListElement;

	pSListElement = m_lstSoundList.FindFirst();
	while (pSListElement) {
		pSListElement->Data->StopMusic();
		pSListElement = m_lstSoundList.FindNext();
	}
}

/*
	Unload all sounds
*/
void ASTSoundManager::Clear()
{
	// Is the sound manager initialized?
	if (!m_bInitialized) return;

	ASTLinkedListElement<ASTSound*>* pSListElement;
	ASTSound* pCSoundT;

	// Remove all sounds
	pSListElement = m_lstSoundList.FindFirst();
	while (pSListElement) {
		if (!pSListElement->Data->IsProtected()) {
			pCSoundT = pSListElement->Data;
			m_lstSoundList.Remove(pCSoundT);
			delete pCSoundT;
		}
		pSListElement = m_lstSoundList.FindNext();
	}
}

/*
	Pre-loads a sound with the given filename
*/
bool ASTSoundManager::PreLoad(const char* pszFilename)
{
	// Is the sound manager initialized?
	if (!m_bInitialized) return false;

	return Load(NULL, pszFilename);
}

/*
	Reloads all sounds

	Returns:
		bool -> 'false' if all went fine else 'true'
*/
bool ASTSoundManager::ReloadSounds()
{
	// Is the sound manager initialized?
	if (!m_bInitialized) return false;

	ASTLinkedListElement<ASTSound*>* pSListElement;
	ASTProgressWindow CProgressWindow;
	bool bError = false;
	int i = 0;

	CProgressWindow.Create("Reload sounds");
	pSListElement = m_lstSoundList.FindFirst();
	while (pSListElement) {
		if (pSListElement->Data) {
			CProgressWindow.SetTask("Sound: %s", pSListElement->Data->GetFilename());
			CProgressWindow.SetProgress((int) ((float) i / m_lstSoundList.GetElements() * 100));
			if (pSListElement->Data->Reload()) bError = true;
		}
		pSListElement = m_lstSoundList.FindNext();
		i++;
	}

	return bError;
}

/*
	Gets the valid sound filename
*/
void ASTSoundManager::GetValidFilename(const char* pszFilename, char* pszValidFilename) const
{
	if (!pszFilename) {
		sprintf(pszValidFilename, "%s\\"ASSTANDARDSOUND, _AS::CFileSystem.GetSoundsDirectory());
		_AS::CFileSystem.GetFullFilename(pszValidFilename);
	} else {
		// Check if this sound could be loaded
		strcpy(pszValidFilename, pszFilename);
		_AS::CFileSystem.GetFullFilename(pszValidFilename);
		if (!_AS::CFileSystem.IsFilenameValid(pszValidFilename)) { // The file wasn't found!
			// Try to use the standard sound directory
			sprintf(pszValidFilename, "%s\\%s", _AS::CFileSystem.GetSoundsDirectory(), pszFilename);
			_AS::CFileSystem.GetFullFilename(pszValidFilename);
			if (!_AS::CFileSystem.IsFilenameValid(pszValidFilename)) { // The file wasn't found!
				// Try to use the standard music directory
				sprintf(pszValidFilename, "%s\\%s", _AS::CFileSystem.GetMusicDirectory(), pszFilename);
				_AS::CFileSystem.GetFullFilename(pszValidFilename);
			}
		}
	}
}

/*
	Loads a sound with the given filename
*/
bool ASTSoundManager::Load(ASTSoundHandler* pCSoundHandler, const char* pszFilename)
{
	// Is the sound manager initialized?
	if (!m_bInitialized) return false;

	ASTLinkedListElement<ASTSound*>* pSListElement;
	ASTSound* pCSoundT;
	char szFilename[256];

	// Get valid filename
	GetValidFilename(pszFilename, szFilename);

	// First check if the sound is already loaded
	pSListElement = m_lstSoundList.FindFirst();
	while (pSListElement) {
		pCSoundT = pSListElement->Data;
		if (!stricmp(pCSoundT->GetFilename(), szFilename)) { // The sound is already loaded
			if (pCSoundHandler) pCSoundT->Load(pCSoundHandler, pszFilename);

			return false;
		}
		pSListElement = m_lstSoundList.FindNext();
	}

	// Load the new sound
	pCSoundT = new ASTSound;
	if (pCSoundT->Load(pCSoundHandler, pszFilename) == -1) { // The sound couldn't be loaded!
		if (pCSoundT) delete pCSoundT;
		if (!pCSoundHandler) return	true;
		if (m_CStandardSound.IsLoaded()) return pCSoundHandler->Load();
		else							 return	true;
	}

	// Add the new sound to the managers sound list
	m_lstSoundList.Add(pCSoundT);

	return false;
}

/*
	Unloads a sound
*/
bool ASTSoundManager::Unload(ASTSoundHandler* pCSoundHandler)
{
	// Is the sound manager initialized?
	if (!m_bInitialized) return false;

	ASTLinkedListElement<ASTSound*>* pSListElement;
	ASTSound* pCSoundT;
	int i;

	if (!pCSoundHandler) return true;

	// Find the sound
	pSListElement = m_lstSoundList.FindFirst();
	while (pSListElement) {
		i = pSListElement->Data->Unload(pCSoundHandler);
		if (i >= 0) return false;
		if (i == -2) { // Should the unused sound be removed?
			pCSoundT = pSListElement->Data;
			m_lstSoundList.Remove(pCSoundT);
			delete pCSoundT;

			return false;
		}
		pSListElement = m_lstSoundList.FindNext();
	}

	return false;
}

/*
	Unloads a sound
*/
bool ASTSoundManager::Unload(ASTSound* pCSound)
{
	// Is the sound manager initialized?
	if (!m_bInitialized) return false;

	if (pCSound->IsProtected() || m_lstSoundList.IsElement(pCSound) < 0) return true;

	m_lstSoundList.Remove(pCSound);
	delete pCSound;

	return false;
}

/*
	Unload all sounds
*/
void ASTSoundManager::Cleanup()
{
	// Is the sound manager initialized?
	if (!m_bInitialized) return;

	ASTLinkedListElement<ASTSound*>* pSListElement;
	ASTSound* pCSoundT;

	_AS::CLog.Output("Cleanup sound manager");

	// Remove all sounds
	pSListElement = m_lstSoundList.FindFirst();
	while (pSListElement) {
		pCSoundT = pSListElement->Data;
		m_lstSoundList.Remove(pCSoundT);
		if (pCSoundT) delete pCSoundT;
		pSListElement = m_lstSoundList.FindNext();
	}
	m_lstSoundList.Clear();
}

/*
	Updates the sound volume
*/
void ASTSoundManager::UpdateVolume()
{
	// Is the sound manager initialized?
	if (!m_bInitialized) return;

	ASTLinkedListElement<ASTSound*>* pSListElement;

	pSListElement = m_lstSoundList.FindFirst();
	while (pSListElement) {
		pSListElement->Data->UpdateVolume();
		pSListElement = m_lstSoundList.FindNext();
	}
}

/*
	Initializes the sound manager
*/
bool ASTSoundManager::Init()
{
	int iRetryCount = 0;
	bool bError;

	// Is the sound deactivated?
	if (_AS::CConfig.IsNoSound()) {
		_AS::CLog.Output("Sound is deactivated");

		return false;
	}

	_AS::CLog.Output("Initialize sound manager");
	_AS::CLog.Output("Initialize FMod (v%.1f)", FMOD_VERSION);

	// Check FMod version
	if (FSOUND_GetVersion() < FMOD_VERSION) {
		MessageBox(GetForegroundWindow(), CText.Get(_T_IncorrectDLLVersion), CText.Get(_T_FModError), MB_OK);

		return true;
	}

    // Configure stability of sound output under windows
	FSOUND_SetBufferSize(FSOUND_BUFFERSIZE);

	// Initialize FSOUND
	FSOUND_SetOutput(_AS::CConfig.m_iSoundOutputDriver);
	FSOUND_SetDriver(_AS::CConfig.m_iSoundDriver);
	FSOUND_SetMixer( _AS::CConfig.m_iSoundMixingDriver);
	FSOUND_SetHWND(NULL);
	while (!FSOUND_Init(_AS::CConfig.m_iSoundOutputRate, _AS::CConfig.m_iSoundChannels, 0) && iRetryCount < 10) {
		Sleep(100);
		iRetryCount++;
	}
	if (iRetryCount == 10) {
    	MessageBox(GetForegroundWindow(), FMOD_ErrorString(FSOUND_GetError()), "FSOUND", MB_ICONHAND | MB_OK | MB_SYSTEMMODAL);

    	return true;
	}

	m_bInitialized = true;

	if (!(bError = m_CStandardSound.Load()))
		m_CStandardSound.GetSound()->m_bProtected = true;

	return bError;
}

/*
	De-initializes the sound manager
*/
bool ASTSoundManager::DeInit()
{
	// Is the sound manager initialized?
	if (!m_bInitialized) return false;

	_AS::CLog.Output("De-initialize sound manager");

	// Cleanup all sounds
	Cleanup();

	// Close FSOUND
	FSOUND_Close();

	m_bInitialized = false;

	return false;
}

/*
	Updates the sound manager
*/
void ASTSoundManager::Update()
{
	// Is the sound manager initialized?
	if (!m_bInitialized) return;

	// Check if the sound manager dialog should be opened (Strg-t)
	if (_AS::CConfig.IsDebugMode() && _AS::CInput.IsKeyPressed(29) && 
		_AS::CInput.IsKeyHit(DIK_N))
		OpenDialog(_AS::CWindowManager.GetMainWindow()->GetWnd());

	// Update sound listener
	if (_AS::CRenderer.GetCamera()) {
		ASTCamera* pCCamera = _AS::CRenderer.GetCamera();
		FSOUND_3D_Listener_SetAttributes(pCCamera->GetPos().fV,
										 pCCamera->GetVelocity().fV,
										 pCCamera->GetDirVector().fX,
										 pCCamera->GetDirVector().fY,
										 pCCamera->GetDirVector().fZ,
										 pCCamera->GetDirUpVector().fX,
										 pCCamera->GetDirUpVector().fY,
										 pCCamera->GetDirUpVector().fZ);
	}

	// Update FSOUND
	FSOUND_3D_Update();
}
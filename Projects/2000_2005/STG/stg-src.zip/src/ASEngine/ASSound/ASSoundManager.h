/*
	File: ASSoundManager.h

	Description: Sound manager code
*/


#ifndef __ASSOUNDMANAGER_H__
#define __ASSOUNDMANAGER_H__


// Definitions
#define ASSTANDARDSOUND "standard.wav" // The standard sound


// Predefinitions
typedef class ASTSound ASTSound;
typedef class ASTSoundHandler ASTSoundHandler;


// Includes
#include <fmod.h>
#include <fmod_errors.h>

#include "ASSoundHandler.h"
#include "ASSound.h"


// Classes
typedef class ASTSoundManager {
	
	friend _AS;
	friend ASTSoundHandler;
	friend ASTConfig;


	public:
		/*
			Constructor
		*/
		AS_API ASTSoundManager();

		/*
			Destructor
		*/
		AS_API ~ASTSoundManager();

		/*
			Returns whether the sound manager is initializes or not

			Returns:
				bool -> 'true' if the sound manager is initializes else 'false'
		*/
		AS_API bool IsInitialized();

		/*
			Restarts the sound system
		*/
		AS_API bool Restart();

		/*
			Returns if unused sounds should be removed automatically

			Returns:
				bool -> 'true' if unused sounds are unloaded automatically else 'false'
		*/
		AS_API bool GetUnloadUnusedSounds() const;

		/*
			Sets if unused sounds should be removed automatically

			Parameters:
				bool bUnloadUnusedSounds -> Should unused sounds be removed automatically?
		*/
		AS_API void SetUnloadUnusedSounds(const bool bUnloadUnusedSounds = true);

		/*
			Unload all unused sounds
		*/
		AS_API void UnloadUnusedSounds();

		/*
			Returns a pointer to the sound with the given ID
		
			Parameters:
				int iSoundID -> The sound ID

			Returns:
				ASTSound* -> Pointer to the sound
		*/
		AS_API ASTSound* GetSound(const int iSoundID);

		/*
			Returns a pointer to the sound with the given filename
		
			Parameters:
				char* pszFilename -> Sound filename

			Returns:
				ASTSound* -> Pointer to the sound
		*/
		AS_API ASTSound* GetSound(const char* pszFilename);

		/*
			Returns a pointer to the standard sound
		
			Returns:
				ASTSound* -> Pointer to the standard sound
		*/
		AS_API ASTSound* GetStandardSound();
		
		/*
			Stops all sounds
		*/
		AS_API void Stop();

		/*
			Stops all sounds

			Notes:
				- Stops only sound effects
		*/
		AS_API void StopSounds();

		/*
			Stops all music

			Notes:
				- Stops only music
		*/
		AS_API void StopMusic();

		/*
			Unload all sounds

			Notes:
				- All sound handlers will loose their sounds
				- Use this function only if you really want to unload all sounds
				- The standard sound will stay alive
		*/
		AS_API void Clear();

		/*
			Pre-loads a sound with the given filename

			Parameters:
				char* pszFilename   -> The filename of the sound

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool PreLoad(const char* pszFilename = NULL);

		/*
			Reloads all sounds

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool ReloadSounds();

		/*
			Gets the valid sound filename

			Parameters:
				char* pszFilename      -> Pointer to the source filename
				char* pszValidFilename -> Pointer to the falid filename

			Notes:
				- If 'pszFilename' is NULL the filename of the standard sound will be returned
				- If the sound isn't found in the given directory it will be searched in the
				  standard sound directory
				- If it isn't in the standard sound directory it will be searched in the
				  standard music directory
		*/
		AS_API void GetValidFilename(const char* pszFilename, char* pszValidFilename) const;

		/*
			Opens the sound manager dialog

			Parameters:
				HWND hWnd -> Parent window handler

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool OpenDialog(const HWND hWnd);


	private:
		bool					 m_bInitialized;		// Is the sound manager initialized?
		ASTSoundHandler		     m_CStandardSound;		// The standard sound
		ASTLinkedList<ASTSound*> m_lstSoundList;		// Linked list of all sounds
		bool					 m_bUnloadUnusedSounds; // Should unused sounds be removed automatically?

		/*
			Loads a sound with the given filename

			Parameters:
				ASTSoundHandler* pCSoundHandler	-> Pointer to the sound handler using this sound
				char*			 pszFilename	-> The filename of the sound

			Returns:
				bool -> 'false' if all went fine else 'true'

			Notes:
				- Filename: The standard sound directory will be used normally but you
							are also allowed to use your own directories
				- If 'pCSoundHandler' is NULL the sound will be pre-loaded
		*/
		bool Load(ASTSoundHandler* pCSoundHandler, const char* pszFilename = NULL);

		/*
			Unloads a sound

			Parameters:
				ASTSoundHandler* pSoundHandler -> Pointer to the sound handler using this sound

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Unload(ASTSoundHandler* pCSoundHandler);

		/*
			Unloads a sound

			Parameters:
				ASTSound* pSound -> Pointer to the sound

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Unload(ASTSound* pCSound);

		/*
			Unload all sounds

			Notes:
				- All sound handlers will loose their sounds
				- Use this function only if you really want to unload all sounds
				- The standard sound will be unloaded, too!
		*/
		void Cleanup();

		/*
			Updates the sound volume
		*/
		void UpdateVolume();

		/*
			Sound manager dialog procedure
		*/
		static LRESULT CALLBACK DialogProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);
		LRESULT Proc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);

		/*
			Initializes the sound manager

			Returns:
				bool -> 'false' is all went fine else 'true'
		*/
		bool Init();

		/*
			De-initializes the sound manager

			Returns:
				bool -> 'false' is all went fine else 'true'
		*/
		bool DeInit();

		/*
			Updates the sound manager
		*/
		void Update();


} ASTSoundManager;


#endif // __ASSOUNDMANAGER_H__
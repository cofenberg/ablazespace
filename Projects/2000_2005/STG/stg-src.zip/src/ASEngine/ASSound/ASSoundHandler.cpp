/*
	File: ASSound.cpp
*/

#include <ASEngineDll.h>


/*
	Constructor
*/
ASTSoundHandler::ASTSoundHandler(const char* pszFilename)
{
	InitSound();
	Load(pszFilename);
}

/*
	Destructor
*/
ASTSoundHandler::~ASTSoundHandler()
{
	Unload();
}

/*
	Loads a sound
*/
bool ASTSoundHandler::Load(const char* pszFilename)
{
	// Is the sound manager initialized?
	if (!_AS::CSoundManager.IsInitialized()) return false;

	char szFilename[256];

	// Check if the handler already uses this object
	if (m_pCSound && !stricmp(m_pCSound->GetFilename(), pszFilename)) return false;

	Unload();

	// Get valid ass-filename
	_AS::CSoundManager.GetValidFilename(pszFilename, szFilename);
	_AS::CFileSystem.CutFilenameEnding(szFilename);
	_AS::CFileSystem.GetFullFilename(szFilename, ASSOUND_FILE);

	// Load 'ass'-file
	m_iVolume  = GetPrivateProfileInt("handler", "volume", 255, szFilename);
	m_bMusic   = GetPrivateProfileInt("handler", "music",    0, szFilename) != 0;

	if (_AS::CSoundManager.Load(this, pszFilename)) return true;

	return false;
}

/*
	Returns if the sound handler has a sound or not	
*/
bool ASTSoundHandler::IsLoaded() const
{
	if (m_pCSound) return true;
	else		   return false;
}

/*
	Unloads the sound
*/
bool ASTSoundHandler::Unload()
{
	bool bError;

	// Does the sound handler has a sound?
	if (!m_pCSound) return true;

	Stop();

	// Unload this sound
	bError = _AS::CSoundManager.Unload(this);

	InitSound();

	return bError;
}

/*
	Returns the sound handlers sound
*/
ASTSound* ASTSoundHandler::GetSound() const
{
	return m_pCSound;
}

/*
	Plays the sound
*/
bool ASTSoundHandler::Play(const bool bStopLast)
{
	// Play sounds?
	if (m_bMusic  && !_AS::CConfig.m_bMusic) return false;
	if (!m_bMusic && !_AS::CConfig.m_bSound) return false;

	// Is a sound loaded?
	if (!m_pCSound) return true;

	if (bStopLast) m_pCSound->Stop(m_iChannel);
	m_iChannel = m_pCSound->Play();

	// Setup sound position	
	UpdateSoundPosition();

	// Setup sound volume
	UpdateSoundVolume();

	return false;
}

/*
	Stops the sound
*/
bool ASTSoundHandler::Stop()
{
	// Is a sound loaded?
	if (!m_pCSound || m_iChannel < 0) return true;

	m_pCSound->Stop(m_iChannel);
	m_iChannel = -1;

	return false;
}

/*
	Checks wether the sound is played or not
*/
bool ASTSoundHandler::IsPlaying()
{
	// Is a sound loaded?
	if (!m_pCSound) return true;

	if (m_pCSound->m_pMod) {
	} else
	if (m_pCSound->m_pSample || m_pCSound->m_pStream) {
		if (m_iChannel < 0) return false;
		else				return true;
	}

	return false;
}

/*
	Sets the volume
*/
void ASTSoundHandler::SetVolume(const float fVolume)
{
	if (m_fCustomVolume == fVolume) return;
	m_fCustomVolume = fVolume;
	UpdateSoundVolume();
}

/*
	Returns the volume
*/
float ASTSoundHandler::GetVolume() const
{
	return m_fCustomVolume;
}

/*
	Returns whether this sound is music or not
*/
bool ASTSoundHandler::IsMusic() const
{
	return m_bMusic;
}

/*
	Custom delete function
*/
void ASTSoundHandler::CustomDelete()
{
	delete this;
}

/*
	This function is called if the sound entity is initialized
*/
void ASTSoundHandler::CustomInitFunction()
{
	InitSound();
}

/*
	This function is called if the sound entity is de-initialized
*/
void ASTSoundHandler::CustomDeInitFunction()
{
}

/*
	This function is called if the sound entity is updated
*/
void ASTSoundHandler::CustomUpdateFunction()
{
	// Update sound position	
	UpdateSoundPosition();
}

/*
	Updates the sound position
*/
void ASTSoundHandler::UpdateSoundPosition() const
{
	if (m_iChannel >= 0)
		FSOUND_3D_SetAttributes(m_iChannel, GetPos().fV, GetVelocity().fV);
}

/*
	Updates the sound volume
*/
void ASTSoundHandler::UpdateSoundVolume() const
{
	float fVolume;

	// Is a sound loaded?
	if (!m_pCSound) return;

	// Get volume factor
	if (m_bMusic) {
		if (_AS::CConfig.m_bMusic) fVolume = _AS::CConfig.m_fMusicVolume;
		else					   fVolume = 0.f;
	} else {
		if (_AS::CConfig.m_bSound) fVolume = _AS::CConfig.m_fSoundVolume;
		else					   fVolume = 0.f;
	}
	fVolume *= m_fCustomVolume;

	if (m_pCSound->m_pMod)
		FMUSIC_SetMasterVolume(m_pCSound->m_pMod, (int) (m_iVolume * fVolume));
	else if (m_pCSound->m_pSample || m_pCSound->m_pStream)
		FSOUND_SetVolume(m_iChannel, (int) (m_iVolume * fVolume));
}

/*
	Initializes the sound handler
*/
void ASTSoundHandler::InitSound()
{
	m_pCSound		= NULL;
	m_iChannel		= -1;
	m_fCustomVolume = 1.f;
	m_iVolume		= 255;
	m_bMusic		= false;
}
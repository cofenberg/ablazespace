/*
	File: ASConsole.h

	Description: Console code
*/


#ifndef __ASCONSOLE_H__
#define __ASCONSOLE_H__


// Classes
typedef class ASTConsole {

	public:


	private:


} ASTConsole;


#endif // __ASCONSOLE_H__
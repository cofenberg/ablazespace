/*
	File: ASConsole.cpp
*/

#include <ASEngineDll.h>



/*
	File: ASEngine.h

	Description: Engine main header
*/


#ifndef __ASENGINE_H__
#define __ASENGINE_H__


// Definitions
#define ASENGINE		"AS-Engine"		// Engine name
#define	ASENGINEVERSION "V1.0"			// Engine version
#define ASMODULENAME	"asengine.dll"	// Engine module name
#define WIN32_LEAN_AND_MEAN
#ifdef ASENGINE_EXPORTS
#define AS_API __declspec(dllexport)
#else
#define AS_API __declspec(dllimport)
#endif


// Typedefs
#include "ASTypes.h"
class _AS;


// Includes
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>

#include <gl\gl.h>
#include <gl\glu.h>
#include <gl\glaux.h>
#include <gl\glext.h>
#include <gl\wglext.h>

#include "ASMath\ASMath.h"
#include "ASTools\ASTools.h"
#include "ASCollision\ASCollision.h"
#include "ASTexture\ASTextureManager.h"
#include "ASModel\ASModelManager.h"
#include "ASEntity\ASEntityManager.h"
#include "ASRenderer\ASRenderer.h"
#include "ASInput\ASInput.h"
#include "ASLanguage\ASLanguageManager.h"
#include "ASFile\ASFileSystem.h"
#include "ASWindow\ASWindowManager.h"
#include "ASTimer\ASTimer.h"
#include "ASConfig\ASConfig.h"
#include "ASLog\ASLog.h"
#include "ASConsole\ASConsole.h"
#include "ASPhysics\ASPhysics.h"
#include "ASParticle\ASParticleManager.h"
#include "ASSound\ASSoundManager.h"

// Engine texts
#include "ASLanguage\ASLanguage.h"


// Classes
typedef class _AS {

	public:
		AS_API static ASTMath			 CMath;
		AS_API static ASTTools			 CTools;
		AS_API static ASTCollision		 CCollision;
		AS_API static ASTTextureManager	 CTextureManager;
		AS_API static ASTModelManager	 CModelManager;
		AS_API static ASTEntityManager	 CEntityManager;
		AS_API static ASTFrustum		 CFrustum;
		AS_API static ASTRenderer		 CRenderer;
		AS_API static ASTInput			 CInput;
		AS_API static ASTLanguageManager CLanguageManager;
		AS_API static ASTFileSystem		 CFileSystem;
		AS_API static ASTWindowManager	 CWindowManager;
		AS_API static ASTTimer			 CTimer;
		AS_API static ASTConfig			 CConfig;
		AS_API static ASTLog			 CLog;
		AS_API static ASTConsole		 CConsole;
		AS_API static ASTParser			 CParser;
		AS_API static ASTPhysics		 CPhysics;
		AS_API static ASTParticleManager CParticleManager;
		AS_API static ASTSoundManager	 CSoundManager;


		/*
			Initialize the engine

			Returns:
				bool -> 'false' if all went find else 'true'

			Notes:
				- If the initialization is failed the 'DeInit'-function is called automatically
		*/
		AS_API static bool Init();

		/*
			Deinitialize the engine

			Returns:
				bool -> 'false' if all went find else 'true'
		*/
		AS_API static bool DeInit();

		/*
			Update all engine stuff

			Notes:
				- Should be done every frame
		*/
		AS_API static void Update();

		/*
			Engine main loop
		*/
		AS_API static void MainLoop();

		/*
			Leave engine main loop 
		*/
		AS_API void LeaveMainLoop();

		/*
			Shut down the application
		*/
		AS_API static void ShutDown();

		/*
			Returns if the application should be shut down
		*/
		AS_API static bool IsShutDown();

		/*
			Preloads data

			Parameters:
				char *pszFilename -> Preload configuration filename

			Notes:
				- Use this function to avoid loading delays later
				- An automatic progress window will show the progress
				- If the pointer to the filename is NULL the standard data defined in 'asconfig.ini'
				  will be preloaded. This standard file is automatically loaded if the engine is initialized.
		*/
		AS_API static void PreloadData(char *pszFilename = NULL);

	
	private:
		static SYSTEMTIME m_SInitTime;		// The time were the engine was initialized
		static bool		  m_bLeaveMainLoop;	// Should the engines main loop be left?
		static bool		  m_bShutDown;		// Should the application be shut down?


		/*
			Initialize the engine

			Returns:
				bool -> 'false' if all went find else 'true'
		*/
		static bool InitEngine();


} _AS;


#endif // __ASENGINE_H__
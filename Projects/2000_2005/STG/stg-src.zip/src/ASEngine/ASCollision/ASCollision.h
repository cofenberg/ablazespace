/*
	File: ASCollision.h

	Description: Collision detection tools
*/

#ifndef __ASCOLLISION_H__
#define __ASCOLLISION_H__


// Predefinitions
typedef class ASTEntity ASTEntity;


// Definitions
enum ASEPlaneRelation { // Used to describe the point position relativ to a plane
	ASeOnPlane,
	ASeOnPlaneFrontside,
	ASeOnPlaneBackside
};


// Structures
typedef struct ASTCollisionMesh {
	ASTVector3D   vPos;
	float	      fRadius;
	ASBOUNDINGBOX fBoundingBox;
	int		      iPlanes;
	ASTPlane*     pCPlane;

} ASTCollisionMesh;

typedef class ASTCollisionPacked {

	public:
		/*
			Constructor
		*/
		AS_API ASTCollisionPacked();

		
		// Output
		ASTVector3D vFinalPosition;		// The position after the movement
		bool		bFoundCollision,	// Was there an collision?
					bFoundACollision;	// Was there an collision in the whole process?
		ASTEntity*	pCEntity;			// The entity we collide with


		// Input
		bool bSlide;	// Is it possible to slide?

		// Data about movement
		ASTVector3D vSourcePoint;	// The point were we started
		ASTVector3D vVelocity;		// The current velocity
		ASTVector3D vERadius;		// Radius of ellipsoid

		// For error handling
		ASTVector3D vLastSafePosition;			// The last safe position
		ASTVector3D vLastSphereCollisionPoint;	// The last sphere collision point were the struck occur
		bool		bStuck;						// Does we stuck something?

		// Data for collision response
		double		dNearestDistance;					// Nearest distance to hit
		ASTVector3D vNearestIntersectionPoint;			// On sphere
		ASTVector3D vNearestPolygonIntersectionPoint;	// On polygon

		// Custom
		bool bCustom1;


} ASTCollisionPacked;


// Classes
typedef class ASTCollision {

	public:	
		/*
			A helper function to calculate the bouncing vector
		*/
		ASTVector3D ASTCollision::Reflect(const ASTVector3D& vIncidentNormal, const ASTVector3D& vNormal) const;

		/*
			Checks wheather a point is in the given triangle or not

			Parameters:
				ASTVector3D& vRayOrigin			    -> Ray origin
				ASTVector3D& vRayDirection		    -> Ray direction
				ASTVector3D* pvIntersectionPointPos -> Position of the intersection point
				ASTPlane&    pPlane					-> Plane which describes the triangle

			Returns:
				bool -> 'true' if the ray intersects the triangle else 'false'
		*/
		AS_API bool IsTriangleCollision(const ASTVector3D& vRayOrigin, const ASTVector3D& vRayDirection, ASTVector3D* pvIntersectionPointPos,
										const ASTPlane& pPlane) const;

		/*
			Check if a point is a triangle

			Parameters:
				ASTVector3D& vPointPos		 -> Point that should be testet
				ASTVector3D& vV1 & vV2 & vV3 -> Triangle points

			Returns:
				bool -> 'true' if the point is in the triangle else 'false'

			Notes:
				- The function below which uses the additional normal of the triangles plane
				  is quite faster as this function!
		*/
		AS_API bool IsPointInTriangle(const ASTVector3D& vPointPos, const ASTVector3D& vV1,
									  const ASTVector3D& vV2, const ASTVector3D& vV3) const;

		/*
			Check if a point is a triangle

			Parameters:
				ASTVector3D& vPointPos -> Point that should be testet
				ASTPlane&    pPlane	   -> Plane describing the triangle

			Returns:
				bool -> 'true' if the point is in the triangle else 'false'
		*/
		AS_API bool IsPointInTriangle(const ASTVector3D& vPointPos, const ASTPlane& pPlane) const;

		/*
			Finds the closest point on a line

			Parameters:
				ASTVector3D& vV1 & vV2    -> Line start & end position
				ASTVector3D& vP vPointPos -> The point from which the closest point on the line should be found

			Returns:
				ASTVector3D -> The closest point on line
		*/
		AS_API ASTVector3D ClosestPointOnLine(const ASTVector3D& vV1, const ASTVector3D& vV2, const ASTVector3D& vPointPos) const;

		/*
			Find the closest point on a triangle

			Parameters:
				ASTVector3D& vV1 & vV2 & vV3 -> Triangle Points
				ASTVector3D& vPointPos		 -> The point from which the closest point on the triangle should be found

			Returns:
				ASTVector3D -> The closest point on triangle
		*/
		AS_API ASTVector3D ClosestPointOnTriangle(const ASTVector3D& vV1, const ASTVector3D& vV2,
												  const ASTVector3D& vV3, const ASTVector3D& vPointPos) const;

		/*
			Get the tangent plane normal of an ellipsoid

			Parameters:
				ASTVector3D& vPointPos        -> Position of the point
				ASTVector3D& vEllipsoidPos    -> Ellipsoid position
				ASTVector3D& vEllipsoidRadius -> Ellipsoid radius

			Returns:
				ASTVector3D -> The tangent plane normal of ellipsoid
		*/
		AS_API ASTVector3D TangentPlaneNormalOfEllipsoid(const ASTVector3D& vPointPos, const ASTVector3D& vEllipsoidPos, const ASTVector3D& vEllipsoidRadius) const;

		/*
			Check on which plane side the point is

			Parameters:
				ASTVector3D& vPointPos	  -> Position of the point
				ASTVector3D& vPlaneOrigin -> Plane origin
				ASTVector3D& vPlaneNormal -> Plane normal

			Returns:
				ASEPlaneRelation -> The plane side the point is on
		*/
		AS_API ASEPlaneRelation ClassifyPoint(const ASTVector3D& vPointPos, const ASTVector3D& vPlaneOrigin, const ASTVector3D& vPlaneNormal) const;

		/*
			Check if the point is in the given sphere

			Parameters:
				ASTVector3D& vPointPos     -> Position of the point
				ASTVector3D& vSpherePos    -> Sphere position
				float&		 fSphereRadius -> Sphere radius

			Returns:
				bool -> 'true' if the point is in the sphere else 'false'
		*/
		AS_API bool IsPointInSphere(const ASTVector3D& vPointPos, const ASTVector3D& vSpherePos, const float& fSphereRadius) const;

		/*
			Check if a ray intersects a plane

			Parameters:
				ASTVector3D& vRayOrigin   -> Ray origin
				ASTVector3D& vRayDir	  -> Ray direction
				ASTVector3D& vPlaneOrigin -> Plane origin
				ASTVector3D& vPlaneNormal -> Plane normal vector

			Returns:
				double -> Return the distance to the (first) intersecting point
		*/
		AS_API double IntersectRayPlane(const ASTVector3D& vRayOrigin, const ASTVector3D& vRayDir,
										const ASTVector3D& vPlaneOrigin, const ASTVector3D& vPlaneNormal) const;

		/*
			Check if the ray intersects the given sphere

			Parameters:
				ASTVector3D& vRayOrigin	   -> ray origin
				ASTVector3D& vRayDir	   -> Ray direction
				ASTVector3D& vSpherePos	   -> Sphere position
				float&		 fSphereRadius -> Sphere radius

			Returns:
				double -> Return the distance to the (first) intersecting point
		*/
		AS_API double IntersectRaySphere(const ASTVector3D& vRayOrigin, const ASTVector3D& vRayDir,
										 const ASTVector3D& vSpherePos, const float& fSphereRadius);

		/*
			Checks whether a line is in a box or not

			Parameters:
				ASTVector3D&   vLineS -> Line start position
				ASTVector3D&   vLineM -> Line end position
				ASBOUNDINGBOX& fBox   -> Box

			Returns:
				bool -> 'true' if the line is in the box else 'false'
		*/
		AS_API bool IsLineInBox(const ASTVector3D& vLineS, const ASTVector3D& vLineM, ASBOUNDINGBOX& fBox) const;


	private:
		bool BoxIntersectionX(const float fX, const ASTVector3D& vLineS, const ASTVector3D& vLineM, ASTVector3D *vRes) const;
		bool BoxIntersectionY(const float fY, const ASTVector3D& vLineS, const ASTVector3D& vLineM, ASTVector3D *vRes) const;
		bool BoxIntersectionZ(const float fZ, const ASTVector3D& vLineS, const ASTVector3D& vLineM, ASTVector3D *vRes) const;
		bool CheckBoxVecX(const ASTVector3D& vVec, ASBOUNDINGBOX& fBox) const;
		bool CheckBoxVecY(const ASTVector3D& vVec, ASBOUNDINGBOX& fBox) const;
		bool CheckBoxVecZ(const ASTVector3D& vVec, ASBOUNDINGBOX& fBox) const;


} ASTCollision;


#endif // __ASCOLLISION_H__
/*
	File: ASCollision.cpp
*/

#include <ASEngineDll.h>
 

/*
	Constructor
*/
ASTCollisionPacked::ASTCollisionPacked()
{
	memset(this, 0, sizeof(ASTCollisionPacked));
}

/*
	A helper function to calculate the bouncing vector
*/
ASTVector3D ASTCollision::Reflect(const ASTVector3D& vIncidentNormal, const ASTVector3D& vNormal) const
{
	ASTVector3D retme;

	float t = vNormal.DotProduct(vIncidentNormal);
	ASTVector3D tn = vNormal;
	tn *= t;
	tn = vIncidentNormal - tn;
	tn *= 2.0f;
	retme = vIncidentNormal - tn;

	return -retme;
}

/*
	Checks wheather a point is in the given triangle or not
*/
bool ASTCollision::IsTriangleCollision(const ASTVector3D& vRayOrigin, const ASTVector3D& vRayDirection, ASTVector3D *pvIntersectionPointPos,
									   const ASTPlane& pPlane) const
{
	double fDistToPlaneIntersection; // The distance from the ray start point to the triangle

	// Shoot ray along the velocity vector
	fDistToPlaneIntersection = IntersectRayPlane(vRayOrigin, vRayDirection, pPlane.vV1, pPlane.vN);

	// Calculate plane intersection point
	pvIntersectionPointPos->fX = (float) (vRayOrigin.fX + fDistToPlaneIntersection * vRayDirection.fX);
	pvIntersectionPointPos->fY = (float) (vRayOrigin.fY + fDistToPlaneIntersection * vRayDirection.fY);
	pvIntersectionPointPos->fZ = (float) (vRayOrigin.fZ + fDistToPlaneIntersection * vRayDirection.fZ);

	if (((*pvIntersectionPointPos).fZ < pPlane.vV1.fZ &&
	     (*pvIntersectionPointPos).fZ < pPlane.vV2.fZ &&
	     (*pvIntersectionPointPos).fZ < pPlane.vV3.fZ) ||
	    ((*pvIntersectionPointPos).fZ > pPlane.vV1.fZ &&
	     (*pvIntersectionPointPos).fZ > pPlane.vV2.fZ &&
	     (*pvIntersectionPointPos).fZ > pPlane.vV3.fZ))
		return false; // There is something wrong!?!

	// Check if the intersection point is in the triangle
	if (!IsPointInTriangle(*pvIntersectionPointPos, pPlane))
		return false; // It's not in the triangle!
	
	return true; // It's in the triangle!
}

/*
	Check if a point is a triangle
*/
bool ASTCollision::IsPointInTriangle(const ASTVector3D& vPointPos, const ASTVector3D& vV1,
									 const ASTVector3D& vV2, const ASTVector3D& vV3) const
{
	double dTotalAngles = 0.f;
	float f;

	// Is the point near the triangle??
	if ((vPointPos.fX < vV1.fX &&
	 	 vPointPos.fX < vV2.fX && 
		 vPointPos.fX < vV3.fX) ||
	    (vPointPos.fX > vV1.fX &&
		 vPointPos.fX > vV2.fX && 
		 vPointPos.fX > vV3.fX) ||
	    (vPointPos.fY < vV1.fY &&
		 vPointPos.fY < vV2.fY && 
		 vPointPos.fY < vV3.fY) ||
	    (vPointPos.fY > vV1.fY &&
		 vPointPos.fY > vV2.fY && 
		 vPointPos.fY > vV3.fY))
		return false; // Nope!

	// Check if the point is on one of the triangles edges
	if ((vPointPos.fX == vV1.fX && vPointPos.fY == vV1.fY && vPointPos.fZ == vV1.fZ) ||
	    (vPointPos.fX == vV2.fX && vPointPos.fY == vV2.fY && vPointPos.fZ == vV2.fZ) ||
	    (vPointPos.fX == vV3.fX && vPointPos.fY == vV3.fY && vPointPos.fZ == vV3.fZ))
		return true;

	// Make the 3 vectors
	ASTVector3D vVT1 = vPointPos - vV1;
	ASTVector3D vVT2 = vPointPos - vV2;
	ASTVector3D vVT3 = vPointPos - vV3;

	vVT1.Normalize();
	vVT2.Normalize();
	vVT3.Normalize();

	f = ASDotProduct(vVT1.fV, vVT2.fV);
	if (f < -1.f) f = -1.f;
	if (f > 1.f)  f = 1.f;
	dTotalAngles += acos((double) f);

	f = ASDotProduct(vVT2.fV, vVT3.fV);
	if (f < -1.f) f = -1.f;
	if (f > 1.f)  f = 1.f;
	dTotalAngles += acos((double) f);

	f = ASDotProduct(vVT3.fV, vVT1.fV);
	if (f < -1.f) f = -1.f;
	if (f > 1.f)  f = 1.f;
	dTotalAngles += acos((double) f);

	if (fabs(dTotalAngles - 2 * AS_PI) <= AS_EPSILON2) return true;

	return false;
}

/*
	Check if a point is a triangle
*/
bool ASTCollision::IsPointInTriangle(const ASTVector3D& vPointPos, const ASTPlane& pPlane) const
{
	const ASTVector3D& vV1		    = pPlane.vV1,
					 & vV2		    = pPlane.vV2,
					 & vV3		    = pPlane.vV3,
					 & vPlaneNormal = pPlane.vN;
	float fU0, fU1, fU2;
	float fV0, fV1, fV2;
	float fA, fB;
	float fMax;
	int   i, j;

	// Is the point near the triangle??
	if ((vPointPos.fX < vV1.fX &&
		 vPointPos.fX < vV2.fX && 
		 vPointPos.fX < vV3.fX) ||
	    (vPointPos.fX > vV1.fX &&
		 vPointPos.fX > vV2.fX && 
		 vPointPos.fX > vV3.fX) ||
	    (vPointPos.fY < vV1.fY &&
		 vPointPos.fY < vV2.fY && 
		 vPointPos.fY < vV3.fY) ||
	    (vPointPos.fY > vV1.fY &&
		 vPointPos.fY > vV2.fY && 
		 vPointPos.fY > vV3.fY))
		return false; // Nope!

	// Check if the point is on one of the triangles edges
	if ((vPointPos.fX == vV1.fX && vPointPos.fY == vV1.fY) ||
	    (vPointPos.fX == vV2.fX && vPointPos.fY == vV2.fY) ||
	    (vPointPos.fX == vV3.fX && vPointPos.fY == vV3.fY))
		return true;

	fMax = (float) __max(__max(fabs(vPlaneNormal.fX), fabs(vPlaneNormal.fY)), fabs(vPlaneNormal.fZ));
	if (fMax == fabs(vPlaneNormal.fX)) {i = 1; j = 2;} // y, z
	if (fMax == fabs(vPlaneNormal.fY)) {i = 0; j = 2;} // x, z
	if (fMax == fabs(vPlaneNormal.fZ)) {i = 0; j = 1;} // x, y
	
	fU0 = vPointPos.fV[i] - vV1.fV[i];
	fV0 = vPointPos.fV[j] - vV1.fV[j];
	fU1 = vV2.fV[i]		  - vV1.fV[i];
	fV1 = vV2.fV[j]		  - vV1.fV[j];
	fU2 = vV3.fV[i]		  - vV1.fV[i];
	fV2 = vV3.fV[j]		  - vV1.fV[j];

	if (fU1 > -AS_EPSILON && fU1 < AS_EPSILON) {
		fB = fU0 / fU2;
		if (0.f <= fB && fB <= 1.f) {
			fA = (fV0 - fB * fV2) / fV1;
			if ((fA >= 0.f) && ((fA + fB) <= 1.f)) return true;
		}
	} else {
		fB = (fV0 * fU1 - fU0 * fV1) / (fV2 * fU1 - fU2 * fV1);
		if (0.f <= fB && fB <= 1.f) {
			fA = (fU0 - fB * fU2) / fU1;
			if ((fA >= 0.f) && ((fA + fB) <= 1.f)) return true;
		}
	}

	return false;
}

/*
	Finds the closest point on a line
*/
ASTVector3D ASTCollision::ClosestPointOnLine(const ASTVector3D& vV1, const ASTVector3D& vV2, const ASTVector3D& vPointPos) const
{
	// Determine dT (the length of the vector from �dA� to �dP�)
	ASTVector3D vV3 = vPointPos  - vV1;
	ASTVector3D vV  = vV2		 - vV1; 
  
	double dD = vV.GetLength();
	vV.Normalize();
	double dT = ASDotProduct(vV.fV, vV3.fV);

	// Check to see if �dT� is beyond the extents of the line segment
	if (dT < 0.f) return vV1;
	if (dT > dD)  return vV2;

	// Return the point between �vV1� and �vV2�
	// set length of vV to dT. vV is normalized so this is easy
	vV *= (float) dT;
       
	return (vV1 + vV);
}

/*
	Find the closest point on a triangle
*/
ASTVector3D ASTCollision::ClosestPointOnTriangle(const ASTVector3D& vV1, const ASTVector3D& vV2,
												 const ASTVector3D& vV3, const ASTVector3D& vPointPos) const
{
	ASTVector3D vRab = ClosestPointOnLine(vV1, vV2, vPointPos);
	ASTVector3D vRbc = ClosestPointOnLine(vV2, vV3, vPointPos);
	ASTVector3D vRca = ClosestPointOnLine(vV3, vV1, vPointPos);

	double dAB = (vPointPos - vRab).GetLength();
	double dBC = (vPointPos - vRbc).GetLength();
	double dCA = (vPointPos - vRca).GetLength();
	double dMin = dAB;

	ASTVector3D vResult = vRab;

	if (dBC < dMin) {
		dMin = dBC;
		vResult = vRbc;
	}

	if (dCA < dMin) vResult = vRca;

	return vResult;	
}

/*
	Get the tangent plane normal of an ellipsoid
*/
ASTVector3D ASTCollision::TangentPlaneNormalOfEllipsoid(const ASTVector3D& vPointPos, const ASTVector3D& vEllipsoidPos, const ASTVector3D& vEllipsoidRadius) const
{
	ASTVector3D vP = vPointPos - vEllipsoidPos;

	double dA2 = vEllipsoidRadius.fX * vEllipsoidPos.fX;
	double dB2 = vEllipsoidRadius.fY * vEllipsoidPos.fY;
	double dC2 = vEllipsoidRadius.fZ * vEllipsoidPos.fZ;

	ASTVector3D vRes((float) (vP.fX / dA2), (float) (vP.fY / dB2), (float) (vP.fY / dB2));
	vRes.Normalize();

	return vRes;
}

/*
	Check on which plane side the point is
*/
ASEPlaneRelation ASTCollision::ClassifyPoint(const ASTVector3D& vPointPos, const ASTVector3D& vPlaneOrigin, const ASTVector3D& vPlaneNormal) const
{
	ASTVector3D vDir = vPlaneOrigin - vPointPos;
	double		  dD = ASDotProduct(vDir.fV, vPlaneNormal.fV);

	if (dD < -0.001f) return ASeOnPlaneFrontside;
	else if(dD > 0.001f) return ASeOnPlaneBackside;

	return ASeOnPlane;	
}

/*
	Check if the point is in the given sphere
*/
bool ASTCollision::IsPointInSphere(const ASTVector3D& vPointPos, const ASTVector3D& vSpherePos, const float& fSphereRadius) const
{
	float fD = (vPointPos - vSpherePos).GetLength();

	if (fD <= fSphereRadius) return true;

	return false;	
}

/*
	Check if a ray intersects a plane
*/
double ASTCollision::IntersectRayPlane(const ASTVector3D& vRayOrigin, const ASTVector3D& vRayDir,
									   const ASTVector3D& vPlaneOrigin, const ASTVector3D& vPlaneNormal) const
{
	double dD	  = -ASDotProduct(vPlaneNormal.fV, vPlaneOrigin.fV);
	double dNumer =  ASDotProduct(vPlaneNormal.fV, vRayOrigin.fV) + dD;
	double dDenom =  ASDotProduct(vPlaneNormal.fV, vRayDir.fV);

	// Normal is orthogonal to vector, can't intersect
	if (!dDenom) return -1.f;

	return -(dNumer / dDenom);	
}

/*
	Check if the ray intersects the given sphere
*/
double ASTCollision::IntersectRaySphere(const ASTVector3D& vRayOrigin, const ASTVector3D& vRayDir,
										const ASTVector3D& vSpherePos, const float& fSphereRadius)
{
	ASTVector3D vDelta = vSpherePos - vRayOrigin;

	float fC = vDelta.GetLength();
	float fV = ASDotProduct(vDelta.fV, vRayDir.fV);
	float fD = fSphereRadius * fSphereRadius - (fC * fC - fV * fV);

	if (fD < 0.) return -1.f; // There was no intersection
   
    // Return the distance to the (first) intersecting point
	return (fV - ASSqrt(fD));
}

/*
	Checks whether a line is in a box or not
*/
bool ASTCollision::IsLineInBox(const ASTVector3D& vLineS, const ASTVector3D& vLineM, ASBOUNDINGBOX& fBox) const
{
	ASTVector3D vLineE;
	
	vLineE.fX = vLineS.fX + vLineM.fX;
	vLineE.fY = vLineS.fY + vLineM.fY;
	vLineE.fZ = vLineS.fZ + vLineM.fZ;
    if (((vLineS.fX >= fBox[0][X]) && (vLineS.fY >= fBox[0][Y]) && (vLineS.fZ >= fBox[0][Z]) &&
         (vLineS.fX <= fBox[1][X]) && (vLineS.fY <= fBox[1][Y]) && (vLineS.fZ <= fBox[1][Y])) ||
        ((vLineE.fX >= fBox[0][X]) && (vLineE.fY >= fBox[0][Y]) && (vLineE.fZ >= fBox[0][Z]) &&
         (vLineE.fX <= fBox[1][X]) && (vLineE.fY <= fBox[1][Y]) && (vLineE.fZ <= fBox[1][Z])))
        return true;
    ASTVector3D vPos;
    int i;

    for (i = 0; i < 6; i++) {
        switch(i) {
            case 0:
                if (BoxIntersectionX(fBox[0][X], vLineS, vLineM, &vPos) && CheckBoxVecX(vPos, fBox))
					return true;
				break;
           
		    case 1:
                if (BoxIntersectionX(fBox[1][X], vLineS, vLineM, &vPos) && CheckBoxVecX(vPos, fBox))
					return true;
				break;
           
		    case 2:
                if (BoxIntersectionY(fBox[0][Y], vLineS, vLineM, &vPos) && CheckBoxVecY(vPos, fBox))
					return true;
				break;
           
			case 3:
                if (BoxIntersectionY(fBox[1][Y], vLineS, vLineM, &vPos) && CheckBoxVecY(vPos, fBox))
					return true;
				break;
           
		    case 4:
                if (BoxIntersectionZ(fBox[0][Z], vLineS, vLineM, &vPos) && CheckBoxVecZ(vPos, fBox))
					return true;
				break;
           
		    case 5:
				if (BoxIntersectionZ(fBox[1][Z], vLineS, vLineM, &vPos) && CheckBoxVecZ(vPos, fBox))
					return true;
				break;
        }
    }

    return false;
}

bool ASTCollision::BoxIntersectionX(const float fX, const ASTVector3D& vLineS, const ASTVector3D& vLineM, ASTVector3D *vRes) const
{
    if (vLineM.fX) {
        float t = (fX - vLineS.fX) / vLineM.fX;
        if ((t >= 0.f) && (t <= 1.f)) {
            (*vRes) = vLineS + vLineM * t;

            return true;
        }
    }

    return false;
}

bool ASTCollision::BoxIntersectionY(const float fY, const ASTVector3D& vLineS, const ASTVector3D& vLineM, ASTVector3D *vRes) const
{
    if (vLineM.fY) {
        float t = (fY - vLineS.fY) / vLineM.fY;
        if ((t >= 0.0f) && (t <= 1.f)) {
            (*vRes) = vLineS + vLineM * t;

            return true;
        }
    }
 
	return false;
}

bool ASTCollision::BoxIntersectionZ(const float fZ, const ASTVector3D& vLineS, const ASTVector3D& vLineM, ASTVector3D *vRes) const
{
    if (vLineM.fZ) {
        float t = (fZ - vLineS.fZ) / vLineM.fZ;
        if ((t >= 0.f) && (t <= 1.f)) {
            (*vRes) = vLineS + vLineM * t;

            return true;
        }
    }
    
	return false;
}

bool ASTCollision::CheckBoxVecX(const ASTVector3D& vVec, ASBOUNDINGBOX& fBox) const
{
    if ((vVec.fY >= fBox[0][Y]) && (vVec.fY <= fBox[1][Y]) && (vVec.fZ >= fBox[0][Z]) && (vVec.fZ <= fBox[1][Z]))
		return true;
    
	return false;
}

bool ASTCollision::CheckBoxVecY(const ASTVector3D& vVec, ASBOUNDINGBOX& fBox) const
{
    if ((vVec.fX >= fBox[0][X]) && (vVec.fX <= fBox[1][X]) && (vVec.fZ >= fBox[0][Z]) && (vVec.fZ <= fBox[1][Z]))
		return true;
    
	return false;
}

bool ASTCollision::CheckBoxVecZ(const ASTVector3D& vVec, ASBOUNDINGBOX& fBox) const
{
    if ((vVec.fX >= fBox[0][X]) && (vVec.fX <= fBox[1][X]) && (vVec.fY >= fBox[0][Y]) && (vVec.fY <= fBox[1][Y]))
		return true;
    
	return false;
}
/*
	File: ASFileSystem.cpp
*/

#include <ASEngineDll.h>
#include <ShellApi.h>
#include <Commdlg.h>


/*
	Returns the application path
*/
const char* ASTFileSystem::GetApplicationPath() const
{
	return m_szApplicationPath;
}

/*
	Checks if the filename is valid or not (does file exist?)
*/
bool ASTFileSystem::IsFilenameValid(const char* pszFilename) const
{
	FILE* pFile;

	// Is the file in the application path?
	if (_strnicmp(m_szApplicationPath, pszFilename, strlen(m_szApplicationPath)))
		return false;

	if (!(pFile = fopen(pszFilename, "r"))) return false;
	fclose(pFile);

	return true;
}

/*
	Returns the filename ending of the given filename
*/
bool ASTFileSystem::GetFilenameEnding(const char* pszFilename, char* pszFilenameEnding) const
{
	const char* pszFilenameT;

	// Check pointers
	if (!pszFilename || !pszFilenameEnding) return false;

	// Check ending
	if (!(pszFilenameT = strchr(pszFilename, '.'))) return false;
	strcpy(pszFilenameEnding, ++pszFilenameT);

	return true;
}

/*
	Checks if the filename has the given ending
*/
bool ASTFileSystem::IsFilenameEnding(const char* pszFilename, const char* pszFilenameEnding) const
{
	char szFilenameEnding[256];
	char szFilename[256];

	// Check pointers
	if (!pszFilename || !pszFilenameEnding) return false;

	// Check ending
	strcpy(szFilename, pszFilename);
	sprintf(szFilenameEnding, ".%s", pszFilenameEnding);
	if (strlen(szFilename) < strlen(szFilenameEnding)) return false;
	_strlwr(szFilename);
	_strlwr(szFilenameEnding);
	for (int i = 0; i < (signed) strlen(szFilenameEnding); i++)
		if(szFilename[strlen(szFilename)-(strlen(szFilenameEnding)-i)] != szFilenameEnding[i]) break;
	if (i == (signed) strlen(szFilenameEnding)) return true;
	else return false;
}

/*
	This function will always return the full filename with path information
*/
void ASTFileSystem::GetFullFilename(char* pszFilename, const char* pszFilenameEnding) const
{
	char szFilename[256];

	// Check pointer
	if (!pszFilename) return;

	// Does this filename already has the application path?
	if (_strnicmp(m_szApplicationPath, pszFilename, strlen(m_szApplicationPath)))
		sprintf(szFilename, "%s%s", m_szApplicationPath, pszFilename);
	else strcpy(szFilename, pszFilename);

	// Is the file ending correct?
	if (!pszFilenameEnding || IsFilenameEnding(pszFilename, pszFilenameEnding))
		strcpy(pszFilename, szFilename);
	else sprintf(pszFilename, "%s.%s", szFilename, pszFilenameEnding);
}

/*
	This function will return the filename without the application path
*/
bool ASTFileSystem::GetFilename(char* pszFilename, const char* pszFilenameEnding) const
{
	char szFilename[256];
	bool bCutPath = false;

	// Check pointer
	if (!pszFilename) return false;

	// Does this filename already has the application path?
	if (_strnicmp(m_szApplicationPath, pszFilename, strlen(m_szApplicationPath)))
		strcpy(szFilename, pszFilename);
	else {
		strcpy(szFilename, pszFilename + strlen(m_szApplicationPath));
		bCutPath = true;
	}

	// Is the file ending correct?
	if (!pszFilenameEnding || IsFilenameEnding(pszFilename, pszFilenameEnding))
		strcpy(pszFilename, szFilename);
	else sprintf(pszFilename, "%s.%s", szFilename, pszFilenameEnding);

	return bCutPath;
}

/*
	Cut of the filename ending
*/
bool ASTFileSystem::CutFilenameEnding(char* pszFilename) const
{
	const char* pszFilenameT;

	// Check pointer
	if (!pszFilename) return true;

	if (!(pszFilenameT = strchr(pszFilename, '.'))) return true;
	pszFilename[pszFilenameT - pszFilename] = '\0';

	return false;
}

/*
	This function will open a get filename dialog and will return the filename(s) without the application path
*/
char* ASTFileSystem::GetFilenameDialog(const HWND hWnd, const char* pszTitle, const char* pszFilter,
									   const char* pszInitalDir, const bool bMultiSelect, const bool bMustExist,
									   const char* pszTempFilename) const
{
    static char szFilename[256];
	static char szFileTitle[256];
    OPENFILENAME ofn;

	// Get standard filename
    if (pszTempFilename) lstrcpy(szFilename, pszTempFilename);
	else lstrcpy(szFilename, "");

	lstrcpy(szFileTitle, "");
	ofn.lStructSize       = sizeof(OPENFILENAME);
	ofn.hwndOwner         = hWnd;
#ifdef WIN32
	ofn.hInstance         = (HINSTANCE) GetWindowLong(hWnd, GWL_HINSTANCE);
#else
	ofn.hInstance         = (HINSTANCE) GetWindowWord(hWnd, GWW_HINSTANCE);
#endif
	ofn.lpstrFilter       = pszFilter;
	ofn.lpstrCustomFilter = (LPSTR) NULL;
	ofn.nMaxCustFilter    = 0L;
	ofn.nFilterIndex      = 1L;
	ofn.lpstrFile         = szFilename;
	ofn.nMaxFile          = sizeof(szFilename);
	ofn.lpstrFileTitle    = szFileTitle;
	ofn.nMaxFileTitle     = sizeof(szFileTitle);
	ofn.lpstrInitialDir   = pszInitalDir;
	ofn.lpstrTitle        = pszTitle;
	ofn.nFileOffset       = 0;
	ofn.nFileExtension    = 0;
	ofn.lpstrDefExt       = pszFilter;
	ofn.lCustData         = 0;
	ofn.Flags = OFN_PATHMUSTEXIST | OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_NONETWORKBUTTON;
    if (bMustExist) ofn.Flags |= OFN_FILEMUSTEXIST; // We load a file...
	if (bMultiSelect) ofn.Flags |= OFN_ALLOWMULTISELECT;
    if (GetOpenFileName(&ofn)) {
		char szFilename[256];

		// Check if the files are in the application directory
		strcpy(szFilename, ofn.lpstrFile);
		if (!GetFilename(szFilename)) return NULL;

		return (char*) ofn.lpstrFile;
	}

	return NULL;
}

/*
	Initializes the function which will get the next filename in the filename list returned by 'GetFilenameDialog'
*/
bool ASTFileSystem::InitGetFilename(char** pszFilename)
{
	if (!pszFilename || !*pszFilename) return true;

	m_bNextFilenameEnd = false;

	// Is this a single filename?
	if (IsFilenameValid(*pszFilename)) return false;

	if (sscanf(*pszFilename, "%s", m_szNextFilenamePath) == EOF) return true;
	*pszFilename += strlen(m_szNextFilenamePath) + 1;

	return false;
}

/*
	This function will get the next filename in the filename list returned by 'GetFilenameDialog'
*/
bool ASTFileSystem::GetNextFilename(char** pszMainFilename, char* pszFilename)
{
	char szTemp[256];

	// Check pointer
	if (!pszMainFilename || !*pszMainFilename || **pszMainFilename == EOF || !pszFilename || m_bNextFilenameEnd) return true;

	// Is this a single filename?
	if (IsFilenameValid(*pszMainFilename)) {
		strcpy(pszFilename, *pszMainFilename);
		if (strlen(pszFilename) + 1 > strlen(*pszMainFilename)) m_bNextFilenameEnd = true;
		*pszMainFilename += strlen(pszFilename);

		return false;
	}

	if (sscanf(*pszMainFilename, "%s", szTemp) == EOF) return true;
	*pszMainFilename += strlen(szTemp) + 1;
	sprintf(pszFilename, "%s\\%s", m_szNextFilenamePath, szTemp);

	return false;
}

/*
	Removes a file
*/
void ASTFileSystem::RemoveFile(const char* pszFilename) const
{
	SetFileAttributes(pszFilename, FILE_ATTRIBUTE_NORMAL);
	DeleteFile(pszFilename);
}

/*
	Removes a directory
*/
void ASTFileSystem::RemoveDirectory(const char* pszFilename) const
{
	WIN32_FIND_DATA FindFileData;
	char szFilename[256];
	char szTemp[256];
	HANDLE Find;
	                   
	// Check pointer
	if (!pszFilename) return;

	// Setup filename information
	strcpy(szFilename, pszFilename);
	GetFullFilename(szFilename);

	// Delete all files in this dictory
    sprintf(szTemp, "%s*.*", szFilename);
	Find = FindFirstFile(szTemp, &FindFileData);
	while(1) {
		if (FindFileData.cFileName[0] != '.' &&
			FindFileData.dwFileAttributes == FILE_ATTRIBUTE_DIRECTORY) {
			// We found a new sub directory
			sprintf(szTemp, "%s%s\\", szFilename, FindFileData.cFileName);
			RemoveDirectory(szTemp);
		} else {
			// We found a file
			sprintf(szTemp, "%s%s", pszFilename, FindFileData.cFileName);
			RemoveFile(szTemp);
		}

		if (!FindNextFile(Find, &FindFileData)) break;
	}
	FindClose(Find);

	// Remove the empty dictory
	RemoveDirectory(szFilename);
}

/*
	The same as the windows function 'WritePrivateProfileString'... only more comfortable ;-)
*/
bool ASTFileSystem::WritePrivateProfileEString(const LPCTSTR lpAppName, const LPCTSTR lpKeyName,
											   const LPCTSTR lpFileName, const char* pszString, ...) const
{
	char	szString[256];
	va_list	Ap;

	// Check pointer
	if (!pszString) return true;

	// Get string
	va_start(Ap, pszString);
	    vsprintf(szString, pszString, Ap);
	va_end(Ap);

	// Write into file
	WritePrivateProfileString(lpAppName, lpKeyName,	szString, lpFileName);

	return false;
}

/*
	Returns the different directories
*/
const char* ASTFileSystem::GetLanguagesDirectory() const
{
	return m_szLanguagesDirectory;
}

const char* ASTFileSystem::GetTexturesDirectory() const
{
	return m_szTexturesDirectory;
}

const char* ASTFileSystem::GetModelsDirectory() const
{
	return m_szModelsDirectory;
}

const char* ASTFileSystem::GetSoundsDirectory() const
{
	return m_szSoundsDirectory;
}

const char* ASTFileSystem::GetMusicDirectory() const
{
	return m_szMusicDirectory;
}

const char* ASTFileSystem::GetScreenshotsDirectory() const
{
	return m_szScreenshotsDirectory;
}

/*
	Opens the custom help file
*/
void ASTFileSystem::OpenHelp() const
{
	if (!stricmp(m_szCustomHelpFilename, "") ||
		!_AS::CWindowManager.GetMainWindow()->m_bActive)
		return;

	{
		char szFilename[256];

		_AS::CInput.Reset();
		strcpy(szFilename, m_szCustomHelpFilename);
		_AS::CFileSystem.GetFullFilename(szFilename);
		SendMessage(_AS::CWindowManager.GetMainWindow()->GetWnd(), WM_SYSCOMMAND, SC_MINIMIZE, 0);
		ShellExecute(0, "open", szFilename, 0, 0, SW_SHOW);
	}
}

/*
	Opens a file
*/
void ASTFileSystem::Open(const char* pszFilename) const
{
	if (!pszFilename) return;

	_AS::CLog.Output("Open file '%s'", pszFilename);
	ShellExecute(0, "open", pszFilename, 0, 0, SW_SHOW);				
}

/*
	Initialize the file system
*/
void ASTFileSystem::Init()
{
	char szApplicationExeName[256], szApplicationDrive[256], szApplicationDir[256];

	// Get application path
	GetModuleFileName(GetModuleHandle(NULL), szApplicationExeName, 256);
	_splitpath(szApplicationExeName, szApplicationDrive, szApplicationDir, NULL, NULL);
	sprintf(m_szApplicationPath, "%s%s", szApplicationDrive, szApplicationDir);
	SetCurrentDirectory(m_szApplicationPath);
}

/*
	Sets the cursom help file
*/
void ASTFileSystem::SetCustomHelpFile(const char* pszFilename)
{
	// Check pointer
	if (!pszFilename) strcpy(m_szCustomHelpFilename, "");
	else strcpy(m_szCustomHelpFilename, pszFilename);
}

/*
	Updates all file relevant stuff
*/
void ASTFileSystem::Update()
{
	// Check if the help file should be opened
	if (_AS::CInput.IsKeyHit(DIK_F1)) OpenHelp();
}
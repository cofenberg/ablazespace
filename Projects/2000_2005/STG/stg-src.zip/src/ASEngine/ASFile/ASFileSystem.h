/*
	File: ASFileSystem.h

	Description: Deals with files
*/


#ifndef __ASFILESYSTEM_H__
#define __ASFILESYSTEM_H__


// Definitions
#define ASCONFIG_FILE  "ini"	// Configuration file
#define ASLOG_FILE	   "log"	// Log file
#define ASTEXT_FILE	   "txt"	// Text file
#define ASTEXTURE_FILE "ast"	// Texture configuration file
#define ASMODEL_FILE   "asm"	// Model configuration file
#define ASSOUND_FILE   "ass"	// Sound configuration file
#define ASSHADER_FILE  "shader"	// Shader file
#define ASMD2_FILE	   "md2"	// Md2 file
#define ASMD2ANI_FILE  "md2ani"	// Md2 animation file
#define ASBMP_FILE	   "bmp"	// Bmp file
#define ASPPM_FILE	   "ppm"	// Ppm file
#define ASTEX_FILE	   "tex"	// Tex file
#define ASPCX_FILE	   "pcx"	// Pcx file
#define ASTGA_FILE	   "tga"	// Tga file
#define ASJPG_FILE	   "jpg"	// Jpg file

// Filename filters
#define ASTEXTURE_FILES \
		TEXT("BMP files (*.bmp)\0*.bmp\0") \
		TEXT("PPM files (*.ppm)\0*.ppm\0") \
		TEXT("TEX files (*.tex)\0*.ter\0") \
		TEXT("PCX files (*.pcx)\0*.pcx\0") \
		TEXT("TGA files (*.tga)\0*.tga\0") \
		TEXT("JPG files (*.jpg)\0*.jpg\0") \
		TEXT("All files (*.*)\0*.*;\0\0")
#define ASMODEL_FILES \
		TEXT("Md2 files (*.md2)\0*.md2\0")
#define ASSOUND_FILES \
		TEXT("Audio files (*.mp3; *.wav;)\0*.mp3; *.wav\0")\
		TEXT("Midi files (*.mid; *.midi;)\0*.mid; *.midi;\0")\
		TEXT("Mod files (*.it; *.mod; *.s3m; *.xm)\0*.it; *.mod; *.s3m; *.xm\0")\
		TEXT("All files (*.*)\0*.*;\0\0")


// Classes
typedef class ASTFileSystem {

	friend _AS;
	friend ASTConfig;
	friend ASTLanguageHandler;


	public:
		/*
			Returns the application path

			Returns:
				char* -> The application path (e.g. 'c:\Blibs\')
		*/
		AS_API const char* GetApplicationPath() const;

		/*
			Checks if the filename is valid or not (does file exist?)

			Parameters:
				char* pszFilename -> Pointer to the filename that should be checked

			Returns:
				bool -> 'true' if the filename is valid else 'false'
		*/
		AS_API bool IsFilenameValid(const char* pszFilename) const;

		/*
			Returns the filename ending of the given filename

			Parameters:
				char* pszFilename		-> The filename from which we want to have the ending
				char* pszFilenameEnding -> The filename ending

			Returns:
				bool -> 'true' if a filename ending was found else 'false'
		*/
		AS_API bool GetFilenameEnding(const char* pszFilename, char* pszFilenameEnding) const;

		/*
			Checks if the filename has the given ending

			Parameters:
				char* pszFilename		-> The filename
				char* pszFilenameEnding -> The file ending (file type)

			Returns:
				bool -> 'true' if the filename has the given ending else 'false'
		*/
		AS_API bool IsFilenameEnding(const char* pszFilename, const char* pszFilenameEnding) const;

		/*
			This function will always return the full filename with path information

			Parameters:
				char* pszFilename		-> The filename
				char* pszFilenameEnding -> The file ending (file type)
		*/
		AS_API void GetFullFilename(char* pszFilename, const char* pszFilenameEnding = NULL) const;

		/*
			This function will return the filename without the application path

			Parameters:
				char* pszFilename		-> The filename
				char* pszFilenameEnding -> The file ending (file type)

			Returns:
				bool -> 'true' if the application path was cut of else 'false'
		*/
		AS_API bool GetFilename(char* pszFilename, const char* pszFilenameEnding = NULL) const;

		/*
			Cut of the filename ending

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool CutFilenameEnding(char* pszFilename) const;

		/*
			This function will open a get filename dialog and will return the filename(s) without the application path

			Parameters:
				HWND  hWnd	          -> Handler of the parent window
				char* pszTitle        -> Title of the dialog
				char* pszFilter       -> Filename filter
				char* pszInitalDir    -> Initial directory
				bool  bMultiSelect    -> Could more than one file be selected?
				bool  bMustExist      -> Must the file exist?
				char* pszTempFilename -> Standart filename

			Returns:
				char* -> Pointer to the filename(s)

			Notes;
				- The files must be within the application directory
		*/
		AS_API char* GetFilenameDialog(const HWND hWnd, const char* pszTitle, const char* pszFilter,
									   const char* pszInitalDir, const bool bMultiSelect = false, const bool bMustExist = true,
									   const char* pszTempFilename = NULL) const;

		/*
			Initializes the function which will get the next filename in the filename list returned by 'GetFilenameDialog'

			Parameters:
				char** pszFilename

			Returns:
				bool -> 'false' if all went fine else 'true'

			Notes:
				- The pointer 'pszFilename' will be set to the first filename position
		*/
		AS_API bool InitGetFilename(char** pszFilename);

		/*
			This function will get the next filename in the filename list returned by 'GetFilenameDialog'

			Parameters:
				char*- pszMainFilename -> Pointer to the current filename string pointer
				char*  pszFilename	   -> Pointer to the string were the filename should be stored

			Returns:
				bool -> 'false' if all went fine else 'true'

			Notes:
				- The pointer 'pszMainFilename' will be set to the next filename position
		*/
		AS_API bool GetNextFilename(char** pszMainFilename, char* pszFilename);

		/*
			Removes a file

			Parameters:
				char* pszFilename -> Name of the file that should be removed

			Notes:
				- File attributes like write protection will be ignored
		*/
		AS_API void RemoveFile(const char* pszFilename) const;

		/*
			Removes a directory

			Parameters:
				char* pszFilename -> Directory that should be removed

			Notes:
				- If files or sub-directories are in the directory they will be removed, too
		*/
		AS_API void RemoveDirectory(const char* pszFilename) const;

		/*
			The same as the windows function 'WritePrivateProfileString'... only more comfortable ;-)

			Parameters:
			  LPCTSTR lpAppName,  // Pointer to section name
			  LPCTSTR lpKeyName,  // Pointer to key name
			  LPCTSTR lpFileName  // Pointer to initialization filename
			  LPCTSTR lpString,   // Pointer to string to add

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool WritePrivateProfileEString(const LPCTSTR lpAppName, const LPCTSTR lpKeyName,
											   const LPCTSTR lpFileName, const char* pszString, ...) const;

		/*
			Returns the different directories
		*/
		AS_API const char* GetLanguagesDirectory() const;
		AS_API const char* GetTexturesDirectory() const;
		AS_API const char* GetModelsDirectory() const;
		AS_API const char* GetSoundsDirectory() const;
		AS_API const char* GetMusicDirectory() const;
		AS_API const char* GetScreenshotsDirectory() const;

		/*
			Opens the custom help file

			Notes:
				- The help file could be setup in the language texts
		*/
		AS_API void OpenHelp() const;

		/*
			Opens a file

			Parameters:
				char* pszFilename -> Filename
		*/
		AS_API void Open(const char* pszFilename) const;


	private:
		char m_szApplicationPath[256];		// The applications path
		char m_szCustomHelpFilename[256];	// The name of the custom help file
		char m_szNextFilenamePath[256];		// Used for 'GetNextFilename'
		bool m_bNextFilenameEnd;			// Was the last filename found?

		// Directories
		char m_szLanguagesDirectory[256];	// Languages directory
		char m_szTexturesDirectory[256];	// Textures directory
		char m_szModelsDirectory[256];		// Models directory
		char m_szSoundsDirectory[256];		// Sounds directory
		char m_szMusicDirectory[256];		// Music directory
		char m_szScreenshotsDirectory[256];	// Screenshots directory

		// Files
		char m_szPreloadFile[256];	// Preload file


		/*
			Initialize the file system
		*/
		void Init();

		/*
			Sets the cursom help file

			Parameters:
				char* pszFilename -> The filename of the help file
		*/
		void SetCustomHelpFile(const char* pszFilename = NULL);

		/*
			Updates all file relevant stuff
		*/
		void Update();


} ASTFileSystem;


#endif // __ASFILESYSTEM_H__
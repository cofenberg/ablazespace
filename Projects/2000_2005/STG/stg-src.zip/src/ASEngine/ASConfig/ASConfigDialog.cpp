/*
	File: ASConfigDialog.cpp
*/

#include <ASEngineDll.h>
#include <commctrl.h>
#include "..\resource.h"


// Definations
#define CONFIG_TABS 6
int TAB_CONFIG_GENERAL, TAB_CONFIG_GRAPHIC, TAB_CONFIG_SOUND, TAB_CONFIG_CONTROL, TAB_CONFIG_DEBUG;

// Variables
ASTConfig CConfigT;
int		  iCurrentConfigTab;
HWND	  hWndConfig, hWndConfigTab[CONFIG_TABS];


/*
	Opens the configuration dialog
*/
bool ASTConfig::OpenDialog(const HWND hWnd)
{
	bool bError = false;

	// Minimize the window
	if (hWnd) SendMessage(hWnd, WM_SYSCOMMAND, SC_MINIMIZE, 0);

	// Make a backup of our current configuration
	memcpy(&CConfigT, this, sizeof(ASTConfig));

	// Add the text update function to the language handler
	CText.AddCustomUpdateFunction(ProcTextUpdate);

	if (DialogBox(GetModuleHandle(ASMODULENAME), MAKEINTRESOURCE(IDD_CONFIG), hWnd, (DLGPROC) ConfigProc) == -1)
		bError = true;
	hWndConfig = NULL;

	// Remove the text update function to the language handler
	CText.RemoveCustomUpdateFunction(ProcTextUpdate);
	
	// Normalize the window
	if (hWnd) SendMessage(hWnd, WM_SIZE, SIZE_RESTORED, 0);

	return bError;
}

/*
	Opens the credits dialog
*/
bool ASTConfig::OpenCreditsDialog(const HWND hWnd)
{
	bool bError = false;

	if(DialogBox(GetModuleHandle(ASMODULENAME), MAKEINTRESOURCE(IDD_CREDITS), hWnd, (DLGPROC) CreditsProc) == -1)
		bError = true;

	return bError;
}

/*
	The text update function
*/
void ASTConfig::ProcTextUpdate()
{
	SendMessage(hWndConfig, WM_INITDIALOG, 0, 0);
}

/*
	Main configuration procedure
*/
LRESULT CALLBACK ASTConfig::ConfigProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	return _AS::CConfig.Proc(hWnd, iMessage, wParam, lParam);
}

LRESULT ASTConfig::Proc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HWND hWndTab;
	TC_ITEM tie;
	int i;

	switch (iMessage) {
        case WM_INITDIALOG:			
			_AS::CLog.Output("Open engine configuration dialog");
			hWndConfig = hWnd;

			// Texts
			SetWindowText( hWnd,					  CText.Get(_T_Configurations));
  			SetDlgItemText(hWnd, IDC_CONFIG_OK,		  CText.Get(_T_Ok));
  			SetDlgItemText(hWnd, IDC_CONFIG_CANCEL,	  CText.Get(_T_Cancel));
  			SetDlgItemText(hWnd, IDC_CONFIG_STANDARD, CText.Get(_T_Standart));
  			SetDlgItemText(hWnd, IDC_CONFIG_QUIT,	  CText.Get(_T_Quit));
  			SetDlgItemText(hWnd, IDC_CONFIG_CREDITS,  CText.Get(_T_Credits));

			// Setup config tabs
			hWndTab = GetDlgItem(hWnd, IDC_CONFIG_TAB);
			TabCtrl_DeleteAllItems(hWndTab);
			tie.mask = TCIF_TEXT;

			// General
			TAB_CONFIG_GENERAL = 0;
			tie.pszText	= (char*) CText.Get(_T_General);
			TabCtrl_InsertItem(hWndTab, TAB_CONFIG_GENERAL, &tie);
			if (hWndConfigTab[TAB_CONFIG_GENERAL]) DestroyWindow(hWndConfigTab[TAB_CONFIG_GENERAL]);
			hWndConfigTab[TAB_CONFIG_GENERAL] = CreateDialogParam(GetModuleHandle(ASMODULENAME), MAKEINTRESOURCE(IDD_CONFIG_GENERAL), hWndTab, (DLGPROC) ConfigGeneralProc, WM_INITDIALOG);

			// Graphic
			TAB_CONFIG_GRAPHIC = TAB_CONFIG_GENERAL + 1;
			tie.pszText	= (char*) CText.Get(_T_Graphic);
			TabCtrl_InsertItem(hWndTab, TAB_CONFIG_GRAPHIC, &tie);
			if (hWndConfigTab[TAB_CONFIG_GRAPHIC]) DestroyWindow(hWndConfigTab[TAB_CONFIG_GRAPHIC]);
			hWndConfigTab[TAB_CONFIG_GRAPHIC] = CreateDialogParam(GetModuleHandle(ASMODULENAME), MAKEINTRESOURCE(IDD_CONFIG_GRAPHIC), hWndTab, (DLGPROC) ConfigGraphicProc, WM_INITDIALOG);

			// Sound
			if (_AS::CSoundManager.IsInitialized()) {
				TAB_CONFIG_SOUND = TAB_CONFIG_GRAPHIC + 1;
				tie.pszText	= (char*) CText.Get(_T_Sound);
				TabCtrl_InsertItem(hWndTab, TAB_CONFIG_SOUND, &tie);
				if (hWndConfigTab[TAB_CONFIG_SOUND]) DestroyWindow(hWndConfigTab[TAB_CONFIG_SOUND]);
				hWndConfigTab[TAB_CONFIG_SOUND] = CreateDialogParam(GetModuleHandle(ASMODULENAME),   MAKEINTRESOURCE(IDD_CONFIG_SOUND),   hWndTab, (DLGPROC) ConfigSoundProc,   WM_INITDIALOG);
			} else TAB_CONFIG_SOUND = TAB_CONFIG_GRAPHIC;

			// Control
			TAB_CONFIG_CONTROL = TAB_CONFIG_SOUND + 1;
			tie.pszText	= (char*) CText.Get(_T_Control);
			TabCtrl_InsertItem(hWndTab, TAB_CONFIG_CONTROL, &tie);
			if (hWndConfigTab[TAB_CONFIG_CONTROL]) DestroyWindow(hWndConfigTab[TAB_CONFIG_CONTROL]);
			hWndConfigTab[TAB_CONFIG_CONTROL] = CreateDialogParam(GetModuleHandle(ASMODULENAME), MAKEINTRESOURCE(IDD_CONFIG_CONTROL), hWndTab, (DLGPROC) ConfigControlProc, WM_INITDIALOG);

			// Debug
			if (m_bDebugMode) {
				TAB_CONFIG_DEBUG = TAB_CONFIG_CONTROL + 1;
				tie.pszText	= (char*) CText.Get(_T_Debug);
				TabCtrl_InsertItem(hWndTab, TAB_CONFIG_DEBUG, &tie);
				if (hWndConfigTab[TAB_CONFIG_DEBUG]) DestroyWindow(hWndConfigTab[TAB_CONFIG_DEBUG]);
				hWndConfigTab[TAB_CONFIG_DEBUG] = CreateDialogParam(GetModuleHandle(ASMODULENAME), MAKEINTRESOURCE(IDD_CONFIG_DEBUG), hWndTab, (DLGPROC) ConfigDebugProc, WM_INITDIALOG);
			} else TAB_CONFIG_DEBUG = TAB_CONFIG_CONTROL;

			iCurrentConfigTab = -1;
			SendMessage(hWnd, WM_NOTIFY, IDC_CONFIG_TAB, 0);

			UpdateWindow(hWnd);
			BringWindowToTop(hWnd);
			return true;

        case WM_COMMAND:
            switch (LOWORD(wParam)) {
                case IDC_CONFIG_OK:
					_AS::CLog.Output("Close engine configuration dialog (ok)");
					Check();
					Save(ASCONFIGFILE);

					// Check if we have to update the textures
					if (m_fTextureQuality != CConfigT.m_fTextureQuality)
						_AS::CTextureManager.ReloadTextures();
					else
					if (m_bTextureFiltering   != CConfigT.m_bTextureFiltering ||
						m_bMipmaps			  != CConfigT.m_bMipmaps ||
						m_bTextureCompression != CConfigT.m_bTextureCompression)
						_AS::CTextureManager.RebuildOpenGLTextures();

					EndDialog(hWnd, false);
					return true;

				case IDC_CONFIG_CANCEL:
					_AS::CLog.Output("Close engine configuration dialog (cancel)");
					memcpy(this, &CConfigT, sizeof(ASTConfig));
					EndDialog(hWnd, false);
					break;
				
				case IDC_CONFIG_STANDARD:
					if (MessageBox(hWnd, CText.Get(_T_AreYouSure), CText.Get(_T_Question), MB_YESNO | MB_ICONQUESTION) == IDNO)
						break;
					Reset();
					SendMessage(hWnd, WM_INITDIALOG, 0, 0);
					break;

				case IDC_CONFIG_QUIT:
					_AS::CLog.Output("Close engine configuration dialog (quit)");
					_AS::ShutDown();

					EndDialog(hWnd, false);
					break;

				case IDC_CONFIG_OPENGL:  DialogBox(GetModuleHandle(ASMODULENAME), MAKEINTRESOURCE(IDD_OPENGL),  hWnd, (DLGPROC) OpenGLInformationProc); break;
				case IDC_CONFIG_CREDITS: OpenCreditsDialog(); break;
				case IDC_ABLAZESPACE_HOMEPAGE: _AS::CFileSystem.Open("http://www.ablazespace.de"); break;
            }
            break;

        case WM_NOTIFY: 
			switch (wParam) {
				case IDC_CONFIG_TAB:
					i = TabCtrl_GetCurSel(GetDlgItem(hWnd, IDC_CONFIG_TAB));
					if (i == iCurrentConfigTab) break; // This tab is already opend
					iCurrentConfigTab = i;
					if (iCurrentConfigTab < 0) iCurrentConfigTab = 0;
					for (i = 0; i < CONFIG_TABS; i++) ShowWindow(hWndConfigTab[i], SW_HIDE);
					UpdateWindow(hWndConfigTab[iCurrentConfigTab]);
					ShowWindow(hWndConfigTab[iCurrentConfigTab], SW_SHOW);
					SetFocus(hWndConfigTab[iCurrentConfigTab]);
					SendMessage(hWndConfigTab[iCurrentConfigTab], WM_INITDIALOG, 0, 0);
					break;
			} 
			break;

		case WM_CLOSE: SendMessage(hWnd, WM_COMMAND, IDC_CONFIG_OK, 0); break;
		case WM_DESTROY: for(i = 0; i < CONFIG_TABS; i++) hWndConfigTab[i] = NULL; break;
    }

    return false;
}

/*
	General task procedure
*/
LRESULT CALLBACK ASTConfig::ConfigGeneralProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	return _AS::CConfig.GeneralProc(hWnd, iMessage, wParam, lParam);
}

LRESULT ASTConfig::GeneralProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	int i;

	switch (iMessage) {
        case WM_INITDIALOG:
			// Texts
  			SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_LANGUAGE_TEXT, CText.Get(_T_Language));
  			SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_SHOW_FPS,	   CText.Get(_T_ShowFPS));

			// Setup check buttons
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_SHOW_FPS, BM_SETCHECK, m_bShowFPS, 0L);

			// Fill up the language list
			{
	 			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LANGUAGE, CB_RESETCONTENT, 0, 0);

				ASTLinkedListElement<char*>* pCListElement = _AS::CLanguageManager.m_lstLanguageList.FindFirst();
				i = 0;
				while (pCListElement && pCListElement->Data) {
					SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LANGUAGE, CB_ADDSTRING, 0, (LONG)(LPSTR) pCListElement->Data);
					if (!stricmp(m_szLanguageName, pCListElement->Data))
						SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LANGUAGE, CB_SETCURSEL, i, 0L);

					pCListElement = _AS::CLanguageManager.m_lstLanguageList.FindNext();
					i++;
				}
			}
	
			UpdateWindow(hWnd);
			return true;

        case WM_COMMAND:
            switch (LOWORD(wParam)) {
				case IDC_CONFIG_GENERAL_SHOW_FPS: m_bShowFPS = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_SHOW_FPS, BM_GETCHECK, 0, 0L) != 0; break;
	
				case IDC_CONFIG_GENERAL_LANGUAGE:
					i = (int) SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LANGUAGE, CB_GETCURSEL, 0, 0L);
					if (i < 0) break;

					{
						char szLanguageName[256];

						SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LANGUAGE, CB_GETLBTEXT, i, (LPARAM) (LPCSTR)  szLanguageName);
						if (!strcmp(m_szLanguageName, szLanguageName)) break; // This language is already selected
						_AS::CLanguageManager.SetLanguage(szLanguageName);
					}
					break;
            }
            break;
    }

    return false;
}

/*
	Graphic task procedure
*/
LRESULT CALLBACK ASTConfig::ConfigGraphicProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	return _AS::CConfig.GraphicProc(hWnd, iMessage, wParam, lParam);
}

LRESULT ASTConfig::GraphicProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	char szTemp[256];
	int i;

	switch (iMessage) {
        case WM_INITDIALOG:
			// Texts
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_LIGHTING_T,				 CText.Get(_T_Lighting));
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_TEXTURE_FILTERING,		 CText.Get(_T_TextureFiltering));
  			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_USE_MIPMAPS,			 CText.Get(_T_UseMipmaps));
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_MULTITEXTURING,		  	 CText.Get(_T_Multitexturing));
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_HIGH_RENDER_QUALITY,	 CText.Get(_T_HighRenderQuality));
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_LIGHTMAPS,				 CText.Get(_T_Lightmaps));
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_SHADOWMAPS,				 CText.Get(_T_Shadowmaps));
  			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_DISPLAY_MODE,			 CText.Get(_T_DisplayMode));
  			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_FULLSCREEN,				 CText.Get(_T_Fullscreen));
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY_T,		 CText.Get(_T_ParticleDensity));
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY_LOW,	 CText.Get(_T_Low));
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY_MEDIUM, CText.Get(_T_Medium));
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY_HIGH,	 CText.Get(_T_High));
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_VISIBILITY_T,			 CText.Get(_T_Visiblity));
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_VISIBILITY_LOW,			 CText.Get(_T_Low));
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_VISIBILITY_MEDIUM,	     CText.Get(_T_Medium));
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_VISIBILITY_HIGH,		 CText.Get(_T_High));
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER_BITS_T,		 CText.Get(_T_ZBufferBits));
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_TEXTURE_COMPRESSION,	 CText.Get(_T_TextureCompression));
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_SMOOTH_LINES,			 CText.Get(_T_SmoothLines));
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_TEXTURE_QUALITY_T,		 CText.Get(_T_TextureQuality));

			// Comic style
			if (m_bComicStyle) {
				// Texts
				SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_COMIC_SILHOUETTES,		 CText.Get(_T_Silhouettes));
				SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_COMIC_CELSHADING,		 CText.Get(_T_CelShading));
				SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_COMIC_STYLE,			 CText.Get(_T_ComicStyle));

				// Setup check buttons
				SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_COMIC_SILHOUETTES, BM_SETCHECK, m_bComicSilhouettes, 0L);
				SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_COMIC_CELSHADING,  BM_SETCHECK, m_bComicCelShading,	 0L);
			}

			// Z buffer depth
 			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER_BITS, CB_RESETCONTENT, 0, 0);
    		SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER_BITS, CB_ADDSTRING, 0, (LONG)(LPSTR) "8");
    		SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER_BITS, CB_ADDSTRING, 0, (LONG)(LPSTR) "16");
    		SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER_BITS, CB_ADDSTRING, 0, (LONG)(LPSTR) "24");
    		SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER_BITS, CB_ADDSTRING, 0, (LONG)(LPSTR) "32");
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER_BITS, CB_SETCURSEL, m_iZBufferBits / 8 - 1, 0L);

			// Setup check buttons
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_FULLSCREEN,			  BM_SETCHECK, m_bFullscreen,		  0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_USE_MIPMAPS,		  BM_SETCHECK, m_bMipmaps,			  0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_TEXTURE_FILTERING,	  BM_SETCHECK, m_bTextureFiltering,	  0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MULTITEXTURING,		  BM_SETCHECK, m_bMultitexturing,	  0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_HIGH_RENDER_QUALITY,  BM_SETCHECK, m_bHighRenderQuality,  0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_PARTICLES,			  BM_SETCHECK, m_bParticles,		  0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_LIGHTMAPS,			  BM_SETCHECK, m_bLightmaps,		  0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_SHADOWMAPS,			  BM_SETCHECK, m_bShadowmaps,		  0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_SMOOTH_LINES,		  BM_SETCHECK, m_bSmoothLines,		  0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_TEXTURE_COMPRESSION,  BM_SETCHECK, m_bTextureCompression, 0L);
			
			// Setup lighting configuration
 			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_LIGHTING, CB_RESETCONTENT, 0, 0);
    		SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_LIGHTING, CB_ADDSTRING, 0, (LONG)(LPSTR) CText.Get(_T_None));
    		SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_LIGHTING, CB_ADDSTRING, 0, (LONG)(LPSTR) CText.Get(_T_Flat));
    		SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_LIGHTING, CB_ADDSTRING, 0, (LONG)(LPSTR) CText.Get(_T_Smooth));
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_LIGHTING, CB_SETCURSEL, m_iLightingMode, 0L);

			// Texture quality
 			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_TEXTURE_QUALITY, CB_RESETCONTENT, 0, 0);
    		SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_TEXTURE_QUALITY, CB_ADDSTRING, 0, (LONG)(LPSTR) CText.Get(_T_Low));
    		SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_TEXTURE_QUALITY, CB_ADDSTRING, 0, (LONG)(LPSTR) CText.Get(_T_Medium));
    		SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_TEXTURE_QUALITY, CB_ADDSTRING, 0, (LONG)(LPSTR) CText.Get(_T_High));
			     if (m_fTextureQuality < 0.5f) i = 0;
			else if (m_fTextureQuality < 1.f)  i = 1;
			else							   i = 2;
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_TEXTURE_QUALITY, CB_SETCURSEL, i, 0L);

			// Activate / deactivate elements
			if (!m_bHighRenderQuality || !_AS::CRenderer.CExtensions.IsMultitextureSupported())
				EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_MULTITEXTURING),		  false);
			else EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_MULTITEXTURING),		  true);
			EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_TEXTURE_COMPRESSION), _AS::CRenderer.CExtensions.IsTextureCompressionS3tcSupported());
			EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_COMIC_CELSHADING),    m_bMultitexturing);

			// Fill up the display mode list
			{
	 			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MODES, CB_RESETCONTENT, 0, 0);
				ASTDynamicLinkedListElement<DEVMODE>* pCListElement = _AS::CRenderer.m_lstDisplayModeList.FindFirst();
				while (pCListElement && pCListElement->pData) {
					if (pCListElement->pData->dmDisplayFrequency)
						sprintf(szTemp, "%dx%dx%d  %d HZ", pCListElement->pData->dmPelsWidth, 
														   pCListElement->pData->dmPelsHeight, 
														   pCListElement->pData->dmBitsPerPel, 
														   pCListElement->pData->dmDisplayFrequency);
					else
						sprintf(szTemp, "%dx%dx%d", pCListElement->pData->dmPelsWidth, 
													pCListElement->pData->dmPelsHeight, 
													pCListElement->pData->dmBitsPerPel);
     				SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MODES, CB_ADDSTRING, 0, (LONG)(LPSTR) szTemp);
					pCListElement = _AS::CRenderer.m_lstDisplayModeList.FindNext();
				}
				SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MODES, CB_SETCURSEL, _AS::CRenderer.m_lstDisplayModeList.IsElement(m_pSDisplayMode), 0L);
			}

			// Setup particle configuration
		    SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY, TBM_SETRANGE, false, MAKELONG(1, 100));
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY, TBM_SETTIC,	true, 50);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY, TBM_SETPOS,	true, (long) ((float) m_fParticleDensity * 100));
			EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY), m_bParticles);
  			sprintf(szTemp, "%.1f%%", (float) m_fParticleDensity * 100);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY_P, szTemp);

			// Setup visiblity configuration
		    SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_VISIBILITY, TBM_SETRANGE, false, MAKELONG(1, 100));
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_VISIBILITY, TBM_SETTIC,	  true, 50);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_VISIBILITY, TBM_SETPOS,   true, (long) ((float) m_fVisibility * 50));
			sprintf(szTemp, "%.1f%%", (float) m_fVisibility * 50);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_VISIBILITY_P, szTemp);

			SetFocus(hWnd);
			UpdateWindow(hWnd);
			return true;

		case WM_NOTIFY:
            switch (wParam) {
				case IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY:
					i = (int) SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY, TBM_GETPOS, 0, 0);
					m_fParticleDensity = (float) i / 100;
					if (m_fParticleDensity > 1.f) m_fParticleDensity = 1.f;
  					sprintf(szTemp, "%0.1f%%", (float) m_fParticleDensity * 100);
					SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY_P, szTemp);
					break;

				case IDC_CONFIG_GRAPHIC_VISIBILITY:
					i = (int) SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_VISIBILITY, TBM_GETPOS, 0, 0);
					m_fVisibility = (float) i / 50;
					if (m_fVisibility < 0.4f) m_fVisibility = 0.4f;
  					sprintf(szTemp, "%0.1f%%", (float) m_fVisibility * 100);
					SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_VISIBILITY_P, szTemp);
					break;
			}
			break;

		case WM_COMMAND:
            switch (LOWORD(wParam)) {
				case IDC_CONFIG_GRAPHIC_FULLSCREEN: m_bFullscreen = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_FULLSCREEN, BM_GETCHECK, 0, 0L) != 0; break;

				case IDC_CONFIG_GRAPHIC_MODES:
   					i = (int) SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MODES, CB_GETCURSEL, 0, 0L);
					if (i < 0) break;
					m_pSDisplayMode = _AS::CRenderer.m_lstDisplayModeList[i];
					CopyMemory(&m_SDisplayMode, m_pSDisplayMode, sizeof(DEVMODE));
					break;

				case IDC_CONFIG_GRAPHIC_TEXTURE_FILTERING: m_bTextureFiltering = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_TEXTURE_FILTERING, BM_GETCHECK, 0, 0L) != 0; break;
				case IDC_CONFIG_GRAPHIC_USE_MIPMAPS: m_bMipmaps = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_USE_MIPMAPS, BM_GETCHECK, 0, 0L) != 0; break;

				case IDC_CONFIG_GRAPHIC_HIGH_RENDER_QUALITY:
					m_bHighRenderQuality = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_HIGH_RENDER_QUALITY, BM_GETCHECK, 0, 0L) != 0;
					if (!m_bHighRenderQuality) {
						EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_MULTITEXTURING),   false);
						EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_COMIC_CELSHADING), false);
					} else {
						EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_MULTITEXTURING),   true);
						EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_COMIC_CELSHADING), true);
					}
					if (!m_bHighRenderQuality) m_bMultitexturing = false;
					break;				
				
				case IDC_CONFIG_GRAPHIC_LIGHTMAPS:      m_bLightmaps  = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_LIGHTMAPS,	    BM_GETCHECK, 0, 0L) != 0; break;
				case IDC_CONFIG_GRAPHIC_SHADOWMAPS:     m_bShadowmaps = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_SHADOWMAPS,	    BM_GETCHECK, 0, 0L) != 0; break;

				case IDC_CONFIG_GRAPHIC_MULTITEXTURING:
					m_bMultitexturing = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MULTITEXTURING, BM_GETCHECK, 0, 0L) != 0;
					EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_COMIC_CELSHADING), m_bMultitexturing);
					break;

				case IDC_CONFIG_GRAPHIC_PARTICLES:
					m_bParticles = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_PARTICLES, BM_GETCHECK, 0, 0L) != 0;
					EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY), m_bParticles);
					break;
				
   				case IDC_CONFIG_GRAPHIC_Z_BUFFER_BITS:
					i = (int) SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER_BITS, CB_GETCURSEL, 0, 0L);
					if (i < 0) break;
					m_iZBufferBits = (i + 1) * 8;
					break;

   				case IDC_CONFIG_GRAPHIC_LIGHTING:
					i = (int) SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_LIGHTING, CB_GETCURSEL, 0, 0L);
					if (i < 0) break;
					m_iLightingMode = i;
					break;

				case IDC_CONFIG_GRAPHIC_TEXTURE_QUALITY:
					i = (int) SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_TEXTURE_QUALITY, CB_GETCURSEL, 0, 0L);
					switch(i) {
						case 0: m_fTextureQuality = 0.2f; break;
						case 1: m_fTextureQuality = 0.6f; break;
						case 2: m_fTextureQuality = 1.f;  break;
					}
					break;
				
				case IDC_CONFIG_GRAPHIC_COMIC_SILHOUETTES:   m_bComicSilhouettes   = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_COMIC_SILHOUETTES,   BM_GETCHECK, 0, 0L) != 0; break;
				case IDC_CONFIG_GRAPHIC_COMIC_CELSHADING:    m_bComicCelShading    = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_COMIC_CELSHADING,    BM_GETCHECK, 0, 0L) != 0; break;
				case IDC_CONFIG_GRAPHIC_SMOOTH_LINES:        m_bSmoothLines        = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_SMOOTH_LINES,		  BM_GETCHECK, 0, 0L) != 0; break;
				case IDC_CONFIG_GRAPHIC_TEXTURE_COMPRESSION: m_bTextureCompression = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_TEXTURE_COMPRESSION, BM_GETCHECK, 0, 0L) != 0; break;
            }
            break;
    }

    return false;
}

/*
	Sound task procedure
*/
LRESULT CALLBACK ASTConfig::ConfigSoundProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	return _AS::CConfig.SoundProc(hWnd, iMessage, wParam, lParam);
}

LRESULT ASTConfig::SoundProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	char szTemp[256];
	int i;
	
	switch (iMessage) {
        case WM_INITDIALOG:
  			// Texts
			SetDlgItemText(hWnd, IDC_CONFIG_SOUND_SOUND_SYSTEM_T,	   CText.Get(_T_SoundSystem));
  			SetDlgItemText(hWnd, IDC_CONFIG_SOUND_OUTPUT_DRIVER_T,	   CText.Get(_T_OutputDriver));
  			SetDlgItemText(hWnd, IDC_CONFIG_SOUND_SOUND_DRIVER_T,	   CText.Get(_T_SoundDriver));
  			SetDlgItemText(hWnd, IDC_CONFIG_SOUND_MIXING_DRIVER_T,	   CText.Get(_T_MixingDriver));
  			SetDlgItemText(hWnd, IDC_CONFIG_SOUND_SOUND_OUTPUT_RATE_T, CText.Get(_T_OutputRate));
  			SetDlgItemText(hWnd, IDC_CONFIG_SOUND_CHANNELS_T,		   CText.Get(_T_Channels));
  			SetDlgItemText(hWnd, IDC_CONFIG_SOUND_SOUND,			   CText.Get(_T_Sound));
  			SetDlgItemText(hWnd, IDC_CONFIG_SOUND_SOUND_VOLUME_T,	   CText.Get(_T_SoundVolume));
  			SetDlgItemText(hWnd, IDC_CONFIG_SOUND_MUSIC,			   CText.Get(_T_Music));
  			SetDlgItemText(hWnd, IDC_CONFIG_SOUND_MUSIC_VOLUME_T,	   CText.Get(_T_MusicVolume));

			// Setup check buttons
			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_SOUND, BM_SETCHECK, m_bSound, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MUSIC, BM_SETCHECK, m_bMusic, 0L);

			// Setup the sound configuration
		    SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_SOUND_VOLUME, TBM_SETRANGE, false, MAKELONG(1, 100));
			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_SOUND_VOLUME, TBM_SETTIC,   true, 50);
			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_SOUND_VOLUME, TBM_SETPOS,   true, (long) (m_fSoundVolume * 100));
  			sprintf(szTemp, "%0.1f%%", m_fSoundVolume * 100);
			SetDlgItemText(hWnd, IDC_CONFIG_SOUND_SOUND_VOLUME_P, szTemp);
		
			// Setup the music configuration
		    SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MUSIC_VOLUME, TBM_SETRANGE, false, MAKELONG(1, 100));
			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MUSIC_VOLUME, TBM_SETTIC,   true, 50);
			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MUSIC_VOLUME, TBM_SETPOS,   true, (long) (m_fMusicVolume * 100));
  			sprintf(szTemp, "%0.1f%%", m_fMusicVolume * 100);
			SetDlgItemText(hWnd, IDC_CONFIG_SOUND_MUSIC_VOLUME_P, szTemp);

			// Activate / deactivate elements
			EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_SOUND_MUSIC_VOLUME), m_bMusic);
			EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_SOUND_SOUND_VOLUME), m_bSound);

			// Setup sound output device list
	 		SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_OUTPUT_DRIVER, CB_RESETCONTENT, 0, 0);
    		SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_OUTPUT_DRIVER, CB_ADDSTRING, 0, (LONG)(LPSTR) "Direct Sound");
    		SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_OUTPUT_DRIVER, CB_ADDSTRING, 0, (LONG)(LPSTR) "Windows Multimedia WaveOut");
    		SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_OUTPUT_DRIVER, CB_ADDSTRING, 0, (LONG)(LPSTR) "A3D");
			if (m_iSoundOutputDriver == FSOUND_OUTPUT_DSOUND) 
				SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_OUTPUT_DRIVER, CB_SETCURSEL, 0, 0L);
			else if (m_iSoundOutputDriver == FSOUND_OUTPUT_WINMM) 
				SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_OUTPUT_DRIVER, CB_SETCURSEL, 1, 0L);
			else if (m_iSoundOutputDriver == FSOUND_OUTPUT_A3D) 
				SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_OUTPUT_DRIVER, CB_SETCURSEL, 2, 0L);

			// Setup sound mixing driver
	 		SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MIXING_DRIVER, CB_RESETCONTENT, 0, 0);
   			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MIXING_DRIVER, CB_ADDSTRING, 0, (LONG)(LPSTR) "Autodetect");
   			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MIXING_DRIVER, CB_ADDSTRING, 0, (LONG)(LPSTR) "Interpolation/Volume Ramping - FPU");
   			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MIXING_DRIVER, CB_ADDSTRING, 0, (LONG)(LPSTR) "Interpolation/Volume Ramping - Pentium MMX");
   			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MIXING_DRIVER, CB_ADDSTRING, 0, (LONG)(LPSTR) "Interpolation/Volume Ramping - P6/P2/P3+ MMX");
			if (m_iSoundMixingDriver == FSOUND_MIXER_QUALITY_AUTODETECT)
				SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MIXING_DRIVER, CB_SETCURSEL, 0, 0L);
			else if (m_iSoundMixingDriver == FSOUND_MIXER_QUALITY_FPU)
				SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MIXING_DRIVER, CB_SETCURSEL, 1, 0L);
			else if (m_iSoundMixingDriver == FSOUND_MIXER_QUALITY_MMXP5)
				SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MIXING_DRIVER, CB_SETCURSEL, 2, 0L);
			else if (m_iSoundMixingDriver == FSOUND_MIXER_QUALITY_MMXP6)
				SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MIXING_DRIVER, CB_SETCURSEL, 3, 0L);

			// Setup sound output rate
	 		SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_OUTPUT_RATE, CB_RESETCONTENT, 0, 0);
   			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_OUTPUT_RATE, CB_ADDSTRING, 0, (LONG)(LPSTR) "48");
   			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_OUTPUT_RATE, CB_ADDSTRING, 0, (LONG)(LPSTR) "44");
   			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_OUTPUT_RATE, CB_ADDSTRING, 0, (LONG)(LPSTR) "22");
   			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_OUTPUT_RATE, CB_ADDSTRING, 0, (LONG)(LPSTR) "11");
   			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_OUTPUT_RATE, CB_ADDSTRING, 0, (LONG)(LPSTR) " 8");
				 if (m_iSoundOutputRate == 48000) i = 0;
			else if (m_iSoundOutputRate == 44100) i = 1;
			else if (m_iSoundOutputRate == 22050) i = 2;
			else if (m_iSoundOutputRate == 11025) i = 3;
			else if (m_iSoundOutputRate ==  8000) i = 4;
			else 											   i = 1;
			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_OUTPUT_RATE, CB_SETCURSEL, i, 0L);

			// Channels
	 		SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_CHANNELS, CB_RESETCONTENT, 0, 0);
   			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_CHANNELS, CB_ADDSTRING, 0, (LONG)(LPSTR) "16");
   			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_CHANNELS, CB_ADDSTRING, 0, (LONG)(LPSTR) "32");
   			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_CHANNELS, CB_ADDSTRING, 0, (LONG)(LPSTR) "64");
   			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_CHANNELS, CB_ADDSTRING, 0, (LONG)(LPSTR) "128");
			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_CHANNELS, CB_SETCURSEL, m_iSoundChannels / 16 - 1, 0L);
			
		Init:
			// Setup sound driver list
	 		SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_SOUND_DRIVER, CB_RESETCONTENT, 0, 0);
			for (i = 0; i < FSOUND_GetNumDrivers(); i++)
    			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_SOUND_DRIVER, CB_ADDSTRING, 0, (LONG)(LPSTR) FSOUND_GetDriverName(i));
			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_SOUND_DRIVER, CB_SETCURSEL, m_iSoundDriver, 0L);

			SetFocus(hWnd);
			UpdateWindow(hWnd);
			return true;

        case WM_NOTIFY:
            switch (wParam) {
				case IDC_CONFIG_SOUND_MUSIC_VOLUME:
					i = SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MUSIC_VOLUME, TBM_GETPOS, 0, 0);
					m_fMusicVolume = (float) i / 100;
  					sprintf(szTemp, "%0.1f%%", m_fMusicVolume * 100);
					SetDlgItemText(hWnd, IDC_CONFIG_SOUND_MUSIC_VOLUME_P, szTemp);
					_AS::CSoundManager.UpdateVolume();
					break;
				
				case IDC_CONFIG_SOUND_SOUND_VOLUME:
					i = SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_SOUND_VOLUME, TBM_GETPOS, 0, 0);
					m_fSoundVolume = (float) i / 100;
  					sprintf(szTemp, "%0.1f%%", m_fSoundVolume * 100);
					SetDlgItemText(hWnd, IDC_CONFIG_SOUND_SOUND_VOLUME_P, szTemp);
					_AS::CSoundManager.UpdateVolume();
					break;
			}
			break;

		case WM_COMMAND:
            switch (LOWORD(wParam)) {
				case IDC_CONFIG_SOUND_OUTPUT_DRIVER:
					i = SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_OUTPUT_DRIVER, CB_GETCURSEL, 0, 0L);
					switch (i) {
						case 0: m_iSoundOutputDriver = FSOUND_OUTPUT_DSOUND; break;
						case 1: m_iSoundOutputDriver = FSOUND_OUTPUT_WINMM; break;
						case 2: m_iSoundOutputDriver = FSOUND_OUTPUT_A3D; break;
					}
					goto Init;

				case IDC_CONFIG_SOUND_SOUND_DRIVER:
					i = SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_SOUND_DRIVER, CB_GETCURSEL, 0, 0L);
					if (i < 0 || i >= FSOUND_GetNumDrivers()) break;
					m_iSoundDriver = i;
					break;

				case IDC_CONFIG_SOUND_MIXING_DRIVER:
					i = SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MIXING_DRIVER, CB_GETCURSEL, 0, 0L);
					switch (i) {
						case 0: m_iSoundMixingDriver = FSOUND_MIXER_QUALITY_AUTODETECT; break;
						case 1: m_iSoundMixingDriver = FSOUND_MIXER_QUALITY_FPU; break;
						case 2: m_iSoundMixingDriver = FSOUND_MIXER_QUALITY_MMXP5; break;
						case 3: m_iSoundMixingDriver = FSOUND_MIXER_QUALITY_MMXP6; break;
					}
					break;

				case IDC_CONFIG_SOUND_OUTPUT_RATE:
					i = SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_OUTPUT_RATE, CB_GETCURSEL, 0, 0L);
					switch (i) {
						case 0: m_iSoundOutputRate = 48000; break;
						case 1: m_iSoundOutputRate = 44100; break;
						case 2: m_iSoundOutputRate = 22050; break;
						case 3: m_iSoundOutputRate = 11025; break;
						case 4: m_iSoundOutputRate =  8000; break;
					}
					break;

				case IDC_CONFIG_SOUND_CHANNELS:
					i = SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_CHANNELS, CB_GETCURSEL, 0, 0L);
					if (i < 0 || i > 3) break;
					m_iSoundChannels = (i + 1) * 16;
					break;

				case IDC_CONFIG_SOUND_SOUND:
					m_bSound = SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_SOUND, BM_GETCHECK, 0, 0L) != 0;
					EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_SOUND_SOUND_VOLUME), m_bSound);
					_AS::CSoundManager.UpdateVolume();
					break;

				case IDC_CONFIG_SOUND_MUSIC:
					m_bMusic = SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MUSIC, BM_GETCHECK, 0, 0L) != 0;
					EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_SOUND_MUSIC_VOLUME), m_bMusic);
					_AS::CSoundManager.UpdateVolume();
					break;
            }
        break;
    }

    return false;
}

/*
	Control task procedure
*/
LRESULT CALLBACK ASTConfig::ConfigControlProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	return _AS::CConfig.ControlProc(hWnd, iMessage, wParam, lParam);
}

LRESULT ASTConfig::ControlProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	char szTemp[256];
	int i;
	
	switch (iMessage) {
        case WM_INITDIALOG:
  			// Texts
  			SetDlgItemText(hWnd, IDC_CONFIG_CONTROL_MOUSE_T,				  CText.Get(_T_Mouse));
  			SetDlgItemText(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY_T,	  CText.Get(_T_Sensibility));
			SetDlgItemText(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY_LOW,    CText.Get(_T_Low));
  			SetDlgItemText(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY_NORMAL, CText.Get(_T_Normal));
  			SetDlgItemText(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY_HIGH,   CText.Get(_T_High));
  			SetDlgItemText(hWnd, IDC_CONFIG_CONTROL_MOUSE_INVERT_Y_AXE,		  CText.Get(_T_InvertYAxe));

			// Setup mouse sensibility configuration
		    SendDlgItemMessage(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY, TBM_SETRANGE, false, MAKELONG(1, 100));
			SendDlgItemMessage(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY, TBM_SETTIC,	 true, 50);
			SendDlgItemMessage(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY, TBM_SETPOS,   true, (long) ((float) m_fMouseSensibility * 50.0f));
  			sprintf(szTemp, "%0.1f%%", (float) m_fMouseSensibility * 100);
			SetDlgItemText(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY_P, szTemp);			

			SendDlgItemMessage(hWnd, IDC_CONFIG_CONTROL_MOUSE_INVERT_Y_AXE, BM_SETCHECK, m_bInvertMouseYAxe, 0L);

			SetFocus(hWnd);
			UpdateWindow(hWnd);
			return true;

        case WM_NOTIFY:
            switch (wParam) {
				case IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY:
					i = (int) SendDlgItemMessage(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY, TBM_GETPOS, 0, 0);
					m_fMouseSensibility = (float) i / 50;
					if (m_fMouseSensibility < 0.1f) m_fMouseSensibility = 0.1f;
  					sprintf(szTemp, "%0.1f%%", (float) m_fMouseSensibility * 100);
					SetDlgItemText(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY_P, szTemp);			
					break;
			}
			break;

		case WM_COMMAND:
			switch (LOWORD(wParam)) {
				case IDC_CONFIG_CONTROL_MOUSE_INVERT_Y_AXE: m_bInvertMouseYAxe = SendDlgItemMessage(hWnd, IDC_CONFIG_CONTROL_MOUSE_INVERT_Y_AXE, BM_GETCHECK, 0, 0L) != 0; break;
			}
			break;
    }

    return false;
}

/*
	Debug task procedure
*/
LRESULT CALLBACK ASTConfig::ConfigDebugProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	return _AS::CConfig.DebugProc(hWnd, iMessage, wParam, lParam);
}

LRESULT ASTConfig::DebugProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	switch (iMessage) {
        case WM_INITDIALOG:
  			// Texts
  			SetDlgItemText(hWnd, IDC_CONFIG_DEBUG_SHOW_COORDINATE_AXES, CText.Get(_T_ShowCoordinateAxes));
  			SetDlgItemText(hWnd, IDC_CONFIG_DEBUG_SHOW_TRIANGLES,	    CText.Get(_T_ShowTriangles));
  			SetDlgItemText(hWnd, IDC_CONFIG_DEBUG_SHOW_BOUNDING_BOXES,  CText.Get(_T_ShowBoundingBoxes));
  			SetDlgItemText(hWnd, IDC_CONFIG_DEBUG_WIREFRAME_MODE,	    CText.Get(_T_WireframeMode));
  			SetDlgItemText(hWnd, IDC_CONFIG_DEBUG_POINT_MODE,		    CText.Get(_T_PointMode));

			// Setup check buttons
			SendDlgItemMessage(hWnd, IDC_CONFIG_DEBUG_SHOW_COORDINATE_AXES, BM_SETCHECK, m_bShowCoordinateAxes, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_DEBUG_SHOW_BOUNDING_BOXES,  BM_SETCHECK, m_bShowBoundingBoxes,  0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_DEBUG_SHOW_TRIANGLES,		BM_SETCHECK, m_bShowTriangles,	    0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_DEBUG_WIREFRAME_MODE,	    BM_SETCHECK, m_bWireframeMode,	    0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_DEBUG_POINT_MODE,		    BM_SETCHECK, m_bPointMode,		    0L);

			SetFocus(hWnd);
			UpdateWindow(hWnd);
			return true;

		case WM_COMMAND:
			switch (LOWORD(wParam)) {
				case IDC_CONFIG_DEBUG_SHOW_COORDINATE_AXES: m_bShowCoordinateAxes = SendDlgItemMessage(hWnd, IDC_CONFIG_DEBUG_SHOW_COORDINATE_AXES, BM_GETCHECK, 0, 0L) != 0; break;
				case IDC_CONFIG_DEBUG_SHOW_BOUNDING_BOXES:  m_bShowBoundingBoxes  = SendDlgItemMessage(hWnd, IDC_CONFIG_DEBUG_SHOW_BOUNDING_BOXES,  BM_GETCHECK, 0, 0L) != 0; break;
				case IDC_CONFIG_DEBUG_SHOW_TRIANGLES:	    m_bShowTriangles	  = SendDlgItemMessage(hWnd, IDC_CONFIG_DEBUG_SHOW_TRIANGLES,	    BM_GETCHECK, 0, 0L) != 0; break;

				case IDC_CONFIG_DEBUG_WIREFRAME_MODE:
					m_bWireframeMode = SendDlgItemMessage(hWnd, IDC_CONFIG_DEBUG_WIREFRAME_MODE, BM_GETCHECK, 0, 0L) != 0;
					if (m_bPointMode) {
						m_bPointMode = false;
						SendDlgItemMessage(hWnd, IDC_CONFIG_DEBUG_POINT_MODE, BM_SETCHECK, m_bPointMode, 0L);
					}
					break;

				case IDC_CONFIG_DEBUG_POINT_MODE:
					m_bPointMode = SendDlgItemMessage(hWnd, IDC_CONFIG_DEBUG_POINT_MODE, BM_GETCHECK, 0, 0L) != 0;
					if (m_bWireframeMode) {
						m_bWireframeMode = false;
						SendDlgItemMessage(hWnd, IDC_CONFIG_DEBUG_WIREFRAME_MODE, BM_SETCHECK, m_bWireframeMode, 0L);
					}
					break;
			}
			break;
    }

    return false;
}

/*
	OpenGL information procedure
*/
LRESULT CALLBACK ASTConfig::OpenGLInformationProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	char *pszTemp, szTemp[256];

    switch (iMessage) {
        case WM_INITDIALOG:
			_AS::CLog.Output("Open OpenGL dialog");
            SetDlgItemText(hWnd, IDC_OPENGL_VERSION_INFO,  (const char *) glGetString(GL_VERSION));
            SetDlgItemText(hWnd, IDC_OPENGL_VENDOR_INFO,   (const char *) glGetString(GL_VENDOR));
            SetDlgItemText(hWnd, IDC_OPENGL_RENDERER_INFO, (const char *) glGetString(GL_RENDERER));
			if (pszTemp = (char *) glGetString(GL_EXTENSIONS)) {
				while (1) {
					if (sscanf(pszTemp, "%s", szTemp) == EOF) break;
					SendDlgItemMessage(hWnd, IDC_OPENGL_EXTENSIONS_INFO, LB_ADDSTRING, 0, (LONG)(LPSTR) szTemp);
					if (!(*(pszTemp + strlen(szTemp) + 1))) break;
					pszTemp += strlen((const char*) szTemp) + 1;
				}
			}

			// Texts
  			SetDlgItemText(hWnd, IDC_OPENGL_OK, CText.Get(_T_Ok));
			return true;

        case WM_COMMAND:
            switch (LOWORD(wParam)) {
                case IDC_OPENGL_OK:
					_AS::CLog.Output("Close OpenGL dialog (ok)");
					EndDialog(hWnd, false);
					return true;
            }
			break;
		
		case WM_CLOSE: SendMessage(hWnd, WM_COMMAND, IDC_OPENGL_OK, 0); break;
    }

    return false;
}

/*
	Credits procedure
*/
LRESULT CALLBACK ASTConfig::CreditsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	char szTemp[256];

	switch (iMessage) {
        case WM_INITDIALOG:
			_AS::CLog.Output("Open engine credits dialog");
            SetDlgItemText(hWnd, IDC_CREDITS_VERSION,    ASENGINEVERSION);
            SetDlgItemText(hWnd, IDC_CREDITS_BUILD_DATE, __DATE__);
            SetDlgItemText(hWnd, IDC_CREDITS_BUILD_TIME, __TIME__);

			// Texts
  			SetDlgItemText(hWnd, IDC_CREDITS_OK,		   CText.Get(_T_Ok));
  			SetDlgItemText(hWnd, IDC_CREDITS_VERSION_TEXT, CText.Get(_T_Version));
  			SetDlgItemText(hWnd, IDC_CREDITS_BUILD,		   CText.Get(_T_Build));
			sprintf(szTemp, "%s:", CText.Get(_T_Programming));
  			SetDlgItemText(hWnd, IDC_CREDITS_PROGRAMMING,  szTemp);
			return true;

        case WM_COMMAND:
            switch (LOWORD(wParam)) {
                case IDC_CREDITS_OK:
					_AS::CLog.Output("Close engine credits dialog");
					EndDialog(hWnd, false);
					return true;
            }
			break;

		case WM_CLOSE: SendMessage(hWnd, WM_COMMAND, IDC_CREDITS_OK, 0); break;
    }

    return false;
}
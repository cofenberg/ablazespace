/*
	File: ASConfig.cpp
*/

#include <ASEngineDll.h>


// Texture compression
#define MAXTEXTURESOMPRESSIONMODES 4
int iTextureCompressionModes[MAXTEXTURESOMPRESSIONMODES] = {GL_RGBA8,
															COMPRESSED_RGBA_S3TC_DXT5_EXT,
															COMPRESSED_RGBA_S3TC_DXT3_EXT,
															COMPRESSED_RGBA_S3TC_DXT1_EXT};


/*
	Constructor
*/
ASTConfig::ASTConfig()
{
	m_bLogActivated = true;
}

/*
	Initialize the configuration
*/
bool ASTConfig::Init()
{
	m_bLoaded = false;

	return Load(ASCONFIGFILE);
}

/*
	Load engine configuration
*/
bool ASTConfig::Load(const char* pszFilename)
{
	char szTemp[256];
	
	// Check pointer
	if (!pszFilename) return true;

	// Save the preview configuration
	if (m_bLoaded) Save(m_szFilename);

	// Setup filename information
	strcpy(m_szFilename, pszFilename);
	_AS::CFileSystem.GetFullFilename(m_szFilename, ASCONFIG_FILE);

	// Load the configurations
	if (GetPrivateProfileInt("general", "last_crashed_message",	1, m_szFilename) != 0)
		m_bLastCrashed = GetPrivateProfileInt("general", "last_crashed", 0, m_szFilename) != 0;
	else m_bLastCrashed = false; 
	WritePrivateProfileString("general", "last_crashed", "1", m_szFilename);
	m_bFirstRun			 = GetPrivateProfileInt("general", "firstrun",			 1, m_szFilename) != 0;
	m_bDebugMode		 = GetPrivateProfileInt("general", "debugmode",			 0, m_szFilename) != 0;
	m_bNoSound			 = GetPrivateProfileInt("general", "nosound",			 0, m_szFilename) != 0;
	m_bLogActivated		 = GetPrivateProfileInt("general", "log",				 1, m_szFilename) != 0;
	m_bShowFPS			 = GetPrivateProfileInt("general", "showfps",			 0, m_szFilename) != 0;
	GetPrivateProfileString("general", "language", "GB", m_szLanguageName, 256, m_szFilename);

	// Debug configurations
	if (m_bDebugMode) {
		m_bShowCoordinateAxes = GetPrivateProfileInt("debug", "showcoordinateaxes", 0, m_szFilename) != 0;
		m_bShowTriangles	  = GetPrivateProfileInt("debug", "showtriangles",	    0, m_szFilename) != 0;
		m_bShowBoundingBoxes  = GetPrivateProfileInt("debug", "showboundingboxes",  0, m_szFilename) != 0;
		m_bWireframeMode	  = GetPrivateProfileInt("debug", "wireframemode",	    0, m_szFilename) != 0;
		m_bPointMode		  = GetPrivateProfileInt("debug", "pointmode",		    0, m_szFilename) != 0;
	}

	// Load display mode information
	m_bFullscreen	  = GetPrivateProfileInt("displaymode", "fullscreen",   1, m_szFilename) != 0;
	    SetDisplayWidth(GetPrivateProfileInt("displaymode", "width",	  640, m_szFilename));
	   SetDisplayHeight(GetPrivateProfileInt("displaymode", "height",	  480, m_szFilename));
	SetDisplayColorBits(GetPrivateProfileInt("displaymode", "colorbits",   16, m_szFilename));
	SetDisplayFrequency(GetPrivateProfileInt("displaymode", "frequency",    0, m_szFilename));

	// Graphic
	m_bUseExtensions		  = GetPrivateProfileInt("graphic", "useextensions",		1, m_szFilename) != 0;
	m_iZBufferBits			  = GetPrivateProfileInt("graphic", "zbufferbits",		   16, m_szFilename);
	m_iLightingMode			  = GetPrivateProfileInt("graphic", "lightingmode",	        2, m_szFilename);
	m_bHighRenderQuality	  = GetPrivateProfileInt("graphic", "highrenderquality",    1, m_szFilename) != 0;
	m_bLightmaps			  = GetPrivateProfileInt("graphic", "lightmaps",			1, m_szFilename) != 0;
	m_bShadowmaps			  = GetPrivateProfileInt("graphic", "shadowmaps",			1, m_szFilename) != 0;
	m_bMultitexturing		  = GetPrivateProfileInt("graphic", "multitexturing",		1, m_szFilename) != 0;
	m_bParticles			  = GetPrivateProfileInt("graphic", "particles",			1, m_szFilename) != 0;
	GetPrivateProfileString("graphic", "particledensity", "1",   szTemp, 256, m_szFilename);
	m_fParticleDensity		  = (float) atof(szTemp);
	GetPrivateProfileString("graphic", "visibility",	  "0.6", szTemp, 256, m_szFilename);
	m_fVisibility			  = (float) atof(szTemp);
	m_bMipmaps				  = GetPrivateProfileInt("graphic", "mipmaps",					1, m_szFilename) != 0;
	m_bTextureFiltering		  = GetPrivateProfileInt("graphic", "texturefiltering",			1, m_szFilename) != 0;
	m_bTextureCompression     = GetPrivateProfileInt("graphic", "texturecompression",		1, m_szFilename) != 0;
	m_iTextureCompressionMode = GetPrivateProfileInt("graphic", "texturecompressionmode",	1, m_szFilename);
	GetPrivateProfileString("graphic", "texturequality", "1", szTemp, 256, m_szFilename);
	m_fTextureQuality		  = (float) atof(szTemp);
	m_bSmoothLines			  = GetPrivateProfileInt("graphic", "smoothlines",				0, m_szFilename) != 0;
	m_bComicStyle			  = GetPrivateProfileInt("graphic", "comicstyle",				1, m_szFilename) != 0;
	m_bComicSilhouettes		  = GetPrivateProfileInt("graphic", "comicsilhouettes",			1, m_szFilename) != 0;
	GetPrivateProfileString("graphic", "comicsilhouetteswidth", "3", szTemp, 256, m_szFilename);
	m_fComicSilhouettesWidth  = (float) atof(szTemp);
	m_bComicCelShading		  = GetPrivateProfileInt("graphic", "comiccelshading",			1, m_szFilename) != 0;

	// Sound
	m_iSoundOutputDriver = GetPrivateProfileInt("sound", "outputdriver",		   	FSOUND_OUTPUT_DSOUND, m_szFilename);
	m_iSoundDriver	     = GetPrivateProfileInt("sound", "driver",			     				 	   0, m_szFilename);
	m_iSoundMixingDriver = GetPrivateProfileInt("sound", "mixingdriver", FSOUND_MIXER_QUALITY_AUTODETECT, m_szFilename);
	m_iSoundOutputRate   = GetPrivateProfileInt("sound", "outputrate",							   44100, m_szFilename);
	m_iSoundChannels	 = GetPrivateProfileInt("sound", "channels",								  64, m_szFilename);
	m_bSound		     = GetPrivateProfileInt("sound", "sound",									   1, m_szFilename) != 0;
	GetPrivateProfileString("sound", "soundvolume", "1", szTemp, 256, m_szFilename);
	m_fSoundVolume = (float) atof(szTemp);
	m_bMusic		     = GetPrivateProfileInt("sound", "music",									   1, m_szFilename) != 0;
	GetPrivateProfileString("sound", "musicvolume", "1", szTemp, 256, m_szFilename);
	m_fMusicVolume = (float) atof(szTemp);

	// Input
	GetPrivateProfileString("input", "mousesensibility", "1", szTemp, 256, m_szFilename);
	m_fMouseSensibility = (float) atof(szTemp);
	m_bInvertMouseYAxe	= GetPrivateProfileInt("input", "invertmouseyaxe", 0, m_szFilename) != 0;

	// Directories
	GetPrivateProfileString("directories", "languages",   "data\\languages",   _AS::CFileSystem.m_szLanguagesDirectory,   256, m_szFilename);
	GetPrivateProfileString("directories", "textures",	  "data\\textures",    _AS::CFileSystem.m_szTexturesDirectory,    256, m_szFilename);
	GetPrivateProfileString("directories", "models",	  "data\\models",      _AS::CFileSystem.m_szModelsDirectory,      256, m_szFilename);
	GetPrivateProfileString("directories", "sounds",	  "data\\sounds",      _AS::CFileSystem.m_szSoundsDirectory,      256, m_szFilename);
	GetPrivateProfileString("directories", "music",		  "data\\music",       _AS::CFileSystem.m_szMusicDirectory,       256, m_szFilename);
	GetPrivateProfileString("directories", "screenshots", "data\\screenshots", _AS::CFileSystem.m_szScreenshotsDirectory, 256, m_szFilename);
	
	// Files
	GetPrivateProfileString("files", "preload", "data\\preload.ini", _AS::CFileSystem.m_szPreloadFile, 256, m_szFilename);
	_AS::CFileSystem.GetFullFilename(_AS::CFileSystem.m_szPreloadFile, ASCONFIG_FILE);

	m_bLoaded = true;
	Check();

	return false;
}

/*
	Save engine configuration
*/
bool ASTConfig::Save(const char* pszFilename)
{
	char szFilename[256];

	// Check pointer
	if (!pszFilename) return true;

	// Setup filename information
	strcpy(m_szFilename, pszFilename);
	strcpy(szFilename, pszFilename);
	_AS::CFileSystem.GetFullFilename(szFilename, ASCONFIG_FILE);

	// Save the configurations
	WritePrivateProfileString("general", "last_crashed", "0", szFilename);
	WritePrivateProfileString("general", "firstrun",	 "0", szFilename);
	_AS::CFileSystem.WritePrivateProfileEString("general", "showfps", szFilename, "%d", m_bShowFPS);
	WritePrivateProfileString("general", "language", m_szLanguageName, szFilename);

	// Debug
	if (m_bDebugMode) {
		_AS::CFileSystem.WritePrivateProfileEString("debug", "showcoordinateaxes", szFilename, "%d", m_bShowCoordinateAxes);
		_AS::CFileSystem.WritePrivateProfileEString("debug", "showtriangles",	   szFilename, "%d", m_bShowTriangles);
		_AS::CFileSystem.WritePrivateProfileEString("debug", "showboundingboxes",  szFilename, "%d", m_bShowBoundingBoxes);
		_AS::CFileSystem.WritePrivateProfileEString("debug", "wireframemode",	   szFilename, "%d", m_bWireframeMode);
		_AS::CFileSystem.WritePrivateProfileEString("debug", "pointmode",		   szFilename, "%d", m_bPointMode);
	}

	// Save display mode information
	_AS::CFileSystem.WritePrivateProfileEString("displaymode", "fullscreen", szFilename, "%d", m_bFullscreen);
	_AS::CFileSystem.WritePrivateProfileEString("displaymode", "width",	     szFilename, "%d", GetDisplayWidth());
	_AS::CFileSystem.WritePrivateProfileEString("displaymode", "height",	 szFilename, "%d", GetDisplayHeight());
	_AS::CFileSystem.WritePrivateProfileEString("displaymode", "colorbits",  szFilename, "%d", GetDisplayColorBits());
	_AS::CFileSystem.WritePrivateProfileEString("displaymode", "frequency",  szFilename, "%d", GetDisplayFrequency());

	// Graphic
	_AS::CFileSystem.WritePrivateProfileEString("graphic", "useextensions",			 szFilename, "%d",   m_bUseExtensions);
	_AS::CFileSystem.WritePrivateProfileEString("graphic", "zbufferbits",			 szFilename, "%d",   m_iZBufferBits);
	_AS::CFileSystem.WritePrivateProfileEString("graphic", "lightingmode",			 szFilename, "%d",   m_iLightingMode);
	_AS::CFileSystem.WritePrivateProfileEString("graphic", "highrenderquality",		 szFilename, "%d",   m_bHighRenderQuality);
	_AS::CFileSystem.WritePrivateProfileEString("graphic", "lightmaps",				 szFilename, "%d",   m_bLightmaps);
	_AS::CFileSystem.WritePrivateProfileEString("graphic", "shadowmaps",			 szFilename, "%d",   m_bShadowmaps);
	_AS::CFileSystem.WritePrivateProfileEString("graphic", "multitexturing",		 szFilename, "%d",   m_bMultitexturing);
	_AS::CFileSystem.WritePrivateProfileEString("graphic", "particles",				 szFilename, "%d",   m_bParticles);
	_AS::CFileSystem.WritePrivateProfileEString("graphic", "particledensity",		 szFilename, "%.2f", m_fParticleDensity);
	_AS::CFileSystem.WritePrivateProfileEString("graphic", "visibility",		 	 szFilename, "%.2f", m_fVisibility);
	_AS::CFileSystem.WritePrivateProfileEString("graphic", "mipmaps",				 szFilename, "%d",   m_bMipmaps);
	_AS::CFileSystem.WritePrivateProfileEString("graphic", "texturefiltering",		 szFilename, "%d",   m_bTextureFiltering);
	_AS::CFileSystem.WritePrivateProfileEString("graphic", "texturecompression",	 szFilename, "%d",   m_bTextureCompression);
	_AS::CFileSystem.WritePrivateProfileEString("graphic", "texturequality",		 szFilename, "%.2f", m_fTextureQuality);
	_AS::CFileSystem.WritePrivateProfileEString("graphic", "smoothlines",			 szFilename, "%d",   m_bSmoothLines);
	_AS::CFileSystem.WritePrivateProfileEString("graphic", "comicstyle",			 szFilename, "%d",   m_bComicStyle);
	if (m_bComicStyle) {
		_AS::CFileSystem.WritePrivateProfileEString("graphic", "comicsilhouettes",		szFilename, "%d",   m_bComicSilhouettes);
		_AS::CFileSystem.WritePrivateProfileEString("graphic", "comicsilhouetteswidth",	szFilename, "%.2f", m_fComicSilhouettesWidth);
		_AS::CFileSystem.WritePrivateProfileEString("graphic", "comiccelshading",		szFilename, "%d",   m_bComicCelShading);
	}

	// Sound
	_AS::CFileSystem.WritePrivateProfileEString("sound", "outputdriver", szFilename, "%d",   m_iSoundOutputDriver);
	_AS::CFileSystem.WritePrivateProfileEString("sound", "driver",		 szFilename, "%d",   m_iSoundDriver);
	_AS::CFileSystem.WritePrivateProfileEString("sound", "mixingdriver", szFilename, "%d",   m_iSoundMixingDriver);
	_AS::CFileSystem.WritePrivateProfileEString("sound", "outputrate",	 szFilename, "%d",   m_iSoundOutputRate);
	_AS::CFileSystem.WritePrivateProfileEString("sound", "channels",	 szFilename, "%d",   m_iSoundChannels);
	if (!m_bNoSound) {
		_AS::CFileSystem.WritePrivateProfileEString("sound", "sound", szFilename, "%d",   m_bSound);
		_AS::CFileSystem.WritePrivateProfileEString("sound", "music", szFilename, "%d",   m_bMusic);
	}
	_AS::CFileSystem.WritePrivateProfileEString("sound", "soundvolume",  szFilename, "%.2f", m_fSoundVolume);
	_AS::CFileSystem.WritePrivateProfileEString("sound", "musicvolume",  szFilename, "%.2f", m_fMusicVolume);

	// Input
	_AS::CFileSystem.WritePrivateProfileEString("input", "mousesensibility", szFilename, "%.2f", m_fMouseSensibility);
	_AS::CFileSystem.WritePrivateProfileEString("input", "invertmouseyaxe",  szFilename, "%d",   m_bInvertMouseYAxe);

	return false;
}

/*
	Check if the configurations are valid
*/
bool ASTConfig::Check()
{
	// Set the log corresponding to the current configuration
	SetLogActivated(m_bLogActivated); 

	if (_AS::CRenderer.IsInitialized()) {
		// Check if texture compression
		if (m_iTextureCompressionMode < 0 || m_iTextureCompressionMode >= MAXTEXTURESOMPRESSIONMODES)
			m_iTextureCompressionMode = 0;
		if (!_AS::CRenderer.CExtensions.IsTextureCompressionS3tcSupported()) {
			m_bTextureCompression	  = false;
			m_iTextureCompressionMode = 0;
		}

		// Check multi-texturing
		if (!_AS::CRenderer.CExtensions.IsMultitextureSupported())
			m_bMultitexturing  = false;
	}

	if (!m_bMultitexturing)
		m_bComicCelShading = false;

	// Comic style
	if (!m_bComicStyle) {
		m_bComicSilhouettes = false;
		m_bComicCelShading  = false;
    }

	// Texture quality
	if (m_fTextureQuality < 0.f)      m_fTextureQuality = 0.f;
	else if (m_fTextureQuality > 1.f) m_fTextureQuality = 1.f;

	// Z buffer bits
	if (m_iZBufferBits !=  8 && m_iZBufferBits != 16 && m_iZBufferBits != 24 &&
		m_iZBufferBits != 32) m_iZBufferBits = 16;

	// Lighting mode
	if (m_iLightingMode < 0)	  m_iLightingMode = 0;
	else if (m_iLightingMode > 2) m_iLightingMode = 2;
	
	// Particle density
	if (m_fParticleDensity < 0.f)	   m_fParticleDensity = 0.f;
	else if (m_fParticleDensity > 1.f) m_fParticleDensity = 1.f;

	// Visibility density
	if (m_fVisibility < 0.2f)	  m_fVisibility = 0.2f;
	else if (m_fVisibility > 2.f) m_fVisibility = 2.f;

	// Silhouettes width
	if (m_fComicSilhouettesWidth < 1.f) m_fComicSilhouettesWidth = m_fComicSilhouettesWidth = 1.f;
	
	// Is the sound deactivated?
	if (m_bNoSound) {
		m_bSound = false;
		m_bMusic = false;
	}

	// Sound output driver
	if (m_iSoundOutputDriver != FSOUND_OUTPUT_DSOUND &&
		m_iSoundOutputDriver != FSOUND_OUTPUT_WINMM &&
		m_iSoundOutputDriver != FSOUND_OUTPUT_A3D)
		m_iSoundOutputDriver = FSOUND_OUTPUT_DSOUND;

	// Sound device
	if (m_iSoundDriver < 0 || m_iSoundDriver >= FSOUND_GetNumDrivers())
		m_iSoundDriver = 0;

	// Sound mixing driver
	if (m_iSoundMixingDriver < 0 || m_iSoundMixingDriver > 5)
		m_iSoundMixingDriver = 3;

	// Sound output rate
	if (m_iSoundOutputRate != 48000 && m_iSoundOutputRate != 44100 && m_iSoundOutputRate != 22050 &&
		m_iSoundOutputRate != 11025 && m_iSoundOutputRate != 8000)
		m_iSoundOutputRate = 44100;
	
	// Sound channels
	if (m_iSoundChannels < 4)   m_iSoundChannels = 4;
	if (m_iSoundChannels > 128) m_iSoundChannels = 128;

	// Sound volume
	if (m_fSoundVolume < 0.f)	   m_fSoundVolume = 0.f;
	else if (m_fSoundVolume > 1.f) m_fSoundVolume = 1.f;

	// Music volume
	if (m_fMusicVolume < 0.f)	   m_fMusicVolume = 0.f;
	else if (m_fMusicVolume > 1.f) m_fMusicVolume = 1.f;

	// Mouse sensibility
	if (m_fMouseSensibility < 0.1f)     m_fMouseSensibility = 0.1f;
	else if (m_fMouseSensibility > 2.f) m_fMouseSensibility = 2.f;

	return false;
}

/*
	Toggle fullscreen mode
*/
bool ASTConfig::ToggleFullscreen()
{
	// Toggle fulscreen mode
	m_bFullscreen = !m_bFullscreen;

	// Rebuild the main window
	_AS::CRenderer.Restart();

	return false;
}

/*
	Functions to get the configuration states
*/
bool  ASTConfig::IsFirstRun()		   const { return m_bFirstRun; }
bool  ASTConfig::IsLastCrashed()       const { return m_bLastCrashed; }
bool  ASTConfig::IsDebugMode()		   const { return m_bDebugMode; }
bool  ASTConfig::IsNoSound()		   const { return m_bNoSound; }
bool  ASTConfig::IsLogActivated()	   const { return m_bLogActivated; }
bool  ASTConfig::IsFullscreen()		   const { return m_bFullscreen; }
bool  ASTConfig::ShowBoundingBoxes()   const { return m_bShowBoundingBoxes; }
bool  ASTConfig::UseExtensions()	   const { return m_bUseExtensions; }
int   ASTConfig::GetDisplayWidth()	   const { return m_SDisplayMode.dmPelsWidth; }
int   ASTConfig::GetDisplayHeight()	   const { return m_SDisplayMode.dmPelsHeight; }
int   ASTConfig::GetDisplayColorBits() const { return m_SDisplayMode.dmBitsPerPel; }
int   ASTConfig::GetDisplayFrequency() const { return m_SDisplayMode.dmDisplayFrequency; }
bool  ASTConfig::IsHighRenderQuality() const { return m_bHighRenderQuality; }
bool  ASTConfig::IsWireframeMode()	   const { return m_bWireframeMode;}
bool  ASTConfig::IsPointMode()		   const { return m_bPointMode; }
float ASTConfig::GetVisibility()	   const { return m_fVisibility; }
bool  ASTConfig::DrawParticles()	   const { return m_bParticles; }
float ASTConfig::GetParticleDensity()  const { return m_fParticleDensity; }
bool  ASTConfig::UseMipmaps()		   const { return m_bMipmaps; }
bool  ASTConfig::DrawShadowmaps()	   const { return m_bShadowmaps; }
bool  ASTConfig::DrawLightmaps()	   const { return m_bLightmaps; }
bool  ASTConfig::UseTextureFiltering() const { return m_bTextureFiltering; }
int   ASTConfig::GetZBufferBits()      const { return m_iZBufferBits; }
int   ASTConfig::GetLightingMode()     const { return m_iLightingMode; }

int	ASTConfig::GetTextureCompressionMode(const bool bAllow) const
{
	if (m_bTextureCompression && bAllow) return iTextureCompressionModes[m_iTextureCompressionMode];
	else return iTextureCompressionModes[0];
}

float ASTConfig::GetTextureQuality()		const { return m_fTextureQuality; }
bool  ASTConfig::IsSmoothLines()			const { return m_bSmoothLines; }
bool  ASTConfig::IsComicStyle()				const { return m_bComicStyle; }
bool  ASTConfig::IsComicSilhouettes()		const { return m_bComicSilhouettes; }
float ASTConfig::GetComicSilhouettesWidth() const { return m_fComicSilhouettesWidth; }
bool  ASTConfig::IsComicCelShading()		const { return m_bComicCelShading; }
const char* ASTConfig::GetLanguageName()	const { return m_szLanguageName; }
float ASTConfig::GetMouseSensibility()		const { return m_fMouseSensibility; }
bool  ASTConfig::InvertMouseYAxe()			const { return m_bInvertMouseYAxe; }

/*
	Functions to set the configuration states
*/
void ASTConfig::SetLogActivated(const bool bState)
{
	if (!bState && m_bLogActivated) { // Deactivate the log
		_AS::CLog.Output("Deactivate log");
		m_bLogActivated = false;
	} if (bState && !m_bLogActivated)  { // Activate the log
		m_bLogActivated = true;
		_AS::CLog.Output("Activate log");
	}
}

/*
	Returns the current display mode
*/
DEVMODE ASTConfig::GetDisplayMode() const
{
	return m_SDisplayMode;
}

/*
	Functions to set the display mode configuration states
*/
void ASTConfig::SetDisplayWidth(const int iWidth)		  { m_SDisplayMode.dmPelsWidth = iWidth; }
void ASTConfig::SetDisplayHeight(const int iHeight)		  { m_SDisplayMode.dmPelsHeight = iHeight; }
void ASTConfig::SetDisplayColorBits(const int iColorBits) { m_SDisplayMode.dmBitsPerPel = iColorBits; }
void ASTConfig::SetDisplayFrequency(const int iFrequency) { m_SDisplayMode.dmDisplayFrequency = iFrequency; }

/*
	Resets the configurations
*/
void ASTConfig::Reset()
{
	// Remove the old configuration file
	_AS::CFileSystem.RemoveFile(m_szFilename);

	// Create a new one
	m_bLoaded = false;
	Load(m_szFilename);
}

/*
	Updates all configuration relevant stuff
*/
void ASTConfig::Update()
{
	// Check if the engine configuration dialog should be opened
	if (_AS::CInput.IsKeyHit(DIK_F12)) {
		SendMessage(_AS::CWindowManager.GetMainWindow()->GetWnd(), WM_SYSCOMMAND, SC_MINIMIZE, 0);
		OpenDialog(_AS::CWindowManager.GetMainWindow()->GetWnd());
		SendMessage(_AS::CWindowManager.GetMainWindow()->GetWnd(), WM_SIZE, SIZE_RESTORED, 0);
	}
}
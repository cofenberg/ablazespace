/*
	File: ASConfig.h

	Description: Configuration stuff
*/


#ifndef __ASCONFIG_H__
#define __ASCONFIG_H__


// Predefinitions
typedef class ASTModelHandler ASTModelHandler; 
typedef class ASTSoundManager ASTSoundManager; 
typedef class ASTSoundHandler ASTSoundHandler; 


// Definitions
#define ASCONFIGFILE "asconfig"	// Name of the standard configuration file


// Classes
typedef class ASTConfig {
	
	friend _AS;
	friend ASTRenderer;
	friend ASTRendererHandler;
	friend ASTLanguageManager;
	friend ASTModelHandler;
	friend ASTWindow;
	friend ASTSoundManager;
	friend ASTSoundHandler;
	friend ASTRendererExtensions;


	public:
		/*
			Constructor
		*/
		AS_API ASTConfig();

		/*
			Initialize the configuration

			Returns:
				bool -> 'false' if all went fine else 'true'

			Notes:
				- Loads automatically the standard config file 'asconfig.ini' 
		*/
		AS_API bool Init();

		/*
			Load engine configuration

			Parameters:
				char* pszFilename -> Filename of the configuration file

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Load(const char* pszFilename);

		/*
			Save engine configuration

			Parameters:
				char* pszFilename -> Filename of the configuration file

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Save(const char* pszFilename);

		/*
			Check if the configurations are valid

			Returns:
				bool -> 'false' if all configurations were valid else 'true'

			Notes:
				- You should check the configurations if you want to go sure that
				  all settings are valid
		*/
		AS_API bool Check();

		/*
			Toggle fullscreen mode

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool ToggleFullscreen();

		/*
			Functions to get the configuration states
		*/
		AS_API bool	 IsFirstRun() const;
		AS_API bool	 IsLastCrashed() const;
		AS_API bool	 IsDebugMode() const;
		AS_API bool	 IsNoSound() const;
		AS_API bool	 IsLogActivated() const;
		AS_API bool  IsFullscreen() const;
		AS_API bool  ShowBoundingBoxes() const;
		AS_API bool  UseExtensions() const;
		AS_API int   GetDisplayWidth() const;
		AS_API int   GetDisplayHeight() const;
		AS_API int   GetDisplayColorBits() const;
		AS_API int   GetDisplayFrequency() const;
		AS_API bool  IsHighRenderQuality() const;
		AS_API bool  IsWireframeMode() const;
		AS_API bool  IsPointMode() const;
		AS_API float GetVisibility() const;
		AS_API bool  DrawParticles() const;
		AS_API float GetParticleDensity() const;
		AS_API bool  UseMipmaps() const;
		AS_API bool  DrawShadowmaps() const;
		AS_API bool  DrawLightmaps() const;
		AS_API bool  UseTextureFiltering() const;
		AS_API int   GetZBufferBits() const;
		AS_API int   GetLightingMode() const;
		AS_API int	 GetTextureCompressionMode(const bool bAllow = true) const;
		AS_API float GetTextureQuality() const;
		AS_API bool  IsSmoothLines() const;
		AS_API bool  IsComicStyle() const;
		AS_API bool  IsComicSilhouettes() const;
		AS_API float GetComicSilhouettesWidth() const;
		AS_API bool  IsComicCelShading() const;
		AS_API const char* GetLanguageName() const;
		AS_API float GetMouseSensibility() const;
		AS_API bool  InvertMouseYAxe() const;

		/*
			Functions to set the configuration states
		*/
		AS_API void SetLogActivated(const bool bState = true);

		/*
			Returns the current display mode

			Returns:
				DEVMODE -> Current display mode
		*/
		AS_API DEVMODE GetDisplayMode() const;

		/*
			Opens the configuration dialog
		
			Parameters:
				HWND hWnd -> Owner window

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool OpenDialog(const HWND hWnd = NULL);

		/*
			Opens the credits dialog
		
			Parameters:
				HWND hWnd -> Owner window

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool OpenCreditsDialog(const HWND hWnd = NULL);


	private:
		char	m_szFilename[256];		// Configuration filename
		bool	m_bLoaded;				// Is a configuration already loaded?

		// Display mode
		bool	 m_bFullscreen;		// Are we in full screen mode?
		DEVMODE	 m_SDisplayMode;	// Information about the current display mode
		DEVMODE* m_pSDisplayMode;	// A pointer to the display mode in the renderer display mode list

		// General
		bool m_bFirstRun;			// Is this the first application start?
		bool m_bLastCrashed;		// Did the application crashed last time?
		bool m_bLogActivated;		// Should the log be activated?
		bool m_bDebugMode;			// Are we in debug mode?
		bool m_bNoSound;			// Should the sound be deactivated?
		bool m_bShowFPS;			// Should the FPS be shown?
		char m_szLanguageName[256];	// The name of the current selected language

		// Debug
		bool m_bShowCoordinateAxes;	// Should the coordinate axes be shown?
		bool m_bShowTriangles;		// Should the number of triangles be shown?
		bool m_bShowBoundingBoxes;	// Should the bounding boxes be shown?
		bool m_bWireframeMode;		// Are we in wireframe rendering mode?
		bool m_bPointMode;			// Are we in point rendering mode?

		// Graphic
		bool  m_bUseExtensions;				// Should the hardware supported extensions be used?
		int	  m_iZBufferBits;				// The depth buffer bits
		int	  m_iLightingMode;				// The lighting mode
		bool  m_bHighRenderQuality;			// Should we use a high render quality?
		bool  m_bLightmaps;					// Should lightmaps be used?
		bool  m_bShadowmaps;				// Should shadowmaps be used?
		bool  m_bMultitexturing;			// Should multitexturing be used?
		bool  m_bParticles;					// Should particles be drawn?
		float m_fParticleDensity;			// The particle density
		float m_fVisibility;				// Visibility
		bool  m_bMipmaps;					// Should mipmaps be used?
		bool  m_bTextureFiltering;			// Should texture filtering be activated?
		bool  m_bTextureCompression;		// Should texture compression be used?
		int   m_iTextureCompressionMode;	// The used texture compression mode
		float m_fTextureQuality;			// Texture quality (resolution)
		bool  m_bSmoothLines;				// Should lines be smooth?
		bool  m_bComicStyle;				// Is comic style enables?
		bool  m_bComicSilhouettes;			// Should silhouettes be drawn?
		float m_fComicSilhouettesWidth;		// The width of the silhouettes
		bool  m_bComicCelShading;			// Should the cel shading be activated?

		// Sound
		int	  m_iSoundOutputDriver;	// Sound output driver
		int   m_iSoundDriver;		// Sound driver
		int   m_iSoundMixingDriver;	// Sound mixing driver
		int	  m_iSoundOutputRate;	// Sound output rate
		int   m_iSoundChannels;		// Number of maximum sound channels
		bool  m_bSound;				// Is the sound activated?
		float m_fSoundVolume;		// Sound volume
		bool  m_bMusic;				// Is the music activated?
		float m_fMusicVolume;		// Music volume

		// Input
		float m_fMouseSensibility;	// Mouse sensibility
		bool  m_bInvertMouseYAxe;	// Invert mouse y axe


		/*
			Functions to set the display mode configuration states
		*/
		void SetDisplayWidth(const int iWidth);
		void SetDisplayHeight(const int iHeight);
		void SetDisplayColorBits(const int iColorBits);
		void SetDisplayFrequency(const int iFrequency);

		/*
			Resets the configurations
		*/
		void Reset();

		/*
			The text update function
		*/
		static void ProcTextUpdate();

		/*
			Main configuration procedure
		*/
		static LRESULT CALLBACK ConfigProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);
		LRESULT Proc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);

		/*
			General task procedure
		*/
		static LRESULT CALLBACK ConfigGeneralProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);
		LRESULT GeneralProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);

		/*
			Graphic task procedure
		*/
		static LRESULT CALLBACK ConfigGraphicProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);
		LRESULT GraphicProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);

		/*
			Sound task procedure
		*/
		static LRESULT CALLBACK ConfigSoundProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);
		LRESULT SoundProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);

		/*
			Control task procedure
		*/
		static LRESULT CALLBACK ConfigControlProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);
		LRESULT ControlProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);

		/*
			Debug task procedure
		*/
		static LRESULT CALLBACK ConfigDebugProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);
		LRESULT DebugProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);

		/*
			OpenGL information procedure
		*/
		static LRESULT CALLBACK OpenGLInformationProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);

		/*
			Credits procedure
		*/
		static LRESULT CALLBACK CreditsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);

		/*
			Updates all configuration relevant stuff
		*/
		void Update();


} ASTConfig;


#endif // __ASCONFIG_H__
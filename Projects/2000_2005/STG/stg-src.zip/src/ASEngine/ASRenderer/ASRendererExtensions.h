/*
	File: ASRendererExtensions.h

	Description: Supported graphic card extensions

	Notes:
		- You must check if the extension is supported by the current hardware before
		  you use it. If the extension isn't available you should offer an alternativ
		  technique
*/


#ifndef __ASRENDEREREXTENSIONS_H__
#define __ASRENDEREREXTENSIONS_H__


/////////////////////////////////////////////////////////////////////////////////////////
// Extensions
/////////////////////////////////////////////////////////////////////////////////////////

// Multitexture
extern AS_API PFNGLMULTITEXCOORD2FARBPROC		glMultiTexCoord2fARB;
extern AS_API PFNGLACTIVETEXTUREARBPROC			glActiveTextureARB;
extern AS_API PFNGLCLIENTACTIVETEXTUREARBPROC	glClientActiveTextureARB;

// Vertex array
extern AS_API PFNWGLALLOCATEMEMORYNVPROC		wglAllocateMemoryNV;
extern AS_API PFNWGLFREEMEMORYNVPROC			wglFreeMemoryNV;
extern AS_API PFNGLVERTEXARRAYRANGENVPROC		glVertexArrayRangeNV;
extern AS_API PFNGLFLUSHVERTEXARRAYRANGENVPROC  glFlushVertexArrayRangeNV;

// Compiled array vertex
extern AS_API PFNGLLOCKARRAYSEXTPROC			glLockArraysEXT;
extern AS_API PFNGLUNLOCKARRAYSEXTPROC			glUnlockArraysEXT;

// Fog coordinates
extern AS_API PFNGLFOGCOORDFEXTPROC				glFogCoordfEXT;

// Texture compression definitions
#define COMPRESSED_RGB_S3TC_DXT1_EXT	0x83F0
#define COMPRESSED_RGBA_S3TC_DXT1_EXT	0x83F1
#define COMPRESSED_RGBA_S3TC_DXT3_EXT	0x83F2
#define COMPRESSED_RGBA_S3TC_DXT5_EXT	0x83F3
/////////////////////////////////////////////////////////////////////////////////////////


// Classes
typedef class ASTRendererExtensions {

	friend ASTRenderer;


	public:
		/*
			Returns if extension 'GL_ARB_multitexture' supported by the hardware

			Returns:
				bool -> 'true' if the extension is supported else 'false'
		*/
		AS_API bool IsMultitextureSupported() const;

		/*
			Returns if extension 'NV_vertex_array_range' supported by the hardware

			Returns:
				bool -> 'true' if the extension is supported else 'false'

		*/
		AS_API bool IsVertexArraySupported() const;

		/*
			Returns if extension 'GL_EXT_compiled_vertex_array' supported by the hardware

			Returns:
				bool -> 'true' if the extension is supported else 'false'
		*/
		AS_API bool IsCompiledVertexArraySupported() const;

		/*
			Returns if extension 'GL_EXT_fog_coord' supported by the hardware

			Returns:
				bool -> 'true' if the extension is supported else 'false'
		*/
		AS_API bool IsFogCoordSupported() const;

		/*
			Returns if extension 'GL_EXT_texture_compression_s3tc' supported by the hardware

			Returns:
				bool -> 'true' if the extension is supported else 'false'
		*/
		AS_API bool IsTextureCompressionS3tcSupported() const;


	private:
		bool m_bMultitextureSupported;				// Is extension 'GL_ARB_multitexture' supported by the hardware?
		bool m_bVertexArraySupported;				// Is extension 'NV_vertex_array_range' supported by the hardware?
		bool m_bCompiledVertexArraySupported;		// Is extension 'GL_EXT_compiled_vertex_array' supported by the hardware?
		bool m_bFogCoordSupported;					// Is extension 'GL_EXT_fog_coord' supported by the hardware?
		bool m_bTextureCompressionS3tcSupported;	// Is extension 'GL_EXT_texture_compression_s3tc' supported by the hardware?


		/*
			Initialize the supported extensions

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Init();

		/*
			Checks whether an extension is supported by the given hardware or not

			Parameters:
				char* pszExtension -> Name of the extension

			Returns:
				bool -> 'true' if the extensions is supported else 'false'
		*/
		bool IsSupported(const char* pszExtension) const;


} ASTRendererExtensions;


#endif // __ASRENDEREREXTENSIONS_H__
/*
	File: ASFont.cpp
*/

#include <ASEngineDll.h>


/*
	Constructor
*/
ASTFont::ASTFont()
{
	m_bInitialized = false;
	m_iList		   = 0;
	m_fSize		   = 1.f;
	m_bDistortion  = false;
}

/*
	Destructor
*/
ASTFont::~ASTFont()
{
	DeInit();
}

/*
	Initializes the font
*/
bool ASTFont::Init(const char* pszFilename)
{
	float fX, fY, fXSize, fYSize;
	char szFilename[256];

	DeInit();
	_AS::CLog.Output("Initialize font");

	// Setup filename
	if (!pszFilename) sprintf(szFilename, "%s\\"ASSTANDARDFONT, _AS::CFileSystem.GetTexturesDirectory());
	else			  strcpy(szFilename, pszFilename);
	
	// Generate font lists
	m_iList = glGenLists(256);

	// Create a font from a texture
	if (m_CTexture.Load(szFilename)) return true;
	if (!pszFilename) m_CTexture.GetTexture()->SetProtected(true);
	m_CTexture.GetTexture()->BindOpenGLTexture();
	fXSize = (float) 16 / m_CTexture.GetTexture()->GetWidth()  * 2;
	fYSize = (float) 16 / m_CTexture.GetTexture()->GetHeight() * 2;

	// Build the font lists
	for (int i = 0; i < 256; i++) {
		// Get position of current character
		fX = (float) (i % 16) / 16.f;
		fY = (float) 1 - (i / 16) / 16.f;

		glNewList(m_iList + i, GL_COMPILE);
			glBegin(GL_QUADS);
				glTexCoord2f(fX, fY - fYSize);
				glVertex2i(0, 0);
				glTexCoord2f(fX + fXSize, fY - fYSize);
				glVertex2i(16, 0);
				glTexCoord2f(fX + fXSize, fY);
				glVertex2i(16, 16);
				glTexCoord2f(fX,  fY);
				glVertex2i(0, 16);
			glEnd();
			glTranslated(10, 0, 0);
		glEndList();
	}

	m_bInitialized = true;

	return false;
}

/*
	De-initializes the font
*/
bool ASTFont::DeInit()
{
	if (!m_bInitialized) return true;

	_AS::CLog.Output("De-initialize font");
	glDeleteLists(m_iList, 256);

	return m_CTexture.Unload();
}

/*
	Prints a text
*/
bool ASTFont::Print(const int iX, const int iY, const bool bCentered, const char* pszText) const
{
	int iXT;

	// Select font texture
	if (!pszText || !m_CTexture.IsLoaded()) return true;
	m_CTexture.GetTexture()->BindOpenGLTexture();

	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	glEnable(GL_BLEND);
	glEnable(GL_TEXTURE_2D);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	glDisable(GL_LIGHTING);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_CULL_FACE);

	// Get correct size
	float fSize = m_fSize + 0.2f;

	if (m_bDistortion) {
		float fXSize = 16 * fSize,
			  fYSize = 16 * fSize,
			  fTrans = 10 * fSize,
			  cx, cy, fVertex[4][2];
		int i, i2, x2, y2;

		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		for(i = 0; i < 4; i++)
			for(i2 = 0; i2 < 2; i2++)
				fVertex[i][i2] = m_fVertex[i][i2] * fSize;
		glDisable(GL_DEPTH_TEST);
		glMatrixMode(GL_PROJECTION);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);
		glDisable(GL_CULL_FACE);
		glPushMatrix();
		glLoadIdentity();
		glOrtho(0, 800, 0, 600, -100, 100);
		glMatrixMode(GL_MODELVIEW);
		glPushMatrix();
		glLoadIdentity();
		if(bCentered) glTranslated(iX-((float) (10.f * fSize * strlen(pszText) / 2.f)), iY, 0);
		else		  glTranslated(iX, iY, 0);
		for(i = 0; i < (signed) strlen(pszText); i++) {
			y2 = (int) ((unsigned char) pszText[i]) / 16;
			x2 = ((unsigned char) pszText[i]) - y2 * 16;
			cx = (float) (32 * x2) / m_CTexture.GetTexture()->GetWidth();
			cy = (float) (32 * y2) / m_CTexture.GetTexture()->GetHeight();
			glBegin(GL_QUADS);
				glTexCoord2f(cx, 1 - cy - 0.0625f);
				glVertex2f(fVertex[0][0], fVertex[0][1]);
				glTexCoord2f(cx + 0.0625f, 1 - cy - 0.0625f);
				glVertex2f(fXSize + fVertex[1][0], fVertex[1][1]);
				glTexCoord2f(cx + 0.0625f, 1 - cy);
				glVertex2f(fXSize + fVertex[2][0], fYSize + fVertex[2][1]);
				glTexCoord2f(cx, 1 - cy);
				glVertex2f(fVertex[3][0], fXSize + fVertex[3][1]);
			glEnd();
			glTranslatef(fTrans, 0.0f, 0.0f);
		}
	} else {
		// Center the text
		if (bCentered) iXT = iX - (int) ((float) 10 * strlen(pszText) / 2);
		else		   iXT = iX;

		glMatrixMode(GL_PROJECTION);
		glPushMatrix();
		glLoadIdentity();
		glOrtho(0, 800, 0, 600, -10, 10);
		glMatrixMode(GL_MODELVIEW);
		glPushMatrix();
		glLoadIdentity();
		glTranslated(iXT, iY, 0);
		glListBase(m_iList);
		glCallLists(strlen(pszText), GL_UNSIGNED_BYTE, pszText);
	}
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
	glPopMatrix();
	glEnable(GL_CULL_FACE);
	glEnable(GL_DEPTH_TEST);
	_AS::CRenderer.SetFillMode();
	_AS::CRenderer.AddTriangles(strlen(pszText) * 2);

	return false;
}
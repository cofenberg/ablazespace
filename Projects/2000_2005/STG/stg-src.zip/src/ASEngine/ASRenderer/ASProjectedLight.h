/*
	File: ASProjectedLight.h

	Description: Projected light source
				 Projected lights could e.g. cast an image on polygons or simply create dynamic lights
*/

#ifndef __ASPROJECTEDLIGHT_H__
#define __ASPROJECTEDLIGHT_H__


// Classes
typedef class ASTProjectedLight {

	public:
		/*
			Constructor

			Parameters:
				ASTVector3D& vPos			-> Position of the light source
				float		 fRadius		-> Light radius
				float		 fDensity		-> Light density
				ASTVector3D& vColor		    -> Color of the light
				bool		 bUseBrightness -> Should brightness be used?
		*/
		AS_API ASTProjectedLight(const ASTVector3D& vPos, const ASTVector3D vColor, const float fRadius = 1.0f, const float fDensity = 1.f,
								 const bool bUseBrightness = true);

		/*
			Draws the projected light source over a triangle
			
			Parameters:
				ASTVector3D& vV1 & vV2 & vV3 -> Triangle points

			Notes:
				- It would be faster to use a precomputed plane like other draw
				  functions use
		*/
		AS_API void DrawTriangle(const ASTVector3D& vV1, const ASTVector3D& vV2, const ASTVector3D& vV3) const;

		/*
			Draws the projected light source over a triangle
			
			Parameters:
				ASTTriangle& tTriangle -> The light triangle

			Notes:
				- The triangles plane must be computed!
		*/
		AS_API void DrawTriangle(const ASTPlane& tTriangle) const;


	private:
		ASTVector3D m_vPos;				// Position of the light source
		float		m_fRadius;			// Radius of light source
		float		m_fDensity;			// Light source density
		ASTVector3D	m_vColor;			// Light color
		bool		m_bUseBrightness;	// Should brightness be used?


} ASTProjectedLight;


#endif // __ASPROJECTEDLIGHT_H__
/*
	File: ASFont.h

	Description: Font
*/


#ifndef __ASFONT_H__
#define __ASFONT_H__


// Definitions
#define ASSTANDARDFONT "standardfont.jpg" // The standard font


// Classes
typedef class ASTFont {
	
	friend ASTRenderer;


	public:
		/*
			Constructor
		*/
		AS_API ASTFont();

		/*
			Destructor
		*/
		AS_API ~ASTFont();


	private:
		bool			  m_bInitialized;	// Is the font initialized?
		ASTTextureHandler m_CTexture;		// The used font texture
		int				  m_iList;			// Base display list for the font set

		float m_fSize;			// Font size
		bool  m_bDistortion;	// Is the font distortion activated?
		float m_fVertex[4][2];	// Vertex distortion


		/*
			Initializes the font
	
			Parameters:
				char* pszFilename -> The filename of the font texture

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Init(const char* pszFilename = NULL);

		/*
			De-initializes the font

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool DeInit();

		/*
			Prints a text

			Parameters:
				int   iX & iY   -> Position of the text
				bool  bCentered -> Should the text be centered at the given position?
				char* pszText   -> The text which should be printed

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Print(const int iX, const int iY, const bool bCentered, const char* pszText) const;


} ASTFont;


#endif // __ASFONT_H__
/*
	File: ASRendererHandler.h

	Description: Renderer handler
*/


#ifndef __ASRENDERERHANDLER_H__
#define __ASRENDERERHANDLER_H__


// Classes
typedef class ASTRendererHandler {

	friend ASTRenderer;
	friend ASTWindow;
	friend ASTLight;


	public:
		/*
			Constructor
		*/
		ASTRendererHandler();

		/*
			Destructor
		*/
		
		AS_API ~ASTRendererHandler();

		/*
			Initialize the renderer handle

			Parameters:
				HWND hWnd	    -> The window handle
				bool bShowInfos -> Should some engine information be shown?

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Init(const HWND hWnd, const bool bShowInfos = true);

		/*
			Deinitialize the renderer handle

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool DeInit();

		/*
			Returns weather the renderer handler is initialized or not

			Returns:
				bool -> 'true' if the renderer handler is initialized else 'false'
		*/
		AS_API bool IsInitialized() const;
		
		/*
			Clears the value (makes it black)
		*/
		AS_API void Clear();

		/*
			Configurates the renderer handler

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Config();

		/*
			Returns the window handle

			Returns:
				HWND -> The window handle
		*/
		AS_API HWND GetWnd() const;
		
		/*
			Returns the private GDI device context

			Returns:
				HDC -> The private GDI device context
		*/
		AS_API HDC GetDC() const;

		/*
			Sets whether the coordinate axes should be shown or not

			Parameters:
				bool bShow -> Should the coordinate axes be shown?
		*/
		AS_API void ShowCoordinateAxes(const bool bShow);

		/*
			Returns whether the coordinate axes should be shown or not

			Returns:
				bool -> 'true' if the coordinate axes are shown else 'false'
		*/
		AS_API bool ShowCoordinateAxes();

		/*
			Increase the triangle counter

			Returns:
				bool -> 'false' if all went fine else 'true'			
		*/
		AS_API bool AddTriangles(const int iTriangles);

		/*
			Initializes the szene
		*/
		void InitSzene();

		/*
			Updates the renderer handler
		*/
		void Update();


	private:
		HWND					m_hWnd;					// Window handler the renderer handler works for
		HDC						m_hDC;					// Private GDI device context
		bool					m_bShowInfos;			// Should some engine information be shown?
		bool					m_bShowCoordinateAxes;	// Should the coordinate axes be shown?

		int m_iTriangles; // The number of triangles in the current frame


} ASTRendererHandler;


#endif // __ASRENDERERHANDLER_H__
/*
	File: ASRendererExtensions.cpp
*/

#include <ASEngineDll.h>


/////////////////////////////////////////////////////////////////////////////////////////
// Extensions
/////////////////////////////////////////////////////////////////////////////////////////

// Multitexture
AS_API PFNGLMULTITEXCOORD2FARBPROC		glMultiTexCoord2fARB;
AS_API PFNGLACTIVETEXTUREARBPROC		glActiveTextureARB;
AS_API PFNGLCLIENTACTIVETEXTUREARBPROC	glClientActiveTextureARB;

// Vertex array
AS_API PFNWGLALLOCATEMEMORYNVPROC		wglAllocateMemoryNV;
AS_API PFNWGLFREEMEMORYNVPROC			wglFreeMemoryNV;
AS_API PFNGLVERTEXARRAYRANGENVPROC		glVertexArrayRangeNV;
AS_API PFNGLFLUSHVERTEXARRAYRANGENVPROC glFlushVertexArrayRangeNV;

// Compiled array vertex
AS_API PFNGLLOCKARRAYSEXTPROC			glLockArraysEXT;
AS_API PFNGLUNLOCKARRAYSEXTPROC			glUnlockArraysEXT;

// Fog coordinates
AS_API PFNGLFOGCOORDFEXTPROC			glFogCoordfEXT;
/////////////////////////////////////////////////////////////////////////////////////////

		
/*
	Returns if extension 'GL_ARB_multitexture' supported by the hardware
*/
bool ASTRendererExtensions::IsMultitextureSupported() const
{
	return m_bMultitextureSupported;
}

/*
	Returns if extension 'NV_vertex_array_range' supported by the hardware
*/
bool ASTRendererExtensions::IsVertexArraySupported() const
{
	return m_bVertexArraySupported;
}

/*
	Returns if extension 'GL_EXT_compiled_vertex_array' supported by the hardware
*/
bool ASTRendererExtensions::IsCompiledVertexArraySupported() const
{
	return m_bCompiledVertexArraySupported;
}

/*
	Returns if extension 'GL_EXT_fog_coord' supported by the hardware
*/
bool ASTRendererExtensions::IsFogCoordSupported() const
{
	return m_bFogCoordSupported;

}

/*
	Returns if extension 'GL_EXT_texture_compression_s3tc' supported by the hardware
*/
bool ASTRendererExtensions::IsTextureCompressionS3tcSupported() const
{
	return m_bTextureCompressionS3tcSupported;
}

/*
	Initialize the supported extensions
*/
bool ASTRendererExtensions::Init()
{
	// Should the extensions be used?
	if (!_AS::CConfig.UseExtensions()) {
		_AS::CLog.Output("Use no hardware supported extensions");

		return false;
	}

	{
		char szTemp[256];
	
		// Print a list af all available extensions into the log
		_AS::CLog.Output("Extensions info:");

		char* pszTemp = (char *) glGetString(GL_EXTENSIONS);
		if (!pszTemp) return true;
		while (1) {
			if (sscanf(pszTemp, "%s", szTemp) == EOF) break;
			_AS::CLog.OutputString(szTemp);
			if (!(*(pszTemp + strlen(szTemp) + 1))) break;
			pszTemp += strlen((const char*) szTemp) + 1;
		}
	}

	// Multitexture
	if (!IsSupported("GL_ARB_multitexture"))
		_AS::CLog.Output("Extension 'GL_ARB_multitexture' not found!");
	else {
		if ((GetPrivateProfileInt("extensions", "GL_ARB_multitexture", 1, _AS::CConfig.m_szFilename) != 0)) {
			glActiveTextureARB		 = (PFNGLCLIENTACTIVETEXTUREARBPROC) wglGetProcAddress("glActiveTextureARB");
			glMultiTexCoord2fARB	 = (PFNGLMULTITEXCOORD2FARBPROC) 	 wglGetProcAddress("glMultiTexCoord2fARB");
			glClientActiveTextureARB = (PFNGLACTIVETEXTUREARBPROC)	     wglGetProcAddress("glClientActiveTextureARB");
			if (!glActiveTextureARB || !glMultiTexCoord2fARB || !glClientActiveTextureARB) {
				_AS::CLog.Output("Couldn't use extension 'GL_ARB_multitexture'!");
			} else {
				m_bMultitextureSupported = true;
				_AS::CLog.Output("Use extension 'GL_ARB_multitexture'");
			}
		}
	}

	// Vertex array
	if (!IsSupported("NV_vertex_array_range"))
		_AS::CLog.Output("Extension 'NV_vertex_array_range' not found!");
	else {
		if ((GetPrivateProfileInt("extensions", "NV_vertex_array_range", 1, _AS::CConfig.m_szFilename) != 0)) {
			wglAllocateMemoryNV		  = (PFNWGLALLOCATEMEMORYNVPROC)	   wglGetProcAddress("wglAllocateMemoryNV");
			wglFreeMemoryNV			  = (PFNWGLFREEMEMORYNVPROC)		   wglGetProcAddress("wglFreeMemoryNV");
			glVertexArrayRangeNV	  = (PFNGLVERTEXARRAYRANGENVPROC)	   wglGetProcAddress("glVertexArrayRangeNV");
			glFlushVertexArrayRangeNV = (PFNGLFLUSHVERTEXARRAYRANGENVPROC) wglGetProcAddress("glFlushVertexArrayRangeNV");
			if (!wglAllocateMemoryNV || !wglFreeMemoryNV || !glVertexArrayRangeNV || !glFlushVertexArrayRangeNV)
				_AS::CLog.Output("Couldn't use extension 'NV_vertex_array_range'!");
			else {
				m_bVertexArraySupported = true;
				_AS::CLog.Output("Use extension 'NV_vertex_array_range'");
			}
		}
	}

	// Compiled vertex array
	if (!IsSupported("GL_EXT_compiled_vertex_array"))
		_AS::CLog.Output("Extension 'GL_EXT_compiled_vertex_array' not found!");
	else {
		if ((GetPrivateProfileInt("extensions", "GL_EXT_compiled_vertex_array", 1, _AS::CConfig.m_szFilename) != 0)) {
			glLockArraysEXT   = (PFNGLLOCKARRAYSEXTPROC)   wglGetProcAddress("glLockArraysEXT");
			glUnlockArraysEXT = (PFNGLUNLOCKARRAYSEXTPROC) wglGetProcAddress("glUnlockArraysEXT");
			if (!glLockArraysEXT || !glUnlockArraysEXT)
				_AS::CLog.Output("Couldn't use extension 'GL_EXT_compiled_vertex_array'!");
			else {
				m_bCompiledVertexArraySupported = true;
				_AS::CLog.Output("Use extension 'GL_EXT_compiled_vertex_array'");
			}
		}
	}

	// Fog coordinates
	if (!IsSupported("GL_EXT_fog_coord"))
		_AS::CLog.Output("Extension 'GL_EXT_fog_coord' not found!");
	else {
		if ((GetPrivateProfileInt("extensions", "GL_EXT_fog_coord", 1, _AS::CConfig.m_szFilename) != 0)) {
			glFogCoordfEXT = (PFNGLFOGCOORDFEXTPROC) wglGetProcAddress("glFogCoordfEXT");
			if (!glFogCoordfEXT)
				_AS::CLog.Output("Couldn't use extension 'GL_EXT_fog_coord'!");
			else {
				m_bFogCoordSupported = true;
				_AS::CLog.Output("Use extension 'GL_EXT_fog_coord'");
			}
		}
	}

	// Texture compression s3tc
	if (!IsSupported("GL_EXT_texture_compression_s3tc"))
		_AS::CLog.Output("Extension 'GL_EXT_texture_compression_s3tc' not found!");
	else {
		if ((GetPrivateProfileInt("extensions", "GL_EXT_texture_compression_s3tc", 1, _AS::CConfig.m_szFilename) != 0)) {
			m_bTextureCompressionS3tcSupported = true;
			_AS::CLog.Output("Use extension 'GL_EXT_texture_compression_s3tc'");
		}
	}

	return false;
}

/*
	Checks whether an extension is supported by the given hardware or not
*/
bool ASTRendererExtensions::IsSupported(const char* pszExtension) const
{
	const char* pszExtensions = NULL, *pszStart;
	char* pszWhere, *pszTerminator;

	// Extension names should not have spaces
	pszWhere = (char*) strchr(pszExtension, ' ');
	if(pszWhere || *pszExtension == '\0') return false;
	if (!(pszExtensions = (const char *) glGetString(GL_EXTENSIONS))) return false;
	
	// It takes a bit of care to be fool-proof about parsing the
	// OpenGL extensions string. Don't be fooled by sub-strings,
	// etc:
	pszStart = pszExtensions;
	while (1)  {
		pszWhere = (char*) strstr((const char *) pszStart, pszExtension);
		if (!pszWhere) break;
		pszTerminator = pszWhere + strlen(pszExtension);
		if (pszWhere == pszStart || *(pszWhere - 1) == ' ' ||
			*pszTerminator == ' ' || *pszTerminator == '\0')
			return true;
		pszStart = pszTerminator;
	}

	return false;
}
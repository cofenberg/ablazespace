/*
	File: ASProjectedLight.cpp
*/

#include <ASEngineDll.h>


/*
	Constructor
*/
ASTProjectedLight::ASTProjectedLight(const ASTVector3D& vPos, const ASTVector3D vColor, const float fRadius, const float fDensity,
									 const bool bUseBrightness)
{
	m_vPos			 = vPos;
	m_fRadius		 = fRadius;
	m_fDensity		 = fDensity;
	m_vColor		 = vColor;
	m_bUseBrightness = bUseBrightness;
}

/*
	Draws the projected light source over a triangle
*/
void ASTProjectedLight::DrawTriangle(const ASTVector3D& vV1, const ASTVector3D& vV2, const ASTVector3D& vV3) const
{
	ASTPlane tTriangle(vV1, vV2, vV3);
	DrawTriangle(tTriangle);
}

/*
	Draws the projected light source over a triangle
*/
void ASTProjectedLight::DrawTriangle(const ASTPlane& tTriangle) const
{
	float fDis, fScale;
    ASTVector3D vNearest, vVerNear, vPlaneRightScale, vPlaneUpScale;

	fDis = (float) ASAbs(tTriangle.DistanceToPlane(m_vPos)) / 2;
	if (fDis > m_fRadius * 2) return; // Too far: don't light the polygon!

	// Nearest point to plane
	m_vPos.ProjectPlane(tTriangle.vRight, tTriangle.vUp, vNearest);

//	if (((m_vPos - tTriangle.vV1).DotProduct(tTriangle.vN)) > 0.f) return;

	// Intense is dependable on distance
	fScale			 = 1.f / (m_fRadius * 2 - fDis);
	vPlaneRightScale = tTriangle.vRight * fScale;
	vPlaneUpScale    = tTriangle.vUp	* fScale;
	if (m_bUseBrightness) {
		float fBrightness = (1.f - (fDis / m_fRadius));
		glColor4f(m_vColor.fR * fBrightness, m_vColor.fG * fBrightness, m_vColor.fB * fBrightness, m_fDensity);
	} else glColor4f(m_vColor.fR, m_vColor.fG, m_vColor.fB, m_fDensity);

	// Vector from polygons vertex to nearest point
	vVerNear = tTriangle.vV1 - vNearest;
	glTexCoord2f((float) ASDotProduct(vVerNear.fV, vPlaneRightScale.fV) + 0.5f,
				 (float) ASDotProduct(vVerNear.fV, vPlaneUpScale.fV)    + 0.5f);
	glVertex3fv(tTriangle.vV1.fV);

	vVerNear = tTriangle.vV2 - vNearest;
	glTexCoord2f((float) ASDotProduct(vVerNear.fV, vPlaneRightScale.fV) + 0.5f,
				 (float) ASDotProduct(vVerNear.fV, vPlaneUpScale.fV)    + 0.5f);
	glVertex3fv(tTriangle.vV2.fV);

	vVerNear = tTriangle.vV3 - vNearest;
	glTexCoord2f((float) ASDotProduct(vVerNear.fV, vPlaneRightScale.fV) + 0.5f,
				 (float) ASDotProduct(vVerNear.fV, vPlaneUpScale.fV)    + 0.5f);
	glVertex3fv(tTriangle.vV3.fV);

	_AS::CRenderer.AddTriangles(1);
}
 /*
	File: ASRenderer.cpp
*/

#include <ASEngineDll.h>
#include "../resource.h"


// Functions
extern void ASLightRendererInit();
extern void ASLightRendererDeInit();


/*
	Constructor
*/
ASTRenderer::ASTRenderer()
{
}

/*
	Destructor
*/
ASTRenderer::~ASTRenderer()
{
	DeInit();
}

/*
	Sets the current used camera
*/
bool ASTRenderer::SetCamera(const ASTCamera* pCCamera)
{
	// Check if the camera is already selected
	if ((ASTCamera*) m_CCameraHandler.GetEntity() != pCCamera)
		m_CCameraHandler.Load((ASTEntity*) pCCamera);

	if (!m_CCameraHandler.IsLoaded()) return true;
	((ASTCamera*) m_CCameraHandler.GetEntity())->Set();

	return false;
}

/*
	Returns the current used camera
*/
ASTCamera* ASTRenderer::GetCamera()
{
	return (ASTCamera*) m_CCameraHandler.GetEntity();
}

/*
	Sets the current rendering device
*/
bool ASTRenderer::SetRenderingDevice(ASTRendererHandler* pCRendererHandler)
{
	// Check pointer
	if (!pCRendererHandler || !pCRendererHandler->GetDC() || !m_hGLRC) return true;

	// Is this renderer handler already active?
	if (m_pCRendererHandler == pCRendererHandler) return false;

	// Make the renderer current
	if (!wglMakeCurrent(pCRendererHandler->GetDC(), m_hGLRC)) return true;

	m_pCRendererHandler = pCRendererHandler;

	return false;
}

/*
	Initialize OpenGL in a given renderer handler
*/
bool ASTRenderer::InitOpenGL(ASTRendererHandler* pCRendererHandler)
{
	unsigned char szBits;
	ASTWindow* pCWindow;
	GLuint PixelFormat;
	HDC hDeskTopDC;

	// Check pointer
	if (!pCRendererHandler) return true;
	_AS::CLog.Output("Initialize OpenGL in window");

	// Check window handle
	if (!pCRendererHandler->GetWnd()) {
		_AS::CLog.Output("There is no handle for this window!");

		return true;
	}

	// Find our engine window
	pCWindow = _AS::CWindowManager.GetWindow(pCRendererHandler->GetWnd());

	// Are we in fullscreen or windowed mode?
	if (pCWindow && _AS::CConfig.IsFullscreen()) {
		_AS::CLog.Output("Go into fullscreen mode");
		szBits = _AS::CConfig.GetDisplayColorBits();
		if (ChangeDisplaySettings(&_AS::CConfig.GetDisplayMode(), CDS_FULLSCREEN) != DISP_CHANGE_SUCCESSFUL) {
			_AS::CLog.Output("ERROR! Couldn't set display mode!");

			return true;
		}
		_AS::CInput.ShowWindowsMouseCursor(false);
		if (pCWindow) pCWindow->m_bFullScreen = true;
	} else {
		_AS::CInput.ShowWindowsMouseCursor(true);
		SetCursor(LoadCursor(NULL, IDC_ARROW));
		if (pCWindow) pCWindow->m_bFullScreen = false;

		// Get destop color depth:
		hDeskTopDC = GetDC(NULL);
		szBits = GetDeviceCaps(hDeskTopDC, BITSPIXEL);
		ReleaseDC(NULL, hDeskTopDC);
	}

	static PIXELFORMATDESCRIPTOR pfd =				// Tells windows how we want things to be
	{
		sizeof(PIXELFORMATDESCRIPTOR),				// Size of this pixel format descriptor
		1,											// Version number
		PFD_DRAW_TO_WINDOW |						// Format must support window
		PFD_SUPPORT_OPENGL |						// Format must support OpenGL
		PFD_DOUBLEBUFFER,							// Must support double buffering
		PFD_TYPE_RGBA,								// Request an RGBA format
		(UCHAR) szBits,								// Select our color depth
		0, 0, 0, 0, 0, 0,							// Color bits ignored
		0,											// No alpha buffer
		0,											// Shift bit ignored
		0,											// No accumulation buffer
		0, 0, 0, 0,									// Accumulation bits ignored
		_AS::CConfig.GetZBufferBits(),				// Z-buffer (depth buffer)  
		0,											// No stencil buffer
		0,											// No auxiliary buffer
		PFD_MAIN_PLANE,								// Main drawing layer
		0,											// Reserved
		0, 0, 0										// Layer masks ignored
	};

	_AS::CLog.Output("Create a OpenGL device context");
	if (!(pCRendererHandler->m_hDC = GetDC(pCRendererHandler->GetWnd()))) { // Did we get a device context?
		_AS::CLog.Output("Can't create a OpenGL device context");
		DeInitOpenGL(pCRendererHandler);

		return true;
	}

	_AS::CLog.Output("Search for a suitable pixel format");
	if (!(PixelFormat = ChoosePixelFormat(pCRendererHandler->m_hDC, &pfd))) { // Did windows find a matching pixel format?
		_AS::CLog.Output("Can't find a suitable pixel format");
		DeInitOpenGL(pCRendererHandler);

		return true;
	}

	_AS::CLog.Output("Set the pixel format");
	if (!SetPixelFormat(pCRendererHandler->m_hDC, PixelFormat, &pfd)) { // Are we able to set the pixel format?
		_AS::CLog.Output("Can't set the pixel format");
		DeInitOpenGL(pCRendererHandler);

		return true;
	}

	// Is this our engines main window?
	if (_AS::CWindowManager.IsMainWindow(pCRendererHandler->GetWnd()) && !m_hGLRC) {
		_AS::CLog.Output("Create a OpenGL rendering context");
		m_pCurrentTexture = NULL;
		if (!(m_hGLRC = wglCreateContext(pCRendererHandler->m_hDC))) { // Are we able to get a rendering context?
			_AS::CLog.Output("Can't create a OpenGL rendering context");
			DeInitOpenGL(pCRendererHandler);

			return true;
		}
	}

	// Configurate OpenGL in the given window
	ConfigOpenGL(pCRendererHandler);

	_AS::CLog.Output("OpenGL initialization complete");

	// Initialize the font
	if (_AS::CWindowManager.IsMainWindow(pCRendererHandler->GetWnd())) {
		m_CFont.Init();

		// Generate all OpenGL textures
		_AS::CTextureManager.GenerateOpenGLTextures();

		{ // Call the custom initialize functions
			ASTLinkedListElement<void (*)()>* pSListElement;

			pSListElement = m_lstCustomInitFunction.FindFirst();
			while (pSListElement) {
				if (pSListElement->Data) pSListElement->Data();
				pSListElement = m_lstCustomInitFunction.FindNext();
			}
		}
	}

	return false;
}
		
/*
	Deinitialize OpenGL in a given renderer handler
*/
bool ASTRenderer::DeInitOpenGL(ASTRendererHandler* pCRendererHandler)
{
	// Check pointer
	if (!pCRendererHandler) return true;

	_AS::CLog.Output("Destroy OpenGL in window");
	if (!pCRendererHandler->GetWnd()) {
		_AS::CLog.Output("There is no handle for this window!");

		return true;
	}

	if (!wglMakeCurrent(NULL, NULL)) // Are we able to release the DC and RC contexts?
		_AS::CLog.Output("Release of DC and RC failed");

	// Is this our engines main window?
	if (_AS::CWindowManager.IsMainWindow(pCRendererHandler->GetWnd()) && m_hGLRC) { // Do we have a rendering context?
		{ // Call the custom de-initialize functions
			ASTLinkedListElement<void (*)()>* pSListElement;

			pSListElement = m_lstCustomDeInitFunction.FindFirst();
			while (pSListElement) {
				if (pSListElement->Data) pSListElement->Data();
				pSListElement = m_lstCustomDeInitFunction.FindNext();
			}
		}

		// Delete all OpenGL textures
		_AS::CTextureManager.DeleteOpenGLTextures();

		m_CFont.DeInit();
		if (!wglDeleteContext(m_hGLRC)) // Are we able to delete the RC?
			_AS::CLog.Output("Release rendering context failed");
		m_hGLRC = NULL;
	}

	// Release the windows DC
	if (pCRendererHandler->m_hDC && !ReleaseDC(pCRendererHandler->GetWnd(), pCRendererHandler->m_hDC)) // Are we able to release the windows DC
		_AS::CLog.Output("Release device context failed");
	pCRendererHandler->m_hDC = NULL;
	if (m_pCRendererHandler == pCRendererHandler) m_pCRendererHandler = NULL;

	if (_AS::CWindowManager.IsMainWindow(pCRendererHandler->GetWnd())) {
		// Set display settings to the saved settings
		_AS::CLog.Output("Set display mode to default");
		ChangeDisplaySettings(NULL, 0);
	}

	_AS::CLog.Output("OpenGL successful deinitialized");

	return false;
}

/*
	Configurate OpenGL in a given window
*/
bool ASTRenderer::ConfigOpenGL(ASTRendererHandler* pCRendererHandler)
{
	// Check pointer
	if (!pCRendererHandler) return true;

	// Make the new rendering device to the current
	if (SetRenderingDevice(pCRendererHandler)) return true;

	// Check the window handle
	if (!pCRendererHandler->GetWnd()) return true;

	// Get the size of the window
	RECT Rect;
	GetWindowRect(pCRendererHandler->GetWnd(), &Rect);
	int iWidth  = Rect.right  - Rect.left,
		iHeight = Rect.bottom - Rect.top;

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glViewport(0, 0, iWidth, iHeight);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.f, (GLfloat) iWidth/(GLfloat) iHeight, 0.1f, 100.0f);
	glMatrixMode(GL_MODELVIEW);
	glPolygonMode(GL_FRONT, GL_FILL);
	glPolygonMode(GL_BACK, GL_FILL);
	glClearColor(0.f, 0.f, 0.f, 1.f);
	glClearDepth(1.f);
	glClearStencil(0);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);
	glDisable(GL_DITHER);
	if (!_AS::CConfig.IsHighRenderQuality()) {
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
		glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_FASTEST);
		glHint(GL_LINE_SMOOTH_HINT, GL_FASTEST);
		glHint(GL_POINT_SMOOTH_HINT, GL_FASTEST);
		glHint(GL_POLYGON_SMOOTH_HINT, GL_FASTEST);
		glFogi(GL_FOG_MODE, GL_EXP2);
		glHint(GL_FOG, GL_FASTEST);
		glHint(GL_FOG_HINT, GL_FASTEST);
		glDisable(GL_COLOR_MATERIAL_FACE);
	} else {
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
		glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
		glHint(GL_POINT_SMOOTH_HINT, GL_NICEST);
		glHint(GL_POLYGON_SMOOTH_HINT, GL_NICEST);
		glFogi(GL_FOG_MODE, GL_EXP2);
		glHint(GL_FOG, GL_NICEST);
		glHint(GL_FOG_HINT, GL_NICEST);
		glEnable(GL_COLOR_MATERIAL);
		glEnable(GL_COLOR_MATERIAL_FACE);
	}
	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);
	switch (_AS::CConfig.GetLightingMode()) {
		case 1: glShadeModel(GL_FLAT); break;
		case 2: glShadeModel(GL_SMOOTH); break;
	}
	glColor4f(1.0f, 1.0f, 1.0f, 1.0);
	glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
	glMateriali(GL_FRONT, GL_SHININESS,128);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_POLYGON_OFFSET_FILL);
	glPolygonOffset(1.1f, 4.0f);
	GLfloat LightDiffuse[]	= { 0.0f, 0.0f, 0.0f, 1.0f }; 
	GLfloat LightAmbient[]	= { 0.0f, 0.0f, 0.0f, 1.0f };
	GLfloat LightPosition[]	= { 0.0f, 0.0f, 0.0f, 1.0f };

	glLightfv(GL_LIGHT1, GL_AMBIENT,  LightAmbient);
	glLightfv(GL_LIGHT1, GL_DIFFUSE,  LightDiffuse);
	glLightfv(GL_LIGHT1, GL_POSITION, LightPosition);
	glEnable(GL_LIGHT1);

	_AS::CRenderer.EnableGL(GL_LIGHTING);
	glEnableClientState(GL_COLOR_ARRAY);
	glEnableClientState(GL_VERTEX_ARRAY);
	DisableGL(GL_LINE_SMOOTH);
	EnableGL(GL_LINE_SMOOTH);
	glEnableClientState(GL_NORMAL_ARRAY);
	_AS::CRenderer.SetFillMode();
	float fogColor[4] = {0.8f, 0.8f, 0.8f, 1.0f};

	glEnable(GL_FOG);						// Turn on fog
	glFogi(GL_FOG_MODE, GL_LINEAR);			// Set the fog mode to LINEAR (Important)
	glFogfv(GL_FOG_COLOR, fogColor);		// Give OpenGL our fog color
	glFogf(GL_FOG_START, 0.0);				// Set the start position for the depth at 0
	glFogf(GL_FOG_END, 50.0);				// Set the end position for the detph at 50

	// Now we tell OpenGL that we are using our fog extension for per vertex
	// fog calculations.  For each vertex that needs fog applied to it we must
	// use the glFogCoordfEXT() function with a depth value passed in.
	// These flags are defined in main.h and are not apart of the normal opengl headers.
	glFogi(GL_FOG_COORDINATE_SOURCE_EXT, GL_FOG_COORDINATE_EXT);

	return false;
}

/*
	Add's a custom initialize function to the language handlers update functions list
*/	
bool ASTRenderer::AddCustomInitFunction(void (*pCustomInitFunction)())
{
	if (m_lstCustomInitFunction.Add(pCustomInitFunction)) return true;

	// Call the custum renderer initialize funtion
	if (IsInitialized()) pCustomInitFunction();

	return false;
}

/*
	Remove's a custom initialize function to the language handlers update functions list
*/	
bool ASTRenderer::RemoveCustomInitFunction(void (*pCustomInitFunction)())
{
	return m_lstCustomInitFunction.Remove(pCustomInitFunction);
}

/*
	Add's a custom de-initialize function to the language handlers update functions list
*/	
bool ASTRenderer::AddCustomDeInitFunction(void (*pCustomDeInitFunction)())
{
	return m_lstCustomDeInitFunction.Add(pCustomDeInitFunction);
}

/*
	Remove's a custom de-initialize function to the language handlers update functions list
*/	
bool ASTRenderer::RemoveCustomDeInitFunction(void (*pCustomDeInitFunction)())
{
	if (m_lstCustomDeInitFunction.Remove(pCustomDeInitFunction)) return true;

	// Call the custum renderer de-initialize funtion
	if (IsInitialized()) pCustomDeInitFunction();

	return false;
}

/*
	Enables OpenGL capabilities
*/
bool ASTRenderer::EnableGL(const int iCapability)
{
	switch (iCapability) {
		case GL_LIGHTING:
			if (!_AS::CConfig.GetLightingMode() || m_bGL_LIGHTING) return true;
			m_bGL_LIGHTING = true;
			glEnable(GL_LIGHTING);
			break;

		case GL_LINE_SMOOTH:
			if (!_AS::CConfig.IsSmoothLines() || m_bGL_LINE_SMOOTH) return true;
			m_bGL_LINE_SMOOTH = true;
			glEnable(GL_LINE_SMOOTH);
			break;
	}

	return false;
}

/*
	Disables OpenGL capabilities
*/
bool ASTRenderer::DisableGL(const int iCapability)
{
	switch (iCapability) {
		case GL_LIGHTING:
			if (!m_bGL_LIGHTING) return true;
			m_bGL_LIGHTING = false;
			glDisable(GL_LIGHTING);
			break;

		case GL_LINE_SMOOTH:
			if (!m_bGL_LINE_SMOOTH) return true;
			m_bGL_LINE_SMOOTH = false;
			glDisable(GL_LINE_SMOOTH);
			break;
	}

	return false;
}

/*
	Check if a OpenGL capability is enabled
*/
bool ASTRenderer::IsEnabledGL(const int iCapability) const
{
	switch (iCapability) {
		case GL_LIGHTING:	 if (m_bGL_LIGHTING)	return true;
		case GL_LINE_SMOOTH: if (m_bGL_LINE_SMOOTH) return true;
	}

	return false;
}

/*
	Sets the standard fill mode
*/
void ASTRenderer::SetFillMode()
{
	if (_AS::CConfig.IsWireframeMode()) glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	else if(_AS::CConfig.IsPointMode()) glPolygonMode(GL_FRONT_AND_BACK, GL_POINT);
	else glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
}

/*
	Restarts the renderer
*/
bool ASTRenderer::Restart()
{
	bool bError = false;

	// Rebuild the main window
	if (m_CWindowHandler->GetWindow()->Rebuild()) bError = true;

	return  bError;
}

/*
	Returns if the renderer is initialized or not
*/
bool ASTRenderer::IsInitialized() const
{
	if (m_hGLRC) return true;
	else return false;
}

/*
	Returns a pointer to the current renderer handler
*/
ASTRendererHandler* ASTRenderer::GetRendererHandler()
{
	return m_pCRendererHandler;
}

/*
	Increase the triangle counter of the current renderer handler
*/
bool ASTRenderer::AddTriangles(const int iTriangles) const
{
	if (!m_pCRendererHandler) return true;

	return m_pCRendererHandler->AddTriangles(iTriangles);
}

/*
	Shows a bounding box
*/
void ASTRenderer::ShowBoundingBox(ASBOUNDINGBOX& fBoundingBox) const
{
	glDisable(GL_TEXTURE_2D);
	glLineWidth(2.0f);

	// Left side:
	glBegin(GL_LINE_LOOP);
		glVertex3fv(fBoundingBox[0]);
		glVertex3f(fBoundingBox[0][X], fBoundingBox[1][Y], fBoundingBox[0][Z]);
		glVertex3f(fBoundingBox[1][X], fBoundingBox[1][Y], fBoundingBox[0][Z]);
		glVertex3f(fBoundingBox[1][X], fBoundingBox[0][Y], fBoundingBox[0][Z]);
	glEnd();

	// Right side:
	glBegin(GL_LINE_LOOP);
		glVertex3f(fBoundingBox[0][X], fBoundingBox[0][Y], fBoundingBox[1][Z]);
		glVertex3f(fBoundingBox[0][X], fBoundingBox[1][Y], fBoundingBox[1][Z]);
		glVertex3fv(fBoundingBox[1]);
		glVertex3f(fBoundingBox[1][X], fBoundingBox[0][Y], fBoundingBox[1][Z]);
	glEnd();

	// The other four lines:
	glBegin(GL_LINES);
		glVertex3fv(fBoundingBox[0]);
		glVertex3f(fBoundingBox[0][X], fBoundingBox[0][Y], fBoundingBox[1][Z]);
		glVertex3f(fBoundingBox[0][X], fBoundingBox[1][Y], fBoundingBox[0][Z]);
		glVertex3f(fBoundingBox[0][X], fBoundingBox[1][Y], fBoundingBox[1][Z]);
		glVertex3f(fBoundingBox[1][X], fBoundingBox[1][Y], fBoundingBox[0][Z]);
		glVertex3fv(fBoundingBox[1]);
		glVertex3f(fBoundingBox[1][X], fBoundingBox[0][Y], fBoundingBox[0][Z]);
		glVertex3f(fBoundingBox[1][X], fBoundingBox[0][Y], fBoundingBox[1][Z]);
	glEnd();
	glEnable(GL_TEXTURE_2D);
}

/*
	Takes a screenshot
*/
int ASTRenderer::TakeScreenshot(int iX, int iY, int iWidth, int iHeight, const char* pszFilename)
{    
	char szFilename[256];
	ASTTexture CTexture;
	RECT Rect;

	// Get the size of the window
	if (m_pCRendererHandler) GetWindowRect(m_pCRendererHandler->GetWnd(), &Rect);

	// Get correct width
	if (iWidth == -1) iWidth   = Rect.right  - Rect.left;

	// Get correct height
	if (iHeight == -1) iHeight = Rect.bottom - Rect.top;

	// Create texture
	CTexture.m_iWidth  = iWidth;
	CTexture.m_iHeight = iHeight;
	if (!(CTexture.m_pszData = new unsigned char[CTexture.m_iWidth * CTexture.m_iHeight * 3])) return true;
    
	if (!pszFilename) { // Create a valid filename
		FILE* pFile;

		for(int i = 0;; i++) {
			memset(szFilename, 0, sizeof(char) * 256);
			sprintf(szFilename, "%s\\screenshot%d.tga", _AS::CFileSystem.GetApplicationPath(), i);
			if (!(pFile = fopen(szFilename, "r"))) break;
			fclose(pFile);
		}
	}

	// Find out the type of the texture and save it
	if (_AS::CFileSystem.IsFilenameEnding(szFilename, ASPPM_FILE))
        glReadPixels(iX, iY, iWidth, iHeight, GL_RGB, GL_UNSIGNED_BYTE, CTexture.m_pszData);
	else
	if (_AS::CFileSystem.IsFilenameEnding(szFilename, ASTGA_FILE))
        glReadPixels(iX, iY, iWidth, iHeight, GL_BGR, GL_UNSIGNED_BYTE, CTexture.m_pszData);
	else {
		_AS::CLog.Output("Invalid file type! Couldn't save screenshot");

		return true;
	}

	// Save texture
	CTexture.Save(szFilename);

    return false;
}

/*
	Sets the current font
*/
void ASTRenderer::SetFont(const char* pszFilename)
{
	// Check pointer
	if (!m_pCRendererHandler) return;

	// Load font texture
	m_CFont.m_CTexture.Load(pszFilename);
}

/*
	Gets the font size
*/
float ASTRenderer::GetFontSize() const
{
	// Check pointer
	if (!m_pCRendererHandler) return 1.f;

	return m_CFont.m_fSize;
}

/*
	Sets the font size
*/
void ASTRenderer::SetFontSize(const float fSize)
{
	// Check pointer
	if (!m_pCRendererHandler) return;

	m_CFont.m_fSize = fSize;
}

/*
	Returns whether the font distortion is activated or not
*/
bool ASTRenderer::GetFontDistortion() const
{
	// Check pointer
	if (!m_pCRendererHandler) return false;

	return m_CFont.m_bDistortion;
}

/*
	Activates / deactivates font distortion
*/
void ASTRenderer::SetFontDistortion(const bool bActive)
{
	// Check pointer
	if (!m_pCRendererHandler) return;

	m_CFont.m_bDistortion = bActive;
}

/*
	Sets the font distortion
*/
void ASTRenderer::SetFontDistortion(const float fVertex[4][2])
{
	// Check pointer
	if (!m_pCRendererHandler) return;

	memcpy(&m_CFont.m_fVertex, fVertex, sizeof(float) * 4 * 2);
}

/*
	Prints a text
*/
bool ASTRenderer::Print(const int iX, const int iY, const bool bCentered, const char* pszText, ...)
{
	char szText[1000];
	va_list arg_list;

	// Check current renderer handler
	if (!m_pCRendererHandler) return true;

	// Get the text
	va_start(arg_list, pszText);
		vsprintf(szText, pszText, arg_list);
	va_end(arg_list);

	// Print the text
	m_CFont.Print(iX, iY, bCentered, szText);

	return false;
}

/*
	Prints a text
*/
bool ASTRenderer::Print(const ASTVector3D& vPos, const bool bCentered, const char* pszText, ...)
{
	double fModelViewMatrix[16], fProjectionMatrix[16], dWinX, dWinY, dWinZ;
	char szText[1000];
	va_list arg_list;
	int iViewport[4];

	// Check current renderer handler
	if (!m_pCRendererHandler) return true;

	// Is the text in the frustum?
	if (!_AS::CFrustum.IsPointIn(vPos)) return true;

	// Get the text
	va_start(arg_list, pszText);
		vsprintf(szText, pszText, arg_list);
	va_end(arg_list);

	// Get text position
	glGetDoublev( GL_MODELVIEW_MATRIX,  fModelViewMatrix);
	glGetDoublev( GL_PROJECTION_MATRIX, fProjectionMatrix);
	glGetIntegerv(GL_VIEWPORT,		    iViewport); 
	gluProject(vPos.fX, vPos.fY, vPos.fZ, fModelViewMatrix, fProjectionMatrix, iViewport, &dWinX, &dWinY, &dWinZ);

	// Print the text
	m_CFont.Print((int) dWinX, (int) dWinY, bCentered, szText);

	return false;
}

/*
	Window message function
*/
long WindowProcedure(HWND hWnd, unsigned uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg) {
        case WM_COMMAND:
            switch (LOWORD(wParam)) {
			// General
				case ID_GENERAL_QUIT: _AS::ShutDown(); break;

			// Options
				case ID_OPTIONS_CONFIG:  _AS::CConfig.OpenDialog(hWnd); break;
				case ID_OPTIONS_OPENLOG: _AS::CLog.Open(); break;

			// Help
				case ID_HELP_HELP:    _AS::CFileSystem.OpenHelp(); break;
				case ID_HELP_CREDITS: _AS::CConfig.OpenCreditsDialog(hWnd); break;
				
			// Homepages
				case ID_ABLAZESPACE_HOMEPAGE: _AS::CFileSystem.Open("http://www.ablazespace.de"); break;
			}
		break;
    }

    return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

/*
	Initialize the renderer
*/
bool ASTRenderer::Init()
{
	bool bTemp;

	_AS::CLog.Output("Initialize renderer");

	// Create a list of all available display modes
	if (QueryDisplayModes()) return true;

	// Get & set the current selected display mode
	UpdateCurrentDisplayModeInformation();

	// On initialisation the main window should stay in window mode
	bTemp = _AS::CConfig.m_bFullscreen;
	_AS::CConfig.m_bFullscreen = false;

	// Create the engine main window
	m_CWindowHandler = new ASTWindowHandler;
	m_CWindowHandler->Create(NULL, NULL, NULL, NULL,
//	m_CWindowHandler->Create(NULL, NULL, WindowProcedure, LoadMenu(GetModuleHandle(ASMODULENAME), MAKEINTRESOURCE(IDR_MENU)),
							 ASENGINE, _AS::CConfig.GetDisplayWidth(), _AS::CConfig.GetDisplayHeight(), ASMAINWINDOWCLASSNAME);
	_AS::CConfig.m_bFullscreen = bTemp;
	
	// Print out OpenGL information:
	_AS::CLog.Output("Show OpenGL information");
	_AS::CLog.Output("Version: %s",		  (const char*) glGetString(GL_VERSION));
	_AS::CLog.Output("Chip info: %s",	  (const char*) glGetString(GL_VENDOR));
	_AS::CLog.Output("Renderer info: %s", (const char*) glGetString(GL_RENDERER));

	// Initialize the supported extensions
	CExtensions.Init();

	// Print out max supported texture size
	{
		int iMaxTextureSize = 0;

		glGetIntegerv(GL_MAX_TEXTURE_SIZE, &iMaxTextureSize);
		_AS::CLog.Output("Max texture size: %dx%d", iMaxTextureSize, iMaxTextureSize);
	}

	// Check if the configuration is vaild (maybe some things are not supported...)
	_AS::CConfig.Check();

	// Add custom renderer initialization functions
	AddCustomInitFunction(ASLightRendererInit);
	AddCustomDeInitFunction(ASLightRendererDeInit);

	return false;
}

/*
	Deinitialize the renderer
*/
bool ASTRenderer::DeInit()
{
	_AS::CLog.Output("Cleanup renderer");

	// Destroy the list of all custom initialize function
	m_lstCustomInitFunction.Clear();

	// Destroy the list of all custom de-initialize function
	m_lstCustomDeInitFunction.Clear();

	if (m_CWindowHandler) {
		delete m_CWindowHandler;
		m_CWindowHandler = NULL;
	}

	return false;
}

/*
	Enumerates all available display modes
*/
bool ASTRenderer::QueryDisplayModes()
{
	char szTemp[256];
	int iDisplayMode = 0;
	DEVMODE DevMode;

	_AS::CLog.Output("Query display available modes");
	while (1) {
		if (!EnumDisplaySettings(NULL, iDisplayMode++, &DevMode)) break;

		// Give out log message
		if (!DevMode.dmDisplayFrequency)
			sprintf(szTemp, "Found: %dx%dx%d", DevMode.dmPelsWidth, DevMode.dmPelsHeight, DevMode.dmBitsPerPel);
		else
			sprintf(szTemp, "Found: %dx%dx%d %d Hz", DevMode.dmPelsWidth, DevMode.dmPelsHeight, DevMode.dmBitsPerPel, DevMode.dmDisplayFrequency);
		if (DevMode.dmPelsWidth < 640 || DevMode.dmPelsHeight < 480 || DevMode.dmBitsPerPel < 16) {
			_AS::CLog.Output("%s -> filtered", szTemp);
			continue;
		}
		_AS::CLog.Output(szTemp);

		// Add found display mode to list
		m_lstDisplayModeList.Add(DevMode);
	}

	if (m_lstDisplayModeList.IsEmpty()) {
		_AS::CLog.Output("ERROR! No available & supported display modes were found!");

		return true;
	}

	return false;
}

/*
	Use the display mode information from the configuration to find the corresponding display mode
*/
bool ASTRenderer::UpdateCurrentDisplayModeInformation()
{
	ASTDynamicLinkedListElement<DEVMODE>* pListElement;
	DEVMODE* pDevMode;

	_AS::CLog.Output("Find display mode corresponding to the configuration settings");
	pListElement = m_lstDisplayModeList.FindFirst();
	while (pListElement) {
		pDevMode = pListElement->pData;
		if (pDevMode->dmPelsWidth	     == (unsigned) _AS::CConfig.GetDisplayWidth() &&
			pDevMode->dmPelsHeight	     == (unsigned) _AS::CConfig.GetDisplayHeight() &&
			pDevMode->dmBitsPerPel		 == (unsigned) _AS::CConfig.GetDisplayColorBits() &&
			pDevMode->dmDisplayFrequency == (unsigned) _AS::CConfig.GetDisplayFrequency()) {
			// We found the correct display mode
			memcpy(&_AS::CConfig.m_SDisplayMode, pDevMode, sizeof(DEVMODE));
			_AS::CConfig.m_pSDisplayMode = pListElement->pData;
			_AS::CLog.Output("Configuration display mode was found");

			return true;
		}
		pListElement = m_lstDisplayModeList.FindNext();
	}
	
	// Use the first available display mode instead
	_AS::CLog.Output("Configuration display mode wasn't found! The first found available display mode will be used instead.");
	memcpy(&_AS::CConfig.m_SDisplayMode, m_lstDisplayModeList.FindFirst()->pData, sizeof(DEVMODE));
	_AS::CConfig.m_pSDisplayMode = m_lstDisplayModeList.FindFirst()->pData;

	return false;
}
/*
	File: ASRendererHandler.cpp
*/

#include <ASEngineDll.h>


/*
	Constructor
*/
ASTRendererHandler::ASTRendererHandler()
{
	memset(this, 0, sizeof(ASTRendererHandler));
}

/*
	Destructor
*/
ASTRendererHandler::~ASTRendererHandler()
{
	DeInit();
}

/*
	Initialize the renderer handler
*/
bool ASTRendererHandler::Init(const HWND hWnd, const bool bShowInfos)
{
	// Check window handler
	if (!hWnd || m_hWnd) return true;
		
	// Setup data
	m_hWnd		 = hWnd;
	m_bShowInfos = bShowInfos;

	// Initialize the renderer for this renderer handler
	if (_AS::CRenderer.InitOpenGL(this)) return true;

	return false;
}

/*
	Deinitialize the renderer handler
*/
bool ASTRendererHandler::DeInit()
{
	bool bResult;

	// Check whether the renderer handler is initialized or not
	if (!m_hWnd) return true;
	
	// Deinitialize the renderer for this renderer handler
	if (_AS::CRenderer.DeInitOpenGL(this)) bResult = true;
	m_hWnd = NULL;

	return bResult;
}

/*
	Returns weather the renderer handler is initialized or not
*/
bool ASTRendererHandler::IsInitialized() const
{
	if (m_hWnd) return true;
	else		return false;
}

/*
	Clears the value
*/
void ASTRendererHandler::Clear()
{
	glClearColor(0.f, 0.f, 0.f, 1.f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glFlush();
	SwapBuffers(m_hDC);
}

/*
	Configurates the renderer handler
*/
bool ASTRendererHandler::Config()
{
	if (!m_hWnd) return true;

	return _AS::CRenderer.ConfigOpenGL(this);
}

/*
	Returns the window handle
*/
HWND ASTRendererHandler::GetWnd() const
{
	return m_hWnd;
}

/*
	Returns the private GDI device context
*/
HDC ASTRendererHandler::GetDC() const
{
	return m_hDC;
}

/*
	Sets whether the coordinate axes should be shown or not
*/
void ASTRendererHandler::ShowCoordinateAxes(const bool bShow)
{
	m_bShowCoordinateAxes = bShow;
}

/*
	Returns whether the coordinate axes should be shown or not
*/
bool ASTRendererHandler::ShowCoordinateAxes()
{
	return m_bShowCoordinateAxes;
}

/*
	Increase the triangle counter
*/
bool ASTRendererHandler::AddTriangles(const int iTriangles)
{
	if (iTriangles < 1) return true;

	m_iTriangles += iTriangles;

	return false;
}

/*
	Initializes the szene
*/
void ASTRendererHandler::InitSzene()
{
	_AS::CRenderer.SetCamera(_AS::CRenderer.GetCamera());

	// Initialzie all render lights
	ASTLight* pCLight = _AS::CEntityManager.FindFirstLight();
	while (pCLight) {
		pCLight->InitRenderLight();

		// Check OpenGL light
		if (pCLight->GetFlags() & ASeLightFlagOpenGL) {
			if (pCLight->GetFlags() & ASELightFlagAmbient)
				glLightfv(GL_LIGHT0 + pCLight->m_iOpenGLID, GL_AMBIENT,  pCLight->m_fColor);
			if (pCLight->GetFlags() & ASELightFlagDiffuse)
				glLightfv(GL_LIGHT0 + pCLight->m_iOpenGLID, GL_DIFFUSE,  pCLight->m_fColor);
			glLightfv(GL_LIGHT0 + pCLight->m_iOpenGLID, GL_POSITION, pCLight->GetPos().fV);
			glEnable( GL_LIGHT0 + pCLight->m_iOpenGLID);
		}

		pCLight = _AS::CEntityManager.FindNextLight();
	}
}

/*
	Updates the renderer handler
*/
void ASTRendererHandler::Update()
{
	// Check whether the renderer handler is initialized or not
	if (!m_hWnd) return;

	if (_AS::CConfig.m_bShowCoordinateAxes || m_bShowCoordinateAxes) {
		// Draw coordinate axis
		glLineWidth(3.f);
		glDisable(GL_TEXTURE_2D);
		glBegin(GL_LINES);
			glColor3f(1.f, 0.f, 0.f);
			glVertex3f(0.f, 0.f, 0.f);
			glVertex3f(10.f, 0.f, 0.f);
			
			glColor3f(0.f, 1.f, 0.f);
			glVertex3f(0.f, 0.f, 0.f);
			glVertex3f(0.f, 10.f, 0.f);

			glColor3f(0.f, 0.f, 1.f);
			glVertex3f(0.f, 0.f, 0.f);
			glVertex3f(0.f, 0.f, 10.f);
		glEnd();

		// X
		glColor3f(1.f, 0.f, 0.f);
		_AS::CRenderer.Print(ASTVector3D(10.f, 0.f, 0.f), true, "X");

		// Y
		glColor3f(0.f, 1.f, 0.f);
		_AS::CRenderer.Print(ASTVector3D(0.f, 10.f, 0.f), true, "Y");

		// Z
		glColor3f(0.f, 0.f, 1.f);
		_AS::CRenderer.Print(ASTVector3D(0.f, 0.f, 10.f), true, "Z");
	}

	// Show some additional information
	if (m_bShowInfos) {
		glColor3f(1.f, 1.f, 1.f);
		_AS::CRenderer.SetFont();
		if (_AS::CConfig.m_bShowFPS)
			_AS::CRenderer.Print(5, 5, false, "FPS: %.2f", _AS::CTimer.GetFramesPerSecond());
		if (_AS::CConfig.m_bShowTriangles)
			_AS::CRenderer.Print(400, 5, false, "%s: %d", CText.Get(_T_Triangles), m_iTriangles);
	}

	// Finally finish the work for the current frame
	glFlush();
	SwapBuffers(m_hDC);

	// Deinitialzie all render lights
	ASTLight* pCLight = _AS::CEntityManager.FindFirstLight();
	while (pCLight) {
		pCLight->DeInitRenderLight();
		pCLight = _AS::CEntityManager.FindNextLight();
	}

	// Reset information
	m_iTriangles	 = 0;
}
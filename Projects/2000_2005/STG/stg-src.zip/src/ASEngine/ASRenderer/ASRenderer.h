/*
	File: ASRenderer.h

	Description: Renderer
*/


#ifndef __ASRENDERER_H__
#define __ASRENDERER_H__


// Predefinitions
typedef class ASTRenderer ASTRenderer;
typedef class ASTRendererHandler ASTRendererHandler;
typedef class ASTWindow ASTWindow;
typedef class ASTWindowHandler ASTWindowHandler;
typedef class ASTFont ASTFont;
typedef class ASTConfig ASTConfig; 
typedef class ASTCamera ASTCamera;


// Includes
#include "ASFrustum.h"
#include "ASFont.h"
#include "ASRendererHandler.h"
#include "ASRendererExtensions.h"
#include "ASProjectedLight.h"


// Classes
typedef class ASTRenderer {
	
	friend _AS;
	friend ASTConfig;
	friend ASTTexture;


	public:
		ASTRendererExtensions CExtensions; // Renderer intern extensions dealer


		/*
			Constructor
		*/
		AS_API ASTRenderer();

		/*
			Destructor
		*/
		AS_API ~ASTRenderer();

		/*
			Sets the current used camera

			Parameters:
				ASTCamera* pCCamera -> The camera which should be used

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool SetCamera(const ASTCamera* pCCamera = NULL);

		/*
			Returns the current used camera

			Returns:
				ASTCamera* -> Pointer to the current used camera
		*/
		AS_API ASTCamera* GetCamera();

		/*
			Sets the current rendering device

			Parameters:
				ASTRendererHandler* pCRendererHandler -> Pointer to the renderer handler

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool SetRenderingDevice(ASTRendererHandler* pCRendererHandler);

		/*
			Initialize OpenGL in a given renderer handler

			Parameters:
				ASTRendererHandler* pCRendererHandler -> Pointer to the renderer handler

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool InitOpenGL(ASTRendererHandler* pCRendererHandler);

		/*
			Deinitialize OpenGL in a given renderer handler

			Parameters:
				ASTRendererHandler* pCRendererHandler -> Pointer to the renderer handler 

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool DeInitOpenGL(ASTRendererHandler* pCRendererHandler);

		/*
			Configurate OpenGL in a given window

			Parameters:
				ASTRendererHandler* pCRendererHandler -> Pointer to the renderer handler

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool ConfigOpenGL(ASTRendererHandler* pCRendererHandler);

		/*
			Add's a custom initialize function to the renderer handlers update functions list

			Parameters:
				void (*pCustomInitFunction)() -> Custom renderer initialize function

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/	
		AS_API bool AddCustomInitFunction(void (*pCustomInitFunction)());

		/*
			Remove's a custom initialize function to the renderer handlers update functions list

			Parameters:
				void (*pCustomInitFunction)() -> Custom renderer initialize function

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/	
		AS_API bool RemoveCustomInitFunction(void (*pCustomInitFunction)());

		/*
			Add's a custom de-initialize function to the renderer handlers update functions list

			Parameters:
				void (*pCustomDeInitFunction)() -> Custom renderer de-initialize function

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/	
		AS_API bool AddCustomDeInitFunction(void (*pCustomDeInitFunction)());

		/*
			Remove's a custom de-initialize function to the renderer handlers update functions list

			Parameters:
				void (*pCustomDeInitFunction)() -> Custom renderer de-initialize function

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/	
		AS_API bool RemoveCustomDeInitFunction(void (*pCustomDeInitFunction)());

		/*
			Enables OpenGL capabilities

			Parameters
				int iCapability -> A symbolic constant indicating an OpenGL capability

			Returns:
				bool -> 'false' if all went fine else 'true'

			Notes:
				- Supported OpenGL capabilities: GL_LIGHTING, GL_LINE_SMOOTH
		*/
		AS_API bool EnableGL(const int iCapability);

		/*
			Disables OpenGL capabilities

			Parameters
				int iCapability -> A symbolic constant indicating an OpenGL capability

			Returns:
				bool -> 'false' if all went fine else 'true'

			Notes:
				- At 'EnableGL()' you will find a list of supported OpenGL capabilities
		*/
		AS_API bool DisableGL(const int iCapability);

		/*
			Check if a OpenGL capability is enabled

			Parameters
				int iCapability -> A symbolic constant indicating an OpenGL capability

			Returns:
				bool -> 'true' if the OpenGL capability is enabled else 'false'
				
			Notes:
				- At 'EnableGL()' you will find a list of supported OpenGL capabilities
		*/
		AS_API bool IsEnabledGL(const int iCapability) const;

		/*
			Sets the standard fill mode

			Notes:
				- Which rendering technique (normal, wireframe or points) should be used
				  depends on the configurations
		*/
		AS_API void SetFillMode();
		
		/*
			Restarts the renderer

			Returns:
				bool -> 'false' if all went fine else 'true'

			Notes:
				- Use this function if you toggle the fullscreen mode
		*/
		AS_API bool Restart();

		/*
			Returns if the renderer is initialized or not

			Returns:
				bool -> 'true' if the renderer is initialized else 'false'
		*/
		AS_API bool IsInitialized() const;

		/*
			Returns a pointer to the current renderer handler

			Returns:
				ASTRendererHandler* -> A pointer to the current renderer handler
		*/
		AS_API ASTRendererHandler* GetRendererHandler();

		/*
			Increase the triangle counter of the current renderer handler

			Returns:
				bool -> 'false' if all went fine else 'true'			
		*/
		AS_API bool AddTriangles(const int iTriangles) const;

		/*
			Shows a bounding box

			Parameters:
				ASBOUNDINGBOX* fBoundingBox -> Pointer to the boundinb box
		*/
		AS_API void ShowBoundingBox(ASBOUNDINGBOX& fBoundingBox) const;

		/*
			Takes a screenshot

			Parameters:
				int iX & iY & iWidth & iHeight -> Define the rectangle to capture.
				const char* pszFilename		   -> Filename

			Returns:
				bool -> 'false' if all went fine else 'true'

			Notes:
				- If iWidth or iHeight is -1 the standard values are taken
				- If pszFilename is NULL the filename will be generated automatically
		*/
		AS_API int TakeScreenshot(int iX = 0, int iY = 0, int iWidth = -1, int iHeight = -1, const char* pszFilename = NULL);


		/////////////////////////////////////////////////////////////////////////////////////////
		// Font & Text
		/////////////////////////////////////////////////////////////////////////////////////////
		/*
			Sets the current font

			Parameters:
				char* pszFilename -> Font texture filename
		*/
		AS_API void SetFont(const char* pszFilename = ASSTANDARDFONT);

		/*
			Gets the font size

			Returns:
				float -> The font size
		*/
		AS_API float GetFontSize() const;

		/*
			Sets the font size

			Paramerers:
				float fSize	-> Font size
		*/
		AS_API void SetFontSize(const float fSize = 1.f);

		/*
			Returns whether the font distortion is activated or not

			Returns:
				bool -> 'true' if the font distortion is activated else 'false'
		*/
		AS_API bool GetFontDistortion() const;
		
		/*
			Activates / deactivates font distortion

			Paramerers:
				bool bActive -> Should the font distortion be active or not?
		*/
		AS_API void SetFontDistortion(const bool bActive = false);

		/*
			Sets the font distortion

			Parameters:
				float fVertex[4][2] -> Font distortion
		*/
		AS_API void SetFontDistortion(const float fVertex[4][2]);

		/*
			Prints a text

			Parameters:
				int   iX & iY   -> Position of the text
				bool  bCentered -> Should the text be centered at the given position?
				char* pszText   -> The text which should be printed

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Print(const int iX, const int iY, const bool bCentered, const char* pszText, ...);

		/*
			Prints a text

			Parameters:
				ASTVector3D& vPos	   -> Position of the text
				bool		 bCentered -> Should the text be centered at the given position?
				char*		 pszText   -> The text which should be printed

			Returns:
				bool -> 'false' if all went fine else 'true' (maybe the text isn't in the frustum?)
		*/
		AS_API bool Print(const ASTVector3D& vPos, const bool bCentered, const char* pszText, ...);


	private:
		ASTDynamicLinkedList<DEVMODE> m_lstDisplayModeList;		// A list of all found display modes
		ASFLOAT4					  m_fFrustum[6];			// Holds the current frustum plane equations
		DEVMODE						  m_DisplayModeBackup;		// The previous display mode
		HGLRC						  m_hGLRC;					// OpenGL rendering context
		ASTWindowHandler*			  m_CWindowHandler;			// The engine main window
		ASTRendererHandler*			  m_pCRendererHandler;		// Pointer to the current renderer handler
		ASTFont						  m_CFont;					// Font
		ASTTexture*					  m_pCurrentTexture;		// The current selected texture
		ASTEntityHandler			  m_CCameraHandler;			// The camera handler holds a pointer to the current used camera

		ASTLinkedList<void (*)()> m_lstCustomInitFunction;		// The custom function which should be called if the renderer is initialized
		ASTLinkedList<void (*)()> m_lstCustomDeInitFunction;	// The custom function which should be called if the renderer is de-initialized

		// OpenGL capabilities
		bool m_bGL_LIGHTING, m_bGL_LINE_SMOOTH;


		/*
			Initialize the renderer

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Init();

		/*
			Deitialize the renderer

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool DeInit();

		/*
			Enumerates all available display modes

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool QueryDisplayModes();

		/*
			Use the display mode information from the configuration to find the corresponding display mode

			Returns:
				bool -> 'false' if a display mode corresponding to the display mode configuration information
						was found else 'true'
		*/
		bool UpdateCurrentDisplayModeInformation();


} ASTRenderer;


#endif // __ASRENDERER_H__
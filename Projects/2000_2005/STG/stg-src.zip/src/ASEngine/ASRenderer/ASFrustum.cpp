/*
	File: ASFrustumCulling.cpp

	Note: 
		The most frustum culling code was taken from Mark Morleys frustrum culling tutorial.
		His Tutorial could be found at: www.markmorley.com/opengl/frustumculling.html
*/

#include <ASEngineDll.h>


/*
	Extracts the current view frustum plane equations
*/
void ASTFrustum::Update()
{
	float fProj[16],		// For grabbing the PROJECTION matrix
		  fModl[16],		// For grabbing the MODELVIEW matrix
		  fClip[16],		// Result of concatenating PROJECTION and MODELVIEW
		  t;				// Temporary work variable
	ASFLOAT4* pfFrustum;	// Pointer to the current frustum side
	int i, i2;
	
	// Get the PROJECTION and MODELVIEW matrix
	glGetFloatv(GL_PROJECTION_MATRIX, fProj);	// Grab the current PROJECTION matrix
	glGetFloatv(GL_MODELVIEW_MATRIX,  fModl);	// Grab the current MODELVIEW matrix

	// Concatenate (multiply) the two matricies
	for (i = 0; i < 16; i += 4)
		for (i2 = 0; i2 < 4; i2++)
			fClip[i + i2] = fModl[i] * fProj[i2] + fModl[i + 1] * fProj[i2 + 4] + fModl[i + 2] * fProj[i2 + 8] + fModl[i + 3] * fProj[i2 + 12];

	// Setup new frustum
	for (i = 0, pfFrustum = &m_fFrustum[0]; i < 6; i++, pfFrustum++) {
		switch(i) {
			case 0: // Extract the RIGHT clipping plane
				(*pfFrustum)[0] = fClip[ 3] - fClip[ 0];
				(*pfFrustum)[1] = fClip[ 7] - fClip[ 4];
				(*pfFrustum)[2] = fClip[11] - fClip[ 8];
				(*pfFrustum)[3] = fClip[15] - fClip[12];
				break;
			
			case 1: // Extract the LEFT clipping plane
				(*pfFrustum)[0] = fClip[ 3] + fClip[ 0];
				(*pfFrustum)[1] = fClip[ 7] + fClip[ 4];
				(*pfFrustum)[2] = fClip[11] + fClip[ 8];
				(*pfFrustum)[3] = fClip[15] + fClip[12];
				break;

			case 2:	// Extract the BOTTOM clipping plane
				(*pfFrustum)[0] = fClip[ 3] + fClip[ 1];
				(*pfFrustum)[1] = fClip[ 7] + fClip[ 5];
				(*pfFrustum)[2] = fClip[11] + fClip[ 9];
				(*pfFrustum)[3] = fClip[15] + fClip[13];
				break;

			case 3: // Extract the TOP clipping plane
				(*pfFrustum)[0] = fClip[ 3] - fClip[ 1];
				(*pfFrustum)[1] = fClip[ 7] - fClip[ 5];
				(*pfFrustum)[2] = fClip[11] - fClip[ 9];
				(*pfFrustum)[3] = fClip[15] - fClip[13];
				break;

			case 4: // Extract the FAR clipping plane
				(*pfFrustum)[0] = fClip[ 3] - fClip[ 2];
				(*pfFrustum)[1] = fClip[ 7] - fClip[ 6];
				(*pfFrustum)[2] = fClip[11] - fClip[10];
				(*pfFrustum)[3] = fClip[15] - fClip[14];
				break;

			case 5: // Extract the NEAR clipping plane
				(*pfFrustum)[0] = fClip[ 3] + fClip[ 2];
				(*pfFrustum)[1] = fClip[ 7] + fClip[ 6];
				(*pfFrustum)[2] = fClip[11] + fClip[10];
				(*pfFrustum)[3] = fClip[15] + fClip[14];
				break;
		}
		
		// Normalize it
		t = (float) ASSqrt((*pfFrustum)[0] * (*pfFrustum)[0] + (*pfFrustum)[1] * (*pfFrustum)[1] + (*pfFrustum)[2] * (*pfFrustum)[2]);
		(*pfFrustum)[0] /= t;
		(*pfFrustum)[1] /= t;
		(*pfFrustum)[2] /= t;
		(*pfFrustum)[3] /= t;
	}
}

/*
	Test if a point is in the frustum
*/
bool ASTFrustum::IsPointIn(const ASTVector3D& vPointPos)
{
	const ASFLOAT4* pfFrustum;	// Pointer to the current frustum side
	float fX = vPointPos.GetX(),
		  fY = vPointPos.GetY(),
		  fZ = vPointPos.GetZ();
	int i;

	// Go through all the sides of the frustum
	for (i = 0, pfFrustum = &m_fFrustum[0]; i < 6; i++, pfFrustum++)
		// Calculate the plane equation and check if the point is behind a side of the frustum
		if ((*pfFrustum)[0] * fX + (*pfFrustum)[1] * fY + (*pfFrustum)[2] * fZ + (*pfFrustum)[3] <= 0) {
			return false;
	}

	// The point is inside of the frustum (In front of ALL the sides of the frustum)
	return true;
}

/*
	Test if a point is in the frustum
*/
bool ASTFrustum::IsPointIn(const float fX, const float fY, const float fZ)
{
	const ASFLOAT4* pfFrustum;	// Pointer to the current frustum side
	int i;

	// Go through all the sides of the frustum
	for (i = 0, pfFrustum = &m_fFrustum[0]; i < 6; i++, pfFrustum++)
		// Calculate the plane equation and check if the point is behind a side of the frustum
		if ((*pfFrustum)[0] * fX + (*pfFrustum)[1] * fY + (*pfFrustum)[2] * fZ + (*pfFrustum)[3] <= 0) {
			return false;
	}

	// The point is inside of the frustum (In front of ALL the sides of the frustum)
	return true;
}

/*
	Test if a sphere is in the frustum
*/
bool ASTFrustum::IsSphereIn(const ASTVector3D& vSphereOrigin, const float& fSphereRadius) const
{
	const ASFLOAT4* pfFrustum;	// Pointer to the current frustum side
	float fX = vSphereOrigin.GetX(),
		  fY = vSphereOrigin.GetY(),
		  fZ = vSphereOrigin.GetZ();
	int i;

	// Go through all the sides of the frustum
	for (i = 0, pfFrustum = &m_fFrustum[0]; i < 6; i++, pfFrustum++)
		if ((*pfFrustum)[0] * fX + (*pfFrustum)[1] * fY + (*pfFrustum)[2] * fZ + (*pfFrustum)[3] <= -fSphereRadius)
			return false;

	return true;
}

/*
	Test if a cube is in the frustum
*/
bool ASTFrustum::IsCubeIn(const ASTVector3D& vCubeOrigin, const float& fCubeSize) const
{
	const ASFLOAT4* pfFrustum;	// Pointer to the current frustum side
	float fX = vCubeOrigin.GetX(),
		  fY = vCubeOrigin.GetY(),
		  fZ = vCubeOrigin.GetZ();
	int i;
	
	// Go through all the sides of the frustum
	for (i = 0, pfFrustum = &m_fFrustum[0]; i < 6; i++, pfFrustum++) {
		if ((*pfFrustum)[0] * (fX - fCubeSize) + (*pfFrustum)[1] * (fY - fCubeSize) + (*pfFrustum)[2] * (fZ - fCubeSize) + (*pfFrustum)[3] > 0) continue;
		if ((*pfFrustum)[0] * (fX + fCubeSize) + (*pfFrustum)[1] * (fY - fCubeSize) + (*pfFrustum)[2] * (fZ - fCubeSize) + (*pfFrustum)[3] > 0) continue;
		if ((*pfFrustum)[0] * (fX - fCubeSize) + (*pfFrustum)[1] * (fY + fCubeSize) + (*pfFrustum)[2] * (fZ - fCubeSize) + (*pfFrustum)[3] > 0) continue;
		if ((*pfFrustum)[0] * (fX + fCubeSize) + (*pfFrustum)[1] * (fY + fCubeSize) + (*pfFrustum)[2] * (fZ - fCubeSize) + (*pfFrustum)[3] > 0) continue;
		if ((*pfFrustum)[0] * (fX - fCubeSize) + (*pfFrustum)[1] * (fY - fCubeSize) + (*pfFrustum)[2] * (fZ + fCubeSize) + (*pfFrustum)[3] > 0) continue;
		if ((*pfFrustum)[0] * (fX + fCubeSize) + (*pfFrustum)[1] * (fY - fCubeSize) + (*pfFrustum)[2] * (fZ + fCubeSize) + (*pfFrustum)[3] > 0) continue;
		if ((*pfFrustum)[0] * (fX - fCubeSize) + (*pfFrustum)[1] * (fY + fCubeSize) + (*pfFrustum)[2] * (fZ + fCubeSize) + (*pfFrustum)[3] > 0) continue;
		if ((*pfFrustum)[0] * (fX + fCubeSize) + (*pfFrustum)[1] * (fY + fCubeSize) + (*pfFrustum)[2] * (fZ + fCubeSize) + (*pfFrustum)[3] > 0) continue;

		return false;
	}

	return true;
}

/*
	Test if a sphere is in the frustum
*/
bool ASTFrustum::IsCubeIn(const ASFLOAT3 fCube[2]) const
{
	const ASFLOAT4* pfFrustum;	// Pointer to the current frustum side
	float fXMin = fCube[0][X],
		  fYMin = fCube[0][Y],
		  fZMin = fCube[0][Z],
		  fXMax = fCube[1][X],
		  fYMax = fCube[1][Y],
		  fZMax = fCube[1][Z];
	int i;

	// Go through all the sides of the frustum
	for (i = 0, pfFrustum = &m_fFrustum[0]; i < 6; i++, pfFrustum++)  {
		if ((*pfFrustum)[0] * fXMin + (*pfFrustum)[1] * fYMin + (*pfFrustum)[2] * fZMin + (*pfFrustum)[3] > 0) continue;
		if ((*pfFrustum)[0] * fXMax + (*pfFrustum)[1] * fYMin + (*pfFrustum)[2] * fZMin + (*pfFrustum)[3] > 0) continue;
		if ((*pfFrustum)[0] * fXMin + (*pfFrustum)[1] * fYMax + (*pfFrustum)[2] * fZMin + (*pfFrustum)[3] > 0) continue;
		if ((*pfFrustum)[0] * fXMax + (*pfFrustum)[1] * fYMax + (*pfFrustum)[2] * fZMin + (*pfFrustum)[3] > 0) continue;
		if ((*pfFrustum)[0] * fXMin + (*pfFrustum)[1] * fYMin + (*pfFrustum)[2] * fZMax + (*pfFrustum)[3] > 0) continue;
		if ((*pfFrustum)[0] * fXMax + (*pfFrustum)[1] * fYMin + (*pfFrustum)[2] * fZMax + (*pfFrustum)[3] > 0) continue;
		if ((*pfFrustum)[0] * fXMin + (*pfFrustum)[1] * fYMax + (*pfFrustum)[2] * fZMax + (*pfFrustum)[3] > 0) continue;
		if ((*pfFrustum)[0] * fXMax + (*pfFrustum)[1] * fYMax + (*pfFrustum)[2] * fZMax + (*pfFrustum)[3] > 0) continue;

		return false;
	}

	return true;
}

/*
	Test if a sphere is in the frustum
*/
bool ASTFrustum::IsCubeIn(const ASTVector3D &vCubeMinPos, const ASTVector3D &vCubeMaxPos) const
{
	const ASFLOAT4* pfFrustum;	// Pointer to the current frustum side
	float fXMin = vCubeMinPos.GetX(),
		  fYMin = vCubeMinPos.GetY(),
		  fZMin = vCubeMinPos.GetZ(),
		  fXMax = vCubeMaxPos.GetX(),
		  fYMax = vCubeMaxPos.GetY(),
		  fZMax = vCubeMaxPos.GetZ();
	int i;

	// Go through all the sides of the frustum
	for (i = 0, pfFrustum = &m_fFrustum[0]; i < 6; i++, pfFrustum++)  {
		if ((*pfFrustum)[0] * fXMin + (*pfFrustum)[1] * fYMin + (*pfFrustum)[2] * fZMin + (*pfFrustum)[3] > 0) continue;
		if ((*pfFrustum)[0] * fXMax + (*pfFrustum)[1] * fYMin + (*pfFrustum)[2] * fZMin + (*pfFrustum)[3] > 0) continue;
		if ((*pfFrustum)[0] * fXMin + (*pfFrustum)[1] * fYMax + (*pfFrustum)[2] * fZMin + (*pfFrustum)[3] > 0) continue;
		if ((*pfFrustum)[0] * fXMax + (*pfFrustum)[1] * fYMax + (*pfFrustum)[2] * fZMin + (*pfFrustum)[3] > 0) continue;
		if ((*pfFrustum)[0] * fXMin + (*pfFrustum)[1] * fYMin + (*pfFrustum)[2] * fZMax + (*pfFrustum)[3] > 0) continue;
		if ((*pfFrustum)[0] * fXMax + (*pfFrustum)[1] * fYMin + (*pfFrustum)[2] * fZMax + (*pfFrustum)[3] > 0) continue;
		if ((*pfFrustum)[0] * fXMin + (*pfFrustum)[1] * fYMax + (*pfFrustum)[2] * fZMax + (*pfFrustum)[3] > 0) continue;
		if ((*pfFrustum)[0] * fXMax + (*pfFrustum)[1] * fYMax + (*pfFrustum)[2] * fZMax + (*pfFrustum)[3] > 0) continue;

		return false;
	}

	return true;
}
/*
	File: ASFrustum.h

	Description: Frustum culling
*/


#ifndef __ASFRUSTUM_H__
#define __ASFRUSTUM_H__



// Classes
typedef class ASTFrustum {
	
	public:
		/*
			Updates the current view frustum plane equations

			Note:
				- Must be done after the camera view was changed
		*/
		AS_API void Update();
		
		/*
			Test if a point is in the frustum

			Parameters:
				float fX & fY & fZ -> Position of the point

			Returns:
				bool -> 'true' if the point is in frustum else 'false'
		*/
		AS_API bool IsPointIn(const float fX, const float fY, const float fZ);

		/*
			Test if a point is in the frustum

			Parameters:
				ASTVector3D vPointPos -> Position of the point

			Returns:
				bool -> 'true' if the point is in frustum else 'false'
		*/
		AS_API bool IsPointIn(const ASTVector3D& vPointPos);

		/*
			Test if a sphere is in the frustum
  
			Parameters:
				ASCVector3D vSphereOrigin -> Middle of the sphere
				float		fSphereRadius -> Sphere radius

			Returns:
				bool -> 'true' if the sphere is in frustum else 'false'
		*/
		AS_API bool IsSphereIn(const ASTVector3D& vSphereOrigin, const float& fSphereRadius) const;

		/*
			Test if a cube is in the frustum

			Parameters:
				ASCVector3D vCubeOrigin -> Middle of the cube
				float		fCubeSize   -> Size of the cube

			Returns:
				bool -> 'true' if the cube is in frustum else 'false'
		*/
		AS_API bool IsCubeIn(const ASTVector3D& vCubeOrigin, const float& fCubeSize) const;
		
		/*
			Test if a sphere is in the frustum

			Parameters:
				ASFLOAT3D& fCube[2] -> Cube size: min/max, x/y/z

			Returns:
				bool -> 'true' if the cube is in frustum else 'false'
		*/
		AS_API bool IsCubeIn(const ASFLOAT3 fCube[2]) const;

		/*
			Test if a sphere is in the frustum

			Parameters:
				ASCVector3D vCubeMinPos -> Minimum position of the cube
				ASCVector3D vCubeMaxPos	-> Maximum position of the cube

			Returns:
				bool -> 'true' if the cube is in frustum else 'false'
		*/
		AS_API bool IsCubeIn(const ASTVector3D& vCubeMinPos, const ASTVector3D& vCubeMaxPos) const;


	private:
		ASFLOAT4 m_fFrustum[6];	// Holds the current frustum plane equations


} ASTFrustum;


#endif // __ASFRUSTUM_H__
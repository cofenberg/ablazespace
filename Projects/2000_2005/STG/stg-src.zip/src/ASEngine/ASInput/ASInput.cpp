/*
	File: ASInput.cpp
*/

#include <ASEngineDll.h>


/*
	Constructor
*/
ASTInput::ASTInput()
{
	m_pCInputHandler = NULL;
}

/*
	Hides the windows mouse cursor
*/
void ASTInput::ShowWindowsMouseCursor(const bool bState) const
{
	if (!bState) {
		while (1) {
			if(ShowCursor(false) < 0) break;
		}
	} else {
		while (1) {
			if(ShowCursor(true) > -1) break;
		}
	}
}

/*
	Returns the ASCII code of a scancode
*/
bool ASTInput::ConvertScancodeToASCII(const DWORD dwScancode, LPWORD lpResult) const
{
	HKL Layout = GetKeyboardLayout(0);
	UCHAR szState[256];
	unsigned char szT = '0';

	if (!GetKeyboardState(szState)) return true;
	UINT vk = MapVirtualKeyEx(dwScancode, 1, Layout);
	ToAsciiEx(vk, dwScancode, szState, lpResult, 0, Layout);

	return false;
}

/*
	Sets the current input handler
*/
bool ASTInput::SetInputHandler(ASTInputHandler* pCInputHandler)
{
	if (pCInputHandler && !pCInputHandler->IsInitialized()) return true;

	m_pCInputHandler = pCInputHandler;

	return false;
}

/*
	Returns if any mouse button is pressed or not
*/
bool ASTInput::IsMouseButtonPressed() const
{
	// Check input handler
	if (!m_pCInputHandler) return false;

	return m_pCInputHandler->m_SMouse.bAButtonPressed;
}

/*
	Returns if the mouse button is pressed or not
*/
bool ASTInput::IsMouseButtonPressed(const int iButton) const
{
	// Check input handler
	if (!m_pCInputHandler) return false;

	return m_pCInputHandler->IsMouseButtonPressed(iButton);
}

/*
	Returns if any mouse button is hit the first time or not
*/
bool ASTInput::IsMouseButtonHit() const
{
	// Check input handler
	if (!m_pCInputHandler) return false;

	return m_pCInputHandler->m_SMouse.bAButtonHit;
}

/*
	Returns if the mouse button is hit the first time or not
*/
bool ASTInput::IsMouseButtonHit(const int iButton) const
{
	// Check input handler
	if (!m_pCInputHandler) return false;

	return m_pCInputHandler->m_SMouse.bButtonPressedFirst[iButton];
}

/*	
	Returns the x position of the mouse
*/
int ASTInput::GetMousePosX() const
{
	// Check input handler
	if (!m_pCInputHandler) return 0;

	return m_pCInputHandler->m_SMouse.iPos[X];
}

/*
	Returns the y position of the mouse 
*/
int ASTInput::GetMousePosY() const
{
	// Check input handler
	if (!m_pCInputHandler) return 0;

	return m_pCInputHandler->m_SMouse.iPos[Y];
}

/*	
	Returns the mouse movement delta
*/
float ASTInput::GetMouseDelta() const
{
	// Check input handler
	if (!m_pCInputHandler) return 0.f;

	if (m_pCInputHandler->m_SMouse.fDeltaX - m_pCInputHandler->m_SMouse.fDeltaY > 0.f)
		return ASSqrt(ASDotProduct(m_pCInputHandler->m_SMouse.fDeltaX, m_pCInputHandler->m_SMouse.fDeltaY));
	else
		return -ASSqrt(ASDotProduct(m_pCInputHandler->m_SMouse.fDeltaX, m_pCInputHandler->m_SMouse.fDeltaY));
}

/*	
	Returns the mouse movement delta of the x-axe
*/
float ASTInput::GetMouseDeltaX() const
{
	// Check input handler
	if (!m_pCInputHandler) return 0.f;

	return m_pCInputHandler->m_SMouse.fDeltaX;
}

/*	
	Returns the mouse movement delta of the y-axe
*/
float ASTInput::GetMouseDeltaY() const
{
	// Check input handler
	if (!m_pCInputHandler) return 0.f;

	return m_pCInputHandler->m_SMouse.fDeltaY;
}

/*
	Returns the pressed key
*/
int ASTInput::IsKeyPressed() const
{
	// Check input handler
	if (!m_pCInputHandler) return false;

	if (!m_pCInputHandler->m_bAKeyPressed) return -1;

	for (int i = 0; i < ASKEYS; i++) if (m_pCInputHandler->IsKeyPressed(i)) return i;

	return -1;
}

/*
	Returns if the key is pressed or not
*/
bool ASTInput::IsKeyPressed(const int iKey) const
{
	// Check input handler
	if (!m_pCInputHandler) return false;

	return m_pCInputHandler->IsKeyPressed(iKey);
}

/*
	Returns the hit key
*/
int ASTInput::IsKeyHit() const
{
	// Check input handler
	if (!m_pCInputHandler) return false;

	if (!m_pCInputHandler->m_bAKeyHit) return -1;

	for (int i = 0; i < ASKEYS; i++) if (m_pCInputHandler->m_bKeyPressedFirst[i]) return i;

	return -1;
}

/*
	Returns if the key is hit the first time or not
*/
bool ASTInput::IsKeyHit(const int iKey) const
{
	// Check input handler
	if (!m_pCInputHandler) return false;

	return m_pCInputHandler->m_bKeyPressedFirst[iKey];
}

/*
	Returns the name of a key
*/
bool ASTInput::GetKeyName(const int iKey, char* pszName) const
{
    DIDEVICEOBJECTINSTANCE Didoi;

	// Check input handler
	if (!m_pCInputHandler) return false;

    Didoi.dwSize = sizeof(Didoi);
	if (FAILED(m_pCInputHandler->m_pKeyboardDevice->GetObjectInfo(&Didoi, iKey, DIPH_BYOFFSET))) return true;
	strcpy(pszName, Didoi.tszName);

	return true;
}

/*
	Resets the keys etc.
*/
void ASTInput::Reset()
{
	// Check input handler
	if (!m_pCInputHandler) return;
	
	m_pCInputHandler->Reset();
}
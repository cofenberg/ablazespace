/*
	File: ASInput.h

	Description: Input management & tools
*/


#ifndef __ASINPUT_H__
#define __ASINPUT_H__


// Predefinitions
typedef class ASTInput ASTInput;


// Definitions
#define ASKEYS		   256 // Number of keys
#define ASMOUSEBUTTONS   8 // Number of mouse buttons
#define ASPRINTKEY     183 // Print key


// Includes
#include <dinput.h>

#include "ASInputHandler.h"


// Classes
typedef class ASTInput {

	friend ASTInputHandler;


	public:
		/*
			Constructor
		*/
		AS_API ASTInput();
		
		/*
			Hides the windows mouse cursor

			Parameters:
				bool bState -> Windows mouse cursor visibility state

			Notes:
				- If you use this function you could sure that the windows
				  mouse cursor has really the desired state
		*/
		AS_API void ShowWindowsMouseCursor(const bool bState = true) const;

		/*
			Returns the ASCII code of a scancode

			Parameters:
				DWORD   dwScancode -> Scancode
				LPWORD* iResult	   -> The converted ASCII code

			Returns:
				bools -> 'false' if all went fine else 'true'

			Notes:
				- You could use this function to get the letter of a key.
				  For instance: Key '65' has normally letter 'a'
		*/
		AS_API bool ConvertScancodeToASCII(const DWORD dwScancode, LPWORD lpResult) const;

		/*
			Sets the current input handler

			Parameters:
				ASTInputHandler* pCInputHandler -> Pointer to the input handler

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool SetInputHandler(ASTInputHandler* pCInputHandler = NULL);

		/*
			Returns if any mouse button is pressed or not

			Returns:
				bool -> 'true' if any mouse button is pressed else 'false'
		*/
		AS_API bool IsMouseButtonPressed() const;

		/*
			Returns if the mouse button is pressed or not

			Parameters:
				int iButton -> The mouse button which should be checked

			Returns:
				bool -> 'true' if the mouse button is pressed else 'false'
		*/
		AS_API bool IsMouseButtonPressed(const int iButton) const;

		/*
			Returns if any mouse button is hit the first time or not

			Returns:
				bool -> 'true' if any mouse button is hit the first time else 'false'
		*/
		AS_API bool IsMouseButtonHit() const;

		/*
			Returns if the mouse button is hit the first time or not

			Parameters:
				int iButton -> The mouse button which should be checked

			Returns:
				bool -> 'true' if the mouse button is hit the first time else 'false'
		*/
		AS_API bool IsMouseButtonHit(const int iButton) const;

		/*	
			Returns the x position of the mouse

			Returns:
				int -> The x position of the mouse
		*/
		AS_API int GetMousePosX() const;

		/*
			Returns the y position of the mouse

			Returns:
				int -> The y position of the mouse
		*/
		AS_API int GetMousePosY() const;

		/*	
			Returns the mouse movement delta

			Returns:
				float -> The mouse movement delta
		*/
		AS_API float GetMouseDelta() const;

		/*	
			Returns the mouse movement delta of the x-axe

			Returns:
				float -> The mouse movement delta of the x-axe
		*/
		AS_API float GetMouseDeltaX() const;

		/*	
			Returns the mouse movement delta of the y-axe

			Returns:
				float -> The mouse movement delta of the y-axe
		*/
		AS_API float GetMouseDeltaY() const;

		/*
			Returns if any key is pressed or not

			Returns:
				int -> ID of the pressed key, '-1' if no one is pressed
		*/
		AS_API int IsKeyPressed() const;

		/*
			Returns if the key is pressed or not

			Parameters:
				int iKey -> The key which should be checked

			Returns:
				bool -> 'true' if the key is pressed else 'false'
		*/
		AS_API bool IsKeyPressed(const int iKey) const;

		/*
			Returns the hit key

			Returns:
				int -> ID of the hit key, '-1' if no one is hit
		*/
		AS_API int IsKeyHit() const;

		/*
			Returns if the key is hit the first time or not

			Parameters:
				int iKey -> The key which should be checked

			Returns:
				bool -> 'true' if the key is hit the first time else 'false'
		*/
		AS_API bool IsKeyHit(const int iKey) const;

		/*
			Returns the name of a key

			Parameters:
				int	  iKey    -> The key code
				char* pszName -> Pointer to a string were the key name should be stored

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool GetKeyName(const int iKey, char* pszName) const;

		/*
			Resets the keys etc.
		*/
		AS_API void Reset();


	private:
		ASTInputHandler* m_pCInputHandler; // Pointer to the current input handler


} ASTInput;


#endif // __ASINPUT_H__
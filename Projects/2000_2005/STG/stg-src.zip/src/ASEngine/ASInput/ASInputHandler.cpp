/*
	File: ASInputHandler.cpp
*/

#include <ASEngineDll.h>


// Definations
#define MOUSE_SAMPLE_BUFFER_SIZE    16  // Arbitrary number of buffer elements
#define KEYBOARD_SAMPLE_BUFFER_SIZE  8  // Arbitrary number of buffer elements


/*
	Constructor
*/
ASTInputHandler::ASTInputHandler()
{
	memset(this, 0, sizeof(ASTInputHandler));
}

/*
	Destructor
*/
ASTInputHandler::~ASTInputHandler()
{
	DeInit();
}

/*
	Setup the mouse and keyboard input device
*/
bool ASTInputHandler::Init(const HWND hWnd, const bool bExclusive, const bool bForeground, const bool bImmediate, const bool bDisableWindowsKey)
{
    DWORD dwCoopFlags;

	// Check window handler
	if (!hWnd || m_hWnd) return true;
	
    // Cleanup any previous call first
    DeInit();
	m_hWnd = hWnd;
	_AS::CLog.Output("Initialize DirectInput 8 interface");

    if (bExclusive) dwCoopFlags = DISCL_EXCLUSIVE;
    else dwCoopFlags = DISCL_NONEXCLUSIVE;
    if (bForeground) dwCoopFlags |= DISCL_FOREGROUND;
    else dwCoopFlags |= DISCL_BACKGROUND;

    // Create a DInput object
    if (FAILED(DirectInput8Create(GetModuleHandle(NULL), DIRECTINPUT_VERSION, 
                                  IID_IDirectInput8, (void **) &m_pDirectInput, NULL))) {
		_AS::CLog.Output("Creation of DirectInput 8 device failed!");

        return true;
	}
    
    // Obtain an interface to the system mouse device
    if (FAILED(m_pDirectInput->CreateDevice(GUID_SysMouse, &m_pMouseDevice, NULL))) {
		_AS::CLog.Output("Creation of mouse device failed!");

		return true;
	}
    
    // Set the data format to "mouse format" - a predefined data format 
    //
    // A data format specifies which controls on a device we
    // are interested in, and how they should be reported.
    //
    // This tells DirectInput that we will be passing a
    // DIMOUSESTATE2 structure to IDirectInputDevice::GetDeviceState
    if (FAILED(m_pMouseDevice->SetDataFormat(&c_dfDIMouse))) {
		_AS::CLog.Output("Setting of mouse data format failed!");

		return true;
	}
    
    // Set the cooperativity level to let DirectInput know how
    // this device should interact with the system and with other
    // DirectInput applications
    if(m_pMouseDevice->SetCooperativeLevel(hWnd, dwCoopFlags) == DIERR_UNSUPPORTED && !bForeground && bExclusive) {
		_AS::CLog.Output("Setting cooperative mouse level failed!");
        DeInit();

        return S_OK;
    }

    // Set relative mode for mouse
    DIPROPDWORD dipdw;
    dipdw.diph.dwSize       = sizeof(DIPROPDWORD);
    dipdw.diph.dwHeaderSize = sizeof(DIPROPHEADER);
    dipdw.diph.dwObj        = 0;
    dipdw.diph.dwHow        = DIPH_DEVICE;
    dipdw.dwData            = DIPROPAXISMODE_ABS;
	m_pMouseDevice->SetProperty(DIPROP_AXISMODE, &dipdw.diph);

    // Disabling the windows key is only allowed only if we are in foreground nonexclusive
    if(bDisableWindowsKey && !bExclusive && bForeground) dwCoopFlags |= DISCL_NOWINKEY;

    // Obtain an interface to the system keyboard device
    if (FAILED(m_pDirectInput->CreateDevice(GUID_SysKeyboard, &m_pKeyboardDevice, NULL))) {
		_AS::CLog.Output("Creation of keyboard device failed!");

        return true;
	}
    
    // Set the data format to "keyboard format" - a predefined data format 
    //
    // A data format specifies which controls on a device we
    // are interested in, and how they should be reported.
    //
    // This tells DirectInput that we will be passing an array
    // of 256 bytes to IDirectInputDevice::GetDeviceState
    if (FAILED(m_pKeyboardDevice->SetDataFormat(&c_dfDIKeyboard))) {
		_AS::CLog.Output("Setting of keyboard data format failed!");

		return true;
	}
    
    // Set the cooperativity level to let DirectInput know how
    // this device should interact with the system and with other
    // DirectInput applications.
    if (m_pKeyboardDevice->SetCooperativeLevel(hWnd, dwCoopFlags) == DIERR_UNSUPPORTED && !bForeground && bExclusive) {
		_AS::CLog.Output("Setting cooperative keyboard level failed!");
        DeInit();

        return true;
    }

    if (!bImmediate) {
        // IMPORTANT STEP TO USE BUFFERED DEVICE DATA!
        //
        // DirectInput uses unbuffered I/O (buffer size = 0) by default.
        // If you want to read buffered data, you need to set a nonzero
        // buffer size.
        //
        // Set the buffer size to SAMPLE_BUFFER_SIZE (defined above) elements.
        //
        // The buffer size is a DWORD property associated with the device.
        DIPROPDWORD dipdw;
        dipdw.diph.dwSize       = sizeof(DIPROPDWORD);
        dipdw.diph.dwHeaderSize = sizeof(DIPROPHEADER);
        dipdw.diph.dwObj        = 0;
        dipdw.diph.dwHow        = DIPH_DEVICE;

        // Setup mouse
        dipdw.dwData            = MOUSE_SAMPLE_BUFFER_SIZE; // Arbitary buffer size
		if (FAILED(m_pMouseDevice->SetProperty(DIPROP_BUFFERSIZE, &dipdw.diph))) {
			_AS::CLog.Output("Setting mouse properties failed!");

			return true;
		}	

		// Setup keyboard:
        dipdw.dwData            = KEYBOARD_SAMPLE_BUFFER_SIZE; // Arbitary buffer size
        if (FAILED(m_pKeyboardDevice->SetProperty(DIPROP_BUFFERSIZE, &dipdw.diph))) {
			_AS::CLog.Output("Setting keyboard properties failed!");

			return true;
		}	
    }

	// Acquire the newly created device
    m_pMouseDevice->Acquire();
    m_pKeyboardDevice->Acquire();

	m_bFirstLoop = true;

	_AS::CLog.Output("DirectInput 8 interface initialization complete");

    return false;
}

/*
	Deinitialize the input devices
*/
bool ASTInputHandler::DeInit()
{
	// Check whether the input handler is initialized or not
	if (!m_hWnd) return true;

	_AS::CLog.Output("Deinitialize DirectInput 8 interface");

    // Unacquire the device one last time just in case 
    // the app tried to exit while the device is still acquired.

    // Mouse
    if (m_pMouseDevice) {
		m_pMouseDevice->Unacquire();
		m_pMouseDevice->Release();
		m_pMouseDevice = NULL;
	}

	// Keyboard
    if (m_pKeyboardDevice) {
		m_pKeyboardDevice->Unacquire();
		m_pKeyboardDevice->Release();
		m_pKeyboardDevice = NULL;
	}

	if (m_pDirectInput) {
		m_pDirectInput->Release();
		m_pDirectInput = NULL;
	}

	m_hWnd = NULL;

	if (_AS::CInput.m_pCInputHandler == this) _AS::CInput.m_pCInputHandler = NULL;

	return false;
}

/*
	Returns whether the input handler is initialized or not
*/
bool ASTInputHandler::IsInitialized() const
{
	if (m_hWnd) return true;
	else		return false;
}

/*
	Resets the keys etc.
*/
void ASTInputHandler::Reset()
{
	memset(&m_SMouse,			0, sizeof(SMouse));
	memset(&m_szKey,			0, sizeof(BYTE) * ASKEYS);
	memset(&m_bKeyPressed,		1, sizeof(bool) * ASKEYS);
	memset(&m_bKeyPressedFirst, 0, sizeof(bool) * ASKEYS);
	m_bAKeyPressed = false;
	m_bAKeyHit	   = false;
}

/*
	Read the input device's state
*/
bool ASTInputHandler::Update()
{
    DIMOUSESTATE Dims2;      // DirectInput mouse state structure
    DWORD dwElements;
	int i;

	// Check whether the input handler is initialized or not
	if (!m_hWnd) return true;

    // Get the input's device state, and put the state in dims
    if (m_pMouseDevice)  {
		ZeroMemory(&Dims2, sizeof(DIMOUSESTATE));
		if (FAILED(m_pMouseDevice->GetDeviceState(sizeof(DIMOUSESTATE), &Dims2)))  {
			// DirectInput may be telling us that the input stream has been
			// interrupted.  We aren't tracking any state between polls, so
			// we don't have any special reset that needs to be done.
			// We just re-acquire and try again
        
			// If input is lost then acquire and keep trying 
			while (m_pMouseDevice->Acquire() == DIERR_INPUTLOST);

			// Result may be DIERR_OTHERAPPHASPRIO or other errors. This
			// may occur when the app is minimized or in the process of 
			// switching, so just try again later 
		}
		m_SMouse.iLastPos[X] = m_SMouse.iPos[X];
		m_SMouse.iLastPos[Y] = m_SMouse.iPos[Y];
		m_SMouse.iPos[X] = Dims2.lX;
		m_SMouse.iPos[Y] = Dims2.lY;
		if (m_bFirstLoop) {
			m_SMouse.iLastPos[X] = m_SMouse.iPos[X];
			m_SMouse.iLastPos[Y] = m_SMouse.iPos[Y];
		}
		m_SMouse.fDeltaX = (m_SMouse.iPos[X] - m_SMouse.iLastPos[X]) * _AS::CConfig.GetMouseSensibility();
		m_SMouse.fDeltaY = (m_SMouse.iPos[Y] - m_SMouse.iLastPos[Y]) * _AS::CConfig.GetMouseSensibility();
		if (_AS::CConfig.InvertMouseYAxe()) m_SMouse.fDeltaY = -m_SMouse.fDeltaY;
		memcpy(&m_SMouse.szButtons, Dims2.rgbButtons, sizeof(Dims2.rgbButtons));
		m_SMouse.bAButtonPressed = false;
 		for (i = 0; i < ASMOUSEBUTTONS; i++) {
			if (IsMouseButtonPressed(i)) {
				m_SMouse.bAButtonPressed = true;
				break;
			}
		}
	}

	// Keyboard
    if (m_pKeyboardDevice) {
		dwElements = KEYBOARD_SAMPLE_BUFFER_SIZE;
		if (m_pKeyboardDevice->GetDeviceState(sizeof(m_szKey), &m_szKey) != DI_OK)  {
			// We got an error or we got DI_BUFFEROVERFLOW.
			//
			// Either way, it means that continuous contact with the
			// device has been lost, either due to an external
			// interruption, or because the buffer overflowed
			// and some events were lost.
			//
			// Consequently, if a button was pressed at the time
			// the buffer overflowed or the connection was broken,
			// the corresponding "up" message might have been lost.
			//
			// But since our simple sample doesn't actually have
			// any state associated with button up or down events,
			// there is no state to reset.  (In a real game, ignoring
			// the buffer overflow would result in the game thinking
			// a key was held down when in fact it isn't; it's just
			// that the "up" event got lost because the buffer
			// overflowed.)
			//
			// If we want to be cleverer, we could do a
			// GetDeviceState() and compare the current state
			// against the state we think the device is in,
			// and process all the states that are currently
			// different from our private state.
			while (m_pKeyboardDevice->Acquire() == DIERR_INPUTLOST);

			// hr may be DIERR_OTHERAPPHASPRIO or other errors.  This
			// may occur when the app is minimized or in the process of 
			// switching, so just try again later 
			for (i = 0; i < ASKEYS; i++) {
				m_szKey[i] = 0;
				m_bKeyPressed[i] = m_bKeyPressedFirst[i] = false;
			}

			return true;
		}

		// Simulate the third mouse button
		if (IsKeyPressed(29)) {
			m_SMouse.szButtons[2]    = 128;
			m_SMouse.bAButtonPressed = true;
		}
	}

	// Update mouse information
	m_SMouse.bAButtonHit = false;
	for (i = 0; i < ASMOUSEBUTTONS; i++) {
		if (!IsMouseButtonPressed(i)) {
			m_SMouse.bButtonPressed[i]	    = false;
			m_SMouse.bButtonPressedFirst[i] = false;
			continue;
		}
		if (!m_SMouse.bButtonPressed[i]) {
			if (!m_SMouse.bButtonPressedFirst[i]) {
				m_SMouse.bButtonPressedFirst[i] = true;
				m_SMouse.bAButtonHit = true;
			}
		} else m_SMouse.bButtonPressedFirst[i] = false;
		m_SMouse.bButtonPressed[i] = true;
	}

	// Update key information
	m_bAKeyPressed = false;
	m_bAKeyHit     = false;
	for (i = 0; i < ASKEYS; i++) {
		if (!IsKeyPressed(i)) {
			m_bKeyPressed[i]	  = false;
			m_bKeyPressedFirst[i] = false;
			continue;
		}
		if (!m_bKeyPressed[i]) {
			m_bKeyPressedFirst[i] = true;
			m_bAKeyHit = true;
		} else m_bKeyPressedFirst[i] = false;

		m_bKeyPressed[i] = true;
		m_bAKeyPressed = true;
	}

	m_bFirstLoop = false;

    return false;
}

/*
	Returns if the mouse button is pressed or not
*/
bool ASTInputHandler::IsMouseButtonPressed(const int iButton) const
{
	return (m_SMouse.szButtons[iButton] & 0x80) != 0;
}

/*
	Returns if the key is pressed or not
*/
bool ASTInputHandler::IsKeyPressed(const int iKey) const
{
	return (m_szKey[iKey] & 0x80) != 0;
}
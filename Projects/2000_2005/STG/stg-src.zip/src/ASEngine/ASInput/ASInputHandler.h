/*
	File: ASInputHandler.h

	Description: Handler for input
*/


#ifndef __ASINPUTHANDLER_H__
#define __ASINPUTHANDLER_H__


// Classes
typedef class ASTInputHandler {

	friend ASTInput;


	public:
		/*
			Constructor
		*/
		ASTInputHandler();

		/*
			Destructor
		*/
		~ASTInputHandler();

		/*
			Initialize the input handler
		
			Parameters:
				HWND hWnd				-> Handle of the window
				bool bExclusive			-> Exclusive mode
				bool bForeground		-> Foreground
				bool bImmediate			-> Immediate
				bool bDisableWindowsKey -> Disable windows key

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Init(const HWND hWnd, const bool bExclusive = false, const bool bForeground = true, bool bImmediate = true, const bool bDisableWindowsKey = false);

		/*
			Deinitialize the input handler

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool DeInit();

		/*
			Returns whether the input handler is initialized or not

			Returns:
				bool -> 'true' if the input handler is initialized else 'false'
		*/
		AS_API bool IsInitialized() const;

		/*
			Resets the keys etc.
		*/
		AS_API void Reset();

		/*
			Read the input device's state

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Update();


	private:
		HWND				 m_hWnd;			// Window handler the input handler works for
		LPDIRECTINPUT8       m_pDirectInput;	// Direct input device
		LPDIRECTINPUTDEVICE8 m_pMouseDevice;	// Mouse device
		LPDIRECTINPUTDEVICE8 m_pKeyboardDevice;	// Keyboard device
		bool				 m_bFirstLoop;		// Is this the first loop after the initialization?

		// Mouse information
		struct SMouse {
			BYTE   szButtons[ASMOUSEBUTTONS];			// Mouse button information
			bool   bButtonPressed[ASMOUSEBUTTONS];		// Is the button pressed?
			bool   bButtonPressedFirst[ASMOUSEBUTTONS];	// Is the button pressed?
			bool   bAButtonPressed;						// Is any mouse button pressed?
			bool   bAButtonHit;							// Is any mouse button hit the first time?
			ASINT2 iPos;								// Current mouse position
			ASINT2 iLastPos;							// Last mouse position
			float  fDeltaX, fDeltaY;					// Mouse movement
		};
		SMouse m_SMouse;

		// Keyboard information
		BYTE  m_szKey[ASKEYS];				// Key information
		bool  m_bKeyPressed[ASKEYS];		// Is the key pressed?
		bool  m_bKeyPressedFirst[ASKEYS];	// Is the key pressed the first time first?
		bool  m_bAKeyPressed;				// Is a key pressed?
		bool  m_bAKeyHit;					// Is a key hit?


		/*
			Returns if the mouse button is pressed or not

			Parameters:
				int iButton -> The mouse button which should be checked

			Returns:
				bool -> 'true' if the mouse button is pressed else 'false'
		*/
		AS_API bool IsMouseButtonPressed(const int iButton) const;

		/*
			Returns if the key is pressed or not

			Parameters:
				int iKey -> The key which should be checked

			Returns:
				bool -> 'true' if the key is pressed else 'false'
		*/
		AS_API bool IsKeyPressed(const int iKey) const;


} ASTInputHandler;


#endif // __ASINPUTHANDLER_H__
/*
	File: ASTypes.h

	Description: Different usefull data types
*/


#ifndef __ASTYPES_H__
#define __ASTYPES_H__


// Typedefs
typedef short  ASSHORT2[2];
typedef short  ASSHORT3[3];
typedef short  ASSHORT4[4];

typedef int	   ASINT2[2];
typedef int    ASINT3[3];
typedef int    ASINT4[4];

typedef float  ASFLOAT2[2];
typedef float  ASFLOAT3[3];
typedef float  ASFLOAT4[4];

typedef double ASDOUBLE2[2];
typedef double ASDOUBLE3[3];
typedef double ASDOUBLE4[4];

typedef float ASBOUNDINGBOX[2][3];


#endif // __ASTYPES_H__
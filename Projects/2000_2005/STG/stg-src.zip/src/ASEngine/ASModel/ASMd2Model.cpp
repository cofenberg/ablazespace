/*
	File: ASMd2Model.cpp
*/

#include <ASEngineDll.h>


/*
	Constructor
*/
ASTMd2Model::ASTMd2Model()
{
	memset(this, 0, sizeof(ASTMd2Model));
}

/*
	Loads a md2 model
*/
bool ASTMd2Model::Load(const char* pszFilename)
{
	int	i, iFrame, iVertex, *piGLCommand, iIndex;
	byte szBuffer[ASMD2MAXFRAMESIZE];
	ASTMd2GLCommand* pSGLCommand;
	ASTMd2Frame *pSFrameT;
	char szVer[5];
	float fX, fY;
	FILE *pFile;

	// Check pointer
	if (!pszFilename) return true;

	strcpy(m_szFilename, pszFilename);
	if (!(pFile = fopen(m_szFilename, "rb"))) return true;

	// Read header
	fread(&m_SHeader, 1, sizeof(ASTMd2Header), pFile);

	// Check model version
	sprintf(szVer, "%c%c%c%c", m_SHeader.iMagic, m_SHeader.iMagic >> 8,
							   m_SHeader.iMagic >> 16, m_SHeader.iMagic >> 24);
	if (stricmp(szVer, "IDP2") || m_SHeader.iVersion != 8) return true;

	// Read triangles
	fseek(pFile, m_SHeader.iOffsetTriangles, SEEK_SET);
	m_pSTriangles		= new ASTMd2Triangle[m_SHeader.iTriangles];
	for (i = 0; i < m_SHeader.iTriangles; i++)
		fread(&m_pSTriangles[i], sizeof(ASTMd2Triangle), 1, pFile);
	
	// Read frames
	fseek(pFile, m_SHeader.iOffsetFrames, SEEK_SET);

	m_pSFrames	= new ASTMd2Frame[m_SHeader.iFrames];

	for (iFrame = 0, pSFrameT = &m_pSFrames[0]; iFrame < m_SHeader.iFrames; iFrame++, pSFrameT++) {
		pSFrameT->pfVertex	   = new ASFLOAT3[m_SHeader.iVertices];
		pSFrameT->pfNormal	   = new ASFLOAT3[m_SHeader.iVertices];

		ASTMd2AliasFrame *pSFrame = (ASTMd2AliasFrame *) szBuffer;
		fread(pSFrame, 1, m_SHeader.iFrameSize, pFile);
		strcpy(pSFrameT->szName, pSFrame->szName);
		
		// Get the vertices:
		for (iVertex = 0; iVertex < m_SHeader.iVertices; iVertex++) {
			pSFrameT->pfVertex[iVertex][X] = (float) ((int) pSFrame->SVertices[iVertex].szVertex[0]) * pSFrame->fScale[0] + pSFrame->fTranslate[0];
			pSFrameT->pfVertex[iVertex][Z] = -1* ((float) ((int) pSFrame->SVertices[iVertex].szVertex[1]) * pSFrame->fScale[1] + pSFrame->fTranslate[1]);
			pSFrameT->pfVertex[iVertex][Y] = (float) ((int) pSFrame->SVertices[iVertex].szVertex[2]) * pSFrame->fScale[2] + pSFrame->fTranslate[2];
		}

		// Get the bounding box of this frame
		GetBoundingBox(iFrame, &pSFrameT->fBoundingBox);
	}

	// Read OpenGL commands
	fseek(pFile, m_SHeader.iOffsetGlCommands, SEEK_SET);
	int* piGLCommandBuffer = new int[m_SHeader.iGlCommands];
	m_SGLCommand = new ASTMd2GLCommand[m_SHeader.iGlCommands];
	memset(piGLCommandBuffer, 0, sizeof(int) * m_SHeader.iGlCommands);
	fread(piGLCommandBuffer, sizeof(int), m_SHeader.iGlCommands, pFile);

	// Build the texture coordinates for each vertex and setup the GL commands
	m_pfTextureCoordinates = new ASFLOAT2[m_SHeader.iVertices];
	piGLCommand = piGLCommandBuffer;
	while (*piGLCommand) {
		pSGLCommand = &m_SGLCommand[m_iGLCommands];
		if (*piGLCommand > 0) { // Triangle strip
			pSGLCommand->iVertices = *piGLCommand;
			piGLCommand++;
			pSGLCommand->bType = 0;
		}
		else { // Triangle fan
			pSGLCommand->iVertices = -*piGLCommand;
			piGLCommand++;
			pSGLCommand->bType = 1;
		}
		if (pSGLCommand->iVertices < 0) pSGLCommand->iVertices = -pSGLCommand->iVertices;
		for (iIndex = 0; iIndex < pSGLCommand->iVertices; iIndex++) {
			fX = *((float*) piGLCommand);
			piGLCommand++;
			fY = 1 - *((float*) piGLCommand);
			piGLCommand++;
			pSGLCommand->iVertex[iIndex] = *piGLCommand;
			piGLCommand++;
			m_pfTextureCoordinates[pSGLCommand->iVertex[iIndex]][X] = fX;
			m_pfTextureCoordinates[pSGLCommand->iVertex[iIndex]][Y] = fY;
		}
		m_iGLCommands++;
	}
	delete piGLCommandBuffer;

	fclose(pFile);

	// Do the rest
	BuildAnimations();
	ComputeNormals();

	m_bLoaded = true;

	return false;
}

/*
	Unloads the md2 model
*/
bool ASTMd2Model::Unload()
{
	ASTMd2Frame *pSFrame;
	int i;

	if (m_pfTextureCoordinates) delete [] m_pfTextureCoordinates;
	if (m_pSTriangles) delete [] m_pSTriangles;
	if (m_pSFrames) {
		for (i = 0, pSFrame = &m_pSFrames[0]; i < m_SHeader.iFrames; i++, pSFrame++) {
			if (pSFrame->pfVertex) delete [] pSFrame->pfVertex;
			if (pSFrame->pfNormal) delete [] pSFrame->pfNormal;
		}
		delete m_pSFrames;
	}

	if (m_SGLCommand) delete m_SGLCommand;
	memset(this, 0, sizeof(ASTMd2Model));

	return false;
}

/*
	Computes the current bounding box
*/
bool ASTMd2Model::GetCurrentBoundingBox(const int iFrame1, const int iFrame2, const float fTime, ASFLOAT3 (*pfBoundingBox)[2])
{
	// Check if the given frames are valid
	if (iFrame1 < 0 || iFrame2 < 0 || iFrame1 >= m_SHeader.iFrames || iFrame2 >= m_SHeader.iFrames)
	   return true;

	ASFLOAT3 (*pfBB1)[2], (*pfBB2)[2];

	pfBB1 = &m_pSFrames[iFrame1].fBoundingBox;
	pfBB2 = &m_pSFrames[iFrame2].fBoundingBox;
	for (int i = 0; i < 3; i++) {
		(*pfBoundingBox)[0][i] = (*pfBB1)[0][i] + fTime * ((*pfBB2)[0][i] - (*pfBB1)[0][i]);
		(*pfBoundingBox)[1][i] = (*pfBB1)[1][i] + fTime * ((*pfBB2)[1][i] - (*pfBB1)[1][i]);
	}

	return false;
}

/*
	Precomputes the md2 model data
*/
bool ASTMd2Model::Precompute(ASTModelHandler* pModelHandler, const int iFrame1, const int iFrame2, const float fTime)
{
	// Check if the given frames are valid
	if (iFrame1 < 0 || iFrame2 < 0 || iFrame1 >= m_SHeader.iFrames || iFrame2 >= m_SHeader.iFrames)
		return true;

	ASTMd2Frame* pSFrame1T = &m_pSFrames[iFrame1];
	ASTMd2Frame* pSFrame2T = &m_pSFrames[iFrame2];
	ASFLOAT3* pfVertexT, *pfLastVertexT, *pfVertex1T, *pfVertex2T, *pfNormalT, *pfNormal1T, *pfNormal2T;

	// Precompute the frame
	pfVertexT			 = &pModelHandler->m_pfVertex[0];
	pfLastVertexT		 = &pModelHandler->m_pfVertex[m_SHeader.iVertices];
	pfNormalT			 = &pModelHandler->m_pfNormal[0];
	if (iFrame2 > iFrame1) {
		pfVertex1T = &pSFrame1T->pfVertex[0];
		pfVertex2T = &pSFrame2T->pfVertex[0];
		pfNormal1T = &pSFrame1T->pfNormal[0];
		pfNormal2T = &pSFrame2T->pfNormal[0];
	} else {
		pfVertex1T = &pSFrame2T->pfVertex[0];
		pfVertex2T = &pSFrame1T->pfVertex[0];
		pfNormal1T = &pSFrame2T->pfNormal[0];
		pfNormal2T = &pSFrame1T->pfNormal[0];
	}
	for (; pfVertexT < pfLastVertexT; pfVertexT++, pfVertex1T++, pfVertex2T++, pfNormalT++, pfNormal1T++, pfNormal2T++)	{
		// Calcualate the current vertex
		(*pfVertexT)[0] = (*pfVertex1T)[0] + fTime * ((*pfVertex2T)[0] - (*pfVertex1T)[0]);
		(*pfVertexT)[1] = (*pfVertex1T)[1] + fTime * ((*pfVertex2T)[1] - (*pfVertex1T)[1]);
		(*pfVertexT)[2] = (*pfVertex1T)[2] + fTime * ((*pfVertex2T)[2] - (*pfVertex1T)[2]);

		// Calcualate the current vertex normal
		(*pfNormalT)[0] = (*pfNormal1T)[0] + fTime * ((*pfNormal2T)[0] - (*pfNormal1T)[0]);
		(*pfNormalT)[1] = (*pfNormal1T)[1] + fTime * ((*pfNormal2T)[1] - (*pfNormal1T)[1]);
		(*pfNormalT)[2] = (*pfNormal1T)[2] + fTime * ((*pfNormal2T)[2] - (*pfNormal1T)[2]);
	}

	return false;
}

/*
	Draws the precomputed md2 model
*/
bool ASTMd2Model::Draw(const float fSilhouetteWidth)
{
	ASTMd2GLCommand* pSGLCommand, *pSGLCommandLast;

	// Draw the precomputed frame
	glDisableClientState(GL_COLOR_ARRAY);
	glEnableClientState(GL_VERTEX_ARRAY);
	if (!_AS::CConfig.IsComicCelShading()) glEnableClientState(GL_NORMAL_ARRAY);
	else								   glDisableClientState(GL_NORMAL_ARRAY);
	glEnableClientState(GL_TEXTURE_COORD_ARRAY);
	glTexCoordPointer(2, GL_FLOAT, 0, m_pfTextureCoordinates);
	if (_AS::CRenderer.CExtensions.IsCompiledVertexArraySupported())
		glLockArraysEXT(0, m_SHeader.iVertices);
	
	pSGLCommandLast = &m_SGLCommand[m_iGLCommands];
	for (pSGLCommand = &m_SGLCommand[0]; pSGLCommand < pSGLCommandLast; pSGLCommand++) {
		if (pSGLCommand->bType) glDrawElements(GL_TRIANGLE_FAN, pSGLCommand->iVertices, GL_UNSIGNED_INT, pSGLCommand->iVertex);
		else glDrawElements(GL_TRIANGLE_STRIP, pSGLCommand->iVertices, GL_UNSIGNED_INT, pSGLCommand->iVertex);
	}
	_AS::CRenderer.AddTriangles(m_SHeader.iTriangles);

	glDisableClientState(GL_TEXTURE_COORD_ARRAY);

	// Should silhouettes be drawn?
	if (_AS::CConfig.IsComicStyle() && _AS::CConfig.IsComicSilhouettes() && !_AS::CConfig.IsWireframeMode() && !_AS::CConfig.IsPointMode() &&
	    fSilhouetteWidth > 0.3) {
		glPolygonOffset(-0.1f, -0.1f);
		glDisableClientState(GL_NORMAL_ARRAY);
		glDisable(GL_TEXTURE_2D);
		glPolygonMode(GL_FRONT, GL_LINE);
		glCullFace(GL_BACK);
		glLineWidth(fSilhouetteWidth);
		glDepthFunc(GL_LEQUAL);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		if (fSilhouetteWidth < 1.f) {
			glColor4f(0.f, 0.f, 0.f, fSilhouetteWidth - 0.3f);
			glEnable(GL_BLEND);
		} else {
			glColor3f(0.f, 0.f, 0.f);
			glDisable(GL_BLEND);
		}

		pSGLCommandLast = &m_SGLCommand[m_iGLCommands];
		for (pSGLCommand = &m_SGLCommand[0]; pSGLCommand < pSGLCommandLast; pSGLCommand++) {
			if (pSGLCommand->bType) glDrawElements(GL_TRIANGLE_FAN, pSGLCommand->iVertices, GL_UNSIGNED_INT, pSGLCommand->iVertex);
			else glDrawElements(GL_TRIANGLE_STRIP, pSGLCommand->iVertices, GL_UNSIGNED_INT, pSGLCommand->iVertex);
		}
		glDepthFunc(GL_LESS);
		glPolygonMode (GL_FRONT, GL_FILL);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);
		glColor3f(1.f, 1.f, 1.f);
		glDisable (GL_BLEND);
		glEnable(GL_TEXTURE_2D);
		glPolygonOffset(0.f, 0.f);
		_AS::CRenderer.AddTriangles(m_SHeader.iTriangles);
	}

	if (_AS::CRenderer.CExtensions.IsCompiledVertexArraySupported())
		glUnlockArraysEXT();

	glDisableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_NORMAL_ARRAY);

	return false;
}

/*
	Gets the bounding box of a frame
*/
bool ASTMd2Model::GetBoundingBox(const int iFrame, ASFLOAT3 (*pfBoundingBox)[2])
{
	// Check if the given frame is valid
	if (iFrame < 0 || iFrame >= m_SHeader.iFrames) return true;

	ASFLOAT3* pfV, *pfVLast;
	int i;

	// Initialize the bounding box
	for (i = 0; i < 3; i++) {
		(*pfBoundingBox)[0][i] = 999999.f;
		(*pfBoundingBox)[1][i] = -999999.f;
	}

	// Get bounding box min / max
	pfVLast = &m_pSFrames[iFrame].pfVertex[m_SHeader.iVertices];
	for (pfV = &m_pSFrames[iFrame].pfVertex[0]; pfV < pfVLast; pfV++) {
		for(i = 0; i < 3; i++) {
			if ((*pfV)[i] < (*pfBoundingBox)[0][i])
				(*pfBoundingBox)[0][i] = (*pfV)[i];
			else if ((*pfV)[i] > (*pfBoundingBox)[1][i])
				(*pfBoundingBox)[1][i] = (*pfV)[i];
		}
	}

	return false;
}

/*
	Builds the animations of the md2 model
*/
void ASTMd2Model::BuildAnimations()
{
	char	t_st[16], t_name[16], t_last[16];
	int		anim_vector[ASMD2MAXFRAMES];
	int		anim_index, t_ln, i;
	ASTMd2Frame* pSFrameT, *pSFrameLastT;

	anim_index = 0;
	m_SAnimation.iNumber = 0;
	for (i = 0; i < ASMD2MAXFRAMES; i++) anim_vector[i] = 0;

	memset(m_SAnimation.SAnimation, 0, sizeof(ASTMD2Animation) * ASMD2MAXFRAMES);
	strcpy(m_SAnimation.SAnimation[m_SAnimation.iNumber].szName, "all frames");
	m_SAnimation.SAnimation[m_SAnimation.iNumber].iFirstFrame = 0;
	m_SAnimation.SAnimation[m_SAnimation.iNumber].iLastFrame = m_SHeader.iFrames;
	m_SAnimation.iNumber++;

	strcpy(t_last, "_0_");
	pSFrameT = &m_pSFrames[0];
	pSFrameLastT = &m_pSFrames[m_SHeader.iFrames];
	for (i = 0; pSFrameT < pSFrameLastT; pSFrameT++, i++) {
		strcpy(t_st, pSFrameT->szName);
		t_ln = strlen(t_st);

		t_ln--;
		while (t_st[t_ln] >= '0' && t_st[t_ln] <= '9' || t_st[t_ln] == '_') t_ln--;
		t_ln++;

		strncpy(t_name, t_st, t_ln);
		t_name[t_ln] = '\0';

		if (stricmp(t_name, t_last)) {
			anim_vector[anim_index] = i;
			anim_index++;
				
			strcpy(m_SAnimation.SAnimation[m_SAnimation.iNumber].szName, t_name);
			m_SAnimation.SAnimation[m_SAnimation.iNumber].iFirstFrame = -1;
			m_SAnimation.SAnimation[m_SAnimation.iNumber].iLastFrame  = -1;
			m_SAnimation.iNumber++;
		}
		
		strcpy(t_last, t_name);
	}

	anim_vector[anim_index] = m_SHeader.iFrames;
	anim_index++;

	for (i = 1; i < anim_index; i++) {
		m_SAnimation.SAnimation[i].iFirstFrame = anim_vector[i - 1];
		m_SAnimation.SAnimation[i].iLastFrame  = anim_vector[i];
	}
}

/*
	Computes the light normals
*/
void ASTMd2Model::ComputeNormals()
{
	ASTMd2Triangle* pSTriangle, *pSTriangleLast;
	ASTMd2Frame* pSFrameT, *pSFrameLastT;
	int i;
	ASFLOAT3* pfV, *pfVLast, fNormalT;
	float v1[3], v2[3], fLength;

	pSFrameLastT = &m_pSFrames[m_SHeader.iFrames];
	for (pSFrameT = &m_pSFrames[0]; pSFrameT < pSFrameLastT; pSFrameT++) {
		// Clear all normals
		memset(pSFrameT->pfNormal, 0, sizeof(ASFLOAT3) * m_SHeader.iVertices);

		// Calculate normals
		pSTriangleLast = &m_pSTriangles[m_SHeader.iTriangles];
		for (pSTriangle = &m_pSTriangles[0]; pSTriangle < pSTriangleLast; pSTriangle++) {
			// Make face normal			
			v1[X] = pSFrameT->pfVertex[pSTriangle->iVertexIndices[1]][X] - pSFrameT->pfVertex[pSTriangle->iVertexIndices[0]][X];
			v1[Y] = pSFrameT->pfVertex[pSTriangle->iVertexIndices[1]][Y] - pSFrameT->pfVertex[pSTriangle->iVertexIndices[0]][Y];
			v1[Z] = pSFrameT->pfVertex[pSTriangle->iVertexIndices[1]][Z] - pSFrameT->pfVertex[pSTriangle->iVertexIndices[0]][Z];
			v2[X] = pSFrameT->pfVertex[pSTriangle->iVertexIndices[2]][X] - pSFrameT->pfVertex[pSTriangle->iVertexIndices[0]][X];
			v2[Y] = pSFrameT->pfVertex[pSTriangle->iVertexIndices[2]][Y] - pSFrameT->pfVertex[pSTriangle->iVertexIndices[0]][Y];
			v2[Z] = pSFrameT->pfVertex[pSTriangle->iVertexIndices[2]][Z] - pSFrameT->pfVertex[pSTriangle->iVertexIndices[0]][Z];
			fNormalT[0] = (v1[1] * v2[2] - v1[2] * v2[1]);
			fNormalT[1] = (v1[2] * v2[0] - v1[0] * v2[2]);
			fNormalT[2] = (v1[0] * v2[1] - v1[1] * v2[0]);

			for (i = 0; i < 3; i++) {
				pSFrameT->pfNormal[pSTriangle->iVertexIndices[i]][X] -= fNormalT[X];
				pSFrameT->pfNormal[pSTriangle->iVertexIndices[i]][Y] += fNormalT[Z];
				pSFrameT->pfNormal[pSTriangle->iVertexIndices[i]][Z] -= fNormalT[Y];
			}
		}

		// Normalize normals
		pfV     = &pSFrameT->pfNormal[0];
		pfVLast = pfV + m_SHeader.iVertices;
		for (; pfV < pfVLast; pfV++) {
			fLength = (float) ASSqrt(ASDotProduct(*pfV, *pfV));
			if (!fLength) {
				(*pfV)[X] = (*pfV)[Y] = (*pfV)[Z] = 1.f;
				continue;
			}
			(*pfV)[X] /= fLength;
			(*pfV)[Y] /= fLength;
			(*pfV)[Z] /= fLength;
		}
	}
}
/*
	File: ASModelHandler.cpp
*/

#include <ASEngineDll.h>


/*
	Constructor
*/
ASTModelHandler::ASTModelHandler(const char* pszFilename)
{
	Init();
	Load(pszFilename);
}

/*
	Destructor
*/
ASTModelHandler::~ASTModelHandler()
{
	Unload();
}

/*
	Gets the model handler flags
*/
int ASTModelHandler::GetFlags() const
{
	return m_iFlags;
}

/*
	Sets the model handler flags
*/
void ASTModelHandler::SetFlags(const int iFlags)
{
	m_iFlags = iFlags;
}

/*
	Gets the model handler animation flags
*/
int ASTModelHandler::GetAnimationFlags() const
{
	return m_iAnimationFlags;
}

/*
	Sets the model handler animation flags
*/
void ASTModelHandler::SetAnimationFlags(const int iAnimationFlags)
{
	m_iAnimationFlags = iAnimationFlags;
}

/*
	Returns whether the model is active or not
*/
bool ASTModelHandler::IsActive() const
{
	return m_bActive;
}

/*
	Activeate / deactivates the model
*/
void ASTModelHandler::SetActive(const bool bActive)
{
	m_bActive = bActive;
}

/*
	Loads a model
*/
bool ASTModelHandler::Load(const char* pszFilename)
{
	// Check if the handler already uses this object
	if (m_pCModel && !stricmp(m_pCModel->GetFilename(), pszFilename)) return false;

	Unload();

	// Load model
	if (_AS::CModelManager.Load(this, pszFilename)) return true;

	// Setup additional model data
	m_pfVertex			  = new ASFLOAT3[m_pCModel->GetModel()->m_SHeader.iVertices];
	m_pfNormal			  = new ASFLOAT3[m_pCModel->GetModel()->m_SHeader.iVertices];
	m_pfTextureCoordinate = new	   float[m_pCModel->GetModel()->m_SHeader.iVertices];

	LoadConfiguration();

	m_bForceUpdate = true;

	return false;
}

/*
	Loads the model configuration of this handler
*/
void ASTModelHandler::LoadConfiguration()
{
	char szFilename[256], szTextureFilename[256], szTemp[256];
	ASFLOAT3 fBoundingBox[2];
	int i, i2;

	// Load 'asm'-file
	strcpy(szFilename, m_pCModel->GetFilename());
	_AS::CFileSystem.CutFilenameEnding(szFilename);
	_AS::CFileSystem.GetFullFilename(szFilename, ASMODEL_FILE);

	// General
	GetPrivateProfileString("general", "texture", ASSTANDARDTEXTURE, szTextureFilename, 256, szFilename);
	GetPrivateProfileString("general", "silhouettewidthfactor", "1", szTemp, 256, szFilename);
	m_fSilhouetteWidthFactor = (float) atof(szTemp);
	GetPrivateProfileString("general", "animation_speed", "1", szTemp, 256, szFilename);
	m_fStandardAnimationSpeed = (float) atof(szTemp);
	m_bNoComicStyle = GetPrivateProfileInt("general", "nocomicstyle", 0, szFilename) != 0;
	GetPrivateProfileString("general", "radius", "1", szTemp, 256, szFilename);
	m_fRadius = (float) atof(szTemp);
	m_bBackfaceCulling = GetPrivateProfileInt("general", "backface_culling", 1, szFilename) != 0;
	m_bCullFace		   = GetPrivateProfileInt("general", "cull_face",		 0, szFilename) != 0;
	m_bCreateCollisionMesh = GetPrivateProfileInt("general", "create_collision_mesh", 0, szFilename) != 0;
	
	// Position
	GetPrivateProfileString("position", "x", "0", szTemp, 256, szFilename);
	m_vPos.fX = (float) atof(szTemp);
	GetPrivateProfileString("position", "y", "0", szTemp, 256, szFilename);
	m_vPos.fY = (float) atof(szTemp);
	GetPrivateProfileString("position", "z", "0", szTemp, 256, szFilename);
	m_vPos.fZ = (float) atof(szTemp);

	// Rotation
	GetPrivateProfileString("rotation", "x", "0", szTemp, 256, szFilename);
	m_vRot.fX = (float) atof(szTemp);
	GetPrivateProfileString("rotation", "y", "0", szTemp, 256, szFilename);
	m_vRot.fY = (float) atof(szTemp);
	GetPrivateProfileString("rotation", "z", "0", szTemp, 256, szFilename);
	m_vRot.fZ = (float) atof(szTemp);

	// Scale
	GetPrivateProfileString("scale", "x", "1", szTemp, 256, szFilename);
	m_vScale.fX = (float) atof(szTemp);
	GetPrivateProfileString("scale", "y", "1", szTemp, 256, szFilename);
	m_vScale.fY = (float) atof(szTemp);
	GetPrivateProfileString("scale", "z", "1", szTemp, 256, szFilename);
	m_vScale.fZ = (float) atof(szTemp);

	// Check if the model has its own object space
	if (m_vPos.IsNull() && m_vRot.IsNull() && m_vScale == 1.f) m_bObjectSpace = false;
	else													   m_bObjectSpace = true;

	// Bounding box
	GetPrivateProfileString("bounding_box", "x_min", "0", szTemp, 256, szFilename);
	m_fStaticBoundingBox[0][X] = (float) atof(szTemp);
	GetPrivateProfileString("bounding_box", "y_min", "0", szTemp, 256, szFilename);
	m_fStaticBoundingBox[0][Y] = (float) atof(szTemp);
	GetPrivateProfileString("bounding_box", "z_min", "0", szTemp, 256, szFilename);
	m_fStaticBoundingBox[0][Z] = (float) atof(szTemp);
	GetPrivateProfileString("bounding_box", "x_max", "0", szTemp, 256, szFilename);
	m_fStaticBoundingBox[1][X] = (float) atof(szTemp);
	GetPrivateProfileString("bounding_box", "y_max", "0", szTemp, 256, szFilename);
	m_fStaticBoundingBox[1][Y] = (float) atof(szTemp);
	GetPrivateProfileString("bounding_box", "z_max", "0", szTemp, 256, szFilename);
	m_fStaticBoundingBox[1][Z] = (float) atof(szTemp);

	// Visibility bounding box
	GetPrivateProfileString("visibility_box", "x_min", "0", szTemp, 256, szFilename);
	m_fVisibilityBoundingBox[0][X] = (float) atof(szTemp);
	GetPrivateProfileString("visibility_box", "y_min", "0", szTemp, 256, szFilename);
	m_fVisibilityBoundingBox[0][Y] = (float) atof(szTemp);
	GetPrivateProfileString("visibility_box", "z_min", "0", szTemp, 256, szFilename);
	m_fVisibilityBoundingBox[0][Z] = (float) atof(szTemp);
	GetPrivateProfileString("visibility_box", "x_max", "0", szTemp, 256, szFilename);
	m_fVisibilityBoundingBox[1][X] = (float) atof(szTemp);
	GetPrivateProfileString("visibility_box", "y_max", "0", szTemp, 256, szFilename);
	m_fVisibilityBoundingBox[1][Y] = (float) atof(szTemp);
	GetPrivateProfileString("visibility_box", "z_max", "0", szTemp, 256, szFilename);
	m_fVisibilityBoundingBox[1][Z] = (float) atof(szTemp);

	// Should the visibility bounding box be calculated automatically??
	if (!m_fVisibilityBoundingBox[0][X] && !m_fVisibilityBoundingBox[0][Y] && !m_fVisibilityBoundingBox[0][Z] &&
        !m_fVisibilityBoundingBox[1][X] && !m_fVisibilityBoundingBox[1][Y] && !m_fVisibilityBoundingBox[1][Z])
		m_bAutoVisibilityBox = true;
	else m_bAutoVisibilityBox = false;

	// Load models standard texture
	m_CTextureHandler.Load(szTextureFilename);

	// Check bounding box
	m_pCModel->m_CModel.GetBoundingBox(0, &fBoundingBox);
	for (i = 0; i < 2; i++)
		for (i2 = 0; i2 < 3; i2++) {
			if (m_fStaticBoundingBox[i][i2]) continue;
			m_fStaticBoundingBox[i][i2] = fBoundingBox[i][i2];
		}
}

/*
	Returns if the model handler has a model or not	
*/
bool ASTModelHandler::IsLoaded() const
{
	if (m_pCModel) return true;
	else		   return false;
}

/*
	Unloads the model
*/
bool ASTModelHandler::Unload()
{
	ASTLinkedListElement<ASTModelHandler*>* pSListElement;
	bool bError;

	// Does the model handler has a model?
	if (!m_pCModel) return true;

	// Update model handlers bind list
	if (m_pCModelHandler) m_pCModelHandler->m_lstModelHandler.Remove(this);
	pSListElement = m_lstModelHandler.FindFirst();
	while (pSListElement) {
		if (pSListElement->Data) pSListElement->Data->m_pCModelHandler = NULL;
		pSListElement = m_lstModelHandler.FindNext();
	}
	m_lstModelHandler.Clear();

	// Unload models standard texture
	m_CTextureHandler.Unload();

	// Destroy additional model information
	if (m_pfVertex) {
		delete [] m_pfVertex;
		m_pfVertex = NULL;
	}
	if (m_pfNormal) {
		delete [] m_pfNormal;
		m_pfNormal = NULL;
	}
	if (m_pfTextureCoordinate) {
		delete [] m_pfTextureCoordinate;
		m_pfTextureCoordinate = NULL;
	}

	// Destroy collision mesh
	if (m_CCollisionMesh.pCPlane) {
		delete [] m_CCollisionMesh.pCPlane;
		m_CCollisionMesh.pCPlane = NULL;
		m_CCollisionMesh.iPlanes = 0;
	}

	// Unload this model
	bError = _AS::CModelManager.Unload(this);

	Init();

	return bError;
}

/*
	Returns the model handlers model
*/
ASTModel* ASTModelHandler::GetModel() const
{
	return m_pCModel;
}

/*
	Returns a pointer to the collision mesh
*/
ASTCollisionMesh* ASTModelHandler::GetCollisionMesh()
{
	if (!m_pCModel || !m_pCModel->GetModel()) return NULL;

	if (m_CCollisionMesh.pCPlane) delete m_CCollisionMesh.pCPlane;
	if (m_pCEntity) m_CCollisionMesh.vPos = m_pCEntity->GetPos();
	else			m_CCollisionMesh.vPos = 0.f;
	m_CCollisionMesh.fRadius = m_fRadius;

	m_pCModel->GetModel()->Precompute(this, m_iFrame, m_iNextFrame, m_fTime);
	TransformToWorldSpace();
	UpdateBoundingBoxes();

	// Get collision bounding box
	memcpy(m_CCollisionMesh.fBoundingBox[0], m_fBoundingBox, sizeof(ASBOUNDINGBOX));

	if (m_bCreateCollisionMesh) { // Use mesh data
		m_CCollisionMesh.iPlanes = m_pCModel->GetModel()->m_SHeader.iTriangles;
		m_CCollisionMesh.pCPlane = new ASTPlane[m_CCollisionMesh.iPlanes];

		{ // Calculate collision planes
			ASTMd2Triangle* pSTriangle, *pSTriangleLast;
			int i;

			pSTriangleLast = &m_pCModel->GetModel()->m_pSTriangles[m_pCModel->GetModel()->m_SHeader.iTriangles];
			for (pSTriangle = &m_pCModel->GetModel()->m_pSTriangles[0], i = 0; pSTriangle < pSTriangleLast; pSTriangle++, i++) 
				m_CCollisionMesh.pCPlane[i].ComputeND(m_pfVertex[pSTriangle->iVertexIndices[0]],
													  m_pfVertex[pSTriangle->iVertexIndices[1]],
													  m_pfVertex[pSTriangle->iVertexIndices[2]]);
		}
	} else { // Use a bounding box
	}

	return &m_CCollisionMesh;
}

/*
	Performs the visibility update
*/
bool ASTModelHandler::UpdateVisibility(const bool bForceModelUpdate)
{
	if (!m_pCModel || !m_pCModel->GetModel()) return false;

	if (!bForceModelUpdate) { // Should the model data be updated?
		ASTVector3D vEntityPos, vEntityRot, vEntityScale;
		float fCameraDistance;

		if (m_pCEntity) {
			vEntityPos   = m_pCEntity->GetPos();
			vEntityRot   = m_pCEntity->GetRot();
			vEntityScale = m_pCEntity->GetScale();
			if (_AS::CRenderer.GetCamera()) fCameraDistance = 10 / (_AS::CRenderer.GetCamera()->GetPos() - (m_vPos + m_pCEntity->GetPos())).GetLength();
		} else fCameraDistance = 1.f;
		if (!m_bForceUpdate && fCameraDistance < 0.1f) { // No animation update
			m_iFrameT	  = m_iFrame;
			m_iNextFrameT = m_iNextFrame;
			m_fTimeT	  = m_fTime;
		}
		if (m_bForceUpdate || m_iFrameT != m_iFrame || m_iNextFrameT != m_iNextFrame || m_fTime != m_fTimeT || 
			vEntityPosT != vEntityPos || vEntityRotT  != vEntityRot || vEntityScaleT != vEntityScale) {
			m_iFrameT	      = m_iFrame;
			m_iNextFrameT     = m_iNextFrame;
			m_fTimeT	      = m_fTime;
			vEntityPosT       = vEntityPos;
			vEntityRotT       = vEntityRot;
			vEntityScaleT     = vEntityScale;
		} else return InFrustum();
	}

	if (!m_bAutoVisibilityBox) {
		UpdateBoundingBoxes();

		if (!bForceModelUpdate && !m_bForceUpdate && !InFrustum()) return false;
	}
	m_bForceUpdate = false;

	// Get model data
	if (m_pCModel->GetModel()->Precompute(this, m_iFrame, m_iNextFrame, m_fTime))
		return false;
	TransformToWorldSpace();
	if (m_bAutoVisibilityBox) {
		UpdateBoundingBoxes();
		if (InFrustum()) return false;
	}

	return true;
}

/*
	Draws the model
*/
bool ASTModelHandler::Draw(const bool bUseModelTexture, const bool bFrustumTest)
{
	bool bError = false, bComicStyleT;
	float fSilhouetteWidth, fCameraDistance;
	int i;

	if (!m_bActive || !m_pCModel || !m_pCModel->GetModel()) return true;

	// Frustum test
	if (bFrustumTest && InFrustum()) return false;

	glDisable(GL_LIGHTING);

	// Setup backface culling
	if (m_bBackfaceCulling) {
		glEnable(GL_CULL_FACE);
		if (m_bCullFace) glCullFace(GL_BACK);
		else			 glCullFace(GL_FRONT);
	}
	else glDisable(GL_CULL_FACE);

	// Get camera distance
	if (_AS::CRenderer.GetCamera())
		fCameraDistance = 10 / (_AS::CRenderer.GetCamera()->GetPos() - (m_vPos + m_pCEntity->GetPos())).GetLength();
	else fCameraDistance = 1.f;

	// Setup comic style
	if (m_bNoComicStyle) {
		bComicStyleT = _AS::CConfig.IsComicStyle();
		_AS::CConfig.m_bComicStyle = false;
	}

	// Get silhouette width
	if (m_fSilhouetteWidthFactor) {
		if (_AS::CRenderer.GetCamera() && m_pCEntity) {
			fSilhouetteWidth = _AS::CConfig.GetComicSilhouettesWidth() * fCameraDistance * m_fSilhouetteWidthFactor;
		} else fSilhouetteWidth = _AS::CConfig.GetComicSilhouettesWidth() * m_fSilhouetteWidthFactor;
	} else fSilhouetteWidth = 0.f;

	glEnable(GL_TEXTURE_2D);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);

	if (fCameraDistance > 0.1f) PerformCelShading();

	// Is the cel shading activated?
	if (_AS::CConfig.IsComicCelShading()) {
		glActiveTextureARB(GL_TEXTURE1_ARB);
		glClientActiveTextureARB(GL_TEXTURE1_ARB);
		glEnableClientState(GL_TEXTURE_COORD_ARRAY);
		glEnable(GL_TEXTURE_1D);
		_AS::CTextureManager.GetCelShadingTexture()->BindOpenGLTexture();
		glTexCoordPointer(1, GL_FLOAT, 0, m_pfTextureCoordinate);
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE); 
		glActiveTextureARB(GL_TEXTURE0_ARB);
		glClientActiveTextureARB(GL_TEXTURE0_ARB);
	} else {
		glNormalPointer(GL_FLOAT, 0, m_pfNormal);
	}

	// Bind the models texture
	if (bUseModelTexture) m_CTextureHandler.GetTexture()->BindOpenGLTexture();

	glVertexPointer(3, GL_FLOAT, 0, m_pfVertex);
	if (m_pCModel->GetModel()->Draw(fSilhouetteWidth)) bError = true;
	if (m_bNoComicStyle) _AS::CConfig.m_bComicStyle = bComicStyleT;

	// Is the cel shading activated?
	if (_AS::CConfig.IsComicCelShading()) {
		glActiveTextureARB(GL_TEXTURE1_ARB);
		glClientActiveTextureARB(GL_TEXTURE1_ARB);
		glDisableClientState(GL_TEXTURE_COORD_ARRAY);
		glDisable(GL_TEXTURE_1D);
		glActiveTextureARB(GL_TEXTURE0_ARB);
		glClientActiveTextureARB(GL_TEXTURE0_ARB);
	}

	// Show the models bounding box
	if ((m_iFlags & ASeModelHandlerFlagShowBoundingBox) || _AS::CConfig.ShowBoundingBoxes()) {
		glColor3f(1.f, 1.f, 1.f);
		_AS::CRenderer.ShowBoundingBox(m_fBoundingBox);

		glPushMatrix();
		glColor3f(1.f, 0.f, 0.f);
		glTranslatef(m_vPos.fX, m_vPos.fY, m_vPos.fZ);
		if (m_pCEntity)	glTranslatef(m_pCEntity->GetPos().fX, m_pCEntity->GetPos().fY, m_pCEntity->GetPos().fZ);
		_AS::CRenderer.ShowBoundingBox(m_fStaticBoundingBox);
		glPopMatrix();

		// Show the models origin
		glPointSize(10.f);
		glBegin(GL_POINTS);
			glVertex3fv(m_vPos.fV);
		glEnd();

/*		// Draw collision mesh
		glDisable(GL_TEXTURE_2D);
		glEnable(GL_CULL_FACE);
		glCullFace(GL_FRONT);
		glBegin(GL_TRIANGLES);
			for (i = 0; i < m_CCollisionMesh.iPlanes; i++) {
				glVertex3fv(m_CCollisionMesh.pCPlane[i].vV1.fV);
				glVertex3fv(m_CCollisionMesh.pCPlane[i].vV2.fV);
				glVertex3fv(m_CCollisionMesh.pCPlane[i].vV3.fV);
			}
		glEnd();
		glEnable(GL_TEXTURE_2D);*/
	}

	// Show vertices
	if (m_iFlags & ASeModelHandlerFlagShowVertices) {
		glColor3f(1.f, 1.f, 1.f);
		glPointSize(5.f);
		glBegin(GL_POINTS);
			for (int i = 0; i < m_pCModel->GetModel()->m_SHeader.iVertices; i++) {
				glVertex3fv(m_pfVertex[i]);
			}
		glEnd();
	}

	// Show normals
	if (m_iFlags & ASeModelHandlerFlagShowNormals) {
		glColor3f(1.f, 1.f, 1.f);
		glLineWidth(5.f);
		glBegin(GL_LINES);
			for (i = 0; i < m_pCModel->GetModel()->m_SHeader.iVertices; i++) {
				glVertex3fv(m_pfVertex[i]);
				glVertex3f(m_pfVertex[i][X] + m_pfNormal[i][X] / 5,
						   m_pfVertex[i][Y] + m_pfNormal[i][Y] / 5,
						   m_pfVertex[i][Z] + m_pfNormal[i][Z] / 5);
			}
		glEnd();
	}

	// Show vertex numbers
	if (m_iFlags & ASeModelHandlerFlagShowVertexNumbers) {
		glColor3f(1.f, 1.f, 1.f);
		for (i = 0; i < m_pCModel->GetModel()->m_SHeader.iVertices; i++)
			_AS::CRenderer.Print(ASTVector3D(m_pfVertex[i]), true, "%d", i);
	}

	return bError;
}

/*
	Sets the current animation
*/
bool ASTModelHandler::SetAnimation(const int iAnimation, const bool bRestart, const bool bResetTimer)
{
	if (iAnimation < 0 || !m_pCModel || !m_pCModel->GetModel() ||
		iAnimation >= m_pCModel->GetModel()->m_SAnimation.iNumber)
		return true;

	if (!bRestart && m_iAnimation == iAnimation) return false;

	{
		ASTMD2Animation* pSAnimation;

		m_iAnimation = iAnimation;
		pSAnimation  = &m_pCModel->GetModel()->m_SAnimation.SAnimation[m_iAnimation];
		m_iFrame     = pSAnimation->iFirstFrame;

		// Get next frame
		if (m_iAnimationFlags & ASeModelAniFlagReverse) { // Play reversed
			if (bResetTimer) m_fTime = 1.f;
			m_iNextFrame = m_iFrame - 1;
			if (m_iNextFrame < pSAnimation->iFirstFrame) {
				if (m_iAnimationFlags & ASeModelAniFlagLoop) m_iNextFrame = pSAnimation->iLastFrame - 1;
				else										 m_iNextFrame = pSAnimation->iFirstFrame;
			}
		} else { // Play normal
			if (bResetTimer) m_fTime = 0.f;
			m_iNextFrame = m_iFrame + 1;
			if (m_iNextFrame >= pSAnimation->iLastFrame) {
				if (m_iAnimationFlags & ASeModelAniFlagLoop) m_iNextFrame = pSAnimation->iFirstFrame;
				else										 m_iNextFrame = pSAnimation->iLastFrame - 1;
			}
		}

		m_bForceUpdate = true;
	}

	return false;
}

/*
	Returns the current animation
*/
int ASTModelHandler::GetAnimation() const
{
	return m_iAnimation;
}

/*
	Returns the current frame step
*/
int ASTModelHandler::GetAnimationFrame(const bool bRelative) const
{
	if (bRelative) return m_iFrame - m_pCModel->GetModel()->m_SAnimation.SAnimation[m_iAnimation].iFirstFrame;
	else		   return m_iFrame;
}

/*
	Returns if the current animation frame is the last frame from the animation
*/
bool ASTModelHandler::IsLastAnimationFrame(const bool bRelative) const
{
	ASTMD2Animation* pSAnimation;

	// Get animation pointer
	if (bRelative) pSAnimation = &m_pCModel->GetModel()->m_SAnimation.SAnimation[m_iAnimation];
	else		   pSAnimation = &m_pCModel->GetModel()->m_SAnimation.SAnimation[0];

	// Check frame
	if (m_iAnimationFlags & ASeModelAniFlagReverse) { // Reversed playback
		if (m_iFrame <= pSAnimation->iFirstFrame) return true;
	} else { // Normal playback
		if (m_iFrame >= pSAnimation->iLastFrame - 1) return true;
	}

	return false;
}

/*
	Sets the current animation frame
*/
void ASTModelHandler::SetAnimationFrame(const int iFrame, const bool bRelative, const bool bResetTimer)
{
	ASTMD2Animation* pSAnimation;

	// Check timer
	if (bResetTimer) {
		if (m_iAnimationFlags & ASeModelAniFlagReverse) m_fTime = 1.f;
		else										    m_fTime = 0.f;
	}
	
	// Get animation pointer
	if (bRelative) pSAnimation = &m_pCModel->GetModel()->m_SAnimation.SAnimation[m_iAnimation];
	else		   pSAnimation = &m_pCModel->GetModel()->m_SAnimation.SAnimation[0];

	// Set current frames
	m_iFrame = iFrame;

	// Check wrapping	
	if (m_iAnimationFlags & ASeModelAniFlagLoop) {
		if (m_iFrame <  pSAnimation->iFirstFrame) m_iFrame = pSAnimation->iLastFrame - 1;
		if (m_iFrame >= pSAnimation->iLastFrame)  m_iFrame = pSAnimation->iFirstFrame;
	} else {
		if (m_iFrame <  pSAnimation->iFirstFrame) m_iFrame = pSAnimation->iFirstFrame;
		if (m_iFrame >= pSAnimation->iLastFrame)  m_iFrame = pSAnimation->iLastFrame - 1;
	}

	// Set next frame
	if (m_iAnimationFlags & ASeModelAniFlagReverse) m_iNextFrame = iFrame - 1;
	else											m_iNextFrame = iFrame + 1;

	// Check wrapping	
	if (m_iAnimationFlags & ASeModelAniFlagLoop) {
		if (m_iNextFrame <  pSAnimation->iFirstFrame) m_iNextFrame = pSAnimation->iLastFrame - 1;
		if (m_iNextFrame >= pSAnimation->iLastFrame)  m_iNextFrame = pSAnimation->iFirstFrame;
	} else {
		if (m_iNextFrame <  pSAnimation->iFirstFrame) m_iNextFrame = pSAnimation->iFirstFrame;
		if (m_iNextFrame >= pSAnimation->iLastFrame)  m_iNextFrame = pSAnimation->iLastFrame - 1;
	}
}

/*
	Returns the whole number of animation frames
*/
int ASTModelHandler::GetAnimaionFrames() const
{
	if (!m_pCModel || !m_pCModel->GetModel()) return -1;
	else									  return m_pCModel->GetModel()->m_SHeader.iFrames;
}

/*
	Sets the animation speed
*/
void ASTModelHandler::SetAnimationSpeed(const float fAnimationSpeed)
{
	m_fAnimationSpeed = fAnimationSpeed;
}

/*
	Returns the animation speed
*/
float ASTModelHandler::GetAnimationSpeed() const
{
	if (!m_pCModel || !m_pCModel->GetModel()) return -1;
	else									  return m_fAnimationSpeed;
}

/*
	Returns the ID of a animation
*/
int ASTModelHandler::GetAnimationID(const char* pszName, const bool bErrorLogMessage) const
{
	if (!m_pCModel || !m_pCModel->GetModel()) return -1;

	for (int i = 0; i < m_pCModel->GetModel()->m_SAnimation.iNumber; i++)
		if (!stricmp(m_pCModel->GetModel()->m_SAnimation.SAnimation[i].szName, pszName))
			return i;

	if (bErrorLogMessage) _AS::CLog.Output("Couldn't find animation '%s' in model '%s'!", pszName, m_pCModel->GetFilename());

	return -1;
}

/*
	Animates the model
*/
bool ASTModelHandler::Animate()
{
	ASTMD2Animation* pSAnimation;

	if (!m_bActive || !m_pCModel || !m_pCModel->GetModel()) return true;

	// Check if the animation should be played
	if (!(m_iAnimationFlags & ASeModelAniFlagPlay)) return false;

	// Check if the model handler is bind to another model handler
	if (m_pCModelHandler) {
		if (m_pCModelHandler->m_iFrame < m_pCModel->GetModel()->m_SAnimation.SAnimation[m_iAnimation].iLastFrame)
			m_iFrame     = m_pCModelHandler->m_iFrame;
		if (m_pCModelHandler->m_iNextFrame < m_pCModel->GetModel()->m_SAnimation.SAnimation[m_iAnimation].iLastFrame) {
			m_iNextFrame = m_pCModelHandler->m_iNextFrame;
			m_fTime = m_pCModelHandler->m_fTime;
		}
	
		UpdateBinded();
		
		return false;
	}
	
	// Check if the animation is valid
	if (m_iAnimation < 0) m_iAnimation = 0;
	if (m_iAnimation >= m_pCModel->GetModel()->m_SAnimation.iNumber) m_iAnimation = m_pCModel->GetModel()->m_SAnimation.iNumber - 1;
	pSAnimation = &m_pCModel->GetModel()->m_SAnimation.SAnimation[m_iAnimation];

	// Perform animation
	if (m_iAnimationFlags & ASeModelAniFlagReverse) { // Play reversed
		// Interpolate to the next frame
		m_fTime -= _AS::CTimer.GetTimeDifference() * 10 * m_fStandardAnimationSpeed * m_fAnimationSpeed;
		if (m_fTime <=  0.f) {
			while (m_fTime < 0.f) m_fTime += 1.f;
			if (m_iFrame <= pSAnimation->iFirstFrame) {
				if (m_iAnimationFlags & ASeModelAniFlagLoop) m_iFrame = pSAnimation->iLastFrame - 1;
			} else m_iFrame--;

			// Get the next frame
			if (m_iNextFrame <= pSAnimation->iFirstFrame) {
				if (m_iAnimationFlags & ASeModelAniFlagLoop) m_iNextFrame = pSAnimation->iLastFrame - 1;
			} else m_iNextFrame = m_iFrame - 1;
		}
	} else { // Play normal
		// Interpolate to the next frame
		m_fTime += _AS::CTimer.GetTimeDifference() * 10 * m_fStandardAnimationSpeed * m_fAnimationSpeed;
		if (m_fTime >=  1.f) {
			while (m_fTime > 1.f) m_fTime -= 1.f;
			if (m_iFrame >= pSAnimation->iLastFrame - 1) {
				if (m_iAnimationFlags & ASeModelAniFlagLoop) m_iFrame = pSAnimation->iFirstFrame;
			} else m_iFrame++;

			// Get the next frame
			if (m_iNextFrame >= pSAnimation->iLastFrame - 1) {
				if (m_iAnimationFlags & ASeModelAniFlagLoop) m_iNextFrame = pSAnimation->iFirstFrame;
			} else m_iNextFrame = m_iFrame + 1;
		}
	}

	// Check wrapping
	if (m_iFrame	 < pSAnimation->iFirstFrame) m_iFrame     = pSAnimation->iFirstFrame;
	if (m_iNextFrame < pSAnimation->iFirstFrame) m_iNextFrame = pSAnimation->iFirstFrame;
	if (m_iFrame	 > pSAnimation->iLastFrame)	 m_iFrame     = pSAnimation->iLastFrame;
	if (m_iNextFrame > pSAnimation->iLastFrame)  m_iNextFrame = pSAnimation->iLastFrame;

	// Update bindet models
	UpdateBinded();

	return false;
}

/*
	Binds the model handler to an other model handler
*/
bool ASTModelHandler::BindTo(ASTModelHandler* pCModelHandler)
{
	if (!pCModelHandler) return true;

	m_pCModelHandler = pCModelHandler;
	m_pCModelHandler->m_lstModelHandler.Add(this);

	return false;
}

/*
	Sets the models owner entity
*/
bool ASTModelHandler::SetEntity(ASTEntity* pCEntity)
{
	// Check pointer
	if (!pCEntity) return true;

	m_pCEntity = pCEntity;

	return false;
}

/*
	Checks whether the model is in the frustum or not
*/
bool ASTModelHandler::InFrustum() const
{
	return _AS::CFrustum.IsCubeIn(m_fBoundingBox);
}

/*
	Gets the models bounding box
*/
void ASTModelHandler::GetBoundingBox(ASBOUNDINGBOX& pfBoundingBox)
{
	memcpy(pfBoundingBox, m_fBoundingBox, sizeof(ASBOUNDINGBOX));
}

/*
	Gets the models static bounding box
*/
void ASTModelHandler::GetStaticBoundingBox(ASBOUNDINGBOX& pfBoundingBox)
{
	memcpy(pfBoundingBox, m_fStaticBoundingBox, sizeof(ASBOUNDINGBOX));
}

/*
	Returns the general model radius
*/
float ASTModelHandler::GetRadius() const
{
	return m_fRadius;
}

/*
	Sets the general model radius
*/
void ASTModelHandler::SetRadius(const float fRadius)
{
	m_fRadius = fRadius;
}

/*
	Returns the vertex with the given ID
*/
bool ASTModelHandler::GetVertex(const int iVertex, ASTVector3D& pvVertex) const
{
	if (!m_pCModel || !m_pCModel->GetModel()) true;
	if (iVertex < 0 || iVertex > m_pCModel->GetModel()->m_SHeader.iVertices) return true;

	pvVertex = m_pfVertex[iVertex];

	return false;
}

/*
	Transform the model data into world space
*/
void ASTModelHandler::TransformToWorldSpace()
{
	if (!m_pCModel || !m_pCModel->GetModel()) return;
	if (!m_pCEntity) return;

	ASFLOAT3* pfVertexT, *pfLastVertexT, *pfNormalT;
	ASTMatrix4x4 mM;
	ASTVector3D vVT, vVTT, vEntityPos, vEntityScale;
	ASTMatrix4x4 mObject;

	// Get inverted entity rotation matrix
	mM = m_pCEntity->GetRotMatrix();
	mM.Invert();

	// Model rotation
	mObject.Rotate(m_vRot.fX, m_vRot.fY, m_vRot.fZ);

	pfVertexT	  = &m_pfVertex[0];
	pfLastVertexT = &m_pfVertex[m_pCModel->GetModel()->m_SHeader.iVertices];
	pfNormalT	  = &m_pfNormal[0];
	vEntityPos    = m_pCEntity->GetPos();
	vEntityScale  = m_pCEntity->GetScale();

	// Transform vertices & normals
	if (!m_bObjectSpace) {
		for (; pfVertexT < pfLastVertexT; pfVertexT++, pfNormalT++)	{
			// World space
			vVTT.Rotate(mM, ASTVector3D(*pfVertexT));
			vVTT *= vEntityScale;
			vVTT += vEntityPos;
			(*pfVertexT)[X] = vVTT.fX;
			(*pfVertexT)[Y] = vVTT.fY;
			(*pfVertexT)[Z] = vVTT.fZ;

			// Normal
			vVT.Rotate(mM, ASTVector3D(*pfNormalT));
			vVT.Normalize();
			(*pfNormalT)[X] = vVT.fX;
			(*pfNormalT)[Y] = vVT.fY;
			(*pfNormalT)[Z] = vVT.fZ;
		}
	} else {
		for (; pfVertexT < pfLastVertexT; pfVertexT++, pfNormalT++)	{
			// Object space
			(*pfVertexT)[X] *= m_vScale.fX;
			(*pfVertexT)[Y] *= m_vScale.fY;
			(*pfVertexT)[Z] *= m_vScale.fZ;
			(*pfVertexT)[X] += m_vPos.fX;
			(*pfVertexT)[Y] += m_vPos.fY;
			(*pfVertexT)[Z] += m_vPos.fZ;
			vVT.Rotate(mObject, ASTVector3D(*pfVertexT));

			// World space
			vVTT.Rotate(mM, vVT);
			vVTT *= vEntityScale;
			vVTT += vEntityPos;
			(*pfVertexT)[X] = vVTT.fX;
			(*pfVertexT)[Y] = vVTT.fY;
			(*pfVertexT)[Z] = vVTT.fZ;

			// Normal
			vVT.Rotate(mObject, ASTVector3D(*pfNormalT));
			vVT.Rotate(mM, vVT);
			vVT.Normalize();
			(*pfNormalT)[X] = vVT.fX;
			(*pfNormalT)[Y] = vVT.fY;
			(*pfNormalT)[Z] = vVT.fZ;
		}
	}
}

/*
	Updates the bounding boxes
*/
void ASTModelHandler::UpdateBoundingBoxes()
{
	ASFLOAT3* pfVertexT, *pfLastVertexT;
	ASTVector3D vEntityPos, vEntityScale;
	int i;

	if (!m_pCModel || !m_pCModel->GetModel()) return;
	if (!m_pCEntity) return;
	vEntityPos   = m_pCEntity->GetPos();
	vEntityScale = m_pCEntity->GetScale();

	if (!m_bAutoVisibilityBox) {
		for (i = 0; i < 3; i++) {
			m_fBoundingBox[0][i] = m_fVisibilityBoundingBox[0][i] * vEntityScale.fV[i] + vEntityPos.fV[i];
			m_fBoundingBox[1][i] = m_fVisibilityBoundingBox[1][i] * vEntityScale.fV[i] + vEntityPos.fV[i];
		}

		return;
	}

	// Initialize the bounding box
	for (i = 0; i < 3; i++) {
		m_fBoundingBox[0][i] = 99999.f;
		m_fBoundingBox[1][i] = -99999.f;
	}

	// Get bounding box
	pfVertexT	  = &m_pfVertex[0];
	pfLastVertexT = &m_pfVertex[m_pCModel->GetModel()->m_SHeader.iVertices];
	for (; pfVertexT < pfLastVertexT; pfVertexT++)	{
		for(i = 0; i < 3; i++) {
			if ((*pfVertexT)[i] < m_fBoundingBox[0][i])
				m_fBoundingBox[0][i] = (*pfVertexT)[i];
			else if ((*pfVertexT)[i] > m_fBoundingBox[1][i])
				m_fBoundingBox[1][i] = (*pfVertexT)[i];
		}
	}
}

/*
	Performs the cel shading
*/
void ASTModelHandler::PerformCelShading()
{
	if (!m_pCModel || !m_pCModel->GetModel()) return;
	if (!_AS::CConfig.IsComicStyle() || !_AS::CConfig.IsComicCelShading() || !m_pCEntity)
		return;

	ASFLOAT3* pfVertexT, *pfLastVertexT, *pfNormalT;
	ASTVector3D vLightDir;
	ASTLight* pCLight;
	float* pfTextureCoordinateT,
		 * pfLastTextureCoordinateT;

	// Reset texture coordinates
	pfTextureCoordinateT     = &m_pfTextureCoordinate[0];
	pfLastTextureCoordinateT = &m_pfTextureCoordinate[m_pCModel->GetModel()->m_SHeader.iVertices];
	for (; pfTextureCoordinateT < pfLastTextureCoordinateT; pfTextureCoordinateT++)
		*pfTextureCoordinateT = 0.f;

	// Lighting
	pCLight = _AS::CEntityManager.FindFirstLight();
	while (pCLight) {
		// Does the light influences the cel shading?
		if (pCLight->GetFlags() & ASeLightFlagCelShading) {
			// Ambiente light
			if (pCLight->GetFlags() & ASELightFlagAmbient) {
				pfTextureCoordinateT     = &m_pfTextureCoordinate[0];
				pfLastTextureCoordinateT = &m_pfTextureCoordinate[m_pCModel->GetModel()->m_SHeader.iVertices];
				for (; pfTextureCoordinateT < pfLastTextureCoordinateT; pfTextureCoordinateT++) {
					*pfTextureCoordinateT += pCLight->GetBrightness();

					// Couldn't it get brighter?
					if (*pfTextureCoordinateT >= 1.f) {
						*pfTextureCoordinateT = 1.f;

						break;
					}
				}
			}

			// Diffuse light
			if (pCLight->GetFlags() & ASELightFlagDiffuse) {
				pfVertexT			 = &m_pfVertex[0];
				pfNormalT			 = &m_pfNormal[0];
				pfLastVertexT		 = &m_pfNormal[m_pCModel->GetModel()->m_SHeader.iVertices];
				pfTextureCoordinateT = &m_pfTextureCoordinate[0];
				for (; pfNormalT < pfLastVertexT; pfVertexT++, pfNormalT++, pfTextureCoordinateT++) {
					// Get light direction
					vLightDir = (pCLight->GetPos() - ASTVector3D(*pfVertexT)).Normalize();

					*pfTextureCoordinateT += ASDotProduct(*pfNormalT, vLightDir.fV) * pCLight->GetBrightness();

					// Couldn't it get brighter?
					if (*pfTextureCoordinateT >= 1.f) {
						*pfTextureCoordinateT = 1.f;

						break;
					}
				}
			}
		}
		pCLight = _AS::CEntityManager.FindNextLight();
	}
}

/*
	Update all stuff which is binded with this model handler
*/
void ASTModelHandler::UpdateBinded()
{
	ASTLinkedListElement<ASTModelHandler*>* pSListElement;

	// Update model handlers which are binded to this one
	pSListElement = m_lstModelHandler.FindFirst();
	while (pSListElement) {
		if (pSListElement->Data) pSListElement->Data->Animate();
		pSListElement = m_lstModelHandler.FindNext();
	}
}

/*
	Initializes the model handler
*/
void ASTModelHandler::Init()
{
	m_bActive		   = false;
	m_pCModel		   = NULL;
	m_bNoComicStyle    = false;
	m_iFlags		   = 0;
	m_iAnimationFlags  = 0;
	m_iAnimation	   = 0;
	m_iFrame		   = 0;
	m_iNextFrame	   = 0;
	m_fTime			   = 0.f;
	m_fAnimationSpeed  = 1.f;
	m_pCModelHandler   = NULL;
	m_pCEntity		   = NULL;

	m_pfVertex			  = NULL;
	m_pfNormal			  = NULL;
	m_pfTextureCoordinate = NULL;
	memset(&m_fBoundingBox,    0, sizeof(ASBOUNDINGBOX));
	memset(&m_CCollisionMesh,  0, sizeof(ASTCollisionMesh));
	memset(&m_lstModelHandler, 0, sizeof(ASTLinkedList<ASTModelHandler*>));

	m_fSilhouetteWidthFactor  = 1.f;
	m_fStandardAnimationSpeed = 1.f;
	m_vPos					  = 0.f;
	m_vRot					  = 0.f;
	m_vScale				  = 1.f;
	memset(&m_fStaticBoundingBox, 0, sizeof(ASBOUNDINGBOX));
	m_bCreateCollisionMesh = false;
	m_fRadius			   = 0.f;
	m_bAutoVisibilityBox   = false;
	m_bBackfaceCulling     = false;
	m_bCullFace            = false;
	m_bObjectSpace		   = false;

	m_bForceUpdate = true;
}
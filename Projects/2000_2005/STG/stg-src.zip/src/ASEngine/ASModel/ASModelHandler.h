/*
	File: ASModelHandler.h

	Description: Model handler
*/


#ifndef __ASMODELHANDLER_H__
#define __ASMODELHANDLER_H__


// Predefinitions
typedef class ASTEntity ASTEntity;


// Definitions
enum ASEModelHandlerFlags {
	ASeModelHandlerFlagShowBoundingBox   = 1,	// Should the model bounding box be shown?
	ASeModelHandlerFlagShowVertices      = 2,	// Show vertices
	ASeModelHandlerFlagShowNormals       = 4,	// Show normals
	ASeModelHandlerFlagShowVertexNumbers = 8,	// Show nertex numbers
};
enum ASEModelAniFlags {
	ASeModelAniFlagPlay    = 1,	// Playback animation
	ASeModelAniFlagLoop    = 2,	// Loop animation
	ASeModelAniFlagReverse = 4,	// Playback animation in reversed order
};


// Classes
typedef class ASTModelHandler {

	friend ASTModel;
	friend ASTMd2Model;
	friend ASTEntity;


	public:
		/*
			Gets the model handler animation flags

			Returns:
				int -> Model handler flags
		*/
		AS_API int GetFlags() const;
		
		/*
			Sets the model handler flags

			Parameters:
				int iFlags -> Model handler flags which should be set
		*/
		AS_API void SetFlags(const int iFlags);

		/*
			Gets the model handler flags

			Returns:
				int -> Model handler animation flags
		*/
		AS_API int GetAnimationFlags() const;
		
		/*
			Sets the model handler animation flags

			Parameters:
				int iAnimationFlags -> Model handler animation flags which should be set
		*/
		AS_API void SetAnimationFlags(const int iAnimationFlags);
		
		/*
			Returns whether the model is active or not

			Returns:
				bool -> 'true' if the model is active else 'false'
		*/
		AS_API bool IsActive() const;

		/*
			Activeate / deactivates the model

			Parameters:
				bool bActive -> Should the model be active?
		*/
		AS_API void SetActive(const bool bActive = true);

		/*
			Constructor

			Parameters:
				char* pszFilename -> Model filename

			Notes:
				- Filename: The standard model directory will be used normally but you
							are also allowed to use your own directories
		*/
		AS_API ASTModelHandler(const char* pszFilename = ASSTANDARDMODEL);

		/*
			Destructor
		*/
		AS_API ~ASTModelHandler();

		/*
			Loads a model

			Parameters:
				char* pszFilename   -> Model filename

			Returns:
				bool -> 'false' if all went fine else 'true'

			Notes:
				- Filename: The standard model directory will be used normally but you
							are also allowed to use your own directories
		*/
		AS_API bool Load(const char* pszFilename = ASSTANDARDMODEL);

		/*
			Loads the model configuration of this handler
		*/
		AS_API void LoadConfiguration();

		/*
			Returns if the model handler has a model or not	

			Returns:
				bool -> 'true' if the model handler has a model else 'false'
		*/
		AS_API bool IsLoaded() const;

		/*
			Unloads the model

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Unload();

		/*
			Returns the model handler model

			Returns:
				ASTModel* -> Pointer to the model handlers model
		*/
		AS_API ASTModel* GetModel() const;

		/*
			Returns a pointer to the collision mesh

			Returns:
				ASTCollisionMesh* -> Pointer to the models collision mesh
		*/
		AS_API ASTCollisionMesh* GetCollisionMesh();

		/*
			Updates the visibility bounding boxes and the model

			Parameters:
				bool bForceModelUpdate -> Should the model data be updated in every case?

			Returns:
				bool -> 'true' if the model is visible else 'false'

			Notes:
				- If the model is visible, the current vertex positions are computed
		*/
		AS_API bool UpdateVisibility(const bool bForceModelUpdate = false);

		/*
			Draws the model

			Parameters:
				bool bUseModelTexture -> If 'true' the models standard texture will be used
				bool bFrustumTest	  -> Should a frustum test be performed? (normaly done by UpdateVisibility())

			Returns:
				bool -> 'false' if all went fine else 'true' (e.g. if its not in the frustum)
		*/
		AS_API bool Draw(const bool bUseModelTexture = true, const bool bFrustumTest = false);

		/*
			Sets the current animation

			Parameters:
				int iAnimation   -> The ID of the animation which should be played
				bool bRestart    -> Should be animation be restarted if it is already played?
				bool bResetTimer -> Reset the animation timer?

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool SetAnimation(const int iAnimation = 0, const bool bRestart = false, const bool bResetTimer = true);

		/*
			Returns the current animation

			Returns:
				int -> The ID of the current animation
		*/
		AS_API int GetAnimation() const;

		/*
			Sets the animation speed

			Parameters:
				float fAnimationSpeed -> Animation speed
		*/
		AS_API void SetAnimationSpeed(const float fAnimationSpeed = 1.f);

		/*
			Returns the animation speed

			Returns:
				float -> Animation speed
		*/
		AS_API float GetAnimationSpeed() const;
		
		/*
			Returns the ID of a animation

			Parameters:
				char* pszName		  -> Animation name
				bool bErrorLogMessage -> Write an error message into the log?

			Returns:
				int -> The animation ID. '-1' if it there was an error.
		*/
		AS_API int GetAnimationID(const char* pszName, const bool bErrorLogMessage = true) const;

		/*
			Animates the model

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Animate();

		/*
			Returns the current animation frame

			Parameters:
				bool bRelative -> Relative frame to animation of the absolute frame number?

			Returns:
				int -> The current animation frame
		*/
		AS_API int GetAnimationFrame(const bool bRelative = true) const;

		/*
			Returns if the current animation frame is the last frame from the animation

			Parameters:
				bool bRelative -> Relative frame to animation of the absolute frame number?

			Returns:
				bool -> 'true' if the current animation frame is the last animation frame else 'false'
		*/
		AS_API bool IsLastAnimationFrame(const bool bRelative = true) const;

		/*
			Sets the current animation frame

			Parameters:
				int iFrame       -> The frame which should be set
				bool bRelative   -> Relative frame to animation of the absolute frame number?
				bool bResetTimer -> Reset the animation timer?
		*/
		AS_API void SetAnimationFrame(const int iFrame, const bool bRelative = false, const bool bResetTimer = true);

		/*
			Returns the whole number of animation frames

			Returns:
				int -> The whole number of animation frames
		*/
		AS_API int GetAnimaionFrames() const;

		/*
			Binds the model handler to an other model handler

			Parameter:
				ASTModelHandler* pCModelHandler -> Pointer to the model handler this
												   model handler should be binded with

			Returns:
				bool -> 'false' if all went fine else 'true'

			Notes:
				- Use this function to connect different models
				- For instance bind a weapon model to a actor model
		*/
		AS_API bool BindTo(ASTModelHandler* pCModelHandler);

		/*
			Sets the models owner entity

			Parameters:
				ASTEntity* pCEntity -> Pointer to the owner entity

			Returns:
				bool -> 'false' if all went fine else 'true'
			
			Notes:
				- You should always give the model handlers a pointer to their owner entity
				- The owner entity is e.g. required to compute the comic silhouette width
		*/
		AS_API bool SetEntity(ASTEntity* pCEntity);

		/*
			Checks whether the model is in the frustum or not

			Returns:
				 bool -> 'true' if the model is in the frustum else 'false'
		*/
		AS_API bool InFrustum() const;

		/*
			Gets the models bounding box

			Parameters:
				ASFLOAT3& pfBoundingBox -> Will receive the bounding box
		*/
		AS_API void GetBoundingBox(ASBOUNDINGBOX& pfBoundingBox);

		/*
			Gets the models static bounding box

			Parameters:
				ASFLOAT3& pfBoundingBox -> Will receive the static bounding box
		*/
		AS_API void GetStaticBoundingBox(ASBOUNDINGBOX& pfBoundingBox);

		/*
			Returns the general model radius

			Returns:
				float -> The general model radius
		*/
		AS_API float GetRadius() const;

		/*
			Sets the general model radius

			Parameter:
				floats fRadius -> The general model radius
		*/
		AS_API void SetRadius(const float fRadius);

		/*
			Returns the vertex with the given ID

			Parameters:
				int iVertex			  -> ID of the vertex
				ASTVector3D& pvVertex -> The vertex with the given ID

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool GetVertex(const int iVertex, ASTVector3D& pvVertex) const;


	private:
		bool			  m_bActive;			// Is the model active?
		ASTModel*		  m_pCModel;			// Pointer to the model this handler uses
		ASTTextureHandler m_CTextureHandler;	// Texture handler holding the models standard texture
		bool			  m_bNoComicStyle;		// Should the model never be drawn in comic style?
		int				  m_iFlags;				// Model handler flags
		int				  m_iAnimationFlags;	// Animation flags
		int				  m_iAnimation;			// The current model Animation
		int				  m_iFrame;				// Current frame
		int				  m_iNextFrame;			// Next frame
		float			  m_fTime;				// Interpolation timer (0-1)
		float			  m_fAnimationSpeed;	// Animation speed
		ASTModelHandler*  m_pCModelHandler;		// The model handler on which this model handler is binded to
		ASTEntity*		  m_pCEntity;			// Pointer to the owner entity

		// Precomputed model frame data for faster rendering and some other purposes
		ASFLOAT3*     m_pfVertex;				// A list of all vertices
		ASFLOAT3*     m_pfNormal;				// All vertex normals
		float*	      m_pfTextureCoordinate;	// Additional texture coordinates for each vertex
		ASBOUNDINGBOX m_fBoundingBox;			// The models current bounding box

		bool		     m_bCreateCollisionMesh;
		ASTCollisionMesh m_CCollisionMesh;

		ASTLinkedList<ASTModelHandler*> m_lstModelHandler; // A list of model handler which are bindet to this model handler

		float		  m_fSilhouetteWidthFactor;		// Silhouette width factor 
		float		  m_fStandardAnimationSpeed;	// Models standard animation speed
		ASBOUNDINGBOX m_fStaticBoundingBox;			// Static model collision bounding box
		bool		  m_bAutoVisibilityBox;			// Should the visibility box be calculated automatically?
		ASBOUNDINGBOX m_fVisibilityBoundingBox;		// Static bounding box used for the visibility determination
		float		  m_fRadius;					// General radius
		bool		  m_bBackfaceCulling;			// Should the backface culling be active?
		bool		  m_bCullFace;					// Which side should be culled? 0 = front, 1 = back

		bool		  m_bObjectSpace;				// Must the object space be transformed? (performance!!)
		ASTVector3D	  m_vPos;						// Position
		ASTVector3D	  m_vRot;						// Rotation
		ASTVector3D   m_vScale;						// Scale

		// Update data
		bool  m_bForceUpdate;
		int   m_iFrameT, m_iNextFrameT;
		float m_fTimeT;
		ASTVector3D vEntityPosT, vEntityRotT, vEntityScaleT;


		/*
			Transform the model data into world space
		*/
		void TransformToWorldSpace();

		/*
			Updates the bounding boxes
		*/
		void UpdateBoundingBoxes();

		/*
			Performs the cel shading
		*/
		void PerformCelShading();

		/*
			Update all stuff which is binded with this model handler
		*/
		void UpdateBinded();

		/*
			Initializes the model handler
		*/
		void Init();


} ASTModelHandler;


#endif // __ASMODELHANDLER_H__
/*
	File: ASModelManager.h

	Description: Model manager
*/


#ifndef __ASMODELMANAGER_H__
#define __ASMODELMANAGER_H__


// Definitions
#define ASSTANDARDMODEL "standard.md2" // The standard model


// Predefinitions
typedef class ASTModel ASTModel;
typedef class ASTModelHandler ASTModelHandler;
typedef class ASTModelManager ASTModelManager;


// Inludes
#include "ASMd2Model.h"
#include "ASModel.h"
#include "ASModelHandler.h"


// Classes
typedef class ASTModelManager {

	friend _AS;
	friend ASTModelHandler;


	public:
		/*
			Constructor
		*/
		AS_API ASTModelManager();

		/*
			Destructor
		*/
		AS_API ~ASTModelManager();

		/*
			Returns if unused models should be removed automatically

			Returns:
				bool -> 'true' if unused models are unloaded automatically else 'false'
		*/
		AS_API bool GetUnloadUnusedModels() const;

		/*
			Sets if unused models should be removed automatically

			Parameters:
				bool bUnloadUnusedModels -> Should unused models be removed automatically?
		*/
		AS_API void SetUnloadUnusedModels(const bool bUnloadUnusedModels = true);

		/*
			Unload all unused models
		*/
		AS_API void UnloadUnusedModels();

		/*
			Returns a pointer to the model with the given ID
		
			Parameters:
				int iModelID -> The model ID

			Returns:
				ASTModel* -> Pointer to the model
		*/
		AS_API ASTModel* GetModel(const int iModelID);

		/*
			Returns a pointer to the Model with the given filename
		
			Parameters:
				char* pszFilename -> Model filename

			Returns:
				ASTModel* -> Pointer to the model
		*/
		AS_API ASTModel* GetModel(const char* pszFilename);

		/*
			Returns a pointer to the standard model
		
			Returns:
				const ASTModel* -> Pointer to the standard model
		*/
		AS_API ASTModel* GetStandardModel();
		
		/*
			Unload all models

			Notes:
				- All model handlers will loose their models
				- Use this function only if you really want to unload all models
				- The standard model will stay alive
		*/
		AS_API void Clear();

		/*
			Pre-loads a model with the given filename

			Parameters:
				char* pszFilename   -> The filename of the model

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool PreLoad(const char* pszFilename = NULL);

		/*
			Reloads all models

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool ReloadModels();

		/*
			Gets the valid model filename

			Parameters:
				char* pszFilename      -> Pointer to the source filename
				char* pszValidFilename -> Pointer to the falid filename

			Notes:
				- If 'pszFilename' is NULL the filename of the standard model will be returned
				- If the model isn't found in the given directory it will be searched in the
				  standard model directory
		*/
		AS_API void GetValidFilename(const char* pszFilename, char* pszValidFilename) const;

		/*
			Opens the model manager dialog

			Parameters:
				HWND hWnd -> Parent window handler

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool OpenDialog(const HWND hWnd);


	private:
		ASTModelHandler		     m_CStandardModel;		// The standard model
		ASTLinkedList<ASTModel*> m_lstModelList;		// Linked list of all models
		bool					 m_bUnloadUnusedModels;	// Should unused models be removed?


		/*
			Initialize the model manager

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Init();

		/*
			Loads a model with the given filename

			Parameters:
				ASTModelHandler* pCModelHandler -> Pointer to the model handler using this model
				char*			 pszFilename   -> The filename of the model

			Returns:
				bool -> 'false' if all went fine else 'true'

			Notes:
				- Filename: The standard model directory will be used normally but you
							are also allowed to use your own directories
				- If 'pCModelHandler' is NULL the model will be pre-loaded
		*/
		bool Load(ASTModelHandler* pCModelHandler, const char* pszFilename);

		/*
			Unloads a model

			Parameters:
				ASTModelHandler* pModelHandler -> Pointer to the model handler using this model

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Unload(ASTModelHandler* pCModelHandler);

		/*
			Unloads a model

			Parameters:
				ASTModel* pModel -> Pointer to the model

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Unload(ASTModel* pCModel);


		/*
			Unload all models

			Notes:
				- All model handlers will loose their models
				- Use this function only if you really want to unload all models
				- The standard model will be unloaded, too!
		*/
		void Cleanup();

		/*
			Model manager dialog procedure
		*/
		static LRESULT CALLBACK DialogProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);
		LRESULT Proc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);

		/*
			Updates all model relevant stuff
		*/
		void Update();


} ASTModelManager;


#endif // __ASMODELMANAGER_H__
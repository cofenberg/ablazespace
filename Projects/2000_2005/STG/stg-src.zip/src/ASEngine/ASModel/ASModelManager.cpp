/*
	File: ASModelManager.cpp
*/

#include <ASEngineDll.h>


/*
	Constructor
*/
ASTModelManager::ASTModelManager()
{
}

/*
	Destructor
*/
ASTModelManager::~ASTModelManager()
{
	Cleanup();
}

/*
	Returns if unused models should be removed automatically
*/
bool ASTModelManager::GetUnloadUnusedModels() const
{
	return m_bUnloadUnusedModels;
}

/*
	Sets if unused models should be removed automatically
*/
void ASTModelManager::SetUnloadUnusedModels(const bool bUnloadUnusedModels)
{
	m_bUnloadUnusedModels = bUnloadUnusedModels;
}

/*
	Unload all unused models
*/
void ASTModelManager::UnloadUnusedModels()
{
	ASTLinkedListElement<ASTModel*>* pSListElement;
	ASTModel* pCModelT;

	// Find the model
	pSListElement = m_lstModelList.FindFirst();
	while (pSListElement) {
		if (!pSListElement->Data->IsProtected() &&
			!pSListElement->Data->m_lstHandler.GetElements()) {
			pCModelT = pSListElement->Data;
			m_lstModelList.Remove(pCModelT);
			delete pCModelT;
		}
		pSListElement = m_lstModelList.FindNext();
	}
}

/*
	Returns a pointer to the model with the given ID
*/
ASTModel* ASTModelManager::GetModel(const int iModelID)
{
	if (iModelID < 0 || iModelID > m_lstModelList.GetElements()) return NULL;
	else return m_lstModelList[iModelID];
}

/*
	Returns a pointer to the model with the given filename
*/
ASTModel* ASTModelManager::GetModel(const char* pszFilename)
{
	ASTLinkedListElement<ASTModel*>* pSListElement;
	char szFilename[256];

	GetValidFilename(pszFilename, &szFilename[0]);
	pSListElement = m_lstModelList.FindFirst();
	while (pSListElement) {
		if (!stricmp(pSListElement->Data->GetFilename(), szFilename)) return pSListElement->Data;
		pSListElement = m_lstModelList.FindNext();
	}

	return NULL;
}

/*
	Returns a pointer to the standard model
*/
ASTModel* ASTModelManager::GetStandardModel()
{
	return m_CStandardModel.GetModel();
}

/*
	Unload all models
*/
void ASTModelManager::Clear()
{
	ASTLinkedListElement<ASTModel*>* pSListElement;
	ASTModel* pCModelT;

	// Remove all models
	pSListElement = m_lstModelList.FindFirst();
	while (pSListElement) {
		if (!pSListElement->Data->IsProtected()) {
			pCModelT = pSListElement->Data;
			m_lstModelList.Remove(pCModelT);
			delete pCModelT;
		}
		pSListElement = m_lstModelList.FindNext();
	}
}

/*
	Pre-loads a model with the given filename
*/
bool ASTModelManager::PreLoad(const char* pszFilename)
{
	return Load(NULL, pszFilename);
}

/*
	Reloads all models
*/
bool ASTModelManager::ReloadModels()
{
	ASTLinkedListElement<ASTModel*>* pSListElement;
	bool bError = false;

	pSListElement = m_lstModelList.FindFirst();
	while (pSListElement) {
		if (pSListElement->Data) if (pSListElement->Data->ReloadModel()) bError = true;
		pSListElement = m_lstModelList.FindNext();
	}

	return bError;
}

/*
	Gets the valid model filename
*/
void ASTModelManager::GetValidFilename(const char* pszFilename, char* pszValidFilename) const
{
	if (!pszFilename) {
		sprintf(pszValidFilename, "%s\\"ASSTANDARDMODEL, _AS::CFileSystem.GetModelsDirectory());
		_AS::CFileSystem.GetFullFilename(pszValidFilename);
	} else {
		// Check if this model could be loaded
		strcpy(pszValidFilename, pszFilename);
		_AS::CFileSystem.GetFullFilename(pszValidFilename);
		if (!_AS::CFileSystem.IsFilenameValid(pszValidFilename)) { // The file wasn't found!
			// Try to use the standard model directory
			sprintf(pszValidFilename, "%s\\%s", _AS::CFileSystem.GetModelsDirectory(), pszFilename);
			_AS::CFileSystem.GetFullFilename(pszValidFilename);
		}
	}
}

/*
	Initialize the model manager
*/
bool ASTModelManager::Init()
{
	bool bError;

	// Load the standard model
	_AS::CLog.Output("Initialize model manager");
	if (!(bError = m_CStandardModel.Load()))
		m_CStandardModel.GetModel()->m_bProtected = true;

	return bError;
}

/*
	Loads a model with the given filename
*/
bool ASTModelManager::Load(ASTModelHandler* pCModelHandler, const char* pszFilename)
{
	ASTLinkedListElement<ASTModel*>* pSListElement;
	ASTModel* pCModelT;
	char szFilename[256];

	// Get valid filename
	GetValidFilename(pszFilename, szFilename);

	// First check if the model is already loaded
	pSListElement = m_lstModelList.FindFirst();
	while (pSListElement) {
		if (!stricmp(pSListElement->Data->GetFilename(), szFilename)) { // The model is already loaded
			if (pCModelHandler) pSListElement->Data->Load(pCModelHandler, pszFilename);

			return false;
		}
		pSListElement = m_lstModelList.FindNext();
	}

	// Load the new model
	pCModelT = new ASTModel;
	if (pCModelT->Load(pCModelHandler, pszFilename) == -1) { // The model couldn't be loaded!
		if (pCModelT) delete pCModelT;
		if (!pCModelHandler) return true;
		if (m_CStandardModel.IsLoaded()) return pCModelHandler->Load();
		else							 return	true;
	}

	// Add the new model to the managers model list
	m_lstModelList.Add(pCModelT);

	return false;
}

/*
	Unloads a model
*/
bool ASTModelManager::Unload(ASTModelHandler* pCModelHandler)
{
	ASTLinkedListElement<ASTModel*>* pSListElement;
	ASTModel* pCModelT;
	int i;

	if (!pCModelHandler) return true;

	// Find the model
	pSListElement = m_lstModelList.FindFirst();
	while (pSListElement) {
		i = pSListElement->Data->Unload(pCModelHandler);
		if (i >= 0) return true;
		if (i == -2) { // Should the unused model be removed?
			pCModelT = pSListElement->Data;
			m_lstModelList.Remove(pCModelT);
			delete pCModelT;

			return false;
		}
		pSListElement = m_lstModelList.FindNext();
	}

	return false;
}

/*
	Unloads a model
*/
bool ASTModelManager::Unload(ASTModel* pCModel)
{
	if (pCModel->IsProtected() || m_lstModelList.IsElement(pCModel) < 0) return true;

	m_lstModelList.Remove(pCModel);
	delete pCModel;

	return false;
}

/*
	Unload all models
*/
void ASTModelManager::Cleanup()
{
	ASTLinkedListElement<ASTModel*>* pSListElement;
	ASTModel* pCModelT;

	_AS::CLog.Output("Cleanup model manager");

	// Remove all models
	pSListElement = m_lstModelList.FindFirst();
	while (pSListElement) {
		pCModelT = pSListElement->Data;
		m_lstModelList.Remove(pCModelT);
		delete pCModelT;
		pSListElement = m_lstModelList.FindNext();
	}
}

/*
	Updates all model relevant stuff
*/
void ASTModelManager::Update()
{
	// Check if the model manager dialog should be opened (Strg-m)
	if (_AS::CConfig.IsDebugMode() && _AS::CInput.IsKeyPressed(29) && 
		_AS::CInput.IsKeyHit(DIK_M))
		OpenDialog(_AS::CWindowManager.GetMainWindow()->GetWnd());
}
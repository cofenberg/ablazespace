/*
	File: ASModel.cpp
*/

#include <ASEngineDll.h>


/*
	Constructor
*/
ASTModel::ASTModel()
{
	memset(this, 0, sizeof(ASTModel));
}

ASTModel::ASTModel(ASTModelHandler* pSModelHandler, const char* pszFilename)
{
	memset(this, 0, sizeof(ASTModel));
	Load(pSModelHandler, pszFilename);
}

/*
	Destructor
*/
ASTModel::~ASTModel()
{
	Clear();
}

/*
	Returns the model name
*/
const char* ASTModel::GetFilename() const
{
	return m_szFilename;
}

/*
	Returns a pointer to the model itself
*/
ASTMd2Model* ASTModel::GetModel()
{
	return &m_CModel;
}

/*
	Sets the model protection state
*/
void ASTModel::SetProtected(const bool bProtected)
{
	if (_AS::CModelManager.GetStandardModel() == this) return;
	m_bProtected = bProtected;
}

/*
	Returns whether the model is protected or not
*/
bool ASTModel::IsProtected() const
{
	return m_bProtected;
}

/*
	Reloads the model
*/
bool ASTModel::ReloadModel()
{
	ASTLinkedListElement<ASTModelHandler*>* pListElement;
	bool bError = false;

	// Reload the model
	UnloadData();
	if (Load(NULL, m_szFilename)) bError = true;

	// Reload the model configuration of the model handlers using this model
	pListElement = m_lstHandler.FindFirst();
	while (pListElement) {
		pListElement->Data->LoadConfiguration();
		pListElement = m_lstHandler.FindNext();
	}

	return bError;
}

/*
	Loads the model
*/
int ASTModel::Load(ASTModelHandler* pSModelHandler, const char* pszFilename)
{
	bool bError;

	// Check if the model is already loaded
	if (m_CModel.m_bLoaded) {
		if (pSModelHandler) {
			pSModelHandler->m_pCModel = this;
			m_lstHandler.Add(pSModelHandler);
		}

		return m_lstHandler.GetElements();
	}

	// Get valid filename
	_AS::CModelManager.GetValidFilename(pszFilename, m_szFilename);

	_AS::CLog.Output("Load model: %s", m_szFilename);

	// Find out the type of the model and load it
	if (_AS::CFileSystem.IsFilenameEnding(m_szFilename, ASMD2_FILE)) bError = m_CModel.Load(m_szFilename);
	else {
		char szFilenameEnding[256];

		if (_AS::CFileSystem.GetFilenameEnding(m_szFilename, szFilenameEnding))
			_AS::CLog.Output("'%s' is an unkown model format!", szFilenameEnding);
		else _AS::CLog.Output("Unkown model format!");
		if (pSModelHandler) pSModelHandler->m_pCModel = _AS::CModelManager.GetStandardModel();

		return -1;
	}

	// Check if there was an error
	if (bError) {
		_AS::CLog.Output("Couldn't load this model!");
		if (pSModelHandler) pSModelHandler->m_pCModel = _AS::CModelManager.GetStandardModel();

		return -1;
	}
	
	// Add the model handler
	if (pSModelHandler) {
		pSModelHandler->m_pCModel = this;
		m_lstHandler.Add(pSModelHandler);
	}

	m_bLoaded = true;

	return m_lstHandler.GetElements();
}

/*
	Unload the model
*/
int ASTModel::Unload(ASTModelHandler* pSModelHandler)
{
	// Check if this model handler is listed in this model
	if (m_lstHandler.Remove(pSModelHandler)) return -1;

	// Set the model handlers model to NULL
	pSModelHandler->m_pCModel = NULL;

	// Is the model now unused?
	if (!_AS::CModelManager.GetUnloadUnusedModels() ||
		m_bProtected || !m_lstHandler.IsEmpty())
		return m_lstHandler.GetElements();

	// Setup model data
	UnloadData();

	return -2;
}

/*
	Unload the model immediately
*/
void ASTModel::Clear()
{
	ASTLinkedListElement<ASTModelHandler*>* pListElement;

	if (!m_bLoaded) return;

	// Unload model data
	UnloadData();

	// Update model handlers using this model
	pListElement = m_lstHandler.FindFirst();
	while (pListElement) {
		if (_AS::CModelManager.GetStandardModel() &&
			_AS::CModelManager.GetStandardModel() != this)
			pListElement->Data->Load(_AS::CModelManager.GetStandardModel()->GetFilename());
		else {
			pListElement->Data->m_pCModel = NULL;
			pListElement->Data->Unload();
		}
		pListElement = m_lstHandler.FindNext();
	}
	m_lstHandler.Clear();
}

/*
	Unload the model data
*/
void ASTModel::UnloadData()
{
	if (!m_bLoaded) return;

	_AS::CLog.Output("Delete model '%s'", m_szFilename);

	// Setup model data
	m_CModel.Unload();

	m_bLoaded = false;
}
 /*
	File: ASMd2Model.cpp
*/

#ifndef __ASMD2MODEL_H__
#define __ASMD2MODEL_H__


// Definitions
#define ASMD2MAXFRAMES	  512
#define ASMD2MAXFRAMESIZE (2048 * 4 + 128)


// Structures
typedef struct  {
   int iMagic; 
   int iVersion; 
   int iSkinWidth; 
   int iSkinHeight; 
   int iFrameSize; 
   int iSkins; 
   int iVertices; 
   int iTexCoords; 
   int iTriangles; 
   int iGlCommands; 
   int iFrames; 
   int iOffsetSkins; 
   int iOffsetTexCoords; 
   int iOffsetTriangles; 
   int iOffsetFrames; 
   int iOffsetGlCommands; 
   int iOffsetEnd; 

} ASTMd2Header;

typedef struct {
   BYTE szVertex[3];		// Vertex
   BYTE szLightNormalIndex; // Light normal index

} ASTMd2AliasTriangleVertex;

typedef struct {
   short iVertexIndices[3];		// Vertex indices
   short iTextureIndices[3];	// Texture indices

} ASTMd2Triangle;

typedef struct {
   float fScale[3];							// Scalation
   float fTranslate[3];						// Translation
   char  szName[16];						// Name
   ASTMd2AliasTriangleVertex SVertices[1];	// Vertices

} ASTMd2AliasFrame;

typedef struct {
   char		 szName[16];		// Frame name
   ASFLOAT3* pfVertex;			// Vertices
   ASFLOAT3* pfFaceNormal;		// Face normals
   ASFLOAT3* pfNormal;			// Vertex normals
   ASFLOAT3  fBoundingBox[2];	// Frame bounding box

} ASTMd2Frame;

typedef struct {
	char szName[16];	// Animation name
	int	 iFirstFrame;	// First frame
	int	 iLastFrame;	// Last frame

} ASTMD2Animation;

typedef struct {
	int				iNumber;					// The number of animations
	ASTMD2Animation SAnimation[ASMD2MAXFRAMES];	// The animations

} ASTMD2Animations;

typedef struct {
	bool bType;			// Triangle type (GL_TRIANGLE_STRIP / GL_TRIANGLE_FAN)
	int iVertices;		// The number of vertices
	int iVertex[64];	// Vertex ID's

} ASTMd2GLCommand;

typedef class ASTMd2Model {

	friend ASTModel;
	friend ASTModelHandler;

	public:
		/*
			Constructor
		*/
		ASTMd2Model();

		/*
			Loads a md2 model

			Parameters:
				char* pszFilename -> The filename of the md2 model

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Load(const char* pszFilename);

		/*
			Unloads the md2 model

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Unload();

		/*
			Computes the current bounding box

			Parameters:
				int		 iFrame1			 -> Current frame
				int		 iFrame2			 -> Next frame
				float	 fTime				 -> Interpolation time
				ASFLOAT3 (*pfBoundingBox)[2] -> Receives the current bounding box

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool GetCurrentBoundingBox(const int iFrame1, const int iFrame2, const float fTime, ASFLOAT3 (*pfBoundingBox)[2]);

		/*
			Precomputes the md2 model data

			Parameters:
				ASTModelHandler* pModelHandler -> Pointer to the model handler
				int				 iFrame1	   -> Current frame
				int				 iFrame2	   -> Next frame
				float			 fTime		   -> Interpolation time

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Precompute(ASTModelHandler* pModelHandler, const int iFrame1, const int iFrame2, const float fTime);

		/*
			Draws the precomputed md2 model

			Parameters:
				float fSilhouetteWidth -> Silhouette width

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool Draw(const float fSilhouetteWidth = 0.f);


	private:
		char m_szFilename[256]; // The filename of the md2 model
		bool m_bLoaded;			// Is the model loaded?
		
		ASTMd2Header	 m_SHeader;
		ASTMd2Triangle*  m_pSTriangles;
		ASTMd2Frame*     m_pSFrames;
		ASFLOAT2*		 m_pfTextureCoordinates;
		int				 m_iGLCommands;
		ASTMd2GLCommand* m_SGLCommand;
		ASTMD2Animations m_SAnimation;


		/*
			Gets the bounding box of a frame

			Parameters:
				int		 iFrame				 -> Frame ID
				ASFLOAT3 (*pfBoundingBox)[2] -> Receives the bounding box of the frame

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool GetBoundingBox(const int iFrame, ASFLOAT3 (*pfBoundingBox)[2]);

		/*
			Builds the animations of the md2 model
		*/
		void BuildAnimations();

		/*
			Computes the light normals
		*/
		void ComputeNormals();


} ASTMd2Model;


#endif // __ASMD2MODEL__
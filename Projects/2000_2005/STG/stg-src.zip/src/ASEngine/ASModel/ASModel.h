/*
	File: ASModel.h

	Description: Model
*/


#ifndef __ASMODEL_H__
#define __ASMODEL_H__


// Classes
typedef class ASTModel {

	friend ASTModelManager;
	friend ASTModelHandler;


	public:
		/*
			Constructor
		*/
		AS_API ASTModel();
		AS_API ASTModel(ASTModelHandler* pSModelHandler, const char* pszFilename = NULL);

		/*
			Destructor
		*/
		AS_API ~ASTModel();

		/*
			Returns the model name

			Returns:
				char* -> Pointer to the model filename
		*/
		AS_API const char* GetFilename() const;

		/*
			Returns a pointer to the model itself
			
			Returns:
				ASTMd2Model* -> Pointer to the model itself
		*/
		AS_API ASTMd2Model* GetModel();

		/*
			Sets the model protection state

			Parameters:
				bool bProtected -> Should the model be protected or not?

			Notes:
				- If the model is protected it will not be removed if the model manager
				  tries it (it's only removed if the application is shut down :)
				- The standard model is always protected because there must be at least one
				  model in the model manager
		*/
		AS_API void SetProtected(const bool bProtected = false);

		/*
			Returns whether the model is protected or not

			Returns:
				bool -> 'true' if the model is protected else 'false'
		*/
		AS_API bool IsProtected() const;

		/*
			Reloads the model

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		AS_API bool ReloadModel();


	private:
		char	    m_szFilename[256];	// The filename of the model
		bool	    m_bLoaded;			// Is the model loaded?
		bool	    m_bProtected;		// Is this model protected (couldn't be unloaded with normal functions)
		ASTMd2Model m_CModel;			// Model data

		ASTLinkedList<ASTModelHandler*> m_lstHandler; // Linked list of all model handlers
													  // using this model


		/*
			Loads the model

			Parameters:
				char*			 pszFilename	-> The filename of the model
				ASTModelHandler* pSModelHandler -> Pointer to the model handler using this model

			Returns:
				int -> The number of model handlers using this model

			Notes:
				- Filename: The standard model directory will be used normally but you
							are also allowed to use your own directories
		*/
		int Load(ASTModelHandler* pSModelHandler, const char* pszFilename = NULL);

		/*
			Unload the model

			Parameters:
				ASTModelHandler* pSModelHandler -> Pointer to the model handler using this model

			Returns:
				int -> The number of model handlers using this model.
					   If it is '-1' the given model handler wasn't listed in the models model handler list.
					   '-2' if the model is now unused.
		*/
		int Unload(ASTModelHandler* pSModelHandler);

		/*
			Unload the model immediately
		*/
		void Clear();

		/*
			Unload the model data
		*/
		void UnloadData();


} ASTModel;


#endif // __ASMODEL_H__
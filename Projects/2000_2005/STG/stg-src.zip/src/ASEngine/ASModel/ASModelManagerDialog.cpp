/*
	File: ASModelManagerDialog.cpp
*/

#include <ASEngineDll.h>
#include "..\resource.h"


// Variables
HWND hWndModelDialog;
ASTRendererHandler CModelPreviewRendererHandler;
ASTModel* pCSelectedModel;
ASFLOAT3 fModelViewPos, fModelViewRot;
ASTModelHandler* pCModelHandler;


/*
	Opens the model manager dialog
*/
bool ASTModelManager::OpenDialog(const HWND hWnd)
{
	bool bError = false;

	if (hWndModelDialog) return true;

	// Minimize the window
	if (hWnd) SendMessage(hWnd, WM_SYSCOMMAND, SC_MINIMIZE, 0);

	if(DialogBox(GetModuleHandle(ASMODULENAME), MAKEINTRESOURCE(IDD_MODELMANAGER), hWnd, (DLGPROC) DialogProc) == -1)
		bError = true;
	
	// Normalize the window
	if (hWnd) SendMessage(hWnd, WM_SIZE, SIZE_RESTORED, 0);

	return bError;
}

/*
	Model manager dialog procedure
*/
LRESULT CALLBACK ASTModelManager::DialogProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	return _AS::CModelManager.Proc(hWnd, iMessage, wParam, lParam);
}

LRESULT ASTModelManager::Proc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	ASTLinkedListElement<ASTModel*>* pSListElement;
	static POINT MousePos, OldMousePos;
    char *pszTemp, szTemp[256];
	ASTModel* pCModel;
	RECT Rect;
	int i;

	switch (iMessage) {
        case WM_INITDIALOG:
			_AS::CLog.Output("Open model manager dialog");
			hWndModelDialog = hWnd;

			// Init renderer handler
			CModelPreviewRendererHandler.Init(GetDlgItem(hWnd, ID_MODELMANAGER_VIEW), false);

			// Texts
			SetWindowText( hWnd,							     CText.Get(_T_ModelManager));
			SetDlgItemText(hWnd, IDC_MODELMANAGER_OK,		     CText.Get(_T_Ok));
			SetDlgItemText(hWnd, IDC_MODELMANAGER_LOAD,		     CText.Get(_T_Load));
			SetDlgItemText(hWnd, IDC_MODELMANAGER_UNLOAD,	     CText.Get(_T_Unload));
			SetDlgItemText(hWnd, IDC_MODELMANAGER_UNLOAD_UNUSED, CText.Get(_T_UnloadUnused));
			SetDlgItemText(hWnd, IDC_MODELMANAGER_UPDATE,        CText.Get(_T_Update));
			SetDlgItemText(hWnd, IDC_MODELMANAGER_RESET_VIEW,    CText.Get(_T_Reset));

			// Setup data
			SetTimer(hWnd, 1, 1, NULL);
			fModelViewPos[X] = fModelViewPos[Y] = 0.f;
			fModelViewPos[Z] = -10.f;
			fModelViewRot[X] = fModelViewRot[Y] = fModelViewRot[Z] = 0.f;
			pCSelectedModel = NULL;
			pCModelHandler = new ASTModelHandler;

		Init:
			if (!pCModelHandler) break;
			if (pCSelectedModel) {
				EnableWindow(GetDlgItem(hWnd, IDC_MODELMANAGER_UNLOAD), !pCSelectedModel->m_bProtected);
				pCModelHandler->Load(pCSelectedModel->m_szFilename);
			} else EnableWindow(GetDlgItem(hWnd, IDC_MODELMANAGER_UNLOAD), false);
			EnableWindow(GetDlgItem(hWnd, IDC_MODELMANAGER_UNLOAD_UNUSED), !GetUnloadUnusedModels());

			// Setup the model list
			SendDlgItemMessage(hWnd, ID_MODELMANAGER_LIST, LB_RESETCONTENT , 0, 0L);
			pSListElement = m_lstModelList.FindFirst();
			i = 0;
			while (pSListElement) {
				sprintf(szTemp, "%s (%s: %d)", pSListElement->Data->m_szFilename,
											   CText.Get(_T_Used),
											   pSListElement->Data->m_lstHandler.GetElements());
				SendDlgItemMessage(hWnd, ID_MODELMANAGER_LIST, LB_ADDSTRING, 0, (LPARAM) szTemp);
				if (pSListElement->Data == pCSelectedModel)
					SendDlgItemMessage(hWnd, ID_MODELMANAGER_LIST, LB_SETCURSEL, i, 0L);
				pSListElement = m_lstModelList.FindNext();
				i++;
			}

			BringWindowToTop(hWnd);
			UpdateWindow(hWnd);
			return true;

		case WM_TIMER:
			if (_AS::CRenderer.SetRenderingDevice(&CModelPreviewRendererHandler)) break;

			glEnable(GL_TEXTURE_2D);
			glDisable(GL_LIGHTING);
			glDisable(GL_FOG);
			glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

			if (pCSelectedModel) {
				glLoadIdentity();
				glTranslatef(fModelViewPos[X], fModelViewPos[Y], fModelViewPos[Z]);
				glRotatef(fModelViewRot[Z], 0.0f, 0.0f, 1.0f);
				glRotatef(fModelViewRot[Y], 0.0f, 1.0f, 0.0f);
				glRotatef(fModelViewRot[X], 1.0f, 0.0f, 0.0f);
				glScalef(0.025f, 0.025f, 0.025f);

				pCModelHandler->Draw();
				pCModelHandler->Animate();
			}

			CModelPreviewRendererHandler.Update();
			_AS::Update();
			break;

        case WM_LBUTTONDOWN: case WM_LBUTTONUP: case WM_RBUTTONDOWN:
        case WM_RBUTTONUP:   case WM_MOUSEMOVE:
			i = wParam;
			memcpy(&OldMousePos, &MousePos, sizeof(POINT));

			GetCursorPos(&MousePos);
			GetWindowRect(hWnd, &Rect);
			GetWindowRect(CModelPreviewRendererHandler.GetWnd(), &Rect);

			if (MousePos.x > Rect.left && MousePos.x < Rect.right &&
			    MousePos.y > Rect.top  && MousePos.y < Rect.bottom) {
				// The mouse is over the window enable view control
				if (i & MK_LBUTTON && i & MK_RBUTTON)
					fModelViewPos[Z] -= (float) (MousePos.x-OldMousePos.x+MousePos.y-OldMousePos.y) / 5;
				else {
					if (i & MK_RBUTTON) {
						fModelViewPos[X] -= (float) (OldMousePos.x - MousePos.x   ) / 10;
						fModelViewPos[Y] -= (float) (MousePos.y    - OldMousePos.y) / 10;
					} else {
						if (i & MK_LBUTTON) {
							fModelViewRot[X] -= (float) (MousePos.y    - OldMousePos.y);
							fModelViewRot[Y] -= (float) (OldMousePos.x - MousePos.x);
						}
						else if (i & MK_MBUTTON) fModelViewRot[Z] -= (float) (OldMousePos.x - MousePos.x);
					}
				}

				if (i & MK_LBUTTON && i & MK_RBUTTON)
					fModelViewPos[Z] -= (float) (MousePos.x - OldMousePos.x + MousePos.y - OldMousePos.y) / 5;
				else if(i & MK_RBUTTON) {
						fModelViewPos[X] -= (float) (OldMousePos.x - MousePos.x)    / 10;
						fModelViewPos[Y] -= (float) (MousePos.y    - OldMousePos.y) / 10;
					 }
			}
			break;

        case WM_COMMAND:
            switch (LOWORD(wParam)) {
                case IDC_MODELMANAGER_OK:
					if (!hWndModelDialog) break;
					_AS::CLog.Output("Close model manager dialog");
					hWndModelDialog = NULL;
					KillTimer(hWnd, 1);
					if (pCModelHandler) {
						delete pCModelHandler;
						pCModelHandler = NULL;
					}
					pCSelectedModel = NULL;
					CModelPreviewRendererHandler.DeInit();
					EndDialog(hWnd, false);

					return true;
				
				case IDC_MODELMANAGER_LOAD:
					KillTimer(hWnd, 1);
					strcpy(szTemp, _AS::CFileSystem.GetModelsDirectory());
					_AS::CFileSystem.GetFullFilename(szTemp);
					pszTemp = _AS::CFileSystem.GetFilenameDialog(hWnd, CText.Get(_T_LoadModel), ASMODEL_FILES, szTemp, true, true, NULL);
					SetTimer(hWnd, 1, 1, NULL);
					_AS::CFileSystem.InitGetFilename(&pszTemp);
					while (!_AS::CFileSystem.GetNextFilename(&pszTemp, szTemp))
						_AS::CModelManager.PreLoad(szTemp);
					goto Init;

				case IDC_MODELMANAGER_UNLOAD:
					if (!pCSelectedModel) break;
					if (pCSelectedModel->m_lstHandler.GetElements()) {
						KillTimer(hWnd, 1);
						sprintf(szTemp, "'%s': %s (%d)\n%s", pCSelectedModel->m_szFilename,
															 CText.Get(_T_ModelIsStillUsed),
															 pCSelectedModel->m_lstHandler.GetElements(),
															 CText.Get(_T_ContinueQuestionMark));
						if(MessageBox(hWnd, szTemp, CText.Get(_T_Question), MB_YESNO | MB_ICONINFORMATION) == IDNO) {
							SetTimer(hWnd, 1, 1, NULL);
							break;
						}
						SetTimer(hWnd, 1, 1, NULL);
					}
					Unload(pCSelectedModel);
					pCSelectedModel = NULL;
					goto Init;

				case IDC_MODELMANAGER_UNLOAD_UNUSED: UnloadUnusedModels(); goto Init;
				case IDC_MODELMANAGER_UPDATE: ReloadModels(); goto Init;

				case ID_MODELMANAGER_LIST:
					i = (int) SendDlgItemMessage(hWnd, ID_MODELMANAGER_LIST, LB_GETCURSEL, 0, 0L);
					if (!(pCModel = GetModel(i))) break;
					pCSelectedModel = pCModel;
					goto Init;

				case IDC_MODELMANAGER_RESET_VIEW:
					fModelViewPos[X] = fModelViewPos[Y] = 0.f;
					fModelViewPos[Z] = -10.f;
					fModelViewRot[X] = fModelViewRot[Y] = fModelViewRot[Z] = 0.f;
					break;
			}
			break;

		case WM_CLOSE: case WM_DESTROY: SendMessage(hWnd, WM_COMMAND, IDC_MODELMANAGER_OK, 0); break;
    }

    return false;
}
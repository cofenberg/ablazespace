/*
	File: ASEngineDll.h

	Description: Engine dll main header which is only used in the engine itself!
*/


#ifndef __ASENGINEDLL_H__
#define __ASENGINEDLL_H__


//Definitions
#ifndef ASENGINE_EXPORTS
#define ASENGINE_EXPORTS
#endif


// Includes
#include "ASEngine.h"


#endif // __ASENGINEDLL_H__
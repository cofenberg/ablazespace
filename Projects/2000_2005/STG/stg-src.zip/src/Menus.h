/*
	File: Menus.h

	Description: Menus
*/

#ifndef __MENUS_H__
#define __MENUS_H__


// Includes
#include "Highscore.h"


// Definitions
#define MENU_POINTS 23
#define TITEL_GRID_X_SIZE 20 // The width of the game title
#define TITEL_GRID_Y_SIZE 10 // The height of the game title


// Structures
typedef struct TMenuPoint {
	int		 iID;		// Menu point ID
	bool     bSelected; // Is this menu point current selected?
	float    fSize;		// The size of the text
	bool     bSize;		// For the size animation
	ASFLOAT3 fColor;	// The text color

} TMenuPoint;


// Classes
typedef class TMenus {

	public:
		/*
			Initializes the menu
		*/
		void Init();

		/*
			De-initializes the menu
		*/
		void DeInit();

		/*
			Draws the menus

			Returns:
				bool -> 'true' if the menus are active else 'false'
		*/
		bool Draw();

		/*
			Updates the menus

			Returns:
				bool -> 'true' if the menus are active else 'false'
		*/
		bool Update();

		/*
			Returns the menu blending

			Returns:
				float -> Menu blending
		*/
		float GetBlending() const;

		/*
			Activates the menu
		*/
		void Activate();

		/*
			Goes after the game into the highscore

			Parameters:
				int  iScore   -> Score that should be inserted
				bool bGameWon -> Is the game won?
		*/
		void EnterHighscore(const int iScore = -1, const bool bGameWon = false);

		/*
			Are the logos currently shown?

			Returns:
				bool -> 'true' if the logos are shown at the moment else 'false'
		*/
		bool IsLogos() const;


	private:
		bool  m_bIsInitialized;	// Is the menu initialized?
		float m_fMenuBlend;		// Menu blending
		float m_bMenuActive;	// Is the menu active?
		float m_fTitleIn;		// Title blending
		int	  m_iMenuPoint;		// Current selected menu point
		float m_fFOV;			// View fov
		bool  m_bGetNewKey;		// Should a new key be received?
		
		THighscore* m_pCHighscore;	// Highscore

		// Menu blending
		float m_fMainBlend, m_fOptionsBlend, m_fKeysBlend, m_fQuestionBlend, m_fCreditsBlend;
		float m_fLogosPercentage, m_fLogoWait, m_fNextLogoWait;
		bool  m_bFastLogos;
		float m_fMenuTimer;

		// Active menus
		bool m_bMainMenu, m_bHighscoreMenu, m_bOptionsMenu, m_bKeysMenu, m_bQuestionMenu, m_bCreditsMenu;

		// Titel
		ASFLOAT3 m_fTitelGridPoint[TITEL_GRID_X_SIZE * TITEL_GRID_Y_SIZE];
		ASFLOAT2 m_fTitelGridTexture[TITEL_GRID_X_SIZE * TITEL_GRID_Y_SIZE];
		float    m_fTitleTimer;

		// Credits
		ASTEntityHandler m_CUrlEntity;
		ASTModelHandler  m_CUrlModel;
		float  m_fCreditsTextY;
		int	   m_iWholeCreditsTextY;
		int    m_iCreditsTexts;
		char** m_pszCreditsText;
		int    m_iCreditsTextures;
		char** m_pszCreditsTexture;

		// Textures
		ASTTextureHandler m_CTitleTexture;
		ASTTextureHandler m_CAblazeSpaceLogoTexture;
		ASTTextureHandler m_C3DimensionenLogoTexture;
		ASTTextureHandler m_CToxeenLogoTexture;
		ASTTextureHandler m_CSTGLogoTexture;

		// Sounds
		ASTSoundHandler m_CChangeSound;
		ASTSoundHandler m_CEnterSound;
		ASTSoundHandler m_CLeaveSound;
		ASTSoundHandler m_CMainMusic;

		/*
			The text update function
		*/
		static void ProcTextUpdate();

		/*
			Draws the menu background
		*/
		void DrawBackground(float fZ, float fLeft, float fTop, float fRight, float fBottom, float fDensity);

		/*
			Draws the main menu
		*/
		void DrawMain();

		/*
			Updates the main menu
		*/
		void UpdateMain();

		/*
			Draws the highscore menu
		*/
		void DrawHighscore();

		/*
			Draws the credits menu
		*/
		void DrawOptions();

		/*
			Updates the credits menu
		*/
		void UpdateOptions();

		/*
			Draws the keys menu
		*/
		void DrawKeys();

		/*
			Updates the keys menu
		*/
		void UpdateKeys();

		/*
			Draws the credits menu
		*/
		void DrawCredits();

		/*
			Updates the credits menu
		*/
		void UpdateCredits();

		/*
			Initializes the title
		*/
		void InitTitle();

		/*
			Draws the title
		*/
		void DrawTitle();

		/*
			Updates the title
		*/
		void UpdateTitle();

		/*
			Initializes all menu points
		*/
		void InitMenuPoints();

		/*
			Updates all menu points
		*/
		void UpdateMenuPoints();

		/*
			Sets the color of a menu point
		*/
		void SetMenuPointColor(TMenuPoint* pMenuPointT, float fBlend, int iKeyCode = -1);


} TMenus;


// Variables
extern TMenus CMenus;


#endif // __MENUS_H__
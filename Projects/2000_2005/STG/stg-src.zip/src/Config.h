/*
	File: Config.h

	Description: Configuration stuff
*/


#ifndef __CONFIG_H__
#define __CONFIG_H__


// Definitions
#define CONFIGFILE "config"	// Name of the standard configuration file


// Classes
typedef class TConfig {
	
	public:
		/*
			Initialize the configuration

			Returns:
				bool -> 'false' if all went fine else 'true'

			Notes:
				- Loads automatically the standard config file 'config.ini'
		*/
		bool Init();

		/*
			Load a configuration

			Parameters:
				char* pszFilename -> Filename of the configuration file

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Load(const char* pszFilename = CONFIGFILE);

		/*
			Save the configuration

			Parameters:
				char* pszFilename -> Filename of the configuration file

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool Save(const char* pszFilename = CONFIGFILE);

		/*
			Check if the configurations are valid

			Returns:
				bool -> 'false' if all configurations were valid else 'true'

			Notes:
				- You should check the configurations if you want to go sure that
				  all settings are valid
		*/
		bool Check();

		/*
			Functions to get the configuration states
		*/
		float GetLevelDetail() const;
		float GetPlants() const;
		bool  ShowQuadtrees() const;
		bool  ShowVertices() const;
		bool  ShowNormals() const;

		/*
			Updates all configuration relevant stuff
		*/
		void Update();

		/*
			Updates the settings of a model handler

			Parameters:
				ASTModelHander& pCModelHandler - Referenze to the model handler
		*/
		void Update(ASTModelHandler& pCModelHandler);

		/*
			Opens the configuration dialog
		
			Parameters:
				HWND hWnd -> Owner window

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool OpenDialog(const HWND hWnd = NULL);

		/*
			Opens the credits dialog
		
			Parameters:
				HWND hWnd -> Owner window

			Returns:
				bool -> 'false' if all went fine else 'true'
		*/
		bool OpenCreditsDialog(const HWND hWnd = NULL);


	private:
		char m_szFilename[256];	// Configuration filename
		bool m_bLoaded;			// Is a configuration already loaded?

		// General
		float m_fLevelDetail;	// Level detail
		float m_fPlants;		// Plants factor

		// Debug
		bool m_bShowQuadtrees;	// Should the quadtrees be shown?
		bool m_bShowVertices;	// Should the vertices be shown?
		bool m_bShowNormals;	// Should the normals be shown?

		/*
			Resets the configurations
		*/
		void Reset();

		/*
			The text update function
		*/
		static void ProcTextUpdate();

		/*
			Main configuration procedure
		*/
		static LRESULT CALLBACK ConfigProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);
		LRESULT Proc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);

		/*
			General task procedure
		*/
		static LRESULT CALLBACK ConfigGeneralProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);
		LRESULT GeneralProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);
 
		/*
			Debug task procedure
		*/
		static LRESULT CALLBACK ConfigDebugProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);
		LRESULT DebugProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);

		/*
			Credits procedure
		*/
		static LRESULT CALLBACK CreditsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);


} TConfig;


// Variables
extern TConfig CConfig;


#endif // __CONFIG_H__
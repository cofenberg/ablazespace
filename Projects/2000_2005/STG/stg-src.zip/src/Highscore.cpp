/*
	File: Highscore.cpp
*/

#include <ASEngine.h>
#include "Language.h"
#include "Highscore.h"
#include "Menus.h"


/*
	Constructor
*/
THighscore::THighscore()
{
	// Setup data
	m_bLoaded	   = false;
	m_bActive	   = false;
	m_fAlpha	   = 0.f;
	m_bGameWon	   = false;
	m_bEnterName   = false;
	m_pSScoreEntry = NULL;

	// Load sounds
		   m_CInputSound.Load("input.mp3");
		   m_CEnterSound.Load("input_finished.mp3");
		 m_CInvalidSound.Load("invalid.mp3");
		  m_CChangeSound.Load("change.mp3");
			m_CBackSound.Load("back.mp3");
    	  m_CWinnerSound.Load("winner.mp3");
	      m_CLooserSound.Load("looser.mp3");
	m_CNewHighscoreSound.Load("newhighscore.mp3");

	// Load highscore data
	Load();
}

/*
	Destructor
*/
THighscore::~THighscore()
{
	// Unload sounds
		   m_CInputSound.Unload();
		   m_CEnterSound.Unload();
		 m_CInvalidSound.Unload();
		  m_CChangeSound.Unload();
			m_CBackSound.Unload();
	      m_CWinnerSound.Unload();
	      m_CLooserSound.Unload();
	m_CNewHighscoreSound.Unload();
	
	// Save highscore
	Save();

	// Unload data
	Unload();
}

/*
	Load a highscore
*/
bool THighscore::Load(const char* pszFilename)
{
	THighscoreEntry SEntry;
	int i, iEntries;
	FILE* pFile;

	// Check pointer
	if (!pszFilename) return true;

	// Save and unload the preview configuration
	if (m_bLoaded) {
		Save(m_szFilename);
		Unload();
	}

	// Setup filename information
	strcpy(m_szFilename, pszFilename);
	_AS::CFileSystem.GetFullFilename(m_szFilename, HIGHSCORE_FILE);

	if (!(pFile = fopen(m_szFilename, "r"))) { // Create a new highscore
		_AS::CLog.Output("Create highscore '%s'", m_szFilename);

		// Create entries
		for (i = 0; i < HIGHSCORE_ENTRIES; i++) {
			switch (i) {
				case 0: strcpy(SEntry.szName, "Softgames - The Game"); SEntry.iScore = 1000; break;
				case 1: strcpy(SEntry.szName, "www.softgames.de");     SEntry.iScore =  900; break;
				case 2: strcpy(SEntry.szName, "AblazeSpace 2002");     SEntry.iScore =  800; break;
				case 3: strcpy(SEntry.szName, "www.ablazespace.de");   SEntry.iScore =  700; break;
				case 4: strcpy(SEntry.szName, "Christian Ofenberg");   SEntry.iScore =  600; break;
				case 5: strcpy(SEntry.szName, "Jens D�rholt");		   SEntry.iScore =  500; break;
				case 6: strcpy(SEntry.szName, "Boris 'Toxeen' Nonte"); SEntry.iScore =  400; break;
				case 7: strcpy(SEntry.szName, "Michael M�ller");	   SEntry.iScore =  300; break;
				case 8: strcpy(SEntry.szName, "Alexander Krug");	   SEntry.iScore =  200; break;
				case 9: strcpy(SEntry.szName, "Second-Evolution");	   SEntry.iScore =  100; break;
			}
			m_lstEntryList.Add(SEntry);
		}

		m_bLoaded = true;

		return false;
	} else 	_AS::CLog.Output("Load highscore '%s'", m_szFilename);

	// Get number of entries
	fread(&iEntries, sizeof(int), 1, pFile);

	// Load all entries
	for (i = 0; i < iEntries; i++) {
		fread(&SEntry, sizeof(THighscoreEntry), 1, pFile);
		m_lstEntryList.Add(SEntry);
	}

	m_bLoaded = true;

	fclose(pFile);

	return false;
}

/*
	Unloads the highscore
*/
bool THighscore::Unload()
{
	if (!m_bLoaded) return false;

	m_lstEntryList.Clear();
	m_bLoaded = false;

	return false;
}

/*
	Save the highscore
*/
bool THighscore::Save(const char* pszFilename)
{
	FILE* pFile;
	int i;

	// Check pointer
	if (!pszFilename) return true;

	// Setup filename information
	strcpy(m_szFilename, pszFilename);
	_AS::CFileSystem.GetFullFilename(m_szFilename, HIGHSCORE_FILE);

	if (!(pFile = fopen(m_szFilename, "w"))) {
		_AS::CLog.Output("Couldn't save highscore '%s'!", m_szFilename);

		return true;
	} else _AS::CLog.Output("Save highscore '%s'", m_szFilename);

	// Save number of entries
	i = m_lstEntryList.GetElements();
	fwrite(&i, sizeof(int), 1, pFile);

	// Save all entries
	for (i = 0; i < m_lstEntryList.GetElements(); i++)
		fwrite(m_lstEntryList[i], sizeof(THighscoreEntry), 1, pFile);

	fclose(pFile);

	return false;
}

/*
	Checks whether and were a new score goes into the highscore
*/
int THighscore::GetScorePlace(const int iScore)
{
	for (int i = 0; i < m_lstEntryList.GetElements(); i++)
		if (iScore >= m_lstEntryList[i]->iScore) return i;

	return -1;
}

/*
	Returns the highscore blending
*/
float THighscore::GetBlending() const
{
	return m_fAlpha;
}

/*
	Open the highscore
*/
void THighscore::Open(const int iScore, const bool bGameWon)
{
	_AS::CInput.Reset();
	m_CChangeSound.Play();

	m_bActive    = true;
	m_bGameWon   = bGameWon;
	m_fTimer     = 0.f;
	m_bEnterName = false;

	if (iScore < 0) return;

	// Try to add a new score to the highscore
	int iPlace;

	m_bEnterName = true;
	if ((iPlace = GetScorePlace(iScore)) > -1) { // Yeah, its in the highscore! :-)
		DWORD dwLength = HIGHSCORE_NAME_LENGTH;

		// Make place for the new king
		for (int i = m_lstEntryList.GetElements() - 1; i > iPlace; i--)
			memcpy(m_lstEntryList[i], m_lstEntryList[i - 1], sizeof(THighscoreEntry));

		m_pSScoreEntry = m_lstEntryList[iPlace];
		GetUserName((LPTSTR) m_pSScoreEntry->szName, &dwLength);
		m_pSScoreEntry->iScore = iScore;
		if (!iPlace) m_CNewHighscoreSound.Play();
		m_CWinnerSound.Play();
	} else m_CLooserSound.Play();
}

/*
	Draws the highscore
*/
bool THighscore::Draw()
{
	char szTemp[256];
	int i, iY;

	// Is the highscore visible?
	if (!m_fAlpha) return false;

	glColor4f(1.f, 1.f, 1.f, m_fAlpha);
	if (m_bGameWon) {
		if(m_pSScoreEntry && m_pSScoreEntry->iScore >= HIGHSCORE_IMPRESSIVE_SCORE) {
			_AS::CRenderer.Print(400, 310, 1, CText.Get(_T_YouHaveWonTheGame));
			_AS::CRenderer.SetFontSize(0.7f);
			_AS::CRenderer.Print(400,  40, 1, CText.Get(_T_YouCouldFindCheatsOnTheAblazeSpace));
			_AS::CRenderer.Print(400,  30, 1, CText.Get(_T_HomepageUnderTheGameFeatures));
			_AS::CRenderer.SetFontSize();
		} else _AS::CRenderer.Print(400, 310, 1, CText.Get(_T_YouHaveWonTheGame));
	}

	if (!m_bEnterName) {
		_AS::CRenderer.SetFontSize(1.5f);
		_AS::CRenderer.Print(400, 330, 1, CText.Get(_T_Highscore));
		_AS::CRenderer.SetFontSize();
	} else {
		if (m_pSScoreEntry) { // The player is in the highscore!
			_AS::CRenderer.Print(400, 350, 1, CText.Get(_T_Congratulations));
			_AS::CRenderer.Print(400, 340, 1, CText.Get(_T_YouAreInTheHighscore));
			_AS::CRenderer.Print(400, 330, 1, CText.Get(_T_EnterYourNameAndHitEnterWhenDone));
		} else { // He's a looser
			_AS::CRenderer.Print(400, 340, 1, CText.Get(_T_YouAreNotInTheHighscore));
			_AS::CRenderer.Print(400, 330, 1, CText.Get(_T_TryItAgain));
		}
	}

	if (!m_bEnterName && (_AS::CTimer.GetPastTime() / 1000) % 2)
		_AS::CRenderer.Print(400, 50, 1, CText.Get(_T_PressAnyKeyToContinue));

	_AS::CRenderer.Print(100, 290, 1, CText.Get(_T_Place));
	_AS::CRenderer.Print(400, 290, 1, CText.Get(_T_Name));
	_AS::CRenderer.Print(680, 290, 1, CText.Get(_T_Score));
	for (i = 0, iY = 260; i < m_lstEntryList.GetElements(); i++, iY -= 20) {
		if (!m_pSScoreEntry || m_pSScoreEntry != m_lstEntryList[i]) {
			glColor4f(1.0f, 1.0f, 1.0f, m_fAlpha);
			sprintf(szTemp, "%s", m_lstEntryList[i]->szName);
		} else {
			glColor4f(1.0f, 0.0f, 0.0f, m_fAlpha);
			if ((_AS::CTimer.GetPastTime() / 500) % 2 || strlen(m_pSScoreEntry->szName) >= HIGHSCORE_NAME_LENGTH)
				sprintf(szTemp, "%s ", m_pSScoreEntry->szName);
			else sprintf(szTemp, "%s_", m_pSScoreEntry->szName);
		}
		
		// Place
		_AS::CRenderer.Print(100, iY, 1, "%d.", i+1);

		// Name
		_AS::CRenderer.Print(400, iY, 1, szTemp);

		// Score
		_AS::CRenderer.Print(680, iY, 1, "%d", m_lstEntryList[i]->iScore);
	}

	return true;
}

/*
	Updates the highscore
*/
bool THighscore::Update()
{
	USHORT iKey;
	int i;

	if (!m_bActive) { // Fade out the highscore
		m_fAlpha -= _AS::CTimer.GetTimeDifference() * 2;
		if (m_fAlpha < 0.f) m_fAlpha = 0.f;

		return false;
	}
	m_fAlpha += _AS::CTimer.GetTimeDifference() * 2;
	if (m_fAlpha > 1.f) m_fAlpha = 1.f;

	// Check enter / esc keys
	if (m_bEnterName && m_pSScoreEntry) {
		if (_AS::CInput.IsKeyHit(DIK_RETURN)) {
			m_bEnterName   = false;
			m_bGameWon     = false;
			m_pSScoreEntry = NULL;
			Save();
			m_CEnterSound.Play();

			return true;
		}
	} else {
		m_fTimer += _AS::CTimer.GetTimeDifference();
		if (_AS::CInput.IsKeyHit() >= 0 || m_fTimer > 15.f) {
			m_bActive = false;
			CMenus.Activate();
			m_CChangeSound.Play();

			return true;
		}

		return true;
	}

	// Enter name
	if (_AS::CInput.IsKeyHit(DIK_BACK)) { // Remove a character
		if (strlen(m_pSScoreEntry->szName) > 0) {
			m_pSScoreEntry->szName[strlen(m_pSScoreEntry->szName) - 1] = '\0';
			m_CBackSound.Play();
		} else m_CInvalidSound.Play();
	} else
	if (_AS::CInput.IsKeyHit(DIK_ESCAPE)) { // Delete whole input
		memset(m_pSScoreEntry->szName, 0, sizeof(char) * HIGHSCORE_NAME_LENGTH);
		m_CChangeSound.Play();
	} else { // Add a character
		if (strlen(m_pSScoreEntry->szName) >= HIGHSCORE_NAME_LENGTH) return true;
		for (i = 0; i < ASKEYS; i++)  {
			if (!_AS::CInput.IsKeyHit(i))  continue;
			_AS::CInput.ConvertScancodeToASCII(i, &iKey);
			sprintf(m_pSScoreEntry->szName, "%s%c", m_pSScoreEntry->szName, iKey);
			m_CInputSound.Play();
		}
	}

	return true;
}
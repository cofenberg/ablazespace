/*
	File: Language.h

	Description: Texts for the game
*/

#ifndef __LANGUAGE_H__
#define __LANGUAGE_H__


// Definitions
#define LANGUAGETEXTFILE "game"	// Game language text file

// _T_Shadows -> Wird nicht mehr ben�tigt!


// Texts
enum {
	_T_Ok, _T_Cancel, _T_Standard, _T_Quit, _T_Configurations, _T_Credits, _T_General, _T_Debug,
	_T_ShowQuadtrees, _T_Question, _T_AreYouSure, _T_Version, _T_Build, _T_Programming, _T_Graphic,
	_T_Shadows, _T_ShowVertices, _T_ShowNormals, _T_YouHaveWonTheGame, _T_YouCouldFindCheatsOnTheAblazeSpace,
	_T_HomepageUnderTheGameFeatures, _T_Highscore, _T_Congratulations, _T_YouAreInTheHighscore,
	_T_EnterYourNameAndHitEnterWhenDone, _T_YouAreNotInTheHighscore, _T_TryItAgain, _T_PressAnyKeyToContinue,
	_T_Place, _T_Name, _T_Score, _T_Music, _T_Continue, _T_Start, _T_Options, _T_Help, _T_MainMenu,
	_T_Plants, _T_ContinueGame, _T_StartGame, _T_Keys, _T_Game, _T_Engine, _T_Back, _T_Left, _T_Right, _T_Up,
	_T_Down, _T_Run, _T_Jump, _T_Attack, _T_Pause, _T_PressNewKey, _T_GameOver, _T_LevelDetail,
	_T_Collect, _T_Crystals, _T_Kill, _T_Turtles, _T_Burn, _T_Mosquitos, _T_GoIntoVortex, _T_Crystal, _T_Turtle,
	_T_Mosquito,
};


// Variables
extern ASTLanguageHandler CText; // Game texts


#endif // __LANGUAGE_H__
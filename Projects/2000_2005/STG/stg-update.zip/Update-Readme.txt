26 September, 2003


Fixed problems under WinXP
- Language enumeration


Update
- If you collect a crystal you will now receive 2 bonus seconds which makes the game more playable! :)
/*
	File: ASLanguageManager.cpp
*/

#include <ASEngineDll.h>


/*
	Constructor
*/
ASTLanguageManager::ASTLanguageManager()
{
}

/*
	Destructor
*/
ASTLanguageManager::~ASTLanguageManager()
{
	DestroyLanguageList();
	m_lstLanguageHandlerList.Clear();
}

/*
	Sets the language system to the given language
*/
bool ASTLanguageManager::SetLanguage(const char* pszLanguage)
{
	ASTLinkedListElement<ASTLanguageHandler*>* pSHandlerListElement;
	ASTLinkedListElement<char*>* pSLanguageListElement;
	ASTLanguageHandler* pLanguageHandler;
	bool bValid = false;

	// Check pointer
	if (!pszLanguage) return true;

	// Check if this is a valid language
	pSLanguageListElement = m_lstLanguageList.FindFirst();
	while (pSLanguageListElement) {
		if (pSLanguageListElement->Data && !stricmp(pSLanguageListElement->Data, pszLanguage)) {
			bValid = true;
			break;
		}
		pSLanguageListElement = m_lstLanguageList.FindNext();
	}
	if (!bValid) return true;
	strcpy(_AS::CConfig.m_szLanguageName, pSLanguageListElement->Data);

	// Update all language handlers
	pSHandlerListElement = m_lstLanguageHandlerList.FindFirst();
	while (pSHandlerListElement) {
		if (pLanguageHandler = pSHandlerListElement->Data) {
			pLanguageHandler->Load(pLanguageHandler->GetFilename());
		}
		pSHandlerListElement = m_lstLanguageHandlerList.FindNext();
	}

	return false;
}

/*
	Generates a list of all available languages
*/
int ASTLanguageManager::GenerateLanguageList()
{
	ASTLinkedListElement<char*>* pSLanguageListElement;
	WIN32_FIND_DATA SFindFileData;
	char szPath[256], *pszTemp;
	bool bValid = false;
	HANDLE hFind;

	_AS::CLog.Output("Enumerate languages");
	DestroyLanguageList();
	
	// Get the language path
	sprintf(szPath, "%s\\*.*", _AS::CFileSystem.GetLanguagesDirectory());
	_AS::CFileSystem.GetFullFilename(szPath, NULL);

	// Enumerate the languages
	hFind = FindFirstFile(szPath, &SFindFileData);
	while (hFind) {
		if (SFindFileData.cFileName[0] != '.' &&
			(SFindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == FILE_ATTRIBUTE_DIRECTORY) {
			// We found a dictory:
			pszTemp = new char[strlen(SFindFileData.cFileName) + 1];
			strcpy(pszTemp, SFindFileData.cFileName);
			_strupr(pszTemp);
			m_lstLanguageList.Add(pszTemp);
		}

		if (!FindNextFile(hFind, &SFindFileData)) break;
	}
	FindClose(hFind);

	// Check if the current selected language is vaild
	pSLanguageListElement = m_lstLanguageList.FindFirst();
	while (pSLanguageListElement) {
		if (pSLanguageListElement->Data && !stricmp(pSLanguageListElement->Data, _AS::CConfig.GetLanguageName())) {
			bValid = true;
			break;
		}
		pSLanguageListElement = m_lstLanguageList.FindNext();
	}
	if (!bValid) {
		_AS::CLog.Output("Current selected language '%s' isn't available!", _AS::CConfig.GetLanguageName());
		if (m_lstLanguageList.GetElements()) {
			strcpy(_AS::CConfig.m_szLanguageName, m_lstLanguageList.FindFirst()->Data);
			_AS::CLog.Output("Select language '%s' instead", _AS::CConfig.GetLanguageName());

		} else _AS::CLog.Output("Error: No languages found at '%s'!", szPath);
	}

	return m_lstLanguageList.GetElements();
}

/*
	Destroys the list of all available languages
*/
bool ASTLanguageManager::DestroyLanguageList()
{
	ASTLinkedListElement<char*>* pSListElement;

	// Remove all found language names
	pSListElement = m_lstLanguageList.FindFirst();
	while (pSListElement) {
		if (pSListElement->Data) delete pSListElement->Data;
		pSListElement = m_lstLanguageList.FindNext();
	}
	m_lstLanguageList.Clear();

	return false;
}
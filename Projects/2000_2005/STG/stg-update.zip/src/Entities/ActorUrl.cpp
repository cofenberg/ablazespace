/*
	File: ActorUrl.cpp
*/

#include <ASEngine.h>
#include "..\Game.h"
#include "..\ParticleGroups\ParticleGroupStars.h"


/*
	Draws the hud
*/
void TActorUrl::DrawHud()
{
	// Draw url head
	glDisable(GL_BLEND);
	glColor3f(1.f, 1.f, 1.f);
	m_CHeadModel.UpdateVisibility(true);
	m_CHeadModel.Draw(true, false);
	glColor3f(1.f, 1.f, 1.f);
	m_CCrystalModel.UpdateVisibility(true);
	m_CCrystalModel.Draw(true, false);
	if (m_bMoveCrystal) {
		ASTVector3D vT = m_CCrystalEntity.GetEntity()->GetPos();

		m_CCrystalEntity.GetEntity()->SetPos(m_vCrystalPos);
		m_CCrystalModel.UpdateVisibility(true);
		m_CCrystalModel.Draw(true, false);
		m_CCrystalEntity.GetEntity()->SetPos(vT);
	}

	_AS::CRenderer.SetFontSize(1.5f);
	glColor3f(1.f, 1.f, 1.f);
	_AS::CRenderer.Print(130, 470, 0, "* %d",      GetLives());
	if (m_iScore < 5 && ((_AS::CTimer.GetPastTime() / 300) % 2)) glColor3f(1.f, 0.f, 0.f);
	_AS::CRenderer.Print(400, 550, 1, "%s: %d", CText.Get(_T_Score), m_iScore);
	if (m_iCrystals >= 4 && ((_AS::CTimer.GetPastTime() / 500) % 2))
		glColor3f(0.f, 1.f, 0.f);
	else
		glColor3f(1.f, 1.f, 1.f);
	_AS::CRenderer.Print(670, 500, 0, "%d *", m_iCrystals);
	_AS::CRenderer.SetFontSize();

	// Show level progress
	_AS::CRenderer.SetFontSize(0.7f);
	glColor3f(1.f, 1.f, 1.f);
	{
		int iY = 30;

		if (!CGame.pCLevel->iMosquitos && !CGame.pCLevel->iTurtles && !CGame.pCLevel->iCrystals) {
			if (((_AS::CTimer.GetPastTime() / 500) % 2))
				_AS::CRenderer.Print(400, 30, 1, "%s", CText.Get(_T_GoIntoVortex));
		} else {
			if (CGame.pCLevel->iMosquitos) {
				if (CGame.pCLevel->iMosquitos == 1)
					_AS::CRenderer.Print(400, iY, 1, "%s %d %s", CText.Get(_T_Burn),	CGame.pCLevel->iMosquitos, CText.Get(_T_Mosquito));
				else
					_AS::CRenderer.Print(400, iY, 1, "%s %d %s", CText.Get(_T_Burn),	CGame.pCLevel->iMosquitos, CText.Get(_T_Mosquitos));
				iY += 10;
			}
			if (CGame.pCLevel->iTurtles) {
				if (CGame.pCLevel->iTurtles == 1)
					_AS::CRenderer.Print(400, iY, 1, "%s %d %s", CText.Get(_T_Kill),	CGame.pCLevel->iTurtles,   CText.Get(_T_Turtle));
				else
					_AS::CRenderer.Print(400, iY, 1, "%s %d %s", CText.Get(_T_Kill),	CGame.pCLevel->iTurtles,   CText.Get(_T_Turtles));
				iY += 10;
			}
			if (CGame.pCLevel->iCrystals) {
				if (CGame.pCLevel->iCrystals == 1)
					_AS::CRenderer.Print(400, iY, 1, "%s %d %s", CText.Get(_T_Collect), CGame.pCLevel->iCrystals,  CText.Get(_T_Crystal));
				else
					_AS::CRenderer.Print(400, iY, 1, "%s %d %s", CText.Get(_T_Collect), CGame.pCLevel->iCrystals,  CText.Get(_T_Crystals));
			}
		}
	}
	_AS::CRenderer.SetFontSize();
}

/*
	Returns the score
*/
int TActorUrl::GetScore() const
{
	return m_iScore;
}

/*
	Increases the score
*/
void TActorUrl::IncScore(const int iScore)
{
	m_iScore += iScore;
	if (m_iScore < 0) m_iScore = 0;
}

/*
	Returns the number of games
*/
int TActorUrl::GetGames() const
{
	return m_iGames;
}

/*
	Increases the number of games
*/
void TActorUrl::IncGames(const int iGames)
{
	if (iGames > 0 && (m_iCrystals < iGames * 4 || m_iGames > 0)) return;

	if (iGames > 0) {
		m_iCrystals -= iGames * 4;
		m_CReceiveGameSound.Play();
		CGame.pCLevel->fTime += iGames * 2.f;
	}
	m_iGames += iGames;
	if (m_iGames < 0) m_iGames = 0;
	if (m_iGames > 1) m_iGames = 1;
}

/*
	Url actor initialisation function
*/
void TActorUrl::InitFunction()
{
	ASTEntity* pCEntity;
	
	// Load models
 	   	   m_CModel.Load("url.md2");
		   m_CModel.SetActive();
		   m_CModel.SetEntity(this);
		   m_CModel.SetAnimationFlags(ASeModelAniFlagPlay | ASeModelAniFlagLoop);
	   m_CHeadModel.Load("url_head.md2");
	   m_CHeadModel.SetActive();
	m_CCrystalModel.Load("crystal.md2");
	m_CCrystalModel.SetActive();

	// Create Url head
	ASCreateEntity(pCEntity, ASTEntity, "Url head");
	pCEntity->IncPos(-17.f, 10.f, -40.f);
	pCEntity->SetRot(-40.f, 70.f, 0.f);
	m_CHeadEntity.Load(pCEntity);
	m_CHeadModel.SetEntity(pCEntity);

	// Create crystal
	ASCreateEntity(pCEntity, ASTEntity, "Crystal");
	pCEntity->SetPos(18.f, 12.f, -40.f);
	pCEntity->SetRot(-90.f, 0.f, 0.f);
	m_CCrystalEntity.Load(pCEntity);
	m_CCrystalModel.SetEntity(pCEntity);

	// Get animations
	ANIMATION_STAND   = m_CModel.GetAnimationID("stand");
	ANIMATION_STAND2  = m_CModel.GetAnimationID("standT");
	ANIMATION_BORING  = m_CModel.GetAnimationID("boring");
	ANIMATION_BORING2 = m_CModel.GetAnimationID("boringT");
	ANIMATION_WALK    = m_CModel.GetAnimationID("walk");
	ANIMATION_RUN     = m_CModel.GetAnimationID("run");
	ANIMATION_JUMP    = m_CModel.GetAnimationID("jump");
	ANIMATION_ATTACK  = m_CModel.GetAnimationID("attack");
	ANIMATION_PAIN    = m_CModel.GetAnimationID("pain");
	ANIMATION_SHOCK   = m_CModel.GetAnimationID("shock");
	ANIMATION_DIE     = m_CModel.GetAnimationID("die");

	// Load sound
	     m_CAttackSound.Load("url_attack.wav");
 	       m_CJumpSound.Load("url_jump.mp3");
 	       m_CPainSound.Load("url_pain.mp3");
   	      m_CShockSound.Load("url_shock.wav");
 	    m_CFallingSound.Load("url_falling.mp3");
        m_CRebirthSound.Load("url_rebirth.mp3");
      m_CExtraLifeSound.Load("url_extralife.mp3");
    m_CReceiveGameSound.Load("url_receivegame.mp3");
      m_CLowScore1Sound.Load("lowscore_1.mp3");
      m_CLowScore2Sound.Load("lowscore_2.mp3");

	// Setup correct position & rotation
	SetPos(0.f, 0.f, -15.f);
	SetRot(90.f, 0.f, 0.f);
	m_vShadowPos = GetPos();
	m_vShadowVelocity = 0.f;

	// Setup data
	SetMaxLives(9);
	SetLives(2);
	SetMaxHealth(100.f);
	SetHealth();
	m_iScore	   = 15;
	m_fScoreTimer  = 0.f;
	m_fStandTimer  = 0.f;
	m_iCrystals	   = 0;
	m_bAttackFrame = false;
	m_bAttack      = false;
	m_iGames	   = 0;
	m_fDustTimer   = 0.f;

	// Activate and setup collision detection
	SetCollisionFlags(ASeCollisionFlagEntities | ASeCollisionFlagSphere | ASeCollisionFlagSphereResponse);
	SetCollisionRadius(m_CModel.GetRadius());

	CGame.pCUrlActor = this;
}

/*
	Url entity de-initialisation function
*/
void TActorUrl::CustomDeInitFunction()
{
	CGame.pCUrlActor = NULL;

	// Unload models
	       m_CModel.Unload();
	   m_CHeadModel.Unload();
	m_CCrystalModel.Unload();

	// Unload entities
	   m_CHeadEntity.Unload(true);
	m_CCrystalEntity.Unload(true);

	// Unload sound
	     m_CAttackSound.Unload();
	       m_CJumpSound.Unload();
	       m_CPainSound.Unload();
	      m_CShockSound.Unload();
	    m_CFallingSound.Unload();
	    m_CRebirthSound.Unload();
  	    m_CFallingSound.Unload();
	  m_CExtraLifeSound.Unload();
	m_CReceiveGameSound.Unload();
	  m_CLowScore1Sound.Unload();
	  m_CLowScore2Sound.Unload();
}

/*
	Checks whether the Url entity is in the frustum or not
*/
bool TActorUrl::CustomFrustumFunction()
{
	if (m_CModel.UpdateVisibility()) return true;

	return false;
}

/*
	Url entity draw solid function
*/
void TActorUrl::CustomDrawSolidFunction()
{
	// Draw model
	glColor3f(1.f, 1.f, 1.f);
	m_CModel.Draw();
		

#ifdef _DEBUG
	float fZ;
	TLevelField* pFieldT = CGame.pCLevel->GetHeight(m_vPos.fX, m_vPos.fY, fZ);

	glColor3f(1.f, 1.f, 1.f);
	glPointSize(10.f);
	glBegin(GL_POINTS);
		glVertex3f(m_vPos.fX, m_vPos.fY, fZ);
	glEnd();
#endif


	// Draw shadow
	CGame.pCLevel->DrawShadow(m_vShadowPos, 3.f);
}

/*
	Url entity draw transparent function
*/
void TActorUrl::CustomDrawTransparentFunction()
{
	if (m_iGames) {
		_AS::CRenderer.SetFontSize(3.f);
		glColor3f(1.f, 1.f, 1.f);
		_AS::CRenderer.Print(ASTVector3D(m_vPos.fX, m_vPos.fY, m_vPos.fZ - 2.f), 1, "*");
		_AS::CRenderer.SetFontSize();
	}
}

/*
	Url entity update function
*/
void TActorUrl::CustomUpdateFunction()
{
	float fVelocity, fLength, fTimeDiff = _AS::CTimer.GetTimeDifference();
	ASTVector3D vE;
	bool bMove = false;

	// Update model settings
	CConfig.Update(m_CModel);
	CConfig.Update(m_CHeadModel);

	// Animate model
	m_CModel.Animate();
	m_CHeadModel.SetAnimationFrame((int) (GetMaxHealth() - GetHealth()));

	{ // Rotate status crystal
		ASTEntity* pCEntity = m_CCrystalEntity.GetEntity();
		pCEntity->IncRot(0.f, 0.f, fTimeDiff * 50);
	}

	if (_AS::CRenderer.GetCamera() &&
	   (_AS::CRenderer.GetCamera()->GetFlags() & ASeCameraFlagFree))
		return;

	if ((((ASTEntity*) this)->GetFlags() & ASeEntityFlagFreeMovement)) return;

	// Get collision ellipsoid radius
	vE = m_CModel.GetRadius();

	// Check cheating
	if (bCheatImmotral)		  SetHealth(100);
	if (bCheatUnlimitedLives) SetLives(9);

	if (!(GetFlags() & eActorFlagDeath)) {
		// Jumping
			if (_AS::CInput.IsKeyPressed(CControl.GetJumpKey()) || _AS::CInput.IsMouseButtonPressed(0)) {
			if (!IsJumping()) {
				if (IsOnFloor()) { // Start jump
					m_CModel.SetAnimation(ANIMATION_STAND);
					Jump(180.f);
					m_CModel.SetAnimationFlags(ASeModelAniFlagPlay);
					m_CModel.SetAnimation(ANIMATION_JUMP);
					m_CModel.SetAnimationSpeed();
					m_CJumpSound.Play();
				}
			} else {
				if (m_fJumpTimer < 0.8f) {
					_AS::CTimer.SetCustomSlowMotionFactor(1.f - m_fJumpTimer);
					Jump(180.f - m_fJumpTimer * 225);
				} else {
					m_vJump = 0.f;
					_AS::CTimer.SetCustomSlowMotionFactor(_AS::CTimer.GetCustomSlowMotionFactor() + fTimeDiff * 2);
					if (_AS::CTimer.GetCustomSlowMotionFactor() > 1.f)
						_AS::CTimer.SetCustomSlowMotionFactor(1.f);
				}
			}
		} else {
			m_vJump = 0.f;
			_AS::CTimer.SetCustomSlowMotionFactor(_AS::CTimer.GetCustomSlowMotionFactor() + fTimeDiff * 2);
			if (_AS::CTimer.GetCustomSlowMotionFactor() > 1.f)
				_AS::CTimer.SetCustomSlowMotionFactor(1.f);
		}

		// Rotate
		IncRot(0.f, _AS::CInput.GetMouseDeltaX() / 1.5f, 0.f);

		// Run
		if (_AS::CInput.IsKeyPressed(CControl.GetRunKey())) fVelocity = 400;
		else												fVelocity = 150;
		if (IsJumping()) fVelocity *= 2;

		// Move forward
		if (_AS::CInput.IsKeyPressed(CControl.GetUpKey())) {
			m_vVelocity += m_vDirVector * fTimeDiff * fVelocity;
			bMove = true;
		}

		// Move backward
		if (_AS::CInput.IsKeyPressed(CControl.GetDownKey())) {
			m_vVelocity -= m_vDirVector * fTimeDiff * fVelocity;
			bMove = true;
		}
				
		// Slide
		if (_AS::CInput.IsKeyPressed(CControl.GetLeftKey())) {
			m_vVelocity += m_vDirRightVector * fTimeDiff * fVelocity;
			bMove = true;
		}
		if (_AS::CInput.IsKeyPressed(CControl.GetRightKey())) {
			m_vVelocity -= m_vDirRightVector * fTimeDiff * fVelocity;
			bMove = true;
		}

		// Perform friction
		if (bMove) {
			PerformFriction(4);

			{ // Create dust particles
				TParticleGroupDust* pCDustEntity;
				ASTParticle SParticle;
				float fZ;

				fLength = m_vVelocity.GetLength() / 30;
				if (fLength > 1.f && !m_fDustTimer &&
					CGame.pCLevel->GetHeight(GetPos().fX, GetPos().fY, fZ) &&
					(pCDustEntity = (TParticleGroupDust*) CGame.pCLevel->CParticleGroupDust.GetEntity())) {

					m_fDustTimer = 1 / fLength / 10;

					// Create dust particles
					for (int i = 0; i < 2 * fLength * _AS::CConfig.GetParticleDensity(); i++) {
						memset(&SParticle, 0, sizeof(ASTParticle));
						SParticle.bActive = true;
						SParticle.fSize = fLength + (float) (rand() % 100) / 100.f;
						SParticle.fColor[A] = SParticle.fEnergie = 0.8f + (float) (rand() % 100) / 500.f;
						SParticle.vPos = GetPos();

						CGame.pCLevel->GetHeight(SParticle.vPos.fX, SParticle.vPos.fY, SParticle.vPos.fZ);
						SParticle.vPos.fZ -= 1.f;

						SParticle.vVelocity.fX = (float) (rand() % 200) / 100.f * fLength;
						if (!(rand() % 2)) SParticle.vVelocity.fX = -SParticle.vVelocity.fX;
						SParticle.vVelocity.fY = (float) (rand() % 200) / 100.f * fLength;
						if (!(rand() % 2)) SParticle.vVelocity.fY = -SParticle.vVelocity.fY;
						SParticle.vVelocity.fZ = - fLength * 2 - (float) (rand() % 200) / 50.f * fLength;

						SParticle.fColor[R] = SParticle.fColor[G] = SParticle.fColor[B] = SParticle.fEnergie;

						// Add the new particle to the dust particle group
						pCDustEntity->AddParticle(SParticle);
					}
				}
			}
		} else PerformFriction(8);

		if (!IsJumping()) {
			// Attack
			if ((_AS::CInput.IsKeyPressed(CControl.GetAttackKey()) || _AS::CInput.IsMouseButtonPressed(1))
				&& !bMove) {
				SetAttackAnimation();
			} else {
				if (m_vVelocity.GetLength() > 0.01f) {
					if (m_CModel.GetAnimation() != ANIMATION_PAIN && m_CModel.GetAnimation() != ANIMATION_SHOCK) {
						float fAniSpeed;

						m_CModel.SetAnimationFlags(ASeModelAniFlagPlay | ASeModelAniFlagLoop);
						if (fVelocity > 250.f) m_CModel.SetAnimation(ANIMATION_RUN);
						else 				   m_CModel.SetAnimation(ANIMATION_WALK);
						fAniSpeed = m_vVelocity.GetLength() / 20;
						if (fAniSpeed < 0.8f) fAniSpeed = 0.8f;
						if (fAniSpeed > 3.5f) fAniSpeed = 3.5f;
						m_CModel.SetAnimationSpeed(fAniSpeed);
					}
				} else SetStandAnimation();
			}
		} else m_CModel.SetAnimationSpeed(4.f);
		CheckBoring();

		{ // Chance camera FOV to create a speed feeling ;)
			ASTCamera* pCCamera;
			if ((pCCamera = _AS::CRenderer.GetCamera())) {
				pCCamera->SetFOV(45.f + m_vVelocity.GetLength() / 30);
			}
		}

		// Update dust timer
		if (m_fDustTimer > 0.f) {
			m_fDustTimer -= fTimeDiff;
			if (m_fDustTimer < 0.f) m_fDustTimer = 0.f;
		}

		{ // Perform movement
			ASTVector3D vVelo = m_vVelocity +
								m_vJump;

			vVelo *= fTimeDiff;

			ASTCollisionPacked CCollisionPacked;
			CGame.pCLevel->Move(CCollisionPacked, m_vPos, vE, vVelo, true, bCheatImmotral);
			m_vPos = CCollisionPacked.vFinalPosition;
			if (CCollisionPacked.bFoundACollision) {
				StopJumping();
			}
			if (CCollisionPacked.bStuck) {
				m_vPos.fZ -= fTimeDiff * 20;
				StopJumping();
			}
		}

		ASTCamera* pCCamera = _AS::CRenderer.GetCamera();
		if (pCCamera) {
			ASTVector3D vVelocity;
			vVelocity = pCCamera->GetVelocityVector();
				// Move forward
				if (_AS::CInput.IsKeyPressed(CControl.GetUpKey()))
					vVelocity += m_vDirVector * fTimeDiff * fVelocity / 10;

				// Move backward
				if (_AS::CInput.IsKeyPressed(CControl.GetDownKey()))
					vVelocity -= m_vDirVector * fTimeDiff * fVelocity / 10;
				
				// Slide
				if (_AS::CInput.IsKeyPressed(CControl.GetLeftKey()))
					vVelocity += m_vDirRightVector * fTimeDiff * fVelocity / 10;
				if (_AS::CInput.IsKeyPressed(CControl.GetRightKey()))
					vVelocity -= m_vDirRightVector * fTimeDiff * fVelocity / 10;

				pCCamera->SetVelocityVector(vVelocity);

				// Perform friction
				pCCamera->PerformFriction(10);
		}

		// Url falls in a cap
		if (m_vPos.fZ >= 20.f) {
			SetFlags(GetFlags() | eActorFlagFalling);
			SendMessage(this, eActorMessageDie);
			m_CFallingSound.Play();
			m_CModel.SetAnimationFlags(ASeModelAniFlagPlay | ASeModelAniFlagLoop);
			m_CModel.SetAnimation(ANIMATION_SHOCK);
			m_CModel.SetAnimationSpeed(3);
			_AS::CTimer.SetCustomSlowMotionFactor(1.f);
		}
	}

	// Move shadow
	for (int i = 0; i < 2; i++) {
		// Update velocity
		if (ASAbs(m_vPos.fV[i] - m_vShadowPos.fV[i]) < 0.1f && m_vShadowVelocity.fV[i] < 0.1f) {
			m_vShadowVelocity.fV[i] = 0.f;
			continue;
		}
		if (m_vShadowPos.fV[i] < m_vPos.fV[i]) {
			m_vShadowVelocity.fV[i]  += fTimeDiff * 5;
			m_vShadowPos.fV[i] += m_vShadowVelocity.fV[i] * fTimeDiff * 10;
			if (m_vShadowPos.fV[i] > m_vPos.fV[i]) m_vShadowVelocity.fV[i] /= 20;
		} else {
			m_vShadowVelocity.fV[i] -= fTimeDiff * 5;
			m_vShadowPos.fV[i] += m_vShadowVelocity.fV[i] * fTimeDiff * 30;
			if (m_vShadowPos.fV[i] < m_vPos.fV[i]) m_vShadowVelocity.fV[i] /= 20;
		}
	}
	m_vShadowPos.fZ = m_vPos.fZ;

	{ // Perform gravity
		ASTCollisionPacked CCollisionPacked;

		m_vGravity += _AS::CPhysics.GetGravity() * fTimeDiff;
		m_vGravity -= m_vGravity * _AS::CPhysics.GetFriction() * fTimeDiff;
		CGame.pCLevel->Move(CCollisionPacked, m_vPos, vE, m_vGravity * fTimeDiff * 100, true, bCheatImmotral);
		SetPos(CCollisionPacked.vFinalPosition);
		if (CCollisionPacked.bFoundACollision) {
			StopJumping();
		}
	}
	CheckAnimations();

	// Move crystal
	if (m_bMoveCrystal) {
		ASTVector3D vTargetPos = m_CHeadEntity.GetEntity()->GetPos();

		for (int i = 0; i < 3; i++) {
			if (m_vCrystalPos.fV[i] > vTargetPos.fV[i]) {
				m_vCrystalPos.fV[i] -= fTimeDiff * 80;
				if (m_vCrystalPos.fV[i] < vTargetPos.fV[i]) m_vCrystalPos.fV[i] = vTargetPos.fV[i];
			} else
			if (m_vCrystalPos.fV[i] < vTargetPos.fV[i]) {
				m_vCrystalPos.fV[i] += fTimeDiff * 80;
				if (m_vCrystalPos.fV[i] > vTargetPos.fV[i]) m_vCrystalPos.fV[i] = vTargetPos.fV[i];
			}
		}
		if (m_vCrystalPos == vTargetPos) {
			IncLives(1);
			m_CExtraLifeSound.Play();
			m_iScore			 += 100;
			CGame.pCLevel->fTime += 8.f;
			m_bMoveCrystal  = false;
		}
	}

	// Decrease score
#ifndef _DEBUG
	if (!bCheatNoScoreDecrease) {
		m_fScoreTimer -= fTimeDiff;
		if (m_fScoreTimer < 0.f) {
			m_fScoreTimer = 1.f;
			m_iScore--;

			if (m_iScore < 0) {
				m_iScore = 0;
				CGame.GameOver();
			} else
			if (m_iScore < 2) m_CLowScore2Sound.Play();
			else if (m_iScore < 5) m_CLowScore1Sound.Play();
		}
	}
#endif
}

/*
	Url entity collision function
*/
void TActorUrl::CustomCollisionFunction(const ASTCollisionPacked& pCCollPacked)
{
	ASTEntity* pCEntity = pCCollPacked.pCEntity;

	if (pCEntity && !(pCEntity->GetCustomFlags() & eEntityFlagDie)) {
		if (!stricmp(pCEntity->GetName(), "Crystal") && pCEntity->GetScale() == 1.f) {
			m_iScore += 20;
			CGame.pCLevel->fTime += 2.f;
			m_iCrystals++;
			if (m_iCrystals >= 10) {
				m_iCrystals    = 0;
				m_bMoveCrystal = true;
				m_vCrystalPos  = m_CCrystalEntity.GetEntity()->GetPos();
			}
			SendMessage(pCEntity, eEntityMessageCollected);
		}
		if (m_bAttack) {
			ASBOUNDINGBOX fBoundingBox;

			if (pCEntity->GetModelHandler()) pCEntity->GetModelHandler()->GetBoundingBox(fBoundingBox);
			if (_AS::CCollision.IsLineInBox(m_vPos, m_vPos + m_vDirVector * 1000, fBoundingBox)) {
				{ // Create stars
					TParticleGroupStars* pCEntity;
					ASTVector3D vPos;

					// Get correct particle group position
					m_CModel.GetVertex(277, vPos);

					// Initialize particle systems
					ASCreateEntity(pCEntity, TParticleGroupStars, "Stars particles");
					pCEntity->SetPos(vPos);
					pCEntity->InitParticleGroup(10, "particle_star.tga");
					pCEntity->SetupTextureAnimation(4, 4);
					pCEntity->SetBlending(false);
				}

				SendMessage(pCEntity, eActorMessageHit, 10);
			}
		}
	}
}

/*
	Process messages
*/
bool TActorUrl::ProcessMessage(const int iMessage, const int iParameter, const void* pData)
{
	switch (iMessage) {
		case eActorMessageHit:
			if ((GetFlags() & eActorFlagDeath) || (GetFlags() & eActorFlagFalling)) return false;
			if (iParameter < -6) {
				m_CModel.SetAnimationFlags(ASeModelAniFlagPlay);
				m_CModel.SetAnimation(0);
				m_CModel.SetAnimation(ANIMATION_PAIN);
				m_CModel.SetAnimationSpeed(2);
				m_CPainSound.Play(true);
			} else {
				if (m_CModel.GetAnimation() == ANIMATION_SHOCK) break;
				m_CModel.SetAnimationFlags(ASeModelAniFlagPlay);
				m_CModel.SetAnimation(ANIMATION_SHOCK);
				m_CModel.SetAnimationSpeed(3);
				m_CShockSound.Play();
			}
			break;

		case eActorMessageDie:
			if (GetFlags() & eActorFlagFalling) return false;
			m_CModel.SetAnimationFlags(ASeModelAniFlagPlay);
			m_CModel.SetAnimation(ANIMATION_DIE);
			m_CModel.SetAnimationSpeed(2.f);
			break;

		default: break;
	}

	return false;
}

/*
	Set stand animation
*/
void TActorUrl::SetStandAnimation()
{
	if (m_CModel.GetAnimation() != ANIMATION_WALK && m_CModel.GetAnimation() != ANIMATION_RUN &&
		m_CModel.GetAnimation() != ANIMATION_JUMP && m_CModel.GetAnimation() != ANIMATION_ATTACK) return;

	m_CModel.SetAnimationFlags(ASeModelAniFlagPlay | ASeModelAniFlagLoop);
	if (rand() %2) m_CModel.SetAnimation(ANIMATION_STAND);
	else		   m_CModel.SetAnimation(ANIMATION_STAND2);
	m_CModel.SetAnimationSpeed(2);

	m_fStandTimer = 4 + ((float) (rand() % 400) / 100);
}

/*
	Set boring animation
*/
void TActorUrl::SetBoringAnimation()
{
	m_CModel.SetAnimationFlags(ASeModelAniFlagPlay);
	if (rand() %2) m_CModel.SetAnimation(ANIMATION_BORING);
	else		   m_CModel.SetAnimation(ANIMATION_BORING2);
	m_CModel.SetAnimationSpeed(2);
}

/*
	Set attack animation
*/
void TActorUrl::SetAttackAnimation()
{
	if (m_CModel.GetAnimation() == ANIMATION_PAIN || m_CModel.GetAnimation() == ANIMATION_SHOCK) return;

	m_CModel.SetAnimationFlags(ASeModelAniFlagPlay | ASeModelAniFlagLoop);
	m_CModel.SetAnimation(ANIMATION_ATTACK);
	m_CModel.SetAnimationSpeed(4.f);
	if (m_CModel.GetAnimationFrame() == 5) {
		if (!m_bAttackFrame) {
			m_bAttack = true;
			m_CAttackSound.Play();
			m_bAttackFrame = true;
		} else m_bAttack = false;
	} else {
		m_bAttackFrame = false;
		m_bAttack	   = false;
	}
}

/*
	Check boring
*/
void TActorUrl::CheckBoring()
{
	if (m_CModel.GetAnimation() != ANIMATION_STAND && m_CModel.GetAnimation() != ANIMATION_STAND2) return;

	m_fStandTimer -= _AS::CTimer.GetTimeDifference();
	if (m_fStandTimer > 0.f) return;
	SetBoringAnimation();
}

/*
	Check the animations
*/
void TActorUrl::CheckAnimations()
{
	// Pain / shock
	if ((m_CModel.GetAnimation() == ANIMATION_PAIN || m_CModel.GetAnimation() == ANIMATION_SHOCK) &&
		m_CModel.IsLastAnimationFrame()) {
		if (m_vPos.fZ >= 20.f) Death();
		else {
			m_CModel.SetAnimationFlags(ASeModelAniFlagPlay | ASeModelAniFlagLoop);
			m_CModel.SetAnimation(ANIMATION_WALK);
			SetStandAnimation();
		}

		return;
	}

	// Boring
	if ((m_CModel.GetAnimation() == ANIMATION_BORING || m_CModel.GetAnimation() == ANIMATION_BORING2) &&
		m_CModel.IsLastAnimationFrame()) {
		m_CModel.SetAnimationFlags(ASeModelAniFlagPlay | ASeModelAniFlagLoop);
		m_CModel.SetAnimation(ANIMATION_WALK);
		SetStandAnimation();

		return;
	}

	// Die
	if (m_CModel.GetAnimation() == ANIMATION_DIE &&
		m_CModel.IsLastAnimationFrame()) {
		m_fDeathTimer += _AS::CTimer.GetTimeDifference();
		if (m_fDeathTimer > 2.f) Death();

		return;
	}

	if (m_CModel.GetAnimation() != ANIMATION_ATTACK) m_bAttackFrame = false;
	if (!m_bAttackFrame) m_bAttack = false;
}

/*
	Url is death
*/
void TActorUrl::Death()
{
	if (GetLives() <= 0) { // Game over!
		CGame.GameOver();

		return;
	}

	// Rebirth
	m_CRebirthSound.Play();
	IncLives(-1);
	SetHealth(GetMaxHealth());
	SetPos(0.f, 0.f, -15.f);
	m_vVelocity		  = 0.f;
	m_vShadowPos      = GetPos();
	m_vShadowVelocity = 0.f;
	m_vGravity		  = 0.f;
	m_fDeathTimer	  = 0.f;
	SetFlags(GetFlags() & ~eActorFlagDeath & ~eActorFlagFalling);
	StopJump();
	m_CModel.SetAnimationFlags(ASeModelAniFlagPlay | ASeModelAniFlagLoop);
	m_CModel.SetAnimation(ANIMATION_WALK);
}

/*
	Stops jumping
*/
void TActorUrl::StopJumping()
{
	TParticleGroupDust* pCDustEntity;
	ASTParticle SParticle;
	float fLength = m_vGravity.GetLength(), fZ;

	if (fLength > 1.f &&
		CGame.pCLevel->GetHeight(GetPos().fX, GetPos().fY, fZ) &&
		(pCDustEntity = (TParticleGroupDust*) CGame.pCLevel->CParticleGroupDust.GetEntity())) {

		// Create dust particles
		for (int i = 0; i < 10 * fLength * _AS::CConfig.GetParticleDensity(); i++) {
			memset(&SParticle, 0, sizeof(ASTParticle));
			SParticle.bActive = true;
			SParticle.fSize = fLength + (float) (rand() % 100) / 100.f;
			SParticle.fColor[A] = SParticle.fEnergie = 0.8f + (float) (rand() % 100) / 500.f;
			SParticle.vPos = GetPos();

			CGame.pCLevel->GetHeight(SParticle.vPos.fX, SParticle.vPos.fY, SParticle.vPos.fZ);
			SParticle.vPos.fZ -= 1.f;

			SParticle.vVelocity.fX = (float) (rand() % 200) / 100.f * fLength;
			if (!(rand() % 2)) SParticle.vVelocity.fX = -SParticle.vVelocity.fX;
			SParticle.vVelocity.fY = (float) (rand() % 200) / 100.f * fLength;
			if (!(rand() % 2)) SParticle.vVelocity.fY = -SParticle.vVelocity.fY;
			SParticle.vVelocity.fZ = - fLength * 2 - (float) (rand() % 200) / 50.f * fLength;

			SParticle.fColor[R] = SParticle.fColor[G] = SParticle.fColor[B] = SParticle.fEnergie;

			// Add the new particle to the dust particle group
			pCDustEntity->AddParticle(SParticle);
		}
	}

	// Stop jumping
	m_vGravity = 0.f;
	StopJump();
}

/*
	Main.cpp

    Last change:
    	24.6.2000

    Description:
		Here occur the program start his inits and his 'dead'.
*/

#include "AS\AS_ENGINE.h"
#include "KeysInfo.h" // Bind the available key actions


// Functions: *****************************************************************
int PASCAL WinMain(HINSTANCE, HINSTANCE, LPSTR, int);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
AS_ENGINE *ASEngine = NULL; // The engine
LEVEL *Level = NULL; // Our loaded level
AS_CAMERA *Camera = NULL; // The camera
///////////////////////////////////////////////////////////////////////////////


int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine, int nCmdShow)
{ // begin WinMain()
	BOOL bTFullScreen;

	bModuleEnd = FALSE;
	bProgramEnd = FALSE;
	strcpy(byLoadLevel, "\0");
	
	// Engine stuff:
	iASResult = ASCreatEngine(&ASEngine, hInstance, nCmdShow);
	if(iASResult != AS_ERROR_NONE)
		return FALSE;
	ASEngine->Init(GAME_INI_FILE);
	if(Config.bFirstRun == TRUE)
	{
		MessageBox(NULL, "This is the first program start please check the setup.\n"
						 "Please see the help for informations.\n", GAME_NAME, MB_OK | MB_ICONINFORMATION);
		bTFullScreen = Config.bFullScreen;
		Config.bFullScreen = FALSE;
	}
	// DInput stuff:
    if(ASInitDInput() != AS_ERROR_NONE) 
    {
        MessageBox(NULL, "Failed to initialize DirectInput.", "Error", MB_ICONERROR | MB_OK);
        PostQuitMessage(1);
    }
    else
	{ // Create the input devices:
		ASDInputInitDevice((GUID *) &GUID_SysKeyboard, lpdiKeyboard, &lpdiKeyboard2);
		if(!lpdiKeyboard2)
			MessageBox(NULL, "Couldn't create the keyboard DInput device.\nI will use now the standart keyboard.", "Error", MB_ICONERROR | MB_OK);
		// We do not need the mouse for this game!		
//		ASDInputInitDevice((GUID *) &GUID_SysMouse, lpdiMouse, &lpdiMouse2);
		ASDInputSetAcquireState(TRUE);
		ASEnumerateDInputKeys();
		if(!Config.bFirstRun)
			ASGiveKeyNamesKeyCodes();
	}
	// Init the OpenGl stuff:
	InitGL(&hWndMain, GAME_TITLE, GAME_NAME);
	//  DSound stuff:
    if(FAILED(DSUtil_InitDirectSound(hWndMain)))
    {
        MessageBox(NULL, "Failed to initialize DirectSound.", "Error", MB_ICONERROR | MB_OK);
		bASSoundPossible = FALSE;
	}
	else
		bASSoundPossible = TRUE;
	// Check if we want to show the setup dialog:
	if(!strcmp(lpCmdLine, "-setup") || Config.bFirstRun) 
	{
		Config.bFullScreen = bTFullScreen;
		OpenSetupDialog(); // Yes! Open now the setup menu:
	}
	// What a module should be start?
	if(!strcmp(lpCmdLine, "-editor")) 
		iASSetActiveModule = EDITOR;
	if(!strcmp(lpCmdLine, "-game") || !strcmp(lpCmdLine, "")) 
		iASSetActiveModule = GAME;
    // The main loop:
	for(; !bProgramEnd;)
	{
		switch(iASSetActiveModule)
		{
			case GAME: GameMain(); break; // We want to play the game
			case EDITOR: EditorMain(); break; // We will create our own levels
			default: bProgramEnd = TRUE;
		}
	}
	// Shut down OpenGL:
	DestroyGL(GAME_NAME, &hWndMain);
	// Destroy the DInput:
    ASDestroyDInput();
    // Destroy the DSound:
	DSUtil_FreeDirectSound();
	// Terminate the engine stuff:
	ASDestroyEngine(&ASEngine);
	return FALSE;
} // end WinMain()
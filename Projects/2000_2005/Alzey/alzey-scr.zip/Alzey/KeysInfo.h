/*
	KeysInfo.h

    Last change:
    	24.6.2000

    Description:
		This are the action keys -> 
		The user could define the keys by self.
*/

#ifndef __KEYS_INFO_H__
#define __KEYS_INFO_H__


int ASUsedKeys = 6; // The number of actions

AS_KEY_ACTION ASKeyAction[6] = 
{
	{"Walk left", 0, AS_KEYBOARD, 203, "", "NACH-LINKS-TASTE"},
	{"Walk up", 0, AS_KEYBOARD, 200, "", "NACH-OBEN-TASTE"},
	{"Walk right", 0, AS_KEYBOARD, 205, "", "NACH-RECHTS-TASTE"},
    {"Walk down", 0, AS_KEYBOARD, 208, "", "NACH-UNTEN-TASTE"},
    {"Zoom out", 0, AS_KEYBOARD, 209, "", "BILD-AB-TASTE"},
    {"Zoom in", 0, AS_KEYBOARD, 201, "", "BILD-AUF-TASTE"},
};


#endif // __KEYS_INFO_H__

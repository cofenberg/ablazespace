/*
	GameHeaders.h

    Last change:
    	24.6.2000

    Description:
		General game stuff.
*/

#ifndef __GAME_HEADERS_H__
#define __GAME_HEADERS_H__


#include "../Level.h" 
#include "../Actor.h" 
#include "../GameMain.h" 
#include "../Editor.h" 
#include "../Intro.h" 


#endif // __GAME_HEADERS_H__
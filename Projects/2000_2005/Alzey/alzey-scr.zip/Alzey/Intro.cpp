/*
	Intro.cpp

    Last change:
    	24.6.2000

    Description:
		The AblazeSpace intro.
*/

#include "AS\AS_ENGINE.h"


// Functions: *****************************************************************
/*
HRESULT INTRO::Load(void);
HRESULT INTRO::Destroy(void);
void INTRO::Init(void);
void INTRO::Play(void);
*/
HRESULT DrawIntro(void);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
INTRO Intro;
float fNextTextTime;
float fTextTime = 1000.0f;
int iText;
float fTestZPos;
BOOL bASIntroOut = FALSE;
AS_BITMAP AblzaeSpaceBitmap;
AS_PARTICLE_HOLDER AblzaeSpaceParticles;
AS_OBJECT *pAblaze;
float fBackgroundRot;
///////////////////////////////////////////////////////////////////////////////


// Class functions:
HRESULT INTRO::Load(void)
{ // begin INTRO::Load()
	sprintf(byASTemp, "%s\\%s\\PAblazeSpace.pcx", byASProgramPath, byASBitmapsFile);
	ASLoadPCX(byASTemp,  &AblzaeSpaceBitmap);
	AblzaeSpaceBitmap.fScale = 0.2f;
	AblzaeSpaceBitmap.fZPos = 20.f;
	AblzaeSpaceBitmap.bySpecialColor = 0;
	return AS_ERROR_NONE;
} // end INTRO::Load()

HRESULT INTRO::Destroy(void)
{ // begin INTRO::Destroy()
	DestroyObject(&pAblaze);
	AblzaeSpaceParticles.Destroy();
	if(!AblzaeSpaceBitmap.Bitmap)
		free(AblzaeSpaceBitmap.Bitmap);
	AblzaeSpaceBitmap.Bitmap = NULL;
	return AS_ERROR_NONE;
} // end INTRO::Destroy()

void INTRO::Init(void)
{ // begin INTRO::Init()
	A_Camera.Init();
	Alzey_Camera.Init();
	fNextTextTime = 0.0f;
	fTextTime = 1000.0f;
	iText = 0;
	fTestZPos = -10.0f;
	bASIntroOut = FALSE;
	fBackgroundRot = 0.0f;
	ASDrawFunction = DrawIntro;
	// Init the particle text:
	AblzaeSpaceParticles.fSlowdown = 500.0f;
	AblzaeSpaceParticles.iParticleType = 0;
	AblzaeSpaceParticles.fDistribution = 10.0f;
	AblzaeSpaceParticles.fFade = -1.0f;
	AblzaeSpaceParticles.fRFadeMin = 0.0001f;
	AblzaeSpaceParticles.fRFadeMax = 0.01f;
	AblzaeSpaceParticles.fRedColor = -1.0f;
	AblzaeSpaceParticles.fGreenColor = -1.0f;
	AblzaeSpaceParticles.fBlueColor = -1.0f;
	AblzaeSpaceParticles.fPos[X] = 0.0f;
	AblzaeSpaceParticles.fPos[Y] = 0.0f;
	AblzaeSpaceParticles.fPos[Z] = -10.0f;
	AblzaeSpaceParticles.fSpeed[X] = 0.0f;
	AblzaeSpaceParticles.fSpeed[Y] = 10.0f;
	AblzaeSpaceParticles.fSpeed[Z] = 0.0f;
	AblzaeSpaceParticles.fRSpeed[X] = 0.005f;
	AblzaeSpaceParticles.fRSpeed[Y] = 0.001f;
	AblzaeSpaceParticles.fRSpeed[Z] = 0.01f;
	AblzaeSpaceParticles.fSpeedIncrease[X] = 0.0f;
	AblzaeSpaceParticles.fSpeedIncrease[Y] = .5f;
	AblzaeSpaceParticles.fSpeedIncrease[Z] = 0.0f;
	AblzaeSpaceParticles.Init(AblzaeSpaceBitmap.iWidth*AblzaeSpaceBitmap.iHeight);
	ASSpeedControl();
} // end INTRO::Init()

void INTRO::Play(void)
{ // begin INTRO::Play()
	int i;
	
	DrawIntro();

	if(!ASSpeedControl())
		return;
	fNextTextTime += (float) 0.1f*lASDeltaT;
	if(fNextTextTime > fTextTime)
	{
		fNextTextTime = 0;
		iText++;
		fTestZPos = -10.0f;
		fTextTime = 1000;
	}
	fTestZPos -= 0.001f*lASDeltaT;
	fBackgroundRot += 0.001f*lASDeltaT; // Background motion velocity
	AblzaeSpaceParticles.Check(!bASIntroOut, &AblzaeSpaceBitmap);

	if(AblzaeSpaceParticles.fSpeedIncrease[Y] >= 0.0f && !bASIntroOut)
		AblzaeSpaceParticles.fSpeedIncrease[Y] -= 0.0001f*lASDeltaT;
	else
	{
		if(bASIntroOut)
			AblzaeSpaceParticles.fSpeedIncrease[Y] -= 0.001f*lASDeltaT;
	}
	if(keys[VK_ESCAPE])
		bProgramEnd = TRUE;
	for(i = 0; i < 256; i++)
		if(keys[i])
		{
			bGameIntro = FALSE;
			InitGame(FALSE);
		}
	if(bGameIntro == FALSE)
		for(i = 0; i < 256; i++)
			keys[i] = FALSE;
} // end INTRO::Play()

HRESULT DrawIntro(void)
{ // begin DrawIntro()
	int i;

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	// Draw Background:
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);
	glDisable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);
	glLoadIdentity();									
	glTranslatef(0.0f, 0.0f, -30.0f);
	glColor4ub(255,255,255,255);
	glMatrixMode(GL_TEXTURE_2D);
	glRotatef(180.0f*float(cos(fBackgroundRot/10.0f)),0.0f,0.0f,1.0f);
	glTranslatef((3.0f*float(cos(fBackgroundRot)))+(2.1f*float(sin(fBackgroundRot*1.4f))),
				(2.8f*float(sin(fBackgroundRot)))+(1.3f*float(sin(fBackgroundRot*1.4f))), 0.0f);
	glRotatef(10.0f*float(sin(fBackgroundRot*1.2f)),1.0f,0.0f,0.0f);
	glMatrixMode(GL_MODELVIEW);
	glCallList(iBackgroundList);
	// Draw the particle name:
	glLoadIdentity();									
	glRotatef(180, 1.0f, 0.0f, 0.0f);
	glColor3f(1.0f, 0.5f, 1.0f);
	glDisable(GL_DEPTH_TEST);
	AblzaeSpaceParticles.Draw();
	// Draw the texts:	
	glLoadIdentity();									
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glDisable(GL_LIGHTING);
	glColor4ub(255,255,255,255);
	switch(iText)
	{
		case 0:
			glLoadIdentity();									
			FontBPrintCentered(0, fTestZPos, -5.0f, "The AblazeSpace project 2000");
		break;

		case 1:
			glLoadIdentity();									
			FontBPrintCentered(0, fTestZPos, -5.0f, "by Christian Ofenberg");
			if(!bASIntroOut)
				for(i = 0; i < AblzaeSpaceParticles.iParticles; i++)
				{
					if(!AblzaeSpaceParticles.pParticle[i].bActive)
						continue; // The particle isn't active
					AblzaeSpaceParticles.pParticle[i].fFade = 0.001f;
				}
			AblzaeSpaceParticles.fFade = 0.001f;
			bASIntroOut	= TRUE;
		break;

		case 2:
			for(i = 0; i < AblzaeSpaceParticles.iParticles; i++)
			{
				if(AblzaeSpaceParticles.pParticle[i].bActive)
					goto Next;
			}
			bGameIntro = FALSE;
			InitGame(FALSE);
		Next:
		break;
	}
	ASSwapBuffers(hDC);
	return AS_ERROR_NONE;
} // end DrawIntro()
/*
	WindowProc.cpp

    Last change:
    	24.6.2000

    Description:
		Deals with the window messages. 
*/

#include "AS\AS_ENGINE.h"


// Functions: *****************************************************************
LRESULT CALLBACK WindowProc(HWND, unsigned, WPARAM, LPARAM);
///////////////////////////////////////////////////////////////////////////////


LRESULT CALLBACK WindowProc(HWND hWnd, unsigned uMsg, WPARAM wParam, LPARAM lParam)
{ // begin WindowProc()
    int i;

	switch(uMsg)
    {
		case WM_KEYDOWN:
			keys[wParam] = true;
		break;

		case WM_KEYUP:
			keys[wParam] = false;
		break;

		case WM_ACTIVATEAPP:
			#ifdef _DEBUG
				if(wParam) 
					OutputDebugString("Anwendung aktiviert!\n");
				else 
					OutputDebugString("Anwendung deaktiviert!\n");
			#endif // _DEBUG
			bProgramActive = wParam;
			break;

		case WM_SIZE:
			if(wParam == SIZE_MINIMIZED)
			{
				// We've been minimized, no need to
				// redraw the screen.
				InvalidateRect(hWnd, NULL, TRUE);
				bProgramActive = FALSE;
			}
			else
				bProgramActive = TRUE;
			ASSpeedControl();
			dwNewTime = GetTickCount();
			Config.iWindowWidth = LOWORD(lParam);
			Config.iWindowHeight = HIWORD(lParam);
			ReSizeGL();
			break;

   		case WM_SETCURSOR:
			SetCursor(LoadCursor(NULL, IDC_ARROW));
			return TRUE;

        case WM_PAINT:
            if(!ASDrawFunction)
				break;
			ASDrawFunction();
			break;

		case WM_MOVE:
            GetClientRect(hWnd, &MainWindow);
            ClientToScreen(hWnd, (LPPOINT) &MainWindow);
            ClientToScreen(hWnd, (LPPOINT) &MainWindow+1);
		break;

        case WM_DESTROY:
            if(!bNewSetting)
				bProgramEnd = TRUE;
            break;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {				
				case IDM_ABOUT:
					OpenAboutDialog();
					break;

				case IDM_HELP: // Opens the help file:
					ShellExecute(0, "open", "help.html", 0, 0, SW_SHOW);
				break;

				case IDM_HELP_VISIT_HOMEPAGE: // Goes to the AblezeSpace homepage:
					ShellExecute(0, "open", "http://AblazeSpace.exit.de/", 0, 0, SW_SHOW);
				break;

				case IDM_HELP_VISIT_UCS: // Goes to the UCS homepage:
					ShellExecute(0, "open", "http://www.ucs.exit.de/", 0, 0, SW_SHOW);
				break;

			// Editor:
				case ID_EDITOR_FILE_GAME: // Go into the game
					iASSetActiveModule = GAME;
					strcpy(byLoadLevel, "\0");
				break;

				case ID_EDITOR_ACTOR_ATTRIBUTE_MENU:
					for(i = 0; i < iActors; i++)
					{
						if(!Actor[i])
							continue;
						if(Actor[i]->iXPos == EditorCursor->iXPos &&
						   Actor[i]->iYPos == EditorCursor->iYPos)
						{ // We've found an actor:
							OpenActorDialog(Actor[i]);
							break;
						}
					}
				break;
				
				case ID_EDITOR_SET_LEFT_WALL:	
					Level->SwitchWall(EditorCursor->iXPos, EditorCursor->iYPos, LEFT);
				break;

				case ID_EDITOR_SET_UP_WALL:	
					Level->SwitchWall(EditorCursor->iXPos, EditorCursor->iYPos, TOP);
				break;

				case ID_EDITOR_SET_RIGHT_WALL:	
					Level->SwitchWall(EditorCursor->iXPos, EditorCursor->iYPos, RIGHT);
				break;

				case ID_EDITOR_SET_DOWN_WALL:	
					Level->SwitchWall(EditorCursor->iXPos, EditorCursor->iYPos, BOTTOM);
				break;
				
				case ID_EDITOR_SET_OBJECT: EditorSetObject(); break;
				
				case ID_EDITOR_OPTIONS_SETUP:
					OpenSetupDialog();
					break;

				case ID_EDITOR_FILE_NEW_LEVEL:
					OpenLADialog(&Level, LA_CREATE);
					EditorLevel();
				break;

				case ID_EDITOR_FILE_LOAD_LEVEL:
					sprintf(byASTemp, "%s\\%s", byASProgramPath, byASUserLevelsFile);
					SetCurrentDirectory(byASTemp);
					pbyASTemp = ASGetFileName(hWndMain, "Open Level", LEVEL_FILES, 0);
					iASResult = Level->Load(pbyASTemp, (void ***) &Actor);
					if(!pbyASTemp || iASResult != AS_ERROR_NONE)
						break;
					EditorLevel();
					EditorCursor->iXPos = 0;
					EditorCursor->iYPos = 0;
					EditorCursor->fPos[Z] = -0.5f;
				break;

				case ID_EDITOR_FILE_SAVE_LEVEL:
					if(Level->byFileName[0] == '\0')
						goto SaveAs;
					Level->Save(Level->byFileName, (void **) Actor, iActors);
				break;

				case ID_EDITOR_FILE_SAVE_LEVEL_AS:
				SaveAs:
					sprintf(byASTemp, "%s\\%s", byASProgramPath, byASUserLevelsFile);
					SetCurrentDirectory(byASTemp);
					Level->Save(ASGetFileName(hWndMain, "Save Level", LEVEL_FILES, 1),
								(void **) Actor, iActors);
					if(Level->byFileName[0] != '\0')
						EnableMenuItem(GetMenu(hWndMain), ID_EDITOR_FILE_SAVE_LEVEL, MF_ENABLED);
				break;

				case ID_EDITOR_FILE_DESTROY_LEVEL:
					Level->Destroy();
					EditorNoLevel();
				break;					

				case ID_EDITOR_FILE_QUIT:
					PostMessage(hWnd, WM_CLOSE, 0, 0);
				break;

				case ID_EDITOR_LEVEL_ADJUST:
					OpenLADialog(&Level, LA_ADJUST);
				break;

				case ID_EDITOR_LEVEL_PLAY:
					if(Level->byFileName[0] == '\0')
					{
						sprintf(byASTemp, "%s\\%s", byASProgramPath, byASUserLevelsFile);
						SetCurrentDirectory(byASTemp);
						pbyASTemp = ASGetFileName(hWndMain, "Save Level", LEVEL_FILES, 1);
						if(!pbyASTemp)
							break;
						Level->Save(pbyASTemp, (void **) Actor, iActors);
					}
					else
						Level->Save(Level->byFileName, (void **) Actor, iActors);
					iASSetActiveModule = GAME;
					strcpy(byLoadLevel, Level->byFileName);
				break;

				case ID_EDITOR_SELECT_PLAYER: iSelectedObject = ACTOR_PLAYER; break;
				case ID_EDITOR_SELECT_E_FOOL: iSelectedObject = ACTOR_E_FOOL; break;
				case ID_EDITOR_SELECT_E_NORMAL: iSelectedObject = ACTOR_E_NORMAL; break;
				case ID_EDITOR_SELECT_E_TERMINATOR: iSelectedObject = ACTOR_E_TERMINATOR; break;
				case ID_EDITOR_SELECT_P_REINCARNATION: iSelectedObject = ACTOR_P_REINCARNATION; break;
				case ID_EDITOR_SELECT_E_REINCARNATION: iSelectedObject = ACTOR_E_REINCARNATION; break;
				case ID_EDITOR_SELECT_DIAMOND: iSelectedObject = ACTOR_DIAMOND; break;
				case ID_EDITOR_SELECT_FRUIT_1: iSelectedObject = ACTOR_FRUIT_1; break;
				case ID_EDITOR_SELECT_HERO: iSelectedObject = ACTOR_HERO; break;
				case ID_EDITOR_SELECT_BOMB: iSelectedObject = ACTOR_BOMB; break;
				case ID_EDITOR_SELECT_HOURGLASS: iSelectedObject = ACTOR_HOURGLASS; break;
				case ID_EDITOR_SELECT_FREEZE: iSelectedObject = ACTOR_FREEZE; break;
				case ID_EDITOR_SELECT_GHOST: iSelectedObject = ACTOR_GHOST; break;
				case ID_EDITOR_SELECT_SPEED: iSelectedObject = ACTOR_SPEED; break;

			// Game:
				case ID_GAME_FILE_LEVEL_INFO:
					OpenLADialog(&Level, LA_SHOW);				
				break;

				case ID_GAME_FILE_EDITOR: // Goes into the editor
					iASSetActiveModule = EDITOR;
					strcpy(byLoadLevel, Level->byFileName);
				break;

				case ID_GAME_FILE_START_NEW_GAME:
					bSingleLevel = FALSE;
					StartNewGame(1, FALSE);
				break;

				case ID_GAME_FILE_END_LEVEL:
					EndGame();
				break;					

				case ID_GAME_FILE_LOAD_LEVEL:
					sprintf(byASTemp, "%s\\%s", byASProgramPath, byASUserLevelsFile);
					SetCurrentDirectory(byASTemp);
					StartLevel(ASGetFileName(hWndMain, "Open Level", LEVEL_FILES, 0));
					bSingleLevel = TRUE;
				break;					

				case ID_GAME_OPTIONS_SETUP:
					OpenSetupDialog();
					break;

				case ID_GAME_FILE_QUIT:
					PostMessage(hWnd, WM_CLOSE, 0, 0);
					break;
			}
			break;

		case WM_SYSKEYUP:
			switch(wParam)
			{
				case VK_RETURN:
					#ifdef _DEBUG
						OutputDebugString("Alt+Enter...\n");
					#endif // _DEBUG
					GLSwitchDisplayMode();
				break;
			}
			break;

		case WM_CLOSE:
            if(!bNewSetting)
				bProgramEnd = TRUE;
		return 0;

		case WM_ENTERMENULOOP:
			bProgramActive = FALSE;			
			RedrawWindow(hWndMain, NULL, NULL, RDW_FRAME);
			DrawMenuBar(hWndMain);
			break;

		case WM_EXITMENULOOP:
			bProgramActive = TRUE;			
    	  break;
    }
    return DefWindowProc(hWnd, uMsg, wParam, lParam);
} // end WindowProc()
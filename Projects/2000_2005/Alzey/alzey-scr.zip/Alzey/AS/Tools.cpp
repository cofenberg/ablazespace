/*
	Tools.cpp

    Last change:
    	24.6.2000

    Description:
		Some useful tools.
*/

#include "AS_ENGINE.h"


// Functions: *****************************************************************
AUX_RGBImageRec *ASLoadBMP(char *);
HRESULT ASLoadPCX(char *,  AS_BITMAP *);
///////////////////////////////////////////////////////////////////////////////


AUX_RGBImageRec *ASLoadBMP(char *Filename)                // Loads A Bitmap Image
{ // begin ASLoadBMP()
        FILE *File=NULL;                                // File Handle
        if (!Filename)                                  // Make Sure A Filename Was Given
        {
                return NULL;                            // If Not Return NULL
        }
        File=fopen(Filename,"r");                       // Check To See If The File Exists
        if (File)                                       // Does The File Exist?
        {
                fclose(File);                           // Close The Handle
                return auxDIBImageLoad(Filename);       // Load The Bitmap And Return A Pointer
        }
        return NULL;                                    // If Load Failed Return NULL
} // end ASLoadBMP()

HRESULT ASLoadPCX(char *filename,  AS_BITMAP *Bitmap)
{ // begin ASLoadPCX()
	enum { NORMAL, RLE};
	char colordat[65000];
    long i;
    int mode=NORMAL,nbytes;
    char abyte,*p;
    FILE *f;
    PcxFile pcx;

    f = fopen(filename, "rb");
    if(!f)
    	return NULL;
	fread(&pcx.hdr,sizeof(PcxHeader),1,f);
	pcx.width = 1+pcx.hdr.xmax-pcx.hdr.xmin;
	pcx.height = 1+pcx.hdr.ymax-pcx.hdr.ymin;
	pcx.imagebytes = (unsigned long)(pcx.width*pcx.height);
	pcx.bitmap=(char*)malloc(pcx.imagebytes+4);
	if(!pcx.bitmap)
    {
		fclose(f);
	    return(NULL);
    }
	for (i = 0; i < (signed) pcx.imagebytes; i++)
    {
	    if(mode == NORMAL)
		{
			abyte = fgetc(f);
			if((unsigned char)abyte > 0xbf)
		    {
			    nbytes = abyte & 0x3f;
			    abyte = fgetc(f);
			    if(--nbytes > 0)
					mode = RLE;
		    }
		}
	    else
        	if(--nbytes == 0)
		    	mode = NORMAL;
	    pcx.bitmap[i+4] = abyte;
    }
	fseek(f, -768L, SEEK_END);      // get palette from pcx file
	fread(colordat, 768, 1, f);
	p = colordat;
	for(i = 0; i < 768; i++)	       // bit shift palette
    	*p++ = *p >>2;
    fclose(f);
	p = pcx.bitmap;
	(*(short *)p) = pcx.width;
	p += sizeof(short);
	(*(short *)p) = pcx.height;
	Bitmap->iWidth = pcx.width;
	Bitmap->iHeight = pcx.height;
	Bitmap->Bitmap = pcx.bitmap;
    return AS_ERROR_NONE;
} // end ASLoadPCX()
/*
	Setup.h

    Last change:
    	24.6.2000

    Description:
		This is the setup dialog  stuff.
*/

#ifndef __SETUP_H__
#define __SETUP_H__


// Functions: *****************************************************************
extern void OpenAboutDialog(void);
extern LRESULT CALLBACK AboutProc(HWND, UINT, WPARAM, LPARAM);
extern void InitSetupDialog(HWND);
extern BOOL CALLBACK DIEnumDevicesProc(LPCDIDEVICEINSTANCE, LPVOID);
extern void OpenSetupDialog(void);
extern LRESULT CALLBACK SetupProc(HWND, UINT, WPARAM, LPARAM);
///////////////////////////////////////////////////////////////////////////////


#endif // __SETUP_H__
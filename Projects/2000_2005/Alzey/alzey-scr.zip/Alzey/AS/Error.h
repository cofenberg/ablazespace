/*
	Error.h

    Last change:
    	24.6.2000

    Description:
		Error stuff.
*/

#ifndef __AS_ERROR_H__
#define __AS_ERROR_H__


enum
{
    AS_ERROR_NONE = 0, // Es trat kein Fehler auf
	AS_ERROR_ZERO_POINTER, // Ein Zeiger auf Null verursachte einen Fehler
	AS_ERROR_FILE_OPEN, // Eine Datei konnte nicht ge�ffnet werden
	AS_ERROR_FILE_CREATING, // Eine Datei konnte nicht erstellt werden
    AS_ERROR_RESERVE_MEMORY, // Es konnte kein Speicher reserviert werden
    AS_ERROR_MISSING_ARGUMENT_IN_FILE, // In einer Datei fehlte etwas
    AS_ERROR_END_OF_FILE, // Das Datei ende wurde ereicht
	AS_ERROR_POLYGON_HAS_INVALID_POINT, // Ein Polygon hat einen ung�ltigen Punkt
	AS_ERROR_POLYGON_HAS_INVALID_TEXTURE, // Ung�ltige Texture gegeben
	AS_ERROR_DD_CREATE_OBJECT, // Fehler beim Anlegen eines DirectDraw-Objekts
	AS_ERROR_DD2_PORT_NOT_FOUND, // DirectDraw2-Schnittstelle nicht gefunden
	AS_ERROR_DD_SET_COOPERATIVE_LEVEL, // Fehler beim Setzen der Kooperationsebene
	AS_ERROR_ENUMERATE_DISPLAY_DEVICES, // Fehler beim Abz�hlen der DirectDraw-Ger�te
	AS_ERROR_ENUMERATE_DISPLAY_MODES, // Fehler beim Abz�hlen der Videomodi
	AS_ERROR_DD_SET_DISPLAY_MODE, // Der Bildschirm Modus konnte nicht gesetzt werden
	AS_ERROR_DD_WINDOW_CONFIGURE,
	AS_ERROR_DD_FULL_CONFIGURE,
};


#endif // __AS_ERROR_H__
/*
	Particle.h

    Last change:
    	24.6.2000

    Description:
		The particle system.
*/

#ifndef __AS_PARTICLE_H__
#define __AS_PARTICLE_H__


// Definitions: ***************************************************************
#define AS_PARTICLE_TYPES 1 
#define AS_S_PARTICLES 10
///////////////////////////////////////////////////////////////////////////////

// Structures: ****************************************************************
typedef struct
{
	BOOL bActive; // Active (TRUE/FALSE)
	float fLife; // Particle life
	float fFade; // Fade speed 
	float fRedColor, fGreenColor, fBlueColor; // The color values
	float fPos[3]; // The world position
	BOOL bTargetPos; // Will the particle to a special pos?
	float fTargetPos[3]; // The particles 'go to pos'
	float fSpeed[3]; // The moving speed
	float fSpeedIncrease[3]; // The moving speed increase
} AS_PARTICLE;

typedef class
{
	public:
		float fSlowdown;
		int iParticleType; // Particle texture type
		int iParticles; // The number of the maximum particles
		float fDistribution;
		float fFade; // Fade speed (-1.f = random)
		float fRFadeMin; // If fade = random than is this the minimum fade speed
		float fRFadeMax; // If fade = random than is this the maximum fade speed
		float fRedColor, fGreenColor, fBlueColor; // The color values (-1.f = random)
		float fPos[3]; // The particles origin
		float fSpeed[3]; // The start speed
		float fRSpeed[3]; // If start = random than is this the maximum start speed
		float fSpeedIncrease[3]; // The speed increase/decrease
		AS_PARTICLE *pParticle;

		HRESULT Init(int);
		void Destroy(void);
		void InitParticles(AS_BITMAP *);
		void InitParticle(int, AS_BITMAP *);
		void Draw(void);
		void Check(BOOL, AS_BITMAP *);
} AS_PARTICLE_HOLDER;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
/*
HRESULT AS_PARTICLE_HOLDER::Init(int);
void AS_PARTICLE_HOLDER::Destroy(void);
void AS_PARTICLE_HOLDER::InitParticles(AS_BITMAP *);
void AS_PARTICLE_HOLDER::InitParticle(int, AS_BITMAP *);
void AS_PARTICLE_HOLDER::Draw(void);
void AS_PARTICLE_HOLDER::Check(BOOL, AS_BITMAP *);
*/
extern void InitParticleSystem(void);
extern void DestroyParticleSystem(void);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern UINT iASParticleTexture[AS_PARTICLE_TYPES];
extern char byASPTFile[AS_PARTICLE_TYPES][128];
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_PARTICLE_H__
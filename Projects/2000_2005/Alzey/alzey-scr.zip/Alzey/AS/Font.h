/*
	Font.h

    Last change:
    	24.6.2000

    Description:
		Bitmap font functions.
*/

#ifndef __AS_FONT_H__
#define __AS_FONT_H__


// Functions: *****************************************************************
extern void InitFonts(void);
extern void DestroyFonts(void);
extern HRESULT LoadFontTextures(void);
extern void BuildBFont(void);
extern void KillBFont(void);
extern void FontBPrint(int, float, float, float, const char *, ...);
extern void FontBPrintCentered(int, float, float, const char *, ...);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern GLuint FontBBase;				// Base Display List For The Font Set
extern GLuint FontTexture[2];			// Storage For Our Font Texture
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_FONT_H__
/*
	AS_ENGINE.h

    Last change:
    	24.6.2000

    Description:
    	You have to bind this file into your program to be able to use the AblazeSpace engine.
*/

#ifndef __AS_ENGINE_H__
#define __AS_ENGINE_H__


// Some engine definitions:
#define AS_VERSION "0.01" // Version

typedef class
{
	public:
		char Version[128], Date[128], Time[128];

		void Init(void);
} PROGRAM_INFO;

extern PROGRAM_INFO ProgramInfo;
////////////////////////////////////////////////////////////////////////////////

#include "BibIncludes.h"

#include "../resource.h"

#include "TypeDefs.h"
#include "Defs.h"


// Engine includes:
#include "Config.h"
#include "File.h"
#include "Font.h"
#include "Error.h"
#include "Setup.h"
#include "DInput/DInput.h"
#include "DSound/DSound.h"
#include "OpenGL/GLMain.h"
#include "../WindowProc.h"
#include "Particle.h" 
#include "Object.h" 
#include "Wrl.h" 
#include "Math3d.h" 
#include "Tools.h" 

// Structures: ****************************************************************
typedef class
{
    public:
        HRESULT Clean(void);
        HRESULT Init(char *);
        HRESULT Destroy(void);
		HRESULT CheckFPS(void);
	private:
} AS_ENGINE;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern HRESULT ASEmptyDraw(void);
extern void ASSwapBuffers(HDC);
extern HRESULT ASCreatEngine(AS_ENGINE **, HINSTANCE, int);
extern HRESULT ASDestroyEngine(AS_ENGINE **);
extern HWND ASCreateWindow(HINSTANCE, WNDPROC, char *, char *, DWORD, DWORD, HMENU, BOOL);
extern HRESULT ASDestroyWindow(HWND *, char *);
extern HRESULT ASEnumerateDisplayModeInfos(void);
extern HRESULT ASAddDisplayModeInfo(DEVMODE);
extern HRESULT ASDestroyDisplayModeInfo(void);
extern HRESULT ASCreateCamera(AS_CAMERA **);
extern HRESULT ASDestroyCamera(AS_CAMERA **);
extern void CheckCameraInput(AS_CAMERA *);
extern BOOL ASPlayMidi(HWND, char *);
extern BOOL ASStopMidi(void);
extern void ASGiveKeyNamesKeyCodes(void);
extern BOOL ASSpeedControl(void);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern UINT iASLists;
extern char keys[256];
extern HWND hWndMain;
extern LPTSTR pMainMenu;
extern RECT MainWindow;
extern HRESULT iASResult;
extern char byASTemp[MAX_PATH];
extern char *pbyASTemp;
extern char *pbyASTemp;
extern int iCmdShow;
extern HDC hDC;
extern HGLRC hRC;
extern HINSTANCE hInstance;
extern HANDLE hMutex;
extern BOOL bASSoundPossible;
extern BOOL bModuleEnd;
extern BOOL bProgramEnd;
extern BOOL bProgramActive;
extern BOOL bNewSetting;
extern int iASActiveModule, iASSetActiveModule; // The active game part (module)
extern HRESULT (*ASDrawFunction)(void);
extern AS_INPUT_KEYS InputKeys[AS_MAX_INPUT_BUTTONS];
extern char byASConfigFile[MAX_PATH];
extern char byASHighscoreFile[MAX_PATH];
extern char byASLevelsFile[MAX_PATH];
extern char byASUserLevelsFile[MAX_PATH];
extern char byASObjectsFile[MAX_PATH];
extern char byASBitmapsFile[MAX_PATH];
extern char byASProgramPath[_MAX_DRIVE+_MAX_DIR];
extern char ExeName[_MAX_PATH];
extern char Drive[_MAX_DRIVE];
extern char Dir[_MAX_DIR];
extern char Directory[];
extern char byASUserName[MAX_PATH];
extern DWORD dwAS_FPS_TimeNow, dwAS_FPS_TimeLast, dwAS_FPS_TimeDifference;
extern int iAS_FPS_RenderedFrames, iAS_FPS_FramesSinceCheck, iAS_FPS;
extern long lASTLast, lASTNow, lASDeltaT;
extern float fASDeltaT;
///////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////

// Game stuff:
#include "../GameHeaders.h"
#include "../Game.h"


#endif // __AS_ENGINE_H__
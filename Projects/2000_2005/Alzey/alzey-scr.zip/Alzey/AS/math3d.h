/*
	Math3D.h

    Last change:
    	24.6.2000

    Description:
		Math stuff.
*/

#ifndef __AS_MATH_3D_H__
#define __AS_MATH_3D_H__


// Functions: *****************************************************************
extern void ASMathRotateArbitrary(float *, float *, float *,
								  float, float, float, float);
extern void ASNormalizePlane(AS_VERTEX *, AS_VERTEX, AS_VERTEX, AS_VERTEX);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_MATH_3D_H__

/*
	Defs.h

    Last change:
    	24.6.2000

    Description:
		A lot of general definitions.
*/

#ifndef __AS_DEFS_H__
#define __AS_DEFS_H__


// Definitions: ***************************************************************
enum {LEFT_TOP, RIGHT_TOP, RIGHT_BOTTOM, LEFT_BOTTOM};
enum {LEFT, TOP, RIGHT, BOTTOM};
enum {AS_KEYBOARD, AS_MOUSE};
#define AS_MAX_MOUSE_BUTTONS 4
#define AS_MAX_JOYSTICK_BUTTONS 32
#define AS_MAX_KEYBOARD_BUTTONS 256
#define AS_MAX_INPUT_BUTTONS 292
#define AS_FORMAT_TOKENS " ,\t\r\n"
#define MODE_OVERLAY	1
#define MODE_FULL		2
#define MODE_WINDOWED	3

#define Dot_product(a, b)\
	((a)[X]*(b)[X]+(a)[Y]*(b)[Y]+(a)[Z]*(b)[Z])

#define CrossProductVer(n, a, b)\
	((n).ox = (a).oy*(b).oz-(a).oz*(b).oy,\
     (n).oy = (a).oz*(b).ox-(a).ox*(b).oz,\
     (n).oz = (a).ox*(b).oy-(a).oy*(b).ox)

#define Add_vec(AB, a, b)\
	((AB)[X] = (b)[X]+(a)[X],\
     (AB)[Y] = (b)[Y]+(a)[Y],\
     (AB)[Z] = (b)[Z]+(a)[Z])

#define SubtVer(AB, a, b)\
	((AB).ox = (b).ox-(a).ox,\
     (AB).oy = (b).oy-(a).oy,\
     (AB).oz = (b).oz-(a).oz)


enum {X, Y, Z};
enum {POS, ROT, SCALE};
#define CAMERA_VDECREASE 0.1f
#define MAX_CAMERA_VELOCITY 2.0f

#ifndef PI
#define PI 3.14159265359
#endif

#define SINSHIFT 8

#define AS_MAX_NAME_LENGTH 256 // Die maximale L�nge von Namen

#define MAX_LIGHTS 4
#define MAX_SYST (MAX_LIGHTS + 1)

#define AS_SCREEN_WIDTH 640
#define AS_SCREEN_HEIGHT 480

#define AS_MAX_Z_BUFFER_DEEP 650000

// Polygon ausf�ll Methoden:
enum 
{
	AS_DRAW_DOTS = 0,
	AS_DRAW_WIREFRAME,
	AS_DRAW_SOLD,
    AS_DRAW_SHADE,
    AS_DRAW_TEXTURE,
    AS_DRAW_TEXTURE_SHADE,
	AS_DRAW_INDIVIDUAL,
};
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_DEFS_H__
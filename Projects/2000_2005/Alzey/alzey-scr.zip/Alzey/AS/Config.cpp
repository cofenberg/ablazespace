/*
	Config.cpp

    Last change:
    	24.6.2000

    Description:
		Loads, saves and deals with the configurations.
*/

#include "AS_ENGINE.h"


// Functions: *****************************************************************
// HRESULT CONFIG::Check(void);
// HRESULT CONFIG::Load(char *);
// HRESULT CONFIG::Save(char *)
void FindConfigMode(void);
HRESULT LoadKeySpecification(char *);
HRESULT SaveKeySpecification(char *);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
CONFIG Config;
DISPLAY_MODE_INFO DisplayModeInfo;
///////////////////////////////////////////////////////////////////////////////


void FindConfigMode(void)
{ // begin FindConfigMode()
	int i;

	for(i = 0; i < DisplayModeInfo.Number; i++)
	{
		if(Config.DevMode.dmPelsWidth == DisplayModeInfo.pDevMode[i].dmPelsWidth && 
		   Config.DevMode.dmPelsHeight == DisplayModeInfo.pDevMode[i].dmPelsHeight && 	
		   Config.DevMode.dmBitsPerPel == DisplayModeInfo.pDevMode[i].dmBitsPerPel && 
		   Config.DevMode.dmDisplayFrequency == DisplayModeInfo.pDevMode[i].dmDisplayFrequency)
		{
			Config.iModeIndex = i;
			CopyMemory(&Config.DevMode, &DisplayModeInfo.pDevMode[Config.iModeIndex], sizeof(DEVMODE));
			break;
		}
	}
} // end FindConfigMode()

HRESULT LoadKeySpecification(char *pbyFileName)
{ // begin LoadKeySpecification()
	int i;

	sprintf(byASTemp, "%s\\%s", byASProgramPath, Config.byKeyFile);
	for(i = 0; i < ASUsedKeys; i++)
	{
		GetPrivateProfileString("Keys", ASKeyAction[i].byAction, ASKeyAction[i].byStandartKey, ASKeyAction[i].byKeyName, MAX_PATH, byASTemp);
		pbyASTemp = ASChangeToken(ASKeyAction[i].byKeyName, '_', ' ');
		strcpy(ASKeyAction[i].byKeyName, pbyASTemp);
		free(pbyASTemp);
		pbyASTemp = NULL;
	}
	return AS_ERROR_NONE;
} // end LoadKeySpecification()

HRESULT SaveKeySpecification(char *pbyFileName)
{ // begin SaveKeySpecification()
	FILE *pFile;
	int i;
	char *pbyTemp;

	pFile = fopen(pbyFileName, "wt");
	if(!pFile)
		return AS_ERROR_FILE_OPEN;
	fprintf(pFile, "# This are the key specifications:\n");
	fprintf(pFile, "[Keys]\n");
	for(i = 0; i < ASUsedKeys; i++)
	{
		pbyTemp = ASChangeToken(ASKeyAction[i].byKeyName, ' ', '_');
		fprintf(pFile, "%s = %s\n", ASKeyAction[i].byAction, pbyTemp);
		free(pbyTemp);
	}
	fclose(pFile);
	return AS_ERROR_NONE;
} // end SaveKeySpecification()


// Class functions:
void CONFIG::Check(void)
{ // begin CONFIG::Check()
	if(!DevMode.dmSize)
		DevMode.dmSize = sizeof(DEVMODE);
	iScreenPixels = DevMode.dmPelsWidth*DevMode.dmPelsHeight;
	iScreenSize = DevMode.dmPelsWidth*DevMode.dmPelsHeight*(DevMode.dmBitsPerPel/8);
	DevMode.dmFields = DM_BITSPERPEL | DM_PELSWIDTH | DM_PELSHEIGHT;
} // end CONFIG::Check()

HRESULT CONFIG::Load(char *pbyFileName)
{ // begin CONFIG::Load()
	// The number of Alzey level:
	LEVELS = GetPrivateProfileInt("General", "levels", 21, pbyFileName);
	//////////
	bFirstRun = GetPrivateProfileInt("General", "FirstRun", 1, pbyFileName);
	bFullScreen = GetPrivateProfileInt("General", "fullscreen", 1, pbyFileName);
	bSound = GetPrivateProfileInt("General", "sound", 1, pbyFileName);
	bMusic = GetPrivateProfileInt("General", "music", 1, pbyFileName);
	byLight = GetPrivateProfileInt("General", "light_mode", 0, pbyFileName);
	bShowFPS = GetPrivateProfileInt("General", "show_fps", 0, pbyFileName);
	DevMode.dmPelsWidth = GetPrivateProfileInt("General", "width", 640, pbyFileName);
	DevMode.dmPelsHeight = GetPrivateProfileInt("General", "height", 480, pbyFileName);
	DevMode.dmBitsPerPel = GetPrivateProfileInt("General", "colordepth", 16, pbyFileName);
	DevMode.dmDisplayFrequency = GetPrivateProfileInt("General", "refresh_rate", 0, pbyFileName);
	iColorDepthFilter = GetPrivateProfileInt("General", "color_depth_filter", 16, pbyFileName);
	iWindowWidth = GetPrivateProfileInt("General", "window_width", 640, pbyFileName);
	iWindowHeight = GetPrivateProfileInt("General", "window_height", 480, pbyFileName);
	GetPrivateProfileString("General", "key_file", "user.ini", byKeyFile, MAX_PATH, pbyFileName);
	sprintf(byASTemp, "%s\\%s", byASProgramPath, byKeyFile);
	LoadKeySpecification(byASTemp);
	Check();
	return AS_ERROR_NONE;
} // end CONFIG::Load()

HRESULT CONFIG::Save(char *pbyFileName)
{ // begin CONFIG::Save()
	FILE *pFile;

	pFile = fopen(pbyFileName, "wt");
	if(!pFile)
		return AS_ERROR_FILE_CREATING;
	fprintf(pFile, "[General]\n");
	///////////////
	fprintf(pFile, "# The number of Alzey levels:\n");
    fprintf(pFile, "levels = %d\n\n", LEVELS);
	///////////////
	fprintf(pFile, "# Is this the first program start? (1 = YES / 0 = NO):\n");
    fprintf(pFile, "firstrun = %d\n", bFirstRun);
	fprintf(pFile, "# Should the program run in fullscreen? (1 = YES / 0 = NO):\n");
    fprintf(pFile, "fullscreen = %d\n", bFullScreen);
	fprintf(pFile, "# Play sound? (1 = YES / 0 = NO):\n");
    fprintf(pFile, "sound = %d\n", bSound);
	fprintf(pFile, "# Play music? (1 = YES / 0 = NO):\n");
    fprintf(pFile, "music = %d\n", bMusic);
	fprintf(pFile, "# Light mode: (0 = none / 1 = flat / 2 = smooth):\n");
    fprintf(pFile, "light_mode = %d\n", byLight);
	fprintf(pFile, "# Display FPS? (1 = YES / 0 = NO):\n");
    fprintf(pFile, "show_fps = %d\n", bShowFPS);
    fprintf(pFile, "# Screen resolution and colordepth:\n");
	fprintf(pFile, "width = %d\n", DevMode.dmPelsWidth);
	fprintf(pFile, "height = %d\n", DevMode.dmPelsHeight);
	fprintf(pFile, "colordepth = %d\n", DevMode.dmBitsPerPel);
	fprintf(pFile, "refresh_rate = %d HZ\n", DevMode.dmDisplayFrequency);
    fprintf(pFile, "# This is the color depth filter f�r the setup menu:(0 = show all color depth)\n");
	fprintf(pFile, "color_depth_filter = %d Bit\n", iColorDepthFilter);
    fprintf(pFile, "# Window seize:\n");
	fprintf(pFile, "window_width = %d\n", iWindowWidth);
	fprintf(pFile, "window_height = %d\n", iWindowHeight);
    fprintf(pFile, "\n# The key specification file:\n");
	fprintf(pFile, "key_file = %s\n", byKeyFile);
	fclose(pFile);
	sprintf(byASTemp, "%s\\%s", byASProgramPath, byKeyFile);
	SaveKeySpecification(byASTemp);
	return AS_ERROR_NONE;
} // end CONFIG::Save()
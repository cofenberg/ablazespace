/*
	Font.cpp

    Last change:
    	24.6.2000

    Description:
		Bitmap font functions.
*/

#include "AS_ENGINE.h"


// Functions: *****************************************************************
void InitFonts(void);
void DestroyFonts(void);
HRESULT LoadFontTextures(void);
void BuildBFont(void);
void KillBFont(void);
void FontBPrint(int, float, float, float, const char *, ...);
void FontBPrintCentered(int, float, float, const char *, ...);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
GLuint FontBBase;				// Base Display List For The Font Set
GLuint FontTexture[2];			// Storage For Our Font Texture
///////////////////////////////////////////////////////////////////////////////


void InitFonts(void)
{ // begin InitFonts()
	LoadFontTextures();
	BuildBFont();
} // end InitFonts()

void DestroyFonts(void)
{ // begin DestroyFonts()
	KillBFont();
	glDeleteTextures(1, &FontTexture[0]);
} // end DestroyFonts()


HRESULT LoadFontTextures(void)                                    // Load Bitmaps And Convert To Textures
{ // begin LoadFontTextures()
	byte Texture[] = {IDB_FONT};
    int i;
	HBITMAP hBMP;
	BITMAP	BMP;
	
	glDeleteTextures(1, &FontTexture[0]);
	glGenTextures(1, &FontTexture[0]);
	for(i = 0; i < 1; i++)
	{
		hBMP = (HBITMAP) LoadImage(GetModuleHandle(NULL), MAKEINTRESOURCE(Texture[i]), IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION);
		if(hBMP)
        {
			GetObject(hBMP, sizeof(BMP), &BMP);
			glPixelStorei(GL_UNPACK_ALIGNMENT,4);
			glBindTexture(GL_TEXTURE_2D, FontTexture[i]);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_NEAREST);
				gluBuild2DMipmaps(GL_TEXTURE_2D, 3, BMP.bmWidth, BMP.bmHeight, GL_BGR_EXT, GL_UNSIGNED_BYTE, BMP.bmBits);
        }
	}
	return AS_ERROR_NONE;
} // end LoadFontTextures()

void BuildBFont(void)								// Build Our Font Display List
{ // begin BuildBFont()
	float	cx;											// Holds Our X Character Coord
	float	cy;											// Holds Our Y Character Coord
	int loop = 0;

	FontBBase = glGenLists(256);								// Creating 256 Display Lists
	iASLists += 256;
	glBindTexture(GL_TEXTURE_2D,  FontTexture[0]);			// Select Our Font Texture
	glColor4f(1.0f, 1.0f, 1.0f, 1.0);					// Full Brightness.  50% Alpha
	glColor3f(1.0f, 1.0f, 1.0f);
	for (loop=0; loop<256; loop++)						// Loop Through All 256 Lists
	{
		cx=float(loop%16)/16.0f;						// X Position Of Current Character
		cy=float(loop/16)/16.0f;						// Y Position Of Current Character

		glNewList(FontBBase+loop,GL_COMPILE);			// Start Building A List
			glBegin(GL_QUADS);							// Use A Quad For Each Character
				glTexCoord2f(cx,1-cy-0.0625f);			// Texture Coord (Bottom Left)
				glVertex2f(0.0f,0.0f);					// Vertex Coord (Bottom Left)
				glTexCoord2f(cx+0.0625f,1-cy-0.0625f);	// Texture Coord (Bottom Right)
				glVertex2f(1.0f,0.0f);					// Vertex Coord (Bottom Right)
				glTexCoord2f(cx+0.0625f,1-cy);			// Texture Coord (Top Right)
				glVertex2f(1.0f,1.0f);					// Vertex Coord (Top Right)
				glTexCoord2f(cx,1-cy);					// Texture Coord (Top Left)
				glVertex2f(0.0f,1.0f);					// Vertex Coord (Top Left)
			glEnd();									// Done Building Our Quad (Character)
			glTranslatef(0.6f,0.0f,0.0f);				// Move To The Right Of The Character
		glEndList();									// Done Building The Display List
	}													// Loop Until All 256 Are Built
} // end BuildBFont()

void KillBFont(void)									// Delete The Font From Memory
{ // begin KillBFont()
	glDeleteLists(FontBBase, 256);						// Delete All 256 Display Lists
} // end KillBFont()

void FontBPrint(int set, float z, float x, float y, const char *string, ...)
{ // begin FontBPrint()
	char	text[256];
	va_list	ap;

	if (set>1)
		set=1;
	if (string==NULL)
		return;
	va_start(ap, string);
		vsprintf(text, string, ap);
	va_end(ap);
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	glEnable(GL_TEXTURE_2D);
	glListBase(FontBBase-32+(128*set));
	glBindTexture(GL_TEXTURE_2D,  FontTexture[0]);
	glTranslated(x, y, z);
	glCallLists(strlen(text), GL_UNSIGNED_BYTE, text);
} // end FontBPrint()

void FontBPrintCentered(int set, float z, float y, const char *string, ...)
{ // begin FontBPrintCentered()
	char	text[256];
	va_list	ap;
	GLfloat x = 0;

	if(set>1)
		set=1;
	if(string==NULL)
		return;
	va_start(ap, string);
		vsprintf(text, string, ap);
	va_end(ap);
	x = (GLfloat)-(strlen(text) * 0.6 / 2.0f);
	FontBPrint(set, z, x, y, text);
} // end FontBPrintCentered()
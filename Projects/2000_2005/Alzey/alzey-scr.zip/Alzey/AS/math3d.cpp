/*
	Math3D.cpp

    Last change:
    	24.6.2000

    Description:
		Math stuff.
*/

#include "AS_ENGINE.h"


// Functions: *****************************************************************
void ASMathRotateArbitrary(float *, float *, float *,
						   float, float, float, float);
void ASNormalizePlane(AS_VERTEX *, AS_VERTEX, AS_VERTEX, AS_VERTEX);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
///////////////////////////////////////////////////////////////////////////////


void ASMathRotateArbitrary(float *fX, float *fY, float *fZ,
						   float fA, float fB, float fC, float fRadians)
{ // begin ASMathRotateArbitrary()
	MATRIX4x4 m;
	float x2,y2,z2;
	float fSinus = (float)sin(fRadians);
	float fCosinus = (float)cos(fRadians);
	float fV = 1-fCosinus;

	m[0][0] = fA*fA + (1-fA*fA)*fCosinus;
	m[0][1] = fA*fB*fV + fC*fSinus;
	m[0][2] = fC*fA*fV - fB*fSinus;

	m[1][0] = fA*fB*fV - fC*fSinus;
	m[1][1] = fB*fB*fV + (1-fB*fB)*fCosinus;
	m[1][2] = fB*fC*fV + fA*fSinus;

	m[2][0] = fC*fA*fV + fB*fSinus;
	m[2][1] = fB*fC*fV - fA*fSinus;
	m[2][2] = fC*fC + (1-fC*fC)*fCosinus;

	x2 = (*fX) * m[0][0] + (*fY) * m[1][0] + (*fZ) * m[2][0];
	y2 = (*fX) * m[0][1] + (*fY) * m[1][1] + (*fZ) * m[2][1];
	z2 = (*fX) * m[0][2] + (*fY) * m[1][2] + (*fZ) * m[2][2];

	*fX = x2; *fY = y2; *fZ = z2;
} // end ASMathRotateArbitrary()

void ASNormalizePlane(AS_VERTEX *ResultV, AS_VERTEX V1, AS_VERTEX V2, AS_VERTEX V3)
{ // begin ASNormalizePlane()
	AS_VERTEX V1_V2, V1_V3;

	SubtVer(V1_V2, V1, V2);
	SubtVer(V1_V3, V1, V3);
	CrossProductVer(*ResultV, V1_V2, V1_V3);
} // end ASNormalizePlane()
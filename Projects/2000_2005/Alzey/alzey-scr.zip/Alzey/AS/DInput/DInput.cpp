/*
	DInput.cpp

    Last change:
    	24.6.2000

    Description:
		DInput main functions.
*/

#include "..\AS_ENGINE.h"


// Definitions: ***************************************************************
#define BUFFERSIZE 16
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
HRESULT ASInitDInput(void);
void ASDestroyDInput(void);
LPDIRECTINPUTDEVICE2 ASDInputCreateDevice2(LPDIRECTINPUT, GUID *);
HRESULT ASDInputInitDevice(GUID *, LPDIRECTINPUT, LPDIRECTINPUTDEVICE2 *);
void ASDInputSetAcquireState(BOOL);
void ASEnumerateDInputKeys(void);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
LPDIRECTINPUT        lpdiKeyboard;
LPDIRECTINPUTDEVICE2 lpdiKeyboard2;
LPDIRECTINPUT        lpdiMouse;
LPDIRECTINPUTDEVICE2 lpdiMouse2;
enum DeviceKind { KEYBOARD, MOUSE, JOYSTICK } CurrentDevice;
///////////////////////////////////////////////////////////////////////////////

HRESULT ASInitDInput(void)
{ // begin ASInitDInput()
    iASResult = DirectInputCreate(hInstance, DIRECTINPUT_VERSION, &lpdiKeyboard, NULL);
    if(FAILED(iASResult))
    {
        MessageBox(NULL, "Failed to initialize DirectInput.", "Error", 
                    MB_ICONERROR | MB_OK );
        return FALSE;
    }
    iASResult = DirectInputCreate(hInstance, DIRECTINPUT_VERSION, &lpdiMouse, NULL);
    if(FAILED(iASResult))
    {
        MessageBox(NULL, "Failed to initialize DirectInput.", "Error", 
                    MB_ICONERROR | MB_OK );
        return FALSE;
    }
    return AS_ERROR_NONE;    
}  // end ASInitDInput()

void ASDestroyDInput(void)
{ // begin ASDestroyDInput()
    ASDInputSetAcquireState(FALSE);
    if(lpdiKeyboard2 != NULL) 
    {
        lpdiKeyboard2->Release();
        lpdiKeyboard2 = NULL;
    }
    if(lpdiKeyboard != NULL)
    { 
        lpdiKeyboard->Release();
        lpdiKeyboard = NULL;
    }
    if(lpdiMouse2 != NULL) 
    {
        lpdiMouse2->Release();
        lpdiMouse2 = NULL;
    }
    if(lpdiMouse != NULL)
    { 
        lpdiMouse->Release();
        lpdiMouse = NULL;
    }
} // end ASDestroyDInput()

LPDIRECTINPUTDEVICE2 ASDInputCreateDevice2(LPDIRECTINPUT lpdi, GUID *pGuid)
{ // begin ASDInputCreateDevice2()
    LPDIRECTINPUTDEVICE  lpdid1;
    LPDIRECTINPUTDEVICE2 lpdid2;

    iASResult = lpdi->CreateDevice(*pGuid, &lpdid1, NULL);
    if(SUCCEEDED(iASResult))
    { 
        iASResult = lpdid1->QueryInterface(IID_IDirectInputDevice2,
                                          (void **) &lpdid2);
        lpdid1->Release();
		if(FAILED(iASResult))
		{
			#ifdef _DEBUG
				OutputDebugString("IDirectInputDevice2-Schnittstelle fehlt!" );
			#endif // _DEBUG
			return NULL;
		} 
    } 
    else
    {
		#ifdef _DEBUG
	        OutputDebugString("Fehler beim Anlegen des Ger�tes" );
		#endif // _DEBUG
        return NULL;
    } 
    return lpdid2;
}  // end ASDInputCreateDevice2();

HRESULT ASDInputInitDevice(GUID *pGuid, LPDIRECTINPUT lpdi, LPDIRECTINPUTDEVICE2 *lpdid2) 
{ // begin ASDInputInitDevice()
    DIDEVICEINSTANCE diDeviceInstance;
    DWORD dwCL, dwCL1;

    if(*lpdid2) 
    {
        ASDInputSetAcquireState(FALSE);
        (*lpdid2)->Release();
    }
    *lpdid2 = ASDInputCreateDevice2(lpdi, pGuid);
    if(!*lpdid2) return FALSE;
    diDeviceInstance.dwSize = sizeof(DIDEVICEINSTANCE);
    (*lpdid2)->GetDeviceInfo(&diDeviceInstance);
	switch(GET_DIDEVICE_TYPE(diDeviceInstance.dwDevType))
    {
        case DIDEVTYPE_KEYBOARD:
            iASResult = (*lpdid2)->SetDataFormat(&c_dfDIKeyboard);
            CurrentDevice = KEYBOARD;
        break;

        case DIDEVTYPE_MOUSE:
            iASResult = (*lpdid2)->SetDataFormat(&c_dfDIMouse);
            CurrentDevice = MOUSE;
        break;

        case DIDEVTYPE_JOYSTICK:
            iASResult = (*lpdid2)->SetDataFormat(&c_dfDIJoystick);
            CurrentDevice = JOYSTICK;
        break;
        
		default: return FALSE;
    }
    if(FAILED(iASResult)) return FALSE;
    if(CurrentDevice == KEYBOARD) 
    	dwCL = DISCL_NONEXCLUSIVE;
    else 
		dwCL = DISCL_EXCLUSIVE;
    dwCL1 = DISCL_BACKGROUND;
    if(CurrentDevice == MOUSE) dwCL = DISCL_NONEXCLUSIVE;
    if(FAILED((*lpdid2)->SetCooperativeLevel(hWndMain,
											 dwCL | dwCL1)))
    {
		#ifdef _DEBUG
	        OutputDebugString( "Failed to set game device cooperative level.\n" );
		#endif // _DEBUG
        *lpdid2 = NULL;
        return DIENUM_STOP;
    }
    DIPROPDWORD dipdw =
    {
        {
            sizeof(DIPROPDWORD),
            sizeof(DIPROPHEADER),
            0,
            DIPH_DEVICE,
        },
        BUFFERSIZE,
    };
    (*lpdid2)->SetProperty(DIPROP_BUFFERSIZE, &dipdw.diph);
    return AS_ERROR_NONE;
} // end ASDInputInitDevice()

void ASDInputSetAcquireState(BOOL bState)
{ // begin ASDInputSetAcquireState()
    if(!bState) // Unacquire.
    {
        if(lpdiKeyboard2)
			lpdiKeyboard2->Unacquire();
        if(lpdiMouse2)
			lpdiMouse2->Unacquire();
    }
    else // Acquire.
    {
        if(lpdiKeyboard2)
	        lpdiKeyboard2->Acquire();
        if(lpdiMouse2)
	        lpdiMouse2->Acquire();
    }
} // end ASDInputSetAcquireState()

void ASEnumerateDInputKeys(void)
{ // begin ASenumerateInputKeys
    DIDEVICEOBJECTINSTANCE didoi;
	DWORD  dwOfs;
	int i, i2;

    didoi.dwSize = sizeof( didoi );
    // Insert keyboard Buttons:
	if(lpdiKeyboard2)
		for(i = 0, i2 = 0; i < AS_MAX_KEYBOARD_BUTTONS; i++ )
		{
			if(SUCCEEDED(lpdiKeyboard2->GetObjectInfo(&didoi, 
												 i, 
												 DIPH_BYOFFSET)))
			{
				strcpy(InputKeys[i2].byName, didoi.tszName);
				InputKeys[i2].iCode = i;
				InputKeys[i2].byDevice = AS_KEYBOARD;
				i2++;
			}
		}
	for(; i2 < AS_MAX_KEYBOARD_BUTTONS; i2++)
		InputKeys[i2].iCode = -1;
    if(lpdiMouse2)
		// Insert mouse Buttons:
		for(i = 0, i2 = 0; i < AS_MAX_MOUSE_BUTTONS; i++ )
		{
			dwOfs =  (FIELD_OFFSET(DIMOUSESTATE, rgbButtons)+i);
			if(SUCCEEDED(lpdiMouse2->GetObjectInfo(&didoi, 
												 dwOfs, 
												 DIPH_BYOFFSET)))
			{
				sprintf(InputKeys[i2+AS_MAX_KEYBOARD_BUTTONS].byName, "Mouse %s", didoi.tszName);
				InputKeys[i2+AS_MAX_KEYBOARD_BUTTONS].iCode = dwOfs;
				InputKeys[i2+AS_MAX_KEYBOARD_BUTTONS].byDevice = AS_MOUSE;
				i2++;
			}
		}
	for(;i2 < AS_MAX_MOUSE_BUTTONS; i2++)
		InputKeys[i2+AS_MAX_KEYBOARD_BUTTONS].iCode = -1;
} // end ASenumerateInputKeys()
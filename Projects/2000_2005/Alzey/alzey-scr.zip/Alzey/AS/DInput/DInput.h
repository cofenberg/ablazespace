/*
	DInput.h

    Last change:
    	24.6.2000

    Description:
		DInput main functions.
*/

#ifndef __AS_DINPUT_H__
#define __AS_DINPUT_H__


// Functions: *****************************************************************
extern HRESULT ASInitDInput(void);
extern void ASDestroyDInput(void);
extern LPDIRECTINPUTDEVICE2 ASDInputCreateDevice2(LPDIRECTINPUT, GUID *);
extern HRESULT ASDInputInitDevice(GUID *, LPDIRECTINPUT, LPDIRECTINPUTDEVICE2 *);
extern void ASDInputSetAcquireState(BOOL);
extern void ASEnumerateDInputKeys(void);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern LPDIRECTINPUT        lpdiKeyboard;
extern LPDIRECTINPUTDEVICE2 lpdiKeyboard2;
extern LPDIRECTINPUT        lpdiMouse;
extern LPDIRECTINPUTDEVICE2 lpdiMouse2;
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_DINPUT_H__




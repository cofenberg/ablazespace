/*
	Wrl.h

    Last change:
    	24.6.2000

    Description:
		Stuff for loading crude VRML scripts.
*/

#ifndef __AS_WRL_H__
#define __AS_WRL_H__


// Functions: *****************************************************************
extern HRESULT ASLoadWrl(FILE *, AS_OBJECT *);
extern HRESULT ASWrlParseStatement(FILE *);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern float fTBoundMin[3], fTBoundMax[3];
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_WRL_H__


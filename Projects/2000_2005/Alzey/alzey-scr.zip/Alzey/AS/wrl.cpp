/*
	Wrl.cpp

    Last change:
    	24.6.2000

    Description:
		This file crudely loads a crude VRML script.
*/

#include "AS_ENGINE.h"


// Functions: *****************************************************************
HRESULT ASLoadWrl(FILE *, AS_OBJECT *);
HRESULT ASWrlParseStatement(FILE *);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
AS_OBJECT *CurrentObj;
AS_OBJECT *FirstObj;
BOOL bExpectingNumbers = FALSE; // Are we expecting a number list?
BOOL MainObj;
int iNestLevel; // The current nesting level
// What kind of number list are we expecting?
enum { NONE, WORLD_COORDS, INDICES } ExpectedNumbers = NONE;
float fTBoundMin[3], fTBoundMax[3];
///////////////////////////////////////////////////////////////////////////////


HRESULT ASLoadWrl(FILE *pFile, AS_OBJECT *pObj)
{ // begin ASLoadWrl()
	char *pstr = NULL;
	int i;

	CurrentObj = pObj;
	FirstObj = pObj;
	MainObj = TRUE;
	iNestLevel = 0;
	for(i = 0; i < 3; i++)
	{
		fTBoundMin[i] = 0.0f;
		fTBoundMax[i] = 0.0f;
	}
	for(;;)
	{
		i = ASWrlParseStatement(pFile);
		if(i)
			break;
	}
	for(i = 0; i < 3; i++)
	{
		pObj->fBoundMin[i] = fTBoundMin[i];
		pObj->fBoundMax[i] = fTBoundMax[i];
	}
	return 0;
} // end ASLoadWrl()

HRESULT ASWrlParseStatement(FILE *fp)
{ // begin ASWrlParseStatement()
	fpos_t tempFilePos;
	char byTemp[256];	
	char str[256];	
	char *pstr, *pstr2;
	int i, i2;

	if(fscanf(fp, "%s", str) == EOF)
		return 1;
	strupr(str);
	if (str[0] == '#') 
		return 0;
	if(bExpectingNumbers) 
	{
		if(str[0] == ']') 
		{
			bExpectingNumbers = FALSE;
			ExpectedNumbers = NONE;
			return 0;
		}
		// Adds actual coordinates
		if(ExpectedNumbers == WORLD_COORDS) 
		{
			AS_VERTEX *v = &CurrentObj->coord[CurrentObj->nVertices];

			pstr = strtok(str, AS_FORMAT_TOKENS);
			v->ox = (float) atof(str);
			fscanf(fp, "%s", str);
			pstr = strtok(str, AS_FORMAT_TOKENS);
			v->oy = (float) atof(str);
			fscanf(fp, "%s", str);
			pstr = strtok(str, AS_FORMAT_TOKENS);
			
			if((pstr2=strchr(pstr, ']'))) 
			{
				bExpectingNumbers = FALSE;
				ExpectedNumbers = NONE;
				*pstr2 = ' ';
			}
			v->oz = (float) atof(pstr);
			CurrentObj->RotateTranslate(v);
			if(fabs(v->ox) > CurrentObj->min_comp) CurrentObj->min_comp = fabs(v->ox);
			if(fabs(v->oy) > CurrentObj->min_comp) CurrentObj->min_comp = fabs(v->oy);
			if(fabs(v->oz) > CurrentObj->min_comp) CurrentObj->min_comp = fabs(v->oz);
			// For the Object group:
			if(fabs(v->ox) > dObjMinComp) dObjMinComp = fabs(v->ox);
			if(fabs(v->oy) > dObjMinComp) dObjMinComp = fabs(v->oy);
			if(fabs(v->oz) > dObjMinComp) dObjMinComp = fabs(v->oz);
			// Get Bounding:
			if(v->ox < CurrentObj->fBoundMin[X]) CurrentObj->fBoundMin[X] = v->ox;
			if(v->oy < CurrentObj->fBoundMin[Y]) CurrentObj->fBoundMin[Y] = v->oy;
			if(v->oz < CurrentObj->fBoundMin[Z]) CurrentObj->fBoundMin[Z] = v->oz;

			if(v->ox > CurrentObj->fBoundMax[X]) CurrentObj->fBoundMax[X] = v->ox;
			if(v->oy > CurrentObj->fBoundMax[Y]) CurrentObj->fBoundMax[Y] = v->oy;
			if(v->oz > CurrentObj->fBoundMax[Z]) CurrentObj->fBoundMax[Z] = v->oz;
			CurrentObj->nVertices++;
		}
		else if(ExpectedNumbers == INDICES) {
			if((pstr2=strchr(str, ']'))) 
			{
				bExpectingNumbers = FALSE;
				ExpectedNumbers = NONE;
				*pstr2 = ' ';
			}
			CurrentObj->indexlist[CurrentObj->nIndices] = atoi(str);
			CurrentObj->nIndices++;
		}
	}
	if(!strcmp(str, "DEF")) 
	{
		// Get the name		
		fscanf(fp, "%s", byTemp);
		// Is this an new Object?
		fscanf(fp, "%s", str);
		if(!strcmp(str, "Transform")) 
		{	// YES!:
			if(!MainObj)
			{				
				AS_OBJECT *pTempObj = (AS_OBJECT *) calloc(1, sizeof(AS_OBJECT));

				CurrentObj->iChilds++;
				CurrentObj->pChild = (AS_OBJECT **) realloc(CurrentObj->pChild, 
														   sizeof(AS_OBJECT)*CurrentObj->iChilds);
				CurrentObj->pChild[CurrentObj->iChilds-1] = pTempObj;
				pTempObj->pParent = CurrentObj;
				pTempObj->iNestLevel = CurrentObj->iNestLevel+1;
				CurrentObj = pTempObj;
				CurrentObj->pAddress = pTempObj;
				CurrentObj->iDefinedNestLevel = iNestLevel+1;
				// Reads the '{':
				fscanf(fp, "%s", str);
			}	
			CurrentObj->pbyName = (char *) malloc(strlen(byTemp)+1);
			strcpy(CurrentObj->pbyName, byTemp);
			// Set defaults
			CurrentObj->fScale[X] = CurrentObj->fScale[Y] = CurrentObj->fScale[Z] = 1.0f;
			MainObj = FALSE;
			return 0;
		}
		else
		if(!strcmp(str, "ParticleHolder")) 
		{ // It is a particle holder on the main Object:
			if(FirstObj->pParticleHolder)
				free(FirstObj->pParticleHolder);
			FirstObj->pParticleHolder = (AS_PARTICLE_HOLDER *) calloc(1, sizeof(AS_PARTICLE_HOLDER));
		
			int iParticles = AS_S_PARTICLES;
			do
			{
				if(!feof(fp)) fscanf(fp,"%s",byASTemp); else break;
				if(feof(fp)) break;
				
				if((strlen(byASTemp)>=2) && (byASTemp[0]=='/') && (byASTemp[1]=='/'))
					ASSetAfterNextToken(fp, '\n'); 
				else		
				if(!strcmp(byASTemp, "translation"))
				{ // Set the position:
					fscanf(fp, "%s", str);
					pstr = strtok(str, AS_FORMAT_TOKENS);
					FirstObj->pParticleHolder->fPos[X] = (float) atof(pstr);
					fscanf(fp, "%s", str);
					pstr = strtok(str, AS_FORMAT_TOKENS);
					FirstObj->pParticleHolder->fPos[Y] = (float) atof(pstr);
					fscanf(fp, "%s", str);
					pstr = strtok(str, AS_FORMAT_TOKENS);
					FirstObj->pParticleHolder->fPos[Z] = (float) atof(pstr);
				}
				else
				if(!strcmp(byASTemp, "speed")) 
				{ // Set the position:
					fscanf(fp, "%s", str);
					pstr = strtok(str, AS_FORMAT_TOKENS);
					FirstObj->pParticleHolder->fSpeed[X] = (float) atof(pstr);
					fscanf(fp, "%s", str);
					pstr = strtok(str, AS_FORMAT_TOKENS);
					FirstObj->pParticleHolder->fSpeed[Y] = (float) atof(pstr);
					fscanf(fp, "%s", str);
					pstr = strtok(str, AS_FORMAT_TOKENS);
					FirstObj->pParticleHolder->fSpeed[Z] = (float) atof(pstr);
				}
				else
				if(!strcmp(byASTemp, "speed_increase")) 
				{ // Set the position:
					fscanf(fp, "%s", str);
					pstr = strtok(str, AS_FORMAT_TOKENS);
					FirstObj->pParticleHolder->fSpeedIncrease[X] = (float) atof(pstr);
					fscanf(fp, "%s", str);
					pstr = strtok(str, AS_FORMAT_TOKENS);
					FirstObj->pParticleHolder->fSpeedIncrease[Y] = (float) atof(pstr);
					fscanf(fp, "%s", str);
					pstr = strtok(str, AS_FORMAT_TOKENS);
					FirstObj->pParticleHolder->fSpeedIncrease[Z] = (float) atof(pstr);
				}
				else
				if(!strcmp(byASTemp, "particles")) 
				{
					fscanf(fp, "%s", str);
					pstr = strtok(str, AS_FORMAT_TOKENS);
					iParticles = atoi(pstr);
				}
				else
				if(!strcmp(byASTemp, "slowdown")) 
				{
					fscanf(fp, "%s", str);
					pstr = strtok(str, AS_FORMAT_TOKENS);
					FirstObj->pParticleHolder->fSlowdown = (float) atof(pstr);
				}
				else
				if(!strcmp(byASTemp, "-fade_random")) 
					FirstObj->pParticleHolder->fFade = -1.0f;
				else
				if(!strcmp(byASTemp, "min_fade")) 
				{
					fscanf(fp, "%s", str);
					pstr = strtok(str, AS_FORMAT_TOKENS);
					FirstObj->pParticleHolder->fRFadeMin = (float) atof(pstr);
				}
				else
				if(!strcmp(byASTemp, "max_fade")) 
				{
					fscanf(fp, "%s", str);
					pstr = strtok(str, AS_FORMAT_TOKENS);
					FirstObj->pParticleHolder->fRFadeMax = (float) atof(pstr);
				}
				else
				if(!strcmp(byASTemp, "distribution")) 
				{
					fscanf(fp, "%s", str);
					pstr = strtok(str, AS_FORMAT_TOKENS);
					FirstObj->pParticleHolder->fDistribution = (float) atof(pstr);
				}
				else
				if(!strcmp(byASTemp, "init")) 
				{
					FirstObj->pParticleHolder->iParticleType = 0;
					FirstObj->pParticleHolder->fRedColor = -1.0f;
					FirstObj->pParticleHolder->fGreenColor = -1.0f;
					FirstObj->pParticleHolder->fBlueColor = -1.0f;
					FirstObj->pParticleHolder->fRSpeed[X] = 0.005f;
					FirstObj->pParticleHolder->fRSpeed[Y] = 0.001f;
					FirstObj->pParticleHolder->fRSpeed[Z] = 0.01f;
					FirstObj->pParticleHolder->Init(iParticles);
					break;
				}
			} while(!feof(fp));
		}
	}
	else if(!strcmp(str, "SCALE")) {
		fscanf(fp, "%s", str);
		pstr = strtok(str, AS_FORMAT_TOKENS); CurrentObj->fScale[X] = (float)atof(pstr);
		fscanf(fp, "%s", str);
		pstr = strtok(str, AS_FORMAT_TOKENS); CurrentObj->fScale[Y] = (float)atof(pstr);
		fscanf(fp, "%s", str);
		pstr = strtok(str, AS_FORMAT_TOKENS); CurrentObj->fScale[Z] = (float)atof(pstr);
	}
	else if(!strcmp(str, "TRANSLATION")) {
		fscanf(fp, "%s", str);
		pstr = strtok(str, AS_FORMAT_TOKENS); CurrentObj->fPos[X] = (float)atof(pstr);
		fscanf(fp, "%s", str);
		pstr = strtok(str, AS_FORMAT_TOKENS); CurrentObj->fPos[Y] = (float)atof(pstr);
		fscanf(fp, "%s", str);
		pstr = strtok(str, AS_FORMAT_TOKENS); CurrentObj->fPos[Z] = (float)atof(pstr);
	}
	else if(!strcmp(str, "ROTATION")) {
		fscanf(fp, "%s", str);
		pstr = strtok(str, AS_FORMAT_TOKENS); CurrentObj->fRot[X] = (float)atof(pstr);
		fscanf(fp, "%s", str);
		pstr = strtok(str, AS_FORMAT_TOKENS); CurrentObj->fRot[Y] = (float)atof(pstr);
		fscanf(fp, "%s", str);
		pstr = strtok(str, AS_FORMAT_TOKENS); CurrentObj->fRot[Z] = (float)atof(pstr);
		fscanf(fp, "%s", str);
		pstr = strtok(str, AS_FORMAT_TOKENS); CurrentObj->fRadians = (float)atof(pstr);
	}
	else if(!strcmp(str, "DIFFUSECOLOR")) {
		fscanf(fp, "%s", str);
		pstr = strtok(str, AS_FORMAT_TOKENS); CurrentObj->fRed = (float)atof(pstr);
		fscanf(fp, "%s", str);
		pstr = strtok(str, AS_FORMAT_TOKENS); CurrentObj->fGreen = (float)atof(pstr);
		fscanf(fp, "%s", str);
		pstr = strtok(str, AS_FORMAT_TOKENS); CurrentObj->fBlue = (float)atof(pstr);
	}
	else if(!strcmp(str, "COORD")) {
		ExpectedNumbers = WORLD_COORDS;
	}
	else if(!strcmp(str, "COORDINDEX")) {
		ExpectedNumbers = INDICES;
	}
	else if(str[0] == '[') {
		if(ExpectedNumbers != NONE) 
		{
			bExpectingNumbers = TRUE;
			if(ExpectedNumbers == WORLD_COORDS)
			{
				fgetpos(fp, &tempFilePos);
				for(i = 0;; i++)
				{
					fscanf(fp, "%s", str);
					fscanf(fp, "%s", str);
					fscanf(fp, "%s", str);
					pstr = strtok(str, AS_FORMAT_TOKENS);					
					if((pstr2=strchr(pstr, ']'))) 
						break;
				}
				fsetpos(fp, &tempFilePos);
				CurrentObj->coord = (AS_VERTEX *) malloc(sizeof(AS_VERTEX)*(i+1));
			}
			else
			{
				fgetpos(fp, &tempFilePos);
				for(i = 0;; i++)
				{
					fscanf(fp, "%s", str);
					pstr = strtok(str, AS_FORMAT_TOKENS);					
					if((pstr2=strchr(pstr, ']'))) 
						break;
				}
				fsetpos(fp, &tempFilePos);
				CurrentObj->indexlist = (int *) malloc(sizeof(int)*(i+1));
			}
		}
	}
	else 
	if(str[0] == '{')
		iNestLevel++;
	else if(str[0] == '}') {		
		if(iNestLevel == CurrentObj->iDefinedNestLevel)
		{ // The current Object is now complete loaded. Go back to the last (parent):
			for(i = 0; i < 3; i++)
			{
				if(fTBoundMin[i] > CurrentObj->fBoundMin[i]) 
					fTBoundMin[i] = CurrentObj->fBoundMin[i];
				if(fTBoundMax[i] < CurrentObj->fBoundMax[i]) 
					fTBoundMax[i] = CurrentObj->fBoundMax[i];
			}
			// Calculate plane constants:
			CurrentObj->Normal = (AS_VERTEX *) calloc(1, sizeof(AS_VERTEX)*(CurrentObj->nIndices/4));
			for(i = 0, i2 = 0; i < (CurrentObj->nIndices-4); i += 4, i2++)
				ASNormalizePlane(&CurrentObj->Normal[i2], CurrentObj->coord[CurrentObj->indexlist[i]], 
								 CurrentObj->coord[CurrentObj->indexlist[i+1]], 
								 CurrentObj->coord[CurrentObj->indexlist[i+2]]);
			if(!CurrentObj->pParent)
				return 0; 
			CurrentObj = CurrentObj->pParent;
		}
		iNestLevel--;
	}		
	return 0;
} // end ASWrlParseStatement()
/*
	Game.h

    Last change:
    	24.6.2000

    Description:
		OpenGL main functions.
*/

#ifndef __OPENGL_MAIN_H__
#define __OPENGL_MAIN_H__


// Functions: *****************************************************************
extern HRESULT InitGL(HWND *, char *, char *);
void CreateAllLists(void);
extern HRESULT DestroyGL(char *, HWND *);
extern HRESULT ReSizeGL(void);
extern HRESULT GLSwitchDisplayMode(void);
///////////////////////////////////////////////////////////////////////////////


#endif // __OPENGL_MAIN_H__
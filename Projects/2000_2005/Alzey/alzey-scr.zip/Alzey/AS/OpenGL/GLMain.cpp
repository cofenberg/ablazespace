/*
	GLMain.cpp

    Last change:
    	24.6.2000

    Description:
		OpenGL main functions.
*/

#include "..\AS_ENGINE.h"


// Functions: *****************************************************************
HRESULT InitGL(HWND *, char *, char *);
void CreateAllLists(void);
HRESULT DestroyGL(char *, HWND *);
HRESULT ReSizeGL(void);
HRESULT GLSwitchDisplayMode(void);
///////////////////////////////////////////////////////////////////////////////


HRESULT InitGL(HWND *hWnd, char *pbyTitle, char *pbyName)
{ // begin InitGL()
	GLuint PixelFormat;

	ASDestroyDisplayModeInfo(); // Destroy the old mode infos
	ASEnumerateDisplayModeInfos(); // Enumerate and store the available display modes
	if(Config.bFullScreen)
	{
		*hWnd = ASCreateWindow(hInstance, WindowProc, pbyTitle, pbyName, 
							   Config.DevMode.dmPelsWidth, Config.DevMode.dmPelsHeight, NULL, TRUE);
		if(ChangeDisplaySettings(&Config.DevMode, CDS_FULLSCREEN) != DISP_CHANGE_SUCCESSFUL)
		{
			int i;
			i = 0;
			return AS_ERROR_NONE;
		}
		ShowCursor(FALSE);
	}
	else
	{
		*hWnd = ASCreateWindow(hInstance, WindowProc, pbyTitle, pbyName, Config.iWindowWidth, 
							   Config.iWindowHeight, LoadMenu(hInstance, pMainMenu), FALSE);
		ShowCursor(TRUE);
	}
	if(iASActiveModule == EDITOR)
	{
		sprintf(byASTemp, GAME_NAME" - Editor");
		SetWindowText(*hWnd, byASTemp);
	}
	static PIXELFORMATDESCRIPTOR pfd =				// pfd Tells Windows How We Want Things To Be
	{
		sizeof(PIXELFORMATDESCRIPTOR),				// Size Of This Pixel Format Descriptor
		1,											// Version Number
		PFD_DRAW_TO_WINDOW |						// Format Must Support Window
		PFD_SUPPORT_OPENGL |						// Format Must Support OpenGL
		PFD_DOUBLEBUFFER,							// Must Support Double Buffering
		PFD_TYPE_RGBA,								// Request An RGBA Format
		(char) Config.DevMode.dmBitsPerPel,              // Select Our Color Depth
		0, 0, 0, 0, 0, 0,							// Color Bits Ignored
		0,											// No Alpha Buffer
		0,											// Shift Bit Ignored
		0,											// No Accumulation Buffer
		0, 0, 0, 0,									// Accumulation Bits Ignored
		16,											// 16Bit Z-Buffer (Depth Buffer)  
		0,											// No Stencil Buffer
		0,											// No Auxiliary Buffer
		PFD_MAIN_PLANE,								// Main Drawing Layer
		0,											// Reserved
		0, 0, 0										// Layer Masks Ignored
	};
	if(!(hDC = GetDC(*hWnd)))							// Did We Get A Device Context?
	{
		DestroyGL(pbyName, hWnd);
		MessageBox(NULL,"Can't Create A GL Device Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}
	if(!(PixelFormat = ChoosePixelFormat(hDC, &pfd)))	// Did Windows Find A Matching Pixel Format?
	{
		DestroyGL(pbyName, hWnd);
		MessageBox(NULL,"Can't Find A Suitable PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}
	if(!SetPixelFormat(hDC, PixelFormat, &pfd))		// Are We Able To Set The Pixel Format?
	{
		DestroyGL(pbyName, hWnd);
		MessageBox(NULL,"Can't Set The PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}
	if(!(hRC=wglCreateContext(hDC)))				// Are We Able To Get A Rendering Context?
	{
		DestroyGL(pbyName, hWnd);
		MessageBox(NULL,"Can't Create A GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}
	if(!wglMakeCurrent(hDC, hRC))					// Try To Activate The Rendering Context
	{
		DestroyGL(pbyName, hWnd);
		MessageBox(NULL,"Can't Activate The GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}
	ShowWindow(*hWnd, SW_SHOW);						// Show The Window
	SetForegroundWindow(*hWnd);						// Slightly Higher Priority
	SetFocus(*hWnd);									// Sets Keyboard Focus To The Window	
	ReSizeGL();
	CreateAllLists();
	if(iASSetActiveModule == GAME)
		GameLevel();
	else
	if(iASSetActiveModule == EDITOR)
		EditorLevel();
	return TRUE;
} // end InitGL()

void CreateAllLists(void)
{ // begin CreateAllLists()
	iASLists = 0;
	InitFonts();
	InitParticleSystem();
	LoadGameTextures();
	CreateGameLists();
	if(Level && Level->Exist)	
		CreatLevelWallLists();
	CreateActorLookListes();
	if(EditorCursorObj)
		EditorCursorObj->CreateList();
} // begin CreateAllLists()

HRESULT DestroyGL(char *pbyName, HWND *hWnd)
{ // begin DestroyGL()
	DestroyFonts();
	DestroyParticleSystem();
	if(Config.bFullScreen)										// Are We In Fullscreen Mode?
	{
		ChangeDisplaySettings(NULL, 0);					// If So Switch Back To The Desktop
		ShowCursor(TRUE);								// Show Mouse Pointer
	}
	if(hRC)											// Do We Have A Rendering Context?
	{
		if(!wglMakeCurrent(NULL, NULL))					// Are We Able To Release The DC And RC Contexts?
		{
			MessageBox(NULL,"Release Of DC And RC Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}
		if(!wglDeleteContext(hRC))						// Are We Able To Delete The RC?
		{
			MessageBox(NULL,"Release Rendering Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}
		hRC = NULL;										// Set RC To NULL
	}
	if(hDC && !ReleaseDC(*hWnd, hDC))					// Are We Able To Release The DC
	{
		MessageBox(NULL,"Release Device Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hDC = NULL;										// Set DC To NULL
	}
	ASDestroyWindow(hWnd, pbyName);
	return AS_ERROR_NONE;
} // end DestroyGL()

GLfloat LightAmbient[]	= { 0.05f, 0.05f, 0.05f, 1.0f };
GLfloat LightDiffuse[]	= { 0.05f, 0.05f, 0.05f, 1.0f }; 
GLfloat LightPosition[]	= { 0.0f, 0.0f, 5.0f, 1.0f };
/*GLfloat LightAmbient[]	= { 0.5f, 0.5f, 0.5f, 0.5f };
GLfloat LightDiffuse[]	= { 0.5f, 0.5f, 0.5f, 0.5f }; 
GLfloat LightPosition[]	= { 7.0f, 7.0f, 5.0f, 1.0f };*/


HRESULT ReSizeGL(void)
{ // begin ReSizeGL()
	glViewport(0, 0, Config.iWindowWidth, Config.iWindowHeight);						// Reset The Current Viewport
	glMatrixMode(GL_PROJECTION);						// Select The Projection Matrix
	glLoadIdentity();									// Reset The Projection Matrix
	// Calculate The Aspect Ratio Of The Window
	gluPerspective(45.0f, (GLfloat) Config.iWindowWidth/ (GLfloat) Config.iWindowHeight, 0.1f, 300.0f);
	glMatrixMode(GL_MODELVIEW);							// Select The Modelview Matrix
	glEnable(GL_TEXTURE_2D);							// Enable Texture Mapping
	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);		
	switch(Config.byLight)
	{
		case 0: case 1: glShadeModel(GL_FLAT); break;
		case 2: glShadeModel(GL_SMOOTH); break;
	}
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);				// Black Background
	glClearDepth(1.0f);									// Depth Buffer Setup
	glColor4f(1.0f, 1.0f, 1.0f, 1.0);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);
	glEnable(GL_COLOR_MATERIAL);
	glEnable(GL_COLOR_MATERIAL_FACE);
	glColorMaterial(GL_FRONT,GL_AMBIENT_AND_DIFFUSE);
	glMateriali(GL_FRONT,GL_SHININESS,128);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);					// Set The Blending Function For Translucency
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_FASTEST);
	glHint(GL_LINE_SMOOTH_HINT, GL_FASTEST);
	glHint(GL_FOG_HINT, GL_FASTEST);
	glHint(GL_POINT_SMOOTH_HINT, GL_FASTEST);
	glHint(GL_POLYGON_SMOOTH_HINT, GL_FASTEST);
	glEnable(GL_NORMALIZE); 
	glPolygonMode(GL_FRONT, GL_FILL);
	glLightfv(GL_LIGHT1, GL_AMBIENT, LightAmbient);		// Setup The Ambient Light
	glLightfv(GL_LIGHT1, GL_DIFFUSE, LightDiffuse);		// Setup The Diffuse Light
	glLightfv(GL_LIGHT1, GL_POSITION,LightPosition);	// Position The Light
	glEnable(GL_LIGHT1);								// Enable Light One
	if(Config.byLight)
		glEnable(GL_LIGHTING);
	return 0;
} // end ReSizeGL();

HRESULT GLSwitchDisplayMode(void)
{ // begin GLSwitchDisplayMode()
	bNewSetting = TRUE;
	DestroyGL(GAME_NAME, &hWndMain);
	Config.bFullScreen = !Config.bFullScreen;
	InitGL(&hWndMain, GAME_TITLE, GAME_NAME);
	bNewSetting = FALSE;
	return AS_ERROR_NONE;
} // end GLSwitchDisplayMode()
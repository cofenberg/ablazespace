/*
	Config.h

    Last change:
    	24.6.2000

    Description:
		Loads, saves and deals with the configurations.
*/

#ifndef __AS_CONFIG_H__
#define __AS_CONFIG_H__


// Functions: *****************************************************************
// HRESULT CONFIG::Check(void);
// HRESULT CONFIG::Load(char *);
// HRESULT CONFIG::Save(char *)
extern void FindConfigMode(void);
extern HRESULT LoadKeySpecification(char *);
extern HRESULT SaveKeySpecification(char *);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern CONFIG Config;
extern DISPLAY_MODE_INFO DisplayModeInfo;
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_CONFIG_H__
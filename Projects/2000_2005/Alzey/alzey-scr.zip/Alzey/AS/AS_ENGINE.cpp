/*
	AS_ENGINE.cpp

    Last change:
    	24.6.2000

    Description:
		This are the main functions of the AblazeSapce engine.
*/

#include "AS_ENGINE.h"


// Functions: *****************************************************************
HRESULT ASEmptyDraw(void);
void ASSwapBuffers(HDC);
HRESULT ASCreatEngine(AS_ENGINE **Engine, HINSTANCE, int);
HRESULT ASDestroyEngine(AS_ENGINE **Engine);
HWND ASCreateWindow(HINSTANCE, WNDPROC, char *, char *, DWORD, DWORD, HMENU, BOOL);
HRESULT ASDestroyWindow(HWND *, char *);
HRESULT ASEnumerateDisplayModeInfos(void);
HRESULT ASAddDisplayModeInfo(DEVMODE);
HRESULT ASDestroyDisplayModeInfo(void);
HRESULT ASCreateCamera(AS_CAMERA **);
HRESULT ASDestroyCamera(AS_CAMERA **);
void CheckCameraInput(AS_CAMERA *);
void ASGiveKeyNamesKeyCodes(void);
BOOL ASSpeedControl(void);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
UINT iASLists;
char keys[256];
PROGRAM_INFO ProgramInfo;
HWND hWndMain = NULL;
LPTSTR pMainMenu = NULL;
RECT MainWindow;
HRESULT iASResult = 0;
char byASTemp[MAX_PATH];
char *pbyASTemp = NULL;
int iCmdShow;
HDC			hDC = NULL;		// Private GDI Device Context
HGLRC		hRC = NULL;		// Permanent Rendering Context
HINSTANCE hInstance = NULL; // Program handle
HANDLE hMutex = NULL;
BOOL bASSoundPossible; // Is it possible to play sounds?

BOOL bModuleEnd = FALSE;
BOOL bProgramEnd = FALSE;
BOOL bProgramActive = TRUE;
BOOL bNewSetting = FALSE;
int iASActiveModule, iASSetActiveModule; // The active game part (module)
HRESULT (*ASDrawFunction)(void) = NULL;
AS_INPUT_KEYS InputKeys[AS_MAX_INPUT_BUTTONS];
char byASConfigFile[MAX_PATH];
char byASHighscoreFile[MAX_PATH];
char byASLevelsFile[MAX_PATH];
char byASUserLevelsFile[MAX_PATH];
char byASObjectsFile[MAX_PATH];
char byASBitmapsFile[MAX_PATH];
char byASProgramPath[_MAX_DRIVE+_MAX_DIR];
char ExeName[_MAX_PATH];
char Drive[_MAX_DRIVE];
char Dir[_MAX_DIR];
char Directory[];
char byASUserName[MAX_PATH];
DWORD dwAS_FPS_TimeNow, dwAS_FPS_TimeLast, dwAS_FPS_TimeDifference;
int iAS_FPS_RenderedFrames, iAS_FPS_FramesSinceCheck, iAS_FPS;
long lASTLast, lASTNow, lASDeltaT;
float fASDeltaT;
///////////////////////////////////////////////////////////////////////////////


HRESULT ASEmptyDraw(void)
{ // begin ASEmptyDraw()
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	SwapBuffers(hDC);
	return AS_ERROR_NONE;
} // end ASEmptyDraw()

void ASSwapBuffers(HDC hDC)
{ // begin ASSwapBuffers()
	ASEngine->CheckFPS();
	if(Config.bShowFPS)
	{
		glDisable(GL_DEPTH_TEST);
		glEnable(GL_BLEND);
		glDisable(GL_LIGHTING);
		glColor4ub(255,255,255,255);
		glLoadIdentity();									
		FontBPrintCentered(0, -40.0f, 15.0f, "FPS: %d", iAS_FPS);
		glLoadIdentity();									
		FontBPrintCentered(0, -40.0f, 14.0f, "Rendered Frames: %d", iAS_FPS_RenderedFrames);
	}
	SwapBuffers(hDC);
} // end ASSwapBuffers()

HRESULT ASCreatEngine(AS_ENGINE **Engine, HINSTANCE hInst, int nCmdShow)
{ // begin ASCreatEngine()
	// Program stuff:
    hInstance = hInst;
	iCmdShow = nCmdShow;
    hMutex = OpenMutex(SYNCHRONIZE, FALSE, GAME_NAME);
    if(hMutex)
    {
        CloseHandle(hMutex);
        sprintf(byASTemp, GAME_NAME" l�uft schon!!");
        MessageBox(0, byASTemp, GAME_NAME, MB_ICONERROR | MB_OK);
        return FALSE;
    }
    else
        hMutex = CreateMutex(NULL, TRUE, GAME_NAME);
	ProgramInfo.Init();
	// Engine stuff:
    if(*Engine) 
        iASResult = ASDestroyEngine(Engine);
    *Engine = (AS_ENGINE *) malloc(sizeof(AS_ENGINE));
    if(!*Engine)
        return AS_ERROR_RESERVE_MEMORY;
    (*Engine)->Clean();    
	return AS_ERROR_NONE;
} // end ASCreatEngine()

HRESULT ASDestroyEngine(AS_ENGINE **Engine)
{ // begin ASDestroyEngine()    
	// Save the config data:
	Config.bFirstRun = FALSE;
	sprintf(byASTemp, "%s\\%s", byASProgramPath, byASConfigFile);
	Config.Save(byASTemp);
	// Program stuff:
	if(hMutex)
		CloseHandle(hMutex);
	hMutex = NULL;
	// Engine stuff:
    iASResult = (*Engine)->Destroy();
    if(iASResult != AS_ERROR_NONE)
        return iASResult;
    free(*Engine);
    *Engine = NULL;
    return AS_ERROR_NONE;
} // end ASDestroyEngine()

HWND ASCreateWindow(HINSTANCE hInstance,
                    WNDPROC WindowProc,
                    char *pbyTitle,
					char *pbyName,					
					DWORD dwWidth,
                    DWORD dwHeight,
			   	    HMENU Menu,
					BOOL bFullScreen)
{ // begin ASCreateWindow()
	// Creats the main Window:
    WNDCLASS wc;
	HWND hWnd;
	DWORD dwStyle, dwExStyle;

	if(bFullScreen)
	{
		dwExStyle = WS_EX_APPWINDOW;								// Window Extended Style
		dwStyle = WS_POPUP;										// Windows Style
		ShowCursor(FALSE);										// Hide Mouse Pointer
	}
	else
	{
		dwExStyle = WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;			// Window Extended Style
		dwStyle = WS_OVERLAPPEDWINDOW;							// Windows Style
	}
	// Set up and register window class
    wc.style = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
    wc.lpfnWndProc = WindowProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = hInstance;
    wc.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_ICON1));
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = NULL;
    wc.lpszMenuName = NULL;
    wc.lpszClassName = pbyName;
    RegisterClass(&wc);
    // Create a fullscreen window
    hWnd = CreateWindowEx(
		dwExStyle,
        pbyName,
        pbyTitle,
		dwStyle |							
		WS_CLIPSIBLINGS |					
		WS_CLIPCHILDREN,					
        CW_USEDEFAULT,
        SW_SHOW,
        dwWidth,
        dwHeight,
        NULL,
        Menu,
        hInstance,
        NULL);
    if(!hWnd)
        return NULL;
	return hWnd;
} // end ASCreateWindow()

HRESULT ASDestroyWindow(HWND *hWnd, char *pbyName)
{ // begin ASDestroyWindow()
	if(*hWnd && !DestroyWindow(*hWnd))					// Are We Able To Destroy The Window?
	{
		MessageBox(NULL,"Could Not Release hWnd.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
	}
	*hWnd = NULL;										// Set hWnd To NULL
	if(!UnregisterClass(pbyName, hInstance))		
	{
		MessageBox(NULL,"Could Not Unregister Class.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
	}
 	return AS_ERROR_NONE;
} // end ASDestroyWindow()

HRESULT ASEnumerateDisplayModeInfos(void)
{ // begin ASEnumerateDisplayModeInfos()
	int i;
	DEVMODE devMode;

	for(i = 0;;i++) 
	{
		if(!EnumDisplaySettings(NULL, i, &devMode)) 
			break;
		ASAddDisplayModeInfo(devMode);
	}
    return AS_ERROR_NONE;
} // end ASEnumerateDisplayModeInfos()

HRESULT ASAddDisplayModeInfo(DEVMODE lpDevMode)
{ // begin ASAddDisplayModeInfo()
	if(lpDevMode.dmBitsPerPel < 8)
		return AS_ERROR_RESERVE_MEMORY;
	DisplayModeInfo.Number++;
	DisplayModeInfo.pDevMode = (DEVMODE *) realloc(DisplayModeInfo.pDevMode, sizeof(DEVMODE)*DisplayModeInfo.Number);
	if(!DisplayModeInfo.pDevMode)
		return AS_ERROR_RESERVE_MEMORY;
	CopyMemory(&DisplayModeInfo.pDevMode[DisplayModeInfo.Number-1], &lpDevMode, sizeof(DEVMODE));
	#ifdef _DEBUG
		sprintf(byASTemp, "Add mode(%d) to DisplayModeInfo: %dx%dx%dx%d\n", DisplayModeInfo.Number-1, 
				DisplayModeInfo.pDevMode[DisplayModeInfo.Number-1].dmPelsWidth, 
				DisplayModeInfo.pDevMode[DisplayModeInfo.Number-1].dmPelsHeight, 
				DisplayModeInfo.pDevMode[DisplayModeInfo.Number-1].dmBitsPerPel, 
				DisplayModeInfo.pDevMode[DisplayModeInfo.Number-1].dmDisplayFrequency);
		OutputDebugString(byASTemp);
	#endif // _DEBUG
	return AS_ERROR_NONE;
} // end ASAddDisplayModeInfo()

HRESULT ASDestroyDisplayModeInfo(void)
{ // begin ASDestroyDisplayModeInfo()
	if(DisplayModeInfo.pDevMode)
		free(DisplayModeInfo.pDevMode);
	DisplayModeInfo.pDevMode = NULL;
	DisplayModeInfo.Number = 0;
	return AS_ERROR_NONE;
} // end ASDestroyDisplayModeInfo()

HRESULT ASCreateCamera(AS_CAMERA **pCamera)
{ // begin ASCreateCamera()
	if(*pCamera)
		ASDestroyCamera(pCamera);
	(*pCamera) = (AS_CAMERA *) calloc(1, sizeof(AS_CAMERA));
	(*pCamera)->Init();
    return AS_ERROR_NONE;
} // end ASCreateCamera()

HRESULT ASDestroyCamera(AS_CAMERA **pCamera)
{ // begin ASDestroyCamera()
	if(*pCamera)
		free(*pCamera);
	*pCamera = NULL;
    return AS_ERROR_NONE;
} // end ASDestroyCamera()

void CheckCameraInput(AS_CAMERA *pCamera)
{ // begin CheckCameraInput()
	if(keys[46])
	{
		keys[46] = FALSE;
		pCamera->fVelocity[ROT][Y] -= 0.01f*lASDeltaT;
	}
	if(keys[34])
	{
		keys[34] = FALSE;
		pCamera->fVelocity[ROT][Y] += 0.01f*lASDeltaT;
	}
	if(keys[36])
	{
		keys[36] = FALSE;
		pCamera->fVelocity[ROT][X] -= 0.01f*lASDeltaT;
	}
	if(keys[35])
	{
		keys[35] = FALSE;
		pCamera->fVelocity[ROT][X] += 0.01f*lASDeltaT; 
	}
	if(keys[45])
	{
		keys[45] = FALSE;
		pCamera->fVelocity[POS][Z] += 0.01f*lASDeltaT;
	}
	if(keys[33])
	{
		keys[33] = FALSE;
		pCamera->fVelocity[POS][Z] -= 0.01f*lASDeltaT;
	}
} // end CheckCameraInput()

BOOL ASPlayMidi(HWND hWnd, char *sFileName)
{
	if(!Config.bMusic)
		return FALSE;

    char buf[256];
    sprintf(buf, "open %s type sequencer alias MUSIC", sFileName);
    if(mciSendString("close all", NULL, 0, NULL) != 0)
        return FALSE;
    if(mciSendString(buf, NULL, 0, NULL) != 0)
        return FALSE;
    if(mciSendString("play MUSIC from 0", NULL, 0, hWnd) != 0)
        return FALSE;
    return TRUE;
}

BOOL ASStopMidi(void)
{
    if(mciSendString("close all", NULL, 0, NULL) != 0)
        return FALSE;
    return TRUE;
}

void ASGiveKeyNamesKeyCodes(void)
{ // begin ASGiveKeyNamesKeyCodes()
	int i, i2;

	for(i = 0; i < ASUsedKeys; i++)
	{
		for(i2 = 0; i2 < AS_MAX_INPUT_BUTTONS; i2++)
			if(!strcmp(ASKeyAction[i].byKeyName, InputKeys[i2].byName))
			{
				ASKeyAction[i].iKeyCode = InputKeys[i2].iCode;
				ASKeyAction[i].byDevice = InputKeys[i2].byDevice;
				break;
			}	
	}
} // end ASGiveKeyNamesKeyCodes()

BOOL ASSpeedControl(void)
{ // begin ASSpeedControl()
	// Speed controlling:
	lASTNow = GetTickCount();
	lASDeltaT = lASTNow-lASTLast;
	lASTLast = lASTNow;
	fASDeltaT = (float) lASDeltaT/100;
	if(!fASDeltaT)
		fASDeltaT = 0.00f;
	return TRUE;
} // end ASSpeedControl()


// Class functions:
void PROGRAM_INFO::Init(void)
{
	strcpy(Version, AS_VERSION);
	strcpy(Date, __DATE__);
	strcpy(Time, __TIME__);
}

HRESULT AS_ENGINE::Clean(void)
{ // begin AS_ENGINE::Clean()
    return AS_ERROR_NONE;
} // end AS_ENGINE::Clean()

HRESULT AS_ENGINE::Init(char *pbyFileName)
{ // begin AS_ENGINE::Init()
	DWORD i = MAX_PATH;

	srand((unsigned) time(NULL));
	// Find Path Info
	GetModuleFileName(hInstance, ExeName, MAX_PATH);
	_splitpath(ExeName, Drive, Dir, NULL, NULL);
	sprintf(byASProgramPath, "%s%s", Drive, Dir);
	SetCurrentDirectory(byASProgramPath);
	// Find system dependent data:
	GetUserName(byASUserName, &i);
	// Loads the game file stuff:
	sprintf(byASTemp, "%s\\%s", byASProgramPath, pbyFileName);
  	GetPrivateProfileString("General", "config_file", "Config.ini", byASConfigFile, MAX_PATH, byASTemp);
  	GetPrivateProfileString("General", "highscore_file", "Highscore.dat", byASHighscoreFile, MAX_PATH, byASTemp);
	GetPrivateProfileString("General", "levels_file", "Data\\Levels", byASLevelsFile, MAX_PATH, byASTemp);
	GetPrivateProfileString("General", "user_levels_file", "Data\\UserLevels", byASUserLevelsFile, MAX_PATH, byASTemp);
	GetPrivateProfileString("General", "objects_file", "Data\\Objects", byASObjectsFile, MAX_PATH, byASTemp);
	GetPrivateProfileString("General", "bitmaps_file", "Data\\Bitmaps", byASBitmapsFile, MAX_PATH, byASTemp);
    // Init FPS:
	dwAS_FPS_TimeNow = GetTickCount();
	dwAS_FPS_TimeLast = GetTickCount();
	dwAS_FPS_TimeDifference = 0;
	iAS_FPS_RenderedFrames = iAS_FPS_FramesSinceCheck = iAS_FPS;
	// Load the config data:
	sprintf(byASTemp, "%s\\%s", byASProgramPath, byASConfigFile);
	Config.Load(byASTemp);
	// Set the standart draw function:
	ASDrawFunction = ASEmptyDraw;
	// Other stuff:
	iASActiveModule = iASSetActiveModule = 0;
	return AS_ERROR_NONE;
} // end AS_ENGINE::Init()

HRESULT AS_ENGINE::Destroy(void)
{ // begin AS_ENGINE::Destroy()
    Clean();
    return AS_ERROR_NONE;
} // end AS_ENGINE::Destroy()

HRESULT AS_ENGINE::CheckFPS(void)
{ // begin AS_ENGINE::CheckFPS()
	dwAS_FPS_TimeNow = GetTickCount();
	dwAS_FPS_TimeDifference = dwAS_FPS_TimeNow-dwAS_FPS_TimeLast;
	iAS_FPS_RenderedFrames++;
	iAS_FPS_FramesSinceCheck++;
	if(dwAS_FPS_TimeDifference > 1000)
	{
		dwAS_FPS_TimeLast = dwAS_FPS_TimeNow;
		iAS_FPS = iAS_FPS_FramesSinceCheck;
		iAS_FPS_FramesSinceCheck = 0;
	}
    return iAS_FPS;
} // end AS_ENGINE::CheckFPS()

void AS_CAMERA::Init(void)
{ // begin AS_CAMERA::Init()
	int i, i2;

	for(i = 0; i < 3; i++)
	{
		fPos[i] = 0.0f;
		fRot[i] = 0.0f;
		fScale[i] = 1.0f;
		for(i2 = 0; i2 < 3; i2++)
			fVelocity[i2][i] = 0.0f;
	}
	fVDecrease = CAMERA_VDECREASE;	
	fPos[X] = 0.0f;
	fPos[Y] = 0.0f;
	fPos[Z] = -10.0f;
	fRot[X] = 180.0f;
} // end AS_CAMERA::Init()

void AS_CAMERA::SetScene(void)
{ // begin AS_CAMERA::SetScene()
	glLoadIdentity();									
	glTranslatef(0.0f, 0.0f, fPos[Z]);
	glRotatef(fRot[X], 1.0f, 0.0f, 0.0f);
	glRotatef(fRot[Y], 0, 1.0f, 0.0f);
	glRotatef(fRot[Z], 0.0f, 0.0f, 1.0f);
	glTranslatef(fPos[X], fPos[Y], 0.0f);
	glScalef(fScale[X], fScale[Y], fScale[Z]);
} // end AS_CAMERA::SetScene()

void AS_CAMERA::CheckMovement(void)
{ // begin AS_CAMERA::CheckMovement()
	int i, i2;

	for(i = 0; i < 3; i++)
	{
		fPos[i] += (fVelocity[POS][i]/100)*lASDeltaT;
		fRot[i] += (fVelocity[ROT][i]/100)*lASDeltaT;
		fScale[i] += (fVelocity[SCALE][i]/100)*fASDeltaT;
		for(i2 = 0; i2 < 3; i2++)
		{
			if(fVelocity[i2][i] > MAX_CAMERA_VELOCITY)
				fVelocity[i2][i] = MAX_CAMERA_VELOCITY;
			if(fVelocity[i2][i] < -MAX_CAMERA_VELOCITY)
				fVelocity[i2][i] = -MAX_CAMERA_VELOCITY;		
			if(fVelocity[i2][i] > 0)
			{
				if(fVelocity[i2][i]-(fVDecrease/100)*lASDeltaT < 0.0f)
					fVelocity[i2][i] = 0.0f;
				else
					fVelocity[i2][i] -= (fVDecrease/100)*lASDeltaT;
			}
			else
			{
				if(fVelocity[i2][i]+(fVDecrease/100)*lASDeltaT > 0.0f)
					fVelocity[i2][i] = 0.0f;
				else
					fVelocity[i2][i] += (fVDecrease/100)*lASDeltaT;
			}
		}
	}
	if(fPos[Z] >= -3.0f)
		fPos[Z] = -3.0f;
	if(fPos[Z] <= -60.0f)
		fPos[Z] = -60.0f;
	if(fGoToPos[Z] >= -3.0f)
		fGoToPos[Z] = -3.0f;
	if(fGoToPos[Z] <= -60.0f)
		fGoToPos[Z] = -60.0f;
} // end AS_CAMERA::CheckMovement()

void AS_CAMERA::NoVelocity(void)
{ // begin AS_CAMERA::NoVelocity()
	int i, i2;

	for(i = 0; i < 3; i++)
		for(i2 = 0; i2 < 3; i2++)
			fVelocity[i2][i] = 0.0f;
} // end AS_CAMERA::NoVelocity()
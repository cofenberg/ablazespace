/*
	Object.h

    Last change:
    	24.6.2000

    Description:
		Object header file.
*/

#ifndef __AS_OBJECT_H__
#define __AS_OBJECT_H__


typedef class AS_OBJECT
{
	public:
		AS_OBJECT *pAddress; 

		char *pbyName;
		float fPos[3]; // Translation
		float fRot[3], fRadians; // Rotation
		float fScale[3]; // Scale
		float fRed, fGreen, fBlue; // The object color

		AS_PARTICLE_HOLDER *pParticleHolder;
		BOOL bShowParticles;

		int nVertices;
		int nIndices;
		AS_VERTEX *coord;
		AS_VERTEX *Normal;
		int *indexlist;
		
		UINT iList;

		int iNestLevel;
		int iDefinedNestLevel;

		int iChilds;
		AS_OBJECT **pChild; // Next object(s)
		AS_OBJECT *pParent; //  Last (parent) object

		// Need overall coords
		double min_comp;
		float fBoundMin[3], fBoundMax[3];

		HRESULT Load(char *);
		void Destroy(void);
		HRESULT FileOutputReport(char *);
		void Normalize(BOOL);
		void Scale(float);
		void ScaleXYZ(float, float, float);
		void RotateTranslate(AS_VERTEX *);
		void SetScale(float, float, float);
		void Draw(float);
		void CreateList(void);
		void Check(void);
		void DrawBound(void);

} AS_OBJECT;

// Functions: *****************************************************************
// HRESULT AS_OBJECT::Load(char *);
// void AS_OBJECT::Destroy(void);
// void AS_OBJECT::Normalize(BOOL);
// void AS_OBJECT::Scale(double);
// HRESULT AS_OBJECT::FileOutputReport(char *);
// void AS_OBJECT::Draw(float);
// void AS_OBJECT::CreateList(void);
// void AS_OBJECT::Check(void);
// void AS_OBJECT::RotateTranslate(AS_VERTEX *);
// void AS_OBJECT::SetScale(float, float, float);
extern HRESULT CreateObject(AS_OBJECT **);
extern void DestroyObject(AS_OBJECT **);
extern void DrawObject(AS_OBJECT *, AS_CAMERA *, float);
extern void CheckObject(AS_OBJECT *);
extern void NormalizeObject(AS_OBJECT *);
extern void ShowObjectInfo(FILE *, AS_OBJECT *);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern double dObjMinComp;
extern BOOL bASShowBound;
extern BOOL bASShowBoundChilds;
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_OBJECT_H__
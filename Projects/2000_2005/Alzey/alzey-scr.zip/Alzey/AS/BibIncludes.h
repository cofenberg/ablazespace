/*
	BibIncludes.h

    Last change:
    	24.6.2000

    Description:
		Important includes.
*/

#ifndef __AS_BIB_INCLUDES_H__
#define __AS_BIB_INCLUDES_H__


#include <windows.h>
#include <windowsx.h>
#include <winuser.h>
#include <wingdi.h>
#include <dinput.h>
#include <dsound.h>
#include <cguid.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <mmsystem.h>

#include <gl\gl.h>
#include <gl\glu.h>
#include <gl\glaux.h>


#endif // __AS_BIB_INCLUDES_H__


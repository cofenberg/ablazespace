/*
	File.h

    Last change:
    	24.6.2000

    Description:
		Tools for the work with files and strings.
*/

#ifndef __AS_FILE_H__
#define __AS_FILE_H__


// Functions: *******************************************************
extern HRESULT ASNextNoSpace(FILE *);
extern void ASSetAfterNextToken(FILE *, char);
extern int ASGetAfterTokenNum(FILE *, char);
extern float ASGetAfterTokenNumF(FILE *, char);
extern char *ASGetAfterTokenStr(FILE *, char);
extern char *ASChangeToken(char *, char, char);
extern char *ASGetFileName(HWND,  char *, char *, BOOL);
/////////////////////////////////////////////////////////////////////


#endif // __AS_FILE_H__
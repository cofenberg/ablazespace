/*
	TypeDefs.h

    Last change:
    	24.6.2000

    Description:
		General variable types.
*/

#ifndef __AS_TYPE_DEFS_H__
#define __AS_TYPE_DEFS_H__


// Definitions: ***************************************************************
#ifndef UCHAR
typedef unsigned char UCHAR;
#endif // UCHAR
#ifndef USHORT
typedef unsigned short USHORT;
#endif // USHORT
#ifndef UINT
typedef unsigned int UINT;
#endif // UINT
typedef float AS_VECTOR[3];
typedef float MATRIX4x4[4][4];
///////////////////////////////////////////////////////////////////////////////

// Structures: ****************************************************************
typedef struct
{
	int iWidth, iHeight;
	float fScale;
	float fZPos; // The z pos in screen (for particle positions...)
	char bySpecialColor; // E.g. for the particle positions
	char *Bitmap;
} AS_BITMAP;

typedef struct
{
	int Number;
	DEVMODE *pDevMode;
} DISPLAY_MODE_INFO;

typedef class
{
	public:
		BOOL bFirstRun;
		BOOL bFullScreen;
		BOOL bSound;
		BOOL bMusic;
		BOOL bShowFPS;
		DWORD dwMode;
		char byLight; // 0 = none, 1 = flat, 2 = smooth
		int iColorDepthFilter;
		int iWindowWidth, iWindowHeight;
		int iModeIndex; 
		DEVMODE DevMode;
		int iScreenPixels, iScreenSize;
		char byKeyFile[MAX_PATH];

		void Check(void);
        HRESULT Load(char *);
	    HRESULT Save(char *);
	private:
} CONFIG;

typedef struct
{
	char byName[MAX_PATH];
	int iCode;
	char byDevice;
} AS_INPUT_KEYS;


typedef struct 
{
	float  sow;                   /* s texture ordinate (s over w) */
	float  tow;                   /* t texture ordinate (t over w) */  
	float  oow;                   /* 1/w (used mipmapping - really 0xfff/w) */
} AS_T_VERTEX;

typedef struct
{
	float x, y;         /* X and Y in screen space */
	float ooz;          /* 65535/Z (used for Z-buffering) */
	float oow;          /* 1/W (used for W-buffering, texturing) */
	float r, g, b, a;   /* R, G, B, A [0..255.0] */
	float z;            /* Z is ignored */
	AS_T_VERTEX tmuvtx[3];
  
	float w, u,v, ou, ov;
	float ox,oy,oz;
	float x64, y64, z64, w64;
} AS_VERTEX;

typedef class 
{
	public:
		float fPos[3], fRot[3], fScale[3];
		float fVelocity[3][3];
		float fVDecrease; // Velocity decrease
		float fGoToPos[3], fGoToRot[3];

		void Init(void);
		void SetScene(void);
		void CheckMovement(void);
		void NoVelocity(void);
} AS_CAMERA;

typedef struct
{
	char byAction[128];
	BOOL bPressed;
	char byDevice; // AS_MOUSE, AS_KEYBOARD
	int iKeyCode;
	char byKeyName[MAX_PATH];
	char byStandartKey[128];
} AS_KEY_ACTION;
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_TYPE_DEFS_H__
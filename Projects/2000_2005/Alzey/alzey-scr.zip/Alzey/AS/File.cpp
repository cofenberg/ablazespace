/*
	File.cpp

    Last change:
    	24.6.2000

    Description:
		Tools for the work with files and strings.
*/

#include "AS_Engine.h"


// Functions: *****************************************************************
HRESULT ASNextNoSpace(FILE *);
void ASSetAfterNextToken(FILE *, char);
int ASGetAfterTokenNum(FILE *, char);
float ASGetAfterTokenNumF(FILE *, char);
char *ASGetAfterTokenStr(FILE *, char);
char *ASChangeToken(char *, char, char);
char *ASGetFileName(HWND,  char *, char *, BOOL);
///////////////////////////////////////////////////////////////////////////////


HRESULT ASNextNoSpace(FILE *pFile)
{ // begin ASNextNoSpace()
	fpos_t tempFilePos;
	int iResult;

 	for(;;)
    {
		fgetpos(pFile, &tempFilePos);
		iResult = fgetc(pFile);
        if(iResult != ' ' && iResult != 10 && iResult != 9)
        {
		   	fsetpos(pFile, &tempFilePos);
        	break;
        }
    }
    if(iResult != EOF)
	    return AS_ERROR_NONE;
    else
        return AS_ERROR_END_OF_FILE;
} // end ASNextNoSpace()

void ASSetAfterNextToken(FILE *pFile, char byToken)
{ // begin ASSetAfterNextToken()
	char byTemp;

	do
	{	
		byTemp = (char) fgetc(pFile);
	} 
	while(byTemp != byToken && !feof(pFile));
} // end ASSetAfterNextToken()

int ASGetAfterTokenNum(FILE *pFile, char byToken)
{ // begin ASGetAfterTokenNum()
	int iNumber;

	ASSetAfterNextToken(pFile, byToken);
    fscanf(pFile, "%d", &iNumber);
	return iNumber;
} // end ASGetAfterTokenNum()

float ASGetAfterTokenNumF(FILE *pFile, char byToken)
{ // begin ASGetAfterTokenNumF()
	float fNumber;

	ASSetAfterNextToken(pFile, byToken);
    fscanf(pFile, "%f", &fNumber);
	return fNumber;
} // end ASGetAfterTokenNumF()

char *ASGetAfterTokenStr(FILE *pFile, char byToken)
{ // begin ASGetAfterTokenStr()
	char byTemp[256];
	char *pbyStr;

	ASSetAfterNextToken(pFile, byToken);
    fscanf(pFile, "%s", byTemp);
	pbyStr = (char *) malloc(strlen(byTemp));
	strcpy(pbyStr, byTemp);
	return pbyStr;
} // end ASGetAfterTokenStr()

char *ASChangeToken(char *pbyStr, char bySourceToken, char byConvertToken)
{ // begin ASChangeToken()
	UINT i;
	char *pbyConvertStr = (char *) malloc(strlen(pbyStr)+1);
	
	strcpy(pbyConvertStr, pbyStr);
	for(i = 0; i < strlen(pbyStr); i++)
	{
		if(pbyConvertStr[i] == bySourceToken)
			pbyConvertStr[i] = byConvertToken;
	}
	return pbyConvertStr;	
} // end ASChangeToken()

char *ASGetFileName(HWND hWnd,  char *pbyTitle, char *pbyFilter, BOOL bMode)
{ // begin ASGetFileName()
    static char file[256];
    static char fileTitle[256];

    OPENFILENAME ofn;

	bProgramActive = FALSE;
    lstrcpy( file, "");
    lstrcpy( fileTitle, "");

    ofn.lStructSize       = sizeof(OPENFILENAME);
    ofn.hwndOwner         = hWnd;
#ifdef WIN32
    ofn.hInstance         = (HINSTANCE) GetWindowLong(hWnd, GWL_HINSTANCE);
#else
    ofn.hInstance         = (HINSTANCE) GetWindowWord(hWnd, GWW_HINSTANCE);
#endif
    ofn.lpstrFilter       = pbyFilter;
    ofn.lpstrCustomFilter = (LPSTR) NULL;
    ofn.nMaxCustFilter    = 0L;
    ofn.nFilterIndex      = 1L;
    ofn.lpstrFile         = file;
    ofn.nMaxFile          = sizeof(file);
    ofn.lpstrFileTitle    = fileTitle;
    ofn.nMaxFileTitle     = sizeof(fileTitle);
    ofn.lpstrInitialDir   = NULL;
    ofn.lpstrTitle        = pbyTitle;
    ofn.nFileOffset       = 0;
    ofn.nFileExtension    = 0;
    ofn.lpstrDefExt       = pbyFilter;
	ofn.lCustData         = 0;

	ofn.Flags = OFN_PATHMUSTEXIST | OFN_ENABLESIZING | OFN_HIDEREADONLY;
    if(!bMode) // We loads a file...
		ofn.Flags |= OFN_FILEMUSTEXIST;

    if (GetOpenFileName(&ofn))
    {
		bProgramActive = TRUE;
	    return (char*)ofn.lpstrFile;
    }
	else
    {
		bProgramActive = TRUE;
	    return NULL;
	}
} // end ASGetFileName()
/*
	Particle.cpp

    Last change:
    	24.6.2000

    Description:
		The particle system.
*/

#include "AS_ENGINE.h"


// Functions: *****************************************************************
/*
HRESULT AS_PARTICLE_HOLDER::Init(int);
void AS_PARTICLE_HOLDER::Destroy(void);
void AS_PARTICLE_HOLDER::InitParticles(AS_BITMAP *);
void AS_PARTICLE_HOLDER::InitParticle(int, AS_BITMAP *);
void AS_PARTICLE_HOLDER::Draw(void);
void AS_PARTICLE_HOLDER::Check(BOOL, AS_BITMAP *);
*/
void InitParticleSystem(void);
void DestroyParticleSystem(void);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
UINT iASParticleTexture[AS_PARTICLE_TYPES];
char byASPTFile[AS_PARTICLE_TYPES][128] =
	{"Particle.bmp"};
///////////////////////////////////////////////////////////////////////////////


void InitParticleSystem(void)
{ // begin InitParticleSystem()
	byte Texture[] = {IDB_PARTICLE};
    int i;
	HBITMAP hBMP;
	BITMAP	BMP;
	
	glDeleteTextures(1, &iASParticleTexture[0]);
	glGenTextures(1, &iASParticleTexture[0]);
	for(i = 0; i < MAX_TEXTURES; i++)
	{
		hBMP = (HBITMAP) LoadImage(GetModuleHandle(NULL), MAKEINTRESOURCE(Texture[i]), IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION);
		if(hBMP)
        {
			GetObject(hBMP, sizeof(BMP), &BMP);
			glPixelStorei(GL_UNPACK_ALIGNMENT,4);
			glBindTexture(GL_TEXTURE_2D, iASParticleTexture[i]);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_NEAREST);
				gluBuild2DMipmaps(GL_TEXTURE_2D, 3, BMP.bmWidth, BMP.bmHeight, GL_BGR_EXT, GL_UNSIGNED_BYTE, BMP.bmBits);
        }
	}
} // end InitParticleSystem()

void DestroyParticleSystem(void)
{ // begin DestroyParticleSystem()
	glDeleteTextures(1, &iASParticleTexture[0]);
} // end DestroyParticleSystem()


// Class functions:
HRESULT AS_PARTICLE_HOLDER::Init(int iMaxParticles)
{ // begin AS_PARTICLE_HOLDER::Ini()
	Destroy();
	// Create a new particle holder;
	iParticles = iMaxParticles;
	pParticle = (AS_PARTICLE *) calloc(iParticles, sizeof(AS_PARTICLE));
    if(!pParticle)
	   return AS_ERROR_RESERVE_MEMORY;
	return AS_ERROR_NONE;
} // end AS_PARTICLE_HOLDER::Ini()

void AS_PARTICLE_HOLDER::Destroy(void)
{ // begin AS_PARTICLE_HOLDER::Destroy()
	if(pParticle)
		free(pParticle);
	pParticle = NULL;
} // end AS_PARTICLE_HOLDER::Destroy()

void AS_PARTICLE_HOLDER::InitParticles(AS_BITMAP *Bitmap)
{ // begin AS_PARTICLE_HOLDER::InitParticles()
	int i;
	
	for(i = 0; i < iParticles; i++)
		InitParticle(i, Bitmap);
} // end AS_PARTICLE_HOLDER::InitParticles()

void AS_PARTICLE_HOLDER::InitParticle(int i, AS_BITMAP *Bitmap)
{ // begin AS_PARTICLE_HOLDER::InitParticle()
	int i2;

	pParticle[i].bActive = FALSE;
	pParticle[i].fLife = 1.0f;
	pParticle[i].bTargetPos = FALSE;
	if(Bitmap)
	{ // The particle becomes maybe a target pos...
		for(i2 = 0; i2 < 10; i2++)
		{
			int iXPos = rand() % Bitmap->iWidth;
			int iYPos = rand() % Bitmap->iHeight;

			if(Bitmap->Bitmap[iYPos*Bitmap->iWidth+iXPos] ==
			   Bitmap->bySpecialColor)
			{ // YES it becomes a target point!
				pParticle[i].bTargetPos = TRUE;
				pParticle[i].fTargetPos[X] = (float) (iXPos-(Bitmap->iWidth/2))*Bitmap->fScale;
				pParticle[i].fTargetPos[Y] = (float) (iYPos-(Bitmap->iHeight/2))*Bitmap->fScale;
				pParticle[i].fTargetPos[Z] = Bitmap->fZPos;
				break;
			}
		}
	}
	if(fFade == -1.0f)
	{
		pParticle[i].fFade = (float) (rand() % ((int) (fRFadeMax*100000)))/100000;
		if(pParticle[i].fFade < fRFadeMin)
			pParticle[i].fFade = fRFadeMin;
	}
	else
		pParticle[i].fFade = fFade;
	if(fRedColor == -1.0f)
		pParticle[i].fRedColor = (float) (rand() % 1000) / 1000;
	else
		pParticle[i].fRedColor = fRedColor;
	if(fGreenColor == -1.0f)
		pParticle[i].fGreenColor = (float) (rand() % 1000) / 1000;
	else
		pParticle[i].fGreenColor = fGreenColor;
	if(fBlueColor == -1.0f)
		pParticle[i].fBlueColor = (float) (rand() % 1000) / 1000;
	else
		pParticle[i].fBlueColor = fBlueColor;
	for(i2 = 0; i2 < 3; i2++)
	{
		pParticle[i].fPos[i2] = fPos[i2];
		pParticle[i].fSpeedIncrease[i2] = fSpeedIncrease[i2];
		if(fSpeed[i2] == -1.0f)
		{
			pParticle[i].fSpeed[i2] = (float) (rand() % (int) (fRSpeed[i2]*100000))/100000;
			if(pParticle[i].fSpeed[i2] == 0.0f)
				pParticle[i].fSpeed[i2] = 0.001f;
		}
		else
		{
			if(fDistribution == 0.0f)
				pParticle[i].fSpeed[i2] = fSpeed[i2];
			else
				pParticle[i].fSpeed[i2] = fSpeed[i2]+((float((rand()%60)-32.0f)/fDistribution));
		}
	}
} // end AS_PARTICLE_HOLDER::InitParticle()

void AS_PARTICLE_HOLDER::Draw(void)
{ // begin AS_PARTICLE_HOLDER::Draw()
	int i;
	
	glDisable(GL_LIGHTING);
	glEnable(GL_BLEND);
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_DEPTH_TEST);
	glBindTexture(GL_TEXTURE_2D,  iASParticleTexture[iParticleType]);
	glColor3f(1.0f, 1.0f, 1.0f);
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	glDisable(GL_CULL_FACE);
	if(!pParticle)
		return;	
	for(i = 0; i < iParticles; i++)
	{
		if(!pParticle[i].bActive)
			continue; // The particle isn't active
		// Draw the particle using our RGB values, fade the particle based on it's life:
		glColor4f(pParticle[i].fRedColor, pParticle[i].fGreenColor, pParticle[i].fBlueColor, pParticle[i].fLife);
		glBegin(GL_TRIANGLE_STRIP);
			glTexCoord2d(1,1); glVertex3f(pParticle[i].fPos[X]+0.5f, pParticle[i].fPos[Y]+0.5f, pParticle[i].fPos[Z]);
			glTexCoord2d(0,1); glVertex3f(pParticle[i].fPos[X]-0.5f, pParticle[i].fPos[Y]+0.5f, pParticle[i].fPos[Z]);
			glTexCoord2d(1,0); glVertex3f(pParticle[i].fPos[X]+0.5f, pParticle[i].fPos[Y]-0.5f, pParticle[i].fPos[Z]);
			glTexCoord2d(0,0); glVertex3f(pParticle[i].fPos[X]-0.5f, pParticle[i].fPos[Y]-0.5f, pParticle[i].fPos[Z]);
		glEnd();
    }
	glEnable(GL_CULL_FACE);
} // end AS_PARTICLE_HOLDER::Draw()

void AS_PARTICLE_HOLDER::Check(BOOL bNewParticles, AS_BITMAP *Bitmap)
{ // begin AS_PARTICLE_HOLDER::Check()
	int i, i2;
	
	for(i = 0; i < iParticles; i++)
	{
		if(!pParticle[i].bActive)
		{
			if(!bNewParticles)
				continue; // The particle isn't active
			else
			{ // Set up a new particle:
				InitParticle(i, Bitmap);
				pParticle[i].bActive = TRUE;
			}
		}
		for(i2 = 0; i2 < 3; i2++)
		{
			pParticle[i].fPos[i2] += (pParticle[i].fSpeed[i2]/fSlowdown/10)*lASDeltaT;
			pParticle[i].fSpeed[i2] += (pParticle[i].fSpeedIncrease[i2]/10)*lASDeltaT;
			if(pParticle[i].bTargetPos)
			{ // The particle want to go to a special position:
				if(pParticle[i].fPos[i2] > pParticle[i].fTargetPos[i2])
				{
					pParticle[i].fPos[i2] -= 0.01f*lASDeltaT;
				}
				else
				{
					pParticle[i].fPos[i2] += 0.01f*lASDeltaT;
				}
			}
		}
		pParticle[i].fLife -= (pParticle[i].fFade/10)*lASDeltaT;

		if(pParticle[i].fLife < 0.0f) 
		{ // The particle is burned out:
			pParticle[i].bActive = FALSE;
		}
    }
} // end AS_PARTICLE_HOLDER::Check()

/*
		}
		for(i2 = 0; i2 < 3; i2++)
		{
			pParticle[i].fPos[i2] += (pParticle[i].fSpeed[i2]/fSlowdown/100)*lASDeltaT;
			pParticle[i].fSpeed[i2] += (pParticle[i].fSpeedIncrease[i2]/100)*lASDeltaT;
			if(pParticle[i].bTargetPos)
			{ // The particle want to go to a special position:
				if(pParticle[i].fPos[i2] > pParticle[i].fTargetPos[i2])
					pParticle[i].fPos[i2] -= 0.002f*lASDeltaT;
				else
					pParticle[i].fPos[i2] += 0.002f*lASDeltaT;
			}
		}
		pParticle[i].fLife -= (pParticle[i].fFade/100)*lASDeltaT;
		if(pParticle[i].fLife < 0.0f) 
		{ // The particle is burned out:
			pParticle[i].bActive = FALSE;
		}*/
/*
	Object.cpp

    Last change:
    	24.6.2000

    Description:
		This function's deals with the control of 3D objects.
*/

#include "AS_ENGINE.h"


// Functions: *****************************************************************
// HRESULT AS_OBJECT::Load(char *);
// void AS_OBJECT::Destroy(void);
// void AS_OBJECT::Normalize(BOOL);
// void AS_OBJECT::Scale(double);
// HRESULT AS_OBJECT::FileOutputReport(char *);
// void AS_OBJECT::Draw(float);
// void AS_OBJECT::CreateList(void);
// void AS_OBJECT::Check(void);
// void AS_OBJECT::RotateTranslate(AS_VERTEX *);
// void AS_OBJECT::SetScale(float, float, float);
HRESULT CreateObject(AS_OBJECT **);
void DestroyObject(AS_OBJECT **);
void DrawObject(AS_OBJECT *, AS_CAMERA *, float);
void CheckObject(AS_OBJECT *);
void NormalizeObject(AS_OBJECT *);
void ShowObjectInfo(FILE *, AS_OBJECT *);
BOOL bASShowBound = FALSE;
BOOL bASShowBoundChilds = FALSE;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
double dObjMinComp;
///////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////
HRESULT CreateObject(AS_OBJECT **pObj)
{ // begin CreateObject()
	(*pObj) = (AS_OBJECT *) calloc(1, sizeof(AS_OBJECT));
	if(!*pObj)
        return AS_ERROR_RESERVE_MEMORY;
	(*pObj)->pAddress = *pObj;
	return AS_ERROR_NONE;
} // end CreateObject()

void DestroyObject(AS_OBJECT **pObj)
{ // begin DestroyObject()
	if(!*pObj)
		return;
	(*pObj)->Destroy();
	free(*pObj);
	*pObj = NULL;
} // end DestroyObject()

void DrawObject(AS_OBJECT *pObj, AS_CAMERA *Camera, float fAlpha)
{ // begin DrawObject()
	BOOL bTempShowBound;

	pObj->SetScale(pObj->fScale[X], pObj->fScale[Y], pObj->fScale[Z]);
	if(Camera)
		Camera->SetScene();
	glTranslatef(pObj->fPos[X], pObj->fPos[Y], pObj->fPos[Z]);
	glRotatef(pObj->fRot[X], 1.0f, 0.0f, 0.0f);
	glRotatef(pObj->fRot[Y], 0.0f, 1.0f, 0.0f);
	glRotatef(pObj->fRot[Z], 0.0f, 0.0f, 1.0f);
	bTempShowBound = bASShowBound;
	if(!bASShowBoundChilds)
		bASShowBound = FALSE;
	else
		bASShowBound = TRUE;
	pObj->Draw(fAlpha);
	bASShowBound = bTempShowBound;
	if(!bASShowBoundChilds && bASShowBound)
	{
		glPushMatrix();
		glScalef(pObj->fScale[X], pObj->fScale[Y], pObj->fScale[Z]);
		pObj->DrawBound();
		glPopMatrix();
	}
} // end DrawObject()

void CheckObject(AS_OBJECT *pObj)
{ // begin CheckObject()
	pObj->Check();
} // end CheckObject()

void NormalizeObject(AS_OBJECT *pObj)
{ // begin NormalizeObject()
	dObjMinComp = pObj->min_comp;;
	pObj->Normalize(TRUE);
	dObjMinComp = 0;
} // end NormalizeObject()

void ShowObjectInfo(FILE *pFile, AS_OBJECT *pObj)
{ // begin ShowObjectInfo()
	int i;

	fprintf(pFile, "\nObject #%x\n", pObj->pAddress);
	fputs("----------\n", pFile);
	fprintf(pFile, "Name: %s\n", pObj->pbyName);
	fprintf(pFile, "Parent: %x\n", pObj->pParent);
	fprintf(pFile, "Childs: %d\n", pObj->iChilds);
	for(i = 0; i < pObj->iChilds; i++)
		fprintf(pFile, "Child %d: %x\n", i, pObj->pChild[i]);
	fprintf(pFile, "Vertices: %d\n", pObj->nVertices);
	fprintf(pFile, "Indices: %d\n", pObj->nIndices);
	fprintf(pFile, "Tx = %f Ty = %f Tz = %f\n", pObj->fPos[X], pObj->fPos[Y], pObj->fPos[Z]);
	fprintf(pFile, "Rx = %f Ry = %f Rz = %f Angle=%f\n\n", pObj->fRot[X], pObj->fRot[Y], pObj->fRot[Z], pObj->fRadians);
	fprintf(pFile, "Childs:\n\n");
 	for(i = 0; i < pObj->iChilds; i++)
		ShowObjectInfo(pFile, pObj->pChild[i]->pAddress);
} // end ShowObjectInfo()


// Object class functions:
HRESULT AS_OBJECT::Load(char *pbyFilename)
{ // begin AS_OBJECT::Load()
	FILE *pFile;
	char byTemp[256];

	pFile = fopen(pbyFilename, "rt");
	if(!pFile) 
	{
		sprintf(byTemp, "Could not open %s file!", pbyFilename);
		MessageBox(NULL, byTemp, NULL, MB_OK);
		return FALSE;
	}
	min_comp = 0.0;
	dObjMinComp = 0;
	ASLoadWrl(pFile, pAddress);
	fclose(pFile);
	bShowParticles = TRUE;
	min_comp = dObjMinComp;
	ScaleXYZ(fScale[X], fScale[Y], fScale[Z]);
	CreateList();
	return TRUE;
} // end AS_OBJECT::Load()

void AS_OBJECT::Destroy(void)
{ // begin AS_OBJECT::Destroy()
	if(pbyName)
		free(pbyName);
	pbyName = NULL;
	if(coord)
		free(coord);
	coord = NULL;
	if(indexlist)
		free(indexlist);
	indexlist = NULL;
	if(Normal)
		free(Normal);
	Normal = NULL;
	if(pParticleHolder)
		pParticleHolder->Destroy();
	pParticleHolder = NULL;
} // end AS_OBJECT::Destroy()

void AS_OBJECT::Normalize(BOOL bParent)
{ // begin AS_OBJECT::Normalize()
	if(bParent)
	{
		if(dObjMinComp == 0) 
			return;
		Scale((float) (1.0f / dObjMinComp));
		return;
	}
	if(min_comp == 0) 
		return;
	Scale((float)  (1.0 / min_comp));
} // end AS_OBJECT::Normalize()

void AS_OBJECT::Scale(float fFactor)
{  // begin AS_OBJECT::Scale()
 	int i, i2;

	for(i = 0; i < iChilds; i++)
		pChild[i]->Scale(fFactor);
	for(i = 0; i < nVertices; i++) 
	{
		coord[i].ox *= fFactor;
		coord[i].oy *= fFactor;
		coord[i].oz *= fFactor;
	}
	fPos[X] *= fFactor;
	fPos[Y] *= fFactor;
	fPos[Z] *= fFactor;
	for(i2 = 0; i2 < 3; i2++)
	{
		fBoundMin[i2] *= fFactor;
		fBoundMax[i2] *= fFactor;
		if(!pParticleHolder)
			continue;
		pParticleHolder->fPos[i2] *= fFactor;
	}
} // end AS_OBJECT::Scale()

void AS_OBJECT::ScaleXYZ(float fX, float fY, float fZ)
{  // begin AS_OBJECT::ScaleXYZ()
 	int i;

	for(i = 0; i < iChilds; i++)
		pChild[i]->ScaleXYZ(fX, fY, fZ);
	for(i = 0; i < nVertices; i++) 
	{
		coord[i].ox *= fX;
		coord[i].oy *= fY;
		coord[i].oz *= fZ;
	}
	fPos[X] *= fX;
	fPos[Y] *= fY;
	fPos[Z] *= fZ;
	fBoundMin[X] *= fX;
	fBoundMin[Y] *= fY;
	fBoundMin[Z] *= fZ;
	fBoundMax[X] *= fX;
	fBoundMax[Y] *= fY;
	fBoundMax[Z] *= fZ;
	if(!pParticleHolder)
		return;;
	pParticleHolder->fPos[X] *= fX;
	pParticleHolder->fPos[Y] *= fY;
	pParticleHolder->fPos[Z] *= fZ;
} // end AS_OBJECT::ScaleXYZ()

HRESULT AS_OBJECT::FileOutputReport(char *pbyFilename)
{ // begin AS_OBJECT::FileOutputReport()
	FILE *pFile = fopen(pbyFilename, "wt");

	if(!pFile)
		return AS_ERROR_FILE_CREATING;
	fprintf(pFile, "Main Object:");
	ShowObjectInfo(pFile, pAddress);
	fclose(pFile);
	return 0;
} // end AS_OBJECT::FileOutputReport()

void AS_OBJECT::CreateList(void)
{ // begin AS_OBJECT::CreateList()
	int i, i2;

	for(i = 0; i < iChilds; i++)
		pChild[i]->CreateList();
	if(!nIndices)
		return;
	iList = iASLists;
	iASLists++;
	glNewList(iList, GL_COMPILE);
		glBegin(GL_TRIANGLES);
			for(i = 0, i2 = 0; i < (nIndices-4); i +=4, i2++)
			{	
				glNormal3f(Normal[i2].ox, Normal[i2].oy, Normal[i2].oz);
				glVertex3f(coord[indexlist[i]].ox, 
						   coord[indexlist[i]].oy,
						   coord[indexlist[i]].oz);
				glVertex3f(coord[indexlist[i+1]].ox, 
						   coord[indexlist[i+1]].oy,
						   coord[indexlist[i+1]].oz);
				glVertex3f(coord[indexlist[i+2]].ox, 
						   coord[indexlist[i+2]].oy,
						   coord[indexlist[i+2]].oz);
			}
		glEnd();
	glEndList();
} // end AS_OBJECT::CreateList()

void AS_OBJECT::Draw(float fAlpha)
{ // begin AS_OBJECT::Draw()
	int i;

	glPolygonMode(GL_FRONT, GL_FILL);
	glPolygonMode(GL_BACK, GL_POINT);
	glPushMatrix();
	for(i = 0; i < iChilds; i++)
		pChild[i]->Draw(fAlpha);
	if(fAlpha == 0.0f)
		return;
	if(fAlpha == 1.0f)
		glDisable(GL_BLEND);
	else
		glEnable(GL_BLEND);
	glScalef(fScale[X], fScale[Y], fScale[Z]);
	if(bASShowBound)
		DrawBound();
	if(pParticleHolder && bShowParticles)
		pParticleHolder->Draw();
	if(!nIndices)
	{
		glPopMatrix();
		return;
	}
	glDisable(GL_TEXTURE_2D);
	if(Config.byLight)
		glEnable(GL_LIGHTING);
	glEnable(GL_DEPTH_TEST);
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	glColor4f(fRed, fGreen, fBlue, fAlpha);
	glCallList(iList);
	glPopMatrix();
} // end AS_OBJECT::Draw()

void AS_OBJECT::Check(void)
{ // begin AS_OBJECT::Check()
	int i;

 	for(i = 0; i < iChilds; i++)
		pChild[i]->Check();
	if(pParticleHolder)
		pParticleHolder->Check(TRUE, NULL);
} // end AS_OBJECT::Check()

void AS_OBJECT::DrawBound(void)
{ // begin AS_OBJECT::DrawBound()
	// Show the object bound:
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	glBegin(GL_QUADS);
		glVertex3f(fBoundMin[X],
				   fBoundMin[Y],
				   fBoundMin[Z]);
		glVertex3f(fBoundMin[X],
				   fBoundMax[Y],
				   fBoundMin[Z]);
		glVertex3f(fBoundMax[X],
				   fBoundMax[Y],
				   fBoundMin[Z]);
		glVertex3f(fBoundMax[X],
				   fBoundMin[Y],
				   fBoundMin[Z]);

		glVertex3f(fBoundMin[X],
				   fBoundMin[Y],
				   fBoundMax[Z]);
		glVertex3f(fBoundMin[X],
				   fBoundMax[Y],
				   fBoundMax[Z]);
		glVertex3f(fBoundMax[X],
				   fBoundMax[Y],
				   fBoundMax[Z]);
		glVertex3f(fBoundMax[X],
				   fBoundMin[Y],
				   fBoundMax[Z]);

		glVertex3f(fBoundMin[X],
				   fBoundMin[Y],
				   fBoundMin[Z]);
		glVertex3f(fBoundMin[X],
				   fBoundMin[Y],
				   fBoundMax[Z]);
		glVertex3f(fBoundMax[X],
				   fBoundMin[Y],
				   fBoundMax[Z]);
		glVertex3f(fBoundMax[X],
				   fBoundMin[Y],
				   fBoundMin[Z]);

		glVertex3f(fBoundMin[X],
				   fBoundMax[Y],
				   fBoundMin[Z]);
		glVertex3f(fBoundMin[X],
				   fBoundMax[Y],
				   fBoundMax[Z]);
		glVertex3f(fBoundMax[X],
				   fBoundMax[Y],
				   fBoundMax[Z]);
		glVertex3f(fBoundMax[X],
				   fBoundMax[Y],
				   fBoundMin[Z]);
	glEnd();
} // end AS_OBJECT::DrawBound()

void AS_OBJECT::RotateTranslate(AS_VERTEX *v)
{ // begin AS_OBJECT::RotateTranslate()
	v->ox *= fScale[X];
	v->oy *= fScale[Y];
	v->oz *= fScale[Z];

	if(fRadians != 0) 
		ASMathRotateArbitrary(&v->ox, &v->oy, &v->oz,
							  fRot[X], fRot[Y], fRot[Z], fRadians);
	v->ox += fPos[X];
	v->oy += fPos[Y];
	v->oz += fPos[Z];
} // end AS_OBJECT::RotateTranslate()

void AS_OBJECT::SetScale(float fX, float fY, float fZ)
{ // begin AS_OBJECT::SetScale()
	int i;

	for(i = 0; i < iChilds; i++)
		pChild[i]->SetScale(fX, fY, fZ);
	fScale[X] = fX;
	fScale[Y] = fY;
	fScale[Z] = fZ;
} // end AS_OBJECT::SetScale()
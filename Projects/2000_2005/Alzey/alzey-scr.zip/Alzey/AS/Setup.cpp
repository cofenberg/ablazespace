/*
	Setup.cpp

    Last change:
    	24.6.2000

    Description:
		This is the setup dialog  stuff.
*/

#include "AS_ENGINE.h"


// Functions: *****************************************************************
extern void StartNewMidi(void);
void OpenAboutDialog(void);
LRESULT CALLBACK AboutProc(HWND, UINT, WPARAM, LPARAM);
void InitSetupDialog(HWND);
BOOL CALLBACK DIEnumDevicesProc(LPCDIDEVICEINSTANCE, LPVOID);
void OpenSetupDialog(void);
LRESULT CALLBACK SetupProc(HWND, UINT, WPARAM, LPARAM);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
HWND hWndSetup;
DEVMODE TempDevMode;
BOOL bTempFullScreen;
BOOL bTempSound;
BOOL bTempMusic;
BOOL bTempShowFPS;
///////////////////////////////////////////////////////////////////////////////


void OpenAboutDialog(void)
{ // begin OpenAboutDialog()
	if(Camera)
		Camera->NoVelocity();
	bProgramActive = FALSE;
	DialogBox(hInstance, MAKEINTRESOURCE(ID_ABOUT), hWndMain, (DLGPROC) AboutProc);
	bProgramActive = TRUE;
} // end OpenAboutDialog()

LRESULT CALLBACK AboutProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin AboutProc()
    switch(iMessage)
    {
        case WM_INITDIALOG:
			    ShowWindow(hWnd, iCmdShow);
				UpdateWindow(hWnd);
            	SetDlgItemText(hWnd, IDA_BUILD_DATE, ProgramInfo.Date);
            	SetDlgItemText(hWnd, IDA_BUILD_TIME, ProgramInfo.Time);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case IDA_OK:
					EndDialog(hWnd, FALSE);
                    return TRUE;
            }
            break;
    }
    return FALSE;
} // end AboutProc()

BOOL CALLBACK DIEnumDevicesProc(LPCDIDEVICEINSTANCE lpddi,
                                LPVOID pvRef)
{
    int i;
    GUID *pGuid;

    i = SendDlgItemMessage(hWndSetup, IDS_INPUT_DEVICES, 
						   CB_ADDSTRING, 0, 
						   (LPARAM) (lpddi->tszProductName));
    pGuid = new GUID(lpddi->guidInstance);
    SendDlgItemMessage(hWndSetup, IDS_INPUT_DEVICES, 
                       CB_SETITEMDATA, i, (DWORD) pGuid);
    return DIENUM_CONTINUE;   
} // DIEnumDevicesProc

void InitSetupDialog(HWND hWnd)
{ // begin InitSetupDialog()
	int i, i2, i3;
    char buff[256];
    DIDEVICEOBJECTINSTANCE didoi;

	FindConfigMode();
 	SendDlgItemMessage(hWnd, IDS_INPUT_DEVICES, CB_RESETCONTENT, 0, 0);
	lpdiKeyboard->EnumDevices( 0,  // All types.
				  DIEnumDevicesProc,
				  NULL, 
				  DIEDFL_ATTACHEDONLY );
	SendDlgItemMessage(hWnd, IDS_INPUT_DEVICES, CB_SETCURSEL, 0, 0L);
	// Action:
 	SendDlgItemMessage(hWnd, IDS_ACTION, CB_RESETCONTENT, 0, 0);
	for(i = 0; i < ASUsedKeys; i++)
   	{
		SendDlgItemMessage(hWnd, IDS_ACTION, CB_ADDSTRING, 0, (LONG) (LPSTR) ASKeyAction[i].byAction);
		SendDlgItemMessage(hWnd, IDS_ACTION, CB_SETITEMDATA, i, i);
 	}
	SendDlgItemMessage(hWnd, IDS_ACTION, CB_SETCURSEL, 0, 0);
	// Keys:
    didoi.dwSize = sizeof( didoi );
    // Insert keyboard Buttons:
	for(i = 0; i < AS_MAX_KEYBOARD_BUTTONS; i++ )
    {
		if(InputKeys[i].iCode == -1)
			continue;
		i2 = SendDlgItemMessage(hWndSetup, IDS_KEYS, 
								CB_ADDSTRING, 0, 
								(LPARAM) InputKeys[i].byName);
        SendDlgItemMessage(hWndSetup, IDS_KEYS, 
						   CB_SETITEMDATA, i, InputKeys[i].iCode);
    }
    // Insert mouse Buttons:
	for(i = 0; i < AS_MAX_MOUSE_BUTTONS; i++ )
    {
		if(InputKeys[i+AS_MAX_KEYBOARD_BUTTONS].iCode == -1)
			continue;
		i2 = SendDlgItemMessage(hWndSetup, IDS_KEYS, 
								CB_ADDSTRING, 0, 
								(LPARAM) InputKeys[i+AS_MAX_KEYBOARD_BUTTONS].byName);
        
		SendDlgItemMessage(hWndSetup, IDS_KEYS, 
						   CB_SETITEMDATA, i+AS_MAX_KEYBOARD_BUTTONS, InputKeys[i+AS_MAX_KEYBOARD_BUTTONS].iCode);
    }
	// Sound:
	if(bASSoundPossible)
		SendDlgItemMessage(hWnd, IDS_SOUND, BM_SETCHECK, Config.bSound, 0L);
	else
		SendDlgItemMessage(hWnd, IDS_SOUND, BM_SETCHECK, 0, 0L);
	SendDlgItemMessage(hWnd, IDS_MUSIC, BM_SETCHECK, Config.bMusic, 0L);
	SendDlgItemMessage(hWnd, IDS_FULLSCREEN, BM_SETCHECK, Config.bFullScreen, 0L);
	switch(Config.byLight)
	{
		case 0: CheckRadioButton(hWnd, IDS_LIGHT_NONE, IDS_LIGHT_SMOOTH, IDS_LIGHT_NONE); break;
		case 1: CheckRadioButton(hWnd, IDS_LIGHT_NONE, IDS_LIGHT_SMOOTH, IDS_LIGHT_FLAT); break;
		case 2: CheckRadioButton(hWnd, IDS_LIGHT_NONE, IDS_LIGHT_SMOOTH, IDS_LIGHT_SMOOTH); break;
	}	
	SendDlgItemMessage(hWnd, IDS_SHOW_FPS, BM_SETCHECK, Config.bShowFPS, 0L);
    // Delete all old entries:	
 	SendDlgItemMessage(hWnd, IDS_COLOR_DEPTH, CB_RESETCONTENT, 0, 0);
 	SendDlgItemMessage(hWnd, IDS_MODES, CB_RESETCONTENT, 0, 0);
	wsprintf(buff, "All");
   	SendDlgItemMessage(hWnd, IDS_COLOR_DEPTH, CB_ADDSTRING, 0, (LONG) (LPSTR) buff);
    for(i = 0; i < 4; i++)
	{
		wsprintf(buff, "%d Bit", (i+1)*8);
	   	SendDlgItemMessage(hWnd, IDS_COLOR_DEPTH, CB_ADDSTRING, 0, (LONG) (LPSTR) buff);
	}
	if(!Config.iColorDepthFilter)
		SendDlgItemMessage(hWnd, IDS_COLOR_DEPTH, CB_SETCURSEL, 0, 0L);
	else
		SendDlgItemMessage(hWnd, IDS_COLOR_DEPTH, CB_SETCURSEL, Config.iColorDepthFilter/8, 0L);
    // Put in the new entries:
    for(i = 0, i2 = 0; i < DisplayModeInfo.Number-1; i++)
	{
		if(Config.iColorDepthFilter)
		{
			if(DisplayModeInfo.pDevMode[i].dmBitsPerPel != (unsigned char) Config.iColorDepthFilter)
				continue;
		}
		wsprintf(buff, "%dx%dx%d  %d HZ", 
				DisplayModeInfo.pDevMode[i].dmPelsWidth, 
				DisplayModeInfo.pDevMode[i].dmPelsHeight, 
				DisplayModeInfo.pDevMode[i].dmBitsPerPel, 
				DisplayModeInfo.pDevMode[i].dmDisplayFrequency);
     	SendDlgItemMessage(hWnd, IDS_MODES, CB_ADDSTRING, 0, (LONG) (LPSTR) buff);
     	SendDlgItemMessage(hWnd, IDS_MODES, CB_SETITEMDATA, i2, i);
		#ifdef _DEBUG
			sprintf(byASTemp, "Insert mode(%d): %dx%dx%dx%d   to IDS_MODES\n", i, 
				DisplayModeInfo.pDevMode[i].dmPelsWidth, 
				DisplayModeInfo.pDevMode[i].dmPelsHeight, 
				DisplayModeInfo.pDevMode[i].dmBitsPerPel, 
				DisplayModeInfo.pDevMode[i].dmDisplayFrequency);
			OutputDebugString(byASTemp);
		#endif
		i2++;
	}
	if(Config.iColorDepthFilter)
	{
		if(DisplayModeInfo.pDevMode[Config.iModeIndex].dmBitsPerPel == (unsigned char) Config.iColorDepthFilter)
		{			
			for(i = 0; i < i2; i++)
			{
				i3 = SendDlgItemMessage(hWnd, IDS_MODES, CB_GETITEMDATA, i, 0);
				if(i3 == Config.iModeIndex)
					break;
			}
			SendDlgItemMessage(hWnd, IDS_MODES, CB_SETCURSEL, i, 0L);
		}
	}
	else
		SendDlgItemMessage(hWnd, IDS_MODES, CB_SETCURSEL, Config.iModeIndex, 0L);
} // end InitSetupDialog()

void OpenSetupDialog(void)
{ // begin OpenSetupDialog()
	if(Camera)
		Camera->NoVelocity();
	bProgramActive = FALSE;
	DialogBox(hInstance, MAKEINTRESOURCE(ID_SETUP), hWndMain, (DLGPROC) SetupProc);
	bProgramActive = TRUE;
} // end OpenSetupDialog()

LRESULT CALLBACK SetupProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin SetupProc()
	int i, i2, i3;

	switch(iMessage)
    {
        case WM_INITDIALOG:
			hWndSetup = hWnd;
			CopyMemory(&TempDevMode, &Config.DevMode, sizeof(DEVMODE));
		    bTempFullScreen = Config.bFullScreen;
		    bTempSound = Config.bSound;
		    bTempMusic = Config.bMusic;
		    bTempShowFPS = Config.bShowFPS;
			ShowWindow(hWnd, iCmdShow);
			UpdateWindow(hWnd);
			InitSetupDialog(hWnd);
			goto SetActionKey;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDS_ACTION:
				SetActionKey:
					i =  SendDlgItemMessage(hWndSetup, IDS_ACTION,
									        CB_GETCURSEL, 0, 0L);
					i =  SendDlgItemMessage(hWndSetup, IDS_ACTION,
									        CB_GETITEMDATA, i, 0L);
					i3 = ASKeyAction[i].iKeyCode;
					if(ASKeyAction[i].byDevice == AS_MOUSE)
						i3 += AS_MAX_KEYBOARD_BUTTONS;
					for(i2 = 0; i2 < AS_MAX_INPUT_BUTTONS; i2++)
					{
						int i4 = SendDlgItemMessage(hWndSetup, IDS_KEYS,
									                CB_GETITEMDATA, i2, 0L);
						if(i3 == i4)
						{
							SendDlgItemMessage(hWndSetup, IDS_KEYS,
											   CB_SETCURSEL, i2, 0L);
							break;
						}
					}
				break;
				
				case IDS_KEYS:
					i =  SendDlgItemMessage(hWndSetup, IDS_KEYS,
									        CB_GETCURSEL, 0, 0L);
					i2 =  SendDlgItemMessage(hWndSetup, IDS_KEYS,
									         CB_GETITEMDATA, i, 0L);
					i =  SendDlgItemMessage(hWndSetup, IDS_ACTION,
									        CB_GETCURSEL, 0, 0L);
					i =  SendDlgItemMessage(hWndSetup, IDS_ACTION,
									        CB_GETITEMDATA, i, 0L);
					if(i2 < AS_MAX_KEYBOARD_BUTTONS) {
						ASKeyAction[i].byDevice = AS_KEYBOARD;
						ASKeyAction[i].iKeyCode = i2;
					}
					else
					if(i2 < AS_MAX_KEYBOARD_BUTTONS+AS_MAX_MOUSE_BUTTONS) {
						ASKeyAction[i].byDevice = AS_MOUSE;
						ASKeyAction[i].iKeyCode = i2-AS_MAX_KEYBOARD_BUTTONS;
					}
					GetDlgItemText(hWnd, IDS_KEYS, ASKeyAction[i].byKeyName, 128);
				break;

				case IDS_FULLSCREEN:
				    Config.bFullScreen = SendDlgItemMessage(hWnd, IDS_FULLSCREEN, BM_GETCHECK, 0, 0L);
				break;

				case IDS_SOUND:
					if(!bASSoundPossible)
						SendDlgItemMessage(hWnd, IDS_SOUND, BM_SETCHECK, 0, 0L);
				    Config.bSound = SendDlgItemMessage(hWnd, IDS_SOUND, BM_GETCHECK, 0, 0L);
				break;

				case IDS_MUSIC:
				    Config.bMusic = SendDlgItemMessage(hWnd, IDS_MUSIC, BM_GETCHECK, 0, 0L);
				break;

				case IDS_SHOW_FPS:
				    Config.bShowFPS = SendDlgItemMessage(hWnd, IDS_SHOW_FPS, BM_GETCHECK, 0, 0L);
				break;

				case IDS_MODES:
   					i = SendDlgItemMessage(hWnd, IDS_MODES, CB_GETCURSEL, 0, 0L);
					i = SendDlgItemMessage(hWnd, IDS_MODES, CB_GETITEMDATA, i, 0);
					Config.iModeIndex = i;                         	
					CopyMemory(&Config.DevMode, &DisplayModeInfo.pDevMode[Config.iModeIndex], sizeof(DEVMODE));
				break;

                case IDS_COLOR_DEPTH:
				    i = SendDlgItemMessage(hWnd, IDS_COLOR_DEPTH, CB_GETCURSEL, 0, 0L);
					if(!Config.iColorDepthFilter)
					{
						if(!i)
							break;
					}
					else
						if(Config.iColorDepthFilter == i)
							break;					
					Config.iColorDepthFilter = i*8;
					InitSetupDialog(hWnd);
				break;

                case IDS_OK:
					if(!Config.bMusic)
						ASStopMidi();
					else
					{
						if(Config.bMusic && !bTempMusic)
							StartNewMidi();
					}
					if(IsDlgButtonChecked(hWnd, IDS_LIGHT_NONE))
						Config.byLight = 0;
					else
					if(IsDlgButtonChecked(hWnd, IDS_LIGHT_FLAT))
						Config.byLight = 1;
					else
					if(IsDlgButtonChecked(hWnd, IDS_LIGHT_SMOOTH))
						Config.byLight = 2;
					Config.iWindowWidth = Config.DevMode.dmPelsWidth;
					Config.iWindowHeight = Config.DevMode.dmPelsHeight;
					bNewSetting = TRUE;
					DestroyGL(GAME_NAME, &hWndMain);
					InitGL(&hWndMain, GAME_TITLE, GAME_NAME);
					bNewSetting = FALSE;
					EndDialog(hWnd, FALSE);
                return TRUE;

                case IDS_CANCEL:
					CopyMemory(&Config.DevMode, &TempDevMode, sizeof(DEVMODE));
				    Config.bFullScreen = bTempFullScreen;
				    Config.bSound = bTempSound;
				    Config.bMusic = bTempMusic;
				    Config.bShowFPS = bTempShowFPS;
					EndDialog(hWnd, FALSE);
                return TRUE;
					
                case IDS_QUIT:
                    bProgramEnd = TRUE;
					EndDialog(hWnd, FALSE);
                return TRUE;

                case IDS_ABOUT:
					OpenAboutDialog();
                return TRUE;
            }
            break;
    }
    return FALSE;
} // end SetupProc()
/*
	Intro.h

    Last change:
    	24.6.2000

    Description:
		The AblazeSpace intro.
*/

#ifndef __INTRO_H__
#define __INTRO_H__


typedef class
{
	public:
		AS_CAMERA A_Camera; // Ablaze logo
		AS_CAMERA Alzey_Camera; // Alzey

		HRESULT Load(void);
		HRESULT Destroy(void);
		void Init(void);
		void Play(void);
} INTRO;

// Functions: *****************************************************************
/*
HRESULT INTRO::Load(void);
HRESULT INTRO::Destroy(void);
void INTRO::Init(void);
void INTRO::Play(void);
*/
extern HRESULT DrawIntro(void);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern INTRO Intro;
///////////////////////////////////////////////////////////////////////////////


#endif // __INTRO_H__
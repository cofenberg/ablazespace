/*
	Game.h

    Last change:
    	24.6.2000

    Description:
		General game informations.
*/

#ifndef __GAME_H__
#define __GAME_H__


#define GAME_TITLE "Alzey 2000"
#define GAME_NAME "Alzey"
#define GAME_VERSION "1.0"
#define GAME_MUTEX_NAME "Alzey Mutex"
#define GAME_INI_FILE "Game.ini"


#endif // __GAME_H__
/*
	Actor.h

    Last change:
    	24.6.2000

    Description:
		Controls the actors.
*/

#ifndef __ACTOR_H__
#define __ACTOR_H__


typedef class ACTOR
{
	public:
		ACTOR *pAddress; 
		char byText[128];
		DWORD dwLastTime;
		int iType;
		int iID;
		int iSXPos, iSYPos; // standard Level (field) position
		int iXPos, iYPos; // Level (field) position
		float fFXPos, fFYPos; // Level (in field) position
		float fPos[3], fRot[3], fScale[3]; // (World) positions
		float fVelocity;
		char byDirection, byNextDirection;
		int iExtraPoints; // This are the points wich the player becomes
		BOOL bNoZeroCheck;
		BOOL bActive;
		BOOL bRandomStart;
		BOOL bRandomReincarnation;
		BOOL bTimeActive;
		BOOL bShowParticles;
		BOOL bLight;
		float fLightRed;
		float fLightGreen;
		float fLightBlue;
		float fLightPos[3];
		int iTimeCounter;
		int iLifes, iScore;
		AS_OBJECT *pLook;
		BOOL bAI;
		BOOL bMove;

		void Init(void);
		void Set(int, int, int, char);
		void CalculateWorldPos(void *);
		void Draw(AS_CAMERA *);
		void Check(void *, ACTOR **, int);
		void CheckTerminator(void *);
		void Move(void *, ACTOR **, int);
		HRESULT CheckBeamer(void);
		HRESULT CheckObstacle(void *);
		void FindNewWay(void *);
		void SetText(ACTOR *, char *);
		HRESULT CheckCollision(ACTOR **, int, int);
		void LoseLife(void);

} ACTOR;

#define ACTOR_VELOCITY 0.01f
#define ACTOR_DIRECTION (rand() % 4)
#define ACTOR_LOOKS 16
#define MAX_ACTORS 100

enum {ACTOR_PLAYER, ACTOR_E_FOOL, ACTOR_E_NORMAL, ACTOR_E_TERMINATOR,
	  ACTOR_P_REINCARNATION, ACTOR_E_REINCARNATION, ACTOR_DIAMOND,
	  ACTOR_FRUIT_1, ACTOR_HERO, ACTOR_BOMB, ACTOR_HOURGLASS, ACTOR_FREEZE,
	  ACTOR_GHOST, ACTOR_SPEED, ACTOR_KILL_ALL_ENEMYS, ACTOR_KILL_NO_ENEMYS, ACTOR_TEXT};
enum {ACTOR_D_LEFT, ACTOR_D_UP, ACTOR_D_RIGHT, ACTOR_D_DOWN};


// Functions: *****************************************************************
/*
void ACTOR::Init(void);
void ACTOR::Set(int, int, int, char, float);
void ACTOR::CalculateWorldPos(void *);
void ACTOR::Draw(AS_CAMERA *);
void ACTOR::Check(void *, ACTOR **, int);
void ACTOR::Move(void *, ACTOR **, int);
HRESULT ACTOR::CheckObstacle(void *);
void ACTOR::FindNewWay(void *);
void ACTOR::SetText(ACTOR *, char *);
HRESULT ACTOR::CheckCollision(ACTOR **, int, int);
*/
extern HRESULT OpenActorDialog(ACTOR *);
extern LRESULT CALLBACK ActorProc(HWND, UINT, WPARAM, LPARAM);
extern void CreateActorLookListes(void);
extern HRESULT CreateActorList(ACTOR ***, int);
extern void DestroyActorList(ACTOR ***);
extern void CheckActors(void *, ACTOR **, int);
extern void ActivateActorsLights(ACTOR **, AS_CAMERA *, int);
extern void DeactivateActorsLights(ACTOR **, int);
extern void DrawActors(ACTOR **, AS_CAMERA *, int);
extern HRESULT CreateActor(ACTOR **);
extern void DestroyActor(ACTOR **);
extern HRESULT LoadActorsLook(void);
extern void DestroyActorsLook(void);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern AS_OBJECT **pActorLook;
extern ACTOR **Actor;
extern int iActors;
extern ACTOR **TextActor;
///////////////////////////////////////////////////////////////////////////////


#endif // __ACTOR_H__
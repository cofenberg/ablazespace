/*
	Actor.cpp

    Last change:
    	24.6.2000

    Description:
		Controls the actors.
*/

#include "AS\AS_ENGINE.h"


// Functions: *****************************************************************
/*
void ACTOR::Init(void);
void ACTOR::Set(int, int, int, char, float);
void ACTOR::CalculateWorldPos(void *);
void ACTOR::Draw(AS_CAMERA *);
void ACTOR::Check(void *, ACTOR **, int);
void ACTOR::Move(void *, ACTOR **, int);
HRESULT ACTOR::CheckObstacle(void *);
void ACTOR::FindNewWay(void *);
void ACTOR::SetText(ACTOR *, char *);
HRESULT ACTOR::CheckCollision(ACTOR **, int, int);
void ACTOR::LoseLife(void);
*/
HRESULT OpenActorDialog(ACTOR *);
LRESULT CALLBACK ActorProc(HWND, UINT, WPARAM, LPARAM);
void CreateActorLookListes(void);
HRESULT CreateActorList(ACTOR ***, int);
void DestroyActorList(ACTOR ***);
void CheckActors(void *, ACTOR **, int);
void ActivateActorsLights(ACTOR **, AS_CAMERA *, int);
void DeactivateActorsLights(ACTOR **, int);
void DrawActors(ACTOR **, AS_CAMERA *, int);
HRESULT CreateActor(ACTOR **);
void DestroyActor(ACTOR **);
HRESULT LoadActorsLook(void);
void DestroyActorsLook(void);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
char cActorLookFile[ACTOR_LOOKS][100] = 
{
	"Player.wrl", 
	"E_Fool.wrl",
	"E_Normal.wrl",
	"E_Terminator.wrl",
	"P_Reincarnation.wrl",
	"E_Reincarnation.wrl",
	"Diamond.wrl",
	"Fruit1.wrl",
	"Hero.wrl",
	"Bomb.wrl",
	"Hourglass.wrl",
	"Freeze.wrl",
	"Ghost.wrl",
	"Speed.wrl",
	"Kill.wrl",
	"NoKill.wrl",
};
AS_OBJECT **pActorLook;
ACTOR **Actor;
int iActors = 0;
ACTOR **TextActor;
ACTOR *pActor;
///////////////////////////////////////////////////////////////////////////////

HRESULT OpenActorDialog(ACTOR *pTActor)
{ // begin OpenActorDialog()
	if(Camera)
		Camera->NoVelocity();
	if(!pTActor)
		return AS_ERROR_NONE;
	pActor = pTActor;
	DialogBox(hInstance, MAKEINTRESOURCE(ID_ACTOR), hWndMain, (DLGPROC) ActorProc);
	return AS_ERROR_NONE;
} // end OpenActorDialog()

LRESULT CALLBACK ActorProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{ // begin ActorProc()
	switch(message)
    {
        case WM_INITDIALOG:
			ShowWindow(hWnd, iCmdShow);
			UpdateWindow(hWnd);
           	sprintf(byASTemp, "(%d = no limit)", NO_LIMIT);
			SetDlgItemText(hWnd, ID_ACTOR_NO_LIMIT_TEXT, byASTemp);
            // Set actor type:
			switch(pActor->iType)
			{
				case ACTOR_PLAYER: SetDlgItemText(hWnd, ID_ACTOR_TYPE, "Player"); break;
				case ACTOR_E_FOOL: SetDlgItemText(hWnd, ID_ACTOR_TYPE, "Enemy: fool"); break;
				case ACTOR_E_NORMAL: SetDlgItemText(hWnd, ID_ACTOR_TYPE, "Enemy: normal"); break;
				case ACTOR_E_TERMINATOR: SetDlgItemText(hWnd, ID_ACTOR_TYPE, "Enemy: terminator"); break;
				case ACTOR_P_REINCARNATION: SetDlgItemText(hWnd, ID_ACTOR_TYPE, "Player reincarnation"); break;
				case ACTOR_E_REINCARNATION: SetDlgItemText(hWnd, ID_ACTOR_TYPE, "Enemy reincarnation"); break;
				case ACTOR_DIAMOND: SetDlgItemText(hWnd, ID_ACTOR_TYPE, "Diamond"); break;
				case ACTOR_FRUIT_1: SetDlgItemText(hWnd, ID_ACTOR_TYPE, "Fruit 1"); break;
				case ACTOR_HERO: SetDlgItemText(hWnd, ID_ACTOR_TYPE, "Hero"); break;
				case ACTOR_BOMB: SetDlgItemText(hWnd, ID_ACTOR_TYPE, "Bomb"); break;
				case ACTOR_HOURGLASS: SetDlgItemText(hWnd, ID_ACTOR_TYPE, "Hourglass"); break;
				case ACTOR_FREEZE: SetDlgItemText(hWnd, ID_ACTOR_TYPE, "Freeze"); break;
				case ACTOR_GHOST: SetDlgItemText(hWnd, ID_ACTOR_TYPE, "Ghost"); break;
				case ACTOR_SPEED: SetDlgItemText(hWnd, ID_ACTOR_TYPE, "Speed"); break;
			}
            // Lifes:
			sprintf(byASTemp, "%d", pActor->iLifes);
			SetDlgItemText(hWnd, ID_ACTOR_LIFES, byASTemp);
            // Extra Points:
			sprintf(byASTemp, "%d", pActor->iExtraPoints);
			SetDlgItemText(hWnd, ID_ACTOR_EXTRA_POINTS, byASTemp);
            // Level pos:
			sprintf(byASTemp, "%d", pActor->iXPos);
			SetDlgItemText(hWnd, ID_ACTOR_X_POS, byASTemp);
			sprintf(byASTemp, "%d", pActor->iYPos);
            SetDlgItemText(hWnd, ID_ACTOR_Y_POS, byASTemp);
            // Velocity:
			sprintf(byASTemp, "%.2f", pActor->fVelocity);
			SetDlgItemText(hWnd, ID_ACTOR_VELOCITY, byASTemp);
            // Scale:
			sprintf(byASTemp, "%.2f", pActor->fScale[X]);
			SetDlgItemText(hWnd, ID_ACTOR_SCALE_X, byASTemp);
			sprintf(byASTemp, "%.2f", pActor->fScale[Y]);
			SetDlgItemText(hWnd, ID_ACTOR_SCALE_Y, byASTemp);
			sprintf(byASTemp, "%.2f", pActor->fScale[Z]);
			SetDlgItemText(hWnd, ID_ACTOR_SCALE_Z, byASTemp);
            // AI:
			SendDlgItemMessage(hWnd, ID_ACTOR_AI, BM_SETCHECK, pActor->bAI, 0L);
            // Move:
			SendDlgItemMessage(hWnd, ID_ACTOR_MOVE, BM_SETCHECK, pActor->bMove, 0L);
            // Random start:
			SendDlgItemMessage(hWnd, ID_ACTOR_RANDOM_START, BM_SETCHECK, pActor->bRandomStart, 0L);
            // Random Reincarnation:
			SendDlgItemMessage(hWnd, ID_ACTOR_RANDOM_REINCARNATION, BM_SETCHECK, pActor->bRandomReincarnation, 0L);
            // Light:
			SendDlgItemMessage(hWnd, ID_ACTOR_LIGHT, BM_SETCHECK, pActor->bLight, 0L);
            // Light color:
			sprintf(byASTemp, "%.2f", pActor->fLightRed);
			SetDlgItemText(hWnd, ID_ACTOR_LIGHT_RED, byASTemp);
			sprintf(byASTemp, "%.2f", pActor->fLightGreen);
			SetDlgItemText(hWnd, ID_ACTOR_LIGHT_GREEN, byASTemp);
			sprintf(byASTemp, "%.2f", pActor->fLightBlue);
			SetDlgItemText(hWnd, ID_ACTOR_LIGHT_BLUE, byASTemp);
            // Light pos:
			sprintf(byASTemp, "%.2f", pActor->fLightPos[X]);
			SetDlgItemText(hWnd, ID_ACTOR_LIGHT_X_POS, byASTemp);
			sprintf(byASTemp, "%.2f", pActor->fLightPos[Y]);
			SetDlgItemText(hWnd, ID_ACTOR_LIGHT_Y_POS, byASTemp);
			sprintf(byASTemp, "%.2f", pActor->fLightPos[Z]);
			SetDlgItemText(hWnd, ID_ACTOR_LIGHT_Z_POS, byASTemp);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_ACTOR_OK:
                    // Lifes:
					GetDlgItemText(hWnd, ID_ACTOR_LIFES, byASTemp, 5);
					pActor->iLifes = atoi(byASTemp);
                    // Extra points:
					GetDlgItemText(hWnd, ID_ACTOR_EXTRA_POINTS, byASTemp, 5);
					pActor->iExtraPoints = atoi(byASTemp);
                    // Level pos:
					GetDlgItemText(hWnd, ID_ACTOR_X_POS, byASTemp, 5);
					pActor->iXPos = atoi(byASTemp);
					GetDlgItemText(hWnd, ID_ACTOR_Y_POS, byASTemp, 5);
					pActor->iYPos = atoi(byASTemp);
                    // Velocity:
					GetDlgItemText(hWnd, ID_ACTOR_VELOCITY, byASTemp, 5);
					pActor->fVelocity = (float) atof(byASTemp);
                    // Scale:
					GetDlgItemText(hWnd, ID_ACTOR_SCALE_X, byASTemp, 5);
					pActor->fScale[X] = (float) atof(byASTemp);
					GetDlgItemText(hWnd, ID_ACTOR_SCALE_Y, byASTemp, 5);
					pActor->fScale[Y] = (float) atof(byASTemp);
					GetDlgItemText(hWnd, ID_ACTOR_SCALE_Z, byASTemp, 5);
					pActor->fScale[Z] = (float) atof(byASTemp);
					// AI:
					pActor->bAI = SendDlgItemMessage(hWnd, ID_ACTOR_AI, BM_GETCHECK, 0, 0L);
					// Move:
					pActor->bMove = SendDlgItemMessage(hWnd, ID_ACTOR_MOVE, BM_GETCHECK, 0, 0L);
					// Random start:
					pActor->bRandomStart = SendDlgItemMessage(hWnd, ID_ACTOR_RANDOM_START, BM_GETCHECK, 0, 0L);
					// Random reincarnation:
					pActor->bRandomReincarnation = SendDlgItemMessage(hWnd, ID_ACTOR_RANDOM_REINCARNATION, BM_GETCHECK, 0, 0L);
					// Light:
					pActor->bLight = SendDlgItemMessage(hWnd, ID_ACTOR_LIGHT, BM_GETCHECK, 0, 0L);
                    // Light color:
					GetDlgItemText(hWnd, ID_ACTOR_LIGHT_RED, byASTemp, 5);
					pActor->fLightRed = (float) atof(byASTemp);
					GetDlgItemText(hWnd, ID_ACTOR_LIGHT_GREEN, byASTemp, 5);
					pActor->fLightGreen = (float) atof(byASTemp);
					GetDlgItemText(hWnd, ID_ACTOR_LIGHT_BLUE, byASTemp, 5);
					pActor->fLightBlue = (float) atof(byASTemp);
		           // Light pos:
					GetDlgItemText(hWnd, ID_ACTOR_LIGHT_X_POS, byASTemp, 5);
					pActor->fLightPos[X] = (float) atof(byASTemp);
					GetDlgItemText(hWnd, ID_ACTOR_LIGHT_Y_POS, byASTemp, 5);
					pActor->fLightPos[Y] = (float) atof(byASTemp);
					GetDlgItemText(hWnd, ID_ACTOR_LIGHT_Z_POS, byASTemp, 5);
					pActor->fLightPos[Z] = (float) atof(byASTemp);
					EndDialog(hWnd, FALSE);
                return TRUE;

				case ID_ACTOR_CANCEL: EndDialog(hWnd, FALSE); return TRUE;
            }
        break;
    }
    return FALSE; 
} // end ActorProc()

void CreateActorLookListes(void)
{ // begin CreateActorLookListes()
	if(!pActorLook)
		return;
	for(int i = 0; i < ACTOR_LOOKS; i++)
	{
		if(!pActorLook[i])
			continue;
		pActorLook[i]->CreateList();
	}
} // end CreateActorLookListes()

HRESULT CreateActorList(ACTOR ***pActor, int iMaxActors)
{ // begin CreateActorList()
	if(!iMaxActors)
		return AS_ERROR_NONE;
	if(*pActor)
		DestroyActorList(pActor);
	iActors = iMaxActors;
	*pActor = (ACTOR **) calloc(iActors, sizeof(ACTOR *));
	return AS_ERROR_NONE;
} // end CreateActorList()

void DestroyActorList(ACTOR ***pActor)
{ // begin DestroyActorList()
	if(!iActors)
		return;
	if(*pActor)
		for(int i = 0; i < iActors; i++)
		{
			if(!(*pActor)[i])
				continue;
			DestroyActor(&(*pActor)[i]);
		}
	*pActor = NULL;
	iActors = 0;
	return;
} // end DestroyActorList()

void CheckActors(void *pVLevel, ACTOR **pActor, int iMaxActors)
{ // begin CheckActors()
	LEVEL *pLevel = (LEVEL *) pVLevel;
	int i, i2, x, y;

	if(!pActor)
		return;
	for(i = 0; i < iActors; i++)
	{
		if(!pActor[i])
			continue;
		if(!pActor[i]->bActive)
		{
			for(i2 = 0; i2 < iActors; i2++)
			{
				if(!pActor[i2])
					continue;
				if(pActor[i]->iXPos == pActor[i2]->iXPos &&
				   pActor[i]->iYPos == pActor[i2]->iYPos)
					continue;
				switch(pActor[i]->iType)
				{
					case ACTOR_FRUIT_1: 
						if((rand() % 1500000) != 50)
							continue;
						goto DoIt;

					case ACTOR_HERO: 
						if((rand() % 700000) != 51)
							continue;
						goto DoIt;
					
					case ACTOR_BOMB: 
						if((rand() % 3000000) != 52)
							continue;
						goto DoIt;
					
					case ACTOR_HOURGLASS:
						if((rand() % 1000000) != 53)
							continue;
						goto DoIt;

					case ACTOR_FREEZE: 
						if((rand() % 1500000) != 54)
							continue;
						goto DoIt;

					case ACTOR_GHOST: 
						if((rand() % 1500000) != 55)
							continue;
						goto DoIt;

					case ACTOR_SPEED:
						if((rand() % 1000000) != 56)
							continue;
					DoIt:
						if(pActor[i]->iLifes == -1)
							break;						
						if(pActor[i]->bRandomReincarnation)
						{
							x = rand() % pLevel->iWidth;
							y = rand() % pLevel->iHeight;
						}
						else
						{
							x = pActor[i]->iSXPos;
							y = pActor[i]->iSYPos;
						}
						pActor[i]->iXPos = x;
						pActor[i]->iYPos = y;
						pActor[i]->fFXPos = 0.0f;
						pActor[i]->fFYPos = 0.0f;
						if(pLevel->CheckWallSurround(pActor[i]->iXPos, pActor[i]->iYPos))
							continue;						
						for(i2 = 0; i2 < iActors; i2++)
						{
							if(!Actor[i2] || !Actor[i2]->bActive)
								continue;
							if(Actor[i2]->iXPos == Actor[i]->iXPos &&
							   Actor[i2]->iYPos == Actor[i]->iYPos &&
							   Actor[i2]->iType == ACTOR_E_REINCARNATION)
								goto Next;
						}
						pActor[i]->bActive = TRUE;
					break;
					
					default: 
						Next:
						continue;
				}
			}
		}
		pActor[i]->Check(pLevel, pActor, iMaxActors);
	}
} // end CheckActors()

void ActivateActorsLights(ACTOR **pActor, AS_CAMERA *pCamera, int iMaxActors)
{ // begin ActivateActorsLights()
	int iLightCounter = 0;
	GLfloat afLightData[4]  = {0.0f, 0.0f, 0.0f, 0.0f};

	if(!pActor || !pCamera || !Config.byLight)
		return;
	Camera->SetScene();
	for(int i = 0; i < iMaxActors; i++)
	{
		if(!pActor[i] || !pActor[i]->bActive  || !pActor[i]->bLight || pActor[i]->bTimeActive)
			continue;
		// Set up the light:
		glDisable(GL_LIGHT2+iLightCounter);
		afLightData[0] = pActor[i]->fPos[X]+pActor[i]->fLightPos[X];
		afLightData[1] = pActor[i]->fPos[Y]+pActor[i]->fLightPos[Y];
		afLightData[2] = pActor[i]->fPos[Z]+pActor[i]->fLightPos[Z];
		afLightData[3] = 1.0f;
		glLightfv(GL_LIGHT2+iLightCounter, GL_POSITION, afLightData);
		afLightData[0] = pActor[i]->fLightRed;
		afLightData[1] = pActor[i]->fLightGreen;
		afLightData[2] = pActor[i]->fLightBlue;
		afLightData[3] = 1.0f;
		glLightfv(GL_LIGHT2+iLightCounter, GL_DIFFUSE, afLightData);
		glEnable(GL_LIGHT2+iLightCounter);
		iLightCounter++;
	}
} // end ActivateActorsLights()

void DeactivateActorsLights(ACTOR **pActor, int iMaxActors)
{ // begin DectivateActorsLights()
	int iLightCounter = 0;

	if(!pActor || !Config.byLight)
		return;
	for(int i = 0; i < iMaxActors; i++)
	{
		if(!pActor[i] || !pActor[i]->bActive  || !pActor[i]->bLight)
			continue;
		// Deactivate the light:
		glDisable(GL_LIGHT2+iLightCounter);
		iLightCounter++;
	}
} // end DectivateActorsLights()

void DrawActors(ACTOR **pActor, AS_CAMERA *Camera, int iMaxActors)
{ // begin DrawActors()
	int	iLightIdx = 0;
	int iLightCount = 0;
	GLfloat afLightData[4]  = {0.0f, 0.0f, 0.0f, 0.0f};

	if(!pActor)
		return;
	for(int i = 0; i < iMaxActors; i++)
	{
		if(!pActor[i] || !pActor[i]->bActive)
			continue;
		pActor[i]->Draw(Camera);
	}
} // end DrawActors()

HRESULT CreateActor(ACTOR **pActor)
{ // begin CreateActor()	
	if(*pActor)
		DestroyActor(pActor);
	(*pActor) = (ACTOR *) calloc(1, sizeof(ACTOR));
	(*pActor)->pAddress = *pActor;
	(*pActor)->Init();
    return AS_ERROR_NONE;
} // end CreateActor()

void DestroyActor(ACTOR **pActor)
{ // begin ASDestroyCamera()
	if(!pActor)
		return;
	if(*pActor)
		free(*pActor);
	*pActor = NULL;
} // end DestroyActor()

HRESULT LoadActorsLook(void)
{ // begin LoadActorsLook()
	if(pActorLook)	
		return AS_ERROR_NONE; // There looks are already loaded
	pActorLook = (AS_OBJECT **) calloc(ACTOR_LOOKS, sizeof(AS_OBJECT));
	for(int i = 0; i < ACTOR_LOOKS; i++)
	{
		CreateObject(&pActorLook[i]);
		sprintf(byASTemp, "%s\\%s\\%s", byASProgramPath, byASObjectsFile, cActorLookFile[i]);
		pActorLook[i]->Load(byASTemp);
	}
	CreateActorLookListes();
	return AS_ERROR_NONE;
} // end LoadActorsLook()

void DestroyActorsLook(void)
{ // begin DestroyActorsLook()
	if(!pActorLook)
		return;
	for(int i = 0; i < ACTOR_LOOKS; i++)
	{
		if(!pActorLook[i])
			continue;
		DestroyObject(&pActorLook[i]);
	}
	free(pActorLook);
	pActorLook = NULL;
	return;
} // end DestroyActorsLook()


// Class functions:
void ACTOR::Init(void)
{ // begin ACTOR::Init()
	int i;
	
	for(i = 0; i < 3; i++)
	{
		fPos[i] = 0.0f;
		fRot[i] = 0.0f;
		fScale[i] = 1.0f;
		fLightPos[i] = 0.0f;
	}
	fVelocity = 0.0f;
	byDirection = ACTOR_DIRECTION;
	bActive = FALSE;
	iScore = 0;
	iExtraPoints = 0;
	bRandomStart = FALSE;
	bRandomReincarnation = FALSE;
	iXPos = 0;
	iYPos = 0;
	fFXPos = 0.0f;
	fFYPos = 0.0f;
	bAI = FALSE;
	bMove = FALSE;
	bTimeActive = FALSE;
	bLight = FALSE;
	fLightRed = 0.0f;
	fLightGreen = 0.0f;
	fLightBlue = 0.0f;
	bShowParticles = TRUE;
	iLifes = NO_LIMIT;
	bNoZeroCheck = FALSE;
	for(i = 0; i < 3; i++)
		fScale[i] = 1.0f;
} // end ACTOR::Init()

void ACTOR::Set(int iSetType, int iSetXPos, int iSetYPos, char bySetDirection)
{ // begin ACTOR::Set()
	Init();
	bActive = TRUE;
	iType = iSetType;
	iXPos = iSetXPos;
	iYPos = iSetYPos;
	byDirection = bySetDirection;
	switch(iType)
	{
		case ACTOR_PLAYER:
			fVelocity = PLAYER_S_VELOCITY;
			bMove = TRUE;
			iLifes = PLAYER_S_LIFES;
			bRandomReincarnation = TRUE;
		break;

		case ACTOR_E_FOOL:
			fVelocity = E_FOOL_S_VELOCITY;
			bAI = TRUE;
			bMove = TRUE;
			iExtraPoints = E_FOOL_POINTS;
		break;

		case ACTOR_E_NORMAL:
			fVelocity = E_NORMAL_S_VELOCITY;
			bAI = TRUE;
			bMove = TRUE;
			iExtraPoints = E_NORMAL_POINTS;
		break;

		case ACTOR_E_TERMINATOR:
			fVelocity = E_TERMINATOR_S_VELOCITY;
			bAI = TRUE;
			bMove = TRUE;
			iExtraPoints = E_TERMINATOR_POINTS;
		break;

		case ACTOR_P_REINCARNATION:
			fVelocity = 0.0f;
		break;

		case ACTOR_E_REINCARNATION:
			fVelocity = 0.0f;
		break;

		case ACTOR_DIAMOND:
			fVelocity = 0.0f;
			iExtraPoints = DIAMOND_POINTS;
		break;

		case ACTOR_FRUIT_1:
			fVelocity = FRUIT_1_S_VELOCITY;
			bAI = TRUE;
			bMove = TRUE;
			iExtraPoints = FRUIT_1_POINTS;
		break;

		case ACTOR_HERO:
			fVelocity = 0.0f;
			iExtraPoints = HERO_POINTS;
		break;

		case ACTOR_BOMB:
			fVelocity = BOMB_S_VELOCITY;
			bAI = TRUE;
			bMove = TRUE;
			iExtraPoints = BOMB_POINTS;
		break;

		case ACTOR_HOURGLASS:
			fVelocity = HOURGLASS_S_VELOCITY;
			bAI = TRUE;
			bMove = TRUE;
			iExtraPoints = HOURGLASS_POINTS;
		break;

		case ACTOR_FREEZE:
			fVelocity = FREEZE_S_VELOCITY;
			bAI = TRUE;
			bMove = TRUE;
			iExtraPoints = FREEZE_POINTS;
		break;

		case ACTOR_GHOST:
			fVelocity = GHOST_S_VELOCITY;
			bAI = TRUE;
			bMove = TRUE;
			iExtraPoints = GHOST_POINTS;
		break;

		case ACTOR_SPEED:
			fVelocity = SPEED_S_VELOCITY;
			bAI = TRUE;
			bMove = TRUE;
			iExtraPoints = SPEED_POINTS;
		break;

		case ACTOR_TEXT:
			fVelocity = TEXT_S_VELOCITY;
		break;
	}
	// Duplicate the actor look:
	pLook = pActorLook[iType];
} // end ACTOR::Set()

void ACTOR::CalculateWorldPos(void *pVLevel)
{ // begin ACTOR::CalculateWorldPos()
	LEVEL *pLevel = (LEVEL *) pVLevel;

	fPos[X] = iXPos*pLevel->fFieldWidth+fFXPos;
	fPos[Y] = iYPos*pLevel->fFieldHeight+fFYPos;
	// Center the actor:
	fPos[X] += pLevel->fFieldWidth/2;
	fPos[Y] += pLevel->fFieldHeight/2;
	if(!pLook)
		fPos[Z] += 0.0f;
	else
		fPos[Z] = pLook->fBoundMin[Z]*fScale[Z];
} // end ACTOR::CalculateWorldPos()

void ACTOR::Draw(AS_CAMERA *Camera)
{ // begin ACTOR::Draw()
	float fTPos[3], fTRot[3], fTScale[3];
	int i;

	if(iType == ACTOR_TEXT)
	{
		Camera->SetScene();
		glDisable(GL_DEPTH_TEST);
		glEnable(GL_BLEND);
		glDisable(GL_LIGHTING);
		glColor4ub(255,255,255,255);
		glRotatef(180, 1.0f, 0.0f, 0.0f);
		FontBPrint(0, -fPos[Z], fPos[X], -fPos[Y], byText);
		return;
	}
	if(!pLook)
		return;
	pLook->bShowParticles = bShowParticles;
	for(i = 0; i < 3; i++)
	{
		fTPos[i] = pLook->fPos[i];
		fTRot[i] = pLook->fRot[i];
		fTScale[i] = pLook->fScale[i];
	}
	pLook->fPos[X] = fPos[X];
	pLook->fPos[Y] = fPos[Y];
	pLook->fPos[Z] = fPos[Z];
	pLook->fRot[X] = fRot[X];
	pLook->fRot[Y] = fRot[Y];
	pLook->fRot[Z] = fRot[Z];
	pLook->fScale[X] = fScale[X];
	pLook->fScale[Y] = fScale[Y];
	pLook->fScale[Z] = fScale[Z];

	if(iType == ACTOR_PLAYER && bGhost)
	{
		glEnable(GL_BLEND);
		DrawObject(pLook, Camera, 1.0f-1.0f*((float) iGhostTime/S_GHOST_TIME));
		glDisable(GL_BLEND);
	}
	else
	{
		glDisable(GL_BLEND);
		DrawObject(pLook, Camera, 1.0f);
	}
	for(i = 0; i < 3; i++)
	{
		pLook->fPos[i] = fTPos[i];
		pLook->fRot[i] = fTRot[i];
		pLook->fScale[i] = fTScale[i];
	}
} // end ACTOR::Draw()

void ACTOR::Check(void *pLevel, ACTOR **pActor, int iMaxActors)
{ // begin ACTOR::Check()
	DWORD dwTimeDifference, dwNewTime;
	
	dwNewTime = GetTickCount();
	dwTimeDifference = dwNewTime-dwLastTime;
	if(bTimeActive)
	{ // The actor isn't active for a time periode:
		if(dwTimeDifference > 100)
		{
			dwLastTime = dwNewTime;
			iTimeCounter--;
		}
		bShowParticles = FALSE;
		if(iTimeCounter < -1)
		{
			bTimeActive = FALSE;
			bShowParticles = TRUE;
		}
	}
	else
		bShowParticles = TRUE;
	if(pLook)
		pLook->Check();
	Move((LEVEL *) pLevel, pActor, iMaxActors);
	CalculateWorldPos(pLevel);
} // end ACTOR::Check()

void ACTOR::CheckTerminator(void *pVLevel)
{ // begin ACTOR::CheckTerminator()
	LEVEL *pLevel = (LEVEL *) pVLevel;
	int i, i2;
	
	if(iType != ACTOR_E_TERMINATOR)
		return;
	// This is a TERMINATOR and he try to find the player(s):
	// Check horizontal and vertical view fields:
	// Look left:
	for(i = iXPos; i > -1; i--)
	{
		if(pLevel->Field[i][iYPos].Wall[LEFT])
			break;
		// Check the actors on this field
		for(i2 = 0; i2 < iActors; i2++)
		{
			if(!Actor[i2] || !Actor[i2]->bActive || Actor[i2]->iType != ACTOR_PLAYER)
				continue;
			if(Actor[i2]->iXPos != i || Actor[i2]->iYPos != iYPos)
				continue;
			// Yeah! The player is found:
			byNextDirection = ACTOR_D_LEFT;
			fVelocity = E_TERMINATOR_FOUND_VELOCITY;
			return;
		}
	}
	// Look up:
	for(i = iYPos; i > -1; i--)
	{
		if(pLevel->Field[iXPos][i].Wall[TOP])
			break;
		// Check the actors on this field
		for(i2 = 0; i2 < iActors; i2++)
		{
			if(!Actor[i2] || !Actor[i2]->bActive || Actor[i2]->iType != ACTOR_PLAYER)
				continue;
			if(Actor[i2]->iXPos != iXPos || Actor[i2]->iYPos != i)
				continue;
			// Yeah! The player is found:
			byNextDirection = ACTOR_D_UP;
			fVelocity = E_TERMINATOR_FOUND_VELOCITY;
			return;
		}
	}
	// Look right:
	for(i = iXPos; i < Level->iWidth; i++)
	{
		if(pLevel->Field[i][iYPos].Wall[RIGHT])
			break;
		// Check the actors on this field
		for(i2 = 0; i2 < iActors; i2++)
		{
			if(!Actor[i2] || !Actor[i2]->bActive || Actor[i2]->iType != ACTOR_PLAYER)
				continue;
			if(Actor[i2]->iXPos != i || Actor[i2]->iYPos != iYPos)
				continue;
			// Yeah! The player is found:
			byNextDirection = ACTOR_D_RIGHT;
			fVelocity = E_TERMINATOR_FOUND_VELOCITY;
			return;
		}
	}
	// Look down:
	for(i = iYPos; i < Level->iHeight; i++)
	{
		if(pLevel->Field[iXPos][i].Wall[BOTTOM])
			break;
		// Check the actors on this field
		for(i2 = 0; i2 < iActors; i2++)
		{
			if(!Actor[i2] || !Actor[i2]->bActive || Actor[i2]->iType != ACTOR_PLAYER)
				continue;
			if(Actor[i2]->iXPos != iXPos || Actor[i2]->iYPos != i)
				continue;
			// Yeah! The player is found:
			byNextDirection = ACTOR_D_DOWN;
			fVelocity = E_TERMINATOR_FOUND_VELOCITY;
			return;
		}
	}
	// He haven't found the player, so he walks normality:
	fVelocity = E_TERMINATOR_S_VELOCITY;
} // end ACTOR::CheckTerminator()

void ACTOR::Move(void *pVLevel, ACTOR **pActor, int iMaxActors)
{ // begin ACTOR::Move()
	LEVEL *pLevel = (LEVEL *) pVLevel;
	int i = -1;

	if(!bActive)
		return;
	if(iType == ACTOR_TEXT)
	{
		fPos[Z] -= fVelocity*fASDeltaT;
		if(fPos[Z] < -5.0f)
			bActive = FALSE;
	}
	if(iType == ACTOR_DIAMOND || iType == ACTOR_HERO || iType == ACTOR_HOURGLASS ||
	    iType == ACTOR_FREEZE || iType == ACTOR_GHOST || iType == ACTOR_BOMB)
	{
		fRot[Y] += 2.0f*fASDeltaT;
		fRot[X] += 3.0f*fASDeltaT;
	}
	if(!bMove)
		return;
	if(bFreeze && iType != ACTOR_PLAYER)
		return;
	if(byNextDirection == -1)
		FindNewWay((LEVEL *) pLevel);
	switch(byDirection)
	{
		case ACTOR_D_LEFT:
			CheckTerminator((LEVEL *) pLevel);
			if(byNextDirection == ACTOR_D_RIGHT)
			{
				byDirection = byNextDirection;
				bNoZeroCheck = TRUE;
			}
			fRot[Z] = 0;
			if(fFXPos-(fVelocity/100)*lASDeltaT < 0.0f)
			{ 				
				if(!bNoZeroCheck && fFXPos != 0.0f)
				{
					fFXPos = 0.0f;
					break;
				}
				bNoZeroCheck = FALSE;
				if(CheckBeamer())
					break; // The actor beams
				if(iXPos-1 < 0 || pLevel->Field[iXPos][iYPos].Wall[LEFT] ||
				   (i = CheckObstacle(pVLevel)))
				{ 
					fFXPos = 0.0f;
					FindNewWay((LEVEL *) pLevel);
					byDirection = byNextDirection;
					break;
				}
				if(iType == ACTOR_E_FOOL)
				{				
					if(rand() % 2 == 0)
						byNextDirection = rand() % 4;
				}
				if(byDirection != byNextDirection)
				{
					byDirection = byNextDirection;
					fFXPos = 0.0f;
					break;				
				}
				fFXPos += pLevel->fFieldWidth;
				iXPos--;
			}
			fFXPos -= (fVelocity/100)*lASDeltaT;
			CheckCollision(pActor, 0, iMaxActors);
		break;

		case ACTOR_D_UP:
			CheckTerminator((LEVEL *) pLevel);
			if(byNextDirection == ACTOR_D_DOWN)
			{
				byDirection = byNextDirection;
				bNoZeroCheck = TRUE;
			}
			fRot[Z] = 90;
			if(fFYPos-(fVelocity/100)*lASDeltaT < 0.0f)
			{ 
				if(!bNoZeroCheck && fFYPos != 0.0f)
				{
					fFYPos = 0.0f;
					break;
				}
				bNoZeroCheck = FALSE;
				if(CheckBeamer())
					break; // The actor beams
				if(iYPos-1 < 0 || pLevel->Field[iXPos][iYPos].Wall[TOP] ||
				   (i = CheckObstacle(pVLevel)))
				{ 
					fFYPos = 0.0f;
					FindNewWay((LEVEL *) pLevel);
					byDirection = byNextDirection;
					break;
				}
				if(iType == ACTOR_E_FOOL)
				{
					if(rand() % 2 == 0)
						byNextDirection = rand() % 4;
				}
				if(byDirection != byNextDirection)
				{
					byDirection = byNextDirection;
					fFXPos = 0.0f;
					break;				
				}
				fFYPos += pLevel->fFieldHeight;
				iYPos--;
			}
			fFYPos -= (fVelocity/100)*lASDeltaT;
			CheckCollision(pActor, 0, iMaxActors);
		break;

		case ACTOR_D_RIGHT:
			CheckTerminator((LEVEL *) pLevel);
			if(byNextDirection == ACTOR_D_LEFT)
			{
				byDirection = byNextDirection;
				bNoZeroCheck = TRUE;
			}
			fRot[Z] = 180;
			if(fFXPos+(fVelocity/100)*lASDeltaT >= 0.0f)
			{ 
				if(!bNoZeroCheck && fFXPos != 0.0f)
				{
					fFXPos = 0.0f;
					break;
				}
				bNoZeroCheck = FALSE;
				if(CheckBeamer())
					break; // The actor beams
				if(iXPos+1 > pLevel->iWidth-1 || pLevel->Field[iXPos][iYPos].Wall[RIGHT] ||
				   (i = CheckObstacle(pVLevel)))
				{ 
					fFXPos = 0.0f;
					FindNewWay((LEVEL *) pLevel);
					byDirection = byNextDirection;
					break;
				}
				if(iType == ACTOR_E_FOOL)
				{
					if(rand() % 2 == 0)
						byNextDirection = rand() % 4;
				}
				if(byDirection != byNextDirection)
				{
					byDirection = byNextDirection;
					fFXPos = 0.0f;
					break;				
				}
				fFXPos -= pLevel->fFieldWidth;
				iXPos++;
			}
			fFXPos += (fVelocity/100)*lASDeltaT;
			CheckCollision(pActor, 0, iMaxActors);
		break;

		case ACTOR_D_DOWN:
			CheckTerminator((LEVEL *) pLevel);
			if(byNextDirection == ACTOR_D_UP)
			{
				byDirection = byNextDirection;
				bNoZeroCheck = TRUE;
			}
			fRot[Z] = -90;
			if(fFYPos+(fVelocity/100)*lASDeltaT >= 0.0f)
			{ 
				if(!bNoZeroCheck && fFYPos != 0.0f)
				{
					fFYPos = 0.0f;
					break;
				}
				bNoZeroCheck = FALSE;
				if(CheckBeamer())
					break; // The actor beams
				if(iYPos+1 > pLevel->iHeight-1 || pLevel->Field[iXPos][iYPos].Wall[BOTTOM] ||
				   (i = CheckObstacle(pVLevel)))

				{ 
					fFYPos = 0.0f;
					FindNewWay((LEVEL *) pLevel);
					byDirection = byNextDirection;
					break;
				}
				if(iType == ACTOR_E_FOOL)
				{
					if(rand() % 2 == 0)
						byNextDirection = rand() % 4;
				}
				if(byDirection != byNextDirection)
				{
					byDirection = byNextDirection;
					fFXPos = 0.0f;
					break;				
				}
				fFYPos -= pLevel->fFieldHeight; 
				iYPos++;
			}
			fFYPos += (fVelocity/100)*lASDeltaT;
			CheckCollision(pActor, 0, iMaxActors);
		break;
	}
} // end ACTOR::Move()

HRESULT ACTOR::CheckBeamer(void)
{ // begin ACTOR::CheckBeamer()
	int i, i2, i3, iBeamer;

	if(iType == ACTOR_PLAYER)
		iBeamer = ACTOR_P_REINCARNATION;
	else
	if(iType == ACTOR_E_FOOL ||
	   iType == ACTOR_E_NORMAL ||
	   iType == ACTOR_E_TERMINATOR)
		iBeamer = ACTOR_E_REINCARNATION;
	else
		return AS_ERROR_NONE;
	for(i = 0; i < iActors; i++)
	{
		if(!Actor[i] || !Actor[i]->bActive ||
		   Actor[i]->iType != iBeamer ||
		   Actor[i]->bTimeActive)
			continue;
		if(iXPos == Actor[i]->iXPos && iYPos == Actor[i]->iYPos)
		{ // The actor is in a beamer:
			// Find an other beamer:
			i2 = rand() % iActors;
			for(i3 = 0; i3 < iActors; i2++, i3++)
			{
				if(i2 >= iActors)
					i2 = 0;
				if(!Actor[i2] || !Actor[i2]->bActive ||
				   Actor[i2]->iType != iBeamer ||
				   Actor[i2]->iID == Actor[i]->iID ||
				   Actor[i2]->bTimeActive)
					continue;
				// The actor could beam:
				iXPos = Actor[i2]->iXPos;
				iYPos = Actor[i2]->iYPos;
				// Deactivate both beamer for a few seconds:
				Actor[i]->bTimeActive = Actor[i2]->bTimeActive = TRUE;
				Actor[i]->iTimeCounter = Actor[i2]->iTimeCounter = BEAMER_DEACTIVATING_TIME+(rand() % 5);
				DSUtil_PlaySound(pBeamerSound, 0); 
				return TRUE;
			}
		}
	}
	return AS_ERROR_NONE;
} // end ACTOR::CheckBeamer()

HRESULT ACTOR::CheckObstacle(void *pVLevel)
{ // begin ACTOR::CheckObstacle()
	int i;
	
	for(i = 0; i < iActors; i++)
	{
		if(!Actor[i] || !Actor[i]->bActive)
			continue;
		if(iType == ACTOR_PLAYER)
		{ // The player couln'd walk thought the enemys reincarnation place:
			if(Actor[i]->iType != ACTOR_E_REINCARNATION)
				continue;
		}
		else
		{
			if(iType == ACTOR_E_TERMINATOR)
			{
				if(fVelocity == E_TERMINATOR_FOUND_VELOCITY)
				{ // The terminator has found the player, no could him stop...
					if(Actor[i]->iType != ACTOR_P_REINCARNATION)
						continue;
				}
				else
				{
					if(rand() % 10 == 1)
					{ // If he is surrounded with objects:
						if(Actor[i]->iType != ACTOR_P_REINCARNATION)
							continue;
					}
					else
					{
						if(Actor[i]->iType != ACTOR_P_REINCARNATION &&
						   Actor[i]->iType != ACTOR_DIAMOND &&
						   Actor[i]->iType != ACTOR_HERO)
							continue;
					}
				}
			}
			else
				if(Actor[i]->iType != ACTOR_P_REINCARNATION)
					continue;
		}
		switch(byNextDirection)
		{
			case ACTOR_D_LEFT: 
				if(Actor[i]->iXPos == iXPos-1 && Actor[i]->iYPos == iYPos)
					return Actor[i]->iType; // There is an obstacle
			break;

			case ACTOR_D_UP: 
				if(Actor[i]->iXPos == iXPos && Actor[i]->iYPos == iYPos-1)
					return Actor[i]->iType; // There is an obstacle
			break;

			case ACTOR_D_RIGHT: 
				if(Actor[i]->iXPos == iXPos+1 && Actor[i]->iYPos == iYPos)
					return Actor[i]->iType; // There is an obstacle
			break;

			case ACTOR_D_DOWN: 
				if(Actor[i]->iXPos == iXPos && Actor[i]->iYPos == iYPos+1)
					return Actor[i]->iType; // There is an obstacle
			break;
		}
	}
	return FALSE; // There was no obstacle
} // end ACTOR::CheckObstacle()

void ACTOR::FindNewWay(void *pVLevel)
{ // begin ACTOR::FindNewWay()
	LEVEL *pLevel = (LEVEL *) pVLevel;
	int i2;
	char byTempDirection = -1;

	if(!bAI)
		return;
	for(int i = 0; i < 20; i++)
	{
		byNextDirection = rand() % 4;
		if(!pLevel->Field[iXPos][iYPos].Wall[byNextDirection])
		{ // Is there the player reincarnation?
			i2 = CheckObstacle(pVLevel);
			if(i2 == ACTOR_P_REINCARNATION)
				continue;
			byTempDirection = byNextDirection;
			if(i2)
				continue;
			break;
		}
	}
	if(byTempDirection != -1)
		byDirection = byTempDirection;
	CheckTerminator((LEVEL *) pLevel);
} // end ACTOR::FindNewWay()

void ACTOR::SetText(ACTOR *pActor, char *pbyText)
{ // begin ACTOR::SetText()
	bActive = TRUE;
	iType = ACTOR_TEXT;
	iXPos = pActor->iXPos;
	iYPos = pActor->iYPos;
	fPos[Z] = pActor->fPos[Z];
	fFXPos = pActor->fFXPos-1.0f;
	fFYPos = pActor->fFYPos+0.5f;
	strcpy(byText, pbyText);
	fVelocity = TEXT_S_VELOCITY;
} // end ACTOR::SetText()

// A cheap collision detection routine, but we didn't need more for this game :-)
HRESULT ACTOR::CheckCollision(ACTOR **pActor, int iStartActor, int iEndActor)
{ // begin ACTOR::CheckCollision()
	int i, i2;
	float fXMin, fXMax, fYMin, fYMax;
	float fXMinT, fXMaxT, fYMinT, fYMaxT;
	ACTOR *pPlayerActor, *pOther;
	float fTBoundMin[3], fTBoundMax[3];
	float fTBoundMin2[3], fTBoundMax2[3];

	if(!pActor || !pLook)
		return AS_ERROR_NONE;

	for(i = 0; i < 3; i++)
	{
		fTBoundMin[i] = pLook->fBoundMin[i];
		fTBoundMax[i] = pLook->fBoundMax[i];
		pLook->fBoundMin[i] *= fScale[i];
		pLook->fBoundMax[i] *= fScale[i];
	}
	fXMin = fPos[X]+pLook->fBoundMin[X];
	fXMax = fPos[X]+pLook->fBoundMax[X];
	fYMin = fPos[Y]+pLook->fBoundMin[Y];
	fYMax = fPos[Y]+pLook->fBoundMax[Y];

	for(i = iStartActor; i < iEndActor; i++)
	{
		if(!pActor[i] || !pActor[i]->bActive || pAddress == pActor[i]->pAddress)
			continue; // The actor couldn't collide with it self!
		// We only check 2 dimensions more isn't needn't for this game!
		for(i2 = 0; i2 < 3; i2++)
		{
			fTBoundMin2[i2] = pActor[i]->pLook->fBoundMin[i2];
			fTBoundMax2[i2] = pActor[i]->pLook->fBoundMax[i2];
			pActor[i]->pLook->fBoundMin[i2] *= pActor[i]->fScale[i2];
			pActor[i]->pLook->fBoundMax[i2] *= pActor[i]->fScale[i2];
		}
		fXMinT = pActor[i]->fPos[X]+pActor[i]->pLook->fBoundMin[X];
		fXMaxT = pActor[i]->fPos[X]+pActor[i]->pLook->fBoundMax[X];
		fYMinT = pActor[i]->fPos[Y]+pActor[i]->pLook->fBoundMin[Y];
		fYMaxT = pActor[i]->fPos[Y]+pActor[i]->pLook->fBoundMax[Y];
		if(fXMax < fXMinT || fXMin > fXMaxT ||
		   fYMax < fYMinT || fYMin > fYMaxT)
			goto Next;
		{ // We have a collision!
			if(pActor[i]->iType == ACTOR_PLAYER)
			{
				pPlayerActor = pActor[i];
				pOther = pAddress;
			}
			else
			{
				if(iType != ACTOR_PLAYER)
					goto Next;
				pPlayerActor = pAddress;
				pOther = pActor[i];
			}
			if(!pOther->bActive || !pPlayerActor->bActive)
				goto Next;
			if(bGhost == TRUE)
				goto Next; // The player i an ghost and can't collide with something (only with walls)
			switch(pOther->iType)
			{
				case ACTOR_E_FOOL:
					if(!bHero)
					{
						pPlayerActor->bActive = FALSE;
						pPlayerActor->LoseLife();
					}
					else
					{
						pPlayerActor->iScore += pOther->iExtraPoints;
						sprintf(byASTemp, "%d", pOther->iExtraPoints);
						TextActor[pOther->iID]->SetText(pOther, byASTemp);
						pOther->bActive = FALSE;
						pOther->LoseLife();
						iKilledEnemys++;
						DSUtil_PlaySound(pEnemyDeadSound, 0);
					}
				break;

				case ACTOR_E_NORMAL:
					if(!bHero)
					{
						pPlayerActor->bActive = FALSE;
						pPlayerActor->LoseLife();
					}
					else
					{
						pPlayerActor->iScore += pOther->iExtraPoints;
						sprintf(byASTemp, "%d", pOther->iExtraPoints);
						TextActor[pOther->iID]->SetText(pOther, byASTemp);
						pOther->bActive = FALSE;
						pOther->LoseLife();
						iKilledEnemys++;
						DSUtil_PlaySound(pEnemyDeadSound, 0);
					}
				break;

				case ACTOR_E_TERMINATOR:
					if(!bHero)
					{
						pPlayerActor->bActive = FALSE;
						pPlayerActor->LoseLife();
					}
					else
					{
						pPlayerActor->iScore += pOther->iExtraPoints;
						sprintf(byASTemp, "%d", pOther->iExtraPoints);
						TextActor[pOther->iID]->SetText(pOther, byASTemp);
						pOther->bActive = FALSE;
						pOther->LoseLife();
						iKilledEnemys++;
						DSUtil_PlaySound(pEnemyDeadSound, 0);
					}
				break;

				case ACTOR_DIAMOND:
					pOther->bActive = FALSE;
					pPlayerActor->iScore += pOther->iExtraPoints;
					sprintf(byASTemp, "%d", pOther->iExtraPoints);
					TextActor[pOther->iID]->SetText(pOther, byASTemp);
					iCollectedDiamonds++;
					DSUtil_PlaySound(pDiamondSound, 0);
				break;

				case ACTOR_FRUIT_1:
					pOther->bActive = FALSE;
					pPlayerActor->iScore += pOther->iExtraPoints;
					sprintf(byASTemp, "%d", pOther->iExtraPoints);
					TextActor[pOther->iID]->SetText(pOther, byASTemp);
					DSUtil_PlaySound(pFruit_1Sound, 0);
				break;

				case ACTOR_HERO:
					pOther->bActive = FALSE;
					pPlayerActor->iScore += pOther->iExtraPoints;
					bHero = TRUE;
					iHeroTime = S_HERO_TIME;
					sprintf(byASTemp, "%d", pOther->iExtraPoints);
					TextActor[pOther->iID]->SetText(pOther, byASTemp);
					DSUtil_PlaySound(pHeroSound, 1);
				break;

				case ACTOR_BOMB:
					pOther->bActive = FALSE;
					pPlayerActor->iScore += pOther->iExtraPoints;
					sprintf(byASTemp, "%d", pOther->iExtraPoints);
					TextActor[pOther->iID]->SetText(pOther, byASTemp);
					DSUtil_PlaySound(pBombSound, 0); 
					// Destory all none hero enemys:
					for(i2 = 0; i2 < iActors; i2++)
					{
						if(!Actor[i2] || !Actor[i2]->bActive)
							continue;
						switch(Actor[i2]->iType)
						{
							case ACTOR_E_FOOL:
								pPlayerActor->iScore += pOther->iExtraPoints;
								sprintf(byASTemp, "%d", pOther->iExtraPoints);
								TextActor[i2]->SetText(pActor[i2], byASTemp);
								Actor[i2]->bActive = FALSE;
								Actor[i2]->LoseLife();
								iKilledEnemys++;
							break;

							case ACTOR_E_NORMAL:
								pPlayerActor->iScore += pOther->iExtraPoints;
								sprintf(byASTemp, "%d", pOther->iExtraPoints);
								TextActor[i2]->SetText(pActor[i2], byASTemp);
								Actor[i2]->bActive = FALSE;
								Actor[i2]->LoseLife();
								iKilledEnemys++;
							break;

							case ACTOR_E_TERMINATOR:
								pPlayerActor->iScore += pOther->iExtraPoints;
								sprintf(byASTemp, "%d", pOther->iExtraPoints);
								TextActor[i2]->SetText(pActor[i2], byASTemp);
								Actor[i2]->bActive = FALSE;
								Actor[i2]->LoseLife();
								iKilledEnemys++;
							break;
						}
					}
				break;

				case ACTOR_HOURGLASS:
					pOther->bActive = FALSE;
					pPlayerActor->iScore += pOther->iExtraPoints;
					sprintf(byASTemp, "+%d sec & %d", S_EXTRA_TIME, pOther->iExtraPoints);
					TextActor[pOther->iID]->SetText(pOther, byASTemp);
					iPlayTime += S_EXTRA_TIME;
					DSUtil_PlaySound(pHourglassSound, 0);
				break;

				case ACTOR_FREEZE:
					pOther->bActive = FALSE;
					pPlayerActor->iScore += pOther->iExtraPoints;
					sprintf(byASTemp, "%d", pOther->iExtraPoints);
					TextActor[pOther->iID]->SetText(pOther, byASTemp);
					bFreeze = TRUE;
					iFreezeTime = S_FREEZE_TIME;
					DSUtil_PlaySound(pFreezeSound, 1);
				break;

				case ACTOR_GHOST:
					pOther->bActive = FALSE;
					pPlayerActor->iScore += pOther->iExtraPoints;
					sprintf(byASTemp, "%d", pOther->iExtraPoints);
					TextActor[pOther->iID]->SetText(pOther, byASTemp);
					bGhost = TRUE;
					iGhostTime = S_GHOST_TIME;
					DSUtil_PlaySound(pGhostSound, 1); 
				break;

				case ACTOR_SPEED:
					pOther->bActive = FALSE;
					pPlayerActor->iScore += pOther->iExtraPoints;
					sprintf(byASTemp, "%d", pOther->iExtraPoints);
					TextActor[pOther->iID]->SetText(pOther, byASTemp);
					bSpeed = TRUE;
					iSpeedTime = S_SPEED_TIME;
					pPlayerActor->fVelocity = PLAYER_SPEED_VELOCITY;
					DSUtil_PlaySound(pSpeedSound, 1);
				break;
			}
		}
	Next:
		for(i2 = 0; i2 < 3; i2++)
		{
			pActor[i]->pLook->fBoundMin[i2] = fTBoundMin2[i2];
			pActor[i]->pLook->fBoundMax[i2] = fTBoundMax2[i2];
		}
	}
	for(i = 0; i < 3; i++)
	{
		pLook->fBoundMin[i] = fTBoundMin[i];
		pLook->fBoundMax[i] = fTBoundMax[i];
	}
	return AS_ERROR_NONE;
} // end ACTOR::CheckCollision()

void ACTOR::LoseLife(void)
{ // begin ACTOR::LoseLife()
	int i, iActorType = -1;

	bActive = FALSE;
	if(iType == ACTOR_PLAYER)
		iActorType = 0;
	if(iType == ACTOR_E_FOOL || iType == ACTOR_E_NORMAL || iType == ACTOR_E_TERMINATOR)
		iActorType = 1;	
	if(iActorType == -1)
		return;
	// Deactivate all player beamers:
	for(i = 0; i < iActors; i++)
	{
		if(!Actor[i] || !Actor[i]->bActive)
			continue;
		if(iActorType == 0 && Actor[i]->iType != ACTOR_P_REINCARNATION)
			continue;
		if(iActorType == 1 && Actor[i]->iType != ACTOR_E_REINCARNATION)
			continue;
		// Deactivate both beamer for a few seconds:
		Actor[i]->bTimeActive = TRUE;
		Actor[i]->iTimeCounter = BEAMER_DEACTIVATING_TIME;
	}
	if(iLifes != NO_LIMIT)
		iLifes--;
	if(iActorType == 0)
		DSUtil_PlaySound(pPlayerDeadSound, 0);
	if(iActorType == 1)
		DSUtil_PlaySound(pEnemyDeadSound, 0);
} // end ACTOR::LoseLife()
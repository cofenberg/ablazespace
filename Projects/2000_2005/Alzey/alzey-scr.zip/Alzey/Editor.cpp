/*
	Editor.cpp

    Last change:
    	24.6.2000

    Description:
		This is the level editor to create easy own levels.
*/

#include "AS\AS_ENGINE.h"


// Functions: *****************************************************************
HRESULT EditorMain(void);
HRESULT InitEditor(void);
void SetStandard(void);
void EditorLevel(void);
void EditorNoLevel(void);
HRESULT DestroyEditor(void);
HRESULT CheckEditorInput(void);
void EditorSetObject(void);
HRESULT EditorCheck(void);
HRESULT EditorDraw(void);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
ACTOR *EditorCursor;
AS_OBJECT *EditorCursorObj;
int iSelectedObject; // What do we want to set down? (ACTORS !!)
float fSelectedRot[3];
///////////////////////////////////////////////////////////////////////////////


HRESULT EditorMain(void)
{ // begin EditorMain()
	MSG  msg;

	InitEditor();
	if(byLoadLevel[0] != '\0')
	{ // We should open a level:
		iASResult = Level->Load(byLoadLevel, (void ***) &Actor);
		if(iASResult == AS_ERROR_NONE)
			EditorLevel();
	}
	for(;!bProgramEnd;)
	{
    	if(iASActiveModule != iASSetActiveModule)		
			break;
		if(PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
    	{
        	if(!GetMessage(&msg, NULL, 0, 0))
        	{
                return msg.wParam;
        	}
        	TranslateMessage(&msg);
        	DispatchMessage(&msg);
    	}
		else
		{	
			if(!bProgramActive)
			    continue;
			EditorCheck();
			ASDrawFunction();
		}
	}
	DestroyEditor();
	return AS_ERROR_NONE;
} // end EditorMain()

HRESULT InitEditor(void)
{ // begin InitEditor()
	for(int i = 0; i < 3; i++)
		fSelectedRot[i] = 0.0f;
	iASActiveModule = EDITOR;
	bProgramActive = TRUE;
	pMainMenu = MAKEINTRESOURCE(ID_EDITOR_MENU);
	if(!Config.bFullScreen)
		SetMenu(hWndMain, LoadMenu(hInstance, pMainMenu));
	EditorNoLevel();
	sprintf(byASTemp, GAME_NAME" - Editor");
	SetWindowText(hWndMain, byASTemp);
	ASDrawFunction = EditorDraw;
	CreateLevel(&Level);
	ASCreateCamera(&Camera);
	LoadActorsLook();
	CreateObject(&EditorCursorObj);
	CreateActor(&EditorCursor);
	sprintf(byASTemp, "%s\\%s\\E_cursor.wrl", byASProgramPath, byASObjectsFile);
	EditorCursorObj->Load(byASTemp);
	EditorCursorObj->Scale(0.5f);
	EditorCursor->pLook = EditorCursorObj;
	SetStandard();
	return AS_ERROR_NONE;
} // end InitEditor()

void SetStandard(void)
{ // begin SetStandard()
	iSelectedObject = ACTOR_PLAYER;
	EditorCursor->iXPos = 0;
	EditorCursor->iYPos = 0;
	EditorCursor->fPos[Z] = -0.5f;
	Camera->Init();
} // end SetStandard()

void EditorLevel(void)
{ // begin EditorLevel()
	CreateAllLists();
	if(!Level || !Level->Exist)
	{
		GameNoLevel();
		return;
	}
	SetStandard();
	// Enable all level dependent menus:
	for(int i = 40014; i < 40039; i++)
		EnableMenuItem(GetMenu(hWndMain), i, MF_ENABLED);
	if(Level->byFileName[0] == '\0')
		EnableMenuItem(GetMenu(hWndMain), ID_EDITOR_FILE_SAVE_LEVEL, MF_GRAYED);
} // end EditorLevel()				 

void EditorNoLevel(void)
{ // begin EditorNoLevel()
	// Disable all level dependent menus:
	for(int i = 40014; i < 40039; i++)
		EnableMenuItem(GetMenu(hWndMain), i, MF_GRAYED);
} // end EditorNoLevel()

HRESULT DestroyEditor(void)
{ // begin DestroyEditor()
	int iTempActors;
	
	iTempActors = iActors;
	DestroyActorList(&Actor);
	iActors = iTempActors;
	DestroyActorList(&TextActor);
	DestroyActorsLook();
	ASDestroyCamera(&Camera);
	DestroyObject(&EditorCursorObj);
	DestroyActor(&EditorCursor);
	DestroyLevel(&Level);
	SetMenu(hWndMain, NULL);
	return AS_ERROR_NONE;
} // end DestroyEditor()

HRESULT CheckEditorInput(void)
{ // begin CheckEditorInput()
	int i;

	if(keys[VK_LEFT])
	{
		keys[VK_LEFT] = FALSE;
		if(EditorCursor->iXPos-1 >= 0)
			EditorCursor->iXPos--;
	}
	if(keys[VK_RIGHT])
	{
		keys[VK_RIGHT] = FALSE;
		if(EditorCursor->iXPos+1 < Level->iWidth)
			EditorCursor->iXPos++;
	}
	if(keys[VK_UP])
	{
		keys[VK_UP] = FALSE;
		if(EditorCursor->iYPos-1 >= 0)
			EditorCursor->iYPos--;
	}
	if(keys[VK_DOWN])
	{
		keys[VK_DOWN] = FALSE;
		if(EditorCursor->iYPos+1 < Level->iHeight)
			EditorCursor->iYPos++;
	}
	if(keys[VK_F1])
	{
		keys[VK_F1] = FALSE;
		iSelectedObject = ACTOR_PLAYER;
	}
	if(keys[VK_F2])
	{
		keys[VK_F2] = FALSE;
		iSelectedObject = ACTOR_E_FOOL;
	}
	if(keys[VK_F3])
	{
		keys[VK_F3] = FALSE;
		iSelectedObject = ACTOR_E_NORMAL;
	}
	if(keys[VK_F4])
	{
		keys[VK_F4] = FALSE;
		iSelectedObject = ACTOR_E_TERMINATOR;
	}
	if(keys[VK_F5])
	{
		keys[VK_F5] = FALSE;
		iSelectedObject = ACTOR_P_REINCARNATION;
	}
	if(keys[VK_F6])
	{
		keys[VK_F6] = FALSE;
		iSelectedObject = ACTOR_E_REINCARNATION;
	}
	if(keys[VK_F7])
	{
		keys[VK_F7] = FALSE;
		iSelectedObject = ACTOR_DIAMOND;
	}
	if(keys[VK_F8])
	{
		keys[VK_F8] = FALSE;
		iSelectedObject = ACTOR_FRUIT_1;
	}
	if(keys[VK_F9])
	{
		keys[VK_F9] = FALSE;
		iSelectedObject = ACTOR_HERO;
	}
	if(keys[VK_F10])
	{
		keys[VK_F10] = FALSE;
		iSelectedObject = ACTOR_BOMB;
	}
	if(keys[VK_F11])
	{
		keys[VK_F11] = FALSE;
		if(iSelectedObject == ACTOR_HOURGLASS)
			iSelectedObject = ACTOR_GHOST;
		else
			iSelectedObject = ACTOR_HOURGLASS;
	}
	if(keys[VK_F12])
	{
		keys[VK_F12] = FALSE;
		if(iSelectedObject == ACTOR_FREEZE)
			iSelectedObject = ACTOR_SPEED;
		else
			iSelectedObject = ACTOR_FREEZE;
	}
	if(keys[VK_TAB])
	{
		keys[VK_TAB] = FALSE;
		if(!bASShowBound)
			bASShowBound = TRUE;
		else
		if(!bASShowBoundChilds)
			bASShowBoundChilds = TRUE;
		else
			bASShowBound = bASShowBoundChilds = FALSE;
	}
	if(keys[VK_SPACE] && Actor && !Config.bFullScreen)
	{ // We open the actor attribute dialog:
		keys[VK_SPACE] = FALSE;
		for(i = 0; i < iActors; i++)
		{
			if(!Actor[i])
				continue;
			if(Actor[i]->iXPos == EditorCursor->iXPos &&
			   Actor[i]->iYPos == EditorCursor->iYPos)
			{ // We've found an actor:
				OpenActorDialog(Actor[i]);
				break;
			}
		}
	}
	if(keys[VK_ESCAPE])
		bProgramEnd = true;
	if(keys[VK_NUMPAD8])
	{
		keys[VK_NUMPAD8] = FALSE;
		Level->SwitchWall(EditorCursor->iXPos, EditorCursor->iYPos, TOP);
	}
	if(keys[VK_NUMPAD2])
	{
		keys[VK_NUMPAD2] = FALSE;
		Level->SwitchWall(EditorCursor->iXPos, EditorCursor->iYPos, BOTTOM);
	}
	if(keys[VK_NUMPAD4])
	{
		keys[VK_NUMPAD4] = FALSE;
		Level->SwitchWall(EditorCursor->iXPos, EditorCursor->iYPos, LEFT);
	}
	if(keys[VK_NUMPAD6])
	{
		keys[VK_NUMPAD6] = FALSE;
		Level->SwitchWall(EditorCursor->iXPos, EditorCursor->iYPos, RIGHT);
	}
	if(keys[VK_NUMPAD5])
	{
		keys[VK_NUMPAD5] = FALSE;
		EditorSetObject();
	}
	return AS_ERROR_NONE;
} // end CheckEditorInput()

void EditorSetObject(void)
{ // begin EditorSetObject()
	int i, iFree = -1;

	if(!Actor)
		return;
	for(i = iActors-1; i >= 0; i--)
	{
		if(!Actor[i])
		{
			iFree = i;
			continue;
		}
		if(Actor[i]->iXPos == EditorCursor->iXPos &&
		   Actor[i]->iYPos == EditorCursor->iYPos)
		{ // Destroy the old object:
			DestroyActor(&Actor[i]);
			return;
		}
	}
	if(iFree == -1)
		return;
	i = iFree;
	// Set the new object:
	CreateActor(&Actor[i]);
	if(!Actor[i])
		return;
	Actor[i]->Set(iSelectedObject, EditorCursor->iXPos, EditorCursor->iYPos, rand() % 4);
} // end EditorSetObject()

HRESULT EditorDraw(void)
{ // begin EditorDraw()
	GLfloat afLightData[4]  = {0.0f, 0.0f, 0.0f, 0.0f};

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	if(!Level || !Level->Exist)
	{
		EditorNoLevel();
		glColor3f(1.0f, 1.0f, 1.0f);
		glLoadIdentity();									
		FontBPrintCentered(0, -20.0f, 0.0f, "No level loaded");
	}
	else
	{
		ActivateActorsLights(Actor, Camera, iActors);
		glEnable(GL_BLEND);
		EditorCursor->CalculateWorldPos((LEVEL *) Level);
		Camera->fPos[X] = -EditorCursor->fPos[X];
		Camera->fPos[Y] = -EditorCursor->fPos[Y];
		Level->Draw(Camera);
		DrawActors(Actor, Camera, iActors);
		glDisable(GL_BLEND);
		EditorCursor->pLook->fPos[X] = EditorCursor->fPos[X];
		EditorCursor->pLook->fPos[Y] = EditorCursor->fPos[Y];
		EditorCursor->pLook->fPos[Z] = EditorCursor->fPos[Z];
		DrawObject(EditorCursor->pLook, Camera, 1.0f);
		// Show the user what he has selected:
		glClear(GL_DEPTH_BUFFER_BIT);
		glLoadIdentity();									
		glTranslatef(-5, 3, -10);
		glRotatef(fSelectedRot[X], 1.0f, 0.0f, 0.0f);
		glRotatef(fSelectedRot[Y], 0, 1.0f, 0.0f);
		glRotatef(fSelectedRot[Z], 0.0f, 0.0f, 1.0f);
		DrawObject(pActorLook[iSelectedObject], NULL, 0.5f);
		DeactivateActorsLights(Actor, iActors);
	}
	ASSwapBuffers(hDC);
	return AS_ERROR_NONE;
} // end EditorDraw()

HRESULT EditorCheck(void)
{ // begin EditorCheck()
	int i; 

	ASSpeedControl();
	CheckCameraInput(Camera);
	CheckEditorInput();
	Camera->CheckMovement();
	for(i = 0; i < 3; i++)
		fSelectedRot[i] += 0.06f;
	for(i = 0; i < iActors; i++)
	{
		if(!Actor[i])
			continue;
		Actor[i]->CalculateWorldPos((LEVEL *) Level);
	}
	return AS_ERROR_NONE;
} // end EditorCheck()
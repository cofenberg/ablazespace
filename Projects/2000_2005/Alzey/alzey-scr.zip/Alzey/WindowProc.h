/*
	WindowProc.h

    Last change:
    	24.6.2000

    Description:
		Deals with the window messages. 
*/

#ifndef __WINDOW_PROC_H__
#define __WINDOW_PROC_H__


// Functions: *****************************************************************
extern LRESULT CALLBACK WindowProc(HWND, unsigned, WPARAM, LPARAM);
///////////////////////////////////////////////////////////////////////////////


#endif // __WINDOW_PROC_H__

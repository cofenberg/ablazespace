/*
	Level.h

    Last change:
    	24.6.2000

    Description:
		All what you need to deal with the levels.
*/

#ifndef __LEVEL_H__
#define __LEVEL_H__


// Definitions: ***************************************************************
enum {LA_SHOW, LA_ADJUST, LA_CREATE};
#define LEVEL_FILES "Level files (*.lev)\0*.lev\0"
#define LEVEL_S_NAME "Noname"
#define LEVEL_S_WIDTH 20
#define LEVEL_S_HEIGHT 20
#define LEVEL_S_FLOOR_Z 0.0f
#define LEVEL_S_WALL_Z_HEIGHT -1.0f
#define LEVEL_S_WALL_WIDTH 0.2f
#define LEVEL_FIELD_S_WIDTH 1.0f
#define LEVEL_FIELD_S_HEIGHT 1.0f
#define LEVEL_LEVEL_GENERAL_RED 0.5f
#define LEVEL_LEVEL_GENERAL_GREEN 0.5f
#define LEVEL_LEVEL_GENERAL_BLUE 0.5f
#define LEVEL_LEVEL_WALL_RED 0.5f
#define LEVEL_LEVEL_WALL_GREEN 0.5f
#define LEVEL_LEVEL_WALL_BLUE 0.5f
#define LEVEL_S_TIME_LIMIT 300 // The level time limit (in seconds)
///////////////////////////////////////////////////////////////////////////////

// Structures: ****************************************************************
typedef struct 
{
	int x, y;
	float xpos, ypos;
} FIELD_POINT;

typedef class
{
	public:
		int x, y;
		FIELD_POINT *Point[4];
		BOOL Wall[4];
} FIELD;

typedef class 
{
	public:
		BOOL Exist; // Is there a level?
		float fZFloor, fWallZHeight, fWallWidth,
		      fFieldWidth, fFieldHeight;
		float fGeneralRed, fGeneralGreen, fGeneralBlue;
		float fWallRed, fWallGreen, fWallBlue;
		int iWidth, iHeight, iFields, FieldPoints;
		float fWidth, fHeight; // The whole level seize
		int iTimeLimit; // The time limit for the level (-1 = no limit/time in seconds)
		char byFileName[MAX_PATH];
		char *pbyName;
		int iTotalDiamonds;
		int iTotalEnemys;
		BOOL bMissionCollectAllDiamonds;
		BOOL bMissionCollectAllDiamondsSuccess;
		BOOL bMissionKillAllEnemys;
		BOOL bMissionKillAllEnemysSuccess;
		BOOL bMissionKillNoEnemys;
		BOOL bMissionKillNoEnemysFailed;
		BOOL bMissionGoToReincarnationWhenDone;

		FIELD_POINT **FieldPoint;
		FIELD **Field;

		HRESULT Create(char *, int, int, float, float, float, float);
		HRESULT Destroy(void);
		void SetStandartA(void);
		void CalculatePoints(void);
		HRESULT Draw(AS_CAMERA *);
		HRESULT DrawWall(FIELD_POINT *, FIELD_POINT *, FIELD_POINT *, FIELD_POINT *);
		HRESULT SwitchWall(int, int, char);
		HRESULT SetWall(int, int, char);
		HRESULT DestroyWall(int, int, char);
		HRESULT Load(char *, void ***);
		HRESULT Save(char *, void **, int);
		void SetGeneralLight(void);
		BOOL CheckWallSurround(int, int);
} LEVEL;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
/*
void LEVEL::SetStandartA(void);
HRESULT LEVEL::SwitchWall(int, int, char);
HRESULT LEVEL::SetWall(int, int, char);
HRESULT LEVEL::DestroyWall(int, int, char);
HRESULT LEVEL::Create(char *, int, int,
					  float, float,
					  float, float);
HRESULT LEVEL::Destroy(void);
void LEVEL::CalculatePoints(void);
HRESULT LEVEL::Draw(AS_CAMERA *);
HRESULT LEVEL::DrawWall(FIELD_POINT *, FIELD_POINT *,
						FIELD_POINT *, FIELD_POINT *);
HRESULT LEVEL::Load(char *, void ***);
HRESULT LEVEL::Save(char *, void **, int);
void LEVEL::SetGeneralLight(void);
BOOL LEVEL::CheckWallSurround(int, int);
*/
extern void CreatLevelWallLists(void);
extern LRESULT CALLBACK LAProc(HWND, UINT, WPARAM, LPARAM);
extern HRESULT OpenLADialog(LEVEL **, char);
extern HRESULT CreateLevel(LEVEL **);
extern HRESULT DestroyLevel(LEVEL **);
///////////////////////////////////////////////////////////////////////////////


#endif // __LEVEL_H__
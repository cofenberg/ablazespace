/*
	Editor.h

    Last change:
    	24.6.2000

    Description:
		This is the level editor to create easy own levels.
*/

#ifndef __EDITOR_H__
#define __EDITOR_H__


// Functions: *****************************************************************
extern HRESULT EditorMain(void);
extern HRESULT InitEditor(void);
extern void SetStandard(void);
extern void EditorLevel(void);
extern void EditorNoLevel(void);
extern HRESULT DestroyEditor(void);
extern HRESULT CheckEditorInput(void);
extern void EditorSetObject(void);
extern HRESULT EditorCheck(void);
extern HRESULT EditorDraw(void);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern int iSelectedObject;
extern AS_OBJECT *EditorCursorObj;
extern ACTOR *EditorCursor;
///////////////////////////////////////////////////////////////////////////////


#endif // __EDITOR_H__
/*
	GameMain.h

    Last change:
    	24.6.2000

    Description:
		Things which other program parts must know about the game.		
*/

#ifndef __GAME_MAIN_H__
#define __GAME_MAIN_H__


// Definitions: ***************************************************************
enum {GAME = 1, EDITOR}; // The program modules
#define MAX_TEXTURES 9
#define NO_LIMIT -2 // There is for something no limit

#define PLAYER_S_VELOCITY 0.25f
#define PLAYER_SPEED_VELOCITY 0.5f
#define E_FOOL_S_VELOCITY 0.1f
#define E_NORMAL_S_VELOCITY 0.15f
#define E_TERMINATOR_S_VELOCITY 0.15f
#define E_TERMINATOR_FOUND_VELOCITY 0.3f
#define FRUIT_1_S_VELOCITY 0.12f
#define BOMB_S_VELOCITY 0.01f
#define HOURGLASS_S_VELOCITY 0.13f
#define FREEZE_S_VELOCITY 0.2f
#define GHOST_S_VELOCITY 0.01f
#define SPEED_S_VELOCITY 0.5f
#define TEXT_S_VELOCITY 0.8f

#define DIAMOND_POINTS 5
#define FRUIT_1_POINTS 200
#define HERO_POINTS 1
#define BOMB_POINTS -50
#define HOURGLASS_POINTS 10
#define FREEZE_POINTS 2
#define GHOST_POINTS 20
#define SPEED_POINTS 5
#define E_FOOL_POINTS 15
#define E_NORMAL_POINTS 30
#define E_TERMINATOR_POINTS 100
#define HERO_TIME 5000 // So long is the actor a hero
#define EXTRA_TIME 10000 // So many time becomes the player
#define FREEZE_TIME 5000 // The enemy freeze time in milli seconds

// Times in seconds/100:
#define S_HERO_TIME 200
#define S_FREEZE_TIME 200
#define S_GHOST_TIME 200
#define S_SPEED_TIME 200
// Times in seconds
#define S_EXTRA_TIME 20

#define PLAYER_S_LIFES 3
#define BEAMER_DEACTIVATING_TIME 30
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern void CreateListStuff(void);
extern HRESULT GameMain(void);
extern HRESULT InitGame(BOOL);
extern HRESULT LoadHighScores(char *);
extern HRESULT SaveHighScores(char *);				
extern void CreateGameLists(void);
extern HRESULT LoadGameTextures(void);
extern HRESULT InitializeGameSounds(void);
extern void CleanupGameSounds(void);
extern void StopAllSounds(void);
extern void GameLevel(void);
extern void GameNoLevel(void);
extern HRESULT DestroyGame(void);
extern HRESULT CheckGameInput(void);
extern HRESULT GameDraw(void);
extern HRESULT GameCheck(void);
extern void StartNewGame(int, BOOL);
extern void StartLevel(char *);
extern void EndGame(void);
extern void GameOver(void);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern int LEVELS; // The number of Alzey's levels
////////////////////////////
extern int iPlayTime; // The play time
extern char byLoadLevel[MAX_PATH]; // The level that should be opend
extern int ASUsedKeys;
extern DWORD dwLastTime, dwNewTime;
extern AS_KEY_ACTION ASKeyAction[6];
extern AS_ENGINE *ASEngine;
extern LEVEL *Level;
extern AS_CAMERA *Camera;
extern BOOL bGameIntro;
extern ACTOR *Player;
extern BOOL bSingleLevel;

extern UINT iTexture[MAX_TEXTURES];
extern UINT iBackgroundList;

extern BOOL bHero, bFreeze, bGhost, bSpeed; // The collected stuff:
extern int iHeroTime, iFreezeTime, iGhostTime, iSpeedTime; // The left time for this stuff
extern int iCollectedDiamonds, iKilledEnemys; // For the level missions
// Game sounds:
extern SoundObject* pDiamondSound;
extern SoundObject* pGhostSound;
extern SoundObject* pBeamerSound;
extern SoundObject* pBombSound;
extern SoundObject* pTimeSound;
extern SoundObject* pHeroSound;
extern SoundObject* pFreezeSound;
extern SoundObject* pSpeedSound;
extern SoundObject* pHourglassSound;
extern SoundObject* pFruit_1Sound;
extern SoundObject* pPlayerDeadSound;
extern SoundObject* pEnemyDeadSound;
extern SoundObject* pGameOverSound;
///////////////////////////////////////////////////////////////////////////////


#endif // __GAME_MAIN_H__
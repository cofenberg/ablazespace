/*
	GameMain.cpp

    Last change:
    	24.6.2000

    Description:
		Here takes the game place.
*/

#include "AS\AS_ENGINE.h"


// Definitions: ***************************************************************
#define SHOW_LEVEL_NAME_TIME 4.0f
#define AT_TITLE_1 4
#define AT_TITLE_5 8
#define TITLE_FLIP_TIME 200
#define MAX_HIGHSCORES 10
// The background:
enum {T_SPACE_UL, T_SPACE_UR, T_SPACE_LL, T_SPACE_RL};
#define SPACE_WIDTH 22
#define SPACE_HEIGHT 16
#define SPACE_DEPTH (-30.0f)
///////////////////////////////////////////////////////////////////////////////

// Structures: ****************************************************************
typedef struct
{
	char byName[9];
	int iLevel;
	int iScore;
} HIGHSCORE;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
HRESULT GameMain(void);
HRESULT InitGame(BOOL);
HRESULT LoadHighScores(char *);
HRESULT SaveHighScores(char *);				
HRESULT LoadGameTextures(void);
HRESULT InitializeGameSounds(void);
void CleanupGameSounds(void);
void StopAllSounds(void);
void CreateGameLists(void);
void GameLevel(void);
void GameNoLevel(void);
HRESULT DestroyGame(void);
HRESULT CheckGameInput(void);
HRESULT GameDraw(void);
HRESULT GameCheck(void);
void StartNewGame(int, BOOL);
void StartLevel(char *);
void EndGame(void);
void GameOver(void);
void DrawPlayersHighscore(void);
void CheckPlayersHighscore(void);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
int LEVELS = 21; // The number of Alzey's levels
////////////////////////////
char byLoadLevel[MAX_PATH]; // The level that should be opend
int iPlayTime; // The play time
DWORD dwLastTime, dwNewTime;
BOOL bGameIntro; // Is the intro active?
BOOL bGameTitle; // Is the level fly active?
ACTOR *Player; // This is a pointer to the players actor
float fStuffRot[3]; 
BOOL bLevelComplete;
char byLevelCompleteInfoStep;
BOOL bShowLevelName;
float fShowLevelNameTime;
BOOL bHero, bFreeze, bGhost, bSpeed; // The collected stuff:
int iHeroTime, iFreezeTime, iGhostTime, iSpeedTime; // The left time for this stuff
int iCollectedDiamonds, iKilledEnemys; // For the level missions
UINT iTexture[MAX_TEXTURES];
UINT iBackgroundList;
char byAT_Step;
BOOL bAT_Direction;
int iAS_Counter;
int iTitleScreenNr;
int iTitleScreenCounter;
BOOL bKeyText;
int iKeyTextCounter;
int iLevel;
BOOL bSingleLevel;
float fTimeCounter = 0.0f;
HIGHSCORE Highscore[MAX_HIGHSCORES] = 
{
	{"Chris", 1, 1000},
	{"CO1", 0, 1},
	{"CO2", 0, 1},
	{"CO3", 0, 1},
	{"CO4", 0, 1},
	{"CO5", 0, 1},
	{"CO6", 0, 1},
	{"CO7", 0, 1},
	{"CO8", 0, 1},
	{"CO9", 0, 1},
};
BOOL bPlayerEnteringHighScore;
char byPlayersHScorePlace;
char byHighScoreInitialsIndex;
const char byLegalHighScoreChars[38] = " 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
// Game sounds:
SoundObject* pDiamondSound;
SoundObject* pGhostSound;
SoundObject* pBeamerSound;
SoundObject* pBombSound;
SoundObject* pHeroSound;
SoundObject* pFreezeSound;
SoundObject* pSpeedSound;
SoundObject* pFruit_1Sound;
SoundObject* pHourglassSound;
SoundObject* pPlayerDeadSound;
SoundObject* pEnemyDeadSound;
SoundObject* pGameOverSound;
SYSTEMTIME MidiStartTime;
///////////////////////////////////////////////////////////////////////////////

void StartNewMidi(void)
{
	if(!Config.bMusic)
		return;
	ASStopMidi();
	ASPlayMidi(hWndMain, "Data/metamorphose.mid");
	GetLocalTime(&MidiStartTime);
}

void CheckMidi(void)
{
	SYSTEMTIME SystemTime;
	WORD wSecondDifference = 0, wMinuteDifference = 0;

	GetLocalTime(&SystemTime);
	wSecondDifference = SystemTime.wSecond-MidiStartTime.wSecond;
	if(wSecondDifference < 0)
		wSecondDifference = -wSecondDifference;
	wMinuteDifference = SystemTime.wMinute-MidiStartTime.wMinute;
	if(wMinuteDifference >= 5 && wSecondDifference >= 35)
		StartNewMidi();
}

HRESULT GameMain(void)
{ // begin GameMain()
	MSG  msg;

	InitializeGameSounds();
	sprintf(byASTemp, "%s\\%s", byASProgramPath, byASHighscoreFile);
	LoadHighScores(byASTemp);
	Intro.Load();
	if(byLoadLevel[0] != '\0')
	{
		InitGame(FALSE);
		bSingleLevel = TRUE;
		StartLevel(byLoadLevel); // We should start a level:
	}
	else
	{
		InitGame(TRUE);
		bGameIntro = TRUE;
		bGameTitle = TRUE;
		Intro.Init();
	}
	for(;;)
	{
    	if(iASActiveModule != iASSetActiveModule)
			break;
		if(PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
    	{
        	if(!GetMessage(&msg, NULL, 0, 0))
        	{
                return msg.wParam;
        	}
        	TranslateMessage(&msg);
        	DispatchMessage(&msg);
    	}
		else
		{	
			if(bProgramEnd)
				break;
			if(!bProgramActive)
			    continue;
			if(bGameIntro)
			{
				Intro.Play();
				continue;
			}	
			GameCheck();
			ASDrawFunction();
		}
	}
	DestroyGame();
	Intro.Destroy();
	sprintf(byASTemp, "%s\\%s", byASProgramPath, byASHighscoreFile);
	SaveHighScores(byASTemp);
	CleanupGameSounds();
	return AS_ERROR_NONE;
} // end GameMain()

HRESULT InitGame(BOOL bShowGameIntro)
{ // begin InitGame()
	bKeyText = TRUE;
	iKeyTextCounter = 0;
	iTitleScreenNr = 0;
	iTitleScreenCounter = 0;
	byAT_Step = AT_TITLE_1;
	bAT_Direction = 0;
	iAS_Counter = 0;
	iASActiveModule = GAME;
	bProgramActive = TRUE;
	bHero = FALSE;
	bFreeze = FALSE;
	bGhost = FALSE;
	bSpeed = FALSE;
	iCollectedDiamonds = 0;
	iKilledEnemys = 0;
	pMainMenu = MAKEINTRESOURCE(ID_GAME_MENU);
	if(!Config.bFullScreen)
		SetMenu(hWndMain, LoadMenu(hInstance, pMainMenu));
	GameNoLevel();
	sprintf(byASTemp, GAME_NAME);
	SetWindowText(hWndMain, byASTemp);
	CreateLevel(&Level);
	ASCreateCamera(&Camera);
	LoadActorsLook();
	Player = NULL;
	// Set standart program path:
	sprintf(byASTemp, "%s", byASProgramPath);
	SetCurrentDirectory(byASTemp);
	bGameTitle = TRUE;
	sprintf(byASTemp, "%s\\%s\\Alzey.lev", byASProgramPath, byASLevelsFile);
	StartLevel(byASTemp);
	if(bShowGameIntro)
	{
		StopAllSounds();
		StartNewMidi();
	}
	Camera->fGoToPos[X] = Level->fWidth/2;
	Camera->fGoToPos[Y] = Level->fHeight/2;
	Camera->fGoToPos[Z] = -20.0f;
	Camera->fGoToRot[X] = 180.0f;
	Camera->fGoToRot[Y] = 0.0f;
	Camera->fGoToRot[Z] = 0.0f;
	iLevel = 1;
	bGameTitle = TRUE;
	GameNoLevel();
	return AS_ERROR_NONE;
} // end InitGame()

HRESULT LoadHighScores(char *pbyFileName)
{ // begin LoadHighScores()
	FILE *pFile = NULL;
	
	if(!pbyFileName)
		return 1;
	pFile = fopen(pbyFileName,"r");
	if(!pFile)
		return 1;
	fread(Highscore, sizeof(HIGHSCORE), MAX_HIGHSCORES, pFile);
	fclose(pFile);
	return AS_ERROR_NONE;
} // end LoadHighScores()

HRESULT SaveHighScores(char *pbyFileName)				
{ // begin SaveHighScores()
	FILE *pFile = NULL;
	
	if(!pbyFileName)
		return false;	
	pFile = fopen(pbyFileName,"w");
	if(!pFile)
		return false;	
	fwrite(Highscore, sizeof(HIGHSCORE), MAX_HIGHSCORES, pFile);
	fclose(pFile);
	return AS_ERROR_NONE;
} // end SaveHighScores()

HRESULT LoadGameTextures(void)
{ // begin LoadGameTextures()
	byte Texture[] = {IDB_SPACE_LU, IDB_SPACE_RU, IDB_SPACE_RB,  IDB_SPACE_LB,
	                  IDB_TITLE_1, IDB_TITLE_2, IDB_TITLE_3, IDB_TITLE_4, IDB_TITLE_5};
	HBITMAP hBMP;
	BITMAP	BMP;
	
	glDeleteTextures(MAX_TEXTURES, &iTexture[0]);
	glGenTextures(MAX_TEXTURES, &iTexture[0]);
	for(int i = 0; i < MAX_TEXTURES; i++)
	{
		hBMP = (HBITMAP) LoadImage(GetModuleHandle(NULL), MAKEINTRESOURCE(Texture[i]), IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION);
		if(hBMP)
        {
			GetObject(hBMP, sizeof(BMP), &BMP);
			glPixelStorei(GL_UNPACK_ALIGNMENT,4);
			glBindTexture(GL_TEXTURE_2D, iTexture[i]);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_NEAREST);
				gluBuild2DMipmaps(GL_TEXTURE_2D, 3, BMP.bmWidth, BMP.bmHeight, GL_BGR_EXT, GL_UNSIGNED_BYTE, BMP.bmBits);
        }
	}
    return AS_ERROR_NONE;
} // end LoadGameTextures()

HRESULT InitializeGameSounds(void)
{ // begin InitializeGameSounds()
	if(!bASSoundPossible)
	    return AS_ERROR_NONE;
    pDiamondSound = DSUtil_CreateSound(TEXT("DIAMOND"), 1);
    pBeamerSound = DSUtil_CreateSound(TEXT("BEAMER"), 1);
    pGhostSound = DSUtil_CreateSound(TEXT("GHOST"), 1);
    pHeroSound = DSUtil_CreateSound(TEXT("HERO"), 1);
    pBombSound = DSUtil_CreateSound(TEXT("BOMB"), 1);
    pFreezeSound = DSUtil_CreateSound(TEXT("FREEZE"), 1);
    pHourglassSound = DSUtil_CreateSound(TEXT("HOURGLASS"), 1);
    pFruit_1Sound = DSUtil_CreateSound(TEXT("FRUIT_1"), 1);
    pSpeedSound = DSUtil_CreateSound(TEXT("SPEED"), 1);
    pPlayerDeadSound = DSUtil_CreateSound(TEXT("PLAYER_DEAD"), 1);
    pEnemyDeadSound = DSUtil_CreateSound(TEXT("ENEMY_DEAD"), 1);
    pGameOverSound = DSUtil_CreateSound(TEXT("GAME_OVER"), 1);
    return AS_ERROR_NONE;
} // end InitializeGameSounds()

void CleanupGameSounds(void)
{ // begin CleanupGameSounds()
	if(!bASSoundPossible)
	    return;
	DSUtil_DestroySound(pDiamondSound);
    pDiamondSound = NULL;    
	DSUtil_DestroySound(pBeamerSound);
    pBeamerSound = NULL;    
	DSUtil_DestroySound(pGhostSound);
    pGhostSound = NULL;    
	DSUtil_DestroySound(pHeroSound);
    pHeroSound = NULL;    
	DSUtil_DestroySound(pBombSound);
    pBombSound = NULL;    
	DSUtil_DestroySound(pFreezeSound);
    pFreezeSound = NULL;    
	DSUtil_DestroySound(pHourglassSound);
    pHourglassSound = NULL;    
	DSUtil_DestroySound(pFruit_1Sound);
    pFruit_1Sound = NULL;    
	DSUtil_DestroySound(pSpeedSound);
    pSpeedSound = NULL;    
	DSUtil_DestroySound(pPlayerDeadSound);
    pPlayerDeadSound = NULL;    
	DSUtil_DestroySound(pEnemyDeadSound);
    pEnemyDeadSound = NULL;    
	DSUtil_DestroySound(pGameOverSound);
    pGameOverSound = NULL;    
} // end CleanupGameSounds()

void StopAllSounds(void)
{ // begin StopAllSounds()
	DSUtil_StopSound(pDiamondSound); 
	DSUtil_StopSound(pGhostSound); 
	DSUtil_StopSound(pBeamerSound); 
	DSUtil_StopSound(pHeroSound); 
	DSUtil_StopSound(pBombSound); 
	DSUtil_StopSound(pFreezeSound); 
	DSUtil_StopSound(pHourglassSound); 
	DSUtil_StopSound(pFruit_1Sound); 
	DSUtil_StopSound(pSpeedSound); 
	DSUtil_StopSound(pPlayerDeadSound); 
	DSUtil_StopSound(pEnemyDeadSound); 
	DSUtil_StopSound(pGameOverSound); 
} // end StopAllSounds()

void CreateGameLists(void)
{ // begin CreateGameLists()
	// Creates the background:
	iBackgroundList = iASLists;
	iASLists++;
	glNewList(iBackgroundList, GL_COMPILE);
		glDisable(GL_CULL_FACE);
		// Upper left
		glBindTexture(GL_TEXTURE_2D, iTexture[0]);
		glBegin(GL_QUADS);
			glNormal3f(0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.0f, 0.0f); glVertex3f(-SPACE_WIDTH, 0.0f, 0.0f);
			glTexCoord2f(0.0f, 1.0f); glVertex3f(-SPACE_WIDTH, SPACE_HEIGHT * 1.4f, 0.0f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f( 0.0f, SPACE_HEIGHT * 1.4f, 0.0f);
			glTexCoord2f(1.0f, 0.0f); glVertex3f( 0.0f, 0.0f, 0.0f);
		glEnd();
		// Upper right
		glBindTexture(GL_TEXTURE_2D, iTexture[1]);
		glBegin(GL_QUADS); 
			glNormal3f(0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.0f, 0.0f); glVertex3f(0.0f, 0.0f, 0.0f);
			glTexCoord2f(0.0f, 1.0f); glVertex3f(0.0f, SPACE_HEIGHT * 1.4f, 0.0f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f(SPACE_WIDTH, SPACE_HEIGHT * 1.4f, 0.0f);
			glTexCoord2f(1.0f, 0.0f); glVertex3f(SPACE_WIDTH, 0.0f, 0.0f);
		glEnd();
		// Lower left
		glBindTexture(GL_TEXTURE_2D, iTexture[2]);
		glBegin(GL_QUADS); 
			glNormal3f(0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.0f, 0.0f); glVertex3f(-SPACE_WIDTH,-SPACE_HEIGHT * 1.4f, 0.0f);
			glTexCoord2f(0.0f, 1.0f); glVertex3f(-SPACE_WIDTH, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f(0.0f, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 0.0f); glVertex3f(0.0f, -SPACE_HEIGHT * 1.4f, 0.0f);
		glEnd();
		// Lower right
		glBindTexture(GL_TEXTURE_2D, iTexture[3]);
		glBegin(GL_QUADS); 
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.0f, 0.0f); glVertex3f(0.0f, -SPACE_HEIGHT * 1.4f, 0.0f);
			glTexCoord2f(0.0f, 1.0f); glVertex3f(0.0f, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f(SPACE_WIDTH, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 0.0f); glVertex3f(SPACE_WIDTH, -SPACE_HEIGHT * 1.4f, 0.0f);
		glEnd();
		glEnable(GL_CULL_FACE);
	glEndList();
} // end CreateGameLists()

void GameLevel(void)
{ // begin GameLevel()
	if(!Level || !Level->Exist)
	{
		GameNoLevel();
		return;
	}
	// Enable all level dependent menus:
	for(int i = 40006; i < 40008; i++)
		EnableMenuItem(GetMenu(hWndMain), i, MF_ENABLED);
} // end GameLevel()

void GameNoLevel(void)
{ // begin GameNoLevel()
	// Disable all level dependent menus:
	for(int i = 40006; i < 40008; i++)
		EnableMenuItem(GetMenu(hWndMain), i, MF_GRAYED);
} // end GameNoLevel()

HRESULT DestroyGame(void)
{ // begin DestroyGame()
	int iTempActors;
	
	iTempActors = iActors;
	DestroyActorList(&Actor);
	iActors = iTempActors;
	DestroyActorList(&TextActor);
	DestroyActorsLook();
	ASDestroyCamera(&Camera);
	DestroyLevel(&Level);
	SetMenu(hWndMain, NULL);
	ASStopMidi();
	return AS_ERROR_NONE;
} // end DestroyGame()

HRESULT CheckGameInput(void)
{ //  begin CheckGameInput()
	if(keys[VK_ESCAPE])
	{
		if(!bGameTitle)
			GameOver();
		else
			bProgramEnd = TRUE;
	}
	if(keys[VK_TAB])
	{
		keys[VK_TAB] = FALSE;
		if(!bASShowBound)
			bASShowBound = TRUE;
		else
		if(!bASShowBoundChilds)
			bASShowBoundChilds = TRUE;
		else
			bASShowBound = bASShowBoundChilds = FALSE;
	}
	if(!Player)
		return AS_ERROR_NONE;
	// The player defined keys:
	if(lpdiKeyboard2)
	{
		lpdiKeyboard2->GetDeviceState(sizeof(keys), keys);
		if(keys[ASKeyAction[0].iKeyCode])
			Player->byNextDirection = ACTOR_D_LEFT;
		if(keys[ASKeyAction[1].iKeyCode])
			Player->byNextDirection = ACTOR_D_UP;
		if(keys[ASKeyAction[2].iKeyCode])
			Player->byNextDirection = ACTOR_D_RIGHT;
		if(keys[ASKeyAction[3].iKeyCode])
			Player->byNextDirection = ACTOR_D_DOWN;
		if(keys[ASKeyAction[4].iKeyCode])
			Camera->fVelocity[POS][Z] -= 0.01f*lASDeltaT;
		if(keys[ASKeyAction[5].iKeyCode])
			Camera->fVelocity[POS][Z] += 0.01f*lASDeltaT;
	}
	else
	{ // It isn't possible to use the DInput device, use default:
		if(keys[VK_LEFT])
		{
			keys[VK_LEFT] = FALSE;
			Player->byNextDirection = ACTOR_D_LEFT;
		}
		if(keys[VK_UP])
		{
			keys[VK_UP] = FALSE;
			Player->byNextDirection = ACTOR_D_UP;
		}
		if(keys[VK_RIGHT])
		{
			keys[VK_RIGHT] = FALSE;
			Player->byNextDirection = ACTOR_D_RIGHT;
		}
		if(keys[VK_DOWN])
		{
			keys[VK_DOWN] = FALSE;
			Player->byNextDirection = ACTOR_D_DOWN;
		}
		if(keys[45])
		{
			keys[45] = FALSE;
			Camera->fVelocity[POS][Z] += 0.01f*fASDeltaT;
		}
		if(keys[33])
		{
			keys[33] = FALSE;
			Camera->fVelocity[POS][Z] -= 0.01f*fASDeltaT;
		}
	}
	return AS_ERROR_NONE;
} // end CheckGameInput()

HRESULT GameDraw(void)
{ // begin GameDraw()
	float flip;

	if(bGameIntro)
		return AS_ERROR_NONE;
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	if(!Level->Exist)
	{
		GameNoLevel();
		glColor3f(1.0f, 1.0f, 1.0f);
		glLoadIdentity();									
		FontBPrintCentered(0, -20.0f, 0.0f, "No level loaded");
	}
	else
	{
		ActivateActorsLights(Actor, Camera, iActors);
		if(!bGameTitle && Player && !bPlayerEnteringHighScore)
		{ // Center the camera on the players position:
			Camera->fPos[X] = -Player->fPos[X];
			Camera->fPos[Y] = -Player->fPos[Y];
			if(Player->fPos[X] < Level->fWidth/2)
				Camera->fRot[Y] = -20+20/((Level->fWidth/2)/Player->fPos[X]);
			else
				Camera->fRot[Y] = -20+20/((Level->fWidth/2)/(Player->fPos[X]));
			if(Player->fPos[Y] < Level->fHeight/2)
				Camera->fRot[X] = 180-(-20+20/((Level->fHeight/2)/Player->fPos[Y]));
			else
				Camera->fRot[X] = 180-(-20+20/((Level->fHeight/2)/(Player->fPos[Y])));
		}
		glDisable(GL_DEPTH_TEST);
		glDisable(GL_BLEND);
		glDisable(GL_LIGHTING);
		glEnable(GL_TEXTURE_2D);
		glLoadIdentity();									
		glTranslatef(0.0f, 0.0f, SPACE_DEPTH);
		glCallList(iBackgroundList);

		Level->Draw(Camera);
		DrawActors(Actor, Camera, iActors);
		DrawActors(TextActor, Camera, iActors);
		// Show the collected stuff:
		glEnable(GL_BLEND);
		if(!bGameTitle)
		{ // We are in the game:
			if(!bPlayerEnteringHighScore)
			{
				if(bHero)
				{ // The player is a super hero man:
					glLoadIdentity();									
					glTranslatef(0.5f, -2.0f, -6.0f);
					glRotatef(fStuffRot[X], 1.0f, 0.0f, 0.0f);
					glRotatef(fStuffRot[Y], 0, 1.0f, 0.0f);
					glRotatef(fStuffRot[Z], 0.0f, 0.0f, 1.0f);
					DrawObject(pActorLook[ACTOR_HERO], NULL, (float) iHeroTime/1000);
				}
				if(bFreeze)
				{ // The all object are freezed:
					glLoadIdentity();									
					glTranslatef(-.5f, -2.0f, -6.0f);
					glRotatef(fStuffRot[X], 1.0f, 0.0f, 0.0f);
					glRotatef(fStuffRot[Y], 0, 1.0f, 0.0f);
					glRotatef(fStuffRot[Z], 0.0f, 0.0f, 1.0f);
					DrawObject(pActorLook[ACTOR_FREEZE], NULL, (float) iFreezeTime/1000);
				}
				if(bGhost)
				{ // The all object are freezed:
					glLoadIdentity();									
					glTranslatef(-1.0f, -2.0f, -6.0f);
					glRotatef(fStuffRot[X], 1.0f, 0.0f, 0.0f);
					glRotatef(fStuffRot[Y], 0, 1.0f, 0.0f);
					glRotatef(fStuffRot[Z], 0.0f, 0.0f, 1.0f);
					DrawObject(pActorLook[ACTOR_GHOST], NULL, (float) iGhostTime/1000);
				}
				if(bSpeed)
				{ // The player becomes more 'speed':
					glLoadIdentity();									
					glTranslatef(0.0f, -2.0f, -6.0f);
					glRotatef(fStuffRot[X], 1.0f, 0.0f, 0.0f);
					glRotatef(fStuffRot[Y], 0, 1.0f, 0.0f);
					glRotatef(fStuffRot[Z], 0.0f, 0.0f, 1.0f);
					DrawObject(pActorLook[ACTOR_SPEED], NULL, (float) iSpeedTime/1000);
				}
				// The mission is to go to an reincarnationn place when done all other missions:
				if((!Level->bMissionCollectAllDiamonds || (Level->bMissionCollectAllDiamonds && Level->bMissionCollectAllDiamondsSuccess)) &&
				  (!Level->bMissionKillAllEnemys || (Level->bMissionKillAllEnemys && Level->bMissionKillAllEnemysSuccess)))
				{
					if(Level->bMissionGoToReincarnationWhenDone)
					{
						glLoadIdentity();									
						glTranslatef(4.0f, -1.5f, -10.0f);
						glRotatef(fStuffRot[X], 1.0f, 0.0f, 0.0f);
						glRotatef(fStuffRot[Y], 0, 1.0f, 0.0f);
						glRotatef(fStuffRot[Z], 0.0f, 0.0f, 1.0f);
						DrawObject(pActorLook[ACTOR_P_REINCARNATION], NULL, 1.0f);
					}
				}
				else
				{ // Show the other missions:
					// If an mission is to collect all diamonds:
					if(Level->bMissionCollectAllDiamonds && !Level->bMissionCollectAllDiamondsSuccess)
					{
						glLoadIdentity();									
						glTranslatef(2.0f, -2.0f, -6.0f);
						glRotatef(fStuffRot[X], 1.0f, 0.0f, 0.0f);
						glRotatef(fStuffRot[Y], 0, 1.0f, 0.0f);
						glRotatef(fStuffRot[Z], 0.0f, 0.0f, 1.0f);
						DrawObject(pActorLook[ACTOR_DIAMOND], NULL, 1.0f);
					}
					// If an mission is to kill all enemys:
					if(Level->bMissionKillAllEnemys && !Level->bMissionKillAllEnemysSuccess)
					{
						glLoadIdentity();									
						glTranslatef(2.0f, -1.5f, -6.0f);
						glRotatef(fStuffRot[X], 1.0f, 0.0f, 0.0f);
						glRotatef(fStuffRot[Y], 0, 1.0f, 0.0f);
						glRotatef(fStuffRot[Z], 0.0f, 0.0f, 1.0f);
						DrawObject(pActorLook[ACTOR_KILL_ALL_ENEMYS], NULL, 1.0f);
					}
					// If an mission is to kill no enemys:
					if(Level->bMissionKillNoEnemys)
					{
						glLoadIdentity();									
						glTranslatef(2.0f, -1.5f, -6.0f);
						glRotatef(fStuffRot[X], 1.0f, 0.0f, 0.0f);
						glRotatef(fStuffRot[Y], 0, 1.0f, 0.0f);
						glRotatef(fStuffRot[Z], 0.0f, 0.0f, 1.0f);
						DrawObject(pActorLook[ACTOR_KILL_NO_ENEMYS], NULL, 1.0f);
					}
				}
				glDisable(GL_DEPTH_TEST);
				glEnable(GL_BLEND);
				glDisable(GL_LIGHTING);
				glColor4ub(255,255,255,255);
				if(Player)
				{
					glLoadIdentity();									
					FontBPrint(0, -30.f, -15.0f, 10.0f, "Score: %d", Player->iScore);
					if(Player->iLifes != NO_LIMIT)
					{
						glLoadIdentity();									
						FontBPrint(0, -30.0f, -15.0f, -10.0f, "Lifes: %d", Player->iLifes);
					}
				}
				if(bLevelComplete)
				{
					glLoadIdentity();									
					if(byLevelCompleteInfoStep == 0)
						FontBPrintCentered(0, -8.0f, 0.0f, "Life bonus");
					else
					if(byLevelCompleteInfoStep == 1)
						FontBPrintCentered(0, -8.0f, 0.0f, "Time bonus");
					else
					if(byLevelCompleteInfoStep == 2)
						FontBPrintCentered(0, -8.0f, 0.0f, "Level complete");
				}
				if(Level->iTimeLimit != NO_LIMIT)
				{
					glLoadIdentity();									
					FontBPrint(0, -30.0f, 10.0f, 10.0f, "Time: %d", iPlayTime);
				}
				// If an mission is to collect all diamonds:
				if(Level->bMissionCollectAllDiamonds && !Level->bMissionCollectAllDiamondsSuccess)
				{ // Show the rest of diamonds:
					glLoadIdentity();									
					FontBPrint(0, -30.0f, 10.0f, -10.0f, "* %d", Level->iTotalDiamonds-iCollectedDiamonds);
				}
				// If an mission is to kill all enemys:
				if(Level->bMissionKillAllEnemys && !Level->bMissionKillAllEnemysSuccess)
				{ // Show the rest of the enemys:
					glLoadIdentity();									
					FontBPrint(0, -30.0f, 10.0f, -8.0f, "* %d", Level->iTotalEnemys-iKilledEnemys);
				}
				if(bShowLevelName == TRUE)
				{
					glLoadIdentity();									
					FontBPrintCentered(0, -2*((float) SHOW_LEVEL_NAME_TIME/fShowLevelNameTime), 0.0f, Level->pbyName);
				}	
			}
			else
				DrawPlayersHighscore();
		}
		else
		{ // The title screen is shown:
			glDisable(GL_DEPTH_TEST);
			glEnable(GL_BLEND);
			glDisable(GL_LIGHTING);
			if(!bKeyText)
				glColor4f(1.0f, 1.0f, 1.0f, 0.2f);
			else
				glColor4f(1.0f, 1.0f, 1.0f, 0.9f);
			glLoadIdentity();									
			FontBPrintCentered(0, -20.0f, 7.0f, "Press any key to start...");
			glColor4f(1.0f, 1.0f, 1.0f, 0.7f);
			switch(iTitleScreenNr)
			{
				case 0: case 2: case 4:
					// Shows the main screen:
					glLoadIdentity();									
					FontBPrintCentered(0, -30.0f, -9.0f, "Alzey is an AblazeSpace project");
					glLoadIdentity();									
					FontBPrintCentered(0, -30.0f, -10.0f, "Programmed & Designed: Christian Ofenberg");
					glLoadIdentity();									
					FontBPrintCentered(0, -30.0f, -11.0f, "Music: Mike Spang");
					glLoadIdentity();									
					FontBPrintCentered(0, -30.0f, -12.0f, "Thanks to: Stephan Wezel");
					// Draw the title:
					glColor4f(1.0f, 1.0f, 1.0f, 0.9f);
					glLoadIdentity();									
					glEnable(GL_TEXTURE_2D);
					glBindTexture(GL_TEXTURE_2D, iTexture[byAT_Step]);
					flip = 1.0f*((float) (TITLE_FLIP_TIME/(iTitleScreenCounter+0.00001f)));
					glDisable(GL_CULL_FACE);
					glBegin(GL_QUADS); 
						glNormal3f(0.0f, 0.0f, 1.0f);
						glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f-flip, -0.5f-flip, -5.0f-flip);
						glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f-flip, 0.5f-flip, -5.0f+flip);
						glTexCoord2f(1.0f, 1.0f); glVertex3f(1.0f+flip, 0.5f+flip, -5.0f-flip);
						glTexCoord2f(1.0f, 0.0f); glVertex3f(1.0f+flip, -0.5f+flip, -5.0f+flip);
					glEnd();
					glEnable(GL_CULL_FACE);
				break;

				case 1: case 3: case 5:
					// Shows the highscore:
					DrawPlayersHighscore();
				break;

				case 6:
					bGameIntro = TRUE;
					Intro.Init();
				break;
			}
		}
		DeactivateActorsLights(Actor, iActors);
	}
	ASSwapBuffers(hDC);
	return AS_ERROR_NONE;
} // end GameDraw()

HRESULT GameCheck(void)
{ // begin GameCheck()	
	DWORD dwTimeDifference;
	int i, i2, i3, x, y, iTime;
	BOOL bBeamerFound = FALSE;

	CheckMidi();
	if(!Level->Exist)
		return AS_ERROR_NONE;
	ASSpeedControl();
	fTimeCounter += 0.1f*lASDeltaT;
	dwNewTime = GetTickCount();
	dwTimeDifference = dwNewTime-dwLastTime;
	for(i = 0; i < 3; i++)
		fStuffRot[i] += 0.006f*lASDeltaT;
	CheckActors((LEVEL *) Level, TextActor, iActors);
	// Is an level complete?
	if(bLevelComplete)
	{
		if(byLevelCompleteInfoStep == 0)
			iTime = 100;
		if(byLevelCompleteInfoStep == 1)
			iTime = 40;
		if(byLevelCompleteInfoStep == 2)
			iTime = 2500;
		if(byLevelCompleteInfoStep == 3)
			iTime = 0;
		for(i = 0; i < 256; i++)
			if(keys[i])
			{
				byLevelCompleteInfoStep = 3;
				iTime = 0;	
			}
		if(dwTimeDifference > (DWORD) iTime)
		{
			dwLastTime = dwNewTime;
			switch(byLevelCompleteInfoStep)
			{
				case 0: // Give for the lifes points:
					if(Player && Player->iLifes != NO_LIMIT && Player->iLifes > 0)
					{
						Player->iScore += 1000;
						Player->iLifes--;
						break;
					}
					byLevelCompleteInfoStep++;
				break;

				case 1: // Give for the time points:
					if(Player && Level && Level->iTimeLimit != NO_LIMIT && iPlayTime > 0)
					{
						Player->iScore += 5;
						iPlayTime--;
						break;	
					}
					byLevelCompleteInfoStep++;
				break;

				case 2:
					byLevelCompleteInfoStep++;
				break;

				case 3:
					if(iLevel == LEVELS)
					{ // The player has won the whole game:
						bLevelComplete = FALSE;
						GameOver();
						return AS_ERROR_NONE;
					}
					// We go to the next level:
					iLevel++;
					StartNewGame(iLevel, TRUE);
				break;
			}
		}
	}
	else // Let the time run:		
		if(Level->iTimeLimit != NO_LIMIT && dwTimeDifference >= 1000)
		{ // So, one second less:
			dwLastTime = dwNewTime;
			iPlayTime--;
		}
	if(fTimeCounter >= 4.0f)
	{
		fTimeCounter = 0.0f;
		if(bGameTitle || bPlayerEnteringHighScore)
		{ // We are in the title screen
			iKeyTextCounter++;
			if(iKeyTextCounter > 50)
			{
				iKeyTextCounter = 0;
				bKeyText = !bKeyText;
			}
			iTitleScreenCounter++;
			if(iTitleScreenCounter > TITLE_FLIP_TIME)
			{
				iTitleScreenCounter = 0;
				iTitleScreenNr++;
			}
			// Animate the title:
			iAS_Counter++;
			if(iAS_Counter > 2)
			{
				iAS_Counter = 0;
				if(!bAT_Direction)
				{
					iAS_Counter = 0;
					byAT_Step++;
					if(byAT_Step >= AT_TITLE_5)
						bAT_Direction = 1;
				}
				else
				{
					byAT_Step--;
					if(byAT_Step <= AT_TITLE_1)
						bAT_Direction = 0;
				}
			}
		}
		///////////
		// Check the collected stuff:
		if(bHero)
		{
			iHeroTime--;
			if(iHeroTime < 0)
			{
				iHeroTime = 0;
				bHero = FALSE;
				DSUtil_StopSound(pHeroSound); 
			}
		}
		if(bFreeze)
		{
			iFreezeTime--;
			if(iFreezeTime < 0)
			{
				iFreezeTime = 0;
				bFreeze = FALSE;
				DSUtil_StopSound(pFreezeSound); 
			}
		}
		if(bGhost)
		{
			iGhostTime--;
			if(iGhostTime < 0)
			{
				iGhostTime = 0;
				bGhost = FALSE;
				DSUtil_StopSound(pGhostSound); 
			}
		}
		if(bSpeed)
		{
			iSpeedTime--;
			if(iSpeedTime < 0)
			{
				iSpeedTime = 0;
				bSpeed = FALSE;
				Player->fVelocity = PLAYER_S_VELOCITY;
				DSUtil_StopSound(pSpeedSound); 
			}
		}
	}
	if(bGameTitle && !bPlayerEnteringHighScore)
	{
		if(keys[VK_ESCAPE])
			bProgramEnd = TRUE;
		for(i = 0; i < 256; i++)
			if(keys[i])
			{ // Game begins:				
				bGameIntro = FALSE;
				bGameTitle = FALSE;
				bSingleLevel = FALSE;
				StartNewGame(1, FALSE);
			}
	}
	if(bGameTitle || bPlayerEnteringHighScore && lASDeltaT)
	{
		// Do camera movement:
		if(Camera->fPos[X] < -Camera->fGoToPos[X])
			Camera->fVelocity[POS][X] += 0.002f*lASDeltaT;
		if(Camera->fPos[X] > -Camera->fGoToPos[X])
			Camera->fVelocity[POS][X] -= 0.002f*lASDeltaT;
		if(Camera->fPos[Y] < -Camera->fGoToPos[Y])
			Camera->fVelocity[POS][Y] += 0.002f*lASDeltaT;
		if(Camera->fPos[Y] > -Camera->fGoToPos[Y])
			Camera->fVelocity[POS][Y] -= 0.002f*lASDeltaT;
		if(Camera->fPos[Z] < Camera->fGoToPos[Z])
			Camera->fVelocity[POS][Z] += 0.002f*lASDeltaT;
		if(Camera->fPos[Z] > Camera->fGoToPos[Z])
			Camera->fVelocity[POS][Z] -= 0.002f*lASDeltaT;
		// Rotation:
		if(Camera->fRot[X] < Camera->fGoToRot[X])
			Camera->fVelocity[ROT][X] += 0.002f*lASDeltaT;
		if(Camera->fRot[X] > Camera->fGoToRot[X])
			Camera->fVelocity[ROT][X] -= 0.002f*lASDeltaT;
		if(Camera->fRot[Y] < Camera->fGoToRot[Y])
			Camera->fVelocity[ROT][Y] += 0.002f*lASDeltaT;
		if(Camera->fRot[Y] > Camera->fGoToRot[Y])
			Camera->fVelocity[ROT][Y] -= 0.002f*lASDeltaT;
		if(Camera->fRot[Z] < Camera->fGoToRot[Z])
			Camera->fVelocity[ROT][Z] += 0.002f*lASDeltaT;
		if(Camera->fRot[Z] > Camera->fGoToRot[Z])
			Camera->fVelocity[ROT][Z] -= 0.002f;
		// Is the camera in the tolerable target area:
		if(Camera->fPos[X] > -Camera->fGoToPos[X]-0.3f &&
		   Camera->fPos[Y] > -Camera->fGoToPos[Y]-0.3f &&
		   Camera->fPos[X] < -Camera->fGoToPos[X]+0.3f &&
		   Camera->fPos[Y] < -Camera->fGoToPos[Y]+0.3f &&
		   Camera->fPos[Z] < -Camera->fGoToPos[Z]+0.3f &&
		   Camera->fPos[Z] < -Camera->fGoToPos[Z]+0.3f)
		{ // Yes! Find a new target point:
			Camera->fGoToPos[X] = ((float) (rand() % (int) (Level->fWidth*10)))/10;
			Camera->fGoToPos[Y] = ((float) (rand() % (int) (Level->fHeight*10)))/10;
			Camera->fGoToPos[Z] = ((Level->fWallZHeight*10)-((float) (rand() % (int) (100)))/10);
			// Rotation:
			Camera->fGoToRot[X] = ((float) (rand() % (int) (300)))/10;
			if(rand() % 2 == 1)
				Camera->fGoToRot[X] = -Camera->fGoToRot[X];
			Camera->fGoToRot[X] += 180;
			Camera->fGoToRot[Y] = ((float) (rand() % (int) (300)))/10;
			if(rand() % 2 == 1)
				Camera->fGoToRot[Y] = -Camera->fGoToRot[Y];
			Camera->fGoToRot[Z] = ((float) (rand() % (int) (100)))/10;
			if(rand() % 2 == 1)
				Camera->fGoToRot[Z] = -Camera->fGoToRot[Z];
		}
	}
	Camera->CheckMovement();
	if(!bLevelComplete && !iPlayTime)
	{ // So, the time is out:
		iPlayTime = Level->iTimeLimit;
		Player->LoseLife();
	}
	if(!bGameTitle)
	{
		if(Level->bMissionCollectAllDiamonds && iCollectedDiamonds == Level->iTotalDiamonds)
		{ // The player has collected all diamonds:
			Level->bMissionCollectAllDiamondsSuccess = TRUE;
		}
		else
			Level->bMissionCollectAllDiamondsSuccess = FALSE;
		if(Level->bMissionKillAllEnemys && iKilledEnemys == Level->iTotalEnemys)
		{ // All enemys are now terminated:
			Level->bMissionKillAllEnemysSuccess = TRUE;
		}
		else
			Level->bMissionKillAllEnemysSuccess = FALSE;
		if(Level->bMissionKillNoEnemys && iKilledEnemys >= 1)
		{ // Oh no! The player has killed an enemy!
			iKilledEnemys--;
			Level->bMissionKillNoEnemysFailed = FALSE;
			Player->LoseLife();
		}
		else
			Level->bMissionKillNoEnemysFailed = FALSE;
		// Check mission status:
		if((!Level->bMissionCollectAllDiamonds || (Level->bMissionCollectAllDiamonds && Level->bMissionCollectAllDiamondsSuccess)) &&
		  (!Level->bMissionKillAllEnemys || (Level->bMissionKillAllEnemys && Level->bMissionKillAllEnemysSuccess)))
		{ // All missions were an success:
			// Should the player go to a reincarnation place?:
			if(Level->bMissionGoToReincarnationWhenDone)
			{ // Yes:
				for(i = 0; i < iActors; i++)
				{
					if(!Actor[i] || !Actor[i]->bActive ||
					   Actor[i]->bTimeActive || Actor[i]->iType != ACTOR_P_REINCARNATION ||
					   Player->iXPos != Actor[i]->iXPos || Player->iYPos != Actor[i]->iYPos ||
					   Player->fFXPos != Actor[i]->fFXPos || Player->fFYPos != Actor[i]->fFYPos)
						continue;
					goto level_end;
				}			
				goto no_level_end;
			}
		level_end:
			if(!bPlayerEnteringHighScore)
			{
				bLevelComplete = TRUE;
				return AS_ERROR_NONE;
			}
		}
	}
no_level_end:
	if(bShowLevelName == TRUE)
	{
		fShowLevelNameTime -= fASDeltaT*0.1f;
		if(fShowLevelNameTime < 0)
			bShowLevelName = FALSE;
	}
	for(i3 = 0; i3 < iActors; i3++)
	{
		if(!Actor[i3] || Actor[i3]->bActive ||
		   (Actor[i3]->iType != ACTOR_E_FOOL &&
		    Actor[i3]->iType != ACTOR_E_NORMAL &&
		    Actor[i3]->iType != ACTOR_E_TERMINATOR))
			continue;
		if(Actor[i3]->iLifes <= -1)
		{
			if(Actor[i3]->iLifes != NO_LIMIT)
				continue;
		}
		i = rand() % iActors;
		for(i2 = 0; i2 < iActors; i++, i2++)
		{
			if(i >= iActors)
				i = 0;
			if(!Actor[i] || !Actor[i]->bActive ||
			   Actor[i]->bTimeActive)
				continue;
			if(Actor[i]->iType == ACTOR_E_REINCARNATION)
			{ // The enemy comes here out:
				Actor[i3]->bActive = TRUE;
				Actor[i3]->iXPos = Actor[i]->iXPos;
				Actor[i3]->iYPos = Actor[i]->iYPos;
				Actor[i3]->fFXPos = 0.0f;
				Actor[i3]->fFYPos = 0.0f;
				iKilledEnemys--;
				// Deactivate beamer for a few seconds:
				Actor[i]->bTimeActive = TRUE;
				Actor[i]->iTimeCounter = BEAMER_DEACTIVATING_TIME;
				break;
			}
		}
	}
	CheckActors((LEVEL *) Level, Actor, iActors);
	if(bGameTitle)
		return 0;
	if(bPlayerEnteringHighScore)
	{ // The player is already dead:
		CheckPlayersHighscore();
		return 0;
	}
	CheckGameInput();
	if(Player)
	{
		if(Player->iLifes == -1)
		{ // The player is DEAD:
			GameOver();
			return 0;
		}
		if(!Player->bActive)
		{ // The player is not in the level:
			// We will choose the reincarnation place per random, if there are more
			// than one:
			i = rand() % iActors;
			for(i2 = 0; i2 < iActors; i++, i2++)
			{
				if(i >= iActors)
					i = 0;
				if(!Actor[i] || !Actor[i]->bActive || Actor[i]->iType != ACTOR_P_REINCARNATION)
					continue;
				bBeamerFound = TRUE;
				if(Actor[i]->bTimeActive)
					continue;
			    // The player comes here out:
				Player->bActive = TRUE;
				Player->iXPos = Actor[i]->iXPos;
				Player->iYPos = Actor[i]->iYPos;
				Player->fFXPos = 0.0f;
				Player->fFYPos = 0.0f;
				bGhost = TRUE;
				iGhostTime = S_GHOST_TIME/2;
				DSUtil_PlaySound(pGhostSound, 1); 
				// Deactivate both beamer for a few seconds:
				Actor[i]->bTimeActive = TRUE;
				Actor[i]->iTimeCounter = BEAMER_DEACTIVATING_TIME;
				break;
			}
			if(!Player->bActive && bBeamerFound == FALSE)
			{ // There is no reincarnation place for the player, so we will set
			 // him per random:
				for(;;)
				{
					if(Player->bRandomReincarnation)
					{
						x = rand() % (Level->iWidth-1);
						y = rand() % (Level->iHeight-1);
					}
					else
					{
						x = Player->iSXPos;
						y = Player->iSYPos;
					}
					if(Level->CheckWallSurround(x, y))
						continue;						
					// There should be no emenys in there near (only for the fair play):
					for(i = 0; i < iActors; i++)
					{
						if(!Actor[i] || !Actor[i]->bActive)
							continue;
						if(Actor[i]->iType == ACTOR_E_FOOL || Actor[i]->iType == ACTOR_E_NORMAL || Actor[i]->iType == ACTOR_E_TERMINATOR)
							if((Actor[i]->iXPos == x && Actor[i]->iYPos == y) ||
							   (Actor[i]->iXPos == x-1 && Actor[i]->iYPos == y) ||
							   (Actor[i]->iXPos == x+1 && Actor[i]->iYPos == y) ||
							   (Actor[i]->iXPos == x && Actor[i]->iYPos == y-1) ||
							   (Actor[i]->iXPos == x && Actor[i]->iYPos == y+1) ||
							   (Actor[i]->iXPos == x-1 && Actor[i]->iYPos == y-1) ||
							   (Actor[i]->iXPos == x+1 && Actor[i]->iYPos == y-1) ||
							   (Actor[i]->iXPos == x+1 && Actor[i]->iYPos == y+1) ||
							   (Actor[i]->iXPos == x-1 && Actor[i]->iYPos == y+1))
								goto NextTry;
					}
					Player->bActive = TRUE;
					Player->iXPos = x;
					Player->iYPos = y;
					Player->fFXPos = 0.0f;
					Player->fFYPos = 0.0f;
					bGhost = TRUE;
					iGhostTime = S_GHOST_TIME;
					DSUtil_PlaySound(pGhostSound, 1); 
					DSUtil_PlaySound(pBeamerSound, 0); 
					break;
				NextTry:;
				}
			}
	 // The player comes here out:
		}
	}
	return AS_ERROR_NONE;
} // end GameCheck()

void StartNewGame(int iTLevel, BOOL bHoldPoints)
{ // begin StartNewGame()
	int iScore = 0;

	iLevel = iTLevel;
	if(bSingleLevel)
	{ // This was only one single level:
		EndGame();
		return;
	}
	if(bHoldPoints && Player)
		iScore = Player->iScore;
	sprintf(byASTemp, "%s\\%s\\Level%d.lev", byASProgramPath, byASLevelsFile, iLevel);
	StartLevel(byASTemp);
	if(Player)
		Player->iScore = iScore;
} // end StartNewGame()

void StartLevel(char *pbyLevelFile)
{ // begin StartLevel()
	int i;
	char byTemp[MAX_PATH];
	int iTempActors;

	StopAllSounds();
	if(!pbyLevelFile)
		return;
	iTempActors = iActors;
	DestroyActorList(&Actor);
	iActors = iTempActors;
	DestroyActorList(&TextActor);
	strcpy(byTemp, pbyLevelFile);
	Level->Load(byTemp, (void ***) &Actor);
	bGameIntro = FALSE;
	bGameTitle = FALSE;
	bPlayerEnteringHighScore = FALSE;
	ASDrawFunction = GameDraw;
	iPlayTime = Level->iTimeLimit; // Set the play time
	dwLastTime = GetTickCount();	
	if(!bGameTitle) // In the Alzey titelscreen are no players
	{
		bGameIntro = FALSE;
		// Find the players:
		for(i = 0; i < iActors; i++)
		{
			if(!Actor[i])
				continue;
			if(Actor[i]->iType == ACTOR_PLAYER)
			{
				Player = Actor[i];
				break;
			}
		}
	}
	// Deactivate the good stuff:
	for(i = 0; i < iActors; i++)
	{
		if(!Actor[i] || !Actor[i]->bRandomStart)
			continue;
		switch(Actor[i]->iType)
		{		
			case ACTOR_P_REINCARNATION:
				Actor[i]->bTimeActive = FALSE;
			break;

			default:
				Actor[i]->bActive = FALSE;
		}
	}
	Camera->Init();
	Camera->fPos[Z] = -10.0f;
	bHero = FALSE;
	bFreeze = FALSE;
	bGhost = FALSE;
	bSpeed = FALSE;
	iCollectedDiamonds = 0;
	iKilledEnemys = 0;
	GameLevel();
	bShowLevelName = TRUE;
	fShowLevelNameTime = SHOW_LEVEL_NAME_TIME;
	bLevelComplete = FALSE;
	byLevelCompleteInfoStep = 0;
	if(Player)
	{
		Player->iScore = 0;
		if(Player->bRandomStart)
			Player->bActive = FALSE;
		else
		{
			Player->bActive = TRUE;
			Player->fFXPos = 0.0f;
			Player->fFYPos = 0.0f;
			bGhost = TRUE;
			iGhostTime = S_GHOST_TIME/2;
			DSUtil_PlaySound(pGhostSound, 1); 
		}
	}
} // end StartLevel()

void EndGame(void)
{ // begin EndGame()
	Level->Destroy();
	InitGame(TRUE);
	Intro.Init();
	bGameIntro = TRUE;
	StopAllSounds();
} // end EndGame()

void GameOver(void)
{ // begin GameOver()
	bPlayerEnteringHighScore = TRUE;
	byPlayersHScorePlace = -1;
	StopAllSounds();
	DSUtil_PlaySound(pGameOverSound, 0);
	Camera->fPos[X] = Level->fWidth/2;
	Camera->fPos[Y] = Level->fHeight/2;
	Camera->fPos[Z] = -20.0f;
	Camera->fGoToPos[X] = Level->fWidth/2;
	Camera->fGoToPos[Y] = Level->fHeight/2;
	Camera->fGoToPos[Z] = -20.0f;
	Camera->fGoToRot[X] = 180.0f;
	Camera->fGoToRot[Y] = 0.0f;
	Camera->fGoToRot[Z] = 0.0f;
} // end GameOver()

void DrawPlayersHighscore(void)
{ // begin DrawPlayersHighscore()
	int i;
	float y;

	glDisable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glDisable(GL_LIGHTING);
	glColor4ub(255,255,255,255);
	if(!bPlayerEnteringHighScore)
	{
		glLoadIdentity();									
		FontBPrintCentered(0, -10.0f, 2.5f, "Highscore");
	}
	else
	{ // The player enters or not his name into the highscore:
		if(byPlayersHScorePlace != -2)
		{
			glLoadIdentity();									
			FontBPrintCentered(0, -13.0f, 4.0f, "Congratulations!");
			glLoadIdentity();									
			FontBPrintCentered(0, -20.0f, 5.5f, "You are in the highscore!");
			glLoadIdentity();									
			FontBPrintCentered(0, -30.0f, 7.0f, "Enter your name and hit enter when done.");
		}
		else // He's a looser:
		{
			glLoadIdentity();									
			FontBPrintCentered(0, -13.0f, 4.0f, "You looser!");
			glLoadIdentity();									
			FontBPrintCentered(0, -20.0f, 5.5f, "You are not in the highscore!");
			glLoadIdentity();									
			FontBPrintCentered(0, -30.0f, 7.0f, "Press enter.");
		}
	}
	glLoadIdentity();									
	glTranslatef(-8.0f, 0.0f, 0.0f);
	FontBPrintCentered(0, -20.0f, 3.5f, "Place");
	glLoadIdentity();									
	glTranslatef(-4.0f, 0.0f, 0.0f);
	FontBPrintCentered(0, -20.0f, 3.5f, "Name");
	glLoadIdentity();									
	glTranslatef(1.0f, 0.0f, 0.0f);
	FontBPrintCentered(0, -20.0f, 3.5f, "Level");
	glLoadIdentity();									
	glTranslatef(6.0f, 0.0f, 0.0f);
	FontBPrintCentered(0, -20.0f, 3.5f, "Score");
	for(i = 0, y = 2.0f; i < MAX_HIGHSCORES; i++, y -= 1.0f)
	{
		if(byPlayersHScorePlace == i)
			glColor4f(0.6f, 0.6f, 0.6f, 0.9f);
		else
			glColor4f(1.0f, 1.0f, 1.0f, 0.9f);
		glLoadIdentity();									
		glTranslatef(-8.0f, 0.0f, 0.0f);
		FontBPrintCentered(0, -20.0f, y, "%d.", i);
		glLoadIdentity();									
		glTranslatef(-4.0f, 0.0f, 0.0f);
		FontBPrintCentered(0, -20.0f, y, "%s", Highscore[i].byName);
		glLoadIdentity();									
		glTranslatef(1.0f, 0.0f, 0.0f);
		FontBPrintCentered(0, -20.0f, y, "%d", Highscore[i].iLevel);
		glLoadIdentity();									
		glTranslatef(6.0f, 0.0f, 0.0f);
		FontBPrintCentered(0, -20.0f, y, "%d", Highscore[i].iScore);
	}
} // end DrawPlayersHighscore()

void CheckPlayersHighscore(void)
{ // begin CheckPlayersHighscore()
	int i, i2;
	
	if(byPlayersHScorePlace == -1)
	{ // Check if the player is in the highscore:
		if(!Player)
			goto Close;
		for(i = 0; i < MAX_HIGHSCORES; i++)
		{
			if(Player->iScore >= Highscore[i].iScore)
			{ // The player is better as someone:
				// Make place for the new king:
				for(i2 = MAX_HIGHSCORES-1; i2 >= i; i2--)
				{
					Highscore[i2].iLevel = Highscore[i2-1].iLevel;
					Highscore[i2].iScore = Highscore[i2-1].iScore;
					strcpy(Highscore[i2].byName, Highscore[i2-1].byName);
				}
				Highscore[i].iScore = Player->iScore;
				Highscore[i].iLevel = iLevel;
				byPlayersHScorePlace = i;
				byHighScoreInitialsIndex = 9;
				for(i2 = 0; i2 < 9; i2++)
					Highscore[i].byName[i2] = byASUserName[i2];
				break;
			}
		}
		if(byPlayersHScorePlace == -1)
		{ // The player is a looser:
			byPlayersHScorePlace = -2;
		}
	}
	if((keys[VK_RETURN]))
	{ // Close the hightscore menu:
	Close:
		bPlayerEnteringHighScore = FALSE;
		EndGame();
		return;
	}
	if(byPlayersHScorePlace != -2)
	{
		if(keys[VK_BACK])
		{
			keys[VK_BACK] = FALSE;
			if(byHighScoreInitialsIndex > 0)
			{
				byHighScoreInitialsIndex--;
				Highscore[byPlayersHScorePlace].byName[byHighScoreInitialsIndex] = ' ';
			}
		}
		else 
		if(byHighScoreInitialsIndex <= 8)
		{			
			for(i = 0; i < 38; i++) 
			{
				if(keys[byLegalHighScoreChars[i]])
				{
					Highscore[byPlayersHScorePlace].byName[byHighScoreInitialsIndex] = byLegalHighScoreChars[i];
					keys[byLegalHighScoreChars[i]] = FALSE;
					byHighScoreInitialsIndex++;
					break;
				}
			}
		}
	}
} // end CheckPlayersHighscore()
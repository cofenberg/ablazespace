/*
	Level.cpp

    Last change:
    	24.6.2000

    Description:
		All what you need to deal with the levels.
*/

#include "AS\AS_ENGINE.h"


// Functions: *****************************************************************
/*
void LEVEL::SetStandartA(void);
HRESULT LEVEL::SwitchWall(int, int, char);
HRESULT LEVEL::SetWall(int, int, char);
HRESULT LEVEL::DestroyWall(int, int, char);
HRESULT LEVEL::Create(char *, int, int,
					  float, float,
					  float, float);
HRESULT LEVEL::Destroy(void);
void LEVEL::CalculatePoints(void);
HRESULT LEVEL::Draw(AS_CAMERA *);
HRESULT LEVEL::DrawWall(FIELD_POINT *, FIELD_POINT *,
						FIELD_POINT *, FIELD_POINT *);
HRESULT LEVEL::Load(char *, void ***);
HRESULT LEVEL::Save(char *, void **, int);
void LEVEL::SetGeneralLight(void);
BOOL LEVEL::CheckWallSurround(int, int);
*/
void CreatLevelWallLists(void);
LRESULT CALLBACK LAProc(HWND, UINT, WPARAM, LPARAM);
HRESULT OpenLADialog(LEVEL **, char);
HRESULT CreateLevel(LEVEL **);
HRESULT DestroyLevel(LEVEL **);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
LEVEL *pTLevel;
char byLAMode;
BOOL Cancel;
int iTActors;
///////////////////////////////////////////////////////////////////////////////

UINT iLevelWallVertical;
UINT iLevelWallHorizontal;

void CreatLevelWallLists(void)
{ // void CreatLevelWallLists()
	if(!Level || !Level->Exist)
		return;
	float fWallWidth = Level->fWallWidth;
	float fWallZHeight = Level->fWallZHeight;
	float fZFloor = Level->fZFloor;
	float fFieldWidth = Level->fFieldWidth;
	float fFieldHeight = Level->fFieldHeight;
	float fHalfWallWidth = fWallWidth/2;
	
	Level->SetGeneralLight();
	// The vertical wall:
	iLevelWallVertical = iASLists;
	iASLists++;
	glNewList(iLevelWallVertical, GL_COMPILE);
		glBegin(GL_QUADS);
			// Upper side:
			glNormal3f(0.0f, fFieldHeight/2, fZFloor+fWallZHeight+1.0f);
			glVertex3f(-fHalfWallWidth, 0.0f, fZFloor+fWallZHeight);
			glVertex3f(-fHalfWallWidth, fFieldHeight, fZFloor+fWallZHeight);
			glVertex3f(fHalfWallWidth, fFieldHeight, fZFloor+fWallZHeight);
			glVertex3f(fHalfWallWidth, 0.0f, fZFloor+fWallZHeight);
			// Left side:
			glNormal3f(-fHalfWallWidth-1.0f, fFieldHeight/2, fZFloor+(fWallZHeight/2));
			glVertex3f(-fHalfWallWidth, 0.0f, fZFloor);
			glVertex3f(-fHalfWallWidth, fFieldHeight, fZFloor);
			glVertex3f(-fHalfWallWidth, fFieldHeight, fZFloor+fWallZHeight);
			glVertex3f(-fHalfWallWidth, 0.0f, fZFloor+fWallZHeight);
			// Top side:
			glNormal3f(0.0f, 1.0f, fZFloor+(fWallZHeight/2));
			glVertex3f(-fHalfWallWidth, 0.0f, fZFloor);
			glVertex3f(-fHalfWallWidth, 0.0f, fZFloor+fWallZHeight);
			glVertex3f(fHalfWallWidth, 0.0f, fZFloor+fWallZHeight);
			glVertex3f(fHalfWallWidth, 0.0f, fZFloor);
			// Right side:
			glNormal3f(fHalfWallWidth+1.0f, fFieldHeight/2, fZFloor+(fWallZHeight/2));
			glVertex3f(fHalfWallWidth, 0.0f, fZFloor);
			glVertex3f(fHalfWallWidth, 0.0f, fZFloor+fWallZHeight);
			glVertex3f(fHalfWallWidth, fFieldHeight, fZFloor+fWallZHeight);
			glVertex3f(fHalfWallWidth, fFieldHeight, fZFloor);
			// Bottom side:
			glNormal3f(0.0f, fFieldHeight+1.0f, fZFloor+(fWallZHeight/2));
			glVertex3f(-fHalfWallWidth, fFieldHeight, fZFloor+fWallZHeight);
			glVertex3f(-fHalfWallWidth, fFieldHeight, fZFloor);
			glVertex3f(fHalfWallWidth, fFieldHeight, fZFloor);
			glVertex3f(fHalfWallWidth, fFieldHeight, fZFloor+fWallZHeight);
		glEnd();
	glEndList();
	// The horizontal wall:
	iLevelWallHorizontal = iASLists;
	iASLists++;
	glNewList(iLevelWallHorizontal, GL_COMPILE);
		glBegin(GL_QUADS);
			// Upper side:
			glNormal3f(fFieldWidth/2, 0.0f, fZFloor+fWallZHeight+1.0f);
			glVertex3f(0.0f, -fHalfWallWidth, fZFloor+fWallZHeight);
			glVertex3f(0.0f, fHalfWallWidth, fZFloor+fWallZHeight);
			glVertex3f(fFieldWidth, fHalfWallWidth, fZFloor+fWallZHeight);
			glVertex3f(fFieldWidth, -fHalfWallWidth, fZFloor+fWallZHeight);
			// Left side:
			glNormal3f(-1.0f, 0.0f, fZFloor+(fWallZHeight/2));
			glVertex3f(0.0f, -fHalfWallWidth, fZFloor+fWallZHeight);
			glVertex3f(0.0f, -fHalfWallWidth, fZFloor);
			glVertex3f(0.0f, fHalfWallWidth, fZFloor);
			glVertex3f(0.0f, fHalfWallWidth, fZFloor+fWallZHeight);
			// Top side:
			glNormal3f(0.0f, -fHalfWallWidth-1.0f, fZFloor+(fWallZHeight/2));
			glVertex3f(0.0f, -fHalfWallWidth, fZFloor);
			glVertex3f(0.0f, -fHalfWallWidth, fZFloor+fWallZHeight);
			glVertex3f(fFieldWidth, -fHalfWallWidth, fZFloor+fWallZHeight);
			glVertex3f(fFieldWidth, -fHalfWallWidth, fZFloor);
			// Right side:
			glNormal3f(fFieldWidth+1, 0.0f, fZFloor+(fWallZHeight/2));
			glVertex3f(fFieldWidth, -fHalfWallWidth, fZFloor);
			glVertex3f(fFieldWidth, -fHalfWallWidth, fZFloor+fWallZHeight);
			glVertex3f(fFieldWidth, fHalfWallWidth, fZFloor+fWallZHeight);
			glVertex3f(fFieldWidth, fHalfWallWidth, fZFloor);
			// Bottom side:
			glNormal3f(0.0f, fHalfWallWidth+1.0f, fZFloor+(fWallZHeight/2));
			glVertex3f(0.0f, fHalfWallWidth, fZFloor+fWallZHeight);
			glVertex3f(0.0f, fHalfWallWidth, fZFloor);
			glVertex3f(fFieldWidth, fHalfWallWidth, fZFloor);
			glVertex3f(fFieldWidth, fHalfWallWidth, fZFloor+fWallZHeight);
		glEnd();
	glEndList();
} // end CreatLevelWallLists()


LRESULT CALLBACK LAProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{ // begin LAProc()
    char byTemp[128];
	BOOL bState = TRUE, bState2 = TRUE;

	switch(message)
    {
        case WM_INITDIALOG:
			ShowWindow(hWnd, iCmdShow);
			UpdateWindow(hWnd);
           	sprintf(byASTemp, "(%d = no limit)", NO_LIMIT);
			SetDlgItemText(hWnd, ID_LA_NO_LIMIT_TEXT, byASTemp);
			switch(byLAMode)
			{
				case LA_SHOW:
           			SetDlgItemText(hWnd, ID_LA_MODE, "Level attributes (show)");
					bState = FALSE;
					bState2 = FALSE;
				break;	

				case LA_ADJUST:
           			SetDlgItemText(hWnd, ID_LA_MODE, "Level attributes (adjust)");
					bState2 = FALSE;
				break;	

				case LA_CREATE:
           			SetDlgItemText(hWnd, ID_LA_MODE, "Level attributes (create)");
					bState = TRUE;
					bState2 = TRUE;
				break;	
			}
			ShowWindow(GetDlgItem(hWnd, ID_LA_CANCEL), bState);
			EnableWindow(GetDlgItem(hWnd, ID_LA_LEVEL_FILE_NAME), bState);
			EnableWindow(GetDlgItem(hWnd, ID_LA_LEVEL_NAME), bState);
			EnableWindow(GetDlgItem(hWnd, ID_LA_LEVEL_WIDTH), bState2);
			EnableWindow(GetDlgItem(hWnd, ID_LA_LEVEL_HEIGHT), bState2);
			EnableWindow(GetDlgItem(hWnd, ID_LA_LEVEL_FLOOR_Z), bState);
			EnableWindow(GetDlgItem(hWnd, ID_LA_LEVEL_WALL_HEIGHT), bState);
			EnableWindow(GetDlgItem(hWnd, ID_LA_LEVEL_WALL_WIDTH), bState);
			EnableWindow(GetDlgItem(hWnd, ID_LA_LEVEL_WALL_RED), bState);
			EnableWindow(GetDlgItem(hWnd, ID_LA_LEVEL_WALL_GREEN), bState);
			EnableWindow(GetDlgItem(hWnd, ID_LA_LEVEL_WALL_BLUE), bState);
			EnableWindow(GetDlgItem(hWnd, ID_LA_FIELD_WIDTH), bState);
			EnableWindow(GetDlgItem(hWnd, ID_LA_FIELD_HEIGHT), bState);
			EnableWindow(GetDlgItem(hWnd, ID_LA_LEVEL_MAX_ACTORS), bState2);
			EnableWindow(GetDlgItem(hWnd, ID_LA_LEVEL_TIME_LIMIT), bState);
			EnableWindow(GetDlgItem(hWnd, ID_LA_MISSION_COLLECT_ALL_DIAMONDS), bState);
			EnableWindow(GetDlgItem(hWnd, ID_LA_MISSION_KILL_ALL_ENEMYS), bState);
			EnableWindow(GetDlgItem(hWnd, ID_LA_MISSION_KILL_NO_ENEMYS), bState);
			EnableWindow(GetDlgItem(hWnd, ID_LA_MISSION_IGNORE_ENEMYS), bState);
			EnableWindow(GetDlgItem(hWnd, ID_LA_MISSION_REINCARNATION_FINISH), bState);
            // Level name:
			SetDlgItemText(hWnd, ID_LA_LEVEL_FILE_NAME, pTLevel->byFileName);
            // Level name:
			SetDlgItemText(hWnd, ID_LA_LEVEL_NAME, pTLevel->pbyName);
            // Level seize:
			sprintf(byTemp, "%d", pTLevel->iWidth);
			SetDlgItemText(hWnd, ID_LA_LEVEL_WIDTH, byTemp);
			sprintf(byTemp, "%d", pTLevel->iHeight);
            SetDlgItemText(hWnd, ID_LA_LEVEL_HEIGHT, byTemp);
            // Floor z pos:
			sprintf(byTemp, "%.2f", pTLevel->fZFloor);
			SetDlgItemText(hWnd, ID_LA_LEVEL_FLOOR_Z, byTemp);
            // Wall height:
			sprintf(byTemp, "%.2f", pTLevel->fWallZHeight);
			SetDlgItemText(hWnd, ID_LA_LEVEL_WALL_HEIGHT, byTemp);
            // Wall width:
			sprintf(byTemp, "%.2f", pTLevel->fWallWidth);
			SetDlgItemText(hWnd, ID_LA_LEVEL_WALL_WIDTH, byTemp);
            // Time limit:
			sprintf(byTemp, "%d", pTLevel->iTimeLimit);
			SetDlgItemText(hWnd, ID_LA_LEVEL_TIME_LIMIT, byTemp);
            // General color:
			sprintf(byTemp, "%.2f", pTLevel->fGeneralRed);
			SetDlgItemText(hWnd, ID_LA_LEVEL_GENERAL_RED, byTemp);
			sprintf(byTemp, "%.2f", pTLevel->fGeneralGreen);
			SetDlgItemText(hWnd, ID_LA_LEVEL_GENERAL_GREEN, byTemp);
			sprintf(byTemp, "%.2f", pTLevel->fGeneralBlue);
			SetDlgItemText(hWnd, ID_LA_LEVEL_GENERAL_BLUE, byTemp);
            // Wall color:
			sprintf(byTemp, "%.2f", pTLevel->fWallRed);
			SetDlgItemText(hWnd, ID_LA_LEVEL_WALL_RED, byTemp);
			sprintf(byTemp, "%.2f", pTLevel->fWallGreen);
			SetDlgItemText(hWnd, ID_LA_LEVEL_WALL_GREEN, byTemp);
			sprintf(byTemp, "%.2f", pTLevel->fWallBlue);
			SetDlgItemText(hWnd, ID_LA_LEVEL_WALL_BLUE, byTemp);
            // Field seize:
			sprintf(byTemp, "%.2f", pTLevel->fFieldWidth);
			SetDlgItemText(hWnd, ID_LA_FIELD_WIDTH, byTemp);
			sprintf(byTemp, "%.2f", pTLevel->fFieldHeight);
            SetDlgItemText(hWnd, ID_LA_FIELD_HEIGHT, byTemp);
			// Max Actors:
			sprintf(byTemp, "%d", iTActors);
			SetDlgItemText(hWnd, ID_LA_LEVEL_MAX_ACTORS, byTemp);
			// Missions:
			SendDlgItemMessage(hWnd, ID_LA_MISSION_COLLECT_ALL_DIAMONDS, BM_SETCHECK, pTLevel->bMissionCollectAllDiamonds, 0L);
			SendDlgItemMessage(hWnd, ID_LA_MISSION_REINCARNATION_FINISH, BM_SETCHECK, pTLevel->bMissionGoToReincarnationWhenDone, 0L);
			if(pTLevel->bMissionKillAllEnemys && pTLevel->bMissionKillNoEnemys)
			{ // Kill all and be no murder? H���H??! 
				pTLevel->bMissionKillAllEnemys = FALSE;
				pTLevel->bMissionKillNoEnemys = FALSE;
			}
			if(pTLevel->bMissionKillAllEnemys)
				CheckRadioButton(hWnd, ID_LA_MISSION_KILL_ALL_ENEMYS, ID_LA_MISSION_IGNORE_ENEMYS, ID_LA_MISSION_KILL_ALL_ENEMYS);
			else
			if(pTLevel->bMissionKillNoEnemys)
				CheckRadioButton(hWnd, ID_LA_MISSION_KILL_ALL_ENEMYS, ID_LA_MISSION_IGNORE_ENEMYS, ID_LA_MISSION_KILL_NO_ENEMYS);
			else
				CheckRadioButton(hWnd, ID_LA_MISSION_KILL_ALL_ENEMYS, ID_LA_MISSION_IGNORE_ENEMYS, ID_LA_MISSION_IGNORE_ENEMYS);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_LA_OK:
                    // Level name:
					GetDlgItemText(hWnd, ID_LA_LEVEL_FILE_NAME, pTLevel->byFileName, MAX_PATH);
					GetDlgItemText(hWnd, ID_LA_LEVEL_NAME, byTemp, 128);
					if(pTLevel->pbyName)
						free(pTLevel->pbyName);
					pTLevel->pbyName = (char *) malloc(strlen(byTemp)+1);
					strcpy(pTLevel->pbyName, byTemp);
                    // Level seize:
					GetDlgItemText(hWnd, ID_LA_LEVEL_WIDTH, byTemp, 5);
					pTLevel->iWidth = atoi(byTemp);
                    GetDlgItemText(hWnd, ID_LA_LEVEL_HEIGHT, byTemp, 5);
					pTLevel->iHeight = atoi(byTemp);
                    // Floor z pos:
					GetDlgItemText(hWnd, ID_LA_LEVEL_FLOOR_Z, byTemp, 5);
					pTLevel->fZFloor = (float) atof(byTemp);
                    // Wall height:
					GetDlgItemText(hWnd, ID_LA_LEVEL_WALL_HEIGHT, byTemp, 5);
					pTLevel->fWallZHeight = (float) atof(byTemp);
                    // Wall width:
					GetDlgItemText(hWnd, ID_LA_LEVEL_WALL_WIDTH, byTemp, 5);
					pTLevel->fWallWidth = (float) atof(byTemp);
                    // Time limit:
					GetDlgItemText(hWnd, ID_LA_LEVEL_TIME_LIMIT, byTemp, 5);
					pTLevel->iTimeLimit = atoi(byTemp);
                    // General color:
					GetDlgItemText(hWnd, ID_LA_LEVEL_GENERAL_RED, byTemp, 5);
					pTLevel->fGeneralRed = (float) atof(byTemp);
					GetDlgItemText(hWnd, ID_LA_LEVEL_GENERAL_GREEN, byTemp, 5);
					pTLevel->fGeneralGreen = (float) atof(byTemp);
					GetDlgItemText(hWnd, ID_LA_LEVEL_GENERAL_BLUE, byTemp, 5);
					pTLevel->fGeneralBlue = (float) atof(byTemp);
                    // Wall color:
					GetDlgItemText(hWnd, ID_LA_LEVEL_WALL_RED, byTemp, 5);
					pTLevel->fWallRed = (float) atof(byTemp);
					GetDlgItemText(hWnd, ID_LA_LEVEL_WALL_GREEN, byTemp, 5);
					pTLevel->fWallGreen = (float) atof(byTemp);
					GetDlgItemText(hWnd, ID_LA_LEVEL_WALL_BLUE, byTemp, 5);
					pTLevel->fWallBlue = (float) atof(byTemp);
                    // Field seize:
					GetDlgItemText(hWnd, ID_LA_FIELD_WIDTH, byTemp, 5);
					pTLevel->fFieldWidth = (float) atof(byTemp);
                    GetDlgItemText(hWnd, ID_LA_FIELD_HEIGHT, byTemp, 5);
					pTLevel->fFieldHeight = (float) atof(byTemp);
					// Max Actors:
					GetDlgItemText(hWnd, ID_LA_LEVEL_MAX_ACTORS, byTemp, 5);
					iTActors = atoi(byTemp);
				// Missions:
					pTLevel->bMissionCollectAllDiamonds = SendDlgItemMessage(hWnd, ID_LA_MISSION_COLLECT_ALL_DIAMONDS, BM_GETCHECK, 0, 0L);
					pTLevel->bMissionGoToReincarnationWhenDone = SendDlgItemMessage(hWnd, ID_LA_MISSION_REINCARNATION_FINISH, BM_GETCHECK, 0, 0L);
					pTLevel->bMissionKillAllEnemys = FALSE;
					pTLevel->bMissionKillNoEnemys = FALSE;
		            if(IsDlgButtonChecked(hWnd, ID_LA_MISSION_KILL_ALL_ENEMYS))
						pTLevel->bMissionKillAllEnemys = TRUE;
		            if(IsDlgButtonChecked(hWnd, ID_LA_MISSION_KILL_NO_ENEMYS))
						pTLevel->bMissionKillNoEnemys = TRUE;
					Cancel = FALSE;
					EndDialog(hWnd, FALSE);
                return TRUE;

				case ID_LA_CANCEL:
					Cancel = TRUE;
					EndDialog(hWnd, FALSE);
                return TRUE;
            }
            break;
    }
    return FALSE; 
} // end LAProc()

HRESULT OpenLADialog(LEVEL **pLevel, char byMode) // LA = Level attributes
{ // begin OpenLADialog()
	char *pbyTemp;
	int iTempActors;

	if(!(*pLevel))
		return AS_ERROR_NONE;		
	if(Camera)
		Camera->NoVelocity();
	bProgramActive = FALSE;
	byLAMode = byMode;
	pTLevel = (LEVEL *) calloc(1, sizeof(LEVEL));
	if(byMode == LA_CREATE)
	{
		// Sets the level attributes to standart.
		pTLevel->SetStandartA();
	}
	else
	{                            
		memcpy(pTLevel, *pLevel, sizeof(**pLevel));
		pTLevel->pbyName = (char *) malloc(strlen((*pLevel)->pbyName)+1);
		strcpy(pTLevel->pbyName, (*pLevel)->pbyName);
		iTActors = iActors;
	}
	DialogBox(hInstance, MAKEINTRESOURCE(ID_LA), hWndMain, (DLGPROC) LAProc);
	if(byMode != LA_SHOW)
	{ // OK or CANCEL?
		if(Cancel)
		{ // Forget all!
			if(pTLevel->pbyName)
				free(pTLevel->pbyName);
			free(pTLevel);
		}
		else
		{ // OK:
			if(byMode == LA_CREATE)
			{
				DestroyLevel(pLevel);
				iTempActors = iActors;
				CreateActorList(&Actor, iTActors);
				iActors = iTempActors;
				CreateActorList(&TextActor, iTActors);
				*pLevel = pTLevel;
				(*pLevel)->Exist = TRUE;
				pbyTemp = (char *) malloc(strlen((*pLevel)->pbyName)+1);
				strcpy(pbyTemp, (*pLevel)->pbyName);
				(*pLevel)->Create(pbyTemp,
								  (*pLevel)->iWidth,
								  (*pLevel)->iHeight,
								  (*pLevel)->fFieldWidth,
								  (*pLevel)->fFieldHeight,
								  (*pLevel)->fZFloor,
								  (*pLevel)->fWallZHeight);
				free(pbyTemp);
				pbyTemp = NULL;
			}
			else
			{ // We give the old level new parameter:
			  // Not all, only the unimportant! (memory..)	
				// Level name:
				strcpy((*pLevel)->byFileName, pTLevel->byFileName);
				if((*pLevel)->pbyName)
					free((*pLevel)->pbyName);
				(*pLevel)->pbyName = pTLevel->pbyName;
				// Floor z pos:
				(*pLevel)->fZFloor = pTLevel->fZFloor;
				// Wall z height:
				(*pLevel)->fWallZHeight = pTLevel->fWallZHeight;
				// Wall width:
				(*pLevel)->fWallWidth = pTLevel->fWallWidth;
				// Time limit:
				(*pLevel)->iTimeLimit = pTLevel->iTimeLimit;
				// General light:
				(*pLevel)->fGeneralRed = pTLevel->fGeneralRed;
				(*pLevel)->fGeneralGreen = pTLevel->fGeneralGreen;
				(*pLevel)->fGeneralBlue = pTLevel->fGeneralBlue;
				// Wall color:
				(*pLevel)->fWallRed = pTLevel->fWallRed;
				(*pLevel)->fWallGreen = pTLevel->fWallGreen;
				(*pLevel)->fWallBlue = pTLevel->fWallBlue;
				// Field seize:
				(*pLevel)->fFieldWidth = pTLevel->fFieldWidth;
				(*pLevel)->fFieldHeight = pTLevel->fFieldHeight;
				// Missions:
				(*pLevel)->bMissionCollectAllDiamonds = pTLevel->bMissionCollectAllDiamonds;
				(*pLevel)->bMissionKillAllEnemys = pTLevel->bMissionKillAllEnemys;
				(*pLevel)->bMissionKillNoEnemys = pTLevel->bMissionKillNoEnemys;
				(*pLevel)->bMissionGoToReincarnationWhenDone = pTLevel->bMissionGoToReincarnationWhenDone;
				free(pTLevel);
				(*pLevel)->CalculatePoints();
			}
		}
	}
	bProgramActive = TRUE;
	(*pLevel)->fWidth = (*pLevel)->fFieldWidth*(*pLevel)->iWidth;
	(*pLevel)->fHeight= (*pLevel)->fFieldHeight*(*pLevel)->iHeight;
	CreateAllLists();
	return AS_ERROR_NONE;
} // end OpenLADialog()

HRESULT CreateLevel(LEVEL **pLevel)
{ // begin CreateLevel()
	if(*pLevel)
		DestroyLevel(pLevel);
	*pLevel = (LEVEL *) calloc(1, sizeof(LEVEL));
	return AS_ERROR_NONE;
} // end CreateLevel()

HRESULT DestroyLevel(LEVEL **pLevel)
{ // begin DestroyLevel()
	if(*pLevel)
	{
		(*pLevel)->Destroy();
		free(*pLevel);
	}
	*pLevel = NULL;
	return AS_ERROR_NONE;
} // end DestroyLevel()

// Class functions:
void LEVEL::SetStandartA(void)
{ // begin SetStandartA()
	if(pbyName)
		free(pbyName);
	pbyName = NULL;
	pbyName = (char *) malloc(strlen(LEVEL_S_NAME)+1);
	strcpy(pbyName, LEVEL_S_NAME);
	iWidth = LEVEL_S_WIDTH;
	iHeight = LEVEL_S_HEIGHT;
	fZFloor = LEVEL_S_FLOOR_Z;
	fWallZHeight = LEVEL_S_WALL_Z_HEIGHT;
	fWallWidth = LEVEL_S_WALL_WIDTH;
	fFieldWidth = LEVEL_FIELD_S_WIDTH;
	fFieldHeight = LEVEL_FIELD_S_HEIGHT;
	iTActors = MAX_ACTORS;
	iTimeLimit = LEVEL_S_TIME_LIMIT;
	fGeneralRed = LEVEL_LEVEL_GENERAL_RED;
	fGeneralGreen = LEVEL_LEVEL_GENERAL_GREEN;
	fGeneralBlue = LEVEL_LEVEL_GENERAL_BLUE;
	fWallRed = LEVEL_LEVEL_WALL_RED;
	fWallGreen = LEVEL_LEVEL_WALL_GREEN;
	fWallBlue = LEVEL_LEVEL_WALL_BLUE;
} // end SetStandartA() 

HRESULT LEVEL::SwitchWall(int x, int y, char WallNr)	
{ // begin LEVEL::SwitchWall()
	if(!Field)
		return AS_ERROR_NONE;
	if(x < 0 || y < 0 || x > iWidth-1 || y > iHeight-1 || 
	  WallNr < 0 || WallNr > 3)
		return 1;
	Field[x][y].Wall[WallNr] = !Field[x][y].Wall[WallNr];
	switch(WallNr)
	{
		case LEFT:
			if(x-1 < 0)
				break;
			Field[x-1][y].Wall[RIGHT] = !Field[x-1][y].Wall[RIGHT];
		break;

		case TOP:
			if(y-1 < 0)
				break;
			Field[x][y-1].Wall[BOTTOM] = !Field[x][y-1].Wall[BOTTOM];
		break;

		case RIGHT:
			if(x+1 > iWidth-1)
				break;
			Field[x+1][y].Wall[LEFT] = !Field[x+1][y].Wall[LEFT];
		break;

		case BOTTOM:
			if(y+1 >iHeight-1)
				break;
			Field[x][y+1].Wall[TOP] = !Field[x][y+1].Wall[TOP];
		break;
	}
	return AS_ERROR_NONE;
} // end LEVEL::SwitchWall()

HRESULT LEVEL::SetWall(int x, int y, char WallNr)	
{ // begin LEVEL::SetWall()
	if(!Field)
		return AS_ERROR_NONE;
	if(x < 0 || y < 0 || x > iWidth-1 || y > iHeight-1 || 
	  WallNr < 0 || WallNr > 3)
		return 1;
	Field[x][y].Wall[WallNr] = TRUE;
	switch(WallNr)
	{
		case LEFT:
			if(x-1 < 0)
				break;
			Field[x-1][y].Wall[RIGHT] = TRUE;
		break;

		case TOP:
			if(y-1 < 0)
				break;
			Field[x][y-1].Wall[BOTTOM] = TRUE;
		break;

		case RIGHT:
			if(x+1 > iWidth-1)
				break;
			Field[x+1][y].Wall[LEFT] = TRUE;
		break;

		case BOTTOM:
			if(y+1 >iHeight-1)
				break;
			Field[x][y+1].Wall[TOP] = TRUE;
		break;
	}
	return AS_ERROR_NONE;
} // end LEVEL::SetWall()

HRESULT LEVEL::DestroyWall(int x, int y, char WallNr)	
{ // begin LEVEL::DestroyWall()
	if(!Field)
		return AS_ERROR_NONE;
	if(x < 0 || y < 0 || x > iWidth-1 || y > iHeight-1 || 
	  WallNr < 0 || WallNr > 3)
		return 1;
	Field[x][y].Wall[WallNr] = FALSE;
	switch(WallNr)
	{
		case LEFT:
			if(x-1 < 0)
				break;
			Field[x-1][y].Wall[RIGHT] = FALSE;
		break;

		case TOP:
			if(y-1 < 0)
				break;
			Field[x][y-1].Wall[BOTTOM] = FALSE;
		break;

		case RIGHT:
			if(x+1 > iWidth-1)
				break;
			Field[x+1][y].Wall[LEFT] = FALSE;
		break;

		case BOTTOM:
			if(y+1 >iHeight-1)
				break;
			Field[x][y+1].Wall[TOP] = FALSE;
		break;
	}
	return AS_ERROR_NONE;
} // end LEVEL::DestroyWall()


HRESULT LEVEL::Create(char *pbyLevelName, int iLevelWidth, int iLevelHeight, 
					  float fLevelFieldWidth, float fLevelFieldHeight,
					  float fLevelZFloor, float fLevelWallZHeight)
{ // begin LEVEL::Create()
	int i, i2, i3;
	FIELD *tempF;
	
	if(Exist) 
		Destroy(); // Destroy old Level
	if(pbyName)
		free(pbyName);
    strcpy(byFileName, "\0");
	pbyName = NULL;
	pbyName = (char *) malloc(strlen(pbyLevelName)+1);
	strcpy(pbyName, pbyLevelName);
	fZFloor = fLevelZFloor;
	fWallZHeight = fLevelWallZHeight;
	iWidth = iLevelWidth; iHeight = iLevelHeight;
	fFieldWidth = fLevelFieldWidth; fFieldHeight = fLevelFieldHeight;
	fWallWidth = (float) (((fFieldWidth+fFieldHeight)/2)/10);
	iFields = iWidth*iHeight; FieldPoints = (iWidth+1)*(iHeight+1);
	fWidth = fFieldWidth*iWidth;
	fHeight= fFieldHeight*iHeight;
	iTotalDiamonds = 0;
	iTotalEnemys = 0;
	bMissionCollectAllDiamonds = TRUE;
	bMissionCollectAllDiamondsSuccess = FALSE;
	bMissionKillAllEnemys = FALSE;
	bMissionKillAllEnemysSuccess = FALSE;
	bMissionKillNoEnemys = FALSE;
	bMissionKillNoEnemysFailed = FALSE;
	// Points:
	if(!(FieldPoint = (FIELD_POINT **) malloc(sizeof(FIELD_POINT)*(iWidth+1))))
	{
		return 1;
	}
	for(i = 0; i < iWidth+1; i++)
		if(!(FieldPoint[i] = (FIELD_POINT *) malloc(sizeof(FIELD_POINT)*(iHeight+1))))
			return 1;
	CalculatePoints();
	// Fields:
	if(!(Field = (FIELD **) malloc(sizeof(FIELD)*iWidth)))
	{
		return 1;
	}
	for(i = 0; i < iWidth; i++)
	{
		if(!(Field[i] = (FIELD *) malloc(sizeof(FIELD)*iHeight)))
		{
			return 1;
		}
		for(i2 = 0; i2 < iHeight; i2++)
		{	
			Field[i][i2].x = i; Field[i][i2].y = i2;	
		}
	}	
	// Fields Setup:
	for(i2 = 0; i2 < iHeight; i2++)
		for(i = 0; i < iWidth; i++)
		{
			tempF = &Field[i][i2];
			tempF->Point[LEFT_TOP] = &FieldPoint[i][i2];
			tempF->Point[RIGHT_TOP] = &FieldPoint[i+1][i2];
			tempF->Point[RIGHT_BOTTOM] = &FieldPoint[i+1][i2+1];
			tempF->Point[LEFT_BOTTOM] = &FieldPoint[i][i2+1];
			for(i3 = 0; i3 < 4; i3++)
				tempF->Wall[i3] = FALSE;
		}
	// Level outline:
	for(i = 0; i < iHeight; i++) // Left
		Field[0][i].Wall[LEFT] = TRUE;
	for(i = 0; i < iWidth; i++) // Top
		Field[i][0].Wall[TOP] = TRUE;
	for(i = 0; i < iHeight; i++) // Right
		Field[iWidth-1][i].Wall[RIGHT] = TRUE;
	for(i = 0; i < iWidth; i++) // Bottom
		Field[i][iHeight-1].Wall[BOTTOM] = TRUE;
	Exist = TRUE;
	return AS_ERROR_NONE;	
} // end LEVEL::Create()

HRESULT LEVEL::Destroy(void)
{ // begin LEVEL::Destroy()
	int i;

	if(pbyName)
		free(pbyName);
	pbyName = NULL;
	if(FieldPoint)
	{
		for(i = 0; i < (iWidth+1); i++)
		{
			if(FieldPoint[i])
				free(FieldPoint[i]);
		}
		if(FieldPoint)
			free(FieldPoint);
		FieldPoint = NULL;
	}
	if(Field)
	{
		for(i = 0; i < iWidth; i++)
		{
			if(Field[i])
				free(Field[i]);
		}
		if(Field)
			free(Field);
		Field = NULL;
	}
	Exist = FALSE;
	return AS_ERROR_NONE;	
} // end LEVEL::Destroy()

void LEVEL::CalculatePoints(void)
{ // begin LEVEL::CalculatePoints()
	int i, i2;
	float xLevelPos, yLevelPos;
	FIELD_POINT *tempFP;

	if(!FieldPoint)
		return;
	for(i = 0, xLevelPos = 0; i < iWidth+1; i++, xLevelPos += fFieldWidth)
	{
		for(i2 = 0, yLevelPos = 0; i2 < iHeight+1; i2++, yLevelPos += fFieldHeight)
		{	
			if(!FieldPoint[i2])
				continue;;
			tempFP = &FieldPoint[i][i2];
			tempFP->x = i; tempFP->y = i2;
			tempFP->xpos = xLevelPos; tempFP->ypos = yLevelPos; 
		}
	}	
} // end LEVEL::CalculatePoints()

HRESULT LEVEL::Draw(AS_CAMERA *pCamera)
{ // begin LEVEL::Draw()
	int x, y;
	FIELD *tField; 

	glPolygonMode(GL_FRONT, GL_FILL);
	glPolygonMode(GL_BACK, GL_POINT);
	glDisable(GL_TEXTURE_2D);
	if(Config.byLight)
		glEnable(GL_LIGHTING);
	glEnable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);
	pCamera->SetScene();
	glColor4f(fWallRed, fWallGreen, fWallBlue, 0.5f);
	for(y = 0; y < iHeight; y++)
	{
		for(x = 0; x < iWidth; x++)
		{	
			tField = &Field[x][y];
			if(tField->Wall[LEFT])
				glCallList(iLevelWallVertical);
			if(tField->Wall[TOP])
				glCallList(iLevelWallHorizontal);
			glTranslatef(fFieldWidth, 0.0f, 0.0f);
		}
		glTranslatef(-fWidth, 0.0f, 0.0f);
		glTranslatef(0.0f, fFieldHeight, 0.0f);
	}
	pCamera->SetScene();
	glTranslatef(0.0f, fHeight, 0.0f);
	// Draw the last x and the last y walls:
	for(x = 0; x < iWidth; x++)
	{	
		tField = &Field[x][iHeight-1];
		if(tField->Wall[BOTTOM])
			glCallList(iLevelWallHorizontal);
		glTranslatef(fFieldWidth, 0.0f, 0.0f);
	}
	pCamera->SetScene();
	glTranslatef(fWidth, 0.0f, 0.0f);
	for(y = 0; y < iHeight; y++)
	{	
		tField = &Field[iWidth-1][y];
		if(tField->Wall[RIGHT])
			glCallList(iLevelWallVertical);
		glTranslatef(0.0f, fFieldHeight, 0.0f);
	}
	return AS_ERROR_NONE;	
} // end LEVEL::Draw()*/

HRESULT LEVEL::Load(char *pbyFileName, void ***pVActor)
{ // begin LEVEL::Load()
	FILE *File;
	char temp[256];
	char byTempName[256];
	int iTempWidth, iTempHeight, i;
	float fTempFieldWidth, fTempFieldHeight, fTempFloorZ, fTempWallHeight;
	int iCounter = 0, iCounter2, iLineCounter, iTempActors, iActorC;
	char *pbyTempLine;	
	BOOL bLine;
	ACTOR ***pActor = (ACTOR ***) pVActor;

	// Loads the level header:
	GetPrivateProfileString("General", "name", "NoName", byTempName, MAX_PATH, pbyFileName);
	iTempWidth = GetPrivateProfileInt("General", "width", 20, pbyFileName);
	iTempHeight = GetPrivateProfileInt("General", "height", 20, pbyFileName);
	GetPrivateProfileString("General", "field_width", "1.0", byASTemp, MAX_PATH, pbyFileName);
	fTempFieldWidth = (float) atof(byASTemp);
	GetPrivateProfileString("General", "field_height", "1.0", byASTemp, MAX_PATH, pbyFileName);
	fTempFieldHeight = (float) atof(byASTemp);
	GetPrivateProfileString("General", "floor_z", "0.0", byASTemp, MAX_PATH, pbyFileName);
	fTempFloorZ = (float) atof(byASTemp);
	GetPrivateProfileString("General", "wall_height", "0.2", byASTemp, MAX_PATH, pbyFileName);
	fTempWallHeight = (float) atof(byASTemp);
	if(!pbyFileName)
		return AS_ERROR_NONE;
	File = fopen(pbyFileName, "rt");
	if(!File)
		return AS_ERROR_FILE_OPEN;
	iTempActors = iActors;
	DestroyActorList(pActor);
	iActors = iTempActors;
	DestroyActorList(&TextActor);
	if(Exist) 
		Destroy(); // Destroy old Level
	// Create the level:
	Create(byTempName, iTempWidth, iTempHeight, fTempFieldWidth, 
		   fTempFieldHeight, fTempFloorZ, fTempWallHeight);
    strcpy(byFileName, pbyFileName);
	pbyTempLine = (char *) malloc(iWidth+2);
	// Missions:
	bMissionCollectAllDiamonds = GetPrivateProfileInt("General", "mission_collect_all_diamonds", 1, pbyFileName);
	bMissionKillAllEnemys = GetPrivateProfileInt("General", "mission_kill_all_enemys", 0, pbyFileName);
	bMissionKillNoEnemys = GetPrivateProfileInt("General", "mission_kill_no_enemys", 0, pbyFileName);
	bMissionGoToReincarnationWhenDone = GetPrivateProfileInt("General", "mission_go_to_reincarnation", 1, pbyFileName);
	//
	iTimeLimit = GetPrivateProfileInt("General", "time_limit", 300, pbyFileName);
	GetPrivateProfileString("General", "general_red", "0.5", byASTemp, MAX_PATH, pbyFileName);
	fGeneralRed = (float) atof(byASTemp);
	GetPrivateProfileString("General", "general_green", "0.5", byASTemp, MAX_PATH, pbyFileName);
	fGeneralGreen = (float) atof(byASTemp);
	GetPrivateProfileString("General", "general_blue", "0.5", byASTemp, MAX_PATH, pbyFileName);
	fGeneralBlue = (float) atof(byASTemp);
	GetPrivateProfileString("General", "wall_red", "0.5", byASTemp, MAX_PATH, pbyFileName);
	fWallRed = (float) atof(byASTemp);
	GetPrivateProfileString("General", "wall_green", "0.5", byASTemp, MAX_PATH, pbyFileName);
	fWallGreen = (float) atof(byASTemp);
	GetPrivateProfileString("General", "wall_blue", "0.5", byASTemp, MAX_PATH, pbyFileName);
	fWallBlue = (float) atof(byASTemp);
	if(bMissionKillAllEnemys && bMissionKillNoEnemys)
	{ // Kill all and be no murder? H���H??! 
		bMissionKillAllEnemys = bMissionKillNoEnemys = FALSE;
	}
	// Loads the level data:
    do
	{
		if(!feof(File)) fscanf(File,"%s",temp); else break;
		if(feof(File)) break;
		
		if((strlen(temp)>=2) && (temp[0]=='/') && (temp[1]=='/') ) 
			ASSetAfterNextToken(File, '\n'); 
		else		
		if(!strcmp(temp, "structure:")) 
		{ // Load the level structure:
		  // Goes through each line:
			for(bLine = 0, iLineCounter = 0, iCounter = 0; iCounter < (iHeight*2)+1; iCounter++)
			{
				if(!feof(File)) fscanf(File,"%s",pbyTempLine); else break;
				if(feof(File)) break;
				
				if((strlen(pbyTempLine)>=2) && (pbyTempLine[0]=='/') && (pbyTempLine[1]=='/') ) 
					ASSetAfterNextToken(File, '\n'); 
				else
				{
					for(iCounter2 = 0; iCounter2 < iWidth+1; iCounter2++)
					{
						if(!bLine)
						{ // We read the y Walls (----):
							if(iCounter2 == iWidth)
								continue;
							if(iLineCounter == iHeight)
							{ // This is the last Field row:
								if(pbyTempLine[iCounter2] == 'X')
									SetWall(iCounter2, iLineCounter-1, BOTTOM);
								if(pbyTempLine[iCounter2] == '0')
									DestroyWall(iCounter2, iLineCounter-1, BOTTOM);
							}
							else
							{ 
								if(pbyTempLine[iCounter2] == 'X')
									SetWall(iCounter2, iLineCounter, TOP);
								if(pbyTempLine[iCounter2] == '0')
									DestroyWall(iCounter2, iLineCounter, TOP);
							}
						}
						else
						{ // We read the x Walls (||||):
							if(iLineCounter == iHeight)
								continue;
							if(iCounter2 == iWidth)
							{ // This is the last Field:
								if(pbyTempLine[iCounter2] == 'X')
									SetWall(iCounter2-1, iLineCounter, RIGHT);
								if(pbyTempLine[iCounter2] == '0')
									DestroyWall(iCounter2-1, iLineCounter, RIGHT);
							}
							else
							{
								if(pbyTempLine[iCounter2] == 'X')
									SetWall(iCounter2, iLineCounter, LEFT);
								if(pbyTempLine[iCounter2] == '0')
									DestroyWall(iCounter2, iLineCounter, LEFT);
							}
						}
					}
					bLine = !bLine;
					if(!bLine)
						iLineCounter++;
				}
			}
		}
		else
		if(!strcmp(temp, "actors")) 
		{ // Creates the actor list, it's important, that this done 
		  // before the actor definiations starts!
			iTempActors = ASGetAfterTokenNum(File, '=');
			CreateActorList(&(*pActor), iTempActors);
			iActors = 0;
			CreateActorList(&TextActor, iTempActors);
			for(i = 0; i < iTempActors; i++)
				CreateActor(&TextActor[i]);
			iActorC = 0;
		}
		if(!strcmp(temp, "start_actor"))
		{ // Load the Actor:
			if(!pActor || iActorC >= iTempActors)
				continue;
			CreateActor(&(*pActor)[iActorC]);
			(*pActor)[iActorC]->iID = iActorC;
			(*pActor)[iActorC]->bActive = TRUE;
			do
			{
				if(!feof(File)) fscanf(File,"%s",temp); else break;
				if(feof(File)) break;
				
				if((strlen(temp)>=2) && (temp[0]=='/') && (temp[1]=='/') ) 
					ASSetAfterNextToken(File, '\n'); 
				else		
				if(!strcmp(temp, "end_actor")) {
					break;
				}
				if(!strcmp(temp, "type")) {
					strcpy(temp, ASGetAfterTokenStr(File, '='));
					if(!strcmp(temp, "actor_player"))
						(*pActor)[iActorC]->iType = ACTOR_PLAYER;
					else
					if(!strcmp(temp, "actor_e_fool"))
					{
						(*pActor)[iActorC]->iType = ACTOR_E_FOOL;
						iTotalEnemys++;
					}
					else
					if(!strcmp(temp, "actor_e_normal"))
					{
						(*pActor)[iActorC]->iType = ACTOR_E_NORMAL;
						iTotalEnemys++;
					}
					else
					if(!strcmp(temp, "actor_e_terminator"))
					{
						(*pActor)[iActorC]->iType = ACTOR_E_TERMINATOR;
						iTotalEnemys++;
					}
					else
					if(!strcmp(temp, "actor_p_reincarnation"))
						(*pActor)[iActorC]->iType = ACTOR_P_REINCARNATION;
					else
					if(!strcmp(temp, "actor_e_reincarnation"))
						(*pActor)[iActorC]->iType = ACTOR_E_REINCARNATION;
					else
					if(!strcmp(temp, "actor_diamond"))
					{
						(*pActor)[iActorC]->iType = ACTOR_DIAMOND;
						iTotalDiamonds++;
					}
					else
					if(!strcmp(temp, "actor_fruit_1"))
						(*pActor)[iActorC]->iType = ACTOR_FRUIT_1;
					else
					if(!strcmp(temp, "actor_hero"))
						(*pActor)[iActorC]->iType = ACTOR_HERO;
					else
					if(!strcmp(temp, "actor_bomb"))
						(*pActor)[iActorC]->iType = ACTOR_BOMB;
					else
					if(!strcmp(temp, "actor_hourglass"))
						(*pActor)[iActorC]->iType = ACTOR_HOURGLASS;
					else
					if(!strcmp(temp, "actor_freeze"))
						(*pActor)[iActorC]->iType = ACTOR_FREEZE;
					else
					if(!strcmp(temp, "actor_ghost"))
						(*pActor)[iActorC]->iType = ACTOR_GHOST;
					else
					if(!strcmp(temp, "actor_speed"))
						(*pActor)[iActorC]->iType = ACTOR_SPEED;
					// Gives the actor the right look:
					(*pActor)[iActorC]->pLook = pActorLook[(*pActor)[iActorC]->iType];
				}
				else
				if(!strcmp(temp, "xpos")) {
					(*pActor)[iActorC]->iXPos = (*pActor)[iActorC]->iSXPos = ASGetAfterTokenNum(File, '=');
				}
				else
				if(!strcmp(temp, "ypos")) {
					(*pActor)[iActorC]->iYPos = (*pActor)[iActorC]->iSYPos = ASGetAfterTokenNum(File, '=');
				}
				else
				if(!strcmp(temp, "xscale")) {
					(*pActor)[iActorC]->fScale[X] = ASGetAfterTokenNumF(File, '=');
				}
				else
				if(!strcmp(temp, "yscale")) {
					(*pActor)[iActorC]->fScale[Y] = ASGetAfterTokenNumF(File, '=');
				}
				else
				if(!strcmp(temp, "zscale")) {
					(*pActor)[iActorC]->fScale[Z] = ASGetAfterTokenNumF(File, '=');
				}
				else
				if(!strcmp(temp, "velocity")) {
					(*pActor)[iActorC]->fVelocity = ASGetAfterTokenNumF(File, '=');
				}
				else
				if(!strcmp(temp, "direction")) {
					strcpy(temp, ASGetAfterTokenStr(File, '='));
					if(!strcmp(temp, "left"))
						(*pActor)[iActorC]->byDirection = ACTOR_D_LEFT;
					else
					if(!strcmp(temp, "up"))
						(*pActor)[iActorC]->byDirection = ACTOR_D_UP;
					else
					if(!strcmp(temp, "right"))
						(*pActor)[iActorC]->byDirection = ACTOR_D_RIGHT;
					else
					if(!strcmp(temp, "down"))
						(*pActor)[iActorC]->byDirection = ACTOR_D_DOWN;									
				}
				else
				if(!strcmp(temp, "active")) {
					(*pActor)[iActorC]->bActive = ASGetAfterTokenNum(File, '=');
				}
				else
				if(!strcmp(temp, "random_start")) {
					(*pActor)[iActorC]->bRandomStart = ASGetAfterTokenNum(File, '=');
				}
				else
				if(!strcmp(temp, "random_reincarnation")) {
					(*pActor)[iActorC]->bRandomReincarnation = ASGetAfterTokenNum(File, '=');
				}
				else
				if(!strcmp(temp, "lifes")) {
					(*pActor)[iActorC]->iLifes = ASGetAfterTokenNum(File, '=');
				}
				else
				if(!strcmp(temp, "extra_points")) {
					(*pActor)[iActorC]->iExtraPoints = ASGetAfterTokenNum(File, '=');
				}
				else
				if(!strcmp(temp, "ai")) {
					(*pActor)[iActorC]->bAI = ASGetAfterTokenNum(File, '=');
				}
				else
				if(!strcmp(temp, "move")) {
					(*pActor)[iActorC]->bMove = ASGetAfterTokenNum(File, '=');
				}
				else
				if(!strcmp(temp, "light")) {
					(*pActor)[iActorC]->bLight = ASGetAfterTokenNum(File, '=');
				}
				else
				if(!strcmp(temp, "light_red")) {
					(*pActor)[iActorC]->fLightRed = ASGetAfterTokenNumF(File, '=');
				}
				else
				if(!strcmp(temp, "light_green")) {
					(*pActor)[iActorC]->fLightGreen = ASGetAfterTokenNumF(File, '=');
				}
				else
				if(!strcmp(temp, "light_blue")) {
					(*pActor)[iActorC]->fLightBlue = ASGetAfterTokenNumF(File, '=');
				}
				else
				if(!strcmp(temp, "light_x_pos")) {
					(*pActor)[iActorC]->fLightPos[X] = ASGetAfterTokenNumF(File, '=');
				}
				else
				if(!strcmp(temp, "light_y_pos")) {
					(*pActor)[iActorC]->fLightPos[Y] = ASGetAfterTokenNumF(File, '=');
				}
				else
				if(!strcmp(temp, "light_z_pos")) {
					(*pActor)[iActorC]->fLightPos[Z] = ASGetAfterTokenNumF(File, '=');
				}
			} while(!feof(File));
		  // End of loading actor
			iActorC++;
		}
	} while(!feof(File));
	free(pbyTempLine);
	pbyTempLine = NULL;
	fclose(File);
	Exist = TRUE;
	CalculatePoints();
	CreateAllLists();
	return AS_ERROR_NONE;	
} // end LEVEL::Load()

HRESULT LEVEL::Save(char *pbyFileName, void **pVActor, int iActors)
{ // begin LEVEL::Save()
	FILE *File;
    time_t long_time;
	struct tm *newtime;
	char *pbyTempLine;
	int Counter, Counter2;
	ACTOR **pActor = (ACTOR **) pVActor;

	if(!pbyFileName)
		return AS_ERROR_NONE;
	File = fopen(pbyFileName, "wt");
	if(!File)
		return AS_ERROR_FILE_CREATING;
    strcpy(byFileName, pbyFileName);
	time( &long_time );               
    newtime = localtime(&long_time);
	fprintf(File, "# %s  version: %s  level file.    Save Time: %d.%d.%d   Date: %d.%d.%d \n\n\n", 
			GAME_NAME, GAME_VERSION, newtime->tm_hour, newtime->tm_min, newtime->tm_sec,
			newtime->tm_mon, newtime->tm_mday, newtime->tm_year);
	fprintf(File, "[General]\n");
	fprintf(File, "# This is the level header, this data must be defined before the level itself!\n\n");
	fprintf(File, "# Missions:\n");
	fprintf(File, "mission_collect_all_diamonds = %d\n", bMissionCollectAllDiamonds);
	fprintf(File, "# When this both attributes are TRUE then the program will setting both to FALSE:\n");
	fprintf(File, "mission_kill_all_enemys = %d\n", bMissionKillAllEnemys);
	fprintf(File, "mission_kill_no_enemys = %d\n", bMissionKillNoEnemys);
	fprintf(File, "# Should the player go to the reincarnation when he has finished the missions?:\n");
	fprintf(File, "mission_go_to_reincarnation = %d\n", bMissionGoToReincarnationWhenDone);
	fprintf(File, "# Other stuff:\n");
	fprintf(File, "name = %s\n", pbyName);
	fprintf(File, "width = %d\n", iWidth);
	fprintf(File, "height = %d\n", iHeight);
	fprintf(File, "field_width = %.2f\n", fFieldWidth);
	fprintf(File, "field_height = %.2f\n", fFieldHeight);
	fprintf(File, "floor_z = %.2f\n", fZFloor);
	fprintf(File, "wall_height = %.2f\n", fWallZHeight);
	fprintf(File, "time_limit = %d\n", iTimeLimit);
	fprintf(File, "#General color\n");
	fprintf(File, "general_red = %.2f\n", fGeneralRed);
	fprintf(File, "general_green = %.2f\n", fGeneralGreen);
	fprintf(File, "general_blue = %.2f\n", fGeneralBlue);
	fprintf(File, "#Wall color\n");
	fprintf(File, "wall_red = %.2f\n", fWallRed);
	fprintf(File, "wall_green = %.2f\n", fWallGreen);
	fprintf(File, "wall_blue = %.2f\n", fWallBlue);
	fprintf(File, "\n# Now follows the level-structure:\n");
	fprintf(File, "structure:\n");
	// Save the level structure:
	pbyTempLine = (char *) malloc(iWidth+10);
    if(!pbyTempLine)
		MessageBox(NULL, "MEMORY.", "Error", MB_ICONERROR | MB_OK);
	for(Counter = 0; Counter < (iHeight*2); Counter++)
	{
		// Save y row:
		for(Counter2 = 0; Counter2 < iWidth; Counter2++)
		{
			if(Counter == iHeight)
			{ // Last y row:
				if(Field[Counter2][Counter-1].Wall[BOTTOM] == TRUE)
					pbyTempLine[Counter2] = 'X';
				else
					pbyTempLine[Counter2] = '0';
			}
			else
			{
				if(Field[Counter2][Counter].Wall[TOP] == TRUE)
					pbyTempLine[Counter2] = 'X';
				else
					pbyTempLine[Counter2] = '0';
			}
		}
		pbyTempLine[Counter2] = '\0';
		fprintf(File, "%s\n", pbyTempLine);
		if(Counter == iHeight)
			break;
		// Save x column:
		for(Counter2 = 0; Counter2 < iWidth+1; Counter2++)
		{
			if(Counter2 == iWidth)
			{ // Last x column:
				if(Field[Counter2-1][Counter].Wall[RIGHT] == TRUE)
					pbyTempLine[Counter2] = 'X';
				else
					pbyTempLine[Counter2] = '0';
			}
			else
			{
				if(Field[Counter2][Counter].Wall[LEFT] == TRUE)
					pbyTempLine[Counter2] = 'X';
				else
					pbyTempLine[Counter2] = '0';
			}
		}
		pbyTempLine[Counter2] = '\0';
		fprintf(File, "%s\n\n", pbyTempLine);
	}
	free(pbyTempLine);
	pbyTempLine = NULL;
	fprintf(File, "# End of the level-structure.\n\n");
	// Save the Actors:
	fprintf(File, "# Now come the actors:\n");
	if(!pActor)
		fprintf(File, "actors = %d\n\n", 0);
	else
	{
		fprintf(File, "actors = %d\n", iActors);
		for(Counter = 0; Counter < iActors; Counter++)
		{
			if(!pActor[Counter])
				continue;
			fprintf(File, "\nstart_actor\n");
			fprintf(File, "# Actor nr: %d:\n", Counter+1);
			switch(pActor[Counter]->iType)
			{
				case ACTOR_PLAYER: fprintf(File, "type = actor_player\n"); break;
				case ACTOR_E_FOOL: fprintf(File, "type = actor_e_fool\n"); break;
				case ACTOR_E_NORMAL: fprintf(File, "type = actor_e_normal\n"); break;
				case ACTOR_E_TERMINATOR: fprintf(File, "type = actor_e_terminator\n"); break;
				case ACTOR_P_REINCARNATION: fprintf(File, "type = actor_p_reincarnation\n"); break;
				case ACTOR_E_REINCARNATION: fprintf(File, "type = actor_e_reincarnation\n"); break;
				case ACTOR_DIAMOND: fprintf(File, "type = actor_diamond\n"); break;
				case ACTOR_FRUIT_1: fprintf(File, "type = actor_fruit_1\n"); break;
				case ACTOR_HERO: fprintf(File, "type = actor_hero\n"); break;
				case ACTOR_BOMB: fprintf(File, "type = actor_bomb\n"); break;
				case ACTOR_HOURGLASS: fprintf(File, "type = actor_hourglass\n"); break;
				case ACTOR_FREEZE: fprintf(File, "type = actor_freeze\n"); break;
				case ACTOR_GHOST: fprintf(File, "type = actor_ghost\n"); break;
				case ACTOR_SPEED: fprintf(File, "type = actor_speed\n"); break;
			}
			fprintf(File, "xpos = %d  ypos = %d\n", pActor[Counter]->iXPos, pActor[Counter]->iYPos);
			if(pActor[Counter]->fScale[X] != 1.0f)
				fprintf(File, "xscale = %.2f", pActor[Counter]->fScale[X]);
			if(pActor[Counter]->fScale[Y] != 1.0f)
				fprintf(File, "yscale = %.2f", pActor[Counter]->fScale[Y]);
			if(pActor[Counter]->fScale[Z] != 1.0f)
				fprintf(File, "zscale = %.2f\n", pActor[Counter]->fScale[Z]);
			if(pActor[Counter]->fVelocity)
				fprintf(File, "velocity = %.2f\n", pActor[Counter]->fVelocity);
			switch(pActor[Counter]->byDirection)
			{
				case ACTOR_D_LEFT: fprintf(File, "direction = left\n"); break;
				case ACTOR_D_UP: fprintf(File, "direction = up\n"); break;
				case ACTOR_D_RIGHT: fprintf(File, "direction = right\n"); break;
				case ACTOR_D_DOWN: fprintf(File, "direction = down\n"); break;
			}
			if(pActor[Counter]->bActive != 1)
				fprintf(File, "active = %d\n", pActor[Counter]->bActive);
			if(pActor[Counter]->bRandomStart)
				fprintf(File, "random_start = %d\n", pActor[Counter]->bRandomStart);
			if(pActor[Counter]->bRandomReincarnation)
				fprintf(File, "random_reincarnation = %d\n", pActor[Counter]->bRandomReincarnation);
			if(pActor[Counter]->iLifes != -2)
				fprintf(File, "lifes = %d\n", pActor[Counter]->iLifes);
			if(pActor[Counter]->iExtraPoints)
				fprintf(File, "extra_points = %d\n", pActor[Counter]->iExtraPoints);
			if(pActor[Counter]->bAI)
				fprintf(File, "ai = %d\n", pActor[Counter]->bAI);
			if(pActor[Counter]->bMove)
				fprintf(File, "move = %d\n", pActor[Counter]->bMove);
			if(pActor[Counter]->bLight)
				fprintf(File, "light = %d\n", pActor[Counter]->bLight);
			if(pActor[Counter]->fLightRed)
				fprintf(File, "light_red = %.2f\n", pActor[Counter]->fLightRed);
			if(pActor[Counter]->fLightGreen)
				fprintf(File, "light_green = %.2f\n", pActor[Counter]->fLightGreen);
			if(pActor[Counter]->fLightBlue)
				fprintf(File, "light_blue = %.2f\n", pActor[Counter]->fLightBlue);
			if(pActor[Counter]->fLightPos[X])
				fprintf(File, "light_x_pos = %.2f\n", pActor[Counter]->fLightPos[X]);
			if(pActor[Counter]->fLightPos[Y])
				fprintf(File, "light_y_pos = %.2f\n", pActor[Counter]->fLightPos[Y]);
			if(pActor[Counter]->fLightPos[Z])
				fprintf(File, "light_z_pos = %.2f\n", pActor[Counter]->fLightPos[Z]);
			fprintf(File, "end_actor\n");
		}
	}
	fclose(File);
	return AS_ERROR_NONE;	
} // end LEVEL::Save()

void LEVEL::SetGeneralLight(void)
{ // begin LEVEL::SetGeneralLight()
	GLfloat afLightData[4]  = {fGeneralRed, fGeneralGreen, fGeneralBlue, 0.0f};

	glLightfv(GL_LIGHT1, GL_AMBIENT, afLightData);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, afLightData);
} // end LEVEL::SetGeneralLight()

BOOL LEVEL::CheckWallSurround(int x, int y)
{ // begin LEVEL::CheckSurrounded()
	// Is the field it surrounded by walls?
	if((Field[x][y].Wall[LEFT] == TRUE || x == 0) &&
	   (Field[x][y].Wall[TOP] == TRUE || y == 0) &&
	   (Field[x][y].Wall[RIGHT] == TRUE || x == iWidth-1) &&
	   (Field[x][y].Wall[BOTTOM] == TRUE || y == iHeight-1))
	   return TRUE;
   return FALSE;
} // end LEVEL::CheckSurrounded()
//-----------------------------------------------------------------------------
// File: Level.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
LEVEL Level;
DWORD dwGameWonStartTime;
///////////////////////////////////////////////////////////////////////////////


// QUADTREE functions: ********************************************************
QUADTREE::QUADTREE(void)
{ // begin QUADTREE::QUADTREE()
	memset(this, 0, sizeof(QUADTREE));
} // end QUADTREE::QUADTREE()

QUADTREE::~QUADTREE(void)
{ // begin QUADTREE::~QUADTREE()
} // end QUADTREE::~QUADTREE()

// Create the quatree for a level:
void QUADTREE::Build(void *pLevelT)
{ // begin QUADTREE::Build()
	LEVEL *pLevel = (LEVEL *) pLevelT;
	QUADTREE *pChildT;
	int iX, iY, iChild, iCurrentChild,
		iHalfFieldsX, iHalfFieldsY;
	float fHalfFieldsX, fHalfFieldsY;

	// Setup quadtree information:
	if(!pParent)
	{ // That's the topmost quadtree:
		iStartX = iStartY = 0;
		iFieldsX = pLevel->iWidth-1;
		iFieldsY = pLevel->iHeight-1;
		iFields = iFieldsX*iFieldsY;
		if(!pField)
			pField = (FIELD **) malloc(sizeof(FIELD)*iFields);
		memset(pField, 0, sizeof(FIELD)*iFields);
	}

	// Setup field pointers:
	for(iY = 0; iY < iFieldsY; iY++)
		for(iX = 0; iX < iFieldsX; iX++)
			pField[iX+iY*iFieldsX] = &pLevel->pField[(iStartX+iX)+(iStartY+iY)*(pLevel->iWidth-1)];

	iChildren = 0;
	if(iFieldsX > 4)
		iChildren += 2;
	if(iFieldsY > 4)
		iChildren += 2;
	if(iChildren)
	{
		if(!pChild)
			pChild = (QUADTREE *) malloc(sizeof(QUADTREE)*iChildren);
		memset(pChild, 0, sizeof(QUADTREE)*iChildren);
		
		// Create the children:
		if(iFieldsX > 5)
		{
			iHalfFieldsX = iFieldsX/2;
			fHalfFieldsX = (float) iFieldsX/2;
		}
		else
		{
			iHalfFieldsX = iFieldsX;
			fHalfFieldsX = (float) iFieldsX;
		}
		if(iFieldsY > 5)
		{
			iHalfFieldsY = iFieldsY/2;
			fHalfFieldsY = (float) iFieldsY/2;
		}
		else
		{
			iHalfFieldsY = iFieldsY;
			fHalfFieldsY = (float) iFieldsY;
		}
		//
		iCurrentChild = 0;
		pChildT = &pChild[iCurrentChild];
		pChildT->pParent = this;
		pChildT->iStartX = iStartX;
		pChildT->iStartY = iStartY;
		pChildT->iFieldsX = iHalfFieldsX;
		pChildT->iFieldsY = iHalfFieldsY;
		iCurrentChild++;
		if(iFieldsX > 5)
		{
			pChildT = &pChild[iCurrentChild];
			pChildT->pParent = this;
			pChildT->iStartX = iStartX+iHalfFieldsX;
			pChildT->iStartY = iStartY;
			pChildT->iFieldsX = iFieldsX-iHalfFieldsX;
			pChildT->iFieldsY = iHalfFieldsY;
			iCurrentChild++;
		}
		if(iFieldsY > 5)
		{
			if(iFieldsX > 5)
			{
				pChildT = &pChild[iCurrentChild];
				pChildT->pParent = this;
				pChildT->iStartX = iStartX+iHalfFieldsX;
				pChildT->iStartY = iStartY+iHalfFieldsY;
				pChildT->iFieldsX = iFieldsX-iHalfFieldsX;
				pChildT->iFieldsY = iFieldsY-iHalfFieldsY;
				iCurrentChild++;
			}
			pChildT = &pChild[iCurrentChild];
			pChildT->pParent = this;
			pChildT->iStartX = iStartX;
			pChildT->iStartY = iStartY+iHalfFieldsY;
			pChildT->iFieldsX = iHalfFieldsX;
			pChildT->iFieldsY = iFieldsY-iHalfFieldsY;
		}

		// Setup children:
		for(iChild = 0; iChild < iChildren; iChild++)		
		{
			pChildT = &pChild[iChild];
			if(pChildT->iStartX+pChildT->iFieldsX > pLevel->iWidth-1)
				pChildT->iFieldsX = pChildT->iStartX+pChildT->iFieldsX-pLevel->iWidth-1;
			if(pChildT->iStartY+pChildT->iFieldsY > pLevel->iHeight-1)
				pChildT->iFieldsY = pChildT->iStartY+pChildT->iFieldsY-pLevel->iHeight-1;
			pChildT->iFields = pChildT->iFieldsX*pChildT->iFieldsY;
			if(!pChildT->pField)
				pChildT->pField = (FIELD **) malloc(sizeof(FIELD)*pChildT->iFields);
			memset(pChildT->pField, 0, sizeof(FIELD)*pChildT->iFields);
						
			// Build child quadtrees of this child quadtree:
			pChildT->Build(pLevelT);
		}
	}
	else
		iChildren = 0;
	
	// First, nothing is in FOV:
	if(!pParent)
	{
		SetNotInFOV();
		GetBoundingBox(pLevel);
	}
} // end QUADTREE::Build()

void QUADTREE::Destroy(void)
{ // begin QUADTREE::Destroy()
	SAFE_DELETE(pField);
	for(int iChild = 0; iChild < iChildren; iChild++)
		pChild[iChild].Destroy();
	SAFE_DELETE(pChild);
	memset(this, 0, sizeof(QUADTREE));
} // end QUADTREE::Destroy()

void QUADTREE::SetNotInFOV(void)
{ // begin QUADTREE::SetNotInFOV()
	bInFOV = FALSE;
	for(int iChild = 0; iChild < iChildren; iChild++)
		pChild[iChild].SetNotInFOV();
} // end QUADTREE::SetNotInFOV()

void QUADTREE::CheckInFOV(void)
{ // begin QUADTREE::CheckInFOV()
	if(!pParent) // Topmost quadtree:
		SetNotInFOV();

	// Check if this quadtree is in the FOV:
	if(!ASCubeInFrustum(fBoundingBox[AS_MIN][X], fBoundingBox[AS_MAX][X],
						fBoundingBox[AS_MIN][Y], fBoundingBox[AS_MAX][Y],
						fBoundingBox[AS_MIN][Z], fBoundingBox[AS_MAX][Z]))
		return; // Not visible!
	
	// It's visible, check now the child quadtrees:
	bInFOV = TRUE;
	for(int iChild = 0; iChild < iChildren; iChild++)
		pChild[iChild].CheckInFOV();
} // end QUADTREE::CheckInFOV()

void QUADTREE::SetFieldsInFOV(void)
{ // begin QUADTREE::SetFieldsInFOV()
	for(int i = 0; i < iFields; i++)
		pField[i]->bInFOV = TRUE;
} // end QUADTREE::SetFieldsInFOV()

void QUADTREE::CheckFieldsInFOV(void)
{ // begin QUADTREE::CheckFieldsInFOV()
	if(!pParent) // Main quadtree:
		SetFieldsInFOV();

	// Is this quadtree visible?
	if(!bInFOV)
	{ // Nope, all fields in it are not visible:
		for(int i = 0; i < iFields; i++)
		{
			if(!pField[i])
				continue;
			pField[i]->bInFOV = FALSE;
		}
		return;
	}

	// Check, if it's complete in the field of view:
	if(ASPointInFrustum(fBoundingBox[AS_MIN][X], fBoundingBox[AS_MIN][Y], fBoundingBox[AS_MIN][Z]) &&
	   ASPointInFrustum(fBoundingBox[AS_MAX][X], fBoundingBox[AS_MIN][Y], fBoundingBox[AS_MIN][Z]) &&
	   ASPointInFrustum(fBoundingBox[AS_MAX][X], fBoundingBox[AS_MAX][Y], fBoundingBox[AS_MIN][Z]) &&
	   ASPointInFrustum(fBoundingBox[AS_MIN][X], fBoundingBox[AS_MAX][Y], fBoundingBox[AS_MIN][Z]) &&
	   ASPointInFrustum(fBoundingBox[AS_MIN][X], fBoundingBox[AS_MIN][Y], fBoundingBox[AS_MAX][Z]) &&
	   ASPointInFrustum(fBoundingBox[AS_MAX][X], fBoundingBox[AS_MIN][Y], fBoundingBox[AS_MAX][Z]) &&
	   ASPointInFrustum(fBoundingBox[AS_MAX][X], fBoundingBox[AS_MAX][Y], fBoundingBox[AS_MAX][Z]) &&
	   ASPointInFrustum(fBoundingBox[AS_MIN][X], fBoundingBox[AS_MAX][Y], fBoundingBox[AS_MAX][Z]))
		return;  // Yep, it's complete in the FOV:
		
	if(!iChildren)
	{ // There are no children, check now each field itself:
		FIELD *pFieldT;
		
		for(int i = 0; i < iFields; i++)
		{
			pFieldT = pField[i];
			if(!pFieldT)
				continue;
			if(!ASCubeInFrustum(pFieldT->fBoundingBox[AS_MIN][X], pFieldT->fBoundingBox[AS_MAX][X],
							    pFieldT->fBoundingBox[AS_MIN][Y], pFieldT->fBoundingBox[AS_MAX][Y],
							    pFieldT->fBoundingBox[AS_MIN][Z], pFieldT->fBoundingBox[AS_MAX][Z]))
				pField[i]->bInFOV = FALSE;
		}
		return;
	}

	for(int iChild = 0; iChild < iChildren; iChild++)
		pChild[iChild].CheckFieldsInFOV();
} // end QUADTREE::CheckFieldsInFOV()

// Get's the bounding box of the quatree:
void QUADTREE::GetBoundingBox(void *pLevelT)
{ // begin QUADTREE::GetBoundingBox()
	LEVEL *pLevel = (LEVEL *) pLevelT;
	int iField, iPoint, i, iPointID;
	float fTemp;

	fBoundingBox[AS_MIN][X] = 10000.0f;
	fBoundingBox[AS_MIN][Y] = 10000.0f;
	fBoundingBox[AS_MIN][Z] = 10000.0f;
	fBoundingBox[AS_MAX][X] = -10000.0f;
	fBoundingBox[AS_MAX][Y] = -10000.0f;
	fBoundingBox[AS_MAX][Z] = -10000.0f;

	for(iField = 0; iField < iFields; iField++)
	{
		if(!pField || !pField[iField])
			continue;
		for(iPoint = 0; iPoint < 4; iPoint++)
		{
			iPointID = pField[iField]->iPoint[iPoint];
			if(iPointID < pLevel->iPoints && iPointID >= 0)
			{
				for(i = 0; i < 3; i++)
				{
					// Check the terrain points:
					fTemp = pLevel->fPoint[iPointID][i];
					if(fBoundingBox[AS_MIN][i] > fTemp)
						fBoundingBox[AS_MIN][i] = fTemp;
					if(fBoundingBox[AS_MAX][i] < fTemp)
						fBoundingBox[AS_MAX][i] = fTemp;
					
					// Check the water points:
					fTemp = pLevel->fWaterPoint[iPointID][i];
					if(fBoundingBox[AS_MIN][i] > fTemp)
						fBoundingBox[AS_MIN][i] = fTemp;
					if(fBoundingBox[AS_MAX][i] < fTemp)
						fBoundingBox[AS_MAX][i] = fTemp;
				}
			}
			else
				continue;
		}
	}

	// Get children bounding boxes:
	for(int iChild = 0; iChild < iChildren; iChild++)
		pChild[iChild].GetBoundingBox(pLevelT);
} // end QUADTREE::GetBoundingBox()

// Get's the bounding box of the quatree: (only z coord)
void QUADTREE::GetBoundingBoxZCoord(void *pLevelT)
{ // begin QUADTREE::GetBoundingBoxZCoord()
	LEVEL *pLevel = (LEVEL *) pLevelT;
	int iField, iPoint, iPointID;
	float fTemp;

	fBoundingBox[AS_MIN][X] = 10000.0f;
	fBoundingBox[AS_MIN][Y] = 10000.0f;
	fBoundingBox[AS_MIN][Z] = 10000.0f;
	fBoundingBox[AS_MAX][X] = -10000.0f;
	fBoundingBox[AS_MAX][Y] = -10000.0f;
	fBoundingBox[AS_MAX][Z] = -10000.0f;

	for(iField = 0; iField < iFields; iField++)
	{
		if(!pField || !pField[iField])
			continue;
		for(iPoint = 0; iPoint < 4; iPoint++)
		{
			iPointID = pField[iField]->iPoint[iPoint];
			if(iPointID < pLevel->iPoints && iPointID >= 0)
			{
				// Check the terrain points:
				fTemp = pLevel->fPoint[iPointID][Z];
				if(fBoundingBox[AS_MIN][Z] > fTemp)
					fBoundingBox[AS_MIN][Z] = fTemp;
				if(fBoundingBox[AS_MAX][Z] < fTemp)
					fBoundingBox[AS_MAX][Z] = fTemp;
				
				// Check the water points:
				fTemp = pLevel->fWaterPoint[iPointID][Z];
				if(fBoundingBox[AS_MIN][Z] > fTemp)
					fBoundingBox[AS_MIN][Z] = fTemp;
				if(fBoundingBox[AS_MAX][Z] < fTemp)
					fBoundingBox[AS_MAX][Z] = fTemp;
			}
			else
				continue;
		}
	}

	// Get children bounding boxes:
	for(int iChild = 0; iChild < iChildren; iChild++)
		pChild[iChild].GetBoundingBox(pLevelT);
} // end QUADTREE::GetBoundingBoxZCoord()

// Draw the bounding boxes:
void QUADTREE::ShowBoundingBox(void)
{ // begin QUADTREE::ShowBoundingBox()
	if(!_ASConfig->bShowQuadtrees)
		return;

	// Draw children bounding boxes:
	for(int iChild = 0; iChild < iChildren; iChild++)
		pChild[iChild].ShowBoundingBox();

	if(!pParent)
		glColor3f(1.0f, 0.0f, 1.0f);
	else
		glColor3f(1.0f, 1.0f, 1.0f);

	ASDrawBoundingBox(fBoundingBox, 1.0f);
} // end QUADTREE::ShowBoundingBox()
///////////////////////////////////////////////////////////////////////////////


// LEVEL functions: ***********************************************************
LEVEL::LEVEL(void)
{ // begin LEVEL::LEVEL()
} // end LEVEL::LEVEL()

LEVEL::~LEVEL(void)
{ // begin LEVEL::~LEVEL()
} // end LEVEL::~LEVEL()

void LEVEL::Create(int iWidthT, int iHeightT)
{ // begin LEVEL::Create()
	AS_PROGRESS_WINDOW ProgressWindow;
	int iX, iY, i, i2;

	ProgressWindow.CreateProgressWindow("Level");
	ProgressWindow.SetTask("Generate an new level...");
	ProgressWindow.SetProgress(0);

	Destroy();
	// General stuff:
	memset(this, 0, sizeof(LEVEL));
	iWidth = iWidthT;
	iHeight = iHeightT;
	iPoints = iWidth*iHeight;
	fWidth = iWidth-1.0f;
	fHeight = iHeight-1.0f;
	iFields = (iWidthT-1)*(iHeightT-1);

	// Create grid points:
	fPoint = (FLOAT3 *) malloc(sizeof(FLOAT3)*iPoints);
	if(!fPoint)
		return;
	fFixPoint = (FLOAT3 *) malloc(sizeof(FLOAT3)*iPoints);
	if(!fFixPoint)
		return;
	fWaterPoint = (FLOAT3 *) malloc(sizeof(FLOAT3)*iPoints);
	if(!fWaterPoint)
		return;
	fPointColor = (FLOAT3 *) malloc(sizeof(FLOAT3)*iPoints);
	if(!fPointColor)
		return;
	fPointNormal = (FLOAT3 *) malloc(sizeof(FLOAT3)*iPoints);
	if(!fPointNormal)
		return;
	vNormalRight = (AS_3D_VECTOR *) malloc(sizeof(AS_3D_VECTOR)*iFields*2);
	if(!vNormalRight)
		return;
	vNormalUp = (AS_3D_VECTOR *) malloc(sizeof(AS_3D_VECTOR)*iFields*2);
	if(!vNormalUp)
		return;
	fWaterAmplitude = (float *) malloc(sizeof(float)*iPoints);
	if(!fWaterAmplitude)
		return;		
	fPointTexCoord = (FLOAT2 *) malloc(sizeof(FLOAT2)*iPoints);
	if(!fPointTexCoord)
		return;
	pField = (FIELD *) malloc(sizeof(FIELD)*iFields);
	if(!pField)
		return;
	memset(pField, 0, sizeof(FIELD)*iFields);
	fNormal = (FLOAT3 *) malloc(sizeof(FLOAT3)*iFields*2);
	if(!fNormal)
		return;
	Plane = (AS_PLANE *) malloc(sizeof(AS_PLANE)*iFields*2);
	if(!Plane)
		return;
	pInFOVFields = (FIELD **) malloc(sizeof(FIELD *)*(iFields+1));
	if(!pInFOVFields)
		return;
	memset(pInFOVFields, 0, sizeof(FIELD *)*iFields);
	iVisiblePoints = (int *) malloc(sizeof(int)*iPoints);
	if(!iVisiblePoints)
		return;
	bPointVisible = (BOOL *) malloc(sizeof(BOOL)*iPoints);
	if(!bPointVisible)
		return;
	memset(bPointVisible, 0, sizeof(BOOL *)*iPoints);
	bWaterFieldVisible = (BOOL *) malloc(sizeof(BOOL)*iFields);
	if(!bWaterFieldVisible)
		return;
	memset(bWaterFieldVisible, 0, sizeof(BOOL *)*iFields);

	// Setup grid points:
	for(iY = 0, i = 0; iY < iHeight; iY++)
		for(iX = 0; iX < iWidth; iX++, i++)
		{
			// Set the coordinates:
			fWaterPoint[i][X] = fFixPoint[i][X] = fPoint[i][X] = (float) iX;
			fWaterPoint[i][Y] = fFixPoint[i][Y] = fPoint[i][Y] = (float) iY;
			fWaterPoint[i][Z] = fFixPoint[i][Z] = fPoint[i][Z] = -0.5f;
			fPointColor[i][R] = fPointColor[i][G] = fPointColor[i][B] = 0.9f;
			fPointTexCoord[i][X] = (float) iX/iWidth;
			fPointTexCoord[i][Y] = (float) iY/iHeight;
		}

	ProgressWindow.SetProgress(20);
	CreateRandomTerrain();
	ProgressWindow.SetProgress(80);

	// Get the highest, lowest and the middle point in the level:
	for(i = 0, fHighestPoint = fMiddleHeight = fLowestPoint = 0.0f; i < iPoints; i++)
	{
		if(fFixPoint[i][Z] < fHighestPoint)
			fHighestPoint = fFixPoint[i][Z];
		if(fFixPoint[i][Z] > fLowestPoint)
			fLowestPoint = fFixPoint[i][Z];
		fMiddleHeight += fFixPoint[i][Z];
	}
	fMiddleHeight /= iPoints;
	
	// Null should be the lowest point:
	for(i = 0; i < iPoints; i++)
	{
		fWaterPoint[i][Z] -= fLowestPoint;
		fFixPoint[i][Z] -= fLowestPoint;
		fPoint[i][Z] -= fLowestPoint;
		fWaterAmplitude[i] = (float) (rand() % 1000)/1000;
	}

	// Get the highest, lowest and the middle point in the level:
	for(i = 0, fHighestPoint = fMiddleHeight = fLowestPoint = 0.0f; i < iPoints; i++)
	{
		if(fFixPoint[i][Z] < fHighestPoint)
			fHighestPoint = fFixPoint[i][Z];
		if(fFixPoint[i][Z] > fLowestPoint)
			fLowestPoint = fFixPoint[i][Z];
		fMiddleHeight += fFixPoint[i][Z];
	}
	fMiddleHeight /= iPoints;
	fCenter[X] = fWidth/2-0.5f;
	fCenter[Y] = fHeight/2-0.5f;

	// Setup fields:
	for(iY = 0, i = 0, i2 = 0; iY < iHeight-1; iY++)
		for(iX = 0; iX < iWidth-1; iX++, i++, i2 += 2)
		{
			pField[i].iID = i;
			pField[i].iPos[X] = iX;
			pField[i].iPos[Y] = iY;
			pField[i].iPoint[0] = iX+iY*iWidth;
			pField[i].iPoint[1] = (iX+1)+iY*iWidth;
			pField[i].iPoint[2] = (iX+1)+(iY+1)*iWidth;
			pField[i].iPoint[3] = iX+(iY+1)*iWidth;
			pField[i].iNormal[0] = i2;
			pField[i].iNormal[1] = i2+1;
		}

	// Initialize some stuff:
	fCurrentWaterHeight = fMiddleHeight+3.0f;
	fFogDensity = 1.5f;
	vAblazeBallPos[0].fX = -1;
	vAblazeBallPos[1].fX = -1;
	vAblazeBallPos[2].fX = -1;
	vAblazeBallPos[3].fX = -1;
	for(i = 0; i < 3; i++)
		iWallAniStep[i] = rand() % 32;
	
	iWallAniSpeed[0] = 20;
	iWallAniSpeed[1] = 30;
	iWallAniSpeed[2] = 40;

	// Setup prongs:
	iProngPos[0][X] = iWidth/2-2;
	iProngPos[0][Y] = iHeight/2-2;
	iProngPos[1][X] = iWidth/2+1;
	iProngPos[1][Y] = iHeight/2-2;
	iProngPos[2][X] = iWidth/2+1;
	iProngPos[2][Y] = iHeight/2+1;
	iProngPos[3][X] = iWidth/2-2;
	iProngPos[3][Y] = iHeight/2+1;
	
	// Ablaze space:
	iAblazeSpacePos[0][X] = iWidth/2-1;
	iAblazeSpacePos[0][Y] = iHeight/2-1;
	iAblazeSpacePos[1][X] = iWidth/2;
	iAblazeSpacePos[1][Y] = iHeight/2-1;
	iAblazeSpacePos[2][X] = iWidth/2;
	iAblazeSpacePos[2][Y] = iHeight/2;
	iAblazeSpacePos[3][X] = iWidth/2-1;
	iAblazeSpacePos[3][Y] = iHeight/2;

	// Final level setup:
	lLastAiringObjectTime = lLastAiringObjectTimeTemp = g_lNow;
	lLastFireBombObjectTime = lLastFireBombObjectTimeTemp =  g_lNow;
	lLastSparkObjectTime = lLastSparkObjectTimeTemp = g_lNow;
	lLastThrustEngineObjectTime = lLastThrustEngineObjectTimeTemp = g_lNow;
	lLastTerraformEngineObjectTime = lLastTerraformEngineObjectTimeTemp = g_lNow;
	bGameWon = FALSE;
	ProgressWindow.SetProgress(100);
	CreateWallsList();
	CreateAblazeSpaceColumnLists();
	bFlashBlend = TRUE;
} // end LEVEL::Create()

void LEVEL::Destroy(void)
{ // begin LEVEL::Destroy()
	DestroyWallsList();
	DestroyAblazeSpaceColumnLists();
	Quadtree.Destroy();
	SAFE_FREE(fPoint);
	SAFE_FREE(fFixPoint);
	SAFE_FREE(fWaterPoint);
	SAFE_FREE(fPointColor);
	SAFE_FREE(fPointNormal);
	SAFE_FREE(vNormalRight);
	SAFE_FREE(vNormalUp);
	SAFE_FREE(fWaterAmplitude);
	SAFE_FREE(fPointTexCoord);
	SAFE_FREE(pField);
	SAFE_FREE(fNormal);
	SAFE_FREE(Plane);
	SAFE_FREE(iVisiblePoints);
	SAFE_FREE(bPointVisible);
	SAFE_FREE(bWaterFieldVisible);
	memset(this, 0, sizeof(LEVEL));
} // end LEVEL::Destroy()

void LEVEL::Restart(void)
{ // begin LEVEL::Restart()
	int i, i2;

	for(i = 0; i < iPoints; i++)
		for(i2 = 0; i2 < 3; i2++)
		{
			fPoint[i][i2] = fFixPoint[i][i2];
			fPointColor[i][i2] = 0.9f;
		}
	// Get the highest, lowest and the middle point in the level:
	for(i = 0, fHighestPoint = fMiddleHeight = fLowestPoint = 0.0f; i < iPoints; i++)
	{
		if(fFixPoint[i][Z] < fHighestPoint)
			fHighestPoint = fFixPoint[i][Z];
		if(fFixPoint[i][Z] > fLowestPoint)
			fLowestPoint = fFixPoint[i][Z];
		fMiddleHeight += fFixPoint[i][Z];
	}
	fMiddleHeight /= iPoints;
	fCurrentWaterHeight = fMiddleHeight+3.0f;
	fFogDensity = 1.5f;
	lLastAiringObjectTime = g_lNow;
	lLastFireBombObjectTime = g_lNow;
	lLastSparkObjectTime = g_lNow;
	lLastThrustEngineObjectTime = g_lNow;
	lLastTerraformEngineObjectTime = g_lNow;
	iAiringObjects = 0;
	iFireBombObjects = 0;
	iSparkObjects = 0;
	iThrustEngineObjects = 0;
	iTerraformEngineObjects = 0;
	iAblazeBallsInAblazeSpace = 0;
	bTerrainUpdate = TRUE;
	bGameWon = FALSE;
	FOVUpdate();
	CalculateNormals();
	Check();
} // end LEVEL::Restart()

void LEVEL::CalculateNormals(void)
{ // begin LEVEL::CalculateNormals()
	int i, i2, iX, iY, iID, iNormals;
	AS_3D_VECTOR vNormalT;
	FIELD *pFieldT;

	// Compute the normals for the fields:
	for(i = 0; i < iFields; i++)
	{
		pFieldT = &pField[i];
		if(!pFieldT)
			break;
			
		// Get the field normals:
		NormalizeFace(&fNormal[pFieldT->iNormal[0]], fPoint[pFieldT->iPoint[3]],
					  fPoint[pFieldT->iPoint[2]], fPoint[pFieldT->iPoint[0]]);
		NormalizeFace(&fNormal[pFieldT->iNormal[1]], fPoint[pFieldT->iPoint[2]],
					  fPoint[pFieldT->iPoint[1]], fPoint[pFieldT->iPoint[0]]);

		// Find the right and up vectors for each face.
		// I precomputer them since they are used a lot:
		vNormalT = fNormal[pFieldT->iNormal[0]];
		vNormalT.GetRightUp(vNormalRight[pFieldT->iNormal[0]], vNormalUp[pFieldT->iNormal[0]]);
		vNormalT = fNormal[pFieldT->iNormal[1]];
		vNormalT.GetRightUp(vNormalRight[pFieldT->iNormal[1]], vNormalUp[pFieldT->iNormal[1]]);

		// Get the planes:
		Plane[pFieldT->iNormal[0]].ComputeND(fPoint[pFieldT->iPoint[3]], fPoint[pFieldT->iPoint[2]], fPoint[pFieldT->iPoint[0]]);
		Plane[pFieldT->iNormal[1]].ComputeND(fPoint[pFieldT->iPoint[2]], fPoint[pFieldT->iPoint[1]], fPoint[pFieldT->iPoint[0]]);
	}

	// Compute normals for the points:
	for(i = 0; i < iPoints; i++)
	{
		memset(fPointNormal[i], 0, sizeof(FLOAT3));
		iNormals = 0;

		// Get the middle normal:
		for(iY = (int) fPoint[i][Y]-1; iY < (int) fPoint[i][Y]+1; iY++)
		{
			if(iY < 0)
				continue;
			if(iY >= iHeight-1)
				break;
			for(iX = (int) fPoint[i][X]-1; iX < (int) fPoint[i][X]+1; iX++)
			{
				if(iX < 0)
					continue;
				if(iX >= iWidth-1)
					break;
				iID = iX+iY*(iWidth-1);
				for(i2 = 0; i2 < 2; i2++)
				{
					fPointNormal[i][X] += fNormal[pField[iID].iNormal[i2]][X];
					fPointNormal[i][Y] += fNormal[pField[iID].iNormal[i2]][Y];
					fPointNormal[i][Z] += fNormal[pField[iID].iNormal[i2]][Z];
					iNormals++;
				}
			}
		}

		fPointNormal[i][X] /= iNormals;
		fPointNormal[i][Y] /= iNormals;
		fPointNormal[i][Z] /= iNormals;
	}
} // end LEVEL::CalculateNormals()

void LEVEL::CalculateFieldBoundingBoxes(void)
{ // begin LEVEL::CalculateFieldBoundingBoxes()
	FLOAT3 *pfPointT;
	FIELD *pFieldT;
	int i, i2, i3;

	// Calculate the field bounding boxes: (for frustum culling)
	for(i = 0; i < iFields; i++)
	{
		pFieldT = &pField[i];
		
		// Setup:
		for(i2 = 0; i2 < 3; i2++)
		{
			pFieldT->fBoundingBox[AS_MIN][i2] = 1000;
			pFieldT->fBoundingBox[AS_MIN][i2] = -1000;
		}

		// Get the fields bounding box:
		for(i2 = 0; i2 < 4; i2++)
		{
			pfPointT = &fPoint[pFieldT->iPoint[i2]];
			
			// Check now each coordinate:
			for(i3 = 0; i3 < 3; i3++)
			{
				if((*pfPointT)[i3] < pFieldT->fBoundingBox[AS_MIN][i3])
					pFieldT->fBoundingBox[AS_MIN][i3] = (*pfPointT)[i3];
				if((*pfPointT)[i3] > pFieldT->fBoundingBox[1][i3])
					pFieldT->fBoundingBox[1][i3] = (*pfPointT)[i3];
			}
		}
	}
} // end LEVEL::CalculateFieldBoundingBoxes()

void LEVEL::RealculateFieldBoundingBoxesZCoord(void)
{ // begin LEVEL::RecalculateFieldBoundingBoxesZCoord()
	FLOAT3 *pfPointT;
	FIELD *pFieldT;
	int i, i2;

	// Realculate only the z coord of the field bounding boxes: (for frustum culling)
	for(i = 0; i < iFields; i++)
	{
		pFieldT = &pField[i];
		
		// Setup:
		pFieldT->fBoundingBox[AS_MIN][Z] = 1000;
		pFieldT->fBoundingBox[AS_MIN][Z] = -1000;

		// Get the fields bounding box:
		for(i2 = 0; i2 < 4; i2++)
		{
			pfPointT = &fPoint[pFieldT->iPoint[i2]];
			
			if((*pfPointT)[Z] < pFieldT->fBoundingBox[AS_MIN][Z])
				pFieldT->fBoundingBox[AS_MIN][Z] = (*pfPointT)[Z];
			if((*pfPointT)[Z] > pFieldT->fBoundingBox[1][Z])
				pFieldT->fBoundingBox[1][Z] = (*pfPointT)[Z];
		}
	}
} // end LEVEL::RealculateFieldBoundingBoxesZCoord()

FLOAT3 *LEVEL::GetPoint(int fX, int fY, POINT_TYPE Type)
{ // begin LEVEL::GetPoint()
	switch(Type)
	{
		case POINT_FIX: return &fFixPoint[fY*iWidth+fX]; break;
		case POINT_CURRENT: return &fPoint[fY*iWidth+fX]; break;
		case POINT_WATER: return &fWaterPoint[fY*iWidth+fX]; break;
	}
	return NULL;
} // end LEVEL::GetPoint()

void LEVEL::GetPoint(float fX, float fY, INT2 &iPos)
{ // begin LEVEL::GetPoint()
	iPos[X] = (int) fX;
	if(fX-iPos[X] > 0.5f)
		iPos[X]++;
	if(iPos[X] < 0)
		iPos[X] = 0;
	if(iPos[X] >= iWidth)
		iPos[X] = iWidth-1;

	iPos[Y] = (int) fY;
	if(fY-iPos[Y] > 0.5f)
		iPos[Y]++;
	if(iPos[Y] < 0)
		iPos[Y] = 0;
	if(iPos[Y] >= iHeight)
		iPos[Y] = iHeight-1;
} // end LEVEL::GetPoint()

void LEVEL::DrawSkyCube(void)
{ // begin LEVEL::DrawSkyCube()
	glColor3f(1.0f-fFogDensity/2, 1.0f-fFogDensity/2, 1.0f-fFogDensity/2);
	glCallList(iSkyCubeList);
} // end LEVEL::DrawSkyCube()

void LEVEL::SetupLights(void)
{ // begin LEVEL::SetupLights()
	float fLightData[4]  = {0.0f, 0.0f, 0.0f, 0.0f};

	if(_AS->iActiveLights+1 < _AS->iMaxLights)
	{ // General environment light:
		GLfloat LightAmbient[]	= { 0.01f, 0.01f-fFogDensity/100, 0.01f-fFogDensity/100, 1.0f };
		GLfloat LightDiffuse[]	= { 0.3f, 0.3f-fFogDensity/10, 0.3f-fFogDensity/10, 1.0f }; 

		fLightData[0] = fWidth/2-0.5f;
		fLightData[1] = fHeight/2-0.5f;
		fLightData[2] = -30+fHighestPoint-5.0f;
		fLightData[3] = 1.0f;
		glLightfv(GL_LIGHT0+_AS->iActiveLights, GL_POSITION, fLightData);
		glLightfv(GL_LIGHT0+_AS->iActiveLights, GL_AMBIENT , LightAmbient);
		glLightfv(GL_LIGHT0+_AS->iActiveLights, GL_DIFFUSE, LightDiffuse);
		glEnable(GL_LIGHT0+_AS->iActiveLights); 
		_AS->iActiveLights++;
	}
	if(_AS->iActiveLights+1 < _AS->iMaxLights)
	{ // Ablaze space light:
		fLightData[0] = fWidth/2-0.5f;
		fLightData[1] = fHeight/2-0.5f;
		fLightData[2] = fMiddleHeight-2;
		fLightData[3] = 1.0f;
		glLightfv(GL_LIGHT0+_AS->iActiveLights, GL_POSITION, fLightData);
		fLightData[0] = fCurrentAblazeSpaceColor[1][0][R];
		fLightData[1] = fCurrentAblazeSpaceColor[1][0][G];
		fLightData[2] = fCurrentAblazeSpaceColor[1][0][B];
		fLightData[3] = 0.0f;
		glLightfv(GL_LIGHT0+_AS->iActiveLights, GL_DIFFUSE, fLightData);
		glEnable(GL_LIGHT0+_AS->iActiveLights); 
		_AS->iActiveLights++;
	}
} // end LEVEL::SetupLights()

void LEVEL::Draw(void)
{ // begin LEVEL::Draw()
	int i,iV1, iV2, iV3, iV4;
	FIELD *pFieldT;

	FOVUpdate();

	ASEnableLighting();
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);
	glDisable(GL_BLEND);

	glEnableClientState(GL_VERTEX_ARRAY);
	if(_ASConfig->bHightRenderQuality)
		glEnableClientState(GL_COLOR_ARRAY);
	glEnableClientState(GL_NORMAL_ARRAY);
	glVertexPointer(3, GL_FLOAT, 0, fPoint);
	if(_ASConfig->bHightRenderQuality)
		glColorPointer(3, GL_FLOAT, 0, fPointColor);
	glNormalPointer(GL_FLOAT, 0, fPointNormal);
	if(_AS->bCompiledVertexArraySupported)
		glLockArraysEXT(0, iPoints);

	// Draw the grid:
	if(!_ASConfig->bMultitexturing)
	{
		glEnableClientState(GL_TEXTURE_COORD_ARRAY);
		glTexCoordPointer(2, GL_FLOAT, 0, fPointTexCoord);
		glColor3f(1.0f, 1.0f, 1.0f);

		glBindTexture(GL_TEXTURE_2D, GameTexture[5].iOpenGLID);
		for(i = 0; i < iFields; i++)
		{
			pFieldT = pInFOVFields[i];
			if(!pFieldT)
				break;

			// Draw the field quad:
			glBegin(GL_TRIANGLE_STRIP);
				glArrayElement(pFieldT->iPoint[3]);
				glArrayElement(pFieldT->iPoint[2]);
				glArrayElement(pFieldT->iPoint[0]);
				glArrayElement(pFieldT->iPoint[1]);
			glEnd();
		}
		glDisableClientState(GL_TEXTURE_COORD_ARRAY);
	}
	else
	{
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		// Render unit 1:
		glActiveTextureARB(GL_TEXTURE0_ARB);
		glEnable(GL_TEXTURE_2D);
		ASEnableLighting();
		glColor3f(1.0f, 1.0f, 1.0f);
		glBindTexture(GL_TEXTURE_2D, GameTexture[5].iOpenGLID);
		
		// Render unit 2: (terrain detail texture)
		glActiveTextureARB(GL_TEXTURE1_ARB);
		ASEnableLighting();
		glColor3f(1.0f, 1.0f, 1.0f);
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, GameTexture[8].iOpenGLID);

		for(i = 0; i < iFields; i++)
		{
			pFieldT = pInFOVFields[i];
			if(!pFieldT)
				break;
				
			// Get the points:
			iV1 = pFieldT->iPoint[3];
			iV2 = pFieldT->iPoint[2];
			iV3 = pFieldT->iPoint[0];
			iV4 = pFieldT->iPoint[1];

			// Draw the field quad:
			glBegin(GL_TRIANGLE_STRIP);
				glMultiTexCoord2fARB(GL_TEXTURE0_ARB, (float) fPointTexCoord[iV1][X], (float) fPointTexCoord[iV1][Y]);
				glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 0.0f, 0.0f);
				glArrayElement(iV1);
				glMultiTexCoord2fARB(GL_TEXTURE0_ARB, (float) fPointTexCoord[iV2][X], (float) fPointTexCoord[iV2][Y]);
				glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 1.0f, 0.0f);
				glArrayElement(iV2);
				glMultiTexCoord2fARB(GL_TEXTURE0_ARB, (float) fPointTexCoord[iV3][X], (float) fPointTexCoord[iV3][Y]);
				glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 1.0f, 1.0f);
				glArrayElement(iV3);
				glMultiTexCoord2fARB(GL_TEXTURE0_ARB, (float) fPointTexCoord[iV4][X], (float) fPointTexCoord[iV4][Y]);
				glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 0.0f, 0.0f);
				glArrayElement(iV4);
			glEnd();
		}

		glDisable(GL_TEXTURE_2D);
		glDisable(GL_BLEND);
		glDisableClientState(GL_COLOR_ARRAY);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);
		glActiveTextureARB(GL_TEXTURE0_ARB);
	}

	if(_AS->bCompiledVertexArraySupported)
		glUnlockArraysEXT();
	glDisableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_COLOR_ARRAY);
	glDisableClientState(GL_NORMAL_ARRAY);
	Quadtree.ShowBoundingBox();
} // end LEVEL::Draw()

void LEVEL::CreateWallsList(void)
{ // begin LEVEL::CreateWallsLists()
	iWallsList[0] = glGenLists(2);
	glNewList(iWallsList[0], GL_COMPILE);
		// The sides:
		glBegin(GL_QUADS);
			// Left:
			glColor4f(1.0f, 0.5f, 0.5f, 0.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(0.0f, 0.0f, fHighestPoint-10.0f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(0.0f, fHeight, fHighestPoint-10.0f);
			glColor4f(1.0f, 0.5f, 0.5f, 0.9f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(0.0f, fHeight, fLowestPoint);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(0.0f, 0.0f, fLowestPoint);

			// Top:
			glColor4f(1.0f, 0.5f, 0.5f, 0.9f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(0.0f, 0.0f, fLowestPoint);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(fWidth, 0.0f, fLowestPoint);
			glColor4f(1.0f, 0.5f, 0.5f, 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(fWidth, 0.0f, fHighestPoint-10.0f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(0.0f, 0.0f, fHighestPoint-10.0f);

			// Right:
			glColor4f(1.0f, 0.5f, 0.5f, 0.9f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(fWidth, 0.0f, fLowestPoint);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(fWidth, fHeight, fLowestPoint);
			glColor4f(1.0f, 0.5f, 0.5f, 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(fWidth, fHeight, fHighestPoint-10.0f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(fWidth, 0.0f, fHighestPoint-10.0f);

			// Bottom:
			glColor4f(1.0f, 0.5f, 0.5f, 0.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(0.0f, fHeight, fHighestPoint-10.0f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(fWidth, fHeight, fHighestPoint-10.0f);
			glColor4f(1.0f, 0.5f, 0.5f, 0.9f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(fWidth, fHeight, fLowestPoint);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(0.0f, fHeight, fLowestPoint);
		glEnd();

	glEndList();

	iWallsList[1] = iWallsList[0]+1;
	glNewList(iWallsList[1], GL_COMPILE);
		// The floor sides:
		glBegin(GL_QUADS);
			// Left:
			glColor4f(1.0f, 0.5f, 0.5f, 0.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(-10.0f, -10.0f, fLowestPoint);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(-10.0f, fHeight+10.0f, fLowestPoint);
			glColor4f(1.0f, 0.5f, 0.5f, 0.9f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(0.0f, fHeight, 0.0f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(0.0f, 0.0f, 0.0f);

			// Top:
			glColor4f(1.0f, 0.5f, 0.5f, 0.9f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(0.0f, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(fWidth, 0.0f, 0.0f);
			glColor4f(1.0f, 0.5f, 0.5f, 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(fWidth+10.0f, -10.0f, fLowestPoint);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(-10.0f, -10.0f, fLowestPoint);

			// Right:
			glColor4f(1.0f, 0.5f, 0.5f, 0.9f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(fWidth, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(fWidth, fHeight, 0.0f);
			glColor4f(1.0f, 0.5f, 0.5f, 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(fWidth+10.0f, fHeight+10.0f, fLowestPoint);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(fWidth+10.0f, -10.0f, fLowestPoint);

			// Bottom:
			glColor4f(1.0f, 0.5f, 0.5f, 0.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(-10.0f, fHeight+10.0f, fLowestPoint);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(fWidth+10.0f, fHeight+10.0f, fLowestPoint);
			glColor4f(1.0f, 0.5f, 0.5f, 0.9f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(fWidth, fHeight, 0.0f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(0.0f, fHeight, 0.0f);
		glEnd();

	glEndList();
} // end LEVEL::CreateWallsLists()

void LEVEL::DestroyWallsList(void)
{ // begin LEVEL::DestroyWallsLists()
	if(glIsList(iWallsList[0]))
		glDeleteLists(iWallsList[0], 2);
} // end LEVEL::DestroyWallsLists()

void LEVEL::CreateAblazeSpaceColumnLists(void)
{ // begin CreateAblazeSpaceColumnLists()
	GLUquadricObj *pQuadric;

	pQuadric = gluNewQuadric();
	gluQuadricDrawStyle(pQuadric, GLU_FILL);
	gluQuadricNormals(pQuadric, GLU_SMOOTH);
	gluQuadricTexture(pQuadric, GL_TRUE);

	iAblazeSpaceColumnList[0] = glGenLists(24);
	for(int i = 0; i < 24; i++)
	{
		iAblazeSpaceColumnList[i] = iAblazeSpaceColumnList[0]+i;
		glNewList(iAblazeSpaceColumnList[i], GL_COMPILE);
			gluCylinder(pQuadric, 1.0f, 1.0f, 1.0f, (int) (6+i), 1);
		glEndList();
	}
	gluDeleteQuadric(pQuadric);
} // end CreateAblazeSpaceColumnLists()

void LEVEL::DestroyAblazeSpaceColumnLists(void)
{ // begin LEVEL::DestroyAblazeSpaceColumnLists()
	if(glIsList(iAblazeSpaceColumnList[0]))
		glDeleteLists(iAblazeSpaceColumnList[0], 24);
} // end LEVEL::DestroyAblazeSpaceColumnLists()

void LEVEL::DrawWalls(void)
{ // begin LEVEL::DrawWalls()
	// Create smooth walls:
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glDisable(GL_LIGHTING);
	glDepthMask(FALSE);

	glBindTexture(GL_TEXTURE_2D, Caust1Texture[iWallAniStep[0]].iOpenGLID);
	glCallList(iWallsList[0]);
	glBindTexture(GL_TEXTURE_2D, Caust1Texture[iWallAniStep[1]].iOpenGLID);
	glCallList(iWallsList[1]);

	// The animated sides:
	glBindTexture(GL_TEXTURE_2D, Caust1Texture[iWallAniStep[1]].iOpenGLID);
	glBegin(GL_QUADS);
		// Left:
		glColor4f(1.0f, 0.5f, 0.5f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-10.0f, -10.0f, -fAniWallHeight);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(-10.0f, fHeight+10.0f, -fAniWallHeight);
		glColor4f(1.0f, 0.5f, 0.5f, 0.9f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(0.0f, fHeight, fLowestPoint);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(0.0f, 0.0f, fLowestPoint);

		// Top:
		glColor4f(1.0f, 0.5f, 0.5f, 0.9f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(0.0f, 0.0f, fLowestPoint);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(fWidth, 0.0f, fLowestPoint);
		glColor4f(1.0f, 0.5f, 0.5f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(fWidth+10.0f, -10.0f, -fAniWallHeight);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-10.0f, -10.0f, -fAniWallHeight);

		// Right:
		glColor4f(1.0f, 0.5f, 0.5f, 0.9f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(fWidth, 0.0f, fLowestPoint);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(fWidth, fHeight, fLowestPoint);
		glColor4f(1.0f, 0.5f, 0.5f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(fWidth+10.0f, fHeight+10.0f, -fAniWallHeight);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(fWidth+10.0f, -10.0f, -fAniWallHeight);

		// Bottom:
		glColor4f(1.0f, 0.5f, 0.5f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-10.0f, fHeight+10.0f, -fAniWallHeight);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(fWidth+10.0f, fHeight+10.0f, -fAniWallHeight);
		glColor4f(1.0f, 0.5f, 0.5f, 0.9f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(fWidth, fHeight, fLowestPoint);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(0.0f, fHeight, fLowestPoint);
	glEnd();

	glDepthMask(TRUE);
	ASEnableLighting();
} // end LEVEL::DrawWalls()

void LEVEL::DrawAblazeColumn(void)
{ // begin LEVEL::DrawAblazeColumn()
	int i, iDetail;
	
	glDisable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, Caust1Texture[iWallAniStep[0]].iOpenGLID);
	glTranslatef(fCenter[X], fCenter[Y], -30+fHighestPoint-2.0f);
	glDisable(GL_BLEND);
	glColor4f(1.0f*fCurrentAblazeColumnRadius[0], 0.8f*fCurrentAblazeColumnRadius[0], 0.2f*fCurrentAblazeColumnRadius[0], 0.9f*fCurrentAblazeColumnRadius[0]);

	// Draw the sphere:
	if(ASSphereInFrustum(fCenter[X], fCenter[Y], -30+fHighestPoint-5.0f, 4))
	{
		glPushMatrix();
		glTranslatef(0.0f, 0.0f, -3.0f);
		iDetail = (int) (30*_ASConfig->fGeometricDetails);
		if(iDetail > (int) (30*_ASConfig->fGeometricDetails))
			iDetail = (int) (30*_ASConfig->fGeometricDetails);
		if(iDetail < 8)
			iDetail = 8;
		glScalef(4.0f, 4.0f, 4.0f);
		glCallList(iSphereList[iDetail-8]);
		glPopMatrix();
	}
	glDepthMask(FALSE);
	glEnable(GL_BLEND);
	
	// Draw the column:
	if(ASCubeInFrustum(fCenter[X]-1.0f, fCenter[X]+1.0f, fCenter[Y]-1.0f, fCenter[Y]+1.0f, -30+fHighestPoint-2.0f+fMiddleHeight, fMiddleHeight))
	{
		glDisable(GL_CULL_FACE);
		for(i = 0; i < 3; i++)
		{
			glPushMatrix();
			glScalef(fCurrentAblazeColumnRadius[i], fCurrentAblazeColumnRadius[i], 30-fHighestPoint+fMiddleHeight);
			glColor4f(1.0f*fCurrentAblazeColumnRadius[i], 0.8f*fCurrentAblazeColumnRadius[i], 0.2f*fCurrentAblazeColumnRadius[i], 0.9f*fCurrentAblazeColumnRadius[i]);
			iDetail = (int) (23*_ASConfig->fGeometricDetails);
			glCallList(iAblazeSpaceColumnList[iDetail]);
			glPopMatrix();
		}
		ParticleManager.pSystem[PS_ABLAZE_SPACE].bActive = TRUE;
		glEnable(GL_CULL_FACE);
	}
	else
		ParticleManager.pSystem[PS_ABLAZE_SPACE].bActive = FALSE;
	ASEnableLighting();
} // end LEVEL::DrawAblazeColumn()

void LEVEL::DrawWater(void)
{ // begin LEVEL::DrawWater()
	int i, iX, iY, iV1, iV2, iV3, iV4;
	FIELD *pFieldT;

	if(_ASCamera->bUnderWater || bNoWater)
		return;
	glDepthMask(FALSE);
	glNormal3f(0.0f, 0.0f, -1.0f);
	
	// Render unit 1: (water)
	if(_ASConfig->bMultitexturing)
	{
		glActiveTextureARB(GL_TEXTURE0_ARB);
		glColor3f(0.0f, 0.0f, 0.5f);
	}
	else
		glColor4f(0.1f, 0.1f, 0.8f, 0.5f);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, Caust1Texture[iWallAniStep[0]].iOpenGLID);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	// Render unit 2: (environment water)
	if(_ASConfig->bMultitexturing)
	{
		glActiveTextureARB(GL_TEXTURE1_ARB);
		glEnable(GL_TEXTURE_2D);
		if(!_ASConfig->bHightRenderQuality)
		{
			glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
			glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
		}
		else
		{
			glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
			glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		}
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		glColor4f(0.0f, 0.0f, 0.8f, 0.5f);
		glBindTexture(GL_TEXTURE_2D, Caust1Texture[Level.iWallAniStep[0]].iOpenGLID);
	}

	if(_ASConfig->bWaterWaves)
	{	// Setup vertex array:
		glEnableClientState(GL_VERTEX_ARRAY);
		glVertexPointer(3, GL_FLOAT, 0, fWaterPoint);
		if(_AS->bCompiledVertexArraySupported)
			glLockArraysEXT(0, iPoints);

		// Draw the water:
		glBegin(GL_QUADS);
			if(!_ASConfig->bMultitexturing)
			{
				// Draw the water surface:
				if(ASCubeInFrustum(0.0f, fWidth, 0.0f, fHeight, fCurrentWaterHeight, fCurrentWaterHeight-0.01f))
				{
					for(i = 0; i < iFields; i++)
					{
						pFieldT = pInFOVFields[i];
						if(!pFieldT)
							break;

						// Check if this water field could be seen:
						if(!bWaterFieldVisible[pFieldT->iID])
							continue; // It couldn't be seen!

						// Draw the water quad:
						iV1 = pFieldT->iPoint[3];
						iV2 = pFieldT->iPoint[2];
						iV3 = pFieldT->iPoint[1];
						iV4 = pFieldT->iPoint[0];

						glTexCoord2f(0.0f, 0.0f);
						glArrayElement(iV1);
						glTexCoord2f(1.0f, 0.0f);
						glArrayElement(iV2);
						glTexCoord2f(1.0f, 1.0f);
						glArrayElement(iV3);
						glTexCoord2f(0.0f, 1.0f);
						glArrayElement(iV4);
					}
				}
			}
			else
			{ // Draw the water surface:
				if(ASCubeInFrustum(0.0f, fWidth, 0.0f, fHeight, fCurrentWaterHeight, fCurrentWaterHeight-0.01f))
				{
					for(i = 0; i < iFields; i++)
					{
						pFieldT = pInFOVFields[i];
						if(!pFieldT)
							break;

						// Check if this water field could be seen:
						if(!bWaterFieldVisible[pFieldT->iID])
							continue; // It couldn't be seen!

						// Draw the water quad:
						iV1 = pFieldT->iPoint[3];
						iV2 = pFieldT->iPoint[2];
						iV3 = pFieldT->iPoint[1];
						iV4 = pFieldT->iPoint[0];

						glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 0.0f, 0.0f);
						glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 0.0f, 0.0f);
						glArrayElement(iV1);
						glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 1.0f, 0.0f);
						glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 1.0f, 0.0f);
						glArrayElement(iV2);
						glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 1.0f, 1.0f);
						glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 1.0f, 1.0f);
						glArrayElement(iV3);
						glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 0.0f, 1.0f);
						glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 0.0f, 1.0f);
						glArrayElement(iV4);
					}
				}
			}

			// Draw the water bounding at the level boundings:
			// Left side:
			if(ASCubeInFrustum(0.0f, 0.001f, 0.0f, fHeight, fLowestPoint, fCurrentWaterHeight-0.01f))
			{
				for(iY = 0; iY < iHeight-1; iY++)
				{
					if(!pField[iY*(iWidth-1)].bInFOV)
						continue;
					iV1 = (iY+1)*iWidth;
					iV2 = iY*iWidth;
					glArrayElement(iV1);
					glArrayElement(iV2);
					glVertex3f(fWaterPoint[iV2][0], fWaterPoint[iV2][Y], fLowestPoint);
					glVertex3f(fWaterPoint[iV1][0], fWaterPoint[iV1][Y], fLowestPoint);
				}
			}
			
			// Top side:
			if(ASCubeInFrustum(0.0f, fWidth, 0.0f, 0.001f, fLowestPoint, fCurrentWaterHeight-0.01f))
			{
				for(iX = 0; iX < iWidth-1; iX++)
				{
					if(!pField[iX].bInFOV)
						continue;
					iV1 = iX;
					iV2 = iX+1;
					glArrayElement(iV1);
					glArrayElement(iV2);
					glVertex3f(fWaterPoint[iV2][X], fWaterPoint[iV2][Y], fLowestPoint);
					glVertex3f(fWaterPoint[iV1][X], fWaterPoint[iV1][Y], fLowestPoint);
				}
			}
			
			// Right side:
			if(ASCubeInFrustum(fWidth, fWidth+0.001f, 0.0f, fHeight, fLowestPoint, fCurrentWaterHeight-0.01f))
			{
				for(iX = iWidth-1, iY = 0; iY < iHeight-1; iY++)
				{
					if(!pField[iX+iY*iX].bInFOV)
						continue;
					iV1 = iY*iWidth+iX;
					iV2 = (iY+1)*iWidth+iX;
					glArrayElement(iV1);
					glArrayElement(iV2);
					glVertex3f(fWaterPoint[iV2][X], fWaterPoint[iV2][Y], fLowestPoint);
					glVertex3f(fWaterPoint[iV1][X], fWaterPoint[iV1][Y], fLowestPoint);
				}
			}

			// Bottom side:
			if(ASCubeInFrustum(0.0f, fWidth, fHeight, fHeight+0.001f, fLowestPoint, fCurrentWaterHeight-0.01f))
			{
				for(iY = iHeight-1, iX = 0; iX < iWidth-1; iX++)
				{
					if(!pField[iX+iY*(iWidth-1)].bInFOV)
						continue;
					iV1 = iY*iWidth+(iX+1);
					iV2 = iY*iWidth+iX;
					glArrayElement(iV1);
					glArrayElement(iV2);
					glVertex3f(fWaterPoint[iV2][X], fWaterPoint[iV2][Y], fLowestPoint);
					glVertex3f(fWaterPoint[iV1][X], fWaterPoint[iV1][Y], fLowestPoint);
				}
			}
		glEnd();

		if(_AS->bCompiledVertexArraySupported)
			glUnlockArraysEXT();
		glDisableClientState(GL_VERTEX_ARRAY);
	}
	else
	{ // Water surface:
		if(!_ASConfig->bMultitexturing)
		{
			glBegin(GL_QUADS);
				glTexCoord2f(0.0f, 0.0f);
				glVertex3f(0.0f, fHeight, fCurrentWaterHeight);
				glTexCoord2f(fWidth*10, 0.0f);
				glVertex3f(fWidth, fHeight, fCurrentWaterHeight);
				glTexCoord2f(fWidth*10, fHeight*10);
				glVertex3f(fWidth, 0.0f, fCurrentWaterHeight);
				glTexCoord2f(0.0f, fHeight*10);
				glVertex3f(0.0f, 0.0f, fCurrentWaterHeight);

				// Draw the water bounding at the level boundings:
				// Left side:
				glVertex3f(0.0f, 0.0f, fLowestPoint);
				glVertex3f(0.0f, fHeight, fLowestPoint);
				glVertex3f(0.0f, fHeight, fCurrentWaterHeight);
				glVertex3f(0.0f, 0.0f, fCurrentWaterHeight);

				// Top side:
				glVertex3f(0.0f, 0.0f, fCurrentWaterHeight);
				glVertex3f(fWidth, 0.0f, fCurrentWaterHeight);
				glVertex3f(fWidth, 0.0f, fLowestPoint);
				glVertex3f(0.0f, 0.0f, fLowestPoint);

				// Right side:
				glVertex3f(fWidth, 0.0f, fCurrentWaterHeight);
				glVertex3f(fWidth, fHeight, fCurrentWaterHeight);
				glVertex3f(fWidth, fHeight, fLowestPoint);
				glVertex3f(fWidth, 0.0f, fLowestPoint);

				// Bottom side:
				glVertex3f(0.0f, fHeight, fLowestPoint);
				glVertex3f(fWidth, fHeight, fLowestPoint);
				glVertex3f(fWidth, fHeight, fCurrentWaterHeight);
				glVertex3f(0.0f, fHeight, fCurrentWaterHeight);
			glEnd();
		}
		else
		{
			glBegin(GL_QUADS);
				glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 0.0f, 0.0f);
				glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 0.0f, 0.0f);
				glVertex3f(0.0f, fHeight, fCurrentWaterHeight);
				glMultiTexCoord2fARB(GL_TEXTURE0_ARB, fWidth, 0.0f);
				glMultiTexCoord2fARB(GL_TEXTURE1_ARB, fWidth, 0.0f);
				glVertex3f(fWidth, fHeight, fCurrentWaterHeight);
				glMultiTexCoord2fARB(GL_TEXTURE0_ARB, fWidth, fHeight);
				glMultiTexCoord2fARB(GL_TEXTURE1_ARB, fWidth, fHeight);
				glVertex3f(fWidth, 0.0f, fCurrentWaterHeight);
				glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 0.0f, fHeight);
				glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 0.0f, fHeight);
				glVertex3f(0.0f, 0.0f, fCurrentWaterHeight);

				// Draw the water bounding at the level boundings:
				// Left side:
				glVertex3f(0.0f, 0.0f, fLowestPoint);
				glVertex3f(0.0f, fHeight, fLowestPoint);
				glVertex3f(0.0f, fHeight, fCurrentWaterHeight);
				glVertex3f(0.0f, 0.0f, fCurrentWaterHeight);

				// Top side:
				glVertex3f(0.0f, 0.0f, fCurrentWaterHeight);
				glVertex3f(fWidth, 0.0f, fCurrentWaterHeight);
				glVertex3f(fWidth, 0.0f, fLowestPoint);
				glVertex3f(0.0f, 0.0f, fLowestPoint);

				// Right side:
				glVertex3f(fWidth, 0.0f, fCurrentWaterHeight);
				glVertex3f(fWidth, fHeight, fCurrentWaterHeight);
				glVertex3f(fWidth, fHeight, fLowestPoint);
				glVertex3f(fWidth, 0.0f, fLowestPoint);

				// Bottom side:
				glVertex3f(0.0f, fHeight, fLowestPoint);
				glVertex3f(fWidth, fHeight, fLowestPoint);
				glVertex3f(fWidth, fHeight, fCurrentWaterHeight);
				glVertex3f(0.0f, fHeight, fCurrentWaterHeight);
			glEnd();
		}
	}
	if(_ASConfig->bMultitexturing)
	{
		glDisable(GL_TEXTURE_2D);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
		glActiveTextureARB(GL_TEXTURE0_ARB);
	}
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	glDepthMask(TRUE);
} // end LEVEL::DrawWater()

void LEVEL::DrawLightMaps(void)
{ // begin LEVEL::DrawLightMaps()
	ACTOR *pActor;
	AS_DLIGHT Light1;

	if(!_ASConfig->bLightmaps)
		return;

	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glBindTexture(GL_TEXTURE_2D, GameTexture[17].iOpenGLID);
	glDepthMask(FALSE);
	glDisable(GL_LIGHTING);
	glDepthFunc(GL_EQUAL);

	// Ablaze space:
	Light1.vPos.fX = fWidth/2-0.5f;
	Light1.vPos.fY = fHeight/2-0.5f;
	Light1.vPos.fZ = fMiddleHeight-1.0f;
	Light1.vColor.fX = fCurrentAblazeSpaceColor[1][2][R];
	Light1.vColor.fY = fCurrentAblazeSpaceColor[1][2][G];
	Light1.vColor.fZ = fCurrentAblazeSpaceColor[1][2][B];
	Light1.fRadius = 5;
	// Terrain:
	PerformLightShadowMapOnTerrain(Light1);

	Light1.fRadius = 3;
	for(int i = 0; i < MAX_ACTORS; i++)
	{
		pActor = &Actor[i];
		if(!pActor->bActive || !pActor->bInFOV)
			continue;
		Light1.vPos = pActor->vWorldPos;
		switch(Actor[i].Type)
		{
			case ACTOR_AblazeBall:
				Light1.vColor.fX = pActor->fFire;
				Light1.vColor.fY = 
				Light1.vColor.fZ = 0.0f;
			break;

			case ACTOR_AiringObj:
				Light1.vColor.fX = 
				Light1.vColor.fY = 0.0f;
				Light1.vColor.fZ = 1.0f;
			break;

			case ACTOR_FireBombObj:
				Light1.vColor.fX = 1.0f;
				Light1.vColor.fY = 0.0f;
				Light1.vColor.fZ = 1.0f;
			break;

			case ACTOR_SparkObj:
				Light1.vColor.fX = 1.0f;
				Light1.vColor.fY = 1.0f;
				Light1.vColor.fZ = 0.0f;
			break;

			case ACTOR_ThrustEngineObj:
				Light1.vColor.fX = 0.0f;
				Light1.vColor.fY = 1.0f;
				Light1.vColor.fZ = 0.0f;
			break;
			
			case ACTOR_TerraformEngineObj:
				Light1.vColor.fX = 0.5f;
				Light1.vColor.fY = 0.5f;
				Light1.vColor.fZ = 0.5f;
			break;
		}
		
		// Scale the color:
		Light1.vColor.fX *= pActor->fRadius/pActor->fNormalRadius;
		Light1.vColor.fY *= pActor->fRadius/pActor->fNormalRadius;
		Light1.vColor.fZ *= pActor->fRadius/pActor->fNormalRadius;
		
		// Terrain:
		PerformLightShadowMapOnTerrain(Light1);
	}
	glDepthFunc(GL_LESS);
	glDepthMask(TRUE);
} // end LEVEL::DrawLightMaps()

void LEVEL::DrawShadowMaps(void)
{ // begin LEVEL::DrawShadowMaps()
	float fX, fY, fD;
	AS_DLIGHT Light1;
	ACTOR *pActor;

	if(!_ASConfig->bShadowmaps)
		return;

	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glBindTexture(GL_TEXTURE_2D, GameTexture[34].iOpenGLID);
	glEnable(GL_ALPHA_TEST);
	glAlphaFunc(GL_GEQUAL, 0.0f);
	glBlendFunc(GL_ZERO, GL_ONE_MINUS_SRC_ALPHA);
	glDepthMask(FALSE);
	glDisable(GL_LIGHTING);
	glDepthFunc(GL_EQUAL);

	for(int i = 0; i < MAX_ACTORS; i++)
	{
		pActor = &Actor[i];
		if(!pActor->bActive || !pActor->bInFOV)
			continue;
		Light1.vPos = pActor->vWorldPos;
		fX = (pActor->vWorldPos.fX-(iWidth/2))/50;
		fY = (pActor->vWorldPos.fY-(iHeight/2))/50;
		fD = ASFastSqrt(fX*fX+fY*fY);
		Light1.vPos.fX += fX;
		Light1.vPos.fY += fY;

		Light1.fRadius = pActor->fRadius*2+fD/2;
		Light1.fDensity = 0.5f-fD/2;

		// Scale the color:
		Light1.vColor.fX *= pActor->fRadius/pActor->fNormalRadius;
		Light1.vColor.fY *= pActor->fRadius/pActor->fNormalRadius;
		Light1.vColor.fZ *= pActor->fRadius/pActor->fNormalRadius;
		
		// Terrain:
		PerformLightShadowMapOnTerrain(Light1);
	}

	glDepthFunc(GL_LESS);
	glDepthMask(TRUE);
	glDisable(GL_ALPHA_TEST);
	glAlphaFunc(GL_GEQUAL, 1.0f);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
} // end LEVEL::DrawShadowMaps()

void LEVEL::PerformLightShadowMapOnTerrain(AS_DLIGHT Light)
{ // begin LEVEL::PerformLightShadowMapOnTerrain()
	int iXStart, iYStart, iXEnd, iYEnd, iX, iY;
	AS_3D_VECTOR vV1, vV2, vV3, vV4;
	FLOAT3 **pfPoint;
	FIELD *pFieldT;
	
	if(!_ASConfig->bWaterWaves)
		return;
	iXStart = (int) (Light.vPos.fX-Light.fRadius-1);
	iXEnd = (int) (Light.vPos.fX+Light.fRadius);
	iYStart = (int) (Light.vPos.fY-Light.fRadius-1);
	iYEnd = (int) (Light.vPos.fY+Light.fRadius);
	if(iXStart < 0)
		iXStart = 0;
	if(iYStart < 0)
		iYStart = 0;
	pfPoint = &fPoint;
	glBegin(GL_TRIANGLES);
		// Loop through all faces in mesh:
		for(iY = iYStart; iY <= iYEnd; iY++)
		{
			if(iY >= iHeight-1)
				break;
			for(iX = iXStart; iX <= iXEnd; iX++)
			{
				if(iX >= iWidth-1)
					break;

				// Is it visible?
				pFieldT = &pField[iX+iY*(iWidth-1)];
				if(!pFieldT->bInFOV)
					continue;

				vV1 = (*pfPoint)[pFieldT->iPoint[0]];
				vV2 = (*pfPoint)[pFieldT->iPoint[1]];
				vV3 = (*pfPoint)[pFieldT->iPoint[2]];
				vV4 = (*pfPoint)[pFieldT->iPoint[3]];
				Light.Light(vV4, vV3, vV1, vNormalRight[pFieldT->iNormal[0]], vNormalUp[pFieldT->iNormal[0]], Plane[pFieldT->iNormal[0]]);
				Light.Light(vV3, vV2, vV1, vNormalRight[pFieldT->iNormal[1]], vNormalUp[pFieldT->iNormal[1]], Plane[pFieldT->iNormal[1]]);
			}
		}
	glEnd();
} // end LEVEL::PerformLightShadowMapOnTerrain()

void LEVEL::Check(void)
{ // begin LEVEL::Check()
	FLOAT3 *fFixPointT, *fPointT;
	int iX, iY, i, i2, i3, iCurrentPoint;
	AS_PARTICLE *pParticleT;
	AS_3D_VECTOR vDelta;
	char byTemp[256];
	ACTOR *pActorT;
	float fTemp;

	if(bNoWater)
		fCurrentWaterHeight = 2.0f;
	if(bNoFog)
		fFogDensity = 0.0f;

	if((bTerrainUpdate && g_lNow-lLastTerrainUpdateTime > 1000) || 
	    g_lNow-lLastTerrainUpdateTime > 10000)
	{
		bTerrainUpdate = FALSE;
		lLastTerrainUpdateTime = g_lNow;
		CalculateNormals();
		RealculateFieldBoundingBoxesZCoord();
		Quadtree.GetBoundingBoxZCoord(this);
	}

	// Compute the water points:
	if(_ASConfig->bWaterWaves)
	{
		for(i = 0; i < iPoints; i++)
		{
			iCurrentPoint = iVisiblePoints[i];
			if(iCurrentPoint == -1)
				break;
			fWaterPoint[iCurrentPoint][Z] = (float) (fCurrentWaterHeight+fWaterAmplitude[iCurrentPoint]*0.6f*((sin(fWaterPoint[iCurrentPoint][X]+fWaterWavesTimer)+sin(fWaterPoint[iCurrentPoint][Y]+fWaterWavesTimer))));
		}
	}
	else
		for(i = 0; i < iPoints; i++)
			fWaterPoint[i][Z] = fCurrentWaterHeight;

	fGeneralGameBlend += (float) g_lDeltatime/1000;
	if(fGeneralGameBlend > 1.0f)
		fGeneralGameBlend = 1.0f;

	if(bPause)
		return;

	if(!(5-Level.iAblazeBallsInAblazeSpace) && !bGameWon)
	{ // The game is finished!
		ASPlayFmodSample(pGameWonSample, FSOUND_LOOP_OFF);
		StopMusic();
		strcpy(byCurrentMusic, "neardark.s3m");
		iCurrentSelectedMusic = -1;
		StartCurrentMusic();
		//Give the player extra points:
		Player.pActor->iSparks = 0;
		_ASCamera->fShakePower = Player.pActor->fThrustPower = 1.0f;
		Player.pActor->fFire = 1.0f;
		Player.iScore += 1500;
		sprintf(byTemp, "+1500 %s", T_Points);
		CreateTextActor(byTemp, Player.pActor->vWorldPos);

		ParticleManager.pSystem[PS_CENTER_ABLAZE].bActive = TRUE;
		bFlashBlend = TRUE;
		bGameWon = TRUE;
		fGameOverBlend = 0.0f;
		dwGameWonStartTime = g_lNow;
	}
	if(bGameWon && g_lNow-dwGameWonStartTime > 20000 && !bShowHighscore)
	{
		bShowGameMenu = TRUE;

		// Enable the highscore
		Player.pActor->fThrustPower = 0.0f;
		bPause = bShowHighscore = TRUE;
		bPlayerEnteringHighScore = TRUE;
		byPlayersHScorePlace = -1;
		fGameMenuBlend = 0.0f;
	}
	
	// Generate new X and Y coordinates for the grid:
	for(iY = 0; iY < iHeight; iY++)
	{
		for(iX = 0; iX < iWidth; iX++)
		{
			fPointT = &fPoint[iY*iWidth+iX];
			fFixPointT = &fFixPoint[iY*iWidth+iX];

			// Finally set the coordinates:
			if(!iX || !iY || iX >= iWidth-1 || iY >= iHeight-1)
			{ // Level outline:
				(*fPointT)[Z] = fLowestPoint;
			}
			else
			{
				// Ablaze space:
				if(iX > iWidth/2-3 && iX < iWidth/2+2 &&
				   iY > iHeight/2-3 && iY < iHeight/2+2)
				{
					if((iX == iProngPos[0][X] && iY == iProngPos[0][Y]) ||
					   (iX == iProngPos[1][X] && iY == iProngPos[1][Y]) ||
					   (iX == iProngPos[2][X] && iY == iProngPos[2][Y]) ||
					   (iX == iProngPos[3][X] && iY == iProngPos[3][Y]))
					{ // Point is a prong:
						(*fPointT)[Z] = fHighestPoint-2.0f;
					}
					else	
					if(iX > iWidth/2-2 && iX < iWidth/2+1 &&
					   iY > iHeight/2-2 && iY < iHeight/2+1)
					{ // Inner part:
						(*fPointT)[Z] = fMiddleHeight-2.0f;
					}
					else
					{ // Outer part:
						(*fPointT)[Z] = fMiddleHeight-3.0f;
					}
				}
			}
		}
	}

	// Animate the middle wall movement:
	if(g_lNow-dwAniWallHeight > dwAniWallHeightSpeed || !dwAniWallHeightSpeed)
	{
		dwAniWallHeight = g_lNow;
		dwAniWallHeightSpeed = rand() % 5000;
		dwAniWallHeightSpeed += 2000;
		fLastAniWallHeight = fAniWallHeight;
		fNewAniWallHeight = (float) (rand() % (int) -fHighestPoint*100)/100;
	}
	fAniWallHeight = fLastAniWallHeight+(fNewAniWallHeight-fLastAniWallHeight)*((float) (0.5f-0.5f*cos(sin(((float) (g_lNow-dwAniWallHeight)/dwAniWallHeightSpeed)*PI)*PI)));

	// Create some fog:
	if(g_lNow-dwLastFogTime > 10+(300-300*_ASConfig->fParticleDensity)+200-(200*fFogDensity))
	{
		dwLastFogTime = g_lNow;
		for(i2 = 0; i2 < 20-(15-15*_ASConfig->fParticleDensity)-(15-(15*fFogDensity)); i2++)
		{
			i = ParticleManager.pSystem[PS_WATER_STREAM].GetFreeParticle();
			if(i != -1)
			{
				pParticleT = &ParticleManager.pSystem[PS_WATER_STREAM].pParticle[i];
				pParticleT->fPos[X] = ((float) (rand() % (int) (Level.fWidth*100))/100);
				pParticleT->fPos[Y] = ((float) (rand() % (int) (Level.fHeight*100))/100);
				if(pField[((int) pParticleT->fPos[X])+((int) pParticleT->fPos[Y])*(iWidth-1)].bInFOV)
				{
					pParticleT->bAlive = TRUE;
					pParticleT->fEngine = (float) 1.0f;
					pParticleT->fColor[0] = 0.0f;
					pParticleT->fColor[1] = 0.0f;
					pParticleT->fColor[2] = 0.0f;
					pParticleT->fFadeSpeed = 0.00001f+((float) (rand() % 100)/100000);
					pParticleT->fSize = 0.8f+(rand() % (int) (1.0f*100))/100;
					if(!(rand() % 2))
						pParticleT->fVelocity[X] = (float) (rand() % 1000)/1000;
					else
						pParticleT->fVelocity[X] = (float) -(rand() % 1000)/1000;
					if(!(rand() % 2))
						pParticleT->fVelocity[Y] = (float) (rand() % 1000)/1000;
					else
						pParticleT->fVelocity[Y] = (float) -(rand() % 1000)/1000;
					pParticleT->fVelocity[Z] = -((float) 0.01f+((float) (rand() % 1000)/1000));
					pParticleT->fPos[Z] = Level.FastComputeHeight(pParticleT->fPos[X], pParticleT->fPos[Y],
																  POINT_WATER);
				}
			}
		}
	}
		
	// Animate the wall textures:
	for(i = 0; i < 3; i++)
	{
		if(g_lNow-dwWallAniTime[i] < (unsigned) iWallAniSpeed[i])
			continue;
		dwWallAniTime[i] = g_lNow;
		iWallAniStep[i]++;
		if(iWallAniStep[i] >= 32)
			iWallAniStep[i] = 0;
	}

	// Animate the water:
	fWaterWavesTimer += (float) g_lDeltatime/800;
	fCurrentWaterDensity = 0.8f;

	CreateWaterBubbles();

	// Animate the ablaze space:
	for(i3 = 0; i3 < 2; i3++)
	{
		for(i = 0; i < 4; i++)
		{
			if(g_lNow-lAblazeSpaceAniTime[i3][i] > iAblazeSpaceAniSpeed[i3][i] || !iAblazeSpaceAniSpeed[i3][i])
			{
				lAblazeSpaceAniTime[i3][i] = g_lNow;
				iAblazeSpaceAniSpeed[i3][i] = (int) (100.0f+((float) (rand() % 10000)/100.0f));
				if(!i3)
				{ // Ablaze space:
					fTemp = 0.2f+(rand() % 100)/20.0f;
					for(i2 = 0; i2 < 3; i2++)
					{
						fLastAblazeSpaceColor[i3][i][i2] = fCurrentAblazeSpaceColor[i3][i][i2];
						fNextAblazeSpaceColor[i3][i][i2] = fTemp;
					}
				}
				else
				{ // Ablaze space:
					for(i2 = 0; i2 < 3; i2++)
						fLastAblazeSpaceColor[i3][i][i2] = fCurrentAblazeSpaceColor[i3][i][i2];
					fNextAblazeSpaceColor[i3][i][i2] = 0.7f+(rand() % 100)/70.0f;
					fTemp = (rand() % 100)/60.0f;
					for(i2 = 1; i2 < 3; i2++)
						fNextAblazeSpaceColor[i3][i][i2] = fTemp;
				}
			}
			
			// Get the current ablaze space color:
			for(i2 = 0; i2 < 3; i2++)
				fCurrentAblazeSpaceColor[i3][i][i2] = fLastAblazeSpaceColor[i3][i][i2]+(fNextAblazeSpaceColor[i3][i][i2]-fLastAblazeSpaceColor[i3][i][i2])*((float) (g_lNow-lAblazeSpaceAniTime[i3][i])/iAblazeSpaceAniSpeed[i3][i]);
		}
	}

	// Animate the ablaze columns:
	if(!bGameWon)
	{
		for(i = 0; i < 3; i++)
		{
			if(g_lNow-lAblazeColumnAniTime[i3] > iAblazeColumnAniSpeed[i3] || !iAblazeColumnAniSpeed[i])
			{
				lAblazeColumnAniTime[i] = g_lNow;
				iAblazeColumnAniSpeed[i] = (int) (100.0f+((float) (rand() % 10000)/100.0f));
				fLastAblazeColumnRadius[i] = fCurrentAblazeColumnRadius[i];
				fNextAblazeColumnRadius[i] = (rand() % 100)/100.0f;
			}
			
			// Get the current ablaze column radius:
			fCurrentAblazeColumnRadius[i] = fLastAblazeColumnRadius[i]+(fNextAblazeColumnRadius[i]-fLastAblazeColumnRadius[i])*((float) (g_lNow-lAblazeColumnAniTime[i])/iAblazeColumnAniSpeed[i]);
		}
	}
	else
	{
		for(i = 0; i < 3; i++)
			fCurrentAblazeColumnRadius[i] += (float) g_lDeltatime/1000;
	}

	if(!bPause)
	{
		// Increase the water height:
		fCurrentWaterHeight -= (float) g_lDeltatime/40000;

		// Decrease fog:
		fFogDensity -= (float) g_lDeltatime/800000;
		if(fFogDensity < 0.0f)
			fFogDensity = 0.0f;
		if(fFogDensity > 6.0f)
			fFogDensity = 6.0f;

		// Check airing objects:
		if(g_lNow-lLastAiringObjectTime < 0)
			lLastAiringObjectTime = g_lNow;
		if(g_lNow-lLastAiringObjectTime > 30000)
		{ // Create a new airing object:
			lLastAiringObjectTime = g_lNow;
			if(iAiringObjects < 5)
			{
				pActorT = FindFreeActor();
				if(pActorT)
				{
					iAiringObjects++;
					pActorT->bActive = TRUE;
					pActorT->Type = ACTOR_AiringObj;
					pActorT->fRadius = 0.01f;
					pActorT->fNormalRadius = 0.4f;
					pActorT->fMass = (float) (pActorT->fRadius*PI);
					
					// Set the obects position:
					pActorT->vWorldPos.fZ = fHighestPoint-30.0f;
					for(;;)
					{
						if((rand() % 2))
							pActorT->vWorldPos.fX = (float) Level.fWidth/2+(rand() % ((int) Level.fWidth/2*1000))/1000;
						else
							pActorT->vWorldPos.fX = (float) Level.fWidth/2-(rand() % ((int) Level.fWidth/2*1000))/1000;
						if((rand() % 2))
							pActorT->vWorldPos.fY = (float) Level.fHeight/2+(rand() % ((int) Level.fHeight/2*1000))/1000;
						else
							pActorT->vWorldPos.fY = (float) Level.fHeight/2-(rand() % ((int) Level.fHeight/2*1000))/1000;
						break;
					}
				}
			}
		}

		// Check fire bomb objects:
		if(g_lNow-lLastFireBombObjectTime < 0)
			lLastFireBombObjectTime = g_lNow;
		if(g_lNow-lLastFireBombObjectTime > 200000)
		{ // Create a new firebomb object:
			lLastFireBombObjectTime = g_lNow;
			if(iFireBombObjects < 1)
			{
				pActorT = FindFreeActor();
				if(pActorT)
				{
					iFireBombObjects++;
					pActorT->bActive = TRUE;
					pActorT->Type = ACTOR_FireBombObj;
					pActorT->fRadius = 0.01f;
					pActorT->fNormalRadius = 0.4f;
					pActorT->fMass = (float) (pActorT->fRadius*PI);
					
					// Set the obects position:
					pActorT->vWorldPos.fZ = fHighestPoint-30.0f;
					for(;;)
					{
						if((rand() % 2))
							pActorT->vWorldPos.fX = (float) Level.fWidth/2+(rand() % ((int) Level.fWidth/2*1000))/1000;
						else
							pActorT->vWorldPos.fX = (float) Level.fWidth/2-(rand() % ((int) Level.fWidth/2*1000))/1000;
						if((rand() % 2))
							pActorT->vWorldPos.fY = (float) Level.fHeight/2+(rand() % ((int) Level.fHeight/2*1000))/1000;
						else
							pActorT->vWorldPos.fY = (float) Level.fHeight/2-(rand() % ((int) Level.fHeight/2*1000))/1000;
						break;
					}
				}
			}
		}

		// Check spark objects:
		if(g_lNow-lLastSparkObjectTime < 0)
			lLastSparkObjectTime = g_lNow;
		if(g_lNow-lLastSparkObjectTime > 8000)
		{ // Create a new spark object:
			lLastSparkObjectTime = g_lNow;
			if(iSparkObjects < 5)
			{
				pActorT = FindFreeActor();
				if(pActorT)
				{
					iSparkObjects++;
					pActorT->bActive = TRUE;
					pActorT->Type = ACTOR_SparkObj;
					pActorT->fRadius = 0.01f;
					pActorT->fNormalRadius = 0.4f;
					pActorT->fMass = (float) (pActorT->fRadius*PI);
					
					// Set the obects position:
					pActorT->vWorldPos.fZ = (float) -(rand() % ((int) (fHighestPoint-30.0f-fLowestPoint)*100))/100;
					for(;;)
					{
						if((rand() % 2))
							pActorT->vWorldPos.fX = (float) Level.fWidth/2+1.0f+(rand() % ((int) (Level.fWidth/2-1.0f)*1000))/1000;
						else
							pActorT->vWorldPos.fX = (float) Level.fWidth/2-1.0f-(rand() % ((int) (Level.fWidth/2-1.0f)*1000))/1000;
						if((rand() % 2))
							pActorT->vWorldPos.fY = (float) Level.fHeight/2+1.0f+(rand() % ((int) (Level.fHeight/2-1.0f)*1000))/1000;
						else
							pActorT->vWorldPos.fY = (float) Level.fHeight/2-1.0f-(rand() % ((int) (Level.fHeight/2-1.0f)*1000))/1000;
						break;
					}
				}
			}
		}

		// Check thrust engine objects:
		if(g_lNow-lLastThrustEngineObjectTime < 0)
			lLastThrustEngineObjectTime = g_lNow;
		if(g_lNow-lLastThrustEngineObjectTime > 100000)
		{ // Create a new thrust object:
			lLastThrustEngineObjectTime = g_lNow;
			if(iThrustEngineObjects < 1)
			{
				pActorT = FindFreeActor();
				if(pActorT)
				{
					iThrustEngineObjects++;
					pActorT->bActive = TRUE;
					pActorT->Type = ACTOR_ThrustEngineObj;
					pActorT->fRadius = 0.01f;
					pActorT->fNormalRadius = 0.4f;
					pActorT->fMass = (float) (pActorT->fRadius*PI);
					
					// Set the obects position:
					pActorT->vWorldPos.fZ = fHighestPoint-30.0f;
					for(;;)
					{
						if((rand() % 2))
							pActorT->vWorldPos.fX = (float) Level.fWidth/2+(rand() % ((int) Level.fWidth/2*1000))/1000;
						else
							pActorT->vWorldPos.fX = (float) Level.fWidth/2-(rand() % ((int) Level.fWidth/2*1000))/1000;
						if((rand() % 2))
							pActorT->vWorldPos.fY = (float) Level.fHeight/2+(rand() % ((int) Level.fHeight/2*1000))/1000;
						else
							pActorT->vWorldPos.fY = (float) Level.fHeight/2-(rand() % ((int) Level.fHeight/2*1000))/1000;
						break;
					}
				}
			}
		}

		// Check terraform engine objects:
		if(g_lNow-lLastTerraformEngineObjectTime < 0)
			lLastTerraformEngineObjectTime = g_lNow;
		if(g_lNow-lLastTerraformEngineObjectTime > 110000)
		{ // Create a new terraform object:
			lLastTerraformEngineObjectTime = g_lNow;
			if(iTerraformEngineObjects < 1)
			{
				pActorT = FindFreeActor();
				if(pActorT)
				{
					iTerraformEngineObjects++;
					pActorT->bActive = TRUE;
					pActorT->Type = ACTOR_TerraformEngineObj;
					pActorT->fRadius = 0.01f;
					pActorT->fNormalRadius = 0.4f;
					pActorT->fMass = (float) (pActorT->fRadius*PI);
					
					// Set the obects position:
					pActorT->vWorldPos.fZ = fHighestPoint-30.0f;
					for(;;)
					{
						if((rand() % 2))
							pActorT->vWorldPos.fX = (float) Level.fWidth/2+(rand() % ((int) Level.fWidth/2*1000))/1000;
						else
							pActorT->vWorldPos.fX = (float) Level.fWidth/2-(rand() % ((int) Level.fWidth/2*1000))/1000;
						if((rand() % 2))
							pActorT->vWorldPos.fY = (float) Level.fHeight/2+(rand() % ((int) Level.fHeight/2*1000))/1000;
						else
							pActorT->vWorldPos.fY = (float) Level.fHeight/2-(rand() % ((int) Level.fHeight/2*1000))/1000;
						break;
					}
				}
			}
		}
	}


	// Setup ablaze space colors into the grid points colors:
	for(i = 0; i < 4; i++)
	{
		for(i2 = 0; i2 < 3; i2++)
		{
			fPointColor[iProngPos[i][X]+iProngPos[i][Y]*iWidth][i2] = fCurrentAblazeSpaceColor[0][i][i2];
			fPointColor[iAblazeSpacePos[i][X]+iAblazeSpacePos[i][Y]*iWidth][i2] = fCurrentAblazeSpaceColor[1][i][i2];
		}
	}
} // end LEVEL::Check()

void LEVEL::FOVUpdate(void)
{ // begin LEVEL::FOVUpdate()
	int i, i2, i3, i4, iV1, iV2, iV3, iV4;
	FIELD *pFieldT;

	// Get the update the fields in FOV list:
	if(_ASConfig->bFrustumCulling)
	{
		Quadtree.CheckInFOV();
		Quadtree.CheckFieldsInFOV();
	}
	else
	{
		for(i = 0; i < iFields; i++)
			pField[i].bInFOV = TRUE;
	}

	// Get the pointers to the visible fields and points:
	memset(bPointVisible, 0, sizeof(BOOL)*iPoints);
	memset(bWaterFieldVisible, 0, sizeof(BOOL)*iFields);
	for(i = 0, i2 = 0, i4 = 0; i < iFields; i++)
	{
		if(!pField[i].bInFOV)
			continue;
		pFieldT = pInFOVFields[i2] = &pField[i];
		for(i3 = 0; i3 < 4; i3++)
		{
			if(bPointVisible[pField[i].iPoint[i3]])
				continue;
			bPointVisible[pField[i].iPoint[i3]] = TRUE;
			iVisiblePoints[i4] = pField[i].iPoint[i3];
			i4++;
		}
		i2++;

		// Check if this water field could be seen:
		iV1 = pFieldT->iPoint[3];
		iV2 = pFieldT->iPoint[2];
		iV3 = pFieldT->iPoint[1];
		iV4 = pFieldT->iPoint[0];
		if(fWaterPoint[iV1][Z] < fPoint[iV1][Z] ||
		   fWaterPoint[iV2][Z] < fPoint[iV2][Z] ||
		   fWaterPoint[iV3][Z] < fPoint[iV3][Z] ||
		   fWaterPoint[iV4][Z] < fPoint[iV4][Z])
			bWaterFieldVisible[i] = TRUE; // It could be seen!
		else
			bWaterFieldVisible[i] = FALSE; // It couldn't be seen!
	}
	pInFOVFields[i2] = NULL;
	iVisiblePoints[i4] = -1;
	iVisibleFieldsNumber = i2;
	iVisiblePointsNumber = i4;
} // end LEVEL::FOVUpdate();

AS_3D_VECTOR LEVEL::CollideWithWorld(AS_3D_VECTOR vPosition, AS_3D_VECTOR vVelocity, BOOL bSlide)
{ // begin LEVEL::CollideWithWorld()
	// Do we need to worry?
	if(vVelocity.GetLength() < AS_EPSILON)
		return vPosition;

	AS_3D_VECTOR vPos;
	AS_3D_VECTOR vDestinationPoint = vPosition+vVelocity;

	// Reset the collision package we send to the mesh:
	ASCollisionPacket.vVelocity = vVelocity;
	ASCollisionPacket.vSourcePoint = vPosition;
	ASCollisionPacket.bFoundCollision = FALSE;
	ASCollisionPacket.bStuck = FALSE;
	ASCollisionPacket.dNearestDistance = -1;

	// Check all meshes:
	CheckCollision();	

	// Check return value here, and possibly call recursively:
	if(!ASCollisionPacket.bFoundCollision)
	{  // If no collision move very close to the desired destination:
		AS_3D_VECTOR vV = vVelocity;
		
		vV.SetLength((float) (vV.GetLength()-AS_EPSILON));

		// Update the last safe position for future error recovery:
		ASCollisionPacket.vLastSafePosition = vPosition;      

		// Return the final position:
		return vPosition+vV;
	}
	else
	{ // There was a collision:
		// If we are stuck, we just back up to last safe position:
		if(ASCollisionPacket.bStuck)
		{	// Okay, sometimes we end up inside our sphere, and we're stuck.
			// That's because this collision detection is designed to be in full
			// 3D, and in a normal stuck situation, we would not have this problem
			// because it would be a backface.

			// We can probably get stuck in any wedge... but the dangerous one is
			// when we are stuck in the ground.			
			return ASCollisionPacket.vLastSafePosition;
		}

		// OK, first task is to move close to where we hit something:
		AS_3D_VECTOR vNewSourcePoint;
               
		// Only update if we are not already very close:
		if(ASCollisionPacket.dNearestDistance >= EPSILON+1.0f)
		{
			AS_3D_VECTOR vV = vVelocity;
			vV.SetLength((float) (ASCollisionPacket.dNearestDistance-EPSILON));
			vNewSourcePoint = ASCollisionPacket.vSourcePoint+vV;
		}
		else
			vNewSourcePoint = ASCollisionPacket.vSourcePoint;
		if(!bSlide)
			return vNewSourcePoint;

		// Now we must calculate the sliding plane:
		AS_3D_VECTOR vSlidePlaneOrigin = ASCollisionPacket.vNearestPolygonIntersectionPoint;
		AS_3D_VECTOR vSlidePlaneNormal = vNewSourcePoint-ASCollisionPacket.vNearestPolygonIntersectionPoint;
  
		// We now project the destination point onto the sliding plane:
		double dL = ASIntersectRayPlane(vDestinationPoint, vSlidePlaneNormal, 
										vSlidePlaneOrigin, vSlidePlaneNormal); 

		// We can now calculate a new destination point on the sliding plane:
		AS_3D_VECTOR vNewDestinationPoint;
		vNewDestinationPoint.fX = (float) (vDestinationPoint.fX+dL*vSlidePlaneNormal.fX);
		vNewDestinationPoint.fY = (float) (vDestinationPoint.fY+dL*vSlidePlaneNormal.fY);
		vNewDestinationPoint.fZ = (float) (vDestinationPoint.fZ+dL*vSlidePlaneNormal.fZ);

		// Generate the slide vector, which will become our new velocity vector
		// for the next iteration:
		AS_3D_VECTOR vNewVelocityVector = vNewDestinationPoint-ASCollisionPacket.vNearestPolygonIntersectionPoint;
   
		// Now we recursively call the function with the new position and velocity:
		ASCollisionPacket.vLastSafePosition = vPosition;
		return CollideWithWorld(vNewSourcePoint, vNewVelocityVector, bSlide);
	}
} // end LEVEL::CollideWithWorld()

void LEVEL::CheckCollision(void)
{ // begin LEVEL::CheckCollision()
	FIELD *pFieldT;
	int iX, iY, i;
	
	// Plane data:
	AS_3D_VECTOR vP1, vP2, vP3;
	AS_3D_VECTOR vPNormal;
	AS_3D_VECTOR vPOrigin;
	AS_3D_VECTOR vV1, vV2;

	// From package:
	AS_3D_VECTOR vSource = ASCollisionPacket.vSourcePoint;
	AS_3D_VECTOR vERadius = ASCollisionPacket.vERadius;
	AS_3D_VECTOR vVelocity = ASCollisionPacket.vVelocity;	

	// Keep a copy of this as it's needed a few times:
	AS_3D_VECTOR vNormalizedVelocity = vVelocity;
	vNormalizedVelocity.Normalize();

	// Intersection data:
	AS_3D_VECTOR vSIPoint; // Sphere intersection point
	AS_3D_VECTOR vPIPoint; // Plane intersection point
	AS_3D_VECTOR vPolyIPoint; // Polygon intersection point

	// How long is our velocity?
	double dDistanceToTravel = vVelocity.GetLength(),
		   dDistToPlaneIntersection,
		   dDistToEllipsoidIntersection;

	int iXStart, iYStart, iXEnd, iYEnd;
	
	if(vVelocity.fX > 0.0f)
	{
		iXStart = (int) ((vSource.fX-1.0f)*vERadius.fX);
		iXEnd = (int) ((vSource.fX+vVelocity.fX+1.0f)*vERadius.fX);
	}
	else
	{
		iXStart = (int) ((vSource.fX+vVelocity.fX-1.0f)*vERadius.fX);
		iXEnd = (int) ((vSource.fX+1.0f)*vERadius.fX);
	}
	if(vVelocity.fY > 0.0f)
	{
		iYStart = (int) ((vSource.fY-1.0f)*vERadius.fX);
		iYEnd = (int) ((vSource.fY+vVelocity.fY+1.0f)*vERadius.fX);
	}
	else
	{
		iYStart = (int) ((vSource.fY+vVelocity.fY-1.0f)*vERadius.fX);
		iYEnd = (int) ((vSource.fY+1.0f)*vERadius.fX);
	}
	if(iXStart < 0)
		iXStart = 0;
	if(iYStart < 0)
		iYStart = 0;
	// Loop through all faces in mesh:
	for(iY = iYStart; iY <= iYEnd; iY++)
	{
		if(iY >= iHeight-1)
			break;
		for(iX = iXStart; iX <= iXEnd; iX++)
		{
			if(iX >= iWidth-1)
				break;
			pFieldT = &pField[iX+iY*(iWidth-1)];
			for(i = 0; i < 2; i++)
			{
				if(!i)
				{ // First triangle:
					vP1 = fPoint[pFieldT->iPoint[3]];
					vP2 = fPoint[pFieldT->iPoint[2]];
					vP3 = fPoint[pFieldT->iPoint[0]];
					vPNormal = fNormal[pFieldT->iNormal[0]];
				}
				else
				{ // Second triangle:
					vP1 = fPoint[pFieldT->iPoint[2]];
					vP2 = fPoint[pFieldT->iPoint[1]];
					vP3 = fPoint[pFieldT->iPoint[0]];
					vPNormal = fNormal[pFieldT->iNormal[1]];
				}

				// Get the data for the triangle in question and scale to ellipsoid space
				vP1 = vP1/vERadius;
				vP2 = vP2/vERadius;
				vP3 = vP3/vERadius;

				// Make the plane containing this triangle:
				vPOrigin = vP1;
				vV1 = vP2-vP1;
				vV2 = vP3-vP1;

				// Ignore backfaces. What we cannot see we cannot collide with ;)
				if(vPNormal.DotProduct(vNormalizedVelocity) <= 1.0f)
				{ 
					// Calculate sphere intersection point:
					vSIPoint = vSource-vPNormal;     

					// Classify point to determine if ellipsoid span the plane:
					DWORD pClass = ASClassifyPoint(vSIPoint, vPOrigin, vPNormal);

					// Find the plane intersection point:
					if(pClass == PLANE_BACKSIDE)
					{ // Plane is embedded in ellipsoid:
						// Find plane intersection point by shooting a ray from the 
						// sphere intersection point along the planes normal:
						dDistToPlaneIntersection = ASIntersectRayPlane(vSIPoint, vPNormal, vPOrigin, vPNormal);

						// Calculate plane intersection point:
						vPIPoint.fX = (float) (vSIPoint.fX+dDistToPlaneIntersection*vPNormal.fX); 
						vPIPoint.fY = (float) (vSIPoint.fY+dDistToPlaneIntersection*vPNormal.fY); 
						vPIPoint.fZ = (float) (vSIPoint.fZ+dDistToPlaneIntersection*vPNormal.fZ); 	
					} 
					else
					{
						// Shoot ray along the velocity vector:
						dDistToPlaneIntersection = ASIntersectRayPlane(vSIPoint, vNormalizedVelocity, vPOrigin, vPNormal);

						if(dDistToPlaneIntersection < EPSILON && dDistToPlaneIntersection > 0.0f)
							dDistToPlaneIntersection = dDistToPlaneIntersection;
						// Calculate plane intersection point:
						vPIPoint.fX = (float) (vSIPoint.fX+dDistToPlaneIntersection*vNormalizedVelocity.fX);
						vPIPoint.fY = (float) (vSIPoint.fY+dDistToPlaneIntersection*vNormalizedVelocity.fY);
						vPIPoint.fZ = (float) (vSIPoint.fZ+dDistToPlaneIntersection*vNormalizedVelocity.fZ);
					}

					// Find polygon intersection point. By default we assume its equal to the 
					// plane intersection point:
					vPolyIPoint = vPIPoint;
					dDistToEllipsoidIntersection = dDistToPlaneIntersection;

					if(!ASCheckPointInTriangle(vPIPoint, vP1, vP2, vP3))
					{ // If not in triangle:
						vPolyIPoint = ASClosestPointOnTriangle(vP1, vP2, vP3, vPIPoint);	
						dDistToEllipsoidIntersection = ASIntersectRaySphere(vPolyIPoint, -vNormalizedVelocity, vSource, 1.0f);

						if(dDistToEllipsoidIntersection > 0)
						{ // Calculate true sphere intersection point:
     						vSIPoint.fX = (float) (vPolyIPoint.fX+dDistToEllipsoidIntersection*(-vNormalizedVelocity.fX));
     						vSIPoint.fY = (float) (vPolyIPoint.fY+dDistToEllipsoidIntersection*(-vNormalizedVelocity.fY));
     						vSIPoint.fZ = (float) (vPolyIPoint.fZ+dDistToEllipsoidIntersection*(-vNormalizedVelocity.fZ));
						}
					} 

  					// Here we do the error checking to see if we got ourself stuck last frame:
   					if(ASCheckPointInSphere(vPolyIPoint, vSource, 1.0f)) 
					{
						ASCollisionPacket.vLastSphereCollisionPoint = vSIPoint;
						ASCollisionPacket.bStuck = TRUE;
					}
					
					// Ok, now we might update the collision data if we hit something:
					if((dDistToEllipsoidIntersection > 0) && (dDistToEllipsoidIntersection <= dDistanceToTravel))
					{ 
						if((!ASCollisionPacket.bFoundCollision) || (dDistToEllipsoidIntersection < ASCollisionPacket.dNearestDistance))
						{ // If we are hit we have a closest hit so far. We save the information:
							ASCollisionPacket.dNearestDistance = dDistToEllipsoidIntersection;
							ASCollisionPacket.vNearestIntersectionPoint = vSIPoint;
							ASCollisionPacket.vNearestPolygonIntersectionPoint = vPolyIPoint;
							ASCollisionPacket.bFoundCollision = ASCollisionPacket.bFoundACollision = TRUE;
							ASCollisionPacket.vLastSphereCollisionPoint = vSIPoint;
						}
					} 
				}
			}
		}
	}
} // end LEVEL::CheckCollision()

float LEVEL::FastComputeHeight(float fX, float fY, POINT_TYPE Type)
{ // begin LEVEL::FastComputeHeight()
	FLOAT3 pLTPoint, pRTPoint, pRBPoint, pLBPoint;
	float fPointXPos, fPointYPos,
	      fPointHeight, fLeftPointHeight, fRightPointHeight;
	int iPointXPos, iPointYPos;

	// Check if the point is in the level:
	if(fX < 0.0f || fY < 0.0f || fX >= fWidth || fY >= fHeight)
		return -1.0f;

	// Compute the current points we are on:
	iPointXPos = (int) fX;
	iPointYPos = (int) fY;

	// Get the pointer to the points:
	memcpy(&pLTPoint, GetPoint(iPointXPos, iPointYPos, Type), sizeof(FLOAT3));
	memcpy(&pRTPoint, GetPoint(iPointXPos+1, iPointYPos, Type), sizeof(FLOAT3));
	memcpy(&pRBPoint, GetPoint(iPointXPos+1, iPointYPos+1, Type), sizeof(FLOAT3));
	memcpy(&pLBPoint, GetPoint(iPointXPos, iPointYPos+1, Type), sizeof(FLOAT3));

	// Compute the x and y pos in the field the points create:
	fPointXPos = 1.0f-(fX-iPointXPos);
	fPointYPos = fY-iPointYPos;

	// Now compute the heigt on this field position:
	// First we compute the left and right field height on this field y pos:
	if(!(pLBPoint[Z]-pLTPoint[Z]))
		fLeftPointHeight = pLTPoint[Z];
	else
		fLeftPointHeight = pLTPoint[Z]+(pLBPoint[Z]-pLTPoint[Z])/(pLBPoint[Y]-pLTPoint[Y])*fPointYPos;
	if(!(pRBPoint[Z]-pRTPoint[Z]))
		fRightPointHeight = pRTPoint[Z];
	else
		fRightPointHeight = pRTPoint[Z]+(pRBPoint[Z]-pRTPoint[Z])/(pRBPoint[Y]-pRTPoint[Y])*fPointYPos;

	// Compute now the hight on the x positon on the field:
	if(!(fLeftPointHeight-fRightPointHeight))
		fPointHeight = fLeftPointHeight;
	else
		fPointHeight = fRightPointHeight+(fLeftPointHeight-fRightPointHeight)/(pRTPoint[X]-pLTPoint[X])*fPointXPos;

	// Yea, we calculated the corresponding height of this x and y position in the level,
	// give the height back;
	return fPointHeight;
} // end LEVEL::FastComputeHeight()

void LEVEL::CreateWaterBubbles(void)
{ // begin LEVEL::CreateWaterBubbles()
	AS_PARTICLE_SYSTEM *pSystemT;
	AS_PARTICLE *pParticleT;
	int i, i2;
	
	if(g_lNow-dwLastWaterBubbleTime < (unsigned) dwWaterBubbleSpeed)
		return;
	dwLastWaterBubbleTime = g_lNow;
	dwWaterBubbleSpeed = rand() % 3;
	pSystemT = &ParticleManager.pSystem[PS_WATER_BUBBLES];
	for(i2 = 0; i2 < 20-(15-15*_ASConfig->fParticleDensity); i2++)
	{
		i = pSystemT->GetFreeParticle();
		if(i == -1)
			return;

		pParticleT = &pSystemT->pParticle[i];
		pParticleT->fPos[X] = pSystemT->fStartPos[X] = ((float) (rand() % (int) (fWidth*100))/100);
		pParticleT->fPos[Y] = pSystemT->fStartPos[Y] = ((float) (rand() % (int) (fHeight*100))/100);
		if(pField[((int) pParticleT->fPos[X])+((int) pParticleT->fPos[Y])*(iWidth-1)].bInFOV)
		{
			pParticleT->bAlive = TRUE;
			pParticleT->fEngine = 1.0f;
			pParticleT->fColor[0] = 1.0f;
			pParticleT->fColor[1] = 1.0f;
			pParticleT->fColor[2] = 1.0f;
			pParticleT->fFadeSpeed = 0.005f;
			pParticleT->fSize = (float) (rand() % 1000)/2000;
			if(pParticleT->fSize < 0.1f)
				pParticleT->fSize = 0.1f;
			if(!(rand() % 2))
				pParticleT->fVelocity[X] = (float) (rand() % 1000)/2000;
			else
				pParticleT->fVelocity[X] = (float) -(rand() % 1000)/2000;
			if(!(rand() % 2))
				pParticleT->fVelocity[Y] = (float) (rand() % 1000)/2000;
			else
				pParticleT->fVelocity[Y] = (float) -(rand() % 1000)/2000;
			pParticleT->fVelocity[Z] = (float) -(rand() % 100)/1000;
			if(!pParticleT->fVelocity[Z])
				pParticleT->fVelocity[Z] = -0.01f;
			pParticleT->fPos[Z] = pSystemT->fStartPos[Z] = FastComputeHeight(pParticleT->fPos[X],
																			 pParticleT->fPos[Y],
																			 POINT_CURRENT);
			if(pParticleT->fPos[Z] <= fCurrentWaterHeight)
				pParticleT->bAlive = FALSE; // No bubbles on land, please:
		}
	}
} // end LEVEL::CreateWaterBubbles()
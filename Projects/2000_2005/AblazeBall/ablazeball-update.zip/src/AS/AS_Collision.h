//-----------------------------------------------------------------------------
// File: AS_Collsison.h
//-----------------------------------------------------------------------------

#ifndef __AS_COLLISION_H__
#define __AS_COLLISION_H__


// Definitions: ***************************************************************
#define AS_PLANE_BACKSIDE 0x000001
#define AS_PLANE_FRONT    0x000010
#define AS_ON_PLANE       0x000100
///////////////////////////////////////////////////////////////////////////////

// Structures: ****************************************************************
typedef struct AS_COLLISION_PACKET
{
	// Data about player movement:
	AS_3D_VECTOR vVelocity; // The current velocity
	AS_3D_VECTOR vSourcePoint; // The point were we started
	AS_3D_VECTOR vERadius; // Radius of ellipsoid

	// For error handling:
	AS_3D_VECTOR vLastSafePosition; // The last safe position
	AS_3D_VECTOR vLastSphereCollisionPoint; // The last sphere collision point were the struck occur
	BOOL bStuck; // Does we stuck something?

	// Data for collision response:
	BOOL bFoundCollision, // Was there an collision?
		 bFoundACollision; // Was there an collision in the whole process?
	double dNearestDistance; // Nearest distance to hit
	AS_3D_VECTOR vNearestIntersectionPoint; // On sphere
	AS_3D_VECTOR vNearestPolygonIntersectionPoint; // On polygon

} AS_COLLISION_PACKET;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern AS_COLLISION_PACKET ASCollisionPacket;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern double ASIntersectRayPlane(AS_3D_VECTOR&, AS_3D_VECTOR&, AS_3D_VECTOR&, AS_3D_VECTOR&);
extern BOOL ASCheckPointInTriangle(AS_3D_VECTOR&, AS_3D_VECTOR&, AS_3D_VECTOR&, AS_3D_VECTOR&);
extern AS_3D_VECTOR ASClosestPointOnLine(AS_3D_VECTOR&, AS_3D_VECTOR&, AS_3D_VECTOR&);
extern AS_3D_VECTOR ASClosestPointOnTriangle(AS_3D_VECTOR&, AS_3D_VECTOR&, AS_3D_VECTOR&, AS_3D_VECTOR&);
extern BOOL ASCheckPointInSphere(AS_3D_VECTOR&, AS_3D_VECTOR&, float);
extern AS_3D_VECTOR ASTangentPlaneNormalOfEllipsoid(AS_3D_VECTOR&, AS_3D_VECTOR&, AS_3D_VECTOR&);
extern DWORD ASClassifyPoint(AS_3D_VECTOR&, AS_3D_VECTOR&, AS_3D_VECTOR&);
extern double ASIntersectRaySphere(AS_3D_VECTOR&, AS_3D_VECTOR&, AS_3D_VECTOR&, float);
extern BOOL ASCheckLineInBox(FLOAT3, FLOAT3, FLOAT3 [2]);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_COLLISION_H__
//-----------------------------------------------------------------------------
// File: AS_Fmod.cpp
//-----------------------------------------------------------------------------

#include "AS_Engine.h"


// Functions: *****************************************************************
BOOL ASInitFmod(void);
BOOL ASDestroyFmod(void);
BOOL ASLoadFmodSamples(char (*)[256], int, AS_FMOD_SAMPLE *);
BOOL ASDestroyFmodSamples(int, AS_FMOD_SAMPLE *);
BOOL ASLoadFmodSample(FSOUND_SAMPLE *, char *, int);
BOOL ASPlayFmodSample(FSOUND_SAMPLE *, int);
BOOL ASStopAllFmodSamples(int, AS_FMOD_SAMPLE *);
BOOL ASStopFmodSample(AS_FMOD_SAMPLE *);
BOOL ASPlayFmodMusic(AS_FMOD_MUSIC *, char *);
BOOL ASDestroyFmodMusic(AS_FMOD_MUSIC *);
///////////////////////////////////////////////////////////////////////////////


BOOL ASInitFmod(void)
{ // begin ASInitFmod()
	_AS->WriteLogMessage("Init Fmod");

	FSOUND_SetOutput(_ASConfig->bySoundOutput);
	FSOUND_SetMinHardwareChannels(AS_MAX_SOUND_CANALS);
	FSOUND_SetMaxHardwareChannels(AS_MAX_SOUND_CANALS);
	FSOUND_SetSFXMasterVolume(_ASConfig->iSoundVolume);
	if(!FSOUND_Init(44100, AS_MAX_SOUND_CANALS, 0))
	{
		_AS->WriteLogMessage("Init of Fmod failed!");
		_AS->bSoundPossible = FALSE;
		return TRUE;
	}
	_AS->bSoundPossible = TRUE;

	return FALSE;
} // end ASInitFmod()

BOOL ASDestroyFmod(void)
{ // begin ASDestroyFmod()
	if(!_AS->bSoundPossible)
		return FALSE;
	FSOUND_Close();
	return FALSE;
} // end ASDestroyFmod()

BOOL ASLoadFmodSamples(char (*byFilename)[256], int iSamples, AS_FMOD_SAMPLE *pSample)
{ // begin ASLoadFmodSamples()
	AS_PROGRESS_WINDOW ProgressWindow;
	char byTemp[256];

	if(!_AS->bSoundPossible)
		return FALSE;
	ProgressWindow.CreateProgressWindow("Sounds");
	ProgressWindow.SetTask("Load sounds...");
	ProgressWindow.SetProgress(0);

	_AS->WriteLogMessage("Load sounds");
	for(int i = 0; i < iSamples; i++)
	{
		ProgressWindow.SetSubTask("%s", pSample[i].byFilename);
		ProgressWindow.SetProgress((UINT) (((float) i/iSamples)*100));
		sprintf(byTemp, "%s%s\\%s", _AS->pbyProgramPath, _AS->pbySoundFile, byFilename[i]);
		_AS->WriteLogMessage("Load sound: %s", byTemp);
		strcpy(pSample[i].byFilename, byTemp);
		if(ASLoadFmodSample(&pSample[i], pSample[i].byFilename, i))
			_AS->WriteLogMessage("Couldn't load that sound!");
	}
	return FALSE;
} // begin ASLoadFmodSamples()

BOOL ASDestroyFmodSamples(int iSamples, AS_FMOD_SAMPLE *pSample)
{ // begin ASDestroyFmodSamples()
	ASStopAllFmodSamples(iSamples, pSample);
	for(int i = 0; i < iSamples; i++)
	{
		FSOUND_StopSound(pSample[i].iCanal);
		pSample[i].iCanal = -1;
		FSOUND_Sample_Free(pSample[i].pSample);
		memset(&pSample[i], 0, sizeof(AS_FMOD_SAMPLE));
	}
	return FALSE;
} // end ASDestroyFmodSamples()

BOOL ASLoadFmodSample(AS_FMOD_SAMPLE *pSample, char *pbyFilename, int iCanal)
{ // begin ASLoadFmodSample()
	if(!_AS->bSoundPossible)
		return FALSE;
	
	for(int i  = 20; i < AS_MAX_SOUND_CANALS; i++)
	{
		if(!FSOUND_IsPlaying(i))
			break;
	}
	if(i >= AS_MAX_SOUND_CANALS)
		return FALSE; // No canal free!
	pSample->pSample = FSOUND_Sample_Load(FSOUND_FREE, pbyFilename, FSOUND_NORMAL | FSOUND_HW3D, 0); // FSOUND_STEREO
	if(!pSample->pSample)
		_AS->WriteLogMessage("Couldn't load this sound");
	pSample->iCanal = -1;
	return FALSE;
} // end ASLoadFmodSample()

BOOL ASPlayFmodSample(AS_FMOD_SAMPLE *pSample, int iMode)
{ // begin ASPlayFmodSample()
	if(!_AS->bSoundPossible || !_ASConfig->bSound ||
	   (iMode == FSOUND_LOOP_NORMAL && pSample->iCanal != -1 && FSOUND_IsPlaying(pSample->iCanal)))
		return FALSE;
	FSOUND_Sample_SetMode(pSample->pSample, iMode);
	pSample->iCanal = FSOUND_PlaySound(FSOUND_FREE, pSample->pSample);
	return FALSE;
} // end ASPlayFmodSample()

BOOL ASStopAllFmodSamples(int iSamples, AS_FMOD_SAMPLE *pSample)
{ // begin ASStopAllFmodSamples()
	for(int i = 0; i < iSamples; i++) {
		FSOUND_StopSound(pSample[i].iCanal);
		pSample[i].iCanal = -1;
	}
	return FALSE;
} // end ASStopAllFmodSamples()

BOOL ASStopFmodSample(AS_FMOD_SAMPLE *pSample)
{ // begin ASPlayFmodSample()
	if(!_AS->bSoundPossible)
		return FALSE;
	FSOUND_StopSound(pSample->iCanal);
	pSample->iCanal = -1;
	return FALSE;
} // end ASStopFmodSample()

BOOL ASPlayFmodMusic(AS_FMOD_MUSIC *pMusic, char *pbyFilename)
{ // begin ASPlayFmodMusic()
	if(!_AS->bSoundPossible || !_ASConfig->bMusic)
		return FALSE;
	_AS->WriteLogMessage("Load music: %s", pbyFilename);
	pMusic->pMod = FMUSIC_LoadSong(pbyFilename);
	if(!pMusic->pMod)
	{
		pMusic->pStream = FSOUND_Stream_OpenFile(pbyFilename, FSOUND_NORMAL | FSOUND_2D, 0);
		FSOUND_Stream_Play(FSOUND_FREE, pMusic->pStream);
	}
	else
	{
		pMusic->pStream = NULL;
		FMUSIC_PlaySong(pMusic->pMod);
	}
	if(FMUSIC_GetType(pMusic->pMod) != FMUSIC_TYPE_IT)
		FMUSIC_SetMasterVolume(pMusic->pMod, _ASConfig->iMusicVolume);
	if(FMUSIC_GetType(pMusic->pMod) == FMUSIC_TYPE_MOD || FMUSIC_GetType(pMusic->pMod) == FMUSIC_TYPE_S3M)
		FMUSIC_SetPanSeperation(pMusic->pMod, 0.85f);
	return FALSE;
} // end ASPlayFmodMusic()

BOOL ASDestroyFmodMusic(AS_FMOD_MUSIC *pMusic)
{ // begin ASDestroyFmodMusic()
	if(pMusic->pMod)
	{
		FMUSIC_FreeSong(pMusic->pMod);
		pMusic->pMod = NULL;
	}
	else
	{
		FSOUND_Stream_Close(pMusic->pStream);
		pMusic->pStream = NULL;
	}
	return FALSE;
} // end ASDestroyFmodMusic()
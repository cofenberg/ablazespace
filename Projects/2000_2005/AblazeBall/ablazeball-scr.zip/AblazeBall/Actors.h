//-----------------------------------------------------------------------------
// File: Actors.h
//-----------------------------------------------------------------------------

#ifndef __ACTORS_H__
#define __ACTORS_H__


// Definitions: ***************************************************************
#define MAX_ACTORS 60
// Actor types:
enum ACTOR_TYPE
{
	ACTOR_AblazeBall, ACTOR_AiringObj, ACTOR_FireBombObj, ACTOR_SparkObj,
	ACTOR_ThrustEngineObj, ACTOR_TerraformEngineObj, ACTOR_Text,
};
// Weapons:
enum
{
};

///////////////////////////////////////////////////////////////////////////////

// Classes: *******************************************************************
typedef class ACTOR
{
	public:
		BOOL bActive, // Is the actor active?
			 bGoingDeath, // Is he going death?
			 bInFOV, // Is this actor visible?
			 bTransparent; // Is this actor transparent?

		float fDamage, // It's damage
			  fFire, // It's fire power
			  fTerraformEngine;

		char byName[256]; // The name of this actor
			  
		int iID; // It's ID
		ACTOR_TYPE Type; // The type of the actor
		
		ACTOR *pParentActor; // It'a parent actor
		
		AS_3D_VECTOR vWorldPos, // The current world position
					 vLastWorldPos, // The last world position
					 vDeathWorldPos, // The position were the actor died
					 vWorldVelocity, // The world velocity
					 vRot, vRotVelocity, // The rotation
					 vDirectionVector, // The direction vector (object orientation)
				     vRightVector, // The up direction vector
				     vUpVector; // The right direction vector
		float  fSlideLRVelocity, // Left/right slide velocity
			   fSlideUDVelocity; // Up/down slide velocity
		float fForward, // The acceleration in the current direction
			  fBackward, // The acceleration in the current direction
			  fNormalMaxVelocity, // The normal max velocity
			  fCurrentMaxVelocity, // The current max velocity
			  fMaxVelocity, // The maximum velocity (Afterburner)
			  fCurrentVelocity; // The current velocity of the actor
		
		DWORD dwLastWaterWaveTime; // The time were the last water wave was created:

		DWORD dwTextureAniTime;
		int iTextureAniStep;
		
		float fRadius, // Radius of the actor
			  fNormalRadius, // The normal radius of the actor
			  fMass, // Mass
			  fThrustPower, // The current power of the thrust
			  fThrustEngine; // The thrust engine
		long lWaterStreamTimer,
			 lAblazeTraceTimer;
		
		int iSparks; // The number of sparks the actor have
		DWORD dwLastSparkDecreaseTime; // The time were the last spark was given out
		
		FLOAT3 fColor;
		// Animation:
		int byAnimation;		// The current animation depends on the current action
		int iAniStep,			// The current animation step
			iNextAniStep;		// The next animation step
		DWORD dwAniTime,		// The time since the last animation step change
			  dwAniDeltaTime;	// The past ani time (for pausing the animation)

		void Move(void);

} ACTOR;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern ACTOR Actor[MAX_ACTORS];
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern void DrawActors(void);
extern void DrawTransparentActors(AS_WINDOW *);
extern BOOL CheckActors(BOOL);
extern void CheckBallCollision(ACTOR *, ACTOR *, AS_3D_VECTOR);
extern void InitActors(void);
extern ACTOR *FindFreeActor(void);
extern void CreateTextActor(char *, AS_3D_VECTOR);
///////////////////////////////////////////////////////////////////////////////


#endif // __ACTORS_H__
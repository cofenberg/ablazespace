//-----------------------------------------------------------------------------
// File: Terrain.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
PERLIN_NOISE PerlinNoise;
BOOL m_bPrecomputefBmSpectralWeights = FALSE;
float *m_pfExponentArrayfBm;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
float fBm(AS_3D_VECTOR, float, float, float);
float fBmTurbulence(AS_3D_VECTOR, float, float, float);
float HeteroMultiFractal(AS_3D_VECTOR, float, float, float, float);
float HybridMultiFractal(AS_3D_VECTOR, float, float, float, float);
float RidgedMultiFractal(AS_3D_VECTOR, float, float, float, float, float);
float MultiFractal(AS_3D_VECTOR, float, float, float, float);
///////////////////////////////////////////////////////////////////////////////


// LEVEL functions: ***********************************************************
void LEVEL::CreateRandomTerrain(void)
{ // begin LEVEL::CreateRandomTerrain()
	PerlinNoise.ReSeed();

	int i, i2,
		iMethod	= rand() % 5; // The selected method
	float fH = 1, // Fractal increment
		  fLac = 2, // Lacunarity
		  fOct = 7, // Octaves
		  fOff = 1, // Offset
		  fG = 2; // Gain
	AS_3D_VECTOR vV;
	
	for(i = 0; i < iPoints; i++)
	{
		fFixPoint[i][X] *= 0.1f;
		fFixPoint[i][Y] *= 0.1f;
	}

	// Compute heights:
	for(i = 0; i < iPoints; i++)
	{
		vV = fFixPoint[i];
		// Use selected method:
		switch(iMethod)
		{
			case 0: // fBm
				fFixPoint[i][Z] = -fBm(vV, fH, fLac, fOct);
			break;
			
			case 1: // fBm Turbulence
				fFixPoint[i][Z] = -fBmTurbulence(vV, fH, fLac, fOct);
			break;
									
			case 2: // HeteroMultiFractal
				fFixPoint[i][Z] = -HeteroMultiFractal(vV, fH, fLac, fOct, fOff);
			break;
			
			case 3: // HybridMultiFractal
				fFixPoint[i][Z] = -HybridMultiFractal(vV, fH, fLac, fOct, fOff);
			break;
			
			case 4: // RidgedMultiFractal
				fFixPoint[i][Z] = -RidgedMultiFractal(vV, fH, fLac, fOct, fOff, fG);
			break;
			
			case 5: // Multifractal -> Created a too serrated terrain... not that good for AblazeBall!
				fFixPoint[i][Z] = -MultiFractal(vV, fH, fLac, fOct, fOff);
			break;

			default:
				int i = 0;
			break;
		}
	}
	// Scale height values between 0 and 2.0:
	float fMin, fMax, avoid_div;

	fMin = fMax = fFixPoint[0][Z];
	for(i = 0; i < iPoints; i++)
	{
		float fVal = fFixPoint[i][Z];
		if(fMin < fVal)
			fMin = fVal;
		if(fMax > fVal)
			fMax = fVal;
	}
	avoid_div = 1.0f/(fMax-fMin);

	if(fMax < -1.5f)
	{ // Setup the points height:
		for(i = 0; i < iPoints; i++)
			fFixPoint[i][Z] = (fFixPoint[i][Z]-fMin)*avoid_div*1.5f;
	}
	float fFactor = 10.0f+(rand() % 1000)/100;
	for(i = 0; i < iPoints; i++)
	{
		for(i2 = 0; i2 < 2; i2++)
			fPoint[i][i2] = fFixPoint[i][i2] *= 10.0f;
		fPoint[i][i2] = fFixPoint[i][Z] *= fFactor;
	}

} // end LEVEL::CreateRandomTerrain()
///////////////////////////////////////////////////////////////////////////////


// LEVEL functions: ***********************************************************
PERLIN_NOISE::PERLIN_NOISE(void)
{ // begin PERLIN_NOISE::PERLIN_NOISE()
	m_bInitialized = FALSE;
	GenerateLookupTables();
} // end PERLIN_NOISE::PERLIN_NOISE()

PERLIN_NOISE::~PERLIN_NOISE(void)
{ // begin PERLIN_NOISE::~PERLIN_NOISE()()
	m_bInitialized = FALSE;
} // end PERLIN_NOISE::~PERLIN_NOISE()

float PERLIN_NOISE::RandomPNFloat(void)
{ // begin PERLIN_NOISE::RandomPNFloat()
	return (float) ((rand() % (WRAP_INDEX + WRAP_INDEX)) - WRAP_INDEX) / WRAP_INDEX;
} // end PERLIN_NOISE::RandomPNFloat()

void PERLIN_NOISE::ReSeed(void)
{ // begin PERLIN_NOISE::ReSeed()
	srand((unsigned int) (time(NULL) + rand()));	// seed random number generator with system clock elapsed seconds
	GenerateLookupTables();
} // end PERLIN_NOISE::ReSeed()

float PERLIN_NOISE::SCurve(float t)
{ // begin PERLIN_NOISE::SCurve()
	return (t * t * (3.0f - 2.0f * t));	// component dropoff given by cubic approximation
} // end PERLIN_NOISE::SCurve()

float PERLIN_NOISE::LinearInterpolation(float t, float a, float b)
{ // begin PERLIN_NOISE::LinearInterpolation()
	return (a + t * (b - a));
} // end PERLIN_NOISE::LinearInterpolation()

void PERLIN_NOISE::ComputeDistanceToLatticePoints(float x, int &grid_point1, int &grid_point2, float &distance_to_gp1, float &distance_to_gp2)
{ // begin PERLIN_NOISE::ComputeDistanceToLatticePoints()
	float t = x + MAX;
	grid_point1 = ((int)t) & MOD_MASK;
	grid_point2 = (grid_point1 + 1) & MOD_MASK;
	distance_to_gp1 = t - (int)t;
	distance_to_gp2 = distance_to_gp1 - 1.0f;
} // end PERLIN_NOISE::ComputeDistanceToLatticePoints()

void PERLIN_NOISE::GenerateLookupTables(void)
{ // begin PERLIN_NOISE::GenerateLookupTables()
	// Fill permutation and gradient lookup tables with random values:
	int i ,j, k;

	for(i = 0; i < WRAP_INDEX; i++)
	{
		// Fill permutation table:
		m_iPermutation[i] = i;

		// Fill 1D gradient table:
		m_fGradient1D[i] = RandomPNFloat();

		// Fill 2D gradient table:
		m_fGradient2D[i].fX = RandomPNFloat();
		m_fGradient2D[i].fY = RandomPNFloat();
		m_fGradient2D[i].Normalize();

		// Fill 3D gradient table:
		m_fGradient3D[i].fX = RandomPNFloat();
		m_fGradient3D[i].fY = RandomPNFloat();
		m_fGradient3D[i].fZ = RandomPNFloat();
		m_fGradient3D[i].Normalize();
	}

	// Shuffle permutation table entries so we can quickly index into the
	// gradient tables in a nonbiased way:
	while(--i)
	{
		k = m_iPermutation[i];
		j = rand() % WRAP_INDEX;

		m_iPermutation[i] = m_iPermutation[j];
		m_iPermutation[j] = k;
	}

	// For added speed, avoid MOD operations and precompute m_iPermutation (P) 
	// to be twice as long, setting P[256...511] := P[0...255]:
	for(i = 0; i < WRAP_INDEX+2; i++)
	{
		// Finish permutation table:
		m_iPermutation[WRAP_INDEX + i] = m_iPermutation[i];

		// Finish 1D gradient table:
		m_fGradient1D[WRAP_INDEX + i] = m_fGradient1D[i];

		// Finish 2D gradient table:
		m_fGradient2D[WRAP_INDEX + i].fX = m_fGradient2D[i].fX;
		m_fGradient2D[WRAP_INDEX + i].fY = m_fGradient2D[i].fY;

		// Finish 3D gradient table:
		m_fGradient3D[WRAP_INDEX + i].fX = m_fGradient3D[i].fX;
		m_fGradient3D[WRAP_INDEX + i].fY = m_fGradient3D[i].fY;
		m_fGradient3D[WRAP_INDEX + i].fZ = m_fGradient3D[i].fZ;
	}

	m_bInitialized = TRUE;
} // end PERLIN_NOISE::GenerateLookupTables()

float PERLIN_NOISE::PNoise1D(float x)
{ // begin PERLIN_NOISE::PNoise1D()
	// Make sure lookup tables have been generated:
	if(!m_bInitialized)
		ReSeed();

	// Find grid points in lattice closest to given input value and 
	// compute distance from input value to those grid points:
	float distance_to_gp1, distance_to_gp2;
	int	grid_point1, grid_point2;

	ComputeDistanceToLatticePoints(x, grid_point1, grid_point2, distance_to_gp1, distance_to_gp2);

	// Exaggerate proximity of input to 0 or 1 using the Ease Curve:
	float ease_curve_weight = SCurve(distance_to_gp1);

	// Compute gradient influences:
	float gradient_influence1 = distance_to_gp1 * m_fGradient1D[m_iPermutation[grid_point1]];
	float gradient_influence2 = distance_to_gp2 * m_fGradient1D[m_iPermutation[grid_point2]];

	// Return the linear interpolation of the gradient influences:
	return LinearInterpolation(ease_curve_weight, gradient_influence1, gradient_influence2);
} // end PERLIN_NOISE::PNoise1D()

float PERLIN_NOISE::PNoise2D(AS_2D_VECTOR vec2f)
{ // begin PERLIN_NOISE::PNoise2D()
	// Make sure lookup tables have been generated:
	if(!m_bInitialized)
		ReSeed();

	// Find grid points in lattice closest to given input value and 
	// compute distance from input value to those grid points:
	float x_distance_to_gp1, x_distance_to_gp2, y_distance_to_gp1, y_distance_to_gp2;
	int x_grid_point1, x_grid_point2, y_grid_point1, y_grid_point2;

	ComputeDistanceToLatticePoints(vec2f.fX, x_grid_point1, x_grid_point2, x_distance_to_gp1, x_distance_to_gp2);
	ComputeDistanceToLatticePoints(vec2f.fY, y_grid_point1, y_grid_point2, y_distance_to_gp1, y_distance_to_gp2);

	// Generate index locations for gradient table:
	int index1, index2, corner1, corner2, corner3, corner4;

	index1 = m_iPermutation[x_grid_point1];
	index2 = m_iPermutation[x_grid_point2];

	corner1 = m_iPermutation[index1 + y_grid_point1];
	corner2 = m_iPermutation[index2 + y_grid_point1];
	corner3 = m_iPermutation[index1 + y_grid_point2];
	corner4 = m_iPermutation[index2 + y_grid_point2];

	// Exaggerate proximity of input to 0 or 1 using the Ease Curve:
	float x_ease_curve_weight = SCurve(x_distance_to_gp1);
	float y_ease_curve_weight = SCurve(y_distance_to_gp1);

	// Compute gradient influences:
	AS_2D_VECTOR q;
	float a, b, u, v;

	q = m_fGradient2D[corner1]; u = x_distance_to_gp1 * q.fX + y_distance_to_gp1 * q.fY;
	q = m_fGradient2D[corner2]; v = x_distance_to_gp2 * q.fX + y_distance_to_gp1 * q.fY;
	a = LinearInterpolation(x_ease_curve_weight, u, v);

	q = m_fGradient2D[corner3]; u = x_distance_to_gp1 * q.fX + y_distance_to_gp2 * q.fY;
	q = m_fGradient2D[corner4]; v = x_distance_to_gp2 * q.fX + y_distance_to_gp2 * q.fY;
	b = LinearInterpolation(x_ease_curve_weight, u, v);

	// Return the linear interpolation of the gradient influences:
	return LinearInterpolation(y_ease_curve_weight, a, b);
} // end PERLIN_NOISE::PNoise2D()

float PERLIN_NOISE::PNoise3D(AS_3D_VECTOR vec3f)
{ // begin PERLIN_NOISE::PNoise3D()
	// Make sure lookup tables have been generated:
	if(!m_bInitialized)
		ReSeed();

	// Find grid points in lattice closest to given input value and 
	// compute distance from input value to those grid points:
	int x_grid_point1, x_grid_point2, y_grid_point1, y_grid_point2, z_grid_point1, z_grid_point2;
	float x_distance_to_gp1, x_distance_to_gp2, y_distance_to_gp1, y_distance_to_gp2, z_distance_to_gp1, z_distance_to_gp2;

	ComputeDistanceToLatticePoints(vec3f.fX, x_grid_point1, x_grid_point2, x_distance_to_gp1, x_distance_to_gp2);
	ComputeDistanceToLatticePoints(vec3f.fY, y_grid_point1, y_grid_point2, y_distance_to_gp1, y_distance_to_gp2);
	ComputeDistanceToLatticePoints(vec3f.fZ, z_grid_point1, z_grid_point2, z_distance_to_gp1, z_distance_to_gp2);

	// Generate index locations for gradient table:
	int index1, index2, corner1, corner2, corner3, corner4;

	index1 = m_iPermutation[x_grid_point1];
	index2 = m_iPermutation[x_grid_point2];

	corner1 = m_iPermutation[index1 + y_grid_point1];
	corner2 = m_iPermutation[index2 + y_grid_point1];
	corner3 = m_iPermutation[index1 + y_grid_point2];
	corner4 = m_iPermutation[index2 + y_grid_point2];

	// Exaggerate proximity of input to 0 or 1 using the Ease Curve:
	float x_ease_curve_weight = SCurve(x_distance_to_gp1);
	float y_ease_curve_weight = SCurve(y_distance_to_gp1);
	float z_ease_curve_weight = SCurve(z_distance_to_gp1);

	// Compute gradient influences:
	AS_3D_VECTOR q;
	float a, b, u, v;

	q = m_fGradient3D[corner1 + z_grid_point1]; u = x_distance_to_gp1 * q.fX + y_distance_to_gp1 * q.fY + z_distance_to_gp1 * q.fZ;
	q = m_fGradient3D[corner2 + z_grid_point1]; v = x_distance_to_gp2 * q.fX + y_distance_to_gp1 * q.fY + z_distance_to_gp1 * q.fZ;
	a = LinearInterpolation(x_ease_curve_weight, u, v);

	q = m_fGradient3D[corner3 + z_grid_point1]; u = x_distance_to_gp1 * q.fX + y_distance_to_gp2 * q.fY + z_distance_to_gp1 * q.fZ;
	q = m_fGradient3D[corner4 + z_grid_point1]; v = x_distance_to_gp2 * q.fX + y_distance_to_gp2 * q.fY + z_distance_to_gp1 * q.fZ;
	b = LinearInterpolation(x_ease_curve_weight, u, v);

	float c = LinearInterpolation(y_ease_curve_weight, a, b);

	q = m_fGradient3D[corner1 + z_grid_point2]; u = x_distance_to_gp1 * q.fX + y_distance_to_gp1 * q.fY + z_distance_to_gp2 * q.fZ;
	q = m_fGradient3D[corner2 + z_grid_point2]; v = x_distance_to_gp2 * q.fX + y_distance_to_gp1 * q.fY + z_distance_to_gp2 * q.fZ;
	a = LinearInterpolation(x_ease_curve_weight, u, v);

	q = m_fGradient3D[corner3 + z_grid_point2]; u = x_distance_to_gp1 * q.fX + y_distance_to_gp2 * q.fY + z_distance_to_gp2 * q.fZ;
	q = m_fGradient3D[corner4 + z_grid_point2]; v = x_distance_to_gp2 * q.fX + y_distance_to_gp2 * q.fY + z_distance_to_gp2 * q.fZ;
	b = LinearInterpolation(x_ease_curve_weight, u, v);

	float d = LinearInterpolation(y_ease_curve_weight, a, b);

	return LinearInterpolation(z_ease_curve_weight, c, d);
} // end PERLIN_NOISE::PNoise3D()
///////////////////////////////////////////////////////////////////////////////

float fBm(AS_3D_VECTOR vV, float H, float lacunarity, float octaves)
{
	float fBm_value, frequency, remainder;
	int	i;
	
	// Precompute and store spectral weights:
	if (!m_bPrecomputefBmSpectralWeights)
	{
	    // Seize required memory for exponent array:
	    m_pfExponentArrayfBm = new float[(int) octaves+1];
	    frequency = 1.0f;

	    for(i = 0; i <= octaves; i++)
	    {
			m_pfExponentArrayfBm[i] = powf(frequency, -H); // compute weight for each frequency
			frequency *= lacunarity;
	    }

	    m_bPrecomputefBmSpectralWeights = TRUE;
	}

	// Zero fBm value:
	fBm_value = 0.0f;
	
	// Spectral construction loop:
	for(i = 0; i < octaves; i++)
	{
	    fBm_value += PerlinNoise.PNoise3D(vV) * m_pfExponentArrayfBm[i];
	    vV *= lacunarity;
	}
	
	remainder = octaves - (int) octaves;

	if(remainder != 0.0f)
	    fBm_value += remainder * PerlinNoise.PNoise3D(vV) * m_pfExponentArrayfBm[i];

	return fBm_value;
}

float fBmTurbulence(AS_3D_VECTOR vV, float H, float lacunarity, float octaves)
{
	float fBm_value, frequency, remainder;
	int	i;
	
	// Precompute and store spectral weights:
	if(!m_bPrecomputefBmSpectralWeights)
	{
	    // Seize required memory for exponent array:
	    m_pfExponentArrayfBm = new float[(int) octaves+1];
	    frequency = 1.0f;

	    for(i = 0; i <= octaves; i++)
	    {
			m_pfExponentArrayfBm[i] = powf(frequency, -H); // compute weight for each frequency
			frequency *= lacunarity;
	    }

	    m_bPrecomputefBmSpectralWeights = TRUE;
	}

	// Zero fBm value:
	fBm_value = 0.0f;
	
	// Spectral construction loop:
	for(i = 0; i < octaves; i++)
	{
		float abs_noise = PerlinNoise.PNoise3D(vV) * m_pfExponentArrayfBm[i];
		if(abs_noise < 0.0f)
			abs_noise = -abs_noise;
	    fBm_value += abs_noise;
	    vV *= lacunarity;
	}
	
	remainder = octaves - (int) octaves;

	if(remainder != 0.0f)
	    fBm_value += remainder * PerlinNoise.PNoise3D(vV) * m_pfExponentArrayfBm[i];

	return fBm_value;
}

float HeteroMultiFractal(AS_3D_VECTOR vV, float H, float lacunarity, float octaves, float offset)
{
	float fBm_value, frequency, remainder, increment;
	int	i;
	
	// Precompute and store spectral weights:
	if(!m_bPrecomputefBmSpectralWeights)
	{
	    // Seize required memory for exponent array:
	    m_pfExponentArrayfBm = new float[(int) octaves+1];
	    frequency = 1.0f;

	    for(i = 0; i <= octaves; i++)
	    {
			m_pfExponentArrayfBm[i] = powf(frequency, -H); // compute weight for each frequency
			frequency *= lacunarity;
	    }

	    m_bPrecomputefBmSpectralWeights = TRUE;
	}

	// Zero fBm value:
	fBm_value = 0.0f;
	
	// First unscaled octave:
	fBm_value = offset + PerlinNoise.PNoise3D(vV);
	vV *= lacunarity;

	// Spectral construction loop:
	for(i = 1; i < octaves; i++)
	{
		increment = PerlinNoise.PNoise3D(vV) + offset;
		increment *= m_pfExponentArrayfBm[i];
		increment *= fBm_value;
		fBm_value += increment;
		vV *= lacunarity;
	}
	
	remainder = octaves - (int) octaves;

	if(remainder != 0.0f)
	{
		increment = (PerlinNoise.PNoise3D(vV) + offset) * m_pfExponentArrayfBm[i];
	    fBm_value += remainder * increment * fBm_value;
	}

	return fBm_value;
}

float HybridMultiFractal(AS_3D_VECTOR vV, float H, float lacunarity, float octaves, float offset)
{
	float fBm_value, frequency, remainder, result, weight, signal;
	int	i;
	
	// Precompute and store spectral weights:
	if(!m_bPrecomputefBmSpectralWeights)
	{
	    // Seize required memory for exponent array:
	    m_pfExponentArrayfBm = new float[(int) octaves+1];
	    frequency = 1.0f;

	    for(i = 0; i <= octaves; i++)
	    {
			m_pfExponentArrayfBm[i] = powf(frequency, -H); // compute weight for each frequency
			frequency *= lacunarity;
	    }

	    m_bPrecomputefBmSpectralWeights = TRUE;
	}

	// Zero fBm value:
	fBm_value = 0.0f;
	
	// First unscaled octave:
	result = (offset + PerlinNoise.PNoise3D(vV)) * m_pfExponentArrayfBm[0];
	weight = result;
	vV *= lacunarity;

	// Spectral construction loop:
	for(i = 1; i < octaves; i++)
	{
	    if(weight > 1.0f)
			weight = 1.0f;
	    signal = (PerlinNoise.PNoise3D(vV) + offset) * m_pfExponentArrayfBm[i];
	    result += weight * signal;
	    weight *= signal;
		vV *= lacunarity;
	}
	
	remainder = octaves - (int) octaves;

	if(remainder != 0.0f)
	    result += remainder * PerlinNoise.PNoise3D(vV) * m_pfExponentArrayfBm[i];

	fBm_value = (result * 0.5f) - 1.0f;
	return fBm_value;
}

float RidgedMultiFractal(AS_3D_VECTOR vV, float H, float lacunarity, float octaves, float offset, float gain)
{
	float fBm_value, frequency, result, weight, signal;
	int	i;
	
	// Precompute and store spectral weights:
	if(!m_bPrecomputefBmSpectralWeights)
	{
	    // Seize required memory for exponent array:
	    m_pfExponentArrayfBm = new float[(int)octaves+1];
	    frequency = 1.0f;

	    for(i = 0; i <= octaves; i++)
	    {
			m_pfExponentArrayfBm[i] = powf(frequency, -H); // compute weight for each frequency
			frequency *= lacunarity;
	    }
	    m_bPrecomputefBmSpectralWeights = TRUE;
	}

	// Zero fBm value:
	fBm_value = 0.0f;
	
	// First unscaled octave:
	signal = PerlinNoise.PNoise3D(vV);
	if(signal < 0.0f)
		signal = -signal;		// abs(signal) creates ridges
	signal = offset - signal;					// invert and translate
	signal *= signal;							// signal^2 sharpens ridges
	result = signal;
	weight = 1.0f;

	// Spectral construction loop:
	for(i = 1; i < octaves; i++)
	{
		vV *= lacunarity;
	    weight = signal * gain;					// weight successive contributions by previous signal
	    if(weight > 1.0f)
			weight = 1.0f;
	    if(weight < 0.0f)
			weight = 0.0f;
	    signal = PerlinNoise.PNoise3D(vV);
	    if(signal < 0.0f)
			signal = -signal;
	    signal = offset - signal;
	    signal *= signal;
	    signal *= weight;
	    result += signal * m_pfExponentArrayfBm[i];
	}
	
	fBm_value = (result - 1.0f) * 0.5f;
	return fBm_value;
}

float MultiFractal(AS_3D_VECTOR vV, float H, float lacunarity, float octaves, float offset)
{
	float fBm_value, frequency, remainder;
	int	i;
	
	// Precompute and store spectral weights:
	if(!m_bPrecomputefBmSpectralWeights)
	{
	    // Seize required memory for exponent array:
	    m_pfExponentArrayfBm = new float[(int)octaves+1];
	    frequency = 1.0f;

	    for(i = 0; i <= octaves; i++)
	    {
			m_pfExponentArrayfBm[i] = powf(frequency, -H); // compute weight for each frequency
			frequency *= lacunarity;
	    }

	    m_bPrecomputefBmSpectralWeights = TRUE;
	}

	// Zero fBm value:
	fBm_value = 0.0f;
	
	// Spectral construction loop:
	for(i = 0; i < octaves; i++)
	{
	    fBm_value += offset * frequency * PerlinNoise.PNoise3D(vV);
	    vV *= lacunarity;
	}
	
	remainder = octaves - (int)octaves;

	if(remainder != 0.0f)
	    fBm_value += remainder * PerlinNoise.PNoise3D(vV) * m_pfExponentArrayfBm[i];

	return fBm_value;
}
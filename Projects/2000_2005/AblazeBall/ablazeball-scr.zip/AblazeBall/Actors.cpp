//-----------------------------------------------------------------------------
// File: Actors.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
ACTOR Actor[MAX_ACTORS];
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
void DrawActors(void);
void DrawTransparentActors(AS_WINDOW *);
BOOL CheckActors(BOOL);
void CheckBallCollision(ACTOR *, ACTOR *, AS_3D_VECTOR);
void InitActors(void);
ACTOR *FindFreeActor(void);
void CreateTextActor(char *, AS_3D_VECTOR);
///////////////////////////////////////////////////////////////////////////////


// ACTOR functions: ***********************************************************
void ACTOR::Move(void)
{ // begin ACTOR::Move()
	AS_3D_VECTOR vScaledPosition, vScaledVelocity;	 
	AS_3D_VECTOR vFinalPosition, vLastVelocity, vLastWorldPos;
	float fHeight;

	// Setup bounding ellipsoid:
	ASCollisionPacket.vERadius.fX = fNormalRadius;
	ASCollisionPacket.vERadius.fY = fNormalRadius;
	ASCollisionPacket.vERadius.fZ = fNormalRadius;
	
	// Setup some general stuff:
	vLastWorldPos = vWorldPos;
	ASCollisionPacket.bFoundACollision = FALSE;
	if(Type == ACTOR_AblazeBall)
	{
		vLastVelocity = vWorldVelocity*fFire;
		vLastVelocity.fZ = vWorldVelocity.fZ;
	}
	else
		vLastVelocity = vWorldVelocity;

	// Not all object have all the time a good collision detection: (FPS increase)
	if(Type == ACTOR_AblazeBall || bInFOV)
	{	// The first thing we do is scale the player and his velocity to
		// ellipsoid space:
		ASCollisionPacket.vLastSafePosition = vScaledPosition = vWorldPos/ASCollisionPacket.vERadius;
		vScaledVelocity = vLastVelocity*((float) g_lDeltatime/30)/ASCollisionPacket.vERadius;

		// Call the recursive collision response function:
		vWorldPos = Level.CollideWithWorld(vScaledPosition, vScaledVelocity, TRUE);

		// When the function returns the result is still in ellipsoid space, so
		// we have to scale it back to R3 before we return it:
		vWorldPos = vWorldPos*ASCollisionPacket.vERadius;
		ASCollisionPacket.vLastSphereCollisionPoint = ASCollisionPacket.vLastSphereCollisionPoint*ASCollisionPacket.vERadius;

		// Error check, the actor wouldn't be happy if he is in the terrain...
		// Does we struck with the terrain?
		if(ASCollisionPacket.bStuck)
		{ // Lift the position, so that we didn't struck the terrain:
			vWorldPos = vLastWorldPos;
			vWorldPos.fZ -= (float) g_lDeltatime/300;
		}
	}
	else
	{
		vWorldPos += vLastVelocity*((float) g_lDeltatime/30);
	}
	
	fHeight = Level.FastComputeHeight(vWorldPos.fX, vWorldPos.fY, POINT_CURRENT);
	if(!ASCollisionPacket.bStuck && fHeight < vWorldPos.fZ)
	{ // Lift the position, so that we didn't struck the terrain:
		vWorldPos.fZ -= (float) g_lDeltatime/50;
		ASCollisionPacket.bFoundACollision = TRUE;
	}

	// Update velocity z:
	if(Type == ACTOR_SparkObj)
	{
		if(ASCollisionPacket.bFoundACollision &&
		   (vWorldVelocity.fZ > 0.1f || vWorldVelocity.fZ+fRadius < -0.1f))
		{
			ASPlayFmodSample(pSmallAblazeBallTerrainSample, FSOUND_LOOP_OFF);
			vWorldVelocity.fZ = -vLastVelocity.fZ/1.3f;
		}
	}
	else
	{
		if(ASCollisionPacket.bFoundACollision &&
 		   (vWorldVelocity.fZ > 0.05f || vWorldVelocity.fZ < -0.05f))
		{
			if(Type == ACTOR_AblazeBall)
			{
				if(Player.pActor != this)
				{
					if(fFire)
						ASPlayFmodSample(pBigAblazeBallTerrainSample, FSOUND_LOOP_OFF);
				}
				else
					ASPlayFmodSample(pSmallAblazeBallTerrainSample, FSOUND_LOOP_OFF);
			}
		}
		if(ASCollisionPacket.bFoundACollision &&
		   (vWorldVelocity.fZ > 0.01f || vWorldVelocity.fZ < -0.01f))
		{
			vWorldVelocity.fZ = -vLastVelocity.fZ/1.2f;
		}
	}
} // end ACTOR::Move()
///////////////////////////////////////////////////////////////////////////////


void DrawActors(void)
{ // begin DrawActors()
	ACTOR *pActor;
	AS_3D_VECTOR vDelta;
	int i, iDetail;

	glCullFace(GL_BACK);
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_CULL_FACE);
	glDisable(GL_BLEND);

	for(i = 0; i < MAX_ACTORS; i++)
	{
		pActor = &Actor[i];
		if(!pActor->bActive || pActor->bTransparent)
			continue;
		if(pActor == Player.pActor && _ASCamera->fZoom > -0.5f)
			continue;

		if(!ASSphereInFrustum(pActor->vWorldPos.fX, pActor->vWorldPos.fY, pActor->vWorldPos.fZ, pActor->fRadius))
		{
			pActor->bInFOV = FALSE;
			continue;
		}
		pActor->bInFOV = TRUE;

		glColor3f(1.0f, 1.0f, 1.0f);
		glPushMatrix();

		glTranslatef(pActor->vWorldPos.fX, pActor->vWorldPos.fY, pActor->vWorldPos.fZ);
		glRotatef(pActor->vRot.fX, 0.0f, 1.0f, 0.0f);
		glRotatef(pActor->vRot.fY, 1.0f, 0.0f, 0.0f);

		vDelta = pActor->vWorldPos-_ASCamera->vWorldPos;
		iDetail = (int) ((1*pActor->fRadius*3)/(vDelta.GetLength()*0.006f)*_ASConfig->fGeometricDetails);
		if(iDetail > (int) (30*_ASConfig->fGeometricDetails))
			iDetail = (int) (30*_ASConfig->fGeometricDetails);
		if(iDetail < 8)
			iDetail = 8;

		switch(pActor->Type)
		{
			case ACTOR_AblazeBall:
				glEnable(GL_TEXTURE_2D);
				glColor3f(0.2f+1.0f*pActor->fFire, 0.2f+1.0f*pActor->fFire, 1.0f*pActor->fFire);
				glBindTexture(GL_TEXTURE_2D, GameTexture[pActor->iTextureAniStep].iOpenGLID);

				glPushMatrix();
				glScalef(pActor->fRadius, pActor->fRadius, pActor->fRadius);
				glCallList(iSphereList[iDetail-8]);
				glPopMatrix();

				glDisable(GL_TEXTURE_2D);
			break;

			case ACTOR_AiringObj: case ACTOR_FireBombObj: case ACTOR_SparkObj:
			case ACTOR_ThrustEngineObj: case ACTOR_TerraformEngineObj:
				glEnable(GL_TEXTURE_2D);
				switch(pActor->Type)
				{
					case ACTOR_AiringObj: glColor3f(0.4f, 0.4f, 1.0f); break;
					case ACTOR_FireBombObj: glColor3f(1.0f, 0.4f, 1.0f); break;
					case ACTOR_SparkObj: glColor3f(1.0f, 1.0f, 0.4f); break;
					case ACTOR_ThrustEngineObj: glColor3f(0.4f, 1.0f, 0.4f); break;
					case ACTOR_TerraformEngineObj: glColor3f(0.5f, 0.5f, 0.5f); break;
				}
				glEnable(GL_TEXTURE_GEN_T);
				
				switch(pActor->Type)
				{
					case ACTOR_AiringObj: glBindTexture(GL_TEXTURE_2D, GameTexture[25].iOpenGLID); break;
					case ACTOR_FireBombObj: glBindTexture(GL_TEXTURE_2D, GameTexture[26].iOpenGLID); break;
					case ACTOR_SparkObj: glBindTexture(GL_TEXTURE_2D, GameTexture[27].iOpenGLID); break;
					case ACTOR_ThrustEngineObj: glBindTexture(GL_TEXTURE_2D, GameTexture[28].iOpenGLID); break;
					case ACTOR_TerraformEngineObj: glBindTexture(GL_TEXTURE_2D, GameTexture[29].iOpenGLID); break;
				}

				glPushMatrix();
				glScalef(pActor->fRadius, pActor->fRadius, pActor->fRadius);
				glCallList(iSphereList[iDetail-8]);
				glPopMatrix();

				glDisable(GL_TEXTURE_2D);
				glDisable(GL_TEXTURE_GEN_T);
			break;
		}
		glPopMatrix();
	}
} // end DrawActors()

void DrawTransparentActors(AS_WINDOW *pWindow)
{ // begin DrawTransparentActors()
	double fModelViewMatrix[16], fProjectionMatrix[16], dWinX, dWinY, dWinZ;
	int iViewport[4];
	char byTemp[256];
	ACTOR *pActor;
	int i, i2; 
	float f;

	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glDepthMask(FALSE);
	glGetDoublev(GL_MODELVIEW_MATRIX, fModelViewMatrix);
	glGetDoublev(GL_PROJECTION_MATRIX, fProjectionMatrix);
	iViewport[0] = iViewport[1] = 0;
	iViewport[2] = 800;
	iViewport[3] = 600;
	for(i = 0; i < MAX_ACTORS; i++)
	{
		pActor = &Actor[i];
		if(!pActor->bActive)
			continue;
		if(pActor->Type == ACTOR_AblazeBall)
		{ // Show its number of sparks:
			if(pActor->iSparks == 4)
				glColor4f(0.5f, 1.0f, 0.5f, 0.9f);
			else
				glColor4f(1.0f, 0.5f, 0.5f, 0.9f);
			memset(byTemp, 0, sizeof(char)*256);
			for(i2 = 0; i2 < pActor->iSparks; i2++)
				sprintf(byTemp, "%s*", byTemp);
			gluProject(pActor->vWorldPos.fX, pActor->vWorldPos.fY, pActor->vWorldPos.fZ-pActor->fRadius, fModelViewMatrix, fProjectionMatrix, iViewport, &dWinX, &dWinY, &dWinZ);
			pWindow->PrintAnimated((int) dWinX, (int) dWinY, byTemp, 0, pActor->fRadius*10, fFontAni, 1);
		}

		if(pActor->Type == ACTOR_Text)
		{
			glColor4f(1.0f, 1.0f, 1.0f, 0.9f);
			gluProject(pActor->vWorldPos.fX, pActor->vWorldPos.fY, pActor->vWorldPos.fZ, fModelViewMatrix, fProjectionMatrix, iViewport, &dWinX, &dWinY, &dWinZ);
			pWindow->PrintAnimated((int) dWinX, (int) dWinY, pActor->byName, 0, pActor->fRadius, fFontAni, 1);
			continue;
		}

		if(pActor->bGoingDeath)
		{
			glDisable(GL_CULL_FACE);
			f = pActor->fRadius/pActor->fNormalRadius;
			switch(pActor->Type)
			{
				case ACTOR_AiringObj: glColor4f(0.4f, 0.4f, 1.0f, f); break;
				case ACTOR_FireBombObj: glColor4f(1.0f, 0.4f, 1.0f, f); break;
				case ACTOR_SparkObj: glColor4f(1.0f, 1.0f, 0.4f, f); break;
				case ACTOR_ThrustEngineObj: glColor4f(0.4f, 1.0f, 0.4f, f); break;
				case ACTOR_TerraformEngineObj: glColor4f(0.5f, 0.5f, 0.5f, f); break;
				default: glColor4f(1.0f, 1.0f, 1.0f, f); break;
			}
			glPushMatrix();

			glTranslatef(pActor->vDeathWorldPos.fX, pActor->vDeathWorldPos.fY, pActor->vDeathWorldPos.fZ);
			glRotatef(pActor->vRot.fX, 0.0f, 1.0f, 0.0f);
			glRotatef(pActor->vRot.fY, 1.0f, 0.0f, 0.0f);

			glRotatef(f*50, 1.0f, 0.0f, 0.0f);
			glRotatef(f*20, 0.0f, 1.0f, 0.0f);
			glRotatef(f*100, 0.0f, 0.0f, 1.0f);
			f = (pActor->fNormalRadius/pActor->fRadius);
			glScalef(f, f, f);

			glBindTexture(GL_TEXTURE_2D, GameTexture[30].iOpenGLID);
			glBegin(GL_QUADS);
				glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, -1.0f, 0.0f);
				glTexCoord2f(1.0f, 0.0f); glVertex3f(1.0f, -1.0f, 0.0f);
				glTexCoord2f(1.0f, 1.0f); glVertex3f(1.0f, 1.0f, 0.0f);
				glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f, 1.0f, 0.0f);
			glEnd();

			glEnable(GL_CULL_FACE);
			glPopMatrix();
		}
		if(!pActor->bTransparent)
			continue;
	}
	glDepthMask(TRUE);
} // end DrawTransparentActors()

BOOL CheckActors(BOOL bOnlyCheck)
{ // begin CheckActors()
	float fDistance, fWaterHeight, fDelta, fHeight, fFactor, fResVelocity, fX, fY, fAmount;
	int i, i2, i3, i4, i5, iRadius, iBurnPoints[5], iScale1, iScale2;
	BOOL bCollision = FALSE, bWaterContact = FALSE;
	ACTOR *pActor, *pActor2, *pCollectorActor, *pCollectedActor, *pBall;
	AS_3D_VECTOR vDelta;
	char byTemp[256];
	DWORD dwTime;
	FLOAT3 fPos;
	INT2 iPos;

	Level.iAblazeBallsInAblazeSpace = 0;
	for(i = 0; i < MAX_ACTORS; i++)
	{
		pActor = &Actor[i];
		if(!pActor->bActive)
			continue;
		if(!bOnlyCheck)
		{
			// Check max velocity:
			fResVelocity = pActor->vWorldVelocity.GetLength();
			if(fResVelocity > 0.7f)
			{ // The velocity is to high!!
				fFactor = 0.7f/fResVelocity;
				pActor->vWorldVelocity *= fFactor;
			}

			if(pActor->Type == ACTOR_Text)
			{
				pActor->vWorldPos.fZ -= (float) g_lDeltatime/500;
				pActor->fRadius += (float) g_lDeltatime/300;
				if(pActor->fRadius >= 5.0f)
					pActor->bGoingDeath = TRUE;
				if(pActor->bGoingDeath)
				{
					pActor->fRadius -= (float) g_lDeltatime/100;
					if(pActor->fRadius <= 0.0f)
						pActor->bActive = FALSE;
				}
				continue;
			}

			// Perform gravitation:
			if(pActor->Type != ACTOR_SparkObj)
			{
				if(!bLowGravitation)
					pActor->vWorldVelocity.fZ += (float) g_lDeltatime/3000;
				else
					pActor->vWorldVelocity.fZ += (float) g_lDeltatime/10000;
			}

			// Move the actor to the new destination:
			pActor->vLastWorldPos = pActor->vWorldPos;
			
			pActor->Move();

			// Perform air friction:
			for(i2 = 0; i2 < 3; i2++)
				pActor->vWorldVelocity.fV[i2] -= pActor->vWorldVelocity.fV[i2]/60.0f*((float) g_lDeltatime/30);

			// Get the current velocity of the actor:
			pActor->fCurrentVelocity = pActor->vWorldVelocity.GetLength();

			// Perform thrust impetus:
			pActor->vWorldVelocity.fZ -= (float) (g_lDeltatime*pActor->fThrustPower)/1800;

			switch(pActor->Type)
			{
				case ACTOR_AblazeBall:
					if(!pActor->bGoingDeath)
					{
						pActor->fRadius += (float) g_lDeltatime/5000;
						if(pActor->fRadius > pActor->fNormalRadius)
							pActor->fRadius = pActor->fNormalRadius;
					}
					else
					{
						pActor->fRadius -= (float) g_lDeltatime/20000;
						if(pActor->fRadius < 0.0f)
							pActor->bActive = FALSE;
					}

					// Rotate the ball:
					pActor->vRot.fX += (pActor->vLastWorldPos.fX-pActor->vWorldPos.fX)*400;
					pActor->vRot.fY += (pActor->vLastWorldPos.fY-pActor->vWorldPos.fY)*400;

					// Animate the texture:
					if(g_lNow-pActor->dwTextureAniTime > 50*(1/pActor->fFire))
					{
						pActor->dwTextureAniTime = g_lNow;
						pActor->iTextureAniStep++;
						if(pActor->iTextureAniStep >= 4)
							pActor->iTextureAniStep = 0;
					}

					// Decrease the fire if the ball uses it's thrust:
					pActor->fFire -= (float) (g_lDeltatime*pActor->fThrustPower)/50000;
					if(pActor->fFire < 0.0f)
						pActor->fFire = 0.0f;
					pActor->fThrustEngine -= (float) (g_lDeltatime*pActor->fThrustPower)/20000;
					Level.fFogDensity -= (float) (g_lDeltatime*pActor->fThrustPower)/100000;
					if(Level.fFogDensity < 0.0f)
						Level.fFogDensity = 0.0f;
					if(pActor->fThrustEngine < 0.0f)
					{
						pActor->fThrustPower = 0.0f;
						pActor->fThrustEngine = 0.0f;
					}
					
					// Burn the earth under the ball:
					iScale1 = 500;
					iScale2 = 20500;
					for(iRadius = 1; iRadius < 4; iRadius++)
					{
						if(!pActor->fThrustPower && iRadius > 1)
							break;
						memset(&iBurnPoints, -1, sizeof(int)*5);
						for(i4 = 0; i4 < 5; i4++)
						{
							switch(i4)
							{
								case 0: fPos[X] = pActor->vWorldPos.fX; fPos[Y] = pActor->vWorldPos.fY; break;
								case 1: fPos[X] = pActor->vWorldPos.fX-pActor->fRadius*iRadius; fPos[Y] = pActor->vWorldPos.fY-pActor->fRadius*iRadius; break;
								case 2: fPos[X] = pActor->vWorldPos.fX+pActor->fRadius*iRadius; fPos[Y] = pActor->vWorldPos.fY-pActor->fRadius*iRadius; break;
								case 3: fPos[X] = pActor->vWorldPos.fX-pActor->fRadius*iRadius; fPos[Y] = pActor->vWorldPos.fY+pActor->fRadius*iRadius; break;
								case 4: fPos[X] = pActor->vWorldPos.fX+pActor->fRadius*iRadius; fPos[Y] = pActor->vWorldPos.fY+pActor->fRadius*iRadius; break;
							}
							
							// Check if the ball is near enought to burn the earth:
							fHeight = Level.FastComputeHeight(fPos[X], fPos[Y], POINT_CURRENT);
							if(pActor->vWorldPos.fZ+pActor->fRadius+0.5f+pActor->fMass < fHeight)
								continue; // It's to far!
							
							// Get burning power:
							fDelta = -((pActor->vWorldPos.fZ+pActor->fRadius+0.5f)-fHeight);
							if(fDelta < 0.00001f)
								fDelta = 0.00001f;
							
							if(fHeight > Level.fCurrentWaterHeight)
								fDelta *= 30; // The buning isn't that strong when it's under water
							
							for(i5 = 0; i5 < 10; i5++)
								fDelta *= 1/pActor->fFire;

							for(i5 = 0; i5 < 2; i5++)
							{
								iPos[i5] = (int) fPos[i5];
								if(fPos[i5]-iPos[i5] > 0.5f)
									iPos[i5]++;
							}
							i2 = iPos[X]+iPos[Y]*Level.iWidth;

							// Check if we are going to burn a point twice:
							for(i5 = 0; i5 < 5; i5++)
							{
								if(iBurnPoints[i5] == -1 || i2 == iBurnPoints[i5])
									break;
							}
							if(iBurnPoints[i5] == i2)
								continue;
							iBurnPoints[i5] = i2;
							if(i2 >= 0 && i2 < Level.iPoints)
							{
								for(i3 = 0; i3 < 3; i3++)
								{
									Level.fPointColor[i2][i3] -= (float) g_lDeltatime/(iScale1+iScale2*fDelta);
									if(Level.fPointColor[i2][i3] < 0.2f)
										Level.fPointColor[i2][i3] = 0.2f;	
								}
							}
						}
						iScale1 = 100;
						iScale2 = 2050;
					}

					// Create the ablaze trace:
					if(g_lNow-pActor->lAblazeTraceTimer > 1.0f/(pActor->fFire*pActor->fFire*pActor->fFire*pActor->fFire*(1.0f+pActor->fCurrentVelocity*10))-100*pActor->fThrustPower &&
					   ((pActor == Player.pActor && _ASCamera->fZoom < -0.5f) || pActor != Player.pActor))
					{
						pActor->lAblazeTraceTimer = g_lNow;
						for(i2 = 0; i2 < 3*_ASConfig->fParticleDensity; i2++)
						{
							CreateAblazeTrace(pActor->vWorldPos.fX, pActor->vWorldPos.fY, pActor->vWorldPos.fZ,
											  pActor->fRadius-0.1f, 1.0f*pActor->fRadius*2, pActor->fFire);
						}
					}

					// Check if the actor has contact with the water:
					fWaterHeight = Level.FastComputeHeight(pActor->vWorldPos.fX, pActor->vWorldPos.fY, POINT_WATER);

					// Check water:
					if(pActor->vWorldPos.fZ+pActor->fRadius >= fWaterHeight && pActor->fFire)
					{
						bWaterContact = TRUE;
						ASPlayFmodSample(pWaterContactSample, FSOUND_LOOP_NORMAL);
						fDelta = fWaterHeight-pActor->vWorldPos.fZ-Actor->fRadius;
						
						// Increase fog:
						Level.fFogDensity += (pActor->fFire*pActor->fFire)*((float) g_lDeltatime/3000);

						// Decrease the water height:
						Level.fCurrentWaterHeight += (pActor->fFire*pActor->fFire)*((float) g_lDeltatime/3000);

						// Create a water stream:
						if(g_lNow-pActor->lWaterStreamTimer > 1.f/(pActor->fFire*pActor->fFire))
						{
							pActor->lWaterStreamTimer = g_lNow;
							CreateWaterStream(pActor->vWorldPos.fX, pActor->vWorldPos.fY, pActor->vWorldPos.fZ,
											  pActor->fRadius, pActor->fRadius, pActor->fFire);
						}
						
						// Decrease actors fire:
						if(pActor->fRadius < 0.5f)
						{
							if(fDelta > 0.0f)
								fAmount = (float) -(g_lDeltatime*fDelta)/3000;
							else
								fAmount = (float) (g_lDeltatime*fDelta)/3000;
							pActor->fFire -= (float) 0.0001*g_lDeltatime-fAmount;
						}
						else
						{
							if(fDelta > 0.0f)
								fAmount = (float) -(g_lDeltatime*fDelta)/500;
							else
								fAmount = (float) (g_lDeltatime*fDelta)/500;
							pActor->fFire -= (float) 0.0001*g_lDeltatime-fAmount;
						}
						if(pActor->fFire < 0.0f)
							pActor->fFire = 0.0f;

						// Perform water friction wich depents on how deep the player is in/under the water:
						for(i2 = 0; i2 < 3; i2++)
							pActor->vWorldVelocity.fV[i2] -= pActor->vWorldVelocity.fV[i2]/40.0f*((float) g_lDeltatime/30);

						// Perform impetus:
						if(fDelta > 0.0f)
							fDelta = -fDelta;
						if(pActor->fFire)
							pActor->vWorldVelocity.fZ += (float) (g_lDeltatime*fDelta)/1200;
			
						if(pActor->vWorldPos.fZ-pActor->fRadius <= fWaterHeight)
						{ // Create water waves:
							dwTime = (DWORD) (1/(pActor->fCurrentVelocity*g_lDeltatime/200));
							if(dwTime > 150)
								dwTime = 150;
							if(g_lNow-pActor->dwLastWaterWaveTime > dwTime)
							{
								pActor->dwLastWaterWaveTime = g_lNow;
								CreateWaterWave(pActor->vWorldPos.fX, pActor->vWorldPos.fY, 1.5f);
							}
						}
					}

					if(!pActor->fFire && pActor == Player.pActor &&
					   !pActor->bGoingDeath)
					{
						ASPlayFmodSample(pDeathSample, FSOUND_LOOP_OFF);
						pActor->bGoingDeath = TRUE;
					}

					if(pActor != Player.pActor)
					{ // Check the sparks:					
						pActor->iSparks = 0;
						if(pActor->fFire > 0.0f)
							pActor->iSparks++;
						if(pActor->fFire > 0.25f)
							pActor->iSparks++;
						if(pActor->fFire > 0.5f)
							pActor->iSparks++;
						if(pActor->fFire > 0.75f)
							pActor->iSparks++;
						else
						{ // The ablaze ball couldn't be moved!
							pActor->vWorldVelocity.fX = 0.0f;
							pActor->vWorldVelocity.fY = 0.0f;
						}
					}

					// Check if the ball is in the ablaze space:
					if(pActor->vWorldPos.fX-pActor->fRadius > Level.iAblazeSpacePos[0][X]-1.0f &&
					   pActor->vWorldPos.fX+pActor->fRadius < Level.iAblazeSpacePos[1][X]+1.0f &&
					   pActor->vWorldPos.fY-pActor->fRadius > Level.iAblazeSpacePos[1][Y]-1.0f &&
					   pActor->vWorldPos.fY+pActor->fRadius < Level.iAblazeSpacePos[2][Y]+1.0f &&
					   !pActor->bGoingDeath)
					{ // Give the actor fire:
						if(pActor != Player.pActor)
							Level.iAblazeBallsInAblazeSpace++;
						else
						{ // Give him fire: (but only a few!!)
							fX = pActor->vWorldPos.fX-(Level.iAblazeSpacePos[0][X]+0.5f);
							fY = pActor->vWorldPos.fY-(Level.iAblazeSpacePos[0][Y]+0.5f);
							fDelta = ASFastSqrt(fX*fX+fY*fY);
							pActor->fFire += (float) (g_lDeltatime*pActor->fRadius*pActor->fRadius*pActor->fRadius*2)/(100000*fDelta);
							if(pActor->fFire > 1.0f)
								pActor->fFire = 1.0f;
							
							// Check his sparks:
							if(pActor->iSparks >= 4)
								Level.iAblazeBallsInAblazeSpace++;
						}
						if(pActor != Player.pActor)
						{
							Level.fMiddleHeight += (float) g_lDeltatime/100000;
							Level.fCurrentWaterHeight += (float) g_lDeltatime/100000;
						}
						if(g_lNow-pActor->dwLastSparkDecreaseTime > 1000)
						{
							pActor->dwLastSparkDecreaseTime = g_lNow;
							if(!pActor->iSparks)
							{
								if(pActor == Player.pActor)
									CreateTextActor(T_SparksRequired, pActor->vWorldPos);
							}
							else
							{
								pActor->iSparks--;
								if(pActor != Player.pActor)
								{
									if(pActor->iSparks == 3)
									{
										ASPlayFmodSample(pAblazeBallInSpaceSample, FSOUND_LOOP_OFF);
										Level.fCurrentWaterHeight += 0.5f;
									}

									ASPlayFmodSample(pSparkToPointsSample, FSOUND_LOOP_OFF);
									pActor->fFire -= 0.25f;
									if(pActor->fFire < 0.0f)
										pActor->fFire = 0.0f;
									Player.iScore += 150;
									sprintf(byTemp, "-1 %s  +150 %s", T_Spark, T_Points);
									CreateTextActor(byTemp, pActor->vWorldPos);
								}
								else
								{
									// Give the player fire for this spark:
									ASPlayFmodSample(pSparkToPointsSample, FSOUND_LOOP_OFF);
									Level.fCurrentWaterHeight += 0.05f;
									pActor->fFire += 0.5f;
									if(pActor->fFire >= 1.0f)
										pActor->fFire = 1.0f;
									Player.iScore += 100;
									sprintf(byTemp, "-1 %s  +100 %s", T_Spark, T_Points);
									CreateTextActor(byTemp, pActor->vWorldPos);
								}
							}
						}
					}
				break;

				default:
					if(!pActor->bGoingDeath)
					{
						pActor->fRadius += (float) g_lDeltatime/3000;
						if(pActor->fRadius > pActor->fNormalRadius)
							pActor->fRadius = pActor->fNormalRadius;
					}
					else
					{
						pActor->fRadius -= (float) g_lDeltatime/3000;
						if(pActor->fRadius < 0.0f)
							pActor->bActive = FALSE;
					}

					if(pActor->Type == ACTOR_SparkObj)
					{ // Create the ablaze trace:
					// Check if the ball is in the ablaze space:
						if(pActor->vWorldPos.fX-pActor->fRadius > Level.iAblazeSpacePos[0][X]-1.0f &&
						   pActor->vWorldPos.fX+pActor->fRadius < Level.iAblazeSpacePos[1][X]+1.0f &&
						   pActor->vWorldPos.fY-pActor->fRadius > Level.iAblazeSpacePos[1][Y]-1.0f &&
						   pActor->vWorldPos.fY+pActor->fRadius < Level.iAblazeSpacePos[2][Y]+1.0f &&
						   !pActor->bGoingDeath)
						{ // Give the player a lot of points:
							Player.iScore += 500;
							sprintf(byTemp, "+500 %s", T_Points);
							CreateTextActor(byTemp, pActor->vWorldPos);
							pActor->bGoingDeath = TRUE;
						}
						for(i2 = 0; i2 < 5; i2++)
						{
							if(g_lNow-pActor->lAblazeTraceTimer > 2)
							{
								pActor->lAblazeTraceTimer = g_lNow;
								CreatePointTrace(pActor->vWorldPos.fX, pActor->vWorldPos.fY, pActor->vWorldPos.fZ,
												 pActor->fRadius-0.1f, 1.0f*pActor->fRadius*2, 1.0f);
							}
						}
					}
					
					// Check if the actor has contact with the water:
					fWaterHeight = Level.FastComputeHeight(pActor->vWorldPos.fX, pActor->vWorldPos.fY, POINT_WATER);

					// Check water:
					if(pActor->vWorldPos.fZ+pActor->fRadius >= fWaterHeight)
					{
						fDelta = fWaterHeight-pActor->vWorldPos.fZ-Actor->fRadius;
						
						// Perform water friction wich depents on how deep the player is in/under the water:
						for(i2 = 0; i2 < 3; i2++)
							pActor->vWorldVelocity.fV[i2] -= pActor->vWorldVelocity.fV[i2]/40.0f*((float) g_lDeltatime/30);

						// Perform impetus:
						if(fDelta > 0.0f)
							fDelta = -fDelta;
						pActor->vWorldVelocity.fZ += (float) (g_lDeltatime*fDelta)/1200;
			
						if(pActor->vWorldPos.fZ-pActor->fRadius <= fWaterHeight)
						{ // Create water waves:
							dwTime = (DWORD) (1/(pActor->fCurrentVelocity*g_lDeltatime/200));
							if(dwTime > 150)
								dwTime = 150;
							if(g_lNow-pActor->dwLastWaterWaveTime > dwTime)
							{
								pActor->dwLastWaterWaveTime = g_lNow;
								CreateWaterWave(pActor->vWorldPos.fX, pActor->vWorldPos.fY, 1.5f);
							}
						}
					}
				break;
			}

			// Check level bounding:
			if((pActor->vWorldPos.fX-pActor->fRadius) < 0.0f)
			{
				ASPlayFmodSample(pCollisionSample, FSOUND_LOOP_OFF);
				pActor->vWorldPos.fX = pActor->fRadius;
				pActor->vWorldVelocity.fX = -pActor->vWorldVelocity.fX;
			}
			if((pActor->vWorldPos.fY-Actor->fRadius) < 0.0f)
			{
				ASPlayFmodSample(pCollisionSample, FSOUND_LOOP_OFF);
				pActor->vWorldPos.fY = pActor->fRadius;
				pActor->vWorldVelocity.fY = -pActor->vWorldVelocity.fY;
			}
			if((pActor->vWorldPos.fX+pActor->fRadius) > Level.fWidth)
			{
				ASPlayFmodSample(pCollisionSample, FSOUND_LOOP_OFF);
				pActor->vWorldPos.fX = Level.fWidth-pActor->fRadius;
				pActor->vWorldVelocity.fX = -pActor->vWorldVelocity.fX;
			}
			if((pActor->vWorldPos.fY+pActor->fRadius) > Level.fHeight)
			{
				ASPlayFmodSample(pCollisionSample, FSOUND_LOOP_OFF);
				pActor->vWorldPos.fY = Level.fHeight-pActor->fRadius;
				pActor->vWorldVelocity.fY = -pActor->vWorldVelocity.fY;
			}
			if((pActor->vWorldPos.fZ-pActor->fRadius) < Level.fHighestPoint-30.0f &&
			   pActor->vWorldVelocity.fZ < 0.0f)
			{
				ASPlayFmodSample(pCollisionSample, FSOUND_LOOP_OFF);
				pActor->vWorldPos.fZ = Level.fHighestPoint-30.0f-pActor->fRadius;
				pActor->vWorldVelocity.fZ = -pActor->vWorldVelocity.fZ;
			}
			
		}

		// Check for collision with other actors:
		if(!pActor->bGoingDeath)
		{
			for(i2 = 0; i2 < MAX_ACTORS; i2++)
			{
				if(i == i2)
					continue;
				pActor2 = &Actor[i2];
				if(!pActor2->bActive || pActor2->bGoingDeath || pActor2->Type == ACTOR_Text)
					continue;
				vDelta = pActor->vWorldPos-pActor2->vWorldPos;
				fDistance = vDelta.DotProduct();
				if(fDistance <= (pActor->fRadius+pActor2->fRadius)*(pActor->fRadius+pActor2->fRadius))
				{ // We have a collision!
					bCollision = TRUE;
					if(bOnlyCheck)
						continue;

					CheckBallCollision(pActor, pActor2, vDelta);
					if(pActor->fFire || pActor2->fFire)
						ASPlayFmodSample(pBallCollisionSample, FSOUND_LOOP_OFF);
					if(pActor->Type == ACTOR_AblazeBall && pActor2->Type == ACTOR_AblazeBall &&
					   (pActor == Player.pActor || pActor2 == Player.pActor))
					{ // Give the great ablaze ball some sparks:
						if(pActor == Player.pActor)
							pBall = pActor2;
						else
							pBall = pActor;

						if(g_lNow-Player.pActor->dwLastSparkDecreaseTime > 1000 && Player.pActor->iSparks > 0 &&
						   pBall->iSparks < 4)
						{
							ASPlayFmodSample(pSparkCommittingSample, FSOUND_LOOP_OFF);
							Player.pActor->dwLastSparkDecreaseTime = g_lNow;
							Player.pActor->iSparks--;
							pBall->iSparks++;
							if(pBall->iSparks >= 4)
								ASPlayFmodSample(pAblazeBallActiveSample, FSOUND_LOOP_OFF);
							pBall->fFire += 0.25f;
							Player.iScore += 60;
							sprintf(byTemp, "-1 %s  +60 %s", T_Spark, T_Points);
							CreateTextActor(byTemp, pActor->vWorldPos);
						}
					}
					if(pActor == Player.pActor || pActor2 == Player.pActor)
					{
						if(pActor == Player.pActor)
						{
							pCollectorActor = pActor;
							pCollectedActor = pActor2;
						}
						else
						{
							pCollectorActor = pActor2;
							pCollectedActor = pActor;
						}
						switch(pCollectedActor->Type)
						{
							case ACTOR_AiringObj:
								ASPlayFmodSample(pAiringObjSample, FSOUND_LOOP_OFF);
								pCollectedActor->bGoingDeath = TRUE;
								pCollectedActor->vDeathWorldPos = pCollectedActor->vWorldPos;
								Level.iAiringObjects--;
								Level.fFogDensity -= 0.5f;
								if(Level.fFogDensity < 0.0f)
									Level.fFogDensity = 0.0f;
								Player.iScore += 10;
								sprintf(byTemp, "+10 %s", T_Points);
								CreateTextActor(byTemp, pCollectedActor->vWorldPos);
							break;

							case ACTOR_FireBombObj:
								pCollectedActor->bGoingDeath = TRUE;
								pCollectedActor->vDeathWorldPos = pCollectedActor->vWorldPos;
								Level.iFireBombObjects--;
								Level.fCurrentWaterHeight += 2.5f;
								Level.fFogDensity += 2.0f;
								CreateWaterBombStream();
								bFlashBlend = TRUE;
								Player.iScore += 20;
								sprintf(byTemp, "+20 %s", T_Points);
								CreateTextActor(byTemp, pCollectedActor->vWorldPos);
							break;

							case ACTOR_SparkObj:
								if(pCollectorActor->iSparks >= 4)
								{
									ASPlayFmodSample(pCollisionSample, FSOUND_LOOP_OFF);
									break; // The actor is full
								}
								ASPlayFmodSample(pSparkObjSample, FSOUND_LOOP_OFF);
								pCollectorActor->iSparks++;
								pCollectedActor->bGoingDeath = TRUE;
								pCollectedActor->vDeathWorldPos = pCollectedActor->vWorldPos;
								Level.iSparkObjects--;
								Player.iScore += 30;
								sprintf(byTemp, "+1 %s  +30 %s", T_Spark, T_Points);
								CreateTextActor(byTemp, pCollectedActor->vWorldPos);
							break;

							case ACTOR_ThrustEngineObj:
								ASPlayFmodSample(pThrustObjSample, FSOUND_LOOP_OFF);
								pCollectedActor->bGoingDeath = TRUE;
								pCollectedActor->vDeathWorldPos = pCollectedActor->vWorldPos;
								pCollectorActor->fThrustEngine = 1.0f;
								Level.iThrustEngineObjects--;
								Player.iScore += 20;
								sprintf(byTemp, "+20 %s", T_Points);
								CreateTextActor(byTemp, pCollectedActor->vWorldPos);
							break;

							case ACTOR_TerraformEngineObj:
								ASPlayFmodSample(pTerraformObjSample, FSOUND_LOOP_OFF);
								pCollectedActor->bGoingDeath = TRUE;
								pCollectedActor->vDeathWorldPos = pCollectedActor->vWorldPos;
								pCollectorActor->fTerraformEngine = 1.0f;
								Level.iTerraformEngineObjects--;
								Player.iScore += 20;
								sprintf(byTemp, "+20 %s", T_Points);
								CreateTextActor(byTemp, pCollectedActor->vWorldPos);
							break;
						}
					}
				}
			}
		}

		if(bCollision && !bOnlyCheck)
			pActor->vWorldPos = pActor->vLastWorldPos;
	}
	if(!bWaterContact)
		ASStopFmodSample(pWaterContactSample);
	return bCollision;
} // end CheckActors()

// Remark: Only two dimensional ball check!!
void CheckBallCollision(ACTOR *pActor1, ACTOR *pActor2, AS_3D_VECTOR vDelta)
{ // begin CheckBallCollision()
	float fContactAngle, fContactAngle2, fZFactorCos, fZFactorSin,
		  fXClosingVelocity, fYClosingVelocity, fZClosingVelocity, fResVelocity,
		  fXContactVelocity, fYContactVelocity, fZContactVelocity, fClosingAngle,
		  fClosingAngle2, fMassFactor, fMass1, fMass2, fAdiff, fPortion;

	// Determine the angle of contact
	if(vDelta.fX != 0)
	{
		fContactAngle = (float) atan(vDelta.fY/vDelta.fX);
		if(fContactAngle < 0)
			fContactAngle = -fContactAngle;
		fContactAngle2 = (float) tan(vDelta.fZ);
		if(fContactAngle2 < 0)
			fContactAngle2 = -fContactAngle2;
	}
	else
	{
		fContactAngle = (float) PId2;
		fContactAngle2 = (float) PId2;
	}

	// To determine how the objects will rebound off of each
	// other, we are not concerned with the speed of each
	// object, but rather the relative, or closing, speeds
	// of the two objects.
	fXClosingVelocity = pActor2->vWorldVelocity.fX-pActor1->vWorldVelocity.fX;
	fYClosingVelocity = pActor2->vWorldVelocity.fY-pActor1->vWorldVelocity.fY;
	fZClosingVelocity = pActor1->vWorldVelocity.fZ-pActor2->vWorldVelocity.fZ;
	// Calculate the x & y speed in the direction of contact
	fResVelocity = ASFastSqrt(fXClosingVelocity*fXClosingVelocity+fYClosingVelocity*fYClosingVelocity+
							  fZClosingVelocity*fZClosingVelocity);
	fZFactorCos = (float) cos(fContactAngle2);
	fZFactorSin = (float) -sin(fContactAngle2);
	fXContactVelocity = (float) cos(fContactAngle)*fResVelocity;
	fYContactVelocity = (float) sin(fContactAngle)*fResVelocity;
	fZContactVelocity = ASFastSqrt(fZClosingVelocity*fZClosingVelocity)*fZFactorSin;

	// Now, determine the closing angle.
	if(fXClosingVelocity != 0)
	{
		fClosingAngle = (float) atan(fYClosingVelocity/fXClosingVelocity);
		if(fClosingAngle < 0)
			fClosingAngle = -fClosingAngle;
		fClosingAngle2 = (float) tan(fZClosingVelocity);
		if(fClosingAngle2 < 0)
			fClosingAngle2 = -fClosingAngle2;
	}
	else
	{
		fClosingAngle = (float) PId2;
		fClosingAngle2 = (float) PId2;
	}

	// Hmmmm...
	// With equal masses,
	// the max rebound speed is 1/2 the closing speed.
	// With unequal masses,
	// the max rebound speed is the closing speed.
	// Okay then,
	// Normalize the two masses to be:  mass1 + mass2 = 2.0
	fMassFactor = 2/(pActor1->fMass+pActor2->fMass);
	fMass1 = pActor1->fMass*fMassFactor;
	fMass2 = pActor2->fMass*fMassFactor;

	if(pActor1->vWorldPos.fZ > pActor2->vWorldPos.fZ)
	{
		pActor1->vWorldVelocity.fZ -= fZContactVelocity*fMass2;
		pActor2->vWorldVelocity.fZ += fZContactVelocity*fMass1;
	}
	else
	{
		pActor1->vWorldVelocity.fZ += fZContactVelocity*fMass2;
		pActor2->vWorldVelocity.fZ -= fZContactVelocity*fMass1;
	}
	// Quadrant-specific stuff
	if(pActor1->vWorldPos.fX > pActor2->vWorldPos.fX)
	{
		if(pActor1->vWorldPos.fY < pActor2->vWorldPos.fY)
		{
			// pActor1 is contacting upper right quadrant of pActor2
			if(fYClosingVelocity < 0)
			{
				if(fXClosingVelocity < 0)
					fAdiff = (float) PI-fContactAngle-fClosingAngle;
				else
					fAdiff = fContactAngle-fClosingAngle;
			}
			else
				fAdiff = fContactAngle+fClosingAngle;
			fPortion = (float) cos(fAdiff)*fZFactorCos;
			pActor1->vWorldVelocity.fX += fXContactVelocity*fPortion*fMass2;
			pActor1->vWorldVelocity.fY -= fYContactVelocity*fPortion*fMass2;
			pActor2->vWorldVelocity.fX -= fXContactVelocity*fPortion*fMass1;
			pActor2->vWorldVelocity.fY += fYContactVelocity*fPortion*fMass1;
		}
		else
		{
			// pActor1 is contacting lower right quadrant of pActor2
			if(fYClosingVelocity > 0)
			{
				if(fXClosingVelocity < 0)
					fAdiff = (float) PI-fContactAngle-fClosingAngle;
				else
					fAdiff = fContactAngle-fClosingAngle;
			}
			else
				fAdiff = fContactAngle+fClosingAngle;
			fPortion = (float) cos(fAdiff)*fZFactorCos;
			pActor1->vWorldVelocity.fX += fXContactVelocity*fPortion*fMass2;
			pActor1->vWorldVelocity.fY += fYContactVelocity*fPortion*fMass2;
			pActor2->vWorldVelocity.fX -= fXContactVelocity*fPortion*fMass1;
			pActor2->vWorldVelocity.fY -= fYContactVelocity*fPortion*fMass1;
		}
	}
	else
	{
		if(pActor1->vWorldPos.fY < pActor2->vWorldPos.fY)
		{
			// pActor1 is contacting upper left quadrant of pActor2
			if(fYClosingVelocity < 0)
			{
				if(fXClosingVelocity < 0)
					fAdiff = fContactAngle-fClosingAngle;
				else
					fAdiff = (float) PI-fContactAngle-fClosingAngle;
			}
			else
				fAdiff = fContactAngle+fClosingAngle;
			fPortion = (float) cos(fAdiff)*fZFactorCos;
			pActor1->vWorldVelocity.fX -= fXContactVelocity*fPortion*fMass2;
			pActor1->vWorldVelocity.fY -= fYContactVelocity*fPortion*fMass2;
			pActor2->vWorldVelocity.fX += fXContactVelocity*fPortion*fMass1;
			pActor2->vWorldVelocity.fY += fYContactVelocity*fPortion*fMass1;
		}
		else
		{
			// pActor1 is contacting lower left quadrant of pActor2
			if(fYClosingVelocity > 0)
			{
				if(fXClosingVelocity < 0)
					fAdiff = fContactAngle-fClosingAngle;
				else
					fAdiff = (float) PI-fContactAngle-fClosingAngle;
			}
			else
				fAdiff = fContactAngle+fClosingAngle;
			fPortion = (float) cos(fAdiff)*fZFactorCos;
			pActor1->vWorldVelocity.fX -= fXContactVelocity*fPortion*fMass2;
			pActor1->vWorldVelocity.fY += fYContactVelocity*fPortion*fMass2;
			pActor2->vWorldVelocity.fX += fXContactVelocity*fPortion*fMass1;
			pActor2->vWorldVelocity.fY -= fYContactVelocity*fPortion*fMass1;
		}
	}
} // end CheckBallCollision()

void InitActors(void)
{ // begin InitActors()
	AS_3D_VECTOR vDelta;
	ACTOR *pActor;
	INT2 iPos;
	int i, iPoint, iXStart, iYStart, iXEnd, iYEnd, iX, iY;

	// Reset all actors:
	for(i = 0; i < MAX_ACTORS; i++)
		memset(&Actor[i], 0, sizeof(ACTOR));

	// Setup the players actor:
	pActor = Player.pActor = &Actor[0];
	pActor->bActive = TRUE;
	pActor->vWorldPos.fX = Level.fWidth/2-0.5f;
	pActor->vWorldPos.fY = Level.fHeight/2-0.5f;
	pActor->vWorldPos.fZ = Level.fHighestPoint-pActor->fRadius*2-5.0f;
	pActor->Type = ACTOR_AblazeBall;
	pActor->fNormalRadius = 0.3f;
	pActor->fRadius = 0.01f;
	pActor->fMass = (float) (pActor->fRadius*PI);
	pActor->fFire = 0.0f;

	// Setup the four ablaze balls:
	for(;;)
	{
		for(i = 1; i < 5; i++)
		{
			pActor = &Actor[i];
			pActor->bActive = TRUE;
			pActor->vWorldPos.fZ = Level.fHighestPoint-pActor->fRadius*2-1.0f;
			for(;;)
			{
				if(Level.vAblazeBallPos[i-1].fX == -1)
				{ // Get an random position:
					pActor->vWorldPos.fV[X] = 3+(float) ((rand() % ((int) (Level.fWidth-6))));
					pActor->vWorldPos.fV[Y] = 3+(float) ((rand() % ((int) (Level.fHeight-6))));
				}
				else
				{ // Set the last start position:
					pActor->vWorldPos = Level.vAblazeBallPos[i-1];
				}

				vDelta.fX = Level.fCenter[X]-pActor->vWorldPos.fX;
				vDelta.fY = Level.fCenter[Y]-pActor->vWorldPos.fY;
				if(vDelta.GetLength() < 20.0f)
					continue; // It shouldn't be so far to the ablaze space!
				if(!CheckActors(TRUE))
					break;
			}
			Level.vAblazeBallPos[i-1] = pActor->vWorldPos;
			pActor->Type = ACTOR_AblazeBall;
			pActor->fNormalRadius = 0.6f;
			pActor->fRadius = 0.01f;
			pActor->fMass = (float) (pActor->fRadius*PI);
		}
		// Check if the two actors to near:
		vDelta.fX = Actor[1].vWorldPos.fX-Actor[2].vWorldPos.fX;
		vDelta.fY = Actor[1].vWorldPos.fY-Actor[2].vWorldPos.fY;
		if(vDelta.GetLength() > 40.0f)
			break; // Ok, they are not too near
		Level.vAblazeBallPos[0].fX = -1;
		Level.vAblazeBallPos[1].fX = -1;
	}
	 
	 // Setup the terrain under the ball:
	for(i = 1; i < 5; i++)
	{
		pActor = &Actor[i];
		if(i == 1)
		{
			Level.GetPoint(pActor->vWorldPos.fX-pActor->fNormalRadius*3, pActor->vWorldPos.fY-pActor->fNormalRadius*3, iPos);
			iXStart = iPos[X];
			iYStart = iPos[Y];
			Level.GetPoint(pActor->vWorldPos.fX+pActor->fNormalRadius*3, pActor->vWorldPos.fY+pActor->fNormalRadius*3, iPos);
			iXEnd = iPos[X];
			iYEnd = iPos[Y];
			for(iY = iYStart; iY <= iYEnd; iY++)
			{
				if(iY >= Level.iHeight-1)
					break;
				for(iX = iXStart; iX <= iXEnd; iX++)
				{
					if(iX >= Level.iWidth-1)
						break;
					iPoint = iX+iY*Level.iWidth;
					Level.fPoint[iPoint][Z] = Level.fHighestPoint;
				}
			}
		}
		else
		{
			Level.GetPoint(pActor->vWorldPos.fX-pActor->fNormalRadius*3, pActor->vWorldPos.fY-pActor->fNormalRadius*3, iPos);
			iXStart = iPos[X];
			iYStart = iPos[Y];
			Level.GetPoint(pActor->vWorldPos.fX+pActor->fNormalRadius*3, pActor->vWorldPos.fY+pActor->fNormalRadius*3, iPos);
			iXEnd = iPos[X];
			iYEnd = iPos[Y];
			for(iY = iYStart; iY <= iYEnd; iY++)
			{
				if(iY >= Level.iHeight-1)
					break;
				for(iX = iXStart; iX <= iXEnd; iX++)
				{
					if(iX >= Level.iWidth-1)
						break;
					iPoint = iX+iY*Level.iWidth;
					Level.fPoint[iPoint][Z] = Level.fLowestPoint;
				}
			}
		}
	}
} // end InitActors()

ACTOR *FindFreeActor(void)
{ // begin FindFreeActor()
	ACTOR *pActor;

	// Find a none active actor and give a pointer to it back:
	for(int i = 1; i < MAX_ACTORS; i++)
	{
		pActor = &Actor[i];
		if(pActor->bActive)
			continue;
		memset(pActor, 0, sizeof(ACTOR));	
		pActor->iID = i;
		pActor->dwAniTime = g_lNow;
		pActor->fColor[0] = 1.0f;
		pActor->fColor[1] = 1.0f;
		pActor->fColor[2] = 1.0f;
		return pActor;
	}
	return 0;
} // end FindFreeActor()

void CreateTextActor(char *pbyText, AS_3D_VECTOR vPos)
{ // begin CreateTextActor()
	ACTOR *pActorT;

	pActorT = FindFreeActor();
	if(!pActorT)
		return;
	ASPlayFmodSample(pClapsSample, FSOUND_LOOP_OFF);
	pActorT->bActive = TRUE;
	pActorT->Type = ACTOR_Text;
	strcpy(pActorT->byName, pbyText);
	pActorT->fRadius = 0.1f;
	pActorT->bTransparent = TRUE;
	pActorT->vWorldPos = vPos;
} // end CreateTextActor()
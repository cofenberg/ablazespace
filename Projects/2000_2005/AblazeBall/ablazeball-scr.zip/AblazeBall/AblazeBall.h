//-----------------------------------------------------------------------------
// File: AblazeBall.h
//-----------------------------------------------------------------------------

#ifndef __ABLAZE_BALL_H__
#define __ABLAZE_BALL_H__


// Classes: *******************************************************************
typedef class SETUP
{
	public:
		BOOL bShowHud; // Should the hud be shown?

		SETUP(void); // Constructor
		
} SETUP;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern AS_CONFIG *pConfig;
extern AS_CAMERA *pCamera;
extern BOOL bOnlyConfig, bLoader;
extern SETUP Setup;
// Cheats:
extern BOOL bCheatsActivated,
			bInvulnerable,
			bUnlimitedThrust,
			bUnlimitedTerraform,
			bUnlimitedSparks,
			bLowGravitation,
			bNoWater,
			bNoFog,
			bSpeedControl;
extern int iSpeedFactor;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern void ChangeDisplayMode(void);
extern void OpenCreditsDialog(HWND);
extern void SetCreditsLanguage(void);
extern LRESULT CALLBACK CreditsProc(HWND, UINT, WPARAM, LPARAM);
extern void OpenHelp(void);
///////////////////////////////////////////////////////////////////////////////


#endif // __ABLAZE_BALL_H__
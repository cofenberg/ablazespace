//-----------------------------------------------------------------------------
// File: Game.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
// Textures:
AS_TEXTURE GameTexture[GAME_TEXTURES];
AS_TEXTURE Caust1Texture[CAUST_1_STEPS];
// Sounds:
AS_FMOD_SAMPLE GameSample[GAME_SAMPLES];
AS_FMOD_SAMPLE *pThrustSample = &GameSample[0],
			   *pSparkCommittingSample = &GameSample[1],
			   *pFireBombObjSample = &GameSample[2],
			   *pSparkToPointsSample = &GameSample[3],
			   *pSparkObjSample = &GameSample[4],
			   *pAiringObjSample = &GameSample[5],
			   *pWaterContactSample = &GameSample[6],
			   *pGameOverSample = &GameSample[7],
			   *pTerraformObjSample = &GameSample[8],
			   *pMenuSelectSample = &GameSample[9],
			   *pMenuSelectionSample = &GameSample[10],
			   *pThrustObjSample = &GameSample[11],
			   *pMenuBackSample = &GameSample[12],
			   *pAblazeBallActiveSample = &GameSample[13],
			   *pSmallAblazeBallTerrainSample = &GameSample[14],
			   *pBigAblazeBallTerrainSample = &GameSample[15],
			   *pBallCollisionSample = &GameSample[16],
			   *pCollisionSample = &GameSample[17],
			   *pDeathSample = &GameSample[18],
			   *pGameWonSample = &GameSample[19],
			   *pAblazeBallInSpaceSample = &GameSample[20],
			   *pTerraformingSample = &GameSample[21],
			   *pClapsSample = &GameSample[22],
			   *pAblazeBallReincarnation = &GameSample[23],
			   *pLooserSample = &GameSample[24],
			   *pWinnerSample = &GameSample[25],
			   *pTopSample = &GameSample[26];
AS_FMOD_MUSIC GameMusic;
// Particle systems:
AS_PARTICLE_MANAGER ParticleManager;
// Lists:
int iSkyCubeList, iSphereList[23];
// Other:
int GAME_WINDOW_ID;
int iFoundGameMusic; // The number of found game music files
char **pbyFoundGameMusic; // The names of the found music files
int iCurrentSelectedMusic;
BOOL bPauseTextBlend, bFlashBlend, bGameOver, bGameWon, bFirstPauseTest;
float fPauseTextBlend, fFlashBlend, fGameOverBlend;
char byCurrentMusic[256]; // The current played music file

// Small message:
long lSmallMessageShowTime, lSmallMessageTimer, lSmallMessageTempTimer;
float fSmallMessageBlend;
char bySmallMessageText[256], bySmallMessageNewText[256];
BOOL bSmallMessageChangeText, bSmallMessageShowText;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
HRESULT Game(void);
void EnumerateGameMusic(void);
void DestroyFoundGameMusic(void);
void StartGameMusic(void);
void CheckGameMusic(void);
void GetNewGameMusic(void);
void CreditsGameMusic(void);
void StartCurrentMusic(void);
void StopMusic(void);
void LoadGameTextures(void);
void LoadSamples(void);
HRESULT GameLoop(void);
HRESULT GameDraw(AS_WINDOW *);
HRESULT GameCheck(AS_WINDOW *);
void UpdateAllTextures(void);
void UpdateRenderQuality(void);
void CreateGameLists(void);
void DestroyGameLists(void);
void InitGameParticleSystems(void);
void DestroyGameParticleSystems(void);
void MakeFlare(float, float, float, float, float, float, float);
void DrawFlares(AS_3D_VECTOR);
void CreateWaterWave(float, float, float);
void CreateWaterStream(float, float, float, float, float, float);
void CreateAblazeTrace(float, float, float, float, float, float);
void CreatePointTrace(float, float, float, float, float, float);
void CreateWaterBombStream(void);
void StartNewGame(void);
void LevelRestart(void);
void ShowSmallMessage(char *, long);
void DisplaySmallMessage(AS_WINDOW *);
void CheckSmallMessage(void);
void RestartSoundSystem(void);
void SetGameLanguage(void);
///////////////////////////////////////////////////////////////////////////////


HRESULT Game(void)
{ // begin Game()
	MSG msg;

	_AS->WriteLogMessage("Enter game module");
	_AS->bDraw = FALSE;
	
	// Create the game window and create the DirectInput stuff:
	_AS->ASCreateWindow(WindowProc, GAME_WINDOW_NAME, GAME_WINDOW_NAME, _ASConfig->iWindowWidth,
					    _ASConfig->iWindowHeight, LoadMenu(_AS->GetInstance(), MAKEINTRESOURCE(IDR_GAME)),
						_ASConfig->bFullScreen, GameDraw, GameCheck, NULL, TRUE);
	GAME_WINDOW_ID = _AS->GetWindows()-1;
	ASInitOpenGL(&_AS->pWindow[GAME_WINDOW_ID],
				 NULL,
				 _AS->pWindow[GAME_WINDOW_ID].GethDC(),
				 _AS->pWindow[GAME_WINDOW_ID].GethRC(), _ASConfig->bFullScreen);
	_AS->CreateDXInputDevices(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), FALSE, TRUE, TRUE, FALSE);
	ShowWindow(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), SW_SHOW);	
	SetGameLanguage();

	// Load and create the game objects and textures:
	EnumerateGameMusic();
	LoadSamples();
	LoadHighscore();
	InitMenuPoints();
	LoadGameTextures();
	ASGenOpenGLTextures(GAME_TEXTURES, GameTexture);
	ASGenOpenGLTextures(CAUST_1_STEPS, Caust1Texture);
	CreateGameLists();
	InitGameParticleSystems();
	
	bShowLogos = TRUE;
	_AS->iActiveLights = 0;
	fGameMenuBlend = 1.0f;
	fGeneralGameMenuBlend = fGeneralGameBlend = 0.0f;
	InitTitel();
	Radar.Setup();

	// Create a level:
	StartNewGame();

	StartGameMusic();
	if(bCheatsActivated)
		ShowSmallMessage("Cheats activated", 5000);
	_AS->WriteLogMessage("Enter game main loop");
	for(;;)
	{
		if(_AS->GetShutDown() || _AS->CheckModuleChange())
			break;
		if(bShowLogos)
			Logos();
		else
		{ 
			byGameMenuMenu = 0;
			bShowGameMenu = TRUE;
			msg.wParam = GameLoop();
		}
	}
	_AS->WriteLogMessage("Left game main loop");

	Level.Destroy();
	StopMusic();
	ASDestroyFmodSamples(GAME_SAMPLES, GameSample);
	SaveHighscore();
	
	// Destroy the game objects and textures:
	DestroyFoundGameMusic();
	ASDestroyOpenGLTextures(GAME_TEXTURES, GameTexture);
	ASDestroyTextures(GAME_TEXTURES, GameTexture);
	ASDestroyOpenGLTextures(CAUST_1_STEPS, Caust1Texture);
	ASDestroyTextures(CAUST_1_STEPS, Caust1Texture);
	DestroyGameLists();
	DestroyGameParticleSystems();

	// Destroy the game window and the corresponding DirectInput stuff:
	_AS->FreeDXInputDevices();
	ASDestroyOpenGL(&_AS->pWindow[GAME_WINDOW_ID],
					NULL,
				    *_AS->pWindow[GAME_WINDOW_ID].GethDC(),
				    *_AS->pWindow[GAME_WINDOW_ID].GethRC());
	_AS->ASDestroyWindow(_AS->pWindow[GAME_WINDOW_ID].GethWnd(), GAME_WINDOW_NAME);
	
	// Left the game module:
	return msg.wParam;
} // end Game()

void EnumerateGameMusic(void)
{ // begin EnumerateGameMusic()
	WIN32_FIND_DATA FindFileData;
	char byTemp[256];
	HANDLE Find;
	                   
	_AS->WriteLogMessage("Enumerate music files");
	if(pbyFoundGameMusic)
		DestroyFoundGameMusic();
	iFoundGameMusic = 0;
	sprintf(byTemp, "%s%s\\List\\*.*", _AS->pbyProgramPath, _AS->pbyMusicFile);
	Find = FindFirstFile(byTemp, &FindFileData);
	for(;;)
	{
		// Check if its an supported music file:
		if(ASCheckEnding(FindFileData.cFileName, "mid") ||
		   ASCheckEnding(FindFileData.cFileName, "mp3") ||
		   ASCheckEnding(FindFileData.cFileName, "s3m") ||
		   ASCheckEnding(FindFileData.cFileName, "xm") ||
		   ASCheckEnding(FindFileData.cFileName, "it"))
		{ // We found an supported musid file:
			iFoundGameMusic++;
			pbyFoundGameMusic = (char **) realloc(pbyFoundGameMusic, sizeof(char **)*iFoundGameMusic);
			pbyFoundGameMusic[iFoundGameMusic-1] = new char[strlen(FindFileData.cFileName)+1];
			strcpy(pbyFoundGameMusic[iFoundGameMusic-1], FindFileData.cFileName);
		}

		if(!FindNextFile(Find, &FindFileData))
			break;
	}
	iCurrentSelectedMusic = 0;
} // end EnumerateGameMusic()

void DestroyFoundGameMusic(void)
{ // begin DestroyFoundGameMusic()
	for(int i = 0; i < iFoundGameMusic; i++)
		SAFE_DELETE(pbyFoundGameMusic[i]);
	SAFE_DELETE(pbyFoundGameMusic);
	iFoundGameMusic = 0;
} // end DestroyFoundGameMusic()

void StartGameMusic(void)
{ // begin StartGameMusic()
	char byTemp[256];
	
	if(iCurrentSelectedMusic == -1)
		GetNewGameMusic();
	StopMusic();
	if(!pbyFoundGameMusic)
		return;
	sprintf(byCurrentMusic, "list\\%s", pbyFoundGameMusic[iCurrentSelectedMusic]);
	StartCurrentMusic();
	sprintf(byTemp, "%s: %s", T_Music, pbyFoundGameMusic[iCurrentSelectedMusic]);
	ShowSmallMessage(byTemp, 3000);
} // end StartGameMusic()

void CheckGameMusic(void)
{ // begin CheckGameMusic()
	if(iCurrentSelectedMusic == -1)
		return; // We play an special music file
	if(!FMUSIC_IsFinished(GameMusic.pMod))
		return; // The music is still playing!
	GetNewGameMusic();
	StartGameMusic();
} // end CheckGameMusic()

void GetNewGameMusic(void)
{ // begin GetNewGameMusic()
	// Get another music:
	if(_ASConfig->bRandomMusic)
		iCurrentSelectedMusic = rand() % iFoundGameMusic;
	else
	{
		iCurrentSelectedMusic++;
		if(iCurrentSelectedMusic >= iFoundGameMusic)
			iCurrentSelectedMusic = 0;
	}
} // end GetNewGameMusic()

void CreditsGameMusic(void)
{ // begin CreditsGameMusic()
	StopMusic();
	strcpy(byCurrentMusic, "un-land.s3m");
	iCurrentSelectedMusic = -1;
	StartCurrentMusic();
} // end CreditsGameMusic()

void StartCurrentMusic(void)
{ // begin StartCurrentMusic()
	char byTemp[256];

	if(!_AS->bSoundPossible || !_ASConfig->bMusic)
		return;
	ASDestroyFmodMusic(&GameMusic);
	// Play the game music:
	sprintf(byTemp, "%s%s\\%s", _AS->pbyProgramPath, _AS->pbyMusicFile, byCurrentMusic);
	_AS->WriteLogMessage("Load music: %s", byTemp);
	if(ASPlayFmodMusic(&GameMusic, byTemp))
		_AS->WriteLogMessage("Couldn't load this music!");
} // end StartCurrentMusic()

void StopMusic(void)
{ // begin StopMusic()
	if(!_AS->bSoundPossible)
		return;
	ASDestroyFmodMusic(&GameMusic);
	memset(&GameMusic, 0, sizeof(AS_FMOD_MUSIC));
} // end StopMusic()

void LoadGameTextures(void)
{ // begin LoadGameTextures()
	char byFilename[GAME_TEXTURES][256] = {"Fire1.jpg", "Fire2.jpg",
										   "Fire3.jpg", "Fire4.jpg",
										   "Particle1.jpg", "Terrain1.jpg",
										   "Wave.jpg", "Bubble.jpg",
										   "Detail.jpg", "Radar.jpg",
										   "SkyCube_Floor.jpg", "SkyCube_Sky.jpg",
										   "SkyCube_Left.jpg", "SkyCube_Top.jpg",
										   "SkyCube_Right.jpg", "SkyCube_Down.jpg",
										   "Particle_AblazeSpace.jpg",
										   "Lightmap.jpg",
										   "Particle_WaterStream.jpg",
										   "AblazeBall.jpg", "Particle_Ablaze.jpg",
										   "ChristianOfenberg.jpg", "Music.jpg",
										   "AS.jpg", "Particle_Point.jpg",
										   "AiringObj.jpg", "FireBombObj.jpg",
										   "SparkObj.jpg", "ThrustEngineObj.jpg",
										   "TerraformEngineObj.jpg", "Wave2.jpg",
										   "AblazeBallNumber.jpg", "Particle_Ablaze2.jpg",
										   "Titel.jpg", "Shadowmap.tga"};
	char byFilename2[CAUST_1_STEPS][256];
	
	ASLoadTextures(byFilename, GAME_TEXTURES, GameTexture);
	for(int i = 0; i < CAUST_1_STEPS; i++)
		sprintf(byFilename2[i], "caust%d.jpg", i);
	ASLoadTextures(byFilename2, CAUST_1_STEPS, Caust1Texture);

	// Some special texture settings:
	GameTexture[34].bNoMipmap = TRUE;
} // end LoadGameTextures()

void LoadSamples(void)
{ // begin LoadSamples()
	char byFilename[GAME_SAMPLES][256] = {"Thrust.wav", "SparkCommitting.wav",
										  "FireBombObj.wav", "SparkToPoints.wav",
										  "SparkObj.wav", "AiringObj.wav",
										  "WaterContact.wav", "GameOver.wav",
										  "TerraformObj.wav", "MenuSelect.wav",
										  "MenuSelection.wav", "ThrustObj.wav",
										  "MenuBack.wav", "AblazeBallActive.wav",
										  "SmallAblazeBallTerrain.wav",
										  "BigAblazeBallTerrain.wav",
										  "BallCollision.wav", "Collision.wav",
										  "Death.wav", "GameWon.wav",
										  "AblazeBallInSpace.wav", "Terraforming.wav",
										  "Claps.wav", "AblazeBallReincarnation.wav",
										  "Looser.wav", "Winner.wav", "Top.wav"};
	
	ASLoadFmodSamples(byFilename, GAME_SAMPLES, GameSample);
} // end LoadSamples()

HRESULT GameLoop(void)
{ // begin GameLoop()
	char byTemp[256];
	MSG msg;

	_AS->pWindow[GAME_WINDOW_ID].SetDrawFunction(GameDraw);
	_AS->pWindow[GAME_WINDOW_ID].SetCheckFunction(GameCheck);

	InitGameParticleSystems();
	Sleep(1); // If this isn't done the system will crash... maybe an windows message error??
	bPause = bShowGameMenu;
	_AS->bDraw = TRUE;
	_ASCamera->SetStandartCamera();
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

	// Go into the game loop:
	_AS->WriteLogMessage("Enter the game loop");
	for(;;)
	{
		if(PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
    	{
        	if(!GetMessage(&msg, NULL, 0, 0))
                break;
        	TranslateMessage(&msg);
        	DispatchMessage(&msg);
    	}
		else
		{	
			if(_AS->GetShutDown() || _AS->CheckModuleChange())
				PostQuitMessage(0);
			if(!_AS->GetActive())
				continue;
			_AS->UpdateWindows();
		}
	}
	_AS->WriteLogMessage("Left the game loop");

	// Save the configuration:	
	sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyConfigFile);
	_ASConfig->Save(byTemp);
	_AS->bDraw = FALSE;
	return msg.wParam;
} // end GameLoop()

HRESULT GameDraw(AS_WINDOW *pWindow)
{ // begin GameDraw()
	char byTemp[256];

	if(!_AS->bDraw || bShowLogos)
		return 0;

	// Setup general stuff:
	if(_ASConfig->bWireframeMode || _ASConfig->bPointMode)
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	else
		glClear(GL_DEPTH_BUFFER_BIT);
	
	// Setup normal projection:
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.f+_ASCamera->fWaterScale[0],
				   (float) (_ASConfig->iWindowWidth+_ASCamera->fWaterScale[1])/(float) (_ASConfig->iWindowHeight+_ASCamera->fWaterScale[2]), 0.1f, 50.0f*_ASConfig->fVisibility);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	// Draw sky cube:
	_ASCamera->SetCameraTranslation(TRUE);
	Level.DrawSkyCube();
	
	// Setup camera:
	_ASCamera->SetCameraTranslation(FALSE);
	ASExtractFrustum();
	
	// If the camera is under the water:
	if(_ASCamera->bUnderWater)
	{
	    GLfloat	fogColor[4] = {0.0f, 0.0f, 1.0f, 1.0f};
	
		glFogfv(GL_FOG_COLOR, fogColor);
		glFogf(GL_FOG_DENSITY, 0.05f);
		glFogf(GL_FOG_START, 0.0f);
		glFogf(GL_FOG_END, 100.0f);
		glEnable(GL_FOG);
	}
	else
	{
	    GLfloat	fogColor[4] = {0.0f, 0.0f, 0.0f, 1.0f};

		glFogfv(GL_FOG_COLOR, fogColor);
		glFogf(GL_FOG_DENSITY, 0.02f*Level.fFogDensity);
		glFogf(GL_FOG_START, 1.0f);
		glFogf(GL_FOG_END, 100.0f);
		glEnable(GL_FOG);
		if(!Level.fFogDensity)
			glDisable(GL_FOG);
	}

	Level.SetupLights();
	Level.Draw();

	_ASCamera->SetCameraTranslation(FALSE);

	DrawActors();

	// Draw transparent stuff:
	Level.DrawWalls();
	_ASCamera->SetCameraTranslation(FALSE);
	Level.DrawAblazeColumn();
	_ASCamera->SetCameraTranslation(FALSE);
	
	Level.DrawWater();
	_ASCamera->SetCameraTranslation(FALSE);
	Level.DrawLightMaps();
	Level.DrawShadowMaps();

	ParticleManager.Draw();
	DrawTransparentActors(pWindow);

	// Draw the ablaze space lens flares:
	AS_3D_VECTOR vAblazeSpace;
	vAblazeSpace.fX = Level.fCenter[X];
	vAblazeSpace.fY = Level.fCenter[Y];
	vAblazeSpace.fZ = Level.fMiddleHeight-2.3f;
	DrawFlares(vAblazeSpace);

	glDisable(GL_FOG);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.f, (float) (_ASConfig->iWindowWidth)/(float) (_ASConfig->iWindowHeight), 0.1f, 150.0f);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	// If the camera is under the water:
	if(_ASCamera->bUnderWater)
	{
		glDisable(GL_DEPTH_TEST);
		glEnable(GL_BLEND);
		glDisable(GL_TEXTURE_2D);
		glBlendFunc(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);
		glColor4f(0.0f, 0.0f, 0.8f, 0.5f);
		glDisable(GL_CULL_FACE);
		glTranslatef(0.0f, 0.0f, -24.0f);
		glBegin(GL_QUADS);
			glVertex2f(-14.0f, -10.0f);
			glVertex2f(14.0f, -10.0f);
			glVertex2f(14.0f,  10.0f);
			glVertex2f(-14.0f,  10.0f);
		glEnd();
		glEnable(GL_CULL_FACE);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	}
	// The flash effect:
	if(fFlashBlend)
	{
		glDisable(GL_DEPTH_TEST);
		glEnable(GL_BLEND);
		glDisable(GL_TEXTURE_2D);
		glColor4f(1.0f, 1.0f, 1.0f, fFlashBlend);
		glDisable(GL_CULL_FACE);
		glTranslatef(0.0f, 0.0f, -24.0f);
		glBegin(GL_QUADS);
			glVertex2f(-14.0f, -10.0f);
			glVertex2f(14.0f, -10.0f);
			glVertex2f(14.0f,  10.0f);
			glVertex2f(-14.0f,  10.0f);
		glEnd();
		glEnable(GL_CULL_FACE);
	}

	// Setup lights:
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glDisable(GL_LIGHTING);

	// Draw the hud:
	DrawHud(pWindow);

	// Draw game menu:
	if(fGameMenuBlend || fCreditsBackgroundBlend || fHighscoreBlend || bShowGameMenu)
		ShowGameMenu(pWindow);

	// Draw pause text:
	if(fPauseTextBlend && !bShowGameMenu && !bGameOver)
	{
		glColor4f(1.0f, 1.0f, 1.0f, fPauseTextBlend);
		pWindow->Print(400, 300, T_Pause, 0, 1);
	}
	
	// Draw game over:
	if(fGameOverBlend)
	{
		glColor4f(1.0f, 1.0f, 1.0f, (fGameOverBlend-fHighscoreBlend)*0.2f);
		pWindow->PrintAnimated(400, 200, T_GameOver, 0, 8.7f, fFontAni, 1);
		glColor4f(1.0f, 1.0f, 1.0f, (fGameOverBlend-fHighscoreBlend)*0.3f);
		pWindow->PrintAnimated(400, 200, T_GameOver, 0, 8.5f, fFontAni, 1);
		glColor4f(1.0f, 1.0f, 1.0f, (fGameOverBlend-fHighscoreBlend)*0.7f);
		pWindow->PrintAnimated(400, 200, T_GameOver, 0, 8.2f, fFontAni, 1);
		glColor4f(1.0f, 1.0f, 1.0f, fGameOverBlend-fHighscoreBlend);
		pWindow->PrintAnimated(400, 200, T_GameOver, 0, 8.0f, fFontAni, 1);
		glColor4f(1.0f, 1.0f, 1.0f, fPauseTextBlend-fHighscoreBlend);
		pWindow->Print(400, 120, M_PressAnyKeyToContinue, 0, 1);
	}
	
	// Dark blend:
	if(fGeneralGameBlend != 1.0f)
	{
		glDisable(GL_DEPTH_TEST);
		glEnable(GL_BLEND);
		glDisable(GL_TEXTURE_2D);
		glBlendFunc(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);
		glColor4f(0.1f, 0.1f, 0.1f, fGeneralGameBlend);
		glLoadIdentity();
		glTranslatef(0.0f, 0.0f, -24.0f);
		glBegin(GL_QUADS);
			glVertex2f(-14.0f, -10.0f);
			glVertex2f(14.0f, -10.0f);
			glVertex2f(14.0f,  10.0f);
			glVertex2f(-14.0f,  10.0f);
		glEnd();
		glEnable(GL_CULL_FACE);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	}

	glColor4f(1.0f, 1.0f, 1.0f, 0.9f);
	_ASCamera->SetCameraTranslation(FALSE);

	DisplaySmallMessage(pWindow);

	// Show the number of visible fields:
	if(_ASConfig->bShowVisibleFields)
	{
		sprintf(byTemp, "%d (%d points)", Level.iVisibleFieldsNumber, Level.iVisiblePointsNumber);
		pWindow->Print(400, 10, byTemp, 0, 1);
	}	
	
	ASSwapBuffers(*pWindow->GethDC(), pWindow, TRUE);
	return 0;
} // end GameDraw()

HRESULT GameCheck(AS_WINDOW *pWindow)
{ // begin GameCheck()
	char byTemp[256];
	int i, i2;

	CheckGameMusic();
	if(bShowLogos)
		return 0;
	if(bGameWon || bGameOver)
	{
		Radar.fBlend -= (float) g_lDeltatime/1000;
		if(Radar.fBlend < 0.0f)
			Radar.fBlend = 0.0f;
	}
	if(bGameWon)
	{
		if(_ASCamera->fZoom != 11.0f)
		{
			if(_ASCamera->fZoom > -11.0f)
			{
				_ASCamera->fZoom -= (float) g_lDeltatime/500;
				if(_ASCamera->fZoom < -11.0f)
					_ASCamera->fZoom = -11.0f;
			}
			else
			{
				_ASCamera->fZoom += (float) g_lDeltatime/500;
				if(_ASCamera->fZoom > -11.0f)
					_ASCamera->fZoom = -11.0f;
			}
		}
		if(!bPause)
			_ASCamera->fRot2Velocity[Z] += (float) g_lDeltatime/200;
		if(_ASCamera->fRot[X] > 0.0f)
		{
			_ASCamera->fRot[X] -= (float) g_lDeltatime/200;
			if(_ASCamera->fRot[X] < 0.0f)
				_ASCamera->fRot[X] = 0.0f;
		}
		if(_ASCamera->fRot[X] < 0.0f)
		{
			_ASCamera->fRot[X] += (float) g_lDeltatime/200;
			if(_ASCamera->fRot[X] > 0.0f)
				_ASCamera->fRot[X] = 0.0f;
		}
		Level.fCurrentWaterHeight += (float) g_lDeltatime/3000;
		if(Level.fCurrentWaterHeight > 0.0f)
			Level.fCurrentWaterHeight = 0.0f;
		Level.fFogDensity -= (float) g_lDeltatime/5000;
		if(Level.fFogDensity < 0.0f)
			Level.fFogDensity = 0.0f;
		for(i = 0; i < Level.iPoints; i++)
		{
			for(i2 = 0; i2 < 3; i2++)
			{
				Level.fPointColor[i][i2] -= (float) g_lDeltatime/10000;
				if(Level.fPointColor[i][i2] < 0.2f)
					Level.fPointColor[i][i2] = 0.2f;
			}
		}
	}
	_AS->ReadDXInput(*pWindow->GethWnd());
	CheckSmallMessage();
	if(!bGameWon)
		Player.Check();
	AnimateFont();
	_ASCamera->Check();
	Level.Check();
	if(!bPause)
	{
		ParticleManager.Check();
		if(!bGameWon)
			CheckActors(FALSE);
		
		// Pause blend:
		fPauseTextBlend -= (float) g_lDeltatime/1000;
		if(fPauseTextBlend < 0.0f)
		{
			fPauseTextBlend = 0.0f;
			bPauseTextBlend = 0;
		}

		// Flesh blend:
		if(bFlashBlend)
		{
			if(!fFlashBlend)
				ASPlayFmodSample(pFireBombObjSample, FSOUND_LOOP_OFF);
			fFlashBlend += (float) g_lDeltatime/500;
			if(fFlashBlend >= 1.0f)
			{
				fFlashBlend = 1.0f;
				bFlashBlend = FALSE;
			}
		}
		else
		{
			fFlashBlend -= (float) g_lDeltatime/500;
			if(fFlashBlend <= 0.0f)
				fFlashBlend = 0.0f;
		}

		bFirstPauseTest = FALSE;
	}
	else
	{ // Pause blend:
		if(!bPauseTextBlend)
		{
			fPauseTextBlend += (float) g_lDeltatime/1000;
			if(fPauseTextBlend > 1.0f)
			{
				fPauseTextBlend = 1.0f;
				bPauseTextBlend = 1;
			}
		}
		else
		{
			fPauseTextBlend -= (float) g_lDeltatime/1000;
			if(fPauseTextBlend < 0.0f)
			{
				fPauseTextBlend = 0.0f;
				bPauseTextBlend = 0;
			}
		}
		if(!bFirstPauseTest)
		{
			bFirstPauseTest = TRUE;
			Level.lLastAiringObjectTimeTemp = g_lNow-Level.lLastAiringObjectTime;
			Level.lLastFireBombObjectTimeTemp = g_lNow-Level.lLastFireBombObjectTime;
		    Level.lLastSparkObjectTimeTemp = g_lNow-Level.lLastSparkObjectTime;
		    Level.lLastThrustEngineObjectTimeTemp = g_lNow-Level.lLastThrustEngineObjectTime;
		    Level.lLastTerraformEngineObjectTimeTemp = g_lNow-Level.lLastTerraformEngineObjectTime;
		}
		else
		{
			if(Level.lLastAiringObjectTimeTemp >0)
				Level.lLastAiringObjectTimeTemp = -Level.lLastAiringObjectTimeTemp;
			if(Level.lLastFireBombObjectTime >0)
				Level.lLastFireBombObjectTime = -Level.lLastFireBombObjectTime;
			if(Level.lLastSparkObjectTime > 0)
				Level.lLastSparkObjectTime = -Level.lLastSparkObjectTime;
			if(Level.lLastThrustEngineObjectTimeTemp > 0)
				Level.lLastThrustEngineObjectTime = -Level.lLastThrustEngineObjectTime;
			if(Level.lLastTerraformEngineObjectTimeTemp > 0)
				Level.lLastTerraformEngineObjectTime = -Level.lLastTerraformEngineObjectTime;
			Level.lLastAiringObjectTime = g_lNow+Level.lLastAiringObjectTimeTemp;
			Level.lLastFireBombObjectTime = g_lNow+Level.lLastFireBombObjectTimeTemp;
		    Level.lLastSparkObjectTime = g_lNow+Level.lLastSparkObjectTimeTemp;
		    Level.lLastThrustEngineObjectTime = g_lNow+Level.lLastThrustEngineObjectTimeTemp;
		    Level.lLastTerraformEngineObjectTime = g_lNow+Level.lLastTerraformEngineObjectTimeTemp;
		}
	}

	if(bGameOver)
	{
		Level.fFogDensity += (float) g_lDeltatime/5000;
		if(Level.fFogDensity > 3.0f)
			Level.fFogDensity = 3.0f;
		_ASCamera->fRot2Velocity[Z] += (float) g_lDeltatime/1000;
		if(_ASCamera->fRot[X] > 0.0f)
		{
			_ASCamera->fRot[X] -= (float) g_lDeltatime/1000;
			if(_ASCamera->fRot[X] < 0.0f)
				_ASCamera->fRot[X] = 0.0f;
		}
		if(_ASCamera->fRot[X] < 0.0f)
		{
			_ASCamera->fRot[X] += (float) g_lDeltatime/1000;
			if(_ASCamera->fRot[X] > 0.0f)
				_ASCamera->fRot[X] = 0.0f;
		}

		fGameOverBlend += (float) g_lDeltatime/500;
		if(fGameOverBlend > 1.0f)
			fGameOverBlend = 1.0f;
		AnimateFont();

		if((CHECK_KEY(ASMouse.byButtons, 0) && ASMouse.byButtonFirst[0]) ||
		   (CHECK_KEY(ASMouse.byButtons, 1) && ASMouse.byButtonFirst[1]) ||
		   (CHECK_KEY(ASMouse.byButtons, 2) && ASMouse.byButtonFirst[2]))
			ASKeyFirst[DIK_SPACE] = TRUE;

		// Check if the 'any key' is pressed:
		for(i = 0; i < 256; i++)
		{
			if(i == AS_SCREENSHOT_KEY)
				continue;
			if(ASKeyFirst[i])
			{
				ASPlayFmodSample(pMenuSelectSample, FSOUND_LOOP_OFF);
				bGameOver = FALSE;
				bShowGameMenu = TRUE;

				// Enable the highscore
				bShowHighscore = TRUE;
				bPlayerEnteringHighScore = TRUE;
				byPlayersHScorePlace = -1;
				fGameMenuBlend = 0.0f;
				return 0;
			}
		}
	}
	else
	{
		fGameOverBlend -= (float) g_lDeltatime/500;
		if(fGameOverBlend < 0.0f)
			fGameOverBlend = 0.0f;
	}

	if(Player.pActor->fThrustPower)
		ASPlayFmodSample(pThrustSample, FSOUND_LOOP_NORMAL);
	else
		ASStopFmodSample(pThrustSample);

	// Game menu blending:
	if(bShowGameMenu)
	{
		fGameMenuBlend += (float) g_lDeltatime/500;
		if(fGameMenuBlend > 1.0f)
			fGameMenuBlend = 1.0f;
	}
	else
	{
		fGameMenuBlend -= (float) g_lDeltatime/500;
		if(fGameMenuBlend < 0.0f)
			fGameMenuBlend = 0.0f;
	}

// Keys:
	if(ASKeyFirst[DIK_F1])
		OpenHelp(); // Open the help file:
	if(ASKeyFirst[DIK_F12])
	{ // Open the configuration menu:
		SendMessage(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), WM_COMMAND, ID_OPTIONS_CONFIG, 0);
	}
	if(!bShowGameMenu && !bGameWon && !bShowHighscore)
	{
		if(ASKeyFirst[DIK_ESCAPE])
		{
			ASPlayFmodSample(pMenuBackSample, FSOUND_LOOP_OFF);
			bShowGameMenu = !bShowGameMenu;
			bPause = bShowGameMenu;
			ASKeyFirst[DIK_ESCAPE] = FALSE;
		}
		else
		{
			if(ASKeyFirst[_ASConfig->iPauseKey[0]] && !bShowGameMenu)
				bPause = !bPause;
			if(ASKeyFirst[_ASConfig->iStandartViewKey[0]])
				_ASCamera->SetStandartCamera();
			if(ASKeyFirst[_ASConfig->iHudKey[0]])
			{
				ASPlayFmodSample(pMenuBackSample, FSOUND_LOOP_OFF);
				Setup.bShowHud = !Setup.bShowHud;
			}
		}
	}

// Other:
	if(fGameMenuBlend || fCreditsBackgroundBlend || fHighscoreBlend || bShowGameMenu)
	{
		CheckMenuPoints();
		CheckGameMenu();
	}

	// Check cheat keys:
	if(bCheatsActivated)
	{
		if(ASKeyFirst[DIK_F2])
		{
			bInvulnerable = !bInvulnerable;
			sprintf(byTemp, "Invulnerable %d", bInvulnerable);
			ShowSmallMessage(byTemp, 3000);
		}
		if(ASKeyFirst[DIK_F3])
		{
			bUnlimitedThrust = !bUnlimitedThrust;
			sprintf(byTemp, "Unlimited thrust %d", bUnlimitedThrust);
			ShowSmallMessage(byTemp, 3000);
		}
		if(ASKeyFirst[DIK_F4])
		{
			bUnlimitedTerraform = !bUnlimitedTerraform;
			sprintf(byTemp, "Unlimited terraform %d", bUnlimitedTerraform);
			ShowSmallMessage(byTemp, 3000);
		}
		if(ASKeyFirst[DIK_F5])
		{
			bUnlimitedSparks = !bUnlimitedSparks;
			sprintf(byTemp, "UnlimitedSparks %d", bUnlimitedSparks);
			ShowSmallMessage(byTemp, 3000);
		}
		if(ASKeyFirst[DIK_F6])
		{
			bLowGravitation = !bLowGravitation;
			sprintf(byTemp, "Low gravitation %d", bLowGravitation);
			ShowSmallMessage(byTemp, 3000);
		}
		if(ASKeyFirst[DIK_F7])
		{
			bNoWater = !bNoWater;
			sprintf(byTemp, "No water %d", bNoWater);
			ShowSmallMessage(byTemp, 3000);
		}
		if(ASKeyFirst[DIK_F8])
		{
			bNoFog = !bNoFog;
			sprintf(byTemp, "No fog %d", bNoFog);
			ShowSmallMessage(byTemp, 3000);
		}
		if(ASKeyFirst[DIK_F9])
		{
			bSpeedControl = !bSpeedControl;
			sprintf(byTemp, "Speed control %d", bSpeedControl);
			ShowSmallMessage(byTemp, 3000);
		}
		if(ASKeyFirst[DIK_F10])
			Level.iAblazeBallsInAblazeSpace = 5;
		if(bSpeedControl)
		{
			if(ASKeyFirst[DIK_ADD])
			{
				iSpeedFactor++;
				if(iSpeedFactor == -1 || iSpeedFactor == 1)
					iSpeedFactor++;
			}
			if(ASKeyFirst[DIK_SUBTRACT])
			{
				iSpeedFactor--;
				if(iSpeedFactor == -1 || iSpeedFactor == 1)
					iSpeedFactor--;
			}
		}
		else
			iSpeedFactor = 1;
	}
	else
		iSpeedFactor = 1;

	if(ASKeyFirst[_ASConfig->iNextMusicKey[0]])
	{
		GetNewGameMusic();
		StartGameMusic();
	}

	return 0;
} // end GameCheck()

void UpdateAllTextures(void)
{ // begin UpdateAllTextures()
	if(bFirstRunConfigDialog)
		return;
	ASDestroyOpenGLTextures(GAME_TEXTURES, GameTexture);
	ASGenOpenGLTextures(GAME_TEXTURES, GameTexture);
	switch(_AS->GetModule())
	{
		case MODULE_GAME:
			_AS->pWindow[GAME_WINDOW_ID].KillFont();
			_AS->pWindow[GAME_WINDOW_ID].BuildFont();
		break;
	}
} // end UpdateAllTextures()

void UpdateRenderQuality(void)
{ // begin UpdateRenderQuality()
	if(bFirstRunConfigDialog)
		return;
	switch(_AS->GetModule())
	{
		case MODULE_GAME:
			ASConfigOpenGL(_AS->pWindow[GAME_WINDOW_ID].GetWidth(), _AS->pWindow[GAME_WINDOW_ID].GetWidth());
		break;
	}
} // end UpdateRenderQuality()

void CreateGameLists(void)
{ // begin CreateGameLists()
	GLUquadricObj *pQuadric;
	FLOAT3 fSkyPoints[8] = 
	{
		{-1.0f, -1.0f, -1.0f}, // 0
		{1.0f, -1.0f, -1.0f}, // 1
		{1.0f, 1.0f, -1.0f}, // 2
		{-1.0f, 1.0f, -1.0f}, // 3
		{-1.0f, -1.0f, 1.0f}, // 4
		{1.0f, -1.0f, 1.0f}, // 5
		{1.0f, 1.0f, 1.0f}, // 6
		{-1.0f, 1.0f, 1.0f}, // 7
	};

	iSkyCubeList = glGenLists(1);
	glNewList(iSkyCubeList, GL_COMPILE);
		// Draw the asteroid belt:
		glEnable(GL_TEXTURE_2D);
		glDisable(GL_LIGHTING);
		glDisable(GL_CULL_FACE);
		glDisable(GL_DEPTH_TEST);
		glDisable(GL_BLEND);
		glDisable(GL_FOG);
		glScalef(10.0f, 10.0f, 10.0f);

		glEnableClientState(GL_VERTEX_ARRAY);
		glVertexPointer(3, GL_FLOAT, 0, fSkyPoints);

		// Floor face
		glBindTexture(GL_TEXTURE_2D, GameTexture[10].iOpenGLID);
		glBegin(GL_QUADS);
			glTexCoord2f(0.001f, 0.001f); glArrayElement(4);
			glTexCoord2f(0.999f, 0.001f); glArrayElement(5);
			glTexCoord2f(1.0f, 0.999f); glArrayElement(6);
			glTexCoord2f(0.001f, 0.999f); glArrayElement(7);
		glEnd();

		// Sky face
		glBindTexture(GL_TEXTURE_2D, GameTexture[11].iOpenGLID);
		glBegin(GL_QUADS);
			glTexCoord2f(0.001f, 0.999f); glArrayElement(0);
			glTexCoord2f(0.001f, 0.001f); glArrayElement(3);
			glTexCoord2f(0.999f, 0.001f); glArrayElement(2);
			glTexCoord2f(0.999f, 0.999f); glArrayElement(1);
		glEnd();

		// Left face
		glBindTexture(GL_TEXTURE_2D, GameTexture[13].iOpenGLID);
		glBegin(GL_QUADS);
			glTexCoord2f(0.999f, 0.001f); glArrayElement(0);
			glTexCoord2f(0.999f, 0.999f); glArrayElement(4);
			glTexCoord2f(0.001f, 0.999f); glArrayElement(7);
			glTexCoord2f(0.001f, 0.001f); glArrayElement(3);
		glEnd();

		// Front face
		glBindTexture(GL_TEXTURE_2D, GameTexture[15].iOpenGLID);
		glBegin(GL_QUADS);
			glTexCoord2f(0.001f, 0.001f); glArrayElement(0);
			glTexCoord2f(0.999f, 0.001f); glArrayElement(1);
			glTexCoord2f(0.999f, 0.999f); glArrayElement(5);
			glTexCoord2f(0.001f, 0.999f); glArrayElement(4);
		glEnd();

		// Right face
		glBindTexture(GL_TEXTURE_2D, GameTexture[14].iOpenGLID);
		glBegin(GL_QUADS);
			glTexCoord2f(0.001f, 0.001f); glArrayElement(1);
			glTexCoord2f(0.999f, 0.001f); glArrayElement(2);
			glTexCoord2f(0.999f, 0.999f); glArrayElement(6);
			glTexCoord2f(0.001f, 0.999f); glArrayElement(5);
		glEnd();

		// Back face
		glBindTexture(GL_TEXTURE_2D, GameTexture[12].iOpenGLID);
		glBegin(GL_QUADS);
			glTexCoord2f(0.999f, 0.001f); glArrayElement(3);
			glTexCoord2f(0.999f, 0.999f); glArrayElement(7);
			glTexCoord2f(0.001f, 0.999f); glArrayElement(6);
			glTexCoord2f(0.001f, 0.001f); glArrayElement(2);
		glEnd();
		
		glDisableClientState(GL_VERTEX_ARRAY);
		glEnable(GL_CULL_FACE);
		glEnable(GL_DEPTH_TEST);
		ASEnableLighting();
	glEndList();

	pQuadric = gluNewQuadric();
	gluQuadricDrawStyle(pQuadric, GLU_FILL);
	gluQuadricNormals(pQuadric, GLU_SMOOTH);
	gluQuadricTexture(pQuadric, GL_TRUE);
	iSphereList[0] = glGenLists(23);
	for(int i = 0; i < 23; i++)
	{
		iSphereList[i] = iSphereList[0]+i;
		glNewList(iSphereList[i], GL_COMPILE);
			gluSphere(pQuadric, 1.0f, 8+i, 8+i);
		glEndList();
	}
	gluDeleteQuadric(pQuadric);
} // end CreateGameLists()()

void DestroyGameLists(void)
{ // begin DestroyGameLists()
	if(glIsList(iSkyCubeList))
		glDeleteLists(iSkyCubeList, 1);
	if(glIsList(iSphereList[0]))
		glDeleteLists(iSphereList[0], 23);
} // end DestroyeGameLists()

void InitGameParticleSystems(void)
{ // begin InitGameParticleSystems()
	AS_PARTICLE_SYSTEM *pSystemT;
	AS_PARTICLE *pParticleT;
	int i, i2;
	
	DestroyGameParticleSystems();
	//
	// PS_WATER_WAVES:
	ParticleManager.AddNewSystem(PS_WaterWaves, 200, NULL, &GameTexture[6], NULL);
	ParticleManager.pSystem[PS_WATER_WAVES].bActive = TRUE;

	// PS_WATER_BUBBLES:
	ParticleManager.AddNewSystem(PS_WaterBubbles, 200, NULL, &GameTexture[7], NULL);
	ParticleManager.pSystem[PS_WATER_BUBBLES].bActive = TRUE;

	// PS_ABLAZE_SPACE:
	ParticleManager.AddNewSystem(PS_AblazeSpace, 200, NULL, &GameTexture[16], NULL);
	pSystemT = &ParticleManager.pSystem[PS_ABLAZE_SPACE];
	pSystemT->bActive = TRUE;
	pSystemT->bAnimatedParticles = TRUE;
	pSystemT->iAnimationColumns = 4;
	pSystemT->iAnimationRows = 4;
	pSystemT->iTextureWidth = 256;
	pSystemT->iTextureHeight = 256;

	// PS_WATER_STREAM:
	ParticleManager.AddNewSystem(PS_WaterStream, 500, NULL, &GameTexture[18], NULL);
	pSystemT = &ParticleManager.pSystem[PS_WATER_STREAM];
	pSystemT->bActive = TRUE;
	pSystemT->bAnimatedParticles = TRUE;
	pSystemT->iAnimationColumns = 4;
	pSystemT->iAnimationRows = 4;
	pSystemT->iTextureWidth = 256;
	pSystemT->iTextureHeight = 256;

	// PS_ABLAZE_TRACE:
	ParticleManager.AddNewSystem(PS_AblazeTrace, 400, NULL, &GameTexture[20], NULL);
	ParticleManager.pSystem[PS_ABLAZE_TRACE].bActive = TRUE;

	// PS_POINT_TRACE:
	ParticleManager.AddNewSystem(PS_AblazeTrace, 400, NULL, &GameTexture[24], NULL);
	ParticleManager.pSystem[PS_POINT_TRACE].bActive = TRUE;

	// The center ablaze:
	ParticleManager.AddNewSystem(PS_Ablaze, 10, NULL, &GameTexture[32], NULL);
	pSystemT = &ParticleManager.pSystem[PS_CENTER_ABLAZE];
	pSystemT->fStartPos[X] = Level.fWidth/2-0.5f;
	pSystemT->fStartPos[Y] = Level.fHeight/2-0.5f;
	pSystemT->fStartPos[Z] = Level.fMiddleHeight-5.0f;
	for(i = 0; i < pSystemT->iParticles; i++)
	{
		pParticleT = &pSystemT->pParticle[i];
		pParticleT->bAlive = TRUE;
		pParticleT->fSize = 20000.0f;
		pParticleT->fColor[R] = 0.0f;
		pParticleT->fColor[G] = 0.0f;
		pParticleT->fColor[B] = 0.0f;
	  	pParticleT->fEngine = 1.0f;
		pParticleT->fSize = 10.0f+((float) (rand() % 500)/30);
		for(i2 = 0; i2 < 3; i2++)
		{
			if((rand() % 2))
				pParticleT->fVelocity[i2] = (3.0f+((float) (rand() % 2000)/1000.0f))/100;
			else
				pParticleT->fVelocity[i2] = -(3.0f+((float) (rand() % 2000)/1000.0f))/100;
		}
	}
	//
} // end InitGameParticleSystems()

void DestroyGameParticleSystems(void)
{ // begin DestroyGameParticleSystems()
	ParticleManager.Destroy();
} // end DestroyGameParticleSystems()

// This is used for making the flares. It only works on one part of the program.
// fP is the position. 1.0f is where the light is, -1.0f is the opposite side.
// fS is the size. 1.0f will fill the screen when looking right at the light.
// fR, fG, and fB are the colour of the flare.
void MakeFlare(float fP, float fS, float fR, float fG, float fB, float fBrightness,
			   FLOAT3 fSPos)
{ // begin MakeFlare()
	float fLoop;

	glBegin(GL_TRIANGLE_FAN);
		glColor4f(1.0f, 1.0f, 1.0f, fBrightness*0.5f);
		glVertex2f(fSPos[X]*fP, fSPos[Y]*fP);
		glColor4f(fR, fG, fB, 0.0f);
		for(fLoop = 0.0f; fLoop < 6.283185307f; fLoop += 6.283185307f/6.0f)
			 glVertex2f((float) (fSPos[X]*fP+sin(fLoop)*fS*fBrightness),
						(float) (fSPos[Y]*fP+cos(fLoop)*fS*fBrightness));
	glEnd();
} // end MakeFlare()

// Make the actual flares:
void DrawFlares(AS_3D_VECTOR vSunPos)
{ // begin DrawFlares();
    GLdouble dModelMatrix[16];
    GLdouble dProjMatrix[16];
    float fBrightness = 0.0f; // How bright the light is
    GLint iViewport[4];
    DOUBLE3 dSPos; // Where on the screen the light is
	FLOAT3 fSPos; // The same as float
    BOOL bBig = TRUE;
    float fDepth; // The depth in the framebuffer
    float fLoop;
    int iX, iY;

	_ASCamera->SetCameraTranslation(FALSE);
    
	// Load the matricies and viewport:
    glGetDoublev(GL_MODELVIEW_MATRIX, dModelMatrix);
    glGetDoublev(GL_PROJECTION_MATRIX, dProjMatrix);
    glGetIntegerv(GL_VIEWPORT, iViewport);
    
	// Find out where the light is on the screen.
	gluProject(vSunPos.fX, vSunPos.fY, vSunPos.fZ, dModelMatrix, dProjMatrix,
				iViewport, &dSPos[X], &dSPos[Y], &dSPos[Z]);

    // Go through some of the points near the light:
	for(iX = -4; iX <= 4; iX++)
        for(iY = -4; iY <= 4; iY++)
        {
            if(iViewport[2]/300.0f*iX+dSPos[X] < iViewport[2] &&
			   iViewport[2]/300.0f*iX+dSPos[X] >= 0 &&
			   iViewport[3]/300.0f*iY+dSPos[Y] < iViewport[3] &&
			   iViewport[3]/300.0f*iY+dSPos[Y] >= 0 )
            { // If the point is on the screen:
                 // Read the depth from the depth buffer:
				glReadPixels((int)(iViewport[2]/300.0f*iX+dSPos[X]),
							 (int)(iViewport[3]/300.0f*iY+dSPos[Y]),
							 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, &fDepth);
                // If the light is infront of what ever was in that spot, increase the brightness:
				if(fDepth >= dSPos[Z])
					fBrightness += 1.0f/81.0f; 
            }
        }
	if(dSPos[X] < iViewport[2] && dSPos[X] >= 0 &&
	   dSPos[Y] < iViewport[3] && dSPos[Y] >= 0 )
    { // If the light is on the screen:
        glReadPixels((int) (dSPos[X]),(int) (dSPos[Y]),
					  1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, &fDepth);
        if(fDepth < dSPos[Z] && dSPos[Z]-fDepth > 0.0002) // It is behind something
            fBrightness = 0.0f; // The light can't be seen
    }
    else // If the light isn't on the screen:
        fBrightness = 0.0f; // The light can't be seen    
	
	// Draw some stuff which has no influence on the flares:

     // Now that we know the brightness, convert:
	dSPos[X] = dSPos[X]/(float) iViewport[2]*2.0f-1.0f;
    // The position to a number between (-1,-1) and (1,1):
	dSPos[Y] = dSPos[Y]/(float) iViewport[2]*2.8f-1.0f;

	// And adjust the brightness so it is brighter at the centre of the screen:
	fBrightness *= (float) ((1.2f-ASFastSqrt((float) (dSPos[X]*dSPos[X]+dSPos[Y]*dSPos[Y])))*fBrightness*0.75f);
	if(fBrightness > 0.99f)
		fBrightness = 0.99f;
	if(fBrightness < 0.0f)
		return;
    
	// Draw now the flares:
	glPushMatrix();
    glLoadIdentity();
    glMatrixMode(GL_PROJECTION);
	glEnable(GL_BLEND);
	glPushMatrix();
	glDepthMask(FALSE);

	// Forget about the view and projection. We will be drawing in 2D for the flares:
	glLoadIdentity();
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    glDisable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
    
    fSPos[X] = (float) dSPos[X];
    fSPos[Y] = (float) dSPos[Y];
    fSPos[Z] = (float) dSPos[Z];

	fBrightness *= 0.4f;

	// Make a steak across the screen where the light is:
	glBegin(GL_TRIANGLE_FAN);
		glColor4f(0.9f, 1.0f, 0.9f, fBrightness*0.2f);
		glVertex2f(fSPos[X], fSPos[Y]);
		glColor4f(1.0f, 1.0f, 1.0f, 0.0f);
		glVertex2f(fSPos[X]+2.5f*fBrightness, fSPos[Y]);
		glVertex2f(fSPos[X], fSPos[Y]+0.1f*fBrightness);
		glVertex2f(fSPos[X]-2.5f*fBrightness, fSPos[Y]);
		glVertex2f(fSPos[X], fSPos[Y]-0.1f*fBrightness);
		glVertex2f(fSPos[X]+2.5f*fBrightness, fSPos[Y]);
    glEnd();

    // Brighten the screen:
	glEnable(GL_BLEND);
	glColor4f(1.0f, 1.0f, 1.0f, fBrightness);
    glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f);
		glVertex2f(fSPos[X]-2, fSPos[Y]-2);
		glTexCoord2f(1.0f, 0.0f);
		glVertex2f(fSPos[X]+2, fSPos[Y]-2);
		glTexCoord2f(1.0f, 1.0f);
		glVertex2f(fSPos[X]+2, fSPos[Y]+2);
		glTexCoord2f(0.0f, 1.0f);
		glVertex2f(fSPos[X]-2, fSPos[Y]+2);
    glEnd();

    // Draw the main flare:
	glBegin(GL_TRIANGLE_FAN);
		glColor4f(1.0f, 1.0f, 1.0f, fBrightness*0.5f);
		glVertex2f(fSPos[X], fSPos[Y]);
		glColor4f(1.0f, 1.0f, 0.5f, 0.0f);
		// Make a 32 point star (64/2=32)
		for(fLoop = 0.0f; fLoop < 6.283185307f; fLoop += 6.283185307f/64.0f)
		{
			glVertex2f((float) (fSPos[X]+sin(fLoop)*(bBig ? 2.0f*fBrightness : 1.0f*fBrightness)),
					   (float) (fSPos[Y]+cos(fLoop)*(bBig ? 2.0f*fBrightness : 1.0f*fBrightness)));
			bBig = !bBig; // Make the next part of the star the opposite of this part
		}                    
    glEnd();
    
    // Draw other flares:
    MakeFlare(0.7f, 0.2f, 1.0f, 1.0f, 1.0f, fBrightness, fSPos);
    MakeFlare(0.6f, 0.3f, 1.0f, 0.6f, 0.6f, fBrightness, fSPos);
    MakeFlare(0.4f, 0.4f, 1.0f, 1.0f, 1.0f, fBrightness, fSPos);
    MakeFlare(0.3f, 0.6f, 0.8f, 0.8f, 0.6f, fBrightness, fSPos);
    MakeFlare(0.2f, 0.5f, 1.0f, 1.0f, 1.0f, fBrightness, fSPos);
    MakeFlare(-0.1f, 0.4f, 0.6f, 1.0f, 0.6f, fBrightness, fSPos);
    MakeFlare(-0.2f, 0.3f, 1.0f, 1.0f, 1.0f, fBrightness, fSPos);
    MakeFlare(-0.4f, 0.2f, 0.6f, 0.8f, 0.8f, fBrightness, fSPos);
    MakeFlare(-0.6f, 0.4f, 1.0f, 1.0f, 1.0f, fBrightness, fSPos);
    MakeFlare(-0.7f, 0.5f, 0.6f, 0.6f, 1.0f, fBrightness, fSPos);
    MakeFlare(-0.8f, 0.6f, 1.0f, 1.0f, 1.0f, fBrightness, fSPos);
    MakeFlare(-0.9f, 0.5f, 0.8f, 0.6f, 0.8f, fBrightness, fSPos);
    MakeFlare(-1.2f, 0.3f, 1.0f, 1.0f, 1.0f, fBrightness, fSPos);

    glEnable(GL_LIGHTING);
    glEnable(GL_CULL_FACE);
    glEnable(GL_DEPTH_TEST);
    glPopMatrix(); 
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
	glDepthMask(TRUE);
} // end DrawFlares()

void CreateWaterWave(float fXPos, float fYPos, float fSize)
{ // begin CreateWaterWave()
	AS_PARTICLE *pParticleT;
	int i;
	
	i = ParticleManager.pSystem[PS_WATER_WAVES].GetFreeParticle();
	if(i == -1)
		return;
	pParticleT = &ParticleManager.pSystem[PS_WATER_WAVES].pParticle[i];
	pParticleT->bAlive = TRUE;
	pParticleT->fEngine = (float) 1.0;
	pParticleT->fColor[0] = 1.0f;
	pParticleT->fColor[1] = 1.0f;
	pParticleT->fColor[2] = 1.0f;
	pParticleT->fFadeSpeed = 0.004f;
	pParticleT->fSize = fSize;
	pParticleT->fPos[X] = fXPos;
	pParticleT->fPos[Y] = fYPos;
} // end CreateWaterWave()

void CreateWaterStream(float fXPos, float fYPos, float fZPos, float fRand, float fSize, float fEnergie)
{ // begin CreateWaterStream()
	AS_PARTICLE *pParticleT;
	int i;
	
	i = ParticleManager.pSystem[PS_WATER_STREAM].GetFreeParticle();
	if(i == -1)
		return;
	if(fSize < 0.01f)
		fSize = 0.01f;
	pParticleT = &ParticleManager.pSystem[PS_WATER_STREAM].pParticle[i];
	pParticleT->bAlive = TRUE;
	pParticleT->fEngine = (float) 1.0f;
	pParticleT->fColor[0] = 0.0f;
	pParticleT->fColor[1] = 0.0f;
	pParticleT->fColor[2] = 0.0f;
	pParticleT->fFadeSpeed = 0.00001f+((float) (rand() % 100)/100000);
	pParticleT->fFadeSpeed *= 1.0f/fEnergie;
	pParticleT->fSize = 0.5f+(rand() % (int) (fSize*100))/100;
	if(!(rand() %2))
		pParticleT->fPos[X] = fXPos+(float) (rand() % (int) (fRand*1000))/1000;
	else
		pParticleT->fPos[X] = fXPos-(float) (rand() % (int) (fRand*1000))/1000;
	if(!(rand() %2))
		pParticleT->fPos[Y] = fYPos+(float) (rand() % (int) (fRand*1000))/1000;
	else
		pParticleT->fPos[Y] = fYPos-(float) (rand() % (int) (fRand*1000))/1000;
	if(!(rand() %2))
		pParticleT->fPos[Z] = fZPos+(float) (rand() % (int) (fRand*1000))/1000;
	else
		pParticleT->fPos[Z] = fZPos-(float) (rand() % (int) (fRand*1000))/1000;
	for(i = 0; i < 2; i++)
	{
		if(!(rand() % 2))
			pParticleT->fVelocity[i] = (float) 0.01f+(rand() % 1000)/600;
		else
			pParticleT->fVelocity[i] = (float) -(0.01f+(rand() % 1000)/600);
		pParticleT->fVelocity[i] *= fEnergie;
	}
	pParticleT->fVelocity[Z] = -((float) 0.1f+((float) (rand() % 1000)/1000));
	pParticleT->fVelocity[Z] *= fEnergie;
} // end CreateWaterStream()

void CreateAblazeTrace(float fXPos, float fYPos, float fZPos, float fRand, float fSize, float fEnergie)
{ // begin CreateAblazeTrace()
	AS_PARTICLE *pParticleT;
	int i;
	
	if(fSize < 0.01f)
		fSize = 0.01f;
	i = ParticleManager.pSystem[PS_ABLAZE_TRACE].GetFreeParticle();
	if(i == -1)
		return;
	pParticleT = &ParticleManager.pSystem[PS_ABLAZE_TRACE].pParticle[i];
	pParticleT->bAlive = TRUE;
	pParticleT->fEngine = (float) 1.0f;
	pParticleT->fColor[0] = 1.0f;
	pParticleT->fColor[1] = 0.5f;
	pParticleT->fColor[2] = 0.0f;
	pParticleT->fFadeSpeed = 0.0001f+((float) (rand() % 100)/10000);
	pParticleT->fFadeSpeed *= 1.0f/fEnergie;
	pParticleT->fSize = 2.0f+(rand() % (int) (fSize*200))/100;
	pParticleT->fSize *= fEnergie;
	if(fRand < 0.05f)
		fRand = 0.05f;
	if(!(rand() %2))
		pParticleT->fPos[X] = fXPos+(float) (rand() % (int) (fRand*1000))/1000;
	else
		pParticleT->fPos[X] = fXPos-(float) (rand() % (int) (fRand*1000))/1000;
	if(!(rand() %2))
		pParticleT->fPos[Y] = fYPos+(float) (rand() % (int) (fRand*1000))/1000;
	else
		pParticleT->fPos[Y] = fYPos-(float) (rand() % (int) (fRand*1000))/1000;
	if(!(rand() %2))
		pParticleT->fPos[Z] = fZPos+(float) (rand() % (int) (fRand*1000))/1000;
	else
		pParticleT->fPos[Z] = fZPos-(float) (rand() % (int) (fRand*1000))/1000;
	for(i = 0; i < 2; i++)
	{
		if(!(rand() % 2))
			pParticleT->fVelocity[i] = (float) 0.01f+(rand() % 1000)/6000;
		else
			pParticleT->fVelocity[i] = (float) -(0.01f+(rand() % 1000)/6000);
		pParticleT->fVelocity[i] *= fEnergie;
	}
	pParticleT->fVelocity[Z] = ((float) 0.1f+((float) (rand() % 1000)/1000));
	pParticleT->fVelocity[Z] *= fEnergie;
} // end CreateAblazeTrace()

void CreatePointTrace(float fXPos, float fYPos, float fZPos, float fRand, float fSize, float fEnergie)
{ // begin CreatePointTrace()
	AS_PARTICLE *pParticleT;
	int i;
	
	if(fSize < 0.01f)
		fSize = 0.01f;
	i = ParticleManager.pSystem[PS_POINT_TRACE].GetFreeParticle();
	if(i == -1)
		return;
	pParticleT = &ParticleManager.pSystem[PS_POINT_TRACE].pParticle[i];
	pParticleT->bAlive = TRUE;
	pParticleT->fEngine = (float) 1.0f;
	pParticleT->fColor[0] = 1.0f;
	pParticleT->fColor[1] = 1.0f;
	pParticleT->fColor[2] = 1.0f;
	pParticleT->fFadeSpeed = 0.0001f+((float) (rand() % 100)/10000);
	pParticleT->fFadeSpeed *= 1.0f/fEnergie;
	pParticleT->fSize = 2.0f+(rand() % (int) (fSize*200))/100;
	pParticleT->fSize *= fEnergie;
	if(fRand < 0.05f)
		fRand = 0.05f;
	if(!(rand() %2))
		pParticleT->fPos[X] = fXPos+(float) (rand() % (int) (fRand*1000))/1000;
	else
		pParticleT->fPos[X] = fXPos-(float) (rand() % (int) (fRand*1000))/1000;
	if(!(rand() %2))
		pParticleT->fPos[Y] = fYPos+(float) (rand() % (int) (fRand*1000))/1000;
	else
		pParticleT->fPos[Y] = fYPos-(float) (rand() % (int) (fRand*1000))/1000;
	if(!(rand() %2))
		pParticleT->fPos[Z] = fZPos+(float) (rand() % (int) (fRand*1000))/1000;
	else
		pParticleT->fPos[Z] = fZPos-(float) (rand() % (int) (fRand*1000))/1000;
	for(i = 0; i < 2; i++)
	{
		if(!(rand() % 2))
			pParticleT->fVelocity[i] = (float) 0.01f+(rand() % 1000)/6000;
		else
			pParticleT->fVelocity[i] = (float) -(0.01f+(rand() % 1000)/6000);
		pParticleT->fVelocity[i] *= fEnergie;
	}
	pParticleT->fVelocity[Z] = ((float) 0.1f+((float) (rand() % 1000)/1000));
	pParticleT->fVelocity[Z] *= fEnergie;
} // end CreatePointTrace()

void CreateWaterBombStream(void)
{ // begin CreateWaterBombStream()
	AS_PARTICLE *pParticleT;
	int i, i2;
	
	for(i2 = 0; i2 < 200; i2++)
	{
		i = ParticleManager.pSystem[PS_WATER_STREAM].GetFreeParticle();
		if(i == -1)
			return;
		pParticleT = &ParticleManager.pSystem[PS_WATER_STREAM].pParticle[i];
		pParticleT->bAlive = TRUE;
		pParticleT->fEngine = (float) 1.0f;
		pParticleT->fColor[0] = 0.0f;
		pParticleT->fColor[1] = 0.0f;
		pParticleT->fColor[2] = 0.0f;
		pParticleT->fFadeSpeed = 0.00001f+((float) (rand() % 100)/100000);
		pParticleT->fSize = 0.5f+(rand() % (int) (0.5f*100))/100;
		if(!(rand() % 2))
			pParticleT->fVelocity[X] = (float) (rand() % 1000)/1000;
		else
			pParticleT->fVelocity[X] = (float) -(rand() % 1000)/1000;
		if(!(rand() % 2))
			pParticleT->fVelocity[Y] = (float) (rand() % 1000)/1000;
		else
			pParticleT->fVelocity[Y] = (float) -(rand() % 1000)/1000;
		pParticleT->fVelocity[Z] = -((float) 0.1f+((float) (rand() % 1000)/1000));
		pParticleT->fPos[X] = ((float) (rand() % (int) (Level.fWidth*100))/100);
		pParticleT->fPos[Y] = ((float) (rand() % (int) (Level.fHeight*100))/100);
		pParticleT->fPos[Z] = Level.FastComputeHeight(pParticleT->fPos[X], pParticleT->fPos[Y],
													  POINT_WATER);
	}
} // end CreateWaterBombStream()

void StartNewGame(void)
{ // begin StartNewGame()
	Level.Destroy();
	Level.Create(LEVEL_SIZE, LEVEL_SIZE);
	_ASCamera->SetStandartCamera();
	InitGameParticleSystems();
	InitActors();
	Player.Init();
	Level.CalculateNormals();
	Level.CalculateFieldBoundingBoxes();
	Level.Quadtree.Build(&Level);
	Level.FOVUpdate();
	Level.bTerrainUpdate = TRUE;
	Level.Check();
	bFirstPauseTest = FALSE;
	iCurrentSelectedMusic = -1;
	StartGameMusic();
} // end StartNewGame()

void LevelRestart(void)
{ // begin LevelRestart()
	Level.Restart();
	_ASCamera->SetStandartCamera();
	InitGameParticleSystems();
	InitActors();
	Player.Init();
	Level.CalculateNormals();
	Level.CalculateFieldBoundingBoxes();
	Level.Quadtree.Build(&Level);
	Level.FOVUpdate();
	Level.Check();
	Level.bTerrainUpdate = TRUE;
	bFirstPauseTest = FALSE;
} // end LevelRestart()

void ShowSmallMessage(char *pbyText, long lShowTime)
{ // begin ShowSmallMessage()
	if(!strcmp(pbyText, bySmallMessageNewText))
		return;
	strcpy(bySmallMessageNewText, pbyText);
	lSmallMessageShowTime = lShowTime;
	bSmallMessageShowText = bSmallMessageChangeText = TRUE;
} // end ShowSmallMessage()

void DisplaySmallMessage(AS_WINDOW *pWindow)
{ // begin DisplaySmallMessage()
	if(fSmallMessageBlend <= 0.0f)
		return; // Show no message!
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glColor4f(1.0f, 1.0f, 1.0f, fSmallMessageBlend);
	pWindow->PrintAnimated(400, 10, bySmallMessageText, 0, fSmallMessageBlend*1.3f, fFontAni, 1);
} // end DisplaySmallMessage()

void CheckSmallMessage(void)
{ // begin CheckSmallMessage()
	if(bSmallMessageChangeText)
	{ // Change to the next text:
		fSmallMessageBlend -= (float) g_lDeltatime/300;
		if(fSmallMessageBlend <= 0.0f)
		{ // Show the new text:
			fSmallMessageBlend = 0.0f;
			lSmallMessageTimer = g_lNow;
			bSmallMessageChangeText = FALSE;
			strcpy(bySmallMessageText, bySmallMessageNewText);
		}
		return;
	}
	if(bSmallMessageShowText)
	{ // Blend in/show the text:
		if(fSmallMessageBlend != 1.0f)
		{
			fSmallMessageBlend += (float) g_lDeltatime/((float) (fSmallMessageBlend+0.01f)*4000);
			if(fSmallMessageBlend >= 1.0f)
				fSmallMessageBlend = 1.0f;
		}
		if(g_lNow-lSmallMessageTimer >= lSmallMessageShowTime)
		{ // Time out, disable the text:
			bSmallMessageShowText = FALSE;
		}
	}
	else
	{ // Blend out the text:
		fSmallMessageBlend -= (float) g_lDeltatime/5000;
		if(fSmallMessageBlend <= 0.0f)
		{
			fSmallMessageBlend = 0.0f;
			strcpy(bySmallMessageText, "");
		}
	}
} // end CheckSmallMessage()

void RestartSoundSystem(void)
{ // begin RestartSoundSystem()
	_AS->WriteLogMessage("Restart sound system");

	ASDestroyFmodSamples(GAME_SAMPLES, GameSample);
	StopMusic();
	ASDestroyFmod();
	ASInitFmod();
	LoadSamples();
	StartCurrentMusic();
} // end RestartSoundSystem()

void SetGameLanguage(void)
{ // begin SetGameLanguage()
	char byTemp[256];
	HWND hWndGame;
	
	if(GAME_WINDOW_ID == -1 || !_AS->GetWindows())
		return;
	hWndGame = *_AS->pWindow[GAME_WINDOW_ID].GethWnd();

	// Setup the texts of the menu bar:
	HMENU hMenu = GetMenu(hWndGame);
	MENUITEMINFO SubMenuInfo = { sizeof(MENUITEMINFO),
							     MIIM_ID | MIIM_TYPE,
								 MFT_STRING, MFS_DEFAULT,
								 IDR_GAME,
								 NULL, NULL, NULL, NULL,
								 T_Quit, 0};
	ModifyMenu(hMenu, 0, MF_STRING | MF_BYPOSITION, 0, T_General);
	SetMenuItemInfo(GetSubMenu(hMenu, 0), 0, TRUE, &SubMenuInfo);
	

	ModifyMenu(hMenu, 1, MF_STRING | MF_BYPOSITION, 0, T_Options);
	
	SubMenuInfo.wID = ID_OPTIONS_CONFIG;
	sprintf(byTemp, "%s\tF12", T_Configuration);
	SubMenuInfo.dwTypeData = byTemp;
	SetMenuItemInfo(GetSubMenu(hMenu, 1), 0, TRUE, &SubMenuInfo);
	
	SubMenuInfo.wID = ID_OPTIONS_SHOW_LOG;
	SubMenuInfo.dwTypeData = T_ShowLog;
	SetMenuItemInfo(GetSubMenu(hMenu, 1), 1, TRUE, &SubMenuInfo);


	ModifyMenu(hMenu, 2, MF_STRING | MF_BYPOSITION, 0, T_Help);
	
	SubMenuInfo.wID = ID_HELP_HELP;
	sprintf(byTemp, "%s\tF1", T_Help);
	SubMenuInfo.dwTypeData = byTemp;
	SetMenuItemInfo(GetSubMenu(hMenu, 2), 0, TRUE, &SubMenuInfo);
	
	SubMenuInfo.wID = ID_HELP_CREDITS;
	SubMenuInfo.dwTypeData = T_Credits;
	SetMenuItemInfo(GetSubMenu(hMenu, 4), 4, TRUE, &SubMenuInfo);

	DrawMenuBar(hWndGame);
} // end SetGameLanguage()
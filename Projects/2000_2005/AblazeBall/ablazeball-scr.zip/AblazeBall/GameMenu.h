//-----------------------------------------------------------------------------
// File: GameMenu.h
//-----------------------------------------------------------------------------

#ifndef __GAME_MENU_H__
#define __GAME_MENU_H__


// Definitions: ***************************************************************
#define MAX_HIGHSCORES 10 // The number of highscore entries
#define MENU_POINTS 26
#define TITEL_GRID_X_SIZE 20 // The width of the game title
#define TITEL_GRID_Y_SIZE 10 // The height of the game title
///////////////////////////////////////////////////////////////////////////////

// Structures: ****************************************************************
typedef struct HIGHSCORE
{
	char byName[50]; // Players name
	int iScore; // Players score

} HIGHSCORE;

typedef struct MENU_POINT
{
	BOOL bSelected; // Is this menu point current selected?
	float fSize; // The size of the text
	BOOL bSize; // For the size animation
	FLOAT3 fColor; // The text color

} MENU_POINT;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern BOOL bShowGameMenu, bPause;
extern char byGameMenuSelected, byGameMenuMenu, byLastGameMenuMenu;
extern float fGameMenuBlend, fGeneralGameMenuBlend, fGeneralGameBlend,
			 fCreditsBackgroundBlend, fHighscoreBlend;
extern BOOL bShowHighscore, bPlayerEnteringHighScore;
extern char byPlayersHScorePlace, byHighScoreInitialsIndex;
extern float fFontAni[4][2];
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern void DrawOptionsText(AS_WINDOW *, int, int, char *);
extern void DrawKeysSetupText(AS_WINDOW *, int, int, char *, char *);
extern void ShowGameMenu(AS_WINDOW *);
extern void CheckGameMenu(void);
extern void AnimateFont(void);
extern void DrawMenuBackground(float, float, float, float, FLOAT3, float);
extern void InitTitel(void);
extern void DrawTitel(void);
extern void CheckTitel(void);
extern HRESULT LoadHighscore(void);
extern HRESULT SaveHighscore(void);
extern void DrawHighscore(AS_WINDOW *);
extern void CheckHighscore(void);
extern void InitMenuPoints(void);
extern void CheckMenuPoints(void);
extern void ShowEndCredits(void);
///////////////////////////////////////////////////////////////////////////////


#endif // __GAME_MENU_H__
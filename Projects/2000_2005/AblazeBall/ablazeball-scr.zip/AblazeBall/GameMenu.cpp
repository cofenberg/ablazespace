//-----------------------------------------------------------------------------
// File: GameMenu.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
long lPressNewKeyTimer;
char byGameMenuSelected, byGameMenuMenu, byLastGameMenuMenu, byGameMenuSelectedTemp;
BOOL bGetPlayerName, // Does the player give in his name?
     bGetNewKey, // Does we wait for a new key definition?
	 bPressNewKeyText,
	 bAreYouSureQuestion,
	 bAreYouSureQuestionAnswer,
	 bShowGameMenu,
	 bPause;
char byGetPlayerName[256]; // The players name
float fGameMenuBlend;
MENU_POINT MenuPoint[MENU_POINTS];

// Game titel:
FLOAT3 fTitelGridPoint[TITEL_GRID_X_SIZE*TITEL_GRID_Y_SIZE];
FLOAT2 fCurrentTitelLensPos, fNextTitelLensPos, fTitelLensPosVelocity;
long lTitelAniTime;
float fCurrentTitelLensEffect, fTitelLensEffectVelocity, fNextTitelLensEffect,
	  fCurrentTitelLensRadius, fTitelLensRadiusVelocity, fNextTitelLensRadius;

// Credits:
BOOL bShowCredits, bCreditsWaiting, bBlendIn, bBlendOut;
float fCreditsBlend, fCreditsBackgroundBlend, fGeneralGameMenuBlend, fGeneralGameBlend,
	  fHighscoreBlend;
long lCreditsNext;
int iCreditsStep;

// Highscore stuff:
HIGHSCORE Highscore[MAX_HIGHSCORES] = 
{
	{"AblazeBall by AblazeSpace 2001", 6000},
	{"Programmed & Designed", 3000},
	{"by Christian Ofenberg", 2000},
	{"Music", 1000},
	{"by Jonne Valtonen", 900},
	{"Additional graphics", 800},
	{"by Michael M�ller", 700},
	{"Thank's to:", 600},
	{"Andr� Stillkerich", 500},
	{"Stephan Wezel", 400},
};
BOOL bShowHighscore, // Should the highscore be shown?
	 bPlayerEnteringHighScore; // Does the player enter his name in the highscore?
char byPlayersHScorePlace; // The players place in the highscore
const char byLegalHighScoreChars[38] = " 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

// For the animated font:
float fFontAni[4][2]; // The current vertex position
float fFontAniLast[4][2]; // The last vertex position
float fFontAniT[4][2]; // The vertex target position
float fFontAniV[4][2]; // The vertex velocity
///////////////////////////////////////////////////////////////////////////////

int iTemp = 0;

// Functions: *****************************************************************
void DrawOptionsText(AS_WINDOW *, int, int, char *);
void DrawKeysSetupText(AS_WINDOW *, int, int, char *, char *);
void ShowGameMenu(AS_WINDOW *);
void CheckGameMenu(void);
void AnimateFont(void);
void DrawMenuBackground(float, float, float, float, FLOAT3, float);
void InitTitel(void);
void DrawTitel(void);
void CheckTitel(void);
HRESULT LoadHighscore(void);
HRESULT SaveHighscore(void);
void DrawHighscore(AS_WINDOW *);
void CheckHighscore(void);
void InitMenuPoints(void);
void CheckMenuPoints(void);
void ShowEndCredits(void);
///////////////////////////////////////////////////////////////////////////////


void DrawOptionsText(AS_WINDOW *pWindow, int iMenu, int iY, char *pbyText)
{ // begin DrawKeysSetupText()
	glColor4f(MenuPoint[iMenu].fColor[R], MenuPoint[iMenu].fColor[G], MenuPoint[iMenu].fColor[B],
			  fGameMenuBlend*fGeneralGameMenuBlend);
	pWindow->PrintAnimated(400, iY, pbyText, 0, MenuPoint[iMenu].fSize*1.3f, fFontAni, 1);
} // end DrawOptionsText()

void DrawKeysSetupText(AS_WINDOW *pWindow, int iMenu, int iY, char *pbyAction, char *pbyKey)
{ // begin DrawKeysSetupText()
	glColor4f(MenuPoint[iMenu].fColor[R], MenuPoint[iMenu].fColor[G], MenuPoint[iMenu].fColor[B],
			  fGameMenuBlend*fGeneralGameMenuBlend);
	pWindow->PrintAnimated(100, iY, pbyAction, 0, MenuPoint[iMenu].fSize*1.2f, fFontAni, 0);
	pWindow->PrintAnimated(390, iY, pbyKey, 0, MenuPoint[iMenu].fSize*1.2f, fFontAni, 0);
} // end DrawKeysSetupText()

void ShowGameMenu(AS_WINDOW *pWindow)
{ // begin ShowGameMenu()
	FLOAT3 fColor = {0.3f, 0.3f, 0.3f};
	GLUquadricObj *pQuadric;
	float fBackAni[4][2];
	int i, i2;

	glCullFace(GL_FRONT);
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glDisable(GL_CULL_FACE);
	glBlendFunc(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);
	glColor4f(0.4f, 0.4f, 0.4f, (1-fGameMenuBlend)+0.6f);
	glBindTexture(GL_TEXTURE_2D, GameTexture[5].iOpenGLID);
	glEnable(GL_TEXTURE_GEN_T);

	_ASCamera->SetCameraTranslation(TRUE);
	pQuadric = gluNewQuadric();
	gluQuadricDrawStyle(pQuadric, GLU_FILL);
	gluQuadricNormals(pQuadric, GLU_SMOOTH);
	gluQuadricTexture(pQuadric, GL_TRUE);
	gluSphere(pQuadric, 5.0f, 5, 5);
	gluDeleteQuadric(pQuadric);
	glEnable(GL_CULL_FACE);
	glDisable(GL_BLEND);
	glCullFace(GL_BACK);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	glDisable(GL_TEXTURE_GEN_T);
	glEnable(GL_CULL_FACE);
	glEnable(GL_DEPTH_TEST);

	DrawTitel();
	for(i = 0; i < 4; i++)
		for(i2 = 0; i2 < 2; i2++)
			fBackAni[i][i2] = -fFontAni[i][i2]*0.2f;

	// Draw the dark blending quad:
	glBlendFunc(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);
	glColor4f(0.1f, 0.1f, 0.1f, 1.0f-fGameMenuBlend*fGeneralGameMenuBlend+0.2f);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_CULL_FACE);
	glLoadIdentity();
	glTranslatef(0.0f, 0.0f, -24.0f);
	switch(byGameMenuMenu)
	{
		case 0: // Main menu background:
			DrawMenuBackground(-6.0f+fBackAni[3][0], -9.5f+fBackAni[3][1],
							   6.5f+fBackAni[2][0], -1.5f+fBackAni[0][1],
							   fColor, 1.0f-fGameMenuBlend*fGeneralGameMenuBlend+0.2f);
			// The info bar:
			glColor4f(0.1f, 0.1f, 0.1f, 1.0f-fGameMenuBlend*fGeneralGameMenuBlend+0.2f);
			DrawMenuBackground(-15.0f, -10.0f,
							   15.0f, -9.0f,
							   fColor, 1.0f-fGameMenuBlend*fGeneralGameMenuBlend+0.2f);
		break;

		case 1: case 3: // The options menu: // Are you sure question:
			DrawMenuBackground(-7.0f+fBackAni[3][0], -3.0f+fBackAni[3][1],
							   7.5f+fBackAni[2][0], 1.5f+fBackAni[0][1],
							   fColor, 1.0f-fGameMenuBlend*fGeneralGameMenuBlend+0.2f);
		break;

		case 4: // Keys setup menu:
			DrawMenuBackground(-11.0f+fBackAni[3][0], -7.0f+fBackAni[3][1],
							   11.0f+fBackAni[2][0], 3.0f+fBackAni[0][1],
							   fColor, 1.0f-fGameMenuBlend*fGeneralGameMenuBlend+0.2f);
		break;

		default:
			glBegin(GL_QUADS);
				glVertex2f(-14.0f, -10.0f);
				glVertex2f(14.0f, -10.0f);
				glVertex2f(14.0f,  10.0f);
				glVertex2f(-14.0f,  10.0f);
			glEnd();
		break;
	}
	if(fHighscoreBlend)
	{ // Highscore background:
		glColor4f(0.1f, 0.1f, 0.1f, 1-fHighscoreBlend+0.2f);
		glLoadIdentity();
		glTranslatef(0.0f, 0.0f, -24.0f);
		DrawMenuBackground(-14.0f+fBackAni[3][0], -7.0f+fBackAni[3][1],
						   14.0f+fBackAni[2][0], 4.0f+fBackAni[0][1],
						   fColor, 1-fHighscoreBlend+0.2f);
		if(bGameWon)
		{
			glColor4f(0.1f, 0.1f, 0.1f, 1-fHighscoreBlend+0.2f);
			DrawMenuBackground(-14.0f+fBackAni[3][0], 5.0f+fBackAni[3][1],
							   14.0f+fBackAni[2][0], 9.5f+fBackAni[0][1],
							   fColor, 1-fHighscoreBlend+0.2f);
		}
	}

	glEnable(GL_CULL_FACE);
	glEnable(GL_TEXTURE_2D);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);

	if(fCreditsBackgroundBlend)
	{ // We are in the credits menu:
		// Draw the background box:
		glBlendFunc(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);
		glColor4f(0.1f, 0.1f, 0.1f, 1.0f-fCreditsBackgroundBlend+0.2f);
		glDisable(GL_TEXTURE_2D);
		glLoadIdentity();
		glTranslatef(0.0f, 0.0f, -24.0f);
		DrawMenuBackground(-13.0f+fBackAni[3][0], -6.5f+fBackAni[3][1],
						   13.0f+fBackAni[2][0], 1.0f+fBackAni[0][1],
						   fColor, 1.0f-fCreditsBackgroundBlend+0.2f);
		glEnable(GL_TEXTURE_2D);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);
		glColor4f(1.0f, 1.0f, 1.0f, fCreditsBackgroundBlend*fCreditsBlend);
		glDisable(GL_CULL_FACE);
		if(iCreditsStep == 0 || iCreditsStep == 1 || iCreditsStep == 2)
		{
			// Display credits pictures:
			glLoadIdentity();
			glTranslatef(-2.0f, -1.2f, -5.0f);

			// AblazeSpace:
			if(iCreditsStep == 0)
				glBindTexture(GL_TEXTURE_2D, GameTexture[23].iOpenGLID);

			// Christian Ofenberg:
			if(iCreditsStep == 1)
				glBindTexture(GL_TEXTURE_2D, GameTexture[21].iOpenGLID);

			// Music:
			if(iCreditsStep == 2)
				glBindTexture(GL_TEXTURE_2D, GameTexture[22].iOpenGLID);

			if(iCreditsStep == 0)
			{
				glBegin(GL_QUADS); 
					glTexCoord2f(1.0f, 0.0f); glVertex2f(3.0f, 0.0f);
					glTexCoord2f(1.0f, 1.0f); glVertex2f(3.0f, 1.0f);
					glTexCoord2f(0.0f, 1.0f); glVertex2f(1.0f, 1.0f);
					glTexCoord2f(0.0f, 0.0f); glVertex2f(1.0f, 0.0f);
				glEnd();
			}
			else
			{
				glBegin(GL_QUADS); 
					glTexCoord2f(1.0f, 1.0f); glVertex2f(1.0f, 0.0f);
					glTexCoord2f(1.0f, 0.0f); glVertex2f(1.0f, 1.0f);
					glTexCoord2f(0.0f, 0.0f); glVertex2f(0.0f, 1.0f);
					glTexCoord2f(0.0f, 1.0f); glVertex2f(0.0f, 0.0f);
				glEnd();
			}
		}

		// Display credits texts:
		glColor4f(1.0f, 1.0f, 1.0f, fCreditsBackgroundBlend);
		pWindow->PrintAnimated(400, 280, "Credits", 0, 2.2f, fFontAni, 1);
		glColor4f(1.0f, 1.0f, 1.0f, fCreditsBackgroundBlend*fCreditsBlend);
		switch(iCreditsStep)
		{
			case 0:
				pWindow->PrintAnimated(400, 200, M_AblazeBallBy, 0, 3.2f, fFontAni, 1);
				pWindow->PrintAnimated(400, 150, "AblazeSpace 2001", 0, 3.2f, fFontAni, 1);
			break;

			case 1:
				pWindow->PrintAnimated(450, 200, M_ProgrammedAndDesignedBy, 0, 1.2f, fFontAni, 1);
				pWindow->PrintAnimated(450, 180, "Christian Ofenberg", 0, 1.2f, fFontAni, 1);
			break;

			case 2:
				pWindow->PrintAnimated(450, 200, M_MusicBy, 0, 1.2f, fFontAni, 1);
				pWindow->PrintAnimated(450, 180, "Jonne Valtonen aka Purple Motion", 0, 1.2f, fFontAni, 1);
			break;

			case 3:
				pWindow->PrintAnimated(400, 230, M_AdditionalGraphicsBy, 0, 1.2f, fFontAni, 1);
				pWindow->PrintAnimated(400, 210, "Michael M�ller", 0, 1.2f, fFontAni, 1);
				pWindow->PrintAnimated(400, 190, "Marc McCall", 0, 1.2f, fFontAni, 1);
				pWindow->PrintAnimated(400, 170, "Sock", 0, 1.2f, fFontAni, 1);
			break;
			
			case 4:
				pWindow->PrintAnimated(400, 190, M_ThanksTo, 0, 1.2f, fFontAni, 1);
			break;

			case 5:
				pWindow->PrintAnimated(400, 210, "Andr� Stillkerich", 0, 1.2f, fFontAni, 1);
				pWindow->PrintAnimated(400, 190, "Stehpan Wezel", 0, 1.2f, fFontAni, 1);
				pWindow->PrintAnimated(400, 170, "Jens D�rholt", 0, 1.2f, fFontAni, 1);
			break;

			case 6:
				pWindow->PrintAnimated(400, 190, M_FurtherThanksTo, 0, 1.2f, fFontAni, 1);
			break;

			case 7:
				pWindow->PrintAnimated(400, 210, "www.gamedev.net", 0, 1.1f, fFontAni, 1);
				pWindow->PrintAnimated(400, 190, M_NeHe, 0, 1.1f, fFontAni, 1);
				pWindow->PrintAnimated(400, 170, M_Romaka, 0, 1.1f, fFontAni, 1);
			break;

			case 8:
				pWindow->PrintAnimated(400, 200, M_VisitTheAblazeSpaceHomepage, 0, 1.2f, fFontAni, 1);
				pWindow->PrintAnimated(400, 180, "www.ablazespace.de", 0, 1.2f, fFontAni, 1);
			break;
		}
		glEnable(GL_CULL_FACE);
	}

	if(fHighscoreBlend)
		DrawHighscore(pWindow);
	if((fGameMenuBlend*fGeneralGameMenuBlend))
	{
		glColor4f(1.0f, 1.0f, 1.0f, fGameMenuBlend*fGeneralGameMenuBlend);
		switch(byGameMenuMenu)
		{
			case 0: // Main menu:
				pWindow->Print(0, 5, "A game by AblazeSpace 2001                                 All rights reserved!", 0, 0);
				pWindow->Print(580, 250, GAME_VERSION, 0, 0);
				pWindow->PrintAnimated(400, 200, T_MainMenu, 0, 2.2f, fFontAni, 1);
				DrawOptionsText(pWindow, 0, 170, T_ContinueGame);
				DrawOptionsText(pWindow, 1, 150, T_LevelRestart);
				DrawOptionsText(pWindow, 2, 130, T_StartNewGame);
				DrawOptionsText(pWindow, 3, 110, T_Highscore);
				DrawOptionsText(pWindow, 4, 90, T_Options);
				DrawOptionsText(pWindow, 5, 70, T_Help);
				DrawOptionsText(pWindow, 6, 50, T_Credits);
				DrawOptionsText(pWindow, 7, 30, T_Quit);
			break;

			case 1: // Are you sure question:
				pWindow->PrintAnimated(400, 290, M_AreYouSure, 0, 2.2f, fFontAni, 1);
				DrawOptionsText(pWindow, 8, 250, T_Yes);
				DrawOptionsText(pWindow, 9, 230, T_No);
			break;

			case 3: // Options:
				pWindow->PrintAnimated(400, 290, T_Options, 0, 2.2f, fFontAni, 1);
				DrawOptionsText(pWindow, 10, 250, T_KeysSetup);
				DrawOptionsText(pWindow, 11, 230, T_OtherOptions);
			break;

			case 4: // Keys setup:
				pWindow->PrintAnimated(400, 340, T_KeysSetup, 0, 2.2f, fFontAni, 1);
				DrawKeysSetupText(pWindow, 12, 300, T_Thrust, AS_DXInputKeys[_ASConfig->iThrustKey[1]].byName);
				DrawKeysSetupText(pWindow, 13, 285, T_Left, AS_DXInputKeys[_ASConfig->iLeftKey[1]].byName);
				DrawKeysSetupText(pWindow, 14, 270, T_Right, AS_DXInputKeys[_ASConfig->iRightKey[1]].byName);
				DrawKeysSetupText(pWindow, 15, 255, T_Up, AS_DXInputKeys[_ASConfig->iUpKey[1]].byName);
				DrawKeysSetupText(pWindow, 16, 240, T_Down, AS_DXInputKeys[_ASConfig->iDownKey[1]].byName);
				DrawKeysSetupText(pWindow, 17, 225, T_IncreaseTerrain, AS_DXInputKeys[_ASConfig->iIncreaseTerrainKey[1]].byName);
				DrawKeysSetupText(pWindow, 18, 210, T_DecreaseTerrain, AS_DXInputKeys[_ASConfig->iDecreaseTerrainKey[1]].byName);
				DrawKeysSetupText(pWindow, 19, 195, T_StrongIncreaseTerrain, AS_DXInputKeys[_ASConfig->iStrongIncreaseTerrainKey[1]].byName);
				DrawKeysSetupText(pWindow, 20, 180, T_StrongDecreaseTerrain, AS_DXInputKeys[_ASConfig->iStrongDecreaseTerrainKey[1]].byName);
				DrawKeysSetupText(pWindow, 21, 165, T_StandartView, AS_DXInputKeys[_ASConfig->iStandartViewKey[1]].byName);
				DrawKeysSetupText(pWindow, 22, 150, T_Pause, AS_DXInputKeys[_ASConfig->iPauseKey[1]].byName);
				DrawKeysSetupText(pWindow, 23, 135, T_Hud, AS_DXInputKeys[_ASConfig->iHudKey[1]].byName);
				DrawKeysSetupText(pWindow, 24, 120, T_NextMusic, AS_DXInputKeys[_ASConfig->iNextMusicKey[1]].byName);
				DrawOptionsText(pWindow, 25, 100, T_StandartConfiguration);
				if(bGetNewKey && bPressNewKeyText)
				{
					glColor3f(1.0f, 1.0f, 1.0f);	
					pWindow->Print(400, 5, T_PressNewKey, 0, 1);
				}
			break;
		}
	}
	if(bGetPlayerName && bPressNewKeyText)
	{
		glEnable(GL_TEXTURE_2D);
		glColor3f(1.0f, 1.0f, 1.0f);	
		pWindow->Print(400, 5, T_EnterName, 0, 1);
	}
	glEnable(GL_DEPTH_TEST);
} // end ShowGameMenu()

void CheckGameMenu(void)
{ // begin CheckGameMenu()
	float fYAcceleration;
	char byTemp[256];
	int i;

	// Check mouse input:
	if((CHECK_KEY(ASMouse.byButtons, 0) && ASMouse.byButtonFirst[0]))
		ASKeyFirst[DIK_SPACE] = TRUE;
	if((CHECK_KEY(ASMouse.byButtons, 1) && ASMouse.byButtonFirst[1]))
		ASKeyFirst[DIK_ESCAPE] = TRUE;
	if(!bShowCredits)
	{
		fYAcceleration = (ASMouse.lY*_ASConfig->fMouseSensibility)*((float) g_lDeltatime/2000);
		if(fYAcceleration > 0.04f)
			ASKeyFirst[DIK_DOWN] = TRUE;
		if(fYAcceleration < -0.04f)
			ASKeyFirst[DIK_UP] = TRUE;
	}
	//
	CheckTitel();
	_ASCamera->Check();
	_ASCamera->fRot2Velocity[Z] += (float) g_lDeltatime/1000;
	ParticleManager.Check();
	Level.Check();
	if(_ASCamera->fRot2Velocity[Z] > 1.0f)
		_ASCamera->fRot2Velocity[Z] = 1.0f;
	
	if(bShowHighscore)
	{ // We are in the highscore menu:
		fGeneralGameMenuBlend -= 0.001f*g_lDeltatime;
		if(fGeneralGameMenuBlend < 0.0f)
			fGeneralGameMenuBlend = 0.0f;
		fHighscoreBlend += (float) g_lDeltatime/1000;
		if(fHighscoreBlend > 1.0f)
			fHighscoreBlend = 1.0f;
		if(!bPlayerEnteringHighScore)
		{ // Check if the 'any key' is pressed:
			for(i = 0; i < 256; i++)
			{
				if(i == AS_SCREENSHOT_KEY)
					continue;
				if(ASKeyFirst[i])
				{
					ASPlayFmodSample(pMenuBackSample, FSOUND_LOOP_OFF);
					bShowHighscore = FALSE;
					byGameMenuMenu = 0;
					break;
				}
			}
		}
		else
		{ // The player gives in his name
			CheckHighscore();
		}
		return;
	}
	else
	{
		fHighscoreBlend -= (float) g_lDeltatime/1000;
		if(fHighscoreBlend < 0.0f)
		{
			bPlayerEnteringHighScore = FALSE;
			fHighscoreBlend = 0.0f;
		}
	}
	
	if(bShowCredits)
	{ // We are in the credits menu:
		fGeneralGameMenuBlend -= 0.001f*g_lDeltatime;
		if(fGeneralGameMenuBlend < 0.0f)
			fGeneralGameMenuBlend = 0.0f;
		fCreditsBackgroundBlend += 0.001f*g_lDeltatime;
		if(fCreditsBackgroundBlend > 1.0f)
			fCreditsBackgroundBlend = 1.0f;
		if(bBlendIn)
		{
			fCreditsBlend += 0.001f*g_lDeltatime;
			if(fCreditsBlend > 1.0f)
			{
				fCreditsBlend = 1.0f;
				bBlendIn = FALSE;
				bCreditsWaiting = TRUE;
				lCreditsNext = g_lNow+5000;
			}
		}
		if(bBlendOut)
		{
			fCreditsBlend -= 0.001f*g_lDeltatime;
			if(fCreditsBlend < 0.0f)
			{
				bBlendOut = FALSE;
				fCreditsBlend = 0.0f;

				// Go to the next text:
				bBlendIn = TRUE;
				iCreditsStep++;
				if(iCreditsStep > 8)
					iCreditsStep = 0;
			}
		}
		if(bCreditsWaiting)
		{
			if(g_lNow > lCreditsNext)
			{
				bCreditsWaiting = FALSE;
				bBlendOut = TRUE;
			}
		}
		
		// Check if the 'any key' is pressed:
		for(i = 0; i < 256; i++)
		{
			if(i == AS_SCREENSHOT_KEY)
				continue;
			if(ASKeyFirst[i])
			{
				ASPlayFmodSample(pMenuBackSample, FSOUND_LOOP_OFF);
				StartGameMusic();
				bShowCredits = FALSE;
				break;
			}
		}

		return;
	}
	else
	{
		fCreditsBackgroundBlend -= 0.001f*g_lDeltatime;
		if(fCreditsBackgroundBlend < 0.0f)
			fCreditsBackgroundBlend = 0.0f;
	}

	if(!bShowHighscore && !bShowCredits)
	{
		fGeneralGameMenuBlend += 0.001f*g_lDeltatime;
		if(fGeneralGameMenuBlend > 1.0f)
			fGeneralGameMenuBlend = 1.0f;
	}

	if(g_lNow-lPressNewKeyTimer > 500)
	{
		lPressNewKeyTimer = g_lNow;
		bPressNewKeyText = !bPressNewKeyText;
	}
	if(!bGetPlayerName && !bGetNewKey)
	{
		if(ASKeyFirst[DIK_UP])
		{
			byGameMenuSelected--;
			ASPlayFmodSample(pMenuSelectSample, FSOUND_LOOP_OFF);
		}
		if(ASKeyFirst[DIK_DOWN])
		{
			byGameMenuSelected++;
			ASPlayFmodSample(pMenuSelectSample, FSOUND_LOOP_OFF);
		}
	}
	switch(byGameMenuMenu)
	{
		case 0: // Main menu:
			if(byGameMenuSelected < 0)
				byGameMenuSelected = 7;
			else
				if(byGameMenuSelected >= 8)
					byGameMenuSelected = 0;
			switch(byGameMenuSelected)
			{
				case 0: MenuPoint[0].bSelected = TRUE; break;
				case 1: MenuPoint[1].bSelected = TRUE; break;
				case 2: MenuPoint[2].bSelected = TRUE; break;
				case 3: MenuPoint[3].bSelected = TRUE; break;
				case 4: MenuPoint[4].bSelected = TRUE; break;
				case 5: MenuPoint[5].bSelected = TRUE; break;
				case 6: MenuPoint[6].bSelected = TRUE; break;
				case 7: MenuPoint[7].bSelected = TRUE; break;
			}
			if(ASKeyFirst[DIK_ESCAPE])
			{
				ASPlayFmodSample(pMenuBackSample, FSOUND_LOOP_OFF);
				if(!bShowGameMenu)
					_AS->SetShutDown(TRUE);
				else
					bShowGameMenu = bPause = FALSE;
			}
			if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
			{ // Check what the player has selected:
				ASPlayFmodSample(pMenuSelectionSample, FSOUND_LOOP_OFF);
				switch(byGameMenuSelected)
				{
					case 0: // Continue game:
						bPause = bShowGameMenu = FALSE;
					break;

					case 1: // Level restart:
						byLastGameMenuMenu = byGameMenuMenu;
						byGameMenuMenu = 1;
						byGameMenuSelectedTemp = byGameMenuSelected;
						byGameMenuSelected = 0;
						bAreYouSureQuestion = TRUE;
						bAreYouSureQuestionAnswer = FALSE;
					break;

					case 2: // New game:						
						byLastGameMenuMenu = byGameMenuMenu;
						byGameMenuMenu = 1;
						byGameMenuSelectedTemp = byGameMenuSelected;
						byGameMenuSelected = 0;
						bAreYouSureQuestion = TRUE;
						bAreYouSureQuestionAnswer = FALSE;
					break;

					case 3: // Highscore:
						bShowHighscore = TRUE;
					break;

					case 4: // Options:
						byGameMenuMenu = 3;
						byGameMenuSelected = 0;
					break;

					case 5: // Help:
						OpenHelp();
					break;

					case 6: // Credits:
						CreditsGameMusic();
						bShowCredits = TRUE;
						iCreditsStep = 0;
						fCreditsBlend = fCreditsBackgroundBlend = 0.0f;
						bBlendIn = TRUE;
						bBlendOut = FALSE;
						bCreditsWaiting = FALSE;
					break;

					case 7: // Quit:
						byLastGameMenuMenu = byGameMenuMenu;
						byGameMenuMenu = 1;
						byGameMenuSelectedTemp = byGameMenuSelected;
						byGameMenuSelected = 0;
						bAreYouSureQuestion = TRUE;
						bAreYouSureQuestionAnswer = FALSE;
					break;
				}
			}
		break;

		case 1: // Are you sure question:
			if(byGameMenuSelected < 0)
				byGameMenuSelected = 1;
			else
				if(byGameMenuSelected >= 2)
					byGameMenuSelected = 0;
			switch(byGameMenuSelected)
			{
				case 0: MenuPoint[8].bSelected = TRUE; break;
				case 1: MenuPoint[9].bSelected = TRUE; break;
			}
			if(ASKeyFirst[DIK_ESCAPE])
			{
				ASPlayFmodSample(pMenuBackSample, FSOUND_LOOP_OFF);
				bAreYouSureQuestionAnswer = FALSE;
				byGameMenuSelected = 0;
				byGameMenuMenu = byLastGameMenuMenu;
			}
			if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
			{
				ASPlayFmodSample(pMenuSelectionSample, FSOUND_LOOP_OFF);
				if(!byGameMenuSelected)
				{
					switch(byLastGameMenuMenu)
					{
						case 0:
							switch(byGameMenuSelectedTemp)
							{
								case 1: LevelRestart(); break;
								case 2: StartNewGame(); break;
								case 7:	_AS->SetShutDown(TRUE); break;
							}
						break;
						
						case 4:
							switch(byGameMenuSelectedTemp)
							{
								case 13:
									_ASConfig->iThrustKey[0] = STANDART_THRUST_KEY;
									_ASConfig->iLeftKey[0] = STANDART_LEFT_KEY;
									_ASConfig->iRightKey[0] = STANDART_RIGHT_KEY;
									_ASConfig->iUpKey[0] = STANDART_UP_KEY;
									_ASConfig->iDownKey[0] = STANDART_DOWN_KEY;
									_ASConfig->iIncreaseTerrainKey[0] = STANDART_INCREASE_TERRAIN_KEY;
									_ASConfig->iDecreaseTerrainKey[0] = STANDART_DECREASE_TERRAIN_KEY;
									_ASConfig->iStrongIncreaseTerrainKey[0] = STANDART_STRONG_INCREASE_TERRAIN_KEY;
									_ASConfig->iStrongDecreaseTerrainKey[0] = STANDART_STRONG_DECREASE_TERRAIN_KEY;
									_ASConfig->iStandartViewKey[0] = STANDART_STANDART_VIEW_KEY;
									_ASConfig->iPauseKey[0] = STANDART_PAUSE_KEY;
									_ASConfig->iHudKey[0] = STANDART_HUD_KEY;
									_ASConfig->iNextMusicKey[0] = STANDART_NEXT_MUSIC_KEY;
									_ASConfig->Check();
								break;
							}
						break;
					}
					bAreYouSureQuestionAnswer = TRUE;
				}
				else
					bAreYouSureQuestionAnswer = FALSE;
				byGameMenuSelected = 0;
				byGameMenuMenu = byLastGameMenuMenu;
			}
		break;

		case 3: // Options:
			if(byGameMenuSelected < 0)
				byGameMenuSelected = 1;
			else
				if(byGameMenuSelected >= 2)
					byGameMenuSelected = 0;
			switch(byGameMenuSelected)
			{
				case 0: MenuPoint[10].bSelected = TRUE; break;
				case 1: MenuPoint[11].bSelected = TRUE; break;
			}
			if(ASKeyFirst[DIK_ESCAPE])
			{
				ASPlayFmodSample(pMenuBackSample, FSOUND_LOOP_OFF);
				byGameMenuSelected = 0;
				byGameMenuMenu = 0;
				
				// Save the configuration:	
				sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyConfigFile);
				_ASConfig->Save(byTemp);
				break;
			}
			if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
			{ // Check what the player has selected:
				ASPlayFmodSample(pMenuSelectionSample, FSOUND_LOOP_OFF);
				ASKeyFirst[DIK_SPACE] = ASKeyFirst[DIK_RETURN] = FALSE;
				switch(byGameMenuSelected)
				{
					case 0: // Setup keys
						byGameMenuSelected = 0;
						byGameMenuMenu = 4;
						bGetNewKey = FALSE;
					break;

					case 1: // Other options
						SendMessage(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), WM_COMMAND, ID_OPTIONS_CONFIG, 0);
					break;
				}
			}
		break;

		case 4: // Setup keys:
			if(byGameMenuSelected < 0)
				byGameMenuSelected = 13;
			else
				if(byGameMenuSelected >= 14)
					byGameMenuSelected = 0;
			switch(byGameMenuSelected)
			{
				case 0: MenuPoint[12].bSelected = TRUE; break;
				case 1: MenuPoint[13].bSelected = TRUE; break;
				case 2: MenuPoint[14].bSelected = TRUE; break;
				case 3: MenuPoint[15].bSelected = TRUE; break;
				case 4: MenuPoint[16].bSelected = TRUE; break;
				case 5: MenuPoint[17].bSelected = TRUE; break;
				case 6: MenuPoint[18].bSelected = TRUE; break;
				case 7: MenuPoint[19].bSelected = TRUE; break;
				case 8: MenuPoint[20].bSelected = TRUE; break;
				case 9: MenuPoint[21].bSelected = TRUE; break;
				case 10: MenuPoint[22].bSelected = TRUE; break;
				case 11: MenuPoint[23].bSelected = TRUE; break;
				case 12: MenuPoint[24].bSelected = TRUE; break;
				case 13: MenuPoint[25].bSelected = TRUE; break;
			}
			if(ASKeyFirst[DIK_ESCAPE])
			{
				ASPlayFmodSample(pMenuBackSample, FSOUND_LOOP_OFF);
				if(bGetNewKey)
					bGetNewKey = FALSE;
				else
				{
					byGameMenuSelected = 0;
					byGameMenuMenu = 3;
				}
				break;
			}
			if(bGetNewKey)
			{
				for(i = 0; i < 256; i++)
				{
					if(!ASKeyFirst[i])
						continue;
					ASPlayFmodSample(pMenuSelectSample, FSOUND_LOOP_OFF);
					// Set the new key:
					switch(byGameMenuSelected)
					{
						case 0: _ASConfig->iThrustKey[0] = i; break;
						case 1: _ASConfig->iLeftKey[0] = i; break;
						case 2: _ASConfig->iRightKey[0] = i; break;
						case 3: _ASConfig->iUpKey[0] = i; break;
						case 4: _ASConfig->iDownKey[0] = i; break;
						case 5: _ASConfig->iIncreaseTerrainKey[0] = i; break;
						case 6: _ASConfig->iDecreaseTerrainKey[0] = i; break;
						case 7: _ASConfig->iStrongIncreaseTerrainKey[0] = i; break;
						case 8: _ASConfig->iStrongDecreaseTerrainKey[0] = i; break;
						case 9: _ASConfig->iStandartViewKey[0] = i; break;
						case 10: _ASConfig->iPauseKey[0] = i; break;
						case 11: _ASConfig->iHudKey[0] = i; break;
						case 12: _ASConfig->iNextMusicKey[0] = i; break;
					}
					bGetNewKey = FALSE;
					_ASConfig->Check();
					break;
				}
			}
			else
			{
				if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
				{ // Check what the player has selected:
					if(byGameMenuSelected == 13)
					{ // Set all key to standart:
						ASPlayFmodSample(pMenuSelectionSample, FSOUND_LOOP_OFF);
						byLastGameMenuMenu = byGameMenuMenu;
						byGameMenuMenu = 1;
						byGameMenuSelectedTemp = byGameMenuSelected;
						byGameMenuSelected = 0;
						bAreYouSureQuestion = TRUE;
						bAreYouSureQuestionAnswer = FALSE;
					}
					else // Get the new key:
					{
						ASPlayFmodSample(pMenuSelectSample, FSOUND_LOOP_OFF);
						bGetNewKey = TRUE;
					}
				}
			}
		break;
	}
} // end CheckGameMenu()

void AnimateFont(void)
{ // begin AnimateFont()
	for(int i = 0; i < 4; i++)
		for(int i2 = 0; i2 < 2; i2++)
		{
			fFontAni[i][i2] += fFontAniV[i][i2]*((float) g_lDeltatime/800);
			if(fFontAniLast[i][i2] >= fFontAniT[i][i2])
			{
				fFontAniV[i][i2] -= ((float) g_lDeltatime/200);
				if(fFontAniV[i][i2] < -1.2f)
					fFontAniV[i][i2] = -1.2f;
				if(fFontAni[i][i2] <= fFontAniT[i][i2])
				{
					fFontAniLast[i][i2] = fFontAni[i][i2];
					if(!(rand() % 2))
						fFontAniT[i][i2] = ((float) (rand() % 10)/8);
					else
						fFontAniT[i][i2] = -((float) (rand() % 10)/8);
				}
			}
			if(fFontAniLast[i][i2] < fFontAniT[i][i2])
			{
				fFontAniV[i][i2] += ((float) g_lDeltatime/200);
				if(fFontAniV[i][i2] > 1.2f)
					fFontAniV[i][i2] = 1.2f;
				if(fFontAni[i][i2] >= fFontAniT[i][i2])
				{
					fFontAniLast[i][i2] = fFontAni[i][i2];
					if(!(rand() % 2))
						fFontAniT[i][i2] = ((float) (rand() % 10)/8);
					else
						fFontAniT[i][i2] = -((float) (rand() % 10)/8);
				}
			}
		}
} // end AnimateFont()

void DrawMenuBackground(float fLeft, float fTop, float fRight, float fBottom,
						FLOAT3 fColor, float fDensity)
{ // begin DrawMenuBackground()
	glDisable(GL_CULL_FACE);
	glBegin(GL_QUADS);
		glVertex2f(fLeft, fTop);
		glVertex2f(fRight, fTop);
		glVertex2f(fRight, fBottom);
		glVertex2f(fLeft, fBottom);
	glEnd();

	// Create a smooth bounding:
	glBegin(GL_QUADS);
		// Left:
		glColor4f(fColor[R], fColor[G], fColor[B], fDensity);
		glVertex2f(fRight, fBottom);
		glVertex2f(fRight, fTop);
		glColor4f(fColor[R], fColor[G], fColor[B], 1.0f);
		glVertex2f(fRight+0.5f, fTop-0.5f);
		glVertex2f(fRight+0.5f, fBottom+0.5f);

		// Top:
		glColor4f(fColor[R], fColor[G], fColor[B], fDensity);
		glVertex2f(fLeft, fBottom);
		glVertex2f(fRight, fBottom);
		glColor4f(fColor[R], fColor[G], fColor[B], 1.0f);
		glVertex2f(fRight+0.5f, fBottom+0.5f);
		glVertex2f(fLeft-0.5f, fBottom+0.5f);

		// Right:
		glColor4f(fColor[R], fColor[G], fColor[B], 1.0f);
		glVertex2f(fLeft-0.5f, fTop-0.5f);
		glVertex2f(fLeft-0.5f, fBottom+0.5f);
		glColor4f(fColor[R], fColor[G], fColor[B], fDensity);
		glVertex2f(fLeft, fBottom);
		glVertex2f(fLeft, fTop);

		// Bottom:
		glColor4f(fColor[R], fColor[G], fColor[B], fDensity);
		glVertex2f(fLeft, fTop);
		glVertex2f(fRight, fTop);
		glColor4f(fColor[R], fColor[G], fColor[B], 1.0f);
		glVertex2f(fRight+0.5f, fTop-0.5f);
		glVertex2f(fLeft-0.5f, fTop-0.5f);

	glEnd();
	glEnable(GL_CULL_FACE);
} // end DrawMenuBackground()

void InitTitel(void)
{ // begin InitTitel()
	fCurrentTitelLensRadius = 21.0f;
	fNextTitelLensRadius = 0.01f;
	fTitelLensRadiusVelocity = 0.0f;
	fCurrentTitelLensEffect = -10.0f;
	fNextTitelLensEffect = -2.0f;
	fTitelLensEffectVelocity = 0.0f;

	fCurrentTitelLensPos[X] = 0.0f;
	fNextTitelLensPos[X] = 0.0f;
	fTitelLensPosVelocity[X] = 0.0f;
	fCurrentTitelLensPos[Y] = 0.0f;
	fNextTitelLensPos[Y] = 0.0f;
	fTitelLensPosVelocity[Y] = 0.0f;
} // end InitTitel()

void DrawTitel(void)
{ // begin DrawTitel()
	int iX, iY;
	
	// Draw the grid:
	glLoadIdentity();
	glRotatef(180.0f, 0.0f, 0.0f, 1.0f);
	glTranslatef(10.0f, -15.0f, -50.0f);
	glRotatef(180.0f, 0.0f, 1.0f, 0.0f);

	glDisable(GL_CULL_FACE);
	glDisable(GL_DEPTH_TEST);
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glDisable(GL_FOG);
	glDisable(GL_LIGHTING);
	glBindTexture(GL_TEXTURE_2D, GameTexture[19].iOpenGLID);
	glColor4f(1.0f, 1.0f, 1.0f, fGameMenuBlend);
	glEnableClientState(GL_VERTEX_ARRAY);
	glVertexPointer(3, GL_FLOAT, 0, fTitelGridPoint);
	glBegin(GL_TRIANGLES);
		for(iY = 0; iY < TITEL_GRID_Y_SIZE-1; iY++)
		{
			for(iX = 1; iX < TITEL_GRID_X_SIZE-1; iX++)
			{
				// Draw the first triangle of the quad:
				glTexCoord2f((float) (iX-1)/(TITEL_GRID_X_SIZE-2), (float) iY/(TITEL_GRID_Y_SIZE-1));
				glArrayElement((iX-1)+iY*TITEL_GRID_X_SIZE);
				glTexCoord2f((float) iX/(TITEL_GRID_X_SIZE-2), (float) iY/(TITEL_GRID_Y_SIZE-1));
				glArrayElement(iX+iY*TITEL_GRID_X_SIZE);
				glTexCoord2f((float) iX/(TITEL_GRID_X_SIZE-2), (float) (iY+1)/(TITEL_GRID_Y_SIZE-1));
				glArrayElement(iX+(iY+1)*TITEL_GRID_X_SIZE);


				// Draw the second triangle of the quad:
				glTexCoord2f((float) iX/(TITEL_GRID_X_SIZE-2), (float) (iY+1)/(TITEL_GRID_Y_SIZE-1));
				glArrayElement(iX+(iY+1)*TITEL_GRID_X_SIZE);
				glTexCoord2f((float) (iX-1)/(TITEL_GRID_X_SIZE-2), (float) (iY+1)/(TITEL_GRID_Y_SIZE-1));
				glArrayElement((iX-1)+(iY+1)*TITEL_GRID_X_SIZE);
				glTexCoord2f((float) (iX-1)/(TITEL_GRID_X_SIZE-2), (float) iY/(TITEL_GRID_Y_SIZE-1));
				glArrayElement((iX-1)+iY*TITEL_GRID_X_SIZE);
			}
		}
	glEnd();
	glDisableClientState(GL_VERTEX_ARRAY);
	glEnable(GL_BLEND);
} // end DrawTitel()

void CheckTitel(void)
{ // begin CheckTitel()
	float fAngle, fR;
	int iX, iY;

	if(fCurrentTitelLensPos[X] > fNextTitelLensPos[X])
	{
		fCurrentTitelLensPos[X] += (float) g_lDeltatime/1000*fTitelLensPosVelocity[X];
		fTitelLensPosVelocity[X] -= (float) g_lDeltatime/1000;
		if(fTitelLensPosVelocity[X] < -1.0f)
			fTitelLensPosVelocity[X] = -1.0f;
		if(fCurrentTitelLensPos[X] <= fNextTitelLensPos[X])
			fNextTitelLensPos[X] = (rand() % TITEL_GRID_X_SIZE*100)/100.0f;
	}
	else
	{
		fCurrentTitelLensPos[X] += (float) g_lDeltatime/1000*fTitelLensPosVelocity[X];
		fTitelLensPosVelocity[X] += (float) g_lDeltatime/1000;
		if(fTitelLensPosVelocity[X] > 1.0f)
			fTitelLensPosVelocity[X] = 1.0f;
		if(fCurrentTitelLensPos[X] >= fNextTitelLensPos[X])
			fNextTitelLensPos[X] = (rand() % TITEL_GRID_X_SIZE*100)/100.0f;
	}
	if(fCurrentTitelLensPos[Y] > fNextTitelLensPos[Y])
	{
		fCurrentTitelLensPos[Y] += (float) g_lDeltatime/1000*fTitelLensPosVelocity[Y];
		fTitelLensPosVelocity[Y] -= (float) g_lDeltatime/1000;
		if(fTitelLensPosVelocity[Y] < -1.0f)
			fTitelLensPosVelocity[Y] = -1.0f;
		if(fCurrentTitelLensPos[Y] <= fNextTitelLensPos[Y])
			fNextTitelLensPos[Y] = (rand() % TITEL_GRID_Y_SIZE*100)/100.0f;
	}
	else
	{
		fCurrentTitelLensPos[Y] += (float) g_lDeltatime/1000*fTitelLensPosVelocity[Y];
		fTitelLensPosVelocity[Y] += (float) g_lDeltatime/1000;
		if(fTitelLensPosVelocity[Y] > 1.0f)
			fTitelLensPosVelocity[Y] = 1.0f;
		if(fCurrentTitelLensPos[Y] >= fNextTitelLensPos[Y])
			fNextTitelLensPos[Y] = (rand() % TITEL_GRID_Y_SIZE*100)/100.0f;
	}

	if(fCurrentTitelLensEffect > fNextTitelLensEffect)
	{
		fCurrentTitelLensEffect += (float) g_lDeltatime/1000*fTitelLensEffectVelocity;
		fTitelLensEffectVelocity -= (float) g_lDeltatime/1000;
		if(fCurrentTitelLensEffect <= fNextTitelLensEffect)
		{
			if(!(rand() % 2))
				fNextTitelLensEffect = (rand() % 60)/100.0f;
			else
				fNextTitelLensEffect = -(rand() % 60)/100.0f;
		}
	}
	else
	{
		fCurrentTitelLensEffect += (float) g_lDeltatime/1000*fTitelLensEffectVelocity;
		fTitelLensEffectVelocity += (float) g_lDeltatime/1000;
		if(fCurrentTitelLensEffect >= fNextTitelLensEffect)
		{
			if(!(rand() % 2))
				fNextTitelLensEffect = (rand() % 60)/100.0f;
			else
				fNextTitelLensEffect = -(rand() % 60)/100.0f;
		}
	}
	if(fCurrentTitelLensRadius > fNextTitelLensRadius)
	{
		fCurrentTitelLensRadius += (float) g_lDeltatime/1000*fTitelLensRadiusVelocity;
		fTitelLensRadiusVelocity -= (float) g_lDeltatime/1000;
		if(fCurrentTitelLensRadius <= fNextTitelLensRadius)
		{
			fTitelLensRadiusVelocity *= 0.02f;
			fNextTitelLensRadius = 1.0f+(rand() % 2000)/100.0f;
		}
	}
	else
	{
		fCurrentTitelLensRadius += (float) g_lDeltatime/1000*fTitelLensRadiusVelocity;
		fTitelLensRadiusVelocity += (float) g_lDeltatime/1000;
		if(fCurrentTitelLensRadius >= fNextTitelLensRadius)
		{
			fTitelLensRadiusVelocity *= 0.02f;
			fNextTitelLensRadius = 1.0f+(rand() % 2000)/100.0f;
		}
	}

	// Setup the grid:
	for(iY = 0; iY < TITEL_GRID_Y_SIZE; iY++)
	{
		for(iX = 0; iX < TITEL_GRID_X_SIZE; iX++)
		{
			// Get the radius of the current point;
			fR = (float) sqrt((iX-fCurrentTitelLensPos[X])*(iX-fCurrentTitelLensPos[X])+
							  (iY-fCurrentTitelLensPos[Y])*(iY-fCurrentTitelLensPos[Y]));
			  
			// Get the angle at that point:
			fAngle = (float) atan2((iX-fCurrentTitelLensPos[X]), (iY-fCurrentTitelLensPos[Y]));

			// If we're inside the unit circle:
			if(fR < fCurrentTitelLensRadius)
				fR = (float) (fCurrentTitelLensRadius*exp(log(fR/fCurrentTitelLensRadius)*fCurrentTitelLensEffect));

			// Finally set the coordinates:
			fTitelGridPoint[iX+iY*TITEL_GRID_X_SIZE][X] = (float) (iX+(fR*sin(fAngle)));
			fTitelGridPoint[iX+iY*TITEL_GRID_X_SIZE][Y] = (float) (iY+(fR*cos(fAngle)));
		}
	}
} // end CheckTitel()

HRESULT LoadHighscore(void)
{ // begin LoadHighscore()
	FILE *pFile = NULL;
	char byTemp[256];
	
	sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyHighscoreFile);
	pFile = fopen(byTemp, "r");
	if(!pFile)
		return 1;
	fread(Highscore, sizeof(HIGHSCORE), MAX_HIGHSCORES, pFile);
	fclose(pFile);
	return 0;
} // end LoadHighscore()

HRESULT SaveHighscore(void)
{ // begin SaveHighscore()
	FILE *pFile = NULL;
	char byTemp[256];
	
	sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyHighscoreFile);
	pFile = fopen(byTemp, "w");
	if(!pFile)
		return 0;
	fwrite(Highscore, sizeof(HIGHSCORE), MAX_HIGHSCORES, pFile);
	fclose(pFile);
	return 0;
} // end SaveHighscore()

void DrawHighscore(AS_WINDOW *pWindow)
{ // begin DrawHighscore()
	char byTemp[256];
	int i, y;

	glColor4f(1.0f, 1.0f, 1.0f, fHighscoreBlend);
	if(bGameWon)
	{
		if(Player.iScore >= 6000)
		{ // 10000 points? Ok, show him the cheats:
			pWindow->PrintAnimated(400, 520, M_YouHaveWonTheGame, 0, 2.2f, fFontAni, 1);
			pWindow->PrintAnimated(400, 500, M_YouCouldfindCheatsOnTheAblazeSpace, 0, 1.2f, fFontAni, 1);
			pWindow->PrintAnimated(400, 480, M_HomepageUnderTheAblazeBallFeatures, 0, 1.2f, fFontAni, 1);
		}
		else
			pWindow->PrintAnimated(400, 500, M_YouHaveWonTheGame, 0, 2.2f, fFontAni, 1);
	}
	if(!bPlayerEnteringHighScore)
		pWindow->PrintAnimated(400, 350, T_Highscore, 0, 3.2f, fFontAni, 1);
	else
	{ // The player enters or not his name into the highscore:
		if(byPlayersHScorePlace != -2)
		{
			pWindow->PrintAnimated(400, 380, T_Congratulations, 0, 1.2f, fFontAni, 1);
			pWindow->PrintAnimated(400, 360, M_YouAreInTheHighscore, 0, 1.2f, fFontAni, 1);
			pWindow->PrintAnimated(400, 340, M_EnterYourNameAndHitEnterWhenDone, 0, 1.2f, fFontAni, 1);
		}
		else // He's a looser:
		{
			pWindow->PrintAnimated(400, 380, M_YouLooser, 0, 1.2f, fFontAni, 1);
			pWindow->PrintAnimated(400, 360, M_YouAreNotInTheHighscore, 0, 1.2f, fFontAni, 1);
			pWindow->PrintAnimated(400, 340, M_PressAnyKeyToContinue, 0, 1.2f, fFontAni, 1);
		}
	}
	pWindow->PrintAnimated(100, 310, T_Place, 0, 1.7f, fFontAni, 1);
	pWindow->PrintAnimated(400, 310, T_Name, 0, 1.7f, fFontAni, 1);
	pWindow->PrintAnimated(680, 310, T_Score, 0, 1.7f, fFontAni, 1);
	for(i = 0, y = 290; i < MAX_HIGHSCORES; i++, y -= 20)
	{
		// Setup:
		if(byPlayersHScorePlace != i || byPlayersHScorePlace == -1 ||  byPlayersHScorePlace == -2 ||
		   !bPlayerEnteringHighScore)
		{
			glColor4f(1.0f, 1.0f, 1.0f, fHighscoreBlend);
			sprintf(byTemp, "%s", Highscore[i].byName);
		}
		else
		{
			glColor4f(1.0f, 0.0f, 0.0f, fHighscoreBlend);
			if((((g_lNow-g_lProgramStartTime) / 500)) % 2 ||
			   strlen(Highscore[byPlayersHScorePlace].byName) >= 39)
				sprintf(byTemp, "%s", Highscore[i].byName);
			else
				sprintf(byTemp, "%s_", Highscore[i].byName);
		}
		
		// Name:
		pWindow->PrintAnimated(400, y, byTemp, 0, 1.2f, fFontAni, 1);

		// Pos:
		sprintf(byTemp, "%d.", i+1);
		pWindow->PrintAnimated(100, y, byTemp, 0, 1.2f, fFontAni, 1);
		
		// Score:
		sprintf(byTemp, "%d",  Highscore[i].iScore);
		pWindow->PrintAnimated(680, y, byTemp, 0, 1.2f, fFontAni, 1);
	}
} // end DrawHighscore()

void CheckHighscore(void)
{ // begin CheckHighscore()
	int i, i2;
	USHORT iKey;

	if(byPlayersHScorePlace == -1)
	{ // Check if the player is in the highscore and which place he have:
		for(i = 0; i < MAX_HIGHSCORES; i++)
		{
			if(Player.iScore >= Highscore[i].iScore)
			{ // The player is better as someone:
				// Make place for the new king:
				for(i2 = MAX_HIGHSCORES-1; i2 >= i; i2--)
				{
					Highscore[i2].iScore = Highscore[i2-1].iScore;
					strcpy(Highscore[i2].byName, Highscore[i2-1].byName);
				}
				Highscore[i].iScore = Player.iScore;
				byPlayersHScorePlace = i;
				memset(Highscore[i].byName, 0, 50);
				for(i2 = 0; i2 < 30; i2++)
				{
					Highscore[i].byName[i2] = _AS->pbyUserName[i2];
					if(_AS->pbyUserName[i2] == '\0')
						break;
				}
				break;
			}
		}
		if(byPlayersHScorePlace == -1 || byPlayersHScorePlace == 9)
		{ // The player is a looser:
			ASPlayFmodSample(pLooserSample, FSOUND_LOOP_OFF);
			if(byPlayersHScorePlace == -1)
				byPlayersHScorePlace = -2;
		}
		if(!byPlayersHScorePlace) // Wow, he's on the top!
		{
			ASPlayFmodSample(pTopSample, FSOUND_LOOP_OFF);
			ASPlayFmodSample(pWinnerSample, FSOUND_LOOP_NORMAL);
		}
		else
			if(byPlayersHScorePlace != -2)
				ASPlayFmodSample(pWinnerSample, FSOUND_LOOP_OFF);
	}
	if(byPlayersHScorePlace == -2)
	{ // The player is a looser:
		// Check if the 'any key' is pressed:
		for(i = 0; i < 256; i++)
		{
			if(i == AS_SCREENSHOT_KEY)
				continue;
			if(ASKeyFirst[i])
			{
				ASPlayFmodSample(pMenuBackSample, FSOUND_LOOP_OFF);
				bShowHighscore = FALSE;
				if(bGameWon)
					ShowEndCredits();
				else
					StartGameMusic();
				LevelRestart();
				break;
			}
		}
		return;
	}
	if(ASKeyFirst[DIK_RETURN] || ASKeyFirst[DIK_ESCAPE])
	{ // Close The Hightscore Menu:
		ASStopFmodSample(pWinnerSample);
		ASPlayFmodSample(pMenuBackSample, FSOUND_LOOP_OFF);
		bShowHighscore = FALSE;
		SaveHighscore();
		if(bGameWon)
			ShowEndCredits();
		else
			StartGameMusic();
		LevelRestart();
		return;
	}
	if(ASKeyFirst[DIK_BACK] && strlen(Highscore[byPlayersHScorePlace].byName) > 0)
		Highscore[byPlayersHScorePlace].byName[strlen(Highscore[byPlayersHScorePlace].byName)-1] = '\0';
	else 
	if(strlen(Highscore[byPlayersHScorePlace].byName) < 39)
	{			
		for(i = 0; i < 256; i++) 
		{
			if(i == DIK_BACK)
				continue;
			if(ASKeyFirst[i])
			{
				ConvertScancodeToASCII(i, &iKey);
				sprintf(Highscore[byPlayersHScorePlace].byName, "%s%c", Highscore[byPlayersHScorePlace].byName, iKey);
				break;
			}
		}
	}
} // end CheckHighscore()

void InitMenuPoints(void)
{ // begin InitMenuPoints()
	int i, i2;
	
	for(i = 0; i < MENU_POINTS; i++)
	{
		MenuPoint[i].fSize = 1.0f;
		for(i2 = 0; i2 < 3; i2++)
			MenuPoint[i].fColor[i2] = 1.0f;
	}
} // end InitMenuPoints()

void CheckMenuPoints(void)
{ // begin CheckMenuPoints()
	int i2;
	
	for(int i = 0; i < MENU_POINTS; i++)
	{
		if(MenuPoint[i].bSelected)
		{
			for(i2 = 1; i2 < 3; i2++)
			{
				if(MenuPoint[i].fColor[i2] > 0.0f)
				{
					MenuPoint[i].fColor[i2] -= (float) g_lDeltatime/200;
					if(MenuPoint[i].fColor[i2] < 0.0f)
						MenuPoint[i].fColor[i2] = 0.0f;
				}
			}
			if(!MenuPoint[i].bSize)
			{
				MenuPoint[i].fSize += (float) g_lDeltatime/3000;
				if(MenuPoint[i].fSize > 1.0f)
				{
					MenuPoint[i].fSize = 1.0f;
					MenuPoint[i].bSize = TRUE;
				}
			}
			else
			{
				MenuPoint[i].fSize -= (float) g_lDeltatime/3000;
				if(MenuPoint[i].fSize < 0.8f)
				{
					MenuPoint[i].fSize = 0.8f;
					MenuPoint[i].bSize = FALSE;
				}
			}
		}
		else
		{
			for(i2 = 1; i2 < 3; i2++)
			{
				if(MenuPoint[i].fColor[i2] < 1.0f)
				{
					MenuPoint[i].fColor[i2] += (float) g_lDeltatime/200;
					if(MenuPoint[i].fColor[i2] > 1.0f)
						MenuPoint[i].fColor[i2] = 1.0f;
				}
			}
			if(MenuPoint[i].fSize > 1.0f)
			{
				MenuPoint[i].fSize -= (float) g_lDeltatime/3000;
				if(MenuPoint[i].fSize < 1.0f)
					MenuPoint[i].fSize = 1.0f;
			}
			if(MenuPoint[i].fSize < 1.0f)
			{
				MenuPoint[i].fSize += (float) g_lDeltatime/3000;
				if(MenuPoint[i].fSize > 1.0f)
					MenuPoint[i].fSize = 1.0f;
			}
		}
		MenuPoint[i].bSelected = FALSE;
	}
} // end CheckMenuPoints() 

void ShowEndCredits(void)
{ // begin ShowEndCredits()
	// Show the credits:
	StopMusic();
	strcpy(byCurrentMusic, "Newbegin.s3m");
	iCurrentSelectedMusic = -1;
	StartCurrentMusic();
	bShowCredits = TRUE;
	iCreditsStep = 0;
	fCreditsBlend = fCreditsBackgroundBlend = 0.0f;
	bBlendIn = TRUE;
	bBlendOut = FALSE;
	bCreditsWaiting = FALSE;
} // end ShowEndCredits()
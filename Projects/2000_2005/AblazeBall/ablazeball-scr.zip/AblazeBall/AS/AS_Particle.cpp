//-----------------------------------------------------------------------------
// File: AS_Particle.cpp
//-----------------------------------------------------------------------------

#include "AS_Engine.h"


// Functions: *****************************************************************
void ASParticleSystemDraw_Standart(AS_PARTICLE_SYSTEM *);
void ASParticleSystemDraw_WaterWaves(AS_PARTICLE_SYSTEM *);
void ASParticleSystemDraw_Ablaze(AS_PARTICLE_SYSTEM *);
void ASParticleSystemCheck_ASLogo(AS_PARTICLE_SYSTEM *);
void ASParticleSystemCheck_Ablaze(AS_PARTICLE_SYSTEM *);
void ASParticleSystemCheck_WaterWaves(AS_PARTICLE_SYSTEM *);
void ASParticleSystemCheck_Bubbles(AS_PARTICLE_SYSTEM *);
void ASParticleSystemCheck_AblazeSpace(AS_PARTICLE_SYSTEM *);
void ASParticleSystemCheck_WaterStream(AS_PARTICLE_SYSTEM *);
void ASParticleSystemCheck_AblazeTrace(AS_PARTICLE_SYSTEM *);
void ASParticleSystemCheck_Ablaze(AS_PARTICLE_SYSTEM *);
///////////////////////////////////////////////////////////////////////////////


//////////          AS_PARTICLE_SYSTEM          ///////////////////////////////

int AS_PARTICLE_SYSTEM::GetFreeParticle(void)
{ // begin AS_PARTICLE_SYSTEM::GetFreeParticle()
	for(int i = 0; i < iParticles; i++)
		if(!pParticle[i].bAlive)
			return i;
	return -1;
} // end AS_PARTICLE_SYSTEM::GetFreeParticle()


//////////          AS_PARTICLE_MANAGER          //////////////////////////////

void AS_PARTICLE_MANAGER::Check(void)
{ // begin AS_PARTICLE_MANAGER::Check()
	if(!_ASConfig->bParticles)
		return;
	for(int i = 0; i < iSystems; i++)
	{
		if(!pSystem[i].Check)
			continue;
		pSystem[i].Check(&pSystem[i]);
	}
} // end AS_PARTICLE_MANAGER::Check()

void AS_PARTICLE_MANAGER::Draw(void)
{ // begin AS_PARTICLE_MANAGER::Drawk()
	if(!_ASConfig->bParticles)
		return;
	glEnable(GL_BLEND);
	glDisable(GL_CULL_FACE);
	glDisable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);
	glDepthMask(FALSE);
	glEnable(GL_DEPTH_TEST);

	for(int i = 0; i < iSystems; i++)
	{
		if(!pSystem[i].Check)
			continue;
		glPushMatrix();
		pSystem[i].Draw(&pSystem[i]);
		glPopMatrix();
	}

	ASEnableLighting();
	glDepthMask(TRUE);
	glDisable(GL_BLEND);
	glEnable(GL_CULL_FACE);
} // end AS_PARTICLE_MANAGER::Draw()

int AS_PARTICLE_MANAGER::AddNewSystem(AS_PARTICLE_SYSTEM_TYPE Type, int iParticles, void *pActor, AS_TEXTURE *pTexture, AS_TEXTURE *pSourceTexture)
{ // begin AS_PARTICLE_MANAGER::AddNewSystem()
	AS_PARTICLE_SYSTEM *pSystemT;
	AS_PARTICLE *pParticleT;
	int i, i2, x, y;
	BYTE *pbyData;

	// Add the new system:
	iSystems++;
	pSystem = (AS_PARTICLE_SYSTEM *) realloc(pSystem, sizeof(AS_PARTICLE_SYSTEM)*iSystems);

	pSystemT = &pSystem[iSystems-1];
	memset(pSystemT, 0, sizeof(AS_PARTICLE_SYSTEM));
	
	// Setup the system:		
	pSystemT->iID = iSystems-1;
	pSystemT->pActor = pActor;
	pSystemT->pTexture = pTexture;
	pSystemT->Type = Type;
	pSystemT->iMaxParticles = iParticles;
	if(pSystemT->Type == PS_ASLogo)
		pSystemT->iParticles = pSystemT->iMaxParticles;
	else
	{
		pSystemT->iParticles = (int) (pSystemT->iMaxParticles*_ASConfig->fParticleDensity);
		if(!pSystemT->iParticles)
			pSystemT->iParticles = 1;
	}
	pSystemT->pParticle = (AS_PARTICLE *) malloc(sizeof(AS_PARTICLE)*pSystemT->iParticles);
	memset(pSystemT->pParticle, 0, sizeof(AS_PARTICLE)*pSystemT->iParticles);

	switch(pSystemT->Type)
	{
		case PS_ASLogo:
			for(i = 0, i2 = 0, x = 0, y = 0; i < pSystemT->iParticles; i++, i2 += 3, x++)
			{
				if(x >= pSourceTexture->iWidth)
				{
					y++;
					x = 0;
				}
				pbyData = pSourceTexture->pbyData;
				if(!pbyData[i2] && !pbyData[i2+1] && !pbyData[i2])
					continue;
				pParticleT = &pSystemT->pParticle[i];
				memset(pParticleT, 0, sizeof(AS_PARTICLE));
				pParticleT->fPos[X] = pParticleT->fLastPos[X] = pParticleT->fFixPos[X] = (float) x;
				pParticleT->fPos[Y] = pParticleT->fLastPos[Y] = pParticleT->fFixPos[Y] = (float) y;
				pParticleT->fColor[0] = (float) pbyData[i2]/255;
				pParticleT->fColor[1] = (float) pbyData[i2+1]/255;
				pParticleT->fColor[2] = (float) pbyData[i2+2]/255;
				pParticleT->bAlive = TRUE;
				pParticleT->fSize = 8.0f+((float) (rand() % 300)/100);
				pParticleT->bTemp[0] = rand() % 2;
			}
			pSystemT->Check = ASParticleSystemCheck_ASLogo;
			pSystemT->Draw = ASParticleSystemDraw_Standart;
			pSystemT->lTimeDelay = pSystemT->lMaxRandomDelay = 1;
			pSystemT->lLiveStartTime = g_lNow;
		break;

		case PS_WaterWaves:
			pSystemT->Check = ASParticleSystemCheck_WaterWaves;
			pSystemT->Draw = ASParticleSystemDraw_WaterWaves;

			pSystemT->lTimeDelay = pSystemT->lMaxRandomDelay = 30;
			pSystemT->lLiveStartTime = g_lNow;
			pSystemT->lLiveEndTime = -1;
		break;

		case PS_WaterBubbles:
			pSystemT->Check = ASParticleSystemCheck_Bubbles;
			pSystemT->Draw = ASParticleSystemDraw_Standart;

			pSystemT->bRandomDelay = FALSE;
			pSystemT->lTimeDelay = pSystemT->lMaxRandomDelay = 1;
			pSystemT->lLiveStartTime = g_lNow;
			pSystemT->lLiveEndTime = g_lNow+500;
		break;

		case PS_AblazeSpace:
			pSystemT->Check = ASParticleSystemCheck_AblazeSpace;
			pSystemT->Draw = ASParticleSystemDraw_Standart;

			pSystemT->bRandomDelay = TRUE;
			pSystemT->lTimeDelay = pSystemT->lMaxRandomDelay = 10;
			pSystemT->lLiveStartTime = g_lNow;
			pSystemT->lLiveEndTime = g_lNow+500;
		break;

		case PS_WaterStream:
			pSystemT->Check = ASParticleSystemCheck_WaterStream;
			pSystemT->Draw = ASParticleSystemDraw_Standart;

			pSystemT->bRandomDelay = TRUE;
			pSystemT->lTimeDelay = pSystemT->lMaxRandomDelay = 10;
			pSystemT->lLiveStartTime = g_lNow;
			pSystemT->lLiveEndTime = g_lNow+500;
		break;

		case PS_AblazeTrace:
			pSystemT->Check = ASParticleSystemCheck_AblazeTrace;
			pSystemT->Draw = ASParticleSystemDraw_Standart;

			pSystemT->bRandomDelay = TRUE;
			pSystemT->lTimeDelay = pSystemT->lMaxRandomDelay = 10;
			pSystemT->lLiveStartTime = g_lNow;
			pSystemT->lLiveEndTime = g_lNow+500;
		break;
		
		case PS_Ablaze:
			pSystemT->Check = ASParticleSystemCheck_Ablaze;
			pSystemT->Draw = ASParticleSystemDraw_Ablaze;
		break;
	}
	return iSystems-1;
} // end AS_PARTICLE_MANAGER::AddNewSystem()

void AS_PARTICLE_MANAGER::DeleteSystem(int iID)
{ // begin AS_PARTICLE_MANAGER::DeleteSystem()
	// Destroy the system:
	SAFE_DELETE(pSystem[iID].pParticle);

	// Update all systems:
	for(int i = iID; i < iSystems-1; i++)
	{
		memcpy(&pSystem[i], &pSystem[i+1], sizeof(AS_PARTICLE_SYSTEM));
		pSystem[i].iID--;
	}

	// Romove the last system:
	iSystems--;
	pSystem = (AS_PARTICLE_SYSTEM *) realloc(pSystem, sizeof(AS_PARTICLE_SYSTEM)*iSystems);
} // end AS_PARTICLE_MANAGER::DeleteSystem()

void AS_PARTICLE_MANAGER::Destroy(void)
{ // begin AS_PARTICLE_MANAGER::Destroy()
	for(int i = 0; i < iSystems; i++)
		SAFE_DELETE(pSystem[i].pParticle);
	SAFE_DELETE(pSystem);
	memset(this, 0, sizeof(AS_PARTICLE_MANAGER));
} // end AS_PARTICLE_MANAGER::Destroy()

void AS_PARTICLE_MANAGER::UpdateSystems(void)
{ // begin AS_PARTICLE_MANAGER::UpdateSystems()
	AS_PARTICLE_SYSTEM *pSystemT;
	int i, i2, iTemp;

	for(i = 0; i < iSystems; i++)
	{
		pSystemT = &pSystem[i];
		iTemp = pSystemT->iParticles;
		pSystemT->iParticles = (int) (pSystemT->iMaxParticles*_ASConfig->fParticleDensity);
		if(!pSystemT->iParticles)
			pSystemT->iParticles = 1;
		pSystemT->pParticle = (AS_PARTICLE *) realloc(pSystemT->pParticle, sizeof(AS_PARTICLE)*pSystemT->iParticles);
		for(i2 = iTemp; i2 < pSystemT->iParticles; i2++)
			memset(&pSystemT->pParticle[i2], 0, sizeof(AS_PARTICLE));
	}
} // end AS_PARTICLE_MANAGER::UpdateSystems()


//////////          Types of partcile systems        //////////////////////////

void ASParticleSystemDraw_Standart(AS_PARTICLE_SYSTEM *pSystemT)
{ // begin ASParticleSystemDraw_Standart)
	AS_PARTICLE *pParticleT;
	int i;

	if(!pSystemT->bActive)
		return;

	switch(pSystemT->Type)
	{
		case PS_WaterBubbles: case PS_AblazeSpace: case PS_WaterStream: case PS_AblazeTrace: break;

		default:
			if((pSystemT->Type != PS_ASLogo && pSystemT->Type != PS_WaterBubbles && pSystemT->Type != PS_AblazeSpace && !pSystemT->pActor) || pSystemT->iVertex < 0)
				return;
		break;
	}

	if(pSystemT->pTexture)
		glBindTexture(GL_TEXTURE_2D, pSystemT->pTexture->iOpenGLID);

	FLOAT3 tl, tr, bl, br;
	FLOAT3 tlT, trT, blT, brT;
	FLOAT3 ptl, ptr, pbl, pbr;
	FLOAT3 x, y;
	float m[16];

	// Get the billboard information: (The particle looks always into the camera)
	glGetFloatv(GL_MODELVIEW_MATRIX, m);
	x[0] = m[0];
	x[1] = m[4];
	x[2] = m[8];
	y[0] = m[1];
	y[1] = m[5];
	y[2] = m[9];
	ASSubVec(x, y, &tl);
	ASAddVec(x, y, &tr);
	ASInvertVec(x, &x);
	ASSubVec(x, y, &bl);
	ASAddVec(x, y, &br);
	ASScaleVec(tl, 0.2f, &tl);
	ASScaleVec(tr, 0.2f, &tr);
	ASScaleVec(bl, 0.2f, &bl);
	ASScaleVec(br, 0.2f, &br);

	float fX, fY, fWidth, fHeight;
	int iX, iY;

	fX = fY = 0.0f;
	fWidth = fHeight = 1.0f;

	glBegin(GL_QUADS);
		for(i = 0; i < pSystemT->iParticles; i++)
		{
			pParticleT = &pSystemT->pParticle[i];

			if(!pParticleT->bAlive)
				continue;

  			// Get animation information:
			if(pSystemT->bAnimatedParticles)
			{
				iY = (int) pParticleT->iAnimationStep/pSystemT->iAnimationColumns;
				iX = pParticleT->iAnimationStep-iY*pSystemT->iAnimationColumns;
				fWidth = (float) pSystemT->iTextureWidth/pSystemT->iAnimationColumns/pSystemT->iTextureWidth;
				fHeight = (float) pSystemT->iTextureWidth/pSystemT->iAnimationRows/pSystemT->iTextureHeight;
				fX = fWidth*iX;
				fY = fHeight*iY;
			}

			// Draw the particle:
			glColor4f(pParticleT->fColor[0], pParticleT->fColor[1], pParticleT->fColor[2], pParticleT->fEngine);

			ASScaleVec(tl, pParticleT->fSize, &tlT);
			ASScaleVec(tr, pParticleT->fSize, &trT);
			ASScaleVec(bl, pParticleT->fSize, &blT);
			ASScaleVec(br, pParticleT->fSize, &brT);

			ASAddVec(pParticleT->fPos, tlT, &ptl);
			ASAddVec(pParticleT->fPos, trT, &ptr);
			ASAddVec(pParticleT->fPos, blT, &pbl);
			ASAddVec(pParticleT->fPos, brT, &pbr);

			glTexCoord2f(fX, fY+fHeight);
			glVertex3fv(ptl);

			glTexCoord2f(fX+fWidth, fY+fHeight);
			glVertex3fv(ptr);

			glTexCoord2f(fX+fWidth, fY);
			glVertex3fv(pbr);

			glTexCoord2f(fX, fY);
			glVertex3fv(pbl);
		}
	glEnd();
} // end ASParticleSystemDraw_Standart()

void ASParticleSystemDraw_WaterWaves(AS_PARTICLE_SYSTEM *pSystemT)
{ // begin ASParticleSystemDraw_WaterWaves)
	AS_PARTICLE *pParticleT;
	int i;

	if(!pSystemT->bActive)
		return;
	if(pSystemT->pTexture)
		glBindTexture(GL_TEXTURE_2D, pSystemT->pTexture->iOpenGLID);

	for(i = 0; i < pSystemT->iParticles; i++)
	{
		pParticleT = &pSystemT->pParticle[i];

		if(!pParticleT->bAlive)
			continue;

		// Draw the particle:
		glColor4f(pParticleT->fColor[0], pParticleT->fColor[1], pParticleT->fColor[2], pParticleT->fEngine/10);

		glPushMatrix();
		glTranslatef(pParticleT->fPos[X], pParticleT->fPos[Y], pParticleT->fPos[Z]);
		glScalef(pParticleT->fSize, pParticleT->fSize, pParticleT->fSize);

		glBegin(GL_QUADS);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(-0.5f, -0.5f, 0.0f);

			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(0.5f, -0.5f, 0.0f);

			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(0.5f, 0.5f, 0.0f);

			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(-0.5f, 0.5f, 0.0f);
		glEnd();
		
		glPopMatrix();
	}
} // end ASParticleSystemDraw_WaterWaves()

void ASParticleSystemDraw_Ablaze(AS_PARTICLE_SYSTEM *pSystemT)
{ // begin ASParticleSystemDraw_Ablaze)
	AS_PARTICLE *pParticleT;
	short i;

/*	if(!ASCubeInFrustum(Environment.fAblazeBox[MIN][X], Environment.fAblazeBox[MIN][Y], Environment.fAblazeBox[MIN][Z],
						Environment.fAblazeBox[MAX][X], Environment.fAblazeBox[MAX][Z], Environment.fAblazeBox[MAX][Z]))
		return; // The ablaze is not visible!*/
	if(!pSystemT->bActive)
		return;

	if(pSystemT->pTexture)
		glBindTexture(GL_TEXTURE_2D, pSystemT->pTexture->iOpenGLID);

	glTranslatef(pSystemT->fStartPos[X], pSystemT->fStartPos[Y], pSystemT->fStartPos[Z]);

	FLOAT3 tl, tr, bl, br;
	FLOAT3 tlT, trT, blT, brT;
	FLOAT3 ptl, ptr, pbl, pbr;
	FLOAT3 x, y;
	float m[16];

	// Get the billboard information: (The particle looks always into the camera)
	glGetFloatv(GL_MODELVIEW_MATRIX, m);
	x[0] = m[0];
	x[1] = m[4];
	x[2] = m[8];
	y[0] = m[1];
	y[1] = m[5];
	y[2] = m[9];
	ASSubVec(x, y, &tl);
	ASAddVec(x, y, &tr);
	ASInvertVec(x, &x);
	ASSubVec(x, y, &bl);
	ASAddVec(x, y, &br);
	ASScaleVec(tl, 0.2f, &tl);
	ASScaleVec(tr, 0.2f, &tr);
	ASScaleVec(bl, 0.2f, &bl);
	ASScaleVec(br, 0.2f, &br);

	glBegin(GL_QUADS);
		for(i = 0; i < pSystemT->iParticles; i++)
		{
			pParticleT = &pSystemT->pParticle[i];

			if(!pParticleT->bAlive)
				continue;
			// Draw the particle:
			glColor4f(pParticleT->fColor[0], pParticleT->fColor[1], pParticleT->fColor[2], pParticleT->fEngine);
			ASScaleVec(tl, pParticleT->fSize, &tlT);
			ASScaleVec(tr, pParticleT->fSize, &trT);
			ASScaleVec(bl, pParticleT->fSize, &blT);
			ASScaleVec(br, pParticleT->fSize, &brT);

			ASAddVec(pParticleT->fPos, tlT, &ptl);
			ASAddVec(pParticleT->fPos, trT, &ptr);
			pbl[0] = pbl[1] = pbl[2] = 0.0f;
			ASAddVec(pParticleT->fPos, blT, &pbl);
			ASAddVec(pParticleT->fPos, brT, &pbr);

			glTexCoord2f(0.0f, 1.0f);
			glVertex3fv(ptl);

			glTexCoord2f(1.0f, 1.0f);
			glVertex3fv(ptr);

			glTexCoord2f(1.0f, 0.0f);
			glVertex3fv(pbr);

			glTexCoord2f(0.0f, 0.0f);
			glVertex3fv(pbl);
		}
	glEnd();
} // end ASParticleSystemDraw_Ablaze()

void ASParticleSystemCheck_ASLogo(AS_PARTICLE_SYSTEM *pSystemT)
{ // begin ASParticleSystemCheck_ASLogo()
	AS_PARTICLE *pParticleT;
	ACTOR *pActorT;
	float fTime;
	int i, i2;

	if(!pSystemT->bActive)
		return;
	pActorT = (ACTOR *) pSystemT->pActor;

	if(pSystemT->bGoingInActive)
	{
		for(i = 0; i < pSystemT->iParticles; i++)
		{
			if(pSystemT->pParticle[i].bAlive)
				break;
		}
		if(i >= pSystemT->iParticles)
		{ // Destroy this system:
   			pSystemT->bActive = FALSE;
			return;
		}
	}
	fTime = (float) g_lDeltatime/1000;
	// Check each particle:
	for(i = 0; i < pSystemT->iParticles; i++)
	{
		pParticleT = &pSystemT->pParticle[i];

		if(!pParticleT->bAlive)
			continue;
		// Animate this particle:
		if(g_lNow-pParticleT->lLastAnimtationTime > pParticleT->iAnimationSpeed*(1/pParticleT->fEngine))
		{
			pParticleT->lLastAnimtationTime = g_lNow;
			pParticleT->iAnimationStep++;
			if(pParticleT->iAnimationStep >= pSystemT->iAnimationColumns*pSystemT->iAnimationRows)
				pParticleT->iAnimationStep = 0;
		}
		if(!pSystemT->bGoingInActive)
		{
			if(pParticleT->fEngine != 1.0f)
			{
				pParticleT->fEngine += (float) g_lDeltatime/10000;
				if(pParticleT->fEngine > 1.0f)
					pParticleT->fEngine = 1.0f;
			}
		}
		else
		{
			pParticleT->fEngine -= (float) g_lDeltatime/20000;
			if(pParticleT->fEngine < 0.0f)
				pParticleT->bAlive = FALSE;
		}
		if(!pParticleT->bTemp[0])
		{
			pParticleT->fSize += (float) g_lDeltatime/1000;
			if(pParticleT->fSize > 8.0f)
				pParticleT->bTemp[0] = TRUE;
		}
		else
		{
			pParticleT->fSize -= (float) g_lDeltatime/1000;
			if(pParticleT->fSize < 5.0f)
				pParticleT->bTemp[0] = FALSE;
		}
		if(!pSystemT->bTemp)
			continue;
		for(i2 = 0; i2 < 3; i2++)
		{
			if(pParticleT->fPos[i2] > pParticleT->fLastPos[i2])
			{
				pParticleT->fVelocity[i2] -= (float) g_lDeltatime/10000;
				if(!pParticleT->bTemp[i2])
				{
					if(pParticleT->fPos[i2]+pParticleT->fVelocity[i2]*((float) g_lDeltatime/100) 
					  < pParticleT->fLastPos[i2])
					{
						pParticleT->bTemp[i2] = TRUE;
						pParticleT->fVelocity[i2] = 0.0f;
					}
				}
			}
			else
			if(pParticleT->fPos[i2] < pParticleT->fLastPos[i2])
			{
				pParticleT->fVelocity[i2] += (float) g_lDeltatime/10000;
				if(!pParticleT->bTemp[i2])
				{
					if(pParticleT->fPos[i2]+pParticleT->fVelocity[i2]*((float) g_lDeltatime/100) 
					  > pParticleT->fLastPos[i2])
					{
						pParticleT->bTemp[i2] = TRUE;
						pParticleT->fVelocity[i2] = 0.0f;
					}
				}
			}

			if(pParticleT->fVelocity[i2] > 1.5f)
				pParticleT->fVelocity[i2] = 1.5f;
			if(pParticleT->fVelocity[i2] < -1.5f)
				pParticleT->fVelocity[i2] = -1.5f;

			pParticleT->fPos[i2] += pParticleT->fVelocity[i2]*((float) g_lDeltatime/100);

			if((pParticleT->fPos[i2] <= pParticleT->fLastPos[i2]+1.0f &&
			    pParticleT->fPos[i2] >= pParticleT->fLastPos[i2]-1.0f) ||
				pParticleT->fPos[i2] >= pParticleT->fFixPos[i2]+0.3f ||
				pParticleT->fPos[i2] <= pParticleT->fFixPos[i2]-0.3f)
			{
				if(pParticleT->fLastPos[i2] != pParticleT->fFixPos[i2] && !pSystemT->bGoingInActive)
					pParticleT->fVelocity[i2] *= 0.2f;
				if((pParticleT->fPos[i2] > pParticleT->fFixPos[i2]+0.3f ||
				    pParticleT->fPos[i2] < pParticleT->fFixPos[i2]-0.3f) &&
					!pSystemT->bGoingInActive)
				   pParticleT->fLastPos[i2] = pParticleT->fFixPos[i2];
				else
				{
					if(!(rand() % 2))
						pParticleT->fLastPos[i2] += (float) 10+(rand() % 1000)/100;
					else
						pParticleT->fLastPos[i2] -= (float) 10+(rand() % 1000)/100;
				}
			}
		}
	}
} // end ASParticleSystemCheck_ASLogo()

void ASParticleSystemCheck_WaterWaves(AS_PARTICLE_SYSTEM *pSystemT)
{ // begin ASParticleSystemCheck_WaterWaves()
	AS_PARTICLE *pParticleT;
	ACTOR *pActorT;
	int i;

	if(!pSystemT->bActive)
		return;
	pActorT = (ACTOR *) pSystemT->pActor;
	// Check each particle:
	for(i = 0; i < pSystemT->iParticles; i++)
	{
		pParticleT = &pSystemT->pParticle[i];

		if(!pParticleT->bAlive)
			continue;
		
		// Check the particle:
		pParticleT->fPos[Z] = Level.fCurrentWaterHeight;
		pParticleT->fEngine -= (float) pParticleT->fFadeSpeed*g_lDeltatime/10.0f;
		pParticleT->fSize += (float) pParticleT->fFadeSpeed*g_lDeltatime/3.0f;
		if(pParticleT->fEngine <= 0.0f)
		{ // The particle is now 'death':
			pParticleT->bAlive = FALSE;
			continue;
		}
	}
} // end ASParticleSystemCheck_WaterWaves()

void ASParticleSystemCheck_Bubbles(AS_PARTICLE_SYSTEM *pSystemT)
{ // begin ASParticleSystemCheck_Bubbles()
	AS_PARTICLE *pParticleT;
	ACTOR *pActorT;
	int i, i2;
	float fTime;

	if(!pSystemT->bActive)
		return;
	pActorT = (ACTOR *) pSystemT->pActor;

	// Check the system:
	if(pSystemT->bGoingInActive)
	{
		for(i = 0; i < pSystemT->iParticles; i++)
		{
			if(pSystemT->pParticle[i].bAlive)
				break;
		}
	}
	else
	if(g_lNow > pSystemT->lNextTime)
	{ // The system should be updated:
		if(pSystemT->bRandomDelay)
		{ // Get the time do the next update per random:
			pSystemT->lTimeDelay = rand() % pSystemT->lMaxRandomDelay;
		}
		pSystemT->lTimeDelay = 100;
		pSystemT->lLastTime = g_lNow;
		pSystemT->lNextTime = pSystemT->lLastTime+pSystemT->lTimeDelay;
	}

	fTime = (float) g_lDeltatime/1000;
	// Check each particle:
	for(i = 0; i < pSystemT->iParticles; i++)
	{
		pParticleT = &pSystemT->pParticle[i];

		if(!pParticleT->bAlive)
			continue;
		// Check if the bubble is still under water:
		if(pParticleT->fPos[Z] < (Level.fCurrentWaterHeight+0.5))
		{
			pParticleT->fEngine -= (float) pParticleT->fFadeSpeed*g_lDeltatime;
			if(pParticleT->fEngine <= 0.0f)
			{ // The particle is now 'death':
				pParticleT->bAlive = FALSE;
				continue;
			}
			pParticleT->fSize = 0.3f/pParticleT->fEngine;
			pParticleT->fColor[0] = 1/pParticleT->fEngine;
			pParticleT->fColor[1] = 1/pParticleT->fEngine;
			pParticleT->fColor[2] = 1/pParticleT->fEngine;
		}
		//
		for(i2 = 0; i2 < 3; i2++)
			if(!pParticleT->fVelocity[i2])
				pParticleT->fVelocity[i2] = -0.001f;
		pParticleT->fVelocity[X] -= pParticleT->fVelocity[X]*fTime;
		pParticleT->fVelocity[Y] -= pParticleT->fVelocity[Y]*fTime;
		pParticleT->fVelocity[Z] += pParticleT->fVelocity[Z]*fTime;
		pParticleT->fPos[X] += pParticleT->fVelocity[X]*fTime;
		pParticleT->fPos[Y] += pParticleT->fVelocity[Y]*fTime;
		pParticleT->fPos[Z] += pParticleT->fVelocity[Z]*fTime;
	}
} // end ASParticleSystemCheck_Bubble()

void ASParticleSystemCheck_AblazeSpace(AS_PARTICLE_SYSTEM *pSystemT)
{ // begin ASParticleSystemCheck_AblazeSpace()
	AS_PARTICLE *pParticleT;
	ACTOR *pActorT;
	int i, i2;
	float fTime;

	if(!pSystemT->bActive)
		return;
	pActorT = (ACTOR *) pSystemT->pActor;

	// Check the system:
	if(pSystemT->bGoingInActive)
	{
		for(i = 0; i < pSystemT->iParticles; i++)
		{
			if(pSystemT->pParticle[i].bAlive)
				break;
		}
	}
	else
	if(g_lNow > pSystemT->lNextTime)
	{ // The system should be updated:
		if(pSystemT->bRandomDelay)
		{ // Get the time do the next update per random:
			pSystemT->lTimeDelay = rand() % pSystemT->lMaxRandomDelay;
		}
		pSystemT->lLastTime = g_lNow;
		pSystemT->lNextTime = pSystemT->lLastTime+pSystemT->lTimeDelay;

		i = pSystemT->GetFreeParticle();
		if(i != -1)
		{
			pParticleT = &pSystemT->pParticle[i];
			memset(pParticleT, 0, sizeof(AS_PARTICLE));
			pParticleT->bAlive = TRUE;
			pParticleT->fEngine = (float) 1.0f;
			pParticleT->fColor[0] = 1.0f;
			pParticleT->fColor[1] = 0.7f;
			pParticleT->fColor[2] = 0.2f;
			pParticleT->fFadeSpeed = 0.0001f+(rand() % 1000)/10000;
			pParticleT->fSize = 0.2f+(rand() % 100)/50;
			pParticleT->fAngle = (float) 0.5f+(rand() % 3600)/10;
			pParticleT->fRadius = 1.0f+(rand() % 100)/100;
			pParticleT->fFixPos[X] = Level.fWidth/2-0.5f;
			pParticleT->fFixPos[Y] = Level.fHeight/2-0.5f;
			pParticleT->fPos[X] = (float) (pParticleT->fFixPos[X]+cos(pParticleT->fAngle)*pParticleT->fRadius);
			pParticleT->fPos[Y] = (float) (pParticleT->fFixPos[Y]+sin(pParticleT->fAngle)*pParticleT->fRadius);
			pParticleT->fPos[Z] = pParticleT->fFixPos[Z] = Level.fMiddleHeight-3.0f;
			for(i = 0; i < 2; i++)
			{
				if(!(rand() % 2))
					pParticleT->fVelocity[i] = (float) 0.01f+(rand() % 1000)/800;
				else
					pParticleT->fVelocity[i] = (float) -(0.01f+(rand() % 1000)/800);
			}
			if(!(rand() % 2))
				pParticleT->fAngleSpeed = (float) (rand() % 1000)/200;
			else
				pParticleT->fAngleSpeed = (float) -(rand() % 1000)/200;
			if(Player.pActor->bGoingDeath)
			{
				pParticleT->fVelocity[Z] = (float) -(0.01f+(rand() % 1000)/400);
				pParticleT->fAngleSpeed += 10;
				pParticleT->fColor[1] = 0.1f;
				pParticleT->fColor[2] = 0.1f;
				pParticleT->fEngine = 3.0f;
			}
			else
				pParticleT->fVelocity[Z] = (float) -(0.01f+(rand() % 1000)/800);
			pParticleT->iAnimationSpeed = 20+(rand() % 20);
		}
	}

	fTime = (float) g_lDeltatime/1000;
	// Check each particle:
	for(i = 0; i < pSystemT->iParticles; i++)
	{
		pParticleT = &pSystemT->pParticle[i];

		if(!pParticleT->bAlive)
			continue;
		
		// Animate this particle:
		if(g_lNow-pParticleT->lLastAnimtationTime > pParticleT->iAnimationSpeed*(1/pParticleT->fEngine))
		{
			pParticleT->lLastAnimtationTime = g_lNow;
			pParticleT->iAnimationStep++;
			if(pParticleT->iAnimationStep >= pSystemT->iAnimationColumns*pSystemT->iAnimationRows)
				pParticleT->iAnimationStep = 0;
		}

		// Check if the bubble is still under water:
		pParticleT->fEngine -= (float) pParticleT->fFadeSpeed*g_lDeltatime;
		if(pParticleT->fEngine <= 0.0f)
		{ // The particle is now 'death':
			pParticleT->bAlive = FALSE;
			continue;
		}

		pParticleT->fSize = 2*pParticleT->fEngine;

		for(i2 = 0; i2 < 3; i2++)
			if(!pParticleT->fVelocity[i2])
				pParticleT->fVelocity[i2] = -0.001f;
		pParticleT->fVelocity[X] -= pParticleT->fVelocity[X]*fTime;
		pParticleT->fVelocity[Y] -= pParticleT->fVelocity[Y]*fTime;
		pParticleT->fVelocity[Z] += pParticleT->fVelocity[Z]*fTime;
		pParticleT->fAngle += pParticleT->fAngleSpeed*fTime;

		pParticleT->fPos[X] = (float) (pParticleT->fFixPos[X]+cos(pParticleT->fAngle)*pParticleT->fRadius);
		pParticleT->fPos[Y] = (float) (pParticleT->fFixPos[Y]+sin(pParticleT->fAngle)*pParticleT->fRadius);
		pParticleT->fPos[Z] = pParticleT->fFixPos[Z];

		pParticleT->fFixPos[X] += pParticleT->fVelocity[X]*fTime;
		pParticleT->fFixPos[Y] += pParticleT->fVelocity[Y]*fTime;
		pParticleT->fFixPos[Z] += pParticleT->fVelocity[Z]*fTime;

		if(pParticleT->fPos[Z] < Level.fHighestPoint-30.0f)
			pParticleT->bAlive = FALSE;
	}
} // end ASParticleSystemCheck_AblazeSpace()

void ASParticleSystemCheck_WaterStream(AS_PARTICLE_SYSTEM *pSystemT)
{ // begin ASParticleSystemCheck_WaterStream()
	AS_PARTICLE *pParticleT;
	ACTOR *pActorT;
	int i, i2;
	float fTime;

	if(!pSystemT->bActive)
		return;
	pActorT = (ACTOR *) pSystemT->pActor;

	// Check the system:
	if(pSystemT->bGoingInActive)
	{
		for(i = 0; i < pSystemT->iParticles; i++)
		{
			if(pSystemT->pParticle[i].bAlive)
				break;
		}
	}
	else
	if(g_lNow > pSystemT->lNextTime)
	{ // The system should be updated:
		if(pSystemT->bRandomDelay)
		{ // Get the time do the next update per random:
			pSystemT->lTimeDelay = rand() % pSystemT->lMaxRandomDelay;
		}
		pSystemT->lLastTime = g_lNow;
		pSystemT->lNextTime = pSystemT->lLastTime+pSystemT->lTimeDelay;
	}

	fTime = (float) g_lDeltatime/1000;
	// Check each particle:
	for(i = 0; i < pSystemT->iParticles; i++)
	{
		pParticleT = &pSystemT->pParticle[i];

		if(!pParticleT->bAlive)
			continue;
		// Check if the bubble is still under water:
		pParticleT->fEngine -= (float) pParticleT->fFadeSpeed*g_lDeltatime;
		if(pParticleT->fEngine <= 0.0f)
		{ // The particle is now 'death':
			pParticleT->bAlive = FALSE;
			continue;
		}

		if(pParticleT->fEngine > 0.5f)
		{
			pParticleT->fColor[0] = (1.0f-pParticleT->fEngine)*2;
			pParticleT->fColor[1] = (1.0f-pParticleT->fEngine)*2;
			pParticleT->fColor[2] = (1.0f-pParticleT->fEngine)*2;
		}
		else
		{
			pParticleT->fColor[0] = pParticleT->fEngine*2;
			pParticleT->fColor[1] = pParticleT->fEngine*2;
			pParticleT->fColor[2] = pParticleT->fEngine*2;
		}
		//
		// Animate this particle:
		if(!pParticleT->iAnimationSpeed)
			pParticleT->iAnimationSpeed = 20+(rand() % 50);
		if(g_lNow-pParticleT->lLastAnimtationTime > pParticleT->iAnimationSpeed*(1/pParticleT->fEngine))
		{
			pParticleT->lLastAnimtationTime = g_lNow;
			pParticleT->iAnimationStep++;
			if(pParticleT->iAnimationStep >= pSystemT->iAnimationColumns*pSystemT->iAnimationRows)
				pParticleT->iAnimationStep = 0;
		}

		pParticleT->fSize += fTime*4;

		for(i2 = 0; i2 < 3; i2++)
			if(!pParticleT->fVelocity[i2])
				pParticleT->fVelocity[i2] = -0.001f;
		pParticleT->fVelocity[X] -= pParticleT->fVelocity[X]*fTime;
		pParticleT->fVelocity[Y] -= pParticleT->fVelocity[Y]*fTime;
		pParticleT->fVelocity[Z] += pParticleT->fVelocity[Z]*fTime;

		pParticleT->fPos[X] += pParticleT->fVelocity[X]*fTime;
		pParticleT->fPos[Y] += pParticleT->fVelocity[Y]*fTime;
		pParticleT->fPos[Z] += pParticleT->fVelocity[Z]*fTime;
	}
} // end ASParticleSystemCheck_WaterStream()

void ASParticleSystemCheck_AblazeTrace(AS_PARTICLE_SYSTEM *pSystemT)
{ // begin ASParticleSystemCheck_AblazeTrace()
	AS_PARTICLE *pParticleT;
	float fTime, fHeight;
	int i;

	if(!pSystemT->bActive)
		return;

	// Check the system:
	if(pSystemT->bGoingInActive)
	{
	}
	else
	if(g_lNow > pSystemT->lNextTime)
	{ // The system should be updated:
		if(pSystemT->bRandomDelay)
		{ // Get the time do the next update per random:
			pSystemT->lTimeDelay = rand() % pSystemT->lMaxRandomDelay;
		}
		pSystemT->lLastTime = g_lNow;
		pSystemT->lNextTime = pSystemT->lLastTime+pSystemT->lTimeDelay;
	}

	fTime = (float) g_lDeltatime/1000;
	// Check each particle:
	for(i = 0; i < pSystemT->iParticles; i++)
	{
		pParticleT = &pSystemT->pParticle[i];

		if(!pParticleT->bAlive)
			continue;
		
		// Check the particle:
		pParticleT->fEngine -= (float) pParticleT->fFadeSpeed*g_lDeltatime/10.0f;
		if(pParticleT->fEngine <= 0.0f)
		{ // The particle is now 'death':
			pParticleT->bAlive = FALSE;
			continue;
		}
		//
		pParticleT->fSize -= fTime*100*pParticleT->fFadeSpeed;
		if(pParticleT->fSize < 0.01)
		{
			pParticleT->bAlive = FALSE;
			continue;
		}

		memcpy(pParticleT->fLastPos, pParticleT->fPos, sizeof(FLOAT3));

		pParticleT->fVelocity[X] += pParticleT->fVelocity[X]*fTime;
		pParticleT->fVelocity[Y] += pParticleT->fVelocity[Y]*fTime;
		pParticleT->fVelocity[Z] += pParticleT->fVelocity[Z]*fTime;
		pParticleT->fPos[X] += pParticleT->fVelocity[X]*fTime;
		pParticleT->fPos[Y] += pParticleT->fVelocity[Y]*fTime;
		pParticleT->fPos[Z] += pParticleT->fVelocity[Z]*fTime;
		
		fHeight = Level.FastComputeHeight(pParticleT->fPos[X], pParticleT->fPos[Y], POINT_CURRENT);
		if(fHeight < pParticleT->fPos[Z]-pParticleT->fSize*0.1f)
			pParticleT->bAlive = FALSE;

		fHeight = Level.FastComputeHeight(pParticleT->fPos[X], pParticleT->fPos[Y], POINT_WATER);
		if(fHeight < pParticleT->fPos[Z]-pParticleT->fSize*0.1f)
			pParticleT->fEngine -= (float) pParticleT->fFadeSpeed*g_lDeltatime/2.0f;
	}
} // end ASParticleSystemCheck_WaterStream()

void ASParticleSystemCheck_Ablaze(AS_PARTICLE_SYSTEM *pSystemT)
{ // begin ASParticleSystemCheck_Ablaze()
	AS_PARTICLE *pParticleT;
	short i, i2;
	float fTime;

/*	if(!ASCubeInFrustum(Environment.fAblazeBox[MIN][X], Environment.fAblazeBox[MIN][Y], Environment.fAblazeBox[MIN][Z],
						Environment.fAblazeBox[MAX][X], Environment.fAblazeBox[MAX][Z], Environment.fAblazeBox[MAX][Z]))
		return; // The ablaze is not visible!*/
	if(!pSystemT->bActive)
		return;

	// Check the system:
	if(pSystemT->bGoingInActive)
	{
		for(i = 0; i < pSystemT->iParticles; i++)
		{
			if(pSystemT->pParticle[i].bAlive)
				break;
		}
		if(i >= pSystemT->iParticles)
		{
			pSystemT->bActive = FALSE;
			pSystemT->bGoingInActive = FALSE;
			return;
		}
	}

	fTime = (float) g_lDeltatime/1000;
	// Check each particle:
	for(i = 0; i < pSystemT->iParticles; i++)
	{
		pParticleT = &pSystemT->pParticle[i];

		if(!pParticleT->bAlive)
			continue;
		
		for(i2 = 0; i2 < 3; i2++)
		{
			pParticleT->fColor[i2] += (float) g_lDeltatime/15000;
			if(pParticleT->fColor[i2] > 1.0f)
				pParticleT->fColor[i2] = 1.0f;
			if(pParticleT->fPos[i2] > pParticleT->fLastPos[i2])
				pParticleT->fVelocity[i2] -= (float) g_lDeltatime/1000;
			else
			if(pParticleT->fPos[i2] < pParticleT->fLastPos[i2])
				pParticleT->fVelocity[i2] += (float) g_lDeltatime/1000;
			if(pParticleT->fVelocity[i2] > 200.0f)
				pParticleT->fVelocity[i2] = 200.0f;
			if(pParticleT->fVelocity[i2] < -200.0f)
				pParticleT->fVelocity[i2] = -200.0f;

			pParticleT->fPos[i2] += pParticleT->fVelocity[i2]*((float) g_lDeltatime/100);

			if((pParticleT->fPos[i2] <= pParticleT->fLastPos[i2]+0.01f &&
				pParticleT->fPos[i2] >= pParticleT->fLastPos[i2]-0.01f) ||
				pParticleT->fPos[i2] >= pParticleT->fFixPos[i2]+2.0f ||
				pParticleT->fPos[i2] <= pParticleT->fFixPos[i2]-2.0)
			{
				if(pParticleT->fLastPos[i2] != pParticleT->fFixPos[i2] && !pSystemT->bGoingInActive)
					pParticleT->fVelocity[i2] *= 0.3f;
				if(pParticleT->fPos[i2] > pParticleT->fFixPos[i2]+1.0f ||
					pParticleT->fPos[i2] < pParticleT->fFixPos[i2]-1.0f)
				   pParticleT->fLastPos[i2] = pParticleT->fFixPos[i2];
				else
				{
					if(!(rand() % 2))
						pParticleT->fLastPos[i2] += (float) 1.0f+(rand() % 100)/10;
					else
						pParticleT->fLastPos[i2] -= (float) 1.0f+(rand() % 100)/10;
				}
			}
		}
	}
} // end ASParticleSystemCheck_Ablaze()
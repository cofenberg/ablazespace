//-----------------------------------------------------------------------------
// File: AS_BibIncludes.h
//-----------------------------------------------------------------------------

#ifndef __AS_BIB_INCLUDES_H__
#define __AS_BIB_INCLUDES_H__


// Includes: ******************************************************************
#include <windows.h>
#include <windowsx.h>
#include <winuser.h>
#include <winbase.h>
#include <wingdi.h>
#include <dinput.h>
#include <dsound.h>
#include <dmusicc.h>
#include <dmusici.h>
#include <commctrl.h>
#include <dshow.h>
#include <commdlg.h>
#include <tchar.h>
#include <cguid.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <mmsystem.h>
#include <mmsystem.h>
#include <gl\gl.h>
#include <gl\glu.h>
#include <gl\glaux.h>
#include <gl\glext.h>
#include <ijl.h>
#include <Fmod.h>
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_BIB_INCLUDES_H__


//-----------------------------------------------------------------------------
// File: AS_DXShow.cpp
//-----------------------------------------------------------------------------

#include "AS_ENGINE.h"


// Functions: *****************************************************************
HRESULT ASDXShowPlay(char *, HWND);
void ASDXShowAdjustWindow(HWND);
void ASDXShowPause(void);
void ASDXShowStop(void);
void ASDXShowClose(void);
void ASDXShowCloseInterfaces(void);
HRESULT ASDXShowToggleMute(void);
HRESULT ASDXShowHandleGraphEvent(void);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
BOOL g_bAudioOnly = FALSE;
DWORD g_dwGraphRegister = 0;
BOOL g_psCurrent = AS_DX_SHOW_INIT;

// DirectShow interfaces
IGraphBuilder *pGB = NULL;
IMediaControl *pMC = NULL;
IMediaEventEx *pME = NULL;
IVideoWindow  *pVW = NULL;
IBasicAudio   *pBA = NULL;
IBasicVideo   *pBV = NULL;
IMediaSeeking *pMS = NULL;
///////////////////////////////////////////////////////////////////////////////


HRESULT ASDXShowPlay(char *szFile, HWND hWnd)
{ // begin ASDXShowPlay()
    WCHAR wFile[MAX_PATH];
    long lVisible;
    HRESULT hr;
    RECT rect;

	if(!_ASConfig->bMusic || g_psCurrent != AS_DX_SHOW_INIT)
		return 0;

    UpdateWindow(hWnd);

#ifndef UNICODE
    MultiByteToWideChar(CP_ACP, 0, szFile, -1, wFile, MAX_PATH);
#else
    lstrcpy(wFile, szFile);
#endif

    // Get the interface for DirectShow's GraphBuilder:
    hr = CoCreateInstance(CLSID_FilterGraph, NULL, CLSCTX_INPROC_SERVER, IID_IGraphBuilder, (void **) &pGB);

    if(FAILED(hr))
	    return hr;
		
    // Have the graph construct its the appropriate graph automatically:
    pGB->RenderFile(wFile, NULL);

    // QueryInterface for DirectShow interfaces:
    pGB->QueryInterface(IID_IMediaControl, (void **) &pMC);
    pGB->QueryInterface(IID_IMediaEventEx, (void **) &pME);
    pGB->QueryInterface(IID_IMediaSeeking, (void **) &pMS);

    // Query for video interfaces, which may not be relevant for audio files:
    pGB->QueryInterface(IID_IVideoWindow, (void **) &pVW);
    pGB->QueryInterface(IID_IBasicVideo, (void **) &pBV);

    // Query for audio interfaces, which may not be relevant for video-only files:
    pGB->QueryInterface(IID_IBasicAudio, (void **) &pBA);

    // Is this an audio-only file (no video component)?
    g_bAudioOnly = FALSE;
    if((!pVW) || (!pBV))
    {
        g_bAudioOnly = TRUE;
        return 0;
    }
    hr = pVW->get_Visible(&lVisible);
    if(FAILED(hr))
    {
        // If this is an audio-only clip, get_Visible() won't work.
        //
        // Also, if this video is encoded with an unsupported codec,
        // we won't see any video, although the audio will work if it is
        // of a supported format.
        //
        if(hr == E_NOINTERFACE)
            g_bAudioOnly = TRUE;
    }
    if(!g_bAudioOnly)
    {
        pVW->put_Owner((OAHWND) hWnd);
        pVW->put_WindowStyle(WS_CHILD | WS_CLIPSIBLINGS | WS_CLIPCHILDREN);
    }

    // Have the graph signal event via window callbacks for performance:
    pME->SetNotifyWindow((OAHWND) hWnd, WM_GRAPHNOTIFY, 0);

    if(!g_bAudioOnly)
    {
		GetClientRect(hWnd, &rect);
		pVW->SetWindowPosition(rect.left, rect.top, rect.right, rect.bottom);
	}

    // Let's get ready to rumble!
    ShowWindow(hWnd, SW_SHOWNORMAL);
    UpdateWindow(hWnd);
    SetForegroundWindow(hWnd);
    SetFocus(hWnd);

    // Run the graph to play the media file:
    pBA->put_Volume(_ASConfig->iMusicVolume);
    pMC->Run();
    g_psCurrent = AS_DX_SHOW_RUNNING;

    SetFocus(hWnd);

	Sleep(10); // If this isn't done the system will crash... maybe an windows message error??

    return hr;
} // end ASDXShowPlay()

void ASDXShowAdjustWindow(HWND hWnd)
{ // begin ASDXShowAdjustWindow()
    HRESULT hr;
    RECT client;
   
    // Track the movement of the container window and resize as needed:
    if(!pVW)
		return;

    GetClientRect(hWnd, &client);
    hr = pVW->SetWindowPosition(client.left, client.top, client.right, client.bottom);
} // end ASDXShowAdjustWindow()

void ASDXShowPause(void)
{ // begin ASDXShowPause()
    HRESULT hr;
    
    if(!pMC)
        return;

    // Toggle play/pause behavior:
    if((g_psCurrent == AS_DX_SHOW_PAUSED) || (g_psCurrent == AS_DX_SHOW_STOPPED))
    {
        if(_ASConfig->bMusic)
		{
			hr = pMC->Run();
			g_psCurrent = AS_DX_SHOW_RUNNING;
		}
    }
    else
    {
        hr = pMC->Pause();
        g_psCurrent = AS_DX_SHOW_PAUSED;
    }
} // begin ASDXShowPause()

void ASDXShowStop(void)
{ // begin ASDXShowStop()
    HRESULT hr;
    
    if((!pMC) || (!pMS))
        return;

    // Stop and reset postion to beginning
    if((g_psCurrent == AS_DX_SHOW_PAUSED) || (g_psCurrent == AS_DX_SHOW_RUNNING))
    {
        LONGLONG pos = 0;
        hr = pMC->Stop();
        g_psCurrent = AS_DX_SHOW_STOPPED;

        hr = pMS->SetPositions(&pos, AM_SEEKING_AbsolutePositioning,
            NULL, AM_SEEKING_NoPositioning);

        // Display the first frame to indicate the reset condition
        hr = pMC->Pause();
    }
} // end ASDXShowStop()

void ASDXShowClose(void)
{ // begin ASDXShowClose()
    HRESULT hr;

    if(pMC)
        hr = pMC->Stop();

    g_psCurrent = AS_DX_SHOW_STOPPED;
    g_bAudioOnly = TRUE;

    ASDXShowCloseInterfaces();

    // No current media state
    g_psCurrent = AS_DX_SHOW_INIT;
	
	Sleep(10); // If this isn't done the system will crash... maybe an windows message error??

} // end ASDXShowClose()

void ASDXShowCloseInterfaces(void)
{ // begin ASDXShowCloseInterfaces()
    HRESULT hr;
    
    // Relinquish ownership (IMPORTANT!) after hiding video window:
    if(pVW)
    {
        hr = pVW->put_Visible(OAFALSE);
        hr = pVW->put_Owner(NULL);
    }

    SAFE_RELEASE(pME);
    SAFE_RELEASE(pMS);
    SAFE_RELEASE(pMC);
    SAFE_RELEASE(pBA);
    SAFE_RELEASE(pBV);
    SAFE_RELEASE(pVW);
    SAFE_RELEASE(pGB);
} // end ASDXShowCloseInterfaces()

HRESULT ASDXShowToggleMute(void)
{ // begin ASDXShowToggleMute()
    HRESULT hr = S_OK;

    if ((!pGB) || (!pBA))
        return S_OK;

    // Read current volume
    hr = pBA->get_Volume(&_ASConfig->iMusicVolume);
    if(hr == E_NOTIMPL)
    { // Fail quietly if this is a video-only media file:
        return S_OK;
    }
    else
		if (FAILED(hr))
			return hr;

    // Switch volume levels
    if(_ASConfig->iMusicVolume == AS_DX_SHOW_VOLUME_FULL)
        _ASConfig->iMusicVolume = AS_DX_SHOW_VOLUME_SILENCE;
    else
        _ASConfig->iMusicVolume = AS_DX_SHOW_VOLUME_FULL;

    // Set new volume
    pBA->put_Volume(_ASConfig->iMusicVolume);

    return hr;
} // end ASDXShowToggleMute()

HRESULT ASDXShowHandleGraphEvent(void)
{ // begin ASDXShowHandleGraphEvent()
    LONG evCode, evParam1, evParam2;
    HRESULT hr = S_OK;

	if(!pME)
		return 0;
    while(SUCCEEDED(pME->GetEvent(&evCode, &evParam1, &evParam2, 0)))
    {
        // Spin through the events
        hr = pME->FreeEventParams(evCode, evParam1, evParam2);

        if(EC_COMPLETE == evCode)
        {
            LONGLONG pos = 0;

            // Reset to first frame of movie
            hr = pMS->SetPositions(&pos, AM_SEEKING_AbsolutePositioning,
                                   NULL, AM_SEEKING_NoPositioning);
            if (FAILED(hr))
            {
                // Some custom filters (like the Windows CE MIDI filter) 
                // may not implement seeking interfaces (IMediaSeeking)
                // to allow seeking to the start.  In that case, just stop 
                // and restart for the same effect.  This should not be
                // necessary in most cases.
                if (FAILED(hr = pMC->Stop()))
                    break;

                if (FAILED(hr = pMC->Run()))
                    break;
            }
        }
    }

    return hr;
} // end ASDXShowHandleGraphEvent()
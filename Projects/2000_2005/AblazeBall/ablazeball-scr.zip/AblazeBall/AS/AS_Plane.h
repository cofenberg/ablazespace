//-----------------------------------------------------------------------------
// File: AS_Plane.h
//-----------------------------------------------------------------------------

#ifndef __AS_PLANE_H__
#define __AS_PLANE_H__


// Classes: *******************************************************************
typedef class AS_PLANE
{
	public:
		AS_3D_VECTOR vN;
		float fD;

		AS_PLANE(float fA = 1.0f, float fB = 0.0f, float fC = 0.0f, float fD1 = 0.0f)
		{
				vN = AS_3D_VECTOR(fA, fB, fC).Normalize();
				fD = fD1;
		}
		AS_PLANE(AS_3D_VECTOR &vVertexA, AS_3D_VECTOR &vVertexB, AS_3D_VECTOR &vVertexC)
		{
			ComputeND(vVertexA, vVertexB, vVertexC);
		}

		AS_PLANE &operator = (AS_PLANE &Plane)
		{
			vN = Plane.vN;
			fD = Plane.fD;
			return *this;
		}

		void ComputeND(AS_3D_VECTOR vVertexA, AS_3D_VECTOR vVertexB, AS_3D_VECTOR vVertexC)
		{
			AS_3D_VECTOR vNormalA = ((vVertexC-vVertexA).Normalize());
			AS_3D_VECTOR vNormalB = ((vVertexC-vVertexB).Normalize());
			vN = (vNormalA.CrossProduct(vNormalB)).Normalize();
			fD = -vVertexA.DotProduct(vN);
		}

		// Boolean Operators:
		BOOL operator == (AS_PLANE &Plane)
		{
			return vN == Plane.vN && fD == Plane.fD;
		}
		BOOL operator != (AS_PLANE &Plane)
		{
			return !(*this == Plane);
		}

		BOOL PointOnPlane(AS_3D_VECTOR &vPoint)
		{
			return DistanceToPlane(vPoint) == 0;
		}
		float DistanceToPlane(AS_3D_VECTOR &vPoint)
		{
			return ((vN.DotProduct(vPoint))+fD);
		}
		AS_3D_VECTOR RayIntersection(AS_3D_VECTOR &vRayPos, AS_3D_VECTOR &vRayDir)
		{
			float fA = vN.DotProduct(vRayDir);
			if(!fA)
				return vRayPos;	// Error line parallel to plane
			
			return vRayPos-vRayDir*(DistanceToPlane(vRayPos)/fA);
		}

} AS_PLANE;
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_PLANE_H__

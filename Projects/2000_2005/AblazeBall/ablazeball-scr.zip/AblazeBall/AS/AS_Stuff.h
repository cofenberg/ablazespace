//-----------------------------------------------------------------------------
// File: AS_Stuff.h
//-----------------------------------------------------------------------------

#ifndef __AS_STUFF_H__
#define __AS_STUFF_H__


// Classes: *******************************************************************
typedef class AS_DLIGHT
{
	public:
		AS_3D_VECTOR vPos,
					 vColor;
		float fRadius, fDensity;

	public:
		AS_DLIGHT(void);
		virtual ~AS_DLIGHT(void);
		void Light(AS_3D_VECTOR, AS_3D_VECTOR, AS_3D_VECTOR, AS_3D_VECTOR, AS_3D_VECTOR, AS_PLANE);

} AS_DLIGHT;
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_STUFF_H__

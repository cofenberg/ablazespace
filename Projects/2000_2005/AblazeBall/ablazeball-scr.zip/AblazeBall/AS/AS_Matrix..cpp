//-----------------------------------------------------------------------------
// File: AS_Matrix.cpp
//-----------------------------------------------------------------------------

#include "AS_Engine.h"


AS_MATRIX AS_MATRIX::Invert(void)
{ // begin AS_MATRIX::Invert()
    AS_MATRIX MT;
    
	MT.fXX = fXX;
    MT.fXY = fYX;
    MT.fXZ = fZX;
    MT.fYX = fXY;
    MT.fYY = fYY;
    MT.fYZ = fZY;
    MT.fZX = fXZ;
    MT.fZY = fYZ;
    MT.fZZ = fZZ;
  
    // The new displacement vector is given by:  d' = -(R^-1) * d
    MT.fWX = -(fWX*MT.fXX + fWY*MT.fYX + fWZ*MT.fZX);
    MT.fWY = -(fWX*MT.fXY + fWY*MT.fYY + fWZ*MT.fZY);
    MT.fWZ = -(fWX*MT.fXZ + fWY*MT.fYZ + fWZ*MT.fZZ);
  
    // The rest stays the same
    MT.fXW = MT.fYW = MT.fZW = 0.0; 
    MT.fWW = 1.0;

    return MT;
} // end AS_MATRIX::Invert()

AS_3D_VECTOR AS_MATRIX::Transform(const AS_3D_VECTOR V)
{ // begin AS_MATRIX::Transform()
    float fW = V.fX*fWX + V.fY*fWY + V.fZ*fWZ + fWW;
    return AS_3D_VECTOR((V.fX*fXX + V.fY*fXY + V.fZ*fXZ+fXW)/fW,
					    (V.fX*fYX + V.fY*fYY + V.fZ*fYZ+fYW)/fW,
					    (V.fX*fZX + V.fY*fZY + V.fZ*fZZ+fZW)/fW);
} // end AS_MATRIX::Transform()

void AS_MATRIX::GetEulerAngles(float &fX, float &fY, float &fZ)
{ // begin AS_MATRIX::GetEulerAngles() 
	double dAngleX, dAngleY, dAngleZ;

	dAngleY = atan2(fZX, ASFastSqrt(fZY*fZY+fZZ*fZZ));
	double dCosangleY = cos(dAngleY);

	if(fabs(dCosangleY) > AS_EPSILON)
	{
		dAngleZ = atan2(-fYX/dCosangleY, fXX/dCosangleY);
		dAngleX = atan2(-fZY/dCosangleY, fZZ/dCosangleY);
	}
	else
	{
		if(fabs(PId2-dAngleY) < AS_EPSILON)
		{
			dAngleX = atan2(fXY , fYY);
			dAngleY = PId2;
			dAngleZ = 0.0;
		}
		else
		{
			dAngleX = atan2(-fXY , fYY);
			dAngleY = -PId2;
			dAngleZ = 0.0;
		}
	}

	// We set the result:
	fX = (float) (-dAngleX*RAD_TO_DEG);
	fY = (float) (-dAngleY*RAD_TO_DEG);
	fZ = (float) (-dAngleZ*RAD_TO_DEG);
} // end AS_MATRIX::GetEulerAngles()

AS_MATRIX AS_MATRIX::operator*(const AS_MATRIX M)
{
	AS_MATRIX MT;

	MT.fM[0] = fM[0]*M.fM[0] + fM[4]*M.fM[1] + fM[8]*M.fM[2] + fM[12]*M.fM[3];
	MT.fM[1] = fM[1]*M.fM[0] + fM[5]*M.fM[1] + fM[9]*M.fM[2] + fM[13]*M.fM[3];
	MT.fM[2] = fM[2]*M.fM[0] + fM[6]*M.fM[1] + fM[10]*M.fM[2] + fM[14]*M.fM[3];
	MT.fM[3] = fM[3]*M.fM[0] + fM[7]*M.fM[1] + fM[11]*M.fM[2] + fM[15]*M.fM[3];
	MT.fM[4] = fM[0]*M.fM[4] + fM[4]*M.fM[5] + fM[8]*M.fM[6] + fM[12]*M.fM[7];
	MT.fM[5] = fM[1]*M.fM[4] + fM[5]*M.fM[5] + fM[9]*M.fM[6] + fM[13]*M.fM[7];
	MT.fM[6] = fM[2]*M.fM[4] + fM[6]*M.fM[5] + fM[10]*M.fM[6] + fM[14]*M.fM[7];
	MT.fM[7] = fM[3]*M.fM[4] + fM[7]*M.fM[5] + fM[11]*M.fM[6] + fM[15]*M.fM[7];
	MT.fM[8] = fM[0]*M.fM[8] + fM[4]*M.fM[9] + fM[8]*M.fM[10] + fM[12]*M.fM[11];
	MT.fM[9] = fM[1]*M.fM[8] + fM[5]*M.fM[9] + fM[9]*M.fM[10] + fM[13]*M.fM[11];
	MT.fM[10]= fM[2]*M.fM[8] + fM[6]*M.fM[9] + fM[10]*M.fM[10] + fM[14]*M.fM[11];
	MT.fM[11]= fM[3]*M.fM[8] + fM[7]*M.fM[9] + fM[11]*M.fM[10] + fM[15]*M.fM[11];
	MT.fM[12]= fM[0]*M.fM[12] + fM[4]*M.fM[13] + fM[8]*M.fM[14] + fM[12]*M.fM[15];
	MT.fM[13]= fM[1]*M.fM[12] + fM[5]*M.fM[13] + fM[9]*M.fM[14] + fM[13]*M.fM[15];
	MT.fM[14]= fM[2]*M.fM[12] + fM[6]*M.fM[13] + fM[10]*M.fM[14] + fM[14]*M.fM[15];
	MT.fM[15]= fM[3]*M.fM[12] + fM[7]*M.fM[13] + fM[11]*M.fM[14] + fM[15]*M.fM[15];
	
	return MT;
}

AS_3D_VECTOR AS_MATRIX::operator*(const AS_3D_VECTOR V)
{
	return AS_3D_VECTOR(V.fX*fXX + V.fY*fXY + V.fZ*fXZ+fXW,
						V.fX*fYX + V.fY*fYY + V.fZ*fYZ+fYW,
						V.fX*fZX + V.fY*fZY + V.fZ*fZZ+fZW);
} 

void AS_MATRIX::Transpose(void)
{ // begin AS_MATRIX::Transpose()
#define swap(a, b) { float fTmp = a; a = b; b = fTmp; }

    swap(fXY, fYX);
    swap(fXZ, fZX);
    swap(fXW, fWX);
    swap(fYZ, fZY);
    swap(fYW, fWY);
    swap(fZW, fWZ);

#undef swap
} // end AS_MATRIX::Transpose()
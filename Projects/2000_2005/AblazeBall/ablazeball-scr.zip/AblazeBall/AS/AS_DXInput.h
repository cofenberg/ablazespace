//-----------------------------------------------------------------------------
// File: AS_DXInput.h
//-----------------------------------------------------------------------------

#ifndef __AS_DXINPUT_H__
#define __AS_DXINPUT_H__


// Definitions: ***************************************************************
#define AS_DX_INPUT_KEYS 256
#define MAX_MOUSE_BUTTONS 8
#define AS_SCREENSHOT_KEY 183 // Print key
///////////////////////////////////////////////////////////////////////////////

// Structures: ****************************************************************
typedef struct
{
    LONG lX, lY, lZ;
    BYTE byButtons[MAX_MOUSE_BUTTONS],
		 byButtonPressed[MAX_MOUSE_BUTTONS],
		 byButtonFirst[MAX_MOUSE_BUTTONS];
	BOOL bButtonDown;

} AS_MOUSE;

typedef struct
{
	char byName[256]; // Name of this key
	int iCode; // Key code

} AS_DX_INPUT_KEY;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern AS_DX_INPUT_KEY AS_DXInputKeys[AS_DX_INPUT_KEYS];
extern AS_MOUSE ASMouse;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern int ConvertScancodeToASCII(DWORD, USHORT *);
extern int GetDXInputKey(int);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_DXINPUT_H__
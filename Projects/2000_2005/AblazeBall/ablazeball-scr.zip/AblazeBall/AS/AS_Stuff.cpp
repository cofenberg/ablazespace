//-----------------------------------------------------------------------------
// File: AS_Stuff.cpp
//-----------------------------------------------------------------------------

#include "AS_Engine.h"


AS_DLIGHT::AS_DLIGHT(void)
{ // begin AS_DLIGHT::AS_DLIGHT()
	fRadius = 3.0f;
	fDensity = 1.0f;
	vColor.fX = 1.0f;
	vColor.fY = 1.0f;
	vColor.fZ = 1.0f;
} // end  AS_DLIGHT::AS_DLIGHT()

AS_DLIGHT::~AS_DLIGHT(void)
{ // begin AS_DLIGHT::~AS_DLIGHT()
} // end AS_DLIGHT::~AS_DLIGHT()

void AS_DLIGHT::Light(AS_3D_VECTOR vV1, AS_3D_VECTOR vV2, AS_3D_VECTOR vV3,
					  AS_3D_VECTOR vRight, AS_3D_VECTOR vUp, AS_PLANE Plane)
{ // begin AS_DLIGHT::Light()
	float fDis, fBrightness, fScale;
    AS_3D_VECTOR vNearest, vVerNear;

	fDis = AS_ABS(Plane.DistanceToPlane(vPos));
	if(fDis > fRadius*2)
		return; // Too far: don't light the polygon:

	// Nearest point to plane:
	vPos.ProjectPlane(vRight, vUp, vNearest);

//	if(((vPos-vNearest).DotProduct(Plane.vN)) < 0.0)
//		return;

	// Intense is dependable on distance:
	fBrightness = (1.0f-(fDis/fRadius));
	fScale = 1.0f/(fRadius*2.0f-fDis);
	glColor4f(vColor.fX*fBrightness, vColor.fY*fBrightness,
			  vColor.fZ*fBrightness, fDensity);

	// Vector from polygons vertex to nearest point:
	vVerNear = vV1-vNearest;
	glTexCoord2f((float) (vVerNear.DotProduct(vRight*fScale)+0.5f), (float) (vVerNear.DotProduct(vUp*fScale)+0.5f));
	glVertex3f(vV1.fX, vV1.fY, vV1.fZ);

	vVerNear = vV2-vNearest;
	glTexCoord2f((float) (vVerNear.DotProduct(vRight*fScale)+0.5f), (float) (vVerNear.DotProduct(vUp*fScale)+0.5f));
	glVertex3f(vV2.fX, vV2.fY, vV2.fZ);

	vVerNear = vV3-vNearest;
	glTexCoord2f((float) (vVerNear.DotProduct(vRight*fScale)+0.5f), (float) (vVerNear.DotProduct(vUp*fScale)+0.5f));
	glVertex3f(vV3.fX, vV3.fY, vV3.fZ);

} // end AS_DLIGHT::Light()

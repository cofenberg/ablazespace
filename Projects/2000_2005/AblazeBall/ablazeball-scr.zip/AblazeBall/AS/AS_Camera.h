//-----------------------------------------------------------------------------
// File: AS_Camera.h
//-----------------------------------------------------------------------------

#ifndef __AS_CAMERA_H__
#define __AS_CAMERA_H__


// Classes: *******************************************************************
typedef class AS_CAMERA
{
	public:
		// Variables:
		FLOAT3 fPos, fPos2, fRot, fRotVelocity, fRot2, fRot2Velocity;
		float fZ;
		float fZoom, fZoomVelocity;
		int iTimeToNext;

		long lTimer1;

		AS_3D_VECTOR vPos, vPosTemp, vVelocity, vWorldPosTemp, vRotTemp;
		AS_3D_VECTOR vWorldPos, // The real world position of the camera
					 vLastWorldPos; // The last real world position
		
		float fSin, fSin90, fCos, fCos90;

		// Shake effect:
		AS_3D_VECTOR vShakePos, vLastShakePos, vNewShakePos;
		float fShakePower, fShakeSpeed;

		// Under water effect:
		BOOL bUnderWater; // Is the camera under the water?
		FLOAT3 fWaterScale, fWaterLastScale, fWaterToScale, fWaterScaleVelocity;

		// Functions:
		AS_CAMERA(void); // Constructor
		void SetCameraTranslation(BOOL);
		void SetStandartCamera(void);
		void CalculateSinCos(void);
		void Check(void);

} AS_CAMERA;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern AS_CAMERA *_ASCamera;
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_CAMERA_H__
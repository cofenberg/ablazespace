//-----------------------------------------------------------------------------
// File: AS_Matrix.h
//-----------------------------------------------------------------------------

#ifndef __AS_MATRIX_H__
#define __AS_MATRIX_H__


// Classes: *******************************************************************
typedef class AS_MATRIX
{
	public:
		union
		{
			float fM[16];
			struct
			{
				float fXX, fXY, fXZ, fXW;
				float fYX, fYY, fYZ, fYW;
				float fZX, fZY, fZZ, fZW;
				float fWX, fWY, fWZ, fWW;
			};
			struct
			{
				float fM44[4][4];
			};
		};

		// Constructor:
		AS_MATRIX(void) { LoadIdentity(); }
		AS_MATRIX(const float *fS)	{ *this = fS; }
		AS_MATRIX(const AS_MATRIX &M) { *this = M; }

		// Assignment operators:
		AS_MATRIX &operator=(const AS_MATRIX M)
		{
			fXX = M.fXX, fXY = M.fXY, fXZ = M.fXZ, fXW = M.fXW;
			fYX = M.fYX, fYY = M.fYY, fYZ = M.fYZ, fYW = M.fYW;
			fZX = M.fZX, fZY = M.fZY, fZZ = M.fZZ, fZW = M.fZW;
			fWX = M.fWX, fWY = M.fWY, fWZ = M.fWZ, fWW = M.fWW;
			return *this;
		}

		// Misc:
		void LoadIdentity(void)
		{
			fXX = 1.0f, fXY = 0.0f, fXZ = 0.0f, fXW = 0.0f;
			fYX = 0.0f, fYY = 1.0f, fYZ = 0.0f, fYW = 0.0f;
			fZX = 0.0f, fZY = 0.0f, fZZ = 1.0f, fZW = 0.0f;
			fWX = 0.0f, fWY = 0.0f, fWZ = 0.0f, fWW = 1.0f;
		}

		void XRot(const float fAngle)
		{
    		const float fC = (float) cos(fAngle);
			const float fS = (float) sin(fAngle);

			fYY = fC;
			fYZ = fS;
			fZY = -fS;
			fZZ = fC;
		}

		void YRot(const float fAngle)
		{
    		const float fC = (float) cos(fAngle);
			const float fS = (float) sin(fAngle);

			fXX = fC;
			fXZ = -fS;
			fZX = fS;
			fZZ = fC;
		}

		void ZRot(const float fAngle)
		{
    		const float fC = (float) cos(fAngle);
			const float fS = (float) sin(fAngle);

			fXX = fC;
			fXY = fS;
			fYX = -fS;
			fYY = fC;
		}

		void Scale(const float fX, const float fY, const float fZ)
		{
    		fXX = fX;   
			fYY = fY;
			fZZ = fZ;  
		}
		void Scale(const AS_3D_VECTOR V) { Scale(V.fX, V.fY, V.fZ); }
		void Scale(const float *fV) { Scale(*fV++, *fV++, *fV); }

		void Translate(const float fX, const float fY, const float fZ)
		{
			fWX += fXX*fX + fYX*fY + fZX*fZ;
			fWY += fXY*fX + fYY*fY + fZY*fZ;
			fWZ += fXZ*fX + fYZ*fY + fZZ*fZ;
			fWW += fXW*fX + fYW*fY + fZW*fZ;
		}
		void Translate(const AS_3D_VECTOR V) { Translate(V.fX, V.fY, V.fZ); }
		void Translate(const float *fV) { Translate(*fV++, *fV++, *fV); }

		AS_MATRIX operator*(const AS_MATRIX M);
		void operator*=(const AS_MATRIX M)
		{ *this = *this*M; }

		AS_3D_VECTOR operator*(const AS_3D_VECTOR);
		void Transpose(void);
		AS_MATRIX Invert(void);
		AS_3D_VECTOR Transform(const AS_3D_VECTOR);
		void GetEulerAngles(float &, float &, float &);

} AS_MATRIX;      


#endif // __AS_MATRIX_H__
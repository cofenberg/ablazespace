//-----------------------------------------------------------------------------
// File: AS_Engine.h
//-----------------------------------------------------------------------------

#ifndef __AS_ENGINE_H__
#define __AS_ENGINE_H__


// Definitions: ***************************************************************
#define AS_WINDOW_NAME "AS-Engine"
enum {MODULE_GAME};
#define AS_GAME_INFO_FILE "Game.ini"
#define AS_LOG_FILE "Log.html"
#define GAME_NAME "AblazeBall"
#define GAME_VERSION "V1.1"
#define GAME_WINDOW_NAME "AblazeBall"
#define MD2_FILE "Model files (*.md2)\0*.md2\0"
#define JPG_FILE "JPG files (*.jpg)\0*.jpg\0"
#define BMP_FILE "BMP files (*.BMP)\0*.BMP\0"
#define PPM_FILE "PPM files (*.PPM)\0*.PPM\0"
#define TGA_FILE "TGA files (*.TGA)\0*.TGA\0"
#define MUSIC_FILES \
		TEXT("Audio files (*.wav; *.mpa; *.mp2; *.mp3; *.au; *.aif; *.aiff; *.snd)\0*.wav; *.mpa; *.mp2; *.mp3; *.au; *.aif; *.aiff; *.snd\0")\
		TEXT("MIDI Files (*.mid, *.midi, *.rmi)\0*.mid; *.midi; *.rmi\0") \
		TEXT("All Files (*.*)\0*.*;\0\0")
///////////////////////////////////////////////////////////////////////////////

// Includes: ******************************************************************
#include "AS_BibIncludes.h"
#include "..\Resource.h"
#include "AS_FrustumCulling.h"
#include "AS_ProgressWindow.h"
#include "AS_Window.h"
#include "AS_OpenGL.h"
#include "AS_Config.h"
#include "AS_Language.h"
#include "AS.h"
#include "AS_Fmod.h"
// DirectX stuff:
#include "AS_DXInput.h"
// Math stuff:
#include "AS_Math.h"
#include "AS_Vector.h"
#include "AS_Plane.h"
// #include "AS_Matrix.h" // Not required in AblazeBall!
// #include "AS_Quaternion.h" // Not required in AblazeBall!
// Other stuff:
#include "AS_Camera.h"
#include "AS_Collision.h"
#include "AS_Particle.h"
#include "AS_Stuff.h"
#include "..\ModuleHeaders.h"
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_ENGINE__
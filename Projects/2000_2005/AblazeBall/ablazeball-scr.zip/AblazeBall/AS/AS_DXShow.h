//-----------------------------------------------------------------------------
// File: AS_DXShow.h
//-----------------------------------------------------------------------------

#ifndef __AS_DXSHOW_H__
#define __AS_DXSHOW_H__


// Definations: ***************************************************************
#define WM_GRAPHNOTIFY  WM_USER+13
#define AS_DX_SHOW_INIT 0
#define AS_DX_SHOW_STOPPED 1
#define AS_DX_SHOW_PAUSED 2
#define AS_DX_SHOW_RUNNING 3
#define AS_DX_SHOW_VOLUME_FULL 0L
#define AS_DX_SHOW_VOLUME_SILENCE -10000L
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern BOOL g_bAudioOnly;
extern DWORD g_dwGraphRegister;
extern BOOL g_psCurrent;

// DirectShow interfaces
extern IGraphBuilder *pGB;
extern IMediaControl *pMC;
extern IMediaEventEx *pME;
extern IVideoWindow  *pVW;
extern IBasicAudio   *pBA;
extern IBasicVideo   *pBV;
extern IMediaSeeking *pMS;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern HRESULT ASDXShowPlay(char *, HWND);
extern void ASDXShowAdjustWindow(HWND);
extern void ASDXShowPause(void);
extern void ASDXShowStop(void);
extern void ASDXShowClose(void);
extern void ASDXShowCloseInterfaces(void);
extern HRESULT ASDXShowToggleMute(void);
extern HRESULT ASDXShowHandleGraphEvent(void);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_DXSHOW_H__
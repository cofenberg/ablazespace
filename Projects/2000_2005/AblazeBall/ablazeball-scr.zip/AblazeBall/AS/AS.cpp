//-----------------------------------------------------------------------------
// File: AS.cpp
//-----------------------------------------------------------------------------

#include "AS_Engine.h"


// Variables: *****************************************************************
AS_PROGRAM_INFO _ASProgramInfo;
AS_ENGINE *_AS;
UCHAR ASKeys[256];
BOOL ASKeyPressed[256], ASKeyFirst[256];
int iASResult;
DEVMODE	ASSavedDisplayMode;
// Multi-texture:
PFNGLMULTITEXCOORD2FARBPROC	glMultiTexCoord2fARB = 0;
PFNGLACTIVETEXTUREARBPROC glActiveTextureARB = 0;
PFNGLCLIENTACTIVETEXTUREARBPROC	glClientActiveTextureARB = 0;
// Compiled array vertex:
PFNGLLOCKARRAYSEXTPROC glLockArraysEXT = 0;
PFNGLUNLOCKARRAYSEXTPROC glUnlockArraysEXT = 0;

// General speed variables
long g_lProgramStartTime	= 0;		// The Program Start Time
long g_lGameLength			= 0;		// Application Run Time Variable
long g_lNow	                = 0;		// The Actual Time
long g_lLastlooptime		= 0;		// Time When Last Loop Was Started
long g_lDeltatime			= 0;		// Change In Time Since Last Iteration
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
HRESULT ASDraw(AS_WINDOW *);
HRESULT ASCheck(AS_WINDOW *);
void ASSwapBuffers(HDC, AS_WINDOW *, BOOL);
char *ASGetFileName(HWND,  char *, char *, BOOL, BOOL, char *);
void ASLoadTextures(char (*)[256], int, AS_TEXTURE *);
void ASDestroyTextures(int, AS_TEXTURE *);
void ASGenOpenGLTextures(int, AS_TEXTURE *);
void ASDestroyOpenGLTextures(int, AS_TEXTURE *);
int ASCheckTextureSize(int);
BOOL ASLoadJpegRGB(AS_TEXTURE *, char *);
BOOL ASLoadBmp(AS_TEXTURE *, char *);
BOOL ASLoadPpm(AS_TEXTURE *, char *);
BOOL ASLoadTga(AS_TEXTURE *, char *);
void ASSavePpm(AS_TEXTURE *, char *);
DWORD ASGetCpuSpeed(void);
void ASRemoveDirectory(char *);
BOOL ASCheckStringEnding(char *, char [256]);
void ASDrawBoundingBox(float [2][3], float);
BOOL ASCheckEnding(char *, char [256]);
///////////////////////////////////////////////////////////////////////////////


// AS_PROGRAM_INFO functions: *************************************************
void AS_PROGRAM_INFO::Init(void)
{ // begin AS_PROGRAM_INFO()
	strcpy(byVersion, GAME_VERSION);
	strcpy(byDate, __DATE__);
	strcpy(byTime, __TIME__);
} // end AS_PROGRAM_INFO()

// AS_ENGINE functions: *******************************************************
AS_ENGINE::AS_ENGINE(HINSTANCE hInstanceT, LPSTR lpCmdLineT, int iCmdShowT, BOOL bOnlyOne)
{ // begin AS_ENGINE::AS_ENGINE()
	DWORD i = MAX_PATH;
	BOOL bTemp, bTemp2;
	int AS_WINDOW_ID;
	char byTemp[256];

	// Init all:
	memset((this), 0, sizeof(AS_ENGINE));
	_AS = this;
	GetLocalTime(&StartTime);
	
	// Set important stuff
	hInstance = hInstanceT;
	lpCmdLine = lpCmdLineT;
	iCmdShow = iCmdShowT;
	hMutex = OpenMutex(MUTEX_ALL_ACCESS, FALSE, GAME_NAME);
    if(hMutex)
    {
        if(bOnlyOne)
		{
			CloseHandle(hMutex);
			MessageBox(0, M_TheProgramIsAlreadyRunning, GAME_NAME, MB_ICONERROR | MB_OK);
			bShutDown = TRUE;
			return;
		}
    }
    else
        hMutex = CreateMutex(NULL, TRUE, GAME_NAME);
	SetPriorityClass(hInstance, 31);
	SetThreadPriority(hInstance, 31);
	_ASProgramInfo.Init();
	bActive = TRUE;
	ASBuildSqrtTable();

	// Initalize the random generator
	srand((unsigned) time(NULL));
  	pbyProgramPath = new char[_MAX_DRIVE+_MAX_DIR];
	pbyProgramExeName = new char[MAX_PATH];
	pbyProgramDrive = new char[_MAX_DRIVE];
	pbyProgramDir = new char[_MAX_DIR];
  	pbyUserName = new char[MAX_PATH];
	pbyConfigFile = new char[MAX_PATH];
	pbyLanguagesFile = new char[MAX_PATH];
  	pbyHighscoreFile = new char[MAX_PATH];
  	pbyObjectsFile = new char[MAX_PATH];
  	pbyBitmapsFile = new char[MAX_PATH];
  	pbyMusicFile = new char[MAX_PATH];
  	pbySoundFile = new char[MAX_PATH];

	// Find path info
	GetModuleFileName(hInstance, pbyProgramExeName, MAX_PATH);
	_splitpath(pbyProgramExeName, pbyProgramDrive, pbyProgramDir, NULL, NULL);
	sprintf(pbyProgramPath, "%s%s", pbyProgramDrive, pbyProgramDir);
	SetCurrentDirectory(pbyProgramPath);
	GetUserName(pbyUserName, &i);

    // Loads the game stuff:
	sprintf(byTemp, "%s"AS_GAME_INFO_FILE"", _AS->pbyProgramPath);
	bLog = GetPrivateProfileInt("general", "log", 1, byTemp);
	bDebugMode = GetPrivateProfileInt("general", "debug_mode", 0, byTemp);
	bStartErrorMessage = GetPrivateProfileInt("general", "start_error_message", 1, byTemp);
	GetPrivateProfileString("general", "config_file", "Config.ini", pbyConfigFile, MAX_PATH, byTemp);
	GetPrivateProfileString("general", "languages_file", "Data\\Languages", pbyLanguagesFile, MAX_PATH, byTemp);
	GetPrivateProfileString("general", "highscore_file", "Highscore.dat", pbyHighscoreFile, MAX_PATH, byTemp);
	GetPrivateProfileString("general", "objects_file", "Data\\Objects", pbyObjectsFile, MAX_PATH, byTemp);
	GetPrivateProfileString("general", "bitmaps_file", "Data\\Bitmaps", pbyBitmapsFile, MAX_PATH, byTemp);
	GetPrivateProfileString("general", "music_file", "Data\\Music", pbyMusicFile, MAX_PATH, byTemp);
	GetPrivateProfileString("general", "sound_file", "Data\\Sound", pbySoundFile, MAX_PATH, byTemp);
	
	// Load the configuration:	
	_ASConfig = new AS_CONFIG;
	sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyConfigFile);
	_ASConfig->Load(byTemp);

	// Open the log:
	bTemp2 = _ASConfig->bLog;
	_ASConfig->bLog = TRUE;
	pLogFile = fopen(AS_LOG_FILE, "wt");
	if(!pLogFile)
	{
		sprintf(byTemp, "Couldn't open the log (%s)\nGo sure that all program-files ready for writing!", AS_LOG_FILE);
		MessageBox(NULL, byTemp, T_Error, MB_OK | MB_ICONINFORMATION);
		bLog = FALSE; // Disable the log
	}

	// Create header:
	WriteLog("<HTML>");
	WriteLog("<HEAD>");
	WriteLog("<TITLE>Log</TITLE>");
	WriteLog("</HEAD>");
	WriteLog("<BODY>");
	////////////////////////////////////
	WriteLog("<P ALIGN=\"CENTER\"><FONT SIZE=\"+1\" COLOR=\"#0080FF\"><U><B>Log-System activated</B></U></FONT></P>");
	WriteLog("<P ALIGN=\"CENTER\"><B><FONT SIZE=\"+1\"><B><U>Program start time:</B></U> Date: %d.%d.%d - Time: %d:%d:%d:%d</FONT></B></P>", StartTime.wMonth, StartTime.wDay, StartTime.wYear, 
																										  StartTime.wHour, StartTime.wMinute, 
																										  StartTime.wSecond, StartTime.wMilliseconds);
	////////////////////////////////////
	WriteLog("<P ALIGN=\"CENTER\"><FONT SIZE=\"+4\"><U><B><I><FONT COLOR=\"#FF0000\">%s %s<FONT></I></B></U></FONT></FONT></P>", GAME_NAME, GAME_VERSION);
	WriteLog("<P ALIGN=\"CENTER\"><B><FONT SIZE=\"+1\">Build: %s %s</FONT></B></P>", _ASProgramInfo.byDate, _ASProgramInfo.byTime);

	// Print out the general system info:
	WriteLog("<P ALIGN=\"CENTER\"><FONT SIZE=\"+2\"><U><B>General system info:</B></U></FONT></P>");
	WriteLog("<TABLE WIDTH=\"1000\">");
	WriteLogMessage("User name: %s", pbyUserName);
	WriteLogMessage("CPU: %d Mhz", ASGetCpuSpeed());
	if(GetSystemMetrics(SM_MOUSEPRESENT))
		WriteLogMessage("There is a mouse");
	else
		WriteLogMessage("There is no mouse");
	sprintf(byTemp, "Number of mouse buttons: %d", GetSystemMetrics(SM_CMOUSEBUTTONS));
	WriteLogMessage(byTemp);	
	sprintf(byTemp, "Display resolution: %dx%d", GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN));
	WriteLogMessage(byTemp);
	WriteLog("</TABLE>");

	// Print out path info:
	WriteLog("<P ALIGN=\"CENTER\"><FONT SIZE=\"+2\"><U><B>File info:</B></U></FONT></P>");
	WriteLog("<TABLE WIDTH=\"1000\">");
	WriteLog("<TR><TD><B><U>Program path:</B></U> %s</TD></TR>", pbyProgramPath);
	WriteLog("<TR><TD><B><U>Game info file:</B></U> "AS_GAME_INFO_FILE"</TD></TR>");
	WriteLog("<TR><TD><B><U>Config file:</B></U> %s</TD></TR>", pbyConfigFile);
	WriteLog("<TR><TD><B><U>Languages file:</B></U> %s</TD></TR>", pbyLanguagesFile);
	WriteLog("<TR><TD><B><U>Highscore file:</B></U> %s</TD></TR>", pbyHighscoreFile);
	WriteLog("<TR><TD><B><U>Objects file:</B></U> %s</TD></TR>", pbyObjectsFile);
	WriteLog("<TR><TD><B><U>Bitmaps file:</B></U> %s</TD></TR>", pbyBitmapsFile);
	WriteLog("<TR><TD><B><U>Music file:</B></U> %s</TD></TR>", pbyMusicFile);
	WriteLog("<TR><TD><B><U>Sound file:</B></U> %s</TD></TR>", pbySoundFile);
	WriteLog("</TABLE>");
	WriteLog("<P ALIGN=\"CENTER\"><FONT SIZE=\"+2\"><U><B>Messages:</B></U></FONT></P>");
	WriteLog("<TABLE WIDTH=\"1000\">");

    // Init FPS:
	dwFPSTimeNow = GetTickCount();
	dwFPSTimeLast = GetTickCount();
	dwFPSTimeDifference = 0;
	iFPSRenderedFrames = iFPSFramesSinceCheck = iFPS = 0;
	EnumerateDisplayModeInfos();

	// Enumerate the languages:
	EnumerateLanguages();

	// Initalize DirectInput:
	WriteLogMessage("Initalize DirectInput");

	// Get the OpenGL stuff:
	WriteLogMessage("Get OpenGL information");
	bTemp = _ASConfig->bFullScreen; 
	_ASConfig->bFullScreen = 0; 
	ASCreateWindow(WindowProc, AS_WINDOW_NAME, AS_WINDOW_NAME, _ASConfig->iWindowWidth, _ASConfig->iWindowHeight, NULL, FALSE, ASDraw, ASCheck, NULL, TRUE);
	AS_WINDOW_ID = _AS->GetWindows()-1;
	ASInitOpenGL(&_AS->pWindow[AS_WINDOW_ID],
				 NULL,
				 _AS->pWindow[AS_WINDOW_ID].GethDC(),
				 _AS->pWindow[AS_WINDOW_ID].GethRC(), FALSE);
	glGetIntegerv(GL_MAX_LIGHTS, &iMaxLights);
	InitExtensions();
	glGetIntegerv(GL_MAX_TEXTURE_SIZE, &iMaxTextureSize);
	ASDestroyOpenGL(&_AS->pWindow[AS_WINDOW_ID],
					NULL,
				    *_AS->pWindow[AS_WINDOW_ID].GethDC(),
				    *_AS->pWindow[AS_WINDOW_ID].GethRC());
	ASDestroyWindow(_AS->pWindow[AS_WINDOW_ID].GethWnd(), AS_WINDOW_NAME);
	_ASConfig->bFullScreen = bTemp; 
	WriteLogMessage("OpenGL information received");

	// Print out the OpenGL information:
	WriteLogMessage("Show OpenGL information");
	WriteLogMessage("Version:");
	WriteLogMessage(pbyOpenGLVersion);
	WriteLogMessage("Chip info:");
	WriteLogMessage(pbyOpenGLChipInfo);
	WriteLogMessage("Renderer info:");
	WriteLogMessage(pbyOpenGLRendererInfo);
	WriteLogMessage("Extensions info:");
	WriteLogMessageS(pbyOpenGLExtensionInfo);
	WriteLogMessage("\nMax texture size: %dx%d", iMaxTextureSize, iMaxTextureSize);
	WriteLogMessage("That's all from OpenGL");


	if(!bOnlyConfig)
		ASInitFmod();

	// Init complete:
	g_lProgramStartTime = GetTickCount();
	WriteLogMessage("AS-Engine init complete");
	_ASConfig->bLog = bTemp2;
} // end AS_ENGINE::AS_ENGINE()

AS_ENGINE::~AS_ENGINE(void)
{ // begin AS_ENGINE::~AS_ENGINE()
	char byTemp[256];
	BOOL bTemp;

	// Shut down the program:
	_AS->WriteLogMessage("Program loop left");
	_AS->WriteLogMessage("Shut down program");

	if(!bOnlyConfig)
		ASDestroyFmod();

	// Check if there was an error:
	if(!_ASConfig->bSetError)
		_ASConfig->bError = FALSE;
	else
		_ASConfig->bError = TRUE;
	_ASConfig->bFirstRun = FALSE;
	if(_ASConfig->bError)
		MessageBox(NULL, M_ProgramEndErrorDetected, GAME_NAME, MB_OK | MB_ICONINFORMATION);

	// Save the configuration:	
	sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyConfigFile);
	_ASConfig->Save(byTemp);

	// Delete OpenGL information
	SAFE_DELETE(pbyOpenGLVersion);
	SAFE_DELETE(pbyOpenGLChipInfo);
	SAFE_DELETE(pbyOpenGLRendererInfo);
	SAFE_DELETE(pbyOpenGLExtensionInfo);

	// Delete last stuff:
	SAFE_DELETE(pbyProgramPath);
	SAFE_DELETE(pbyProgramExeName);
	SAFE_DELETE(pbyProgramDrive);
	SAFE_DELETE(pbyProgramDir);
	SAFE_DELETE(pbyUserName);
	SAFE_DELETE(pbyConfigFile);
	SAFE_DELETE(pbyLanguagesFile);
	SAFE_DELETE(pbyHighscoreFile);
	SAFE_DELETE(pbyObjectsFile);
	SAFE_DELETE(pbyMusicFile);
	SAFE_DELETE(pbySoundFile);
	DestroyDisplayModeInfo();
	DestroyLanguage();

	// Close the Log:
	bTemp = _ASConfig->bLog;
	_ASConfig->bLog = TRUE;
	WriteLogMessage("Shut down AS-Engine");
	WriteLog("</TABLE>");
	WriteLog("<P ALIGN=\"CENTER\"><FONT SIZE=\"+1\" COLOR=\"#0080FF\"><U><B>Log-System closed</B></U></FONT></P>");
	WriteLog("</BODY>\n");
	WriteLog("</HTML>\n");
	if(pLogFile)
		fclose(pLogFile);
	_ASConfig->bLog = bTemp;
	delete _ASConfig;
} // end AS_ENGINE::~AS_ENGINE()

void AS_ENGINE::WriteLog(const char *pbyMessage, ...)
{ // begin AS_ENGINE::WriteLog()
	char byText[1000];
	va_list	list;

	if(!bLog || !pLogFile || !_ASConfig->bLog)
		return;
	va_start(list, pbyMessage);
		vsprintf(byText, pbyMessage, list);
	va_end(list);
	fprintf(pLogFile, byText);
	fflush(pLogFile);
} // end AS_ENGINE::WriteLog()

void AS_ENGINE::WriteLogMessage(const char *pbyMessage, ...)
{ // begin AS_ENGINE::WriteLogMessage()
	char byText[1000];
	va_list	list;

	if(!bLog || !pLogFile || !_ASConfig->bLog)
		return;
	va_start(list, pbyMessage);
		vsprintf(byText, pbyMessage, list);
	va_end(list);
	fprintf(pLogFile, "<TR><TD><FONT SIZE=\"+1\">%s</FONT></TD</TR>", byText);
	fflush(pLogFile);
} // end AS_ENGINE::WriteLogMessage()

void AS_ENGINE::WriteLogMessageS(char *pbyMessage)
{ // begin AS_ENGINE::WriteLogMessageS()
	if(!bLog || !pLogFile || !_ASConfig->bLog)
		return;
	fprintf(pLogFile, "<TR><TD><FONT SIZE=\"+1\">%s</FONT></TD</TR>", pbyMessage);
	fflush(pLogFile);
} // end AS_ENGINE::WriteLogMessageS()

HWND AS_ENGINE::ASCreateWindow(WNDPROC WindowProc,
							   LPCTSTR pbyTitle,
							   LPCTSTR pbyName,
							   DWORD dwWidth,
							   DWORD dwHeight,
			   				   HMENU Menu,
							   BOOL bFullScreen,
							   HRESULT (*pDrawTemp)(AS_WINDOW *),
							   HRESULT (*pCheckTemp)(AS_WINDOW *),
							   HBRUSH hBackground,
							   BOOL bIsMainWindowT)
{ // begin AS_ENGINE::ASCreateWindow()
	HWND hWnd;
		
	WriteLogMessage("Create window");
	if(bMainWindow && bIsMainWindowT)
	{
		WriteLogMessage("There is already a main window!");
		return NULL;
	}
	WriteLogMessage("Titel: %s", pbyTitle);
	WriteLogMessage("Name: %s", pbyName);
	WriteLogMessage("Width: %d", dwWidth);
	WriteLogMessage("Height: %d", dwHeight);
	WriteLogMessage("Full screen: %d", bFullScreen);
	iWindows++;
	pWindow = (AS_WINDOW *) realloc(pWindow, sizeof(AS_WINDOW)*iWindows);
	hWnd = pWindow[iWindows-1].ASCreateWindow(WindowProc, 
											  pbyTitle,
											  pbyName,
											  dwWidth,
											  dwHeight,
											  Menu,
											  bFullScreen,
											  pDrawTemp,
											  pCheckTemp,
											  hBackground,
											  bIsMainWindowT);
	pWindow[iWindows-1].SetID(iWindows-1);
	WriteLogMessage("Window(ID: %d) successful created", iWindows-1);
	if(!bMainWindow && bIsMainWindowT)
		bMainWindow = TRUE;
	return hWnd;
} // end AS_ENGINE::ASCreateWindow()

HRESULT AS_ENGINE::ASDestroyWindow(HWND *hWnd, LPCTSTR pbyName)
{ // begin AS_ENGINE::ASDestroyWindow()
	LPTSTR lpClassName = new char[MAX_PATH];
	int i;
	
	WriteLogMessage("Destroy window");
	WriteLogMessage("Name: %s", pbyName);
	if(!hWnd)
	{ // Find the window self:
		for(i = 0; i < iWindows; i++)
		{
			GetClassName(*pWindow[i].GethWnd(), lpClassName, MAX_PATH);
			if(!strcmp(lpClassName, pbyName))
			{ // We�ve found the window!
				HWND hTemp; 

				hTemp = *pWindow[i].GethWnd();
				hWnd = &hTemp;
				break;
			}
		}
	}
	if(!hWnd)
		return 1;
	for(i = 0; i < iWindows; i++)
		if(*pWindow[i].GethWnd() == *hWnd)
		{
			WriteLogMessage("ID: %d", i);
			if(pWindow[i].GetIsMainWindow())
				bMainWindow = FALSE;
			pWindow[i].ASDestroyWindow(hWnd, pbyName);			
			pWindow[i] = pWindow[iWindows-1];
			iWindows--;
			pWindow = (AS_WINDOW *) realloc(pWindow, sizeof(AS_WINDOW)*iWindows);
			WriteLogMessage("Window successful destroyed");
			return 0;
		}
	return 1;
} // end AS_ENGINE::ASDestroyWindow()

HRESULT AS_ENGINE::EnumerateDisplayModeInfos(void)
{ // begin AS_ENGINE::EnumerateDisplayModeInfos()
	DEVMODE devMode;

	DestroyDisplayModeInfo();
	WriteLogMessage("Enumerate display modes...");
	for(int i = 0;;i++) 
	{
		if(!EnumDisplaySettings(NULL, i, &devMode)) 
			break;
		AddDisplayModeInfo(devMode);
	}
	WriteLogMessage("Complete");
    return 0;
} // end AS_ENGINE::EnumerateDisplayModeInfos()

HRESULT AS_ENGINE::AddDisplayModeInfo(DEVMODE lpDevMode)
{ // begin AS_ENGINE::AddDisplayModeInfo()
	if(lpDevMode.dmBitsPerPel < 16)
		return 1;
	DisplayModeInfo.Number++;
	DisplayModeInfo.pDevMode = (DEVMODE *) realloc(DisplayModeInfo.pDevMode, sizeof(DEVMODE)*DisplayModeInfo.Number);
	if(!DisplayModeInfo.pDevMode)
		return 1;
	CopyMemory(&DisplayModeInfo.pDevMode[DisplayModeInfo.Number-1], &lpDevMode, sizeof(DEVMODE));
	WriteLogMessage("Found: %dx%dx%d", DisplayModeInfo.pDevMode[DisplayModeInfo.Number-1].dmPelsWidth,
									   DisplayModeInfo.pDevMode[DisplayModeInfo.Number-1].dmPelsHeight,
									   DisplayModeInfo.pDevMode[DisplayModeInfo.Number-1].dmBitsPerPel);
	return 0;
} // end AS_ENGINE::AddDisplayModeInfo()

HRESULT AS_ENGINE::DestroyDisplayModeInfo(void)
{ // begin AS_ENGINE::DestroyDisplayModeInfo()
	if(DisplayModeInfo.pDevMode)
		free(DisplayModeInfo.pDevMode);
	DisplayModeInfo.pDevMode = NULL;
	DisplayModeInfo.Number = 0;
	return 0;
} // end AS_ENGINE::DestroyDisplayModeInfo()

void AS_ENGINE::UpdateWindows(void)
{ // begin AS_ENGINE::UpdateWindows()
	// Check the speed control stuff
	g_lNow = GetTickCount();
	g_lDeltatime = g_lNow-g_lLastlooptime;
	if(g_lDeltatime > 100)
		g_lDeltatime = 100;

	if(bSpeedControl && (iSpeedFactor > 1 || iSpeedFactor < -1))
	{
		if(iSpeedFactor > 0)
			g_lDeltatime = (long) (g_lDeltatime*((float) iSpeedFactor/2));
		else
			g_lDeltatime = (long) (g_lDeltatime/((float) -iSpeedFactor/2));
	}

	g_lLastlooptime = g_lNow;
	g_lGameLength = (g_lNow-g_lProgramStartTime)/1000;	

	// Check the windows
	for(int i = 0; i < iWindows; i++)
	{
		pWindow[i].Check();
		pWindow[i].Draw();
	}
	UpdateFPS();
} // end AS_ENGINE::UpdateWindows()

int AS_ENGINE::FindWindowID(HWND hWnd)
{ // begin AS_ENGINE::FindWindowID()
	for(int i = 0; i < iWindows; i++)
		if(*pWindow[i].GethWnd() == hWnd)
			return i;
	return -1;
} // end AS_ENGINE::FindWindowID()

int AS_ENGINE::UpdateFPS(void)
{ // begin AS_ENGINE::UpdateFPS()
	dwFPSTimeNow = GetTickCount();
	dwFPSTimeDifference = dwFPSTimeNow-dwFPSTimeLast;
	iFPSRenderedFrames++;
	iFPSFramesSinceCheck++;
	if(dwFPSTimeDifference > 1000)
	{
		dwFPSTimeLast = dwFPSTimeNow;
		iFPS = iFPSFramesSinceCheck;
		iFPSFramesSinceCheck = 0;
	}
    return iFPS;
} // end AS_ENGINE::UpdateFPS()

void AS_ENGINE::ShowMouseCursor(BOOL bState)
{ // begin AS_ENGINE::ShowMouseCursor()
	int i;
	
	// Disables/Enables the mouse cursor:
	if(!bState)
	{
		for(;;)
		{
			i = ShowCursor(FALSE);
			if(i < 0)
				break;
		}
	}
	else
	{
		for(;;)
		{
			i = ShowCursor(TRUE);
			if(i >= 0)
				break;
		}
	}
} // end AS_ENGINE::ShowMouseCursor()

BOOL AS_ENGINE::IsExtensionSupported(const char *pbyExtension)
{ // begin AS_ENGINE::IsExtensionSupported()
	const GLubyte *pbyExtensions = NULL;
	const GLubyte *pbyStart;
	GLubyte *pbyWhere, *pbyTerminator;

	// Extension names should not have spaces:
	pbyWhere = (GLubyte *) strchr(pbyExtension, ' ');
	if(pbyWhere || *pbyExtension == '\0')
		return 0;
	pbyExtensions = glGetString(GL_EXTENSIONS);
	
	// It takes a bit of care to be fool-proof about parsing the
	// OpenGL extensions string. Don't be fooled by sub-strings,
	// etc:
	pbyStart = pbyExtensions;
	for(;;) 
	{
		pbyWhere = (GLubyte *) strstr((const char *) pbyStart, pbyExtension);
		if(!pbyWhere)
			break;
		pbyTerminator = pbyWhere+strlen(pbyExtension);
		if(pbyWhere == pbyStart || *(pbyWhere - 1) == ' ')
			if(*pbyTerminator == ' ' || *pbyTerminator == '\0')
				return 1;
		pbyStart = pbyTerminator;
	}
	return 0;
} // end AS_ENGINE::IsExtensionSupported()

void AS_ENGINE::InitExtensions(void)
{ // begin AS_ENGINE::InitExtensions()
	// Multi-texture:
    bMultitexSupported = FALSE;
	if(!IsExtensionSupported("GL_ARB_multitexture"))
	{
		_AS->WriteLogMessage("Extension GL_ARB_multitexture not found!");
		_ASConfig->bMultitexturing = FALSE;
	}
	else
	{
		glActiveTextureARB = (PFNGLCLIENTACTIVETEXTUREARBPROC) wglGetProcAddress("glActiveTextureARB");
		glMultiTexCoord2fARB = (PFNGLMULTITEXCOORD2FARBPROC) wglGetProcAddress("glMultiTexCoord2fARB");
		glClientActiveTextureARB = (PFNGLACTIVETEXTUREARBPROC) wglGetProcAddress("glClientActiveTextureARB");
		if(!glActiveTextureARB || !glMultiTexCoord2fARB || !glClientActiveTextureARB)
		{
			_AS->WriteLogMessage("Couldn't use extension GL_ARB_multitexture!");
			_ASConfig->bMultitexturing = FALSE;
		}
		else
			bMultitexSupported = TRUE;
	}

	// Compiled-vertex-arrays:
	bCompiledVertexArraySupported = FALSE;
	if(!IsExtensionSupported("GL_EXT_compiled_vertex_array"))
	{
		_AS->WriteLogMessage("Extension GL_EXT_compiled_vertex_array not found!");
		_ASConfig->bMultitexturing = FALSE;
	}
	else
	{
		glLockArraysEXT = (PFNGLLOCKARRAYSEXTPROC) wglGetProcAddress("glLockArraysEXT");
		glUnlockArraysEXT = (PFNGLUNLOCKARRAYSEXTPROC) wglGetProcAddress("glUnlockArraysEXT");
		if(!glLockArraysEXT || !glUnlockArraysEXT)
			_AS->WriteLogMessage("Couldn't use extension GL_EXT_compiled_vertex_array!");
		else
			bCompiledVertexArraySupported = TRUE;
	}
} // end AS_ENGINE::InitExtensions()


// Functions: *****************************************************************
// Temporarily draw function:
HRESULT ASDraw(AS_WINDOW *pWindow)
{ // begin ASDraw()
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	ASSwapBuffers(*pWindow->GethDC(), pWindow, FALSE);
	return 0;
} // end ASDraw()

// Temporarily check function:
HRESULT ASCheck(AS_WINDOW *pWindow)
{ // begin ASCheck()
	return 0;
} // end ASCheck()

void ASSwapBuffers(HDC hDC, AS_WINDOW *pWindow, BOOL bShowInfo)
{ // begin ASSwapBuffers()
	char byTemp[256];

	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glDisable(GL_LIGHTING);

	// Deactivate all lights:
	if(_ASConfig->byLight)
	{
		for(int i = 0; i < 8; i++)
			glDisable(GL_LIGHT0+i);
	}
	_AS->iActiveLights = 0;

	glColor4f(1.0f, 1.0f, 1.0f, 0.95f);
	if(_ASConfig->bShowFPS && bShowInfo)
	{ // Display FPS:
		sprintf(byTemp, "FPS: %d", _AS->GetFPS());
		if(!pWindow)
			ASPrint(10, 10, byTemp, 0);
		else
			pWindow->Print(10, 10, byTemp, 0, 0);
	}
	if(_ASConfig->bShowCulledObjects && bShowInfo)
	{ // Display culled objects:
		sprintf(byTemp, "Culled: %d", iASCulledObjects);
		if(!pWindow)
			ASPrint(100, 10, byTemp, 0);
		else
			pWindow->Print(100, 10, byTemp, 0, 0);
	}
	if(bSpeedControl && (iSpeedFactor > 1 || iSpeedFactor < -1))
	{
		sprintf(byTemp, "*%d", iSpeedFactor);
		if(!pWindow)
			ASPrint(10, 30, byTemp, 0);
		else
			pWindow->Print(10, 30, byTemp, 0, 0);
	}
	glFlush();
	SwapBuffers(hDC);

	// Check for screenshot:
	if(_AS->bMakeScreenshot)
	{
		_AS->bMakeScreenshot = FALSE;
		pWindow->MakeScreenshot(NULL);
	}
} // end ASSwapBuffers()

char *ASGetFileName(HWND hWnd, char *pbyTitle, char *pbyFilter,
					BOOL bMode, BOOL bMultiSelect, char *pbyInitalDir)
{ // begin ASGetFileName()
    static char file[256];
    static char fileTitle[256];
    OPENFILENAME ofn;

    lstrcpy( file, "");
    lstrcpy( fileTitle, "");
    ofn.lStructSize       = sizeof(OPENFILENAME);
    ofn.hwndOwner         = hWnd;
#ifdef WIN32
    ofn.hInstance         = (HINSTANCE) GetWindowLong(hWnd, GWL_HINSTANCE);
#else
    ofn.hInstance         = (HINSTANCE) GetWindowWord(hWnd, GWW_HINSTANCE);
#endif
    ofn.lpstrFilter       = pbyFilter;
    ofn.lpstrCustomFilter = (LPSTR) NULL;
    ofn.nMaxCustFilter    = 0L;
    ofn.nFilterIndex      = 1L;
    ofn.lpstrFile         = file;
    ofn.nMaxFile          = sizeof(file);
    ofn.lpstrFileTitle    = fileTitle;
    ofn.nMaxFileTitle     = sizeof(fileTitle);
    ofn.lpstrInitialDir   = pbyInitalDir;
    ofn.lpstrTitle        = pbyTitle;
    ofn.nFileOffset       = 0;
    ofn.nFileExtension    = 0;
    ofn.lpstrDefExt       = pbyFilter;
	ofn.lCustData         = 0;
	ofn.Flags = OFN_PATHMUSTEXIST | OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_NONETWORKBUTTON;
    if(!bMode) // We load a file...
		ofn.Flags |= OFN_FILEMUSTEXIST;
	if(bMultiSelect)
		ofn.Flags |= OFN_ALLOWMULTISELECT;
    if (GetOpenFileName(&ofn))
	    return (char *) ofn.lpstrFile;
	return NULL;
} // end ASGetFileName()

void ASLoadTextures(char (*byFilename)[256], int iTextures, AS_TEXTURE *pTexture)
{ // begin ASLoadTextures()
	AS_PROGRESS_WINDOW ProgressWindow;
	AS_TEXTURE *pTextureT;
	char byTemp[256];

	ProgressWindow.CreateProgressWindow("Textures");
	ProgressWindow.SetTask("Load textures...");
	ProgressWindow.SetProgress(0);

	_AS->WriteLogMessage("Load textures");
	for(int i = 0; i < iTextures; i++)
	{
		pTextureT = &pTexture[i];
		ProgressWindow.SetSubTask("%s", pTextureT->byFilename);
		ProgressWindow.SetProgress((UINT) (((float) i/iTextures)*100));
		sprintf(byTemp, "%s%s\\%s", _AS->pbyProgramPath, _AS->pbyBitmapsFile, byFilename[i]);
		_AS->WriteLogMessage("Load texture: %s", byTemp);
		strcpy(pTextureT->byFilename, byTemp);
		if(ASCheckStringEnding(byTemp, "jpg"))
			ASLoadJpegRGB(pTextureT, byTemp);
		else
		if(ASCheckStringEnding(byTemp, "bmp"))
			ASLoadBmp(pTextureT, byTemp);
		else
		if(ASCheckStringEnding(byTemp, "ppm"))
			ASLoadPpm(pTextureT, byTemp);
		else
		if(ASCheckStringEnding(byTemp, "tga"))
			ASLoadTga(pTextureT, byTemp);
		if(!pTextureT->iWidth)
			_AS->WriteLogMessage("Couldn't load that texture!");
	}
} // begin ASLoadTextures()

void ASDestroyTextures(int iTextures, AS_TEXTURE *Texture)
{ // begin ASDestroyTextures()
	for(int i = 0; i < iTextures; i++)
		SAFE_DELETE(Texture[i].pbyData);
} // end ASDestroyTextures()

void ASGenOpenGLTextures(int iTextures, AS_TEXTURE *Texture)
{ // begin ASGenOpenGLTextures()
	AS_PROGRESS_WINDOW ProgressWindow;
	AS_TEXTURE *pTextureT;

	ProgressWindow.CreateProgressWindow("OpenGL");
	ProgressWindow.SetTask("Generate OpenGL  textures...");
	ProgressWindow.SetProgress(0);

	if(!Texture[0].pbyData)
		return;
	_AS->WriteLogMessage("Generate OpenGL textures");
	for(int i = 0; i < iTextures; i++)
	{
		pTextureT = &Texture[i];
		ProgressWindow.SetSubTask("%s", pTextureT->byFilename);
		ProgressWindow.SetProgress((UINT) (((float) i/iTextures)*100));
		glGenTextures(1, &pTextureT->iOpenGLID);
		glBindTexture(GL_TEXTURE_2D, pTextureT->iOpenGLID);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
		if(_ASConfig->bUseMipmaps && !pTextureT->bNoMipmap)
		{
			if(_ASConfig->bFastTexturing)
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST_MIPMAP_NEAREST);
				gluBuild2DMipmaps(GL_TEXTURE_2D, pTextureT->byColorComponents, pTextureT->iWidth,
								  pTextureT->iHeight, pTextureT->iFormat, GL_UNSIGNED_BYTE,
								  pTextureT->pbyData);
			}
			else
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);
				gluBuild2DMipmaps(GL_TEXTURE_2D, pTextureT->byColorComponents, pTextureT->iWidth,
								  pTextureT->iHeight, pTextureT->iFormat, GL_UNSIGNED_BYTE,
								  pTextureT->pbyData);
			}
		}
		else
		{
			if(_ASConfig->bFastTexturing)
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
				glTexImage2D(GL_TEXTURE_2D, 0, pTextureT->byColorComponents, pTextureT->iWidth,
							 pTextureT->iHeight, 0, pTextureT->iFormat, GL_UNSIGNED_BYTE,
							 pTextureT->pbyData);
			}
			else
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
				glTexImage2D(GL_TEXTURE_2D, 0, pTextureT->byColorComponents, pTextureT->iWidth,
							 pTextureT->iHeight, 0, pTextureT->iFormat, GL_UNSIGNED_BYTE,
							 pTextureT->pbyData);
			}
		}
	}
} // end ASGenOpenGLTextures()

void ASDestroyOpenGLTextures(int iTextures, AS_TEXTURE *Texture)
{ // begin ASDestroyOpenGLTextures()
	if(!Texture[0].pbyData)
		return;
	for(int i = 0; i < iTextures; i++)
		glDeleteTextures(1, &Texture[i].iOpenGLID);
} // end ASDestroyOpenGLTextures()

///////////////////////////////////////////////////////////////////////////////
// Make sure dimension is a power of 2:
int ASCheckTextureSize(int iX)
{ // begin ASCheckTextureSize()
    if (iX == 2 || iX == 4 || 
        iX == 8 || iX == 16 || 
        iX == 32 || iX == 64 ||
        iX == 128 || iX == 256 ||
		iX == 512 || iX == 1024)
        return true;
	return false;
} // end ASCheckTextureSize()

///////////////////////////////////////////////////////////////////////////////
// Loads a jpg texture:
BOOL ASLoadJpegRGB(AS_TEXTURE *pTexture, char *pbyFilename)
{ // begin ASLoadJpegRGB()
	JPEG_CORE_PROPERTIES jcProps;
	
	_AS->WriteLogMessage("Load jpg: %s", pbyFilename);
	memset(&jcProps, 0, sizeof(JPEG_CORE_PROPERTIES));
	ijlInit(&jcProps);
	jcProps.JPGFile = pbyFilename;
	ijlRead(&jcProps, IJL_JFILE_READPARAMS);

	pTexture->iWidth = (int) jcProps.JPGWidth;
	pTexture->iHeight = (int) jcProps.JPGHeight;

	// Make sure dimension is a power of 2:
    if(!ASCheckTextureSize(pTexture->iWidth) || !ASCheckTextureSize(pTexture->iHeight))
		_AS->WriteLogMessage("Texture size is no dimension of 2. Maybe there could be some troubles with it!");
	if(pTexture->iWidth > _AS->iMaxTextureSize || pTexture->iHeight > _AS->iMaxTextureSize)
		_AS->WriteLogMessage("Texture size is to large for that system! (max: %dx%d)", _AS->iMaxTextureSize, _AS->iMaxTextureSize);

	// Setup texture information:
	pTexture->iFormat = GL_RGB;
	pTexture->iImageBits = 24;
	pTexture->byColorComponents = 3;

	pTexture->pbyData = (BYTE *) malloc(pTexture->iWidth*pTexture->iHeight*pTexture->byColorComponents);
	jcProps.DIBWidth = jcProps.JPGWidth;
	jcProps.DIBHeight = jcProps.JPGHeight;
	jcProps.DIBChannels = 3;
	jcProps.DIBColor = IJL_RGB;
	jcProps.DIBPadBytes = 0;
	jcProps.DIBBytes = (BYTE *) pTexture->pbyData;
	jcProps.JPGColor = IJL_YCBCR;
	if(ijlRead(&jcProps, IJL_JFILE_READWHOLEIMAGE) != IJL_OK)
	{
		SAFE_DELETE(pTexture->pbyData);
		return true;
	}
	ijlFree(&jcProps);
	
	return false;
} // end ASLoadJpegRGB()

///////////////////////////////////////////////////////////////////////////////
// Loads a bmp texture:
BOOL ASLoadBmp(AS_TEXTURE *pTexture, char *pbyFilename)
{ // begin ASLoadBmp()
	AUX_RGBImageRec *pImage;
	int i;

	if(!(pImage = auxDIBImageLoad(pbyFilename)))
		return true;

	// Get texture dimension:
	pTexture->iWidth = pImage->sizeX;
	pTexture->iHeight = pImage->sizeY;

	// Setup texture information:
	pTexture->iFormat = GL_RGB;
	pTexture->iImageBits = 24;
	pTexture->byColorComponents = 3;

	// Make sure dimension is a power of 2:
	if(!ASCheckTextureSize(pTexture->iWidth) || !ASCheckTextureSize(pTexture->iHeight))
		_AS->WriteLogMessage("Texture size is no dimension of 2. Maybe there could be some troubles with it!");
	if(pTexture->iWidth > _AS->iMaxTextureSize || pTexture->iHeight > _AS->iMaxTextureSize)
		_AS->WriteLogMessage("Texture size is to large for that system! (max: %dx%d)", _AS->iMaxTextureSize, _AS->iMaxTextureSize);
	
	pTexture->pbyData = (BYTE *) malloc(pTexture->iWidth*pTexture->iHeight*pTexture->byColorComponents);

	// Get the fliped texture data:
	for(i = 0; i < pTexture->iHeight; i++)
		memcpy(&pTexture->pbyData[pTexture->byColorComponents*i*pTexture->iWidth],
			   &pImage->data[pTexture->byColorComponents*(pTexture->iHeight-i-1)*pTexture->iWidth],
			   pTexture->byColorComponents*pTexture->iWidth);

	free(pImage->data);

	return false;
} // end ASLoadBmp()

///////////////////////////////////////////////////////////////////////////////
// Loads a ppm texture:
BOOL ASLoadPpm(AS_TEXTURE *pTexture, char *pbyFilename)
{ // begin ASLoadPpm()
	int x, y;
	FILE *fp;
	
	fp = fopen(pbyFilename, "rb");
	if(!fp)
		return true;
	
	// Get the PPM bitmap size:
	fscanf(fp, "P6\n%d %d\n255\n", &pTexture->iWidth, &pTexture->iHeight);
	pTexture->iFormat = GL_RGB;
	pTexture->iImageBits = 16;
	pTexture->byColorComponents = 3;

	// Go sure dimension is a power of 2:
	if(!ASCheckTextureSize(pTexture->iWidth) || !ASCheckTextureSize(pTexture->iHeight))
		_AS->WriteLogMessage("Texture size is no dimension of 2. Maybe there could be some troubles with it!");
	if(pTexture->iWidth > _AS->iMaxTextureSize || pTexture->iHeight > _AS->iMaxTextureSize)
		_AS->WriteLogMessage("Texture size is to large for that system! (max: %dx%d)", _AS->iMaxTextureSize, _AS->iMaxTextureSize);

	pTexture->pbyData = (BYTE *) malloc(pTexture->iWidth*pTexture->iHeight*3);
	if(!pTexture->pbyData)
		return true;

	// Now load in the bitmap:
	for(y = 0; y < pTexture->iHeight; y++)
	{
		for(x = 0; x < pTexture->iWidth; x++)
		{
			pTexture->pbyData[(y*pTexture->iWidth+x)*3] = fgetc(fp);
			pTexture->pbyData[(y*pTexture->iWidth+x)*3+1] = fgetc(fp);
			pTexture->pbyData[(y*pTexture->iWidth+x)*3+2] = fgetc(fp);
		}
	}
	fclose(fp);

	return false;
} // end ASLoadPpm()

///////////////////////////////////////////////////////////////////////////////
// Loads up a targa file. Supported types are 8,24 and 32 uncompressed images.  
BOOL ASLoadTga(AS_TEXTURE *pTexture, char *pbyFilename)
{ // begin ASLoadTga()
    BYTE byType[4], byInfo[7];
	BYTE byTemp, *pbyData;
	int i, iSize, iBread;
    FILE *fp;

    if(!(fp = fopen(pbyFilename, "r+bt")))
        return true;
        
    fread(&byType, sizeof(BYTE), 3, fp); // Read in colormap info and image type, byte 0 ignored
    fseek(fp, 12, SEEK_SET); // Seek past the header and useless info
    fread(&byInfo, sizeof(BYTE), 6, fp);

    if(byType[1] != 0 || (byType[2] != 2 && byType[2] != 3))
        return true;
	
    pTexture->iWidth = byInfo[0]+byInfo[1]*256; 
    pTexture->iHeight = byInfo[2]+byInfo[3]*256;
    
	// Make sure dimension is a power of 2:
    if(!ASCheckTextureSize(pTexture->iWidth) || !ASCheckTextureSize(pTexture->iHeight))
		_AS->WriteLogMessage("Texture size is no dimension of 2. Maybe there could be some troubles with it!");
	if(pTexture->iWidth > _AS->iMaxTextureSize || pTexture->iHeight > _AS->iMaxTextureSize)
		_AS->WriteLogMessage("Texture size is to large for that system! (max: %dx%d)", _AS->iMaxTextureSize, _AS->iMaxTextureSize);

    pTexture->iImageBits = byInfo[4]; 
    iSize = pTexture->iWidth*pTexture->iHeight;

    // Make sure we are loading a supported type:
    if(pTexture->iImageBits != 32 && pTexture->iImageBits != 24 && pTexture->iImageBits != 8)
        return true;
	pTexture->byColorComponents = (char) pTexture->iImageBits/8;
	
	// Get texture data:
    switch(pTexture->iImageBits)
	{
		case 32:
			if(!(pbyData = (BYTE *) malloc(iSize*4)))
				return true; 
			if(!(pTexture->pbyData = (BYTE *) malloc(iSize*4)))
				return true; 

			iBread = fread(pbyData, sizeof(BYTE), iSize*4, fp); 

			// TGA is stored in BGRA:
			if(iBread != iSize*4)
			{
				free(pbyData);
				free(pTexture->pbyData);
				return true;
			}

			for(i = 0; i < iSize*4; i += 4)
			{
				byTemp = pbyData[i];
				pbyData[i] = pbyData[i+2];
				pbyData[i+2] = byTemp;
			}

			pTexture->iFormat = GL_RGBA;
		break;

		case 24:
			if(!(pbyData = (BYTE *) malloc(iSize*3)))
				return true; 
			if(!(pTexture->pbyData = (BYTE *) malloc(iSize*3)))
				return true; 

			iBread = fread(pbyData, sizeof(BYTE), iSize*3, fp); 

			// TGA is stored in BGR:
			if(iBread != iSize*3)
			{
				free(pbyData);
				free(pTexture->pbyData);
				return true;
			}

			for(i = 0; i < iSize*3; i += 3)
			{
				byTemp = pbyData[i];
				pbyData[i] = pbyData[i+2];
				pbyData[i+2] = byTemp;
			}

			pTexture->iFormat = GL_RGB;
		break;
		
		case 8:
			if(!(pbyData = (BYTE *) malloc(iSize)))
				return true; 
			if(!(pTexture->pbyData = (BYTE *) malloc(iSize)))
				return true; 

			iBread = fread(pbyData, sizeof(BYTE), iSize, fp); 

			if(iBread != iSize)
			{
				free(pbyData);
				free(pTexture->pbyData);
				return true;
			}

			pTexture->iFormat = GL_LUMINANCE;
		break;

		default: return true;
	}

    fclose(fp);

	// Flip texture data:
	for(i = 0; i < pTexture->iHeight; i++)
		memcpy(&pTexture->pbyData[pTexture->byColorComponents*i*pTexture->iWidth],
			   &pbyData[pTexture->byColorComponents*(pTexture->iHeight-i-1)*pTexture->iWidth],
			   pTexture->byColorComponents*pTexture->iWidth);
	free(pbyData);
    
	return false;
} // end ASLoadTga()

///////////////////////////////////////////////////////////////////////////////
// Saves a ppm texture:
void ASSavePpm(AS_TEXTURE *pTextureT, char *pbyFilename)
{ // begin ASSavePpm()
	int x, y, c;
	FILE *fp;

	if(!pTextureT->pbyData)
		return;

	fp = fopen(pbyFilename, "wb");
	if(!fp)
		return;

	// Write the PPM file:
	fprintf (fp, "P6\n%d %d\n255\n", pTextureT->iWidth, pTextureT->iHeight);
	for(y = 0; y < pTextureT->iHeight; y++)
	{
		for(x = 0; x < pTextureT->iWidth; x++)
		{
			c = 0xff & pTextureT->pbyData[((pTextureT->iHeight-1-y)*pTextureT->iWidth+x)*3];
			fputc(c, fp);
			c = 0xff & pTextureT->pbyData[((pTextureT->iHeight-1-y)*pTextureT->iWidth+x)*3+1];
			fputc (c, fp);
			c = 0xff & pTextureT->pbyData[((pTextureT->iHeight-1-y)*pTextureT->iWidth+x)*3+2];
			fputc(c, fp);
		}
	}
	fclose(fp);
} // end ASSavePpm()

DWORD ASGetCpuSpeed(void)
{ // begin ASGetCpuSpeed()
  int timeStart = 0;
  int timeStop = 0;
  unsigned long StartTicks = 0;
  unsigned long EndTicks = 0;
  unsigned long TotalTicks = 0;
  unsigned long cpuSpeed = 0;

  timeStart = timeGetTime();
  for(;;)
  {
    timeStop = timeGetTime();
    if((timeStop-timeStart) > 1)
	{ // rollover past 1
		__asm
		{
			xor eax, eax
			xor ebx, ebx
			xor ecx, ecx
			xor edx, edx
			_emit 0x0f // CPUID
			_emit 0xa2
			_emit 0x0f // RTDSC
			_emit 0x31
			mov [StartTicks], eax // Tick counter starts here
		}
		break;
    }
  }
  timeStart = timeStop;
  for(;;)
  {
    timeStop = timeGetTime();
    if((timeStop-timeStart) > 1000)
	{ // one second
		__asm
		{
			xor eax, eax
			xor ebx, ebx
			xor ecx, ecx
			xor edx, edx
			_emit 0x0f
			_emit 0xa2
			_emit 0x0f
			_emit 0x31
			mov [EndTicks], eax
		}
      break;
    }
  }
  TotalTicks = EndTicks-StartTicks; // total
  cpuSpeed = TotalTicks/1000000; // speed
  return((DWORD) cpuSpeed);
} // end ASGetCpuSpeed()

void ASRemoveDirectory(char *pbyFilename)
{ // begin ASRemoveDirectory()
	WIN32_FIND_DATA FindFileData;
	char byTemp[256];
	HANDLE Find;
	                   
	// Delete all files in this dictory:
    sprintf(byTemp, "%s*.*", pbyFilename);
	Find = FindFirstFile(byTemp, &FindFileData);
	for(;;)
	{
		if(FindFileData.cFileName[0] != '.' && FindFileData.dwFileAttributes == FILE_ATTRIBUTE_DIRECTORY)
		{ // We found a new sub directory:
			sprintf(byTemp, "%s%s\\", pbyFilename, FindFileData.cFileName);
			ASRemoveDirectory(byTemp);
		}
		else
		{
			sprintf(byTemp, "%s%s", pbyFilename, FindFileData.cFileName);
			remove(byTemp);
		}
		if(!FindNextFile(Find, &FindFileData))
			break;
	}
	FindClose(Find);
	// Remove the empty dictory:
	RemoveDirectory(pbyFilename);
} // end ASRemoveDirectory()

///////////////////////////////////////////////////////////////////////////////
// Checks if a string ends which a given string:
BOOL ASCheckStringEnding(char *pbyText, char byEnding[256])
{ // begin ASCheckStringEnding()
	_strlwr(pbyText);
	for(int i = 0; i < (signed) strlen(byEnding); i++)
	{
		if(pbyText[strlen(pbyText)-(strlen(byEnding)-i)] != byEnding[i])
			break;
	}
	if(i == (signed) strlen(byEnding))
	   return true;

	return false;
} // end ASCheckStringEnding()

void ASDrawBoundingBox(float fBox[2][3], float fScale)
{ // begin ASDrawBoundingBox()
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_LIGHTING);
	glDepthMask(FALSE);
	glLineWidth(2.0f);

	// Left side:
	glBegin(GL_LINE_LOOP);
		glVertex3f(fBox[0][X], fBox[0][Y], fBox[0][Z]);
		glVertex3f(fBox[0][X], fBox[1][Y], fBox[0][Z]);
		glVertex3f(fBox[1][X], fBox[1][Y], fBox[0][Z]);
		glVertex3f(fBox[1][X], fBox[0][Y], fBox[0][Z]);
	glEnd();

	// Right side:
	glBegin(GL_LINE_LOOP);
		glVertex3f(fBox[0][X], fBox[0][Y], fBox[1][Z]);
		glVertex3f(fBox[0][X], fBox[1][Y], fBox[1][Z]);
		glVertex3f(fBox[1][X], fBox[1][Y], fBox[1][Z]);
		glVertex3f(fBox[1][X], fBox[0][Y], fBox[1][Z]);
	glEnd();

	// The other four lines:
	glBegin(GL_LINES);
		glVertex3f(fBox[0][X], fBox[0][Y], fBox[0][Z]);
		glVertex3f(fBox[0][X], fBox[0][Y], fBox[1][Z]);
		glVertex3f(fBox[0][X], fBox[1][Y], fBox[0][Z]);
		glVertex3f(fBox[0][X], fBox[1][Y], fBox[1][Z]);
		glVertex3f(fBox[1][X], fBox[1][Y], fBox[0][Z]);
		glVertex3f(fBox[1][X], fBox[1][Y], fBox[1][Z]);
		glVertex3f(fBox[1][X], fBox[0][Y], fBox[0][Z]);
		glVertex3f(fBox[1][X], fBox[0][Y], fBox[1][Z]);
	glEnd();
	glEnable(GL_TEXTURE_2D);
	ASEnableLighting();
	glLineWidth(1.0f);
	glDepthMask(TRUE);
} // end ASDrawBoundingBox()

BOOL ASCheckEnding(char *pbyText, char byEnding[256])
{ // begin ASCheckEnding()
	_strlwr(pbyText);
	for(int i = 0; i < (signed) strlen(byEnding); i++)
	{
		if(pbyText[strlen(pbyText)-(strlen(byEnding)-i)] != byEnding[i])
			break;
	}
	if(i == (signed) strlen(byEnding))
	   return TRUE;
	return FALSE;
} // end ASCheckEnding()
//-----------------------------------------------------------------------------
// File: AS_Camera.cpp
//-----------------------------------------------------------------------------

#include "AS_Engine.h"


// Variables: *****************************************************************
AS_CAMERA *_ASCamera;
///////////////////////////////////////////////////////////////////////////////


// Constructor:
AS_CAMERA::AS_CAMERA(void)
{ // begin AS_CAMERA::AS_CAMERA()
	memset(this, 0, sizeof(AS_CAMERA));
} // end AS_CAMERA::AS_CAMERA()

// Set current camera translation:
void AS_CAMERA::SetCameraTranslation(BOOL bOnlyRot)
{ // begin AS_CAMERA::SetCameraTranslation(()
	if(bOnlyRot)
	{
		glLoadIdentity();
		glRotatef(fRot[X]+vRotTemp.fX, 1.0f, 0.0f, 0.0f);
		glRotatef(fRot[Y]+180.0f+vRotTemp.fY, 0.0f, 1.0f, 0.0f);
		glRotatef(fRot[Z]+180.0f, 0.0f, 0.0f, 1.0f);
	}
	else
	{
		glLoadIdentity();
		glTranslatef(0.0f, 0.0f, fZoom);
		glRotatef(fRot[X]+vRotTemp.fX, 1.0f, 0.0f, 0.0f);
		glRotatef(fRot[Y]+180.0f+vRotTemp.fY, 0.0f, 1.0f, 0.0f);
		glRotatef(fRot[Z]+180.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(-Actor[0].vWorldPos.fX+vPos.fX+vPosTemp.fX-_ASCamera->vShakePos.fX*_ASCamera->fShakePower*5,
					 -Actor[0].vWorldPos.fY+vPos.fY+vPosTemp.fY-_ASCamera->vShakePos.fY*_ASCamera->fShakePower*5,
					 -Actor[0].vWorldPos.fZ);
	}
} // end AS_CAMERA::SetCameraTranslation()

void AS_CAMERA::SetStandartCamera(void)
{ // begin AS_CAMERA::SetStandartCamera()
	float fRotCos;
	
	memset(this, 0, sizeof(AS_CAMERA));
	fRot[X] = -40.0f;
	fZoom = -10.0f;
	fShakeSpeed = 5.0f;

	// Compute the real world position:
	fRotCos = (float) cos(-fRot[X]*PI/180);
	vWorldPos.fX = (Actor[0].vWorldPos.fX+vPos.fX)-fSin*fZoom*(1-fRotCos);
	vWorldPos.fY = (Actor[0].vWorldPos.fY+vPos.fY)-fCos*fZoom*(1-fRotCos);
	vWorldPos.fZ = Actor[0].vWorldPos.fZ+fZoom*fRotCos;
	vLastWorldPos = vWorldPos;
} // end AS_CAMERA::SetStandartCamera()

void AS_CAMERA::CalculateSinCos(void)
{ // begin AS_CAMERA::CalculateSinCos()
	// We should be in the range of 0.0 and 360.0:
	for(;;)
	{
		if(fRot[Z] < 0.0f)
			fRot[Z] += 360.0f;
		if(fRot[Z] > 360.0f)
			fRot[Z] -= 360.0f;
		if(fRot[Z] >= 0.0f && fRot[Z] <= 360.0f)
			break;
	}
	// This are the sin/cos depending of the current camera direction:
	fSin = (float) sin(fRot[Z]*DEG_TO_RAD);
	fSin90 = (float) sin((fRot[Z]+90.0f)*DEG_TO_RAD);
	fCos = (float) cos(fRot[Z]*DEG_TO_RAD);
	fCos90 = (float) cos((fRot[Z]+90.0f)*DEG_TO_RAD);
} // end AS_CAMERA::CalculateSinCos()

void AS_CAMERA::Check(void)
{ // begin AS_CAMERA::Check()
	AS_3D_VECTOR vVelocity, vDelta, vScaledPosition, vScaledVelocity,
				 vFinalPosition, vLastVelocity, vLastWorldPos,
				 vRayDirection;
	float fRotCos, fRotSin;
	int i;
	
	for(i = 0; i < 3; i++)
	{
		// Camera position:
		vPos.fV[i] -= vPos.fV[i]/10*((float) g_lDeltatime/100);
		vRotTemp.fV[i] -= vRotTemp.fV[i]/10*((float) g_lDeltatime/100);

		// Camera rotation:
		if(fRot2Velocity[i])
			fRot[i] += (float) g_lDeltatime/100*fRot2Velocity[i];

		// Rotate speed decrease:
		fRot2Velocity[i] -= fRot2Velocity[i]/20*((float) g_lDeltatime/30);
	}
	if(fZoomVelocity)
		fZoom += ((float) g_lDeltatime/1000)*fZoomVelocity;
	fZoomVelocity -= fZoomVelocity/20*((float) g_lDeltatime/30);
	if(fZoom > 0.0f)
	{
		fZoomVelocity = 0.0f;
		fZoom = 0.0f;
	}
	if(fZoom < -50.0f)
	{
		fZoomVelocity = 0.0f;
		fZoom = -50.0f;
	}

	if(g_lNow-lTimer1 > 10)
	{
		lTimer1 = g_lNow;
		for(i = 0; i < 3; i++)
			pCamera->vPosTemp.fV[i] = pCamera->vPosTemp.fV[i]/1.03f;
	}
	CalculateSinCos();
	
	if(!bPause)
	{
		// Camera shake effect:
		if(!fShakePower)
		{
			pCamera->vShakePos = pCamera->vNewShakePos = 0.0f;
			pCamera->fShakeSpeed = 0.0f;
		}
		else
		{
			for(i = 0; i < 3; i++)
			{
				if(pCamera->vLastShakePos.fV[i] > pCamera->vNewShakePos.fV[i])
				{
					pCamera->vShakePos.fV[i] -= (float) pCamera->fShakeSpeed*g_lDeltatime/10000;
					if(pCamera->vShakePos.fV[i] <= pCamera->vNewShakePos.fV[i])
					{
						pCamera->fShakeSpeed = 5.0f+((float) (rand() % 100)/1000);
						pCamera->vLastShakePos.fV[i] = pCamera->vShakePos.fV[i];
						if((rand() % 2))
							pCamera->vNewShakePos.fV[i] = (float) (rand() % 100)/10000.0f;
						else
							pCamera->vNewShakePos.fV[i] = -(float) (rand() % 100)/10000.0f;
					}
				}
				else
				{
					pCamera->vShakePos.fV[i] += (float) pCamera->fShakeSpeed*g_lDeltatime/10000;
					if(pCamera->vShakePos.fV[i] >= pCamera->vNewShakePos.fV[i])
					{
						pCamera->vLastShakePos.fV[i] = pCamera->vShakePos.fV[i];
						pCamera->fShakeSpeed = 5.0f+((float) (rand() % 100)/1000);
						if((rand() % 2))
							pCamera->vNewShakePos.fV[i] = (float) (rand() % 100)/10000.0f;
						else
							pCamera->vNewShakePos.fV[i] = -(float) (rand() % 100)/10000.0f;
					}
				}			
			}
		}
	}
			
	// Backup the last world position:
	vLastWorldPos = vWorldPos;

	// Compute the real world position:
	fRotCos = (float) cos(fRot[X]*DEG_TO_RAD);
	fRotSin = (float) sin(-fRot[X]*DEG_TO_RAD);
	vWorldPos.fX = (Actor[0].vWorldPos.fX+vPos.fX)-fSin*fZoom*fRotSin;
	vWorldPos.fY = (Actor[0].vWorldPos.fY+vPos.fY)-fCos*fZoom*fRotSin;
	vWorldPos.fZ = Actor[0].vWorldPos.fZ+fZoom*fRotCos;
	vWorldPosTemp = vWorldPos;

/* // Doesn't work right...

	// Compute the movement velocity:
	vVelocity = vWorldPos-vLastWorldPos;
	
	// Check now for collision with the level:
	// Setup bounding ellipsoid:
	memset(&ASCollisionPacket, 0, sizeof(AS_COLLISION_PACKET));
	ASCollisionPacket.vERadius.fX =
	ASCollisionPacket.vERadius.fY =
	ASCollisionPacket.vERadius.fZ = 0.5f;
	
	// Setup some general stuff:
	ASCollisionPacket.bFoundACollision = FALSE;

	// The first thing we do is scale the player and his velocity to
	// ellipsoid space:
	ASCollisionPacket.vLastSafePosition = vScaledPosition = vLastWorldPos/ASCollisionPacket.vERadius;
	vScaledVelocity = vVelocity*ASCollisionPacket.vERadius;

	// Call the recursive collision response function:
	vWorldPos = Level.CollideWithWorld(vScaledPosition, vScaledVelocity, TRUE);

	// When the function returns the result is still in ellipsoid space, so
	// we have to scale it back to R3 before we return it:
	vWorldPos = vWorldPos*ASCollisionPacket.vERadius;
	ASCollisionPacket.vLastSphereCollisionPoint = ASCollisionPacket.vLastSphereCollisionPoint*ASCollisionPacket.vERadius;

	if(ASCollisionPacket.bFoundACollision)
		fRot[X] += (float) g_lDeltatime/100; // Lift the camera
		*/

	// Check if the camera is under the water:
	if(vWorldPos.fX >= 0.0f && vWorldPos.fX <= Level.fWidth &&
	   vWorldPos.fY >= 0.0f && vWorldPos.fY <= Level.fHeight)
	{
		if(Level.fCurrentWaterHeight < vWorldPos.fZ+0.05f)
			bUnderWater = TRUE;
		else
			bUnderWater = FALSE;
	}
	else
		bUnderWater = FALSE;
	
	// Create the under water effect:
	if(!bUnderWater)
	{
		for(i = 0; i < 3; i++)
		{
			fWaterScale[i] = fWaterLastScale[i] =
			fWaterToScale[i] = fWaterScaleVelocity[i] = 0.0f;
		}
		return;
	}
	if(bPause)
		return;

	// Create the under water effect:
	if(fWaterLastScale[0] > fWaterToScale[0])
	{
		fWaterScaleVelocity[0] -= (float) g_lDeltatime/100000;
		fWaterScale[0] += fWaterScaleVelocity[0];
		if(fWaterScale[0] <= fWaterToScale[0])
		{
			fWaterScaleVelocity[0] *= 0.6f;
			if(!(rand() % 2))
				fWaterToScale[0] = -(float) (rand() % 1000)/100;
			else
				fWaterToScale[0] = (float) (rand() % 1000)/100;
		}
	}
	else
	{
		fWaterScaleVelocity[0] += (float) g_lDeltatime/100000;
		fWaterScale[0] += fWaterScaleVelocity[0];
		if(fWaterScale[0] >= fWaterToScale[0])
		{
			fWaterScaleVelocity[0] *= 0.6f;
			if(!(rand() % 2))
				fWaterToScale[0] = -(float) (rand() % 1000)/800;
			else
				fWaterToScale[0] = (float) (rand() % 1000)/800;
		}
	}
	for(i = 1; i < 3; i++)
	{
		if(fWaterLastScale[i] > fWaterToScale[i])
		{
			fWaterScaleVelocity[i] -= (float) g_lDeltatime/1000;
			fWaterScale[i] += fWaterScaleVelocity[i];
			if(fWaterScale[i] <= fWaterToScale[i])
			{
				fWaterScaleVelocity[i] *= 0.8f;
				if(!(rand() % 2))
					fWaterToScale[i] = -(float) (rand() % 1000)/50;
				else
					fWaterToScale[i] = (float) (rand() % 1000)/50;
			}
		}
		else
		{
			fWaterScaleVelocity[i] += (float) g_lDeltatime/1000;
			fWaterScale[i] += fWaterScaleVelocity[i];
			if(fWaterScale[i] >= fWaterToScale[i])
			{
				fWaterScaleVelocity[i] *= 0.8f;
				if(!(rand() % 2))
					fWaterToScale[i] = -(float) (rand() % 1000)/50;
				else
					fWaterToScale[i] = (float) (rand() % 1000)/50;
			}
		}
	}

} // end AS_CAMERA::Check()
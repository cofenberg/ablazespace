//-----------------------------------------------------------------------------
// File: AS_Quaternion.cpp
//-----------------------------------------------------------------------------

#include "AS_Engine.h"


// AS_QUATERNION functions: ***************************************************

AS_QUATERNION::AS_QUATERNION(void)
{ // begin AS_QUATERNION::AS_QUATERNION()
	Reset();
} // end AS_QUATERNION::AS_QUATERNION()

AS_QUATERNION::AS_QUATERNION(const AS_QUATERNION &CopyFrom)
{ // begin AS_QUATERNION::AS_QUATERNION()
	Set(CopyFrom);
} // end AS_QUATERNION::AS_QUATERNION()

AS_QUATERNION::AS_QUATERNION(float fX, float fY, float fZ)
{ // begin AS_QUATERNION::AS_QUATERNION()
	Set(fX, fY, fZ);
} // end AS_QUATERNION::AS_QUATERNION()

AS_QUATERNION::AS_QUATERNION(float fAngle, float fX, float fY, float fZ)
{ // begin AS_QUATERNION::AS_QUATERNION()
	Set(fAngle, fX, fY, fZ);
} // end AS_QUATERNION::AS_QUATERNION()

AS_QUATERNION &AS_QUATERNION::Reset(void)
{ // begin AS_QUATERNION::Reset()
	fQ[0] = 1.0f;
	fQ[1] = 0.0f;
	fQ[2] = 0.0f;
	fQ[3] = 0.0f;
	return *this;
} // end AS_QUATERNION::Reset()

AS_QUATERNION &AS_QUATERNION::Set(const AS_QUATERNION &CopyFrom)
{ // begin AS_QUATERNION::Set()
	fQ[0] = CopyFrom.fQ[0];
	fQ[1] = CopyFrom.fQ[1];
	fQ[2] = CopyFrom.fQ[2];
	fQ[3] = CopyFrom.fQ[3];
	return *this;
} // end AS_QUATERNION::Set()

AS_QUATERNION &AS_QUATERNION::Set(float fX, float fY, float fZ)
{ // begin AS_QUATERNION::Set()
	AS_QUATERNION xQ(fX, 1.0f, 0.0f, 0.0f);
	AS_QUATERNION yQ(fY, 0.0f, 1.0f, 0.0f);
	AS_QUATERNION zQ(fZ, 0.0f, 0.0f, 1.0f);

	Set(xQ);
	PostMult(yQ);
	PostMult(zQ);
	return *this;
} // end AS_QUATERNION::Set()

AS_QUATERNION &AS_QUATERNION::Set(float fAngle, float fX, float fY, float fZ)
{ // begin AS_QUATERNION::Set()
	float fFactor = fX*fX+fY*fY+fZ*fZ;
	if(!fFactor)
		fFactor = (float) AS_EPSILON;

	float fScaleBy = (float) (1.0/ASFastSqrt(fFactor));
	fX = fX*fScaleBy;
	fY = fY*fScaleBy;
	fZ = fZ*fScaleBy;

	fQ[0] = (float) cos(fAngle/2.0f);

	float fSinHalfAngle = (float) sin(fAngle/2.0f);
	fQ[1] = fX*fSinHalfAngle;
	fQ[2] = fY*fSinHalfAngle;
	fQ[3] = fZ*fSinHalfAngle;

	return *this;
} // end AS_QUATERNION::Set()

AS_QUATERNION &AS_QUATERNION::PostMult(const AS_QUATERNION &Quat)
{ // begin AS_QUATERNION::PostMult()
	AS_QUATERNION TempQ(*this);
	MultAndSet(TempQ, Quat);

	return *this;
} // end AS_QUATERNION::PostMult()()

AS_QUATERNION &AS_QUATERNION::MultAndSet(const AS_QUATERNION &Quat1, const AS_QUATERNION &Quat2)
{ // begin AS_QUATERNION::MultAndSet()
	fQ[0] = Quat2.fQ[0]*Quat1.fQ[0]
		   -Quat2.fQ[1]*Quat1.fQ[1]
		   -Quat2.fQ[2]*Quat1.fQ[2]
		   -Quat2.fQ[3]*Quat1.fQ[3];

	fQ[1] = Quat2.fQ[0]*Quat1.fQ[1]
		   +Quat2.fQ[1]*Quat1.fQ[0]
		   +Quat2.fQ[2]*Quat1.fQ[3]
		   -Quat2.fQ[3]*Quat1.fQ[2];

	fQ[2] = Quat2.fQ[0]*Quat1.fQ[2]
		   -Quat2.fQ[1]*Quat1.fQ[3]
		   +Quat2.fQ[2]*Quat1.fQ[0]
		   +Quat2.fQ[3]*Quat1.fQ[1];

	fQ[3] = Quat2.fQ[0]*Quat1.fQ[3]
		   +Quat2.fQ[1]*Quat1.fQ[2]
		   -Quat2.fQ[2]*Quat1.fQ[1]
		   +Quat2.fQ[3]*Quat1.fQ[0];

	return *this;
} // end AS_QUATERNION::MultAndSet()

AS_QUATERNION &AS_QUATERNION::Normalize(void)
{ // begin AS_QUATERNION::Normalize()
	float fFactor = fQ[0]*fQ[0]+
					fQ[1]*fQ[1]+
					fQ[2]*fQ[2]+
					fQ[3]*fQ[3];
	float fScaleBy = (float) (1.0/ASFastSqrt(fFactor));

	fQ[0] = fQ[0]*fScaleBy;
	fQ[1] = fQ[1]*fScaleBy;
	fQ[2] = fQ[2]*fScaleBy;
	fQ[3] = fQ[3]*fScaleBy;

	return *this;
} // end AS_QUATERNION::Normalize()

AS_QUATERNION AS_QUATERNION::Inversed(void)
{ // begin AS_QUATERNION::Inversed()
	AS_QUATERNION T;
	
	T.fQ[1] = -fQ[1];
	T.fQ[2] = -fQ[2];
	T.fQ[3] = -fQ[3];
	return T;
} // end AS_QUATERNION::Inversed()

float AS_QUATERNION::DotProduct(void)
{ // begin AS_QUATERNION::DotProduct()
	return fX*fX+fY*fY+fZ*fZ+fW*fW;
} // end AS_QUATERNION::DotProduct()

float AS_QUATERNION::DotProduct(AS_QUATERNION Q)
{ // begin AS_QUATERNION::DotProduct()
	return fX*Q.fX+fY*Q.fY+fZ*Q.fZ+fW*Q.fW;
} // end AS_QUATERNION::DotProduct()

float AS_QUATERNION::GetLength(void)
{ // begin AS_QUATERNION::GetLength()
	return (float) ASFastSqrt(fX*fX+fY*fY+fZ*fZ+fW*fW);
} // end AS_QUATERNION::GetLength()

void AS_QUATERNION::GetMatrix(AS_MATRIX *M)
{ // begin AS_QUATERNION::GetMatrix()
	Normalize();

	float fW = fQ[0];
	float fX = fQ[1];
	float fY = fQ[2];
	float fZ = fQ[3];

	float fXX = fX*fX;
	float fYY = fY*fY;
	float fZZ = fZ*fZ;


	M->fXX = 1.0f-2.0f*(fYY+fZZ);
	M->fYX = 2.0f*(fX*fY+fW*fZ);
	M->fZX = 2.0f*(fX*fZ-fW*fY);
	M->fWX = 0.0f;

	M->fXY = 2.0f*(fX*fY-fW*fZ);
	M->fYY = 1.0f-2.0f*(fXX+fZZ);
	M->fZY = 2.0f*(fY*fZ+fW*fX);
	M->fWY = 0.0f;

	M->fXZ = 2.0f*(fX*fZ+fW*fY);
	M->fYZ = 2.0f*(fY*fZ-fW*fX);
	M->fZZ = 1.0f-2.0f*(fXX+fYY);
	M->fWZ = 0.0f;

	M->fXW = 0.0f;
	M->fYW = 0.0f;
	M->fZW = 0.0f;
	M->fWW = 1.0f;
} // end AS_QUATERNION::GetMatrix()

void AS_QUATERNION::GetInvertedMatrix(AS_MATRIX *M)
{ // begin AS_QUATERNION::GetInvertedMatrix()
	Normalize();

	float fW = fQ[0];
	float fX = fQ[1];
	float fY = fQ[2];
	float fZ = fQ[3];

	float fXX = fX*fX;
	float fYY = fY*fY;
	float fZZ = fZ*fZ;

	M->fXX = -(1.0f-2.0f*(fYY+fZZ));
	M->fYX = -(2.0f*(fX*fY+fW*fZ));
	M->fZX = -(2.0f*(fX*fZ-fW*fY));
	M->fWX = 0.0f;

	M->fXY = 2.0f*(fX*fY-fW*fZ);
	M->fYY = 1.0f-2.0f*(fXX+fZZ);
	M->fZY = 2.0f*(fY*fZ+fW*fX);
	M->fWY = 0.0f;

	M->fXZ = 2.0f*(fX*fZ+fW*fY);
	M->fYZ = 2.0f*(fY*fZ-fW*fX);
	M->fZZ = 1.0f-2.0f*(fXX+fYY);
	M->fWZ = 0.0f;

	M->fXW = 0.0f;
	M->fYW = 0.0f;
	M->fZW = 0.0f;
	M->fWW = 1.0f;
} // end AS_QUATERNION::GetInvertedMatrix()

void AS_QUATERNION::SetMatrix(AS_MATRIX M)
{ // begin AS_QUATERNION::SetMatrix()
	float fTr, fS, fQ[4];
    int i, j, k;
	int iNxt[3] = {1, 2, 0};

	fTr = M.fXX+M.fYY+M.fZZ;

	// Check the diagonal:
	if(fTr > 0.0f)
	{
		fS = (float) ASFastSqrt(fTr+1.0f);
		fW = fS/2.0f;
		fS = 0.5f/fS;
		fX = (M.fZY-M.fYZ)*fS;
		fY = (M.fXZ-M.fZX)*fS;
		fZ = (M.fYX-M.fXY)*fS;
	}
	else
	{ // Diagonal is negative:
		i = 0;
		if(M.fYY > M.fXX)
			i = 1;
		if(M.fZZ > M.fM44[i][i])
			i = 2;
		
		j = iNxt[i];
		k = iNxt[j];

		fS = (float) ASFastSqrt((M.fM44[i][i]-(M.fM44[j][j]+M.fM44[k][k]))+1.0f);

		fQ[i] = fS*0.5f;

		if(fS != 0.0)
			fS = 0.5f/fS;

		fQ[3] = (M.fM44[j][k] - M.fM44[k][j])*fS;
		fQ[j] = (M.fM44[i][j] + M.fM44[j][i])*fS;
		fQ[k] = (M.fM44[i][k] + M.fM44[k][i])*fS;

		fX = fQ[0];
		fY = fQ[1];
		fZ = fQ[2];
		fW = fQ[3];
  }
} // end AS_QUATERNION::SetMatrix()

void AS_QUATERNION::GetAxisAngle(float &fAxisX, float &fAxisY, float &fAxisZ, float &fRotAngle)
{ // begin AS_QUATERNION::GetAxisAngle()
	float fLenOfVector = fQ[1]*fQ[1]+fQ[2]*fQ[2]+fQ[3]*fQ[3];

	if(fLenOfVector < AS_EPSILON)
	{
		fAxisX = 1.0f;
		fAxisY = 0.0f;
		fAxisZ = 0.0f;
		fRotAngle = 0.0f;
	}
	else
	{
		float fInvLen = (float) (1.0/ASFastSqrt(fLenOfVector));
		fAxisX = fQ[1]*fInvLen;
		fAxisY = fQ[2]*fInvLen;
		fAxisZ = fQ[3]*fInvLen;
		fRotAngle = (float) (2.0f*acos(fQ[0]));
	}
} // end AS_QUATERNION::GetAxisAngle()

void AS_QUATERNION::GetDirectionVector(AS_3D_VECTOR *vDir)
{ /// begin AS_QUATERNION::GetDirectionVector()
	Normalize();

	float fW = fQ[0];
	float fX = fQ[1];
	float fY = fQ[2];
	float fZ = fQ[3];

	(*vDir).fX = 2.0f*(fX*fZ-fW*fY);
	(*vDir).fY = 2.0f*(fY*fZ+fW*fX);
	(*vDir).fZ = 1.0f-2.0f*(fX*fX+fY*fY);
} // end AS_QUATERNION::GetDirectionVector()

void AS_QUATERNION::EulerToQuat(const float fEX, const float fEY, const float fEZ)
{ // begin AS_QUATERNION::EulerToQuat()
	double dEX, dEY, dEZ; // Temp half euler angles
	double dCR, dCP, dCY, dSR, dSP, dSY, dCPCY, dSPSY; // Temp vars in roll, pitch and yaw

	// Convert to rads and half them:
	dEX = DEG_TO_RAD*fEX/2.0f;
	dEY = DEG_TO_RAD*fEY/2.0f;
	dEZ = DEG_TO_RAD*fEZ/2.0f;

	dCR = cos(dEX);
	dCP = cos(dEY);
	dCY = cos(dEZ);

	dSR = sin(dEX);
	dSP = sin(dEY);
	dSY = sin(dEZ);

	dCPCY = dCP*dCY;
	dSPSY = dSP*dSY;

	fW = float(dCR*dCPCY + dSR*dSPSY);

	fX = float(dSR*dCPCY - dCR*dSPSY);
	fY = float(dCR*dSP*dSY + dSR*dCP*dSY);
	fZ = float(dCR*dCP*dSY - dSR*dSP*dCY);

	Normalize();
} // end AS_QUATERNION::EulerToQuat()

void AS_QUATERNION::GetEulerAngles(float &fX, float &fY, float &fZ)
{ // begin AS_QUATERNION::GetEulerAngles()
	AS_MATRIX Matrix;

	GetMatrix(&Matrix);
	Matrix.GetEulerAngles(fX, fY, fZ);
} // end AS_QUATERNION::GetEulerAngles()


//	fTime = -2 * (x*x*x) + 3 * (x*x);
//	t = 0.5 - 0.5 * cos(sin(x*PI)*PI);
//	fTime = x;

// Computes spherical linear interpolation between Q1 and Q2 with time 0-1
void AS_QUATERNION::Slerp(const AS_QUATERNION Q1, const AS_QUATERNION Q2, const float fTime)
{ // begin AS_QUATERNION::Slerp()
	float fOmega, fCosom, fSinom, fScale0, fScale1;
	FLOAT4 fFrom, fTo, fTo1;

	memcpy(&fFrom, Q1.fQ, sizeof(FLOAT4));
	memcpy(&fTo, Q2.fQ, sizeof(FLOAT4));

	enum {W, X, Y, Z};

	// Calc cosine:
	fCosom = fFrom[X]*fTo[X] + fFrom[Y]*fTo[Y] + fFrom[Z]*fTo[Z] + fFrom[W]*fTo[W];

	// Adjust signs: (if necessary)
	if(fCosom < 0.0f)
	{ 
		  fCosom = -fCosom; 
		  fTo1[0] = -fTo[X];
          fTo1[1] = -fTo[Y];
          fTo1[2] = -fTo[Z];
          fTo1[3] = -fTo[W];
	} 
	else 
	{
          fTo1[0] = fTo[X];
          fTo1[1] = fTo[Y];
          fTo1[2] = fTo[Z];
          fTo1[3] = fTo[W];
	}

	// Calculate coefficients:
	if((1.0f-fCosom) > AS_EPSILON)
	{ // Standard case: (slerp)
		fOmega = (float) acos(fCosom);
        fSinom = (float) sin(fOmega);
        fScale0 = (float) sin((1.0f-fTime)*fOmega)/fSinom;
        fScale1 = (float) sin(fTime*fOmega)/fSinom;
	} 
	else
	{   // "from" and "to" quaternions are very close 
		//  ... so we can do a linear interpolation:
		fScale0 = 1.0f-fTime;
        fScale1 = fTime;
	}

	// Calculate final values:
	fQ[X] = fScale0*fFrom[X] + fScale1*fTo1[0];
	fQ[Y] = fScale0*fFrom[Y] + fScale1*fTo1[1];
	fQ[Z] = fScale0*fFrom[Z] + fScale1*fTo1[2];
	fQ[W] = fScale0*fFrom[W] + fScale1*fTo1[3];
} // end AS_QUATERNION::Slerp()

void AS_QUATERNION::SquadSlerp(AS_QUATERNION a, AS_QUATERNION p, AS_QUATERNION q,
							   AS_QUATERNION b, float t)
{ // begin AS_QUATERNION::SquadSlerp()
	AS_QUATERNION ab;
	AS_QUATERNION pq;

	ab.Slerp(a, b, t);
	pq.Slerp(p, q, t);
	Slerp(ab, pq, 2*t*(1-t));
} // end AS_QUATERNION::SquadSlerp()

void AS_QUATERNION::Invert(void)
{ // begin AS_QUATERNION::Invert()
	float l, m;

	l = GetLength();
	if(fabs(l) < AS_EPSILON)
	{
		fX = fY = fZ = 0.0f;
		fW = 1.0f;
	}
	else
	{  
		m = 1.0f/l;
		fX = -fX*m;
		fY = -fY*m;
		fZ = -fZ*m;
		fW = fW*m;
	}
} // end AS_QUATERNION::Invert()

void AS_QUATERNION::Mult(AS_QUATERNION a, AS_QUATERNION b)
{ // begin AS_QUATERNION::Mult()
	fX = a.fW*b.fX + a.fX*b.fW + a.fY*b.fZ - a.fZ*b.fY;
	fY = a.fW*b.fY + a.fY*b.fW + a.fZ*b.fX - a.fX*b.fZ;
	fZ = a.fW*b.fZ + a.fZ*b.fW + a.fX*b.fY - a.fY*b.fX;
	fW = a.fW*b.fW - a.fX*b.fX - a.fY*b.fY - a.fZ*b.fZ;
} // end AS_QUATERNION::Mult()

void AS_QUATERNION::Ln(void)
{ // begin AS_QUATERNION::Ln()
	float om, s, t;

	s = (float) ASFastSqrt(fX*fX + fY*fY + fZ*fZ);
	om = (float) atan2(s, fW);
	if(fabs(s) < AS_EPSILON)
		t = 0.0f;
	else
		t = om/s;
	for(int i = 1; i < 4; ++i)
	  fQ[i] = fQ[i]*t;
	fW = 0.0f;
} // end AS_QUATERNION::Ln()

void AS_QUATERNION::LnDif(AS_QUATERNION a, AS_QUATERNION b)
{ // begin AS_QUATERNION::LnDif()
	AS_QUATERNION invp;

	for(int i = 0; i < 4; i++)
		invp.fQ[i] = a.fQ[i];
	invp.Invert();
	Mult(invp, b);
	Ln();
} // end AS_QUATERNION::LnDif()

void AS_QUATERNION::Exp(void)
{ // begin AS_QUATERNION::Exp()
	float om, sinom;

	om = (float) ASFastSqrt(fX*fX + fY*fY + fZ*fZ);
	if(fabs(om) < AS_EPSILON)
		sinom = 1.0f;
	else
		sinom = (float) sin(om)/om;
	for(int i = 1; i < 4; ++i)
	  fQ[i] = fQ[i]*sinom;
	fW = (float) cos(om);
} // end AS_QUATERNION::Exp()

void AS_QUATERNION::InnerPoint(AS_QUATERNION p, AS_QUATERNION q, AS_QUATERNION n)
{ // begin AS_QUATERNION::InnerPoint()
	AS_QUATERNION dn, dp, x;

	dn.LnDif(q, n);
	dp.LnDif(q, p);
	for(int i = 0; i < 4; i++)
		x.fQ[i] = -1.0f/4.0f*(dn.fQ[i]+dp.fQ[i]);
	x.Exp();
	Mult(q, x);
} // end AS_QUATERNION::InnerPoint()
//-----------------------------------------------------------------------------
// File: AS_Collision.cpp
//-----------------------------------------------------------------------------

#include "AS_Engine.h"


// Variables: *****************************************************************
AS_COLLISION_PACKET ASCollisionPacket;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
double ASIntersectRayPlane(AS_3D_VECTOR, AS_3D_VECTOR, AS_3D_VECTOR, AS_3D_VECTOR);
BOOL ASCheckPointInTriangle(AS_3D_VECTOR, AS_3D_VECTOR, AS_3D_VECTOR, AS_3D_VECTOR);
AS_3D_VECTOR ASClosestPointOnLine(AS_3D_VECTOR, AS_3D_VECTOR, AS_3D_VECTOR);
AS_3D_VECTOR ASClosestPointOnTriangle(AS_3D_VECTOR, AS_3D_VECTOR, AS_3D_VECTOR, AS_3D_VECTOR);
BOOL ASCheckPointInSphere(AS_3D_VECTOR, AS_3D_VECTOR, float);
AS_3D_VECTOR ASTangentPlaneNormalOfEllipsoid(AS_3D_VECTOR, AS_3D_VECTOR, AS_3D_VECTOR);
DWORD ASClassifyPoint(AS_3D_VECTOR, AS_3D_VECTOR, AS_3D_VECTOR);
double ASIntersectRaySphere(AS_3D_VECTOR, AS_3D_VECTOR, AS_3D_VECTOR, float);
BOOL ASCheckLineInBox(FLOAT3, FLOAT3, FLOAT3 [2]);
///////////////////////////////////////////////////////////////////////////////


double ASIntersectRayPlane(AS_3D_VECTOR vROrigin, AS_3D_VECTOR vRVector,
						   AS_3D_VECTOR vPOrigin, AS_3D_VECTOR vPNormal)
{ // begin ASIntersectRayPlane()
	double dD = -vPNormal.DotProduct(vPOrigin);
	double dNumer = vPNormal.DotProduct(vROrigin)+dD;
	double dDenom = vPNormal.DotProduct(vRVector);

	if(!dDenom) // Normal is orthogonal to vector, cant intersect:
		return -1.0f;

	return -(dNumer/dDenom);	
} // end ASIntersectRayPlane()

BOOL ASCheckPointInTriangle(AS_3D_VECTOR vPoint, AS_3D_VECTOR vA,
							AS_3D_VECTOR vB, AS_3D_VECTOR vC)
{ // begin ASCheckPointInTriangle()
	double dTotalAngles = 0.0f;
	float f;
   
	// Is the tested point near in that triangle??
	if((vPoint.fX < vA.fX &&
		vPoint.fX < vB.fX && 
		vPoint.fX < vC.fX) ||
	   (vPoint.fX > vA.fX &&
		vPoint.fX > vB.fX && 
		vPoint.fX > vC.fX) ||
	   (vPoint.fY < vA.fY &&
		vPoint.fY < vB.fY && 
		vPoint.fY < vC.fY) ||
	   (vPoint.fY > vA.fY &&
		vPoint.fY > vB.fY && 
		vPoint.fY > vC.fY))
		return FALSE; // Nope!

	// Check if the point is on one of the triangles edges:
	if((vPoint.fX == vA.fX && vPoint.fY == vA.fY) ||
	   (vPoint.fX == vB.fX && vPoint.fY == vB.fY) ||
	   (vPoint.fX == vC.fX && vPoint.fY == vC.fY))
		return TRUE;

	// Make the 3 vectors:
	AS_3D_VECTOR vV1 = vPoint-vA;
	AS_3D_VECTOR vV2 = vPoint-vB;
	AS_3D_VECTOR vV3 = vPoint-vC;

	vV1.Normalize();
	vV2.Normalize();
	vV3.Normalize();

	f = vV1.DotProduct(vV2);
	ASLimitMinMax(f, -1.0f, 1.0f);
	dTotalAngles += acos((double) f);

	f = vV2.DotProduct(vV3);
	ASLimitMinMax(f, -1.0f, 1.0f);
	dTotalAngles += acos((double) f);

	f = vV3.DotProduct(vV1);
	ASLimitMinMax(f, -1.0f, 1.0f);
	dTotalAngles += acos((double) f);

	if(fabs(dTotalAngles-2*PI) <= 0.005)
		return TRUE;

	return FALSE;
} // end ASCheckPointInTriangle()

BOOL ASCheckPointInTriangle(AS_3D_VECTOR vPoint, AS_3D_VECTOR vNormal,
							AS_3D_VECTOR vP1, AS_3D_VECTOR vP2, AS_3D_VECTOR vP3)
{ // begin ASCheckPointInTriangle()
	static const float Delta = 1.0e-05f;
	float u0, u1, u2;
	float v0, v1, v2;
	float a, b;
	float max;
	int i, j;
	bool bInter = 0;

	// Is the tested point near in that triangle??
	if((vPoint.fX < vP1.fX &&
		vPoint.fX < vP2.fX && 
		vPoint.fX < vP3.fX) ||
	   (vPoint.fX > vP1.fX &&
		vPoint.fX > vP2.fX && 
		vPoint.fX > vP3.fX) ||
	   (vPoint.fY < vP1.fY &&
		vPoint.fY < vP2.fY && 
		vPoint.fY < vP3.fY) ||
	   (vPoint.fY > vP1.fY &&
		vPoint.fY > vP2.fY && 
		vPoint.fY > vP3.fY))
		return FALSE; // Nope!

	// Check if the point is on one of the triangles edges:
	if((vPoint.fX == vP1.fX && vPoint.fY == vP1.fY) ||
	   (vPoint.fX == vP2.fX && vPoint.fY == vP2.fY) ||
	   (vPoint.fX == vP3.fX && vPoint.fY == vP3.fY))
		return TRUE;

	max = AS_MAX(AS_MAX(AS_ABS(vNormal.fX), AS_ABS(vNormal.fY)), AS_ABS(vNormal.fZ));
	if (max == AS_ABS(vNormal.fX)) {i = 1; j = 2;} // y, z
	if (max == AS_ABS(vNormal.fY)) {i = 0; j = 2;} // x, z
	if (max == AS_ABS(vNormal.fZ)) {i = 0; j = 1;} // x, y
	
	u0 = vPoint.fV[i]-vP1.fV[i];
	v0 = vPoint.fV[j]-vP1.fV[j];
	u1 = vP2.fV[i]-vP1.fV[i];
	v1 = vP2.fV[j]-vP1.fV[j];
	u2 = vP3.fV[i]-vP1.fV[i];
	v2 = vP3.fV[j]-vP1.fV[j];

	if (u1 > -Delta && u1 < Delta)
	{
		b = u0 / u2;
		if (0.0f <= b && b <= 1.0f)
		{
			a = (v0 - b * v2) / v1;
			if ((a >= 0.0f) && (( a + b ) <= 1.0f))
				bInter = 1;
		}
	}
	else
	{
		b = (v0 * u1 - u0 * v1) / (v2 * u1 - u2 * v1);
		if (0.0f <= b && b <= 1.0f)
		{
			a = (u0 - b * u2) / u1;
			if ((a >= 0.0f) && (( a + b ) <= 1.0f ))
				bInter = 1;
		}
	}

	return bInter;
} // end ASCheckPointInTriangle()

AS_3D_VECTOR ASClosestPointOnLine(AS_3D_VECTOR vA, AS_3D_VECTOR vB, AS_3D_VECTOR vP)
{ // begin ASClosestPointOnLine()
	// Determine dT: (the length of the vector from �dA� to �dP�)
	AS_3D_VECTOR vC = vP-vA;
	AS_3D_VECTOR vV = vB-vA; 
  
	double dD = vV.GetLength();
  
	vV.Normalize();

	double dT = vV.DotProduct(vC);

	// Check to see if �dT� is beyond the extents of the line segment:
	if(dT < 0.0f)
		return vA;
	if(dT > dD)
		return vB;

	// Return the point between �vA� and �vB�
	// set length of vV to dT. vV is normalized so this is easy:
	vV *= (float) dT;
       
	return (vA+vV);
} // end ASClosestPointOnLine()

AS_3D_VECTOR ASClosestPointOnTriangle(AS_3D_VECTOR vA, AS_3D_VECTOR vB,
									  AS_3D_VECTOR vC, AS_3D_VECTOR vP)
{ // begin ASClosestPointOnTriangle()
	AS_3D_VECTOR vRab = ASClosestPointOnLine(vA, vB, vP);
	AS_3D_VECTOR vRbc = ASClosestPointOnLine(vB, vC, vP);
	AS_3D_VECTOR vRca = ASClosestPointOnLine(vC, vA, vP);

	double dAB = (vP-vRab).GetLength();
	double dBC = (vP-vRbc).GetLength();
	double dCA = (vP-vRca).GetLength();
	double dMin = dAB;

	AS_3D_VECTOR vResult = vRab;

	if(dBC < dMin)
	{
		dMin = dBC;
		vResult = vRbc;
	}

	if(dCA < dMin)
		vResult = vRca;

	return vResult;	
} // end ASClosestPointOnTriangle()

BOOL ASCheckPointInSphere(AS_3D_VECTOR vPoint, AS_3D_VECTOR vS, float fR)
{ // begin ASCheckPointInSphere()
	float fD = (vPoint-vS).GetLength();

	if(fD <= fR)
		return TRUE;
	return FALSE;	
} // end ASCheckPointInSphere()

AS_3D_VECTOR ASTangentPlaneNormalOfEllipsoid(AS_3D_VECTOR vPoint,
											 AS_3D_VECTOR vE, AS_3D_VECTOR vER)
{ // begin ASTangentPlaneNormalOfEllipsoid()
	AS_3D_VECTOR vP = vPoint-vE;

	double dA2 = vER.fX*vE.fX;
	double dB2 = vER.fY*vE.fY;
	double dC2 = vER.fZ*vE.fZ;

	AS_3D_VECTOR vRes;
	vRes.fX = (float) (vP.fX/dA2);
	vRes.fY = (float) (vP.fY/dB2);
	vRes.fZ = (float) (vP.fZ/dC2);

	vRes.Normalize();
	return vRes;
} // end ASTangentPlaneNormalOfEllipsoid()

DWORD ASClassifyPoint(AS_3D_VECTOR vPoint, AS_3D_VECTOR vP, AS_3D_VECTOR vN)
{ // begin ASClassifyPoint()
	AS_3D_VECTOR vDir = vP-vPoint;
	double dD = vDir.DotProduct(vN);

	if(dD < -0.001f)
		return AS_PLANE_FRONT;	
	else
		if(dD > 0.001f)
			return AS_PLANE_BACKSIDE;	

	return AS_ON_PLANE;	
} // end ASClassifyPoint()

double ASIntersectRaySphere(AS_3D_VECTOR vRayPos, AS_3D_VECTOR vRayDir,
							     AS_3D_VECTOR vSpherePos, float fSphereRadius)
{ // begin ASIntersectRaySphere()
	AS_3D_VECTOR vDelta = vSpherePos-vRayPos;

	float fC = vDelta.GetLength();
	float fV = vDelta.DotProduct(vRayDir);
	float fD = fSphereRadius*fSphereRadius-(fC*fC-fV*fV);

	if(fD < 0.0)
		return -1.0f; // There was no intersection
   
   // Return the distance to the (first) intersecting point:
	return (fV-ASFastSqrt(fD));
} // end ASIntersectRaySphere()

BOOL ASBoxIntersectionX(float fX, FLOAT3 fLineS, FLOAT3 fLineM, FLOAT3 *fRes)
{ // begin ASBoxIntersectionX()
    if(fLineM[X] != 0.0f)
	{
        float t = (fX-fLineS[X])/fLineM[X];
        if((t >= 0.0f) && (t <= 1.0f))
		{
            (*fRes)[X] = fLineS[X]+fLineM[X]*t;
            (*fRes)[Y] = fLineS[Y]+fLineM[Y]*t;
            (*fRes)[Z] = fLineS[Z]+fLineM[Z]*t;
            return TRUE;
        }
    }
    return FALSE;
} // end ASBoxIntersectionX()

BOOL ASBoxIntersectionY(float fY, FLOAT3 fLineS, FLOAT3 fLineM, FLOAT3 *fRes)
{ // begin ASBoxIntersectionY()
    if(fLineM[Y] != 0.0f)
	{
        float t = (fY-fLineS[Y])/fLineM[Y];
        if((t >= 0.0f) && (t <= 1.0f))
		{
            (*fRes)[X] = fLineS[X]+fLineM[X]*t;
            (*fRes)[Y] = fLineS[Y]+fLineM[Y]*t;
            (*fRes)[Z] = fLineS[Z]+fLineM[Z]*t;
            return TRUE;
        }
    }
    return FALSE;
} // end ASBoxIntersectionY()

BOOL ASBoxIntersectionZ(float fZ, FLOAT3 fLineS, FLOAT3 fLineM, FLOAT3 *fRes)
{ // begin ASBoxIntersectionZ()
    if(fLineM[Z] != 0.0f)
	{
        float t = (fZ-fLineS[Z])/fLineM[Z];
        if((t >= 0.0f) && (t <= 1.0f))
		{
            (*fRes)[X] = fLineS[X]+fLineM[X]*t;
            (*fRes)[Y] = fLineS[Y]+fLineM[Y]*t;
            (*fRes)[Z] = fLineS[Z]+fLineM[Z]*t;
            return TRUE;
        }
    }
    return FALSE;
} // end ASBoxIntersectionZ()

BOOL ASCheckBoxVecX(FLOAT3 fVec, FLOAT3 fBox[2])
{ // begin ASCheckBoxVecX()
    if((fVec[Y] >= fBox[MIN][Y]) && (fVec[Y] <= fBox[MAX][Y]) && (fVec[Z] >= fBox[MIN][Z]) && (fVec[Z] <= fBox[MAX][Z]))
		return TRUE;
    return FALSE;
} // end ASCheckBoxVecX()

BOOL ASCheckBoxVecY(FLOAT3 fVec, FLOAT3 fBox[2])
{ // begin ASCheckBoxVecY()
    if((fVec[X] >= fBox[MIN][X]) && (fVec[X] <= fBox[MAX][X]) && (fVec[Z] >= fBox[MIN][Z]) && (fVec[Z] <= fBox[MAX][Z]))
		return TRUE;
    return FALSE;
} // end ASCheckBoxVecY()

BOOL ASCheckBoxVecZ(FLOAT3 fVec, FLOAT3 fBox[2])
{ // begin ASCheckBoxVecZ()
    if((fVec[X] >= fBox[MIN][X]) && (fVec[X] <= fBox[MAX][X]) && (fVec[Y] >= fBox[MIN][Y]) && (fVec[Y] <= fBox[MAX][Y]))
		return TRUE;
    return FALSE;
} // end ASCheckBoxVecZ()

BOOL ASCheckLineInBox(FLOAT3 fLineS, FLOAT3 fLineM, FLOAT3 fBox[2])
{ // begin ASCheckRayBox()
	FLOAT3 fLineE;
	
	fLineE[X] = fLineS[X]+fLineM[X];
	fLineE[Y] = fLineS[Y]+fLineM[Y];
	fLineE[Z] = fLineS[Z]+fLineM[Z];
    if(((fLineS[X] >= fBox[MIN][X]) && (fLineS[Y] >= fBox[MIN][Y]) && (fLineS[Z] >= fBox[MIN][Z]) &&
        (fLineS[X] <= fBox[MAX][X]) && (fLineS[Y] <= fBox[MAX][Y]) && (fLineS[Z] <= fBox[MAX][Y])) ||
       ((fLineE[X] >= fBox[MIN][X]) && (fLineE[Y] >= fBox[MIN][Y]) && (fLineE[Z] >= fBox[MIN][Z]) &&
        (fLineE[X] <= fBox[MAX][X]) && (fLineE[Y] <= fBox[MAX][Y]) && (fLineE[Z] <= fBox[MAX][Z])))
        return TRUE;
    FLOAT3 fPos;
    int i;

    for(i = 0; i < 6; i++)
	{
        switch(i)
		{
            case 0:
                if(ASBoxIntersectionX(fBox[MIN][X], fLineS, fLineM, &fPos) && ASCheckBoxVecX(fPos, fBox))
					return TRUE;
            break;
           
		    case 1:
                if(ASBoxIntersectionX(fBox[MAX][X], fLineS, fLineM, &fPos) && ASCheckBoxVecX(fPos, fBox))
					return TRUE;
            break;
           
		    case 2:
                if(ASBoxIntersectionY(fBox[MIN][Y], fLineS, fLineM, &fPos) && ASCheckBoxVecY(fPos, fBox))
					return TRUE;
            break;
           
		    case 3:
                if(ASBoxIntersectionY(fBox[MAX][Y], fLineS, fLineM, &fPos) && ASCheckBoxVecY(fPos, fBox))
					return TRUE;
            break;
           
		    case 4:
                if(ASBoxIntersectionZ(fBox[MIN][Z], fLineS, fLineM, &fPos) && ASCheckBoxVecZ(fPos, fBox))
					return TRUE;
            break;
           
		    case 5:
				if(ASBoxIntersectionZ(fBox[MAX][Z], fLineS, fLineM, &fPos) && ASCheckBoxVecZ(fPos, fBox))
					return TRUE;
            break;
        }
    }
    return FALSE;
} // end ASCheckRayBox()
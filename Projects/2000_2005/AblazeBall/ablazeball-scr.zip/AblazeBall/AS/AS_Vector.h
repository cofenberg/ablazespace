//-----------------------------------------------------------------------------
// File: AS_Vector.h
//-----------------------------------------------------------------------------

#ifndef __AS_VECTOR_H__
#define __AS_VECTOR_H__


// Classes: *******************************************************************
typedef class AS_2D_VECTOR
{
	public:
		union
		{
			FLOAT2 fV;
			struct
			{
				float fX, fY;
			};
		};

		// Constructor:
		AS_2D_VECTOR(void) { fX = fY = 0.0f; }
		AS_2D_VECTOR(float fXT, float fYT) { fY = fXT, fY = fYT; }
		AS_2D_VECTOR(const float *fV) { *this = fV; }
		AS_2D_VECTOR(const AS_2D_VECTOR &V) { *this = V; }

		// Assignment operators:
		AS_2D_VECTOR &operator=(const float *fV)
		{
			fX = *fV++, fY = *fV;
			return  *this;
		}
		AS_2D_VECTOR &operator=(const AS_2D_VECTOR &V)
		{
			fX = V.fX, fY = V.fY;
			return *this;
		}
		AS_2D_VECTOR &operator=(const float fD)
		{
			fX = fY = fD;
			return *this;
		}

		// Comparison:
		BOOL operator==(const AS_2D_VECTOR V)
		{ return fX == V.fX && fY == V.fY; }
		BOOL operator!=(const AS_2D_VECTOR V)
		{ return !(*this == V); }

		// Vector:
	    AS_2D_VECTOR operator - ()
		{ return AS_2D_VECTOR(-fX, -fY); }
		AS_2D_VECTOR &operator+=(const AS_2D_VECTOR V)
		{
			fX += V.fX, fY += V.fY;
			return *this;
		}
		AS_2D_VECTOR operator+(const AS_2D_VECTOR V)
		{ return AS_2D_VECTOR(fX+V.fX, fY+V.fY); }
		AS_2D_VECTOR &operator+=(const float fN)
		{
			fX += fN, fY += fN;
			return *this;
		}
		AS_2D_VECTOR operator+(const float fN)
		{ return AS_2D_VECTOR(fX+fN, fY+fN); }
		AS_2D_VECTOR &operator-=(const AS_2D_VECTOR V)
		{
			fX -= V.fX, fY -= V.fY;
			return *this;
		}
		AS_2D_VECTOR operator-(const AS_2D_VECTOR V)
		{ return AS_2D_VECTOR(fX-V.fX, fY-V.fY); }
		AS_2D_VECTOR &operator-=(const float fN)
		{
			fX -= fN, fY -= fN;
			return *this;
		}
		AS_2D_VECTOR operator-(const float fN)
		{ return AS_2D_VECTOR(fX-fN, fY-fN); }
		AS_2D_VECTOR &operator*=(const AS_2D_VECTOR V)
		{
			fX *= V.fX, fY *= V.fY;
			return *this;
		}
		AS_2D_VECTOR operator*(const AS_2D_VECTOR V)
		{ return AS_2D_VECTOR(fX*V.fX, fY*V.fY); }
		AS_2D_VECTOR &operator/=(const AS_2D_VECTOR V)
		{
			fX /= V.fX, fY /= V.fY;
			return *this;
		}
		AS_2D_VECTOR operator/(const AS_2D_VECTOR V)
		{ return AS_2D_VECTOR(fX/V.fX, fY/V.fY); }

		// Scalar
		AS_2D_VECTOR &operator*=(float fS)
		{
			fX *= fS, fY *= fS;
			return *this;
		}
		AS_2D_VECTOR operator*(float fS)
		{ return AS_2D_VECTOR(fX*fS, fY*fS); }
		AS_2D_VECTOR &operator/=(float fS)
		{
			fX /= fS, fY /= fS;
			return *this;
		}
		AS_2D_VECTOR operator/(float fS)
		{ return AS_2D_VECTOR(fX/fS, fY/fS); }

		// Stuff:
		void Set(const float fXT, const float fYT)
		{ fX = fXT; fY = fYT; }
		float GetLength(void) { return (float) ASFastSqrt(fX*fX+fY*fY); }
		void SetLength(float fL) { *this *= fL/GetLength(); }

		AS_2D_VECTOR &Normalize(void)
		{
			float fU = fX*fX+fY*fY;
			if(fabs(fU-1.0) < AS_EPSILON)
				return *this;
			fU = 1.0f/(float) ASFastSqrt(fU);
			*this *= fU;
			return *this;
		}

		AS_2D_VECTOR GetNormalized(void)
		{ return AS_2D_VECTOR(*this).Normalize(); }

		float DotProduct(void) { return fX*fX+fY*fY; }
		float DotProduct(const AS_2D_VECTOR V) { return fX*V.fX+fY*V.fY; }

		// Misc:
		BOOL IsNull(void)
		{
			if(!fX && !fY)
				return TRUE;
			return FALSE;
		}

} AS_2D_VECTOR;

typedef class AS_3D_VECTOR
{
	public:
		union
		{
			FLOAT3 fV;
			struct
			{
				float fX, fY, fZ;
			};
			struct
			{
				float fHeading, fPitch, fRoll;
			};
		};

		// Constructor:
		AS_3D_VECTOR(void) { fX = fY = fZ = 0.0f; }
		AS_3D_VECTOR(float fXT, float fYT, float fZT)
		{ fX = fXT, fY = fYT, fZ = fZT; }
		AS_3D_VECTOR(const float *fV) { *this = fV; }
		AS_3D_VECTOR(const AS_3D_VECTOR &V) { *this = V; }

		// Assignment operators:
		AS_3D_VECTOR &operator=(const AS_3D_VECTOR &V)
		{
			fX = V.fX, fY = V.fY, fZ = V.fZ;
			return *this;
		}
		AS_3D_VECTOR &operator=(const float *fV)
		{
			fX = *fV++, fY = *fV++, fZ = *fV;
			return *this;
		}
		AS_3D_VECTOR &operator=(const float fD)
		{
			fX = fY = fZ = fD;
			return *this;
		}

		// Comparison:
		BOOL operator==(const AS_3D_VECTOR &V)
		{ return fX == V.fX && fY == V.fY && fZ == V.fZ; }
		BOOL operator!=(const AS_3D_VECTOR V)
		{ return !(*this == V); }

		// Vector:
	    AS_3D_VECTOR operator - ()
		{ return AS_3D_VECTOR(-fX, -fY, -fZ); }
		AS_3D_VECTOR &operator+=(const AS_3D_VECTOR V)
		{
			fX += V.fX, fY += V.fY, fZ += V.fZ;
			return *this;
		}
		AS_3D_VECTOR operator+(const AS_3D_VECTOR V)
		{ return AS_3D_VECTOR(fX+V.fX, fY+V.fY, fZ+V.fZ); }
		AS_3D_VECTOR &operator+=(const float fN)
		{
			fX += fN, fY += fN, fZ += fN;
			return *this;
		}
		AS_3D_VECTOR operator+(const float fN)
		{ return AS_3D_VECTOR(fX+fN, fY+fN, fZ+fN); }
		AS_3D_VECTOR &operator-=(const AS_3D_VECTOR V)
		{
			fX -= V.fX, fY -= V.fY, fZ -= V.fZ;
			return *this;
		}
		AS_3D_VECTOR operator-(const AS_3D_VECTOR V)
		{ return AS_3D_VECTOR(fX-V.fX, fY-V.fY, fZ-V.fZ); }
		AS_3D_VECTOR &operator-=(const float fN)
		{
			fX -= fN, fY -= fN, fZ -= fN;
			return *this;
		}
		AS_3D_VECTOR operator-(const float fN)
		{ return AS_3D_VECTOR(fX-fN, fY-fN, fZ-fN); }
		AS_3D_VECTOR &operator*=(const AS_3D_VECTOR V)
		{
			fX *= V.fX, fY *= V.fY, fZ *= V.fZ;
			return *this;
		}
		AS_3D_VECTOR operator*(const AS_3D_VECTOR V)
		{ return AS_3D_VECTOR(fX*V.fX, fY*V.fY, fZ*V.fZ); }
		AS_3D_VECTOR &operator/=(const AS_3D_VECTOR V)
		{
			fX /= V.fX, fY /= V.fY, fZ /= V.fZ;
			return *this;
		}
		AS_3D_VECTOR operator/(const AS_3D_VECTOR V)
		{ return AS_3D_VECTOR(fX/V.fX, fY/V.fY, fZ/V.fZ); }

		// Scalar:
		AS_3D_VECTOR &operator*=(float fS)
		{
			fX *= fS, fY *= fS, fZ *= fS;
			return *this;
		}
		AS_3D_VECTOR operator*(float fS)
		{ return AS_3D_VECTOR(fX*fS, fY*fS, fZ*fS); }
		AS_3D_VECTOR &operator/=(float fS)
		{
			*this*=1.0f/fS;
			return *this;
		}
		AS_3D_VECTOR operator/(float fS)
		{ return operator*(1.0f/fS); }

		// Stuff:
		void Set(const float fXT, const float fYT, const float fZT)
		{ fX = fXT; fY = fYT;  fZ = fZT; }
		float GetLength(void) { return (float) ASFastSqrt(fX*fX+fY*fY+fZ*fZ); }
		void SetLength(float fL) { *this *= fL/GetLength(); }

		AS_3D_VECTOR &Normalize(void)
		{
			float fU = fX*fX+fY*fY+fZ*fZ;
			if(fabs(fU-1.0) < AS_EPSILON)
				return *this;
			fU = 1.0f/(float) ASFastSqrt(fU);
			*this *= fU;
			return *this;
		}

		AS_3D_VECTOR GetNormalized(void)
		{ return AS_3D_VECTOR(*this).Normalize(); }

		AS_3D_VECTOR CrossProduct(const AS_3D_VECTOR V)
		{
			return AS_3D_VECTOR((fY*V.fZ)-(fZ*V.fY),
								(fZ*V.fX)-(fX*V.fZ),
								(fX*V.fY)-(fY*V.fX));
		}
		
		void CrossProduct(const AS_3D_VECTOR vV1, const AS_3D_VECTOR vV2)
		{
			fX = (vV1.fY*vV2.fZ)-(vV1.fZ*vV2.fY);
			fY = (vV1.fZ*vV2.fX)-(vV1.fX*vV2.fZ);
			fZ = (vV1.fX*vV2.fY)-(vV1.fY*vV2.fX);
		}

		void GetFaceNormal(AS_3D_VECTOR vP1,
						   AS_3D_VECTOR vP2,
						   AS_3D_VECTOR vP3)
		{
			CrossProduct(vP1-vP2, vP1-vP3);
			Normalize();
		}

		// Get the right and up vectors for a given normal:
		void GetRightUp(AS_3D_VECTOR &vRight, AS_3D_VECTOR &vUp)
		{
			AS_3D_VECTOR vFN(AS_ABS(fX), AS_ABS(fY), AS_ABS(fZ));
			if(vFN.fX > 1.0f)
				vFN.fZ = 1.0f;
			if(vFN.fY > 1.0f)
				vFN.fY = 1.0f;
			if(vFN.fZ > 1.0f)
				vFN.fZ = 1.0f;
			int iMajor = X;
			AS_3D_VECTOR vAxis[3] = 
			{
			   AS_3D_VECTOR(1.0f, 0.0f, 0.0f),
			   AS_3D_VECTOR(0.0f, 1.0f, 0.0f),
			   AS_3D_VECTOR(0.0f, 0.0f, 1.0f)
			};

			// Find the major axis:
			if(vFN.fY > vFN.fV[iMajor])
			  iMajor = Y;
			if(vFN.fZ > vFN.fV[iMajor])
			  iMajor = Z;

			// Build right vector by hand: (faster)
			if(vFN.fX == 1.0f || vFN.fY == 1.0f || vFN.fZ == 1.0f)
			{
				if(iMajor == X && fX > 0.0f)
					vRight.Set(0.0f, 0.0f, -1.0f);
				else
					if(iMajor == X)
						vRight.Set(0.0f, 0.0f, 1.0f);

			  if(iMajor == Y || (iMajor == Z && fZ > 0.0f))
				 vRight.Set(1.0f, 0.0f, 0.0f);
			  if(iMajor == Z && fZ < 0.0f)
				 vRight.Set(-1.0f, 0.0f, 0.0f);
			}
			else
				vRight.CrossProduct(vAxis[iMajor], *this);

			vUp.CrossProduct(*this, vRight);
			vRight.Normalize();
			vUp.Normalize();
		}

		// Project the vector onto the vector 'vV'
		void ProjectVector(AS_3D_VECTOR vV, AS_3D_VECTOR &vRes)
		{
		   vRes = vV;
		   vRes *= ((vV.DotProduct(*this))/(vV.DotProduct()));
		}

		// Project the vector on to the plane created by 'v1' and 'v2'. 'v1' and
		// 'v2' MUST be perpindicular to eachother!
		void ProjectPlane(const AS_3D_VECTOR vV1, const AS_3D_VECTOR vV2, AS_3D_VECTOR &vRes)
		{
		   AS_3D_VECTOR vT1, vT2;
   
		   ProjectVector(vV1, vT1);
		   ProjectVector(vV2, vT2);
		   vRes = vT1+vT2;
		}

		float AngleBetween(AS_3D_VECTOR V)
		{ return (DotProduct(V)/(GetLength()*V.GetLength())); }

		float DotProduct(void) { return fX*fX+fY*fY+fZ*fZ; }
		float DotProduct(const AS_3D_VECTOR V) { return fX*V.fX+fY*V.fY+fZ*V.fZ; }

		// Misc:
		BOOL IsNull(void)
		{
			if(!fX && !fY && !fZ)
				return TRUE;
			return FALSE;
		}

} AS_3D_VECTOR;
///////////////////////////////////////////////////////////////////////////////


inline float ASGetLengthOfVector(AS_3D_VECTOR vV)
{ // begin ASGetLengthOfVector()
	return (float) ASFastSqrt(vV.fX*vV.fX+vV.fY*vV.fY+vV.fZ*vV.fZ);
} // end ASGetLengthOfVector()


#endif // __AS_VECTOR_H__
//-----------------------------------------------------------------------------
// File: AS_Config.cpp
//-----------------------------------------------------------------------------

#include "AS_ENGINE.h"


// Definations: ***************************************************************
enum {TAB_CONFIG_GENERAL, TAB_CONFIG_GRAPHIC, TAB_CONFIG_SOUND, TAB_CONFIG_CONTROL};
#define CONFIG_TABS 4 
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
AS_CONFIG *_ASConfig;
AS_CONFIG ConfigT;
DISPLAY_MODE_INFO DisplayModeInfo;
HWND hWndConfig, hWndCheats;
HWND hWndConfigTab[CONFIG_TABS];
int iCurrentConfigTab;
long g_lTestTime;
char byLastSoundOutput;
BOOL bFirstRunConfigDialog;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
// HRESULT CONFIG::Check(void);
// HRESULT CONFIG::Load(char *);
// HRESULT CONFIG::Save(char *)
void OpenConfigDialog(HWND);
LRESULT CALLBACK ConfigProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK ConfigGeneralProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK ConfigGraphicProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK ConfigSoundProc(HWND, UINT, WPARAM, LPARAM);
void SetupConfigTabs(void);
void SetConfigLanguage(void);
///////////////////////////////////////////////////////////////////////////////


// AS_CONFIG functions: *******************************************************
AS_CONFIG::AS_CONFIG(void)
{ // begin AS_CONFIG::AS_CONFIG()
	memset(this, 0, sizeof(AS_CONFIG));
} // end AS_CONFIG::AS_CONFIG()

AS_CONFIG::~AS_CONFIG(void)
{ // begin AS_CONFIG::~AS_CONFIG()
} // end AS_CONFIG::~AS_CONFIG()

void AS_CONFIG::Check(void)
{ // begin AS_CONFIG::Check()
	// Update the general information:
	if(!DevMode.dmSize)
		DevMode.dmSize = sizeof(DEVMODE);
	iScreenPixels = (int) (DevMode.dmPelsWidth*DevMode.dmPelsHeight);
	iScreenSize = (int) (DevMode.dmPelsWidth*DevMode.dmPelsHeight*(DevMode.dmBitsPerPel/8));
	DevMode.dmFields = DM_BITSPERPEL | DM_PELSWIDTH | DM_PELSHEIGHT;
	// Find the current display mode id:
	for(int i = 0; i < DisplayModeInfo.Number; i++)
	{
		if(DevMode.dmPelsWidth == DisplayModeInfo.pDevMode[i].dmPelsWidth && 
		   DevMode.dmPelsHeight == DisplayModeInfo.pDevMode[i].dmPelsHeight && 	
		   DevMode.dmBitsPerPel == DisplayModeInfo.pDevMode[i].dmBitsPerPel && 
		   DevMode.dmDisplayFrequency == DisplayModeInfo.pDevMode[i].dmDisplayFrequency)
		{
			iModeIndex = i;
			CopyMemory(&DevMode, &DisplayModeInfo.pDevMode[iModeIndex], sizeof(DEVMODE));
			break;
		}
	}
	if(iWindowWidth < 100)
		iWindowWidth = 100;
	if(iWindowHeight < 100)
		iWindowHeight = 100;
	if(fParticleDensity < 0.0f)
		fParticleDensity = 0.0f;
	if(fParticleDensity > 1.0f)
		fParticleDensity = 1.0f;
	if(fGeometricDetails < 0.1f)
		fGeometricDetails = 0.1f;
	if(fGeometricDetails > 1.0f)
		fGeometricDetails = 1.0f;
	if(fVisibility < 0.4f)
		fVisibility = 0.4f;


	// Check keys:
	iThrustKey[1] = GetDXInputKey(iThrustKey[0]);
	iLeftKey[1] = GetDXInputKey(iLeftKey[0]);
	iRightKey[1] = GetDXInputKey(iRightKey[0]);
	iUpKey[1] = GetDXInputKey(iUpKey[0]);
	iDownKey[1] = GetDXInputKey(iDownKey[0]);
	iIncreaseTerrainKey[1] = GetDXInputKey(iIncreaseTerrainKey[0]);
	iDecreaseTerrainKey[1] = GetDXInputKey(iDecreaseTerrainKey[0]);
	iStrongIncreaseTerrainKey[1] = GetDXInputKey(iStrongIncreaseTerrainKey[0]);
	iStrongDecreaseTerrainKey[1] = GetDXInputKey(iStrongDecreaseTerrainKey[0]);
	iStandartViewKey[1] = GetDXInputKey(iStandartViewKey[0]);
	iPauseKey[1] = GetDXInputKey(iPauseKey[0]);
	iHudKey[1] = GetDXInputKey(iHudKey[0]);
	iNextMusicKey[1] = GetDXInputKey(iNextMusicKey[0]);
} // end AS_CONFIG::Check()

HRESULT AS_CONFIG::Load(char *pbyFilename)
{ // begin CONFIG::Load()
	char byTemp[256];

	if(!pbyFilename)
		return 1;
	// Load the configurations from the given file:

	// General:
	bFirstRun = GetPrivateProfileInt("general", "firstrun", 1, pbyFilename);
	bError = GetPrivateProfileInt("general", "error", 1, pbyFilename);
	bDrawBounding = GetPrivateProfileInt("general", "draw_bounding", 0, pbyFilename);
	bShowQuadtrees = GetPrivateProfileInt("general", "show_quadtrees", 0, pbyFilename);
	bShowVisibleFields = GetPrivateProfileInt("general", "show_visible_fields", 0, pbyFilename);
	bFrustumCulling = GetPrivateProfileInt("general", "frustum_culling", 1, pbyFilename);	
	bShowLogo = GetPrivateProfileInt("general", "show_logo", 1, pbyFilename);	
	bShowFPS = GetPrivateProfileInt("general", "show_fps", 0, pbyFilename);
	bLog = GetPrivateProfileInt("general", "log", 1, pbyFilename);
	iWindowWidth = GetPrivateProfileInt("general", "window_width", DevMode.dmPelsWidth, pbyFilename);
	iWindowHeight = GetPrivateProfileInt("general", "window_height", DevMode.dmPelsHeight, pbyFilename);
	GetPrivateProfileString("general", "language", "GB", byLanguage, MAX_PATH, pbyFilename);
	_strupr(byLanguage);
	GetPrivateProfileString("general", "mouse_sensibility", "1.0f", byTemp, MAX_PATH, pbyFilename);
	fMouseSensibility = (float) atof(byTemp);

	// Graphic:
	bFullScreen = GetPrivateProfileInt("graphic", "fullscreen", 1, pbyFilename);
	byZBuffer = GetPrivateProfileInt("graphic", "z_buffer", 2, pbyFilename);
	byLight = GetPrivateProfileInt("graphic", "light_mode", 2, pbyFilename);
	bFastTexturing = GetPrivateProfileInt("graphic", "fast_texturing", 0, pbyFilename);
	bUseMipmaps = GetPrivateProfileInt("graphic", "use_mipmaps", 1, pbyFilename);
	bLightmaps	 = GetPrivateProfileInt("graphic", "lightmaps", 1, pbyFilename);
	bShadowmaps	 = GetPrivateProfileInt("graphic", "shadowmaps", 1, pbyFilename);
	bMultitexturing = GetPrivateProfileInt("graphic", "multitexturing", 1, pbyFilename);
	bHightRenderQuality = GetPrivateProfileInt("graphic", "hight_render_quality", 1, pbyFilename);
	bWaterWaves = GetPrivateProfileInt("graphic", "water_waves", 1, pbyFilename);
	bDithering = GetPrivateProfileInt("graphic", "dithering", 1, pbyFilename);
	DevMode.dmPelsWidth = GetPrivateProfileInt("graphic", "width", 640, pbyFilename);
	DevMode.dmPelsHeight = GetPrivateProfileInt("graphic", "height", 480, pbyFilename);
	DevMode.dmBitsPerPel = GetPrivateProfileInt("graphic", "colordepth", 16, pbyFilename);
	DevMode.dmDisplayFrequency = GetPrivateProfileInt("graphic", "refresh_rate", 0, pbyFilename);
	bParticles = GetPrivateProfileInt("graphic", "particles", DevMode.dmPelsHeight, pbyFilename);
	GetPrivateProfileString("graphic", "particle_density", "1.0f", byTemp, MAX_PATH, pbyFilename);
	fParticleDensity = (float) atof(byTemp);
	GetPrivateProfileString("graphic", "geometric_detail", "1.0f", byTemp, MAX_PATH, pbyFilename);
	fGeometricDetails = (float) atof(byTemp);
	GetPrivateProfileString("graphic", "visibility", "1.0f", byTemp, MAX_PATH, pbyFilename);
	fVisibility = (float) atof(byTemp);

	// Sound:
	bSound = GetPrivateProfileInt("sound", "sound", 1, pbyFilename);
	bMusic = GetPrivateProfileInt("sound", "music", 1, pbyFilename);
	bRandomMusic = GetPrivateProfileInt("sound", "random_music", 0, pbyFilename);
	bySoundOutput = GetPrivateProfileInt("sound", "sound_output", FSOUND_OUTPUT_WINMM, pbyFilename);
	iMusicVolume = GetPrivateProfileInt("sound", "music_volume", 120, pbyFilename);
	iSoundVolume = GetPrivateProfileInt("sound", "sound_volume", 170, pbyFilename);

	// Keys:
	iThrustKey[0] = GetPrivateProfileInt("keys", "thrust", STANDART_THRUST_KEY, pbyFilename);
	iLeftKey[0] = GetPrivateProfileInt("keys", "left", STANDART_LEFT_KEY, pbyFilename);
	iRightKey[0] = GetPrivateProfileInt("keys", "right", STANDART_RIGHT_KEY, pbyFilename);
	iUpKey[0] = GetPrivateProfileInt("keys", "top", STANDART_UP_KEY, pbyFilename);
	iDownKey[0] = GetPrivateProfileInt("keys", "down", STANDART_DOWN_KEY, pbyFilename);
	iIncreaseTerrainKey[0] = GetPrivateProfileInt("keys", "increase_terrain", STANDART_INCREASE_TERRAIN_KEY, pbyFilename);
	iDecreaseTerrainKey[0] = GetPrivateProfileInt("keys", "decrease_terrain", STANDART_DECREASE_TERRAIN_KEY, pbyFilename);
	iStrongIncreaseTerrainKey[0] = GetPrivateProfileInt("keys", "strong_increase_terrain", STANDART_STRONG_INCREASE_TERRAIN_KEY, pbyFilename);
	iStrongDecreaseTerrainKey[0] = GetPrivateProfileInt("keys", "strong_decrease_terrain", STANDART_STRONG_DECREASE_TERRAIN_KEY, pbyFilename);
	iStandartViewKey[0] = GetPrivateProfileInt("keys", "standart_view", STANDART_STANDART_VIEW_KEY, pbyFilename);
	iPauseKey[0] = GetPrivateProfileInt("keys", "pause", STANDART_PAUSE_KEY, pbyFilename);
	iHudKey[0] = GetPrivateProfileInt("keys", "hud", STANDART_HUD_KEY, pbyFilename);
	iNextMusicKey[0] = GetPrivateProfileInt("keys", "next_music", STANDART_NEXT_MUSIC_KEY, pbyFilename);
	
	// Debug stuff:
	if(_AS->bDebugMode)
	{
		bShowCulledObjects = GetPrivateProfileInt("general", "show_culled_objects", 0, pbyFilename);	
		bWireframeMode = GetPrivateProfileInt("general", "wireframe_mode", 0, pbyFilename);	
		bPointMode = GetPrivateProfileInt("general", "point_mode", 0, pbyFilename);	
	}

	Check(); // Update the configurations
	if(!_AS->bStartErrorMessage)
		_ASConfig->bError = FALSE;
	return 0;
} // end AS_CONFIG::Load()

HRESULT AS_CONFIG::Save(char *pbyFilename)
{ // begin AS_CONFIG::Save()
	FILE *pFile;

	if(!pbyFilename)
		return 1;
	// Save the current configurations:
	pFile = fopen(pbyFilename, "wt");
	if(!pFile)
		return 1;
	if(iWindowWidth < 100)
		iWindowWidth = 100;
	if(iWindowHeight < 100)
		iWindowHeight = 100;
	
	// General:
	fprintf(pFile, "[general]\n");
    fprintf(pFile, "firstrun=%d\n", bFirstRun);
    fprintf(pFile, "error=%d\n", bError);
    fprintf(pFile, "show_fps=%d\n", bShowFPS);
    fprintf(pFile, "frustum_culling=%d\n", bFrustumCulling);
    fprintf(pFile, "show_logo=%d\n", bShowLogo);
    fprintf(pFile, "draw_bounding=%d\n", bDrawBounding);    
    fprintf(pFile, "show_quadtrees=%d\n", bShowQuadtrees);
    fprintf(pFile, "show_visible_fields=%d\n", bShowVisibleFields);	
	fprintf(pFile, "log=%d\n", bLog);
	fprintf(pFile, "window_width=%d\n", iWindowWidth);
	fprintf(pFile, "window_height=%d\n", iWindowHeight);
	fprintf(pFile, "language=%s\n", byLanguage);
	fprintf(pFile, "mouse_sensibility=%f\n", fMouseSensibility);

	// Graphic:
	fprintf(pFile, "\n[graphic]\n");
    fprintf(pFile, "fullscreen=%d\n", bFullScreen);
    fprintf(pFile, "z_buffer=%d\n", byZBuffer);
    fprintf(pFile, "light_mode=%d\n", byLight);
    fprintf(pFile, "fast_texturing=%d\n", bFastTexturing);
    fprintf(pFile, "use_mipmaps=%d\n", bUseMipmaps);
    fprintf(pFile, "shadowmaps=%d\n", bShadowmaps);
    fprintf(pFile, "multitexturing=%d\n", bMultitexturing);
	fprintf(pFile, "hight_render_quality=%d\n", bHightRenderQuality);
	fprintf(pFile, "water_waves=%d\n", bWaterWaves);
	fprintf(pFile, "dithering=%d\n", bDithering);
	fprintf(pFile, "width=%d\n", DevMode.dmPelsWidth);
	fprintf(pFile, "height=%d\n", DevMode.dmPelsHeight);
	fprintf(pFile, "colordepth=%d\n", DevMode.dmBitsPerPel);
	fprintf(pFile, "refresh_rate=%d HZ\n", DevMode.dmDisplayFrequency);
	fprintf(pFile, "particles=%d\n", bParticles);
	fprintf(pFile, "particle_density=%f\n", fParticleDensity);
	fprintf(pFile, "geometric_detail=%f\n", fGeometricDetails);
	fprintf(pFile, "visibility=%f\n", fVisibility);
	
	fprintf(pFile, "\n[sound]\n");
    fprintf(pFile, "sound=%d\n", bSound);
    fprintf(pFile, "music=%d\n", bMusic);
	fprintf(pFile, "random_music=%d\n", bRandomMusic);
	fprintf(pFile, "sound_output=%d\n", bySoundOutput);
	fprintf(pFile, "music_volume=%d\n", iMusicVolume);
	fprintf(pFile, "sound_volume=%d\n", iSoundVolume);

	// Keys:
	fprintf(pFile, "\n[keys]\n");
	fprintf(pFile, "thrust=%d\n", iThrustKey[0]);
	fprintf(pFile, "left=%d\n", iLeftKey[0]);
	fprintf(pFile, "right=%d\n", iRightKey[0]);
	fprintf(pFile, "up=%d\n", iUpKey[0]);
	fprintf(pFile, "down=%d\n", iDownKey[0]);
	fprintf(pFile, "increase_terrain=%d\n", iIncreaseTerrainKey[0]);
	fprintf(pFile, "decrease_terrain=%d\n", iDecreaseTerrainKey[0]);
	fprintf(pFile, "strong_increase_terrain=%d\n", iStrongIncreaseTerrainKey[0]);
	fprintf(pFile, "strong_decrease_terrain=%d\n", iStrongDecreaseTerrainKey[0]);
	fprintf(pFile, "standart_view=%d\n", iStandartViewKey[0]);
	fprintf(pFile, "pause=%d\n", iPauseKey[0]);
	fprintf(pFile, "hud=%d\n", iHudKey[0]);
	fprintf(pFile, "next_music=%d\n", iNextMusicKey[0]);

    // Debug stuff:
	if(_AS->bDebugMode)
	{
		fprintf(pFile, "\n[debug]\n");
		fprintf(pFile, "show_culled_objects=%d\n", bShowCulledObjects);
		fprintf(pFile, "wireframe_mode=%d\n", bWireframeMode);
		fprintf(pFile, "point_mode=%d\n", bPointMode);
	}

	fclose(pFile);
	return 0;
} // end AS_CONFIG::Save()


// Functions: *****************************************************************
void OpenConfigDialog(HWND hWnd)
{ // begin OpenConfigDialog()
	DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CONFIG), hWnd, (DLGPROC) ConfigProc);
} // begin OpenConfigDialog()

LRESULT CALLBACK ConfigProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin ConfigProc()
	char byTemp[256];
	int i, i2;

	switch(iMessage)
    {
        case WM_INITDIALOG:
			_AS->WriteLogMessage("Open config dialog");
			memcpy(&ConfigT, _ASConfig, sizeof(AS_CONFIG));
			if(!hWndConfig)
				iCurrentConfigTab = -1;
			hWndConfig = hWnd;
			SetConfigLanguage();
			g_lTestTime = GetTickCount();
			byLastSoundOutput = _ASConfig->bySoundOutput;
			if(bOnlyConfig)
				ShowWindow(GetDlgItem(hWnd, ID_CONFIG_QUIT), FALSE);			
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_CONFIG_OK:
					if(GetTickCount()-g_lTestTime < 500)
						break; // The user probably hadn't the change to do this selection!
					if(IsDlgButtonChecked(hWndConfigTab[TAB_CONFIG_GRAPHIC], IDC_CONFIG_GRAPHIC_LIGHT_NONE))
						_ASConfig->byLight = 0;
					else
					if(IsDlgButtonChecked(hWndConfigTab[TAB_CONFIG_GRAPHIC], IDC_CONFIG_GRAPHIC_LIGHT_FLAT))
						_ASConfig->byLight = 1;
					else
					if(IsDlgButtonChecked(hWndConfigTab[TAB_CONFIG_GRAPHIC], IDC_CONFIG_GRAPHIC_LIGHT_SMOOTH))
						_ASConfig->byLight = 2;

					// Check sound output:
					if(IsDlgButtonChecked(hWndConfigTab[TAB_CONFIG_SOUND], IDC_CONFIG_SOUND_WINDOWS_MULTIMEDIA))
						_ASConfig->bySoundOutput = FSOUND_OUTPUT_WINMM;
					else
					if(IsDlgButtonChecked(hWndConfigTab[TAB_CONFIG_SOUND], IDC_CONFIG_SOUND_DIRECT_SOUND))
						_ASConfig->bySoundOutput = FSOUND_OUTPUT_DSOUND;
					if(_ASConfig->bySoundOutput != byLastSoundOutput && !bOnlyConfig)
						RestartSoundSystem();

					EndDialog(hWnd, FALSE);
					hWndConfig = NULL;
					for(i2 = 0; i2 < CONFIG_TABS; i2++)
						hWndConfigTab[i2] = NULL;
					// Save the configuration:	
					sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyConfigFile);
					_ASConfig->Save(byTemp);
					ParticleManager.UpdateSystems();
					_AS->WriteLogMessage("Close config dialog (ok)");
					g_lNow = GetTickCount();
                return TRUE;

				case ID_CONFIG_CANCEL:
					memcpy(_ASConfig, &ConfigT, sizeof(AS_CONFIG));
					EndDialog(hWnd, FALSE);
					hWndConfig = NULL;
					for(i2 = 0; i2 < CONFIG_TABS; i2++)
						hWndConfigTab[i2] = NULL;;
					_AS->WriteLogMessage("Close config dialog (cancel)");
					g_lNow = GetTickCount();
				break;
				
				case ID_CONFIG_QUIT:
					EndDialog(hWnd, FALSE);
					hWndConfig = NULL;
					_AS->SetShutDown(TRUE);
				break;

				case IDC_CONFIG_OPENGL:
					DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_OPENGL), hWnd, (DLGPROC) OpenGLInfoProc);
				break;

				case IDC_CONFIG_CREDITS:
					OpenCreditsDialog(hWnd);
				break;

				case IDC_HOMEPAGE:
					ShellExecute(0, "open", "http://www.ablazespace.de/", 0, 0, SW_SHOW);
				break;

				case IDC_VALTONEN_HOMEPAGE:
					ShellExecute(0, "open", "http://www.valtone.com/", 0, 0, SW_SHOW);
				break;

				case IDC_GAMEDEV_HOMEPAGE:
					ShellExecute(0, "open", "http://www.gamedev.net/", 0, 0, SW_SHOW);
				break;

				case IDC_NEHE_HOMEPAGE:
					ShellExecute(0, "open", "http://nehe.gamedev.net/", 0, 0, SW_SHOW);
				break;

				case IDC_ROMAKA_HOMEPAGE:
					ShellExecute(0, "open", "http://romka.demonews.com/", 0, 0, SW_SHOW);
				break;

				case IDC_CONFIG_HELP:
					OpenHelp();
				break;
            }
            break;

        case WM_NOTIFY: 
			switch(wParam)
			{
				case IDC_CONFIG_TAB:
					i = TabCtrl_GetCurSel(GetDlgItem(hWnd, IDC_CONFIG_TAB));
					if(i == iCurrentConfigTab)
						break; // This tab is already opend
					iCurrentConfigTab = i;
					for(i2 = 0; i2 < CONFIG_TABS; i2++)
						ShowWindow(hWndConfigTab[i2], SW_HIDE);
					UpdateWindow(hWndConfigTab[i]);
					ShowWindow(hWndConfigTab[i], SW_SHOW);
					SetFocus(hWndConfigTab[i]);
					SendMessage(hWndConfigTab[i], WM_INITDIALOG, 0, 0);
				break;
			} 
		break; 

		case WM_CLOSE:
			SendMessage(hWnd, WM_COMMAND, ID_CONFIG_OK, 0);
		break;
    }
    return FALSE;
} // end ConfigProc()

LRESULT CALLBACK ConfigGeneralProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin ConfigGeneralProc()
	int i;
	BOOL bTemp;

	switch(iMessage)
    {
        case WM_INITDIALOG:
			// Texts:
			SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_LOG, T_Log);
  			SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_SHOW_FPS, T_ShowFPS);
  			SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_LANGUAGE_TEXT, T_Language);
  			SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_FRUSTUM_CULLING, T_FrustumCulling);

			if(!_AS->bDebugMode)
			{ // Debug stuff:
  				SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_SHOW_BOUNDING_BOXES, T_ShowBoundingBoxes);
  				SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_SHOW_QUADTREES, T_ShowQuadtrees);
  				SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_SHOW_VISIBLE_FIELDS, T_ShowVisibleFields);
  				SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_SHOW_CULLED_OBJECTS, T_ShowCulledObjects);
  				SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_WIREFRAME_MODE, T_WireframeMode);
  				SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_POINT_MODE, T_PointMode);
				ShowWindow(GetDlgItem(hWnd, IDC_CONFIG_GENERAL_SHOW_BOUNDING_BOXES), FALSE);
				ShowWindow(GetDlgItem(hWnd, IDC_CONFIG_GENERAL_SHOW_QUADTREES), FALSE);
				ShowWindow(GetDlgItem(hWnd, IDC_CONFIG_GENERAL_SHOW_VISIBLE_FIELDS), FALSE);
				ShowWindow(GetDlgItem(hWnd, IDC_CONFIG_GENERAL_SHOW_CULLED_OBJECTS), FALSE);
				ShowWindow(GetDlgItem(hWnd, IDC_CONFIG_GENERAL_WIREFRAME_MODE), FALSE);
				ShowWindow(GetDlgItem(hWnd, IDC_CONFIG_GENERAL_POINT_MODE), FALSE);
			}

			//
 			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LANGUAGE, CB_RESETCONTENT, 0, 0);
			for(i = 0; i < iASLanguages; i++)
 			{
				SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LANGUAGE, CB_ADDSTRING, 0, (LONG)(LPSTR) pbyASLanguage[i]);
				if(!strcmp(pbyASLanguage[i], _ASConfig->byLanguage))
					SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LANGUAGE, CB_SETCURSEL, i, 0L);
			}
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_SHOW_FPS, BM_SETCHECK, _ASConfig->bShowFPS, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LOG, BM_SETCHECK, _ASConfig->bLog, 0L);
			if(!_AS->bLog)
				EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GENERAL_LOG), FALSE);
			else
				EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GENERAL_LOG), TRUE);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_SHOW_BOUNDING_BOXES, BM_SETCHECK, _ASConfig->bDrawBounding, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_SHOW_QUADTREES, BM_SETCHECK, _ASConfig->bShowQuadtrees, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_SHOW_VISIBLE_FIELDS, BM_SETCHECK, _ASConfig->bShowVisibleFields, 0L);			
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_FRUSTUM_CULLING, BM_SETCHECK, _ASConfig->bFrustumCulling, 0L);
			
			// Debug stuff:
			if(_ASConfig->bWireframeMode && _ASConfig->bPointMode)
				_ASConfig->bPointMode = FALSE;
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_SHOW_CULLED_OBJECTS, BM_SETCHECK, _ASConfig->bShowCulledObjects, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_WIREFRAME_MODE, BM_SETCHECK, _ASConfig->bWireframeMode, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_POINT_MODE, BM_SETCHECK, _ASConfig->bPointMode, 0L);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_CONFIG_GENERAL_SHOW_FPS:
					_ASConfig->bShowFPS = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_SHOW_FPS, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_GENERAL_LOG:
					_ASConfig->bLog = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LOG, BM_GETCHECK, 0, 0L);
					bTemp = _ASConfig->bLog;
					_ASConfig->bLog = TRUE;
					if(!bTemp)
						_AS->WriteLogMessage("Deactivate the log");
					else
						_AS->WriteLogMessage("Activate the log");
					_ASConfig->bLog = bTemp;
				break;
	
				case IDC_CONFIG_GENERAL_LANGUAGE:
					i = (int) SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LANGUAGE, CB_GETCURSEL, 0, 0L);
					if(i == -1)
						break;
					if(!strcmp(_ASConfig->byLanguage, pbyASLanguage[i]))
						break; // This language is already selected
					strcpy(_ASConfig->byLanguage, pbyASLanguage[i]);
					iCurrentConfigTab = -1;
					SetLanguage(_ASConfig->byLanguage);
				break;

				case IDC_CONFIG_GENERAL_SHOW_BOUNDING_BOXES:
					_ASConfig->bDrawBounding = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_SHOW_BOUNDING_BOXES, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_GENERAL_SHOW_QUADTREES:
					_ASConfig->bShowQuadtrees = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_SHOW_QUADTREES, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_GENERAL_SHOW_VISIBLE_FIELDS:
					_ASConfig->bShowVisibleFields = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_SHOW_VISIBLE_FIELDS, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_GENERAL_FRUSTUM_CULLING:
					_ASConfig->bFrustumCulling = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_FRUSTUM_CULLING, BM_GETCHECK, 0, 0L);
				break;
				
				// Debug stuff:
				case IDC_CONFIG_GENERAL_SHOW_CULLED_OBJECTS:
					_ASConfig->bShowCulledObjects = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_SHOW_CULLED_OBJECTS, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_GENERAL_WIREFRAME_MODE:
					_ASConfig->bWireframeMode = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_WIREFRAME_MODE, BM_GETCHECK, 0, 0L);
					if(_ASConfig->bPointMode)
					{
						_ASConfig->bPointMode = FALSE;
						SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_POINT_MODE, BM_SETCHECK, _ASConfig->bPointMode, 0L);
					}
					UpdateRenderQuality();
				break;

				case IDC_CONFIG_GENERAL_POINT_MODE:
					_ASConfig->bPointMode = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_POINT_MODE, BM_GETCHECK, 0, 0L);
					if(_ASConfig->bWireframeMode)
					{
						_ASConfig->bWireframeMode = FALSE;
						SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_WIREFRAME_MODE, BM_SETCHECK, _ASConfig->bWireframeMode, 0L);
					}
					UpdateRenderQuality();
				break;
            }
            break;
    }
    return FALSE;
} // end ConfigGeneralProc()

LRESULT CALLBACK ConfigGraphicProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin ConfigGraphicProc()
	int i, i2;
    LPSTR byTemp = new char[MAX_PATH];

	switch(iMessage)
    {
        case WM_INITDIALOG:
			// Texts:
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_LIGHTING, T_Lighting);
  			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_LIGHT_NONE, T_None);
  			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_LIGHT_FLAT, T_Flat);
  			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_LIGHT_SMOOTH, T_Smooth);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_FAST_TEXTURING, T_FastTexturing);
  			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_USE_MIPMAPS, T_UseMipmaps);
  			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_LIGHTMAPS, T_LightMaps);
  			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_SHADOWMAPS, T_ShadowMaps);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_MULTITEXTURING, T_Multitexturing);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_HIGHT_RENDER_QUALITY, T_HightRenderQuality);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_WATER_WAVES, T_WaterWaves);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_DITHERING, T_Dithering);
  			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_DISPLAY_MODE, T_DisplayMode);
  			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_FULLSCREEN, T_Fullscreen);

			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY_T, T_ParticleDensity);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY_LOW, T_Low);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY_MIDDLE, T_Middle);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY_ALL, T_All);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_GEOMETRIC_DETAIL_T, T_GeometricDetail);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_GEOMETRIC_DETAIL_LOW, T_Low);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_GEOMETRIC_DETAIL_MIDDLE, T_Middle);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_GEOMETRIC_DETAIL_ALL, T_All);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_VISIBILITY_T, T_Visibility);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_VISIBILITY_LOW, T_Low);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_VISIBILITY_MIDDLE, T_Middle);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_VISIBILITY_HIGH, T_High);
			
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER_T, T_ZBuffer);
			//
 			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER, CB_RESETCONTENT, 0, 0);
    		SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER, CB_ADDSTRING, 0, (LONG)(LPSTR) "8");
    		SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER, CB_ADDSTRING, 0, (LONG)(LPSTR) "16");
    		SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER, CB_ADDSTRING, 0, (LONG)(LPSTR) "24");
    		SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER, CB_ADDSTRING, 0, (LONG)(LPSTR) "32");
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER, CB_SETCURSEL, _ASConfig->byZBuffer/8-1, 0L);

			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_FULLSCREEN, BM_SETCHECK, _ASConfig->bFullScreen, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_FAST_TEXTURING, BM_SETCHECK, _ASConfig->bFastTexturing, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_USE_MIPMAPS, BM_SETCHECK, _ASConfig->bUseMipmaps, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_LIGHTMAPS, BM_SETCHECK, _ASConfig->bLightmaps, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_SHADOWMAPS, BM_SETCHECK, _ASConfig->bShadowmaps, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_HIGHT_RENDER_QUALITY, BM_SETCHECK, _ASConfig->bHightRenderQuality, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_WATER_WAVES, BM_SETCHECK, _ASConfig->bWaterWaves, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_DITHERING, BM_SETCHECK, _ASConfig->bDithering, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MULTITEXTURING, BM_SETCHECK, _ASConfig->bMultitexturing, 0L);
			
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_PARTICLES, BM_SETCHECK, _ASConfig->bParticles, 0L);
			if(!_AS->bMultitexSupported)
				EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_MULTITEXTURING), FALSE);
			else
				EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_MULTITEXTURING), TRUE);

			switch(_ASConfig->byLight)
			{
				case 0: CheckRadioButton(hWnd, IDC_CONFIG_GRAPHIC_LIGHT_NONE, IDC_CONFIG_GRAPHIC_LIGHT_SMOOTH, IDC_CONFIG_GRAPHIC_LIGHT_NONE); break;
				case 1: CheckRadioButton(hWnd, IDC_CONFIG_GRAPHIC_LIGHT_NONE, IDC_CONFIG_GRAPHIC_LIGHT_SMOOTH, IDC_CONFIG_GRAPHIC_LIGHT_FLAT); break;
				case 2: CheckRadioButton(hWnd, IDC_CONFIG_GRAPHIC_LIGHT_NONE, IDC_CONFIG_GRAPHIC_LIGHT_SMOOTH, IDC_CONFIG_GRAPHIC_LIGHT_SMOOTH); break;
			}	

 			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MODES, CB_RESETCONTENT, 0, 0);
			wsprintf(byTemp, "All");
			// Put in the new entries:
			for(i = 0, i2 = 0; i < DisplayModeInfo.Number-1; i++)
			{
				if(DisplayModeInfo.pDevMode[i].dmBitsPerPel < (unsigned char) 16)
					continue;
				wsprintf(byTemp, "%dx%dx%d  %d HZ", 
						DisplayModeInfo.pDevMode[i].dmPelsWidth, 
						DisplayModeInfo.pDevMode[i].dmPelsHeight, 
						DisplayModeInfo.pDevMode[i].dmBitsPerPel, 
						DisplayModeInfo.pDevMode[i].dmDisplayFrequency);
     			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MODES, CB_ADDSTRING, 0, (LONG)(LPSTR) byTemp);
     			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MODES, CB_SETITEMDATA, i2, i);
				i2++;
			}
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MODES, CB_SETCURSEL, _ASConfig->iModeIndex, 0L);
		    SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY, TBM_SETRANGE, FALSE, MAKELONG(1, 100));
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY, TBM_SETTIC, TRUE, 50);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY, TBM_SETPOS, TRUE, (long) ((float) _ASConfig->fParticleDensity*100.0f));			
			EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY), _ASConfig->bParticles);
  			sprintf(byTemp, "%0.1f%%", (float) _ASConfig->fParticleDensity*100);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY_P, byTemp);

		    SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_GEOMETRIC_DETAIL, TBM_SETRANGE, FALSE, MAKELONG(1, 10));
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_GEOMETRIC_DETAIL, TBM_SETTIC, TRUE, 5);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_GEOMETRIC_DETAIL, TBM_SETPOS, TRUE, (long) ((float) _ASConfig->fGeometricDetails*10.0f));
  			sprintf(byTemp, "%0.1f%%", (float) _ASConfig->fGeometricDetails/10*1000);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_GEOMETRIC_DETAIL_P, byTemp);

		    SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_VISIBILITY, TBM_SETRANGE, FALSE, MAKELONG(1, 100));
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_VISIBILITY, TBM_SETTIC, TRUE, 50);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_VISIBILITY, TBM_SETPOS, TRUE, (long) ((float) _ASConfig->fVisibility*50.0f));
  			sprintf(byTemp, "%0.1f%%", (float) _ASConfig->fVisibility/0.5f);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_VISIBILITY_P, byTemp);			
		return TRUE;

		case WM_NOTIFY:
            switch(wParam)
            {
				case IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY:
					i = (int) SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY, TBM_GETPOS, 0, 0);
					_ASConfig->fParticleDensity = (float) i/100;
					if(_ASConfig->fParticleDensity < 0.0f)
						_ASConfig->fParticleDensity = 0.0f;
					if(_ASConfig->fParticleDensity > 1.0f)
						_ASConfig->fParticleDensity = 1.0f;
  					sprintf(byTemp, "%0.1f%%", (float) _ASConfig->fParticleDensity*100);
					SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY_P, byTemp);
				break;

				case IDC_CONFIG_GRAPHIC_GEOMETRIC_DETAIL:
					i = (int) SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_GEOMETRIC_DETAIL, TBM_GETPOS, 0, 0);
					_ASConfig->fGeometricDetails = (float) i/10;
					if(_ASConfig->fGeometricDetails < 0.1f)
						_ASConfig->fGeometricDetails = 0.1f;
					if(_ASConfig->fGeometricDetails > 1.0f)
						_ASConfig->fGeometricDetails = 1.0f;
  					sprintf(byTemp, "%0.1f%%", (float) _ASConfig->fGeometricDetails/10*1000);
					SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_GEOMETRIC_DETAIL_P, byTemp);
				break;

				case IDC_CONFIG_GRAPHIC_VISIBILITY:
					i = (int) SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_VISIBILITY, TBM_GETPOS, 0, 0);
					_ASConfig->fVisibility = (float) i/50;
  					sprintf(byTemp, "%0.1f%%", (float) _ASConfig->fVisibility*100);
					SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_VISIBILITY_P, byTemp);			
				break;
			}
		break;

		case WM_COMMAND:
            switch(LOWORD(wParam))
            {

				case IDC_CONFIG_GRAPHIC_FULLSCREEN:
				    _ASConfig->bFullScreen = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_FULLSCREEN, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_GRAPHIC_MODES:
   					i = (int) SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MODES, CB_GETCURSEL, 0, 0L);
					i = (int) SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MODES, CB_GETITEMDATA, i, 0);
					_ASConfig->iModeIndex = i;                         	
					CopyMemory(&_ASConfig->DevMode, &DisplayModeInfo.pDevMode[_ASConfig->iModeIndex], sizeof(DEVMODE));
				break;

				case IDC_CONFIG_GRAPHIC_FAST_TEXTURING:
					_ASConfig->bFastTexturing = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_FAST_TEXTURING, BM_GETCHECK, 0, 0L);
					UpdateAllTextures();
				break;

				case IDC_CONFIG_GRAPHIC_USE_MIPMAPS:
					_ASConfig->bUseMipmaps = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_USE_MIPMAPS, BM_GETCHECK, 0, 0L);
					UpdateAllTextures();
				break;

				case IDC_CONFIG_GRAPHIC_LIGHTMAPS:
					_ASConfig->bLightmaps = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_LIGHTMAPS, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_GRAPHIC_SHADOWMAPS:
					_ASConfig->bShadowmaps = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_SHADOWMAPS, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_GRAPHIC_HIGHT_RENDER_QUALITY:
					_ASConfig->bHightRenderQuality = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_HIGHT_RENDER_QUALITY, BM_GETCHECK, 0, 0L);
					UpdateRenderQuality();
				break;

				case IDC_CONFIG_GRAPHIC_WATER_WAVES:
					_ASConfig->bWaterWaves = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_WATER_WAVES, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_GRAPHIC_DITHERING:
					_ASConfig->bDithering = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_DITHERING, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_GRAPHIC_MULTITEXTURING:
					_ASConfig->bMultitexturing = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MULTITEXTURING, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_GRAPHIC_PARTICLES:
					_ASConfig->bParticles = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_PARTICLES, BM_GETCHECK, 0, 0L);
					EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY), _ASConfig->bParticles);
				break;
				
   				case IDC_CONFIG_GRAPHIC_Z_BUFFER:
					i = (int) SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER, CB_GETCURSEL, 0, 0L);
					if(i < 0)
						break;
					_ASConfig->byZBuffer = (i+1)*8;
				break;
            }
            break;
    }
    return FALSE;
} // end ConfigGraphicProc()

LRESULT CALLBACK ConfigSoundProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin ConfigSoundProc()
	char byTemp[256];
	
	switch(iMessage)
    {
        case WM_INITDIALOG:
  			// Texts:
  			SetDlgItemText(hWnd, IDC_CONFIG_SOUND_MUSIC, T_Music);
  			SetDlgItemText(hWnd, IDC_CONFIG_SOUND_SOUND, T_Sound);
  			SetDlgItemText(hWnd, IDC_CONFIG_SOUND_MUSIC_VOLUME_T, T_MusicVolume);
  			SetDlgItemText(hWnd, IDC_CONFIG_SOUND_RANDOM_MUSIC, T_RandomMusic);
			//
			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MUSIC, BM_SETCHECK, _ASConfig->bMusic, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_SOUND, BM_SETCHECK, _ASConfig->bSound, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_RANDOM_MUSIC, BM_SETCHECK, _ASConfig->bRandomMusic, 0L);			

		    SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MUSIC_VOLUME, TBM_SETRANGE, FALSE, MAKELONG(1, 255));
			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MUSIC_VOLUME, TBM_SETTIC, TRUE, 128);
			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MUSIC_VOLUME, TBM_SETPOS, TRUE, (long) _ASConfig->iMusicVolume);
  			sprintf(byTemp, "%0.1f%%", (float) _ASConfig->iMusicVolume/255*100);
			SetDlgItemText(hWnd, IDC_CONFIG_SOUND_MUSIC_VOLUME_P, byTemp);

		    SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_SOUND_VOLUME, TBM_SETRANGE, FALSE, MAKELONG(1, 255));
			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_SOUND_VOLUME, TBM_SETTIC, TRUE, 128);
			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_SOUND_VOLUME, TBM_SETPOS, TRUE, (long) _ASConfig->iSoundVolume);
  			sprintf(byTemp, "%0.1f%%", (float) _ASConfig->iSoundVolume/255*100);
			SetDlgItemText(hWnd, IDC_CONFIG_SOUND_SOUND_VOLUME_P, byTemp);
		
			switch(_ASConfig->bySoundOutput)
			{
				case FSOUND_OUTPUT_WINMM: CheckRadioButton(hWnd, IDC_CONFIG_SOUND_WINDOWS_MULTIMEDIA, IDC_CONFIG_SOUND_DIRECT_SOUND, IDC_CONFIG_SOUND_WINDOWS_MULTIMEDIA); break;
				case FSOUND_OUTPUT_DSOUND: CheckRadioButton(hWnd, IDC_CONFIG_SOUND_WINDOWS_MULTIMEDIA, IDC_CONFIG_SOUND_DIRECT_SOUND, IDC_CONFIG_SOUND_DIRECT_SOUND); break;
			}	

		Init:
			EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_SOUND_MUSIC_VOLUME), _ASConfig->bMusic);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_CONFIG_SOUND_MUSIC:
					_ASConfig->bMusic = SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MUSIC, BM_GETCHECK, 0, 0L);
					goto Init;
				break;

				case IDC_CONFIG_SOUND_SOUND:
					_ASConfig->bSound = SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_SOUND, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_SOUND_RANDOM_MUSIC:
					_ASConfig->bRandomMusic = SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_RANDOM_MUSIC, BM_GETCHECK, 0, 0L);
				break;
            }
        break;

        case WM_NOTIFY:
            switch(wParam)
            {
				case IDC_CONFIG_SOUND_MUSIC_VOLUME:
					_ASConfig->iMusicVolume = (int) SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MUSIC_VOLUME, TBM_GETPOS, 0, 0);
					FMUSIC_SetMasterVolume(GameMusic.pMod, _ASConfig->iMusicVolume);
  					sprintf(byTemp, "%0.1f%%", (float) _ASConfig->iMusicVolume/255*100);
					SetDlgItemText(hWnd, IDC_CONFIG_SOUND_MUSIC_VOLUME_P, byTemp);
				break;
				
				case IDC_CONFIG_SOUND_SOUND_VOLUME:
					_ASConfig->iSoundVolume = (int) SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_SOUND_VOLUME, TBM_GETPOS, 0, 0);
					FSOUND_SetSFXMasterVolume(_ASConfig->iSoundVolume);
  					sprintf(byTemp, "%0.1f%%", (float) _ASConfig->iSoundVolume/255*100);
					SetDlgItemText(hWnd, IDC_CONFIG_SOUND_SOUND_VOLUME_P, byTemp);
				break;
			}
		break;
    }
    return FALSE;
} // end ConfigSoundProc()

LRESULT CALLBACK ConfigControlProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin ConfigControlProc()
	char byTemp[256];
	int i;
	
	switch(iMessage)
    {
        case WM_INITDIALOG:
  			// Texts:
  			SetDlgItemText(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY_T, T_MouseSensibility);
			SetDlgItemText(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY_SLOW, T_Slow);
  			SetDlgItemText(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY_NORMAL, T_Normal);
  			SetDlgItemText(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY_FAST, T_Fast);
			//
		    SendDlgItemMessage(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY, TBM_SETRANGE, FALSE, MAKELONG(1, 100));
			SendDlgItemMessage(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY, TBM_SETTIC, TRUE, 50);
			SendDlgItemMessage(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY, TBM_SETPOS, TRUE, (long) ((float) _ASConfig->fMouseSensibility*50.0f));
  			sprintf(byTemp, "%0.1f%%", (float) _ASConfig->fMouseSensibility/0.5f);
			SetDlgItemText(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY_P, byTemp);			
		return TRUE;

        case WM_NOTIFY:
            switch(wParam)
            {
				case IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY:
					i = (int) SendDlgItemMessage(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY, TBM_GETPOS, 0, 0);
					_ASConfig->fMouseSensibility = (float) i/50;
  					sprintf(byTemp, "%0.1f%%", (float) _ASConfig->fMouseSensibility*100);
					SetDlgItemText(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY_P, byTemp);			
				break;
			}
		break;
    }
    return FALSE;
} // end ConfigControlProc()

void SetupConfigTabs(void)
{ // begin SetupConfigTabs()
	HWND hWndTab;
	TC_ITEM tie; 

	// Setup config tabs:
	hWndTab = GetDlgItem(hWndConfig, IDC_CONFIG_TAB);
	TabCtrl_DeleteAllItems(hWndTab);
	tie.mask = TCIF_TEXT;
	// General:
	tie.pszText	= T_General;
	TabCtrl_InsertItem(hWndTab, TAB_CONFIG_GENERAL, &tie);
	if(hWndConfigTab[TAB_CONFIG_GENERAL])
		DestroyWindow(hWndConfigTab[TAB_CONFIG_GENERAL]);
	hWndConfigTab[TAB_CONFIG_GENERAL] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CONFIG_GENERAL), hWndTab, (DLGPROC) ConfigGeneralProc, WM_INITDIALOG);
	// Graphic:
	tie.pszText	= T_Graphic;
	TabCtrl_InsertItem(hWndTab, TAB_CONFIG_GRAPHIC, &tie);
	if(hWndConfigTab[TAB_CONFIG_GRAPHIC])
		DestroyWindow(hWndConfigTab[TAB_CONFIG_GRAPHIC]);
	hWndConfigTab[TAB_CONFIG_GRAPHIC] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CONFIG_GRAPHIC), hWndTab, (DLGPROC) ConfigGraphicProc, WM_INITDIALOG);
	// Sound:
	tie.pszText	= T_Sound;
	TabCtrl_InsertItem(hWndTab, TAB_CONFIG_SOUND, &tie);
	if(hWndConfigTab[TAB_CONFIG_SOUND])
		DestroyWindow(hWndConfigTab[TAB_CONFIG_SOUND]);
	hWndConfigTab[TAB_CONFIG_SOUND] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CONFIG_SOUND), hWndTab, (DLGPROC) ConfigSoundProc, WM_INITDIALOG);
	// Control:
	tie.pszText	= T_Control;
	TabCtrl_InsertItem(hWndTab, TAB_CONFIG_CONTROL, &tie);
	if(hWndConfigTab[TAB_CONFIG_CONTROL])
		DestroyWindow(hWndConfigTab[TAB_CONFIG_CONTROL]);
	hWndConfigTab[TAB_CONFIG_CONTROL] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CONFIG_CONTROL), hWndTab, (DLGPROC) ConfigControlProc, WM_INITDIALOG);
	//
	if(iCurrentConfigTab != -1 && iCurrentConfigTab < CONFIG_TABS)
		TabCtrl_SetCurSel(GetDlgItem(hWndConfig, IDC_CONFIG_TAB), iCurrentConfigTab);
	SendMessage(hWndConfig, WM_NOTIFY, IDC_CONFIG_TAB, 0);
	ShowWindow(hWndConfig, _AS->GetCmdShow());
	UpdateWindow(hWndConfig);
} // end SetupConfigTabs()

void SetConfigLanguage(void)
{ // begin SetConfigLanguage()
	if(!hWndConfig)
		return;
	SetWindowText(hWndConfig, T_Configuration);
  	SetDlgItemText(hWndConfig, ID_CONFIG_OK, T_Ok);
  	SetDlgItemText(hWndConfig, ID_CONFIG_CANCEL, T_Cancel);
  	SetDlgItemText(hWndConfig, ID_CONFIG_QUIT, T_Quit);
  	SetDlgItemText(hWndConfig, IDC_CONFIG_HELP, T_Help);
  	SetDlgItemText(hWndConfig, IDC_CONFIG_CREDITS, T_Credits);
  	SetDlgItemText(hWndConfig, IDC_HOMEPAGE, T_Homepage);  	
	SetupConfigTabs();
} // end SetConfigLanguage()
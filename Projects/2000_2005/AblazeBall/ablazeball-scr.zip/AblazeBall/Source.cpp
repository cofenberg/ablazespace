#include <windows.h>
#include <gl\gl.h>
#include <gl\glu.h>
#include <gl\glaux.h>
#include <stdio.h>
#include "glext.h"


void render_quads(GLvoid)
{
	// first setup texture units, one for the base texture and another for the light texture

	//first texture unit
	glActiveTextureARB(GL_TEXTURE0_ARB);
	glEnable(GL_TEXTURE_2D);

	// second texture unit
	glActiveTextureARB(GL_TEXTURE1_ARB);
	glColor3f(top, top, top);
	glEnable(GL_TEXTURE_2D);

	//render the top quad

	glBegin(GL_QUADS);

		//ceiling
		glNormal3f(0.0f,  -0.5f,  0.0f);

		glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 1.0f, 0.0f); 
		glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 1.0f, 0.0f); 
		glVertex3f(-5.0f, 3.0f, -7.0f);

		glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 1.0f, 1.0f); 
		glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 1.0f, 1.0f); 
		glVertex3f( 5.0f, 3.0f, -7.0f);

		glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 0.0f, 1.0f); 
		glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 0.0f, 1.0f); 
		glVertex3f( 5.0f, 3.0f,  3.0f);

		glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 0.0f, 0.0f); 
		glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 0.0f, 0.0f);
		glVertex3f(-5.0f, 3.0f,  3.0f);

	glEnd();

	// second texture unit
	glActiveTextureARB(GL_TEXTURE1_ARB);
	glBindTexture(GL_TEXTURE_2D, tex[1].texID);
	glColor3f(bottom, bottom, bottom);
	glEnable(GL_TEXTURE_2D);

	//render the bottom quad

	glBegin(GL_QUADS);

		// floor
		glNormal3f(0.0f,  0.5f,  0.0f);

		glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 1.0f, 0.0f); 
		glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 1.0f, 0.0f); 
		glVertex3f(-5.0f, -3.0f, -7.0f);

		glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 1.0f, 1.0f); 
		glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 1.0f, 1.0f); 
		glVertex3f( 5.0f, -3.0f, -7.0f);

		glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 0.0f, 1.0f); 
		glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 0.0f, 1.0f); 
		glVertex3f( 5.0f, -3.0f,  3.0f);

		glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 0.0f, 0.0f); 
		glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 0.0f, 0.0f); 
		glVertex3f(-5.0f, -3.0f,  3.0f);

	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f);
}

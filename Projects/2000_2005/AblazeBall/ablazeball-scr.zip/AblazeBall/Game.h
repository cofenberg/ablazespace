//-----------------------------------------------------------------------------
// File: Game.h
//-----------------------------------------------------------------------------

#ifndef __AS_GAME_H__
#define __AS_GAME_H__


// Definitions: ***************************************************************
#define GAME_TEXTURES 35
#define CAUST_1_STEPS 32
#define GAME_SAMPLES 27
///////////////////////////////////////////////////////////////////////////////
// Standart keys:
#define	STANDART_THRUST_KEY 57
#define	STANDART_LEFT_KEY 203
#define	STANDART_RIGHT_KEY 205
#define	STANDART_UP_KEY 200
#define	STANDART_DOWN_KEY 208
#define	STANDART_INCREASE_TERRAIN_KEY 30
#define	STANDART_DECREASE_TERRAIN_KEY 44
#define	STANDART_STRONG_INCREASE_TERRAIN_KEY 31
#define	STANDART_STRONG_DECREASE_TERRAIN_KEY 45
#define	STANDART_STANDART_VIEW_KEY 15
#define	STANDART_PAUSE_KEY 25
#define	STANDART_HUD_KEY 35
#define STANDART_NEXT_MUSIC_KEY 87

// Static particle systems:
enum
{
	PS_WATER_WAVES, PS_WATER_BUBBLES, PS_ABLAZE_SPACE, PS_WATER_STREAM,
	PS_ABLAZE_TRACE, PS_POINT_TRACE, PS_CENTER_ABLAZE,
};
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern AS_TEXTURE GameTexture[GAME_TEXTURES];	// The game textures
extern AS_TEXTURE Caust1Texture[CAUST_1_STEPS];
extern AS_FMOD_SAMPLE GameSample[GAME_SAMPLES];
extern AS_FMOD_SAMPLE *pThrustSample, *pSparkCommittingSample, *pFireBombObjSample,
					  *pSparkToPointsSample, *pSparkObjSample, *pAiringObjSample,
					  *pWaterContactSample, *pGameOverSample, *pTerraformObjSample,
					  *pMenuSelectSample, *pMenuSelectionSample, *pThrustObjSample,
					  *pMenuBackSample, *pAblazeBallActiveSample,
					  *pSmallAblazeBallTerrainSample, *pBigAblazeBallTerrainSample,
					  *pBallCollisionSample, *pCollisionSample,
					  *pDeathSample, *pGameWonSample, *pAblazeBallInSpaceSample,
					  *pTerraformingSample, *pClapsSample, *pAblazeBallReincarnation,
					  *pLooserSample, *pWinnerSample, *pTopSample;
extern AS_FMOD_MUSIC GameMusic;
extern AS_PARTICLE_MANAGER ParticleManager;
extern int iSkyCubeList, iSphereList[23];
extern int GAME_WINDOW_ID;
extern int iFoundGameMusic;
extern char **pbyFoundGameMusic;
extern int iCurrentSelectedMusic;
extern BOOL bPauseTextBlend, bFlashBlend, bGameOver, bGameWon;
extern float fPauseTextBlend, fFlashBlend, fGameOverBlend;
extern char byCurrentMusic[256];
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern HRESULT Game(void);
extern void EnumerateGameMusic(void);
extern void DestroyFoundGameMusic(void);
extern void StartGameMusic(void);
extern void StopMusic(void);
extern void CheckGameMusic(void);
extern void GetNewGameMusic(void);
extern void CreditsGameMusic(void);
extern void StartCurrentMusic(void);
extern void StopGameMusic(void);
extern void LoadGameTextures(void);
extern void LoadSounds(void);
extern HRESULT GameLoop(void);
extern HRESULT GameDraw(AS_WINDOW *);
extern HRESULT GameCheck(AS_WINDOW *);
extern void UpdateAllTextures(void);
extern void UpdateRenderQuality(void);
extern void CreateGameLists(void);
extern void DestroyGameLists(void);
extern void InitGameParticleSystems(void);
extern void DestroyGameParticleSystems(void);
extern void MakeFlare(float, float, float, float, float, float, float);
extern void DrawFlares(AS_3D_VECTOR);
extern void CreateWaterWave(float, float, float);
extern void CreateWaterStream(float, float, float, float, float, float);
extern void CreateAblazeTrace(float, float, float, float, float, float);
extern void CreatePointTrace(float, float, float, float, float, float);
extern void CreateWaterBombStream(void);
extern void StartNewGame(void);
extern void LevelRestart(void);
extern void ShowSmallMessage(char *, long);
extern void DisplaySmallMessage(AS_WINDOW *);
extern void CheckSmallMessage(void);
extern void RestartSoundSystem(void);
extern void SetGameLanguage(void);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_GAME_H__
//-----------------------------------------------------------------------------
// File: Hud.h
//-----------------------------------------------------------------------------

#ifndef __AS_HUD_H__
#define __AS_HUD_H__


// Classes: *******************************************************************
typedef class RADAR
{
	public:
		AS_2D_VECTOR vCenter;	// Floating version
		float fRadius; // Floating version
		float fBlend; // Radar alpha value

		void Setup(void);
		void GetRadarCoord(AS_3D_VECTOR, AS_2D_VECTOR *);
		void Draw(void);
		void DrawTargetArrow(AS_2D_VECTOR, float);

} RADAR;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern RADAR Radar;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern void DrawHud(AS_WINDOW *);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_HUD_H__
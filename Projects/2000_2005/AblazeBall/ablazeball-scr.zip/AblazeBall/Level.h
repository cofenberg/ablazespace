//-----------------------------------------------------------------------------
// File: Level.h
//-----------------------------------------------------------------------------

#ifndef __LEVEL_H__
#define __LEVEL_H__


// Definitions: ***************************************************************
enum POINT_TYPE
{
	POINT_FIX, POINT_CURRENT, POINT_WATER,
};
#define LEVEL_SIZE 65
#define EPSILON 0.001
///////////////////////////////////////////////////////////////////////////////

// Classes: ****************************************************************---
typedef class FIELD
{
	public:
		int iID; // The field ID
		INT2 iPos; // Field world position
		int iPoint[4]; // The four grid points of the field
		int iNormal[2]; // The triangles normals
		FLOAT3 fBoundingBox[2]; // The fields bounding box min/max x/y/z
		BOOL bInFOV; // Is this field in the field of view?

} FIELD;

// The quatrees are used to improve the field of view culling:
typedef class QUADTREE
{
	public:
		int iChildren; // The number of children
		QUADTREE *pChild; // The children
		QUADTREE *pParent; // The parent quadtree of this quadtree

		BOOL bInFOV; // Is this quadtree in the field of view?
		float fBoundingBox[2][3]; // The quadtrees bounding box min/max x/y/z

		int iStartX, iStartY, // The start cut position of the fields
			iFieldsX, iFieldsY, // The number of x/y fields
			iFields; // The number of fields in this quadtree

		FIELD **pField; // Pointer to the fields in this quadtree


		QUADTREE(void);
		~QUADTREE(void);
		void Build(void *);
		void Destroy(void);
		void SetNotInFOV(void);
		void CheckInFOV(void);
		void SetFieldsInFOV(void);
		void CheckFieldsInFOV(void);
		void GetBoundingBox(void *);
		void GetBoundingBoxZCoord(void *);
		void ShowBoundingBox(void);
		
} QUADTREE;

typedef class LEVEL
{
	public:
		// The grid points:
		FLOAT3 *fFixPoint, // The fixed points
			   *fPoint, // The current points
			   *fWaterPoint, // The heights of the water points
			   *fPointColor, // The color of each point
			   *fPointNormal, // The normal of each point
			   *fNormal; // The normals of the fields (each field has two)
		AS_3D_VECTOR *vNormalRight, // The right normals of each field
					 *vNormalUp; // The up normals of each field
		float *fWaterAmplitude; // The amplitude of each water point
		AS_PLANE *Plane; // The planes of each field (each field has two)
		FLOAT2 *fPointTexCoord; // The texture coordinate of this point
		FIELD *pField, // The fields
			  **pInFOVFields; // Pointer to the fields which are in the FOV
		
		QUADTREE Quadtree; // The levels quadtree
		int iVisibleFieldsNumber, // The number of the visible fields
			iVisiblePointsNumber; // The number of visible points
		int *iVisiblePoints; // A list with the points which are in the FOV
		BOOL *bPointVisible, // Is the grid point in the FOV?
			 *bWaterFieldVisible; // Stores if an water field is visible or not (if it is under the earth)

		int iWidth, iHeight, // The level size
			iPoints, // Total number of grid points
			iFields; // The number of fields

		float fWidth, fHeight, // The level world size
			  fHighestPoint, // The highest point in the level
			  fMiddleHeight, // The middle height
			  fLowestPoint, // The lowest level point
			  fCenter[2]; // The levels center
		
		BOOL bTerrainUpdate; // If the height of the terrain is changed we have to recompose
							 // stuff but if this is done every time it would be too slow!
		long lLastTerrainUpdateTime, // The time since the last terrain update
			 dwLastFogTime; // The time were the last fog was made

		float fFogDensity; // The fog density of the level

		AS_3D_VECTOR vAblazeBallPos[4]; // The positions of the ablaze balls (for the level restart)
		int iAblazeBallsInAblazeSpace; // The number of AblazeBalls wich are in the AblazeSpace

		int iAiringObjects; // The number of airing objects in the level
		long lLastAiringObjectTime; // The time were the last airing object was created
		int iFireBombObjects; // The number of fire bomb objects in the level
		long lLastFireBombObjectTime; // The time were the last fire bomb object was created
		int iSparkObjects; // The number of spark objects in the level
		long lLastSparkObjectTime; // The time were the last spark object was created
		int iThrustEngineObjects; // The number of thrust engine objects in the level
		long lLastThrustEngineObjectTime; // The time were the last thrust engine object was created
		int iTerraformEngineObjects; // The number of terraform engine objects in the level
		long lLastTerraformEngineObjectTime; // The time were the last terraform engine object was created
		
		// If the game is paused the time should be stopped:
		long lLastAiringObjectTimeTemp,
			 lLastFireBombObjectTimeTemp,
		     lLastSparkObjectTimeTemp,
		     lLastThrustEngineObjectTimeTemp,
		     lLastTerraformEngineObjectTimeTemp;
		
		// The ablaze space:
		INT2 iProngPos[4], // The prong positions of the ablaze place
			 iAblazeSpacePos[4]; // The ablaze space points
		
		// For the ablaze space animation: ([0][...] = Prong color   [1][...] = Ablaze space color)
		long lAblazeSpaceAniTime[2][4];
		int  iAblazeSpaceAniSpeed[2][4];
		FLOAT3 fCurrentAblazeSpaceColor[2][4],
			   fNextAblazeSpaceColor[2][4],
			   fLastAblazeSpaceColor[2][4];
		float fNextAblazeColumnRadius[3],
			  fCurrentAblazeColumnRadius[3],
			  fLastAblazeColumnRadius[3];
		int iAblazeColumnAniSpeed[3];
		long lAblazeColumnAniTime[3];

		// Wall animation:
		float fAniWallHeight, // For the wall animation
			  fNewAniWallHeight, // The new wall height
			  fLastAniWallHeight; // The last wall height
		DWORD dwAniWallHeight,
			  dwAniWallHeightSpeed;
		int iWallAniStep[3],
			iWallAniSpeed[3];
		DWORD dwWallAniTime[3];

		// Water animation:
		float fCurrentWaterDensity, // The current water density
			  fCurrentWaterHeight, // The current water height
			  fWaterWavesTimer; // For the water wave movement
		DWORD dwLastWaterBubbleTime, // The time were the last water bubble was created
			  dwWaterBubbleSpeed; // When should the next bubble be created?

		GLint iWallsList[2], // Wall lists
			  iAblazeSpaceColumnList[24]; // The lists for the ablaze space column


		LEVEL(void);
		~LEVEL(void);
		void Create(int, int);
		void Destroy(void);
		void Restart(void);
		void CalculateNormals(void);
		void CalculateFieldBoundingBoxes(void);
		void RealculateFieldBoundingBoxesZCoord(void);
		FLOAT3 *GetPoint(int, int, POINT_TYPE);
		void GetPoint(float, float, INT2 &);
		void DrawSkyCube(void);
		void SetupLights(void);
		void Draw(void);
		void CreateWallsList(void);
		void DestroyWallsList(void);
		void CreateAblazeSpaceColumnLists(void);
		void DestroyAblazeSpaceColumnLists(void);
		void DrawWalls(void);
		void DrawAblazeColumn(void);
		void DrawWater(void);
		void DrawLightMaps(void);
		void DrawShadowMaps(void);
		void PerformLightShadowMapOnTerrain(AS_DLIGHT);
		void Check(void);
		void FOVUpdate(void);
		AS_3D_VECTOR CollideWithWorld(AS_3D_VECTOR, AS_3D_VECTOR, BOOL);
		void CheckCollision(void);
		float FastComputeHeight(float, float, POINT_TYPE);
		void CreateWaterBubbles(void);
		void CreateRandomTerrain(void);

} LEVEL;
///////////////////////////////////////////////////////////////////////////////


// Variables: *****************************************************************
extern LEVEL Level;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
///////////////////////////////////////////////////////////////////////////////


#endif // __LEVEL_H__
//-----------------------------------------------------------------------------
// File: Terrain.h
//-----------------------------------------------------------------------------

#ifndef __TERRAIN_H__
#define __TERRAIN_H__


// Definitions: ***************************************************************
#define WRAP_INDEX	256
#define MOD_MASK	255
#define MAX			4096
///////////////////////////////////////////////////////////////////////////////


/*	Definition of Terms: (cf. Matt Zucker; Ken Perlin)

	Noise Function: a function that takes a coordinate in some space and maps
	it to a real number between -1 and 1 (or between 0 and 1).

	Wavelet: a functions which drops off to zero outside of some region, and
	which integrates to zero. The radius of a wavelet simply refers to the
	distance in its domain space from the wavelet center to where its value
	drops off to zero.

	Perlin Noise: a function for generating coherent noise over a space. Coherent
	noise means that for any two points in the space, the value of the noise
	function changes smoothly as you move from one point to the other--no 
	discontinuities. The key to understanding the algorithm is to think of
	space as being divided into a regular lattice of cubical cels, with one
	pseudorandom wavelet per lattice point. 

*/

// Classes: *******************************************************************
class PERLIN_NOISE
{
	public:
		BOOL m_bInitialized;
		unsigned m_iPermutation[WRAP_INDEX * 2 + 2];	// Lattice table
		float m_fGradient1D[WRAP_INDEX * 2 + 2]; // Gradient tables
		AS_2D_VECTOR m_fGradient2D[WRAP_INDEX * 2 + 2];
		AS_3D_VECTOR m_fGradient3D[WRAP_INDEX * 2 + 2];


		PERLIN_NOISE(void);
		~PERLIN_NOISE(void);
		float RandomPNFloat(void); // Range [-1,1]
		void GenerateLookupTables(void);
		void ReSeed(void);
		float SCurve(float);
		float LinearInterpolation(float, float, float);
		void ComputeDistanceToLatticePoints(float, int &, int &, float &, float &);
		float PNoise1D(float);
		float PNoise2D(AS_2D_VECTOR);
		float PNoise3D(AS_3D_VECTOR);

};
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern PERLIN_NOISE PerlinNoise;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern float fBm(AS_3D_VECTOR, float, float, float);
extern float fBmTurbulence(AS_3D_VECTOR, float, float, float);
extern float HeteroMultiFractal(AS_3D_VECTOR, float, float, float, float);
extern float HybridMultiFractal(AS_3D_VECTOR, float, float, float, float);
extern float RidgedMultiFractal(AS_3D_VECTOR, float, float, float, float, float);
extern float MultiFractal(AS_3D_VECTOR, float, float, float, float);
///////////////////////////////////////////////////////////////////////////////


#endif // __TERRAIN_H__
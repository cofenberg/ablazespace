//-----------------------------------------------------------------------------
// File: Hud.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
RADAR Radar;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
void DrawHud(AS_WINDOW *);
///////////////////////////////////////////////////////////////////////////////


// RADAR functions: ***********************************************************
// Setup the radar:
void RADAR::Setup(void)
{ // begin RADAR::Setup()
	vCenter.fX = _ASConfig->iWindowWidth-80.0f;
	vCenter.fY = _ASConfig->iWindowHeight-80.0f;
	fRadius = _ASConfig->iWindowHeight/8.0f-10.0f;
} // end RADAR::Setup()

// Compute the two-D radar coordinates of an object:
void RADAR::GetRadarCoord(AS_3D_VECTOR vPos, AS_2D_VECTOR *vRadarPos)
{ // begin RADAR::GetRadarCoord()
	ACTOR *pPlayer = Player.pActor;
	AS_3D_VECTOR vDeltaPos;

	// Compute coords of object relative to player:
	vDeltaPos = vPos-pPlayer->vWorldPos;
	
	// Normalize that:
	vDeltaPos.Normalize();

	// Convert to cartesian:
	(*vRadarPos).fX = vCenter.fX+vDeltaPos.fX*fRadius*_ASCamera->fSin90-vDeltaPos.fY*fRadius*_ASCamera->fSin;
	(*vRadarPos).fY = vCenter.fY+vDeltaPos.fX*fRadius*_ASCamera->fCos90-vDeltaPos.fY*fRadius*_ASCamera->fCos;
} // end RADAR::GetRadarCoord()

// Display the Wing Commander-like radar:
void RADAR::Draw(void)
{ // begin RADAR::Draw()
	AS_2D_VECTOR vRadarPos, vPos2D;
	AS_3D_VECTOR vPos, vWorldPosT;
	AS_3D_VECTOR vDeltaPos;
	ACTOR *pActorT;
	int i;

	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_CULL_FACE);


	// Draw direction arrows:
	// Arrow pointing to the ablaze space:
	vWorldPosT.fX = Level.fWidth/2-0.5f;
	vWorldPosT.fY = Level.fHeight/2-0.5f;
	vWorldPosT.fZ = Actor[0].vWorldPos.fZ;
	vDeltaPos = vWorldPosT-Player.pActor->vWorldPos;
	if(vDeltaPos.GetLength() > 2.0f)
	{
		glColor4f(1.0f, 1.0f, 1.0f, fBlend);
		GetRadarCoord(vWorldPosT, &vPos2D);
		vPos2D -= Radar.vCenter;
		DrawTargetArrow(vPos2D, 20.0f);
	}

	for(i = 1; i < 5; i++)
	{
		pActorT = &Actor[i];
		if(!pActorT->bActive || pActorT == Player.pActor)
			continue;
		Radar.GetRadarCoord(pActorT->vWorldPos, &vPos2D);
		vPos2D -= Radar.vCenter;
		switch(pActorT->Type)
		{
			case ACTOR_AblazeBall:
				glColor4f(1.0f, 0.0f, 0.0f, fBlend);
				DrawTargetArrow(vPos2D, 40);
			break;
		}
	}

	// Draw the radar itself:
	glColor4f(1.0f, 1.0f, 1.0f, fBlend);
	glLoadIdentity();
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	glOrtho(0.0, ((double) _ASConfig->iWindowWidth), 0.0,
			((double) _ASConfig->iWindowHeight), -1.0, 1.0);
	glTranslatef((float) _ASCamera->vShakePos.fX*300*_ASCamera->fShakePower,
				 (float) _ASCamera->vShakePos.fY*300*_ASCamera->fShakePower,
				 0.0f);

	// Draw the radar bitmap:
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, GameTexture[9].iOpenGLID);
	glEnable(GL_BLEND);
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f);
		glVertex2f(vCenter.fX-fRadius, vCenter.fY-fRadius);
		glTexCoord2f(1.0f, 0.0f);
		glVertex2f(vCenter.fX+fRadius, vCenter.fY-fRadius);
		glTexCoord2f(1.0f, 1.0f);
		glVertex2f(vCenter.fX+fRadius, vCenter.fY+fRadius);
		glTexCoord2f(0.0f, 1.0f);
		glVertex2f(vCenter.fX-fRadius, vCenter.fY+fRadius);
	glEnd();
	glDisable(GL_TEXTURE_2D);


	// Draw radar points:
	// Ablaze space:
	glColor4f(1.0f, 1.0f, 1.0f, fBlend);
	glPointSize(10.0f);
	Radar.GetRadarCoord(vWorldPosT, &vPos2D);
	glBegin(GL_POINTS);
		glVertex2f(vPos2D.fX, vPos2D.fY);
	glEnd();
	
	// Actors:
	glBegin(GL_POINTS);
		for(i = 1; i < MAX_ACTORS; i++)
		{
			pActorT = &Actor[i];
			if(!pActorT->bActive || pActorT->Type == ACTOR_Text)
				continue;
			Radar.GetRadarCoord(pActorT->vWorldPos, &vPos2D);
			switch(pActorT->Type)
			{
				case ACTOR_AblazeBall:
					glColor4f(1.0f, 0.0f, 0.0f, fBlend);
					glPointSize(2.0f);
				break;

				case ACTOR_AiringObj:
					glColor4f(0.0f, 0.0f, 1.0f, fBlend);
					glPointSize(2.0f);
				break;

				case ACTOR_FireBombObj:
					glColor4f(1.0f, 0.0f, 1.0f, fBlend);
					glPointSize(2.0f);
				break;

				case ACTOR_SparkObj:
					glColor4f(1.0f, 1.0f, 0.0f, fBlend);
					glPointSize(2.0f);
				break;

				case ACTOR_ThrustEngineObj:
					glColor4f(0.0f, 1.0f, 0.0f, fBlend);
					glPointSize(2.0f);
				break;

				case ACTOR_TerraformEngineObj:
					glColor4f(0.5f, 0.5f, 0.5f, fBlend);
					glPointSize(2.0f);
				break;
			}
			glVertex2f(vPos2D.fX, vPos2D.fY);
		}
	glEnd();


	glEnable(GL_BLEND);
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_CULL_FACE);
	glEnable(GL_DEPTH_TEST);
	ASEnableLighting();
	glEnable(GL_TEXTURE_2D);
	glPointSize(1.0f);
} // end RADAR::Draw()

// Draw an arrow pointing in an given direction:
void RADAR::DrawTargetArrow(AS_2D_VECTOR vPos, float fLength)
{ // begin RADAR::DrawTargetArrow()
	float fAngle, fM[16];
	
	// Should the arrow be shown?
	if(vPos.fX > -0.3f && vPos.fY > -0.3f &&
	   vPos.fX < 0.3f && vPos.fY < 0.3f)
	   return; // No, the point is in the players view
	glGetFloatv(GL_MODELVIEW_MATRIX, fM);
	glLoadIdentity();
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	glOrtho(0.0, ((double) _ASConfig->iWindowWidth), 0.0,
			((double) _ASConfig->iWindowHeight), -1.0, 1.0);
	glTranslatef((float) _ASCamera->vShakePos.fX*300*_ASCamera->fShakePower,
				 (float) _ASCamera->vShakePos.fY*300*_ASCamera->fShakePower,
				 0.0f);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);
	glDisable(GL_CULL_FACE);
	glDisable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glLineWidth(1.0f);
	
	// Get arrow angle:
	if(vPos.fX != 0)
	{
		if(vPos.fX > 0)
			fAngle = (float) (atan(vPos.fY/vPos.fX)*RAD_TO_DEG);
		else
			fAngle = (float) ((atan(vPos.fY/vPos.fX)*RAD_TO_DEG)-180.0f);
	}
	
	// Setup arrow:
	glTranslatef(vCenter.fX, vCenter.fY, 0.0f);
	glRotatef(fAngle, 0.0f, 0.0f, 1.0f);
	
	// Draw arrow:
	glBegin(GL_LINES);
		glVertex3f(0.0f, 5.0f, 0.0f);
		glVertex3f(fLength, 0.0f, 0.0f);
		glVertex3f(0.0f, -5.0f, 0.0f);
		glVertex3f(fLength, 0.0f, 0.0f);
		glVertex3f(0.0f, -5.0f, 0.0f);
		glVertex3f(0.0f, 5.0f, 0.0f);
	glEnd();

	glLoadMatrixf(fM);
} // end RADAR::DrawTargetArrow()
///////////////////////////////////////////////////////////////////////////////


void DrawHud(AS_WINDOW *pWindow)
{ // begin DrawHud()
	int iX, iY;
	char byTemp[256];

	if(!Setup.bShowHud || fGameMenuBlend == 1.0f)
		return; // The hud isn't active
	
	if(!bGameWon)
	{
		if(fGameOverBlend)
			Radar.fBlend = 1.0f-fGameOverBlend;
		else
			Radar.fBlend = 1.0f-fGameMenuBlend;
	}

	// Draw the radar:
	glEnable(GL_POINT_SMOOTH);
	glEnable(GL_LINE_SMOOTH);
	Radar.Draw();
	glDisable(GL_POINT_SMOOTH);
	glDisable(GL_LINE_SMOOTH);

	glLoadIdentity();
	glDisable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);
	glColor4f(1.0f, 1.0f, 1.0f, Radar.fBlend);
	
	iX = (int) (_ASCamera->vShakePos.fX*300*_ASCamera->fShakePower);
	iY = (int) (_ASCamera->vShakePos.fY*300*_ASCamera->fShakePower);

	glColor4f(1.0f, 1.0f, 1.0f, Radar.fBlend);

	// Score:
	sprintf(byTemp, "%s: %d", T_Score, Player.iScore);
	pWindow->PrintAnimated(10+iX, 570+iY, byTemp, 0, 1.3f, fFontAni, 0);

	// Lives:
	sprintf(byTemp, "%s: %d", T_Lives, Player.iLives);
	if(!Player.iLives)
	{
		glColor4f(1.0f, 0.0f, 0.0f, Radar.fBlend);
		pWindow->PrintAnimated(10+iX, 550+iY, byTemp, 0, 1.5f, fFontAni, 0);
	}
	else
		pWindow->PrintAnimated(10+iX, 550+iY, byTemp, 0, 1.5f, fFontAni, 0);

	glColor4f(1.0f, 1.0f, 1.0f, Radar.fBlend);
	if(5-Level.iAblazeBallsInAblazeSpace)
	{
		sprintf(byTemp, "*%d", 5-Level.iAblazeBallsInAblazeSpace);
		pWindow->PrintAnimated(750+iX, 30+iY, byTemp, 0, 1.5f, fFontAni, 0);
	}

	// Fire:
	glLoadIdentity();
	glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_DEPTH_TEST);
	glTranslatef(-0.5f+(float) iX/150, 0.75f+(float) iY/150, -2.0f);
	glColor4f(0.0f, 0.0f, 0.0f, 0.2f*Radar.fBlend+(1-Radar.fBlend));
	glBlendFunc(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);
	glBegin(GL_QUADS);
		glVertex3f(-0.01f, -0.01f, 0.0f);
		glVertex3f(1.0f+0.01f, -0.01f, 0.0f);
		glVertex3f(1.0f+0.01f, 0.03f, 0.0f);
		glVertex3f(-0.01f, 0.03f, 0.0f);
	glEnd();
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, Caust1Texture[Level.iWallAniStep[0]].iOpenGLID);
	glColor4f(1.0f-Player.pActor->fFire, Player.pActor->fFire, 0.0f, Radar.fBlend);
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(0.0f, 0.0f, 0.0f);
		glTexCoord2f(Player.pActor->fFire*10.0f, 0.0f);
		glVertex3f(1.0f*Player.pActor->fFire, 0.0f, 0.0f);
		glTexCoord2f(Player.pActor->fFire*10.0f, 1.0f);
		glVertex3f(1.0f*Player.pActor->fFire, 0.02f, 0.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(0.0f, 0.02f, 0.0f);
	glEnd();
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);

	// Thrust engine:
	glLoadIdentity();
	glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_DEPTH_TEST);
	glTranslatef(-1.0f+(float) iX/150, -0.45f+(float) iY/150, -2.0f);
	glRotatef(80.0f, 0.0f, 0.0f, 1.0f);
	glColor4f(0.0f, 0.0f, 0.0f, 0.2f*Radar.fBlend+(1-Radar.fBlend));
	glBlendFunc(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);
	glBegin(GL_QUADS);
		glVertex3f(-0.01f, -0.01f, 0.0f);
		glVertex3f(1.0f+0.01f, -0.01f, 0.0f);
		glVertex3f(1.0f+0.01f, 0.04f, 0.0f);
		glVertex3f(-0.01f, 0.04f, 0.0f);
	glEnd();
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, Caust1Texture[Level.iWallAniStep[0]].iOpenGLID);
	glColor4f(1.0f-Player.pActor->fThrustEngine, 0.0f, Player.pActor->fThrustEngine, Radar.fBlend);
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(0.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(1.0f*Player.pActor->fThrustEngine, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(1.0f*Player.pActor->fThrustEngine, 0.03f, 0.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(0.0f, 0.03f, 0.0f);
	glEnd();
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);

	// Terraform engine:
	glLoadIdentity();
	glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_DEPTH_TEST);
	glTranslatef(-1.0f+(float) iX/150, -0.75f+(float) iY/150, -2.0f);
	glColor4f(0.0f, 0.0f, 0.0f, 0.2f*Radar.fBlend+(1-Radar.fBlend));
	glBlendFunc(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);
	glBegin(GL_QUADS);
		glVertex3f(-0.01f, -0.01f, 0.0f);
		glVertex3f(1.0f+0.01f, -0.01f, 0.0f);
		glVertex3f(1.0f+0.01f, 0.03f, 0.0f);
		glVertex3f(-0.01f, 0.03f, 0.0f);
	glEnd();
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, Caust1Texture[Level.iWallAniStep[0]].iOpenGLID);
	glColor4f(1.0f-Player.pActor->fTerraformEngine/2, Player.pActor->fTerraformEngine/2, 0.0f, Radar.fBlend);
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(0.0f, 0.0f, 0.0f);
		glTexCoord2f(Player.pActor->fTerraformEngine*10.0f, 0.0f);
		glVertex3f(1.0f*Player.pActor->fTerraformEngine, 0.0f, 0.0f);
		glTexCoord2f(Player.pActor->fTerraformEngine*10.0f, 1.0f);
		glVertex3f(1.0f*Player.pActor->fTerraformEngine, 0.02f, 0.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(0.0f, 0.02f, 0.0f);
	glEnd();
	
	glEnable(GL_TEXTURE_2D);
	if(3-Level.iAblazeBallsInAblazeSpace)
	{
		glBindTexture(GL_TEXTURE_2D, GameTexture[31].iOpenGLID);
		glColor4f(1.0f, 1.0f, 1.0f, Radar.fBlend);
		glLoadIdentity();
		glTranslatef(4.5f+(float) iX/50, -3.5f+(float) iY/50, -10.0f);
		glBegin(GL_QUADS);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(-0.5f, -0.5f, 0.0f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(0.5f, -0.5f, 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(0.5f, 0.5f, 0.0f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(-0.5f, 0.5f, 0.0f);
		glEnd();
	}

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);

} // end DrawHud()

//-----------------------------------------------------------------------------
// File: Logos.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
BOOL bShowLogos, bShowTitel;
int iStep, iASLogoPSSystem;
long lLogoStartTime;
float fBallVelocity, fBallPos, fBallRot, fAblazeSpaceBlend, fTitelBlend;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
void Logos(void);
HRESULT LogosDraw(AS_WINDOW *);
HRESULT LogosCheck(AS_WINDOW *);
void DrawLogoBox(short [6]);
void InitLogos(void);
void SetLogosCamera(void);
///////////////////////////////////////////////////////////////////////////////


void Logos(void)
{ // begin Logos()
	MSG msg;

	if(!_ASConfig->bShowLogo)
	{
		bShowLogos = FALSE;
		return;
	}
	
	_AS->bDraw = FALSE;
	_AS->pWindow[GAME_WINDOW_ID].SetDrawFunction(LogosDraw);
	_AS->pWindow[GAME_WINDOW_ID].SetCheckFunction(LogosCheck);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0f, (GLfloat)(_ASConfig->iWindowWidth)/(GLfloat)(_ASConfig->iWindowHeight), 0.1f, 2000.0f);
	glMatrixMode(GL_MODELVIEW);

	glEnable(GL_TEXTURE_2D);
	glEnable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);
	glDisable(GL_FOG);
	
	DestroyGameParticleSystems();
	InitLogos();
	lLogoStartTime = GetTickCount();

	bShowLogos = TRUE;
	_AS->bDraw = TRUE;

	for(;;)
	{
		if(PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
		{
			if(!GetMessage(&msg, NULL, 0, 0))
				break;
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else
		{	
			if(_AS->GetShutDown() || _AS->CheckModuleChange() || !bShowLogos)
				PostQuitMessage(0);
			if(!_AS->GetActive())
				continue;
			_AS->UpdateWindows();
		}
	}
	DestroyGameParticleSystems();
} // end Logos()

HRESULT LogosDraw(AS_WINDOW *pWindow)
{ // begin LogosDraw()
	GLfloat afLightData[4]  = {0.0f, 0.0f, 0.0f, 0.0f};

	if(!_AS->bDraw)
		return 0;

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0f, (GLfloat)(_ASConfig->iWindowWidth)/(GLfloat)(_ASConfig->iWindowHeight), 0.1f, 2000.0f);
	glMatrixMode(GL_MODELVIEW);

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	glTranslatef(0.0f, 0.0f, -190.0f-fBallPos);
	glRotatef(fBallRot, 1.0f, 0.0f, 0.0f);
	glTranslatef(-50.0f, -20.0f, 0.0f);
	ParticleManager.Draw();

	glDisable(GL_LIGHTING);
	if(fAblazeSpaceBlend)
	{
		glEnable(GL_BLEND);
		glColor4f(1.0f, 1.0f, 1.0f, fAblazeSpaceBlend);
		pWindow->PrintAnimated(400, (int) (80*fAblazeSpaceBlend-80*(1-fAblazeSpaceBlend)), "AblazeSpace", 0, 3.2f, fFontAni, 1);
	}
	
	if(fTitelBlend)
	{
		glDisable(GL_DEPTH_TEST);
		glEnable(GL_BLEND);
		glEnable(GL_TEXTURE_2D);
		glColor4f(1.0f, 1.0f, 1.0f, fTitelBlend);
		glBindTexture(GL_TEXTURE_2D, GameTexture[33].iOpenGLID);
		glLoadIdentity();
		glTranslatef(0.0f, 0.0f, -24.0f);
		glBegin(GL_QUADS);
			glTexCoord2f(0.0f, 1.0f);
			glVertex2f(-14.0f, -10.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex2f(14.0f, -10.0f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex2f(14.0f, 10.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex2f(-14.0f, 10.0f);
		glEnd();
	}

	ASSwapBuffers(*pWindow->GethDC(), pWindow, TRUE);
	return 0;
} // end LogosDraw()

HRESULT LogosCheck(AS_WINDOW *pWindow)
{ // begin LogosCheck()
	int i;
	
	_AS->ReadDXInput(*pWindow->GethWnd());
	if((CHECK_KEY(ASMouse.byButtons, 0) && ASMouse.byButtonFirst[0]) ||
	   (CHECK_KEY(ASMouse.byButtons, 1) && ASMouse.byButtonFirst[1]) ||
	   (CHECK_KEY(ASMouse.byButtons, 2) && ASMouse.byButtonFirst[2]))
		ASKeyFirst[DIK_SPACE] = TRUE;
	AnimateFont();

	ParticleManager.Check();
	if(g_lNow-lLogoStartTime > 18000 && !fTitelBlend)
	{
		ParticleManager.pSystem[iASLogoPSSystem].bGoingInActive = TRUE;
		bShowTitel = TRUE;
	}
	
	if(bShowTitel)
	{
		fTitelBlend += (float) g_lDeltatime/17000;
		if(fTitelBlend >= 1.0f)
		{
			fTitelBlend = 1.0f;
			bShowTitel = FALSE;
		}
	}
	else
	{
		fTitelBlend -= (float) g_lDeltatime/7000;
		if(fTitelBlend < 0.0f)
			fTitelBlend = 0.0f;
	}

	if(!ParticleManager.pSystem[iASLogoPSSystem].bActive && !fTitelBlend)
		bShowLogos = FALSE;

	for(i = 0; i < 256; i++)
		if(ASKeyFirst[i])
		{
			ParticleManager.pSystem[iASLogoPSSystem].bGoingInActive = TRUE;
			bShowLogos = FALSE;
			break;
		}

	fBallPos -= fBallVelocity*((float) g_lDeltatime/15);
	fBallVelocity -= fBallVelocity/100.0f*((float) g_lDeltatime/30);
	if(fBallVelocity < 0.05f)
	{
		fBallRot -= fBallRot/100.0f*((float) g_lDeltatime/30);
		if(fBallRot < 0.0f)
			fBallRot = 0.0f;
		if(!ParticleManager.pSystem[iASLogoPSSystem].bTemp)
		{
			ParticleManager.pSystem[iASLogoPSSystem].bTemp = TRUE;
			lLogoStartTime = GetTickCount();
		}
	}
	else
		fBallRot += fBallVelocity*((float) g_lDeltatime);

	if(ParticleManager.pSystem[iASLogoPSSystem].bTemp)
	{
		if(ParticleManager.pSystem[iASLogoPSSystem].bGoingInActive)
		{
			fAblazeSpaceBlend -= (float) g_lDeltatime/10000;
			if(fAblazeSpaceBlend > 1.0f)
				fAblazeSpaceBlend = 1.0f;
		}
		else
		{
			fAblazeSpaceBlend += (float) g_lDeltatime/13000;
			if(fAblazeSpaceBlend > 1.0f)
				fAblazeSpaceBlend = 1.0f;
		}
	}

	return 0;
} // end LogosCheck()

void InitLogos(void)
{ // begin InitLogos()
	AS_PARTICLE_SYSTEM *pSystemT;
	AS_PARTICLE *pParticleT;
	float fAngle, fAngle2;
	int i;
	
	iASLogoPSSystem = ParticleManager.AddNewSystem(PS_ASLogo, GameTexture[23].iWidth*GameTexture[23].iHeight, NULL, &GameTexture[16], &GameTexture[23]);
	ParticleManager.pSystem[iASLogoPSSystem].bActive = TRUE;
	pSystemT = &ParticleManager.pSystem[iASLogoPSSystem];
	pSystemT->bActive = TRUE;
	pSystemT->bAnimatedParticles = TRUE;
	pSystemT->iAnimationColumns = 4;
	pSystemT->iAnimationRows = 4;
	pSystemT->iTextureWidth = 256;
	pSystemT->iTextureHeight = 256;
	for(i = 0; i < pSystemT->iParticles; i++)
		pSystemT->pParticle[i].iAnimationStep = rand() % pSystemT->iAnimationColumns*pSystemT->iAnimationRows;

	// Make an particle ball:
	for(i = 0; i < ParticleManager.pSystem[iASLogoPSSystem].iParticles; i++)
	{
		pParticleT = &ParticleManager.pSystem[iASLogoPSSystem].pParticle[i];
		
		fAngle = (float) (rand() % 36000)/100;
		fAngle2 = (float) (rand() % 36000)/100;
		pParticleT->fPos[X] = (float) (cos(fAngle*DEG_TO_RAD)*12*cos(fAngle2*DEG_TO_RAD));
		pParticleT->fPos[Y] = (float) (sin(fAngle*DEG_TO_RAD)*12*cos(fAngle2*DEG_TO_RAD));
		pParticleT->fPos[Z] = (float) (sin(fAngle2*DEG_TO_RAD)*12);
		pParticleT->fPos[X] += 50.0f;
		pParticleT->fPos[Y] += 20.0f;
	}

	fBallVelocity = 1.0f;	fBallPos = 100.0f;
	fBallRot = 0.0f;
	fAblazeSpaceBlend = 0.0f;
	bShowTitel = FALSE;
	fTitelBlend = 0.0f;
} // end InitLogos()

void SetLogosCamera(void)
{ // begin SetLogosCamera()
	glLoadIdentity();
	glTranslatef(0.0f, 0.0f, -1.5f);
	glRotatef(20.0f, 1.0f, 0.0f, 0.0f);
} // end SetLogosCamera()
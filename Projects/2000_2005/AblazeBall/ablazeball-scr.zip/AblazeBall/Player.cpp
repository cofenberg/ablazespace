//-----------------------------------------------------------------------------
// File: Player.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
PLAYER Player; // Player information
///////////////////////////////////////////////////////////////////////////////


// PLAYER functions: **********************************************************
PLAYER::PLAYER(void)
{ // begin PLAYER::PLAYER()
	Init();
} // end PLAYER::PLAYER()

PLAYER::~PLAYER(void)
{ // begin PLAYER::~PLAYER()
} // end PLAYER::~PLAYER()

void PLAYER::Init(void)
{ // begin PLAYER::Init()
	Player.pActor = &Actor[0];
	Player.pActor->fThrustEngine = 1.0f;
	Player.pActor->fTerraformEngine = 1.0f;
	iLives = 3;
	iScore = 0;
} // end PLAYER::Init()

void PLAYER::Check(void)
{ // begin PLAYER::Check()
	int iXStart, iYStart, iXEnd, iYEnd, iX, iY;
	float fXAcceleration, fYAcceleration, fR;
	char byTemp[256];
	ACTOR *pActor;
	INT2 iPos;
		
	if(bShowGameMenu || bGameOver)
		return;

	pActor = Player.pActor;
	if(bInvulnerable)
		pActor->fFire = 1.0f;
	if(bUnlimitedThrust)
		pActor->fThrustEngine = 1.0f;
	if(bUnlimitedTerraform)
		pActor->fTerraformEngine = 1.0f;
	if(bUnlimitedSparks)
		pActor->iSparks = 4;
	if(!pActor->bActive)
	{ // Rebirth the players actor:
		Player.iLives--;
		if(Player.iLives >= 0)
		{
			ASPlayFmodSample(pAblazeBallReincarnation, FSOUND_LOOP_OFF);
			pActor->bActive = TRUE;
			pActor->bGoingDeath = FALSE;
			pActor->vWorldPos.fZ = Level.fHighestPoint-27.0f-pActor->fRadius*2-1.0f;
			pActor->fFire = 1.0f;
			pActor->fThrustEngine = 1.0f;
			pActor->fTerraformEngine = 1.0f;
			pActor->iSparks = 0;
			pActor->vWorldPos.fX = Level.fWidth/2-0.5f;
			pActor->vWorldPos.fY = Level.fHeight/2-0.5f;
			Player.iScore -= 200;
			if(Player.iScore < 0)
				Player.iScore = 0;
			sprintf(byTemp, "-500 %s", T_Points);
			CreateTextActor(byTemp, pActor->vWorldPos);
			fFlashBlend = TRUE;
		}
		else
		{ // Game over:
			ASPlayFmodSample(pGameOverSample, FSOUND_LOOP_OFF);
			bGameOver = bPause = TRUE;
			fGameOverBlend = 0.0f;
			return;
		}
	}

	//	Mouse camera movement and rotate:
	// Compute the player acceleration corresponding the mouse movement:
	fXAcceleration = ((float) ASMouse.lX)*_ASConfig->fMouseSensibility;
	if(fXAcceleration)
		fXAcceleration /= 30.0f;
	fYAcceleration = ((float) ASMouse.lY)*_ASConfig->fMouseSensibility;
	if(fYAcceleration)
		fYAcceleration /= 30.0f;
	
	if(CHECK_KEY(ASMouse.byButtons, 0) && CHECK_KEY(ASMouse.byButtons, 1))
	{ // Camera zoom:
		_ASCamera->fZoomVelocity -= ((float) fYAcceleration*5);
	}
	else
	{
		if(CHECK_KEY(ASMouse.byButtons, 0))
		{ // Move camera view:
			_ASCamera->vPos.fX -= _ASCamera->fSin90*fXAcceleration;
			_ASCamera->vPos.fX -= _ASCamera->fSin*fYAcceleration;
			_ASCamera->vPos.fY -= _ASCamera->fCos90*fXAcceleration;
			_ASCamera->vPos.fY -= _ASCamera->fCos*fYAcceleration;
		}
		if(CHECK_KEY(ASMouse.byButtons, 1))
		{ // Rotate camera view:
			_ASCamera->fRot2Velocity[Z] -= (float) fXAcceleration*3;
			_ASCamera->fRot2Velocity[X] -= (float) fYAcceleration*3;
		}
		if((!CHECK_KEY(ASMouse.byButtons, 0) && !CHECK_KEY(ASMouse.byButtons, 1)) ||
		   CHECK_KEY(ASMouse.byButtons, 2) && !bPause)
		{ // Move player plus camera:
			// Move the players actor:
			pActor->vWorldVelocity.fX += _ASCamera->fSin90*fXAcceleration/40+
										 _ASCamera->fSin*fYAcceleration/40;
			pActor->vWorldVelocity.fY += _ASCamera->fCos90*fXAcceleration/40+
										 _ASCamera->fCos*fYAcceleration/40;
			
			// Move the camera view:
			_ASCamera->vPos.fX -= _ASCamera->fSin90*((float) g_lDeltatime/500.0f)*fXAcceleration-
								  _ASCamera->fSin*((float) g_lDeltatime/500.0f)*fYAcceleration;
			_ASCamera->vPos.fY -= _ASCamera->fCos90*((float) g_lDeltatime/500.0f)*fXAcceleration-
								  _ASCamera->fCos*((float) g_lDeltatime/500.0f)*fYAcceleration;

			_ASCamera->vRotTemp.fX += fYAcceleration/5;
			_ASCamera->vRotTemp.fY += fXAcceleration/5;
		}
	}
	
	// Check camera keys:
	if(CHECK_KEY(ASKeys, _ASConfig->iLeftKey[0]))
	{
		_ASCamera->vPos.fX += _ASCamera->fSin90*((float) g_lDeltatime/500.0f)*5;
		_ASCamera->vPos.fY += _ASCamera->fCos90*((float) g_lDeltatime/500.0f)*5;
	}
	if(CHECK_KEY(ASKeys, _ASConfig->iRightKey[0]))
	{
		_ASCamera->vPos.fX -= _ASCamera->fSin90*((float) g_lDeltatime/500.0f)*5;
		_ASCamera->vPos.fY -= _ASCamera->fCos90*((float) g_lDeltatime/500.0f)*5;
	}
	if(CHECK_KEY(ASKeys, _ASConfig->iUpKey[0]))
	{
		_ASCamera->vPos.fX += _ASCamera->fSin*((float) g_lDeltatime/500.0f)*5;
		_ASCamera->vPos.fY += _ASCamera->fCos*((float) g_lDeltatime/500.0f)*5;
	}
	if(CHECK_KEY(ASKeys, _ASConfig->iDownKey[0]))
	{
		_ASCamera->vPos.fX -= _ASCamera->fSin*((float) g_lDeltatime/500.0f)*5;
		_ASCamera->vPos.fY -= _ASCamera->fCos*((float) g_lDeltatime/500.0f)*5;
	}

	if(bPause)
		return;

	// Check player keys:
	if(CHECK_KEY(ASKeys, _ASConfig->iThrustKey[0]) && pActor->fFire)
	{
	 	pActor->fThrustPower += (float) g_lDeltatime/1000;
		if(pActor->fThrustPower > 1.0f)
			pActor->fThrustPower = 1.0f;
	}
	else
	{
	 	pActor->fThrustPower -= (float) g_lDeltatime/1000;
		if(pActor->fThrustPower < 0.0f)
			pActor->fThrustPower = 0.0f;
	}

	// Get the current grid point the ball is on:
	Level.GetPoint(pActor->vWorldPos.fX, pActor->vWorldPos.fY, iPos);
	if(CHECK_KEY(ASKeys, _ASConfig->iStrongIncreaseTerrainKey[0]) &&
	   iPos[X] >= 1 && iPos[Y] >= 1 && iPos[X] < Level.iWidth-1 && iPos[Y] < Level.iHeight-1 &&
	   pActor->fTerraformEngine)
	{
		ASPlayFmodSample(pTerraformingSample, FSOUND_LOOP_NORMAL);
		iXStart = iPos[X]-2;
		if(iXStart < 0)
			iXStart = 0;
		iYStart = iPos[Y]-2;
		if(iYStart < 0)
			iYStart = 0;
		iXEnd = iPos[X]+3;
		if(iXEnd >= Level.iWidth)
			iXEnd = Level.iWidth-1;
		iYEnd = iPos[Y]+3;
		if(iYEnd >= Level.iHeight)
			iYEnd = Level.iHeight-1;
		for(iY = iYStart; iY < iYEnd; iY++)
			for(iX = iXStart; iX < iXEnd; iX++)
			{
				fR = (float) sqrt((iX-iPos[X])*(iX-iPos[X])+(iY-iPos[Y])*(iY-iPos[Y]));
				if(fR < 1.0f)
					fR = 1.0f;
				Level.fPoint[iX+iY*Level.iWidth][Z] -= (float) (g_lDeltatime*pActor->fFire)/(300*fR);
				if(Level.fPoint[iX+iY*Level.iWidth][Z] < Level.fHighestPoint-10)
					Level.fPoint[iX+iY*Level.iWidth][Z] = Level.fHighestPoint-10;
			}
		Level.bTerrainUpdate = TRUE;
		pActor->fTerraformEngine -= (float) (g_lDeltatime*pActor->fFire)/25000;
		if(pActor->fTerraformEngine < 0.0f)
			 pActor->fTerraformEngine = 0.0f;
	}
	else
	if(CHECK_KEY(ASKeys, _ASConfig->iStrongDecreaseTerrainKey[0]) &&
	   iPos[X] >= 1 && iPos[Y] >= 1 && iPos[X] < Level.iWidth-1 && iPos[Y] < Level.iHeight-1 &&
	   pActor->fTerraformEngine)
	{
		ASPlayFmodSample(pTerraformingSample, FSOUND_LOOP_NORMAL);
		iXStart = iPos[X]-2;
		if(iXStart < 0)
			iXStart = 0;
		iYStart = iPos[Y]-2;
		if(iYStart < 0)
			iYStart = 0;
		iXEnd = iPos[X]+3;
		if(iXEnd >= Level.iWidth)
			iXEnd = Level.iWidth-1;
		iYEnd = iPos[Y]+3;
		if(iYEnd >= Level.iHeight)
			iYEnd = Level.iHeight-1;
		for(iY = iYStart; iY < iYEnd; iY++)
			for(iX = iXStart; iX < iXEnd; iX++)
			{
				fR = (float) sqrt((iX-iPos[X])*(iX-iPos[X])+(iY-iPos[Y])*(iY-iPos[Y]));
				if(fR < 1.0f)
					fR = 1.0f;
				Level.fPoint[iX+iY*Level.iWidth][Z] += (float) (g_lDeltatime*pActor->fFire)/(300*fR);
				if(Level.fPoint[iX+iY*Level.iWidth][Z] > Level.fLowestPoint+10)
					Level.fPoint[iX+iY*Level.iWidth][Z] = Level.fLowestPoint+10;
			}
		Level.bTerrainUpdate = TRUE;
		pActor->fTerraformEngine -= (float) (g_lDeltatime*pActor->fFire)/25000;
		if(pActor->fTerraformEngine < 0.0f)
			 pActor->fTerraformEngine = 0.0f;
	}
	else
	if(CHECK_KEY(ASKeys, _ASConfig->iIncreaseTerrainKey[0]) && pActor->fTerraformEngine)
	{
		ASPlayFmodSample(pTerraformingSample, FSOUND_LOOP_NORMAL);
		Level.fPoint[iPos[X]+iPos[Y]*Level.iWidth][Z] -= (float) (g_lDeltatime*pActor->fFire)/300;
		if(Level.fPoint[iPos[X]+iPos[Y]*Level.iWidth][Z] < Level.fHighestPoint-10)
			Level.fPoint[iPos[X]+iPos[Y]*Level.iWidth][Z] = Level.fHighestPoint-10;
		pActor->fTerraformEngine -= (float) (g_lDeltatime*pActor->fFire)/75000;
		if(pActor->fTerraformEngine < 0.0f)
			 pActor->fTerraformEngine = 0.0f;
		Level.bTerrainUpdate = TRUE;
	}
	else
	if(CHECK_KEY(ASKeys, _ASConfig->iDecreaseTerrainKey[0]) && pActor->fTerraformEngine)
	{
		ASPlayFmodSample(pTerraformingSample, FSOUND_LOOP_NORMAL);
		Level.fPoint[iPos[X]+iPos[Y]*Level.iWidth][Z] += (float) (g_lDeltatime*pActor->fFire)/300;
		if(Level.fPoint[iPos[X]+iPos[Y]*Level.iWidth][Z] > Level.fLowestPoint+10)
			Level.fPoint[iPos[X]+iPos[Y]*Level.iWidth][Z] = Level.fLowestPoint+10;
		pActor->fTerraformEngine -= (float) (g_lDeltatime*pActor->fFire)/75000;
		if(pActor->fTerraformEngine < 0.0f)
			 pActor->fTerraformEngine = 0.0f;
		Level.bTerrainUpdate = TRUE;
	}
	else
		ASStopFmodSample(pTerraformingSample);

	_ASCamera->fShakePower = pActor->fThrustPower;

	// Check players actor:
} // end PLAYER::Check()
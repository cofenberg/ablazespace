// Demo featuring the GL_ARB_multitexture extension and fake dynamic lights.
// Author: Martin Estevao (lpsoftware@gdnmail.net) (http://lpsoftware.cfxweb.net)
// API: OpenGL 1.2

// This source code is Copyright Martin Estevao 2001.  It may not be re-printed or re-distributed without the author's consent.

#include <windows.h>
#include <gl\gl.h>
#include <gl\glu.h>
#include <gl\glaux.h>
#include <stdio.h>
#include "glext.h"
#include "tga.h"

//classes

class Point {

public:

	float x, y, z;
};

//globals

HDC hdc = NULL;
HGLRC hrc = NULL;
HWND main_window_handle = NULL;
HINSTANCE hinstance = NULL;

bool keys[256];
bool active;

bool multitex_support = FALSE;
bool multitex_use     = FALSE;

Point camera = {10.0f, 0.0f, 8.0f};

TextureImage tex[2];  //manages the tga's, textures

//fake light stuff
float top = 0.5f;
float bottom = 0.5f;

//real light properties
GLfloat light_ambient[] = {0.6f, 0.6f, 0.6f, 1.0f};
GLfloat light_diffuse[] = {0.0f, 0.0f, 0.0f, 1.0f};
GLfloat light_position[] = {0.0f, 0.0f, 0.0f, 1.0f};

PFNGLMULTITEXCOORD2FARBPROC		glMultiTexCoord2fARB		= 0;
PFNGLACTIVETEXTUREARBPROC		glActiveTextureARB			= 0;
PFNGLCLIENTACTIVETEXTUREARBPROC	glClientActiveTextureARB	= 0;

//prototypes
LRESULT	CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
GLvoid resize_gl_scene(GLsizei width, GLsizei height);
int load_textures(GLvoid);
int setup_lighting(GLvoid);
void render_quads(GLvoid);
bool multitex_supported(GLvoid);

GLvoid resize_gl_scene(GLsizei width, GLsizei height)
{
	if (height == 0)								
		height = 1;
	
	glViewport(0, 0, width, height);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0f, (GLfloat) width / (GLfloat) height, 0.1f, 100.0f);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

int load_textures(GLvoid)
{
	if ((!LoadTGA(&tex[0],"texture1.tga")) ||
		(!LoadTGA(&tex[1],"texture2.tga")))
	{
		return FALSE;
	}

	return(1);
}

int init_gl(GLvoid)
{
	//setup multitex support
	if (multitex_supported())
	{
		multitex_support = TRUE;
		multitex_use     = TRUE;
	}

	//load textures.	
	if (!load_textures()) 
	{
		return FALSE;	
	}

	glEnable(GL_TEXTURE_2D);

	glShadeModel(GL_SMOOTH);
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);

	glClearDepth(1.0f);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);

	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

	setup_lighting();

	glColor3f(1.0f, 1.0f, 1.0f);

	glEnable(GL_COLOR_MATERIAL);

	return(1);
}

bool multitex_supported(void)
{	
    char *ext;

    ext = (char *) glGetString(GL_EXTENSIONS);
   
    if (!(strstr(ext, "GL_ARB_multitexture")) == 1)
    {
		return FALSE;
	} 
	
	else 
	{
		glMultiTexCoord2fARB     =  (PFNGLMULTITEXCOORD2FARBPROC)     wglGetProcAddress("glMultiTexCoord2fARB");
		glActiveTextureARB       =  (PFNGLACTIVETEXTUREARBPROC)       wglGetProcAddress("glActiveTextureARB");		
		glClientActiveTextureARB =  (PFNGLCLIENTACTIVETEXTUREARBPROC) wglGetProcAddress("glClientActiveTextureARB");
      
		if (!glActiveTextureARB || !glMultiTexCoord2fARB || 
			!glClientActiveTextureARB)
		{
			return FALSE;
		}
    }

	return TRUE;
}

int setup_lighting(GLvoid)
{
	//set up light

	glLightfv(GL_LIGHT1, GL_AMBIENT, light_ambient);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, light_diffuse);
	glLightfv(GL_LIGHT1, GL_POSITION, light_position);
	glEnable(GL_LIGHT1);
	glEnable(GL_LIGHTING);

	return(1);
}

void render_quads(GLvoid)
{
	// first setup texture units, one for the base texture and another for the light texture

	//first texture unit
	glActiveTextureARB(GL_TEXTURE0_ARB);
	glBindTexture(GL_TEXTURE_2D, tex[0].texID);
	glEnable(GL_TEXTURE_2D);

	// second texture unit
	glActiveTextureARB(GL_TEXTURE1_ARB);
	glBindTexture(GL_TEXTURE_2D, tex[1].texID);
	glColor3f(top, top, top);
	glEnable(GL_TEXTURE_2D);

	//render the top quad

	glBegin(GL_QUADS);

		//ceiling
		glNormal3f(0.0f,  -0.5f,  0.0f);

		glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 1.0f, 0.0f); 
		glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 1.0f, 0.0f); 
		glVertex3f(-5.0f, 3.0f, -7.0f);

		glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 1.0f, 1.0f); 
		glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 1.0f, 1.0f); 
		glVertex3f( 5.0f, 3.0f, -7.0f);

		glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 0.0f, 1.0f); 
		glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 0.0f, 1.0f); 
		glVertex3f( 5.0f, 3.0f,  3.0f);

		glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 0.0f, 0.0f); 
		glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 0.0f, 0.0f);
		glVertex3f(-5.0f, 3.0f,  3.0f);

	glEnd();

	// second texture unit
	glActiveTextureARB(GL_TEXTURE1_ARB);
	glBindTexture(GL_TEXTURE_2D, tex[1].texID);
	glColor3f(bottom, bottom, bottom);
	glEnable(GL_TEXTURE_2D);

	//render the bottom quad

	glBegin(GL_QUADS);

		// floor
		glNormal3f(0.0f,  0.5f,  0.0f);

		glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 1.0f, 0.0f); 
		glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 1.0f, 0.0f); 
		glVertex3f(-5.0f, -3.0f, -7.0f);

		glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 1.0f, 1.0f); 
		glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 1.0f, 1.0f); 
		glVertex3f( 5.0f, -3.0f, -7.0f);

		glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 0.0f, 1.0f); 
		glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 0.0f, 1.0f); 
		glVertex3f( 5.0f, -3.0f,  3.0f);

		glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 0.0f, 0.0f); 
		glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 0.0f, 0.0f); 
		glVertex3f(-5.0f, -3.0f,  3.0f);

	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f);
}

int render_scene(GLvoid)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); 

	glPushMatrix();

		gluLookAt(camera.x, camera.y, camera.z, 3.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f);

		render_quads();

	glPopMatrix();

	return(1);
}

GLvoid kill_window(GLvoid)							
{
	ChangeDisplaySettings(NULL,0);				
	ShowCursor(TRUE);							

	if (hrc)										
	{
		if (!wglMakeCurrent(NULL,NULL))				
		{
			MessageBox(NULL,"Release Of DC And RC Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}

		if (!wglDeleteContext(hrc))				
		{
			MessageBox(NULL,"Release Rendering Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}

		hrc=NULL;								
	}

	if (hdc && !ReleaseDC(main_window_handle, hdc))				
	{
		MessageBox(NULL,"Release Device Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hdc = NULL;								
	}

	if (main_window_handle && !DestroyWindow(main_window_handle))				
	{
		MessageBox(NULL,"Could Not Release hWnd.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		main_window_handle = NULL;									
	}

	if (!UnregisterClass("OpenGL",hinstance))		
	{
		MessageBox(NULL,"Could Not Unregister Class.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hinstance = NULL;							
	}
}

int create_window(GLvoid)
{
	GLuint		PixelFormat;			// Holds The Results After Searching For A Match
	WNDCLASS	wc;						// Windows Class Structure
	DWORD		dwExStyle;				// Window Extended Style
	DWORD		dwStyle;
	DEVMODE dmScreenSettings;								// Device Mode

	hinstance			= GetModuleHandle(NULL);				// Grab An Instance For Our Window

	wc.style			= CS_HREDRAW | CS_VREDRAW | CS_OWNDC;	// Redraw On Size, And Own DC For Window.
	wc.lpfnWndProc		= (WNDPROC)WndProc;					// WndProc Handles Messages
	wc.cbClsExtra		= 0;									// No Extra Window Data
	wc.cbWndExtra		= 0;									// No Extra Window Data
	wc.hInstance		= hinstance;							// Set The Instance
	wc.hIcon			= LoadIcon(NULL, IDI_WINLOGO);			// Load The Default Icon
	wc.hCursor			= LoadCursor(NULL, IDC_ARROW);			// Load The Arrow Pointer
	wc.hbrBackground	= NULL;									// No Background Required For GL
	wc.lpszMenuName		= NULL;									// We Don't Want A Menu
	wc.lpszClassName	= "OpenGL";								// Set The Class Name

	if (!RegisterClass(&wc))									// Attempt To Register The Window Class
	{
		MessageBox(NULL,"Failed To Register The Window Class.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;											// Return FALSE
	}

	memset(&dmScreenSettings,0,sizeof(dmScreenSettings));	// Makes Sure Memory's Cleared
	dmScreenSettings.dmSize=sizeof(dmScreenSettings);		// Size Of The Devmode Structure
	dmScreenSettings.dmPelsWidth	= 640;				// Selected Screen Width
	dmScreenSettings.dmPelsHeight	= 480;				// Selected Screen Height
	dmScreenSettings.dmBitsPerPel	= 16;					// Selected Bits Per Pixel
	dmScreenSettings.dmFields=DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;

	if (ChangeDisplaySettings(&dmScreenSettings,CDS_FULLSCREEN)!=DISP_CHANGE_SUCCESSFUL)
	{
		MessageBox(NULL, "Couldn't set the display settings.","ERROR", MB_OK);
		return FALSE;
	}

	dwExStyle=WS_EX_APPWINDOW;								// Window Extended Style
	dwStyle=WS_POPUP;										// Windows Style
	ShowCursor(FALSE);										// Hide Mouse Pointer
	
	if (!(main_window_handle = CreateWindowEx(dwExStyle,							// Extended Style For The Window
							  "OpenGL",							// Class Name
							  "Amir #1 Solution",				// Window Title
							  dwStyle |							// Defined Window Style
							  WS_CLIPSIBLINGS |					// Required Window Style
							  WS_CLIPCHILDREN,					// Required Window Style
							  0, 0,								// Window Position
							  640,	// Calculate Window Width
							  480,	// Calculate Window Height
							  NULL,								// No Parent Window
							  NULL,								// No Menu
							  hinstance,							// Instance
							  NULL)))								// Dont Pass Anything To WM_CREATE
	{
		kill_window();								// Reset The Display
		MessageBox(NULL,"Window Creation Error.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	static	PIXELFORMATDESCRIPTOR pfd =				// pfd Tells Windows How We Want Things To Be
	{
		sizeof(PIXELFORMATDESCRIPTOR),				// Size Of This Pixel Format Descriptor
		1,											// Version Number
		PFD_DRAW_TO_WINDOW |						// Format Must Support Window
		PFD_SUPPORT_OPENGL |						// Format Must Support OpenGL
		PFD_DOUBLEBUFFER,							// Must Support Double Buffering
		PFD_TYPE_RGBA,								// Request An RGBA Format
		16,										// Select Our Color Depth
		0, 0, 0, 0, 0, 0,							// Color Bits Ignored
		0,											// No Alpha Buffer
		0,											// Shift Bit Ignored
		0,											// No Accumulation Buffer
		0, 0, 0, 0,									// Accumulation Bits Ignored
		16,											// 16Bit Z-Buffer (Depth Buffer)  
		0,											// No Stencil Buffer
		0,											// No Auxiliary Buffer
		PFD_MAIN_PLANE,								// Main Drawing Layer
		0,											// Reserved
		0, 0, 0										// Layer Masks Ignored
	};

	if (!(hdc=GetDC(main_window_handle)))							// Did We Get A Device Context?
	{
		kill_window();								// Reset The Display
		MessageBox(NULL,"Can't Create A GL Device Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if (!(PixelFormat=ChoosePixelFormat(hdc,&pfd)))	// Did Windows Find A Matching Pixel Format?
	{
		kill_window();								// Reset The Display
		MessageBox(NULL,"Can't Find A Suitable PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if(!SetPixelFormat(hdc,PixelFormat,&pfd))		// Are We Able To Set The Pixel Format?
	{
		kill_window();								// Reset The Display
		MessageBox(NULL,"Can't Set The PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if (!(hrc = wglCreateContext(hdc)))				// Are We Able To Get A Rendering Context?
	{
		kill_window();								// Reset The Display
		MessageBox(NULL,"Can't Create A GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if(!wglMakeCurrent(hdc,hrc))					// Try To Activate The Rendering Context
	{
		kill_window();								// Reset The Display
		MessageBox(NULL,"Can't Activate The GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	ShowWindow(main_window_handle,SW_SHOW);						// Show The Window
	SetForegroundWindow(main_window_handle);						// Slightly Higher Priority
	SetFocus(main_window_handle);									// Sets Keyboard Focus To The Window
	resize_gl_scene(640, 480);					// Set Up Our Perspective GL Screen

	if (!init_gl())									// Initialize Our Newly Created GL Window
	{
		kill_window();								// Reset The Display
		MessageBox(NULL,"Initialization Failed.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	return TRUE;									// Success
}

LRESULT CALLBACK WndProc(	HWND	hWnd,			// Handle For This Window
							UINT	uMsg,			// Message For This Window
							WPARAM	wParam,			// Additional Message Information
							LPARAM	lParam)			// Additional Message Information
{
	switch (uMsg)									// Check For Windows Messages
	{
		case WM_ACTIVATE:							// Watch For Window Activate Message
		{
			if (!HIWORD(wParam))					// Check Minimization State
			{
				active=TRUE;						// Program Is Active
			}
			else
			{
				active=FALSE;						// Program Is No Longer Active
			}

			return 0;								// Return To The Message Loop
		}

		case WM_SYSCOMMAND:							// Intercept System Commands
		{
			switch (wParam)							// Check System Calls
			{
				case SC_SCREENSAVE:					// Screensaver Trying To Start?
				case SC_MONITORPOWER:				// Monitor Trying To Enter Powersave?
				return 0;							// Prevent From Happening
			}
			break;									// Exit
		}

		case WM_CLOSE:								// Did We Receive A Close Message?
		{
			PostQuitMessage(0);						// Send A Quit Message
			return 0;								// Jump Back
		}

		case WM_KEYDOWN:							// Is A Key Being Held Down?
		{
			keys[wParam] = TRUE;					// If So, Mark It As TRUE
			return 0;								// Jump Back
		}

		case WM_KEYUP:								// Has A Key Been Released?
		{
			keys[wParam] = FALSE;					// If So, Mark It As FALSE
			return 0;								// Jump Back
		}

		case WM_SIZE:								// Resize The OpenGL Window
		{
			resize_gl_scene(LOWORD(lParam),HIWORD(lParam));  // LoWord=Width, HiWord=Height
			return 0;								// Jump Back
		}
	}

	// Pass All Unhandled Messages To DefWindowProc
	return DefWindowProc(hWnd,uMsg,wParam,lParam);
}

int WINAPI WinMain(	HINSTANCE	hInstance,			// Instance
					HINSTANCE	hPrevInstance,		// Previous Instance
					LPSTR		lpCmdLine,			// Command Line Parameters
					int			nCmdShow)			// Window Show State
{
	MSG		msg;									// Windows Message Structure
	BOOL	done=FALSE;								// Bool Variable To Exit Loop

	// Create Our OpenGL Window
	if (!create_window())
	{
		return 0;									// Quit If Window Was Not Created
	}

//	MessageBox(NULL,"Press the UP and DOWN arrow keys to adjust 'fake light' poosition.","",MB_OK|MB_ICONEXCLAMATION);

	while(!done)									// Loop That Runs While done=FALSE
	{
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE))	// Is There A Message Waiting?
		{
			if (msg.message==WM_QUIT)				// Have We Received A Quit Message?
			{
				done=TRUE;							// If So done=TRUE
			}
			else									// If Not, Deal With Window Messages
			{
				TranslateMessage(&msg);				// Translate The Message
				DispatchMessage(&msg);				// Dispatch The Message
			}
		}
		else										// If There Are No Messages
		{
			// Draw The Scene.  Watch For ESC Key And Quit Messages From DrawGLScene()
			if ((active && !render_scene()) || keys[VK_ESCAPE])	// Active?  Was There A Quit Received?
			{
				done=TRUE;							// ESC or DrawGLScene Signalled A Quit
			}
			else									// Not Time To Quit, Update Screen
			{
				SwapBuffers(hdc);					// Swap Buffers (Double Buffering)
			}

			if (keys[VK_F1])						// Is F1 Being Pressed?
			{
				keys[VK_F1]=FALSE;					// If So Make Key FALSE
				kill_window();						// Kill Our Current Window

				if (!create_window())
				{
					return 0;						// Quit If Window Was Not Created
				}
			}

			if (keys[VK_UP])
			{
				if (top < 1.0f)
				{
					top += 0.001f;
					bottom -= 0.001f;
				}
			}

			if (keys[VK_DOWN])
			{
				if (bottom < 1.0f)
				{
					bottom += 0.001f;
					top -= 0.001f;
				}
			}
		}
	}

	// Shutdown
	kill_window();									// Kill The Window
	return (msg.wParam);							// Exit The Program
}


	


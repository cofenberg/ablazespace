
     A      SS
    AAA    S 
   A   A    SS
  AAAAAAA     S
 A       A SS
  AblazeSpace


AblazeBall V1.1
Date: 2.3.02


� 2000-2001 AblazeSpace. All rights reserved.
This program is Freeware, and may be distributed freely to
other parties; however, it is not to be sold.
See the file license.txt for details.


Notes:
- You could add your own favorite music (mp3, midi & mods) by copy it into your AblazeBall Folder
  under Data\Music\List\
- Deactivate the lightmaps if the game is too slow


See the help files for more information.


Christian Ofenberg
Homepage: www.ablazespace.de
Mail: mail@AblazeSpace.de

//-----------------------------------------------------------------------------
// File: AS_Camera.h
//-----------------------------------------------------------------------------

#ifndef __AS_CAMERA_H__
#define __AS_CAMERA_H__


// Classes: *******************************************************************
typedef class AS_CAMERA
{
	public:
		// Variables:
		FLOAT3 fPos, fPos2, fRot, fRotVelocity, fRot2, fRot2Velocity;
		float fZ;
		int iTimeToNext;
		
		// Shake effect:
		AS_3D_VECTOR vShakePos, vLastShakePos, vNewShakePos;
		float fShakeSpeed;

		// Functions:
		CAMERA(void); // Constructor
		void SetCameraTranslation(BOOL);
		void SetStandartCamera(void);

} AS_CAMERA;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern AS_CAMERA *_ASCamera;
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_CAMERA_H__
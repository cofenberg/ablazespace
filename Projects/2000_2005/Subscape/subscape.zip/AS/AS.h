 //-----------------------------------------------------------------------------
// File: AS.h
//-----------------------------------------------------------------------------

#ifndef __AS_H__
#define __AS_H__


// Structures: ****************************************************************
typedef struct
{
	char byFilename[256]; // The filename of the texture
	BYTE *pbyData; // The texture data
	int iColorDepth; // Color depth
	int iWidth, iHeight; // The size of the texture
	int iID; // The ID
	GLuint iOpenGLID; // The OpenGL ID
	int iUsed; // How often is this texture used?

} AS_TEXTURE;
///////////////////////////////////////////////////////////////////////////////

// Definitions: ***************************************************************
enum {X, Y, Z};
enum {HEADING, PITCH, ROLL};
enum {R, G, B, A};
enum {RIGHT, DOWN, LEFT, UP};
enum {MIN, MAX};

#define ASEnableLighting() if(_ASConfig->byLight != 0 && !_ASConfig->bWireframeMode && !_ASConfig->bPointMode) { glEnable(GL_LIGHTING); }
#define CHECK_KEY(a, b)  (a[b] & 0x80)
#define SAFE_DELETE(p)  { if(p) { delete (p);     (p) = NULL; } }
#define SAFE_RELEASE(p) { if(p) { (p)->Release(); (p) = NULL; } }

typedef float FLOAT2[2];
typedef float FLOAT3[3];
typedef float FLOAT4[4];
typedef double DOUBLE2[2];
typedef double DOUBLE3[3];
typedef double DOUBLE4[4];
typedef int INT2[2];
typedef int INT3[3];
typedef int INT4[4];
typedef short SHORT2[2];
typedef short SHORT3[3];
typedef short SHORT4[4];
typedef char CHAR2[2];
typedef char CHAR3[2];
typedef char CHAR4[2];
///////////////////////////////////////////////////////////////////////////////

// Classes: *******************************************************************
// Some program information:
typedef class
{
	public:
		char byVersion[128], // Program version number
			 byDate[128], // Program build date
			 byTime[128]; // Program build time

		void Init(void);

} AS_PROGRAM_INFO;

// The AblazeSpace engine:
typedef class AS_ENGINE
{
	HINSTANCE hInstance; // Program instance
    LPSTR lpCmdLine; // Program commando line
	HANDLE hMutex; // Program mutex
	BOOL bShutDown, // Should the program be shut down?
		 bActive; // Is your application active?
	int iCmdShow, // Program show parameters
		iWindows, // The number of active windows in the program
		iModule, // The current program module
		iNextModule; // The next program module which should be entered
	
	SYSTEMTIME StartTime;
	DWORD dwFPSTimeNow, dwFPSTimeLast, dwFPSTimeDifference;
	int iFPSRenderedFrames, iFPSFramesSinceCheck, iFPS;
	BOOL bMainWindow; // Is there a main window?
	// The Log:
	FILE *pLogFile;

	// DX input:
	LPDIRECTINPUT8       pDXDI;
	LPDIRECTINPUTDEVICE8 pDXMouse;
	LPDIRECTINPUTDEVICE8 pDXKeyboard;
	
	// DX Audio:
	CMusicManager *pMusicManager;
	CMusicSegment *pMusicSegment;
	//

	public:
		AS_ENGINE(HINSTANCE, LPSTR, int, BOOL);
		~AS_ENGINE(void);

		void WriteLog(const char *, ...);
		void WriteLogMessage(const char *, ...);
		void WriteLogMessageS(char *);
		HWND ASCreateWindow(WNDPROC, LPCTSTR, LPCTSTR, DWORD, DWORD, HMENU, BOOL,							HRESULT (*)(AS_WINDOW *), HRESULT (*)(AS_WINDOW *),
							HBRUSH, BOOL);
		HRESULT ASDestroyWindow(HWND *, LPCTSTR);
		HRESULT EnumerateDisplayModeInfos(void);
		HRESULT AddDisplayModeInfo(DEVMODE);
		HRESULT DestroyDisplayModeInfo(void);
		void UpdateWindows(void);
		int FindWindowID(HWND);
		int UpdateFPS(void);

		HINSTANCE GetInstance(void) { return hInstance; }
		LPSTR GetCmdLine(void) { return lpCmdLine; };
		int GetCmdShow(void) { return iCmdShow; };
		BOOL GetShutDown(void) { return bShutDown; }
		void SetShutDown(BOOL bState) { bShutDown = bState; }
		BOOL GetActive(void) { return bActive; }
		void SetActive(BOOL bState) { bActive = bState; }
		void SetModule(int iModuleT) { iModule = iNextModule = iModuleT; }
		int GetModule(void) { return iModule; }
		void SetNextModule(int iNextModuleT) { iNextModule = iNextModuleT; }
		int GetNextModule(void) { return iNextModule; }
		BOOL CheckModuleChange(void) { if(iModule != iNextModule) return TRUE; return FALSE; }
		int GetWindows(void) { return iWindows; }

		int GetFPS(void) { return iFPS; };
		void ShowMouseCursor(BOOL);

		// DX input:
		HRESULT CreateDXInputDevices(HWND, BOOL, BOOL, BOOL, BOOL);
		HRESULT ReadDXInput(HWND);
		void FreeDXInputDevices(void);
		void ASEnumerateDXInputKeys(void);

		// DX Audio:
		HRESULT CreateDXAudio(HWND);
		void DestroyDXAudio(void);
		HRESULT LoadMusic(char *);
		HRESULT PlayMusic(HWND);
		void StopMusic(void);
		//

		AS_WINDOW *pWindow; // The program windows
		LPTSTR pbyProgramPath,
			   pbyProgramExeName,
			   pbyProgramDrive,
			   pbyProgramDir,
			   pbyUserName;
		BOOL bLog,	// Should the log be activated?
			 bDebugMode, // Should the program run in debug mode?
			 bStartErrorMessage; // Should an message be shown if an error occurred at the last program run?
		int iMaxLights, // The maximum number of possible lights
			iActiveLights; // The number of active lights
		BOOL bDraw, // Should the draw functions be activated?
			 bMakeScreenshot, // Should a screenshot be taken??
			 bScreenShotTaken; // Was the screenshot already taken?
		
		// Paths:
		LPTSTR pbyConfigFile,
			   pbyLanguagesFile,
			   pbyHighscoreFile,
			   pbyObjectsFile,
			   pbyBitmapsFile,
			   pbyMusicFile,
			   pbySoundFile,
			   pbySolarSystemsFile;

	friend AS_WINDOW;

} AS_ENGINE;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern AS_PROGRAM_INFO _ASProgramInfo;
extern AS_ENGINE *_AS;
extern UCHAR ASKeys[256];
extern BOOL ASKeyPressed[256], ASKeyFirst[256];
extern int iASResult;
extern DEVMODE ASSavedDisplayMode;
// General speed variables
extern long g_lProgramStartTime;
extern long g_lGameLength;
extern long g_lNow;
extern long g_lLastlooptime;
extern long g_lDeltatime;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern HRESULT ASDraw(AS_WINDOW *);
extern HRESULT ASCheck(AS_WINDOW *);
extern void ASSwapBuffers(HDC, AS_WINDOW *, BOOL);
extern char *ASGetFileName(HWND,  char *, char *, BOOL, BOOL, char *);
extern void ASLoadTextures(char (*)[256], int, AS_TEXTURE *);
extern void ASDestroyTextures(int, AS_TEXTURE *);
extern void ASGenOpenGLTextures(int, AS_TEXTURE *);
extern void ASDestroyOpenGLTextures(int, AS_TEXTURE *);
extern BOOL ASLoadJpegRGB(AS_TEXTURE *, char *);
extern DWORD ASGetCpuSpeed(void);
extern void ASRemoveDirectory(char *);
extern void ASDrawBoundingBox(float [2][3], float);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS__
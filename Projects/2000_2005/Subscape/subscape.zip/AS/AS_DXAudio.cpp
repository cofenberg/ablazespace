//-----------------------------------------------------------------------------
// File: AS_DXAudio.cpp
//-----------------------------------------------------------------------------

#include "AS_ENGINE.h"


//-----------------------------------------------------------------------------
// Desc: Init both DirectMusic and DirectSound
//-----------------------------------------------------------------------------
HRESULT AS_ENGINE::CreateDXAudio(HWND hWnd)
{ // begin AS_ENGINE::CreateDXAudio()
    pMusicManager = new CMusicManager();

    // Init DirectMusic with a default audio path
    pMusicManager->Initialize(hWnd, 16);
	return 0;
} // end AS_ENGINE::CreateDXAudio()

void AS_ENGINE::DestroyDXAudio(void)
{ // begin AS_ENGINE::DestroyDXAudio()
    StopMusic();
	SAFE_DELETE(pMusicSegment);
    SAFE_DELETE(pMusicManager);
} // end AS_ENGINE::DestroyDXAudio()

HRESULT AS_ENGINE::LoadMusic(char *pbyFilename)
{ // begin AS_ENGINE::LoadMusic()
    // Stop the music:
	if(pMusicSegment)
        pMusicSegment->Stop(0);

	if(!_ASConfig->bMusic)
		return 0;

    // Load now the new one:
    // Free any previous segment, and make a new one
    SAFE_DELETE(pMusicSegment);

    // Have the loader collect any garbage now that the old 
    // segment has been released
    pMusicManager->CollectGarbage();

    // For DirectMusic must know if the file is a standard MIDI file or not
    // in order to load the correct instruments.
    BOOL bMidiFile = FALSE;
	strlwr(pbyFilename);
    if(strstr(pbyFilename, ".mid") != NULL ||
       strstr(pbyFilename, ".rmi") != NULL) 
        bMidiFile = TRUE;

    // Load the file into a DirectMusic segment 
    if(pMusicManager->CreateSegmentFromFile(&pMusicSegment, pbyFilename, TRUE, bMidiFile))
        return 1;
	
	return 0;
} // end AS_ENGINE::LoadMusic()

HRESULT AS_ENGINE::PlayMusic(HWND hWnd)
{ // begin AS_ENGINE::PlayMusic()
    if(!pMusicSegment)
        return 1;

	if(!_ASConfig->bMusic)
		return 0;
    // Set the segment to repeat many times
    if(pMusicSegment->SetRepeats(DMUS_SEG_REPEAT_INFINITE))
        return 1;

    // Play the segment and wait. The DMUS_SEGF_BEAT indicates to play on the 
    // next beat if there is a segment currently playing. 
    if(pMusicSegment->Play(DMUS_SEGF_BEAT))
        return 1;

    return 0;
} // end AS_ENGINE::PlayMusic()

void AS_ENGINE::StopMusic(void)
{ // begin AS_ENGINE::StopMusic()
	if(pMusicSegment)
		pMusicSegment->Stop(DMUS_SEGF_BEAT);
} // end AS_ENGINE::StopMusic()

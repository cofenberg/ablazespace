//-----------------------------------------------------------------------------
// File: AS_LanguageText.h
//-----------------------------------------------------------------------------

///////////////////////////////////////////////////////////////////////////////
// Here are all pointers to the texts:
T_HelpFile = pbyASText[0],
T_CreditsFile = pbyASText[1],
T_Ok = pbyASText[2],
T_Cancel = pbyASText[3],
T_Fullscreen = pbyASText[4],
T_DisplayMode = pbyASText[5],
T_Language = pbyASText[6],
T_Help = pbyASText[7],
T_Music = pbyASText[8],
T_Sound = pbyASText[9],
T_ShowFPS = pbyASText[10],
T_Log = pbyASText[11],
T_Lighting = pbyASText[12],
T_None = pbyASText[13],
T_Flat = pbyASText[14],
T_Smooth = pbyASText[15],
T_FastTexturing = pbyASText[16],
T_UseMipmaps = pbyASText[17],
T_Credits = pbyASText[18],
T_Configuration = pbyASText[19];
T_Homepage = pbyASText[20];
T_Version_ = pbyASText[21];
T_ProgrammingAndDesign_ = pbyASText[22];
T_Music_ = pbyASText[23];
T_Homepage_ = pbyASText[24];
T_EMail_ = pbyASText[25];
T_ProgramInfo_ = pbyASText[26];
T_Build_ = pbyASText[27];
T_General = pbyASText[28],
T_Graphic = pbyASText[29],
T_Programming = pbyASText[30],
T_HightRenderQuality = pbyASText[31],
T_MouseSensibility = pbyASText[32],
T_Quit = pbyASText[33],
T_Error = pbyASText[34],
T_ShowBoundingBoxes = pbyASText[35],
T_FrustumCulling = pbyASText[36],
T_ShowCulledObjects = pbyASText[37],
T_Pause = pbyASText[38],
T_MoreCredits = pbyASText[39],
T_MainMenu = pbyASText[40],
T_StartGame = pbyASText[41],
T_Options = pbyASText[42],
T_Yes = pbyASText[43],
T_No = pbyASText[44],
T_KeysSetup = pbyASText[45],
T_OtherOptions = pbyASText[46],
T_Left = pbyASText[47],
T_Right = pbyASText[48],
T_Up = pbyASText[49],
T_Down = pbyASText[50],
T_Shot = pbyASText[51],
T_ChangePerspective = pbyASText[52],
T_StandartView = pbyASText[53],
T_LevelRestart = pbyASText[54],
T_StandartConfiguration = pbyASText[55],
T_PressNewKey = pbyASText[56],
T_EnterName = pbyASText[57],
T_Multitexturing = pbyASText[58],
T_Particles = pbyASText[59],
T_ParticleDensity = pbyASText[60],
T_Low = pbyASText[61],
T_Middle = pbyASText[62],
T_All = pbyASText[63],
T_ZBuffer = pbyASText[64],
T_MusicVolume = pbyASText[65],
T_Slow = pbyASText[66],
T_Normal = pbyASText[67],
T_Fast = pbyASText[68],
T_Invulnerable = pbyASText[69],
T_Lives = pbyASText[70],
T_Points = pbyASText[71],
T_Control = pbyASText[72],
T_Cheats = pbyASText[73],
T_Afterburner = pbyASText[74],
T_RollLeft = pbyASText[75],
T_RollRight = pbyASText[76],
T_FullStop = pbyASText[77],
T_Slide = pbyASText[78],
T_Forward = pbyASText[79],
T_Backward = pbyASText[80],
T_SelectTarget = pbyASText[81],
T_Hud = pbyASText[82],
T_WireframeMode = pbyASText[83],
T_PointMode = pbyASText[84],

// *T_ = pbyASText[],


// Pointer to messages:	
M_FirstProgramStart = pbyASMessage[0],
M_ProgramWasNotSutDownCorrectlyAtLastTime = pbyASMessage[1],
M_ProgramEndErrorDetected = pbyASMessage[2],
M_TheProgramIsAlreadyRunning = pbyASMessage[3],
M_CouldNotInitializeOpenGLGraphic = pbyASMessage[4],
M_PressAnyKeyToContinue = pbyASMessage[5],
M_AreYouSure = pbyASMessage[6],

// *T_ = pbyASMessage[],

///////////////////////////////////////////////////////////////////////////////
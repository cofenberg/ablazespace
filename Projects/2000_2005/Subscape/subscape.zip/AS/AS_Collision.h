//-----------------------------------------------------------------------------
// File: AS_Collsison.h
//-----------------------------------------------------------------------------

#ifndef __AS_COLLISION_H__
#define __AS_COLLISION_H__


// Functions: *****************************************************************
//extern double ASIntersectRayPlane(AS_VECTOR, AS_VECTOR, AS_VECTOR, AS_VECTOR);
//extern BOOL ASCheckPointInTriangle(AS_VECTOR, AS_VECTOR, AS_VECTOR, AS_VECTOR);
extern BOOL ASCheckRaySphereCollision(AS_3D_VECTOR, AS_3D_VECTOR, AS_3D_VECTOR, float);
extern BOOL ASCheckLineInBox(FLOAT3, FLOAT3, FLOAT3 [2]);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_COLLISION_H__
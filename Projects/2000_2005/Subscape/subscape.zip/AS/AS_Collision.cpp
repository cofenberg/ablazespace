//-----------------------------------------------------------------------------
// File: AS_Collision.cpp
//-----------------------------------------------------------------------------

#include "AS_Engine.h"


// Functions: *****************************************************************
//double ASIntersectRayPlane(AS_VECTOR, AS_VECTOR, AS_VECTOR, AS_VECTOR);
//BOOL ASCheckPointInTriangle(AS_VECTOR, AS_VECTOR, AS_VECTOR, AS_VECTOR);
BOOL ASCheckRaySphereCollision(AS_3D_VECTOR, AS_3D_VECTOR, AS_3D_VECTOR, float);
BOOL ASCheckLineInBox(FLOAT3, FLOAT3, FLOAT3 [2]);
///////////////////////////////////////////////////////////////////////////////

/*// ----------------------------------------------------------------------
// Name  : ASIntersectRayPlane()
// Input : rOrigin - origin of ray in world space
//         rVector - vector describing direction of ray in world space
//         pOrigin - Origin of plane 
//         pNormal - Normal to plane
// Notes : Normalized directional vectors expected
// Return: distance to plane in world units, -1 if no intersection.
// -----------------------------------------------------------------------  
double ASIntersectRayPlane(AS_VECTOR rOrigin, AS_VECTOR rVector, AS_VECTOR pOrigin, AS_VECTOR pNormal)
{ // begin ASIntersectRayPlane()
	double d = - (dot(pNormal,pOrigin));

	double numer = dot(pNormal,rOrigin)+d;
	double denom = dot(pNormal,rVector);

	if(!denom) // normal is orthogonal to vector, cant intersect
		return (-1.0f);

	return -(numer/denom);	
} // end ASIntersectRayPlane()


// ----------------------------------------------------------------------
// Name  : ASCheckPointInTriangle()
// Input : point - point we wish to check for inclusion
//         a - first vertex in triangle
//         b - second vertex in triangle 
//         c - third vertex in triangle
// Notes : Triangle should be defined in clockwise order a,b,c
// Return: TRUE if point is in triangle, FALSE if not.
// -----------------------------------------------------------------------  
BOOL ASCheckPointInTriangle(AS_VECTOR point, AS_VECTOR a, AS_VECTOR b, AS_VECTOR c)
{ // begin ASCheckPointInTriangle()
	double total_angles = 0.0f, t;
   
	// make the 3 vectors
	AS_VECTOR v1 = point-a;
	AS_VECTOR v2 = point-b;
	AS_VECTOR v3 = point-c;

	normalizeVector(v1);
	normalizeVector(v2);
	normalizeVector(v3);

	t = dot(v1,v2);
	if(t < -1.0f)
		t = -1.0f;
	if(t > 1.0f)
		1.0f;
	total_angles += acos(t);
	t = dot(v2,v3);
	if(t < -1.0f)
		t = -1.0f;
	if(t > 1.0f)
		1.0f;
	total_angles += acos(t);
	t = dot(v3,v1);
	if(t < -1.0f)
		t = -1.0f;
	if(t > 1.0f)
		1.0f;
	total_angles += acos(t);

	if(fabs(total_angles-2*PI) <= 0.005)
		return TRUE;
 
	return FALSE;
} // end ASCheckPointInTriangle()
*/
BOOL ASCheckRaySphereCollision(AS_3D_VECTOR vRayPos, AS_3D_VECTOR vRayDir, AS_3D_VECTOR vSpherePos, float fSphereRadius)
{ // begin ASCheckRaySphereCollision()
	AS_3D_VECTOR vDelta;

	vDelta = vSpherePos-vRayPos;
	float fC = vDelta.GetLength();
	float fV = vDelta.DotProduct(vRayDir);
	float fD = fSphereRadius*fSphereRadius-(fC*fC-fV*fV);

	if(fD < 0.0)
		return FALSE; // There was no collision
	float fT = (float) (fV-sqrt(fD));
	if(fT < 0.0f)
		return FALSE; // The intersection is behind the ray:
	return TRUE; // There was an collision
} // end ASCheckRaySphereCollision()

BOOL ASBoxIntersectionX(float fX, FLOAT3 fLineS, FLOAT3 fLineM, FLOAT3 *fRes)
{ // begin ASBoxIntersectionX()
    if(fLineM[X] != 0.0f)
	{
        float t = (fX-fLineS[X])/fLineM[X];
        if((t >= 0.0f) && (t <= 1.0f))
		{
            (*fRes)[X] = fLineS[X]+fLineM[X]*t;
            (*fRes)[Y] = fLineS[Y]+fLineM[Y]*t;
            (*fRes)[Z] = fLineS[Z]+fLineM[Z]*t;
            return TRUE;
        }
    }
    return FALSE;
} // end ASBoxIntersectionX()

BOOL ASBoxIntersectionY(float fY, FLOAT3 fLineS, FLOAT3 fLineM, FLOAT3 *fRes)
{ // begin ASBoxIntersectionY()
    if(fLineM[Y] != 0.0f)
	{
        float t = (fY-fLineS[Y])/fLineM[Y];
        if((t >= 0.0f) && (t <= 1.0f))
		{
            (*fRes)[X] = fLineS[X]+fLineM[X]*t;
            (*fRes)[Y] = fLineS[Y]+fLineM[Y]*t;
            (*fRes)[Z] = fLineS[Z]+fLineM[Z]*t;
            return TRUE;
        }
    }
    return FALSE;
} // end ASBoxIntersectionY()

BOOL ASBoxIntersectionZ(float fZ, FLOAT3 fLineS, FLOAT3 fLineM, FLOAT3 *fRes)
{ // begin ASBoxIntersectionZ()
    if(fLineM[Z] != 0.0f)
	{
        float t = (fZ-fLineS[Z])/fLineM[Z];
        if((t >= 0.0f) && (t <= 1.0f))
		{
            (*fRes)[X] = fLineS[X]+fLineM[X]*t;
            (*fRes)[Y] = fLineS[Y]+fLineM[Y]*t;
            (*fRes)[Z] = fLineS[Z]+fLineM[Z]*t;
            return TRUE;
        }
    }
    return FALSE;
} // end ASBoxIntersectionZ()

BOOL ASCheckBoxVecX(FLOAT3 fVec, FLOAT3 fBox[2])
{ // begin ASCheckBoxVecX()
    if((fVec[Y] >= fBox[MIN][Y]) && (fVec[Y] <= fBox[MAX][Y]) && (fVec[Z] >= fBox[MIN][Z]) && (fVec[Z] <= fBox[MAX][Z]))
		return TRUE;
    return FALSE;
} // end ASCheckBoxVecX()

BOOL ASCheckBoxVecY(FLOAT3 fVec, FLOAT3 fBox[2])
{ // begin ASCheckBoxVecY()
    if((fVec[X] >= fBox[MIN][X]) && (fVec[X] <= fBox[MAX][X]) && (fVec[Z] >= fBox[MIN][Z]) && (fVec[Z] <= fBox[MAX][Z]))
		return TRUE;
    return FALSE;
} // end ASCheckBoxVecY()

BOOL ASCheckBoxVecZ(FLOAT3 fVec, FLOAT3 fBox[2])
{ // begin ASCheckBoxVecZ()
    if((fVec[X] >= fBox[MIN][X]) && (fVec[X] <= fBox[MAX][X]) && (fVec[Y] >= fBox[MIN][Y]) && (fVec[Y] <= fBox[MAX][Y]))
		return TRUE;
    return FALSE;
} // end ASCheckBoxVecZ()

BOOL ASCheckLineInBox(FLOAT3 fLineS, FLOAT3 fLineM, FLOAT3 fBox[2])
{ // begin ASCheckRayBox()
	FLOAT3 fLineE;
	
	fLineE[X] = fLineS[X]+fLineM[X];
	fLineE[Y] = fLineS[Y]+fLineM[Y];
	fLineE[Z] = fLineS[Z]+fLineM[Z];
    if(((fLineS[X] >= fBox[MIN][X]) && (fLineS[Y] >= fBox[MIN][Y]) && (fLineS[Z] >= fBox[MIN][Z]) &&
        (fLineS[X] <= fBox[MAX][X]) && (fLineS[Y] <= fBox[MAX][Y]) && (fLineS[Z] <= fBox[MAX][Y])) ||
       ((fLineE[X] >= fBox[MIN][X]) && (fLineE[Y] >= fBox[MIN][Y]) && (fLineE[Z] >= fBox[MIN][Z]) &&
        (fLineE[X] <= fBox[MAX][X]) && (fLineE[Y] <= fBox[MAX][Y]) && (fLineE[Z] <= fBox[MAX][Z])))
        return TRUE;
    FLOAT3 fPos;
    int i;

    for(i = 0; i < 6; i++)
	{
        switch(i)
		{
            case 0:
                if(ASBoxIntersectionX(fBox[MIN][X], fLineS, fLineM, &fPos) && ASCheckBoxVecX(fPos, fBox))
					return TRUE;
            break;
           
		    case 1:
                if(ASBoxIntersectionX(fBox[MAX][X], fLineS, fLineM, &fPos) && ASCheckBoxVecX(fPos, fBox))
					return TRUE;
            break;
           
		    case 2:
                if(ASBoxIntersectionY(fBox[MIN][Y], fLineS, fLineM, &fPos) && ASCheckBoxVecY(fPos, fBox))
					return TRUE;
            break;
           
		    case 3:
                if(ASBoxIntersectionY(fBox[MAX][Y], fLineS, fLineM, &fPos) && ASCheckBoxVecY(fPos, fBox))
					return TRUE;
            break;
           
		    case 4:
                if(ASBoxIntersectionZ(fBox[MIN][Z], fLineS, fLineM, &fPos) && ASCheckBoxVecZ(fPos, fBox))
					return TRUE;
            break;
           
		    case 5:
				if(ASBoxIntersectionZ(fBox[MAX][Z], fLineS, fLineM, &fPos) && ASCheckBoxVecZ(fPos, fBox))
					return TRUE;
            break;
        }
    }
    return FALSE;
} // end ASCheckRayBox()
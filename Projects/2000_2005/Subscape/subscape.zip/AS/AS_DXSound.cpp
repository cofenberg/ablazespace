//-----------------------------------------------------------------------------
// File: AS_DXSound.cpp
//-----------------------------------------------------------------------------

#include "AS_ENGINE.h"


// Variables: *****************************************************************
CSoundManager *g_pSoundManager = NULL;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
void ASCreatDXSoundManager(HWND);
void ASDestroyDXSoundManager(void);
void ASLoadDXSound(HWND, CSound **, char *);
void ASPlayDXSound(CSound *, BOOL);
void ASStopDXSound(CSound *);
void ASResetDXSound(CSound *);
void ASDestroyDXSound(CSound **);
///////////////////////////////////////////////////////////////////////////////


void ASCreatDXSoundManager(HWND hWnd)
{ // begin ASCreatDXSoundManager()
	if(!_ASConfig->bSound)
		return;
	_AS->WriteLogMessage("Create DirectSound");
    // Create a static IDirectSound in the CSound class.  
    // Set coop level to DSSCL_PRIORITY, and set primary buffer 
    // format to stereo, 22kHz and 16-bit output.
    g_pSoundManager = new CSoundManager();

    if(FAILED(g_pSoundManager->Initialize(hWnd, DSSCL_PRIORITY, 2, 22050, 16)))
    {
		_AS->WriteLogMessage("Error initializing DirectSound.");
        return;
    }
	else
		_AS->WriteLogMessage("OK");
} // end ASCreatDXSoundManager()

void ASDestroyDXSoundManager(void)
{ // begin ASDestroyDXSoundManager()
	SAFE_DELETE(g_pSoundManager);
} // end ASDestroyDXSoundManager()

void ASLoadDXSound(HWND hWnd, CSound **pSound, char *byFilename)
{ // begin ASLoadDXSound()
	if(!_ASConfig->bSound)
		return;
    DWORD dwCreationFlags;

    dwCreationFlags = 0;
    dwCreationFlags |= DSBCAPS_GLOBALFOCUS;
    // Add extra flags needed for the UI:
    dwCreationFlags |= DSBCAPS_CTRLPAN | DSBCAPS_CTRLVOLUME | DSBCAPS_CTRLFREQUENCY;

    // Free any previous sound
    SAFE_DELETE(*pSound);

    // Load the wave file into a DirectSound buffer:
    if(FAILED(g_pSoundManager->Create(pSound, byFilename, dwCreationFlags, GUID_NULL)))
        return;
} // end ASLoadDXSound()

void ASPlayDXSound(CSound *pSound, BOOL bLooped)
{ // begin ASPlayDXSound()
	if(!_ASConfig->bSound)
		return;
    DWORD dwLooped = bLooped ? DSBPLAY_LOOPING : 0L;

    if(!pSound)
		return;
	if(FAILED(pSound->Play(0, dwLooped)))
        return;
} // end ASPlayDXSound()

void ASStopDXSound(CSound *pSound)
{ // begin ASStopDXSound()
    if(!pSound)
		return;
    pSound->Stop();
	pSound->Reset();
} // end ASStopDXSound()

void ASResetDXSound(CSound *pSound)
{ // begin ASResetDXSound()
    if(!pSound)
		return;
	pSound->Reset();
} // end ASResetDXSound()

void ASDestroyDXSound(CSound **pSound)
{ // begin ASDestroyDXSound()
	if(!_ASConfig->bSound)
		return;
	if(!*pSound)
		return;
	ASStopDXSound(*pSound);
	SAFE_DELETE(*pSound);
} // end ASDestroyDXSound()


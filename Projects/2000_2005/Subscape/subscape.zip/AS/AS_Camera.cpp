//-----------------------------------------------------------------------------
// File: AS_Camera.cpp
//-----------------------------------------------------------------------------

#include "AS_Engine.h"


// Variables: *****************************************************************
AS_CAMERA *_ASCamera;
///////////////////////////////////////////////////////////////////////////////


// Constructor:
/*AS_CAMERA::AS_CAMERA(void)
{ // begin AS_CAMERA::AS_CAMERA()
	memset(this, 0, sizeof(AS_CAMERA));
} // end AS_CAMERA::AS_CAMERA() */

// Set current camera translation:
void AS_CAMERA::SetCameraTranslation(BOOL bOnlyRot)
{ // begin AS_CAMERA::SetCameraTranslation(()
	ACTOR *pPlayer = &Player.Actor;

	glLoadIdentity();
	if(!Player.bPilotView)
	{ // 
		if(!bOnlyRot)
			glTranslatef(fPos[X]+fPos2[X]+vShakePos.fX*Player.fAfterburnerPower,
						 fPos[Y]+fPos2[Y]+vShakePos.fY*Player.fAfterburnerPower-2.0f,
						 fPos[Z]+vShakePos.fZ*Player.fAfterburnerPower+fZ);
		glRotatef(fRot[Z]+fRot2[Z]+vShakePos.fZ*Player.fAfterburnerPower*10, 0.0f, 0.0f, 1.0f);
		glRotatef(-fRot[X]+fRot2[X]+10.0f+vShakePos.fX*Player.fAfterburnerPower*10, 1.0f, 0.0f, 0.0f);
		glRotatef(-fRot[Y]+fRot2[Y]+vShakePos.fY*Player.fAfterburnerPower*10, 0.0f, 1.0f, 0.0f);
	}
	else
	{
		glRotatef(fRot[Z]+fRot2[Z]+vShakePos.fZ*Player.fAfterburnerPower*10, 0.0f, 0.0f, 1.0f);
		glRotatef(-fRot[X]+fRot2[X]+vShakePos.fX*Player.fAfterburnerPower*10, 1.0f, 0.0f, 0.0f);
		glRotatef(-fRot[Y]+fRot2[Y]+vShakePos.fY*Player.fAfterburnerPower*10, 0.0f, 1.0f, 0.0f);
		glTranslatef(vShakePos.fX*Player.fAfterburnerPower,
					 vShakePos.fY*Player.fAfterburnerPower,
					 vShakePos.fZ*Player.fAfterburnerPower);
	}
	pPlayer->ApplyToCamera(bOnlyRot);
} // end AS_CAMERA::SetCameraTranslation()

void AS_CAMERA::SetStandartCamera(void)
{ // begin AS_CAMERA::SetStandartCamera()
	ACTOR *pPlayer = &Player.Actor;

	memset(this, 0, sizeof(AS_CAMERA));
	fPos[Z] = -15.0f;
	fShakeSpeed = 5.0f;
	pPlayer->vRot.fX = -90.0f;
	pPlayer->vRot.fY = 0.0f;
	pPlayer->vRot.fZ = 0.0f;
	pPlayer->vRotVelocity = 0.0f;
} // end AS_CAMERA::SetStandartCamera()
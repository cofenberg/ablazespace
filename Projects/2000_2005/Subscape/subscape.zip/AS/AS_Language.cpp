//-----------------------------------------------------------------------------
// File: AS_Language.cpp
//-----------------------------------------------------------------------------

#include "AS_ENGINE.h"


// Variables: *****************************************************************
char *pbyASText[AS_TEXTS];
char *pbyASMessage[AS_MESSAGES];
int iASCreditsTexts;
char **pbyASCreditsText;
int iASLanguages;  // The number of languages
char **pbyASLanguage; // All found languages names
// Here are all pointers to the texts:
char *T_HelpFile, *T_CreditsFile,
 	 *T_Ok, *T_Cancel, *T_Fullscreen, *T_DisplayMode, *T_Language,
 	 *T_Help, *T_Music, *T_Sound, *T_ShowFPS, *T_Log, *T_Lighting,
 	 *T_None, *T_Flat, *T_Smooth, *T_FastTexturing, *T_UseMipmaps,
 	 *T_Credits, *T_Configuration, *T_Homepage, *T_Version_,
	 *T_ProgrammingAndDesign_, *T_Music_, *T_Homepage_, *T_EMail_,
	 *T_ProgramInfo_, *T_Build_, *T_General, *T_Graphic, *T_Programming,
	 *T_HightRenderQuality, *T_MouseSensibility, *T_Quit, *T_Error,
	 *T_ShutdownError, *T_ShowBoundingBoxes, *T_FrustumCulling,
	 *T_ShowCulledObjects, *T_Pause, *T_MoreCredits,
	 *T_MainMenu, *T_StartGame, *T_Options, *T_Yes, *T_No, *T_KeysSetup,
	 *T_OtherOptions, *T_Left, *T_Right, *T_Up, *T_Down, *T_Shot,
	 *T_ChangePerspective, *T_StandartView, *T_LevelRestart,
	 *T_StandartConfiguration, *T_PressNewKey, *T_EnterName, *T_Multitexturing,
	 *T_Particles, *T_ParticleDensity, *T_Low, *T_Middle, *T_All, *T_ZBuffer,
	 *T_MusicVolume, *T_Slow, *T_Normal, *T_Fast, *T_Invulnerable, *T_Lives,
	 *T_Points, *T_Control, *T_Cheats, *T_Afterburner, *T_RollLeft, *T_RollRight,
	 *T_FullStop, *T_Slide, *T_Forward, *T_Backward, *T_SelectTarget, *T_Hud,
	 *T_WireframeMode, *T_PointMode;

// Pointer to messages:	
char *M_FirstProgramStart, *M_ProgramWasNotSutDownCorrectlyAtLastTime,
	 *M_ProgramEndErrorDetected, *M_TheProgramIsAlreadyRunning,
	 *M_CouldNotInitializeOpenGLGraphic, *M_PressAnyKeyToContinue, *M_AreYouSure;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
void EnumerateLanguages(void);
void SetLanguage(char *);
void DestroyLanguage(void);
///////////////////////////////////////////////////////////////////////////////


void EnumerateLanguages(void)
{ // begin EnumerateLanguages()
	WIN32_FIND_DATA FindFileData;
	char byTemp[256];
	HANDLE Find;
	                   
	_AS->WriteLogMessage("Enumerate languages");
	if(pbyASLanguage)
	{
		for(int i = 0; i < iASLanguages; i++)
			free(pbyASLanguage[i]);
		free(pbyASLanguage);
	}
	iASLanguages = 0;
	sprintf(byTemp, "%s%s\\*.*", _AS->pbyProgramPath, _AS->pbyLanguagesFile);
	Find = FindFirstFile(byTemp, &FindFileData);
	for(;;)
	{
		if(FindFileData.cFileName[0] != '.' && FindFileData.dwFileAttributes == FILE_ATTRIBUTE_DIRECTORY)
		{ // We found a dictory:
			iASLanguages++;
			pbyASLanguage = (char **) realloc(pbyASLanguage, sizeof(char **)*iASLanguages);
			pbyASLanguage[iASLanguages-1] = new char[strlen(FindFileData.cFileName)+1];
			strcpy(pbyASLanguage[iASLanguages-1], FindFileData.cFileName);
		}
		if(!FindNextFile(Find, &FindFileData))
			break;
	}
	FindClose(Find);
} // end EnumerateLanguages()

void SetLanguage(char *pbyLanguage)
{ // begin SetLanguage()
	char byFile[256], byTemp[256];
    int i;

	sprintf(byTemp, "Set language to %s", pbyLanguage);
	_AS->WriteLogMessage(byTemp);
	DestroyLanguage();
	sprintf(byFile, "%s%s\\%s\\general.txt", _AS->pbyProgramPath, _AS->pbyLanguagesFile, pbyLanguage);
	GetPrivateProfileString("help", "file", "", byTemp, MAX_PATH, byFile);
	pbyASText[0] = (char *) malloc(strlen(byTemp)+1);
	strcpy(pbyASText[0], byTemp);
	GetPrivateProfileString("help", "credits_file", "", byTemp, MAX_PATH, byFile);
	pbyASText[1] = (char *) malloc(strlen(byTemp)+1);
	strcpy(pbyASText[1], byTemp);
	// Load all texts:
	for(i = 2; i < AS_TEXTS; i++)
	{
		sprintf(byTemp, "%d", i-2);
		GetPrivateProfileString("general", byTemp, "", byTemp, MAX_PATH, byFile);
		pbyASText[i] = (char *) malloc(strlen(byTemp)+1);
		strcpy(pbyASText[i], byTemp);
	}
	// Load all messages:
	for(i = 0; i < AS_MESSAGES; i++)
	{
		sprintf(byTemp, "%d", i);
		GetPrivateProfileString("messages", byTemp, "", byTemp, MAX_PATH, byFile);
		pbyASMessage[i] = (char *) malloc(strlen(byTemp)+1);
		strcpy(pbyASMessage[i], byTemp);
	}
	
	#include "AS_LanguageText.h"

	// Load credits texts:
	sprintf(byFile, "%s%s\\%s\\credits.txt", _AS->pbyProgramPath, _AS->pbyLanguagesFile, pbyLanguage);
	iASCreditsTexts = GetPrivateProfileInt("general", "texts", 0, byFile);
	pbyASCreditsText = (char **) malloc(sizeof(char *)*iASCreditsTexts);
	for(i = 0; i < iASCreditsTexts; i++)
	{
		sprintf(byTemp, "%d", i);
		GetPrivateProfileString("texts", byTemp, "", byTemp, MAX_PATH, byFile);
		pbyASCreditsText[i] = (char *) malloc(strlen(byTemp)+1);
		strcpy(pbyASCreditsText[i], byTemp);
	}
	
	// Update the dialogs and so on:
	SetConfigLanguage();
} // end SetLanguage()

void DestroyLanguage(void)
{ // begin DestroyLanguage()
	for(int i = 0; i < AS_TEXTS; i++)
		SAFE_DELETE(pbyASText[i]);
	for(i = 0; i < AS_MESSAGES; i++)
		SAFE_DELETE(pbyASMessage[i]);
	for(i = 0; i < iASCreditsTexts; i++)
		SAFE_DELETE(pbyASCreditsText[i]);
	SAFE_DELETE(pbyASCreditsText);
} // end DestroyLanguage()
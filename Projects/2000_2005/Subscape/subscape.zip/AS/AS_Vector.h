//-----------------------------------------------------------------------------
// File: AS_Vector.h
//-----------------------------------------------------------------------------

#ifndef __AS_VECTOR_H__
#define __AS_VECTOR_H__


// Classes: *******************************************************************
typedef class AS_2D_VECTOR
{
	public:
		union
		{
			FLOAT2 fV;
			struct
			{
				float fX, fY;
			};
		};

		// Constructor:
		AS_2D_VECTOR(void) { fX = fY = 0.0f; }
		AS_2D_VECTOR(float fXT, float fYT) { fY = fXT, fY = fYT; }
		AS_2D_VECTOR(const float *fV) { *this = fV; }
		AS_2D_VECTOR(const AS_2D_VECTOR &V) { *this = V; }

		// Assignment operators:
		AS_2D_VECTOR &operator=(const float *fV)
		{
			fX = *fV++, fY = *fV;
			return  *this;
		}
		AS_2D_VECTOR &operator=(const AS_2D_VECTOR &V)
		{
			fX = V.fX, fY = V.fY;
			return *this;
		}
		AS_2D_VECTOR &operator=(const float fD)
		{
			fX = fY = fD;
			return *this;
		}

		// Comparison:
		BOOL operator==(const AS_2D_VECTOR V)
		{
			return fX == V.fX && fY == V.fY;
		}
		BOOL operator!=(const AS_2D_VECTOR V)
		{
			return !(*this == V);
		}

		// Vector:
		AS_2D_VECTOR &operator+=(const AS_2D_VECTOR V)
		{
			fX += V.fX, fY += V.fY;
			return *this;
		}
		AS_2D_VECTOR operator+(const AS_2D_VECTOR V)
		{
			return AS_2D_VECTOR(fX+V.fX, fY+V.fY);
		}
		AS_2D_VECTOR &operator-=(const AS_2D_VECTOR V)
		{
			fX -= V.fX, fY -= V.fY;
			return *this;
		}
		AS_2D_VECTOR operator-(const AS_2D_VECTOR V)
		{
			return AS_2D_VECTOR(fX-V.fX, fY-V.fY);
		}
		AS_2D_VECTOR &operator*=(const AS_2D_VECTOR V)
		{
			fX *= V.fX, fY *= V.fY;
			return *this;
		}
		AS_2D_VECTOR operator*(const AS_2D_VECTOR V)
		{
			return AS_2D_VECTOR(fX*V.fX, fY*V.fY);
		}
		AS_2D_VECTOR &operator/=(const AS_2D_VECTOR V)
		{
			fX /= V.fX, fY /= V.fY;
			return *this;
		}
		AS_2D_VECTOR operator/(const AS_2D_VECTOR V)
		{
			return AS_2D_VECTOR(fX/V.fX, fY/V.fY);
		}

		// Scalar
		AS_2D_VECTOR &operator*=(float fS)
		{
			fX *= fS, fY *= fS;
			return *this;
		}
		AS_2D_VECTOR operator*(float fS)
		{
			return AS_2D_VECTOR(fX*fS, fY*fS);
		}
		AS_2D_VECTOR &operator/=(float fS)
		{
			fX /= fS, fY /= fS;
			return *this;
		}
		AS_2D_VECTOR operator/(float fS)
		{
			return AS_2D_VECTOR(fX/fS, fY/fS);
		}

		// Stuff:
		float GetLength(void) { return (float) sqrt(fX*fX+fY*fY); }
		void SetLength(float fL) { *this *= fL/GetLength(); }
		void Invert(void) { fX = -fX; fY = -fY; }

		void Normalize(void)
		{
			float fU = fX*fX+fY*fY;
			if(fabs(fU-1.0) < AS_EPSILON)
				return;
			fU = 1.0f/(float) sqrt(fU);
			*this *= fU;
		}

		float DotProduct(void) { return fX*fX+fY*fY; }
		float DotProduct(const AS_2D_VECTOR V) { return fX*V.fX+fY*V.fY; }

		// Misc:
		BOOL IsNull(void)
		{
			if(!fX && !fY)
				return TRUE;
			return FALSE;
		}

} AS_2D_VECTOR;

typedef class AS_3D_VECTOR
{
	public:
		union
		{
			FLOAT3 fV;
			struct
			{
				float fX, fY, fZ;
			};
			struct
			{
				float fHeading, fPitch, fRoll;
			};
		};

		// Constructor:
		AS_3D_VECTOR(void) { fX = fY = fZ = 0.0f; }
		AS_3D_VECTOR(float fXT, float fYT, float fZT)
		{
			fX = fXT, fY = fYT, fZ = fZT;
		}
		AS_3D_VECTOR(const float *fV) { *this = fV; }
		AS_3D_VECTOR(const AS_3D_VECTOR &V) { *this = V; }

		// Assignment operators:
		AS_3D_VECTOR &operator=(const AS_3D_VECTOR &V)
		{
			fX = V.fX, fY = V.fY, fZ = V.fZ;
			return *this;
		}
		AS_3D_VECTOR &operator=(const float *fV)
		{
			fX = *fV++, fY = *fV++, fZ = *fV;
			return *this;
		}
		AS_3D_VECTOR &operator=(const float fD)
		{
			fX = fY = fZ = fD;
			return *this;
		}

		// Comparison:
		BOOL operator==(const AS_3D_VECTOR &V)
		{
			return fX == V.fX && fY == V.fY && fZ == V.fZ;
		}
		BOOL operator!=(const AS_3D_VECTOR V)
		{
			return !(*this == V);
		}

		// Vector:
		AS_3D_VECTOR &operator+=(const AS_3D_VECTOR V)
		{
			fX += V.fX, fY += V.fY, fZ += V.fZ;
			return *this;
		}
		AS_3D_VECTOR operator+(const AS_3D_VECTOR V)
		{
			return AS_3D_VECTOR(fX+V.fX, fY+V.fY, fZ+V.fZ);
		}
		AS_3D_VECTOR &operator-=(const AS_3D_VECTOR V)
		{
			fX -= V.fX, fY -= V.fY, fZ -= V.fZ;
			return *this;
		}
		AS_3D_VECTOR operator-(const AS_3D_VECTOR V)
		{
			return AS_3D_VECTOR(fX-V.fX, fY-V.fY, fZ-V.fZ);
		}
		AS_3D_VECTOR &operator*=(const AS_3D_VECTOR V)
		{
			fX *= V.fX, fY *= V.fY, fZ *= V.fZ;
			return *this;
		}
		AS_3D_VECTOR operator*(const AS_3D_VECTOR V)
		{
			return AS_3D_VECTOR(fX*V.fX, fY*V.fY, fZ*V.fZ);
		}
		AS_3D_VECTOR &operator/=(const AS_3D_VECTOR V)
		{
			fX /= V.fX, fY /= V.fY, fZ /= V.fZ;
			return *this;
		}
		AS_3D_VECTOR operator/(const AS_3D_VECTOR V)
		{
			return AS_3D_VECTOR(fX/V.fX, fY/V.fY, fZ/V.fZ);
		}

		// Scalar:
		AS_3D_VECTOR &operator*=(float fS)
		{
			fX *= fS, fY *= fS, fZ *= fS;
			return *this;
		}
		AS_3D_VECTOR operator*(float fS)
		{
			return AS_3D_VECTOR(fX*fS, fY*fS, fZ*fS);
		}
		AS_3D_VECTOR &operator/=(float fS)
		{
			*this*=1.0f/fS;
			return *this;
		}
		AS_3D_VECTOR operator/(float fS)
		{
			return operator*(1.0f/fS);
		}

		// Stuff:
		float GetLength(void) { return (float) sqrt(fX*fX+fY*fY+fZ*fZ); }
		void SetLength(float fL) { *this *= fL/GetLength(); }
		void Invert(void) { fX = -fX; fY = -fY; fZ = -fZ; }

		void Normalize(void)
		{
			float fU = fX*fX+fY*fY+fZ*fZ;
			if(fabs(fU-1.0) < AS_EPSILON)
				return;
			fU = 1.0f/(float) sqrt(fU);
			*this *= fU;
		}

		AS_3D_VECTOR CrossProduct(const AS_3D_VECTOR V)
		{
			return AS_3D_VECTOR((fY*V.fZ)-(fZ*V.fY),
								(fZ*V.fX)-(fX*V.fZ),
								(fX*V.fY)-(fY*V.fX));
		}

		float DotProduct(void) { return fX*fX+fY*fY+fZ*fZ; }
		float DotProduct(const AS_3D_VECTOR V) { return fX*V.fX+fY*V.fY+fZ*V.fZ; }

		// Misc:
		BOOL IsNull(void)
		{
			if(!fX && !fY && !fZ)
				return TRUE;
			return FALSE;
		}

} AS_3D_VECTOR;
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_VECTOR_H__
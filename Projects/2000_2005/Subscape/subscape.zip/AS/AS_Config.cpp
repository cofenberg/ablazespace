//-----------------------------------------------------------------------------
// File: AS_Config.cpp
//-----------------------------------------------------------------------------

#include "AS_ENGINE.h"


// Definations: ***************************************************************
enum {TAB_CONFIG_GENERAL, TAB_CONFIG_GRAPHIC, TAB_CONFIG_SOUND, TAB_CONFIG_CONTROL,
	  TAB_CONFIG_CHEATS};
#define CONFIG_TABS 5
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
AS_CONFIG *_ASConfig;
AS_CONFIG ConfigT;
DISPLAY_MODE_INFO DisplayModeInfo;
HWND hWndConfig, hWndCheats;
HWND hWndConfigTab[CONFIG_TABS];
int iCurrentConfigTab;
long g_lTestTime;
BOOL bFirstRunConfigDialog;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
// HRESULT CONFIG::Check(void);
// HRESULT CONFIG::Load(char *);
// HRESULT CONFIG::Save(char *)
void OpenConfigDialog(HWND);
LRESULT CALLBACK ConfigProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK ConfigGeneralProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK ConfigGraphicProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK ConfigSoundProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK ConfigCheatsProc(HWND, UINT, WPARAM, LPARAM);
void UpdateCheats(void);
void SetupConfigTabs(void);
void SetConfigLanguage(void);
///////////////////////////////////////////////////////////////////////////////


// AS_CONFIG functions: *******************************************************
AS_CONFIG::AS_CONFIG(void)
{ // begin AS_CONFIG::AS_CONFIG()
	memset(this, 0, sizeof(AS_CONFIG));
} // end AS_CONFIG::AS_CONFIG()

AS_CONFIG::~AS_CONFIG(void)
{ // begin AS_CONFIG::~AS_CONFIG()
} // end AS_CONFIG::~AS_CONFIG()

void AS_CONFIG::Check(void)
{ // begin AS_CONFIG::Check()
	// Update the general information:
	if(!DevMode.dmSize)
		DevMode.dmSize = sizeof(DEVMODE);
	iScreenPixels = (int) (DevMode.dmPelsWidth*DevMode.dmPelsHeight);
	iScreenSize = (int) (DevMode.dmPelsWidth*DevMode.dmPelsHeight*(DevMode.dmBitsPerPel/8));
	DevMode.dmFields = DM_BITSPERPEL | DM_PELSWIDTH | DM_PELSHEIGHT;
	// Find the current display mode id:
	for(int i = 0; i < DisplayModeInfo.Number; i++)
	{
		if(DevMode.dmPelsWidth == DisplayModeInfo.pDevMode[i].dmPelsWidth && 
		   DevMode.dmPelsHeight == DisplayModeInfo.pDevMode[i].dmPelsHeight && 	
		   DevMode.dmBitsPerPel == DisplayModeInfo.pDevMode[i].dmBitsPerPel && 
		   DevMode.dmDisplayFrequency == DisplayModeInfo.pDevMode[i].dmDisplayFrequency)
		{
			iModeIndex = i;
			CopyMemory(&DevMode, &DisplayModeInfo.pDevMode[iModeIndex], sizeof(DEVMODE));
			break;
		}
	}
	if(iWindowWidth < 100)
		iWindowWidth = 100;
	if(iWindowHeight < 100)
		iWindowHeight = 100;
	if(_ASConfig->fParticleDensity > 1.0f)
		_ASConfig->fParticleDensity = 1.0f;

	// Check keys:
	iLeftKey[1] = GetDXInputKey(iLeftKey[0]);
	iRightKey[1] = GetDXInputKey(iRightKey[0]);
	iUpKey[1] = GetDXInputKey(iUpKey[0]);
	iDownKey[1] = GetDXInputKey(iDownKey[0]);
	iShotKey[1] = GetDXInputKey(iShotKey[0]);
	iChangePerspectiveKey[1] = GetDXInputKey(iChangePerspectiveKey[0]);
	iStandartViewKey[1] = GetDXInputKey(iStandartViewKey[0]);
	iPauseKey[1] = GetDXInputKey(iPauseKey[0]);
	iLevelRestartKey[1] = GetDXInputKey(iLevelRestartKey[0]);
	iAfterburnerKey[1] = GetDXInputKey(iAfterburnerKey[0]);
	iRollLeftKey[1] = GetDXInputKey(iRollLeftKey[0]);
	iRollRightKey[1] = GetDXInputKey(iRollRightKey[0]);
	iFullStopKey[1] = GetDXInputKey(iFullStopKey[0]);
	iSlideKey[1] = GetDXInputKey(iSlideKey[0]);
	iForwardKey[1] = GetDXInputKey(iForwardKey[0]);
	iBackwardKey[1] = GetDXInputKey(iBackwardKey[0]);
	iSelectTargetKey[1] = GetDXInputKey(iSelectTargetKey[0]);
	iHudKey[1] = GetDXInputKey(iHudKey[0]);
} // end AS_CONFIG::Check()

HRESULT AS_CONFIG::Load(char *pbyFilename)
{ // begin CONFIG::Load()
	char byTemp[256];

	if(!pbyFilename)
		return 1;
	// Load the configurations from the given file:

	// General:
	bFirstRun = GetPrivateProfileInt("General", "firstrun", 1, pbyFilename);
	bError = GetPrivateProfileInt("General", "error", 1, pbyFilename);
	bSound = GetPrivateProfileInt("General", "sound", 1, pbyFilename);
	bMusic = GetPrivateProfileInt("General", "music", 1, pbyFilename);
	bDrawBounding = GetPrivateProfileInt("General", "draw_bounding", 0, pbyFilename);
	bFrustumCulling = GetPrivateProfileInt("General", "frustum_culling", 1, pbyFilename);	
	bShowFPS = GetPrivateProfileInt("General", "show_fps", 0, pbyFilename);
	bLog = GetPrivateProfileInt("General", "log", 1, pbyFilename);
	iWindowWidth = GetPrivateProfileInt("General", "window_width", DevMode.dmPelsWidth, pbyFilename);
	iWindowHeight = GetPrivateProfileInt("General", "window_height", DevMode.dmPelsHeight, pbyFilename);
	GetPrivateProfileString("General", "language", "Gb", byLanguage, MAX_PATH, pbyFilename);
	GetPrivateProfileString("General", "mouse_sensibility", "1.0f", byTemp, MAX_PATH, pbyFilename);
	fMouseSensibility = (float) atof(byTemp);
	iMusicVolume = GetPrivateProfileInt("General", "music_volume", AS_DX_SHOW_VOLUME_FULL, pbyFilename);

	// Graphic:
	bFullScreen = GetPrivateProfileInt("Graphic", "fullscreen", 1, pbyFilename);
	byZBuffer = GetPrivateProfileInt("Graphic", "z_buffer", 2, pbyFilename);
	byLight = GetPrivateProfileInt("Graphic", "light_mode", 2, pbyFilename);
	bFastTexturing = GetPrivateProfileInt("Graphic", "fast_texturing", 0, pbyFilename);
	bUseMipmaps = GetPrivateProfileInt("Graphic", "use_mipmaps", 0, pbyFilename);
	bMultitexturing = GetPrivateProfileInt("Graphic", "multitexturing", 1, pbyFilename);
	bHightRenderQuality = GetPrivateProfileInt("Graphic", "hight_render_quality", 1, pbyFilename);
	DevMode.dmPelsWidth = GetPrivateProfileInt("Graphic", "width", 640, pbyFilename);
	DevMode.dmPelsHeight = GetPrivateProfileInt("Graphic", "height", 480, pbyFilename);
	DevMode.dmBitsPerPel = GetPrivateProfileInt("Graphic", "colordepth", 16, pbyFilename);
	DevMode.dmDisplayFrequency = GetPrivateProfileInt("Graphic", "refresh_rate", 0, pbyFilename);
	bParticles = GetPrivateProfileInt("Graphic", "particles", DevMode.dmPelsHeight, pbyFilename);
	GetPrivateProfileString("Graphic", "particle_density", "1.0f", byTemp, MAX_PATH, pbyFilename);
	fParticleDensity = (float) atof(byTemp);

	// Keys:
	iLeftKey[0] = GetPrivateProfileInt("Keys", "left", STANDART_LEFT_KEY, pbyFilename);
	iRightKey[0] = GetPrivateProfileInt("Keys", "right", STANDART_RIGHT_KEY, pbyFilename);
	iUpKey[0] = GetPrivateProfileInt("Keys", "top", STANDART_UP_KEY, pbyFilename);
	iDownKey[0] = GetPrivateProfileInt("Keys", "down", STANDART_DOWN_KEY, pbyFilename);
	iShotKey[0] = GetPrivateProfileInt("Keys", "shot", STANDART_SHOT_KEY, pbyFilename);
	iChangePerspectiveKey[0] = GetPrivateProfileInt("Keys", "change_perspective", STANDART_CHANGE_PERSPECTIVE_KEY, pbyFilename);
	iStandartViewKey[0] = GetPrivateProfileInt("Keys", "standart_view", STANDART_STANDART_VIEW_KEY, pbyFilename);
	iPauseKey[0] = GetPrivateProfileInt("Keys", "pause", STANDART_PAUSE_KEY, pbyFilename);
	iLevelRestartKey[0] = GetPrivateProfileInt("Keys", "level_restart", STANDART_LEVEL_RESTART_KEY, pbyFilename);
	iAfterburnerKey[0] = GetPrivateProfileInt("Keys", "afterburner", STANDART_AFTERBURNER_KEY, pbyFilename);
	iRollLeftKey[0] = GetPrivateProfileInt("Keys", "roll_left", STANDART_ROLL_LEFT_KEY, pbyFilename);
	iRollRightKey[0] = GetPrivateProfileInt("Keys", "roll_right", STANDART_ROLL_RIGHT_KEY, pbyFilename);
	iFullStopKey[0] = GetPrivateProfileInt("Keys", "full_stop", STANDART_FULL_STOP_KEY, pbyFilename);
	iSlideKey[0] = GetPrivateProfileInt("Keys", "slide", STANDART_SLIDE_KEY, pbyFilename);
	iForwardKey[0] = GetPrivateProfileInt("Keys", "forward", STANDART_FORWARD_KEY, pbyFilename);
	iBackwardKey[0] = GetPrivateProfileInt("Keys", "backward", STANDART_BACKWARD_KEY, pbyFilename);
	iSelectTargetKey[0] = GetPrivateProfileInt("Keys", "select_target", STANDART_SELECT_TARGET_KEY, pbyFilename);
	iHudKey[0] = GetPrivateProfileInt("Keys", "hud", STANDART_HUD_KEY, pbyFilename);
	
	// Debug stuff:
	bShowCulledObjects = GetPrivateProfileInt("General", "show_culled_objects", 0, pbyFilename);	
	bWireframeMode = GetPrivateProfileInt("General", "wireframe_mode", 0, pbyFilename);	
	bPointMode = GetPrivateProfileInt("General", "point_mode", 0, pbyFilename);	

	Check(); // Update the configurations
	if(!_AS->bStartErrorMessage)
		_ASConfig->bError = FALSE;
	return 0;
} // end AS_CONFIG::Load()

HRESULT AS_CONFIG::Save(char *pbyFilename)
{ // begin AS_CONFIG::Save()
	FILE *pFile;

	if(!pbyFilename)
		return 1;
	// Save the current configurations:
	pFile = fopen(pbyFilename, "wt");
	if(!pFile)
		return 1;
	if(iWindowWidth < 100)
		iWindowWidth = 100;
	if(iWindowHeight < 100)
		iWindowHeight = 100;
	
	// General:
	fprintf(pFile, "[General]\n");
    fprintf(pFile, "firstrun=%d\n", bFirstRun);
    fprintf(pFile, "error=%d\n", bError);
    fprintf(pFile, "sound=%d\n", bSound);
    fprintf(pFile, "music=%d\n", bMusic);
    fprintf(pFile, "show_fps=%d\n", bShowFPS);
    fprintf(pFile, "frustum_culling=%d\n", bFrustumCulling);
    fprintf(pFile, "draw_bounding=%d\n", bDrawBounding);    
	fprintf(pFile, "log=%d\n", bLog);
	fprintf(pFile, "window_width=%d\n", iWindowWidth);
	fprintf(pFile, "window_height=%d\n", iWindowHeight);
	fprintf(pFile, "language=%s\n", byLanguage);
	fprintf(pFile, "mouse_sensibility=%f\n", fMouseSensibility);
	fprintf(pFile, "music_volume=%d\n", iMusicVolume);

	// Graphic:
	fprintf(pFile, "\n[Graphic]\n");
    fprintf(pFile, "fullscreen=%d\n", bFullScreen);
    fprintf(pFile, "z_buffer=%d\n", byZBuffer);
    fprintf(pFile, "light_mode=%d\n", byLight);
    fprintf(pFile, "fast_texturing=%d\n", bFastTexturing);
    fprintf(pFile, "use_mipmaps=%d\n", bUseMipmaps);
    fprintf(pFile, "multitexturing=%d\n", bMultitexturing);
	fprintf(pFile, "hight_render_quality=%d\n", bHightRenderQuality);
	fprintf(pFile, "width=%d\n", DevMode.dmPelsWidth);
	fprintf(pFile, "height=%d\n", DevMode.dmPelsHeight);
	fprintf(pFile, "colordepth=%d\n", DevMode.dmBitsPerPel);
	fprintf(pFile, "refresh_rate=%d HZ\n", DevMode.dmDisplayFrequency);
	fprintf(pFile, "particles=%d\n", bParticles);
	fprintf(pFile, "particle_density=%f\n", fParticleDensity);
	
	// Keys:
	fprintf(pFile, "\n[Keys]\n");
	fprintf(pFile, "left=%d\n", iLeftKey[0]);
	fprintf(pFile, "right=%d\n", iRightKey[0]);
	fprintf(pFile, "up=%d\n", iUpKey[0]);
	fprintf(pFile, "down=%d\n", iDownKey[0]);
	fprintf(pFile, "shot=%d\n", iShotKey[0]);
	fprintf(pFile, "change_perspective=%d\n", iChangePerspectiveKey[0]);
	fprintf(pFile, "standart_view=%d\n", iStandartViewKey[0]);
	fprintf(pFile, "pause=%d\n", iPauseKey[0]);
	fprintf(pFile, "level_restart=%d\n", iLevelRestartKey[0]);
	fprintf(pFile, "afterburner=%d\n", iAfterburnerKey[0]);
	fprintf(pFile, "roll_left=%d\n", iRollLeftKey[0]);
	fprintf(pFile, "roll_right=%d\n", iRollRightKey[0]);
	fprintf(pFile, "full_stop=%d\n", iFullStopKey[0]);
	fprintf(pFile, "slide=%d\n", iSlideKey[0]);
	fprintf(pFile, "forward=%d\n", iForwardKey[0]);
	fprintf(pFile, "backward=%d\n", iBackwardKey[0]);
	fprintf(pFile, "select_target=%d\n", iSelectTargetKey[0]);
	fprintf(pFile, "Hud=%d\n", iHudKey[0]);

    // Debug stuff:
	fprintf(pFile, "\n[Debug]\n");
	fprintf(pFile, "show_culled_objects=%d\n", bShowCulledObjects);
    fprintf(pFile, "wireframe_mode=%d\n", bWireframeMode);
    fprintf(pFile, "point_mode=%d\n", bPointMode);

	fclose(pFile);
	return 0;
} // end AS_CONFIG::Save()


// Functions: *****************************************************************
void OpenConfigDialog(HWND hWnd)
{ // begin OpenConfigDialog()
	DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CONFIG), hWnd, (DLGPROC) ConfigProc);
} // begin OpenConfigDialog()

LRESULT CALLBACK ConfigProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin ConfigProc()
	char byTemp[256];
	int i, i2;

	switch(iMessage)
    {
        case WM_INITDIALOG:
			_AS->WriteLogMessage("Open config dialog");
			memcpy(&ConfigT, _ASConfig, sizeof(AS_CONFIG));
			if(!hWndConfig)
				iCurrentConfigTab = -1;
			hWndConfig = hWnd;
			SetConfigLanguage();
			g_lTestTime = GetTickCount();
			if(bOnlyConfig)
				ShowWindow(GetDlgItem(hWnd, ID_CONFIG_QUIT), FALSE);			
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_CONFIG_OK:
					if(GetTickCount()-g_lTestTime < 500)
						break; // The user probably hadn't the change to do this selection!
					if(IsDlgButtonChecked(hWndConfigTab[TAB_CONFIG_GRAPHIC], IDC_CONFIG_GRAPHIC_LIGHT_NONE))
						_ASConfig->byLight = 0;
					else
					if(IsDlgButtonChecked(hWndConfigTab[TAB_CONFIG_GRAPHIC], IDC_CONFIG_GRAPHIC_LIGHT_FLAT))
						_ASConfig->byLight = 1;
					else
					if(IsDlgButtonChecked(hWndConfigTab[TAB_CONFIG_GRAPHIC], IDC_CONFIG_GRAPHIC_LIGHT_SMOOTH))
						_ASConfig->byLight = 2;
					EndDialog(hWnd, FALSE);
					hWndConfig = NULL;
					for(i2 = 0; i2 < CONFIG_TABS; i2++)
						hWndConfigTab[i2] = NULL;
					// Save the configuration:	
					sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyConfigFile);
					_ASConfig->Save(byTemp);
					ParticleManager.UpdateSystems();
					_AS->WriteLogMessage("Close config dialog (ok)");
					g_lNow = GetTickCount();
                return TRUE;

				case ID_CONFIG_CANCEL:
					memcpy(_ASConfig, &ConfigT, sizeof(AS_CONFIG));
					EndDialog(hWnd, FALSE);
					hWndConfig = NULL;
					for(i2 = 0; i2 < CONFIG_TABS; i2++)
						hWndConfigTab[i2] = NULL;;
					_AS->WriteLogMessage("Close config dialog (cancel)");
					g_lNow = GetTickCount();
				break;
				
				case ID_CONFIG_QUIT:
					EndDialog(hWnd, FALSE);
					hWndConfig = NULL;
					_AS->SetShutDown(TRUE);
				break;

				case IDC_CONFIG_OPENGL:
					DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_OPENGL), hWnd, (DLGPROC) OpenGLInfoProc);
				break;

				case IDC_CONFIG_CREDITS:
					OpenCreditsDialog(hWnd);
				break;

				case IDC_HOMEPAGE:
					ShellExecute(0, "open", "http://ablazespace.exit.de/", 0, 0, SW_SHOW);
				break;

				case IDC_MSPANG_HOMEPAGE:
					ShellExecute(0, "open", "http://www.mspang.de/", 0, 0, SW_SHOW);
				break;

				case IDC_NEHE_HOMEPAGE:
					ShellExecute(0, "open", "http://nehe.gamedev.net/", 0, 0, SW_SHOW);
				break;

				case IDC_CONFIG_HELP:
					OpenHelp();
				break;
            }
            break;

        case WM_NOTIFY: 
			switch(wParam)
			{
				case IDC_CONFIG_TAB:
					i = TabCtrl_GetCurSel(GetDlgItem(hWnd, IDC_CONFIG_TAB));
					if(i == iCurrentConfigTab)
						break; // This tab is already opend
					iCurrentConfigTab = i;
					for(i2 = 0; i2 < CONFIG_TABS; i2++)
						ShowWindow(hWndConfigTab[i2], SW_HIDE);
					UpdateWindow(hWndConfigTab[i]);
					ShowWindow(hWndConfigTab[i], SW_SHOW);
					SetFocus(hWndConfigTab[i]);
					SendMessage(hWndConfigTab[i], WM_INITDIALOG, 0, 0);
				break;
			} 
		break; 

		case WM_CLOSE:
			SendMessage(hWnd, WM_COMMAND, ID_CONFIG_OK, 0);
		break;
    }
    return FALSE;
} // end ConfigProc()

LRESULT CALLBACK ConfigGeneralProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin ConfigGeneralProc()
	int i;
	BOOL bTemp;

	switch(iMessage)
    {
        case WM_INITDIALOG:
			// Texts:
			SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_LOG, T_Log);
  			SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_SHOW_FPS, T_ShowFPS);
  			SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_LANGUAGE_TEXT, T_Language);
  			SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_FRUSTUM_CULLING, T_FrustumCulling);

			if(!_AS->bDebugMode)
			{ // Debug stuff:
  				SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_SHOW_BOUNDING_BOXES, T_ShowBoundingBoxes);
  				SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_SHOW_CULLED_OBJECTS, T_ShowCulledObjects);
  				SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_WIREFRAME_MODE, T_WireframeMode);
  				SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_POINT_MODE, T_PointMode);
				ShowWindow(GetDlgItem(hWnd, IDC_CONFIG_GENERAL_SHOW_BOUNDING_BOXES), FALSE);
				ShowWindow(GetDlgItem(hWnd, IDC_CONFIG_GENERAL_SHOW_CULLED_OBJECTS), FALSE);
				ShowWindow(GetDlgItem(hWnd, IDC_CONFIG_GENERAL_WIREFRAME_MODE), FALSE);
				ShowWindow(GetDlgItem(hWnd, IDC_CONFIG_GENERAL_POINT_MODE), FALSE);
			}

			//
 			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LANGUAGE, CB_RESETCONTENT, 0, 0);
			for(i = 0; i < iASLanguages; i++)
 			{
				SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LANGUAGE, CB_ADDSTRING, 0, (LONG)(LPSTR) pbyASLanguage[i]);
				if(!strcmp(pbyASLanguage[i], _ASConfig->byLanguage))
					SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LANGUAGE, CB_SETCURSEL, i, 0L);
			}
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_SHOW_FPS, BM_SETCHECK, _ASConfig->bShowFPS, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LOG, BM_SETCHECK, _ASConfig->bLog, 0L);
			if(!_AS->bLog)
				EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GENERAL_LOG), FALSE);
			else
				EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GENERAL_LOG), TRUE);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_SHOW_BOUNDING_BOXES, BM_SETCHECK, _ASConfig->bDrawBounding, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_FRUSTUM_CULLING, BM_SETCHECK, _ASConfig->bFrustumCulling, 0L);
			
			// Debug stuff:
			if(_ASConfig->bWireframeMode && _ASConfig->bPointMode)
				_ASConfig->bPointMode = FALSE;
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_SHOW_CULLED_OBJECTS, BM_SETCHECK, _ASConfig->bShowCulledObjects, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_WIREFRAME_MODE, BM_SETCHECK, _ASConfig->bWireframeMode, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_POINT_MODE, BM_SETCHECK, _ASConfig->bPointMode, 0L);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_CONFIG_GENERAL_SHOW_FPS:
					_ASConfig->bShowFPS = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_SHOW_FPS, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_GENERAL_LOG:
					_ASConfig->bLog = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LOG, BM_GETCHECK, 0, 0L);
					bTemp = _ASConfig->bLog;
					_ASConfig->bLog = TRUE;
					if(!bTemp)
						_AS->WriteLogMessage("Deactivate the log");
					else
						_AS->WriteLogMessage("Activate the log");
					_ASConfig->bLog = bTemp;
				break;
	
				case IDC_CONFIG_GENERAL_LANGUAGE:
					i = (int) SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LANGUAGE, CB_GETCURSEL, 0, 0L);
					if(i == -1)
						break;
					if(!strcmp(_ASConfig->byLanguage, pbyASLanguage[i]))
						break; // This language is already selected
					strcpy(_ASConfig->byLanguage, pbyASLanguage[i]);
					iCurrentConfigTab = -1;
					SetLanguage(_ASConfig->byLanguage);
				break;

				case IDC_CONFIG_GENERAL_SHOW_BOUNDING_BOXES:
					_ASConfig->bDrawBounding = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_SHOW_BOUNDING_BOXES, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_GENERAL_FRUSTUM_CULLING:
					_ASConfig->bFrustumCulling = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_FRUSTUM_CULLING, BM_GETCHECK, 0, 0L);
				break;
				
				// Debug stuff:
				case IDC_CONFIG_GENERAL_SHOW_CULLED_OBJECTS:
					_ASConfig->bShowCulledObjects = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_SHOW_CULLED_OBJECTS, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_GENERAL_WIREFRAME_MODE:
					_ASConfig->bWireframeMode = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_WIREFRAME_MODE, BM_GETCHECK, 0, 0L);
					if(_ASConfig->bPointMode)
					{
						_ASConfig->bPointMode = FALSE;
						SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_POINT_MODE, BM_SETCHECK, _ASConfig->bPointMode, 0L);
					}
					UpdateRenderQuality();
				break;

				case IDC_CONFIG_GENERAL_POINT_MODE:
					_ASConfig->bPointMode = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_POINT_MODE, BM_GETCHECK, 0, 0L);
					if(_ASConfig->bWireframeMode)
					{
						_ASConfig->bWireframeMode = FALSE;
						SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_WIREFRAME_MODE, BM_SETCHECK, _ASConfig->bWireframeMode, 0L);
					}
					UpdateRenderQuality();
				break;
            }
            break;
    }
    return FALSE;
} // end ConfigGeneralProc()

LRESULT CALLBACK ConfigGraphicProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin ConfigGraphicProc()
	int i, i2;
    LPSTR byTemp = new char[MAX_PATH];

	switch(iMessage)
    {
        case WM_INITDIALOG:
			// Texts:
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_LIGHTING, T_Lighting);
  			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_LIGHT_NONE, T_None);
  			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_LIGHT_FLAT, T_Flat);
  			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_LIGHT_SMOOTH, T_Smooth);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_FAST_TEXTURING, T_FastTexturing);
  			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_USE_MIPMAPS, T_UseMipmaps);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_MULTITEXTURING, T_Multitexturing);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_HIGHT_RENDER_QUALITY, T_HightRenderQuality);
  			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_DISPLAY_MODE, T_DisplayMode);
  			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_FULLSCREEN, T_Fullscreen);

			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_PARTICLES, T_Particles);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY_T, T_ParticleDensity);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY_LOW, T_Low);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY_MIDDLE, T_Middle);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY_ALL, T_All);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER_T, T_ZBuffer);
			//
 			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER, CB_RESETCONTENT, 0, 0);
    		SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER, CB_ADDSTRING, 0, (LONG)(LPSTR) "8");
    		SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER, CB_ADDSTRING, 0, (LONG)(LPSTR) "16");
    		SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER, CB_ADDSTRING, 0, (LONG)(LPSTR) "24");
    		SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER, CB_ADDSTRING, 0, (LONG)(LPSTR) "32");
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER, CB_SETCURSEL, _ASConfig->byZBuffer/8-1, 0L);

			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_FULLSCREEN, BM_SETCHECK, _ASConfig->bFullScreen, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_FAST_TEXTURING, BM_SETCHECK, _ASConfig->bFastTexturing, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_USE_MIPMAPS, BM_SETCHECK, _ASConfig->bUseMipmaps, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_HIGHT_RENDER_QUALITY, BM_SETCHECK, _ASConfig->bHightRenderQuality, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MULTITEXTURING, BM_SETCHECK, _ASConfig->bMultitexturing, 0L);
			
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_PARTICLES, BM_SETCHECK, _ASConfig->bParticles, 0L);
			if(!_ASConfig->bHightRenderQuality)
				EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_MULTITEXTURING), FALSE);
			else
				EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_MULTITEXTURING), TRUE);
			switch(_ASConfig->byLight)
			{
				case 0: CheckRadioButton(hWnd, IDC_CONFIG_GRAPHIC_LIGHT_NONE, IDC_CONFIG_GRAPHIC_LIGHT_SMOOTH, IDC_CONFIG_GRAPHIC_LIGHT_NONE); break;
				case 1: CheckRadioButton(hWnd, IDC_CONFIG_GRAPHIC_LIGHT_NONE, IDC_CONFIG_GRAPHIC_LIGHT_SMOOTH, IDC_CONFIG_GRAPHIC_LIGHT_FLAT); break;
				case 2: CheckRadioButton(hWnd, IDC_CONFIG_GRAPHIC_LIGHT_NONE, IDC_CONFIG_GRAPHIC_LIGHT_SMOOTH, IDC_CONFIG_GRAPHIC_LIGHT_SMOOTH); break;
			}	
 			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MODES, CB_RESETCONTENT, 0, 0);
			wsprintf(byTemp, "All");
			// Put in the new entries:
			for(i = 0, i2 = 0; i < DisplayModeInfo.Number-1; i++)
			{
				if(DisplayModeInfo.pDevMode[i].dmBitsPerPel < (unsigned char) 16)
					continue;
				wsprintf(byTemp, "%dx%dx%d  %d HZ", 
						DisplayModeInfo.pDevMode[i].dmPelsWidth, 
						DisplayModeInfo.pDevMode[i].dmPelsHeight, 
						DisplayModeInfo.pDevMode[i].dmBitsPerPel, 
						DisplayModeInfo.pDevMode[i].dmDisplayFrequency);
     			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MODES, CB_ADDSTRING, 0, (LONG)(LPSTR) byTemp);
     			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MODES, CB_SETITEMDATA, i2, i);
				i2++;
			}
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MODES, CB_SETCURSEL, _ASConfig->iModeIndex, 0L);
		    SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY, TBM_SETRANGE, FALSE, MAKELONG(1, 100));
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY, TBM_SETTIC, TRUE, 50);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY, TBM_SETPOS, TRUE, (long) ((float) _ASConfig->fParticleDensity*100.0f));
			EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY), _ASConfig->bParticles);
		return TRUE;

		case WM_NOTIFY:
            switch(wParam)
            {
				case IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY:
					i = (int) SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY, TBM_GETPOS, 0, 0);
					_ASConfig->fParticleDensity = (float) i/100;
					if(_ASConfig->fParticleDensity > 1.0f)
						_ASConfig->fParticleDensity = 1.0f;
				break;
			}
		break;

		case WM_COMMAND:
            switch(LOWORD(wParam))
            {

				case IDC_CONFIG_GRAPHIC_FULLSCREEN:
				    _ASConfig->bFullScreen = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_FULLSCREEN, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_GRAPHIC_MODES:
   					i = (int) SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MODES, CB_GETCURSEL, 0, 0L);
					i = (int) SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MODES, CB_GETITEMDATA, i, 0);
					_ASConfig->iModeIndex = i;                         	
					CopyMemory(&_ASConfig->DevMode, &DisplayModeInfo.pDevMode[_ASConfig->iModeIndex], sizeof(DEVMODE));
				break;

				case IDC_CONFIG_GRAPHIC_FAST_TEXTURING:
					_ASConfig->bFastTexturing = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_FAST_TEXTURING, BM_GETCHECK, 0, 0L);
					UpdateAllTextures();
				break;

				case IDC_CONFIG_GRAPHIC_USE_MIPMAPS:
					_ASConfig->bUseMipmaps = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_USE_MIPMAPS, BM_GETCHECK, 0, 0L);
					UpdateAllTextures();
				break;

				case IDC_CONFIG_GRAPHIC_HIGHT_RENDER_QUALITY:
					_ASConfig->bHightRenderQuality = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_HIGHT_RENDER_QUALITY, BM_GETCHECK, 0, 0L);
					if(!_ASConfig->bHightRenderQuality)
					{
						EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_MULTITEXTURING), FALSE);
						SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MULTITEXTURING, BM_SETCHECK, FALSE, 0L);
					}
					else
					{
						EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_MULTITEXTURING), TRUE);
					}
					if(!_ASConfig->bHightRenderQuality)
						_ASConfig->bMultitexturing = FALSE;
					UpdateRenderQuality();
				break;

				case IDC_CONFIG_GRAPHIC_MULTITEXTURING:
					_ASConfig->bMultitexturing = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MULTITEXTURING, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_GRAPHIC_PARTICLES:
					_ASConfig->bParticles = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_PARTICLES, BM_GETCHECK, 0, 0L);
					EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY), _ASConfig->bParticles);
				break;
				
   				case IDC_CONFIG_GRAPHIC_Z_BUFFER:
					i = (int) SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER, CB_GETCURSEL, 0, 0L);
					if(i < 0)
						break;
					_ASConfig->byZBuffer = (i+1)*8;
				break;
            }
            break;
    }
    return FALSE;
} // end ConfigGraphicProc()

LRESULT CALLBACK ConfigSoundProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin ConfigSoundProc()
	int i;

	switch(iMessage)
    {
        case WM_INITDIALOG:
  			// Texts:
  			SetDlgItemText(hWnd, IDC_CONFIG_SOUND_MUSIC, T_Music);
  			SetDlgItemText(hWnd, IDC_CONFIG_SOUND_SOUND, T_Sound);
  			SetDlgItemText(hWnd, IDC_CONFIG_SOUND_MUSIC_VOLUME_T, T_MusicVolume);
			//
			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MUSIC, BM_SETCHECK, _ASConfig->bMusic, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_SOUND, BM_SETCHECK, _ASConfig->bSound, 0L);

		    SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MUSIC_VOLUME, TBM_SETRANGE, FALSE, MAKELONG(1, -(AS_DX_SHOW_VOLUME_SILENCE)));
			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MUSIC_VOLUME, TBM_SETTIC, TRUE, (-AS_DX_SHOW_VOLUME_SILENCE)/2);
			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MUSIC_VOLUME, TBM_SETPOS, TRUE, (long) -_ASConfig->iMusicVolume);
		
		Init:
			EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_SOUND_MUSIC_VOLUME), _ASConfig->bMusic);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_CONFIG_SOUND_MUSIC:
					_ASConfig->bMusic = SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MUSIC, BM_GETCHECK, 0, 0L);
					ASDXShowPause();
					goto Init;
				break;

				case IDC_CONFIG_SOUND_SOUND:
					_ASConfig->bSound = SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_SOUND, BM_GETCHECK, 0, 0L);
				break;
            }
        break;

        case WM_NOTIFY:
            switch(wParam)
            {
				case IDC_CONFIG_SOUND_MUSIC_VOLUME:
					i = (int) SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MUSIC_VOLUME, TBM_GETPOS, 0, 0);
					_ASConfig->iMusicVolume = -i;
				    if(pBA)
						pBA->put_Volume(_ASConfig->iMusicVolume);
				break;
			}
		break;
    }
    return FALSE;
} // end ConfigSoundProc()

LRESULT CALLBACK ConfigControlProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin ConfigControlProc()
	int i;
	
	switch(iMessage)
    {
        case WM_INITDIALOG:
  			// Texts:
  			SetDlgItemText(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY_T, T_MouseSensibility);
			SetDlgItemText(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY_SLOW, T_Slow);
  			SetDlgItemText(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY_NORMAL, T_Normal);
  			SetDlgItemText(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY_FAST, T_Fast);
			//
		    SendDlgItemMessage(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY, TBM_SETRANGE, FALSE, MAKELONG(1, 100));
			SendDlgItemMessage(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY, TBM_SETTIC, TRUE, 50);
			SendDlgItemMessage(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY, TBM_SETPOS, TRUE, (long) ((float) _ASConfig->fMouseSensibility*50.0f));
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case 0:
				break;
            }
        break;

        case WM_NOTIFY:
            switch(wParam)
            {
				case IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY:
					i = (int) SendDlgItemMessage(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY, TBM_GETPOS, 0, 0);
					_ASConfig->fMouseSensibility = (float) i/50;
				break;
			}
		break;
    }
    return FALSE;
} // end ConfigControlProc()

LRESULT CALLBACK ConfigCheatsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin ConfigCheatsProc()
	switch(iMessage)
    {
        case WM_INITDIALOG:
			hWndCheats = hWnd;
			// Texts:
			//
			UpdateCheats();
		return TRUE;

        case WM_COMMAND:
//            switch(LOWORD(wParam))
//            {
//            }
        break;
    }
    return FALSE;
} // end ConfigCheatsProc()

void UpdateCheats(void)
{ // begin UpdateCheats()
	if(!hWndCheats)
		return;
} // end UpdateCheats()

void SetupConfigTabs(void)
{ // begin SetupConfigTabs()
	HWND hWndTab;
	TC_ITEM tie; 

	// Setup config tabs:
	hWndTab = GetDlgItem(hWndConfig, IDC_CONFIG_TAB);
	TabCtrl_DeleteAllItems(hWndTab);
	tie.mask = TCIF_TEXT;
	// General:
	tie.pszText	= T_General;
	TabCtrl_InsertItem(hWndTab, TAB_CONFIG_GENERAL, &tie);
	if(hWndConfigTab[TAB_CONFIG_GENERAL])
		DestroyWindow(hWndConfigTab[TAB_CONFIG_GENERAL]);
	hWndConfigTab[TAB_CONFIG_GENERAL] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CONFIG_GENERAL), hWndTab, (DLGPROC) ConfigGeneralProc, WM_INITDIALOG);
	// Graphic:
	tie.pszText	= T_Graphic;
	TabCtrl_InsertItem(hWndTab, TAB_CONFIG_GRAPHIC, &tie);
	if(hWndConfigTab[TAB_CONFIG_GRAPHIC])
		DestroyWindow(hWndConfigTab[TAB_CONFIG_GRAPHIC]);
	hWndConfigTab[TAB_CONFIG_GRAPHIC] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CONFIG_GRAPHIC), hWndTab, (DLGPROC) ConfigGraphicProc, WM_INITDIALOG);
	// Sound:
	tie.pszText	= T_Sound;
	TabCtrl_InsertItem(hWndTab, TAB_CONFIG_SOUND, &tie);
	if(hWndConfigTab[TAB_CONFIG_SOUND])
		DestroyWindow(hWndConfigTab[TAB_CONFIG_SOUND]);
	hWndConfigTab[TAB_CONFIG_SOUND] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CONFIG_SOUND), hWndTab, (DLGPROC) ConfigSoundProc, WM_INITDIALOG);
	// Control:
	tie.pszText	= T_Control;
	TabCtrl_InsertItem(hWndTab, TAB_CONFIG_CONTROL, &tie);
	if(hWndConfigTab[TAB_CONFIG_CONTROL])
		DestroyWindow(hWndConfigTab[TAB_CONFIG_CONTROL]);
	hWndConfigTab[TAB_CONFIG_CONTROL] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CONFIG_CONTROL), hWndTab, (DLGPROC) ConfigControlProc, WM_INITDIALOG);
	if(bCheatsActivated)
	{ // Cheats:
		tie.pszText	= T_Cheats;
		TabCtrl_InsertItem(hWndTab, TAB_CONFIG_CHEATS, &tie);
		if(hWndConfigTab[TAB_CONFIG_CHEATS])
			DestroyWindow(hWndConfigTab[TAB_CONFIG_CHEATS]);
		hWndConfigTab[TAB_CONFIG_CHEATS] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CONFIG_CHEATS), hWndTab, (DLGPROC) ConfigCheatsProc, WM_INITDIALOG);
	}
	//
	if(iCurrentConfigTab != -1 && iCurrentConfigTab < CONFIG_TABS)
		TabCtrl_SetCurSel(GetDlgItem(hWndConfig, IDC_CONFIG_TAB), iCurrentConfigTab);
	SendMessage(hWndConfig, WM_NOTIFY, IDC_CONFIG_TAB, 0);
	ShowWindow(hWndConfig, _AS->GetCmdShow());
	UpdateWindow(hWndConfig);
} // end SetupConfigTabs()

void SetConfigLanguage(void)
{ // begin SetConfigLanguage()
	if(!hWndConfig)
		return;
	SetWindowText(hWndConfig, T_Configuration);
  	SetDlgItemText(hWndConfig, ID_CONFIG_OK, T_Ok);
  	SetDlgItemText(hWndConfig, ID_CONFIG_CANCEL, T_Cancel);
  	SetDlgItemText(hWndConfig, ID_CONFIG_QUIT, T_Quit);
  	SetDlgItemText(hWndConfig, IDC_CONFIG_HELP, T_Help);
  	SetDlgItemText(hWndConfig, IDC_CONFIG_CREDITS, T_Credits);
  	SetDlgItemText(hWndConfig, IDC_HOMEPAGE, T_Homepage);  	
	SetupConfigTabs();
} // end SetConfigLanguage()
//-----------------------------------------------------------------------------
// File: AS_Quaternion.h
//-----------------------------------------------------------------------------

#ifndef __AS_QUATERNION_H_
#define __AS_QUATERNION_H_


// Classes: *******************************************************************
typedef class AS_QUATERNION
{
	public:
		union
		{
			float fQ[4];
			struct
			{
				float w, x, y, z;
			};
			struct
			{
				float fW, fX, fY, fZ;
			};
		};

		// Constructor:
		AS_QUATERNION(void);
		AS_QUATERNION(const AS_QUATERNION &);
		AS_QUATERNION(float, float, float);
		AS_QUATERNION(float, float, float, float);
		
		// Misc:
		AS_QUATERNION &Reset(void);
		AS_QUATERNION &Set(const AS_QUATERNION &);
		AS_QUATERNION &Set(float, float, float);
		AS_QUATERNION &Set(float, float, float, float);
		AS_QUATERNION &PostMult(const AS_QUATERNION &);
		AS_QUATERNION &MultAndSet(const AS_QUATERNION &, const AS_QUATERNION &);
		AS_QUATERNION &Normalize(void);
		void GetMatrix(AS_MATRIX *);
		void GetInvertedMatrix(AS_MATRIX *);
		void SetMatrix(AS_MATRIX);
		void GetAxisAngle(float &, float &, float &, float &);
		void GetDirectionVector(AS_3D_VECTOR *);
		void EulerToQuat(const float, const float, const float);
		void GetEulerAngles(float &, float &, float &);
		void Slerp(const AS_QUATERNION, const AS_QUATERNION, const float);

} AS_QUATERNION;
///////////////////////////////////////////////////////////////////////////////


#endif	// __AS_QUATERNION_H_
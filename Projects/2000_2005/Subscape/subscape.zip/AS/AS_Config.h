//-----------------------------------------------------------------------------
// File: AS_Config.h
//-----------------------------------------------------------------------------

#ifndef __AS_CONFIG_H__
#define __AS_CONFIG_H__


// Structures: ****************************************************************
typedef struct
{
	int Number;
	DEVMODE *pDevMode;

} DISPLAY_MODE_INFO;
///////////////////////////////////////////////////////////////////////////////

// Classes: *******************************************************************
typedef class AS_CONFIG
{
	public:
		// General:
		BOOL bFirstRun; // Is this the first program start?
		BOOL bError, bSetError; // Was there an error?
		BOOL bSound; // Are the sounds activated?
		BOOL bMusic; // Are the music activated?
		BOOL bFrustumCulling; // Frustrum culling active?
		BOOL bShowFPS; // Should the frame rate be shown?
		BOOL bLog; // Is the program log active?
		char byLanguage[256]; // The selected language (name of the folder)
		float fMouseSensibility; // The mouse sensibility (0-1)
		long iMusicVolume; // The volume of the music
		
		// Graphic:
		BOOL bFullScreen; // Are we in fullscreen mode?
		BOOL bFastTexturing; 
		BOOL bUseMipmaps;
		BOOL bMultitexturing;
		BOOL bHightRenderQuality;
		DWORD dwMode;
		char byZBuffer; // The z buffer bit depth
		char byLight; // 0 = none, 1 = flat, 2 = smooth
		int iWindowWidth, iWindowHeight; // Main window size
		int iModeIndex; 
		DEVMODE DevMode;
		int iScreenPixels, iScreenSize;
		BOOL bParticles; // Are the particles activated?
		float fParticleDensity; // The number of partilces (1.0 = full)

		// Keys:
		// [0] = Key array position
		// [1] = Key description array position
		short iLeftKey[2], iRightKey[2], iUpKey[2], iDownKey[2],
			  iShotKey[2], iChangePerspectiveKey[2],
			  iStandartViewKey[2], iPauseKey[2],
			  iLevelRestartKey[2], iAfterburnerKey[2],
			  iRollLeftKey[2], iRollRightKey[2],
			  iFullStopKey[2], iSlideKey[2],
			  iForwardKey[2], iBackwardKey[2],
			  iSelectTargetKey[2], iHudKey[2];

		// Debug stuff:
		BOOL bWireframeMode,
			 bPointMode,
			 bShowCulledObjects,
			 bDrawBounding;

		AS_CONFIG(void);
		~AS_CONFIG(void);

		void Check(void);
        HRESULT Load(char *);
	    HRESULT Save(char *);

} AS_CONFIG;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern AS_CONFIG *_ASConfig;
extern DISPLAY_MODE_INFO DisplayModeInfo;
extern BOOL bFirstRunConfigDialog;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern void OpenConfigDialog(HWND);
extern LRESULT CALLBACK ConfigProc(HWND, UINT, WPARAM, LPARAM);
extern LRESULT CALLBACK ConfigGeneralProc(HWND, UINT, WPARAM, LPARAM);
extern LRESULT CALLBACK ConfigGraphicProc(HWND, UINT, WPARAM, LPARAM);
extern LRESULT CALLBACK ConfigSoundProc(HWND, UINT, WPARAM, LPARAM);
extern LRESULT CALLBACK ConfigCheatsProc(HWND, UINT, WPARAM, LPARAM);
extern void UpdateCheats(void);
extern void SetupConfigTabs(void);
extern void SetConfigLanguage(void);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_CONFIG_H__
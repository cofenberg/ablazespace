//---------------------------------------------------------------------------
// File: AS_Language.h
//-----------------------------------------------------------------------------

#ifndef __AS_LANGUAGE_H__
#define __AS_LANGUAGE_H__


// Variables: *****************************************************************
#define AS_TEXTS 85
extern char *pbyASText[AS_TEXTS];
#define AS_MESSAGES 8
extern char *pbyASMessage[AS_MESSAGES];
extern int iASCreditsTexts;
extern char **pbyASCreditsText;
extern int iASLanguages;  // The number of languages
extern char **pbyASLanguage; // All found languages names
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern void EnumerateLanguages(void);
extern void SetLanguage(char *);
extern void DestroyLanguage(void);
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// Here are all pointers to the texts:
extern char *T_HelpFile, *T_CreditsFile,
			*T_Ok, *T_Cancel, *T_Fullscreen, *T_DisplayMode, *T_Language,
			*T_Help, *T_Music, *T_Sound, *T_ShowFPS, *T_Log, *T_Lighting,
			*T_None, *T_Flat, *T_Smooth, *T_FastTexturing, *T_UseMipmaps,
			*T_Credits, *T_Configuration, *T_Homepage, *T_Version_,
			*T_ProgrammingAndDesign_, *T_Music_, *T_Homepage_, *T_EMail_,
			*T_ProgramInfo_, *T_Build_, *T_General, *T_Graphic, *T_Programming,
			*T_HightRenderQuality, *T_MouseSensibility, *T_Quit, *T_Error,
			*T_ShutdownError, *T_ShowBoundingBoxes, *T_FrustumCulling,
			*T_ShowCulledObjects, *T_Pause, *T_MoreCredits,
			*T_MainMenu, *T_StartGame, *T_Options, *T_Yes, *T_No, *T_KeysSetup,
			*T_OtherOptions, *T_Left, *T_Right, *T_Up, *T_Down, *T_Shot,
			*T_ChangePerspective, *T_StandartView, *T_LevelRestart,
			*T_StandartConfiguration, *T_PressNewKey, *T_EnterName, *T_Multitexturing,
			*T_Particles, *T_ParticleDensity, *T_Low, *T_Middle, *T_All, *T_ZBuffer,
			*T_MusicVolume, *T_Slow, *T_Normal, *T_Fast, *T_Invulnerable, *T_Lives,
			*T_Points, *T_Control, *T_Cheats, *T_Afterburner, *T_RollLeft, *T_RollRight,
			*T_FullStop, *T_Slide, *T_Forward, *T_Backward, *T_SelectTarget, *T_Hud,
			*T_WireframeMode, *T_PointMode;

// Pointer to messages:	
extern char *M_FirstProgramStart, *M_ProgramWasNotSutDownCorrectlyAtLastTime,
			*M_ProgramEndErrorDetected, *M_TheProgramIsAlreadyRunning,
			*M_CouldNotInitializeOpenGLGraphic, *M_PressAnyKeyToContinue, *M_AreYouSure;
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_LANGUAGE_H__
// The most frustum culling code was taken from Mark Morleys frustrum culling tutorial.
// His Tutorial could be found at:
// http://www.markmorley.com/opengl/frustumculling.html

#include "AS_Engine.h"


// Functions: *****************************************************************
void ASExtractFrustum(void);
BOOL ASPointInFrustum(float, float, float);
BOOL ASSphereInFrustum(float, float, float, float);
BOOL ASCubeInFrustum(float, float, float, float);
BOOL ASCubeInFrustum(float, float, float, float, float, float);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
float fASFrustum[6][4]; // Holds The Current Frustum Plane Equations
int iASCulledObjects; // The number of culled objects
///////////////////////////////////////////////////////////////////////////////


// Extracts The Current View Frustum Plane Equations:
void ASExtractFrustum(void)
{ // begin ASExtractFrustum()
	iASCulledObjects = 0;

	if(!_ASConfig->bFrustumCulling)
		return;

	float proj[16], // For grabbing the PROJECTION matrix
		  modl[16],	// For grabbing the MODELVIEW matrix
		  clip[16],	// Result of concatenating PROJECTION and MODELVIEW
		  t; // Temporary work variable
	
	glGetFloatv(GL_PROJECTION_MATRIX, proj); // Grab the current PROJECTION matrix
	glGetFloatv(GL_MODELVIEW_MATRIX, modl);	// Grab the current MODELVIEW matrix

	// Concatenate (Multiply) The Two Matricies
	clip[ 0] = modl[ 0]*proj[ 0] + modl[ 1]*proj[ 4] + modl[ 2]*proj[ 8] + modl[ 3]*proj[12];
	clip[ 1] = modl[ 0]*proj[ 1] + modl[ 1]*proj[ 5] + modl[ 2]*proj[ 9] + modl[ 3]*proj[13];
	clip[ 2] = modl[ 0]*proj[ 2] + modl[ 1]*proj[ 6] + modl[ 2]*proj[10] + modl[ 3]*proj[14];
	clip[ 3] = modl[ 0]*proj[ 3] + modl[ 1]*proj[ 7] + modl[ 2]*proj[11] + modl[ 3]*proj[15];

	clip[ 4] = modl[ 4]*proj[ 0] + modl[ 5]*proj[ 4] + modl[ 6]*proj[ 8] + modl[ 7]*proj[12];
	clip[ 5] = modl[ 4]*proj[ 1] + modl[ 5]*proj[ 5] + modl[ 6]*proj[ 9] + modl[ 7]*proj[13];
	clip[ 6] = modl[ 4]*proj[ 2] + modl[ 5]*proj[ 6] + modl[ 6]*proj[10] + modl[ 7]*proj[14];
	clip[ 7] = modl[ 4]*proj[ 3] + modl[ 5]*proj[ 7] + modl[ 6]*proj[11] + modl[ 7]*proj[15];

	clip[ 8] = modl[ 8]*proj[ 0] + modl[ 9]*proj[ 4] + modl[10]*proj[ 8] + modl[11]*proj[12];
	clip[ 9] = modl[ 8]*proj[ 1] + modl[ 9]*proj[ 5] + modl[10]*proj[ 9] + modl[11]*proj[13];
	clip[10] = modl[ 8]*proj[ 2] + modl[ 9]*proj[ 6] + modl[10]*proj[10] + modl[11]*proj[14];
	clip[11] = modl[ 8]*proj[ 3] + modl[ 9]*proj[ 7] + modl[10]*proj[11] + modl[11]*proj[15];

	clip[12] = modl[12]*proj[ 0] + modl[13]*proj[ 4] + modl[14]*proj[ 8] + modl[15]*proj[12];
	clip[13] = modl[12]*proj[ 1] + modl[13]*proj[ 5] + modl[14]*proj[ 9] + modl[15]*proj[13];
	clip[14] = modl[12]*proj[ 2] + modl[13]*proj[ 6] + modl[14]*proj[10] + modl[15]*proj[14];
	clip[15] = modl[12]*proj[ 3] + modl[13]*proj[ 7] + modl[14]*proj[11] + modl[15]*proj[15];


	// Extract the RIGHT clipping plane
	fASFrustum[0][0] = clip[ 3] - clip[ 0];
	fASFrustum[0][1] = clip[ 7] - clip[ 4];
	fASFrustum[0][2] = clip[11] - clip[ 8];
	fASFrustum[0][3] = clip[15] - clip[12];

	// Normalize it
	t = (float) sqrt(fASFrustum[0][0]*fASFrustum[0][0]+
					 fASFrustum[0][1]*fASFrustum[0][1]+
					 fASFrustum[0][2]*fASFrustum[0][2]);
	fASFrustum[0][0] /= t;
	fASFrustum[0][1] /= t;
	fASFrustum[0][2] /= t;
	fASFrustum[0][3] /= t;

	// Extract the LEFT clipping plane:
	fASFrustum[1][0] = clip[ 3] + clip[ 0];
	fASFrustum[1][1] = clip[ 7] + clip[ 4];
	fASFrustum[1][2] = clip[11] + clip[ 8];
	fASFrustum[1][3] = clip[15] + clip[12];

	// Normalize it:
	t = (float) sqrt(fASFrustum[1][0]*fASFrustum[1][0]+
					 fASFrustum[1][1]*fASFrustum[1][1]+
					 fASFrustum[1][2]*fASFrustum[1][2]);
	fASFrustum[1][0] /= t;
	fASFrustum[1][1] /= t;
	fASFrustum[1][2] /= t;
	fASFrustum[1][3] /= t;

	// Extract the BOTTOM clipping plane:
	fASFrustum[2][0] = clip[ 3] + clip[ 1];
	fASFrustum[2][1] = clip[ 7] + clip[ 5];
	fASFrustum[2][2] = clip[11] + clip[ 9];
	fASFrustum[2][3] = clip[15] + clip[13];

	// Normalize it:
	t = (float) sqrt(fASFrustum[2][0]*fASFrustum[2][0]+
					 fASFrustum[2][1]*fASFrustum[2][1]+
					 fASFrustum[2][2]*fASFrustum[2][2]);
	fASFrustum[2][0] /= t;
	fASFrustum[2][1] /= t;
	fASFrustum[2][2] /= t;
	fASFrustum[2][3] /= t;

	// Extract the TOP clipping plane:
	fASFrustum[3][0] = clip[ 3] - clip[ 1];
	fASFrustum[3][1] = clip[ 7] - clip[ 5];
	fASFrustum[3][2] = clip[11] - clip[ 9];
	fASFrustum[3][3] = clip[15] - clip[13];

	// Normalize it:
	t = (float) sqrt(fASFrustum[3][0]*fASFrustum[3][0]+
					 fASFrustum[3][1]*fASFrustum[3][1]+
					 fASFrustum[3][2]*fASFrustum[3][2]);
	fASFrustum[3][0] /= t;
	fASFrustum[3][1] /= t;
	fASFrustum[3][2] /= t;
	fASFrustum[3][3] /= t;

	// Extract the FAR clipping plane:
	fASFrustum[4][0] = clip[ 3] - clip[ 2];
	fASFrustum[4][1] = clip[ 7] - clip[ 6];
	fASFrustum[4][2] = clip[11] - clip[10];
	fASFrustum[4][3] = clip[15] - clip[14];

	// Normalize it
	t = (float) sqrt(fASFrustum[4][0]*fASFrustum[4][0]+
					 fASFrustum[4][1]*fASFrustum[4][1]+
					 fASFrustum[4][2]*fASFrustum[4][2]);
	fASFrustum[4][0] /= t;
	fASFrustum[4][1] /= t;
	fASFrustum[4][2] /= t;
	fASFrustum[4][3] /= t;

	// Extract the NEAR clipping plane:
	// This is last on purpose (see ASPointInFrustum() for reason)
	fASFrustum[5][0] = clip[ 3] + clip[ 2];
	fASFrustum[5][1] = clip[ 7] + clip[ 6];
	fASFrustum[5][2] = clip[11] + clip[10];
	fASFrustum[5][3] = clip[15] + clip[14];

	// Normalize it:
	t = (float) sqrt(fASFrustum[5][0]*fASFrustum[5][0]+
					 fASFrustum[5][1]*fASFrustum[5][1]+
					 fASFrustum[5][2]*fASFrustum[5][2]);
	fASFrustum[5][0] /= t;
	fASFrustum[5][1] /= t;
	fASFrustum[5][2] /= t;
	fASFrustum[5][3] /= t;
} // end ASExtractFrustum()

// Test if a point is in the frustum:
BOOL ASPointInFrustum(float x, float y, float z)
{ // begin ASPointInFrustum()
	if(!_ASConfig->bFrustumCulling)
		return true;

	for(int p = 0; p < 6; p++ )
		if( fASFrustum[p][0] * x + fASFrustum[p][1] * y + fASFrustum[p][2] * z + fASFrustum[p][3] <= 0 )
		{
			iASCulledObjects++;
			return false;
		}
	return true;
} // end ASPointInFrustum()

// Test if a sphere is in the frustum:
BOOL SphereInFrustum(float x, float y, float z, float radius)
{ // begin SphereInFrustum()
	if(!_ASConfig->bFrustumCulling)
		return true;

	for(int p = 0; p < 6; p++ )
		if( fASFrustum[p][0] * x + fASFrustum[p][1] * y + fASFrustum[p][2] * z + fASFrustum[p][3] <= -radius )
		{
			iASCulledObjects++;
			return false;
		}
	return true;
} // end SphereInFrustum()

// Test if a cube is in the frustum:
BOOL CubeInFrustum(float x, float y, float z, float size)
{ // begin CubeInFrustum()
	if(!_ASConfig->bFrustumCulling)
		return true;

	for(int p = 0; p < 6; p++ )
	{
		if(fASFrustum[p][0]*(x - size) + fASFrustum[p][1]*(y - size) + fASFrustum[p][2]*(z - size) + fASFrustum[p][3] > 0)
			continue;
		if(fASFrustum[p][0]*(x + size) + fASFrustum[p][1]*(y - size) + fASFrustum[p][2]*(z - size) + fASFrustum[p][3] > 0)
			continue;
		if(fASFrustum[p][0]*(x - size) + fASFrustum[p][1]*(y + size) + fASFrustum[p][2]*(z - size) + fASFrustum[p][3] > 0)
			continue;
		if(fASFrustum[p][0]*(x + size) + fASFrustum[p][1]*(y + size) + fASFrustum[p][2]*(z - size) + fASFrustum[p][3] > 0)
			continue;
		if(fASFrustum[p][0]*(x - size) + fASFrustum[p][1]*(y - size) + fASFrustum[p][2]*(z + size) + fASFrustum[p][3] > 0)
			continue;
		if(fASFrustum[p][0]*(x + size) + fASFrustum[p][1]*(y - size) + fASFrustum[p][2]*(z + size) + fASFrustum[p][3] > 0)
			continue;
		if(fASFrustum[p][0]*(x - size) + fASFrustum[p][1]*(y + size) + fASFrustum[p][2]*(z + size) + fASFrustum[p][3] > 0)
			continue;
		if(fASFrustum[p][0]*(x + size) + fASFrustum[p][1]*(y + size) + fASFrustum[p][2]*(z + size) + fASFrustum[p][3] > 0)
			continue;
		iASCulledObjects++;
		return false;
	}
	return true;
} // end CubeInFrustum()

// Test if a cube with different sizes is in the frustum:
BOOL ASCubeInFrustum(float fXMin, float fXMax, float fYMin, float fYMax, float fZMin, float fZMax)
{ // begin ASCubeInFrustum()
	if(!_ASConfig->bFrustumCulling)
		return true;

	for(int p = 0; p < 6; p++ )
	{
		if(fASFrustum[p][0]*fXMin + fASFrustum[p][1]*fYMin + fASFrustum[p][2]*fZMin + fASFrustum[p][3] > 0)
			continue;
		if(fASFrustum[p][0]*fXMax + fASFrustum[p][1]*fYMin + fASFrustum[p][2]*fZMin + fASFrustum[p][3] > 0)
			continue;
		if(fASFrustum[p][0]*fXMin + fASFrustum[p][1]*fYMax + fASFrustum[p][2]*fZMin + fASFrustum[p][3] > 0)
			continue;
		if(fASFrustum[p][0]*fXMax + fASFrustum[p][1]*fYMax + fASFrustum[p][2]*fZMin + fASFrustum[p][3] > 0)
			continue;
		if(fASFrustum[p][0]*fXMin + fASFrustum[p][1]*fYMin + fASFrustum[p][2]*fZMax + fASFrustum[p][3] > 0)
			continue;
		if(fASFrustum[p][0]*fXMax + fASFrustum[p][1]*fYMin + fASFrustum[p][2]*fZMax + fASFrustum[p][3] > 0)
			continue;
		if(fASFrustum[p][0]*fXMin + fASFrustum[p][1]*fYMax + fASFrustum[p][2]*fZMax + fASFrustum[p][3] > 0)
			continue;
		if(fASFrustum[p][0]*fXMax + fASFrustum[p][1]*fYMax + fASFrustum[p][2]*fZMax + fASFrustum[p][3] > 0)
			continue;
		iASCulledObjects++;
		return false;
	}
	return true;
} // end ASCubeInFrustum()
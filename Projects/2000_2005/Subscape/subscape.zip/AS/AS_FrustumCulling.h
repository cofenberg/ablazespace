//-----------------------------------------------------------------------------
// File: AS_FrustumCulling.h
//-----------------------------------------------------------------------------

#ifndef __AS_FRUSTUM_CULLING_H__
#define __AS_FRUSTUM_CULLING_H__


// Functions: *****************************************************************
extern void ASExtractFrustum(void);
extern BOOL ASPointInFrustum(float, float, float);
extern BOOL ASSphereInFrustum(float, float, float, float);
extern BOOL ASCubeInFrustum(float, float, float, float);
extern BOOL ASCubeInFrustum(float, float, float, float, float, float);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern float fASFrustum[6][4];
extern int iASCulledObjects;
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_FRUSTUM_CULLING_H__
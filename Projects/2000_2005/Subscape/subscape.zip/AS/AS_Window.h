//-----------------------------------------------------------------------------
// File: AS_Window.h
//-----------------------------------------------------------------------------

#ifndef __AS_WINDOW_H__
#define __AS_WINDOW_H__


// Classes: *******************************************************************
typedef class AS_WINDOW
{
	HWND  hWnd; // Window handle
	HDC	  hDC; // Private GDI device context
	HGLRC hRC; // Permanent rendering context

	int iWidth, iHeight; // The size of the window
	int iID; // The windows ID
	BOOL bIsMainWindow; // Is this the main window?
	BOOL bDisplayUpdateInfo; // Should the update information be shown (e.g. the FPS)

	GLuint iFontBase;
	GLuint iFontTexture[1];

	HRESULT (*pDraw)(AS_WINDOW *);
	HRESULT (*pCheck)(AS_WINDOW *);

	public:

		HWND ASCreateWindow(WNDPROC, LPCTSTR, LPCTSTR, DWORD, DWORD, HMENU, BOOL,
							HRESULT (*)(AS_WINDOW *), HRESULT (*)(AS_WINDOW *), HBRUSH,
							BOOL);
		HRESULT ASDestroyWindow(HWND *, LPCTSTR);
		HRESULT InitOpenGL(void);
		HRESULT DestroyOpenGL(void);
		HRESULT Draw(void);
		HRESULT Check(void);
		HWND *GethWnd(void) { return &hWnd; }
		HDC *GethDC(void) { return &hDC; }
		HGLRC *GethRC(void) { return &hRC; }
		void SetID(int iIDT) { iID = iIDT; }
		int GetID(void) { return iID; }
		int GetWidth(void) { return iWidth; }
		int GetHeight(void) { return iWidth; }
		BOOL GetIsMainWindow(void) { return bIsMainWindow; }
		void SetDrawFunction(HRESULT (*pTemp)(AS_WINDOW *)) { pDraw = pTemp; }
		void SetCheckFunction(HRESULT (*pTemp)(AS_WINDOW *)) { pCheck = pTemp; }
		void Resize(int, int);
		void MakeScreenshot(char *);

		void BuildFont(void);
		void KillFont(void);
		void Print(int, int, char *, int, BOOL);
		void PrintAnimated(int, int, char *, int,
						   float, float [4][2], BOOL);

} AS_WINDOW;
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_WINDOW__
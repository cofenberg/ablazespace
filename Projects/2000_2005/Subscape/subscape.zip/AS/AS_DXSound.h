//-----------------------------------------------------------------------------
// File: AS_DXSound.h
//-----------------------------------------------------------------------------

#ifndef __AS_DXSOUND_H__
#define __AS_DXSOUND_H__


// Functions: *****************************************************************
extern void ASCreatDXSoundManager(HWND);
extern void ASDestroyDXSoundManager(void);
extern void ASLoadDXSound(HWND, CSound **, char *);
extern void ASPlayDXSound(CSound *, BOOL);
extern void ASStopDXSound(CSound *);
extern void ASResetDXSound(CSound *);
extern void ASDestroyDXSound(CSound **);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_DXSOUND_H__
//-----------------------------------------------------------------------------
// File: AS_Particle.cpp
//-----------------------------------------------------------------------------

#include "AS_Engine.h"


// Functions: *****************************************************************
void ASParticleSystemDraw_Standart(AS_PARTICLE_SYSTEM *);
void ASParticleSystemDraw_Ablaze(AS_PARTICLE_SYSTEM *);
void ASParticleSystemCheck_Md2Trace(AS_PARTICLE_SYSTEM *);
void ASParticleSystemCheck_ShotTrace1(AS_PARTICLE_SYSTEM *);
void ASParticleSystemCheck_Smoke1(AS_PARTICLE_SYSTEM *);
void ASParticleSystemCheck_ASLogo(AS_PARTICLE_SYSTEM *);
void ASParticleSystemCheck_Engine(AS_PARTICLE_SYSTEM *);
void ASParticleSystemCheck_Crosshair(AS_PARTICLE_SYSTEM *);
void ASParticleSystemCheck_Ablaze(AS_PARTICLE_SYSTEM *);
///////////////////////////////////////////////////////////////////////////////


//////////          AS_PARTICLE_SYSTEM          ///////////////////////////////

// Get's the vertices positions of a md2 model and creat's particles:
void AS_PARTICLE_SYSTEM::CreateMd2Vertices(AS_MD2_MODEL *model, int frame1, int frame2,
										   float pol, FLOAT3 fPos, FLOAT3 fRot, float fScale)
{ // begin AS_PARTICLE_SYSTEM::CreateMd2Vertices()
	AS_MD2_FRAME *f1 = &model->frames[frame1];
	AS_MD2_FRAME *f2 = &model->frames[frame2];
	float x1, y1, z1, x2, y2, z2;
	AS_PARTICLE *pParticleT;
	short i, i2;
	

	for(i = 0, i2 = 0; i < model->header.numVertices; i += iMaxParticles/iParticles)
	{
		if(pParticle[i2].bAlive)
		{ // Find the next free particle:
			for(i2++;; i2++)
			{
				if(i2 >= iParticles)
				{
					i = model->header.numVertices;
					break;
				}
				if(!pParticle[i2].bAlive)
				{ // We've found an none active particle:
					break;
				}
			}
			if(i2 >= iParticles)
			{ // There is no active particle!
				break;
			}
		}

		// Create a particle on this md2 vertex:
		pParticleT = &pParticle[i2];
		pParticleT->bAlive = TRUE;

		// Calculate the position of the particle:
		x1 = f1->vertices[i].vertex[0];
		y1 = f1->vertices[i].vertex[1];
		z1 = f1->vertices[i].vertex[2];
		x2 = f2->vertices[i].vertex[0];
		y2 = f2->vertices[i].vertex[1];
		z2 = f2->vertices[i].vertex[2];
		pParticleT->fPos[X] = (x1+pol*(x2-x1));
		pParticleT->fPos[Y] = (y1+pol*(y2-y1));
		pParticleT->fPos[Z] = (z1+pol*(z2-z1));

		ASRotateVectorX(pParticleT->fPos, fRot[X], &pParticleT->fPos);
		ASRotateVectorZ(pParticleT->fPos, fRot[Y], &pParticleT->fPos);
		ASRotateVectorZ(pParticleT->fPos, fRot[Z], &pParticleT->fPos);

		pParticleT->fPos[X] *= fScale;
		pParticleT->fPos[Y] *= fScale;
		pParticleT->fPos[Z] *= fScale;

		pParticleT->fPos[X] += fPos[X];
		pParticleT->fPos[Y] += fPos[Y];
		pParticleT->fPos[Z] += fPos[Z];
		pParticleT->fVelocity[X] = 0.0f;
		pParticleT->fVelocity[Y] = 0.0f;
		pParticleT->fVelocity[Z] = 0.5f;
		if(!bChecked)
		{
			pParticleT->fEngine = (float) (rand() % 100)/100;
			pParticleT->fSize = (float) (rand() % 100)/80;
			pParticleT->fColor[0] = (float) (rand() % 100)/100;
			pParticleT->fColor[1] = (float) (rand() % 100)/100;
			pParticleT->fColor[2] = (float) (rand() % 100)/100;

			pParticleT->fFadeSpeed = (float) (rand() % 100)/5000;
			if(!pParticleT->fFadeSpeed)
				pParticleT->fFadeSpeed = 0.01f;
			pParticleT->fFixPos[X] = pParticleT->fLastPos[X] = pParticleT->fPos[X];
			pParticleT->fFixPos[Y] = pParticleT->fLastPos[Y] = pParticleT->fPos[Y];
			pParticleT->fFixPos[Z] = pParticleT->fLastPos[Z] = pParticleT->fPos[Z];
		}
	}
} // end AS_PARTICLE_SYSTEM::CreateMd2Vertices()

short AS_PARTICLE_SYSTEM::GetFreeParticle(void)
{ // begin AS_PARTICLE_SYSTEM::GetFreeParticle()
	short i;

	for(i = 0; i < iParticles; i++)
		if(!pParticle[i].bAlive)
			return i;
	return -1;
} // end AS_PARTICLE_SYSTEM::GetFreeParticle()


//////////          AS_PARTICLE_MANAGER          //////////////////////////////

void AS_PARTICLE_MANAGER::Check(void)
{ // begin AS_PARTICLE_MANAGER::Check()
	short i;

	if(!_ASConfig->bParticles)
		return;
	for(i = 0; i < iSystems; i++)
	{
		if(!pSystem[i].Check)
			continue;
		pSystem[i].Check(&pSystem[i]);
	}
} // end AS_PARTICLE_MANAGER::Check()

void AS_PARTICLE_MANAGER::Draw(void)
{ // begin AS_PARTICLE_MANAGER::Drawk()
	short i;

	if(!_ASConfig->bParticles)
		return;
	glEnable(GL_BLEND);
	glDisable(GL_CULL_FACE);
	glDisable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);
	glDepthMask(FALSE);
	glEnable(GL_DEPTH_TEST);

	for(i = 0; i < iSystems; i++)
	{
		if(!pSystem[i].Check)
			continue;
		glPushMatrix();
		if((ACTOR *) pSystem[i].pActor == &Player.Actor)
		{
			float axisX, axisY, axisZ, rotAngle;
			glTranslatef(Player.Actor.vWorldPos.fX, Player.Actor.vWorldPos.fY, -Player.Actor.vWorldPos.fZ);
			Player.Actor.qRotation.GetAxisAngle(axisX, axisY, axisZ, rotAngle);
			glRotatef((float) (rotAngle*RAD_TO_DEG), axisX, axisY, -axisZ);
			glRotatef(90.0f, 0.0f, 1.0f, 0.0f);
			glScalef(0.01f, 0.01f, 0.01f);
		}
		pSystem[i].Draw(&pSystem[i]);
		glPopMatrix();
	}

	ASEnableLighting();
	glDepthMask(TRUE);
	glDisable(GL_BLEND);
	glEnable(GL_CULL_FACE);
} // end AS_PARTICLE_MANAGER::Draw()

short AS_PARTICLE_MANAGER::AddNewSystem(AS_PARTICLE_SYSTEM_TYPE Type, short iParticles, void *pActor, AS_TEXTURE *pTexture, AS_TEXTURE *pSourceTexture)
{ // begin AS_PARTICLE_MANAGER::AddNewSystem()
	AS_PARTICLE_SYSTEM *pSystemT;
	AS_PARTICLE *pParticleT;
	short i, i2, x, y;
	BYTE *pbyData;

	// Add the new system:
	iSystems++;
	pSystem = (AS_PARTICLE_SYSTEM *) realloc(pSystem, sizeof(AS_PARTICLE_SYSTEM)*iSystems);

	pSystemT = &pSystem[iSystems-1];
	memset(pSystemT, 0, sizeof(AS_PARTICLE_SYSTEM));
	
	// Setup the system:		
	pSystemT->iID = iSystems-1;
	pSystemT->pActor = pActor;
	pSystemT->pTexture = pTexture;
	pSystemT->Type = Type;
	pSystemT->iMaxParticles = iParticles;
	if(pSystemT->Type == PS_ASLogo)
		pSystemT->iParticles = pSystemT->iMaxParticles;
	else
	{
		pSystemT->iParticles = (short) (pSystemT->iMaxParticles*_ASConfig->fParticleDensity);
		if(!pSystemT->iParticles)
			pSystemT->iParticles = 1;
	}
	pSystemT->pParticle = (AS_PARTICLE *) malloc(sizeof(AS_PARTICLE)*pSystemT->iParticles);
	memset(pSystemT->pParticle, 0, sizeof(AS_PARTICLE)*pSystemT->iParticles);

	switch(pSystemT->Type)
	{
		case PS_Md2Trace:
			pSystemT->Check = ASParticleSystemCheck_Md2Trace;
			pSystemT->Draw = ASParticleSystemDraw_Standart;

			pSystemT->bRandomDelay = FALSE;
			pSystemT->lTimeDelay = pSystemT->lMaxRandomDelay = 30;
			pSystemT->lLiveStartTime = g_lNow;
			pSystemT->lLiveEndTime = -1;
		break;

		case PS_ShotTrace1:
			pSystemT->Check = ASParticleSystemCheck_ShotTrace1;
			pSystemT->Draw = ASParticleSystemDraw_Standart;

			pSystemT->bRandomDelay = FALSE;
			pSystemT->lTimeDelay = pSystemT->lMaxRandomDelay = 10;
			pSystemT->lLiveStartTime = g_lNow;
			pSystemT->lLiveEndTime = -1;
		break;

		case PS_Smoke1:
			pSystemT->Check = ASParticleSystemCheck_Smoke1;
			pSystemT->Draw = ASParticleSystemDraw_Standart;

			pSystemT->bRandomDelay = FALSE;
			pSystemT->lTimeDelay = pSystemT->lMaxRandomDelay = 1;
			pSystemT->lLiveStartTime = g_lNow;
			pSystemT->lLiveEndTime = g_lNow+500;
		break;

		case PS_Smoke2:
			pSystemT->Check = ASParticleSystemCheck_Smoke1;
			pSystemT->Draw = ASParticleSystemDraw_Standart;

			pSystemT->bRandomDelay = FALSE;
			pSystemT->lTimeDelay = pSystemT->lMaxRandomDelay = 50;
			pSystemT->lLiveStartTime = g_lNow;
			pSystemT->lLiveEndTime = -1;
		break;

		case PS_ASLogo:
			for(i = 0, i2 = 0, x = 0, y = 0; i < pSystemT->iParticles; i++, i2 += 3, x++)
			{
				if(x >= pSourceTexture->iWidth)
				{
					y++;
					x = 0;
				}
				pbyData = pSourceTexture->pbyData;
				if(!pbyData[i2] && !pbyData[i2+1] && !pbyData[i2])
					continue;
				pParticleT = &pSystemT->pParticle[i];
				memset(pParticleT, 0, sizeof(AS_PARTICLE));
				pParticleT->fPos[X] = pParticleT->fLastPos[X] = pParticleT->fFixPos[X] = (float) x;
				pParticleT->fPos[Y] = pParticleT->fLastPos[Y] = pParticleT->fFixPos[Y] = (float) y;
				pParticleT->fColor[0] = (float) pbyData[i2]/255;
				pParticleT->fColor[1] = (float) pbyData[i2+1]/255;
				pParticleT->fColor[2] = (float) pbyData[i2+2]/255;
				pParticleT->bAlive = TRUE;
				pParticleT->fSize = 8.0f+((float) (rand() % 300)/100);
				pParticleT->bTemp[0] = rand() % 2;
			}
			pSystemT->Check = ASParticleSystemCheck_ASLogo;
			pSystemT->Draw = ASParticleSystemDraw_Standart;
			pSystemT->lTimeDelay = pSystemT->lMaxRandomDelay = 1;
			pSystemT->lLiveStartTime = g_lNow;
		break;

		case PS_Engine:
			pSystemT->Check = ASParticleSystemCheck_Engine;
			pSystemT->Draw = ASParticleSystemDraw_Standart;

			pSystemT->bRandomDelay = FALSE;
			pSystemT->lTimeDelay = pSystemT->lMaxRandomDelay = 50;
			pSystemT->lLiveStartTime = g_lNow;
			pSystemT->lLiveEndTime = -1;
		break;

		case PS_Crosshair:
			pSystemT->Check = ASParticleSystemCheck_Crosshair;
			pSystemT->Draw = ASParticleSystemDraw_Standart;
		break;

		case PS_Ablaze:
			pSystemT->Check = ASParticleSystemCheck_Ablaze;
			pSystemT->Draw = ASParticleSystemDraw_Ablaze;
		break;
	}
	return iSystems-1;
} // end AS_PARTICLE_MANAGER::AddNewSystem()

void AS_PARTICLE_MANAGER::DeleteSystem(short iID)
{ // begin AS_PARTICLE_MANAGER::DeleteSystem()
	short i;

	// Destroy the system:
	SAFE_DELETE(pSystem[iID].pParticle);

	// Update all systems:
	for(i = iID; i < iSystems-1; i++)
	{
		memcpy(&pSystem[i], &pSystem[i+1], sizeof(AS_PARTICLE_SYSTEM));
		pSystem[i].iID--;
	}

	// Romove the last system:
	iSystems--;
	pSystem = (AS_PARTICLE_SYSTEM *) realloc(pSystem, sizeof(AS_PARTICLE_SYSTEM)*iSystems);
} // end AS_PARTICLE_MANAGER::DeleteSystem()

void AS_PARTICLE_MANAGER::Destroy(void)
{ // begin AS_PARTICLE_MANAGER::Destroy()
	short i;

	for(i = 0; i < iSystems; i++)
		SAFE_DELETE(pSystem[i].pParticle);
	SAFE_DELETE(pSystem);
	memset(this, 0, sizeof(AS_PARTICLE_MANAGER));
} // end AS_PARTICLE_MANAGER::Destroy()

void AS_PARTICLE_MANAGER::UpdateSystems(void)
{ // begin AS_PARTICLE_MANAGER::UpdateSystems()
	AS_PARTICLE_SYSTEM *pSystemT;
	short i, i2, iTemp;

	for(i = 0; i < iSystems; i++)
	{
		pSystemT = &pSystem[i];
		iTemp = pSystemT->iParticles;
		pSystemT->iParticles = (short) (pSystemT->iMaxParticles*_ASConfig->fParticleDensity);
		if(!pSystemT->iParticles)
			pSystemT->iParticles = 1;
		pSystemT->pParticle = (AS_PARTICLE *) realloc(pSystemT->pParticle, sizeof(AS_PARTICLE)*pSystemT->iParticles);
		for(i2 = iTemp; i2 < pSystemT->iParticles; i2++)
			memset(&pSystemT->pParticle[i2], 0, sizeof(AS_PARTICLE));
	}
} // end AS_PARTICLE_MANAGER::UpdateSystems()

//////////          Types of partcile systems        //////////////////////////
//////////          Md2Trace       ////////////////////////////////////////////

void ASParticleSystemDraw_Standart(AS_PARTICLE_SYSTEM *pSystemT)
{ // begin ASParticleSystemDraw_Standart)
	AS_PARTICLE *pParticleT;
	short i;

	if(pSystemT->Type == PS_ShotTrace1)
	 i = 0;

	if(!pSystemT->bActive || (pSystemT->Type != PS_ASLogo && pSystemT->Type != PS_Engine && !pSystemT->pActor) || pSystemT->iVertex < 0)
		return;

	if(pSystemT->pTexture)
		glBindTexture(GL_TEXTURE_2D, pSystemT->pTexture->iOpenGLID);

	FLOAT3 tl, tr, bl, br;
	FLOAT3 tlT, trT, blT, brT;
	FLOAT3 ptl, ptr, pbl, pbr;
	FLOAT3 x, y;
	float m[16];

	// Get the billboard information: (The particle looks always into the camera)
	glGetFloatv(GL_MODELVIEW_MATRIX, m);
	x[0] = m[0];
	x[1] = m[4];
	x[2] = m[8];
	y[0] = m[1];
	y[1] = m[5];
	y[2] = m[9];
	ASSubVec(x, y, &tl);
	ASAddVec(x, y, &tr);
	ASInvertVec(x, &x);
	ASSubVec(x, y, &bl);
	ASAddVec(x, y, &br);
	ASScaleVec(tl, 0.2f, &tl);
	ASScaleVec(tr, 0.2f, &tr);
	ASScaleVec(bl, 0.2f, &bl);
	ASScaleVec(br, 0.2f, &br);

  	glBegin(GL_QUADS);
		for(i = 0; i < pSystemT->iParticles; i++)
		{
			pParticleT = &pSystemT->pParticle[i];

			if(!pParticleT->bAlive)
				continue;

			// Draw the particle:
			glColor4f(pParticleT->fColor[0], pParticleT->fColor[1], pParticleT->fColor[2], pParticleT->fEngine);

			ASScaleVec(tl, pParticleT->fSize, &tlT);
			ASScaleVec(tr, pParticleT->fSize, &trT);
			ASScaleVec(bl, pParticleT->fSize, &blT);
			ASScaleVec(br, pParticleT->fSize, &brT);

			ASAddVec(pParticleT->fPos, tlT, &ptl);
			ASAddVec(pParticleT->fPos, trT, &ptr);
			ASAddVec(pParticleT->fPos, blT, &pbl);
			ASAddVec(pParticleT->fPos, brT, &pbr);

			glTexCoord2f(0.0f, 1.0f);
			glVertex3fv(ptl);

			glTexCoord2f(1.0f, 1.0f);
			glVertex3fv(ptr);

			glTexCoord2f(1.0f, 0.0f);
			glVertex3fv(pbr);

			glTexCoord2f(0.0f, 0.0f);
			glVertex3fv(pbl);
		}
	glEnd();
} // end ASParticleSystemDraw_Standart()

void ASParticleSystemDraw_Ablaze(AS_PARTICLE_SYSTEM *pSystemT)
{ // begin ASParticleSystemDraw_Ablaze)
	AS_PARTICLE *pParticleT;
	short i;

/*	if(!ASCubeInFrustum(Environment.fAblazeBox[MIN][X], Environment.fAblazeBox[MIN][Y], Environment.fAblazeBox[MIN][Z],
						Environment.fAblazeBox[MAX][X], Environment.fAblazeBox[MAX][Z], Environment.fAblazeBox[MAX][Z]))
		return; // The ablaze is not visible!*/
	if(!pSystemT->bActive)
		return;

	if(pSystemT->pTexture)
		glBindTexture(GL_TEXTURE_2D, pSystemT->pTexture->iOpenGLID);

	FLOAT3 tl, tr, bl, br;
	FLOAT3 tlT, trT, blT, brT;
	FLOAT3 ptl, ptr, pbl, pbr;
	FLOAT3 x, y;
	float m[16];

	// Get the billboard information: (The particle looks always into the camera)
	glGetFloatv(GL_MODELVIEW_MATRIX, m);
	x[0] = m[0];
	x[1] = m[4];
	x[2] = m[8];
	y[0] = m[1];
	y[1] = m[5];
	y[2] = m[9];
	ASSubVec(x, y, &tl);
	ASAddVec(x, y, &tr);
	ASInvertVec(x, &x);
	ASSubVec(x, y, &bl);
	ASAddVec(x, y, &br);
	ASScaleVec(tl, 0.2f, &tl);
	ASScaleVec(tr, 0.2f, &tr);
	ASScaleVec(bl, 0.2f, &bl);
	ASScaleVec(br, 0.2f, &br);

	glBegin(GL_QUADS);
		for(i = 0; i < pSystemT->iParticles; i++)
		{
			pParticleT = &pSystemT->pParticle[i];

			if(!pParticleT->bAlive)
				continue;
			// Draw the particle:
			glColor4f(pParticleT->fColor[0], pParticleT->fColor[1], pParticleT->fColor[2], pParticleT->fEngine);
			ASScaleVec(tl, pParticleT->fSize, &tlT);
			ASScaleVec(tr, pParticleT->fSize, &trT);
			ASScaleVec(bl, pParticleT->fSize, &blT);
			ASScaleVec(br, pParticleT->fSize, &brT);

			ASAddVec(pParticleT->fPos, tlT, &ptl);
			if(pParticleT->bTemp[0])
				ASAddVec(pParticleT->fPos, trT, &ptr);
			else
				ptr[0] = ptr[1] = ptr[2] = 0.0f;
			ASAddVec(pParticleT->fPos, blT, &pbl);
			ASAddVec(pParticleT->fPos, brT, &pbr);

			glTexCoord2f(0.0f, 1.0f);
			glVertex3fv(ptl);

			glTexCoord2f(1.0f, 1.0f);
			glVertex3fv(ptr);

			glTexCoord2f(1.0f, 0.0f);
			glVertex3fv(pbr);

			glTexCoord2f(0.0f, 0.0f);
			glVertex3fv(pbl);
		}
	glEnd();
} // end ASParticleSystemDraw_Ablaze()

void ASParticleSystemCheck_Md2Trace(AS_PARTICLE_SYSTEM *pSystemT)
{ // begin ASParticleSystemCheck_Md2Trace()
	AS_PARTICLE *pParticleT;
	ACTOR *pActorT;
	float fTime;
	short i;

	pActorT = (ACTOR *) pSystemT->pActor;
	if(!pSystemT->bActive || !pActorT || !pActorT->bActive)
		return;

	// Check the system:
	if(pSystemT->lLiveEndTime != -1 && g_lNow > pSystemT->lLiveEndTime)
		pSystemT->bGoingInActive = TRUE;
	if(pSystemT->bGoingInActive)
	{
		for(i = 0; i < pSystemT->iParticles; i++)
		{
			if(pSystemT->pParticle[i].bAlive)
				break;
		}
		if(i >= pSystemT->iParticles)
		{
			pSystemT->bActive = FALSE;
			pSystemT->bGoingInActive = FALSE;
			return;
		}
	}
	else
	if(g_lNow > pSystemT->lNextTime)
	{ // The system should be updated:
		if(pSystemT->bRandomDelay)
		{ // Get the time do the next update per random:
			pSystemT->lTimeDelay = rand() % pSystemT->lMaxRandomDelay;
		}
		pSystemT->lLastTime = g_lNow;
		pSystemT->lNextTime = pSystemT->lLastTime+pSystemT->lTimeDelay;
		// 
		switch(pActorT->byType)
		{
			case ACTOR_PLAYER_SHIP:
/*				fPos[X] = pPlayer->fWorldPos[X]+0.5f;
				fPos[Y] = pPlayer->fWorldPos[Y]+0.5f;
				fPos[Z] = pPlayer->fWorldPos[Z]-0.6f;
				pSystemT->CreateMd2Vertices(pXeModel, pActorT->iAniStep, pActorT->iNextAniStep, pPlayer->fModelInterpolation, fPos);*/
			break;
		}
	}

	fTime = (float) g_lDeltatime/1000;
	FLOAT3 fRayDirection;
	
	// Ray direction for the 'normal' test points:
	fRayDirection[X] = 0.0f;
	fRayDirection[Y] = 0.0f;
	fRayDirection[Z] = 1.0f;

	FLOAT3 fPoint;
	fPoint[X] = fPoint[Y] = fPoint[Z] = 0.0f;


	// Check each particle:
	for(i = 0; i < pSystemT->iParticles; i++)
	{
		pParticleT = &pSystemT->pParticle[i];

		if(!pParticleT->bAlive)
			continue;
		
		// Check the particle:
		pParticleT->fEngine -= (float) pParticleT->fFadeSpeed*g_lDeltatime/10.0f;
		if(pParticleT->fEngine <= 0.0f)
		{ // The particle is now 'death':
			pParticleT->bAlive = FALSE;
			continue;
		}
		memcpy(pParticleT->fLastPos, pParticleT->fPos, sizeof(FLOAT3));

		pParticleT->fVelocity[X] += pParticleT->fVelocity[X]*fTime;
		pParticleT->fVelocity[Y] += pParticleT->fVelocity[Y]*fTime;
		pParticleT->fVelocity[Z] += pParticleT->fVelocity[Z]*fTime;
		pParticleT->fPos[X] += pParticleT->fVelocity[X]*fTime;
		pParticleT->fPos[Y] += pParticleT->fVelocity[Y]*fTime;
		pParticleT->fPos[Z] += pParticleT->fVelocity[Z]*fTime;
	}
} // end ASParticleSystemCheck_Md2Trace()

void ASParticleSystemCheck_ShotTrace1(AS_PARTICLE_SYSTEM *pSystemT)
{ // begin ASParticleSystemCheck_ShotTrace1()
	AS_PARTICLE *pParticleT;
	ACTOR *pActorT;
	short i, i2;

	pActorT = (ACTOR *) pSystemT->pActor;

	float f = pActorT->vWorldVelocity.GetLength();

	float f2 = (f/pActorT->fForward);

	if(!pSystemT->bActive || !pActorT)
		return;

	if(!pActorT->bActive || pActorT->bGoingDeath)
		pSystemT->bGoingInActive = TRUE;
	if(pSystemT->lLiveEndTime != -1 && g_lNow > pSystemT->lLiveEndTime)
		pSystemT->bGoingInActive = TRUE;
	// Check the system:
	if(pSystemT->bGoingInActive)
	{
		for(i = 0; i < pSystemT->iParticles; i++)
		{
			if(pSystemT->pParticle[i].bAlive)
				break;
		}
		if(i >= pSystemT->iParticles)
		{ // Destroy this system:
   			ParticleManager.DeleteSystem(pSystemT->iID);
			return;
		}
	}
	else
	if(g_lNow > pSystemT->lNextTime*0) // *(f/pSystemT->pActor->fForward)
	{ // The system should be updated:
		if(pSystemT->bRandomDelay)
		{ // Get the time do the next update per random:
			pSystemT->lTimeDelay = rand() % pSystemT->lMaxRandomDelay;
		}
		pSystemT->lLastTime = g_lNow;
		pSystemT->lNextTime = pSystemT->lLastTime+pSystemT->lTimeDelay;
		// 
		i2 = pSystemT->GetFreeParticle();
		if(i2 != -1)
		{
			pParticleT = &pSystemT->pParticle[i2];
			pParticleT->bAlive = TRUE;
			pParticleT->fEngine = 3.0f;
			pParticleT->fColor[0] = 1.0f;
			pParticleT->fColor[1] = 0.5f;
			pParticleT->fColor[2] = 0.5f;
			pParticleT->fFadeSpeed = 0.1f;
			pParticleT->fSize = 2.0f;
			pParticleT->fPos[X] = pActorT->vWorldPos.fX;
			pParticleT->fPos[Y] = pActorT->vWorldPos.fY;
			pParticleT->fPos[Z] = -pActorT->vWorldPos.fZ;
		}
	}

	// Check each particle:
	for(i = 0; i < pSystemT->iParticles; i++)
	{
		pParticleT = &pSystemT->pParticle[i];

		if(!pParticleT->bAlive)
			continue;
		
		// Check the particle:
		pParticleT->fEngine -= (float) pParticleT->fFadeSpeed*g_lDeltatime/10.0f;
		if(pParticleT->fEngine <= 0.0f)
		{ // The particle is now 'death':
			pParticleT->bAlive = FALSE;
			continue;
		}
	}
} // end ASParticleSystemCheck_ShotTrace1()

void ASParticleSystemCheck_Smoke1(AS_PARTICLE_SYSTEM *pSystemT)
{ // begin ASParticleSystemCheck_Smoke1()
	AS_PARTICLE *pParticleT;
	ACTOR *pActorT;
	short i, i2;
	float fTime;

	pSystemT->iVertex = 0;
	
	if(!pSystemT->bActive)
		return;
	pActorT = (ACTOR *) pSystemT->pActor;

	if(!pActorT->bActive || pActorT->bGoingDeath)
		pSystemT->bGoingInActive = TRUE;
	// Check the system:
	if(pSystemT->lLiveEndTime != -1 && g_lNow > pSystemT->lLiveEndTime)
		pSystemT->bGoingInActive = TRUE;
	if(pSystemT->bGoingInActive)
	{
		for(i = 0; i < pSystemT->iParticles; i++)
		{
			if(pSystemT->pParticle[i].bAlive)
				break;
		}
		if(i >= pSystemT->iParticles)
		{ // Destroy this system:
   			ParticleManager.DeleteSystem(pSystemT->iID);
			return;
		}
	}
	else
	if(g_lNow > pSystemT->lNextTime)
	{ // The system should be updated:
		if(pSystemT->bRandomDelay)
		{ // Get the time do the next update per random:
			pSystemT->lTimeDelay = rand() % pSystemT->lMaxRandomDelay;
		}
		pSystemT->lLastTime = g_lNow;
		pSystemT->lNextTime = pSystemT->lLastTime+pSystemT->lTimeDelay;
		// 
		i2 = pSystemT->GetFreeParticle();
		if(i2 != -1)
		{
			pParticleT = &pSystemT->pParticle[i2];
			pParticleT->bAlive = TRUE;
			pParticleT->fEngine = (float) (pSystemT->lLiveEndTime-g_lNow)/(pSystemT->lLiveEndTime-pSystemT->lLiveStartTime)*2;
			pParticleT->fColor[0] = 1.0f;
			pParticleT->fColor[1] = 1.0f;
			pParticleT->fColor[2] = 1.0f;
			pParticleT->fFadeSpeed = 0.01f;
			pParticleT->fSize = 5.0f;
			if(pActorT)
			{ // The smoke is connected with an point of an actor:
				if(pActorT->byType == ACTOR_PLAYER_SHIP)
				{
					pParticleT->fSize = 1.0f;
/*					fPos[X] = pActorT->fWorldPos[X]+0.5f;
					fPos[Y] = pActorT->fWorldPos[Y]+0.5f;
					fPos[Z] = pActorT->fWorldPos[Z]-0.6f;
					if(pActorT->iAniStep < pXeWeaponModel->header.numFrames &&
					   pActorT->iNextAniStep < pXeWeaponModel->header.numFrames )
						ASGetMd2Vertex(pXeWeaponModel, pActorT->iAniStep, pActorT->iNextAniStep, pActorT->fModelInterpolation, fPos, 0.025f,
									   -90.0f, pPlayer->fRot[Y], 0.0f, pSystemT->iVertex, &pParticleT->fPos);
					pParticleT->fVelocity[Z] = -0.5f;*/
				}
			}
			else
			{
				pParticleT->fPos[X] = pSystemT->fStartPos[X];
				pParticleT->fPos[Y] = pSystemT->fStartPos[Y];
				pParticleT->fPos[Z] = pSystemT->fStartPos[Z];
			}
		}
	}

	fTime = (float) g_lDeltatime/1000;
	// Check each particle:
	if(pActorT->byType == ACTOR_PLAYER_SHIP)
	{
		for(i = 0; i < pSystemT->iParticles; i++)
		{
			pParticleT = &pSystemT->pParticle[i];

			if(!pParticleT->bAlive)
				continue;
			
			// Check the particle:
			pParticleT->fEngine -= (float) pParticleT->fFadeSpeed*g_lDeltatime/10.0f;
			if(pParticleT->fEngine <= 0.0f)
			{ // The particle is now 'death':
				pParticleT->bAlive = FALSE;
				continue;
			}
			pParticleT->fSize = 1/pParticleT->fEngine;

			pParticleT->fColor[0] = 1/pParticleT->fSize;
			pParticleT->fColor[1] = 1/pParticleT->fSize;
			pParticleT->fColor[2] = 1/pParticleT->fSize;
			pParticleT->fVelocity[X] += pParticleT->fVelocity[X]*fTime;
			pParticleT->fVelocity[Y] += pParticleT->fVelocity[Y]*fTime;
			pParticleT->fVelocity[Z] += pParticleT->fVelocity[Z]*fTime;
			pParticleT->fPos[X] += pParticleT->fVelocity[X]*fTime;
			pParticleT->fPos[Y] += pParticleT->fVelocity[Y]*fTime;
			pParticleT->fPos[Z] += pParticleT->fVelocity[Z]*fTime;
		}
	}
} // end ASParticleSystemCheck_Smoke1()

void ASParticleSystemCheck_ASLogo(AS_PARTICLE_SYSTEM *pSystemT)
{ // begin ASParticleSystemCheck_ASLogo()
	AS_PARTICLE *pParticleT;
	ACTOR *pActorT;
	float fTime;
	short i, i2;

	if(!pSystemT->bActive)
		return;
	pActorT = (ACTOR *) pSystemT->pActor;

	if(pSystemT->bGoingInActive)
	{
		for(i = 0; i < pSystemT->iParticles; i++)
		{
			if(pSystemT->pParticle[i].bAlive)
				break;
		}
		if(i >= pSystemT->iParticles)
		{ // Destroy this system:
   			pSystemT->bActive = FALSE;
			return;
		}
	}
	fTime = (float) g_lDeltatime/1000;
	// Check each particle:
	for(i = 0; i < pSystemT->iParticles; i++)
	{
		pParticleT = &pSystemT->pParticle[i];

		if(!pParticleT->bAlive)
			continue;
		for(i2 = 0; i2 < 3; i2++)
		{
			if(pParticleT->fPos[i2] > pParticleT->fLastPos[i2])
			{
				pParticleT->fVelocity[i2] -= (float) g_lDeltatime/10000;
				if(!pParticleT->bTemp[i2])
				{
					if(pParticleT->fPos[i2]+pParticleT->fVelocity[i2]*((float) g_lDeltatime/100) 
					  < pParticleT->fLastPos[i2])
					{
						pParticleT->bTemp[i2] = TRUE;
						pParticleT->fVelocity[i2] = 0.0f;
					}
				}
			}
			else
			if(pParticleT->fPos[i2] < pParticleT->fLastPos[i2])
			{
				pParticleT->fVelocity[i2] += (float) g_lDeltatime/10000;
				if(!pParticleT->bTemp[i2])
				{
					if(pParticleT->fPos[i2]+pParticleT->fVelocity[i2]*((float) g_lDeltatime/100) 
					  > pParticleT->fLastPos[i2])
					{
						pParticleT->bTemp[i2] = TRUE;
						pParticleT->fVelocity[i2] = 0.0f;
					}
				}
			}

			if(pParticleT->fVelocity[i2] > 1.5f)
				pParticleT->fVelocity[i2] = 1.5f;
			if(pParticleT->fVelocity[i2] < -1.5f)
				pParticleT->fVelocity[i2] = -1.5f;

			pParticleT->fPos[i2] += pParticleT->fVelocity[i2]*((float) g_lDeltatime/100);

			if((pParticleT->fPos[i2] <= pParticleT->fLastPos[i2]+1.0f &&
			    pParticleT->fPos[i2] >= pParticleT->fLastPos[i2]-1.0f) ||
				pParticleT->fPos[i2] >= pParticleT->fFixPos[i2]+0.3f ||
				pParticleT->fPos[i2] <= pParticleT->fFixPos[i2]-0.3f)
			{
				if(pParticleT->fLastPos[i2] != pParticleT->fFixPos[i2] && !pSystemT->bGoingInActive)
					pParticleT->fVelocity[i2] *= 0.2f;
				if((pParticleT->fPos[i2] > pParticleT->fFixPos[i2]+0.3f ||
				    pParticleT->fPos[i2] < pParticleT->fFixPos[i2]-0.3f) &&
					!pSystemT->bGoingInActive)
				   pParticleT->fLastPos[i2] = pParticleT->fFixPos[i2];
				else
				{
					if(!(rand() % 2))
						pParticleT->fLastPos[i2] += (float) 10+(rand() % 1000)/100;
					else
						pParticleT->fLastPos[i2] -= (float) 10+(rand() % 1000)/100;
				}
			}
			if(!pSystemT->bGoingInActive)
			{
				if(pParticleT->fEngine != 1.0f)
				{
					pParticleT->fEngine += (float) g_lDeltatime/10000;
					if(pParticleT->fEngine > 1.0f)
						pParticleT->fEngine = 1.0f;
				}
			}
			else
			{
				pParticleT->fEngine -= (float) g_lDeltatime/20000;
				if(pParticleT->fEngine < 0.0f)
					pParticleT->bAlive = FALSE;
			}
			if(!pParticleT->bTemp[0])
			{
				pParticleT->fSize += (float) g_lDeltatime/1000;
				if(pParticleT->fSize > 11.0f)
					pParticleT->bTemp[0] = TRUE;
			}
			else
			{
				pParticleT->fSize -= (float) g_lDeltatime/1000;
				if(pParticleT->fSize < 3.0f)
					pParticleT->bTemp[0] = FALSE;
			}
		}
	}
} // end ASParticleSystemCheck_ASLogo()

void ASParticleSystemCheck_Engine(AS_PARTICLE_SYSTEM *pSystemT)
{ // begin ASParticleSystemCheck_Engine()
	AS_PARTICLE *pParticleT;
	short i;
	float fTime;

	if(!pSystemT->bActive)
		return;
	// Check the system:
	fTime = (float) g_lDeltatime/1000;
	// Check each particle:
	for(i = 0; i < pSystemT->iParticles; i++)
	{
		pParticleT = &pSystemT->pParticle[i];
		if(!pParticleT->bAlive)
			continue;
		// Check the particle:
		pParticleT->fEngine -= (float) pParticleT->fFadeSpeed*g_lDeltatime/10.0f;
		if(pParticleT->fEngine <= 0.0f)
		{ // The particle is now 'death':
			pParticleT->bAlive = FALSE;
			continue;
		}
		pParticleT->fSize += (float) g_lDeltatime/(pParticleT->fFadeSpeed*500);

		pParticleT->fColor[0] -= (float) g_lDeltatime/(pParticleT->fFadeSpeed*100000);
		pParticleT->fColor[1] -= (float) g_lDeltatime/(pParticleT->fFadeSpeed*100000);
		pParticleT->fColor[2] -= (float) g_lDeltatime/(pParticleT->fFadeSpeed*100000);
/*		pParticleT->fVelocity[X] += pParticleT->fVelocity[X]*fTime;
		pParticleT->fVelocity[Y] += pParticleT->fVelocity[Y]*fTime;
		pParticleT->fVelocity[Z] += pParticleT->fVelocity[Z]*fTime;*/
		pParticleT->fPos[X] += pParticleT->fVelocity[X]*fTime;
		pParticleT->fPos[Y] += pParticleT->fVelocity[Y]*fTime;
		pParticleT->fPos[Z] += pParticleT->fVelocity[Z]*fTime;
	}
} // end ASParticleSystemCheck_Engine()

void ASParticleSystemCheck_Crosshair(AS_PARTICLE_SYSTEM *pSystemT)
{ // begin ASParticleSystemCheck_Crosshair()
} // end ASParticleSystemCheck_Crosshair()

void ASParticleSystemCheck_Ablaze(AS_PARTICLE_SYSTEM *pSystemT)
{ // begin ASParticleSystemCheck_Ablaze()
	AS_PARTICLE *pParticleT;
	short i, i2;
	float fTime;

/*	if(!ASCubeInFrustum(Environment.fAblazeBox[MIN][X], Environment.fAblazeBox[MIN][Y], Environment.fAblazeBox[MIN][Z],
						Environment.fAblazeBox[MAX][X], Environment.fAblazeBox[MAX][Z], Environment.fAblazeBox[MAX][Z]))
		return; // The ablaze is not visible!*/
	if(!pSystemT->bActive)
		return;

	// Check the system:
	if(pSystemT->bGoingInActive)
	{
		for(i = 0; i < pSystemT->iParticles; i++)
		{
			if(pSystemT->pParticle[i].bAlive)
				break;
		}
		if(i >= pSystemT->iParticles)
		{
			pSystemT->bActive = FALSE;
			pSystemT->bGoingInActive = FALSE;
			return;
		}
	}

	fTime = (float) g_lDeltatime/1000;
	// Check each particle:
	for(i = 0; i < pSystemT->iParticles; i++)
	{
		pParticleT = &pSystemT->pParticle[i];

		if(!pParticleT->bAlive)
			continue;
		
		for(i2 = 0; i2 < 3; i2++)
		{
			if(pParticleT->bTemp[0])
			{
				if(pParticleT->fPos[i2] > pParticleT->fLastPos[i2])
					pParticleT->fVelocity[i2] -= (float) g_lDeltatime/10;
				else
				if(pParticleT->fPos[i2] < pParticleT->fLastPos[i2])
					pParticleT->fVelocity[i2] += (float) g_lDeltatime/10;
				if(pParticleT->fVelocity[i2] > 50.0f)
					pParticleT->fVelocity[i2] = 50.0f;
				if(pParticleT->fVelocity[i2] < -50.0f)
					pParticleT->fVelocity[i2] = -50.0f;
			}
			else
			{
				if(pParticleT->fPos[i2] > pParticleT->fLastPos[i2])
					pParticleT->fVelocity[i2] -= (float) g_lDeltatime;
				else
				if(pParticleT->fPos[i2] < pParticleT->fLastPos[i2])
					pParticleT->fVelocity[i2] += (float) g_lDeltatime;
				if(pParticleT->fVelocity[i2] > 400.0f)
					pParticleT->fVelocity[i2] = 400.0f;
				if(pParticleT->fVelocity[i2] < -400.0f)
					pParticleT->fVelocity[i2] = -400.0f;
			}

			pParticleT->fPos[i2] += pParticleT->fVelocity[i2]*((float) g_lDeltatime/10000);

			if(pParticleT->bTemp[0])
			{
				if((pParticleT->fPos[i2] <= pParticleT->fLastPos[i2]+0.1f &&
					pParticleT->fPos[i2] >= pParticleT->fLastPos[i2]-0.1f) ||
					pParticleT->fPos[i2] >= pParticleT->fFixPos[i2]+6.0f ||
					pParticleT->fPos[i2] <= pParticleT->fFixPos[i2]-6.0)
				{
					if(pParticleT->fLastPos[i2] != pParticleT->fFixPos[i2] && !pSystemT->bGoingInActive)
						pParticleT->fVelocity[i2] *= 0.2f;
					if(pParticleT->fPos[i2] > pParticleT->fFixPos[i2]+1.0f ||
						pParticleT->fPos[i2] < pParticleT->fFixPos[i2]-1.0f)
					   pParticleT->fLastPos[i2] = pParticleT->fFixPos[i2];
					else
					{
						if(!(rand() % 2))
							pParticleT->fLastPos[i2] += (float) 10+(rand() % 100)/100;
						else
							pParticleT->fLastPos[i2] -= (float) 10+(rand() % 100)/100;
					}
				}
			}
			else
			{
				if((pParticleT->fPos[i2] <= pParticleT->fLastPos[i2]+0.1f &&
					pParticleT->fPos[i2] >= pParticleT->fLastPos[i2]-0.1f) ||
					pParticleT->fPos[i2] >= pParticleT->fFixPos[i2]+10.0f ||
					pParticleT->fPos[i2] <= pParticleT->fFixPos[i2]-10.0)
				{
					if(pParticleT->fLastPos[i2] != pParticleT->fFixPos[i2] && !pSystemT->bGoingInActive)
						pParticleT->fVelocity[i2] *= 0.5f;
					if(pParticleT->fPos[i2] > pParticleT->fFixPos[i2]+1.0f ||
						pParticleT->fPos[i2] < pParticleT->fFixPos[i2]-1.0f)
					   pParticleT->fLastPos[i2] = pParticleT->fFixPos[i2];
					else
					{
						if(!(rand() % 2))
							pParticleT->fLastPos[i2] += (float) 10+(rand() % 100)/10;
						else
							pParticleT->fLastPos[i2] -= (float) 10+(rand() % 100)/10;
					}
				}
			}
		}
	}
} // end ASParticleSystemCheck_Ablaze()
//-----------------------------------------------------------------------------
// File: AS_ProcessWindow.h
//-----------------------------------------------------------------------------

#ifndef __AS_PROGRESS_WINDOW_H__
#define __AS_PROGRESS_WINDOW_H__


// Classes: *******************************************************************
class AS_PROGRESS_WINDOW
{
	public:
		static void SetTask(PSTR, ...);
		static void SetSubTask(PSTR, ...);
		bool CreateProgressWindow(PSTR);
		AS_PROGRESS_WINDOW();
		virtual ~AS_PROGRESS_WINDOW();
		
		inline static void SetProgress(unsigned int iProgress)
		{ // Set the progress of the progress bar:
			if(m_hWndProgressBar)
				SendMessage(m_hWndProgressBar, PBM_SETPOS, iProgress, 0);
		}

	protected:
		HWND m_hWndProgress;
		static HWND m_hWndProgressBar;
		static HWND m_hWndStatic, m_hWndStatic2;

		// Dummy window procedure
		static friend LRESULT CALLBACK ProgressWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
			{   return DefWindowProc(hWnd, message, wParam, lParam);	}
};
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_PROGRESS_WINDOW_H__
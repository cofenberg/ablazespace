//-----------------------------------------------------------------------------
// File: AS_Particle.h
//-----------------------------------------------------------------------------

#ifndef __AS_PARTICLE_H__
#define __AS_PARTICLE_H__


// Definitions: ***************************************************************
// The types of particle systems
enum AS_PARTICLE_SYSTEM_TYPE
{
	PS_Md2Trace = 0, // A trace of a md2 model
	PS_ShotTrace1, // A shot trace
	PS_Smoke1, // Smoke
	PS_Smoke2, // Smoke
	PS_ASLogo, // AS logo
	PS_Engine, // Engine
	PS_Crosshair, // The players crosshair
	PS_Ablaze, // The ablaze effect
};
///////////////////////////////////////////////////////////////////////////////

// Structures: ****************************************************************
typedef class AS_PARTICLE
{
	private:

	public:
		BOOL bAlive; // Is this particle active?
		float fEngine; // The engine (equal to the live time)
		float fFadeSpeed; // The fade speed
		float fColor[3]; // The color of this particle
		float fFixPos[3]; // The fix positon in the space (e.g. used for particle images)
		float fPos[3]; // The positon in the space
		float fLastPos[3]; // The last positon
		float fVelocity[3]; // The velocity
		float fSize; // The size of the particle
		BOOL bTemp[3]; // For different stuff...

} AS_PARTICLE;

typedef class AS_PARTICLE_SYSTEM
{
	private:

	public:
		short iID; // The systems ID in the manager
		AS_PARTICLE_SYSTEM_TYPE Type; // The type of this particle system
		AS_TEXTURE *pTexture; // A pointer to the particle texture
		
		BOOL bActive; // Is the particle system active?
		BOOL bGoingInActive; // Should the system been going inactive?
		BOOL bUpdate;
		BOOL bChecked;

		short iMaxParticles; // The maximum number of particles
		short iParticles; // The number of particles (scaled by the configuration)
		AS_PARTICLE *pParticle; // The particles

		BOOL bRandomDelay; // Is the delay is created my random?
		long lMaxRandomDelay; // The greatest random delay
		long lTimeDelay; // How long should be waited to the next update?
		long lLastTime; // The last time were the system was updated (the particle emission)
		long lNextTime; // The next time were the system should be updated (the particle emission)
		
		long lLiveStartTime; // The time were the system came into live
		long lLiveEndTime; // The time were the system live should be end (-1 = no live time limit)
		
		FLOAT3 fStartPos; // The start position of this particle system:
		short iVertex; // A vertex of a model the particle system is connected with
		 

		void *pActor; // A pointer to the actor, if the system is connected with it


		void (*Check)(AS_PARTICLE_SYSTEM *);
		void (*Draw)(AS_PARTICLE_SYSTEM *);

		void CreateMd2Vertices(AS_MD2_MODEL *, int, int, float, FLOAT3, FLOAT3, float);
		short GetFreeParticle(void);

} AS_PARTICLE_SYSTEM;

typedef class AS_PARTICLE_MANAGER
{
	private:

	public:
		short iSystems; // The number of particle systems:
		AS_PARTICLE_SYSTEM *pSystem; // The particle systems

		void Check(void);
		void Draw(void);

		short AddNewSystem(AS_PARTICLE_SYSTEM_TYPE, short, void *, AS_TEXTURE *, AS_TEXTURE *);
		void DeleteSystem(short);
		void Destroy(void);
		void UpdateSystems(void);

} AS_PARTICLE_MANAGER;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_PARTICLE__
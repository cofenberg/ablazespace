//-----------------------------------------------------------------------------
// File: AS_Engine.h
//-----------------------------------------------------------------------------

#ifndef __AS_ENGINE_H__
#define __AS_ENGINE_H__


// Definitions: ***************************************************************
#define AS_WINDOW_NAME "AS-Engine"
enum {MODULE_GAME, MODULE_EDITOR};
#define AS_GAME_INFO_FILE "Game.ini"
#define AS_LOG_FILE "Log.html"
#define GAME_NAME "Subscape"
#define GAME_VERSION "V0.1"
#define GAME_WINDOW_NAME "Subscape"
#define MD2_FILE "Model files (*.md2)\0*.md2\0"
#define JPG_FILE "JPG files (*.jpg)\0*.jpg\0"
#define MUSIC_FILES \
		TEXT("Audio files (*.wav; *.mpa; *.mp2; *.mp3; *.au; *.aif; *.aiff; *.snd)\0*.wav; *.mpa; *.mp2; *.mp3; *.au; *.aif; *.aiff; *.snd\0")\
		TEXT("MIDI Files (*.mid, *.midi, *.rmi)\0*.mid; *.midi; *.rmi\0") \
		TEXT("All Files (*.*)\0*.*;\0\0")
///////////////////////////////////////////////////////////////////////////////

// Includes: ******************************************************************
#include "AS_BibIncludes.h"
#include "..\Resource.h"
#include "AS_FrustumCulling.h"
#include "AS_ProgressWindow.h"
#include "AS_Window.h"
#include "AS_OpenGL.h"
#include "AS_Config.h"
#include "AS_Language.h"
#include "DMUtil.h"
#include "DXUtil.h"
#include "DSUtil.h"
#include "AS.h"
#include "AS_MD2.h"
// DirectX stuff:
#include "AS_DXInput.h"
#include "AS_DXSound.h"
#include "AS_DXAudio.h"
#include "AS_DXShow.h"
// Math stuff:
#include "AS_Math.h"
#include "AS_Vector.h"
#include "AS_Matrix.h"
#include "AS_Quaternion.h"
// Other stuff:
#include "AS_Camera.h"
#include "AS_Collision.h"
#include "AS_Particle.h"
#include "..\ModuleHeaders.h"
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_ENGINE__
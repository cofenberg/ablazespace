//-----------------------------------------------------------------------------
// File: AS_Math.h
//-----------------------------------------------------------------------------

#ifndef __AS_MATH_H__
#define __AS_MATH_H__


// Definitions: ***************************************************************
#define AS_EPSILON 1e-12
//#define EPSILON 0.05f
#define PLANE_BACKSIDE 0x000001
#define PLANE_FRONT    0x000010
#define ON_PLANE       0x000100
#define PI            3.14159265358979
#define PId2          1.5707963279489
#define DEG_TO_RAD 0.0174532925199432957692369076848861
#define RAD_TO_DEG 57.29577951

typedef float MATRIX[4][4];
#define M_4x4_TO_16(Row, Col) fM[Row*4+Col]

#define LIMIT_RANGE(low, value, high)	{	if (value < low)	value = low;	else if(value > high)	value = high;	}

#define SubtVer(AB, a, b)\
	((AB)[X] = (b)[X]-(a)[X],\
     (AB)[Y] = (b)[Y]-(a)[Y],\
     (AB)[Z] = (b)[Z]-(a)[Z])
#define CrossProductVer(AB, a, b)\
	((AB)[X] = (a)[Y]*(b)[Z]-(a)[Z]*(b)[Y],\
     (AB)[Y] = (a)[Z]*(b)[X]-(a)[X]*(b)[Z],\
     (AB)[Z] = (a)[X]*(b)[Y]-(a)[Y]*(b)[X])
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern void NormalizeFace(FLOAT3 *, FLOAT3, FLOAT3, FLOAT3);
extern void ASAddVec(FLOAT3, FLOAT3, FLOAT3 *);
extern void ASSubVec(FLOAT3, FLOAT3, FLOAT3 *);
extern void ASMulVec(FLOAT3, FLOAT3, FLOAT3 *);
extern void ASScaleVec(FLOAT3, float, FLOAT3 *);
extern void ASInvertVec(FLOAT3, FLOAT3 *);
extern void ASRotateVectorX(FLOAT3, float, FLOAT3 *);
extern void ASRotateVectorY(FLOAT3, float, FLOAT3 *);
extern void ASRotateVectorZ(FLOAT3, float, FLOAT3 *);
extern void ASNormalize(FLOAT3 *);
extern void ASVectMult(FLOAT3, FLOAT3, FLOAT3 *);
extern void ASCatmullRom(FLOAT3 [4], float, FLOAT3 *);
extern void ASRotateAroundLine(FLOAT3, FLOAT3, FLOAT3, float, FLOAT3 *);
extern void ASMultVecMatrix(FLOAT3, float [16], FLOAT3 *);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_MATH_H__
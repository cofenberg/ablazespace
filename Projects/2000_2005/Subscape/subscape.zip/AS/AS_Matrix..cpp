//-----------------------------------------------------------------------------
// File: AS_Matrix.cpp
//-----------------------------------------------------------------------------

#include "AS_Engine.h"


AS_MATRIX AS_MATRIX::Invert(void)
{ // begin AS_MATRIX::Invert()
    AS_MATRIX MT;
    
	MT.fXX = fXX;
    MT.fXY = fYX;
    MT.fXZ = fZX;
    MT.fYX = fXY;
    MT.fYY = fYY;
    MT.fYZ = fZY;
    MT.fZX = fXZ;
    MT.fZY = fYZ;
    MT.fZZ = fZZ;
  
    // The new displacement vector is given by:  d' = -(R^-1) * d
    MT.fWX = -(fWX*MT.fXX + fWY*MT.fYX + fWZ*MT.fZX);
    MT.fWY = -(fWX*MT.fXY + fWY*MT.fYY + fWZ*MT.fZY);
    MT.fWZ = -(fWX*MT.fXZ + fWY*MT.fYZ + fWZ*MT.fZZ);
  
    // The rest stays the same
    MT.fXW = MT.fYW = MT.fZW = 0.0; 
    MT.fWW = 1.0;

    return MT;
} // end AS_MATRIX::Invert()

AS_3D_VECTOR AS_MATRIX::Transform(const AS_3D_VECTOR V)
{ // begin AS_MATRIX::Transform()
    float fW = V.fX*fWX + V.fY*fWY + V.fZ*fWZ + fWW;
    return AS_3D_VECTOR((V.fX*fXX + V.fY*fXY + V.fZ*fXZ+fXW)/fW,
					    (V.fX*fYX + V.fY*fYY + V.fZ*fYZ+fYW)/fW,
					    (V.fX*fZX + V.fY*fZY + V.fZ*fZZ+fZW)/fW);
} // end AS_MATRIX::Transform()

void AS_MATRIX::GetEulerAngles(float &fX, float &fY, float &fZ)
{ // begin AS_MATRIX::GetEulerAngles() 
	double dAngleX, dAngleY, dAngleZ;

	dAngleY = atan2(fZX, sqrt(fZY*fZY+fZZ*fZZ));
	double dCosangleY = cos(dAngleY);

	if(fabs(dCosangleY) > AS_EPSILON)
	{
		dAngleZ = atan2(-fYX/dCosangleY, fXX/dCosangleY);
		dAngleX = atan2(-fZY/dCosangleY, fZZ/dCosangleY);
	}
	else
	{
		if(fabs(PId2-dAngleY) < AS_EPSILON)
		{
			dAngleX = atan2(fXY , fYY);
			dAngleY = PId2;
			dAngleZ = 0.0;
		}
		else
		{
			dAngleX = atan2(-fXY , fYY);
			dAngleY = -PId2;
			dAngleZ = 0.0;
		}
	}

	// We set the result:
	fX = (float) (-dAngleX*RAD_TO_DEG);
	fY = (float) (-dAngleY*RAD_TO_DEG);
	fZ = (float) (-dAngleZ*RAD_TO_DEG);
} // end AS_MATRIX::GetEulerAngles()

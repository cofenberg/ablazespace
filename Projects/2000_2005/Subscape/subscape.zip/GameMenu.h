//-----------------------------------------------------------------------------
// File: GameMenu.h
//-----------------------------------------------------------------------------

#ifndef __GAME_MENU_H__
#define __GAME_MENU_H__


// Definitions: ***************************************************************
#define GAME_MENU_TEXTURES 1
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern BOOL bInGameMenu, bShowGameMenu, bPause;
extern AS_TEXTURE GameMenuTexture[GAME_MENU_TEXTURES];
extern char byGameMenuSelected, byGameMenuMenu, byLastGameMenuMenu;
extern float fGameMenuBlend;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern HRESULT GameMenuLoop(void);
extern void StartMenuMusic(void);
extern HRESULT GameMenuDraw(AS_WINDOW *);
extern HRESULT GameMenuCheck(AS_WINDOW *);
extern void DrawOptionsText(short, short, char *);
extern void DrawKeysSetupText(short, short, char *, char *);
extern void ShowGameMenu(AS_WINDOW *);
extern void CheckGameMenu(void);
extern void CheckGameMenuPerspective(void);
extern void SetGameMenuPerspective(void);
///////////////////////////////////////////////////////////////////////////////


#endif // __GAME_MENU_H__
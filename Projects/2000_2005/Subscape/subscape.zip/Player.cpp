//-----------------------------------------------------------------------------
// File: Player.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
PLAYER Player;
// Player shield bounding spheres:
FLOAT4 fPlayerPosR[8] = 
				{ {220.644f, -83.6207f, -150.391f, 10.0f}, // Left front:
				  {59.5186f, -68.3327f, -163.254f, 20.0f}, // Left front2:
				  {220.644f, -83.6207f, 150.6207f, 10.0f}, // Right front:
				  {59.5186f, -68.3327f, 150.391f, 20.0f}, // Right front2:
				  {50.1659f, -48.2813f, -13.9933f, 20.0f}, // Pilot part:
				  {-226.307f, -21.6869f, -1.55478f, 35.0f}, // Middle part:
				  {-322.686f, -113.6207f, -276.118f, 20.0f}, // Left wing:
				  {-322.686f, -113.6207f, 276.55478f, 20.0f}, // Right wing:
				};
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
void SetupPlayerLight(int, int, FLOAT3);
void SetupPlayerLights(void);
void PlayerControl(void);
void DrawPlayerSolid(void);
void DrawPlayerTransparent(void);
void InitPlayer(void);
void CheckPlayer(void);
BOOL CheckPlayerCollision(void);
void CheckBallCollision(ACTOR *, ACTOR *, AS_3D_VECTOR);
///////////////////////////////////////////////////////////////////////////////


void SetupPlayerLight(int iEngine, int iVertex, FLOAT3 fPos2)
{ // begin SetupPlayerLight()
	float fLightData[4]  = {0.0f, 0.0f, 0.0f, 0.0f};
	float fPower;
	FLOAT3 fPos;

	if(_AS->iActiveLights+1 >= _AS->iMaxLights)
		return;
	fPower = Player.ShipEngine[iEngine].fActualPower*Player.ShipEngine[iEngine].fPower;
	if(fPower)
	{
		ASGetMd2Vertex(pPlayerShipHull, 0, fPos2, 1.0f,
					   0.0f, 0.0f,  0.0f, iVertex, &fPos);
		fLightData[0] = fPos[X];
		fLightData[1] = fPos[Y];
		fLightData[2] = fPos[Z];
		fLightData[3] = 0.0f;
		glLightfv(GL_LIGHT0+_AS->iActiveLights, GL_POSITION, fLightData);
		fLightData[0] = fPower;
		fLightData[1] = fPower*0.5f;
		fLightData[2] = fPower;
		fLightData[3] = 0.5f;
		glLightfv(GL_LIGHT0+_AS->iActiveLights, GL_DIFFUSE, fLightData);
		glEnable(GL_LIGHT0+_AS->iActiveLights); 
		_AS->iActiveLights++;
	}
} // end SetupPlayerLight()

void SetupPlayerLights(void)
{ // begin SetupPlayerLights()
	float fLightData[4]  = {0.0f, 0.0f, 0.0f, 0.0f};
	ACTOR *pPlayer = &Player.Actor;
	FLOAT3 fPos, fPos2;
	float fPower;

	fPos2[X] = pPlayer->vWorldPos.fX;
	fPos2[Y] = pPlayer->vWorldPos.fY;
	fPos2[Z] = pPlayer->vWorldPos.fZ;
	glPushMatrix();
	pPlayer->Apply();

	// Main engine:
	if(_AS->iActiveLights+1 < _AS->iMaxLights)
	{
		if(!Player.fAfterburnerPower)
			fPower = Player.ShipEngine[MAIN_SHIP_ENGINE].fPower;
		else
			fPower = Player.ShipEngine[MAIN_SHIP_ENGINE].fActualPower*Player.ShipEngine[MAIN_SHIP_ENGINE].fPower;
		if(fPower)
		{
			ASGetMd2Vertex(pPlayerShipHull, 0, fPos2, 1.0f,
						   0.0f, 0.0f,  0.0f, 386, &fPos);
			fLightData[0] = fPos[X];
			fLightData[1] = fPos[Y];
			fLightData[2] = fPos[Z];
			fLightData[3] = 0.0f;
			glLightfv(GL_LIGHT0+_AS->iActiveLights, GL_POSITION, fLightData);
			fLightData[0] = fPower*(0.5f*Player.fAfterburnerPower);
			fLightData[1] = fPower*0.5f;
			fLightData[2] = fPower;
			fLightData[3] = 1.0f;
			glLightfv(GL_LIGHT0+_AS->iActiveLights, GL_DIFFUSE, fLightData);
			glEnable(GL_LIGHT0+_AS->iActiveLights);
			_AS->iActiveLights++;
		}
	}

	SetupPlayerLight(RIGHT_SHIP_ENGINE, 175, fPos2);
	SetupPlayerLight(LEFT_SHIP_ENGINE, 186, fPos2);
	SetupPlayerLight(RIGHT_BOTTOM_SHIP_ENGINE, 230, fPos2);
	SetupPlayerLight(LEFT_BOTTOM_SHIP_ENGINE, 232, fPos2);
	SetupPlayerLight(BACKWARD_SHIP_ENGINE, 201, fPos2);
	SetupPlayerLight(TOP_SHIP_ENGINE, 167, fPos2);
	SetupPlayerLight(BOTTOM_SHIP_ENGINE, 196, fPos2);
	SetupPlayerLight(TOP_FRONT_SHIP_ENGINE, 373, fPos2);
	SetupPlayerLight(BOTTOM_FRONT_SHIP_ENGINE, 375, fPos2);

	glPopMatrix();
} // end SetupPlayerLights()

void PlayerControl(void)
{ // begin PlayerControl()
	float fSpeed1000 = (float) g_lDeltatime/1000.0f,
		  fSpeed500 = (float) g_lDeltatime/500.0f,
		  fSpeed200 = (float) g_lDeltatime/200.0f,
		  fSpeed100 = (float) g_lDeltatime/100.0f,
		  fSpeed10 = (float) g_lDeltatime/10.0f;
	float fXAcceleration, fYAcceleration;
	ACTOR *pPlayer = &Player.Actor, *pActor;
	static long lCameraTimer;
	static long lFullStopTimer;
	int i;
	FLOAT3 fPos, fPos2, fTempV;
	float m[16];
	
	// Set standart camera view: 
	if(CHECK_KEY(ASKeys, _ASConfig->iStandartViewKey[0]))
	{
		_ASCamera->SetStandartCamera();
		InitGameParticleSystems();
	}


	if(CHECK_KEY(ASKeys, _ASConfig->iLevelRestartKey[0]))
	{
		InitPlayer();
		_ASCamera->SetStandartCamera();
	}

	if(CHECK_KEY(ASKeys, DIK_RETURN))
	{
		pPlayer->fDamage += (float) g_lDeltatime/1000;
		if(pPlayer->fDamage > 1.0f)
			pPlayer->fDamage = 1.0f;
	}
	if(CHECK_KEY(ASKeys, DIK_BACKSPACE))
	{
		pPlayer->fDamage -= (float) g_lDeltatime/1000;
		if(pPlayer->fDamage < 0.0f)
			pPlayer->fDamage = 0.0f;
	}

	// Afterburner:
	if(CHECK_KEY(ASKeys, _ASConfig->iAfterburnerKey[0]) && !Player.fAfterburnerRegeneration)
	{
		pCamera->fZ -= fSpeed1000;
		pPlayer->fForward += fSpeed10*2;
	 	Player.fAfterburnerPower += fSpeed1000;
		if(Player.fAfterburnerPower > 1.0f)
			Player.fAfterburnerPower = 1.0f;
		Player.ShipEngine[MAIN_SHIP_ENGINE].fPower += fSpeed500;
		if(Player.ShipEngine[MAIN_SHIP_ENGINE].fPower > 1.0f)
			Player.ShipEngine[MAIN_SHIP_ENGINE].fPower = 1.0f;
		Player.fAfterburnerEngine -= Player.fAfterburnerEngineDecreaseSpeed*fSpeed10/5;
		if(Player.fAfterburnerEngine < 0.0f)
		{
			Player.fAfterburnerEngine = 0.0f;
			Player.fAfterburnerRegeneration = TRUE;
		}
	}
	else
	{
		Player.fAfterburnerPower -= fSpeed1000;
		if(Player.fAfterburnerPower < 0.0f)
			Player.fAfterburnerPower = 0.0f;
		Player.fAfterburnerEngine += Player.fAfterburnerEngineRegenerationSpeed*fSpeed10/5;
		if(Player.fAfterburnerEngine >= 20.0f)
			Player.fAfterburnerRegeneration = FALSE;
		if(Player.fAfterburnerEngine > Player.fMaxAfterburnerEngine)
			Player.fAfterburnerEngine = Player.fMaxAfterburnerEngine;
	}
	pPlayer->fCurrentMaxVelocity = pPlayer->fNormalMaxVelocity+((pPlayer->fMaxVelocity-pPlayer->fNormalMaxVelocity)*Player.fAfterburnerPower);
	// Forward:
	if(CHECK_KEY(ASKeys, _ASConfig->iForwardKey[0]) || CHECK_KEY(ASKeys, _ASConfig->iAfterburnerKey[0]))
	{
		pCamera->fZ -= fSpeed1000;
		pPlayer->fForward += fSpeed100*4;
		Player.ShipEngine[MAIN_SHIP_ENGINE].fPower += fSpeed500;
		if(Player.ShipEngine[MAIN_SHIP_ENGINE].fPower > 1.0f)
			Player.ShipEngine[MAIN_SHIP_ENGINE].fPower = 1.0f;
	}
	else
	{
		Player.ShipEngine[MAIN_SHIP_ENGINE].fPower -= fSpeed500;
		if(Player.ShipEngine[MAIN_SHIP_ENGINE].fPower < 0.0f)
			Player.ShipEngine[MAIN_SHIP_ENGINE].fPower = 0.0f;
	}
	pPlayer->fForward *= Player.ShipEngine[MAIN_SHIP_ENGINE].fPower;
	// Backward
	if(CHECK_KEY(ASKeys, _ASConfig->iBackwardKey[0]))
	{
		pCamera->fZ += fSpeed500;
		pPlayer->fBackward -= fSpeed100*4;
		Player.ShipEngine[BACKWARD_SHIP_ENGINE].fPower += fSpeed500;
		if(Player.ShipEngine[BACKWARD_SHIP_ENGINE].fPower > 1.0f)
			Player.ShipEngine[BACKWARD_SHIP_ENGINE].fPower = 1.0f;
	}
	else
	{
		Player.ShipEngine[BACKWARD_SHIP_ENGINE].fPower -= fSpeed500;
		if(Player.ShipEngine[BACKWARD_SHIP_ENGINE].fPower < 0.0f)
			Player.ShipEngine[BACKWARD_SHIP_ENGINE].fPower = 0.0f;
	}
	pPlayer->fBackward *= Player.ShipEngine[BACKWARD_SHIP_ENGINE].fPower;
	// Slide left:  		
	if(CHECK_KEY(ASKeys, _ASConfig->iLeftKey[0]) && CHECK_KEY(ASKeys, 157))
	{
		pPlayer->fSlideLRVelocity += fSpeed100;
		pCamera->fRot2[Y] -= fSpeed100;
		Player.ShipEngine[RIGHT_BOTTOM_SHIP_ENGINE].fPower += fSpeed500;
		if(Player.ShipEngine[RIGHT_BOTTOM_SHIP_ENGINE].fPower > 1.0f)
			Player.ShipEngine[RIGHT_BOTTOM_SHIP_ENGINE].fPower = 1.0f;
	}
	else
	{
		Player.ShipEngine[RIGHT_BOTTOM_SHIP_ENGINE].fPower -= fSpeed500;
		if(Player.ShipEngine[RIGHT_BOTTOM_SHIP_ENGINE].fPower < 0.0f)
			Player.ShipEngine[RIGHT_BOTTOM_SHIP_ENGINE].fPower = 0.0f;
	}
	// Slide up:
	if(CHECK_KEY(ASKeys, _ASConfig->iUpKey[0]) && CHECK_KEY(ASKeys, 157))
	{
		pPlayer->fSlideUDVelocity += fSpeed100;
		pCamera->fRot2[X] -= fSpeed100;
		Player.ShipEngine[BOTTOM_SHIP_ENGINE].fPower += fSpeed500;
		if(Player.ShipEngine[BOTTOM_SHIP_ENGINE].fPower > 1.0f)
			Player.ShipEngine[BOTTOM_SHIP_ENGINE].fPower = 1.0f;
	}
	else
	{
		Player.ShipEngine[BOTTOM_SHIP_ENGINE].fPower -= fSpeed500;
		if(Player.ShipEngine[BOTTOM_SHIP_ENGINE].fPower < 0.0f)
			Player.ShipEngine[BOTTOM_SHIP_ENGINE].fPower = 0.0f;
	}
	// Slide right:
	if(CHECK_KEY(ASKeys, _ASConfig->iRightKey[0]) && CHECK_KEY(ASKeys, 157))
	{
		pPlayer->fSlideLRVelocity -= fSpeed100;
		pCamera->fRot2[Y] += fSpeed100;
		Player.ShipEngine[LEFT_BOTTOM_SHIP_ENGINE].fPower += fSpeed500;
		if(Player.ShipEngine[LEFT_BOTTOM_SHIP_ENGINE].fPower > 1.0f)
			Player.ShipEngine[LEFT_BOTTOM_SHIP_ENGINE].fPower = 1.0f;
	}
	else
	{
		Player.ShipEngine[LEFT_BOTTOM_SHIP_ENGINE].fPower -= fSpeed500;
		if(Player.ShipEngine[LEFT_BOTTOM_SHIP_ENGINE].fPower < 0.0f)
			Player.ShipEngine[LEFT_BOTTOM_SHIP_ENGINE].fPower = 0.0f;
	}
	// Slide down:
	if(CHECK_KEY(ASKeys, _ASConfig->iDownKey[0]) && CHECK_KEY(ASKeys, 157))
	{
		pPlayer->fSlideUDVelocity -= fSpeed100;
		pCamera->fRot2[X] += fSpeed100;
		Player.ShipEngine[TOP_SHIP_ENGINE].fPower += fSpeed500;
		if(Player.ShipEngine[TOP_SHIP_ENGINE].fPower > 1.0f)
			Player.ShipEngine[TOP_SHIP_ENGINE].fPower = 1.0f;
	}
	else
	{
		Player.ShipEngine[TOP_SHIP_ENGINE].fPower -= fSpeed500;
		if(Player.ShipEngine[TOP_SHIP_ENGINE].fPower < 0.0f)
			Player.ShipEngine[TOP_SHIP_ENGINE].fPower = 0.0f;
	}
	// Turn left:
	if(CHECK_KEY(ASKeys, _ASConfig->iLeftKey[0]) && !CHECK_KEY(ASKeys, 157))
	{
		pCamera->fRot2[Y] += fSpeed100;
		pPlayer->vRotVelocity.fHeading += fSpeed200;
		Player.ShipEngine[RIGHT_SHIP_ENGINE].fPower += fSpeed500;
		if(Player.ShipEngine[RIGHT_SHIP_ENGINE].fPower > 1.0f)
			Player.ShipEngine[RIGHT_SHIP_ENGINE].fPower = 1.0f;
	}
	else
	{
		Player.ShipEngine[RIGHT_SHIP_ENGINE].fPower -= fSpeed500;
		if(Player.ShipEngine[RIGHT_SHIP_ENGINE].fPower < 0.0f)
			Player.ShipEngine[RIGHT_SHIP_ENGINE].fPower = 0.0f;
	}
	// Turn up:
	if(CHECK_KEY(ASKeys, _ASConfig->iUpKey[0]) && !CHECK_KEY(ASKeys, 157))
	{
		pCamera->fRot2[X] += fSpeed100;
		pPlayer->vRotVelocity.fPitch += fSpeed200;
		Player.ShipEngine[BOTTOM_FRONT_SHIP_ENGINE].fPower += fSpeed500;
		if(Player.ShipEngine[BOTTOM_FRONT_SHIP_ENGINE].fPower > 1.0f)
			Player.ShipEngine[BOTTOM_FRONT_SHIP_ENGINE].fPower = 1.0f;
	}
	else
	{
		Player.ShipEngine[BOTTOM_FRONT_SHIP_ENGINE].fPower -= fSpeed500;
		if(Player.ShipEngine[BOTTOM_FRONT_SHIP_ENGINE].fPower < 0.0f)
			Player.ShipEngine[BOTTOM_FRONT_SHIP_ENGINE].fPower = 0.0f;
	}
	// Turn right:
	if(CHECK_KEY(ASKeys, _ASConfig->iRightKey[0]) && !CHECK_KEY(ASKeys, 157))
	{
		pCamera->fRot2[Y] -= fSpeed100;
		pPlayer->vRotVelocity.fHeading -= fSpeed200;
		Player.ShipEngine[LEFT_SHIP_ENGINE].fPower += fSpeed500;
		if(Player.ShipEngine[LEFT_SHIP_ENGINE].fPower > 1.0f)
			Player.ShipEngine[LEFT_SHIP_ENGINE].fPower = 1.0f;
	}
	else
	{
		Player.ShipEngine[LEFT_SHIP_ENGINE].fPower -= fSpeed500;
		if(Player.ShipEngine[LEFT_SHIP_ENGINE].fPower < 0.0f)
			Player.ShipEngine[LEFT_SHIP_ENGINE].fPower = 0.0f;
	}
	// Turn down:
	if(CHECK_KEY(ASKeys, _ASConfig->iDownKey[0]) && !CHECK_KEY(ASKeys, 157))
	{
		pCamera->fRot2[X] -= fSpeed100;
		pPlayer->vRotVelocity.fPitch -= fSpeed200;
		Player.ShipEngine[TOP_FRONT_SHIP_ENGINE].fPower += fSpeed500;
		if(Player.ShipEngine[TOP_FRONT_SHIP_ENGINE].fPower > 1.0f)
			Player.ShipEngine[TOP_FRONT_SHIP_ENGINE].fPower = 1.0f;
	}
	else
	{
		Player.ShipEngine[TOP_FRONT_SHIP_ENGINE].fPower -= fSpeed500;
		if(Player.ShipEngine[TOP_FRONT_SHIP_ENGINE].fPower < 0.0f)
			Player.ShipEngine[TOP_FRONT_SHIP_ENGINE].fPower = 0.0f;
	}
	// Roll left:
	if(CHECK_KEY(ASKeys, _ASConfig->iRollLeftKey[0]))
	{
		pCamera->fRot2[Z] += fSpeed100;
		pPlayer->vRotVelocity.fRoll -= fSpeed200;
	}
	// Roll right:
	if(CHECK_KEY(ASKeys, _ASConfig->iRollRightKey[0]))
	{
		pCamera->fRot2[Z] -= fSpeed100;
		pPlayer->vRotVelocity.fRoll += fSpeed200;
	}
	// Full stop:
	if(CHECK_KEY(ASKeys, _ASConfig->iFullStopKey[0]))
	{
	 	Player.fAfterburnerPower += fSpeed1000*2;
		if(Player.fAfterburnerPower > 1.0f)
			Player.fAfterburnerPower = 1.0f;
		for(i = 0; i < 10; i++)
		{
			Player.ShipEngine[i].fPower += fSpeed1000*2;
			if(Player.ShipEngine[i].fPower > 1.0f)
				Player.ShipEngine[i].fPower = 1.0f;
		}
		if(g_lNow-lFullStopTimer > 10)
		{
			lFullStopTimer = g_lNow;
			for(i = 0; i < 3; i++)
			{	// Decrease player speed:
				pPlayer->vWorldVelocity.fV[i] = pPlayer->vWorldVelocity.fV[i]/1.1f;
				pPlayer->vRotVelocity.fV[i] = pPlayer->vRotVelocity.fV[i]/1.1f;
			}
		}
	}

	// Select target:
	if(CHECK_KEY(ASKeys, _ASConfig->iSelectTargetKey[0]))
	{
		Player.iFixedTargetID = Player.iTargetID;
	}
	// 
	if(!pPlayer->bPrimaryWeaponReady)
	{
		pPlayer->fPrimaryWeaponReady += (float) g_lDeltatime/500;
		if(pPlayer->fPrimaryWeaponReady >= 1.0f)
		{
			pPlayer->fPrimaryWeaponReady = 0.0f;
			pPlayer->bPrimaryWeaponReady = TRUE;
		}
	}
	if(CHECK_KEY(ASKeys, _ASConfig->iShotKey[0]) &&
	   pPlayer->bPrimaryWeaponReady)
	{
		pActor = FindFreeActor();
		if(pActor)
		{
/*			pActor->bActive = TRUE;
			pActor->qRotation.Reset();
			pActor->pParentActor = pPlayer;
			// Get shot start position:
			fPos2[X] = pPlayer->vWorldPos.fX;
			fPos2[Y] = pPlayer->vWorldPos.fY;
			fPos2[Z] = pPlayer->vWorldPos.fZ;
			ASGetMd2Vertex(pWeaponPhaser, 0, fPos2, 1.0f,
						   0.0f, 0.0f,  0.0f, 12, &fPos);
			glLoadIdentity();
			float axisX, axisY, axisZ, rotAngle;
			glTranslatef(Player.Actor.vWorldPos.fX, Player.Actor.vWorldPos.fY, -Player.Actor.vWorldPos.fZ);
			Player.Actor.qRotation.GetAxisAngle(axisX, axisY, axisZ, rotAngle);
			glRotatef((float) (rotAngle*RAD_TO_DEG), -axisX, -axisY, -axisZ);
			glRotatef(-90.0f, 0.0f, 1.0f, 0.0f);
			glScalef(0.01f, 0.01f, 0.01f);

			glGetFloatv(GL_MODELVIEW_MATRIX, m);
			ASMultVecMatrix(fPos, m, &pActor->fWorldPos);
			pActor->vWorldPos += pPlayer->vWorldPos;
			memcpy(&pActor->qRotation, &pPlayer->qRotation, sizeof(AS_QUATERNION));
			memcpy(&pActor->fWorldVelocity, &pPlayer->fWorldVelocity, sizeof(AS_QUATERNION));
			pActor->fForward = 80.0f+pPlayer->fForward;
			// Setup other shot attributes:
			switch(Player.iPrimaryWeapon)
			{
				case PHASER_WEAPON:
					pActor->byType = ACTOR_PHASER_SHOT;
        			i = ParticleManager.AddNewSystem(PS_ShotTrace1, 50, pActor, &GameTexture[1], NULL);
					ParticleManager.pSystem[i].bActive = TRUE;
				break;
			}
			
			pPlayer->bPrimaryWeaponReady = FALSE;*/
		}
	}


	//	Mouse camera movement and rotate:
	// Compute the player acceleration corresponding the mouse movement:
	fXAcceleration = ((float) ASMouse.lX/g_lDeltatime)*_ASConfig->fMouseSensibility*0.35f;
	fYAcceleration = ((float) ASMouse.lY/g_lDeltatime)*_ASConfig->fMouseSensibility*0.35f;
	if(CHECK_KEY(ASMouse.byButtons, 0) && CHECK_KEY(ASMouse.byButtons, 1))
		pCamera->fPos2[Z] -= (float) fYAcceleration*0.5f;
	else
	{
		if(CHECK_KEY(ASMouse.byButtons, 0))
		{
			pCamera->fPos2[X] -= (float) fXAcceleration*0.5f;
			pCamera->fPos2[Y] += (float) fYAcceleration*0.5f;
		}
		if(CHECK_KEY(ASMouse.byButtons, 1))
		{
			pCamera->fPos2[Z] -= (float) fYAcceleration*0.5f;
			pCamera->fRot2Velocity[Z] -= (float) fXAcceleration*4;
		}
		if((!CHECK_KEY(ASMouse.byButtons, 0) && !CHECK_KEY(ASMouse.byButtons, 1)) ||
		   CHECK_KEY(ASMouse.byButtons, 2))
		{
			pCamera->fRot2Velocity[Y] -= ((float) fXAcceleration*4);
			pCamera->fRot2Velocity[X] -= (float) fYAcceleration*4;
		}
	}
	
	// Update some data:
	for(i = 0; i < 3; i++)
	{
		// Camera:
		if(pCamera->fPos2[i])
			pCamera->fPos[i] += (float) g_lDeltatime/100*pCamera->fPos2[i];
		if(pCamera->fRot2Velocity[i])
			pCamera->fRot[i] += (float) g_lDeltatime/100*pCamera->fRot2Velocity[i];
		// Player:
	}
	
	// Zoom limitation:
	if(pCamera->fPos[Z] > -5.0f)
	{
		pCamera->fPos[Z] = -5.0f;
		pCamera->fPos2[Z] = -pCamera->fPos2[Z];
		pCamera->fPos2[Z] /= 2.0f;
	}
	if(pCamera->fPos[Z] < -140.0f)
	{
		pCamera->fPos[Z] = -140.0f;
		pCamera->fPos2[Z] = -pCamera->fPos2[Z];
		pCamera->fPos2[Z] /= 2.0f;
	}
	
	// Rotate speed decrease:
	for(i = 0; i < 3; i++)
		pCamera->fRot2[i] -= pCamera->fRot2[i]/24.0f*((float) g_lDeltatime/30);
	pCamera->fZ -= pCamera->fZ/40.0f*((float) g_lDeltatime/30);
	
//	pCamera->fPos2[Z] = pCamera->fPos2[Z]/1.03f;

	if(g_lNow-lCameraTimer > 10)
	{
		lCameraTimer = g_lNow;
		for(i = 0; i < 3; i++)
		{
			// Decrease camera speed:
			pCamera->fRot2Velocity[i] = pCamera->fRot2Velocity[i]/1.03f;
			pCamera->fPos2[i] = pCamera->fPos2[i]/1.03f;
		}
	}
	for(i = 0; i < 2; i++)
		pCamera->fPos[i] = pCamera->fPos[i]/1.03f;
	
	// Shake effect:
	if(!Player.fAfterburnerPower)
	{
		pCamera->vShakePos = pCamera->vNewShakePos = 0.0f;
		pCamera->fShakeSpeed = 0.0f;
	}
	else
	{
		for(i = 0; i < 3; i++)
		{
			if(pCamera->vLastShakePos.fV[i] > pCamera->vNewShakePos.fV[i])
			{
				pCamera->vShakePos.fV[i] -= pCamera->fShakeSpeed*fSpeed1000/10;
				if(pCamera->vShakePos.fV[i] <= pCamera->vNewShakePos.fV[i])
				{
					pCamera->fShakeSpeed = 5.0f+((float) (rand() % 100)/1000);
					pCamera->vLastShakePos.fV[i] = pCamera->vShakePos.fV[i];
					if((rand() % 2))
						pCamera->vNewShakePos.fV[i] = (float) (rand() % 100)/10000.0f;
					else
						pCamera->vNewShakePos.fV[i] = -(float) (rand() % 100)/10000.0f;
				}
			}
			else
			{
				pCamera->vShakePos.fV[i] += pCamera->fShakeSpeed*fSpeed1000/10;
				if(pCamera->vShakePos.fV[i] >= pCamera->vNewShakePos.fV[i])
				{
					pCamera->vLastShakePos.fV[i] = pCamera->vShakePos.fV[i];
					pCamera->fShakeSpeed = 5.0f+((float) (rand() % 100)/1000);
					if((rand() % 2))
						pCamera->vNewShakePos.fV[i] = (float) (rand() % 100)/10000.0f;
					else
						pCamera->vNewShakePos.fV[i] = -(float) (rand() % 100)/10000.0f;
				}
			}			
		}
	}

	pPlayer->Update();
} // end PlayerControl()

extern int iTemp;

void DrawPlayerSolid(void)
{ // begin DrawPlayerSolid()
	ACTOR *pPlayer = &Player.Actor;

	glPushMatrix();
	pPlayer->Apply();
	glScalef(0.01f, 0.01f, 0.01f);
	glRotatef(90.0f, 0.0f, 1.0f, 0.0f);

	ASEnableLighting();
	glEnable(GL_CULL_FACE);
	glCullFace(GL_FRONT);
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_BLEND);

	// Ship hull:
	glColor4f(0.5f, 0.5f, 0.5f, 1.0f);
	glBindTexture(GL_TEXTURE_2D, GameTexture[9].iOpenGLID);
	ASDrawMd2Frame(pPlayerShipHull, 0);

	// Pilot:
	glColor4f(0.5f, 0.5f, 0.5f, 1.0f);
	glBindTexture(GL_TEXTURE_2D, GameTexture[12].iOpenGLID);
	ASDrawMd2Frame(pPlayerShipPilot, 0);

	// Weapon:
	glColor4f(0.5f, 0.5f, 0.5f, 1.0f);
	glBindTexture(GL_TEXTURE_2D, GameTexture[12].iOpenGLID);
	ASDrawMd2Frame(pWeaponPhaser, 0);

/////////// Show vertex pos test: //////////////////////////
//			glRotatef(90.0f, 0.0f, 1.0f, 0.0f);
//			glRotatef(180.0f, 0.0f, 0.0f, 1.0f);
//			glRotatef(180.0f, 1.0f, 0.0f, 0.0f);

	FLOAT3 fPos, fPos2, fPos3;
	float m[16];

	fPos2[X] = Player.Actor.vWorldPos.fX;
	fPos2[Y] = Player.Actor.vWorldPos.fY;
	fPos2[Z] = Player.Actor.vWorldPos.fZ;
//	iTemp = 9;
	
//	pPlayer->fWorldPos[X] = pPlayer->fWorldPos[Y] = pPlayer->fWorldPos[Z] = 0.0f;
	ASGetMd2Vertex(pWeaponPhaser, 0, fPos2, 1.0f,
				   0.0f, 0.0f,  0.0f, 12, &fPos);
	glDisable(GL_DEPTH_TEST);
	glPointSize(5.0f);
	glDisable(GL_TEXTURE_2D);
	glColor3f(1.0f, 1.0f, 1.0f);


	glLoadIdentity();
	pPlayer->Apply();
	glScalef(0.01f, 0.01f, 0.01f);
	glGetFloatv(GL_MODELVIEW_MATRIX, m);
	ASMultVecMatrix(fPos, m, &fPos2);

	glScalef(100.0f, 100.0f, 100.0f);
//	glScalef(0.01f, 0.01f, 0.01f);
	glBegin(GL_POINTS);
		glVertex3fv(fPos2);
	glEnd();
	glEnable(GL_DEPTH_TEST);
	glCullFace(GL_BACK);
/////////////////////////////////////////////////////////////////
	ASDrawBoundingBox(pPlayerShipHull->fBoundingBox, 1.0f);
	glPopMatrix();
} // end DrawPlayerSolid()

void DrawPlayerTransparent(void)
{ // begin DrawPlayerTransparent()
	ACTOR *pPlayer = &Player.Actor;

//	if(bPilotView)
//		return;	glPushMatrix();
	glPushMatrix();
	pPlayer->Apply();
	glScalef(0.01f, 0.01f, 0.01f);
	glRotatef(90.0f, 0.0f, 1.0f, 0.0f);

	glEnable(GL_CULL_FACE);
	glCullFace(GL_FRONT);
	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glDepthMask(FALSE);
	glEnable(GL_DEPTH_TEST);

	glColor4f(0.5f, 0.5f, 0.5f, 0.5f);
	glDisable(GL_CULL_FACE);
	// Ship glass:
//	glBindTexture(GL_TEXTURE_2D, GameTexture[10].iOpenGLID);
//	ASDrawMd2Frame(pPlayerShipGlass, 0);
	// Weapon:
	ASDrawMd2Frame(pWeaponPhaser, 0);
	glEnable(GL_CULL_FACE);


//	glColor4f(pPlayer->fDamage, 1.0f-pPlayer->fDamage, Player.fDamagePulse, 0.4f);
	glColor4f(pPlayer->fDamage, 1.0f-pPlayer->fDamage, Player.fDamagePulse, 0.4f);
	glEnable(GL_TEXTURE_GEN_S);
	glEnable(GL_TEXTURE_GEN_T);
	// Ship hull environment:
//	glBindTexture(GL_TEXTURE_2D, GameTexture[11].iOpenGLID);
	glBindTexture(GL_TEXTURE_2D, Caust1Texture[0].iOpenGLID);
	glBindTexture(GL_TEXTURE_2D, Caust1Texture[Environment.iSphereAniStep].iOpenGLID);
	ASDrawMd2Frame(pPlayerShipHull, 0);

	// Ship glass environment:
	ASDrawMd2Frame(pPlayerShipGlass, 0);

	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);
	glDepthMask(TRUE);
	glPopMatrix();
} // end DrawPlayerTransparent()

void InitPlayer(void)
{ // begin InitPlayer()
	InitActors();

	ACTOR *pPlayer;
	
	pPlayer = &Player.Actor;
	memset(pPlayer, 0, sizeof(ACTOR));
	pPlayer->bActive = TRUE;
	pPlayer->fRadius = 5.0f;
	pPlayer->byType = ACTOR_PLAYER_SHIP;
	pPlayer->fMass = pPlayer->fRadius*((float) PI)*10;
	pPlayer->qRotation.Reset();
	pPlayer->vWorldPos.fZ = -50.0f;
	pPlayer->fNormalMaxVelocity = 70.0f;
	pPlayer->fCurrentMaxVelocity = 70.0f;
	pPlayer->fMaxVelocity = 200.0f;

	Player.fMaxAfterburnerEngine = Player.fAfterburnerEngine = 100;
	Player.fAfterburnerEngineDecreaseSpeed = 1.0f;
	Player.fAfterburnerEngineRegenerationSpeed = 0.5f;

} // end InitPlayer()

void CheckPlayer(void)
{ // begin CheckPlayer()
	int i, i2, i3;

	PlayerControl();
	CheckPlayerCollision();
	CheckPlayerShipEngine();

	// Animate the players shield:
	for(i = 0; i < 8; i++)
	{
		if(!Player.bShieldLight[i])
		{
			if(Player.fShieldLight[i] >= 0.0f)
			{
				Player.fShieldLight[i] -= (float) g_lDeltatime/1000;
				if(Player.fShieldLight[i] < 0.0f)
					Player.fShieldLight[i] = 0.0f;
			}
			continue;
		}
		Player.fShieldLight[i] += (float) g_lDeltatime/1000;
		if(Player.fShieldLight[i] >= 1.0f)
		{
			Player.fShieldLight[i] = 1.0f;
			Player.bShieldLight[i] = FALSE;
		}
	}
	// Animate the damage pulse:
	if(!Player.bDamagePulse)
	{
		Player.fDamagePulse += (float) (g_lDeltatime/(2000-(1500*Player.Actor.fDamage)));
		if(Player.fDamagePulse >= 0.8f)
		{
			Player.fDamagePulse = 0.8f;
			Player.bDamagePulse = TRUE;
		}
	}
	else
	{
		Player.fDamagePulse -= (float) (g_lDeltatime/(2000-(1500*Player.Actor.fDamage)));
		if(Player.fDamagePulse <= 0.0f)
		{
			Player.fDamagePulse = 0.0f;
			Player.bDamagePulse = FALSE;
		}
	}
/*

	Player.bTarget = FALSE;
	ParticleManager.pSystem[PS_PLAYER_CROSSHAIR].pParticle[0].fColor[G] = 1.0f;
	ParticleManager.pSystem[PS_PLAYER_CROSSHAIR].pParticle[0].fColor[B] = 1.0f;

	FLOAT3 fLineM, fLineS;
	float fDistance, fDeltaX, fDeltaY, fDeltaZ;
	fLineS[X] = Player.Actor.fWorldPos[X];
	fLineS[Y] = Player.Actor.fWorldPos[Y];
	fLineS[Z] = Player.Actor.fWorldPos[Z];

	fLineM[X] = Player.Actor.fDirectionVector[X]*100000;
	fLineM[Y] = Player.Actor.fDirectionVector[Y]*100000;
	fLineM[Z] = Player.Actor.fDirectionVector[Z]*100000;
	Player.fTargetDistance = 1000000;
	Player.iTargetID = -1;


	if(ASCheckLineInBox(fLineS, fLineM, Environment.fAblazeBox))
	{
		Player.bTarget = TRUE;
		ParticleManager.pSystem[PS_PLAYER_CROSSHAIR].pParticle[0].fColor[G] = 0.0f;
		ParticleManager.pSystem[PS_PLAYER_CROSSHAIR].pParticle[0].fColor[B] = 0.0f;
	}

	ACTOR *pActor, *pPlayer;
	FLOAT3 fBox[2];
	pPlayer = &Player.Actor;

	for(i = 0; i < MAX_ACTORS; i++)
	{
		pActor = &Actor[i];
		for(i2 = 0; i2 < 3; i2++)
			for(i3 = 0; i3 < 2; i3++)
				fBox[i3][i2] = pActor->fWorldPos[i2];
		for(i2 = 0; i2 < 3; i2++)
			for(i3 = 0; i3 < 2; i3++)
				fBox[i3][i2] += pAsteroid->fBoundingBox[i3][i2]*0.01f*pActor->fRadius;

//		if(ASCheckLineInBox(fLineS, fLineM, fBox))
		if(ASCheckRaySphereCollision(pPlayer->fWorldPos, pPlayer->fDirectionVector, pActor->fWorldPos, pActor->fRadius))
		{
			Player.bTarget = TRUE;
			Player.iTargetID = i;
			fDeltaX = pPlayer->fWorldPos[X]-pActor->fWorldPos[X]+pPlayer->fRadius;
			fDeltaY = pPlayer->fWorldPos[Y]-pActor->fWorldPos[Y]+pPlayer->fRadius;
			fDeltaZ = pPlayer->fWorldPos[Z]-pActor->fWorldPos[Z]+pPlayer->fRadius;
			fDistance = (float) sqrt(fDeltaX*fDeltaX+fDeltaY*fDeltaY+fDeltaZ*fDeltaZ);
			if(fDistance < Player.fTargetDistance)
			{
				Player.fTargetDistance = fDistance;
			}
			ParticleManager.pSystem[PS_PLAYER_CROSSHAIR].pParticle[0].fColor[G] = 0.0f;
			ParticleManager.pSystem[PS_PLAYER_CROSSHAIR].pParticle[0].fColor[B] = 0.0f;
		}
	}
	if(Player.iFixedTargetID != -1)
	{
		pActor = &Actor[Player.iFixedTargetID];
		fDeltaX = pPlayer->fWorldPos[X]-pActor->fWorldPos[X]+pPlayer->fRadius;
		fDeltaY = pPlayer->fWorldPos[Y]-pActor->fWorldPos[Y]+pPlayer->fRadius;
		fDeltaZ = pPlayer->fWorldPos[Z]-pActor->fWorldPos[Z]+pPlayer->fRadius;
		Player.fFixedTargetDistance = (float) sqrt(fDeltaX*fDeltaX+fDeltaY*fDeltaY+fDeltaZ*fDeltaZ);
	}*/
} // end CheckPlayer()

BOOL CheckPlayerCollision(void)
{ // begin CheckPlayerCollision()
	float fDistance, fRadius;
	ACTOR *pPlayer = &Player.Actor;
	ACTOR *pActor;
	AS_3D_VECTOR vDelta;
	int i, i2;
	BOOL bCollision = FALSE;
	float m[16];
	FLOAT3 fTempV, fTempV2;
	
	glLoadIdentity();
	pPlayer->Apply();
	glScalef(0.01f, 0.01f, 0.01f);
	glRotatef(90.0f, 0.0f, 1.0f, 0.0f);
	glGetFloatv(GL_MODELVIEW_MATRIX, m);
	
	// Check if the player ship collides with an other actor:
	for(i = 0; i < MAX_ACTORS; i++)
	{
		pActor = &Actor[i];
		if(!pActor->bActive)
			continue;
		
		if(pActor->byType == ACTOR_PHASER_SHOT)
			continue;

		for(i2 = 0; i2 < 8; i2++)
		{
			memcpy(&fTempV, fPlayerPosR[i2], sizeof(FLOAT3));
			ASMultVecMatrix(fTempV, m, &fTempV2);
			vDelta = (pPlayer->vWorldPos+fTempV2)-pActor->vWorldPos;
			fDistance = vDelta.DotProduct();
			fRadius = fPlayerPosR[i2][3]/100;
			if(fDistance <= (fRadius+pActor->fRadius)*(fRadius+pActor->fRadius))
			{ // We have a collision!
				Player.bShieldLight[i2] = TRUE;
				Actor[0].vWorldVelocity = 0.0f;
				CheckBallCollision(pPlayer, pActor, vDelta);
				bCollision = TRUE;
			}
		}
	}

	if(bCollision)
		pPlayer->vWorldPos = pPlayer->vLastWorldPos;
	return bCollision;
} // end CheckPlayerCollision()

void CheckBallCollision(ACTOR *pActor1, ACTOR *pActor2, AS_3D_VECTOR vDelta)
{ // begin CheckBallCollision()
	float fContactAngle,
		  fXClosingVelocity, fYClosingVelocity, fResVelocity, fXContactVelocity,
		  fYContactVelocity, fClosingAngle, fMassFactor, fMass1, fMass2, fAdiff, fPortion;

	// Determine the angle of contact
	if(vDelta.fX != 0)
	{
		fContactAngle = (float) atan(vDelta.fY/vDelta.fX);
		if(fContactAngle < 0)
			fContactAngle = -fContactAngle;
	}
	else
		fContactAngle = (float) PId2;
	// To determine how the objects will rebound off of each
	// other, we are not concerned with the speed of each
	// object, but rather the relative, or closing, speeds
	// of the two objects.
	fXClosingVelocity = pActor2->vWorldVelocity.fX-pActor1->vWorldVelocity.fX;
	fYClosingVelocity = pActor2->vWorldVelocity.fY-pActor1->vWorldVelocity.fY;
	// Calculate the x & y speed in the direction of contact
	fResVelocity = (float)  sqrt(fXClosingVelocity*fXClosingVelocity+fYClosingVelocity*fYClosingVelocity);
	fXContactVelocity = (float)  cos(fContactAngle)*fResVelocity;
	fYContactVelocity = (float)  sin(fContactAngle)*fResVelocity;
	// Now, determine the closing angle.
	if(fXClosingVelocity != 0)
	{
		fClosingAngle = (float) atan(fYClosingVelocity/fXClosingVelocity);
		if(fClosingAngle < 0)
			fClosingAngle = -fClosingAngle;
	}
	else
		fClosingAngle = (float) PId2;
	// Hmmmm...
	// With equal masses,
	// the max rebound speed is 1/2 the closing speed.
	// With unequal masses,
	// the max rebound speed is the closing speed.
	// Okay then,
	// Normalize the two masses to be:  mass1 + mass2 = 2.0
	fMassFactor = 2/(pActor1->fMass+pActor2->fMass);
	fMass1 = pActor1->fMass*fMassFactor;
	fMass2 = pActor2->fMass*fMassFactor;	
	// Quadrant-specific stuff
	if(pActor1->vWorldPos.fX > pActor2->vWorldPos.fX)
	{
		if(pActor1->vWorldPos.fY < pActor2->vWorldPos.fY)
		{
			// pActor1 is contacting upper right quadrant of pActor2
			if(fYClosingVelocity < 0)
			{
				if(fXClosingVelocity < 0)
					fAdiff = (float) PI-fContactAngle-fClosingAngle;
				else
					fAdiff = fContactAngle-fClosingAngle;
			}
			else
				fAdiff = fContactAngle+fClosingAngle;
			fPortion = (float) cos(fAdiff);
			pActor1->vWorldVelocity.fX += fXContactVelocity*fPortion*fMass2;
			pActor1->vWorldVelocity.fY -= fYContactVelocity*fPortion*fMass2;
			pActor2->vWorldVelocity.fX -= fXContactVelocity*fPortion*fMass1;
			pActor2->vWorldVelocity.fY += fYContactVelocity*fPortion*fMass1;
		}
		else
		{
			// pActor1 is contacting lower right quadrant of pActor2
			if(fYClosingVelocity > 0)
			{
				if(fXClosingVelocity < 0)
					fAdiff = (float) PI-fContactAngle-fClosingAngle;
				else
					fAdiff = fContactAngle-fClosingAngle;
			}
			else
				fAdiff = fContactAngle+fClosingAngle;
			fPortion = (float) cos(fAdiff);
			pActor1->vWorldVelocity.fX += fXContactVelocity*fPortion*fMass2;
			pActor1->vWorldVelocity.fY += fYContactVelocity*fPortion*fMass2;
			pActor2->vWorldVelocity.fX -= fXContactVelocity*fPortion*fMass1;
			pActor2->vWorldVelocity.fY -= fYContactVelocity*fPortion*fMass1;
		}
	}
	else
	{
		if(pActor1->vWorldPos.fY < pActor2->vWorldPos.fY)
		{
			// pActor1 is contacting upper left quadrant of pActor2
			if(fYClosingVelocity < 0)
			{
				if(fXClosingVelocity < 0)
					fAdiff = fContactAngle-fClosingAngle;
				else
					fAdiff = (float) PI-fContactAngle-fClosingAngle;
			}
			else
				fAdiff = fContactAngle+fClosingAngle;
			fPortion = (float) cos(fAdiff);
			pActor1->vWorldVelocity.fX -= fXContactVelocity*fPortion*fMass2;
			pActor1->vWorldVelocity.fY -= fYContactVelocity*fPortion*fMass2;
			pActor2->vWorldVelocity.fX += fXContactVelocity*fPortion*fMass1;
			pActor2->vWorldVelocity.fY += fYContactVelocity*fPortion*fMass1;
		}
		else
		{
			// pActor1 is contacting lower left quadrant of pActor2
			if(fYClosingVelocity > 0)
			{
				if(fXClosingVelocity < 0)
					fAdiff = fContactAngle-fClosingAngle;
				else
					fAdiff = (float) PI-fContactAngle-fClosingAngle;
			}
			else
				fAdiff = fContactAngle+fClosingAngle;
			fPortion = (float) cos(fAdiff);
			pActor1->vWorldVelocity.fX -= fXContactVelocity*fPortion*fMass2;
			pActor1->vWorldVelocity.fY += fYContactVelocity*fPortion*fMass2;
			pActor2->vWorldVelocity.fX += fXContactVelocity*fPortion*fMass1;
			pActor2->vWorldVelocity.fY -= fYContactVelocity*fPortion*fMass1;
		}
	}
/*
	if(vDelta.fZ != 0)
	{
		fContactAngle = (float) atan(vDelta.fY/vDelta.fZ);
		if(fContactAngle < 0)
			fContactAngle = -fContactAngle;
	}
	else
		fContactAngle = (float) PId2;
	// To determine how the objects will rebound off of each
	// other, we are not concerned with the speed of each
	// object, but rather the relative, or closing, speeds
	// of the two objects.
	fXClosingVelocity = pActor2->vWorldVelocity.fZ-pActor1->vWorldVelocity.fZ;
	fYClosingVelocity = pActor2->vWorldVelocity.fY-pActor1->vWorldVelocity.fY;
	// Calculate the x & y speed in the direction of contact
	fResVelocity = (float)  sqrt(fXClosingVelocity*fXClosingVelocity+fYClosingVelocity*fYClosingVelocity);
	fXContactVelocity = (float)  cos(fContactAngle)*fResVelocity;
	fYContactVelocity = (float)  sin(fContactAngle)*fResVelocity;
	// Now, determine the closing angle.
	if(fXClosingVelocity != 0)
	{
		fClosingAngle = (float) atan(fYClosingVelocity/fXClosingVelocity);
		if(fClosingAngle < 0)
			fClosingAngle = -fClosingAngle;
	}
	else
		fClosingAngle = (float) PId2;
	// Hmmmm...
	// With equal masses,
	// the max rebound speed is 1/2 the closing speed.
	// With unequal masses,
	// the max rebound speed is the closing speed.
	// Okay then,
	// Normalize the two masses to be:  mass1 + mass2 = 2.0
	fMassFactor = 2/(pActor1->fMass+pActor2->fMass);
	fMass1 = pActor1->fMass*fMassFactor;
	fMass2 = pActor2->fMass*fMassFactor;	
	// Quadrant-specific stuff
	if(pActor1->fWorldPos[Z] > pActor2->fWorldPos[Z])
	{
		if(pActor1->fWorldPos[Y] < pActor2->fWorldPos[Y])
		{
			// pActor1 is contacting upper right quadrant of pActor2
			if(fYClosingVelocity < 0)
			{
				if(fXClosingVelocity < 0)
					fAdiff = (float) PI-fContactAngle-fClosingAngle;
				else
					fAdiff = fContactAngle-fClosingAngle;
			}
			else
				fAdiff = fContactAngle+fClosingAngle;
			fPortion = (float) cos(fAdiff);
			pActor1->vWorldVelocity.fZ += fXContactVelocity*fPortion*fMass2;
			pActor1->vWorldVelocity.fY -= fYContactVelocity*fPortion*fMass2;
			pActor2->vWorldVelocity.fZ -= fXContactVelocity*fPortion*fMass1;
			pActor2->vWorldVelocity.fY += fYContactVelocity*fPortion*fMass1;
		}
		else
		{
			// pActor1 is contacting lower right quadrant of pActor2
			if(fYClosingVelocity > 0)
			{
				if(fXClosingVelocity < 0)
					fAdiff = (float) PI-fContactAngle-fClosingAngle;
				else
					fAdiff = fContactAngle-fClosingAngle;
			}
			else
				fAdiff = fContactAngle+fClosingAngle;
			fPortion = (float) cos(fAdiff);
			pActor1->vWorldVelocity.fZ += fXContactVelocity*fPortion*fMass2;
			pActor1->vWorldVelocity.fY += fYContactVelocity*fPortion*fMass2;
			pActor2->vWorldVelocity.fZ -= fXContactVelocity*fPortion*fMass1;
			pActor2->vWorldVelocity.fY -= fYContactVelocity*fPortion*fMass1;
		}
	}
	else
	{
		if(pActor1->fWorldPos[Y] < pActor2->fWorldPos[Y])
		{
			// pActor1 is contacting upper left quadrant of pActor2
			if(fYClosingVelocity < 0)
			{
				if(fXClosingVelocity < 0)
					fAdiff = fContactAngle-fClosingAngle;
				else
					fAdiff = (float) PI-fContactAngle-fClosingAngle;
			}
			else
				fAdiff = fContactAngle+fClosingAngle;
			fPortion = (float) cos(fAdiff);
			pActor1->vWorldVelocity.fZ -= fXContactVelocity*fPortion*fMass2;
			pActor1->vWorldVelocity.fY -= fYContactVelocity*fPortion*fMass2;
			pActor2->vWorldVelocity.fZ += fXContactVelocity*fPortion*fMass1;
			pActor2->vWorldVelocity.fY += fYContactVelocity*fPortion*fMass1;
		}
		else
		{
			// pActor1 is contacting lower left quadrant of pActor2
			if(fYClosingVelocity > 0)
			{
				if(fXClosingVelocity < 0)
					fAdiff = fContactAngle-fClosingAngle;
				else
					fAdiff = (float) PI-fContactAngle-fClosingAngle;
			}
			else
				fAdiff = fContactAngle+fClosingAngle;
			fPortion = (float) cos(fAdiff);
			pActor1->vWorldVelocity.fZ -= fXContactVelocity*fPortion*fMass2;
			pActor1->vWorldVelocity.fY += fYContactVelocity*fPortion*fMass2;
			pActor2->vWorldVelocity.fZ += fXContactVelocity*fPortion*fMass1;
			pActor2->vWorldVelocity.fY -= fYContactVelocity*fPortion*fMass1;
		}
	}*/
} // end CheckBallCollision()

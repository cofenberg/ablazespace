//-----------------------------------------------------------------------------
// File: PlayerEngines.h
//-----------------------------------------------------------------------------

#ifndef __AS_PLAYER_ENGINES_H__
#define __AS_PLAYER_ENGINES_H__


// Definitions: ***************************************************************
// The different ship engines:
enum
{
	MAIN_SHIP_ENGINE, LEFT_SHIP_ENGINE, RIGHT_SHIP_ENGINE, 
	LEFT_BOTTOM_SHIP_ENGINE, RIGHT_BOTTOM_SHIP_ENGINE, BACKWARD_SHIP_ENGINE,
	TOP_SHIP_ENGINE, BOTTOM_SHIP_ENGINE, TOP_FRONT_SHIP_ENGINE, BOTTOM_FRONT_SHIP_ENGINE,
};
///////////////////////////////////////////////////////////////////////////////

// Structures: ****************************************************************
typedef struct SHIP_ENGINE
{
	float fPower;
	int iAniStep;
	long lAniTimer;

	// Flickering engine light:
	float fLastPower, fActualPower, fNewPower;
	long lPowerTimer, lPowerSpeed;

} SHIP_ENGINE;
///////////////////////////////////////////////////////////////////////////////


// Functions: *****************************************************************
extern void CreateEngineParticles(AS_MD2_MODEL *, int, int, int, long, float,
								  float, FLOAT3, FLOAT3, float, int, float, int);
extern void DrawPlayerShipEngine(void);
extern void CheckPlayerShipEngine(void);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_PLAYER_ENGINES_H__
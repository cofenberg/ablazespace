//-----------------------------------------------------------------------------
// File: GameMenu.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
BOOL bInGameMenu;
AS_TEXTURE GameMenuTexture[GAME_MENU_TEXTURES];
long lPressNewKeyTimer;
char byGameMenuSelected, byGameMenuMenu, byLastGameMenuMenu, byGameMenuSelectedTemp;
BOOL bGetPlayerName, // Does the player give in his name?
     bGetNewKey, // Does we wait for a new key definition?
	 bPressNewKeyText,
	 bAreYouSureQuestion,
	 bAreYouSureQuestionAnswer,
	 bShowGameMenu,
	 bPause;
char byGetPlayerName[256]; // The players name
char byMonitorAnimationStep;
long lMonitorAnimationTimer;
float fGameMenuBlend;
///////////////////////////////////////////////////////////////////////////////

int iTemp = 0;

// Functions: *****************************************************************
HRESULT GameMenuLoop(void);
void StartMenuMusic(void);
HRESULT GameMenuDraw(AS_WINDOW *);
HRESULT GameMenuCheck(AS_WINDOW *);
void DrawOptionsText(AS_WINDOW *, int, int, char *);
void DrawKeysSetupText(AS_WINDOW *, int, int, char *, char *);
void ShowGameMenu(AS_WINDOW *);
void CheckGameMenu(void);
///////////////////////////////////////////////////////////////////////////////


HRESULT GameMenuLoop(void)
{ // begin GameMenuLoop()
	MSG msg;

	_AS->pWindow[GAME_WINDOW_ID].SetDrawFunction(GameMenuDraw);
	_AS->pWindow[GAME_WINDOW_ID].SetCheckFunction(GameMenuCheck);

	char byFilename[GAME_MENU_TEXTURES][256] = {".jpg"};
	ASLoadTextures(byFilename, GAME_MENU_TEXTURES, GameMenuTexture);
	ASGenOpenGLTextures(GAME_MENU_TEXTURES, GameMenuTexture);

	InitGameParticleSystems();
	StartMenuMusic();

	bShowGameMenu = bPause = byGameMenuMenu = byMonitorAnimationStep = 0;	
	bInGameMenu	= FALSE;
	_AS->bDraw = TRUE;

	// Go into the game menu loop:
	_AS->WriteLogMessage("Enter the game menu loop");
	for(;;)
	{
		if(PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
    	{
        	if(!GetMessage(&msg, NULL, 0, 0))
                break;
        	TranslateMessage(&msg);
        	DispatchMessage(&msg);
    	}
		else
		{	
			if(_AS->GetShutDown() || _AS->CheckModuleChange() || !bInGameMenu)
				PostQuitMessage(0);
			if(!_AS->GetActive())
				continue;
			_AS->UpdateWindows();
		}
	}
	_AS->WriteLogMessage("Left the game menu loop");

	ASDestroyOpenGLTextures(GAME_MENU_TEXTURES, GameMenuTexture);
	ASDestroyTextures(GAME_MENU_TEXTURES, GameMenuTexture);
	_AS->bDraw = FALSE;

	return msg.wParam;
} // end GameMenuLoop()

void StartMenuMusic(void)
{ // begin StartMenuMusic()
	char byTemp[256];

	// Play the menu music:
	sprintf(byTemp, "%s%s\\TheRealThink.mid", _AS->pbyProgramPath, _AS->pbyMusicFile);
	_AS->WriteLogMessage("Load music: %s", byTemp);
	ASDXShowPlay(byTemp, *_AS->pWindow[GAME_WINDOW_ID].GethWnd());
} // end StartMenuMusic()

HRESULT GameMenuDraw(AS_WINDOW *pWindow)
{ // begin GameMenuMenu()
	GLfloat afLightData[4]  = {0.0f, 0.0f, 0.0f, 0.0f};

	if(!_AS->bDraw)
		return 0;
	
	glLoadIdentity();
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	ASEnableLighting();

	// Draw the sky cube:
	Environment.DrawSkyCube();
	
	_ASCamera->SetCameraTranslation(FALSE);
	glDisable(GL_FOG);
	glDisable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_DEPTH_TEST);	
	glDisable(GL_CULL_FACE);
	glEnable(GL_BLEND);

/*	// Monitor animation:
	glLoadIdentity();
	if(g_lNow-lMonitorAnimationTimer > 100)
	{
		lMonitorAnimationTimer = g_lNow;
		byMonitorAnimationStep++;
		if(byMonitorAnimationStep > 6)
			byMonitorAnimationStep = 0;
	}
	glBindTexture(GL_TEXTURE_2D, GameTexture[2+byMonitorAnimationStep].iOpenGLID);
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  1.0f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f, -1.0f,  1.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f,  1.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f,  1.0f);
	glEnd();*/

	// Draw the options:
	// Game version:
	glColor3f(1.0f, 1.0f, 1.0f);	
	pWindow->Print(560, 300, GAME_VERSION, 0, 0);

	ShowGameMenu(pWindow);

	if(ParticleManager.pSystem[iASLogoPSSystem].bActive)
	{
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		gluPerspective(45.0f, (GLfloat)(_ASConfig->iWindowWidth+200)/(GLfloat)(_ASConfig->iWindowHeight), 0.1f, 10000.0f);
		glMatrixMode(GL_MODELVIEW);

		glLoadIdentity();
		glTranslatef(-50.0f, -20.0f, -80.0f);
		glDisable(GL_FOG);
		glEnable(GL_BLEND);
		glDisable(GL_CULL_FACE);
		glDisable(GL_LIGHTING);
		glEnable(GL_TEXTURE_2D);
		glDepthMask(FALSE);
		glEnable(GL_DEPTH_TEST);

		ParticleManager.pSystem[iASLogoPSSystem].Draw(&ParticleManager.pSystem[iASLogoPSSystem]);

		ASEnableLighting();
		glDepthMask(TRUE);
		glEnable(GL_CULL_FACE);
	}
	
	glDisable(GL_LIGHTING);
	glEnable(GL_BLEND);

	ASSwapBuffers(*pWindow->GethDC(), pWindow, TRUE);
	return 0;
} // end GameMenuMenu()

HRESULT GameMenuCheck(AS_WINDOW *pWindow)
{ // begin GameMenuCheck()
	_AS->ReadDXInput(*pWindow->GethWnd());
	ParticleManager.Check();

// Keys:
	if(ASKeyFirst[DIK_F1])
	{ // Open the help file:
		if(_ASConfig->bFullScreen)
		{ // Switch to window mode:
			_ASConfig->bFullScreen = FALSE;
			ChangeDisplayMode();
		}
		OpenHelp();
		return 0;
	}
	if(ASKeyFirst[DIK_F12])
	{ // Open the configuration menu:
		SendMessage(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), WM_COMMAND, ID_OPTIONS_CONFIG, 0);
	}

	CheckGameMenu();

	return 0;
} // end GameMenuCheck()

void DrawOptionsText(AS_WINDOW *pWindow, int iID, int iY, char *pbyText)
{ // begin DrawKeysSetupText()
	if(byGameMenuSelected == iID)
		glColor4f(1.0f, 0.0f, 0.0f, fGameMenuBlend);
	else
		glColor4f(1.0f, 1.0f, 1.0f, fGameMenuBlend);
	pWindow->Print(320, iY, pbyText, 0, 1);
} // end DrawOptionsText()

void DrawKeysSetupText(AS_WINDOW *pWindow, int iID, int iY, char *pbyAction, char *pbyKey)
{ // begin DrawKeysSetupText()
	if(byGameMenuSelected == iID)
		glColor4f(1.0f, 0.0f, 0.0f, fGameMenuBlend);
	else
		glColor4f(1.0f, 1.0f, 1.0f, fGameMenuBlend);
	pWindow->Print(100, iY, pbyAction, 0, 0);
	pWindow->Print(380, iY, pbyKey, 0, 0);
} // end DrawKeysSetupText()

void ShowGameMenu(AS_WINDOW *pWindow)
{ // begin ShowGameMenu()
	glDisable(GL_DEPTH_TEST);
	if(fGameMenuBlend != 0.0f)
	{ // Draw the dark blending quad:
		glBlendFunc(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);
		glColor4f(0.1f, 0.1f, 0.1f, 1.0f-fGameMenuBlend+0.2f);
		glDisable(GL_TEXTURE_2D);
		glDisable(GL_CULL_FACE);
		glLoadIdentity();
		glTranslatef(0.0f, 0.0f, -34.0f);
		glBegin(GL_QUADS);
			glNormal3f(0.0f, 0.0f, 1.0f);
			glVertex3f(-15.0f, -11.0f, 10.0f);
			glVertex3f( 15.0f, -11.0f, 10.0f);
			glVertex3f( 15.0f,  11.0f, 10.0f);
			glVertex3f(-15.0f,  11.0f, 10.0f);
		glEnd();
		glEnable(GL_CULL_FACE);
		glEnable(GL_TEXTURE_2D);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	}

	glColor4f(1.0f, 1.0f, 1.0f, fGameMenuBlend);
	switch(byGameMenuMenu)
	{
		case 0: // Main menu:
			pWindow->Print(0, 5, "A game by AblazeSpace 2001                 All rights reserved!", 0, 0);
			pWindow->Print(320, 200, T_MainMenu, 0, 1);
			DrawOptionsText(pWindow, 0, 160, T_StartGame);
			DrawOptionsText(pWindow, 1, 140, T_Options);
			DrawOptionsText(pWindow, 2, 120, T_Help);
			DrawOptionsText(pWindow, 3, 100, T_Credits);
			DrawOptionsText(pWindow, 4, 80, T_Quit);
		break;

		case 1: // Are you sure question:
			pWindow->Print(320, 230, M_AreYouSure, 0, 1);
			DrawOptionsText(pWindow, 0, 200, T_Yes);
			DrawOptionsText(pWindow, 1, 185, T_No);
		break;

		case 2: // Options:
			pWindow->Print(320, 230, T_Options, 0, 1);
			DrawOptionsText(pWindow, 0, 200, T_KeysSetup);
			DrawOptionsText(pWindow, 1, 180, T_OtherOptions);
		break;

		case 3: // Keys setup:
			pWindow->Print(320, 270, T_KeysSetup, 0, 1);
			DrawKeysSetupText(pWindow, 0, 250, T_Left, AS_DXInputKeys[_ASConfig->iLeftKey[1]].byName);
			DrawKeysSetupText(pWindow, 1, 237, T_Right, AS_DXInputKeys[_ASConfig->iRightKey[1]].byName);
			DrawKeysSetupText(pWindow, 2, 224, T_Up, AS_DXInputKeys[_ASConfig->iUpKey[1]].byName);
			DrawKeysSetupText(pWindow, 3, 211, T_Down, AS_DXInputKeys[_ASConfig->iDownKey[1]].byName);
			DrawKeysSetupText(pWindow, 4, 198, T_Shot, AS_DXInputKeys[_ASConfig->iShotKey[1]].byName);
			DrawKeysSetupText(pWindow, 5, 185, T_ChangePerspective, AS_DXInputKeys[_ASConfig->iChangePerspectiveKey[1]].byName);
			DrawKeysSetupText(pWindow, 6, 172, T_StandartView, AS_DXInputKeys[_ASConfig->iStandartViewKey[1]].byName);
			DrawKeysSetupText(pWindow, 7, 159, T_Pause, AS_DXInputKeys[_ASConfig->iPauseKey[1]].byName);
			DrawKeysSetupText(pWindow, 8, 146, T_LevelRestart, AS_DXInputKeys[_ASConfig->iLevelRestartKey[1]].byName);
			DrawKeysSetupText(pWindow, 9, 133, T_Afterburner, AS_DXInputKeys[_ASConfig->iAfterburnerKey[1]].byName);
			DrawKeysSetupText(pWindow, 10, 120, T_RollLeft, AS_DXInputKeys[_ASConfig->iRollLeftKey[1]].byName);
			DrawKeysSetupText(pWindow, 11, 107, T_RollRight, AS_DXInputKeys[_ASConfig->iRollRightKey[1]].byName);
			DrawKeysSetupText(pWindow, 12, 94, T_FullStop, AS_DXInputKeys[_ASConfig->iFullStopKey[1]].byName);
			DrawKeysSetupText(pWindow, 13, 81, T_Slide, AS_DXInputKeys[_ASConfig->iSlideKey[1]].byName);
			DrawKeysSetupText(pWindow, 14, 68, T_Forward, AS_DXInputKeys[_ASConfig->iForwardKey[1]].byName);
			DrawKeysSetupText(pWindow, 15, 55, T_Backward, AS_DXInputKeys[_ASConfig->iBackwardKey[1]].byName);
			DrawKeysSetupText(pWindow, 16, 42, T_SelectTarget, AS_DXInputKeys[_ASConfig->iSelectTargetKey[1]].byName);
			DrawKeysSetupText(pWindow, 17, 29, T_Hud, AS_DXInputKeys[_ASConfig->iHudKey[1]].byName);
			DrawOptionsText(pWindow, 18, 16, T_StandartConfiguration);
			if(bGetNewKey && bPressNewKeyText)
			{
				glColor3f(1.0f, 1.0f, 1.0f);	
				pWindow->Print(320, 5, T_PressNewKey, 0, 1);
			}
		break;
	}
	if(bGetPlayerName && bPressNewKeyText)
	{
		glEnable(GL_TEXTURE_2D);
		glColor3f(1.0f, 1.0f, 1.0f);	
		pWindow->Print(320, 5, T_EnterName, 0, 1);
	}
	glEnable(GL_DEPTH_TEST);
} // end ShowGameMenu()

void CheckGameMenu(void)
{ // begin CheckGameMenu()
	int i;

	if(g_lNow-lPressNewKeyTimer > 500)
	{
		lPressNewKeyTimer = g_lNow;
		bPressNewKeyText = !bPressNewKeyText;
	}
	if(!bGetPlayerName && !bGetNewKey)
	{
		if(ASKeyFirst[DIK_UP])
			byGameMenuSelected--;
		if(ASKeyFirst[DIK_DOWN])
			byGameMenuSelected++;
	}
	if(bAreYouSureQuestion)
	{
		bAreYouSureQuestion = FALSE;
		byGameMenuSelected = byGameMenuSelectedTemp;
		if(!bAreYouSureQuestionAnswer)
			return;
		goto StartNewGame;
	}
	switch(byGameMenuMenu)
	{
		case 0: // Main menu:
			if(byGameMenuSelected < 0)
				byGameMenuSelected = 4;
			else
				if(byGameMenuSelected >= 5)
					byGameMenuSelected = 0;
			if(ASKeyFirst[DIK_ESCAPE])
			{
				if(!bShowGameMenu)
					_AS->SetShutDown(TRUE);
				else
					bShowGameMenu = bPause = FALSE;
			}
			if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
			{ // Check what the player has selected:
				switch(byGameMenuSelected)
				{
					case 0: // New game:
						if(bShowGameMenu)
						{
							byLastGameMenuMenu = byGameMenuMenu;
							byGameMenuMenu = 1;
							byGameMenuSelectedTemp = byGameMenuSelected;
							byGameMenuSelected = 0;
							bAreYouSureQuestion = TRUE;
							bAreYouSureQuestionAnswer = FALSE;
							return;
						}
					StartNewGame:
						bInGameMenu = FALSE;
					break;

					case 1: // Options:
						byGameMenuMenu = 2;
						byGameMenuSelected = 0;
					break;

					case 2: // Help:
						if(_ASConfig->bFullScreen)
						{ // Switch to window mode:
							_ASConfig->bFullScreen = FALSE;
							ChangeDisplayMode();
						}
						OpenHelp();
					break;

					case 3: // Credits:
					break;

					case 4: // Quit:
						_AS->SetShutDown(TRUE);
					break;
				}
			}
		break;

		case 1: // Are you sure question:
			if(byGameMenuSelected < 0)
				byGameMenuSelected = 1;
			else
				if(byGameMenuSelected >= 2)
					byGameMenuSelected = 0;
			if(ASKeyFirst[DIK_ESCAPE])
			{
				bAreYouSureQuestionAnswer = FALSE;
				byGameMenuSelected = 0;
				byGameMenuMenu = byLastGameMenuMenu;
			}
			if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
			{
				if(!byGameMenuSelected)
					bAreYouSureQuestionAnswer = TRUE;
				else
					bAreYouSureQuestionAnswer = FALSE;
				byGameMenuSelected = 0;
				byGameMenuMenu = byLastGameMenuMenu;
			}
		break;

		case 2: // Options:
			if(byGameMenuSelected < 0)
				byGameMenuSelected = 1;
			else
				if(byGameMenuSelected >= 2)
					byGameMenuSelected = 0;
			if(ASKeyFirst[DIK_ESCAPE])
			{
				byGameMenuSelected = 0;
				byGameMenuMenu = 0;
				break;
			}
			if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
			{ // Check what the player has selected:
				ASKeyFirst[DIK_SPACE] = ASKeyFirst[DIK_RETURN] = FALSE;
				switch(byGameMenuSelected)
				{
					case 0: // Setup keys
						byGameMenuSelected = 0;
						byGameMenuMenu = 3;
						bGetNewKey = FALSE;
					break;

					case 1: // Other options
						SendMessage(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), WM_COMMAND, ID_OPTIONS_CONFIG, 0);
					break;
				}
			}
		break;

		case 3: // Setup keys:
			if(byGameMenuSelected < 0)
				byGameMenuSelected = 16;
			else
				if(byGameMenuSelected >= 17)
					byGameMenuSelected = 0;
			if(ASKeyFirst[DIK_ESCAPE])
			{
				if(bGetNewKey)
					bGetNewKey = FALSE;
				else
				{
					byGameMenuSelected = 0;
					byGameMenuMenu = 2;
				}
				break;
			}
			if(bGetNewKey)
			{
				for(i = 0; i < 256; i++)
				{
					if(!ASKeyFirst[i])
						continue;
					// Set the new key:
					switch(byGameMenuSelected)
					{
						case 0: _ASConfig->iLeftKey[0] = i; break;
						case 1: _ASConfig->iRightKey[0] = i; break;
						case 2: _ASConfig->iUpKey[0] = i; break;
						case 3: _ASConfig->iDownKey[0] = i; break;
						case 4: _ASConfig->iShotKey[0] = i; break;
						case 5: _ASConfig->iChangePerspectiveKey[0] = i; break;
						case 6: _ASConfig->iStandartViewKey[0] = i; break;
						case 7: _ASConfig->iPauseKey[0] = i; break;
						case 8: _ASConfig->iLevelRestartKey[0] = i; break;
						case 9: _ASConfig->iAfterburnerKey[0] = i; break;
						case 10: _ASConfig->iRollLeftKey[0] = i; break;
						case 11: _ASConfig->iRollRightKey[0] = i; break;
						case 12: _ASConfig->iFullStopKey[0] = i; break;
						case 13: _ASConfig->iSlideKey[0] = i; break;
						case 14: _ASConfig->iForwardKey[0] = i; break;
						case 15: _ASConfig->iBackwardKey[0] = i; break;
						case 16: _ASConfig->iSelectTargetKey[0] = i; break;
						case 17: _ASConfig->iHudKey[0] = i; break;
					}
					bGetNewKey = FALSE;
					_ASConfig->Check();
				}
			}
			else
			{
				if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
				{ // Check what the player has selected:
					if(byGameMenuSelected == 18)
					{ // Set all key to standart:
						_ASConfig->iLeftKey[0] = STANDART_LEFT_KEY;
						_ASConfig->iRightKey[0] = STANDART_RIGHT_KEY;
						_ASConfig->iUpKey[0] = STANDART_UP_KEY;
						_ASConfig->iDownKey[0] = STANDART_DOWN_KEY;
						_ASConfig->iShotKey[0] = STANDART_SHOT_KEY;
						_ASConfig->iChangePerspectiveKey[0] = STANDART_CHANGE_PERSPECTIVE_KEY;
						_ASConfig->iStandartViewKey[0] = STANDART_STANDART_VIEW_KEY;
						_ASConfig->iPauseKey[0] = STANDART_PAUSE_KEY;
						_ASConfig->iLevelRestartKey[0] = STANDART_LEVEL_RESTART_KEY;
						_ASConfig->iAfterburnerKey[0] = STANDART_AFTERBURNER_KEY;
						_ASConfig->iRollLeftKey[0] = STANDART_ROLL_LEFT_KEY;
						_ASConfig->iRollRightKey[0] = STANDART_ROLL_RIGHT_KEY;
						_ASConfig->iFullStopKey[0] = STANDART_FULL_STOP_KEY;
						_ASConfig->iSlideKey[0] = STANDART_SLIDE_KEY;
						_ASConfig->iForwardKey[0] = STANDART_FORWARD_KEY;
						_ASConfig->iBackwardKey[0] = STANDART_BACKWARD_KEY;
						_ASConfig->iSelectTargetKey[0] = STANDART_SELECT_TARGET_KEY;
						_ASConfig->iHudKey[0] = STANDART_HUD_KEY;
						_ASConfig->Check();
					}
					else // Get the new key:
						bGetNewKey = TRUE;
				}
			}
		break;
	}
} // end CheckGameMenu()
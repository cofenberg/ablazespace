//-----------------------------------------------------------------------------
// File: Game.h
//-----------------------------------------------------------------------------

#ifndef __AS_GAME_H__
#define __AS_GAME_H__


// Definitions: ***************************************************************
#define GAME_TEXTURES 22
#define CAUST_1_STEPS 32
#define MODELS 5
///////////////////////////////////////////////////////////////////////////////
// Standart keys:
#define	STANDART_LEFT_KEY 203
#define	STANDART_RIGHT_KEY 205
#define	STANDART_UP_KEY 200
#define	STANDART_DOWN_KEY 208
#define	STANDART_SHOT_KEY 57
#define	STANDART_LEVEL_RESTART_KEY 87
#define	STANDART_CHANGE_PERSPECTIVE_KEY 60
#define	STANDART_PAUSE_KEY 25
#define	STANDART_STANDART_VIEW_KEY 76
#define	STANDART_AFTERBURNER_KEY 15
#define STANDART_ROLL_LEFT_KEY 211
#define STANDART_ROLL_RIGHT_KEY 209
#define STANDART_FULL_STOP_KEY 207
#define STANDART_SLIDE_KEY 157
#define STANDART_FORWARD_KEY 16
#define STANDART_BACKWARD_KEY 17
#define STANDART_SELECT_TARGET_KEY 14
#define	STANDART_HUD_KEY 35
// Static particle systems:
enum
{
	PS_PLAYER_SHIP_MAIN_ENGINE, PS_PLAYER_SHIP_RIGHT_ENGINE, PS_PLAYER_SHIP_LEFT_ENGINE,
	PS_PLAYER_SHIP_RIGHT_BOTTOM_ENGINE, PS_PLAYER_SHIP_LEFT_BOTTOM_ENGINE,
	PS_PLAYER_SHIP_BACKWARD_ENGINE, PS_PLAYER_SHIP_TOP_ENGINE, PS_PLAYER_SHIP_BOTTOM_ENGINE,
	PS_PLAYER_SHIP_TOP_FRONT_ENGINE, PS_PLAYER_SHIP_BOTTOM_FRONT_ENGINE, PS_PLAYER_CROSSHAIR,
	PS_CENTER_ABLAZE,
};
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern AS_TEXTURE GameTexture[GAME_TEXTURES];	// The game textures
extern AS_TEXTURE Caust1Texture[CAUST_1_STEPS];
extern AS_PARTICLE_MANAGER ParticleManager;
extern AS_MD2_MODEL *pPlayerShipHull, *pPlayerShipGlass, *pPlayerShipPilot,
					 *pAsteroid, *pWeaponPhaser;
extern int GAME_WINDOW_ID;
extern GLuint iAsteroidBeltList, iSphereList, iEnvironmentSphereList;
extern AS_CAMERA CameraBackup[2];
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern HRESULT Game(void);
extern void LoadGameTextures(void);
extern HRESULT GameLoop(void);
extern HRESULT GameDraw(AS_WINDOW *);
extern HRESULT GameCheck(AS_WINDOW *);
extern void UpdateAllTextures(void);
extern void UpdateRenderQuality(void);
extern void CreateGameLists(void);
extern void DestroyGameLists(void);
extern void InitGameObjects(void);
extern void DestroyGameObjects(void);
extern void InitGameParticleSystems(void);
extern void DestroyGameParticleSystems(void);
extern void MakeFlare(float, float, float, float, float, float, float);
extern void DrawFlares(void);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_GAME_H__
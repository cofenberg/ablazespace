Subscape ist momentan noch weit von einem Spiel entfent... ist bisher nur nen looser Code zu Test-
Zwecken... aber das fertige Spiel wird sicher nicht schlechter aussehen...


Mouse: Move camera

Keys:
F2 - Pilot/Third person view
Numpad5 - Reset Camera
q = Accelerate
w = Backward
TAB - Afterburner
Cursor keys: Move
Str + cursor keys: Strafe
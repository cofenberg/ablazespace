//-----------------------------------------------------------------------------
// File: Environment.h
//-----------------------------------------------------------------------------

#ifndef __AS_ENVIRONMENT_H__
#define __AS_ENVIRONMENT_H__


// Classes: *******************************************************************
typedef class ENVIRONMENT
{
	public:
		// Environment sphere:
		short iSphereAniStep;
		long lSphereAniTime;
		float fSphereRadius, fSphereColor, fLastSphereColor, fNewSphereColor,
			  fSphereColorSpeed;
		// The ablaze in the center of the sphere:
		float fAblazeBox[2][3];

		ENVIRONMENT(void);
		void SetupLights(void);
		void Draw(void);
		void Check(void);
		void DrawSkyCube(void);

} ENVIRONMENT;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern ENVIRONMENT Environment;
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_ENVIRONMENT_H__
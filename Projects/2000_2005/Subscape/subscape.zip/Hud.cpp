//-----------------------------------------------------------------------------
// File: Hud.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
RADAR Radar;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
void DrawHud(AS_WINDOW *);
///////////////////////////////////////////////////////////////////////////////


// RADAR functions: ***********************************************************
// Setup the radar:
void RADAR::SetupHud(void)
{ // begin RADAR::SetupHud()
	vCenter.fX = _ASConfig->iWindowWidth/2.0f;
	vCenter.fY = _ASConfig->iWindowHeight/8.0f;
	fRadius = _ASConfig->iWindowHeight/8.0f-10.0f;
} // end RADAR::SetupHud()

// Compute the two-D radar coordinates of an object:
void RADAR::GetRadarCoord(AS_3D_VECTOR vPos, AS_2D_VECTOR *vRadarPos)
{ // begin RADAR::GetRadarCoord()
	float fRadarR, fT, fRadarCOS, fRadarSIN, fRT;
	ACTOR *pPlayer = &Player.Actor;
	AS_3D_VECTOR vDeltaPos, vV;

	// Compute coords of object relative to player:
	vDeltaPos = vPos-pPlayer->vWorldPos;
	
	// Normalize that:
	vDeltaPos.Normalize();
	
	// Distance of blip from center of radar is cosine of angle
	// between view direction and direction to object:
	fRadarR = pPlayer->vDirectionVector.DotProduct(vDeltaPos);
	
	// Find magnitude of projection of fDeltaPos onto view vector:
	fT = fRadarR;
	
	// Determine projection of object on plane perpendicular
	// to viewing plane:
	vV = vDeltaPos+pPlayer->vDirectionVector*(-fT);
	
	// Handle special case of null fV2, meaning object is on
	// line of sight:
	if(vV.IsNull())
	{
		(*vRadarPos) = vCenter;
		return;
	}
	
	// Else normalize fV2:
	vV.Normalize();
	
	// fV2 is now a vector from player's viewpoint to projection
	// of object on the player's plane.  Compute angle from player's
	// up vector to object:
	fRadarSIN = pPlayer->vRightVector.DotProduct(vV);;
	fRadarCOS = pPlayer->vUpVector.DotProduct(vV);
	
	// Convert to cartesian:
	fRT = (1.0f-fRadarR)/2.0f;
	(*vRadarPos).fX = vCenter.fX+fRadius*(-fRT)*fRadarSIN*1.5f;
	(*vRadarPos).fY = vCenter.fY+fRadius*fRT*fRadarCOS;
} // end RADAR::GetRadarCoord()

// Display the Wing Commander-like radar:
void RADAR::Draw(void)
{ // begin RADAR::Draw()
	AS_2D_VECTOR vRadarPos, vPos2D;
	AS_3D_VECTOR vPos, vWorldPosT;
	ACTOR *pActorT;
	int i;
	
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_CULL_FACE);


	// Draw direction arrows:
	// Arrow pointing to the center ablaze:
	glColor4f(1.0f, 1.0f, 1.0f, 0.9f);
	GetRadarCoord(vWorldPosT, &vPos2D);
	vPos2D -= Radar.vCenter;
	DrawTargetArrow(vPos2D);

	// Draw direction arrow to the current selected actor:
	if(Player.iFixedTargetID != -1)
	{
		glColor4f(1.0f, 0.0f, 0.0f, 0.9f);
		GetRadarCoord(Actor[Player.iFixedTargetID].vWorldPos, &vPos2D);
		vPos2D -= Radar.vCenter;
		DrawTargetArrow(vPos2D);
	}

	// Draw the radar itself:
	glColor4f(1.0f, 1.0f, 1.0f, 0.9f);
	glLoadIdentity();
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	glOrtho(0.0, ((double) _ASConfig->iWindowWidth), 0.0,
			((double) _ASConfig->iWindowHeight), -1.0, 1.0);
	glTranslatef((float) pCamera->vShakePos.fX*500*Player.fAfterburnerPower,
				 (float) pCamera->vShakePos.fY*500*Player.fAfterburnerPower,
				 0.0f);

	// Draw the radar bitmap:
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, GameTexture[21].iOpenGLID);
	glEnable(GL_BLEND);
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f);
		glVertex2f(vCenter.fX-fRadius*1.5f, vCenter.fY-fRadius);
		glTexCoord2f(1.0f, 0.0f);
		glVertex2f(vCenter.fX+fRadius*1.5f, vCenter.fY-fRadius);
		glTexCoord2f(1.0f, 1.0f);
		glVertex2f(vCenter.fX+fRadius*1.5f, vCenter.fY+fRadius);
		glTexCoord2f(0.0f, 1.0f);
		glVertex2f(vCenter.fX-fRadius*1.5f, vCenter.fY+fRadius);
	glEnd();
	glDisable(GL_TEXTURE_2D);


	// Draw radar points:
	// Center ablaze:
	glColor4f(1.0f, 1.0f, 1.0f, 0.9f);
	glPointSize(8.0f);
	Radar.GetRadarCoord(vWorldPosT, &vPos2D);
	glBegin(GL_POINTS);
		glVertex2f(vPos2D.fX, vPos2D.fY);
	glEnd();
	
	// Actors:
	glColor4f(0.0f, 1.0f, 1.0f, 0.9f);
	glPointSize(4.0f);
	glBegin(GL_POINTS);
		for(i = 0; i < MAX_ACTORS; i++)
		{
			pActorT = &Actor[i];
			if(!pActorT->bActive)
				continue;
			Radar.GetRadarCoord(pActorT->vWorldPos, &vPos2D);
			switch(pActorT->byType)
			{
				case ACTOR_ASTEROID:
					glColor4f(0.0f, 1.0f, 1.0f, 0.9f);
					glPointSize(2.0f);
				break;

				case ACTOR_PHASER_SHOT:
					glColor4f(0.0f, 0.0f, 1.0f, 0.9f);
					glPointSize(1.0f);
				break;
			}
			glVertex2f(vPos2D.fX, vPos2D.fY);
		}
	glEnd();


	glEnable(GL_BLEND);
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_CULL_FACE);
	glEnable(GL_DEPTH_TEST);
	ASEnableLighting();
	glEnable(GL_TEXTURE_2D);
	glPointSize(1.0f);
} // end RADAR::Draw()

// Draw an arrow pointing in an given direction:
void RADAR::DrawTargetArrow(AS_2D_VECTOR vPos)
{ // begin RADAR::DrawTargetArrow()
	float fAngle, fM[16];
	
	// Should the arrow be shown?
	if(vPos.fX > -0.3f && vPos.fY > -0.3f &&
	   vPos.fX < 0.3f && vPos.fY < 0.3f)
	   return; // No, the point is in the players view
	glGetFloatv(GL_MODELVIEW_MATRIX, fM);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);
	glDisable(GL_CULL_FACE);
	glDisable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glLineWidth(1.0f);
	
	// Get arrow angle:
	if(vPos.fX != 0)
	{
		if(vPos.fX > 0)
			fAngle = (float) (atan(vPos.fY/vPos.fX)*RAD_TO_DEG);
		else
			fAngle = (float) ((atan(vPos.fY/vPos.fX)*RAD_TO_DEG)-180.0f);
	}
	
	// Setup arrow:
	glRotatef(fAngle, 0.0f, 0.0f, 1.0f);
	glTranslatef(0.5f, 0.0f, -8.0f);
	
	// Draw arrow:
	glBegin(GL_LINES);
		glVertex3f(0.0f, 0.1f, 0.0f);
		glVertex3f(0.3f, 0.0f, 0.0f);
		glVertex3f(0.0f, -0.1f, 0.0f);
		glVertex3f(0.3f, 0.0f, 0.0f);
		glVertex3f(0.0f, -0.1f, 0.0f);
		glVertex3f(0.0f, 0.1f, 0.0f);
	glEnd();

	glLoadMatrixf(fM);
} // end RADAR::DrawTargetArrow()
///////////////////////////////////////////////////////////////////////////////


void DrawHud(AS_WINDOW *pWindow)
{ // begin DrawHud()
	int iX, iY;
	char byTemp[256];
	float fPower;

	if(!Setup.bShowHud)
		return; // The hud isn't active
	
	// Draw the radar:
	glEnable(GL_POINT_SMOOTH);
	glEnable(GL_LINE_SMOOTH);
	Radar.Draw();
	glDisable(GL_POINT_SMOOTH);
	glDisable(GL_LINE_SMOOTH);
	
	glLoadIdentity();
	glTranslatef(pCamera->vShakePos.fX*Player.fAfterburnerPower*5,
				 pCamera->vShakePos.fY*Player.fAfterburnerPower*5,
				 pCamera->vShakePos.fZ*Player.fAfterburnerPower*5);
	glEnable(GL_TEXTURE_2D);
	glColor4f(1.0f, 1.0f, 1.0f, 0.9f);
	glDisable(GL_CULL_FACE);
	glEnable(GL_TEXTURE_2D);
	
	// Draw the info console in the middle of the screen:
	glBindTexture(GL_TEXTURE_2D, GameTexture[19].iOpenGLID);
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  -8.0f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f, -1.0f,  -8.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f,  -8.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f,  -8.0f);
	glEnd();
	
	// Show afterburner power:
	fPower = Player.fAfterburnerEngine/Player.fMaxAfterburnerEngine;
	glBindTexture(GL_TEXTURE_2D, GameTexture[20].iOpenGLID);
	glTranslatef(0.0f, -1.0f, 0.0f);
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f, 0.0f,  -8.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f, 0.0f,  -8.0f);
		glTexCoord2f(1.0f, 1.0f-fPower); glVertex3f( 1.0f, fPower*2,  -8.0f);
		glTexCoord2f(0.0f, 1.0f-fPower); glVertex3f(-1.0f, fPower*2,  -8.0f);
	glEnd();
	
	glEnable(GL_CULL_FACE);

	iX = (int) (pCamera->vShakePos.fX*500*Player.fAfterburnerPower);
	iY = (int) (pCamera->vShakePos.fY*500*Player.fAfterburnerPower);
	glColor4f(1.0f, 1.0f, 1.0f, 0.9f);

	// Show afterburner engine:
	sprintf(byTemp, "%.0f",Player.fAfterburnerEngine);
	pWindow->Print(230+iX, 240+iY, byTemp, 0, 1);

	// Show player velocity:
	sprintf(byTemp, "%.0f", Player.Actor.vWorldVelocity.GetLength());
	pWindow->Print(315+iX, 180+iY, byTemp, 0, 1);

	// Show distance to selectet target:
	if(Player.iTargetID != -1)
	{
		sprintf(byTemp, "%.0f",Player.fTargetDistance);
		pWindow->Print(315+iX, 280+iY, byTemp, 0, 1);
	}

	// Show distance to fixed target:
	if(Player.iFixedTargetID != -1)
	{
		glColor4f(1.0f, 0.0f, 0.0f, 0.9f);
		sprintf(byTemp, "%.0f",Player.fFixedTargetDistance);
		pWindow->Print(315+iX, 230+iY, byTemp, 0, 1);
	}
} // end DrawHud()
//-----------------------------------------------------------------------------
// File: Intro.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"



typedef struct TUNNEL_PATH
{
	FLOAT3 fPos;
	TUNNEL_PATH *pNext;

} TUNNEL_PATH;

TUNNEL_PATH TunnelPath[18] =
{
	{ {0, 0, 0}, &TunnelPath[1] },
	{ {20, 10, 0}, &TunnelPath[2] },
	{ {40, 0, 0}, &TunnelPath[3] },
	{ {60, 10, 0}, &TunnelPath[4] },
	{ {80, 0, 10}, &TunnelPath[5] },
	{ {100, 10, 10}, &TunnelPath[6] },
	{ {120, 10.5, 0}, &TunnelPath[7] },
	{ {140, 0, 0}, &TunnelPath[8] },
	{ {160, 10, 0}, &TunnelPath[9] },
	{ {180, 0, 0}, &TunnelPath[10] },
	{ {200, 0, 10}, &TunnelPath[11] },
	{ {220, 10, 0}, &TunnelPath[12] },
	{ {240, 0, 10}, &TunnelPath[13] },
	{ {260, 0, 10}, &TunnelPath[14] },
	{ {280, 10, 0}, &TunnelPath[15] },
	{ {300, 0, 2}, &TunnelPath[16] },
	{ {320, 10, 0}, &TunnelPath[17] },
	{ {340, 0, 20}, NULL},
};


// Camera variables
float fTunnelT;
TUNNEL_PATH *pTunnelPos;

short iTunnelAniStep;
long lTunnelAniTimer, lTunnelLightTimer;
float alpha=0;
float fTunnelLight, fTunnelLightNew, fTunnelLightLast;
float fTunnelLightSpeed;

#define TUNNEL_PARTS 15

// Tunnel Drawing Variables
int tFlag=0;
FLOAT3 fPrevPoints[TUNNEL_PARTS];

// Modes
float ModeX=0;
int ModeXFlag=0;


// Variables: *****************************************************************
BOOL bPlayIntro;
FLOAT3 fTunnel[30];
float fTunnelAngle;
FLOAT3 fGMPerspective, fGMPerspectiveVelocity, fGMPerspectiveTo, fGMPerspectiveLast;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
HRESULT IntroLoop(void);
HRESULT IntroDraw(AS_WINDOW *);
HRESULT IntroCheck(AS_WINDOW *);
BOOL ComputeTunnelPos(TUNNEL_PATH *, float, FLOAT3 *);
void DrawTunnel(void);
void SplashTunnel(void);
void CheckPerspective(void);
void SetTunnelPerspective(void);
///////////////////////////////////////////////////////////////////////////////
AS_TEXTURE BlurTexture;
void CreateBlurTexture(void);
void DestroyBlurTexture(void);

void CreateBlurTexture(void)
{ // begin CreateBlurTexture()
	UINT *piData;

	// Create storage space for texture data (128x128x4)
	piData = (UINT *) new UINT[((128*128)*4*sizeof(UINT))];
	memset(piData, 0, sizeof(UINT)*128*128*4);

	glGenTextures(1, &BlurTexture.iOpenGLID);
	glBindTexture(GL_TEXTURE_2D, BlurTexture.iOpenGLID);
	glTexImage2D(GL_TEXTURE_2D, 0, 4, 128, 128, 0, GL_RGBA, GL_UNSIGNED_BYTE, piData);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	delete [] piData;
} // end CreateBlurTexture()

void DestroyBlurTexture(void)
{ // begin DestroyBlurTexture()
	glDeleteTextures(1, &BlurTexture.iOpenGLID);
} // end DestroyBlurTexture()

HRESULT IntroLoop(void)
{ // begin IntroLoop()
	MSG msg;

	_AS->pWindow[GAME_WINDOW_ID].SetDrawFunction(IntroDraw);
	_AS->pWindow[GAME_WINDOW_ID].SetCheckFunction(IntroCheck);

	InitGameParticleSystems();
	ASDXShowClose();
	Sleep(1); // If this isn't done the system will crash... maybe an windows message error??
	_AS->bDraw = TRUE;


	for(int i = 0; i < 3; i++)
		fGMPerspective[i] = fGMPerspectiveVelocity[i] =
		fGMPerspectiveTo[i] = fGMPerspectiveLast[i] = 0.0f;
	pTunnelPos = &TunnelPath[0];
	pCamera->fPos[Z] = -15.0f;


	bPlayIntro = TRUE;

	// Go into the game loop:
	_AS->WriteLogMessage("Enter the intro loop");
	CreateBlurTexture();
	for(;;)
	{
		if(PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
    	{
        	if(!GetMessage(&msg, NULL, 0, 0))
                break;
        	TranslateMessage(&msg);
        	DispatchMessage(&msg);
    	}
		else
		{	
			if(_AS->GetShutDown() || _AS->CheckModuleChange() || !bPlayIntro)
				PostQuitMessage(0);
			if(!_AS->GetActive())
				continue;
			_AS->UpdateWindows();
		}
	}
	DestroyBlurTexture();

	_AS->WriteLogMessage("Left the intro loop");
	bInGameMenu	= TRUE;
	_AS->bDraw = FALSE;

	return msg.wParam;
} // end IntroLoop()

HRESULT IntroDraw(AS_WINDOW *pWindow)
{ // begin IntroDraw()
	if(!_AS->bDraw)
		return 0;



	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glViewport(0, 0, 128, 128);	// Set our viewport (match texture size)

	SetTunnelPerspective();
	glDisable(GL_BLEND);
	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);
	glDisable(GL_LIGHTING);
	glColor3f(0.2f, 0.2f, 0.2f);
	glCallList(iAsteroidBeltList);

	ASEnableLighting();
	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);
	glDisable(GL_LIGHTING);
	glDisable(GL_BLEND);
	glEnable(GL_TEXTURE_2D);


	glLoadIdentity();
	glBindTexture(GL_TEXTURE_2D, GameTexture[18].iOpenGLID);

	glCullFace(GL_FRONT);

	glBindTexture(GL_TEXTURE_2D, BlurTexture.iOpenGLID); // Bind to the blur texture
	// Copy our viewport to the blur texture (from 0,0 to 128,128... no border)
	glCopyTexImage2D(GL_TEXTURE_2D, 0, GL_LUMINANCE, 0, 0, 128, 128, 0);

	// Now draw the real visible stuff:
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glViewport(0, 0, _ASConfig->iWindowWidth, _ASConfig->iWindowHeight);



	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


	SetTunnelPerspective();
	glDisable(GL_BLEND);
	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);
	glDisable(GL_LIGHTING);
	glColor3f(0.2f, 0.2f, 0.2f);
	glCallList(iAsteroidBeltList);

	ASEnableLighting();
	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);
	glDisable(GL_LIGHTING);
	glDisable(GL_BLEND);
	glEnable(GL_TEXTURE_2D);


	glLoadIdentity();
	glBindTexture(GL_TEXTURE_2D, GameTexture[18].iOpenGLID);

	glCullFace(GL_FRONT);
	DrawTunnel();
	SplashTunnel();

	

	glPushMatrix();
	ASEnableLighting();

	_ASCamera->SetCameraTranslation(FALSE);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.f+fGMPerspective[0]/5,
				   (GLfloat)(_ASConfig->iWindowWidth+fGMPerspective[1]/5)/
				   (GLfloat)(_ASConfig->iWindowHeight+fGMPerspective[2]/5),
				   0.1f, 1000.0f);
	glMatrixMode(GL_MODELVIEW);

	// Main level light:
	GLfloat afLightData[4]  = {0.0f, 0.0f, 0.0f, 0.0f};
	afLightData[0] = 0.0f;
	afLightData[1] = 0.0f;
	afLightData[2] = 0.0f;
	afLightData[3] = 1.0f;
	glLightfv(GL_LIGHT1, GL_POSITION, afLightData);
	afLightData[0] = 1.0f;
	afLightData[1] = 1.0f;
	afLightData[2] = 1.0f;
	afLightData[3] = 1.0f;
	glLightfv(GL_LIGHT1, GL_AMBIENT, afLightData);
	glEnable(GL_LIGHT1);
	_AS->iActiveLights += 2;
	glClear(GL_DEPTH_BUFFER_BIT);
	glDisable(GL_FOG);
	DrawPlayerSolid();

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.f+fGMPerspective[0]/5,
				   (GLfloat)(_ASConfig->iWindowWidth+fGMPerspective[1]/5)/
				   (GLfloat)(_ASConfig->iWindowHeight+fGMPerspective[2]/5),
				   0.1f, 1000.0f);
	glMatrixMode(GL_MODELVIEW);
	DrawPlayerTransparent();
		// Now draw the blur around the alien:
		glDisable(GL_DEPTH_TEST);
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);
		glBindTexture(GL_TEXTURE_2D, BlurTexture.iOpenGLID);
		glMatrixMode(GL_PROJECTION);
		glPushMatrix();
		glLoadIdentity();
		glOrtho(0, _ASConfig->iWindowWidth, _ASConfig->iWindowHeight, 0, -1, 1);
		glMatrixMode(GL_MODELVIEW);
		glPushMatrix();
		glLoadIdentity();		

		float fInc = 0.03f, fSpost = 0.0f, fAlphainc = 0.9f/15, fAlpha = 0.4f;
		fAlphainc = fAlpha/15;
		glBegin(GL_QUADS);
			for(int i = 0; i < 15; i++)
			{
				glColor4f(1.0f, 1.0f, 1.0f, fAlpha);
				glTexCoord2f(0.0f+fSpost, 1.0f-fSpost);
				glVertex2f(0.0f, 0.0f);
				glTexCoord2f(0.0f+fSpost, 0.0f+fSpost);
				glVertex2f(0.0f, (float) _ASConfig->iWindowHeight);
				glTexCoord2f(1.0f-fSpost, 0.0f+fSpost);
				glVertex2f((float) _ASConfig->iWindowWidth, (float) _ASConfig->iWindowHeight);
				glTexCoord2f(1.0f-fSpost, 1.0f-fSpost);
				glVertex2f((float) _ASConfig->iWindowWidth, 0.0f);
				fSpost += fInc;
				fAlpha -= fAlphainc;
			}
		glEnd();

		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		glViewport(0, 0, _ASConfig->iWindowWidth, _ASConfig->iWindowHeight);
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		gluPerspective(45.f, (GLfloat)_ASConfig->iWindowWidth/(GLfloat)_ASConfig->iWindowHeight, 0.1f, 1000.0f);
		glMatrixMode(GL_MODELVIEW);
		glDisable(GL_DEPTH_TEST);
		glLoadIdentity();

	ASSwapBuffers(*pWindow->GethDC(), pWindow, TRUE);
	glPopMatrix();
	return 0;
} // end IntroDraw()

HRESULT IntroCheck(AS_WINDOW *pWindow)
{ // begin IntroCheck()
	short i;
	
	_AS->ReadDXInput(*pWindow->GethWnd());
	if(ASKeyFirst[DIK_ESCAPE])
	{
			bPlayIntro = FALSE;
//		_AS->SetShutDown(TRUE);
	}
	CheckPlayer();
	Environment.Check();

	for(i = 0; i < 256; i++)
		if(ASKeyFirst[i])
		{
//			bPlayIntro = FALSE;
			break;
	}
	return 0;
} // end IntroCheck()

BOOL ComputeTunnelPos(TUNNEL_PATH *pPos, float fTime, FLOAT3 *fRes)
{ // begin ComputeTunnelPos()
	FLOAT3 fP4[4];
	short i;
	
	if(pPos->pNext->pNext->pNext)
	{
		for(i = 0; i < 4; i++)
		{
			fP4[i][X] = pPos->fPos[X];
			fP4[i][Y] = pPos->fPos[Y];
			fP4[i][Z] = pPos->fPos[Z];
			pPos = pPos->pNext;
		}
	} 
	else
	{
		// End of tunnel
		ModeX = 1.0;
		ModeXFlag = 0;
		return 1;
	}
	ASCatmullRom(fP4, fTime, fRes);
	return 0;
} // end ComputeTunnelPos()

void DrawTunnel(void)
{
	TUNNEL_PATH *pPos, *pTunnelPosT;
	FLOAT3 fCurrentPos, fNextPos, T, op2;
	float t;
	int i, j, k, flag;
	FLOAT3 fPoints[TUNNEL_PARTS];
	GLfloat light_position[4];

	// Animate	the caust:
	if(g_lNow-lTunnelAniTimer > 30)
	{
		lTunnelAniTimer = g_lNow;
		iTunnelAniStep++;
		if(iTunnelAniStep >= CAUST_1_STEPS)
			iTunnelAniStep = 0;
	}
	
	// Animate the tunnel light:
	if(fTunnelLightLast < fTunnelLightNew)
	{
		fTunnelLight += ((float) g_lDeltatime/500)*fTunnelLightSpeed;
		if(fTunnelLight >= fTunnelLightNew)
			goto IniNewTunnelLight;
	}
	else
	{
		fTunnelLight -= ((float) g_lDeltatime/500)*fTunnelLightSpeed;
		if(fTunnelLight <= fTunnelLightNew)
		{
		IniNewTunnelLight:
			fTunnelLightLast = fTunnelLight;
			fTunnelLightNew = (float) 0.3f+(rand() % 100)/130.0f;
			fTunnelLightSpeed = (float) (rand() % 1000)/800.0f;
		}
	}
	CheckPerspective();
	
	// Get current curve:
	if(ComputeTunnelPos(pTunnelPos, fTunnelT, &fCurrentPos))
		return;

	// Next camera position
	pTunnelPosT = pTunnelPos;
	fTunnelT += ((float) g_lDeltatime/25000);
	if(fTunnelT >= 1)
	{
		fTunnelT = fTunnelT-1;
		pTunnelPosT = pTunnelPos->pNext;
	}
		
	// Get curve for next camera position
	if(ComputeTunnelPos(pTunnelPosT, fTunnelT, &fNextPos))
		return;
	
	ASEnableLighting();
	// Rotate camera
	glRotatef(alpha, 0, 0, -1);
	alpha += (float) g_lDeltatime/50;
	gluLookAt(fCurrentPos[X], fCurrentPos[Y], fCurrentPos[Z], fNextPos[X], fNextPos[Y], fNextPos[Z], 0, 1, 0);

	// Set light position
	light_position[0] = fCurrentPos[X];
	light_position[1] = fCurrentPos[Y];
	light_position[2] = fCurrentPos[Z];
	light_position[3] = 1;
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);
	GLfloat light_ambient[] = {1.0, 1.0, 1.0, 1.0};
	GLfloat light_diffuse[] = {1.0, 1.0, 1.0, 1.0};
	GLfloat light_specular[] = {1.0, 1.0, 1.0, 1.0};
	
	for(i = 0; i < 3; i++)
	{
		light_ambient[i] *= fTunnelLight;
		light_diffuse[i] *= fTunnelLight;
		light_specular[i] *= fTunnelLight;
	}
	
	
	GLfloat fogColor[4] = {0.0, 0.0, 0.0, 1.0};
	glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
	glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);
	glFogi(GL_FOG_MODE, GL_EXP);
	glFogfv(GL_FOG_COLOR, fogColor);
	glFogf(GL_FOG_DENSITY, 0.3f);
	glEnable(GL_FOG);

	glEnable(GL_LIGHT0);

	pPos = pTunnelPos;
	flag = 0;
	t = 0;
	k = 0;
	// Draw tunnel from current curve and next 2 curves:
	while(k < 3)
	{
		if(ComputeTunnelPos(pPos, t, &fCurrentPos))
			return;

		t += 0.1f;
		if (t >= 1.0)
		{
			t = t - 1;
			k++;
			pPos = pPos->pNext;
		}
	
		if(ComputeTunnelPos(pPos, t, &fNextPos))
			return;

		T[X] = fNextPos[X]-fCurrentPos[X];
		T[Y] = fNextPos[Y]-fCurrentPos[Y];
		T[Z] = fNextPos[Z]-fCurrentPos[Z];
		ASNormalize(&T);
			
		fNextPos[X] = fCurrentPos[X];
		fNextPos[Y] = fCurrentPos[Y];
		fNextPos[Z] = fCurrentPos[Z]+0.25f;

		for(i = 0; i < TUNNEL_PARTS; i++)
		{
			ASRotateAroundLine(fNextPos, fCurrentPos, T, (float) (i*360.0f/TUNNEL_PARTS*PI/180.0f), &op2);
			fPoints[i][X] = op2[X];
			fPoints[i][Y] = op2[Y];
			fPoints[i][Z] = op2[Z];
			if(!flag)
			{
				fPrevPoints[i][X] = op2[X];
				fPrevPoints[i][Y] = op2[Y];
				fPrevPoints[i][Z] = op2[Z];
			}
		}
	
		if (!flag)
		{
			flag = 1;
			continue;
		}
		
		// Draw 10 polygons for current point
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);
		glEnable(GL_BLEND);
		for(short ii = 0; ii < 3; ii++)
		{
			switch(ii)
			{
				case 0:
					glColor4f(1.0f, 1.0f, 1.0f, 0.6f);
					glBindTexture(GL_TEXTURE_2D, GameTexture[18].iOpenGLID);
					glDisable(GL_TEXTURE_GEN_S);
					glDisable(GL_TEXTURE_GEN_T);
				break;

				case 1:
					glColor4f(1.0f, 1.0f, 1.0f, 0.7f);
					glBindTexture(GL_TEXTURE_2D, GameTexture[11].iOpenGLID);
					glEnable(GL_TEXTURE_GEN_S);
					glEnable(GL_TEXTURE_GEN_T);
				break;

				case 2:
					glColor4f(0.4f, 0.4f, 1.0f, 1.0f);
					glBindTexture(GL_TEXTURE_2D, Caust1Texture[iTunnelAniStep].iOpenGLID);
					glDisable(GL_TEXTURE_GEN_S);
					glDisable(GL_TEXTURE_GEN_T);
				break;
			}
	glBegin(GL_QUADS);
			for(i = 0; i < TUNNEL_PARTS; i++)
			{
				j = i+1;
				if(j > TUNNEL_PARTS-1)
					j = 0;
				glNormal3f(0, 0, 1); // Normal for lighting
				glTexCoord2f(0, 0); glVertex3f(fPrevPoints[i][X], fPrevPoints[i][Y], fPrevPoints[i][Z]);
				glNormal3f(0, 0, 1);
				glTexCoord2f(1, 0); glVertex3f(fPoints[i][X], fPoints[i][Y], fPoints[i][Z]);
				glNormal3f(0, 0, 1);
				glTexCoord2f(1, 1); glVertex3f(fPoints[j][X], fPoints[j][Y], fPoints[j][Z]);
				glNormal3f(0, 0, 1);
				glTexCoord2f(0, 1); glVertex3f(fPrevPoints[j][X], fPrevPoints[j][Y], fPrevPoints[j][Z]);
			}
	glEnd();
		}
		// Save current polygon coordinates for next position:
		for(i = 0; i < TUNNEL_PARTS; i++)
		{
			fPrevPoints[i][X] = fPoints[i][X];
			fPrevPoints[i][Y] = fPoints[i][Y];
			fPrevPoints[i][Z] = fPoints[i][Z];
		}
	}
	pTunnelPos = pTunnelPosT;
}

void SplashTunnel(void)
{
	if (ModeX > 0)
	{
		// Reset tunnel and camera position
		if (!ModeXFlag)
		{
			pTunnelPos = &TunnelPath[0];
			fTunnelT = 0.0f;
			tFlag = 0;
			ModeXFlag = 1;
		}
		// Now we want to draw splash screen
		glLoadIdentity();
		// Disable all unused features
		glDisable(GL_DEPTH_TEST);
		glDisable(GL_LIGHTING);
		glDisable(GL_FOG);
		glDisable(GL_CULL_FACE);

		glBlendFunc(GL_SRC_ALPHA, GL_DST_ALPHA);
		glEnable(GL_BLEND);
		glDisable(GL_TEXTURE_2D);
		glColor4f(1, 1, 1, ModeX);
		
		// Draw splash screen (simply quad)
		glBegin(GL_QUADS);
	    glVertex3f(-10, -10, -1);
	    glVertex3f(10, -10, -1);
	    glVertex3f(10, 10, -1);
	    glVertex3f(-10, 10, -1);
		glEnd();

		ModeX -= 0.05f;
		if (ModeX <= 0)	ModeX = 0;

		glEnable(GL_CULL_FACE);
		glEnable(GL_DEPTH_TEST);
		glEnable(GL_LIGHTING);
		glEnable(GL_FOG);
		glEnable(GL_TEXTURE_2D);
		glDisable(GL_BLEND);
		glColor4f(1, 1, 1, 1);
	}
}

void CheckPerspective(void)
{ // begin CheckPerspective()
	short i;

	// Create the perspective effect:
	if(fGMPerspectiveLast[0] > fGMPerspectiveTo[0])
	{
		fGMPerspectiveVelocity[0] -= (float) g_lDeltatime/10000;
		fGMPerspective[0] += fGMPerspectiveVelocity[0];
		if(fGMPerspective[0] <= fGMPerspectiveTo[0])
		{
			fGMPerspectiveVelocity[0] *= 0.6f;
			if(!(rand() % 2))
				fGMPerspectiveTo[0] = -(float) (rand() % 1000)/100;
			else
				fGMPerspectiveTo[0] = (float) (rand() % 1000)/100;
		}
	}
	else
	{
		fGMPerspectiveVelocity[0] += (float) g_lDeltatime/10000;
		fGMPerspective[0] += fGMPerspectiveVelocity[0];
		if(fGMPerspective[0] >= fGMPerspectiveTo[0])
		{
			fGMPerspectiveVelocity[0] *= 0.6f;
			if(!(rand() % 2))
				fGMPerspectiveTo[0] = -(float) (rand() % 1000)/100;
			else
				fGMPerspectiveTo[0] = (float) (rand() % 1000)/100;
		}
	}
	for(i = 1; i < 3; i++)
	{
		if(fGMPerspectiveLast[i] > fGMPerspectiveTo[i])
		{
			fGMPerspectiveVelocity[i] -= (float) g_lDeltatime/1000;
			fGMPerspective[i] += fGMPerspectiveVelocity[i];
			if(fGMPerspective[i] <= fGMPerspectiveTo[i])
			{
				fGMPerspectiveVelocity[i] *= 0.8f;
				if(!(rand() % 2))
					fGMPerspectiveTo[i] = -(float) (rand() % 1000)/5;
				else
					fGMPerspectiveTo[i] = (float) (rand() % 1000)/5;
			}
		}
		else
		{
			fGMPerspectiveVelocity[i] += (float) g_lDeltatime/1000;
			fGMPerspective[i] += fGMPerspectiveVelocity[i];
			if(fGMPerspective[i] >= fGMPerspectiveTo[i])
			{
				fGMPerspectiveVelocity[i] *= 0.8f;
				if(!(rand() % 2))
					fGMPerspectiveTo[i] = -(float) (rand() % 1000)/50;
				else
					fGMPerspectiveTo[i] = (float) (rand() % 1000)/50;
			}
		}
	}
} // end CheckPerspective()

void SetTunnelPerspective(void)
{ // begin SetTunnelPerspective()
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.f+fGMPerspective[0],
				   (GLfloat)(_ASConfig->iWindowWidth+fGMPerspective[1])/
				   (GLfloat)(_ASConfig->iWindowHeight+800.0f+fGMPerspective[2]),
				   0.1f, 1000.0f);
	glMatrixMode(GL_MODELVIEW);
} // end SetTunnelPerspective()
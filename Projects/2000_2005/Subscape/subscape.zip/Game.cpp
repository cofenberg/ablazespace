//-----------------------------------------------------------------------------
// File: Game.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"

// Variables: *****************************************************************
// Textures:
AS_TEXTURE GameTexture[GAME_TEXTURES];
AS_TEXTURE Caust1Texture[CAUST_1_STEPS];
// Particle systems:
AS_PARTICLE_MANAGER ParticleManager;
// Models:
AS_MD2_MODEL *pPlayerShipHull, *pPlayerShipGlass, *pPlayerShipPilot,
			 *pAsteroid, *pWeaponPhaser;
AS_MD2_MODEL **pModels[] = {&pPlayerShipHull, &pPlayerShipGlass, &pPlayerShipPilot,
						    &pAsteroid, &pWeaponPhaser};
// Lists:
GLuint iAsteroidBeltList, iSphereList, iEnvironmentSphereList;
// Other:
int GAME_WINDOW_ID;
AS_CAMERA CameraBackup[2];
///////////////////////////////////////////////////////////////////////////////

extern int iTemp;

// Functions: *****************************************************************
HRESULT Game(void);
void LoadGameTextures(void);
HRESULT GameLoop(void);
HRESULT GameDraw(AS_WINDOW *);
HRESULT GameCheck(AS_WINDOW *);
void UpdateAllTextures(void);
void UpdateRenderQuality(void);
void CreateGameLists(void);
void DestroyGameLists(void);
void InitGameObjects(void);
void DestroyGameObjects(void);
void InitGameParticleSystems(void);
void DestroyGameParticleSystems(void);
void MakeFlare(float, float, float, float, float, float, float);
void DrawFlares(void);
///////////////////////////////////////////////////////////////////////////////


HRESULT Game(void)
{ // begin Game()
	MSG msg;

	_AS->WriteLogMessage("Enter game module");
	_AS->bDraw = FALSE;
	
	// Create the game window and create the DirectInput stuff:
	_AS->ASCreateWindow(WindowProc, GAME_WINDOW_NAME, GAME_WINDOW_NAME, _ASConfig->iWindowWidth,
					    _ASConfig->iWindowHeight, LoadMenu(_AS->GetInstance(), MAKEINTRESOURCE(IDR_GAME)),
						_ASConfig->bFullScreen, GameMenuDraw, GameMenuCheck, NULL, TRUE);
	GAME_WINDOW_ID = _AS->GetWindows()-1;
	ASInitOpenGL(&_AS->pWindow[GAME_WINDOW_ID],
				 NULL,
				 _AS->pWindow[GAME_WINDOW_ID].GethDC(),
				 _AS->pWindow[GAME_WINDOW_ID].GethRC(), _ASConfig->bFullScreen);
	_AS->CreateDXInputDevices(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), FALSE, TRUE, TRUE, FALSE);
	_AS->CreateDXAudio(*_AS->pWindow[GAME_WINDOW_ID].GethWnd());
	ASCreatDXSoundManager(*_AS->pWindow[GAME_WINDOW_ID].GethWnd());
	ShowWindow(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), SW_SHOW);	

	// Load and create the game objects and textures:
	InitGameObjects();
	LoadGameTextures();
	ASGenOpenGLTextures(GAME_TEXTURES, GameTexture);
	ASGenOpenGLTextures(CAUST_1_STEPS, Caust1Texture);
	char byFilename[LOGOS_TEXTURES][256] = {"AS.jpg"};
	ASLoadTextures(byFilename, LOGOS_TEXTURES, LogosTexture);
	ASGenOpenGLTextures(LOGOS_TEXTURES, LogosTexture);
	CreateGameLists();
	InitGameParticleSystems();
	
	bShowLogos = TRUE;
	bInGameMenu	= TRUE;
	_AS->iActiveLights = 0;
	bShowGameMenu = 0;


	bPlayIntro = TRUE;
	bInGameMenu	= FALSE;


	_AS->WriteLogMessage("Enter game main loop");
	for(;;)
	{
		if(_AS->GetShutDown() || _AS->CheckModuleChange())
			break;
		if(bShowLogos)
			Logos();
		else
			if(bInGameMenu)
			{ // We are in the game menu:
				msg.wParam = GameMenuLoop();
			}
			else
			{ 
				if(bPlayIntro)
				{ // Play the intro:
					 msg.wParam = IntroLoop();
				}
				else
				{ // We are in the game:
					ASDXShowClose();
					msg.wParam = GameLoop();
					ASDXShowClose();
					byGameMenuMenu = 0;
				}
			}
	}
	_AS->WriteLogMessage("Left game main loop");

	ASDXShowClose();
	
	// Destroy the game objects and textures:
	DestroyGameObjects();
	ASDestroyOpenGLTextures(GAME_TEXTURES, GameTexture);
	ASDestroyTextures(GAME_TEXTURES, GameTexture);
	ASDestroyOpenGLTextures(CAUST_1_STEPS, Caust1Texture);
	ASDestroyTextures(CAUST_1_STEPS, Caust1Texture);
	ASDestroyOpenGLTextures(LOGOS_TEXTURES, LogosTexture);
	ASDestroyTextures(LOGOS_TEXTURES, LogosTexture);
	DestroyGameLists();
	DestroyGameParticleSystems();

	// Destroy the game window and the corresponding DirectInput stuff:
	_AS->FreeDXInputDevices();
	_AS->DestroyDXAudio();
	ASDestroyDXSoundManager();
	ASDestroyOpenGL(&_AS->pWindow[GAME_WINDOW_ID],
					NULL,
				    *_AS->pWindow[GAME_WINDOW_ID].GethDC(),
				    *_AS->pWindow[GAME_WINDOW_ID].GethRC());
	_AS->ASDestroyWindow(_AS->pWindow[GAME_WINDOW_ID].GethWnd(), GAME_WINDOW_NAME);
	
	// Left the game module:
	return msg.wParam;
} // end Game()

void LoadGameTextures(void)
{ // begin LoadGameTextures()
	char byFilename[GAME_TEXTURES][256] = {"AsteroidBelt.jpg", "Particle1.jpg",
										   "Monitor1.jpg", "Monitor2.jpg",
										   "Monitor3.jpg", "Monitor4.jpg",
										   "Monitor5.jpg", "Monitor6.jpg",
										   "Monitor7.jpg",										   
										   "PlayerShipHull.jpg", "PlayerShipGlass.jpg",
										   "PlayerShipEnvironment.jpg", 
										   "PlayerShipPilot.jpg", "Water.jpg",
										   "EngineParticle.jpg", "Crosshair.jpg",
										   "Asteroid.jpg", "Ablaze.jpg",
										   "Tunnel.jpg", "Hud.jpg", "Hud1.jpg",
										   "Radar.jpg"};
	char byFilename2[CAUST_1_STEPS][256];
	
	ASLoadTextures(byFilename, GAME_TEXTURES, GameTexture);
	for(int i = 0; i < CAUST_1_STEPS; i++)
		sprintf(byFilename2[i], "caust%d.jpg", i);
	ASLoadTextures(byFilename2, CAUST_1_STEPS, Caust1Texture);
} // end LoadGameTextures()

HRESULT GameLoop(void)
{ // begin GameLoop()
	char byTemp[256];
	MSG msg;

	_AS->pWindow[GAME_WINDOW_ID].SetDrawFunction(GameDraw);
	_AS->pWindow[GAME_WINDOW_ID].SetCheckFunction(GameCheck);

	InitGameParticleSystems();
	ASDXShowClose();
	Sleep(1); // If this isn't done the system will crash... maybe an windows message error??
	bShowGameMenu = bPause = FALSE;
	_AS->bDraw = TRUE;
	InitPlayer();
	_ASCamera->SetStandartCamera();
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	Player.bPilotView = FALSE;
	Player.iTargetID = Player.iFixedTargetID = -1;
	Player.iPrimaryWeapon = PHASER_WEAPON;
	Radar.SetupHud();

	// Go into the game loop:
	_AS->WriteLogMessage("Enter the game loop");
	for(;;)
	{
		if(PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
    	{
        	if(!GetMessage(&msg, NULL, 0, 0))
                break;
        	TranslateMessage(&msg);
        	DispatchMessage(&msg);
    	}
		else
		{	
			if(_AS->GetShutDown() || _AS->CheckModuleChange() || bInGameMenu)
				PostQuitMessage(0);
			if(!_AS->GetActive())
				continue;
			_AS->UpdateWindows();
		}
	}
	_AS->WriteLogMessage("Left the game loop");
	
	// Save the configuration:	
	sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyConfigFile);
	_ASConfig->Save(byTemp);
	_AS->bDraw = FALSE;
	return msg.wParam;
} // end GameLoop()

HRESULT GameDraw(AS_WINDOW *pWindow)
{ // begin GameDraw()
	char byTemp[256];

	if(!_AS->bDraw)
		return 0;
	
	// Setup general stuff:
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	// Setup normal projection:
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.f, (float) (_ASConfig->iWindowWidth)/(float) (_ASConfig->iWindowHeight), 0.1f, 10000.0f);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	// Draw sky cube:
	glDisable(GL_DEPTH_TEST);
	Environment.DrawSkyCube();
	glEnable(GL_DEPTH_TEST);
	
	// Setup camera:
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.f, (float) (_ASConfig->iWindowWidth)/(float) (_ASConfig->iWindowHeight), 0.1f, 1000.0f);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	_ASCamera->SetCameraTranslation(FALSE);
	ASExtractFrustum();
	
	// Setup lights:
	Environment.SetupLights();
	SetupPlayerLights();	
	
	// Draw sold objects:
	DrawPlayerSolid();
	DrawActors();
	
	// Draw transparent objects:
	ParticleManager.Draw();
	DrawPlayerTransparent();
	DrawPlayerShipEngine();

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.f, (float) (_ASConfig->iWindowWidth)/(float) (_ASConfig->iWindowHeight), 0.1f, 10000.0f);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	Environment.Draw();
	
	DrawFlares();

	// Draw the hud:
	DrawHud(pWindow);

	// Draw game menu:
	if(fGameMenuBlend != 0.0f)
		ShowGameMenu(pWindow);

	// Draw pause text:
	glColor4f(1.0f, 1.0f, 1.0f, 0.9f);
	if(bPause && !bShowGameMenu)
		pWindow->Print(320, 450, T_Pause, 0, 1);


/////////////////////////////////////////////////////////////////
// Temp stuff:

/////////// Show vertex pos test: //////////////////////////
/*	glEnable(GL_TEXTURE_2D);
	glColor4f(1.0f, 1.0f, 1.0f, 0.9f);
	sprintf(byTemp, "%d", iTemp);
	pWindow->Print(300, 400, byTemp, 0, 0);*/
/////////////////////////////////////////////////////////////////

	
	ASSwapBuffers(*pWindow->GethDC(), pWindow, TRUE);
	return 0;
} // end GameDraw()

HRESULT GameCheck(AS_WINDOW *pWindow)
{ // begin GameCheck()
	_AS->ReadDXInput(*pWindow->GethWnd());
	if(!bPause)
	{
		ParticleManager.Check();
		Environment.Check();
		CheckPlayer();
		CheckActors(FALSE);
	}

	// Game menu blending:
	if(bShowGameMenu)
	{
		fGameMenuBlend += (float) g_lDeltatime/500;
		if(fGameMenuBlend > 1.0f)
			fGameMenuBlend = 1.0f;
	}
	else
	{
		fGameMenuBlend -= (float) g_lDeltatime/500;
		if(fGameMenuBlend < 0.0f)
			fGameMenuBlend = 0.0f;
	}

// Keys:
	if(ASKeyFirst[DIK_F1])
	{ // Open the help file:
		if(_ASConfig->bFullScreen)
		{ // Switch to window mode:
			_ASConfig->bFullScreen = FALSE;
			ChangeDisplayMode();
		}
		OpenHelp();
		return 0;
	}
	if(ASKeyFirst[DIK_F12])
	{ // Open the configuration menu:
		SendMessage(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), WM_COMMAND, ID_OPTIONS_CONFIG, 0);
	}
	if(!bShowGameMenu)
	{
		if(ASKeyFirst[DIK_ESCAPE])
		{
			bShowGameMenu = !bShowGameMenu;
			bPause = bShowGameMenu;
			ASKeyFirst[DIK_ESCAPE] = FALSE;
		}
		else
			if(ASKeyFirst[_ASConfig->iPauseKey[0]] && !bShowGameMenu)
				bPause = !bPause;
	}

// Other:
	if(bShowGameMenu)
		CheckGameMenu();

	if(ASKeyFirst[_ASConfig->iChangePerspectiveKey[0]])
	{
		memcpy(&CameraBackup[Player.bPilotView], pCamera, sizeof(AS_CAMERA));
		Player.bPilotView = !Player.bPilotView;
		memcpy(pCamera, &CameraBackup[Player.bPilotView], sizeof(AS_CAMERA));
	}
	if(ASKeyFirst[_ASConfig->iHudKey[0]])
		Setup.bShowHud = !Setup.bShowHud;

/////////// Show vertex pos test: //////////////////////////
	if(ASKeyFirst[DIK_A])
	{
		if(iTemp > 1)
			iTemp--;
	}
	if(ASKeyFirst[DIK_S])
	{
		if(iTemp < pWeaponPhaser->header.numVertices-1)
			iTemp++;
	}
	if(CHECK_KEY(ASKeys, DIK_D))
	{
		if(iTemp > 1)
			iTemp--;
	}
	if(CHECK_KEY(ASKeys, DIK_F))
	{
		if(iTemp < pWeaponPhaser->header.numVertices-1)
			iTemp++;
	}
/////////////////////////////////////////////////////////////////
	return 0;
} // end GameCheck()

void UpdateAllTextures(void)
{ // begin UpdateAllTextures()
	if(bFirstRunConfigDialog)
		return;
	ASDestroyOpenGLTextures(GAME_TEXTURES, GameTexture);
	ASDestroyOpenGLTextures(GAME_MENU_TEXTURES, GameMenuTexture);
	ASGenOpenGLTextures(GAME_TEXTURES, GameTexture);
	ASGenOpenGLTextures(GAME_MENU_TEXTURES, GameMenuTexture);
	switch(_AS->GetModule())
	{
		case MODULE_GAME:
			_AS->pWindow[GAME_WINDOW_ID].KillFont();
			_AS->pWindow[GAME_WINDOW_ID].BuildFont();
		break;
	}
} // end UpdateAllTextures()

void UpdateRenderQuality(void)
{ // begin UpdateRenderQuality()
	if(bFirstRunConfigDialog)
		return;
	switch(_AS->GetModule())
	{
		case MODULE_GAME:
			ASConfigOpenGL(_AS->pWindow[GAME_WINDOW_ID].GetWidth(), _AS->pWindow[GAME_WINDOW_ID].GetWidth());
		break;
	}
} // end UpdateRenderQuality()

void CreateGameLists(void)
{ // begin CreateGameLists()
	GLUquadricObj *pQuadric;

	iAsteroidBeltList = glGenLists(3);
	glNewList(iAsteroidBeltList, GL_COMPILE);
		// Draw the asteroid belt:
		glEnable(GL_TEXTURE_2D);
		glDisable(GL_LIGHTING);
		glDisable(GL_CULL_FACE);
		glDisable(GL_DEPTH_TEST);
		glDisable(GL_BLEND);
		glDisable(GL_FOG);
		glScalef(1000.0f, 1000.0f, 1000.0f);
		glBindTexture(GL_TEXTURE_2D, GameTexture[0].iOpenGLID);
		glBegin(GL_QUADS);
			// Floor Face
			glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  1.0f);
			glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f, -1.0f,  1.0f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f,  1.0f);
			glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f,  1.0f);
			// Sky Face
			glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, -1.0f, -1.0f);
			glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f,  1.0f, -1.0f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f, -1.0f);
			glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f, -1.0f, -1.0f);
			// Back Face
			glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f,  1.0f, -1.0f);
			glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f,  1.0f,  1.0f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f,  1.0f);
			glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f,  1.0f, -1.0f);
			// Front Face
			glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, -1.0f, -1.0f);
			glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f, -1.0f, -1.0f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f, -1.0f,  1.0f);
			glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f, -1.0f,  1.0f);
			// Right face
			glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, -1.0f, -1.0f);
			glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f,  1.0f, -1.0f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f,  1.0f);
			glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f, -1.0f,  1.0f);
			// Left Face
			glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, -1.0f, -1.0f);
			glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  1.0f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f,  1.0f,  1.0f);
			glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f, -1.0f);
		glEnd();
		glEnable(GL_CULL_FACE);
		glEnable(GL_DEPTH_TEST);
		ASEnableLighting();
	glEndList();

	// Sphere:
	iSphereList = iAsteroidBeltList+1;
	glNewList(iSphereList, GL_COMPILE);
		pQuadric = gluNewQuadric();
		gluQuadricDrawStyle(pQuadric, GLU_FILL);
		gluQuadricNormals(pQuadric, GLU_SMOOTH);
		gluQuadricTexture(pQuadric, GL_TRUE);
		gluSphere(pQuadric, 1.3f, 10, 10);
		gluDeleteQuadric(pQuadric);
	glEndList();
	
	// Environment sphere:
	iEnvironmentSphereList = iSphereList+1;
	glNewList(iEnvironmentSphereList, GL_COMPILE);
		pQuadric = gluNewQuadric();
		gluQuadricDrawStyle(pQuadric, GLU_FILL);
		gluQuadricNormals(pQuadric, GLU_SMOOTH);
		gluQuadricTexture(pQuadric, GL_TRUE);
		gluSphere(pQuadric, Environment.fSphereRadius, 50, 50);
		gluDeleteQuadric(pQuadric);
	glEndList();
	//
} // end CreateGameLists()()

void DestroyGameLists(void)
{ // begin DestroyGameLists()
	if(glIsList(iAsteroidBeltList))
		glDeleteLists(iAsteroidBeltList, 3);
} // end DestroyeGameLists()

void InitGameObjects(void)
{ // begin InitGameObjects()
	char byModelFileTemp[MODELS][256] = {"PlayerShipHull.md2", "PlayerShipGlass.md2",
										 "PlayerShipPilot.md2", "Asteroid.md2",
										 "WeaponPhaser.md2"};
	char byTemp[256], byTemp2[256];

	// Load all models:
	for(int i = 0; i < MODELS; i++)
	{
		sprintf(byTemp, "%s%s\\%s", _AS->pbyProgramPath, _AS->pbyObjectsFile, byModelFileTemp[i]);
		sprintf(byTemp2, "Load model: %s", byTemp);
		_AS->WriteLogMessage(byTemp2);
		if(!((*pModels[i]) = ASLoadMd2Model(byTemp)))
		{
			_AS->WriteLogMessage("------------------------------------------");
			_AS->WriteLogMessage("Couldn't load: %s   program couldn't run!!", byTemp);
			_AS->WriteLogMessage("------------------------------------------");
			_ASConfig->bError = TRUE;
			_ASConfig->bSetError = TRUE;
			_AS->SetShutDown(TRUE);
			return;
		}
	}
} // end InitGameObjects()

void DestroyGameObjects(void)
{ // begin DestroyGameObjects()	
	// Destroy all game models:
	for(int i = 0; i < MODELS; i++)
	{
		if(!(*pModels[i]))
			continue;
		ASFreeMd2Model(*pModels[i]);
	}
} // end DestroyGameObjects()

void InitGameParticleSystems(void)
{ // begin InitGameParticleSystems()
	AS_PARTICLE_SYSTEM *pSystemT;
	AS_PARTICLE *pParticleT;
	int i, i2;

	DestroyGameParticleSystems();
	// PS_PLAYER_SHIP_ENGINE:
	for(i = 0; i < PLAYER_SHIP_ENGINES; i++)
	{
		ParticleManager.AddNewSystem(PS_Engine, 50, &Player.Actor, &GameTexture[14], NULL);
		ParticleManager.pSystem[i].bActive = TRUE;
	}

	// Player crosshair:
	ParticleManager.AddNewSystem(PS_Crosshair, 1, &Player.Actor, &GameTexture[15], NULL);
	ParticleManager.pSystem[PS_PLAYER_CROSSHAIR].bActive = TRUE;
	pSystemT = &ParticleManager.pSystem[PS_PLAYER_CROSSHAIR];
	i = pSystemT->GetFreeParticle();
	if(i != -1)
	{
		pParticleT = &pSystemT->pParticle[i];
		memset(pParticleT, 0, sizeof(AS_PARTICLE));
		pParticleT->bAlive = TRUE;
		pParticleT->fEngine = 1.0f;
		pParticleT->fColor[0] = 1.0f;
		pParticleT->fColor[1] = 1.0f;
		pParticleT->fColor[2] = 1.0f;
		pParticleT->fSize = 20000.0f;
		pParticleT->fPos[X] = 500.0f;
	}

	// The center ablaze:
	ParticleManager.AddNewSystem(PS_Ablaze, 50, NULL, &GameTexture[17], NULL);
	ParticleManager.pSystem[PS_CENTER_ABLAZE].bActive = TRUE;
	pSystemT = &ParticleManager.pSystem[PS_CENTER_ABLAZE];
	for(i = 0; i < pSystemT->iParticles; i++)
	{
		pParticleT = &pSystemT->pParticle[i];
		pParticleT->bAlive = TRUE;
		pParticleT->fSize = 20000.0f;
		pParticleT->fColor[R] = 1.0f;
		pParticleT->fColor[G] = 1.0f;
		pParticleT->fColor[B] = 1.0f;
	  	pParticleT->fEngine = 1.0f;
		if(!(rand() % 10))
		{
			pParticleT->bTemp[0] = TRUE;
			pParticleT->fSize = 50.0f+((float) (rand() % 200)/8);
			for(i2 = 0; i2 < 3; i2++)
			{
				if((rand() % 2))
					pParticleT->fVelocity[i2] = 30.0f+((float) (rand() % 2000)/100.0f);
				else
					pParticleT->fVelocity[i2] = -(30.0f+((float) (rand() % 2000)/100.0f));
			}
		}
		else
		{
			pParticleT->fSize = 10.0f+((float) (rand() % 500)/100);
			for(i2 = 0; i2 < 3; i2++)
			{
				if((rand() % 2))
					pParticleT->fVelocity[i2] = 300.0f+((float) (rand() % 20000)/100.0f);
				else
					pParticleT->fVelocity[i2] = -(300.0f+((float) (rand() % 20000)/100.0f));
				if((rand() % 2))
					pParticleT->fPos[i2] = pParticleT->fFixPos[i2] = pParticleT->fLastPos[i2] = (float) (rand() % 100)/10;
				else
					pParticleT->fPos[i2] = pParticleT->fFixPos[i2] = pParticleT->fLastPos[i2] = -(float) (rand() % 100)/10;
			}
		}
	}
	//
} // end InitGameParticleSystems()

void DestroyGameParticleSystems(void)
{ // begin DestroyGameParticleSystems()
	ParticleManager.Destroy();
} // end DestroyGameParticleSystems()

// This is used for making the flares. It only works on one part of the program.
// fP is the position. 1.0f is where the light is, -1.0f is the opposite side.
// fS is the size. 1.0f will fill the screen when looking right at the light.
// fR, fG, and fB are the colour of the flare.
void MakeFlare(float fP, float fS, float fR, float fG, float fB, float fBrightness,
			   FLOAT3 fSPos)
{ // begin MakeFlare()
	float fLoop;

	glBegin(GL_TRIANGLE_FAN);
		glColor4f(1.0f, 1.0f, 1.0f, fBrightness*0.5f);
		glVertex2f(fSPos[X]*fP, fSPos[Y]*fP);
		glColor4f(fR, fG, fB, 0.0f);
		for(fLoop = 0.0f; fLoop < 6.283185307f; fLoop += 6.283185307f/6.0f)
			 glVertex2f((float) (fSPos[X]*fP+sin(fLoop)*fS*fBrightness),
						(float) (fSPos[Y]*fP+cos(fLoop)*fS*fBrightness));
	glEnd();
} // end MakeFlare()

// Make the actual flares:
void DrawFlares(void)
{ // begin DrawFlares();
    GLdouble dModelMatrix[16];
    GLdouble dProjMatrix[16];
    float fBrightness = 0.0f; // How bright the light is
    GLint iViewport[4];
	FLOAT3 fSunPos = {0.0f, 0.0f, 0.0f};
    DOUBLE3 dSPos; // Where on the screen the light is
	FLOAT3 fSPos; // The same as float
    BOOL bBig = TRUE;
    float fDepth; // The depth in the framebuffer
    float fLoop, fFactor;
    int iX, iY;

	_ASCamera->SetCameraTranslation(FALSE);
    
	// Load the matricies and viewport:
    glGetDoublev(GL_MODELVIEW_MATRIX, dModelMatrix);
    glGetDoublev(GL_PROJECTION_MATRIX, dProjMatrix);
    glGetIntegerv(GL_VIEWPORT, iViewport);
    
	// Find out where the light is on the screen.
	gluProject(fSunPos[X], fSunPos[Y], fSunPos[Z], dModelMatrix, dProjMatrix,
				iViewport, &dSPos[X], &dSPos[Y], &dSPos[Z]);

    // Go through some of the points near the light:
	for(iX = -4; iX <= 4; iX++)
        for(iY = -4; iY <= 4; iY++)
        {
            if(iViewport[2]/300.0f*iX+dSPos[X] < iViewport[2] &&
			   iViewport[2]/300.0f*iX+dSPos[X] >= 0 &&
			   iViewport[3]/300.0f*iY+dSPos[Y] < iViewport[3] &&
			   iViewport[3]/300.0f*iY+dSPos[Y] >= 0 )
            { // If the point is on the screen:
                 // Read the depth from the depth buffer:
				glReadPixels((int)(iViewport[2]/300.0f*iX+dSPos[X]),
							 (int)(iViewport[3]/300.0f*iY+dSPos[Y]),
							 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, &fDepth);
                // If the light is infront of what ever was in that spot, increase the brightness:
				if(fDepth >= dSPos[Z])
					fBrightness += 1.0f/81.0f; 
            }
        }
	if(dSPos[X] < iViewport[2] && dSPos[X] >= 0 &&
	   dSPos[Y] < iViewport[3] && dSPos[Y] >= 0 )
    { // If the light is on the screen:
        glReadPixels((int) (dSPos[X]),(int) (dSPos[Y]),
					  1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, &fDepth);
        if(fDepth < dSPos[Z] && dSPos[Z]-fDepth > 0.0002) // It is behind something
            fBrightness = 0.0f; // The light can't be seen
    }
    else // If the light isn't on the screen:
        fBrightness = 0.0f; // The light can't be seen    
	
	// Draw some stuff which has no influence on the flares:

     // Now that we know the brightness, convert:
	dSPos[X] = dSPos[X]/(float) iViewport[2]*2.0f-1.0f;
    // The position to a number between (-1,-1) and (1,1):
	dSPos[Y] = dSPos[Y]/(float) iViewport[2]*2.8f-1.0f;

	// And adjust the brightness so it is brighter at the centre of the screen:
	fBrightness *= (float) ((1.2f-sqrt(dSPos[X]*dSPos[X]+dSPos[Y]*dSPos[Y]))*fBrightness*0.75f);
	fFactor = (float) Environment.fSphereRadius/2/Player.Actor.vWorldPos.GetLength();
	if(fFactor > 1.0f)
		fFactor = 1.0f;
	fBrightness *= fFactor;
	if(fBrightness > 0.99f)
		fBrightness = 0.99f;
	if(fBrightness < 0.0f)
		return;
    
	// Draw now the flares:
	glPushMatrix();
    glLoadIdentity();
    glMatrixMode(GL_PROJECTION);
	glEnable(GL_BLEND);
	glPushMatrix();
	glDepthMask(FALSE);

	// Forget about the view and projection. We will be drawing in 2D for the flares:
	glLoadIdentity();
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    glDisable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
    
    fSPos[X] = (float) dSPos[X];
    fSPos[Y] = (float) dSPos[Y];
    fSPos[Z] = (float) dSPos[Z];
	 // Make a steak across the screen where the light is:
	glBegin(GL_TRIANGLE_FAN);
		glColor4f(0.9f, 1.0f, 0.9f, fBrightness*0.5f);
		glVertex2f(fSPos[X], fSPos[Y]);
		glColor4f(1.0f, 1.0f, 1.0f, 0.0f);
		glVertex2f(fSPos[X]+2.5f*fBrightness, fSPos[Y]);
		glVertex2f(fSPos[X], fSPos[Y]+0.1f*fBrightness);
		glVertex2f(fSPos[X]-2.5f*fBrightness, fSPos[Y]);
		glVertex2f(fSPos[X], fSPos[Y]-0.1f*fBrightness);
		glVertex2f(fSPos[X]+2.5f*fBrightness, fSPos[Y]);
    glEnd();

    // Brighten the screen:
	glEnable(GL_BLEND);
	glColor4f(1.0f, 1.0f, 1.0f, fBrightness);
    glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f);
		glVertex2f(fSPos[X]-2, fSPos[Y]-2);
		glTexCoord2f(1.0f, 0.0f);
		glVertex2f(fSPos[X]+2, fSPos[Y]-2);
		glTexCoord2f(1.0f, 1.0f);
		glVertex2f(fSPos[X]+2, fSPos[Y]+2);
		glTexCoord2f(0.0f, 1.0f);
		glVertex2f(fSPos[X]-2, fSPos[Y]+2);
    glEnd();

    // Draw the main flare:
	glBegin(GL_TRIANGLE_FAN);
		glColor4f(1.0f, 1.0f, 1.0f, fBrightness*0.5f);
		glVertex2f(fSPos[X], fSPos[Y]);
		glColor4f(1.0f, 1.0f, 0.5f, 0.0f);
		// Make a 32 point star (64/2=32)
		for(fLoop = 0.0f; fLoop < 6.283185307f; fLoop += 6.283185307f/64.0f)
		{
			glVertex2f((float) (fSPos[X]+sin(fLoop)*(bBig ? 2.0f*fBrightness : 1.0f*fBrightness)),
					   (float) (fSPos[Y]+cos(fLoop)*(bBig ? 2.0f*fBrightness : 1.0f*fBrightness)));
			bBig = !bBig; // Make the next part of the star the opposite of this part
		}                    
    glEnd();
    
    // Draw other flares:
    MakeFlare(0.7f, 0.2f, 1.0f, 1.0f, 1.0f, fBrightness, fSPos);
    MakeFlare(0.6f, 0.3f, 1.0f, 0.6f, 0.6f, fBrightness, fSPos);
    MakeFlare(0.4f, 0.4f, 1.0f, 1.0f, 1.0f, fBrightness, fSPos);
    MakeFlare(0.3f, 0.6f, 0.8f, 0.8f, 0.6f, fBrightness, fSPos);
    MakeFlare(0.2f, 0.5f, 1.0f, 1.0f, 1.0f, fBrightness, fSPos);
    MakeFlare(-0.1f, 0.4f, 0.6f, 1.0f, 0.6f, fBrightness, fSPos);
    MakeFlare(-0.2f, 0.3f, 1.0f, 1.0f, 1.0f, fBrightness, fSPos);
    MakeFlare(-0.4f, 0.2f, 0.6f, 0.8f, 0.8f, fBrightness, fSPos);
    MakeFlare(-0.6f, 0.4f, 1.0f, 1.0f, 1.0f, fBrightness, fSPos);
    MakeFlare(-0.7f, 0.5f, 0.6f, 0.6f, 1.0f, fBrightness, fSPos);
    MakeFlare(-0.8f, 0.6f, 1.0f, 1.0f, 1.0f, fBrightness, fSPos);
    MakeFlare(-0.9f, 0.5f, 0.8f, 0.6f, 0.8f, fBrightness, fSPos);
    MakeFlare(-1.2f, 0.3f, 1.0f, 1.0f, 1.0f, fBrightness, fSPos);

    glEnable(GL_LIGHTING);
    glEnable(GL_CULL_FACE);
    glEnable(GL_DEPTH_TEST);
    glPopMatrix(); 
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
	glDepthMask(TRUE);
} // end DrawFlares()
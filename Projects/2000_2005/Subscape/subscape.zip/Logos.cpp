//-----------------------------------------------------------------------------
// File: Logos.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
AS_TEXTURE LogosTexture[LOGOS_TEXTURES];
BOOL bShowLogos;
short iStep, iASLogoPSSystem;
long lLogoStartTime;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
void Logos(void);
HRESULT LogosDraw(AS_WINDOW *);
HRESULT LogosCheck(AS_WINDOW *);
void DrawLogoBox(short [6]);
void InitLogos(void);
void SetLogosCamera(void);
///////////////////////////////////////////////////////////////////////////////


void Logos(void)
{ // begin Logos()
	MSG msg;

	_AS->bDraw = FALSE;
	DestroyGameParticleSystems();
	_AS->pWindow[GAME_WINDOW_ID].SetDrawFunction(LogosDraw);
	_AS->pWindow[GAME_WINDOW_ID].SetCheckFunction(LogosCheck);
	InitLogos();
	StartMenuMusic();
	lLogoStartTime = GetTickCount();

	bShowLogos = FALSE;
	_AS->bDraw = TRUE;


/*	for(;;)
	{
		if(PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
		{
			if(!GetMessage(&msg, NULL, 0, 0))
				break;
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else
		{	
			if(_AS->GetShutDown() || _AS->CheckModuleChange() || !bShowLogos)
				PostQuitMessage(0);
			if(!_AS->GetActive())
				continue;
			_AS->UpdateWindows();
		}
	}*/

	bInGameMenu = TRUE;
} // end Logos()

HRESULT LogosDraw(AS_WINDOW *pWindow)
{ // begin LogosDraw()
	GLfloat afLightData[4]  = {0.0f, 0.0f, 0.0f, 0.0f};

	if(!_AS->bDraw)
		return 0;
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0f, (GLfloat)(_ASConfig->iWindowWidth+200)/(GLfloat)(_ASConfig->iWindowHeight), 0.1f, 10000.0f);
	glMatrixMode(GL_MODELVIEW);

	afLightData[0] = 0.0f;
	afLightData[1] = 0.0f;
	afLightData[2] = 0.0f;
	afLightData[3] = 1.0f;
	glLightfv(GL_LIGHT1, GL_POSITION, afLightData);
	afLightData[0] = 1.0f;
	afLightData[1] = 1.0f;
	afLightData[2] = 1.0f;
	afLightData[3] = 1.0f;
	glLightfv(GL_LIGHT1, GL_AMBIENT, afLightData);
	glEnable(GL_LIGHT1);

	glEnable(GL_TEXTURE_2D);
	glEnable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);
	ASEnableLighting();

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	glLoadIdentity();
	glTranslatef(-50.0f, -20.0f, -80.0f);
	glDisable(GL_FOG);
	ParticleManager.Draw();

	ASSwapBuffers(*pWindow->GethDC(), pWindow, TRUE);

	glDisable(GL_LIGHT1);
	return 0;
} // end LogosDraw()

HRESULT LogosCheck(AS_WINDOW *pWindow)
{ // begin LogosCheck()
	short i;
	
	_AS->ReadDXInput(*pWindow->GethWnd());

	ParticleManager.Check();
	if(g_lNow-lLogoStartTime > 10000)
	{
		ParticleManager.pSystem[iASLogoPSSystem].bGoingInActive = TRUE;
		bShowLogos = FALSE;
	}

	for(i = 0; i < 256; i++)
		if(ASKeyFirst[i])
		{
			ParticleManager.pSystem[iASLogoPSSystem].bGoingInActive = TRUE;
			bShowLogos = FALSE;
			break;
		}

	return 0;
} // end LogosCheck()

void InitLogos(void)
{ // begin InitLogos()
	AS_PARTICLE *pParticleT;
	short i, i2;
	
	iASLogoPSSystem = ParticleManager.AddNewSystem(PS_ASLogo, LogosTexture[0].iWidth*LogosTexture[0].iHeight, NULL, &GameTexture[1], &LogosTexture[0]);
	ParticleManager.pSystem[iASLogoPSSystem].bActive = TRUE;
	// Disort particles:
	for(i = 0; i < ParticleManager.pSystem[iASLogoPSSystem].iParticles; i++)
	{
		pParticleT = &ParticleManager.pSystem[iASLogoPSSystem].pParticle[i];
		for(i2 = 0; i2 < 3; i2++)
		{
			if(!(rand() % 2))
				pParticleT->fPos[i2] += (float) (rand() % 20);
			else
				pParticleT->fPos[i2] -= (float) (rand() % 20);
			pParticleT->fLastPos[i2] = pParticleT->fFixPos[i2];
		}
	}
} // end InitLogos()

void SetLogosCamera(void)
{ // begin SetLogosCamera()
	glLoadIdentity();
	glTranslatef(0.0f, 0.0f, -1.5f);
	glRotatef(20.0f, 1.0f, 0.0f, 0.0f);
} // end SetLogosCamera()
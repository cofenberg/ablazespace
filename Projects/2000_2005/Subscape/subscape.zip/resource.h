//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Resource.rc
//
#define IDC_CREDITS_VERSION_TEXT        1
#define IDD_OPENGL                      102
#define IDR_GAME                        104
#define IDD_CONFIG                      105
#define IDD_CREDITS                     109
#define IDC_CONFIG_GRAPHIC_MODES        113
#define IDC_CONFIG_GRAPHIC_Z_BUFFER     114
#define IDI_GAME_ICON                   130
#define IDD_CONFIG_GRAPHIC              134
#define IDD_CONFIG_GENERAL              135
#define IDD_CONFIG_SOUND                136
#define IDD_CONFIG_CONTROL              169
#define IDD_CONFIG_CHEATS               178
#define IDC_OPENGL_CHIP                 1000
#define IDC_HOMEPAGE                    1000
#define IDC_OPENGL_RENDERER             1001
#define IDC_NEHE_HOMEPAGE               1001
#define IDC_OPENGL_VERSION              1002
#define IDC_CONFIG_SOUND_MUSIC          1003
#define IDC_MSPANG_HOMEPAGE             1003
#define IDC_OPENGL_VERSION_INFO         1004
#define IDC_CONFIG_SOUND_SOUND          1004
#define IDC_OPENGL_CHIP_INFO            1005
#define IDC_OPENGL_RENDERER_INFO        1006
#define IDC_CONFIG_GENERAL_SHOW_FPS     1006
#define IDC_OPENGL_EXTENSIONS           1007
#define IDC_OPENGL_EXTENSIONS_INFO      1008
#define ID_OPENGL_OK                    1009
#define IDC_CONFIG_GRAPHIC_FAST_TEXTURING 1009
#define IDC_CONFIG_GRAPHIC_USE_MIPMAPS  1010
#define IDC_CONFIG_GENERAL_LOG          1011
#define IDC_CONFIG_GRAPHIC_HIGHT_RENDER_QUALITY 1011
#define IDC_CONFIG_GENERAL_SHOW_BOUNDING_BOXES 1012
#define IDC_CONFIG_GRAPHIC_MULTITEXTURING 1012
#define IDC_CONFIG_GENERAL_FRUSTUM_CULLING 1013
#define ID_CONFIG_OK                    1014
#define IDC_CONFIG_GENERAL_SHOW_CULLED_OBJECTS 1014
#define ID_CONFIG_CANCEL                1015
#define IDC_CONFIG_GENERAL_WIREFRAME_MODE 1015
#define IDC_CREDITS_BUILD_DATE          1016
#define ID_CONFIG_QUIT                  1016
#define IDC_CONFIG_GENERAL_POINT_MODE   1016
#define IDC_CREDITS_BUILD_TIME          1017
#define IDC_CREDITS_OK                  1018
#define IDC_CREDITS_VERSION             1019
#define IDC_CONFIG_CREDITS              1021
#define IDC_CONFIG_OPENGL               1022
#define IDC_CONFIG_HELP                 1023
#define IDC_CONFIG_GRAPHIC_FULLSCREEN   1033
#define IDC_CONFIG_GENERAL_LANGUAGE     1089
#define IDC_CONFIG_GRAPHIC_LIGHTING     1090
#define IDC_CONFIG_GRAPHIC_DISPLAY_MODE 1091
#define IDC_CONFIG_GENERAL_LANGUAGE_TEXT 1092
#define IDC_CREDITS_HOMEPAGE            1093
#define IDC_CREDITS_PROGRAMMING_AND_DESIGN 1094
#define IDC_CREDITS_MUSIC               1095
#define IDC_CREDITS_E_MAIL              1096
#define IDC_CREDITS_PROGRAM_INFO        1097
#define IDC_CREDITS_BUILD               1098
#define none                            1099
#define none1                           1100
#define none2                           1101
#define IDC_CONFIG_GRAPHIC_LIGHT_NONE   1101
#define none3                           1102
#define IDC_CONFIG_GRAPHIC_LIGHT_FLAT   1102
#define IDC_CONFIG_GRAPHIC_LIGHT_SMOOTH 1103
#define IDC_CONFIG_TAB                  1118
#define IDC_CREDITS_MORE                1222
#define IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY 1279
#define IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY_SLOW 1283
#define IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY_FAST 1284
#define IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY_NORMAL 1285
#define IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY_T 1286
#define IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY_T 1288
#define IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY_LOW 1289
#define IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY_MIDDLE 1290
#define IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY_ALL 1291
#define IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY 1292
#define IDC_CONFIG_GRAPHIC_PARTICLES    1293
#define IDC_CONFIG_GRAPHIC_Z_BUFFER_T   1294
#define IDC_CONFIG_SOUND_MUSIC_VOLUME_T 1295
#define IDC_CONFIG_SOUND_MUSIC_VOLUME   1296
#define IDC_CONFIG_CHEATS_INVULNERABLE  1346
#define IDC_CONFIG_CHEATS_LIVES_T       1349
#define IDC_CONFIG_CHEATS_LIVES         1350
#define IDC_CONFIG_CHEATS_POINTS_T      1351
#define IDC_CONFIG_CHEATS_POINTS        1352
#define ID_GAME_FILE_QUIT               40003
#define ID_OPTIONS_CONFIG               40004
#define ID_HELP_CREDITS                 40008
#define ID_HELP_HOMEPAGE                40009
#define ID_HELP_HELP                    40010
#define ID_FILE_SHOW_LOG                40012
#define none5                           40035

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        180
#define _APS_NEXT_COMMAND_VALUE         40039
#define _APS_NEXT_CONTROL_VALUE         1386
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

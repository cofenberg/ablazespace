//-----------------------------------------------------------------------------
// File: PlayerEngines.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Functions: *****************************************************************
void CreateEngineParticles(AS_MD2_MODEL *, int, int, int, long, float,
						   float, FLOAT3, AS_3D_VECTOR, float, int, float, int);
void DrawEnginePart(FLOAT3, float, int, int, int, int);
void DrawEngineMainPart(FLOAT3, float, int, int, int, int);
void DrawPlayerShipEngine(void);
void CheckPlayerShipEngine(void);
///////////////////////////////////////////////////////////////////////////////


void CreateEngineParticles(AS_MD2_MODEL *pModel, int iStartVertex, int iEndVertex,
						   int iParticleSystem, long lTimeDelay, float fSize,
						   float fFadeSpeed, FLOAT3 fWorldPos, AS_3D_VECTOR vRot, float fScale,
						   int iFrame, float fSpeed, int iRandom)
{ // begin CreateEngineParticles()
	AS_PARTICLE_SYSTEM *pSystemT;
	AS_PARTICLE *pParticleT;
	FLOAT3 fPosT1, fPosT2;
	float fColor;
	int i;
	
	pSystemT = &ParticleManager.pSystem[iParticleSystem];
	if(g_lNow < pSystemT->lNextTime)
		return;
	// The system should be updated:
	pSystemT->lLastTime = g_lNow;
	pSystemT->lNextTime = pSystemT->lLastTime+lTimeDelay;
	// 
	i = pSystemT->GetFreeParticle();
	if(i == -1)
		return;
	ASGetMd2Vertex(pModel, iFrame, fWorldPos, fScale,
				  0.0f, 0.0f, 0.0f, iStartVertex, &fPosT1);
	ASGetMd2Vertex(pModel, iFrame, fWorldPos, fScale,
				   0.0f, 0.0f,  0.0f, iEndVertex, &fPosT2);
	pParticleT = &pSystemT->pParticle[i];
	memset(pParticleT, 0, sizeof(AS_PARTICLE));
	pParticleT->bAlive = TRUE;
	pParticleT->fEngine = (float) 1.0f;
	fColor = 0.4f+((float) (rand() % 100)/160);
	pParticleT->fColor[0] = fColor;
	pParticleT->fColor[1] = fColor;
	pParticleT->fColor[2] = fColor;
	pParticleT->fFadeSpeed = fFadeSpeed;
	pParticleT->fSize = fSize;
	pParticleT->fPos[X] = fPosT1[X];
	pParticleT->fPos[Y] = fPosT1[Y];
	pParticleT->fPos[Z] = fPosT1[Z];
	if(!(rand() % 2))
		pParticleT->fVelocity[X] = (fPosT2[X]-fPosT1[X])*(fSpeed+((rand() % iRandom)/100));
	else
		pParticleT->fVelocity[X] = (fPosT2[X]-fPosT1[X])*(fSpeed-((rand() % iRandom)/100));
	if(!(rand() % 2))
		pParticleT->fVelocity[Y] = (fPosT2[Y]-fPosT1[Y])*(fSpeed+((rand() % iRandom)/100));
	else
		pParticleT->fVelocity[Y] = (fPosT2[Y]-fPosT1[Y])*(fSpeed-((rand() % iRandom)/100));
	if(!(rand() % 2))
		pParticleT->fVelocity[Z] = (fPosT2[Z]-fPosT1[Z])*(fSpeed+((rand() % iRandom)/100));
	else
		pParticleT->fVelocity[Z] = (fPosT2[Z]-fPosT1[Z])*(fSpeed-((rand() % iRandom)/100));
} // end CreateEngineParticles()

void DrawEnginePart(FLOAT3 fPos2, float fPower, int i1, int i2, int i3, int i4)
{ // begin DrawEnginePart()
	FLOAT3 fPos;

	ASGetMd2Vertex(pPlayerShipHull, 0, fPos2, 1.0f,
				   0.0f, 0.0f,  0.0f, i1, &fPos);
	glColor4f(0.5f*fPower, 0.5f*fPower, fPower, 0.999f);
	glTexCoord2f(0.0f, 0.0f); glVertex3fv(fPos);
	ASGetMd2Vertex(pPlayerShipHull, 0, fPos2, 1.0f,
				   0.0f, 0.0f,  0.0f, i2, &fPos);
	glColor4f(0.5f*fPower, 0.5f*fPower, fPower, 0.999f);
	glTexCoord2f(1.0f, 0.0f); glVertex3fv(fPos);
	ASGetMd2Vertex(pPlayerShipHull, 0, fPos2, 1.0f,
				   0.0f, 0.0f,  0.0f, i3, &fPos);
	glColor4f(0.0f, 0.0f, 0.0f, 0.999f);
	glTexCoord2f(1.0f, 1.0f); glVertex3fv(fPos);
	ASGetMd2Vertex(pPlayerShipHull, 0, fPos2, 1.0f,
				   0.0f, 0.0f,  0.0f, i4, &fPos);
	glColor4f(0.0f, 0.0f, 0.0f, 0.999f);
	glTexCoord2f(0.0f, 1.0f); glVertex3fv(fPos);
} // end DrawEnginePart()

void DrawEngineMainPart(FLOAT3 fPos2, float fPower, int i1, int i2, int i3, int i4)
{ // begin DrawEngineMainPart()
	FLOAT3 fPos;

	ASGetMd2Vertex(pPlayerShipHull, 0, fPos2, 1.0f,
				   0.0f, 0.0f,  0.0f, i1, &fPos);
	glColor4f(0.5f*fPower, 0.5f*fPower, fPower, 0.999f); glTexCoord2f(0.0f, 0.0f); glVertex3fv(fPos);
	ASGetMd2Vertex(pPlayerShipHull, 0, fPos2, 1.0f,
				   0.0f, 0.0f,  0.0f, i2, &fPos);
	glColor4f(0.5f*fPower, 0.5f*fPower, fPower, 0.999f); glTexCoord2f(1.0f, 0.0f); glVertex3fv(fPos);
	ASGetMd2Vertex(pPlayerShipHull, 0, fPos2, 1.0f,
				   0.0f, 0.0f,  0.0f, i3, &fPos);
	glColor4f(0.0f, 0.0f, 0.0f, 0.999f); glTexCoord2f(1.0f, 1.0f); glVertex3fv(fPos);
	ASGetMd2Vertex(pPlayerShipHull, 0, fPos2, 1.0f,
				   0.0f, 0.0f,  0.0f, i4, &fPos);
	glColor4f(0.0f, 0.0f, 0.0f, 0.999f); glTexCoord2f(0.0f, 1.0f); glVertex3fv(fPos);
} // end DrawEngineMainPart()

void DrawPlayerShipEngine(void)
{ // begin DrawPlayerShipEngine()
	FLOAT3 fPos2 = {0.0f, 0.0f, 0.0f};
	ACTOR *pPlayer = &Player.Actor;
	float fPower;
	int i;

	fPos2[X] = 0.0f;
	fPos2[Y] = 0.0f;
	fPos2[Z] = 0.0f;
	glDisable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glDepthMask(FALSE);
	glEnable(GL_AUTO_NORMAL);

	// Draw the shields:
	glBindTexture(GL_TEXTURE_2D, Caust1Texture[Environment.iSphereAniStep].iOpenGLID);
	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);
	_ASCamera->SetCameraTranslation(FALSE);
	pPlayer->Apply();
	glScalef(0.01f, 0.01f, 0.01f);
	glRotatef(90.0f, 0.0f, 1.0f, 0.0f);
	glDisable(GL_CULL_FACE);
	for(i = 0; i < 8; i++)
	{
		if(!Player.fShieldLight[i])
			continue;
		glColor4f(0.5f*Player.fShieldLight[i], 0.5f*Player.fShieldLight[i], Player.fShieldLight[i], 0.999f);
		glPushMatrix();
		glTranslatef(fPlayerPosR[i][X], fPlayerPosR[i][Y], fPlayerPosR[i][Z]);
		glScalef(pPlayer->fRadius*fPlayerPosR[i][3], pPlayer->fRadius*fPlayerPosR[i][3], pPlayer->fRadius*fPlayerPosR[i][3]);
		glCallList(iSphereList);
		glPopMatrix();
	}
	
	_ASCamera->SetCameraTranslation(FALSE);
	pPlayer->Apply();
	glScalef(0.01f, 0.01f, 0.01f);
	glRotatef(90.0f, 0.0f, 1.0f, 0.0f);

	// Main engine:
	fPower = Player.ShipEngine[MAIN_SHIP_ENGINE].fPower;
	if(fPower)
	{
		glBindTexture(GL_TEXTURE_2D, Caust1Texture[Player.ShipEngine[MAIN_SHIP_ENGINE].iAniStep].iOpenGLID);
		glBegin(GL_QUADS);
			DrawEngineMainPart(fPos2, fPower, 104, 106, 105, 103);
			DrawEngineMainPart(fPos2, fPower, 103, 310, 311, 104);
			DrawEnginePart(fPos2, fPower, 106, 105, 207, 208);
			DrawEnginePart(fPos2, fPower, 105, 103, 205, 207);
			DrawEnginePart(fPos2, fPower, 103, 310, 209, 205);
			DrawEnginePart(fPos2, fPower, 310, 311, 210, 209);
			DrawEnginePart(fPos2, fPower, 311, 104, 206, 210);
			DrawEnginePart(fPos2, fPower, 104, 106, 208, 206);
		glEnd();
	}
	// Right engine:
	fPower = Player.ShipEngine[RIGHT_SHIP_ENGINE].fPower;
	if(fPower)
	{
		glBindTexture(GL_TEXTURE_2D, Caust1Texture[Player.ShipEngine[RIGHT_SHIP_ENGINE].iAniStep].iOpenGLID);
		glBegin(GL_QUADS);
			DrawEngineMainPart(fPos2, fPower, 308, 309, 307, 306);
			DrawEnginePart(fPos2, fPower, 308, 309, 326, 325);
			DrawEnginePart(fPos2, fPower, 309, 307, 176, 326);
			DrawEnginePart(fPos2, fPower, 307, 306, 324, 176);
			DrawEnginePart(fPos2, fPower, 306, 308, 325, 324);
		glEnd();
	}
	// Left engine:
	fPower = Player.ShipEngine[LEFT_SHIP_ENGINE].fPower;
	if(fPower)
	{
		glBindTexture(GL_TEXTURE_2D, Caust1Texture[Player.ShipEngine[LEFT_SHIP_ENGINE].iAniStep].iOpenGLID);
		glBegin(GL_QUADS);
			DrawEngineMainPart(fPos2, fPower, 95, 96, 98, 97);
			DrawEnginePart(fPos2, fPower, 95, 96, 321, 182);
			DrawEnginePart(fPos2, fPower, 96, 98, 184, 321);
			DrawEnginePart(fPos2, fPower, 98, 97, 183, 184);
			DrawEnginePart(fPos2, fPower, 97, 95, 182, 183);
		glEnd();
	}
	// Right bottom engine:
	fPower = Player.ShipEngine[RIGHT_BOTTOM_SHIP_ENGINE].fPower;
	if(fPower)
	{
		glBindTexture(GL_TEXTURE_2D, Caust1Texture[Player.ShipEngine[RIGHT_BOTTOM_SHIP_ENGINE].iAniStep].iOpenGLID);
		glBegin(GL_QUADS);
			DrawEngineMainPart(fPos2, fPower, 337, 338, 339, 336);
			DrawEngineMainPart(fPos2, fPower, 339, 334, 335, 336);
			DrawEnginePart(fPos2, fPower, 337, 338, 237, 177);
			DrawEnginePart(fPos2, fPower, 338, 339, 391, 237);
			DrawEnginePart(fPos2, fPower, 339, 334, 178, 391);
			DrawEnginePart(fPos2, fPower, 334, 335, 393, 178);
			DrawEnginePart(fPos2, fPower, 335, 336, 392, 393);
			DrawEnginePart(fPos2, fPower, 336, 337, 177, 392);
		glEnd();
	}
	// Left bottom engine:
	fPower = Player.ShipEngine[LEFT_BOTTOM_SHIP_ENGINE].fPower;
	if(fPower)
	{
		glBindTexture(GL_TEXTURE_2D, Caust1Texture[Player.ShipEngine[LEFT_BOTTOM_SHIP_ENGINE].iAniStep].iOpenGLID);
		glBegin(GL_QUADS);
			DrawEngineMainPart(fPos2, fPower, 217, 222, 221, 218);
			DrawEngineMainPart(fPos2, fPower, 221, 220, 219, 218);
			DrawEnginePart(fPos2, fPower, 217, 222, 387, 388);
			DrawEnginePart(fPos2, fPower, 222, 221, 323, 387);
			DrawEnginePart(fPos2, fPower, 221, 220, 322, 323);
			DrawEnginePart(fPos2, fPower, 220, 219, 390, 322);
			DrawEnginePart(fPos2, fPower, 219, 218, 389, 390);
			DrawEnginePart(fPos2, fPower, 218, 217, 388, 389);
		glEnd();
	}
	// Backward engine:
	fPower = Player.ShipEngine[BACKWARD_SHIP_ENGINE].fPower;
	if(fPower)
	{
		glBindTexture(GL_TEXTURE_2D, Caust1Texture[Player.ShipEngine[BACKWARD_SHIP_ENGINE].iAniStep].iOpenGLID);
		glBegin(GL_QUADS);
			DrawEngineMainPart(fPos2, fPower, 142, 144, 143, 141);
			DrawEnginePart(fPos2, fPower, 142, 144, 200, 198);
			DrawEnginePart(fPos2, fPower, 144, 143, 199, 200);
			DrawEnginePart(fPos2, fPower, 143, 141, 197, 199);
			DrawEnginePart(fPos2, fPower, 141, 142, 198, 197);
		glEnd();
	}
	// Top engine:
	fPower = Player.ShipEngine[TOP_SHIP_ENGINE].fPower;
	if(fPower)
	{
		glBindTexture(GL_TEXTURE_2D, Caust1Texture[Player.ShipEngine[TOP_SHIP_ENGINE].iAniStep].iOpenGLID);
		glBegin(GL_QUADS);
			DrawEngineMainPart(fPos2, fPower, 165, 164, 163, 162);
			DrawEngineMainPart(fPos2, fPower, 162, 161, 166, 165);
			DrawEnginePart(fPos2, fPower, 165, 164, 171, 172);
			DrawEnginePart(fPos2, fPower, 164, 163, 170, 171);
			DrawEnginePart(fPos2, fPower, 163, 162, 169, 170);
			DrawEnginePart(fPos2, fPower, 162, 161, 168, 169);
			DrawEnginePart(fPos2, fPower, 161, 166, 173, 168);
			DrawEnginePart(fPos2, fPower, 166, 165, 172, 173);
		glEnd();
	}
	// Bottom engine:
	fPower = Player.ShipEngine[BOTTOM_SHIP_ENGINE].fPower;
	if(fPower)
	{
		glBindTexture(GL_TEXTURE_2D, Caust1Texture[Player.ShipEngine[BOTTOM_SHIP_ENGINE].iAniStep].iOpenGLID);
		glBegin(GL_QUADS);
			DrawEngineMainPart(fPos2, fPower, 151, 155, 154, 319);
			DrawEngineMainPart(fPos2, fPower, 154, 152, 318, 319);
			DrawEnginePart(fPos2, fPower, 151, 155, 192, 188);
			DrawEnginePart(fPos2, fPower, 155, 154, 191, 192);
			DrawEnginePart(fPos2, fPower, 154, 152, 190, 191);
			DrawEnginePart(fPos2, fPower, 152, 318, 189, 190);
			DrawEnginePart(fPos2, fPower, 318, 319, 187, 189);
			DrawEnginePart(fPos2, fPower, 319, 151, 188, 187);
		glEnd();
	}
	// Top front engine:
	fPower = Player.ShipEngine[TOP_FRONT_SHIP_ENGINE].fPower;
	if(fPower)
	{
		glBindTexture(GL_TEXTURE_2D, Caust1Texture[Player.ShipEngine[TOP_FRONT_SHIP_ENGINE].iAniStep].iOpenGLID);
		glBegin(GL_QUADS);
			DrawEngineMainPart(fPos2, fPower, 363, 364, 368, 367);
			DrawEnginePart(fPos2, fPower, 363, 364, 381, 384);
			DrawEnginePart(fPos2, fPower, 364, 368, 382, 381);
			DrawEnginePart(fPos2, fPower, 368, 367, 383, 382);
			DrawEnginePart(fPos2, fPower, 367, 363, 384, 383);
		glEnd();
	}
	// Bottom front engine:
	fPower = Player.ShipEngine[BOTTOM_FRONT_SHIP_ENGINE].fPower;
	if(fPower)
	{
		glBindTexture(GL_TEXTURE_2D, Caust1Texture[Player.ShipEngine[BOTTOM_FRONT_SHIP_ENGINE].iAniStep].iOpenGLID);
		glBegin(GL_QUADS);
			DrawEngineMainPart(fPos2, fPower, 349, 350, 352, 351);
			DrawEnginePart(fPos2, fPower, 349, 350, 377, 380);
			DrawEnginePart(fPos2, fPower, 350, 352, 378, 377);
			DrawEnginePart(fPos2, fPower, 352, 351, 379, 378);
			DrawEnginePart(fPos2, fPower, 351, 349, 380, 379);
		glEnd();
	}

	ASEnableLighting();
	glDepthMask(TRUE);
	glEnable(GL_CULL_FACE);
	glDisable(GL_AUTO_NORMAL);
} // end DrawPlayerShipEngine()

void CheckPlayerShipEngine(void)
{ // begin CheckPlayerShipEngine()
	FLOAT3 fPos2 = {0.0f, 0.0f, 0.0f};
	SHIP_ENGINE	*Engine;
	ACTOR *pPlayer = &Player.Actor;
	float fPower;
	int i;

	// Animate the ship engines:
	for(i = 0; i < 10; i++)
	{
		Engine = &Player.ShipEngine[i];
		if(!Engine->fPower)
		{
			Engine->fActualPower = Engine->fNewPower =
			Engine->fLastPower = 0.0f;
			continue;
		}
		// Animate the blue engine:
		if(g_lNow-Engine->lAniTimer > (50*(1.0f-Engine->fPower)))
		{ // Go to the next animation step:
			Engine->lAniTimer = g_lNow;
			Engine->iAniStep++;
			if(Engine->iAniStep >= 32)
				Engine->iAniStep = 0;
		}
		// Flickering engine light:
		if(g_lNow-Engine->lPowerTimer > Engine->lPowerSpeed)
		{
			if(Engine->fLastPower > Engine->fNewPower)
			{
				Engine->fActualPower -= (float) g_lDeltatime/100;
				if(Engine->fActualPower <= Engine->fNewPower)
					goto NewPower;
			}
			if(Engine->fLastPower <= Engine->fNewPower)
			{
				Engine->fActualPower += (float) g_lDeltatime/100;
				if(Engine->fActualPower >= Engine->fNewPower)
				{
				NewPower:
					Engine->fActualPower = Engine->fNewPower;
					Engine->lPowerTimer = g_lNow;
					Engine->lPowerSpeed = 1+(rand() % 5);
					Engine->fLastPower = Engine->fNewPower;
					for(;;)
					{
						Engine->fNewPower = 0.2f+((float) (rand() % 100)/120);
						if(Engine->fLastPower-Engine->fNewPower > 0.3f ||
						    Engine->fLastPower-Engine->fNewPower < -0.3f)
							break;
					}
				}
			}
		}
	}

	// Engine particles:
	// Main engine:
	fPower = Player.fAfterburnerPower;
	if(fPower)
		CreateEngineParticles(pPlayerShipHull, 386, 385, PS_PLAYER_SHIP_MAIN_ENGINE,
							  (long) (40+40*(1.0f-fPower)), 100000.0f*fPower, 0.01f, fPos2,
							  pPlayer->vRot, 1.0f, 0, 15.0f, 500);
	// Right engine:
	fPower = Player.ShipEngine[RIGHT_SHIP_ENGINE].fPower;
	if(fPower)
		CreateEngineParticles(pPlayerShipHull, 175, 327, PS_PLAYER_SHIP_RIGHT_ENGINE,
							  (long) (20+20*(1.0f-fPower)), 15000.0f, 0.03f, fPos2,
							  pPlayer->vRot, 1.0f, 0, 30.0f, 300);
	// Left engine:
	fPower = Player.ShipEngine[LEFT_SHIP_ENGINE].fPower;
	if(fPower)
		CreateEngineParticles(pPlayerShipHull, 186, 185, PS_PLAYER_SHIP_LEFT_ENGINE,
							  (long) (20+20*(1.0f-fPower)), 15000.0f, 0.03f, fPos2,
							  pPlayer->vRot, 1.0f, 0, 30.0f, 300);
	// Right bottom engine:
	fPower = Player.ShipEngine[RIGHT_BOTTOM_SHIP_ENGINE].fPower;
	if(fPower)
		CreateEngineParticles(pPlayerShipHull, 230, 231, PS_PLAYER_SHIP_RIGHT_BOTTOM_ENGINE,
							  (long) (20+20*(1.0f-fPower)), 15000.0f, 0.03f, fPos2,
							  pPlayer->vRot, 1.0f, 0, 30.0f, 300);
	// Left bottom engine:
	fPower = Player.ShipEngine[LEFT_BOTTOM_SHIP_ENGINE].fPower;
	if(fPower)
		CreateEngineParticles(pPlayerShipHull, 232, 233, PS_PLAYER_SHIP_LEFT_BOTTOM_ENGINE,
							  (long) (20+20*(1.0f-fPower)), 15000.0f, 0.03f, fPos2,
							  pPlayer->vRot, 1.0f, 0, 30.0f, 300);
	// Backward:
	fPower = Player.ShipEngine[BACKWARD_SHIP_ENGINE].fPower;
	if(fPower)
		CreateEngineParticles(pPlayerShipHull, 201, 202, PS_PLAYER_SHIP_BACKWARD_ENGINE,
							  (long) (35+35*(1.0f-fPower)), 30000.0f, 0.03f, fPos2,
							  pPlayer->vRot, 1.0f, 0, 30.0f, 600);
	// Top:
	fPower = Player.ShipEngine[TOP_SHIP_ENGINE].fPower;
	if(fPower)
		CreateEngineParticles(pPlayerShipHull, 167, 174, PS_PLAYER_SHIP_TOP_ENGINE,
							  (long) (30+30*(1.0f-fPower)), 15000.0f, 0.03f, fPos2,
							  pPlayer->vRot, 1.0f, 0, 30.0f, 300);
	// Bottom:
	fPower = Player.ShipEngine[BOTTOM_SHIP_ENGINE].fPower;
	if(fPower)
		CreateEngineParticles(pPlayerShipHull, 196, 193, PS_PLAYER_SHIP_BOTTOM_ENGINE,
							  (long) (30+30*(1.0f-fPower)), 15000.0f, 0.03f, fPos2,
							  pPlayer->vRot, 1.0f, 0, 30.0f, 300);
	// Top front:
	fPower = Player.ShipEngine[TOP_FRONT_SHIP_ENGINE].fPower;
	if(fPower)
		CreateEngineParticles(pPlayerShipHull, 373, 374, PS_PLAYER_SHIP_TOP_FRONT_ENGINE,
							  (long) (30+30*(1.0f-fPower)), 15000.0f, 0.03f, fPos2,
							  pPlayer->vRot, 1.0f, 0, 30.0f, 300);
	// Bottom front:
	fPower = Player.ShipEngine[BOTTOM_FRONT_SHIP_ENGINE].fPower;
	if(fPower)
		CreateEngineParticles(pPlayerShipHull, 375, 376, PS_PLAYER_SHIP_BOTTOM_FRONT_ENGINE,
							  (long) (30+30*(1.0f-fPower)), 15000.0f, 0.03f, fPos2,
							  pPlayer->vRot, 1.0f, 0, 30.0f, 300);
} // end CheckPlayerShipEngine()
//-----------------------------------------------------------------------------
// File: Environment.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
ENVIRONMENT Environment;
///////////////////////////////////////////////////////////////////////////////


ENVIRONMENT::ENVIRONMENT(void)
{ // begin ENVIRONMENT::ENVIRONMENT()
	memset(this, 0, sizeof(ENVIRONMENT));
	fAblazeBox[MIN][X] = 
	fAblazeBox[MIN][Y] = 
	fAblazeBox[MIN][Z] = -30.0f;
	fAblazeBox[MAX][X] = 
	fAblazeBox[MAX][Y] = 
	fAblazeBox[MAX][Z] = -30.0f;
	fSphereRadius = 1000.f;
} // end ENVIRONMENT::ENVIRONMENT()

void ENVIRONMENT::SetupLights(void)
{ // begin ENVIRONMENT::SetupLights()
	GLfloat fLightData[4]  = {0.0f, 0.0f, 0.0f, 0.0f};

	ASEnableLighting();
	
	// Main environment light:
	if(_AS->iActiveLights+1 < _AS->iMaxLights)
	{
		fLightData[0] = 0.9f;
		fLightData[1] = 0.9f;
		fLightData[2] = 0.9f;
		fLightData[3] = 1.0f;
		glLightfv(GL_LIGHT2, GL_POSITION, fLightData);
		fLightData[0] = 0.4f;
		fLightData[1] = 0.3f;
		fLightData[2] = 0.3f;
		fLightData[3] = 1.0f;
		glLightfv(GL_LIGHT2, GL_AMBIENT, fLightData);
		glEnable(GL_LIGHT2);
		_AS->iActiveLights += 2;
	}

	// Ablaze light:
	if(_AS->iActiveLights+1 < _AS->iMaxLights)
	{
		fLightData[0] = 0.5f;
		fLightData[1] = 0.5f;
		fLightData[2] = 0.5f;
		fLightData[3] = 0.0f;
		glLightfv(GL_LIGHT0+_AS->iActiveLights, GL_POSITION, fLightData);
		fLightData[0] = 0.0f;
		fLightData[1] = 0.0f;
		fLightData[2] = 0.5f;
		fLightData[3] = 0.01f;
		glLightfv(GL_LIGHT0+_AS->iActiveLights, GL_SPECULAR, fLightData);
		glEnable(GL_LIGHT0+_AS->iActiveLights);
		_AS->iActiveLights++;
	}
} // end ENVIRONMENT::SetupLights()

void ENVIRONMENT::Draw(void)
{ // begin ENVIRONMENT::Draw()
	GLfloat fFogColor[4] = {0.0, 0.0, 0.0, 1.0};

	ASDrawBoundingBox(fAblazeBox, 1.0f);
	
	// Draw the environment sphere:
	glDisable(GL_FOG);
	glDisable(GL_CULL_FACE);
	glEnable(GL_BLEND);
	glDepthMask(FALSE);
	
	// Setup fog:
	glFogi(GL_FOG_MODE, GL_EXP);
	glFogfv(GL_FOG_COLOR, fFogColor);
	glFogf(GL_FOG_DENSITY, 0.005f);
	
	// Setup texture stuff:
	glColor4f(0.5f*fSphereColor, 0.5f*fSphereColor, 1.0f*fSphereColor, 0.99f);
	glBindTexture(GL_TEXTURE_2D, Caust1Texture[iSphereAniStep].iOpenGLID);
	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);

	_ASCamera->SetCameraTranslation(FALSE);
	glCallList(iEnvironmentSphereList);
	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);
	glDisable(GL_LIGHTING);
	glDepthMask(TRUE);
} // end ENVIRONMENT::Draw()

void ENVIRONMENT::Check(void)
{ // begin ENVIRONMENT::Check()
	// Animate the environment sphere:
	if(g_lNow-lSphereAniTime > 40)
	{
		lSphereAniTime = g_lNow;
		iSphereAniStep++;
		if(iSphereAniStep >= CAUST_1_STEPS)
			iSphereAniStep = 0;
	}
	// Animate the sphere light:
	if(fLastSphereColor < fNewSphereColor)
	{
		fSphereColor += ((float) g_lDeltatime/500)*fSphereColorSpeed;
		if(fSphereColor >= fNewSphereColor)
			goto IniNewSphereColor;
	}
	else
	{
		fSphereColor -= ((float) g_lDeltatime/500)*fSphereColorSpeed;
		if(fSphereColor <= fNewSphereColor)
		{
		IniNewSphereColor:
			fLastSphereColor = fSphereColor;
			fNewSphereColor = (float) 0.3f+(rand() % 100)/130.0f;
			fSphereColorSpeed = (float) (rand() % 1000)/800.0f;
		}
	}
} // end ENVIRONMENT::Check()

void ENVIRONMENT::DrawSkyCube(void)
{ // begin ENVIRONMENT::DrawSkyCube()
	_ASCamera->SetCameraTranslation(TRUE);
	glColor3f(1.0f, 1.0f, 1.0f);
	glCallList(iAsteroidBeltList);
} // end ENVIRONMENT::DrawSkyCube()

//-----------------------------------------------------------------------------
// File: Player.h
//-----------------------------------------------------------------------------

#ifndef __AS_PLAYER_H__
#define __AS_PLAYER_H__


// Definitions: ***************************************************************
#define PLAYER_SHIP_ENGINES 10
///////////////////////////////////////////////////////////////////////////////

// Structures: ****************************************************************
typedef struct PLAYER
{
	SHIP_ENGINE ShipEngine[PLAYER_SHIP_ENGINES];
	float fShieldLight[8];
	BOOL bShieldLight[8];
	float fAfterburnerPower,
		  fDamagePulse,
		  fAfterburnerEngine;
	float fMaxAfterburnerEngine,
		  fAfterburnerEngineDecreaseSpeed,
		  fAfterburnerEngineRegenerationSpeed;
	BOOL bDamagePulse,
		 bTarget, // Is something in the view line?
		 fAfterburnerRegeneration; // Is the afterburner regenerating?
								   // (it couldn't be used in that time)
	float fTargetDistance, // Distance to the target in the view
		  fFixedTargetDistance; // Distance to the selected targets
	int iTargetID, // The current target which is in the view
		iFixedTargetID; // The current selected target
	ACTOR Actor; // The players actor
	BOOL bPilotView; // Are we in the pilot view mode?

	int iPrimaryWeapon; // The selected primary weapon

} PLAYER;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern PLAYER Player;
extern FLOAT4 fPlayerPosR[8];
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern void SetupPlayerLight(int, int, FLOAT3);
extern void SetupPlayerLights(void);
extern void PlayerControl(void);
extern void DrawPlayerSolid(void);
extern void DrawPlayerTransparent(void);
extern void InitPlayer(void);
extern void CheckPlayer(void);
extern BOOL CheckPlayerCollision(void);
extern void CheckBallCollision(ACTOR *, ACTOR *, AS_3D_VECTOR);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_PLAYER_H__
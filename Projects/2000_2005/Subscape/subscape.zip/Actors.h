//-----------------------------------------------------------------------------
// File: Actors.h
//-----------------------------------------------------------------------------

#ifndef __ACTORS_H__
#define __ACTORS_H__


// Definitions: ***************************************************************
#define MAX_ACTORS 100
// Actor types:
enum
{
	ACTOR_PLAYER_SHIP, ACTOR_ASTEROID, ACTOR_PHASER_SHOT,
};
// Weapons:
enum
{
	PHASER_WEAPON,
};

///////////////////////////////////////////////////////////////////////////////

// Structures: ****************************************************************
typedef class ACTOR
{
	public:
		BOOL bActive, // Is the actor active?
			 bGoingDeath; // Is he going death?
		float fDamage; // It's damage
		int iID; // It's ID
		char byType; // The type of the actor
		
		ACTOR *pParentActor; // It'a parent actor
		
		AS_3D_VECTOR vWorldPos, // The current world position
					 vLastWorldPos, // The last world position
					 vWorldVelocity, // The world velocity
					 vRot, vRotVelocity, // The rotation
					 vDirectionVector, // The direction vector (object orientation)
				     vRightVector, // The up direction vector
				     vUpVector; // The right direction vector
		float  fSlideLRVelocity, // Left/right slide velocity
			   fSlideUDVelocity; // Up/down slide velocity
		float fForward, // The acceleration in the current direction
			  fBackward, // The acceleration in the current direction
			  fNormalMaxVelocity, // The normal max velocity
			  fCurrentMaxVelocity, // The current max velocity
			  fMaxVelocity; // The maximum velocity (Afterburner)
		AS_QUATERNION qRotation; // The rotation saved as an quaternion
		
		
		float fRadius, fMass;
		
		FLOAT3 fColor;
		// Animation:
		int byAnimation;		// The current animation depends on the current action
		int iAniStep,			// The current animation step
			iNextAniStep;		// The next animation step
		DWORD dwAniTime,		// The time since the last animation step change
			  dwAniDeltaTime;	// The past ani time (for pausing the animation)
		float fModelInterpolation;

		// Weapon state:
		BOOL bPrimaryWeaponReady;
		float fPrimaryWeaponReady;


		void Apply(void);
		void ApplyToCamera(BOOL);
		void Update(void);

} ACTOR;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern ACTOR Actor[MAX_ACTORS];
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern void DrawActors(void);
extern BOOL CheckActors(BOOL);
extern void InitActors(void);
extern ACTOR *FindFreeActor(void);
///////////////////////////////////////////////////////////////////////////////


#endif // __ACTORS_H__
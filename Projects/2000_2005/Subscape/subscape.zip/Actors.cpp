//--------------------.f--------------------------------------------------------
// File: Actors.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
ACTOR Actor[MAX_ACTORS];
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
void DrawActors(void);
BOOL CheckActors(BOOL);
void InitActors(void);
ACTOR *FindFreeActor(void);
///////////////////////////////////////////////////////////////////////////////


// ACTOR functions: ***********************************************************
void ACTOR::Apply(void)
{ // end ACTOR::Apply()
	float fAxisX, fAxisY, fAxisZ, fRotAngle;
	
	glTranslatef(vWorldPos.fX, vWorldPos.fY, -vWorldPos.fZ);
	qRotation.GetAxisAngle(fAxisX, fAxisY, fAxisZ, fRotAngle);
	glRotatef((float) (fRotAngle*RAD_TO_DEG), fAxisX, fAxisY, -fAxisZ);
} // end ACTOR::Apply()

void ACTOR::ApplyToCamera(BOOL bOnlyRot)
{ // begin ACTOR::ApplyToCamera()
	float axisX, axisY, axisZ, rotAngle;
	
	qRotation.GetAxisAngle(axisX, axisY, axisZ, rotAngle);
	glRotatef((float) (rotAngle*RAD_TO_DEG), -axisX, -axisY, axisZ);
	if(!bOnlyRot)
		glTranslatef(-vWorldPos.fX, -vWorldPos.fY, vWorldPos.fZ);
} // end ACTOR::ApplyToCamera()

void ACTOR::Update(void)
{ // begin ACTOR::Update()
	float fRadius1, fRadius2, fDistance, fResVelo, fFactor;
	float fSpeed = (float) g_lDeltatime/1000;
	AS_QUATERNION qRotationT;
	int i;

	// Slide movement:
	// Left/right:
	memcpy(&qRotationT, &qRotation, sizeof(AS_QUATERNION));
	qRotation.PostMult(AS_QUATERNION(0.0f, 90.0f, 0.0f));
	qRotation.GetDirectionVector(&vRightVector);
	for(i = 0; i < 3; i++)
		vWorldVelocity.fV[i] += (vRightVector.fV[i]*fSlideLRVelocity)*fSpeed*15;
	memcpy(&qRotation, &qRotationT, sizeof(AS_QUATERNION));

	// Up/Down:
	qRotation.PostMult(AS_QUATERNION(90.0f, 0.0f, 0.0f));
	qRotation.GetDirectionVector(&vUpVector);
	for(i = 0; i < 3; i++)
		vWorldVelocity.fV[i] += (vUpVector.fV[i]*fSlideUDVelocity)*fSpeed*15;
	memcpy(&qRotation, &qRotationT, sizeof(AS_QUATERNION));
	
	// Normal movement:
	// Compute the direction vector:
	qRotation.PostMult(AS_QUATERNION(vRotVelocity.fPitch*fSpeed/5,
									 vRotVelocity.fHeading*fSpeed/5,
									 vRotVelocity.fRoll*fSpeed/5));
	qRotation.GetDirectionVector(&vDirectionVector);
	for(i = 0; i < 3; i++)
	{
		// Update the velocity:
		vWorldVelocity.fV[i] += (vDirectionVector.fV[i]*fForward)*fSpeed;
		vWorldVelocity.fV[i] += (vDirectionVector.fV[i]*fBackward)*fSpeed;
		
		// Update the world position:
		vLastWorldPos.fV[i] = vWorldPos.fV[i];
		vWorldPos.fV[i] += vWorldVelocity.fV[i]*fSpeed;
		
		// Update rotation:
		vRot.fV[i] += vRotVelocity.fV[i]*fSpeed*10;
		if(vRot.fV[i] >= 360.0f)
			vRot.fV[i] -= 360.0f;
		else
			if(vRot.fV[i] < 0.0f)
				vRot.fV[i] += 360.0f;

		// Decrease the velocities:
		vWorldVelocity.fV[i] -= vWorldVelocity.fV[i]/200.0f*((float) g_lDeltatime/30);
		vRotVelocity.fV[i] -= vRotVelocity.fV[i]/60.0f*((float) g_lDeltatime/30);
	}
	
	fDistance = vWorldPos.GetLength();
	if(byType != ACTOR_PHASER_SHOT)
	{
		fResVelo = vWorldVelocity.GetLength();
		if(fResVelo > fCurrentMaxVelocity)
		{ // The velocity is to high!!
			fFactor = fCurrentMaxVelocity/fResVelo;
			for(i = 0; i < 3; i++)
				vWorldVelocity.fV[i] *= fFactor;
		}

		fSlideLRVelocity -= fSlideLRVelocity/10.0f*((float) g_lDeltatime/30);
		fSlideUDVelocity -= fSlideUDVelocity/10.0f*((float) g_lDeltatime/30);

		if(fForward > fCurrentMaxVelocity)
			fForward = fCurrentMaxVelocity;
		if(fForward < -fCurrentMaxVelocity)
			fForward = -fCurrentMaxVelocity;
		if(fForward > fCurrentMaxVelocity)
			fForward= fCurrentMaxVelocity;
		if(fBackward > fCurrentMaxVelocity)
			fBackward = fCurrentMaxVelocity;
		if(fBackward < -fCurrentMaxVelocity)
			fBackward = -fCurrentMaxVelocity;
		if(fBackward > fCurrentMaxVelocity)
			fBackward = fCurrentMaxVelocity;
		if(fSlideLRVelocity > fCurrentMaxVelocity)
			fSlideLRVelocity = fCurrentMaxVelocity;
		if(fSlideLRVelocity < -fCurrentMaxVelocity)
			fSlideLRVelocity = -fCurrentMaxVelocity;
		if(fSlideUDVelocity > fCurrentMaxVelocity)
			fSlideUDVelocity = fCurrentMaxVelocity;
		if(fSlideUDVelocity < -fCurrentMaxVelocity)
			fSlideUDVelocity = -fCurrentMaxVelocity;
	}

	// Check if the actor is near outside the sphere:
	if(fDistance > Environment.fSphereRadius-10.0f)
	{ // Yea, he should bounce off:
		for(i = 0; i < 3; i++)
		{
			if(vWorldPos.fV[i] > 0.0f)
			{
				if(!fDistance)
					vWorldVelocity.fV[i] += 200.0f*fSpeed;
				else
				{
					if(!vWorldVelocity.fV[i] || (vWorldVelocity.fV[i] < 1.0f && vWorldVelocity.fV[i] > -1.0f))
						vWorldVelocity.fV[i] -= fDistance/200.0f*fSpeed*10;
					else
					if(vWorldVelocity.fV[i] > 0.0f)
						vWorldVelocity.fV[i] -= fDistance/200.0f*fSpeed*vWorldVelocity.fV[i]*2;
					else
						vWorldVelocity.fV[i] += fDistance/200.0f*fSpeed*vWorldVelocity.fV[i]*2;
				}
			}
			else
			{
				if(!fDistance)
					vWorldVelocity.fV[i] -= 200.0f*fSpeed;
				else
				{
					if(!vWorldVelocity.fV[i] || (vWorldVelocity.fV[i] < 1.0f && vWorldVelocity.fV[i] > -1.0f))
						vWorldVelocity.fV[i] += fDistance/200.0f*fSpeed*10;
					else
					if(vWorldVelocity.fV[i] < 0.0f)
						vWorldVelocity.fV[i] -= fDistance/200.0f*fSpeed*vWorldVelocity.fV[i]*2;
					else
						vWorldVelocity.fV[i] += fDistance/200.0f*fSpeed*vWorldVelocity.fV[i]*2;
				}
			}
		}
	}

	// Check if the actor is in the range of the center ablaze:
	if(vWorldPos.fX > Environment.fAblazeBox[0][X] &&
	   vWorldPos.fY > Environment.fAblazeBox[0][Y] &&
	   vWorldPos.fZ > Environment.fAblazeBox[0][Z] &&
	   vWorldPos.fX < Environment.fAblazeBox[1][X] &&
	   vWorldPos.fY < Environment.fAblazeBox[1][Y] &&
	   vWorldPos.fZ < Environment.fAblazeBox[1][Z])
	{ // Yea, it's in range, he should bounce off:
		for(i = 0; i < 3; i++)
		{
			if(vWorldPos.fV[i] > 0.0f)
			{
				if(!fDistance)
					vWorldVelocity.fV[i] += 30.0f*fSpeed;
				else
				{
					if(!vWorldVelocity.fV[i] || (vWorldVelocity.fV[i] < 1.0f && vWorldVelocity.fV[i] > -1.0f))
						vWorldVelocity.fV[i] += 30.0f/fDistance*fSpeed*10;
					else
					if(vWorldVelocity.fV[i] > 0.0f)
						vWorldVelocity.fV[i] += 30.0f/fDistance*fSpeed*vWorldVelocity.fV[i]*2;
					else
						vWorldVelocity.fV[i] -= 30.0f/fDistance*fSpeed*vWorldVelocity.fV[i]*2;
				}
			}
			else
			{
				if(!fDistance)
					vWorldVelocity.fV[i] -= 30.0f*fSpeed;
				else
				{
					if(!vWorldVelocity.fV[i] || (vWorldVelocity.fV[i] < 1.0f && vWorldVelocity.fV[i] > -1.0f))
						vWorldVelocity.fV[i] -= 30.0f/fDistance*fSpeed*10;
					else
					if(vWorldVelocity.fV[i] < 0.0f)
						vWorldVelocity.fV[i] += 30.0f/fDistance*fSpeed*vWorldVelocity.fV[i]*2;
					else
						vWorldVelocity.fV[i] -= 30.0f/fDistance*fSpeed*vWorldVelocity.fV[i]*2;
				}
			}
		}
	}

	// Check if the actor collides with the sphere:
	fRadius1 = fRadius;
	fRadius2 = Environment.fSphereRadius-(fRadius*2);
 	if(fDistance >= (fRadius1+fRadius2)*(fRadius1+fRadius2))
	{ // The actor collides with the wall of the subspace bubble!
		if(byType == ACTOR_PLAYER_SHIP)
		{
			for(i = 0; i < 8; i++)
				Player.bShieldLight[i] = TRUE;
		}
		vWorldVelocity.Invert();
		vWorldPos = vLastWorldPos;
	}
} // end ACTOR::Update()
///////////////////////////////////////////////////////////////////////////////

void DrawActors(void)
{ // begin DrawActors()
	ACTOR *pActor;
	int i;

	glCullFace(GL_FRONT);
	glCullFace(GL_BACK);
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_BLEND);
	glColor3f(0.5f, 0.5f, 0.5f);
	glBindTexture(GL_TEXTURE_2D, GameTexture[16].iOpenGLID);
	glEnable(GL_AUTO_NORMAL);
	ASEnableLighting();
	for(i = 0; i < MAX_ACTORS; i++)
	{
		pActor = &Actor[i];
		if(!pActor->bActive)// ||
//		   !CubeInFrustum(pActor->fWorldPos[X], pActor->fWorldPos[Y],
//						  pActor->fWorldPos[Z], pActor->fRadius*100))
			continue;
		glPushMatrix();
		glColor3f(1.0f, 1.0f, 1.0f);
		pActor->Apply();

		if(pActor->byType == ACTOR_PHASER_SHOT)
		{
			pActor->fRadius = 0.2f;
			glEnable(GL_BLEND);
			glColor4f(1.0f, 1.0f, 1.0f, 0.9f);
		}
		else
			glDisable(GL_BLEND);
	
//		glScalef(pActor->fRadius, pActor->fRadius, pActor->fRadius);
		GLUquadricObj *pQuadric;
		pQuadric = gluNewQuadric();
		gluQuadricDrawStyle(pQuadric, GLU_FILL);
		gluQuadricNormals(pQuadric, GLU_SMOOTH);
		gluQuadricTexture(pQuadric, GL_TRUE);
		gluSphere(pQuadric, pActor->fRadius, 50, 50);
		gluDeleteQuadric(pQuadric);

//		ASDrawMd2Frame(pAsteroid, 0);
		if(Player.iFixedTargetID == i || Player.iTargetID == i)
		{
			_ASConfig->bDrawBounding = TRUE;
			if(Player.iFixedTargetID == i)
				glColor3f(1.0f, 0.0f, 0.0f);
			else
				glColor3f(1.0f, 1.0f, 1.0f);
			ASDrawBoundingBox(pAsteroid->fBoundingBox, pActor->fRadius);
			_ASConfig->bDrawBounding = FALSE;
		}
		glPopMatrix();
	}
} // end DrawActors()

BOOL CheckActors(BOOL bOnlyCheck)
{ // begin CheckActors()
	float fDistance;
	BOOL bCollision = FALSE;
	ACTOR *pActor, *pActor2;
	AS_3D_VECTOR vDelta;
	int i, i2;

	for(i = 0; i < MAX_ACTORS; i++)
	{
		pActor = &Actor[i];
		if(!pActor->bActive)
			continue;
		if(!bOnlyCheck)
			pActor->Update();
		if(!pActor->vWorldVelocity.fX && !pActor->vWorldVelocity.fY && !pActor->vWorldVelocity.fZ)
			continue;
		for(i2 = 0; i2 < MAX_ACTORS; i2++)
		{
			if(i == i2)
				continue;
			pActor2 = &Actor[i2];
			if(!pActor2->bActive)
				continue;
			vDelta = pActor->vWorldPos-pActor2->vWorldPos;
			fDistance = vDelta.DotProduct();
			if(fDistance <= (pActor->fRadius+pActor2->fRadius)*(pActor->fRadius+pActor2->fRadius))
			{ // We have a collision!
				if(!bOnlyCheck)
					CheckBallCollision(pActor, pActor2, vDelta);
				bCollision = TRUE;
			}
		}
		if(bCollision && !bOnlyCheck)
			pActor->vWorldPos = pActor->vLastWorldPos;
	}
	return bCollision;
} // end CheckActors()

void InitActors(void)
{ // begin InitActors()
	ACTOR *pActor;
	int i, i2;

	memset(Actor, 0, sizeof(ACTOR)*MAX_ACTORS);
		
	for(i = 0; i < 5; i++)
	{
		pActor = &Actor[i];
		pActor->bActive = TRUE;
		for(;;)
		{
			for(i2 = 0; i2 < 3; i2++)
			{
				if((rand() % 2))
					pActor->vWorldPos.fV[i2] = (float) ((rand() % ((short) (Environment.fSphereRadius-20)*10000)))/50;
				else
					pActor->vWorldPos.fV[i2] = (float) -((rand() % ((short) (Environment.fSphereRadius-20)*10000)))/50;
				if(pActor->vWorldPos.fV[i2] < 30.0 && pActor->vWorldPos.fV[i2] > -30.0)
					i2--;
			}
			 //&& !CheckPlayerCollision()
			if(!(rand() % 10))
				pActor->fRadius = (float) (rand() % 200000)/500;
			else
				pActor->fRadius = (float) (rand() % 200000)/2000;
			if(!CheckActors(TRUE))
				break;
		}

		pActor->byType = ACTOR_ASTEROID;
		pActor->fMass = pActor->fRadius*((float) PI);
		pActor->qRotation.Reset();
	}
} // end InitActors()

ACTOR *FindFreeActor(void)
{ // begin FindFreeActor()
	ACTOR *pActorT;

	// Find a none active actor and give a pointer to it back:
	for(int i = 0; i < MAX_ACTORS; i++)
	{
		pActorT = &Actor[i];
		if(pActorT->bActive)
			continue;
		memset(pActorT, 0, sizeof(ACTOR));	
		pActorT->iID = i;
		pActorT->dwAniTime = g_lNow;
		pActorT->fColor[0] = 1.0f;
		pActorT->fColor[1] = 1.0f;
		pActorT->fColor[2] = 1.0f;
		return pActorT;
	}
	return 0;
} // end FindFreeActor()
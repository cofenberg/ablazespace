#ifndef __AS_OBJECT_H__
#define __AS_OBJECT_H__


// Classes: *****************************************************************
// General object information
typedef struct AS_OBJECT_HEADER
{
	char byName[256];			   // The object name
	short iFrames;				   // The number of key-frames
	short iAnimations;		       // Number of animations (like run, jump...)
	short iNestLevel;			   // The nesting level of this object
	short iChildren;			   // The number of children
	BOOL bUseVertexColorData;	   // Should the vertex color saved
	BOOL bUseVertexTexturePosData; // Should the texture coordinates color saved
	BOOL bActive;				   // Is this object active? (visible... The children are drawn always)
	BOOL bChildrenActive;		   // Are the children active?
} AS_OBJECT_HEADER;

// A object key-frame
typedef struct AS_OBJECT_FRAME
{
	char byName[256];	  // The frame name
	short iID;			  // A individual ID 
	short iUsed;		  // The number of usage by animations
	MATRIX Matrix;		  // The matrix stores all transformations
	short iDiffuseColors; // Number of vertex colors
	FLOAT3 *fDiffuseColor;// All vertex colors
	short iVertices;      // Number of vertices
	FLOAT3 *fVertex;	  // All vertices
	short iNormals;		  // Number of normals
	FLOAT3 *fNormal;      // All normals colors
	short iTextureCoords; // Number of texture coordinates
	FLOAT2 *fTextureCoord;// All texture coordinates
	short iFaces;	      // Number of faces (polygons)
	SHORT3 *iFace;		  // All faces
	
	FLOAT3 fMin, fMax, fMiddle; // Bounding
} AS_OBJECT_FRAME;

// A single animation step
typedef struct AS_OBJECT_ANIMATION_STEP
{
	short iID;				 // A individual ID
	short iFrameID;			 // The key-frame ID of this step
	AS_OBJECT_FRAME *pFrame; // Pointer to the key-frame
	DWORD dwInterpolateTime; // The time which is required to go to the next frame
	// Precalculated (for speed increase) data.
	// They are normaly only one time calculated (at loading).
	FLOAT3 *fDiffuseColorIncreasePos;
	FLOAT3 *fVertexIncreasePos;
	FLOAT3 *fNormalIncreasePos;
	FLOAT2 *fTextureCoordIncreasePos;
	MATRIX MatrixIncrease;	 // The matrix stores all transformations
} AS_OBJECT_ANIMATION_STEP;

// A whole animation (like run, jump...)
typedef struct AS_OBJECT_ANIMATION
{
	char byName[256]; // The animation name
	short iID;		  // A individual ID
	short iSteps;	  // The number of animation steps
	AS_OBJECT_ANIMATION_STEP *pStep; // All animation steps
	AS_OBJECT_ANIMATION_STEP *pStepT; // Pointer to the current animation step
} AS_OBJECT_ANIMATION;

// A object
typedef class AS_OBJECT
{
	public:
		char *pbyFilename; // 
		short iID;
		MATRIX Matrix; // The scene matrix


		char *pbyTextureFilename;


		AS_OBJECT *pParent;
		AS_OBJECT **pChild;
	

		float fPos[3];
		float fScale[3];
		float fRot[3];
		float Radians;

		DWORD dwCurrentTime, dwLastTime, dwTimeDifference; // For the smooth animation
		AS_OBJECT_HEADER Header;
		AS_OBJECT_FRAME *pFrame;
		AS_OBJECT_FRAME *pFrameT; // Pointer to a frame
		AS_OBJECT_ANIMATION *pAnimation;
		AS_OBJECT_ANIMATION *pAnimationT; // Pointer to a animation
		AS_OBJECT_FRAME CurrentFrame; // The calculated current frame

		AS_OBJECT(void);
		~AS_OBJECT(void);
		void SetFrameT(short);
		void SetAnimationT(short);
		void SetAnimationStepT(short);
		void SetInterpolateTime(DWORD);
		void CalculateInterpolations(void);
		void CalculateCurrentFrame(void);
		void Draw(BOOL, BOOL, BOOL);
		void DrawBounding(void);
		void Destroy(void);
		HRESULT Load(char *);
		HRESULT LoadPart(FILE *);
		void SetupAnimationData(BOOL);

} AS_OBJECT;
///////////////////////////////////////////////////////////////////////////////


#endif //__AS_OBJECT_H__
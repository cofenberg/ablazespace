/*
 *	The game Invasion was written by Christian Ofenberg 2000. (www.ablazespace.de)
 * 	The most functions were taken out from the tutorials from NeHe. (nehe.gamedev.net)
 * 	So a big thank to Jeff Molofee for his great homepage who helps 
 *	people which started in OpenGL coding.
 */
#define APP_TITLE "Invasion"
#define VERSION "V1.1"

#include "Invasion.h"
#include "Levels.h"

typedef struct AS_TEXTURE
{
	char byFilename[256]; // The filename of the texture
	BYTE *pbyData; // The texture data
	int iColorDepth; // Color depth
	int iWidth, iHeight; // The size of the texture
	int iID; // The ID
	GLuint iOpenGLID; // The OpenGL ID
	int iUsed; // How often is this texture used?
	GLenum iFormat; // The texture format RGB or RGBA
	int iImageBits; // The number of image bit depth
	char byColorComponents; // The number of color components
	BOOL bNoMipmap; // This texture should never used as mipmap (maybe there are some graphic bugs...)

} AS_TEXTURE;

#define WORLD_WIDTH			22	// Holds The Width Of Our World
#define  WORLD_HALFWIDTH	11	// Holds Half The Width Of Our World
#define  WORLD_HEIGHT		16	// Holds The Height Of Our World
#define  WORLD_HALFHEIGHT	8	// Holds Half The Height Of Our World
#define  WORLD_DEPTH		-20	// 

#define TEXTURES 16				// The Number Of Used Textures
#define NUM_LISTS 1			// The Number Of Display Lists

HDC			hDC=NULL;		// Private GDI Device Context
HGLRC		hRC=NULL;		// Permanent Rendering Context
HWND		hWnd=NULL;		// Holds Our Window Handle
HINSTANCE	hInstance;		// Holds The Instance Of The Application
HANDLE hMutex;              // Whith this handle we could go sure that the program
							// runs only one time at the same time

bool	keys[256];			// Array Used For The Keyboard Routine
bool	active=TRUE;		// Window Active Flag Set To TRUE By Default
bool    bSoundPossible;     // Is Sound Possible?
int iCmdShow;

LRESULT	CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);	// Declaration For WndProc

GLuint	base;				// Base Display List For The Font
AS_TEXTURE GameTexture[TEXTURES];
//GLuint	texture[TEXTURES];	// Storage For Our Font Texture
GLuint background_list;		// The Background List
GLuint	loop;				// Generic Loop Variable
char byTemp[256];			// Generic String Variable
GLfloat g_fBackgroundRot = 0.0f;	// Background Motion Velocity

int	 g_iFps					= 0;		// Frames Per Second Variable
long g_lGameLength			= 0;		// Application Run Time Variable
long g_lNow	                = 0;		// The Actual Time
long g_lLastlooptime		= 0;		// Time When Last Loop Was Started
long g_lDeltatime			= 0;		// Change In Time Since Last Iteration
long g_lFramesRendered		= 0;		// The Total Number Of Rendered Frames
long g_lProgramStartTime	= 0;		// The Program Start Time
long g_lLastChecktime       = 0;		// The Time Where The Last FPS Update happened
long g_lFramesRenderedSinceCheck = 0;   // The Number Of Frames Rendered Since The Last FPS Update
// General Light
GLfloat LightDiffuse[]	= { 0.5f, 0.5f, 0.5f, 1.0f }; 
GLfloat LightAmbient[]	= { 0.8f, 0.8f, 0.8f, 1.0f };
GLfloat LightPosition[]	= { 10.0f, 10.0f, 10.0f, 1.0f };
// Path Info
char ExeName[_MAX_PATH];
char Drive[_MAX_DRIVE];
char Dir[_MAX_DIR];
char Directory[_MAX_DRIVE+_MAX_DIR];
// OpenGL Info
char *pbyOpenGLVersion, *pbyOpenGLChipInfo, *pbyOpenGLRendererInfo, *pbyOpenGLExtensionInfo;
///////////////////////////////////////////////////////////////////

SYSTEMTIME MidiStartTime;
char byMidi;
int iMaxLights;							// The Maximum Number Of Lights Which Are Supported
char byWall[MAX_ALIEN_COLUMN];			// All Walls
char LEVELS;							// The Number Of Levels
char byLevel,							// The Current Level Number
	 byStartLevel;						// The start level
AS_CONFIG Config;						// Configurations Info
LEVEL *pLevel;							// Pointer To The Current Level
LEVEL *pLevels[NORMAL_LEVELS];						// Pointer To All Levels
// Normal Levels
LEVEL *pNormalLevels[NORMAL_LEVELS] = 
	   {&Level1, &Level2, &Level3, &Level4, &Level5, &Level6, &Level7, &Level8,
	    &Level9, &Level10, &Level11, &Level12, &Level13, &Level14, &Level15, &Level16};
// Easter Egg Levels
LEVEL *pEasterEggLevels[NORMAL_LEVELS] = 
	   {&EasterEggLevel1, &EasterEggLevel2, &EasterEggLevel3, &EasterEggLevel4,
	    &EasterEggLevel5, &EasterEggLevel6, &EasterEggLevel7, &EasterEggLevel8,
		&EasterEggLevel9, &EasterEggLevel10, &EasterEggLevel11};
// All Game Objects
AS_OBJECT *pPlanet;
AS_OBJECT *pShot1;
AS_OBJECT *pShot2;
AS_OBJECT *pShot3;
AS_OBJECT *pWormholeShot;
AS_OBJECT *pAlien1;
AS_OBJECT *pAlien2;
AS_OBJECT *pAlien3;
AS_OBJECT *pAlien4;
AS_OBJECT *pAlien5;
AS_OBJECT *pBigBoss;
AS_OBJECT *pShip;
AS_OBJECT *pWall;
AS_OBJECT *pPower;
AS_OBJECT *pObjectLive;
AS_OBJECT *pObjectWall;
AS_OBJECT *pObjectSingleLaser;
AS_OBJECT *pObjectDoubleLaser;
AS_OBJECT *pObjectPowerIncrease;
// All Sounds
SoundObject *pExplosion1Sound;
SoundObject *pExplosion2Sound;
SoundObject *pWormholeSound;
SoundObject *pInvasionSound;
SoundObject *pPlayerShotSound;
SoundObject *pAlienShotSound;
SoundObject *pAlien5ShotSound;
SoundObject *pBigBossShotSound;
SoundObject *pWormholeShotSound;
SoundObject *pAlien5DeadSound;
SoundObject *pBigBossDeadSound;
SoundObject *pAlienAttackSound;
SoundObject *pObjectLiveSound;
SoundObject *pObjectWallSound;
SoundObject *pObjectSingleLaserSound;
SoundObject *pObjectDoubleLaserSound;
SoundObject *pObjectPowerIncreaseSound;
// All Actors
ACTOR pPlayer;
ACTOR pAlien[MAX_ALIENS];
ACTOR pObject[MAX_OBJECTS];
ACTOR pShot[MAX_SHOTS];
// Game Variables
float fPlanetZScale, fPlanetZScaleVelocity;	// Planet Stuff
FLOAT3 fRot;							// The Game Field Rotation
float fZPos, fXRot;						// The Game Field Direction
BOOL bGameOver;							// Is The Game Over?
BOOL bGameWon;							// Is The Game Won?
long lLastPlayerShotTime;
// The Wormhole Animation
char byWormholeAni[WORMHOLE_ANIS] = {7, 8, 9, 10, 11, 10, 9, 8, 7, 8};
char byWormholeAniStep;					// The Current Wormhole Animation Step
float fWormholeHitPoints;				// The Wormhole Hitpoints
char byPlayerWeapon;					// The Current Player Weapon
long iScore;							// The Players Score
BOOL done;								// Bool Variable To Exit The Main Loop
BOOL bAnyKeyMessage;					// For The Blinking Any Key Message In The Game Intro
BOOL bShowHighscore;					// Should The Highscore Displayed At The Game Intro
BOOL bMoorhuhnCheat, bInvulnerableCheat, bUnlimitedPower, bAlwaysDouble;
// Highscore stuff
typedef struct
{
	char byName[30];
	int iLevel;
	long iScore;
} HIGHSCORE;

HIGHSCORE Highscore[MAX_HIGHSCORES] = 
{
	{"Invasion", 1, 1000},
	{"is a AblazeSpace", 0, 1},
	{"project", 0, 1},
	{"-------", 0, 1},
	{"Programmed & Designed", 0, 1},
	{"by Christian Ofenberg", 0, 1},
	{"-------", 0, 1},
	{"Music by", 0, 1},
	{"Mike Spang", 0, 1},
	{"-------", 1},
};
BOOL bPlayerEnteringHighScore;
char byPlayersHScorePlace;
char byHighScoreInitialsIndex;
const char byLegalHighScoreChars[38] = " 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
// Other Stuff
BOOL bProgramStart;
BOOL bGameIntro;

ACTOR::ACTOR(void)
{
	memset(this, 0, sizeof(ACTOR));
}

ACTOR::~ACTOR(void)
{
}

void InitActor(ACTOR *pActor)
{
	short i;
	float t;

	pActor->iAnimationT = 0;
	pActor->iStepT = 0;
	pActor->iTemp = 0;
	pActor->bActive = TRUE;
	pActor->bAttack = FALSE;
	pActor->iExplosionStep = -1;
	pActor->bShield = FALSE;
	pActor->fPower = pActor->fMaxPower;
	t = pActor->fPos[Y];
	for(i = 0; i < 3; i++)
		pActor->fRotVelocity[i] = pActor->fRot[i] = pActor->fPos[i] =
		pActor->fPos2[i] = pActor->fPosVelocity[i] = pActor->fPos2Velocity[i] = 0.0f;
	if(pActor->iType == PLAYER)
	{
		pActor->fPos[X] = SPACE_WIDTH/2;
		pActor->fPos[Y] = t;
		pActor->bGhost = TRUE;
		pActor->lStartTime = GetTickCount();
	}
}

void SetWalls(void)
{
	ACTOR *pActor;
	short x;

	// Set The Walls
	for(x = 0; x < MAX_ALIEN_COLUMN; x++)
	{
		pActor = &pAlien[MAX_ALIEN_ROW*MAX_ALIEN_COLUMN+x];
		InitActor(pActor);
		pActor->fPos[X] = (float) 5+x*10;
		pActor->fPos[Y] = (float) 13.0f;
		pActor->iType = WALL;
		pActor->byLives = 4; // This Wall Could Be 5 Times Hit
		pActor->iAnimationT = 0;
	}
}

BOOL ASPlayMidi(HWND hWnd, char *sFileName)
{
	if(!Config.bMusic)
		return FALSE;

    char buf[256];
    sprintf(buf, "open %s type sequencer alias MUSIC", sFileName);
    if(mciSendString("close all", NULL, 0, NULL) != 0)
        return FALSE;
    if(mciSendString(buf, NULL, 0, NULL) != 0)
        return FALSE;
    if(mciSendString("play MUSIC from 0", NULL, 0, hWnd) != 0)
        return FALSE;
    return TRUE;
}

BOOL ASStopMidi(void)
{
	if(!Config.bMusic)
		return FALSE;

    if(mciSendString("close all", NULL, 0, NULL) != 0)
        return FALSE;
    return TRUE;
}

BOOL PauseMidi()
{
	if(!Config.bMusic)
		return FALSE;

    if (mciSendString("stop MUSIC", NULL, 0, NULL) != 0)
		return(FALSE);

    return TRUE;
}

BOOL ResumeMidi()
{	
	if(!Config.bMusic)
		return FALSE;

    if (mciSendString("play MUSIC notify", NULL, 0, hWnd) != 0)
		return(FALSE);
    return TRUE;
}

void StartNewMidi(void)
{
	int t;

	ASStopMidi();
	switch(rand() % 3)
	{
		case 0:
			ASPlayMidi(hWnd, "IntoLigh.mid");
			byMidi = 0;
		break;
		
		case 1:
			ASPlayMidi(hWnd, "TheCruiser.mid");
			byMidi = 1;
		break;
		
		case 2:
			ASPlayMidi(hWnd, "Ursa.mid");
			byMidi = 2;
		break;

		default:
		t= 0;
	}	
	GetLocalTime(&MidiStartTime);
}

void CheckMidi(void)
{
	SYSTEMTIME SystemTime;
	WORD wSecondDifference = 0, wMinuteDifference = 0;

	GetLocalTime(&SystemTime);
	wSecondDifference = SystemTime.wSecond-MidiStartTime.wSecond;
	if(wSecondDifference < 0)
		wSecondDifference = -wSecondDifference;
	wMinuteDifference = SystemTime.wMinute-MidiStartTime.wMinute;
	switch(byMidi)
	{
		case 0:
			if(wMinuteDifference >= 5 && wSecondDifference >= 8)
				StartNewMidi();
		break;

		case 1:
			if(wMinuteDifference >= 5 && wSecondDifference >= 10)
				StartNewMidi();
		break;

		case 2:
			if(wMinuteDifference >= 4 && wSecondDifference >= 56)
				StartNewMidi();
		break;
	}
}

void ShowMouseCursor(BOOL bState)
{ // begin ShowMouseCursor()
	int i;
	
	// Disables/Enables the mouse cursor:
	if(!bState)
	{
		for(;;)
		{
			i = ShowCursor(FALSE);
			if(i < 0)
				break;
		}
	}
	else
	{
		for(;;)
		{
			i = ShowCursor(TRUE);
			if(i >= 0)
				break;
		}
	}
} // end ShowMouseCursor()

// Loads a jpg texture:
BOOL ASLoadJpegRGB(AS_TEXTURE *pTexture, char *pbyFilename)
{ // begin ASLoadJpegRGB()
	JPEG_CORE_PROPERTIES jcProps;
	
	memset(&jcProps, 0, sizeof(JPEG_CORE_PROPERTIES));
	ijlInit(&jcProps);
	jcProps.JPGFile = pbyFilename;
	ijlRead(&jcProps, IJL_JFILE_READPARAMS);

	pTexture->iWidth = (int) jcProps.JPGWidth;
	pTexture->iHeight = (int) jcProps.JPGHeight;

	// Setup texture information:
	pTexture->iFormat = GL_RGB;
	pTexture->iImageBits = 24;
	pTexture->byColorComponents = 3;

	pTexture->pbyData = (BYTE *) malloc(pTexture->iWidth*pTexture->iHeight*pTexture->byColorComponents);
	jcProps.DIBWidth = jcProps.JPGWidth;
	jcProps.DIBHeight = jcProps.JPGHeight;
	jcProps.DIBChannels = 3;
	jcProps.DIBColor = IJL_RGB;
	jcProps.DIBPadBytes = 0;
	jcProps.DIBBytes = (BYTE *) pTexture->pbyData;
	jcProps.JPGColor = IJL_YCBCR;
	if(ijlRead(&jcProps, IJL_JFILE_READWHOLEIMAGE) != IJL_OK)
	{
		if(pTexture->pbyData)
			delete pTexture->pbyData;
		return true;
	}
	ijlFree(&jcProps);
	
	return false;
} // end ASLoadJpegRGB()

void ASLoadTextures(char (*byFilename)[256], int iTextures, AS_TEXTURE *pTexture)
{ // begin ASLoadTextures()
	AS_TEXTURE *pTextureT;

	for(int i = 0; i < iTextures; i++)
	{
		pTextureT = &pTexture[i];
		strcpy(pTextureT->byFilename, byFilename[i]);
		ASLoadJpegRGB(pTextureT, pTextureT->byFilename);
	}
} // begin ASLoadTextures()

void ASDestroyTextures(int iTextures, AS_TEXTURE *Texture)
{ // begin ASDestroyTextures()
	for(int i = 0; i < iTextures; i++)
	{
		if(Texture[i].pbyData)
			Texture[i].pbyData;
	}
} // end ASDestroyTextures()

void ASGenOpenGLTextures(int iTextures, AS_TEXTURE *Texture)
{ // begin ASGenOpenGLTextures()
	AS_TEXTURE *pTextureT;

	if(!Texture[0].pbyData)
		return;
	for(int i = 0; i < iTextures; i++)
	{
		pTextureT = &Texture[i];
		glGenTextures(1, &pTextureT->iOpenGLID);
		glBindTexture(GL_TEXTURE_2D, pTextureT->iOpenGLID);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);
		gluBuild2DMipmaps(GL_TEXTURE_2D, pTextureT->byColorComponents, pTextureT->iWidth,
						  pTextureT->iHeight, pTextureT->iFormat, GL_UNSIGNED_BYTE,
						  pTextureT->pbyData);
	}
} // end ASGenOpenGLTextures()

void ASDestroyOpenGLTextures(int iTextures, AS_TEXTURE *Texture)
{ // begin ASDestroyOpenGLTextures()
	if(!Texture[0].pbyData)
		return;
	for(int i = 0; i < iTextures; i++)
		glDeleteTextures(1, &Texture[i].iOpenGLID);
} // end ASDestroyOpenGLTextures()

void StartLevel(LEVEL *pLevelT, BOOL bPlayer, BOOL bInitalize)
{
	ACTOR *pActor;
	short x, y, i;
	
	pLevel = pLevelT;
	// Set The Aliens
	for(y = 0; y < MAX_ALIEN_ROW; y++)
		for(x = 0; x < MAX_ALIEN_COLUMN; x++)
		{
			pActor = &pAlien[y*MAX_ALIEN_COLUMN+x];
			if(!pLevel->byAliens[y][x])
			{
				pActor->bActive = FALSE;
				continue;
			}
			InitActor(pActor);
			pActor->fPos[X] = (float) 5+(x+pLevel->byXStart)*10;
			pActor->fPos[Y] = SPACE_HEIGHT-(5+(y+pLevel->byYStart)*10);
			pActor->fPosVelocity[X] = pLevel->fXStartVelocity;
			pActor->fPosVelocity[Y] = pLevel->fYStartVelocity;
			pActor->iType = pLevel->byAliens[y][x];
			pActor->byLives = 0;
			if(pActor->iType == ALIEN_3)
				pActor->byLives = 4; // This Alien Could Be 5 Times Hit
			else
			if(pActor->iType == BIG_BOSS)
				pActor->byLives = 100;
			pActor->fPos2[Y] = SPACE_HEIGHT;
		}
	if(!bPlayer)
		return;
	InitActor(&pPlayer);
	pPlayer.iType = PLAYER;
	bGameOver = FALSE;
	if(!bInitalize)
		return;
	// Init Objects
	for(i = 0; i < MAX_OBJECTS; i++)
		pObject[i].bActive = FALSE;
	SetWalls();
	// We Begin A New Game
	byPlayerWeapon = SINGLE_LASER_WEAPON;
	pPlayer.byLives = 3;
	pPlayer.fPower = pPlayer.fMaxPower = MAX_PLAYER_POWER;
	iScore = 0;
	byWormholeAniStep = 0;
	fWormholeHitPoints = 100.0f;
	for(i = 0; i < MAX_SHOTS; i++)
		pShot[i].bActive = FALSE;
	bGameWon = FALSE;
}

void StartNewGame(void)
{
	bGameIntro = FALSE;
	bPlayerEnteringHighScore = FALSE;
	byLevel = byStartLevel;
	StartLevel(pLevels[byLevel], TRUE, TRUE);
	lLastPlayerShotTime = g_lNow;
}

HRESULT LoadHighScores(char *pbyFilename)
{
	FILE *pFile = NULL;
	
	if(!pbyFilename)
		return 1;
	pFile = fopen(pbyFilename,"r");
	if(!pFile)
		return 1;
	fread(Highscore, sizeof(HIGHSCORE), MAX_HIGHSCORES, pFile);
	fclose(pFile);
	return 0;
}

HRESULT SaveHighScores(char *pbyFilename)
{
	FILE *pFile = NULL;
	
	if(!pbyFilename)
		return 0;	
	pFile = fopen(pbyFilename,"w");
	if(!pFile)
		return 0;
	fwrite(Highscore, sizeof(HIGHSCORE), MAX_HIGHSCORES, pFile);
	fclose(pFile);
	return 0;
}

void InitGameIntro(void)
{
	fWormholeHitPoints = 100.0f;
	fPlanetZScale = 2.0f;
	pPlanet->SetAnimationT(0);
	pPlanet->SetAnimationStepT(0);
	fPlanetZScaleVelocity = 0.0f;
	bGameIntro = TRUE;
	bPlayerEnteringHighScore = FALSE;
	pPlayer.byLives = 0;
	bGameWon = FALSE;
}

void GameOver(void)
{
	short i;

	if(!bGameOver)
	{
		DSUtil_PlaySound(pInvasionSound, 0);
		bGameOver = TRUE;
		for(i = 0; i < MAX_ALIENS; i++)
			pAlien[i].fPosVelocity[Y] -= 1.0f;
		pPlanet->SetAnimationT(1);
		pPlanet->SetAnimationStepT(0);
		if(LEVELS == EASTER_EGG_LEVELS)
			StartLevel(&InvasionEgg, FALSE, FALSE);
		else
			StartLevel(&Invasion, FALSE, FALSE);
		pPlayer.fPower = pPlayer.fMaxPower;
		// Enable Highscore
		bPlayerEnteringHighScore = TRUE;
		byPlayersHScorePlace = -1;
	}
}
//////////////////////////////////////////////////////////////////////

void InitSounds()
{
	// Create Sounds
	if(!bSoundPossible)
		return;

    pExplosion1Sound = DSUtil_CreateSound(TEXT("EXPLOSION1"), 1);
    pExplosion2Sound = DSUtil_CreateSound(TEXT("EXPLOSION2"), 1);
    pWormholeSound = DSUtil_CreateSound(TEXT("WORMHOLE"), 1);
    pInvasionSound = DSUtil_CreateSound(TEXT("INVASION"), 1);
    pPlayerShotSound = DSUtil_CreateSound(TEXT("PLAYER_SHOT"), 1);
    pAlienShotSound = DSUtil_CreateSound(TEXT("ALIEN_SHOT"), 1);
    pAlien5ShotSound = DSUtil_CreateSound(TEXT("ALIEN_5_SHOT"), 1);
    pBigBossShotSound = DSUtil_CreateSound(TEXT("BIG_BOSS_SHOT"), 1);
    pWormholeShotSound = DSUtil_CreateSound(TEXT("WORMHOLE_SHOT"), 1);
    pAlien5DeadSound = DSUtil_CreateSound(TEXT("ALIEN_5_DEAD"), 1);
    pBigBossDeadSound = DSUtil_CreateSound(TEXT("BIG_BOSS_DEAD"), 1);
    pAlienAttackSound = DSUtil_CreateSound(TEXT("ALIEN_ATTACK"), 1);
    pObjectLiveSound = DSUtil_CreateSound(TEXT("O_LIVE"), 1);
    pObjectWallSound = DSUtil_CreateSound(TEXT("O_WALL"), 1);
    pObjectSingleLaserSound = DSUtil_CreateSound(TEXT("O_SINGLE_LASER"), 1);
    pObjectDoubleLaserSound = DSUtil_CreateSound(TEXT("O_DOUBLE_LASER"), 1);
    pObjectPowerIncreaseSound = DSUtil_CreateSound(TEXT("O_POWER_INCREASE"), 1);
}

void DestroySounds(void)
{
	// Destroy Sounds
	if(!bSoundPossible)
		return;
	DSUtil_DestroySound(pExplosion1Sound);
	pExplosion1Sound = NULL;
	DSUtil_DestroySound(pExplosion2Sound);
	pExplosion2Sound = NULL;
	DSUtil_DestroySound(pWormholeSound);
	pWormholeSound = NULL;
	DSUtil_DestroySound(pInvasionSound);
	pInvasionSound = NULL;
	DSUtil_DestroySound(pPlayerShotSound);
	pPlayerShotSound = NULL;
	DSUtil_DestroySound(pAlienShotSound);
	pAlienShotSound = NULL;
	DSUtil_DestroySound(pAlien5ShotSound);
	pAlien5ShotSound = NULL;
	DSUtil_DestroySound(pBigBossShotSound);
	pBigBossShotSound = NULL;
	DSUtil_DestroySound(pWormholeShotSound);
	pWormholeShotSound = NULL;
	DSUtil_DestroySound(pAlien5DeadSound);
	pAlien5DeadSound = NULL;
	DSUtil_DestroySound(pBigBossDeadSound);
	pBigBossDeadSound = NULL;
	DSUtil_DestroySound(pAlienAttackSound);
	pAlienAttackSound = NULL;
	DSUtil_DestroySound(pObjectLiveSound);
	pObjectLiveSound = NULL;
	DSUtil_DestroySound(pObjectWallSound);
	pObjectWallSound = NULL;
	DSUtil_DestroySound(pObjectSingleLaserSound);
	pObjectSingleLaserSound = NULL;
	DSUtil_DestroySound(pObjectDoubleLaserSound);
	pObjectDoubleLaserSound = NULL;
	DSUtil_DestroySound(pObjectPowerIncreaseSound);
	pObjectPowerIncreaseSound = NULL;
}

void NormalizeFace(FLOAT3 *ResultV, FLOAT3 V1, FLOAT3 V2, FLOAT3 V3)
{
	FLOAT3 V1_V2, V1_V3;
	float fLength;

	SubtVer(V1_V2, V1, V2);
	SubtVer(V1_V3, V1, V3);
	CrossProductVer(*ResultV, V1_V2, V1_V3);
	fLength = (float) sqrt((*ResultV)[X]*(*ResultV)[X]+(*ResultV)[Y]*(*ResultV)[Y]+(*ResultV)[Z]*(*ResultV)[Z]);
	(*ResultV)[X] /= fLength;
	(*ResultV)[Y] /= fLength;
	(*ResultV)[Z] /= fLength;
}

int LoadGLTextures()                                    // Load Bitmaps And Convert To Textures
{
	char byFilename[TEXTURES][256] = {"Font.jpg",
									  "space_lt.jpg",
									  "space_rt.jpg",
									  "space_rb.jpg",
									  "space_lb.jpg",
									  "Alien.jpg",
									  "Ship.jpg",
									  "Worm1.jpg",
									  "Worm2.jpg",
									  "Worm3.jpg",
									  "Worm4.jpg",
									  "Worm5.jpg",
									  "Explosion1.jpg",
									  "Title1.jpg",
									  "Title2.jpg",
									  "Title3.jpg"};

	ASLoadTextures(byFilename, TEXTURES, GameTexture);
	ASGenOpenGLTextures(TEXTURES, GameTexture);
    return TRUE;
}

void DestroyGLTextures(void)
{ // begin DestroyGLTextures()
	ASDestroyOpenGLTextures(TEXTURES, GameTexture);
	ASDestroyTextures(TEXTURES, GameTexture);
} // end DestroyGLTextures()

GLvoid BuildFont(GLvoid)								// Build Our Font Display List
{
	float	cx;											// Holds Our X Character Coord
	float	cy;											// Holds Our Y Character Coord

	base=glGenLists(256);								// Creating 256 Display Lists
	glBindTexture(GL_TEXTURE_2D, GameTexture[0].iOpenGLID);			// Select Our Font Texture
	for (loop=0; loop<256; loop++)						// Loop Through All 256 Lists
	{
		cx=float(loop%16)/16.0f;						// X Position Of Current Character
		cy=float(loop/16)/16.0f;						// Y Position Of Current Character

		glNewList(base+loop,GL_COMPILE);				// Start Building A List
			glBegin(GL_QUADS);							// Use A Quad For Each Character
				glTexCoord2f(cx,1-cy-0.0625f);			// Texture Coord (Bottom Left)
				glVertex2i(0,0);						// Vertex Coord (Bottom Left)
				glTexCoord2f(cx+0.0625f,1-cy-0.0625f);	// Texture Coord (Bottom Right)
				glVertex2i(16,0);						// Vertex Coord (Bottom Right)
				glTexCoord2f(cx+0.0625f,1-cy);			// Texture Coord (Top Right)
				glVertex2i(16,16);						// Vertex Coord (Top Right)
				glTexCoord2f(cx,1-cy);					// Texture Coord (Top Left)
				glVertex2i(0,16);						// Vertex Coord (Top Left)
			glEnd();									// Done Building Our Quad (Character)
			glTranslated(10,0,0);						// Move To The Right Of The Character
		glEndList();									// Done Building The Display List
	}													// Loop Until All 256 Are Built
}

GLvoid KillFont(GLvoid)									// Delete The Font From Memory
{
	glDeleteLists(base,256);							// Delete All 256 Display Lists
}

GLvoid glPrint(GLint x, GLint y, char *string, int set)	// Where The Printing Happens
{
	if (set>1)
		set=1;
	glBindTexture(GL_TEXTURE_2D, GameTexture[0].iOpenGLID);			// Select Our Font Texture
	glDisable(GL_DEPTH_TEST);							// Disables Depth Testing
	glMatrixMode(GL_PROJECTION);						// Select The Projection Matrix
	glPushMatrix();										// Store The Projection Matrix
	glLoadIdentity();									// Reset The Projection Matrix
	glOrtho(0,640,0,480,-100,100);						// Set Up An Ortho Screen
	glMatrixMode(GL_MODELVIEW);							// Select The Modelview Matrix
	glPushMatrix();										// Store The Modelview Matrix
	glLoadIdentity();									// Reset The Modelview Matrix
	glTranslated(x,y,0);								// Position The Text (0,0 - Bottom Left)
	glListBase(base-32+(128*set));						// Choose The Font Set (0 or 1)
	glCallLists(strlen(string),GL_BYTE,string);			// Write The Text To The Screen
	glMatrixMode(GL_PROJECTION);						// Select The Projection Matrix
	glPopMatrix();										// Restore The Old Projection Matrix
	glMatrixMode(GL_MODELVIEW);							// Select The Modelview Matrix
	glPopMatrix();										// Restore The Old Projection Matrix
	glEnable(GL_DEPTH_TEST);							// Enables Depth Testing
}

GLvoid ReSizeGLScene(GLsizei width, GLsizei height)		// Resize And Initialize The GL Window
{
	if (height==0)										// Prevent A Divide By Zero By
		height=1;										// Making Height Equal One

	glViewport(0,0,width,height);						// Reset The Current Viewport

	glMatrixMode(GL_PROJECTION);						// Select The Projection Matrix
	glLoadIdentity();									// Reset The Projection Matrix

	// Calculate The Aspect Ratio Of The Window
	gluPerspective(45.0f,(GLfloat)width/(GLfloat)height,0.1f,1000.0f);

	glMatrixMode(GL_MODELVIEW);							// Select The Modelview Matrix
	glLoadIdentity();									// Reset The Modelview Matrix
}

GLvoid CreateLists(GLvoid)
{	
	background_list = glGenLists(NUM_LISTS);
	
	// Draw Background As Textured Quad
	glNewList(background_list, GL_COMPILE);
		// Upper Left
		glBindTexture(GL_TEXTURE_2D, GameTexture[1].iOpenGLID);
		glBegin(GL_QUADS);
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.0f, 1.0f); glVertex3f(-WORLD_WIDTH, WORLD_HEIGHT * 1.4f, 0.0f);
			glTexCoord2f(0.0f, 0.0f); glVertex3f(-WORLD_WIDTH, 0.0f        , 0.0f);
			glTexCoord2f(1.0f, 0.0f); glVertex3f( 0.0f       , 0.0f        , 0.0f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f( 0.0f       , WORLD_HEIGHT * 1.4f, 0.0f);
		glEnd();
		
		// Upper Right
		glBindTexture(GL_TEXTURE_2D, GameTexture[2].iOpenGLID);
		glBegin(GL_QUADS); 
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.0f, 1.0f); glVertex3f( 0.0f       , WORLD_HEIGHT * 1.4f, 0.0f);
			glTexCoord2f(0.0f, 0.0f); glVertex3f( 0.0f       , 0.0f        , 0.0f);
			glTexCoord2f(1.0f, 0.0f); glVertex3f( WORLD_WIDTH, 0.0f        , 0.0f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f( WORLD_WIDTH, WORLD_HEIGHT * 1.4f, 0.0f);
		glEnd();
		
		// Lower Right
		glBindTexture(GL_TEXTURE_2D, GameTexture[3].iOpenGLID);
		glBegin(GL_QUADS); 
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.0f, 1.0f); glVertex3f( 0.0f       , 0.0f        , 0.0f);
			glTexCoord2f(0.0f, 0.0f); glVertex3f( 0.0f       ,-WORLD_HEIGHT * 1.4f, 0.0f);
			glTexCoord2f(1.0f, 0.0f); glVertex3f( WORLD_WIDTH,-WORLD_HEIGHT * 1.4f, 0.0f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f( WORLD_WIDTH, 0.0f        , 0.0f);
		glEnd();

		// Lower Left
		glBindTexture(GL_TEXTURE_2D, GameTexture[4].iOpenGLID);
		glBegin(GL_QUADS); 
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.0f, 1.0f); glVertex3f(-WORLD_WIDTH, 0.0f        , 0.0f);
			glTexCoord2f(0.0f, 0.0f); glVertex3f(-WORLD_WIDTH,-WORLD_HEIGHT * 1.4f, 0.0f);
			glTexCoord2f(1.0f, 0.0f); glVertex3f( 0.0f       ,-WORLD_HEIGHT * 1.4f, 0.0f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f( 0.0f       , 0.0f        , 0.0f);
		glEnd();
		
	glEndList();
}

int InitGL(GLvoid)										// All Setup For OpenGL Goes Here
{
	if (!LoadGLTextures())								// Jump To Texture Loading Routine
		return FALSE;									// If Texture Didn't Load Return FALSE
	BuildFont();										// Build The Font
	CreateLists();										// Create All Required Display Lists
	switch(_ASConfig->byLight)
	{
		case 1:
			glShadeModel(GL_FLAT);					    // Enable Smooth Shading
		break;

		case 2:
			glShadeModel(GL_SMOOTH);					// Enable Smooth Shading
		break;
	}
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);				// Black Background
	glClearDepth(1.0f);									// Depth Buffer Setup
	glEnable(GL_DEPTH_TEST);							// Enables Depth Testing
	glDepthFunc(GL_LEQUAL);								// The Type Of Depth Testing To Do
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	// Really Nice Perspective Calculations
	glColor4f(1.0f, 1.0f, 1.0f, 1.0);
	
	
	
	
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glPolygonMode(GL_FRONT, GL_FILL);
	glPolygonMode(GL_BACK, GL_FILL);
	glDepthFunc(GL_LESS);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_FASTEST);
	glHint(GL_LINE_SMOOTH_HINT, GL_FASTEST);
	glHint(GL_FOG_HINT, GL_FASTEST);
	glHint(GL_POINT_SMOOTH_HINT, GL_FASTEST);
	glHint(GL_POLYGON_SMOOTH_HINT, GL_FASTEST);
	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);		
	glColor3f(1.0f, 1.0f, 1.0f);
	glColor4f(1.0f, 1.0f, 1.0f, 1.0);
	glEnable(GL_COLOR_MATERIAL);
	glEnable(GL_COLOR_MATERIAL_FACE);
	glColorMaterial(GL_FRONT,GL_AMBIENT_AND_DIFFUSE);
	glMateriali(GL_FRONT,GL_SHININESS,128);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);					// Set The Blending Function For Translucency
	glEnable(GL_TEXTURE_2D);

	glEnable(GL_COLOR_MATERIAL);
	glColorMaterial(GL_FRONT,GL_AMBIENT_AND_DIFFUSE);
	glMateriali(GL_FRONT,GL_SHININESS,128);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	// Really Nice Perspective Calculations
	
	glLightfv(GL_LIGHT1, GL_AMBIENT, LightAmbient);		// Setup The Ambient Light
	glLightfv(GL_LIGHT1, GL_DIFFUSE, LightDiffuse);		// Setup The Diffuse Light
	glLightfv(GL_LIGHT1, GL_POSITION,LightPosition);	// Position The Light
	glEnable(GL_LIGHT1);								// Enable Light One
	glDepthFunc(GL_LEQUAL);								// The Type Of Depth Test To Do
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);					// Select The Type Of Blending

	glEnableClientState(GL_COLOR_ARRAY);
	glEnableClientState(GL_VERTEX_ARRAY);
	glEnableClientState(GL_NORMAL_ARRAY);
	return TRUE;										// Initialization Went OK
}

void DrawExplosion(short iExplosionStep)
{
	short x, y;
	float fX, fY;
	GLboolean bS, bT;

	glGetBooleanv(GL_TEXTURE_GEN_S, &bS);
	glGetBooleanv(GL_TEXTURE_GEN_T, &bT);
	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);
	glDepthMask(FALSE);
	y = (short) iExplosionStep/4;
	x = iExplosionStep-y*4;
	fX = (float) 64*x/256;
	fY = (float) 64*y/256;
	glEnable(GL_BLEND);
	glColor4f(1.0f, 1.0f, 1.0f, 0.8f);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	glBindTexture(GL_TEXTURE_2D, GameTexture[12].iOpenGLID);
	glBegin(GL_QUADS);
		glTexCoord2f(fX, fY);
		glVertex3i(-5, -5, 0);
		glTexCoord2f(fX+0.25f, fY);
		glVertex3i(5, -5, 0);
		glTexCoord2f(fX+0.25f, fY+0.25f);
		glVertex3i(5, 5, 0);
		glTexCoord2f(fX, fY+0.25f);
		glVertex3i(-5, 5, 0);

		glTexCoord2f(fX, fY);
		glVertex3i(-5, 0, -5);
		glTexCoord2f(fX+0.25f, fY);
		glVertex3i(5, 0, -5);
		glTexCoord2f(fX+0.25f, fY+0.25f);
		glVertex3i(5, 0, 5);
		glTexCoord2f(fX, fY+0.25f);
		glVertex3i(-5, 0, 5);
	glEnd();
	glDepthMask(TRUE);
	if(bS)
		glEnable(GL_TEXTURE_GEN_S);
	if(bT)
		glEnable(GL_TEXTURE_GEN_T);
}

void DrawShot(void)
{
	AS_OBJECT *pObject;
	ACTOR *pActor;
	short i;

	glEnable(GL_BLEND);
	glColor4f(1.0f, 1.0f, 1.0f, 0.8f);
	for(i = 0; i < MAX_SHOTS; i++)
	{
		pActor = &pShot[i];
		if(!pActor->bActive)
			continue;
		glLoadIdentity();									// Reset The Current Modelview Matrix
		glTranslatef(-pPlayer.fPos[X], pPlayer.fPos[Y], fZPos);
		glRotatef(fXRot, 1.0f, 0.0f, 0.0f);
		glTranslatef(pActor->fPos[X], pActor->fPos[Y], 0.0f);
		switch(pActor->iType)
		{
			case PLAYER_SHOT: pObject = pShot1; break;
			case ALIEN_SHOT: pObject = pShot2; break;
			case ALIEN_5_SHOT: pObject = pShot3; break;
			case WORMHOLE_SHOT: pObject = pWormholeShot; break;
		}
		glMultMatrixf(pObject->Matrix[0]);
		pObject->Draw(TRUE, FALSE, Config.bDrawBounding);
		pActor->pFrameT = pObject->pChild[0]->pAnimationT->pStepT->pFrame;
	}
	glDisable(GL_BLEND);
}

void DrawAlien(void)
{
	AS_OBJECT *pObject;
	ACTOR *pActor;
	short i;

	for(i = 0; i < MAX_ALIENS; i++)
	{
		pActor = &pAlien[i];
		if(!pActor->bActive)
			continue;
		glLoadIdentity();									// Reset The Current Modelview Matrix
		glTranslatef(-pPlayer.fPos[X], pPlayer.fPos[Y], fZPos);
		glRotatef(fXRot, 1.0f, 0.0f, 0.0f);
		glTranslatef(pActor->fPos[X]+pActor->fPos2[X], pActor->fPos[Y]+pActor->fPos2[Y], 0.0f);
		if(pActor->iExplosionStep != -1)
		{
			glPushMatrix();
			glTranslatef(0.0f, 0.0f, -8.0f);
			DrawExplosion(pActor->iExplosionStep);
			glDisable(GL_BLEND);
			glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND);
			glPopMatrix();
			if(pActor->iExplosionStep > 8)
				continue;
		}
		if(pActor->iType != WALL)
			glBindTexture(GL_TEXTURE_2D, GameTexture[5].iOpenGLID);
		else
			glBindTexture(GL_TEXTURE_2D, GameTexture[6].iOpenGLID);
		switch(pActor->iType)
		{
			case ALIEN_1: pObject = pAlien1; break;
			case ALIEN_2: pObject = pAlien2; break;
			case ALIEN_3: pObject = pAlien3; break;
			case ALIEN_4: pObject = pAlien4; break;
			case ALIEN_5: pObject = pAlien5; break;			
			case BIG_BOSS: pObject = pBigBoss; break;			
			case WALL: pObject = pWall; break;
		}
		glMultMatrixf(pObject->Matrix[0]);
		glRotatef(pActor->fRot[X], 1.0f, 0.0f, 0.0f);
		glRotatef(pActor->fRot[Y], 0.0f, 1.0f, 0.0f);
		glRotatef(pActor->fRot[Z], 0.0f, 0.0f, 1.0f);
		pObject->SetAnimationT(pActor->iAnimationT);
		pObject->SetAnimationStepT(pActor->iStepT);
		pObject->pChild[0]->dwLastTime = pActor->dwLastTime;
		if(pActor->iType == ALIEN_5)
			pObject->Draw(TRUE, FALSE, Config.bDrawBounding);
		else
			pObject->Draw(TRUE, TRUE, Config.bDrawBounding);
		pActor->dwLastTime = pObject->pChild[0]->dwLastTime;
		pActor->iStepT = pObject->pChild[0]->pAnimationT->pStepT->iID;
		pActor->pFrameT = pObject->pChild[0]->pAnimationT->pStepT->pFrame;
	}
}

void DrawPlayer(void)
{
	if(!pPlayer.bActive)
		return;
	glLoadIdentity();									// Reset The Current Modelview Matrix
	glTranslatef(0.0f, pPlayer.fPos[Y], fZPos);
	glRotatef(fXRot, 1.0f, 0.0f, 0.0f);
	glMultMatrixf(pShip->Matrix[0]);
	glRotatef(pPlayer.fRot[X], 1.0f, 0.0f, 0.0f);
	glRotatef(pPlayer.fRot[Y], 0.0f, 1.0f, 0.0f);
	glRotatef(pPlayer.fRot[Z], 0.0f, 0.0f, 1.0f);
	if(pPlayer.iExplosionStep != -1)
	{
		glPushMatrix();
		DrawExplosion(pPlayer.iExplosionStep);
		glDisable(GL_BLEND);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND);
		glPopMatrix();
		if(pPlayer.iExplosionStep > 8)
			return;
	}
	glBindTexture(GL_TEXTURE_2D, GameTexture[6].iOpenGLID);
	pShip->pChild[0]->Draw(TRUE, TRUE, Config.bDrawBounding);
	if(byPlayerWeapon == DOUBLE_LASER_WEAPON)
		pShip->pChild[1]->Draw(TRUE, TRUE, Config.bDrawBounding);
	pPlayer.pFrameT = pShip->pChild[0]->pAnimationT->pStepT->pFrame;
}

void ActivateShotLights(void)
{
	short i, iLightCounter = 1;
	GLfloat afLightData[4]  = {0.0f, 0.0f, 0.0f, 0.0f};
	ACTOR *pActor;

	if(!_ASConfig->byLight)
		return;
	if(pPlayer.bShield)	
	{
		afLightData[0] = pPlayer.fPos[X];
		afLightData[1] = pPlayer.fPos[Y];
		afLightData[2] = pPlayer.fPos[Z]+5.0f;
		afLightData[3] = 1.0f;
		glLightfv(GL_LIGHT2+iLightCounter, GL_POSITION, afLightData);
		afLightData[0] = 0.0f;
		afLightData[1] = 0.0f;
		afLightData[2] = 1.0f;
		glLightfv(GL_LIGHT2+iLightCounter, GL_DIFFUSE, afLightData);
		glEnable(GL_LIGHT2+iLightCounter);
		iLightCounter++;
	}
	for(i = 0; i < MAX_SHOTS; i++)
	{
		pActor = &pShot[i];
		if(!pActor->bActive)
			continue;
		if(iMaxLights < iLightCounter-2)
			break;
		afLightData[0] = pActor->fPos[X];
		afLightData[1] = pActor->fPos[Y];
		afLightData[2] = pActor->fPos[Z]-10.0f;
		afLightData[3] = 1.0f;
		glLightfv(GL_LIGHT2+iLightCounter, GL_POSITION, afLightData);
		switch(pActor->iType)
		{
			case PLAYER_SHOT:
				afLightData[0] = 1.0f;
				afLightData[1] = 0.0f;
				afLightData[2] = 0.0f;
			break;

			case ALIEN_SHOT:
				afLightData[0] = 0.0f;
				afLightData[1] = 1.0f;
				afLightData[2] = 0.0f;
			break;
		}
		glLightfv(GL_LIGHT2+iLightCounter, GL_DIFFUSE, afLightData);
		glEnable(GL_LIGHT2+iLightCounter);
		iLightCounter++;
	}
}

void DeactivateShotLights(void)
{
	short i, iLightCounter = 1;

	if(!_ASConfig->byLight)
		return;
	for(i = 0; i < MAX_SHOTS; i++)
	{
		if(!pShot[i].bActive)
			continue;
		if(iMaxLights < iLightCounter-2)
			break;
		glDisable(GL_LIGHT2+iLightCounter);
		iLightCounter++;
	}
}

void DrawObjects(void)
{
	ACTOR *pActor;
	AS_OBJECT *pObjectT;
	short i;

	for(i = 0; i < MAX_OBJECTS; i++)
	{
		pActor = &pObject[i];
		if(!pActor->bActive)
			continue;
		glLoadIdentity();
		glTranslatef(-pPlayer.fPos[X], pPlayer.fPos[Y], fZPos);
		glRotatef(fXRot, 1.0f, 0.0f, 0.0f);
		glTranslatef(pActor->fPos[X], pActor->fPos[Y], 0.0f);
		switch(pActor->iType)
		{
			case OBJECT_LIVE: pObjectT = pObjectLive; break;
			case OBJECT_WALL: pObjectT = pObjectWall; break;
			case OBJECT_SINGLE_LASER_WEAPON: pObjectT = pObjectSingleLaser; break;
			case OBJECT_DOUBLE_LASER_WEAPON: pObjectT = pObjectDoubleLaser; break;
			case OBJECT_POWER_INCREASE: pObjectT = pObjectPowerIncrease; break;
		}
		glMultMatrixf(pObjectT->Matrix[0]);
		glRotatef(pActor->fRot[X], 1.0f, 0.0f, 0.0f);
		glRotatef(pActor->fRot[Y], 0.0f, 1.0f, 0.0f);
		glRotatef(pActor->fRot[Z], 0.0f, 0.0f, 1.0f);
		pObjectT->Draw(TRUE, TRUE, Config.bDrawBounding);
		pActor->pFrameT = pObjectT->pChild[0]->pAnimationT->pStepT->pFrame;
	}
}

void DrawPlayersHighscore(void)
{
	short i, y;

	glDisable(GL_LIGHTING);
	glEnable(GL_BLEND);
	glColor4ub(255,255,255,255);
	if(bGameWon)
	{
		glPrint(200, 420, "You Have Won The Game!", 1);
		if(LEVELS == NORMAL_LEVELS)
		{
			glPrint(110, 400, "Try to start the program whith the parameter", 1);
			glPrint(260, 380, "Moorhuhn", 1);
		}

	}
	if(!bPlayerEnteringHighScore)
		glPrint(270, 390, "Highscore", 1);
	else
	{ // The player enters or not his name into the highscore:
		if(byPlayersHScorePlace != -2)
		{
			glPrint(260, 300, "Congratulations!", 0);
			glPrint(220, 290, "You are in the highscore!", 0);
			glPrint(140, 280, "Enter your name and hit enter when done.", 0);
		}
		else // He's a looser:
		{
			glPrint(270, 300, "You looser!", 0);
			glPrint(180, 290, "You are not in the highscore!", 0);
			glPrint(270, 280, "Press enter.", 0);
		}
	}
	glPrint(50, 230, "Place", 0);
	glPrint(150, 230, "Name", 0);
	glPrint(400, 230, "Level", 0);
	glPrint(500, 230, "Score", 0);
	for(i = 0, y = 220; i < MAX_HIGHSCORES; i++, y -= 15)
	{
		if(byPlayersHScorePlace == i)
			glColor4f(1.0f, 1.0f, 1.0f, 0.9f);
		else
			glColor4f(0.6f, 0.6f, 0.6f, 0.9f);
		sprintf(byTemp, "%d.", i);
		glPrint(50, y, byTemp, 0);
		glPrint(150, y, Highscore[i].byName, 0);
		sprintf(byTemp, "%d", Highscore[i].iLevel);
		glPrint(400, y, byTemp, 0);
		sprintf(byTemp, "%d",  Highscore[i].iScore);
		glPrint(500, y, byTemp, 0);
	}
}

int DrawGLScene(GLvoid)									// Here's Where We Do All The Drawing
{
	float fTemp;

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	// Clear Screen And Depth Buffer
	if(bProgramStart)
	{
		SwapBuffers(hDC);
		return 0;
	}
	glDisable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	glLoadIdentity();									// Reset The Current Modelview Matrix
	// Draw the background:
	glColor4ub(255,255,255,128);
	glTranslatef(0.0f, 0.0f, -30.0f);
	glMatrixMode(GL_TEXTURE_2D);
	glRotatef(180.0f*float(cos(g_fBackgroundRot/10.0f)),0.0f,0.0f,1.0f);
	glTranslatef((3.0f*float(cos(g_fBackgroundRot)))+(2.1f*float(sin(g_fBackgroundRot*1.4f))),(2.8f*float(sin(g_fBackgroundRot)))+(1.3f*float(sin(g_fBackgroundRot*1.4f))),0.0f);
	glRotatef(10.0f*float(sin(g_fBackgroundRot*1.2f)),1.0f,0.0f,0.0f);
	glMatrixMode(GL_MODELVIEW);
	glCallList(background_list);
	glEnable(GL_CULL_FACE);
	glColor4f(1.0f,1.0f,1.0f, 1.0f);
	glScalef(fPlanetZScale, fPlanetZScale, fPlanetZScale);
	glEnable(GL_DEPTH_TEST);
	glDisable(GL_TEXTURE_2D);
	pPlanet->pChild[1]->Draw(FALSE, FALSE, FALSE);
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glColor4f(1.0f,1.0f,1.0f, 0.3f);
	glBindTexture(GL_TEXTURE_2D, GameTexture[5].iOpenGLID);
	pPlanet->pChild[1]->Draw(FALSE, TRUE, FALSE);
	glDisable(GL_BLEND);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND);
	if(pPlayer.byLives == -1 || pPlayer.byLives == 0 || pPlayer.byLives == 1)
		pPlanet->pChild[2]->Draw(FALSE, TRUE, FALSE);
	if(pPlayer.byLives == -1 || pPlayer.byLives == 0)
		pPlanet->pChild[3]->Draw(FALSE, TRUE, FALSE);
	glClear(GL_DEPTH_BUFFER_BIT);
	//
	if(!bGameIntro)
	{ // We Are In The Game
		glEnable(GL_DEPTH_TEST);
		/////////////////////////////////////////////////////////////////
		// Dislay The View Data
	/*	sprintf(byTemp, "XRos: %f", fXRot);
		glPrint(320, 100, byTemp, 0);
		sprintf(byTemp, "ZPos: %f", fZPos);
		glPrint(320, 130, byTemp, 0);
		sprintf(byTemp, "PlayerYPos: %f", pPlayer.fPos[Y]);
		glPrint(320, 160, byTemp, 0);*/
		/////////////////////////////////////////////////////////////////
		glEnableLighting();
		ActivateShotLights();
		// Outlines
		glLoadIdentity();
		glTranslatef(-pPlayer.fPos[X], pPlayer.fPos[Y], fZPos);
		glRotatef(fXRot, 1.0f, 0.0f, 0.0f);
		glPushMatrix();
		glLineWidth(3.f);
		glColor3f(1.0f, 1.0f, 1.0f);
		glColor4f(1.0f, 1.0f, 1.0f, 0.8f);
		glBegin(GL_LINES);
			glVertex3f(0.0f, 0.0f, 0.0f);
			glVertex3f(0.0f, SPACE_HEIGHT, 0.0f);
			glVertex3f(SPACE_WIDTH, 0.0f, 0.0f);
			glVertex3f(SPACE_WIDTH, SPACE_HEIGHT, 0.0f);
		glEnd();	
		// Draw Actors
		glDisable(GL_BLEND);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND);		
		DrawShot();    // Draw The Shots
		DrawAlien();   // Draw The Aliens
		if(pPlayer.bShield)
		{
			glEnable(GL_BLEND);
			glColor4f(0.0f, 0.0f, 1.0f, 0.95f);
			glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
			glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
			glEnable(GL_TEXTURE_GEN_S);
			glEnable(GL_TEXTURE_GEN_T);
		}
		DrawPlayer();  // Draw The Player
		glPopMatrix();

		// Wormhole
		glEnable(GL_TEXTURE_2D);
		glEnable(GL_BLEND);
		glDisable(GL_CULL_FACE);
		glDisable(GL_LIGHTING);
		fTemp = fWormholeHitPoints/100;
		glColor4f(1.0f-fTemp, fTemp, fTemp, 0.8f);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		glBindTexture(GL_TEXTURE_2D, GameTexture[byWormholeAni[byWormholeAniStep]].iOpenGLID);
		glDepthMask(FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
		glBegin(GL_QUADS);
			// Left bottom
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f(0.0f, SPACE_HEIGHT, 0.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f(SPACE_WIDTH/2, SPACE_HEIGHT, 0.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f(SPACE_WIDTH/2, SPACE_HEIGHT, 40.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f(0.0f, SPACE_HEIGHT, 40.0f);
			// Right bottom
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f(SPACE_WIDTH/2, SPACE_HEIGHT, 0.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f(SPACE_WIDTH, SPACE_HEIGHT, 0.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f(SPACE_WIDTH, SPACE_HEIGHT, 40.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f(SPACE_WIDTH/2, SPACE_HEIGHT, 40.0f);
			// Left Top
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f(0.0f, SPACE_HEIGHT, 0.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f(0.0f, SPACE_HEIGHT, -40.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f(SPACE_WIDTH/2, SPACE_HEIGHT, -40.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f(SPACE_WIDTH/2, SPACE_HEIGHT, 0.0f);
			// Right Top
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f(SPACE_WIDTH/2, SPACE_HEIGHT, 0.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f(SPACE_WIDTH/2, SPACE_HEIGHT, -40.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f(SPACE_WIDTH, SPACE_HEIGHT, -40.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f(SPACE_WIDTH, SPACE_HEIGHT, 0.0f);
		glEnd();
		glEnable(GL_CULL_FACE);
		glDepthMask(TRUE);

		// Show The Players Lives
		glEnable(GL_BLEND);
		glColor3f(0.0f, 0.0f, 1.0f);
		glColor4f(0.0f, 0.0f, 1.0f, 0.95f);
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		if(pPlayer.byLives != -1)
		{
			glBindTexture(GL_TEXTURE_2D, GameTexture[6].iOpenGLID);
			glLoadIdentity();
			glTranslatef(-45.0f, 35.0f, -100.0f);
			glRotatef(fRot[X], 1.0f, 0.0f, 0.0f);
			glRotatef(fRot[Y], 0.0f, 1.0f, 0.0f);
			glRotatef(fRot[Z], 0.0f, 0.0f, 1.0f);
			pShip->pChild[0]->Draw(TRUE, TRUE, FALSE);
			// Display Players Power:
			glLoadIdentity();
			glTranslatef(7.0f, 5.0f, -15.0f);
			glRotatef(90, 0.0f, 1.0f, 0.0f);
			glRotatef(45, 1.0f, 0.0f, 0.0f);
			glRotatef(45, 0.0f, 0.0f, 1.0f);
			glScalef(pPlayer.fPower/pPlayer.fMaxPower, pPlayer.fPower/pPlayer.fMaxPower, pPlayer.fPower/pPlayer.fMaxPower);
			pPower->Draw(TRUE, FALSE, FALSE);
			glDisable(GL_BLEND);
		}
		DrawObjects(); // Draw The Objects

		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
		glEnable(GL_BLEND);
		// Draw Texts
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		glEnable(GL_TEXTURE_2D);
		glColor4f(1.0f,1.0f,1.0f, 0.8f);
		// Display The Level Name
		glPrint(10, 465, pLevel->byName, 0);
		if(pPlayer.byLives != -1)
		{
			// Show player lives:
			sprintf(byTemp, "* %d", pPlayer.byLives);
			glPrint(130, 430, byTemp, 0);
			// Display Players Power
			sprintf(byTemp, "P: %.3f", pPlayer.fPower);
			glPrint(520, 420, byTemp, 0);
			// Display highscore
			sprintf(byTemp, "%d", iScore);
			glPrint(400, 10, byTemp, 0);
		}
		if(Config.bShowFPS)
		{
			// Display FPS
			sprintf(byTemp, "FPS: %d", g_iFps);
			glPrint(0, 10, byTemp, 0);
		}

		// Draw The Highscore
		if(bPlayerEnteringHighScore)
			DrawPlayersHighscore();	
	}
	else
	{ // We Are In The Game Intro
		// Wormhole
		glLoadIdentity();
		glTranslatef(0.0f, 0.0f, -2.5f);
		glEnable(GL_TEXTURE_2D);
		glEnable(GL_BLEND);
		glColor4f(1.0f, 1.0f, 1.0f, 0.8f);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		glBindTexture(GL_TEXTURE_2D, GameTexture[byWormholeAni[byWormholeAniStep]].iOpenGLID);
		glDepthMask(FALSE);
		glBegin(GL_QUADS);
			// Left bottom
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f(-1.0f, -1.0f, 0.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f(0.0f, -1.0f, 0.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f(0.0f, 0.0f, 0.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f(-1.0f, 0.0f, 0.0f);
			// Right bottom
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f(0.0f, -1.0f, 0.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f(1.0f, -1.0f, 0.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f(1.0f, 0.0f, 0.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f(0.0f, 0.0f, 0.0f);
			// Left Top
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f(-1.0f, 0.0f, 0.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f(0.0f, 0.0f, 0.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f(0.0f, 1.0f, 0.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f(-1.0f, 1.0f, 0.0f);
			// Right Top
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f(0.0f, 0.0f, 0.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f(1.0f, 0.0f, 0.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f(1.0f, 1.0f, 0.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f(0.0f, 1.0f, 0.0f);
		glEnd();
		// Draw Title
		glLoadIdentity();
		glTranslatef(0.0f, 1.0f, -6.0f);
		glBindTexture(GL_TEXTURE_2D, GameTexture[13].iOpenGLID);
		glBegin(GL_QUADS);
			glTexCoord2f(0.01f, 0.01f);
			glVertex3f(-3.0f, -1.0f, 0.0f);
			glTexCoord2f(0.99f, 0.01f);
			glVertex3f(-1.0f, -1.0f, 0.0f);
			glTexCoord2f(0.99f, 0.99f);
			glVertex3f(-1.0f, 1.0f, 0.0f);
			glTexCoord2f(0.01f, 0.99f);
			glVertex3f(-3.0f, 1.0f, 0.0f);
		glEnd();
		glBindTexture(GL_TEXTURE_2D, GameTexture[14].iOpenGLID);
		glBegin(GL_QUADS);
			glTexCoord2f(0.01f, 0.01f);
			glVertex3f(-1.0f, -1.0f, 0.0f);
			glTexCoord2f(0.99f, 0.01f);
			glVertex3f(1.0f, -1.0f, 0.0f);
			glTexCoord2f(0.99f, 0.99f);
			glVertex3f(1.0f, 1.0f, 0.0f);
			glTexCoord2f(0.01f, 0.99f);
			glVertex3f(-1.0f, 1.0f, 0.0f);
		glEnd();
		glBindTexture(GL_TEXTURE_2D, GameTexture[15].iOpenGLID);
		glBegin(GL_QUADS);
			glTexCoord2f(0.01f, 0.01f);
			glVertex3f(1.0f, -1.0f, 0.0f);
			glTexCoord2f(0.99f, 0.01f);
			glVertex3f(3.0f, -1.0f, 0.0f);
			glTexCoord2f(0.99f, 0.99f);
			glVertex3f(3.0f, 1.0f, 0.0f);
			glTexCoord2f(0.01f, 0.99f);
			glVertex3f(1.0f, 1.0f, 0.0f);
		glEnd();
		glDepthMask(TRUE);
		// Draw Some Objects On The Screen
		glDisable(GL_BLEND);
		glEnable(GL_DEPTH_TEST);
		glEnable(GL_LIGHTING);
		if(LEVELS == EASTER_EGG_LEVELS)
		{
			glDisable(GL_TEXTURE_2D);
			glLoadIdentity();
			glTranslatef(0.0f, 0.0f, -20.0f);
			glRotatef(fRot[X], 1.0f, 0.0f, 0.0f);
			glRotatef(fRot[Y], 0.0f, 1.0f, 0.0f);
			glRotatef(fRot[Z], 0.0f, 0.0f, 1.0f);
			pAlien5->Draw(TRUE, FALSE, FALSE);
			glEnable(GL_TEXTURE_2D);
		}
		else
		{
			glBindTexture(GL_TEXTURE_2D, GameTexture[5].iOpenGLID);
			glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND);
			glLoadIdentity();
			glTranslatef(-30.0f, 20.0f, -70.0f);
			glRotatef(fRot[X], 1.0f, 0.0f, 0.0f);
			glRotatef(fRot[Y], 0.0f, 1.0f, 0.0f);
			glRotatef(fRot[Z], 0.0f, 0.0f, 1.0f);
			pAlien1->Draw(TRUE, TRUE, FALSE);
			glLoadIdentity();
			glTranslatef(30.0f, 20.0f, -70.0f);
			glRotatef(fRot[X], 1.0f, 0.0f, 0.0f);
			glRotatef(fRot[Y], 0.0f, 1.0f, 0.0f);
			glRotatef(fRot[Z], 0.0f, 0.0f, 1.0f);
			pAlien2->Draw(TRUE, TRUE, FALSE);
			glLoadIdentity();
			glTranslatef(-30.0f, 0.0f, -70.0f);
			glRotatef(fRot[X], 1.0f, 0.0f, 0.0f);
			glRotatef(fRot[Y], 0.0f, 1.0f, 0.0f);
			glRotatef(fRot[Z], 0.0f, 0.0f, 1.0f);
			pAlien3->Draw(TRUE, TRUE, FALSE);
			glLoadIdentity();
			glTranslatef(30.0f, 0.0f, -70.0f);
			glRotatef(fRot[X], 1.0f, 0.0f, 0.0f);
			glRotatef(fRot[Y], 0.0f, 1.0f, 0.0f);
			glRotatef(fRot[Z], 0.0f, 0.0f, 1.0f);
			pAlien4->Draw(TRUE, TRUE, FALSE);
			glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		}
		// Draw Texts
		glEnable(GL_BLEND);
		if(bShowHighscore)
			DrawPlayersHighscore();
		glColor4f(1.0f, 1.0f, 1.0f, 0.95f);
		if(bAnyKeyMessage)
			glPrint(200, 450, "Press Any Key To Start", 0);
		else
			if(LEVELS == EASTER_EGG_LEVELS)
				glPrint(220, 420, "Or Any Moorhuhn", 0);
		// Credits
		glColor4f(0.7f, 0.7f, 0.7f, 0.95f);
		glPrint(5, 50, "Invasion is a AblazeSpace project (www.ablazespace.de)", 0);
		glPrint(130, 40, "Programmed & Designed by Christian Ofenberg", 0);
		glPrint(170, 30, "Music by Mike Spang", 0);
		glPrint(10, 20, "Thank's to NeHe (nehe.gamedev.net)", 0);
		glPrint(150, 10, "and the Blender (www.blender.nl) crew", 0);
	}	
	SwapBuffers(hDC);									// Swap Buffers (Double Buffering)
	DeactivateShotLights();
	return TRUE;										// Everything Went OK
}

GLvoid KillGLWindow(GLvoid)								// Properly Kill The Window
{
	ASStopMidi();
	DestroySounds();
	glDisableClientState(GL_COLOR_ARRAY);
	glDisableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_NORMAL_ARRAY);
	if (Config.bFullScreen)										// Are We In Fullscreen Mode?
	{
		ChangeDisplaySettings(NULL,0);					// If So Switch Back To The Desktop
		ShowMouseCursor(TRUE);								// Show Mouse Pointer
	}

	KillFont();											// Kill The Font
	DestroyGLTextures();
	glDeleteLists(background_list, NUM_LISTS);
	if (hRC)											// Do We Have A Rendering Context?
	{
		if (!wglMakeCurrent(NULL,NULL))					// Are We Able To Release The DC And RC Contexts?
		{
			MessageBox(NULL,"Release Of DC And RC Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}

		if (!wglDeleteContext(hRC))						// Are We Able To Delete The RC?
		{
			MessageBox(NULL,"Release Rendering Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}
		hRC=NULL;										// Set RC To NULL
	}

	if (hDC && !ReleaseDC(hWnd,hDC))					// Are We Able To Release The DC
	{
		MessageBox(NULL,"Release Device Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hDC=NULL;										// Set DC To NULL
	}

	if (hWnd && !DestroyWindow(hWnd))					// Are We Able To Destroy The Window?
	{
		MessageBox(NULL,"Could Not Release hWnd.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hWnd=NULL;										// Set hWnd To NULL
	}

	if (!UnregisterClass("OpenGL",hInstance))			// Are We Able To Unregister Class
	{
		MessageBox(NULL,"Could Not Unregister Class.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hInstance=NULL;									// Set hInstance To NULL
	}

}

/*	This Code Creates Our OpenGL Window.  Parameters Are:					*
 *	title			- Title To Appear At The Top Of The Window				*
 *	width			- Width Of The GL Window Or Fullscreen Mode				*
 *	height			- Height Of The GL Window Or Fullscreen Mode			*
 *	bits			- Number Of Bits To Use For Color (8/16/24/32)			*
 *	fullscreenflag	- Use Fullscreen Mode (TRUE) Or Windowed Mode (FALSE)	*/
 
BOOL CreateGLWindow(char* title, int width, int height, int bits, BOOL *fullscreen)
{
	GLuint		PixelFormat;			// Holds The Results After Searching For A Match
	WNDCLASS	wc;						// Windows Class Structure
	DWORD		dwExStyle;				// Window Extended Style
	DWORD		dwStyle;				// Window Style
	RECT		WindowRect;				// Grabs Rectangle Upper Left / Lower Right Values
	WindowRect.left=(long)0;			// Set Left Value To 0
	WindowRect.right=(long)width;		// Set Right Value To Requested Width
	WindowRect.top=(long)0;				// Set Top Value To 0
	WindowRect.bottom=(long)height;		// Set Bottom Value To Requested Height

	hInstance			= GetModuleHandle(NULL);				// Grab An Instance For Our Window
	wc.style			= CS_HREDRAW | CS_VREDRAW | CS_OWNDC;	// Redraw On Size, And Own DC For Window.
	wc.lpfnWndProc		= (WNDPROC) WndProc;					// WndProc Handles Messages
	wc.cbClsExtra		= 0;									// No Extra Window Data
	wc.cbWndExtra		= 0;									// No Extra Window Data
	wc.hInstance		= hInstance;							// Set The Instance
	wc.hIcon			= LoadIcon(NULL, IDI_WINLOGO);			// Load The Default Icon
	wc.hCursor			= LoadCursor(NULL, IDC_ARROW);			// Load The Arrow Pointer
	wc.hbrBackground	= NULL;									// No Background Required For GL
	wc.lpszMenuName		= NULL;									// We Don't Want A Menu
	wc.lpszClassName	= "OpenGL";								// Set The Class Name

	if (!RegisterClass(&wc))									// Attempt To Register The Window Class
	{
		MessageBox(NULL,"Failed To Register The Window Class.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;											// Return FALSE
	}
	
	if (*fullscreen)												// Attempt Fullscreen Mode?
	{
		DEVMODE dmScreenSettings;								// Device Mode
		memset(&dmScreenSettings,0,sizeof(dmScreenSettings));	// Makes Sure Memory's Cleared
		dmScreenSettings.dmSize=sizeof(dmScreenSettings);		// Size Of The Devmode Structure
		dmScreenSettings.dmPelsWidth	= width;				// Selected Screen Width
		dmScreenSettings.dmPelsHeight	= height;				// Selected Screen Height
		dmScreenSettings.dmBitsPerPel	= bits;					// Selected Bits Per Pixel
		dmScreenSettings.dmFields=DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;

		// Try To Set Selected Mode And Get Results.  NOTE: CDS_FULLSCREEN Gets Rid Of Start Bar.
		if (ChangeDisplaySettings(&dmScreenSettings,CDS_FULLSCREEN)!=DISP_CHANGE_SUCCESSFUL)
		{
			// If The Mode Fails, Offer Two Options.  Quit Or Use Windowed Mode.
			if (MessageBox(NULL,"The Requested Fullscreen Mode Is Not Supported By\nYour Video Card. Use Windowed Mode Instead?","NeHe GL",MB_YESNO|MB_ICONEXCLAMATION)==IDYES)
			{
				*fullscreen=FALSE;		// Windowed Mode Selected.  Fullscreen = FALSE
			}
			else
			{
				// Pop Up A Message Box Letting User Know The Program Is Closing.
				MessageBox(NULL,"Program Will Now Close.","ERROR",MB_OK|MB_ICONSTOP);
				return FALSE;									// Return FALSE
			}
		}
	}

	if (*fullscreen)												// Are We Still In Fullscreen Mode?
	{
		dwExStyle=WS_EX_APPWINDOW;								// Window Extended Style
		dwStyle=WS_POPUP;										// Windows Style
		ShowMouseCursor(FALSE);										// Hide Mouse Pointer
	}
	else
	{
		dwExStyle=WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;			// Window Extended Style
		dwStyle=WS_OVERLAPPEDWINDOW;							// Windows Style
	}

	AdjustWindowRectEx(&WindowRect, dwStyle, FALSE, dwExStyle);		// Adjust Window To True Requested Size

	// Create The Window
	if (!(hWnd=CreateWindowEx(	dwExStyle,							// Extended Style For The Window
								"OpenGL",							// Class Name
								title,								// Window Title
								dwStyle |							// Defined Window Style
								WS_CLIPSIBLINGS |					// Required Window Style
								WS_CLIPCHILDREN,					// Required Window Style
								0, 0,								// Window Position
								WindowRect.right-WindowRect.left,	// Calculate Window Width
								WindowRect.bottom-WindowRect.top,	// Calculate Window Height
								NULL,								// No Parent Window
								NULL,								// No Menu
								hInstance,							// Instance
								NULL)))								// Dont Pass Anything To WM_CREATE
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Window Creation Error.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	static	PIXELFORMATDESCRIPTOR pfd=				// pfd Tells Windows How We Want Things To Be
	{
		sizeof(PIXELFORMATDESCRIPTOR),				// Size Of This Pixel Format Descriptor
		1,											// Version Number
		PFD_DRAW_TO_WINDOW |						// Format Must Support Window
		PFD_SUPPORT_OPENGL |						// Format Must Support OpenGL
		PFD_DOUBLEBUFFER,							// Must Support Double Buffering
		PFD_TYPE_RGBA,								// Request An RGBA Format
		bits,										// Select Our Color Depth
		0, 0, 0, 0, 0, 0,							// Color Bits Ignored
		0,											// No Alpha Buffer
		0,											// Shift Bit Ignored
		0,											// No Accumulation Buffer
		0, 0, 0, 0,									// Accumulation Bits Ignored
		16,											// 16Bit Z-Buffer (Depth Buffer)  
		0,											// No Stencil Buffer
		0,											// No Auxiliary Buffer
		PFD_MAIN_PLANE,								// Main Drawing Layer
		0,											// Reserved
		0, 0, 0										// Layer Masks Ignored
	};
	
	if (!(hDC=GetDC(hWnd)))							// Did We Get A Device Context?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Create A GL Device Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if (!(PixelFormat=ChoosePixelFormat(hDC,&pfd)))	// Did Windows Find A Matching Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Find A Suitable PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if(!SetPixelFormat(hDC,PixelFormat,&pfd))		// Are We Able To Set The Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Set The PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if (!(hRC=wglCreateContext(hDC)))				// Are We Able To Get A Rendering Context?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Create A GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if(!wglMakeCurrent(hDC,hRC))					// Try To Activate The Rendering Context
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Activate The GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	ShowWindow(hWnd,SW_SHOW);						// Show The Window
	SetForegroundWindow(hWnd);						// Slightly Higher Priority
	SetFocus(hWnd);									// Sets Keyboard Focus To The Window
	ReSizeGLScene(width, height);					// Set Up Our Perspective GL Screen

	if (!InitGL())									// Initialize Our Newly Created GL Window
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Initialization Failed.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}
	// Get OpenGL Information
	// Version
	if(pbyOpenGLVersion)
		delete pbyOpenGLVersion;
	pbyOpenGLVersion = new char[strlen((const char *) glGetString(GL_VERSION))+1];
	strcpy(pbyOpenGLVersion, (const char *) glGetString(GL_VERSION));
	// Chip Info
	if(pbyOpenGLChipInfo)
		delete pbyOpenGLChipInfo;
	pbyOpenGLChipInfo = new char[strlen((const char *) glGetString(GL_VENDOR))+1];
	strcpy(pbyOpenGLChipInfo, (const char *) glGetString(GL_VENDOR));
	// Renderer Info
	if(pbyOpenGLRendererInfo)
		delete pbyOpenGLRendererInfo;
	pbyOpenGLRendererInfo = new char[strlen((const char *) glGetString(GL_RENDERER))+1];
	strcpy(pbyOpenGLRendererInfo, (const char *) glGetString(GL_RENDERER));
	// Extensions Info
	if(pbyOpenGLExtensionInfo)
		delete pbyOpenGLExtensionInfo;
	pbyOpenGLExtensionInfo = new char[strlen((const char *) glGetString(GL_EXTENSIONS))+1];
	strcpy(pbyOpenGLExtensionInfo, (const char *) glGetString(GL_EXTENSIONS));

	// Initialize DirectX Sound
    if(FAILED(DSUtil_InitDirectSound(hWnd)))
		bSoundPossible = FALSE;
	else
		bSoundPossible = TRUE;
	InitSounds();
	StartNewMidi();
	return TRUE;									// Success
}

LRESULT CALLBACK WndProc(	HWND	hWnd,			// Handle For This Window
							UINT	uMsg,			// Message For This Window
							WPARAM	wParam,			// Additional Message Information
							LPARAM	lParam)			// Additional Message Information
{
	switch (uMsg)									// Check For Windows Messages
	{
        case MCI_NOTIFY:
        {
            if (wParam == MCI_NOTIFY_SUCCESSFUL)
				StartNewMidi();
        }
        break;

		case WM_ACTIVATE:							// Watch For Window Activate Message
		{
			if (!HIWORD(wParam))					// Check Minimization State
			{
				active=TRUE;						// Program Is Active
			}
			else
			{
				active=FALSE;						// Program Is No Longer Active
			}

			return 0;								// Return To The Message Loop
		}

		case WM_PAINT:
			DrawGLScene();							// Here's Where We Do All The Drawing
		break;

		case WM_SYSKEYUP:
			switch (wParam)							// Check System Calls
			{
				case VK_RETURN:
					KillGLWindow();					// Kill Our Current Window
					Config.bFullScreen=!Config.bFullScreen;			// Toggle Fullscreen / Windowed Mode
					// Recreate Our OpenGL Window
					if(!Config.bFullScreen)
					{
						if (!CreateGLWindow(APP_TITLE,Config.iWindowWidth,Config.iWindowHeight,Config.DevMode.dmBitsPerPel,&Config.bFullScreen))
							return 0;					// Quit If Window Was Not Created
					}
					else
					{
						if (!CreateGLWindow(APP_TITLE,Config.DevMode.dmPelsWidth,Config.DevMode.dmPelsHeight,Config.DevMode.dmBitsPerPel,&Config.bFullScreen))
							return 0;					// Quit If Window Was Not Created
					}
				break;
			}
		break;

		case WM_SYSCOMMAND:							// Intercept System Commands
			switch (wParam)							// Check System Calls
			{
				case SC_SCREENSAVE:					// Screensaver Trying To Start?
				case SC_MONITORPOWER:				// Monitor Trying To Enter Powersave?
				return 0;							// Prevent From Happening
			}
		break;

		case WM_CLOSE:								// Did We Receive A Close Message?
		{
			PostQuitMessage(0);						// Send A Quit Message
			return 0;								// Jump Back
		}

		case WM_KEYDOWN:							// Is A Key Being Held Down?
		{
			keys[wParam] = TRUE;					// If So, Mark It As TRUE
			return 0;								// Jump Back
		}

		case WM_KEYUP:								// Has A Key Been Released?
		{
			keys[wParam] = FALSE;					// If So, Mark It As FALSE
			return 0;								// Jump Back
		}

		case WM_SIZE:								// Resize The OpenGL Window
		{
			Config.iWindowWidth = LOWORD(lParam);
			Config.iWindowHeight = HIWORD(lParam);
			ReSizeGLScene(LOWORD(lParam),HIWORD(lParam));  // LoWord=Width, HiWord=Height
			return 0;								// Jump Back
		}
	}

	// Pass All Unhandled Messages To DefWindowProc
	return DefWindowProc(hWnd,uMsg,wParam,lParam);
}

void CheckObjects(ACTOR *pActor2)
{
	ACTOR *pActor;
	short i;

	for(i = 0; i < MAX_OBJECTS; i++)
	{
		pActor = &pObject[i];
		if(!pActor->bActive && pActor2 != NULL)
		{
			pActor->fPos[X] = pActor2->fPos[X];
			pActor->fPos[Y] = pActor2->fPos[Y];
			pActor->fPosVelocity[Y] = -1.0f;
			if(rand() % 2 == 1)
				pActor->fPosVelocity[X] =  (float) (rand() % 100)/100.0f;
			else
				pActor->fPosVelocity[X] = -((float) (rand() % 100)/100.0f);
			// A Object Should Go Into The World
			if((rand() % pLevel->iObjectPowerIncreaseRandom) == 2)
			{
				pActor->bActive = TRUE;
				pActor->iType = OBJECT_POWER_INCREASE;
			}
			else
			if((rand() % pLevel->iObjectWallRandom) == 2)
			{
				pActor->bActive = TRUE;
				pActor->iType = OBJECT_WALL;
			}
			else
			if((rand() % pLevel->iObjectSingleLaserRandom) == 2)
			{
				pActor->bActive = TRUE;
				pActor->iType = OBJECT_SINGLE_LASER_WEAPON;
			}
			else
			if((rand() % pLevel->iObjectDoubleLaserRandom) == 2)
			{
				pActor->bActive = TRUE;
				pActor->iType = OBJECT_DOUBLE_LASER_WEAPON;
			}
			else
			if((rand() % pLevel->iObjectLiveRandom) == 2)
			{
				pActor->bActive = TRUE;
				pActor->iType = OBJECT_LIVE;
			}
			continue;
		}
		if(pActor->bActive)
		{
			pActor->fPos[X] += (pActor->fPosVelocity[X]*g_lDeltatime)/1000.0f;
			pActor->fPos[Y] += (pActor->fPosVelocity[Y]*g_lDeltatime)/100.0f;
			pActor->fRot[X] += (5.0f*g_lDeltatime)/100.0f;
			pActor->fRot[Y] += (5.0f*g_lDeltatime)/100.0f;
			pActor->fRot[Z] += (5.0f*g_lDeltatime)/100.0f;
			if(pActor->fPos[Y] < -20.0f || pActor->fPos[X] > SPACE_WIDTH+20.0f ||
			   pActor->fPos[X] < -0.0f)
			   pActor->bActive = FALSE;
		}
	}
}

void CheckShot(void)
{
	ACTOR *pActor, *pActor2;
	short i, i2, i3;
	float fX, fY, fDistance, f;
	BOOL bCheckOnlyWall = FALSE, bCheckNoWall = FALSE;

	for(i = 0; i < MAX_SHOTS; i++)
	{
		pActor = &pShot[i];
		if(!pActor->bActive)
			continue;
		pActor->fPos[Y] += (pActor->fPosVelocity[Y]*g_lDeltatime)/50.0f;
		pActor->fPos[X] += (pActor->fPosVelocity[X]*g_lDeltatime)/50.0f;
		if(pActor->fPos[X] < -100.0f)
			pActor->bActive = FALSE;
		if(pActor->fPos[X] > SPACE_WIDTH+100.0f)
			pActor->bActive = FALSE;
		if(pActor->iType != WORMHOLE_SHOT && pActor->fPos[Y] > SPACE_HEIGHT+5.0f &&
		   pActor->iType == PLAYER_SHOT)
		{
			pActor->bActive = FALSE;
			if(byPlayerWeapon == DOUBLE_LASER_WEAPON)
				fWormholeHitPoints -= 8.0f;
			else
				fWormholeHitPoints -= 10.0f;
			DSUtil_PlaySound(pWormholeSound, 0);
		}
		if(pActor->fPos[Y] < -20.0f)
			pActor->bActive = FALSE;
		bCheckNoWall = FALSE;
		switch(pActor->iType)
		{
			case PLAYER_SHOT: case WORMHOLE_SHOT:
				if(!pActor->pFrameT)
					break;
			CheckAlien:
				for(i2 = 0; i2 < MAX_ALIENS; i2++)
				{
					pActor2 = &pAlien[i2];
					if(!pActor2->bActive || !pActor2->pFrameT ||
						pActor2->iExplosionStep != -1) 
						continue;
					if(pActor2->iType == ALIEN_2)
						f = -13.0f;
					else
						f = -7.0f;
					if(bCheckOnlyWall && pActor2->iType != WALL)
						continue;
					fX = pActor2->fPos[X]+pActor2->fPos2[X]-pActor->fPos[X];
					fY = pActor2->fPos[Y]+pActor2->fPos2[Y]-pActor->fPos[Y];
					fDistance = fX*fX + fY*fY;
  					if(fDistance <= (pActor->pFrameT->fMiddle[X]+pActor2->pFrameT->fMiddle[X]+f)*
									(pActor->pFrameT->fMiddle[Y]+pActor2->pFrameT->fMiddle[Y]+f))
					{ // We Habe A Collision						
 						pActor->bActive = FALSE;
						if(!pActor2->bShield || pActor->iType == WORMHOLE_SHOT)
							pActor2->byLives--;
						if(pActor2->byLives <= -1)
						{
							if(pActor2->iType != WALL)
								CheckObjects(pActor2);
							pActor2->iExplosionStep = 0;
							pActor2->lStartTime = GetTickCount();
							pActor2->fPosVelocity[Y] = 2.0f;
							pActor2->fRotVelocity[X] = -2.0f;
							pActor2->fRotVelocity[Y] = 1.0f;
							pActor2->fRotVelocity[Z] = -10.0f;
							switch(pActor2->iType)
							{
								case ALIEN_5:
									DSUtil_PlaySound(pAlien5DeadSound, 0);
								break;
	
								case BIG_BOSS:
									DSUtil_PlaySound(pBigBossDeadSound, 0);
									fWormholeHitPoints = 0;
									for(i3 = 0; i3 < 50; i3++)
										CheckObjects(pActor2);
								break;

								default:
									DSUtil_PlaySound(pExplosion1Sound, 0);
							}
							// Give The Player Some Points
							switch(pActor2->iType)
							{
								case ALIEN_1: iScore += ALIEN_1_POINTS; break;
								case ALIEN_2: iScore += ALIEN_2_POINTS; break;
								case ALIEN_3: iScore += ALIEN_3_POINTS; break;
								case ALIEN_4: iScore += ALIEN_4_POINTS; break;
								case ALIEN_5: iScore += ALIEN_5_POINTS; break;
								case BIG_BOSS: iScore += BIG_BOSS_POINTS; break;
							}
							break;
						}
						if(pActor2->iType == ALIEN_3)
						{ // Show The Damage
							pActor2->iAnimationT++;
							pActor2->iStepT = 0;
							// The Shot Goes Back
							pActor->bActive = TRUE;
							pActor->fPosVelocity[Y] = -pActor->fPosVelocity[Y];
						}
						if(pActor2->iType == WALL)
						{ // Show The Damage
							pActor2->iAnimationT++;
							pActor2->iStepT = 0;
						}
						if(pActor2->iType == BIG_BOSS)
						{ // Show The Damage
							pActor2->fPos[Y] += 0.5f;
						}
						break;
					}
				}
				if(pActor->fPosVelocity[Y] < 0)
				{
					bCheckNoWall = TRUE;
					goto PlayerCheck;
				}
				if(pActor->iType == WORMHOLE_SHOT)	
					goto PlayerCheck;
			break;
			
			case ALIEN_SHOT: case ALIEN_5_SHOT:
			PlayerCheck:
				if(!pActor->pFrameT || !pPlayer.bActive || !pPlayer.pFrameT ||
					pPlayer.iExplosionStep != -1)
					continue;
				fX = pPlayer.fPos[X]-pActor->fPos[X];
				fY = 0.0f-pActor->fPos[Y];
				fDistance = fX*fX + fY*fY;
  				if(fDistance <= (pActor->pFrameT->fMiddle[X]+pPlayer.pFrameT->fMiddle[X])*
								(pActor->pFrameT->fMiddle[Y]+pPlayer.pFrameT->fMiddle[Y]))
				{ // We Have A Collision
					pActor->bActive = FALSE;
					if((!pPlayer.bShield || pActor->iType == WORMHOLE_SHOT) &&
					    !bInvulnerableCheat)
					{
						pPlayer.byLives--;
						pPlayer.iExplosionStep = 0;
						pPlayer.lStartTime = GetTickCount();
						pPlayer.fRotVelocity[X] = -0.5f;
						pPlayer.fRotVelocity[Z] = 0.5f;
						pPlayer.fRotVelocity[Z] = -0.2f;
						pPlayer.fPosVelocity[Z] = -1.0f;
						DSUtil_PlaySound(pExplosion2Sound, 0);
						fPlanetZScaleVelocity = 0.1f;
					}
					goto NextShot;
				}
				if(pActor->iType != WORMHOLE_SHOT && !bCheckNoWall)
				{
					// Check If The Alien Shot Hits A Wall					
					bCheckOnlyWall = TRUE;
					goto CheckAlien;
				}
			break;
		}
	NextShot:;
	}
}

void CheckAlien(void)
{
	ACTOR *pActor, *pActor2;
	float fX, fY, fDistance;
	short i;

	for(i = 0; i < MAX_ALIENS; i++)
	{
		pActor = &pAlien[i];
		if(!pActor->bActive)
			continue;
		// Animate The Explosion
		if(pActor->iExplosionStep != -1)
		{
			pActor->iExplosionStep = (short) (g_lNow - pActor->lStartTime) / 100;
			if(pActor->iExplosionStep >= 16)
				pActor->bActive = FALSE;			
		}
		// Move The Alien
		if(pActor->iType != BIG_BOSS)
		{
			pActor->fPos[X] += (pActor->fPosVelocity[X]*g_lDeltatime)/1000;
			pActor->fPos[Y] += (pActor->fPosVelocity[Y]*g_lDeltatime)/1000;
		}
		if(pActor->fPos[Y] < 0.0f)
		{ // The Player Couldn't Stop Them!
			GameOver();
			return;
		}
		pActor->fRot[X] += (pActor->fRotVelocity[X]*g_lDeltatime)/1000;
		pActor->fRot[Y] += (pActor->fRotVelocity[Y]*g_lDeltatime)/1000;
		pActor->fRot[Z] += (pActor->fRotVelocity[Z]*g_lDeltatime)/1000;
		if(pActor->fPosVelocity[Y] > 0.0f)
		{
			pActor->fPosVelocity[Y] -= pLevel->fYSpeedDecrease*g_lDeltatime/1000;
			if(pActor->fPosVelocity[Y] < 0.0f)
				pActor->fPosVelocity[Y] = 0.0f;
		}
		else
		{
			pActor->fPosVelocity[Y] += pLevel->fYSpeedDecrease*g_lDeltatime/1000;
			if(pActor->fPosVelocity[Y] > 0.0f)
				pActor->fPosVelocity[Y] = 0.0f;
		}
		if(pActor->iType != WALL)
		{
			if(pActor->fPosVelocity[X] < 0)
				pActor->fPosVelocity[X]	-= pLevel->fXSpeedIncrease*g_lDeltatime/1000;
			else
				pActor->fPosVelocity[X]	+= pLevel->fXSpeedIncrease*g_lDeltatime/1000;
		}
		if(pActor->fPos[X] < 4.0f)
		{
			pActor->fPos[X] = 4.0f;
			pActor->fPosVelocity[X] = -pActor->fPosVelocity[X];
			pActor->fPosVelocity[Y] -= 1.0f;
		}
		else
			if(pActor->fPos[X] > SPACE_WIDTH-4.0f)
			{
				pActor->fPos[X] = SPACE_WIDTH-4.0f;
				pActor->fPosVelocity[X] = -pActor->fPosVelocity[X];
				pActor->fPosVelocity[Y] -= 1.0f;
			}
		if(pActor->fPos2[Y] > 0.0f)
		{
			pActor->fPos2[Y] -= pActor->fPos2[Y]/SPACE_HEIGHT;
			if(pActor->fPos2[Y] < 0.5f)
				pActor->fPos2[Y] = 0.0f;
		}
		switch(pActor->iType)
		{
			case ALIEN_1:
				if(pActor->bAttack)
				{
					if(pActor->iStepT == 2 && !pActor->iTemp)
					{
						// The Alien Fires Now
						for(i = 0; i < MAX_SHOTS; i++)
						{
							pActor2 = &pShot[i];
							if(pActor2->bActive)
								continue;
							// We Found A None Active Shot:
							pActor2->bActive = TRUE;
							InitActor(pActor2);
							pActor2->fPos[X] = pActor->fPos[X]+pActor->fPos2[X];
							pActor2->fPos[Y] = pActor->fPos[Y]+pActor->fPos2[Y];
							pActor2->fPosVelocity[Y] = -2.0f;
							pActor2->iType = ALIEN_SHOT;
							DSUtil_PlaySound(pAlienShotSound, 0);
							pActor->iTemp = 1;
							break;
						}
					}
					if(pActor->iStepT == 4)
					{
						pActor->bAttack = FALSE;
						pActor->iTemp = 0;
						pActor->iAnimationT = 0;
						pActor->iStepT = 0;
					}
					break;
				}
				// Check If The Alien Fire A Shot:
				if((rand() % pLevel->iAlien1Random) == 2)
				{
					pActor->bAttack = TRUE;
					pActor->iAnimationT = 1;
					pActor->iStepT = 0;
				}
			break;

			case ALIEN_2:
				// Check If The Alien Attack The Player:
				if(pActor->bAttack)
				{
					pActor->fPos2[Y] += pActor->fPos2Velocity[Y]*g_lDeltatime/100;
					pActor->fPos2Velocity[Y] -= 0.01f*g_lDeltatime;
					if(pActor->fPos2Velocity[Y] < -2.0f)
						pActor->fPos2Velocity[Y] = -2.0f;
					if(pActor->fPos[Y]+pActor->fPos2[Y] < -20.0f)
					{
						pActor->fPos2[Y] = SPACE_HEIGHT+20.0f;
						pActor->bAttack = FALSE;
						pActor->iAnimationT = 0;
						pActor->iStepT = -1;
					}
				}
				else
					if((rand() % pLevel->iAlien2Random) == 2 && pActor->fPos2[Y] == 0.0f)
					{
						pActor->bAttack = TRUE;
						pActor->iAnimationT = 1;
						pActor->iStepT = 0;
						for(i = 0; i < MAX_SHOTS; i++)
						{
							pActor2 = &pShot[i];
							if(pActor2->bActive)
								continue;
							// We Found A None Active Shot:
							pActor2->bActive = TRUE;
							InitActor(pActor2);
							pActor2->fPos[X] = pActor->fPos[X];
							pActor2->fPos[Y] = pActor->fPos[Y];
							pActor2->fPosVelocity[Y] = -2.0f;
							pActor2->iType = ALIEN_SHOT;
							DSUtil_PlaySound(pAlienAttackSound, 0);
							break;
						}
					}
			break;

			case ALIEN_3:
				// This Alien Do Nothing
				if((rand() % pLevel->iAlien3Random) == 2)
				{
				}
			break;
			
			case ALIEN_4:
				if(pActor->bAttack)
				{
					if(pActor->iStepT == 12)
					{ // Deactivate The Shield
						pActor->bAttack = FALSE;
						pActor->bShield = FALSE;
						pActor->iAnimationT = 0;
						pActor->iStepT = 0;
					}
					break;
				}
				// Check If The Alien Activate His Shield:
				if((rand() % pLevel->iAlien4Random) == 2)
				{
					pActor->bAttack = TRUE;
					pActor->bShield = TRUE;
					pActor->iAnimationT = 1;
					pActor->iStepT = 0;
				}
			break;

			case ALIEN_5:
				if(pActor->bAttack)
				{
					if(pActor->iStepT == 3 && !pActor->iTemp)
					{
						// The 'Alien' Fires Now
						for(i = 0; i < MAX_SHOTS; i++)
						{
							pActor2 = &pShot[i];
							if(pActor2->bActive)
								continue;
							// We Found A None Active Shot:
							pActor2 = &pShot[i];
							if(pActor2->bActive)
								continue;
							// We Found A None Active Shot:
							pActor2->bActive = TRUE;
							InitActor(pActor2);
							pActor2->fPos[X] = pActor->fPos[X]+pActor->fPos2[X];
							pActor2->fPos[Y] = pActor->fPos[Y]+pActor->fPos2[Y];
							pActor2->fPosVelocity[Y] = -2.0f;
							pActor2->iType = ALIEN_5_SHOT;
							DSUtil_PlaySound(pAlien5ShotSound, 0);
							pActor->iTemp = 1;
							break;
						}
					}
					if(pActor->iStepT == 6)
					{
						pActor->bAttack = FALSE;
						pActor->iTemp = 0;
						pActor->iAnimationT = 0;
						pActor->iStepT = 0;
					}
					break;
				}
				// Check If The 'Alien' Fires A Shot:
				if((rand() % pLevel->iAlien5Random) == 2)
				{
					pActor->bAttack = TRUE;
					pActor->iAnimationT = 1;
					pActor->iStepT = 0;
				}
			break;

			case BIG_BOSS:
				// Check If The BigBoss Fire:
				if((rand() % (320-(300-100/(pActor->byLives+2)*300))) == 2)
				{
					for(i = 0; i < MAX_ALIENS/4; i++)
					{
						pActor2 = &pAlien[i];
						if(pActor2->bActive)
							continue;
						// We Found A None Active Alien
						InitActor(pActor2);
						pActor2->bActive = TRUE;
						pActor2->fPos[X] = pActor->fPos[X]+pActor->fPos2[X];
						pActor2->fPos[Y] = pActor->fPos[Y]+pActor->fPos2[Y]-30.0f;
						if(rand() % 2 == 0)
						{
							pActor2->fPos[X] += (float) (rand() % 10);
							pActor2->fPosVelocity[X] = (float) (rand() % 10)/10;
						}
						else
						{
							pActor2->fPos[X] -= (float) (rand() % 10);
							pActor2->fPosVelocity[X] = -((float) (rand() % 10)/10);
						}
						pActor2->fPos2[Y] = pActor->fPos[Y]+pActor->fPos2[Y]-pActor2->fPos[Y];
						pActor2->fPos[Y] -= ((float) (rand() % 100)/50);
						pActor2->fPos2Velocity[Y] = ((float) (rand() % 100)/50);
						pActor2->iType = (rand() % 4)+ALIEN_1;
						if(pActor2->iType == ALIEN_3)
							pActor2->byLives = 4;
						DSUtil_PlaySound(pAlien5ShotSound, 0);
						break;
					}
				}
			break;
		}
		// Check If The Alien Hits The Player
		if(!pPlayer.bActive || pPlayer.bShield || pPlayer.iExplosionStep != -1)
			continue;
		fX = pPlayer.fPos[X]-(pActor->fPos[X]+pActor->fPos2[X]);
		fY = 0.0f-(pActor->fPos[Y]+pActor->fPos2[Y]);
		fDistance = fX*fX + fY*fY;
  		if(!pActor->pFrameT || !pPlayer.pFrameT)
			continue;
		if(fDistance <= (pActor->pFrameT->fMiddle[X]+pPlayer.pFrameT->fMiddle[X])*
						(pActor->pFrameT->fMiddle[Y]+pPlayer.pFrameT->fMiddle[Y]))
		{ // We Have A Collision
			// Alien
			pActor->byLives--;
			if(pActor->byLives <= -1)
			{
				pActor->iExplosionStep = 0;
				pActor->lStartTime = GetTickCount();
				pActor->fPosVelocity[Y] = 2.0;
				pActor->fRotVelocity[X] = -2.0;
				pActor->fRotVelocity[Y] = 1.0;
				pActor->fRotVelocity[Z] = -10;
				if(pActor->iType == ALIEN_5)
					DSUtil_PlaySound(pAlien5DeadSound, 0);
				else
					DSUtil_PlaySound(pExplosion1Sound, 0);
			}
			else
				if(pActor->iType == ALIEN_3)
				{ // Show The Damage
					pActor->iAnimationT++;
					pActor->iStepT = 0;
				}
			if(!bInvulnerableCheat)
			{ // Player
				pPlayer.byLives--;
				pPlayer.iExplosionStep = 0;
				pPlayer.lStartTime = GetTickCount();
				pPlayer.fRotVelocity[X] = -1.0;
				pPlayer.fRotVelocity[Z] = 1.0;
				pPlayer.fRotVelocity[Z] = -0.5;
				pPlayer.fPosVelocity[Z] = -1.0;
				DSUtil_PlaySound(pExplosion2Sound, 0);
    			fPlanetZScaleVelocity = 0.1f;
			}
			break;
		}
	}
}

void CheckPlayer(void)
{
	ACTOR *pActor;
	float fX, fY, fDistance;
	short i;

	if(bAlwaysDouble)
		byPlayerWeapon = DOUBLE_LASER_WEAPON;
	if(bUnlimitedPower)
		pPlayer.fPower = pPlayer.fMaxPower;
	if(!pPlayer.bActive && !bGameWon)
	{
		if(pPlayer.byLives >= 0)
		{
			InitActor(&pPlayer);
			byPlayerWeapon = SINGLE_LASER_WEAPON;
		}
		else
		{ // The Game Is Over The Planet Killed
			GameOver();
		}
		return;
	}
	// Check Ghost modus
	if(pPlayer.bGhost)
		if((g_lNow - pPlayer.lStartTime) > PLAYER_GHOST_TIME)
			pPlayer.bGhost = FALSE;
	// Check Players Power
	if(pPlayer.fPower < pPlayer.fMaxPower)
	{
		pPlayer.fPower += 0.02f*g_lDeltatime;
		if(pPlayer.fPower > pPlayer.fMaxPower)
			pPlayer.fPower = pPlayer.fMaxPower;
	}	
	// Animate The Explosion
	if(pPlayer.iExplosionStep != -1)
	{
		pPlayer.iExplosionStep = (short) (g_lNow - pPlayer.lStartTime) / 100;
		if(pPlayer.iExplosionStep >= 16)
			pPlayer.bActive = FALSE;			
	}
	// Position
	pPlayer.fPos[X] += pPlayer.fPosVelocity[X]*g_lDeltatime;
	pPlayer.fPos[Z] += pPlayer.fPosVelocity[Z]*g_lDeltatime;
	// Check The Level Bounds
	if(pPlayer.pFrameT)
	{
		if(pPlayer.fPos[X]-pPlayer.pFrameT->fMiddle[X] < 0.0f)
			pPlayer.fPos[X] = pPlayer.pFrameT->fMiddle[X];
		if(pPlayer.fPos[X]+pPlayer.pFrameT->fMiddle[X] > SPACE_WIDTH)
			pPlayer.fPos[X] = SPACE_WIDTH-pPlayer.pFrameT->fMiddle[X];
	}
	// Check If He Collects A Object
	for(i = 0; i < MAX_OBJECTS; i++)
	{
		pActor = &pObject[i];
		if(!pActor->bActive || !pActor->pFrameT)
			continue;
		fX = pPlayer.fPos[X]-pActor->fPos[X];
		fY = 0.0f-pActor->fPos[Y];
		fDistance = fX*fX + fY*fY;
  		if(!pPlayer.pFrameT || !pActor->pFrameT)
			continue;
		if(fDistance <= (pPlayer.pFrameT->fMiddle[X]+pActor->pFrameT->fMiddle[X])*
						(pPlayer.pFrameT->fMiddle[Y]+pActor->pFrameT->fMiddle[Y]))
		{ // We Habe A Collision						
			switch(pActor->iType)
			{
				case OBJECT_LIVE:
					if(pPlayer.byLives < 3)
					{
						pPlayer.byLives++;
						fPlanetZScaleVelocity = -0.1f;
					}
					DSUtil_PlaySound(pObjectLiveSound, 0);
					iScore += O_LIVE_POINTS;
				break;
				
				case OBJECT_WALL:
					SetWalls();
					iScore += O_WALL_POINTS;
					DSUtil_PlaySound(pObjectWallSound, 0);
				break;
				
				case OBJECT_SINGLE_LASER_WEAPON:
					byPlayerWeapon = SINGLE_LASER_WEAPON;
					iScore += O_SINGLE_LASER_POINTS;
					DSUtil_PlaySound(pObjectSingleLaserSound, 0);
				break;
				
				case OBJECT_DOUBLE_LASER_WEAPON:
					byPlayerWeapon = DOUBLE_LASER_WEAPON;
					iScore += O_DOUBLE_LASER_POINTS;
					DSUtil_PlaySound(pObjectDoubleLaserSound, 0);
				break;
				
				case OBJECT_POWER_INCREASE:
					pPlayer.fMaxPower += 10.0f;
					iScore += O_POWER_INCREASE_POINTS;
					DSUtil_PlaySound(pObjectPowerIncreaseSound, 0);
				break;
			}			
			pActor->bActive = FALSE;
		}
	}
}

void CheckPlayersHighscore(void)
{
	int i, i2;
	unsigned long i3;
	
	if(byPlayersHScorePlace == -1)
	{ // Check if the player is in the highscore:
		for(i = 0; i < MAX_HIGHSCORES; i++)
		{
			if(iScore >= Highscore[i].iScore)
			{ // The player is better as someone:
				// Make place for the new king:
				for(i2 = MAX_HIGHSCORES-1; i2 >= i; i2--)
				{
					Highscore[i2].iLevel = Highscore[i2-1].iLevel;
					Highscore[i2].iScore = Highscore[i2-1].iScore;
					strcpy(Highscore[i2].byName, Highscore[i2-1].byName);
				}
				Highscore[i].iScore = iScore;
				Highscore[i].iLevel = byLevel;
				byPlayersHScorePlace = i;
				byHighScoreInitialsIndex = 9;
				i3 = MAX_PATH;
				GetUserName(byTemp, &i3);
				memset(Highscore[i].byName, 0, 30);
				for(i2 = 0; i2 < 9; i2++)
				{
					Highscore[i].byName[i2] = byTemp[i2];
					if(byTemp[i2] == '\0')
						break;
				}
				break;
			}
		}
		if(byPlayersHScorePlace == -1)
		{ // The player is a looser:
			byPlayersHScorePlace = -2;
		}
	}
	if(byHighScoreInitialsIndex < 9)
	{
		if((((g_lNow-g_lProgramStartTime) / 500)) % 2)
			Highscore[byPlayersHScorePlace].byName[byHighScoreInitialsIndex] = '_';
		else
			Highscore[byPlayersHScorePlace].byName[byHighScoreInitialsIndex] = ' ';
	}
	if((keys[VK_RETURN]))
	{ // Close The Hightscore Menu:
		keys[VK_RETURN]=FALSE;
		if(byHighScoreInitialsIndex < 9)
			Highscore[byPlayersHScorePlace].byName[byHighScoreInitialsIndex] = ' ';
		InitGameIntro();
		return;
	}
	if(byPlayersHScorePlace != -2)
	{
		if(keys[VK_BACK])
		{
			keys[VK_BACK] = FALSE;
			if(byHighScoreInitialsIndex > 0)
			{
				Highscore[byPlayersHScorePlace].byName[byHighScoreInitialsIndex] = ' ';
				byHighScoreInitialsIndex--;
				Highscore[byPlayersHScorePlace].byName[byHighScoreInitialsIndex] = ' ';
			}
		}
		else 
		if(byHighScoreInitialsIndex <= 8)
		{			
			for(i = 0; i < 38; i++) 
			{
				if(keys[byLegalHighScoreChars[i]])
				{
					Highscore[byPlayersHScorePlace].byName[byHighScoreInitialsIndex] = byLegalHighScoreChars[i];
					keys[byLegalHighScoreChars[i]] = FALSE;
					byHighScoreInitialsIndex++;
					break;
				}
			}
		}
	}
}

GLvoid CheckScene(GLvoid)
{
	ACTOR *pActor;
	short i, i2, i3;

	CheckMidi();
	// Update Time
	g_lNow = GetTickCount();
	g_lDeltatime = g_lNow - g_lLastChecktime;
	if(Config.bShowFPS)
	{
		g_lFramesRenderedSinceCheck++;
		if(g_lDeltatime > 1000)
		{
			// Compute average FPS
			g_lLastChecktime = g_lNow;
			g_iFps =  g_lFramesRenderedSinceCheck;
			g_lFramesRenderedSinceCheck = 0;
		}
	}
	g_lDeltatime = g_lNow - g_lLastlooptime;
	g_lLastlooptime = g_lNow;
	g_lGameLength = (g_lNow - g_lProgramStartTime) / 1000;
	// Move Background
	g_fBackgroundRot += 0.0005f * g_lDeltatime;
	// Check The Wormhole
	if(fWormholeHitPoints < 1)
	{
		// The Wormhole Fires Shots
		fWormholeHitPoints = 20;
		i3 = (rand() % 50)+50;
		for(i2 = 0; i2 < i3; i2++)
			for(i = 0; i < MAX_SHOTS; i++)
			{
				pActor = &pShot[i];
				if(pActor->bActive)
					continue;
				// We Found A None Active Shot:
				pActor->bActive = TRUE;
				pActor->fPos[X] = (float) (rand() % ((int) SPACE_WIDTH));
				pActor->fPos[Y] = SPACE_HEIGHT+((float) (rand() % 30));
				if(rand() % 2 == 0)
					pActor->fPosVelocity[X] = -((float) (rand() % ((int) 500))/100);
				else
					pActor->fPosVelocity[X] = (float) (rand() % ((int) 500))/100;
				pActor->fPosVelocity[Y] = -((float) (rand() % ((int) 1300))/1000);
				if(pActor->fPosVelocity[Y] > -2.0f)
					pActor->fPosVelocity[Y] = -2.0f;
				pActor->iType = WORMHOLE_SHOT;
				DSUtil_PlaySound(pWormholeShotSound, 0);
				break;
			}
	}
	if(fWormholeHitPoints)
		byWormholeAniStep = ((int) ((g_lNow - g_lProgramStartTime) / fWormholeHitPoints)) % WORMHOLE_ANIS;
	if(!byWormholeAniStep)
		fWormholeHitPoints += 0.5f;
	if(fWormholeHitPoints > 100.0f)
		fWormholeHitPoints = 100.0f;
	if(!bGameIntro)
	{ // We Are In The Game
		if(bPlayerEnteringHighScore)
		{
			CheckPlayersHighscore();
		}
		else
		{
			if (keys[VK_ESCAPE])
			{
				keys[VK_ESCAPE]=FALSE;
				InitGameIntro();
				return;
			}		
			if(pPlayer.byLives == -1)
			{ // The Player Is Dead
				pPlayer.fPos[X] = SPACE_WIDTH/2;
			}
			// Player Control
			if(pPlayer.iExplosionStep == -1 && pPlayer.bActive)
			{
				if (keys[VK_DOWN] || pPlayer.bGhost)
					pPlayer.bShield = TRUE;
				else
					pPlayer.bShield = FALSE;
				if(pPlayer.bShield && !pPlayer.bGhost)
				{
					pPlayer.fPower -= SHIELD_POWER;
					if(pPlayer.fPower < 0.0f)
					{
						pPlayer.fPower = 0.0f;
						pPlayer.bShield = FALSE;
					}
				}
				if (keys[VK_LEFT])
				{
					// Position
					pPlayer.fPosVelocity[X] -= 0.005f*g_lDeltatime;
					if(pPlayer.fPosVelocity[X] < -0.05f)
						pPlayer.fPosVelocity[X] = -0.05f;
					// Rotation
					pPlayer.fRotVelocity[Z] -= 0.005f*g_lDeltatime;
					if(pPlayer.fRotVelocity[Z] < -0.05f)
						pPlayer.fRotVelocity[Z] = -0.05f;
				}
				else
				if (keys[VK_RIGHT])
				{
					// Position
					pPlayer.fPosVelocity[X] += 0.005f*g_lDeltatime;
					if(pPlayer.fPosVelocity[X] > 0.05f)
						pPlayer.fPosVelocity[X] = 0.05f;
					// Rotation
					pPlayer.fRotVelocity[Z] += 0.005f*g_lDeltatime;
					if(pPlayer.fRotVelocity[Z] > 0.05f)
						pPlayer.fRotVelocity[Z] = 0.05f;
				}
				else
				{
					// Position
					if(pPlayer.fPosVelocity[X] > 0.0f)
					{
						pPlayer.fPosVelocity[X] -= 0.0005f*g_lDeltatime;
						if(pPlayer.fPosVelocity[X] < 0.0f)
							pPlayer.fPosVelocity[X] = 0.0f;
					}
					else
					{
						if(pPlayer.fPosVelocity[X] < 0.0f)
							pPlayer.fPosVelocity[X] += 0.0005f*g_lDeltatime;
						if(pPlayer.fPosVelocity[X] > 0.0f)
							pPlayer.fPosVelocity[X] = 0.0f;
					}
					// Rotation
					if(pPlayer.fRot[Z] > 0)
					{
						pPlayer.fRotVelocity[Z] -= 0.001f*g_lDeltatime;
						if(pPlayer.fRotVelocity[Z] < -0.03f)
							pPlayer.fRotVelocity[Z] = -0.03f;
						pPlayer.fRot[Z] += pPlayer.fRotVelocity[Z]*g_lDeltatime;
						if(pPlayer.fRot[Z] < 0.0f)
						{
							pPlayer.fRot[Z] = 0.0f;
							pPlayer.fRotVelocity[Z] = 0.0f;
						}
					}
					else
					if(pPlayer.fRot[Z] < 0)
					{
						pPlayer.fRotVelocity[Z] += 0.001f*g_lDeltatime;
						if(pPlayer.fRotVelocity[Z] > 0.03f)
							pPlayer.fRotVelocity[Z] = 0.03f;
						pPlayer.fRot[Z] += pPlayer.fRotVelocity[Z]*g_lDeltatime;
						if(pPlayer.fRot[Z] > 0.0f)
						{
							pPlayer.fRot[Z] = 0.0f;
							pPlayer.fRotVelocity[Z] = 0.0f;

						}
					}
					goto Next;
				}
				// Rotation
				pPlayer.fRot[Z] += pPlayer.fRotVelocity[Z]*g_lDeltatime;
				if(pPlayer.fRot[Z] > 30.0f)
					pPlayer.fRot[Z] = 30.0f;
				else
					if(pPlayer.fRot[Z] < -30.0f)
						pPlayer.fRot[Z] = -30.0f;
			Next:
				if (keys[VK_SPACE])
				{
					keys[VK_SPACE]=FALSE;
					if(((pPlayer.fPower >= SINGLE_SHOT_POWER && byPlayerWeapon == SINGLE_LASER_WEAPON) ||
					   (pPlayer.fPower >= DOUBLE_SHOT_POWER && byPlayerWeapon == DOUBLE_LASER_WEAPON)) && 
					   g_lNow-lLastPlayerShotTime > 200)
					{
						lLastPlayerShotTime = g_lNow;
						if(byPlayerWeapon == DOUBLE_LASER_WEAPON)
							i3 = 2;
						else
							i3 = 1;
						for(i2 = 0; i2 < i3; i2++)
							for(i = 0; i < MAX_SHOTS; i++)
							{
								pActor = &pShot[i];
								if(pActor->bActive)
									continue;
								// We Found A None Active Shot:
								pActor->bActive = TRUE;
								InitActor(pActor);
								if(byPlayerWeapon == DOUBLE_LASER_WEAPON)
								{
									pPlayer.fPower -= DOUBLE_SHOT_POWER;
									if(!i2)
										pActor->fPos[X] = pPlayer.fPos[X]-3.0f;
									else
										pActor->fPos[X] = pPlayer.fPos[X]+3.0f;
								}
								else
								{
									pPlayer.fPower -= SINGLE_SHOT_POWER;
									pActor->fPos[X] = pPlayer.fPos[X];
								}
								pActor->fPos[Y] = 0.0f;
								pActor->fPosVelocity[Y] = 2.0f;
								pActor->iType = PLAYER_SHOT;
								DSUtil_PlaySound(pPlayerShotSound, 0);
								break;
							}
					}
				}
			}
			else
			{
				pPlayer.fRot[X] += pPlayer.fRotVelocity[X]*g_lDeltatime;
				pPlayer.fRot[Y] += pPlayer.fRotVelocity[Y]*g_lDeltatime;
				pPlayer.fRot[Z] += pPlayer.fRotVelocity[Z]*g_lDeltatime;
			}
		}
		// Standart Perspectives:
		if (keys[VK_F1])
		{
			keys[VK_F1]=FALSE;
			fXRot = -80.0f;
			fZPos = -10.0f;
			pPlayer.fPos[Y] = 0.0f;
		}
		if (keys[VK_F2])
		{
			keys[VK_F2]=FALSE;
			fXRot = -64.0f;
			fZPos = -28.0f;
			pPlayer.fPos[Y] = -1.0f;
		}
		if (keys[VK_F3])
		{
			keys[VK_F3]=FALSE;
			fXRot = -40.0f;
			fZPos = -126.0f;
			pPlayer.fPos[Y] = -40.0f;
		}
		if (keys[VK_F4])
		{
			keys[VK_F4]=FALSE;
			fXRot = -0.0f;
			fZPos = -137.0f;
			pPlayer.fPos[Y] = -50.0f;
		}
		if (keys[VK_F5])
		{
			keys[VK_F5]=FALSE;
			fXRot = 40.0f;
			fZPos = -150.0f;
			pPlayer.fPos[Y] = -57.0f;
		}
		if (keys[VK_F6])
		{
			keys[VK_F6]=FALSE;
			fXRot = 60.0f;
			fZPos = -179.0f;
			pPlayer.fPos[Y] = -38.0f;
		}
		if (keys[VK_F7])
		{
			keys[VK_F7]=FALSE;
			fXRot = 80.0f;
			fZPos = -155.0f;
			pPlayer.fPos[Y] = -20.0f;
		}
		// Adjust Perspective
		if (keys[VK_SUBTRACT])
		{
			keys[VK_SUBTRACT]=FALSE;
			if(fXRot > -80.0f)
				fXRot -= 1.0f;
		}
		if (keys[VK_ADD])
		{
			keys[VK_ADD]=FALSE;
			if(fXRot < 80.0f)
				fXRot += 1.0f;
		}
		if (keys[VK_NUMPAD7])
		{
			keys[VK_NUMPAD7]=FALSE;
			fZPos += 1.0f;
		}
		if (keys[VK_NUMPAD1])
		{
			keys[VK_NUMPAD1]=FALSE;
			fZPos -= 1.0f;
		}
		if (keys[VK_NUMPAD9])
		{
			keys[VK_NUMPAD7]=FALSE;
			pPlayer.fPos[Y] += 1.0f;
		}
		if (keys[VK_NUMPAD3])
		{
			keys[VK_NUMPAD1]=FALSE;
			pPlayer.fPos[Y] -= 1.0f;
		}
		// Check Game Stuff
		CheckShot();     // Check The Shots
		CheckAlien();    // Check The Aliens
		CheckObjects(NULL); // Check The Objects
		CheckPlayer();   // Check The Actors
		// Check Planet:
		fPlanetZScale += fPlanetZScaleVelocity*g_lDeltatime/300;
		if(fPlanetZScaleVelocity > 0.0f || (fPlanetZScale > 2.0f && pPlayer.byLives == 3) ||
		  (fPlanetZScale > 1.0f && pPlayer.byLives == 1) ||
		  (fPlanetZScale > 1.5f && pPlayer.byLives == 2) ||
		  (fPlanetZScale > 0.5f && pPlayer.byLives == 0))
		{
			fPlanetZScaleVelocity -= 0.00001f*g_lDeltatime;
			if(fPlanetZScaleVelocity < 0.0f)
				fPlanetZScaleVelocity = 0.0f;
		}
		if(fPlanetZScaleVelocity < 0.0f || (fPlanetZScale < 2.0f && pPlayer.byLives == 3) ||
		  (fPlanetZScale < 1.5f && pPlayer.byLives == 2) ||
		  (fPlanetZScale < 1.0f && pPlayer.byLives == 1) ||
		  (fPlanetZScale < 0.5f && pPlayer.byLives == 0))
		{
			fPlanetZScaleVelocity += 0.00001f*g_lDeltatime;
			if(fPlanetZScaleVelocity > 0.0f)
				fPlanetZScaleVelocity = 0.0f;
		}
		// Check If The Player Has Completed the Level
		for(i = 0; i < MAX_ALIENS; i++)
		{
			if(pAlien[i].bActive && pAlien[i].iType != WALL)
				goto NoneComplete;
		}
		// Yes, The Level Is Complete
		if(!bGameWon)
			byLevel++;
		if(byLevel >= LEVELS)
		{ // The Player Has Won The Game
			if(!bGameWon)
			{
				DSUtil_PlaySound(pBigBossDeadSound, 0);
				bPlayerEnteringHighScore = TRUE;
				byPlayersHScorePlace = -1;
				bGameWon = TRUE;
				pPlayer.bActive = FALSE;
			}
		}
		else
		{ // To The Next
			StartLevel(pLevels[byLevel], FALSE, FALSE);
		}
	NoneComplete:;
	}
	else
	{ // We Are In The Game Intro
		bAnyKeyMessage = ((BOOL) ((g_lNow - g_lProgramStartTime) / 1000)) % 2;
		bShowHighscore = ((BOOL) ((g_lNow - g_lProgramStartTime) / 10000)) % 2;
		// Check Keys
		if (keys[VK_ESCAPE])
		{
			keys[VK_ESCAPE]=FALSE;
			done = TRUE;
			return;
		}
		// Check If The Any KeyIs Pressed :)
		for(i = 0; i < 256; i++)
		{
			if(i == VK_ESCAPE || i == VK_F12)
				continue;
			if(keys[i])
			{ // Start The Game
				StartNewGame();
			}
		}
	}
	// General Rotate Variable
	if(bGameIntro)
		for(i = 0; i < 3; i++)
			fRot[i] += 0.01f*g_lDeltatime;
	else
		for(i = 0; i < 3; i++)
			fRot[i] += 0.05f*g_lDeltatime;
	// Open The Config Dialog
	if (keys[VK_F12])
	{
		keys[VK_F12]=FALSE;
		KillGLWindow();					// Kill Our Current Window
		DialogBox(hInstance, MAKEINTRESOURCE(IDD_CONFIG), NULL, (DLGPROC) ConfigProc);
		// Recreate Our OpenGL Window
		if(!Config.bFullScreen)
		{
			if (!CreateGLWindow(APP_TITLE,Config.iWindowWidth,Config.iWindowHeight,Config.DevMode.dmBitsPerPel,&Config.bFullScreen))
				return;					// Quit If Window Was Not Created
		}
		else
		{
			if (!CreateGLWindow(APP_TITLE,Config.DevMode.dmPelsWidth,Config.DevMode.dmPelsHeight,Config.DevMode.dmBitsPerPel,&Config.bFullScreen))
				return;					// Quit If Window Was Not Created
		}
	}
}

void InitGameStuff(void)
{
	// Game stuff:
	pPlanet = new AS_OBJECT;
	pPlanet->Load("Planet.aso");
	// Shot
	pShot1 = new AS_OBJECT;
	pShot1->Load("Shot1.aso");
	pShot2 = new AS_OBJECT;
	pShot2->Load("Shot2.aso");
	pShot3 = new AS_OBJECT;
	pShot3->Load("Shot3.aso");
	pWormholeShot = new AS_OBJECT;
	pWormholeShot->Load("WormholeShot.aso");	
	// Aliens
	pAlien1 = new AS_OBJECT;
	pAlien1->Load("Alien1.aso");
	pAlien2 = new AS_OBJECT;
	pAlien2->Load("Alien2.aso");
	pAlien3 = new AS_OBJECT;
	pAlien3->Load("Alien3.aso");
	pAlien4 = new AS_OBJECT;
	pAlien4->Load("Alien4.aso");
	pAlien5 = new AS_OBJECT;
	pAlien5->Load("Alien5.aso");
	pBigBoss = new AS_OBJECT;
	pBigBoss->Load("BigBoss.aso");
	// Objects
	pObjectLive = new AS_OBJECT;
	pObjectLive->Load("ObjectLive.aso");
	pObjectWall = new AS_OBJECT;
	pObjectWall->Load("ObjectWall.aso");
	pObjectSingleLaser = new AS_OBJECT;
	pObjectSingleLaser->Load("ObjectSingleLaser.aso");
	pObjectDoubleLaser = new AS_OBJECT;
	pObjectDoubleLaser->Load("ObjectDoubleLaser.aso");
	pObjectPowerIncrease = new AS_OBJECT;
	pObjectPowerIncrease->Load("ObjectPowerIncrease.aso");
	// Player
	pShip = new AS_OBJECT;
	pShip->Load("Ship.aso");
	pWall = new AS_OBJECT;
	pWall->Load("Wall.aso");
	pPower = new AS_OBJECT;
	pPower->Load("Power.aso");
	fXRot = -40.0f;
	fZPos = -126.0f;
	pPlayer.fPos[Y] = -40.0f;
	glGetIntegerv(GL_MAX_LIGHTS, &iMaxLights);
}

void DestroyGameStuff(void)
{
	// Game stuff
	pPlanet->Destroy();
	delete pPlanet;
	// Shot
	pShot1->Destroy();
	delete pShot1;
	pShot2->Destroy();
	delete pShot2;
	pShot3->Destroy();
	delete pShot3;
	pWormholeShot->Destroy();
	delete pWormholeShot;
	// Aliens
	pAlien1->Destroy();
	delete pAlien1;
	pAlien2->Destroy();
	delete pAlien2;
	pAlien3->Destroy();
	delete pAlien3;
	pAlien4->Destroy();
	delete pAlien4;
	pAlien5->Destroy();
	delete pAlien5;
	pBigBoss->Destroy();
	delete pBigBoss;
	// Objects
	pObjectLive->Destroy();
	delete pObjectLive;
	pObjectWall->Destroy();
	delete pObjectWall;
	pObjectSingleLaser->Destroy();
	delete pObjectSingleLaser;
	pObjectDoubleLaser->Destroy();
	delete pObjectDoubleLaser;
	pObjectPowerIncrease->Destroy();
	delete pObjectPowerIncrease;
	// Player
	pShip->Destroy();
	delete pShip;
	pWall->Destroy();
	delete pWall;

	pPower->Destroy();
	delete pPower;
}

HRESULT AddDisplayModeInfo(DEVMODE lpDevMode)
{
	if(lpDevMode.dmBitsPerPel < 16)
		return 1;
	DisplayModeInfo.Number++;
	DisplayModeInfo.pDevMode = (DEVMODE *) realloc(DisplayModeInfo.pDevMode, sizeof(DEVMODE)*DisplayModeInfo.Number);
	if(!DisplayModeInfo.pDevMode)
		return 1;
	CopyMemory(&DisplayModeInfo.pDevMode[DisplayModeInfo.Number-1], &lpDevMode, sizeof(DEVMODE));
	return 0;
}

HRESULT DestroyDisplayModeInfo(void)
{
	if(DisplayModeInfo.pDevMode)
		free(DisplayModeInfo.pDevMode);
	DisplayModeInfo.pDevMode = NULL;
	DisplayModeInfo.Number = 0;
	return 0;
}

HRESULT EnumerateDisplayModeInfos(void)
{
	int i;
	DEVMODE devMode;

	DestroyDisplayModeInfo();
	for(i = 0;;i++) 
	{
		if(!EnumDisplaySettings(NULL, i, &devMode)) 
			break;
		AddDisplayModeInfo(devMode);
	}
    return 0;
}

LRESULT CALLBACK CreditsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
    switch(iMessage)
    {
        case WM_INITDIALOG:
				ShowWindow(hWnd, iCmdShow);
				UpdateWindow(hWnd);
            	SetDlgItemText(hWnd, IDC_CREDITS_VERSION, VERSION);
            	SetDlgItemText(hWnd, IDC_CREDITS_BUILD_DATE, __DATE__);
            	SetDlgItemText(hWnd, IDC_CREDITS_BUILD_TIME, __TIME__);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case IDC_CREDITS_OK:
				OK:
					EndDialog(hWnd, FALSE);
                return TRUE;
            }
        break;

		case WM_CLOSE:
			goto OK;
    }
    return FALSE;
}

LRESULT CALLBACK OpenGLInfoProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
    switch(iMessage)
    {
        case WM_INITDIALOG:
				ShowWindow(hWnd, iCmdShow);
				UpdateWindow(hWnd);
            	SetDlgItemText(hWnd, IDC_OPENGL_VERSION_INFO, (const char *) pbyOpenGLVersion);
            	SetDlgItemText(hWnd, IDC_OPENGL_CHIP_INFO, (const char *) pbyOpenGLChipInfo);
            	SetDlgItemText(hWnd, IDC_OPENGL_RENDERER_INFO, (const char *) pbyOpenGLRendererInfo);
            	SetDlgItemText(hWnd, IDC_OPENGL_EXTENSIONS_INFO, (const char *) pbyOpenGLExtensionInfo);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_OPENGL_OK:
				Cancel:
					EndDialog(hWnd, FALSE);
                return TRUE;
            }
        break;
		
		case WM_CLOSE:
			goto Cancel;
    }
    return FALSE;
}

int WINAPI WinMain(	HINSTANCE	hInstanceT,			// Instance
					HINSTANCE	hPrevInstance,		// Previous Instance
					LPSTR		lpCmdLine,			// Command Line Parameters
					int			nCmdShow)			// Window Show State
{
	MSG		msg;									// Windows Message Structure
	short i;
	LPSTR lpTemp;

	hInstance = hInstanceT;
	iCmdShow = nCmdShow;
	// Check That The Game Runs Only One Time At The Same Time
    hMutex = OpenMutex(SYNCHRONIZE, FALSE, APP_TITLE);
    if(hMutex)
    {
		CloseHandle(hMutex);
		sprintf(byTemp, APP_TITLE" is running twice!!");
		MessageBox(0, byTemp, "Attention", MB_ICONERROR | MB_OK);
		return 1;
    }
    else
        hMutex = CreateMutex(NULL, TRUE, APP_TITLE);
	SetPriorityClass(hInstance, 31);
	SetThreadPriority(hInstance, 31);
	// Find Path Info
	GetModuleFileName(hInstance, ExeName, MAX_PATH);
	_splitpath(ExeName, Drive, Dir, NULL, NULL);
	sprintf(Directory, "%s%s", Drive, Dir);
	SetCurrentDirectory(Directory);
	// Set The Current Config
	_ASConfig = &Config;
	// Initalize The Random Generator
	srand((unsigned) GetTickCount());
	// Check the commando line:
	bMoorhuhnCheat = FALSE;
	bInvulnerableCheat = FALSE;
	bUnlimitedPower = FALSE;
	bAlwaysDouble = FALSE;
	lpTemp = lpCmdLine;
	for(;;)
	{
		if(sscanf(lpTemp, "%s", byTemp) == EOF)
			break;
		// Check the cheats:
		if(!strcmp(byTemp, "-Moorhuhn"))
			bMoorhuhnCheat = TRUE;
		else
		if(!strcmp(byTemp, "-invulnerable"))
			bInvulnerableCheat = TRUE;
		else
		if(!strcmp(byTemp, "-unlimited_power"))
			bUnlimitedPower = TRUE;
		else
		if(!strcmp(byTemp, "-always_double"))
			bAlwaysDouble = TRUE;
		else
		if(!strcmp(byTemp, "-Level1"))
			byStartLevel = 0;
		else
		if(!strcmp(byTemp, "-Level2"))
			byStartLevel = 1;
		else
		if(!strcmp(byTemp, "-Level3"))
			byStartLevel = 2;
		else
		if(!strcmp(byTemp, "-Level4"))
			byStartLevel = 3;
		else
		if(!strcmp(byTemp, "-Level5"))
			byStartLevel = 4;
		else
		if(!strcmp(byTemp, "-Level6"))
			byStartLevel = 5;
		else
		if(!strcmp(byTemp, "-Level7"))
			byStartLevel = 6;
		else
		if(!strcmp(byTemp, "-Level8"))
			byStartLevel = 7;
		else
		if(!strcmp(byTemp, "-Level9"))
			byStartLevel = 8;
		else
		if(!strcmp(byTemp, "-Level10"))
			byStartLevel = 9;
		else
		if(!strcmp(byTemp, "-Level11"))
			byStartLevel = 10;
		else
		if(!strcmp(byTemp, "-Level12"))
			byStartLevel = 11;
		else
		if(!strcmp(byTemp, "-Level13"))
			byStartLevel = 12;
		else
		if(!strcmp(byTemp, "-Level14"))
			byStartLevel = 13;
		else
		if(!strcmp(byTemp, "-Level15"))
			byStartLevel = 14;
		else
		if(!strcmp(byTemp, "-Level16"))
			byStartLevel = 15;
		if(*(lpTemp+strlen(byTemp)) == 0)
			break;
		lpTemp += strlen(byTemp)+1;
	}
	// Are We In The Easter Egg Modus?
	if(bMoorhuhnCheat)
	{ // Yep
		MessageBox(NULL,"You Play Now In The Moorhuhn Modus!", "Easter Egg",MB_OK|MB_ICONQUESTION);
		LEVELS = EASTER_EGG_LEVELS;
		for(i = 0; i < LEVELS; i++)
			pLevels[i] = pEasterEggLevels[i];
	}
	else
	{ // Nope
		LEVELS = NORMAL_LEVELS;
		for(i = 0; i < LEVELS; i++)
			pLevels[i] = pNormalLevels[i];
	}
	if(byStartLevel > LEVELS-1)
		byStartLevel = 0;
	// Enumerate The Number Of Display Modes
	EnumerateDisplayModeInfos();
	Config.bFullScreen = 0;
	// Create A Standart Window First To Get The OpenGL Information
	bProgramStart = TRUE;
	if (!CreateGLWindow(APP_TITLE,200,1,16,&Config.bFullScreen))
		return 0;					// Quit If Window Was Not Created
	KillGLWindow();					// Kill Our Current Window
	// Load Configurations
	sprintf(byTemp, "%s%s", Directory, "Config.ini");
	Config.Load(byTemp);
	// Load The Highscore
	LoadHighScores("Highscore.dat");
	// Is This The First Program Start?
	if(!strcmp(lpCmdLine, "Config") || Config.bFirstRun)
	{ // Open The Config Dialog
		MessageBox(NULL, "This is the first program start please check the setup.\n",
				   APP_TITLE, MB_OK | MB_ICONINFORMATION);
		DialogBox(hInstance, MAKEINTRESOURCE(IDD_CONFIG), NULL, (DLGPROC) ConfigProc);
	}
	Config.bFirstRun = FALSE;
	// Is An Error Detected?
	if(Config.bError)
	{ // Open The Config Dialog
		MessageBox(NULL, "The program wasn't correctly shut down on the last run!\n",
				   "Info", MB_OK | MB_ICONINFORMATION);
		DialogBox(hInstance, MAKEINTRESOURCE(IDD_CONFIG), NULL, (DLGPROC) ConfigProc);
	}
	InitGameStuff();
	// Create Our OpenGL Window
	if(!Config.bFullScreen)
	{
		if (!CreateGLWindow(APP_TITLE,Config.iWindowWidth,Config.iWindowHeight,Config.DevMode.dmBitsPerPel,&Config.bFullScreen))
			return 0;					// Quit If Window Was Not Created
	}
	else
	{
		if (!CreateGLWindow(APP_TITLE,Config.DevMode.dmPelsWidth,Config.DevMode.dmPelsHeight,Config.DevMode.dmBitsPerPel,&Config.bFullScreen))
			return 0;					// Quit If Window Was Not Created
	}
	// Init Timekeeping Variables
	g_lProgramStartTime = GetTickCount();
	g_lNow = GetTickCount();
	bProgramStart = FALSE;
	Config.bError = TRUE;							// Maybe There Will Happen A Error
	InitGameIntro();
	while(!done)									// Loop That Runs While done=FALSE
	{
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE))	// Is There A Message Waiting?
		{
			if (msg.message==WM_QUIT)				// Have We Received A Quit Message?
			{
				done=TRUE;							// If So done=TRUE
			}
			else									// If Not, Deal With Window Messages
			{
				TranslateMessage(&msg);				// Translate The Message
				DispatchMessage(&msg);				// Dispatch The Message
			}
		}
		else										// If There Are No Messages
		{
			// Draw The Scene.  Watch For ESC Key And Quit Messages From DrawGLScene()
			if ((active && !DrawGLScene()))	// Active?  Was There A Quit Received?
				done=TRUE;							// ESC or DrawGLScene Signalled A Quit
			else									// Not Time To Quit, Update Screen
			{
				CheckScene();							// Check The Game Scene
			}
		}
	}
	DestroyGameStuff();
	// Shutdown
	KillGLWindow();									// Kill The Window
	// Destroy DirectXSound
	DSUtil_FreeDirectSound();
	Config.bError = FALSE;							// There Was No Error
	// Save The Highscore
	SaveHighScores("Highscore.dat");
	// Save Config
	sprintf(byTemp, "%s%s", Directory, "Config.ini");
	Config.Save(byTemp);
	// Destroy The Display Modes Info
	DestroyDisplayModeInfo();
	// Delete OpenGL Information
	if(pbyOpenGLVersion)
		delete pbyOpenGLVersion;
	// Chip Info
	if(pbyOpenGLChipInfo)
		delete pbyOpenGLChipInfo;
	// Renderer Info
	if(pbyOpenGLRendererInfo)
		delete pbyOpenGLRendererInfo;
	// Extensions Info
	if(pbyOpenGLExtensionInfo)
		delete pbyOpenGLExtensionInfo;
	// That Was All Folks!
	return (msg.wParam);							// Exit The Program
}
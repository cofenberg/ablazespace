//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDD_OPENGL                      102
#define IDD_CONFIG                      105
#define IDD_CREDITS                     109
#define IDI_INVASION                    111
#define IDC_CONFIG_MODES                113
#define IDC_OPENGL_CHIP                 1000
#define IDC_HOMEPAGE                    1000
#define IDC_OPENGL_RENDERER             1001
#define IDC_NEHE_HOMEPAGE               1001
#define IDC_OPENGL_VERSION              1002
#define IDC_BLENDER_HOMEPAGE            1002
#define IDC_CONFIG_MUSIC                1003
#define IDC_OPENGL_VERSION_INFO         1004
#define IDC_CONFIG_SOUND                1004
#define IDC_OPENGL_CHIP_INFO            1005
#define IDC_CONFIG_DRAW_BOUNDING        1005
#define IDC_OPENGL_RENDERER_INFO        1006
#define IDC_CONFIG_SHOW_FPS             1006
#define IDC_OPENGL_EXTENSIONS           1007
#define IDC_OPENGL_EXTENSIONS_INFO      1008
#define ID_OPENGL_OK                    1009
#define ID_CONFIG_OK                    1014
#define ID_CONFIG_CANCEL                1015
#define IDC_CREDITS_BUILD_DATE          1016
#define IDC_CREDITS_BUILD_TIME          1017
#define IDC_CREDITS_OK                  1018
#define IDC_CREDITS_VERSION             1019
#define IDC_CONFIG_CREDITS              1021
#define IDC_CONFIG_OPENGL               1022
#define IDC_INVASION_HELP               1023
#define IDC_CONFIG_FULLSCREEN           1033
#define IDC_CONFIG_COLOR_DEPTH          1034
#define IDC_TEXT                        1058
#define IDC_CONFIG_LIGHT_NONE           1101
#define IDC_CONFIG_LIGHT_FLAT           1102
#define IDC_CONFIG_LIGHT_SMOOTH         1103

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        154
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

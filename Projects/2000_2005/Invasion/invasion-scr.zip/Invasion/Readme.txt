The "Intel Jpeg Library" to load JPEG files could be found at the Intel homepage. (www.intel.com)
You will need the headers to compile the program.
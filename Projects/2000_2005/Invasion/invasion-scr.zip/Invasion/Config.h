#ifndef __CONFIG_H__
#define __CONFIG_H__


// Structures: ****************************************************************
typedef struct
{
	int Number;
	DEVMODE *pDevMode;
} DISPLAY_MODE_INFO;
///////////////////////////////////////////////////////////////////////////////
// Classes: *******************************************************************
typedef class
{
	public:
		BOOL bFirstRun;
		BOOL bError;
		BOOL bFullScreen;
		BOOL bSound;
		BOOL bMusic;
		BOOL bDrawBounding;
		BOOL bShowFPS;
		DWORD dwMode;
		char byLight; // 0 = none, 1 = flat, 2 = smooth
		int iColorDepthFilter;
		int iWindowWidth, iWindowHeight;
		int iModeIndex; 
		DEVMODE DevMode;
		int iScreenPixels, iScreenSize;

		void Check(void);
        HRESULT Load(char *);
	    HRESULT Save(char *);
} AS_CONFIG;
///////////////////////////////////////////////////////////////////////////////
// Variables: *****************************************************************
extern AS_CONFIG *_ASConfig;
extern DISPLAY_MODE_INFO DisplayModeInfo;
///////////////////////////////////////////////////////////////////////////////
// Functions: *****************************************************************
extern LRESULT CALLBACK ConfigProc(HWND, UINT, WPARAM, LPARAM);
///////////////////////////////////////////////////////////////////////////////


#endif // __CONFIG_H__
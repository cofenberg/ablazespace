#ifndef INVASION
#define INVASION


#include <windows.h>		// Header File For Windows
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <dsound.h>
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library
#include <ijl.h>


enum {X, Y, Z};
#define ASO_FILE "Object files (*.aso)\0*.aso\0"

#define SubtVer(AB, a, b)\
	((AB)[X] = (b)[X]-(a)[X],\
     (AB)[Y] = (b)[Y]-(a)[Y],\
     (AB)[Z] = (b)[Z]-(a)[Z])
#define CrossProductVer(AB, a, b)\
	((AB)[X] = (a)[Y]*(b)[Z]-(a)[Z]*(b)[Y],\
     (AB)[Y] = (a)[Z]*(b)[X]-(a)[X]*(b)[Z],\
     (AB)[Z] = (a)[X]*(b)[Y]-(a)[Y]*(b)[X])
#define glEnableLighting() if(_ASConfig->byLight != 0) { glEnable(GL_LIGHTING); }

typedef float FLOAT3[3];
typedef float FLOAT2[2];
typedef int INT3[3];
typedef int SHORT3[3];
typedef float MATRIX[4][4];


extern void NormalizeFace(FLOAT3 *, FLOAT3, FLOAT3, FLOAT3);
extern LRESULT CALLBACK CreditsProc(HWND, UINT, WPARAM, LPARAM);
extern HRESULT CALLBACK OpenGLInfoProc(HWND, UINT, WPARAM, LPARAM);

#include "resource.h"		// The Resource Stuff
#include "AS_Object.h"
#include "DSound.h"
#include "Config.h"

extern HINSTANCE hInstance;
extern int iCmdShow;
extern char LEVELS;
#define NORMAL_LEVELS 16
#define EASTER_EGG_LEVELS 11

#define MAX_HIGHSCORES 10

#define PLAYER 0
#define ALIEN_1 1
#define ALIEN_2 2
#define ALIEN_3 3
#define ALIEN_4 4
#define ALIEN_5 5
#define BIG_BOSS 6
#define WALL 7
#define PLAYER_SHOT 8
#define ALIEN_SHOT 9
#define ALIEN_5_SHOT 10
#define WORMHOLE_SHOT 11
#define OBJECT_LIVE 12
#define OBJECT_WALL 13
#define OBJECT_SINGLE_LASER_WEAPON 14
#define OBJECT_DOUBLE_LASER_WEAPON 15
#define OBJECT_POWER_INCREASE 16

#define SINGLE_LASER_WEAPON 0
#define DOUBLE_LASER_WEAPON 1

#define MAX_ALIEN_ROW 15
#define MAX_ALIEN_COLUMN 10
#define MAX_ALIENS 161
#define MAX_OBJECTS 10
#define MAX_SHOTS 200
#define SPACE_WIDTH 100.0f
#define SPACE_HEIGHT 100.0f
#define SPACE_HALF_WIDTH 50.0f
#define SPACE_HALF_HEIGHT 50.0f
#define WORMHOLE_ANIS 10

#define ALIEN_1_POINTS 10
#define ALIEN_2_POINTS 15
#define ALIEN_3_POINTS 30
#define ALIEN_4_POINTS 45
#define ALIEN_5_POINTS 100
#define BIG_BOSS_POINTS 10000

#define O_LIVE_POINTS 100
#define O_WALL_POINTS 20
#define O_SINGLE_LASER_POINTS 30
#define O_DOUBLE_LASER_POINTS 40
#define O_POWER_INCREASE_POINTS 500

#define PLAYER_GHOST_TIME 3000
#define MAX_PLAYER_POWER 70.0f
#define SINGLE_SHOT_POWER 10.0f
#define DOUBLE_SHOT_POWER 10.0f
#define SHIELD_POWER 0.5f

typedef class ACTOR
{
	public:
		float fPos[2];
		float fPos2[2];
		float fRot[3];

		float fPosVelocity[2];
		float fRotVelocity[2];
		float fPos2Velocity[2];
		short iType;
		BOOL bActive;
		short iExplosionStep;
		DWORD lStartTime;
		char byLives;
		AS_OBJECT_FRAME *pFrameT;
		short iAnimationT;
		short iStepT;
		DWORD dwLastTime;
		short iTemp;
		float fPower, fMaxPower;

		BOOL bGhost;
		BOOL bShield;
		BOOL bAttack;

		ACTOR(void);
		~ACTOR(void);

} ACTOR;

typedef struct LEVEL
{
	char byName[256];
	char byXStart, byYStart;
	short iAlien1Random, iAlien2Random, iAlien3Random, iAlien4Random, iAlien5Random;
	float fXStartVelocity, fYStartVelocity;
	float fXSpeedIncrease;
	float fYSpeedDecrease;
	char byAliens[MAX_ALIEN_ROW][MAX_ALIEN_COLUMN];
	short iObjectLiveRandom, iObjectWallRandom, iObjectSingleLaserRandom, 
		  iObjectDoubleLaserRandom, iObjectPowerIncreaseRandom;
} LEVEL;


#endif // INVASION
Convey-Demo


New Level:
Name: The great escape
Author: Christian Ofenberg
Homepage: http://ablazespace.exit.de/
E-Mail: AblazeSpace@web.de


Installation:
Copy the lev-file into into your Convey folder under 'Data\SingleLevels\'.
Now start the game and select the new level under the option 'Single level'.


Description:
As you walk through the road you fall somewhere down.
After your awaking you are in a prison, you don't now why...
try to escape from this dark place!
Convey - Second demo               May 24, 2001 


- The Concey level editor is not available in the demo
- No sound effects included
- If there's a publisher that wants to banish Convey commercial, please contact me



Christian Ofenberg
AblazeSpace

Homapage: www.ablazespace.de
E-Mail: mail@AblazeSpace.de
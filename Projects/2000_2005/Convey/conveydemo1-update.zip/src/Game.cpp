//-----------------------------------------------------------------------------
// File: Game.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


#define GAME_LEVELS 5

// Variables: *****************************************************************
int GAME_WINDOW_ID;
short iLevelCompleteSpeed, iPauseBlendSpeed;
ACTOR DisplayActor[DISPLAY_ACTORS];
ACTOR PlayerTemp;
ACTOR DeadSmileyActor;
ACTOR OktaActor;
AS_TEXTURE GameTexture[GAME_TEXTURES];	// The game textures
AS_TEXTURE GameTitleTexture[4];			// The game titel texture
char byCurrentLevelName[256];			// The name of the current level
char bySelectedSingleLevel[256];		// The name of the selected single player level
LEVEL *pLevel;							// The 'main' level
BOOL bSingleLevel,						// Are we playing an single level?
	 bPlayerCameraView;					// Are we in the ego-shooter camera perspective??
AS_MD2_MODEL *pXeModel, *pXeWeaponModel, *pDeadSmileyModel, *pOktaModel;
AS_MD2_MODEL **pModels[] = {&pXeModel, &pXeWeaponModel, &pDeadSmileyModel, &pOktaModel};
AS_OBJECT *pHealthObject, *pLiveObject, *pPullObject, *pThrowObject,
	   	   *pForceObject, *pPointObject, *pGhostObject, *pPlayerShot,
		   *pTimeObject, *pStepsObject, *pSpeedObject, *pWingObject,
		   *pShieldObject, *pJumpObject, *pAirObject;
AS_OBJECT **pObjects[] = {&pHealthObject, &pLiveObject, &pPullObject,
						  &pThrowObject, &pForceObject, &pPointObject,
						  &pGhostObject, &pPlayerShot, &pTimeObject,
						  &pStepsObject, &pSpeedObject, &pWingObject,
						  &pShieldObject, &pJumpObject, &pAirObject};
float fSin, fSin90, fCos, fCos90, fCameraVelocity = 1.0f, fPauseBlend,
	  fPauseTextBlend;
BOOL bPause, bPauseTextBlend, bLevelPressAnyKey, bHurryUpText;
long lGameTimer, lPauseTimer, lLevelCompleteTimer, lKeyTimer, lCameraTimerT, lHurryUpTimer,
     lCameraPauseTimerT;
long lGhostTimeSave, lSpeedTimeSave, lWingTimeSave, lShieldTimeSave;
AS_CAMERA TempCamera;
// OpenGL lists:
GLuint iGameTitleList, iWaveList, iShieldList, iHealthObjList, iLiveObjList, iPullObjList,
	   iThrowObjList, iForceObjList, iPointObjList, iGhostObjList, iPlayerShotObjList,
	   iTimeObjList, iStepsObjList, iSpeedObjList, iWingObjList, iShieldObjList,
	   iJumpObjList, iAirObjList;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
HRESULT Game(void);
HRESULT GameLoop(void);
HRESULT GameDraw(AS_WINDOW *);
HRESULT GameCheck(AS_WINDOW *);
void LoadGameTextures(void);
void DestroyGameTextures(void);
void GenOpenGLGameTextures(void);
void DestroyOpenGLGameTextures(void);
void UpdateAllTextures(void);
void UpdateRenderQuality(void);
void CreateGameLists(void);
void DestroyGameLists(void);
void InitGameObjects(void);
void DestroyGameObjects(void);
void CalculateCamersSinCos(void);
void CheckCameraKeys(BOOL);
BOOL PlayCameraScript(BOOL);
void SetCameraTranslation(BOOL);
void StartLevel(char *);
void StartCurrentLevel(void);
void StartLevelMusic(void);
void DestroyLevel(void);
void InitDisplayActors(void);
void OpenHelp(void);
///////////////////////////////////////////////////////////////////////////////


HRESULT Game(void)
{ // begin Game()
	MSG msg;

	_AS->WriteLogMessage("Enter game module");

	// Create the game window and create the DirectInput stuff:
	_AS->ASCreateWindow(WindowProc, GAME_WINDOW_NAME, GAME_WINDOW_NAME, _ASConfig->iWindowWidth,
					    _ASConfig->iWindowHeight, LoadMenu(_AS->GetInstance(), MAKEINTRESOURCE(IDR_GAME)),
						_ASConfig->bFullScreen, GameMenuDraw, GameMenuCheck, NULL, FALSE, TRUE);
	GAME_WINDOW_ID = _AS->GetWindows()-1;
	ASInitOpenGL(&_AS->pWindow[GAME_WINDOW_ID],
				 NULL,
				 _AS->pWindow[GAME_WINDOW_ID].GethDC(),
				 _AS->pWindow[GAME_WINDOW_ID].GethRC(), _ASConfig->bFullScreen);
	_AS->CreateDXInputDevices(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), FALSE, TRUE, TRUE, FALSE);
	_AS->CreateDXAudio(*_AS->pWindow[GAME_WINDOW_ID].GethWnd());
	ShowWindow(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), SW_SHOW);	


	// Load and create the game objects and textures:
	InitGameObjects();
	LoadGameTextures();
	GenOpenGLGameTextures();

	if(!bEditorTestLevel)
		bInGameMenu	= TRUE;
	else
		bInGameMenu = FALSE;

	_AS->WriteLogMessage("Enter game main loop");
	for(;;)
	{
		if(bInGameMenu)
		{ // We are in the game menu:
			msg.wParam = GameMenuLoop();
			_AS->StopMusic();
		}
		else
		{ // We are in the game:
			msg.wParam = GameLoop();
			if(bEditorTestLevel)
				_AS->SetNextModule(MODULE_EDITOR);
			_AS->StopMusic();
		}
		if(_AS->GetShutDown() || _AS->CheckModuleChange())
			break;
	}
	_AS->WriteLogMessage("Left game main loop");

	DestroyCampaign(&CurrentCampaign);
	DestroyGameObjects();
	DestroyGameTextures();
	DestroyOpenGLGameTextures();
	
	// Destroy the game window and the corresponding DirectInput stuff:
	_AS->FreeDXInputDevices();
	_AS->DestroyDXAudio();

	ASDestroyOpenGL(&_AS->pWindow[GAME_WINDOW_ID],
					NULL,
				    *_AS->pWindow[GAME_WINDOW_ID].GethDC(),
				    *_AS->pWindow[GAME_WINDOW_ID].GethRC());
	_AS->ASDestroyWindow(_AS->pWindow[GAME_WINDOW_ID].GethWnd(), GAME_WINDOW_NAME);
	// Left the game module:
	return msg.wParam;
} // end Game()

HRESULT GameLoop(void)
{ // begin GameLoop()
	char byTemp[256];
	MSG msg;
	short i;

	_AS->pWindow[GAME_WINDOW_ID].SetDrawFunction(GameDraw);
	_AS->pWindow[GAME_WINDOW_ID].SetCheckFunction(GameCheck);

	StartCurrentLevel();	

	lKeyTimer = g_lNow;

	// Go into the game loop:
	_AS->WriteLogMessage("Enter the game loop");
	for(;;)
	{
		if(PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
    	{
        	if(!GetMessage(&msg, NULL, 0, 0))
                break;
        	TranslateMessage(&msg);
        	DispatchMessage(&msg);
    	}
		else
		{	
			if(_AS->GetShutDown() || _AS->CheckModuleChange() || bInGameMenu)
				PostQuitMessage(0);
			if(!_AS->GetActive())
			{
				pPlayer->dwAniTime = g_lNow;
				for(i = 0; i < MAX_ACTORS; i++)
					Actor[i].dwAniTime = g_lNow;
				continue;
			}
			_AS->UpdateWindows();
		}
	}
	_AS->WriteLogMessage("Left the game loop");
	DestroyLevel();
	// Save the configuration:	
	sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyConfigFile);
	_ASConfig->Save(byTemp);
	
	if(!bSingleLevel) // Save the player identity:
		SavePlayerIdentity(&PlayerIdentity, &CurrentCampaign);
	return msg.wParam;
} // end GameLoop()

HRESULT GameDraw(AS_WINDOW *pWindow)
{ // begin GameDraw()
	char byTemp[256];
	short i;
	float fBlend, f;

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	SetCameraTranslation(TRUE);
	pLevel->DrawSkyCube();
	pLevel->InitLevelDraw();
	ASEnableLighting();

	// Draw the level:
	glEnable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);
	
	SetCameraTranslation(FALSE);
	ASExtractFrustum();

	SetActorsLights();

	glColor3f(1.0f, 1.0f, 1.0f);
	pLevel->Draw(0);

	DrawActors();
	DrawPlayer();
	DrawEffects();

	// Draw the water:
	SetCameraTranslation(FALSE);
	pLevel->DrawWater();
	
	if(pPlayer->bGoingDeath)
	{ // Show the live symbol:
	    GLfloat	fogColor[4] = {0.0f, 0.0f, 0.0f, 1.0f};
		
		glClear(GL_DEPTH_BUFFER_BIT);
		glEnable(GL_FOG);
		glFogfv(GL_FOG_COLOR, fogColor);
		glFogf(GL_FOG_DENSITY, 0.054f);
		glFogf(GL_FOG_START, 0.0f);
		glFogf(GL_FOG_END, 10.0f);
		glEnable(GL_TEXTURE_2D);
		glLoadIdentity();
		glTranslatef(0.0f, 0.0f, -20.0f);
		AnimateActorModel(&DeadSmileyActor, *pDeadSmileyModel, 150, 9);
		glEnable(GL_TEXTURE_2D);
		glCullFace(GL_FRONT);
		glBindTexture(GL_TEXTURE_2D, GameTexture[9].iOpenGLID);
		f = ((float) (g_lNow-pPlayer->lStartTime)/PLAYER_DEAD_FLOOR_TIME);
		glScalef(f, f, f);
		glRotatef(-90.0f, 0.0f, 1.0f, 0.0f);
		glColor4f(1.0f, 1.0f, 1.0f, 1.0f-f);
		ASDrawMd2FrameInt(pDeadSmileyModel, DeadSmileyActor.iAniStep, DeadSmileyActor.iNextAniStep, (float) (g_lNow-DeadSmileyActor.dwAniTime)/(float) 150);
		glCullFace(GL_BACK);
		pLevel->InitLevelDraw();
	}

	glDisable(GL_LIGHTING);
	if(fPauseBlend != 0.0f)
	{ // Draw the game title:
		glClear(GL_DEPTH_BUFFER_BIT);
		glEnable(GL_BLEND);
		glDisable(GL_TEXTURE_2D);
		glBlendFunc(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);
		glColor4f(0.1f, 0.1f, 0.1f, 1.0f-fPauseBlend+0.2f);
		glDisable(GL_CULL_FACE);
		glLoadIdentity();
		glTranslatef(0.0f, 0.0f, -34.0f);
		glBegin(GL_QUADS);
			glNormal3f(0.0f, 0.0f, 1.0f);
			glVertex3f(-15.0f, -11.0f, 10.0f);
			glVertex3f( 15.0f, -11.0f, 10.0f);
			glVertex3f( 15.0f,  11.0f, 10.0f);
			glVertex3f(-15.0f,  11.0f, 10.0f);
		glEnd();
		glEnable(GL_CULL_FACE);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);

		glDisable(GL_FOG);
		glEnable(GL_TEXTURE_2D);
		glDisable(GL_DEPTH_TEST);
		glColor4f(1.0f, 1.0f, 1.0f, fPauseBlend);
		glLoadIdentity();
		glTranslatef(-1.0f, 0.7f, -1.8f);
		glCallList(iGameTitleList);
		glEnable(GL_DEPTH_TEST);
		if(bLevelComplete)
		{ // Draw the 'dancing' alien:
			glCullFace(GL_FRONT);
			glLoadIdentity();
			if(fPauseBlend == 1.0f)
				glDisable(GL_BLEND);
			glTranslatef(0.0f, 0.0f, -20.0f);
			glRotatef(-90.0f, 0.0f, 1.0f, 0.0f);
			glScalef(0.1f, 0.1f, 0.1f);
			glBindTexture(GL_TEXTURE_2D, GameTexture[4].iOpenGLID);
			ASDrawMd2FrameInt(pXeModel, PlayerTemp.iAniStep, PlayerTemp.iNextAniStep, (float) (g_lNow-PlayerTemp.dwAniTime)/(float) PLAYER_ANIMATION_SPEED);
			glCullFace(GL_BACK);
		}
		glEnable(GL_BLEND);
		ShowMissionState(pWindow);
		glDisable(GL_BLEND);
	}

	if(pPlayer->fAir != 1.0f && fPauseBlend != 1.0f && !pPlayer->bGoingDeath)
	{ // Show the players air:
		if(fPauseBlend != 0.0f)
			glEnable(GL_BLEND);
		else
			glDisable(GL_BLEND);
		glLoadIdentity();
		glDisable(GL_TEXTURE_2D);
		glDisable(GL_DEPTH_TEST);
		glTranslatef(-.5f, -0.7f, -2.0f);
		glColor4f(0.0f, 0.0f, 0.0f, 1.0f-fPauseBlend);
		glBegin(GL_QUADS);
			glNormal3f(0.0f, 0.0f, 1.0f);

			glVertex3f(-0.01f, -0.01f, 0.0f);
			glVertex3f(1.0f*pPlayer->fAir+0.11f, -0.01f, 0.0f);
			glVertex3f(1.0f*pPlayer->fAir+0.11f, 0.06f, 0.0f);
			glVertex3f(-0.01f, 0.06f, 0.0f);
		glEnd();
		glColor4f(1.0f-pPlayer->fAir, 0.0f, pPlayer->fAir, 1.0f-fPauseBlend);
		glBegin(GL_QUADS);
			glNormal3f(0.0f, 0.0f, 1.0f);

			glVertex3f(0.0f, 0.0f, 0.0f);
			glVertex3f(1.0f*pPlayer->fAir+0.1f, 0.0f, 0.0f);
			glVertex3f(1.0f*pPlayer->fAir+0.1f, 0.05f, 0.0f);
			glVertex3f(0.0f, 0.05f, 0.0f);
		glEnd();
		glEnable(GL_TEXTURE_2D);
		glEnable(GL_DEPTH_TEST);
		glEnable(GL_BLEND);
	}

	if(bCameraAnimation && (pLevel->pCurrentCameraScript == &pLevel->pCameraScript[pLevel->iStartCamera]))
	{
	}
	else
	if(fPauseBlend != 1.0f || bLevelComplete)
	{ // Display player info:	
		glEnable(GL_TEXTURE_2D);
		glEnable(GL_BLEND);
		glDisable(GL_FOG);
		glClear(GL_DEPTH_BUFFER_BIT);
		if(!bLevelComplete)
			fBlend = 1.0f-fPauseBlend;
		else
			fBlend = 1.0f;
		// Display the texts:
		glColor4f(1.0f, 1.0f, 1.0f, fBlend);
		// Lives:
		sprintf(byTemp, "* %d", PlayerInfo.iLives);
		pWindow->glPrint(60, 425, byTemp, 0);
		// Health:
		if(pPlayer->fPower <= 20.0f)
			glColor4f(1.0f, 0.0f, 0.0f, fBlend);
		sprintf(byTemp, "* %0.0f", pPlayer->fPower);
		pWindow->glPrint(60, 385, byTemp, 0);
		glColor4f(1.0f, 1.0f, 1.0f, fBlend);
		// Points:
		sprintf(byTemp, "* %d", PlayerInfo.iPoints);
		pWindow->glPrint(60, 345, byTemp, 0);

		// Display this stuff if it is available:
		// Force:
		if(PlayerInfo.iForce != 1)
		{
			if(!pLevel->bUnlimitedForce)
			{
				sprintf(byTemp, "* %d", PlayerInfo.iForce);
				pWindow->glPrint(60, 235, byTemp, 0);
			}
			DisplayActor[FORCE_DISPLAY].bActive = TRUE;
		}
		else
			DisplayActor[FORCE_DISPLAY].bActive = FALSE;
		// Throw:
		if(PlayerInfo.bThrowBoxes)
		{
			if(!pLevel->bUnlimitedThrow)
			{
				sprintf(byTemp, "* %d", PlayerInfo.iThrowBoxes);
				pWindow->glPrint(60, 195, byTemp, 0);
			}
			DisplayActor[THROW_DISPLAY].bActive = TRUE;
		}
		else
			DisplayActor[THROW_DISPLAY].bActive = FALSE;
		// Weapon:
		if(PlayerInfo.bWeapon)
		{
			if(!pLevel->bUnlimitedWeapon)
			{
				sprintf(byTemp, "* %d", PlayerInfo.iWeaponShots);
				pWindow->glPrint(60, 155, byTemp, 0);
			}
			DisplayActor[WEAPON_DISPLAY].bActive = TRUE;
		}
		else
			DisplayActor[WEAPON_DISPLAY].bActive = FALSE;
		// Pull:
		if(PlayerInfo.bPullBoxes)
		{
			if(!pLevel->bUnlimitedPull)
			{
				sprintf(byTemp, "* %d", PlayerInfo.iPullBoxes);
				pWindow->glPrint(60, 115, byTemp, 0);
			}
			DisplayActor[PULL_DISPLAY].bActive = TRUE;
		}
		else
			DisplayActor[PULL_DISPLAY].bActive = FALSE;
		// Ghost:
		if(PlayerInfo.bGhost)
		{
			if(GHOST_TIME-(g_lNow-PlayerInfo.lGhostTime) <= 0)
				glColor4f(1.0f, 0.0f, 0.0f, fBlend);
			sprintf(byTemp, "* %d", GHOST_TIME-(g_lNow-PlayerInfo.lGhostTime));
			pWindow->glPrint(60, 75, byTemp, 0);
			DisplayActor[GHOST_DISPLAY].bActive = TRUE;
		}
		else
			DisplayActor[GHOST_DISPLAY].bActive = FALSE;
		// Speed:
		if(PlayerInfo.bSpeed)
		{
			if(SPEED_TIME-(g_lNow-PlayerInfo.lSpeedTime) <= 0)
				glColor4f(1.0f, 0.0f, 0.0f, fBlend);
			sprintf(byTemp, "* %d", SPEED_TIME-(g_lNow-PlayerInfo.lSpeedTime));
			pWindow->glPrint(60, 35, byTemp, 0);
			DisplayActor[SPEED_DISPLAY].bActive = TRUE;
		}
		else
			DisplayActor[SPEED_DISPLAY].bActive = FALSE;
		glColor4f(1.0f, 1.0f, 1.0f, fBlend);
		// Wing:
		if(PlayerInfo.bWing)
		{
			if(WING_TIME-(g_lNow-PlayerInfo.lWingTime) <= 0)
				glColor4f(1.0f, 0.0f, 0.0f, fBlend);
			sprintf(byTemp, "* %d", WING_TIME-(g_lNow-PlayerInfo.lWingTime));
			pWindow->glPrint(550, 230, byTemp, 0);
			DisplayActor[WING_DISPLAY].bActive = TRUE;
		}
		else
			DisplayActor[WING_DISPLAY].bActive = FALSE;
		glColor4f(1.0f, 1.0f, 1.0f, fBlend);
		// Shield:
		if(PlayerInfo.bShield)
		{
			if(SHIELD_TIME-(g_lNow-PlayerInfo.lShieldTime) <= 0)
				glColor4f(1.0f, 0.0f, 0.0f, fBlend);
			sprintf(byTemp, "* %d", SHIELD_TIME-(g_lNow-PlayerInfo.lShieldTime));
			pWindow->glPrint(550, 195, byTemp, 0);
			DisplayActor[SHIELD_DISPLAY].bActive = TRUE;
		}
		else
			DisplayActor[SHIELD_DISPLAY].bActive = FALSE;
		// Jump:
		if(PlayerInfo.bJump)
		{
			if(!pLevel->bUnlimitedJump)
			{
				sprintf(byTemp, "* %d", PlayerInfo.iJump);
				pWindow->glPrint(550, 160, byTemp, 0);
			}
			DisplayActor[JUMP_DISPLAY].bActive = TRUE;
		}
		else
			DisplayActor[JUMP_DISPLAY].bActive = FALSE;
		glColor4f(1.0f, 1.0f, 1.0f, fBlend);
		if((bLevelComplete && pLevel->iTimeLimit) || !bLevelComplete)
		{ // Time:
			if(pLevel->bTimeLimit && pLevel->iTimeLimit < 10)
				glColor4f(1.0f, 0.0f, 0.0f, fBlend);
			sprintf(byTemp, "* %d", pLevel->iTimeLimit);
			pWindow->glPrint(550, 425, byTemp, 0);
		}
		else
			DisplayActor[TIME_DISPLAY].bActive = FALSE;
		glColor4f(1.0f, 1.0f, 1.0f, fBlend);
		if((bLevelComplete && pLevel->iStepsLimit) || !bLevelComplete)
		{ // Steps:
			if(pLevel->bStepsLimit && pLevel->iStepsLimit < 10)
				glColor4f(1.0f, 0.0f, 0.0f, fBlend);
			sprintf(byTemp, "* %d", pLevel->iStepsLimit);
			pWindow->glPrint(550, 385, byTemp, 0);
		}
		else
			DisplayActor[STEPS_DISPLAY].bActive = FALSE;
		// Draw the symbol:
		glColor4f(1.0f, 1.0f, 1.0f, fBlend);
		for(i = 0; i < DISPLAY_ACTORS; i++)
		{
			if(!DisplayActor[i].bActive)
				continue;
			glLoadIdentity();
			glTranslatef(DisplayActor[i].fWorldPos[X], DisplayActor[i].fWorldPos[Y], DisplayActor[i].fWorldPos[Z]);
			if(i != WEAPON_DISPLAY)
			{
				glRotatef(DisplayActor[i].fRot[X], 1.0f, 0.0f, 0.0f);
				glRotatef(DisplayActor[i].fRot[Y], 0.0f, 1.0f, 0.0f);
				glRotatef(DisplayActor[i].fRot[Z], 0.0f, 0.0f, 1.0f);
			}
			glScalef(DisplayActor[i].fSize*0.2f, DisplayActor[i].fSize*0.2f, DisplayActor[i].fSize*0.2f);
			glBindTexture(GL_TEXTURE_2D, GameTexture[DisplayActor[i].iAniStep].iOpenGLID);
			switch(i)
			{
				case HEALTH_DISPLAY:
					glCallList(iHealthObjList);
				break;

				case LIVE_DISPLAY:
					glCallList(iLiveObjList);
				break;

				case PULL_DISPLAY:
					glCallList(iPullObjList);
				break;

				case THROW_DISPLAY:
					glCallList(iThrowObjList);
				break;

				case FORCE_DISPLAY:
					glCallList(iForceObjList);
				break;

				case WEAPON_DISPLAY:
					glCullFace(GL_FRONT);
					glColor4f(1.0f, 1.0f, 1.0f, fBlend);
					glScalef(0.2f, 0.2f, 0.2f);
					glBindTexture(GL_TEXTURE_2D, GameTexture[6].iOpenGLID);
					ASDrawMd2FrameInt(pXeWeaponModel, DisplayActor[i].iAniStep, DisplayActor[i].iNextAniStep, (float) (g_lNow-DisplayActor[i].dwAniTime)/(float) PLAYER_ANIMATION_SPEED);
					glCullFace(GL_BACK);
				break;

				case POINT_DISPLAY:
					glCallList(iPointObjList);
				break;

				case GHOST_DISPLAY:
					if(GHOST_TIME-(g_lNow-PlayerInfo.lGhostTime) <= 0)
						glScalef(2.0f, 2.0f, 2.0f);
					glCallList(iGhostObjList);
				break;

				case TIME_DISPLAY:
					glCallList(iTimeObjList);
				break;

				case STEPS_DISPLAY:
					glCallList(iStepsObjList);
				break;

				case SPEED_DISPLAY:
					glCallList(iSpeedObjList);
				break;
				
				case WING_DISPLAY:
					glCallList(iWingObjList);
				break;

				case SHIELD_DISPLAY:
					glCallList(iShieldObjList);
				break;

				case JUMP_DISPLAY:
					glCallList(iJumpObjList);
				break;
			}
		}
	}

	// Show text:	
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glColor4f(1.0f, 1.0f, 1.0f, 0.95f);

	if(bPause)
	{
		if(fPauseBlend < 1.0f)
		{
			fPauseBlend += (float) g_lDeltatime/iPauseBlendSpeed;
			if(fPauseBlend > 1.0f)
			{
				fPauseBlend = 1.0f;
				iPauseBlendSpeed = PAUSE_BLEND_SPEED;
			}
		}
	}
	else
	{
		if(fPauseBlend > 0.0f)
		{
			fPauseBlend -= (float) g_lDeltatime/iPauseBlendSpeed;
			if(fPauseBlend < 0.0f)
			{
				fPauseBlend = 0.0f;
				iPauseBlendSpeed = PAUSE_BLEND_SPEED;
			}
		}
	}
	if(fPauseBlend != 0.0f && !bLevelComplete)
	{
		glColor4f(1.0f, 1.0f, 1.0f, fPauseTextBlend);
		pWindow->glPrint(300, 450, T_Pause, 0);
	}
	if(bLevelPressAnyKey && bLevelComplete)
	{
		glColor4f(1.0f, 1.0f, 1.0f, fPauseTextBlend);
		pWindow->glPrint(150, 120, M_PressAnyKeyToContinue, 0);
	}
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	if(OktaActor.bActive && !pPlayer->bGoingDeath && !bLevelComplete && bHurryUpText && !bPause && fPauseBlend == 0.0f)
		pWindow->glPrint(250, 450, T_HurryUp, 0);

//	sprintf(byTemp, "%f", pPlayer->fAir);
//	pWindow->glPrint(150, 450, byTemp, 0);

	ASSwapBuffers(*pWindow->GethDC(), pWindow, TRUE);
	pLevel->DeInitLevelDraw();
	if(_ASConfig->byLight)
	{
		for(i = 0; i < 8; i++)
			glDisable(GL_LIGHT0+i);
	}
	return 0;
} // end GameDraw()

HRESULT GameCheck(AS_WINDOW *pWindow)
{ // begin GameCheck()
	float fXAcceleration = 0.0f, fYAcceleration = 0.0f;
	short i;
	BOOL bLoop;

	_AS->ReadDXInput(*pWindow->GethWnd());

	if(bLevelComplete)
	{ 
		if(!bLevelPressAnyKey)
		{ // Take all tools like the weapon shots and give the player points for this:
			if(g_lNow-lLevelCompleteTimer > iLevelCompleteSpeed)
			{
				lLevelCompleteTimer = g_lNow;
				if(!pLevel->bUnlimitedWeapon && PlayerInfo.iWeaponShots > 0)
				{
					PlayerInfo.iPoints += 5;
					PlayerInfo.iWeaponShots--;
				}
				else
					PlayerInfo.bWeapon = FALSE;
				if(!pLevel->bUnlimitedPull && PlayerInfo.iPullBoxes > 0)
				{
					PlayerInfo.iPoints += 5;
					PlayerInfo.iPullBoxes--;
				}
				else
					PlayerInfo.bPullBoxes = FALSE;
				if(!pLevel->bUnlimitedThrow && PlayerInfo.iThrowBoxes > 0)
				{
					PlayerInfo.iPoints += 5;
					PlayerInfo.iThrowBoxes--;
				}
				else
					PlayerInfo.bThrowBoxes = FALSE;
				if(!pLevel->bUnlimitedJump && PlayerInfo.iJump > 0)
				{
					PlayerInfo.iPoints += 5;
					PlayerInfo.iJump--;
				}
				else
					PlayerInfo.bJump = FALSE;
				if(!pLevel->bUnlimitedForce && PlayerInfo.iForce > 1)
				{
					PlayerInfo.iPoints += 5;
					PlayerInfo.iForce--;
				}
				else
					PlayerInfo.iForce = 1;
				if(GHOST_TIME-(g_lNow-PlayerInfo.lGhostTime) > 0)
				{
					PlayerInfo.iPoints += 1;
					PlayerInfo.lGhostTime -= 500;
				}
				else
					PlayerInfo.bGhost = FALSE;
				if(SPEED_TIME-(g_lNow-PlayerInfo.lSpeedTime) > 0)
				{
					PlayerInfo.iPoints += 1;
					PlayerInfo.lSpeedTime -= 500;
				}
				else
					PlayerInfo.bSpeed = FALSE;
				if(WING_TIME-(g_lNow-PlayerInfo.lWingTime) > 0)
				{
					PlayerInfo.iPoints += 1;
					PlayerInfo.lWingTime -= 500;
				}
				else
					PlayerInfo.bWing = FALSE;
				if(SHIELD_TIME-(g_lNow-PlayerInfo.lShieldTime) > 0)
				{
					PlayerInfo.iPoints += 1;
					PlayerInfo.lShieldTime -= 500;
				}
				else
					PlayerInfo.bShield = FALSE;
				if(!pLevel->bTimeLimit)
					pLevel->iTimeLimit = 0;
				else
				{
					if(pLevel->iTimeLimit > 0)
					{
						PlayerInfo.iPoints += 1;
						pLevel->iTimeLimit -= 5;
					}
					else
						pLevel->iTimeLimit = 0;
				}
				if(!pLevel->bStepsLimit)
					pLevel->iStepsLimit = 0;
				else
				{
					if(pLevel->iStepsLimit > 0)
					{
						PlayerInfo.iPoints += 1;
						pLevel->iStepsLimit -= 2;
					}
					else
						pLevel->iStepsLimit = 0;
				}
				// Check if the player could now go to the next level:
				if(!PlayerInfo.bWeapon &&
				   !PlayerInfo.bPullBoxes &&
				   !PlayerInfo.bThrowBoxes && 
				   PlayerInfo.iForce == 1 &&		
				   !PlayerInfo.bGhost &&
				   !PlayerInfo.bSpeed &&
				   !PlayerInfo.bWing &&
				   !PlayerInfo.bJump &&
				   !PlayerInfo.bShield &&
				   !pLevel->iTimeLimit &&
				   !pLevel->iStepsLimit)
				{
					bLevelPressAnyKey = TRUE; // The player could now go to the next level
					for(i = 0; i < 256; i++)
						ASKeys[i] = 0;
				}
				// Stop now:
				if(ASKeyFirst[_ASConfig->iLevelRestartKey])
				{ // Restart the current level:
					StartCurrentLevel();
					return 0;
				}
				for(i = 0; i < 256; i++)
				{
					if(CHECK_KEY(ASKeys, i))
					{
						iLevelCompleteSpeed = 1;
					}
				}
			}
		}
		if(bLevelPressAnyKey)
		{ // Left this level now?
			if(ASKeyFirst[_ASConfig->iLevelRestartKey])
			{ // Restart the current level:
				StartCurrentLevel();
				return 0;
			}
			for(i = 0; i < 256; i++)
			{
				if(CHECK_KEY(ASKeys, i))
				{ // Go into the next level:
					if(bEditorTestLevel)
					{
						_AS->SetNextModule(MODULE_EDITOR);
						return 0;					
					}
					PlayerIdentity.iSelectedLevel++;
					PlayerIdentity.iFinishedLevels++;
					
					if(PlayerIdentity.iSelectedLevel > CurrentCampaign.iLevels || bSingleLevel)
					{ // The game is finished!
						bInGameMenu = TRUE;
						PlayerIdentity.iSelectedLevel--;
						PlayerIdentity.iFinishedLevels--;
						return 0;
					}
					// Setup the current player stuff:
					PlayerIdentity.iPoints[PlayerIdentity.iSelectedLevel-1] = PlayerInfo.iPoints;
					PlayerIdentity.iLives[PlayerIdentity.iSelectedLevel-1] = PlayerInfo.iLives;
					PlayerIdentity.fPower[PlayerIdentity.iSelectedLevel-1] = pPlayer->fPower;
					if(!bSingleLevel) // Save the player identity:
						SavePlayerIdentity(&PlayerIdentity, &CurrentCampaign);

					sprintf(byCurrentLevelName, "%s%s", _AS->pbyProgramPath, CurrentCampaign.byLevelFilename[PlayerIdentity.iSelectedLevel-1]);
					StartLevel(byCurrentLevelName);
				}
			}
		}
	}
	if(bPause)
	{
		if(!bLevelComplete)
		{
			PlayerInfo.lGhostTime = g_lNow-lGhostTimeSave;
			PlayerInfo.lSpeedTime = g_lNow-lSpeedTimeSave;
			PlayerInfo.lWingTime = g_lNow-lWingTimeSave;
			PlayerInfo.lShieldTime = g_lNow-lShieldTimeSave;
			pPlayer->dwAniTime = g_lNow-pPlayer->dwAniDeltaTime;
			for(i = 0; i < MAX_ACTORS; i++)
				Actor[i].dwAniTime = g_lNow-Actor[i].dwAniDeltaTime;
			OktaActor.dwAniTime = g_lNow-OktaActor.dwAniDeltaTime;
			DeadSmileyActor.dwAniTime = g_lNow-DeadSmileyActor.dwAniDeltaTime;
		}
		if(fPauseBlend != 1.0f)
			fPauseTextBlend = fPauseBlend;
		else
		{
			if(!bPauseTextBlend)
			{
				fPauseTextBlend += (float) g_lDeltatime/1000;
				if(fPauseTextBlend > 1.0f)
				{
					fPauseTextBlend = 1.0f;
					bPauseTextBlend = 1;
				}
			}
			else
			{
				fPauseTextBlend -= (float) g_lDeltatime/1000;
				if(fPauseTextBlend < 0.0f)
				{
					fPauseTextBlend = 0.0f;
					bPauseTextBlend = 0;
				}
			}
		}
		if(PlayerTemp.byAction != ACTION_FUNNY)
		{
			PlayerTemp.byAction = ACTION_FUNNY;
			PlayerTemp.byAnimation = 8;
			PlayerTemp.iAniStep = pXeModel->Ani.anim[PlayerTemp.byAnimation].firstFrame;
			PlayerTemp.dwAniTime = g_lNow;
		}
		PlayerTemp.iNextAniStep = PlayerTemp.iAniStep+1;
		if(PlayerTemp.iNextAniStep >= pXeModel->Ani.anim[PlayerTemp.byAnimation].lastFrame)
			PlayerTemp.iNextAniStep = pXeModel->Ani.anim[PlayerTemp.byAnimation].firstFrame;
		if(g_lNow-PlayerTemp.dwAniTime > PLAYER_ANIMATION_SPEED)
		{
			PlayerTemp.dwAniTime = g_lNow;
			PlayerTemp.iAniStep++;
			if(PlayerTemp.iAniStep >= pXeModel->Ani.anim[PlayerTemp.byAnimation].lastFrame)
				PlayerTemp.iAniStep = pXeModel->Ani.anim[PlayerTemp.byAnimation].firstFrame;
		}
	}
	if(fPauseBlend != 1.0f)
		fPauseTextBlend = fPauseBlend;
	// Animate the display actors:
	for(i = 0; i < DISPLAY_ACTORS; i++)
	{
		if(!DisplayActor[i].bActive)
			continue;
		if(i == WEAPON_DISPLAY)
		{	
			DisplayActor[i].iNextAniStep = DisplayActor[i].iAniStep+1;
			if(DisplayActor[i].iNextAniStep >= pXeWeaponModel->Ani.anim[1].lastFrame)
				DisplayActor[i].iNextAniStep = pXeWeaponModel->Ani.anim[1].firstFrame;
			if(g_lNow-DisplayActor[i].dwAniTime > PLAYER_ANIMATION_SPEED)
			{
				DisplayActor[i].dwAniTime = g_lNow;
				DisplayActor[i].iAniStep++;
				if(DisplayActor[i].iAniStep >= pXeWeaponModel->Ani.anim[1].lastFrame)
					DisplayActor[i].iAniStep = pXeWeaponModel->Ani.anim[1].firstFrame;
			}
		}
		else
		if(g_lNow-DisplayActor[i].dwAniTime > OBJECTS_ANI_SPEED)
		{
			DisplayActor[i].dwAniTime = g_lNow;
			DisplayActor[i].iAniStep++;
			if(DisplayActor[i].iAniStep > 3)
				DisplayActor[i].iAniStep = 0;
		}
		// Rotate the object:
		DisplayActor[i].fRot[X] += (float) g_lDeltatime/OBJECT_ROTATE_SPEED;
		DisplayActor[i].fRot[Y] += (float) g_lDeltatime/OBJECT_ROTATE_SPEED;
		DisplayActor[i].fRot[Z] += (float) g_lDeltatime/OBJECT_ROTATE_SPEED;
	}
		
// Camera:
	if(!bCameraAnimation)
	{
		CheckCameraKeys(FALSE);
		//	Mouse camera movement and rotate:
		// Compute the player acceleration corresponding the mouse movement:
		fXAcceleration = ((float) ASMouse.lX/g_lDeltatime)*_ASConfig->fMouseSensibility*0.35f;
		fYAcceleration = ((float) ASMouse.lY/g_lDeltatime)*_ASConfig->fMouseSensibility*0.35f;
		if(CHECK_KEY(ASMouse.byButtons, 0) && CHECK_KEY(ASMouse.byButtons, 1) && !bPlayerCameraView)
			pCamera->fZ -= fYAcceleration;
		else
		{
			if(!bPlayerCameraView)
			{
				if(CHECK_KEY(ASMouse.byButtons, 1))
				{
					pCamera->fRot[X] += fYAcceleration*10.0f;
					pCamera->fRot[Y] += fXAcceleration*10.0f;
				}
				if(CHECK_KEY(ASMouse.byButtons, 0))
				{
					if(fXAcceleration)
					{
						pCamera->fPos2[X] -= fSin90*fXAcceleration;
						pCamera->fPos2[Y] -= fCos90*fXAcceleration;
					}
					if(fYAcceleration)
					{
						pCamera->fPos2[X] -= fSin*fYAcceleration;
						pCamera->fPos2[Y] -= fCos*fYAcceleration;
					}
				}
				if((!CHECK_KEY(ASMouse.byButtons, 0) && !CHECK_KEY(ASMouse.byButtons, 1)) ||
				   CHECK_KEY(ASMouse.byButtons, 2))
					pCamera->fRot[Z] -= fXAcceleration*10.0f;
			}
			else
			{
				pCamera->fRot2[Z] -= fXAcceleration*4;
				pCamera->fRot2[X] += fYAcceleration*4;
				if(CHECK_KEY(ASMouse.byButtons, 1))
					pCamera->fRot2[Y] += fXAcceleration*4;
			}
		}
	}
	CalculateCamersSinCos(); // Update the sin/cos for the camera
	if(pLevel->bEndCameraLoop && bLevelComplete)
		bLoop = TRUE;
	else
		bLoop = FALSE;
	if(PlayCameraScript(bLoop))
	{
		CheckPlayer(TRUE);
		CheckActors(FALSE);
		return 0;
	}
	if(!bPlayerCameraView)
	{ // We are in the free camera perspective:
		if(pCamera->fZ > -1.5f)
			pCamera->fZ = -1.5f;
		if(pCamera->fZ < -20.5f)
			pCamera->fZ = -20.5f;
		if(_ASConfig->bTiltCamera)
		{ // Tilt the camera dependent on the players position:
			if(pPlayer->fWorldPos[X] > pLevel->fWholeWidth/2)
			{
				if(!(pPlayer->fWorldPos[X]-pLevel->fWholeWidth/2))
					pCamera->fRot[Y] = 0.0f;
				else
					pCamera->fRot[Y] = 100.0f*((pPlayer->fWorldPos[X]-pLevel->fWholeWidth/2)/pLevel->fWholeWidth/2);
			}
			else
			{
				if(!(pLevel->fWholeWidth/2-pPlayer->fWorldPos[X]))
					pCamera->fRot[Y] = 0.0f;
				else
					pCamera->fRot[Y] = -100.0f*((pLevel->fWholeWidth/2-pPlayer->fWorldPos[X])/pLevel->fWholeWidth/2);
			}
			if(pPlayer->fWorldPos[Y] > pLevel->fWholeHeight/2)
			{
				if(!(pPlayer->fWorldPos[Y]-pLevel->fWholeHeight/2))
					pCamera->fRot[X] = 0.0f;
				else
					pCamera->fRot[X] = 100.0f*((pPlayer->fWorldPos[Y]-pLevel->fWholeHeight/2)/pLevel->fWholeHeight/2);
			}
			else
			{
				if(!(pLevel->fWholeHeight/2-pPlayer->fWorldPos[Y]))
					pCamera->fRot[X] = 0.0f;
				else
					pCamera->fRot[X] = -100.0f*((pLevel->fWholeHeight/2-pPlayer->fWorldPos[Y])/pLevel->fWholeHeight/2);
			}
		}
		if(!bFreeCameraRotate)
		{
			if(pCamera->fRot[X] < -90.0f)
				pCamera->fRot[X] = -90.0f;
			if(pCamera->fRot[X] > 90.0f)
				pCamera->fRot[X] = 90.0f;
			if(pCamera->fRot[Y] < -90.0f)
				pCamera->fRot[Y] = -90.0f;
			if(pCamera->fRot[Y] > 90.0f)
				pCamera->fRot[Y] = 90.0f;
		}
		// Set the current camera view:
		pCamera->fPos[X] = -pPlayer->fWorldPos[X]+pCamera->fPos2[X]-0.5f;
		pCamera->fPos[Y] = -pPlayer->fWorldPos[Y]+pCamera->fPos2[Y]-0.5f;
		pCamera->fPos[Z] = pCamera->fZ+pCamera->fPos2[Z];
		if(g_lNow-lCameraTimerT > 10)
		{
			lCameraTimerT = g_lNow;
			pCamera->fPos2[X] = pCamera->fPos2[X]/1.03f;
			pCamera->fPos2[Y] = pCamera->fPos2[Y]/1.03f;
			pCamera->fPos2[Z] = pCamera->fPos2[Z]/1.03f;
		}
		if(_ASConfig->bBackCamera)
		{ // Set the back camera:
			pCamera->fRot[Z] = -pPlayer->fRot[Y]-90.0f;
		}
	}
	else
	{ // We are in the ego-shooter perspective:
		pCamera->fPos[X] = -pPlayer->fWorldPos[X]-0.5f;
		pCamera->fPos[Y] = -pPlayer->fWorldPos[Y]-0.5f;
		pCamera->fPos[Z] = pPlayer->fWorldPos[Z]-0.8f;
		pCamera->fRot[X] = 90.0f+pCamera->fRot2[X];
		pCamera->fRot[Y] = 0.0f+pCamera->fRot2[Y];
		pCamera->fRot[Z] = -pPlayer->fRot[Y]+270.0f+pCamera->fRot2[Z];
		if(g_lNow-lCameraTimerT > 10)
		{
			lCameraTimerT = g_lNow;
			for(i = 0; i < 3; i++)
			{
				pCamera->fRot2[i] /= 1.03f;
				pCamera->fRot2Velocity[i] /= 1.03f;
				pCamera->fRot2[i] += pCamera->fRot2Velocity[i]*g_lDeltatime;
			}
		}
	}

	if(bLevelComplete)
	{
		CheckPlayer(TRUE);
		CheckActors(FALSE);
		return 0;
	}
// Keys:
	if(ASKeyFirst[DIK_ESCAPE])
	{ // Go back to the main menu:
		SendMessage(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), WM_COMMAND, ID_GAME_FILE_GAME_MENU, 0);
	}
	if(ASKeyFirst[_ASConfig->iLevelRestartKey])
	{ // Restart the current level:
		StartCurrentLevel();
		return 0;
	}

	if(ASKeyFirst[_ASConfig->iPauseKey] && !bLevelComplete && !pPlayer->bGoingDeath)
	{
	Pause:
		lPauseTimer = g_lNow;
		bPause = !bPause;
		lGhostTimeSave = g_lNow-PlayerInfo.lGhostTime;
		lSpeedTimeSave = g_lNow-PlayerInfo.lSpeedTime;
		lWingTimeSave = g_lNow-PlayerInfo.lWingTime;
		lShieldTimeSave =  g_lNow-PlayerInfo.lShieldTime;
	}
	if(ASKeyFirst[DIK_F1])
	{ // Open the help file:
		if(_ASConfig->bFullScreen)
		{ // Switch to window mode:
			_ASConfig->bFullScreen = FALSE;
			ChangeDisplayMode();
		}
		ASKeyFirst[DIK_F1] = false;
		OpenHelp();
		goto Pause; // Pause the game
	}
	if(ASKeyFirst[_ASConfig->iChangePerspectiveKey])
	{ // Change the perscective:
		if(!bPlayerCameraView && pLevel->bPlayerCamera)
		{
			memcpy(&TempCamera, pCamera, sizeof(AS_CAMERA));
			pCamera->fRot2[X] = -90.0f;
			bPlayerCameraView = TRUE;
		}
		else
		if(bPlayerCameraView && pLevel->bFreeCamera)
		{
			memcpy(pCamera, &TempCamera, sizeof(AS_CAMERA));
			pCamera->fPos2[Z] = -pCamera->fPos[Z];
			bPlayerCameraView = FALSE;
		}
	}
	if(ASKeyFirst[_ASConfig->iBackCameraKey])
	{ // Change the camera mode: (back camera or not)
		_ASConfig->bBackCamera = !_ASConfig->bBackCamera;
	}
	if(ASKeyFirst[DIK_F12])
	{ // Open the configuration menu:
		SendMessage(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), WM_COMMAND, ID_OPTIONS_CONFIG, 0);
	}

	if(bPause)
		return 0;
// Actors:
	CheckPlayer(FALSE);
	CheckActors(FALSE);

	// Level time limit:
	if(g_lNow-pLevel->lTimeLimitTime > 1000)
	{
		pLevel->lTimeLimitTime = g_lNow;
		if(pLevel->bTimeLimit)
		{
			pLevel->iTimeLimit--;
			if(pLevel->iTimeLimit < 0)
				pLevel->iTimeLimit = 0;
		}
		else
			pLevel->iTimeLimit++;
	}
	CheckMissions();
	if(OktaActor.bActive && g_lNow-lHurryUpTimer > 500)
	{
		lHurryUpTimer = g_lNow;
		bHurryUpText = !bHurryUpText;
	}
	return 0;
} // end GameCheck()

void LoadGameTextures(void)
{ // begin LoadGameTextures()
	char byFilename[GAME_TEXTURES][256] = {"Fire1.jpg", "Fire2.jpg", "Fire3.jpg",
										   "Fire4.jpg", "Xe.jpg", "XeRambo.jpg",
										   "XeWeapon.jpg", "Wave.jpg", "Shield.jpg",
										   "DeadSmiley.jpg", "Okta.jpg"},
		 byTemp[256];
	AS_PROGRESS_WINDOW ProgressWindow;
	short i;

	ProgressWindow.CreateProgressWindow("Load");
	ProgressWindow.SetTask("Game textures...");
	ProgressWindow.SetProgress(0);
	for(i = 0; i < GAME_TEXTURES; i++)
	{
		sprintf(byTemp, "%s%s\\%s", _AS->pbyProgramPath, _AS->pbyBitmapsFile, byFilename[i]);
		ProgressWindow.SetSubTask(byTemp);
		ProgressWindow.SetProgress((UINT) (((float) i/GAME_TEXTURES)*100));
		ASLoadJpegRGB(&GameTexture[i], byTemp);
	}
	for(i = 0; i < 4; i++)
	{
		sprintf(byTemp, "%s%s\\convey%d.jpg", _AS->pbyProgramPath, _AS->pbyBitmapsFile, i+1);
		ProgressWindow.SetSubTask(byTemp);
		ProgressWindow.SetProgress((UINT) (((float) i/4)*100));
		ASLoadJpegRGB(&GameTitleTexture[i], byTemp);
	}
} // begin LoadGameTextures()

void DestroyGameTextures(void)
{ // begin DestroyGameTextures()
	short i;

	for(i = 0; i < GAME_TEXTURES; i++)
		free(GameTexture[i].pbyData);
	for(i = 0; i < 4; i++)
		free(GameTitleTexture[i].pbyData);
} // end DestroyGameTextures()

void GenOpenGLGameTextures(void)
{ // begin GenOpenGLGameTextures()
	AS_PROGRESS_WINDOW ProgressWindow;

	ProgressWindow.CreateProgressWindow("Loading game textures");
	ProgressWindow.SetTask("Generate OpenGL game textures...");
	ProgressWindow.SetProgress(0);
	for(short i = 0; i < GAME_TEXTURES; i++)
	{
		ProgressWindow.SetSubTask("%s", GameTexture[i].byFilename);
		ProgressWindow.SetProgress((UINT) (((float) i/GAME_TEXTURES)*100));
		glGenTextures(1, &GameTexture[i].iOpenGLID);
		glBindTexture(GL_TEXTURE_2D, GameTexture[i].iOpenGLID);
		if(_ASConfig->bUseMipmaps)
		{
			if(_ASConfig->bFastTexturing)
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST_MIPMAP_NEAREST);
				gluBuild2DMipmaps(GL_TEXTURE_2D, 3, GameTexture[i].iWidth, GameTexture[i].iHeight, GL_RGB, GL_UNSIGNED_BYTE, GameTexture[i].pbyData);
			}
			else
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);
				gluBuild2DMipmaps(GL_TEXTURE_2D, 3, GameTexture[i].iWidth, GameTexture[i].iHeight, GL_RGB, GL_UNSIGNED_BYTE, GameTexture[i].pbyData);
			}
		}
		else
		{
			if(_ASConfig->bFastTexturing)
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
				glTexImage2D(GL_TEXTURE_2D, 0, 3, GameTexture[i].iWidth, GameTexture[i].iHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, GameTexture[i].pbyData);
			}
			else
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
				glTexImage2D(GL_TEXTURE_2D, 0, 3, GameTexture[i].iWidth, GameTexture[i].iHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, GameTexture[i].pbyData);
			}
		}
	}
	for(i = 0; i < 4; i++)
	{
		ProgressWindow.SetSubTask("%s", GameTitleTexture[i].byFilename);
		glGenTextures(1, &GameTitleTexture[i].iOpenGLID);
		glBindTexture(GL_TEXTURE_2D, GameTitleTexture[i].iOpenGLID);
		if(_ASConfig->bUseMipmaps)
		{
			if(_ASConfig->bFastTexturing)
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST_MIPMAP_NEAREST);
				gluBuild2DMipmaps(GL_TEXTURE_2D, 3, 128, 128, GL_RGB, GL_UNSIGNED_BYTE, GameTitleTexture[i].pbyData);
			}
			else
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);
				gluBuild2DMipmaps(GL_TEXTURE_2D, 3, 128, 128, GL_RGB, GL_UNSIGNED_BYTE, GameTitleTexture[i].pbyData);
			}
		}
		else
		{
			if(_ASConfig->bFastTexturing)
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
				glTexImage2D(GL_TEXTURE_2D, 0, 3, 128, 128, 0, GL_RGB, GL_UNSIGNED_BYTE, GameTitleTexture[i].pbyData);
			}
			else
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
				glTexImage2D(GL_TEXTURE_2D, 0, 3, 128, 128, 0, GL_RGB, GL_UNSIGNED_BYTE, GameTitleTexture[i].pbyData);
			}
		}
	}
	CreateGameLists();
} // end GenOpenGLGameTextures()

void DestroyOpenGLGameTextures(void)
{ // begin DestroyOpenGLGameTextures()
	AS_PROGRESS_WINDOW ProgressWindow;
	short i;

	ProgressWindow.CreateProgressWindow("Destroy game textures");
	ProgressWindow.SetTask("Delete OpenGL game textures...");
	ProgressWindow.SetProgress(0);
	for(i = 0; i < GAME_TEXTURES; i++)
	{
		ProgressWindow.SetSubTask("%s", GameTexture[i].byFilename);
		ProgressWindow.SetProgress((UINT) (((float) i/GAME_TEXTURES)*100));
		glDeleteTextures(1, &GameTexture[i].iOpenGLID);
	}
	for(i = 0; i < 3; i++)
	{
		ProgressWindow.SetSubTask("%s", GameTitleTexture[i].byFilename);
		glDeleteTextures(1, &GameTitleTexture[i].iOpenGLID);
	}

	DestroyGameLists();
} // end DestroyOpenGLGameTextures()

void UpdateAllTextures(void)
{ // begin UpdateAllTextures()
	if(!pLevel || bFirstRunConfigDialog)
		return;
	switch(_AS->GetModule())
	{
		case MODULE_GAME:
			_AS->pWindow[GAME_WINDOW_ID].KillFont();
			DestroyOpenGLGameTextures();
			DestroyOpenGLGameMenuTextures();
			pLevel->DestroyTexturesOpenGL(*_AS->pWindow[GAME_WINDOW_ID].GethDC(), 
										  *_AS->pWindow[GAME_WINDOW_ID].GethRC());
			_AS->pWindow[GAME_WINDOW_ID].BuildFont();
			GenOpenGLGameMenuTextures();
			GenOpenGLGameTextures();
			pLevel->GenTexturesOpenGL(*_AS->pWindow[GAME_WINDOW_ID].GethDC(), 
									  *_AS->pWindow[GAME_WINDOW_ID].GethRC());
		break;

		case MODULE_EDITOR:
			KillFont();
			DestroyOpenGLGameTextures();
			pLevel->DestroyTexturesOpenGL(hDCEditorShow, hRCEditorShow);
			BuildFont();
			GenOpenGLGameTextures();
			pLevel->GenTexturesOpenGL(hDCEditorShow, hRCEditorShow);
		break;
	}
} // end UpdateAllTextures()

void UpdateRenderQuality(void)
{ // begin UpdateRenderQuality()
	RECT Rect;

	if(bFirstRunConfigDialog)
		return;
	switch(_AS->GetModule())
	{
		case MODULE_GAME:
			ASConfigOpenGL(_AS->pWindow[GAME_WINDOW_ID].GetWidth(), _AS->pWindow[GAME_WINDOW_ID].GetWidth());
		break;

		case MODULE_EDITOR:
			GetWindowRect(hWndEditorShow, &Rect);
			wglMakeCurrent(hDCEditorShow, hRCEditorShow);
			ASConfigOpenGL(Rect.right-Rect.left, Rect.bottom-Rect.top);
		break;
	}
} // end UpdateRenderQuality()

void CreateGameLists(void)
{ // begin CreateGameLists()
	short i;

	// Game title list:
	iGameTitleList = glGenLists(18);
	glNewList(iGameTitleList, GL_COMPILE);
		for(i = 0; i < 4; i++)
		{
			glTranslatef(0.5, 0.0f, 0.0f);
			glBindTexture(GL_TEXTURE_2D, GameTitleTexture[i].iOpenGLID);
			glBegin(GL_QUADS);
				// Left bottom
				glNormal3f( 0.0f, 0.0f, 1.0f);
				glTexCoord2f(0.01f, 0.99f); glVertex3f(-0.5f, -0.5f, 0.0f);
				glTexCoord2f(0.99f, 0.99f); glVertex3f(0.0f, -0.5f, 0.0f);
				glTexCoord2f(0.99f, 0.01f); glVertex3f(0.0f, 0.0f, 0.0f);
				glTexCoord2f(0.01f, 0.01f); glVertex3f(-0.5f, 0.0f, 0.0f);
			glEnd();
		}
	glEndList();
	// Wave list:
	iWaveList = iGameTitleList+1;
	glNewList(iWaveList, GL_COMPILE);
		glBindTexture(GL_TEXTURE_2D, GameTexture[7].iOpenGLID);
		glBegin(GL_QUADS);
			// Left bottom
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f(-0.5f, -0.5f, 0.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f(0.0f, -0.5f, 0.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f(0.0f, 0.0f, 0.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f(-0.5f, 0.0f, 0.0f);
			// Right bottom
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f(0.0f, -0.5f, 0.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f(0.5f, -0.5f, 0.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f(0.5f, 0.0f, 0.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f(0.0f, 0.0f, 0.0f);
			// Left Top
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f(-0.5f, 0.0f, 0.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f(0.0f, 0.0f, 0.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f(0.0f, 0.5f, 0.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f(-0.5f, 0.5f, 0.0f);
			// Right Top
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f(0.0f, 0.0f, 0.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f(0.5f, 0.0f, 0.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f(0.5f, 0.5f, 0.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f(0.0f, 0.5f, 0.0f);
		glEnd();
	glEndList();
	// Shield list:
	iShieldList = iWaveList+1;
	glNewList(iShieldList, GL_COMPILE);
		glBindTexture(GL_TEXTURE_2D, GameTexture[8].iOpenGLID);
		glBegin(GL_QUADS);
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f(-0.7f, -0.7f, 0.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f(0.7f, -0.7f, 0.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f(0.7f, 0.7f, 0.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f(-0.7f, 0.7f, 0.0f);
		glEnd();
	glEndList();
	// Health object list:
	iHealthObjList = iShieldList+1;
	glNewList(iHealthObjList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		pHealthObject->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
	// Live object list:
	iLiveObjList = iHealthObjList+1;
	glNewList(iLiveObjList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		pLiveObject->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
	//  object list:
	iPullObjList = iLiveObjList+1;
	glNewList(iPullObjList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		pPullObject->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
	// Throw object list:
	iThrowObjList = iPullObjList+1;
	glNewList(iThrowObjList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		pThrowObject->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
	// Force object list:
	iForceObjList = iThrowObjList+1;
	glNewList(iForceObjList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		pForceObject->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
	// Point object list:
	iPointObjList = iForceObjList+1;
	glNewList(iPointObjList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		pPointObject->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
	// Ghost object list:
	iGhostObjList = iPointObjList+1;
	glNewList(iGhostObjList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		pGhostObject->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
	// Player shot object list:
	iPlayerShotObjList = iGhostObjList+1;
	glNewList(iPlayerShotObjList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		pPlayerShot->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
	// Time object list::
	iTimeObjList = iPlayerShotObjList+1;
	glNewList(iTimeObjList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		pTimeObject->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
	// Step object list::
	iStepsObjList = iTimeObjList+1;
	glNewList(iStepsObjList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		pStepsObject->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
	// Speed object list::
	iSpeedObjList = iStepsObjList+1;
	glNewList(iSpeedObjList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		pSpeedObject->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
	// Wing object list::
	iWingObjList = iSpeedObjList+1;
	glNewList(iWingObjList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		pWingObject->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
	// Shield object list::
	iShieldObjList = iWingObjList+1;
	glNewList(iShieldObjList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		pShieldObject->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
	// Jump object list::
	iJumpObjList = iShieldObjList+1;
	glNewList(iJumpObjList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		pJumpObject->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
	// Air object list::
	iAirObjList = iJumpObjList+1;
	glNewList(iAirObjList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		pAirObject->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
} // end CreateGameLists()()

void DestroyGameLists(void)
{ // begin DestroyGameLists()
	glDeleteLists(iWaveList, 18);
} // end DestroyeGameLists()()

void InitGameObjects(void)
{ // begin InitGameObjects()
	char byModelFileTemp[MODELS][256] = {"Xe.md2", "XeWeapon.md2", "DeadSmiley.md2", "Okta.md2"};
	char byObjectFileTemp[OBJECTS][256] = {"HealthObj.aso", "LiveObj.aso", "PullObj.aso",
										   "ThrowObj.aso", "ForceObj.aso", "PointObj.aso",
										   "GhostObj.aso", "PlayerShotObj.aso",
										   "TimeObj.aso", "StepsObj.aso", "SpeedObj.aso",
										   "WingObj.aso", "ShieldObj.aso",
										   "JumpObj.aso", "AirObj.aso"};
	char byTemp[256];
	short i;

	// Load all models:
	for(i = 0; i < MODELS; i++)
	{
		sprintf(byTemp, "%s%s\\%s", _AS->pbyProgramPath, _AS->pbyObjectsFile, byModelFileTemp[i]);
		if(!((*pModels[i]) = ASLoadMd2Model(byTemp)))
		{
			_AS->WriteLogMessage("------------------------------------------");
			_AS->WriteLogMessage("Couldn't load: %s   program couldn't run!!", byTemp);
			_AS->WriteLogMessage("------------------------------------------");
			_ASConfig->bError = TRUE;
			_ASConfig->bSetError = TRUE;
			_AS->SetShutDown(TRUE);
			return;
		}
	}
	pDeadSmileyModel->header.skinWidth = 512;
	pDeadSmileyModel->header.skinHeight = 512;
	pOktaModel->header.skinHeight = 256;
	// Load all objects:
	for(i = 0; i < OBJECTS; i++)
	{
		*pObjects[i] = new AS_OBJECT;
		sprintf(byTemp, "%s%s\\%s", _AS->pbyProgramPath, _AS->pbyObjectsFile, byObjectFileTemp[i]);
		if((*pObjects[i])->Load(byTemp) == -1)
		{
			_AS->WriteLogMessage("------------------------------------------");
			_AS->WriteLogMessage("Couldn't load: %s   program couldn't run!!", byTemp);
			_AS->WriteLogMessage("------------------------------------------");
			_ASConfig->bError = TRUE;
			_ASConfig->bSetError = TRUE;
			_AS->SetShutDown(TRUE);
			return;
		}
	}
	// Create and initalize the player:
	pPlayer = new ACTOR;
	memset(&PlayerInfo, 0, sizeof(PLAYER_INFO));
} // end InitGameObjects()

void DestroyGameObjects(void)
{ // begin DestroyGameObjects()
	short i;
	
	// Destroy all game objects:
	for(i = 0; i < MODELS; i++)
	{
		if(!(*pModels[i]))
			continue;
		ASFreeMd2Model(*pModels[i]);
	}
	// Destroy all objects:
	for(i = 0; i < OBJECTS; i++)
	{
		if(!(*pObjects[i]))
			continue;
		(*pObjects[i])->Destroy();
		delete *pObjects[i];
	}

	// 'Destroy' the player:
	delete pPlayer;
} // end DestroyGameObjects()

void CalculateCamersSinCos(void)
{ // begin CalculateCamersSinCos()
	if (pCamera->fRot[Z] == -1)
		pCamera->fRot[Z] = 0;
	// We should be in the range of 0.0 and 360.0:
	for(int i=0; i<100;i++)
	{
		if(pCamera->fRot[Z] < 0.0f)
			pCamera->fRot[Z] += 360.0f;
		if(pCamera->fRot[Z] > 360.0f)
			pCamera->fRot[Z] -= 360.0f;
		if(pCamera->fRot[Z] >= 0.0f && pCamera->fRot[Z] <= 360.0f)
			break;
	}
	// This are the sin/cos depending of the current camera direction:
	fSin = (float) sin(pCamera->fRot[Z]*PI180);
	fSin90 = (float) sin((pCamera->fRot[Z]+90.0f)*PI180);
	fCos = (float) cos(pCamera->fRot[Z]*PI180);
	fCos90 = (float) cos((pCamera->fRot[Z]+90.0f)*PI180);
} // end CalculateCamersSinCos()

void CheckCameraKeys(BOOL bEditor)
{ // begin CheckCameraKeys()
	// Camera movement keys:
	if(bEditor)
	{
		if(CHECK_KEY(ASKeys, DIK_LEFT))
		{
			pCamera->fPos[X] += fSin90*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
			pCamera->fPos[Y] += fCos90*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
			pCamera->fPos2[X] += fSin90*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
			pCamera->fPos2[Y] += fCos90*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
		}
		if(CHECK_KEY(ASKeys, DIK_RIGHT))
		{
			pCamera->fPos[X] -= fSin90*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
			pCamera->fPos[Y] -= fCos90*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
			pCamera->fPos2[X] -= fSin90*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
			pCamera->fPos2[Y] -= fCos90*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
		}
		if(CHECK_KEY(ASKeys, DIK_UP))
		{
			pCamera->fPos[X] += fSin*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
			pCamera->fPos[Y] += fCos*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
			pCamera->fPos2[X] += fSin*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
			pCamera->fPos2[Y] += fCos*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
		}
		if(CHECK_KEY(ASKeys, DIK_DOWN))
		{
			pCamera->fPos[X] -= fSin*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
			pCamera->fPos[Y] -= fCos*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
			pCamera->fPos2[X] -= fSin*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
			pCamera->fPos2[Y] -= fCos*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
		}
	}

	// Rotate and move the camera:
	if(CHECK_KEY(ASKeys, DIK_NUMPAD4))
		pCamera->fRot[Y] += 0.05f*g_lDeltatime*fCameraVelocity;
	if(CHECK_KEY(ASKeys, DIK_NUMPAD6))
		pCamera->fRot[Y] -= 0.05f*g_lDeltatime*fCameraVelocity;
	if(CHECK_KEY(ASKeys, DIK_NUMPAD8))
		pCamera->fRot[X] += 0.05f*g_lDeltatime*fCameraVelocity;
	if(CHECK_KEY(ASKeys, DIK_NUMPAD2))
		pCamera->fRot[X] -= 0.05f*g_lDeltatime*fCameraVelocity;
	if(CHECK_KEY(ASKeys, DIK_NUMPAD9))
		pCamera->fRot[Z] -= 0.05f*g_lDeltatime*fCameraVelocity;
	if(CHECK_KEY(ASKeys, DIK_NUMPAD3))
		pCamera->fRot[Z] += 0.05f*g_lDeltatime*fCameraVelocity;
	
	// Check the standart view key:
	if(CHECK_KEY(ASKeys, _ASConfig->iStandartViewKey) && !pPlayer->bGoingDeath)
		pLevel->SetStandartView();

	// Zoom in and out:
	if(CHECK_KEY(ASKeys, DIK_ADD))
		pCamera->fZ += 0.01f*g_lDeltatime*fCameraVelocity;
	if(CHECK_KEY(ASKeys, DIK_SUBTRACT))
		pCamera->fZ -= 0.01f*g_lDeltatime*fCameraVelocity;
} // end CheckCameraKeys()

BOOL PlayCameraScript(BOOL bLoop)
{ // begin PlayCameraScript()
	AS_CAMERA *pCameraNow, *pCameraNext;
	float fDeltaT;
	short i, i2;

	if(bCameraAnimation && pLevel->pCurrentCameraScript)
	{ // We play a camera script:
		if(bPause && !bLevelComplete)
			lCameraTimer = g_lNow-lCameraPauseTimerT;
		if(!bPause || bLevelComplete)
		{
			// Make a smooth camera movement:
			// Get the camera positions:
			pCameraNow = &pLevel->pCurrentCameraScript->pCamera[pLevel->iCurrentCameraStep];
			i2 = pLevel->iCurrentCameraStep+1;
			if(i2 >= pLevel->pCurrentCameraScript->iSteps)
				i2 = 0;
			pCameraNext = &pLevel->pCurrentCameraScript->pCamera[i2];
			
			// No division throught zero!!
			if(!pCameraNow->iTimeToNext)
				pCameraNow->iTimeToNext = 1;
			if(!pCameraNext->iTimeToNext)
				pCameraNext->iTimeToNext = 1;

			// Calculate the current camera pos:
			fDeltaT = (float) (g_lNow-lCameraTimer)/pCameraNow->iTimeToNext;
			if(fDeltaT > 1.0f)
				fDeltaT = 1.0f;
			for(i = 0; i < 3; i++)
			{
				pCamera->fPos[i] = pCameraNow->fPos[i]-(pCameraNow->fPos[i]-pCameraNext->fPos[i])*fDeltaT;
					
				float fD = pCameraNow->fRot[i]-pCameraNext->fRot[i];
				float fDistance;
				
				// The rotation is a little more complex...
				if(fD > 180 || fD < -180)
				{
					// Calculate the 'real' distance:
					if(pCameraNow->fRot[i] < 180)
						fDistance = pCameraNow->fRot[i];
					else
						fDistance = 360-pCameraNow->fRot[i];
					if(pCameraNext->fRot[i] < 180)
						fDistance += pCameraNext->fRot[i];
					else
						fDistance += 360-pCameraNext->fRot[i];

					// Check how we have to turn:
					if(fD < 0)  // We have to turn left:
						pCamera->fRot[i] = pCameraNow->fRot[i]-(fDistance*fDeltaT);
					else // We have to turn right:
						pCamera->fRot[i] = pCameraNow->fRot[i]+(fDistance*fDeltaT);
				}
				else
					pCamera->fRot[i] = pCameraNow->fRot[i]-(pCameraNow->fRot[i]-pCameraNext->fRot[i])*fDeltaT;
			}
			pCamera->fZ = pCameraNow->fZ-(pCameraNow->fZ-pCameraNext->fZ)*fDeltaT+TempCamera.fZ;
			// Check if we have to go to the next camera step:
			if(g_lNow-lCameraTimer > pLevel->pCurrentCameraScript->pCamera[pLevel->iCurrentCameraStep].iTimeToNext)
			{ // Go to the next animation step:
				lCameraTimer = g_lNow;
				pLevel->iCurrentCameraStep++;
				if(pLevel->iCurrentCameraStep >= pLevel->pCurrentCameraScript->iSteps-1 && !bLoop)
				{
					memset(&pCamera->fPos2, 0, sizeof(FLOAT3));
					bCameraAnimation = FALSE;
				}
				else
				{
					if(pLevel->iCurrentCameraStep >= pLevel->pCurrentCameraScript->iSteps)
						pLevel->iCurrentCameraStep = 0;
				}
			}
		}
		if(ASKeyFirst[_ASConfig->iPauseKey] && !bLevelComplete)
		{
			lPauseTimer = g_lNow;
			bPause = !bPause;
			if(bPause)
				lCameraPauseTimerT = g_lNow-lCameraTimer;
		}
		if(!bLoop && !bPause)
		{
			// Stop the camera script?
			for(i = 0; i < 256; i++)
			{
				if(i == _ASConfig->iPauseKey && !bLevelComplete)
					continue;
				if(ASKeyFirst[i])
				{
					pLevel->iCurrentCameraStep = pLevel->pCurrentCameraScript->iSteps-1;
					memcpy(pCamera, &pLevel->pCurrentCameraScript->pCamera[pLevel->iCurrentCameraStep], sizeof(AS_CAMERA));
					bCameraAnimation = FALSE;
					memset(&pCamera->fPos2, 0, sizeof(FLOAT3));
					return 0;
				}
			}
		}
		return 1;
	}
	return 0;
} // end PlayCameraScript()

void SetCameraTranslation(BOOL bOnlyRot)
{ // begin SetCameraTranslation(()
	if(bCameraAnimation || _AS->GetModule() == MODULE_EDITOR)
	{
		glLoadIdentity();
		glRotatef(pCamera->fRot[X], 1.0f, 0.0f, 0.0f);
		glRotatef(pCamera->fRot[Y]+180.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(pCamera->fRot[Z]+180.0f, 0.0f, 0.0f, 1.0f);
		if(!bOnlyRot)
			glTranslatef(pCamera->fPos[X], pCamera->fPos[Y], -pCamera->fPos[Z]);
	}
	else
	{
		glLoadIdentity();
		if(!bPlayerCameraView)
		{
			if(!bOnlyRot)
				glTranslatef(0.0f, 0.0f, pCamera->fPos[Z]);
			glRotatef(pCamera->fRot[X], 1.0f, 0.0f, 0.0f);
			glRotatef(pCamera->fRot[Y]+180.0f, 0.0f, 1.0f, 0.0f);
			glRotatef(pCamera->fRot[Z]+180.0f, 0.0f, 0.0f, 1.0f);
			if(!bOnlyRot)
				glTranslatef(pCamera->fPos[X], pCamera->fPos[Y], -pPlayer->fWorldPos[Z]+0.5f);
		}
		else
		{
			glRotatef(pCamera->fRot[X], 1.0f, 0.0f, 0.0f);
			glRotatef(pCamera->fRot[Y], 0.0f, 1.0f, 0.0f);
			glRotatef(pCamera->fRot[Z], 0.0f, 0.0f, 1.0f);
			if(!bOnlyRot)
				glTranslatef(pCamera->fPos[X], pCamera->fPos[Y], -pCamera->fPos[Z]);
		}
	}
} // end SetCameraTranslation()

void StartLevel(char *pbyFilename)
{ // begin StartLevel()
	char byOldMusic[256];
	short iX, iY;
	int i;

	// Player game init settings:
	memset(&PlayerInfo, 0, sizeof(PLAYER_INFO));
	PlayerInfo.iForce = 1;
	bPlayerCameraView = FALSE;
	if(pLevel) // Backup the old music file:
		strcpy(byOldMusic, pLevel->byMusicFile);	

	// Destroy the old level:
	if(pLevel)
		DestroyLevel();

	// Setup the new level:
	pLevel = new LEVEL;

	// Load the level:
	pLevel->Load(byCurrentLevelName);
	pLevel->GenTexturesOpenGL(*_AS->pWindow[GAME_WINDOW_ID].GethDC(), 
							  *_AS->pWindow[GAME_WINDOW_ID].GethRC());

	// Compare if this music is still running:
	if(strcmp(byOldMusic, pLevel->byMusicFile) && pLevel->bMusic)
	{ // Nope, start the new level music:	
		StartLevelMusic();
	}
	else
		if(!pLevel->bMusic)
			_AS->StopMusic();


	bLevelComplete = FALSE;
	if(pPlayer->bActive)
		SetPlayerToCheckpoint();
	else
	{ // Set the player per random into the level:
		for(i = 0; i < pLevel->iFields*10; i++)
		{
			iX = rand() % (pLevel->iWidth-1);
			iY = rand() % (pLevel->iHeight-1);
			if(!pLevel->pField[iY*pLevel->iWidth+iX].bActive ||
			   pLevel->pField[iY*pLevel->iWidth+iX].bWall ||
			   pLevel->pField[iY*pLevel->iWidth+iX].pActor)
				continue; // No good start position!!
			pPlayer->iFieldPos[X] = iX;
			pPlayer->iFieldPos[Y] = iY;
			GET_FIELD_ID(iX, iY, pPlayer->iFieldID);
			pPlayer->bActive = TRUE;
			pPlayer->byType = ACTOR_PLAYER;
			pPlayer->fColor[0] = 1.0f;
			pPlayer->fColor[1] = 1.0f;
			pPlayer->fColor[2] = 1.0f;
			pLevel->pField[pPlayer->iFieldID].pActor = pPlayer;
			PlayerInfo.iCheckpointFieldID = pPlayer->iFieldID;
		}
	}

	// Initalize some other stuff:
	g_lNow = lGameTimer = GetTickCount();
	g_lLastlooptime = g_lNow;
	SetCursorPos(X_MOUSE_SCREEN_POS, Y_MOUSE_SCREEN_POS);
	bPause = bLevelPressAnyKey = FALSE;
	fPauseBlend	= 1.0f;
	fPauseTextBlend	= 1.0f;
	iPauseBlendSpeed = 5000;
	InitDisplayActors();
	OktaActor.bActive = FALSE;

	// Camera:
	pLevel->iCurrentCameraStep = 0;
	lCameraTimer = g_lNow;
	bCameraAnimation = pLevel->bStartCamera;
	memset(&TempCamera, 0, sizeof(AS_CAMERA));
	if(pLevel->bStartCamera)
		pLevel->pCurrentCameraScript = &pLevel->pCameraScript[pLevel->iStartCamera];
	for(i = 0; i < 256; i++)
		ASKeys[i] = 0;

	if(!bEditorTestLevel)
	{	// Setup the current player stuff:
		PlayerInfo.iPoints += PlayerIdentity.iPoints[PlayerIdentity.iSelectedLevel-1];
		PlayerInfo.iLives += PlayerIdentity.iLives[PlayerIdentity.iSelectedLevel-1];
		pPlayer->fPower += PlayerIdentity.fPower[PlayerIdentity.iSelectedLevel-1];
	}
	else
	{
		pPlayer->fPower += 100.0f;
		PlayerInfo.iLives += 3;
	}
	for(i = 0; i < 256; i++)
	{
		ASKeyFirst[i] = FALSE;
		ASKeyPressed[i] = TRUE;
	}
} // end StartLevel()

void StartCurrentLevel(void)
{ // begin StartCurrentLevel()
	// Start the level:
	if(!bEditorTestLevel)
	{
		if(!bSingleLevel)
			sprintf(byCurrentLevelName, "%s%s", _AS->pbyProgramPath, CurrentCampaign.byLevelFilename[PlayerIdentity.iSelectedLevel-1]);
		else
			sprintf(byCurrentLevelName, "%s%s\\%s", _AS->pbyProgramPath, _AS->pbySingleLevelsFile, bySelectedSingleLevel);
	}
	StartLevel(byCurrentLevelName);	
} // end StartCurrentLevel()

void StartLevelMusic(void)
{ // begin StartLevelMusic()
	char byTemp[256];

	sprintf(byTemp, "%s%s", _AS->pbyProgramPath, pLevel->byMusicFile);
	_AS->LoadMusic(byTemp);
	_AS->PlayMusic(*_AS->pWindow[GAME_WINDOW_ID].GethWnd());
} // end StartLevelMusic()

void DestroyLevel(void)
{ // begin DestroyLevel()
	pLevel->DestroyTexturesOpenGL(*_AS->pWindow[GAME_WINDOW_ID].GethDC(), 
								  *_AS->pWindow[GAME_WINDOW_ID].GethRC());
	DestroyLevel(&pLevel);
} // end DestroyLevel()

void InitDisplayActors(void)
{ // begin InitDisplayActors()
	float f;
	short i;

	for(i = 0; i < DISPLAY_ACTORS; i++)
		DisplayActor[i].fSize = 1.0f;

	for(i = 0; i < DISPLAY_ACTORS; i++)
	{
		DisplayActor[i].bActive = TRUE;
		DisplayActor[i].fWorldPos[X] = -7.0f;
		DisplayActor[i].fWorldPos[Y] = 5.0f-i;
		DisplayActor[i].fWorldPos[Z] = -15.0f;
		if(i > 2)
			DisplayActor[i].fWorldPos[Y] -= 2.0f;
	}
	f = DisplayActor[HEALTH_DISPLAY].fWorldPos[Y]; 
	DisplayActor[HEALTH_DISPLAY].fWorldPos[Y] = DisplayActor[LIVE_DISPLAY].fWorldPos[Y];
	DisplayActor[LIVE_DISPLAY].fWorldPos[Y] = f;

	f = DisplayActor[POINT_DISPLAY].fWorldPos[Y]; 
	DisplayActor[POINT_DISPLAY].fWorldPos[Y] = DisplayActor[PULL_DISPLAY].fWorldPos[Y];
	DisplayActor[PULL_DISPLAY].fWorldPos[Y] = f;

	f = DisplayActor[FORCE_DISPLAY].fWorldPos[Y]; 
	DisplayActor[FORCE_DISPLAY].fWorldPos[Y] = DisplayActor[THROW_DISPLAY].fWorldPos[Y];
	DisplayActor[THROW_DISPLAY].fWorldPos[Y] = f;

	DisplayActor[TIME_DISPLAY].fWorldPos[X] = 6.0f;
	DisplayActor[TIME_DISPLAY].fWorldPos[Y] = 5.0f;
	DisplayActor[STEPS_DISPLAY].fWorldPos[X] = 6.0f;
	DisplayActor[STEPS_DISPLAY].fWorldPos[Y] = 4.0f;

	DisplayActor[WING_DISPLAY].fWorldPos[X] = 6.0f;
	DisplayActor[WING_DISPLAY].fWorldPos[Y] = 0.0f;
	DisplayActor[SHIELD_DISPLAY].fWorldPos[X] = 6.0f;
	DisplayActor[SHIELD_DISPLAY].fWorldPos[Y] = -1.0f;
	DisplayActor[JUMP_DISPLAY].fWorldPos[X] = 6.0f;
	DisplayActor[JUMP_DISPLAY].fWorldPos[Y] = -2.0f;
} // end InitDisplayActors()

void OpenHelp(void)
{ // begin OpenHelp()
	char byTemp[256];

	_AS->WriteLogMessage("Open help file");
	sprintf(byTemp, "%s%s", _AS->pbyProgramPath, T_HelpFile);
	ShellExecute(0, "open", byTemp, 0, 0, SW_SHOW);
} // end OpenHelp()

//-----------------------------------------------------------------------------
// File: GameMenu.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
BOOL bInGameMenu;
AS_TEXTURE GameMenuTexture[GAME_MENU_TEXTURES];
short iGameMenuBackgroundAniStep;
long lGameMenuBackgroundAniTimer, lPressNewKeyTimer;
long lBackFlashTime, lBackFlashTimeDelay, lLastGameMenuKeyTime;
float fBackFlash, fBackFlashDelta, fCurrentBackFlash, fLastBackFlash;
char byGameMenuSelected, byGameMenuMenu;
char **pbySingleLevels; // The found single level names
short iSingleLevels;   // The number of found single player levels
char **pbyCampaign; // The found campaigns names
short iCampaigns;   // The number of found campaigns
char **pbyPlayerID; // The found player ID's
short iPlayerIDs; // The number of found player ID's
BOOL bGetPlayerName, // Does the player give in his name?
     bGetNewKey, // Does we wait for a new key definition?
	 bPressNewKeyText;
char byGetPlayerName[256]; // The players name
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
HRESULT GameMenuLoop(void);
void StartMenuMusic(void);
HRESULT GameMenuDraw(AS_WINDOW *);
HRESULT GameMenuCheck(AS_WINDOW *);
void LoadGameMenuTextures(void);
void DestroyGameMenuTextures(void);
void GenOpenGLGameMenuTextures(void);
void DestroyOpenGLGameMenuTextures(void);
void EnumerateSingleLevels(void);
void DestroySingleLevelList(void);
void EnumerateCampaigns(void);
void DestroyCampaignsList(void);
void EnumeratePlayerIDs(void);
void DestroyPlayerIDList(void);
///////////////////////////////////////////////////////////////////////////////
void InitGalaxy(void);
void DrawGalaxy(void);
void DrawStar(float);
///////////////////////////////////////////////////////////////////////////////


HRESULT GameMenuLoop(void)
{ // begin GameMenuLoop()
	MSG msg;
	short i;

	_AS->pWindow[GAME_WINDOW_ID].SetDrawFunction(GameMenuDraw);
	_AS->pWindow[GAME_WINDOW_ID].SetCheckFunction(GameMenuCheck);

	InitGalaxy();;
	LoadGameMenuTextures();
	GenOpenGLGameMenuTextures();
	StartMenuMusic();
	
	bEditorTestLevel = FALSE;
	byGameMenuMenu = 0;
	iGameMenuBackgroundAniStep = byGameMenuSelected = 0;
	lGameMenuBackgroundAniTimer = lBackFlashTime = lLastGameMenuKeyTime = g_lNow;

	// Go into the game menu loop:
	_AS->WriteLogMessage("Enter the game menu loop");
	for(;;)
	{
		if(PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
    	{
        	if(!GetMessage(&msg, NULL, 0, 0))
                break;
        	TranslateMessage(&msg);
        	DispatchMessage(&msg);
    	}
		else
		{	
			if(_AS->GetShutDown() || _AS->CheckModuleChange() || !bInGameMenu)
				PostQuitMessage(0);
			if(!_AS->GetActive())
			{
				pPlayer->dwAniTime = g_lNow;
				for(i = 0; i < MAX_ACTORS; i++)
					Actor[i].dwAniTime = g_lNow;
				continue;
			}
			_AS->UpdateWindows();
		}
	}
	_AS->WriteLogMessage("Left the game menu loop");

	DestroySingleLevelList();
	DestroyCampaignsList();
	DestroyPlayerIDList();
	DestroyOpenGLGameMenuTextures();
	DestroyGameMenuTextures();

	return msg.wParam;
} // end GameMenuLoop()

void StartMenuMusic(void)
{ // begin StartMenuMusic()
	AS_PROGRESS_WINDOW ProgressWindow;
	char byTemp[256];

	ProgressWindow.CreateProgressWindow("Loading");
	ProgressWindow.SetTask("Load music...");
	ProgressWindow.SetProgress(0);
	// Play the menu music:
	sprintf(byTemp, "%s%s\\Missing.mid", _AS->pbyProgramPath, _AS->pbyMusicFile);
	_AS->WriteLogMessage("Load music: %s", byTemp);
	_AS->LoadMusic(byTemp);
	_AS->PlayMusic(*_AS->pWindow[GAME_WINDOW_ID].GethWnd());
} // end StartMenuMusic()

HRESULT GameMenuDraw(AS_WINDOW *pWindow)
{ // begin GameMenuMenu()
	short iX, iY, i;
	float fX, fY, fSize;
//	char byTemp[256];

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glDisable(GL_FOG);
	glDisable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_DEPTH_TEST);
	
	// Draw the galaxy:
	glEnable(GL_BLEND);
	glColor4f(1.0f, 1.0f, 1.0f, 0.99f);
	glBlendFunc(GL_ONE, GL_ONE);
	DrawGalaxy();
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);

	// Draw the water background:
	// Calculate the current frame:
	iY = (short) iGameMenuBackgroundAniStep/7;
	iX = iGameMenuBackgroundAniStep-iY*7;
	fX = (float) (1+65*iX)/512;
	fY = (float) (1+65*iY)/512;
	fSize = 0.125f;
	glColor4f(fCurrentBackFlash, fCurrentBackFlash, 0.5f+fCurrentBackFlash, 0.5f);
	glEnable(GL_BLEND);
	glLoadIdentity();
	glTranslatef(0.0f, 0.0f, -34.0f);
	glBindTexture(GL_TEXTURE_2D, GameMenuTexture[0].iOpenGLID);
	glBegin(GL_QUADS);
		glNormal3f( 0.0f, 0.0f, 1.0f);
		glTexCoord2f(fX, fY); glVertex3f(-15.0f, -11.0f, 10.0f);
		glTexCoord2f(fX+fSize, fY); glVertex3f(15.0f, -11.0f, 10.0f);
		glTexCoord2f(fX+fSize, fY+fSize); glVertex3f(15.0f, 11.0f, 10.0f);
		glTexCoord2f(fX, fY+fSize); glVertex3f(-15.0f, 11.0f, 10.0f);
	glEnd();

	glColor4f(fCurrentBackFlash-0.3f, fCurrentBackFlash-0.3f, 0.2f+fCurrentBackFlash, 0.4f);
	glBlendFunc(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);
	switch(byGameMenuMenu)
	{
		case 0: // Main menu background:
			glBegin(GL_QUADS);
				glNormal3f(0.0f, 0.0f, 1.0f);
				glTexCoord2f(fX, fY); glVertex3f(-4.0f, -7.5f, 10.0f);
				glTexCoord2f(fX+fSize, fY); glVertex3f(5.0f, -7.5f, 10.0f);
				glTexCoord2f(fX+fSize, fY+fSize); glVertex3f(5.0f, 1.0f, 10.0f);
				glTexCoord2f(fX, fY+fSize); glVertex3f(-4.0f, 1.0f, 10.0f);
			glEnd();

			// The info bar:
			glBegin(GL_QUADS);
				glNormal3f(0.0f, 0.0f, 1.0f);
				glTexCoord2f(fX, fY); glVertex3f(-14.0f, -10.0f, 10.0f);
				glTexCoord2f(fX+fSize, fY); glVertex3f(14.0f, -10.0f, 10.0f);
				glTexCoord2f(fX+fSize, fY+fSize); glVertex3f(14.0f, -9.0f, 10.0f);
				glTexCoord2f(fX, fY+fSize); glVertex3f(-14.0f, -9.0f, 10.0f);
			glEnd();
		break;

		case 6: // The options menu:
			glBegin(GL_QUADS);
				glNormal3f(0.0f, 0.0f, 1.0f);
				glTexCoord2f(fX, fY); glVertex3f(-6.0f, -3.0f, 10.0f);
				glTexCoord2f(fX+fSize, fY); glVertex3f(5.0f, -3.0f, 10.0f);
				glTexCoord2f(fX+fSize, fY+fSize); glVertex3f(5.0f, 1.0f, 10.0f);
				glTexCoord2f(fX, fY+fSize); glVertex3f(-6.0f, 1.0f, 10.0f);
			glEnd();
		break;

		case 7: // Keys setup menu:
			glBegin(GL_QUADS);
				glNormal3f(0.0f, 0.0f, 1.0f);
				glTexCoord2f(fX, fY); glVertex3f(-5.0f, -8.5f, 10.0f);
				glTexCoord2f(fX+fSize, fY); glVertex3f(6.0f, -8.5f, 10.0f);
				glTexCoord2f(fX+fSize, fY+fSize); glVertex3f(6.0f, 2.0f, 10.0f);
				glTexCoord2f(fX, fY+fSize); glVertex3f(-5.0f, 2.0f, 10.0f);
			glEnd();
		break;

		default:
			glBegin(GL_QUADS);
				glNormal3f(0.0f, 0.0f, 1.0f);
				glTexCoord2f(fX, fY); glVertex3f(-14.0f, -10.0f, 10.0f);
				glTexCoord2f(fX+fSize, fY); glVertex3f(14.0f, -10.0f, 10.0f);
				glTexCoord2f(fX+fSize, fY+fSize); glVertex3f(14.0f, 1.0f, 10.0f);
				glTexCoord2f(fX, fY+fSize); glVertex3f(-14.0f, 1.0f, 10.0f);
			glEnd();
		break;
	}

	glBlendFunc(GL_SRC_ALPHA, GL_ONE);

	// Draw the game title:
	glEnable(GL_BLEND);
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	glLoadIdentity();
	glTranslatef(-1.0f, 0.7f, -1.8f);
	glCallList(iGameTitleList);

	glEnable(GL_BLEND);

	// Draw the options:
	// Menu name:
	glColor3f(1.0f, 1.0f, 1.0f);	
	pWindow->glPrint(560, 300, GAME_VERSION, 0);

	switch(byGameMenuMenu)
	{
		case 0: // Main menu:
			pWindow->glPrint(0, 5, "A game by AblazeSpace 2001                 All rights reserved!", 1);
		
			pWindow->glPrint(250, 230, T_MainMenu, 0);
			// Start game:
			glColor3f(1.0f, 1.0f, 1.0f);	
			if(byGameMenuSelected == 0)
				glColor3f(1.0f, 0.0f, 0.0f);
			pWindow->glPrint(250, 200, T_StartGame, 0);
			
			// Continue game:
			glColor3f(1.0f, 1.0f, 1.0f);	
			if(byGameMenuSelected == 1)
				glColor3f(1.0f, 0.0f, 0.0f);
			pWindow->glPrint(250, 180, T_ContinueGame, 0);

			// Single level:
			glColor3f(1.0f, 1.0f, 1.0f);	
			if(byGameMenuSelected == 2)
				glColor3f(1.0f, 0.0f, 0.0f);
			pWindow->glPrint(250, 160, T_SingleLevel, 0);

			// Editor:
			glColor3f(1.0f, 1.0f, 1.0f);	
			if(byGameMenuSelected == 3)
				glColor3f(1.0f, 0.0f, 0.0f);
			pWindow->glPrint(250, 140, T_Editor, 0);

			// Options:
			glColor3f(1.0f, 1.0f, 1.0f);	
			if(byGameMenuSelected == 4)
				glColor3f(1.0f, 0.0f, 0.0f);
			pWindow->glPrint(250, 120, T_Options, 0);

			// Help:
			glColor3f(1.0f, 1.0f, 1.0f);	
			if(byGameMenuSelected == 5)
				glColor3f(1.0f, 0.0f, 0.0f);
			pWindow->glPrint(250, 100, T_Help, 0);

			// Quit:
			glColor3f(1.0f, 1.0f, 1.0f);	
			if(byGameMenuSelected == 6)
				glColor3f(1.0f, 0.0f, 0.0f);
			pWindow->glPrint(250, 80, T_Quit, 0);
		break;

		case 1: // Select single level:
			pWindow->glPrint(10, 230, T_SingleLevel, 0);
			glColor3f(1.0f, 0.0f, 0.0f);	
			for(i = byGameMenuSelected-5, iY = 200; i < byGameMenuSelected+11; i++)
			{
				if(i < 0)
					continue;
				if(i >= iSingleLevels)
					break;
				glColor3f(1.0f, 1.0f, 1.0f);	
				if(i == byGameMenuSelected)
					glColor3f(1.0f, 0.0f, 0.0f);	
				pWindow->glPrint(10, iY, pbySingleLevels[i], 0);
				iY -= 20;
			}
		break;

		case 2: // Select campaign:
			pWindow->glPrint(10, 230, T_SelectCampaign, 0);
			for(i = byGameMenuSelected-5, iY = 200; i < byGameMenuSelected+11; i++)
			{
				if(i < 0)
					continue;
				if(i >= iCampaigns)
					break;
				glColor3f(1.0f, 1.0f, 1.0f);	
				if(i == byGameMenuSelected)
					glColor3f(1.0f, 0.0f, 0.0f);	
				pWindow->glPrint(10, iY, pbyCampaign[i], 0);
				iY -= 20;
			}
		break;

		case 3: // Select player ID:
			pWindow->glPrint(10, 230, T_SelectYourID, 0);
			for(i = byGameMenuSelected-5, iY = 200; i < byGameMenuSelected+11; i++)
			{
				if(i < 0)
					continue;
				if(i >= iPlayerIDs)
					break;
				if(i == byGameMenuSelected)
					glColor3f(1.0f, 0.0f, 0.0f);	
				pWindow->glPrint(10, iY, pbyPlayerID[i], 0);
				glColor3f(1.0f, 1.0f, 1.0f);	
				iY -= 20;
			}
		break;

		case 4: // Select level of the selected campaign:
			pWindow->glPrint(10, 230, T_SelectLevel, 0);
			for(i = byGameMenuSelected-5, iY = 200; i < byGameMenuSelected+11; i++)
			{
				if(i < 0)
					continue;
				if(i >= PlayerIdentity.iFinishedLevels+1 || !pbyCampaignLevelNames || i >= CurrentCampaign.iLevels || !pbyCampaignLevelNames[i])
					break;
				if(i == byGameMenuSelected)
					glColor3f(1.0f, 0.0f, 0.0f);	
				pWindow->glPrint(10, iY, pbyCampaignLevelNames[i], 0);
				glColor3f(1.0f, 1.0f, 1.0f);
				iY -= 20;
			}
		break;

		case 5: // Select player ID or create a new one:
			pWindow->glPrint(10, 230, T_SelectYourID, 0);
			for(i = byGameMenuSelected-5, iY = 200; i < byGameMenuSelected+11; i++)
			{
				if(i < 0)
					continue;
				if(i >= iPlayerIDs)
				{
					if(i == byGameMenuSelected)
						glColor3f(1.0f, 0.0f, 0.0f);	
					if(!bGetPlayerName)
						pWindow->glPrint(10, iY, T_CreateANewPlayerID, 0);
					else
					{ // The player gives in his name:
						pWindow->glPrint(10, iY, byGetPlayerName, 0);
					}
					break;
				}
				if(i == byGameMenuSelected)
					glColor3f(1.0f, 0.0f, 0.0f);	
				pWindow->glPrint(10, iY, pbyPlayerID[i], 0);
				glColor3f(1.0f, 1.0f, 1.0f);	
				iY -= 20;
			}
		break;

		case 6: // Options:
			pWindow->glPrint(200, 230, T_Options, 0);
			// Set keys:
			glColor3f(1.0f, 1.0f, 1.0f);	
			if(byGameMenuSelected == 0)
				glColor3f(1.0f, 0.0f, 0.0f);
			pWindow->glPrint(200, 200, T_KeysSetup, 0);
			// Other Options:
			glColor3f(1.0f, 1.0f, 1.0f);	
			if(byGameMenuSelected == 1)
				glColor3f(1.0f, 0.0f, 0.0f);
			pWindow->glPrint(200, 180, T_OtherOptions, 0);
		break;

		case 7: // Keys setup:
			pWindow->glPrint(220, 260, T_KeysSetup, 0);
			// Left:
			glColor3f(1.0f, 1.0f, 1.0f);	
			if(byGameMenuSelected == 0)
				glColor3f(1.0f, 0.0f, 0.0f);
			pWindow->glPrint(220, 230, T_Left, 0);
			// Right:
			glColor3f(1.0f, 1.0f, 1.0f);	
			if(byGameMenuSelected == 1)
				glColor3f(1.0f, 0.0f, 0.0f);
			pWindow->glPrint(220, 217, T_Right, 0);
			// Up:
			glColor3f(1.0f, 1.0f, 1.0f);	
			if(byGameMenuSelected == 2)
				glColor3f(1.0f, 0.0f, 0.0f);
			pWindow->glPrint(220, 204, T_Up, 0);
			// Down:
			glColor3f(1.0f, 1.0f, 1.0f);	
			if(byGameMenuSelected == 3)
				glColor3f(1.0f, 0.0f, 0.0f);
			pWindow->glPrint(220, 191, T_Down, 0);
			// Shot:
			glColor3f(1.0f, 1.0f, 1.0f);	
			if(byGameMenuSelected == 4)
				glColor3f(1.0f, 0.0f, 0.0f);
			pWindow->glPrint(220, 178, T_Shot, 0);
			// Throw:
			glColor3f(1.0f, 1.0f, 1.0f);	
			if(byGameMenuSelected == 5)
				glColor3f(1.0f, 0.0f, 0.0f);
			pWindow->glPrint(220, 165, T_ThrowObj, 0);
			// Pull:
			glColor3f(1.0f, 1.0f, 1.0f);	
			if(byGameMenuSelected == 6)
				glColor3f(1.0f, 0.0f, 0.0f);
			pWindow->glPrint(220, 152, T_PullObj, 0);
			// Suicide:
			glColor3f(1.0f, 1.0f, 1.0f);	
			if(byGameMenuSelected == 7)
				glColor3f(1.0f, 0.0f, 0.0f);
			pWindow->glPrint(220, 139, T_Suicide, 0);
			// Jump:
			glColor3f(1.0f, 1.0f, 1.0f);	
			if(byGameMenuSelected == 8)
				glColor3f(1.0f, 0.0f, 0.0f);
			pWindow->glPrint(220, 126, T_Jump, 0);
			// Level restart:
			glColor3f(1.0f, 1.0f, 1.0f);	
			if(byGameMenuSelected == 9)
				glColor3f(1.0f, 0.0f, 0.0f);
			pWindow->glPrint(220, 113, T_LevelRestart, 0);
			// Change perspective:
			glColor3f(1.0f, 1.0f, 1.0f);	
			if(byGameMenuSelected == 10)
				glColor3f(1.0f, 0.0f, 0.0f);
			pWindow->glPrint(220, 100, T_ChangePerspective, 0);
			// Back camera:
			glColor3f(1.0f, 1.0f, 1.0f);	
			if(byGameMenuSelected == 11)
				glColor3f(1.0f, 0.0f, 0.0f);
			pWindow->glPrint(220, 87, T_BackCamera, 0);
			// Pause:
			glColor3f(1.0f, 1.0f, 1.0f);	
			if(byGameMenuSelected == 12)
				glColor3f(1.0f, 0.0f, 0.0f);
			pWindow->glPrint(220, 74, T_Pause, 0);
			// Standart view:
			glColor3f(1.0f, 1.0f, 1.0f);	
			if(byGameMenuSelected == 13)
				glColor3f(1.0f, 0.0f, 0.0f);
			pWindow->glPrint(220, 61, T_StandartView, 0);
			// Standart configuration:
			glColor3f(1.0f, 1.0f, 1.0f);	
			if(byGameMenuSelected == 14)
				glColor3f(1.0f, 0.0f, 0.0f);
			pWindow->glPrint(220, 40, T_StandartConfiguration, 0);
			if(bGetNewKey && bPressNewKeyText)
			{
				glColor3f(1.0f, 1.0f, 1.0f);	
				pWindow->glPrint(220, 10, T_PressNewKey, 0);
			}
		break;
	}

//	sprintf(byTemp, "X: %f   Y:%f     Z:$f", fMousePos[X], fMousePos[Y], fMousePos[Z]);
//	pWindow->glPrint(200, 130, byTemp, 0);

	ASSwapBuffers(*pWindow->GethDC(), pWindow, TRUE);
	return 0;
} // end GameMenuMenu()

HRESULT GameMenuCheck(AS_WINDOW *pWindow)
{ // begin GameMenuCheck()
	short i;
	USHORT iKey;
	char byTemp[256];
	float fDelta;
	
	_AS->ReadDXInput(*pWindow->GethWnd());
// Keys:
	if(ASKeyFirst[DIK_F1])
	{ // Open the help file:
	Help:
		if(_ASConfig->bFullScreen)
		{ // Switch to window mode:
			_ASConfig->bFullScreen = FALSE;
			ChangeDisplayMode();
		}
		OpenHelp();
		return 0;
	}
	if(ASKeyFirst[DIK_F12])
	{ // Open the configuration menu:
		SendMessage(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), WM_COMMAND, ID_OPTIONS_CONFIG, 0);
	}

	// The select keys:
	if(!bGetPlayerName && !bGetNewKey)
	{
		if(ASKeyFirst[DIK_UP])
			byGameMenuSelected--;
		if(ASKeyFirst[DIK_DOWN])
			byGameMenuSelected++;
	}
	switch(byGameMenuMenu)
	{
		case 0: // Main menu:
			if(byGameMenuSelected < 0)
				byGameMenuSelected = 6;
			else
				if(byGameMenuSelected >= 7)
					byGameMenuSelected = 0;
			if(ASKeyFirst[DIK_ESCAPE])
				_AS->SetShutDown(TRUE);
			if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
			{ // Check what the player has selected:
				switch(byGameMenuSelected)
				{
					case 0: // New game:
						EnumerateCampaigns();
						if(!iCampaigns)
						{ // There is no campaign!!
							_AS->WriteLogMessage("There is no campaign!");
							break;
						}
						byGameMenuMenu = 2;
						byGameMenuSelected = 0;
					break;

					case 1: // Continue game:
						EnumeratePlayerIDs();
						if(!iPlayerIDs)
						{ // There is no player ID!!
							_AS->WriteLogMessage("There is no player ID!");
							break;
						}
						byGameMenuMenu = 3;
						byGameMenuSelected = 0;
					break;

					case 2: // Single level:
						EnumerateSingleLevels();
						if(!iSingleLevels)
						{ // There is no single level!!
							_AS->WriteLogMessage("There is no single level!");
							break;
						}
						byGameMenuMenu = 1;
						byGameMenuSelected = 0;
					break;

					case 3: // Editor:
						_AS->SetNextModule(MODULE_EDITOR);
					break;

					case 4: // Options:
						byGameMenuMenu = 6;
						byGameMenuSelected = 0;
					break;

					case 5: // Help:
						goto Help;

					case 6: // Quit:
						_AS->SetShutDown(TRUE);
					break;
				}
			}
		break;

		case 1: // Select a single level:
			if(byGameMenuSelected < 0)
				byGameMenuSelected = iSingleLevels-1;
			else
				if(byGameMenuSelected >= iSingleLevels)
					byGameMenuSelected = 0;
			if(ASKeyFirst[DIK_ESCAPE])
			{
				byGameMenuSelected = 0;
				byGameMenuMenu = 0;
				break;
			}
			if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
			{ // Check what the player has selected:
				// Start the selected single level:
				bInGameMenu = FALSE;
				bSingleLevel = TRUE;
				CurrentCampaign.iLevels = 1;
				strcpy(bySelectedSingleLevel, pbySingleLevels[byGameMenuSelected]);
				CreateNewPlayerInfo(&PlayerIdentity, &CurrentCampaign);
			}
		break;

		case 2: // Select campaign:
			if(byGameMenuSelected < 0)
				byGameMenuSelected = iCampaigns-1;
			else
				if(byGameMenuSelected >= iCampaigns)
					byGameMenuSelected = 0;
			if(ASKeyFirst[DIK_ESCAPE])
			{
				byGameMenuSelected = 0;
				byGameMenuMenu = 0;
				break;
			}
			if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
			{ // Check what the player has selected:
				// Load the campaign:
				sprintf(byTemp, "%s%s\\%s\\%s.cam", _AS->pbyProgramPath, _AS->pbyCampaignsFile, pbyCampaign[byGameMenuSelected],
													pbyCampaign[byGameMenuSelected]);
				if(LoadCampaign(&CurrentCampaign, byTemp))
				{
					_AS->WriteLogMessage("Couldn't open %s!", byTemp);
					break;
				}
				// Go sure that there is the right campaign name:
				strcpy(CurrentCampaign.byName, pbyCampaign[byGameMenuSelected]);
				byGameMenuMenu = 5;
				byGameMenuSelected = 0;
				EnumeratePlayerIDs();
				bGetPlayerName = FALSE;
			}
		break;

		case 3: // Select player ID:
			if(byGameMenuSelected < 0)
				byGameMenuSelected = iPlayerIDs-1;
			else
				if(byGameMenuSelected >= iPlayerIDs)
					byGameMenuSelected = 0;
			if(ASKeyFirst[DIK_ESCAPE])
			{
				byGameMenuSelected = 0;
				byGameMenuMenu = 0;
				break;
			}
			if(ASKeyFirst[DIK_DELETE])
			{ // Delete the selected ID:
				_AS->WriteLogMessage("Delete player ID: %s", PlayerIdentity.byName);
				sprintf(byTemp, "%s%s\\%s.id", _AS->pbyProgramPath, _AS->pbyIdentityFile, pbyPlayerID[byGameMenuSelected]);
				remove(byTemp);
				EnumeratePlayerIDs();
				if(!iPlayerIDs)
					byGameMenuMenu = 0;
				byGameMenuSelected = 0;
			}
			if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
			{ // Check what the player has selected:
				// Load the player ID:
				DestroyCampaign(&CurrentCampaign);
				LoadPlayerIdentity(pbyPlayerID[byGameMenuSelected], &PlayerIdentity, &CurrentCampaign);
				sprintf(byTemp, "%s%s\\%s\\%s.cam", _AS->pbyProgramPath, _AS->pbyCampaignsFile, PlayerIdentity.byCampaignName, PlayerIdentity.byCampaignName);
				if(LoadCampaign(&CurrentCampaign, byTemp))
				{
					_AS->WriteLogMessage("Couldn't open %s!", byTemp);
					break;
				}
				// Setup now the final player identity:
				LoadPlayerIdentity(pbyPlayerID[byGameMenuSelected], &PlayerIdentity, &CurrentCampaign);
				byGameMenuSelected = (char) PlayerIdentity.iFinishedLevels;
				byGameMenuMenu = 4;
			}
		break;

		case 4: // Select level of the selected campaign:
			if(byGameMenuSelected < 0)
				byGameMenuSelected = (char) PlayerIdentity.iFinishedLevels;
			else
				if(byGameMenuSelected >= PlayerIdentity.iFinishedLevels+1)
					byGameMenuSelected = 0;
			if(ASKeyFirst[DIK_ESCAPE])
			{
				byGameMenuSelected = 0;
				byGameMenuMenu = 0;
				byGameMenuMenu = 3;
				break;
			}
			if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
			{ // Check what the player has selected:
				// Start the selected level:
				PlayerIdentity.iSelectedLevel = byGameMenuSelected+1;
				bInGameMenu = FALSE;
				bSingleLevel = FALSE;
			}
		break;

		case 5: // Select player ID or create a new one:
			if(byGameMenuSelected < 0)
				byGameMenuSelected = (char) iPlayerIDs;
			else
				if(byGameMenuSelected >= iPlayerIDs+1)
					byGameMenuSelected = 0;
			if(bGetPlayerName)
			{
				if(strlen(byGetPlayerName) < PLAYER_NAME_LENGTH-1)
				{
					for(i = 0; i < 256; i++)
					{
						if(ASKeyFirst[i])
						{
							ConvertScancodeToASCII(i, &iKey);
							sprintf(byGetPlayerName, "%s%c", byGetPlayerName, iKey);
						}
					}
				}
				if(ASKeyFirst[DIK_BACK] && strlen(byGetPlayerName) > 1)
					byGetPlayerName[strlen(byGetPlayerName)-2] = '\0';
				if(ASKeyFirst[DIK_ESCAPE])
					bGetPlayerName = FALSE;
				if(ASKeyFirst[DIK_RETURN])
				{ // Get the player name:
					bGetPlayerName = FALSE;
					byGetPlayerName[strlen(byGetPlayerName)-1] = '\0';
					// Create a new player identity:
					CreateNewPlayerInfo(&PlayerIdentity, &CurrentCampaign);
					strcpy(PlayerIdentity.byName, byGetPlayerName);
					SavePlayerIdentity(&PlayerIdentity, &CurrentCampaign);
					EnumeratePlayerIDs();
					for(byGameMenuSelected = 0;; byGameMenuSelected++)
					{
						if(!strcmp(PlayerIdentity.byName, byGetPlayerName))
							break;
					}
					goto StartSelectedCampaign;
				}
			}
			else
			{
				if(ASKeyFirst[DIK_ESCAPE])
				{
					byGameMenuSelected = 0;
					byGameMenuMenu = 2;
					bGetPlayerName = FALSE;
					break;
				}
				if(ASKeyFirst[DIK_DELETE] && iPlayerIDs > byGameMenuSelected)
				{ // Delete the selected ID:
					_AS->WriteLogMessage("Delete player ID: %s", PlayerIdentity.byName);
					sprintf(byTemp, "%s%s\\%s.id", _AS->pbyProgramPath, _AS->pbyIdentityFile, pbyPlayerID[byGameMenuSelected]);
					remove(byTemp);
					EnumeratePlayerIDs();
					byGameMenuSelected = 0;
				}
				if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
				{ // Check what the player has selected:
					// Load the player ID:
					if(iPlayerIDs <= byGameMenuSelected)
					{ // Create a new player ID:
						bGetPlayerName = TRUE;
						strcpy(byGetPlayerName, "");
						break;
					}
					else
					{ // Use a old player ID:
						LoadPlayerIdentity(pbyPlayerID[byGameMenuSelected], &PlayerIdentity, &CurrentCampaign);
						strcpy(byGetPlayerName, PlayerIdentity.byName);
						DestroyPlayerInfo(&PlayerIdentity);
						CreateNewPlayerInfo(&PlayerIdentity, &CurrentCampaign);
						strcpy(PlayerIdentity.byName, byGetPlayerName);
					}
				StartSelectedCampaign:
					// Start the selected campaign:
					bInGameMenu = FALSE;
					bSingleLevel = FALSE;
				}
			}
		break;

		case 6: // Options:
			if(byGameMenuSelected < 0)
				byGameMenuSelected = 1;
			else
				if(byGameMenuSelected >= 2)
					byGameMenuSelected = 0;
			if(ASKeyFirst[DIK_ESCAPE])
			{
				byGameMenuSelected = 0;
				byGameMenuMenu = 0;
				break;
			}
			if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
			{ // Check what the player has selected:
				ASKeyFirst[DIK_SPACE] = ASKeyFirst[DIK_RETURN] = FALSE;
				switch(byGameMenuSelected)
				{
					case 0: // Setup keys
						byGameMenuSelected = 0;
						byGameMenuMenu = 7;
						bGetNewKey = FALSE;
					break;

					case 1: // Other options
						SendMessage(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), WM_COMMAND, ID_OPTIONS_CONFIG, 0);
					break;
				}
			}
		break;

		case 7: // Setup keys:
			if(byGameMenuSelected < 0)
				byGameMenuSelected = 14;
			else
				if(byGameMenuSelected >= 15)
					byGameMenuSelected = 0;
			if(ASKeyFirst[DIK_ESCAPE])
			{
				if(bGetNewKey)
					bGetNewKey = FALSE;
				else
				{
					byGameMenuSelected = 0;
					byGameMenuMenu = 6;
				}
				break;
			}
			if(bGetNewKey)
			{
				for(i = 0; i < 256; i++)
				{
					if(!ASKeyFirst[i])
						continue;
					// Set the new key:
					switch(byGameMenuSelected)
					{
						case 0: _ASConfig->iLeftKey = i; break;
						case 1: _ASConfig->iRightKey = i; break;
						case 2: _ASConfig->iUpKey = i; break;
						case 3: _ASConfig->iDownKey = i; break;
						case 4: _ASConfig->iShotKey = i; break;
						case 5: _ASConfig->iThrowKey = i; break;
						case 6: _ASConfig->iPullKey = i; break;
						case 7: _ASConfig->iSuicideKey = i; break;
						case 8: _ASConfig->iJumpKey = i; break;
						case 9: _ASConfig->iLevelRestartKey = i; break;
						case 10: _ASConfig->iChangePerspectiveKey = i; break;
						case 11: _ASConfig->iBackCameraKey = i; break;
						case 12: _ASConfig->iPauseKey = i; break;
						case 13: _ASConfig->iStandartViewKey = i; break;
					}
					bGetNewKey = FALSE;
				}
			}
			else
			{
				if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
				{ // Check what the player has selected:
					if(byGameMenuSelected == 14)
					{ // Set all key to standart:
						_ASConfig->iLeftKey = STANDART_LEFT_KEY;
						_ASConfig->iRightKey = STANDART_RIGHT_KEY;
						_ASConfig->iUpKey = STANDART_UP_KEY;
						_ASConfig->iDownKey = STANDART_DOWN_KEY;
						_ASConfig->iShotKey = STANDART_SHOT_KEY;
						_ASConfig->iThrowKey = STANDART_THROW_KEY;
						_ASConfig->iPullKey = STANDART_PULL_KEY;
						_ASConfig->iSuicideKey = STANDART_SUICIDE_KEY;
						_ASConfig->iJumpKey = STANDART_JUMP_KEY;
						_ASConfig->iLevelRestartKey = STANDART_LEVEL_RESTART_KEY;
						_ASConfig->iChangePerspectiveKey = STANDART_CHANGE_PERSPECTIVE_KEY;
						_ASConfig->iBackCameraKey = STANDART_BACK_CAMERA_KEY;
						_ASConfig->iPauseKey = STANDART_PAUSE_KEY;
						_ASConfig->iStandartViewKey = STANDART_STANDART_VIEW_KEY;
					}
					else // Get the new key:
						bGetNewKey = TRUE;
				}
			}
		break;
	}

	if(g_lNow-lPressNewKeyTimer > 500)
	{
		lPressNewKeyTimer = g_lNow;
		bPressNewKeyText = !bPressNewKeyText;
	}
	// Animate the background:
	if(g_lNow-lGameMenuBackgroundAniTimer > 70)
	{ // Go to the next animation step:
		lGameMenuBackgroundAniTimer = g_lNow;
		iGameMenuBackgroundAniStep++;
		if(iGameMenuBackgroundAniStep >= 32)
			iGameMenuBackgroundAniStep = 0;
	}
	// Change the color of the background:
	if((g_lNow-lBackFlashTime) > lBackFlashTimeDelay)
	{
		lBackFlashTime = g_lNow;
		lBackFlashTimeDelay = rand() % 500+300;
		fLastBackFlash = fBackFlash;
		fBackFlash = (float) (rand() % 50)/100.0f;
		fBackFlashDelta = fBackFlash-fLastBackFlash;
	}
	fDelta = ((float) (g_lNow-lBackFlashTime+1)/lBackFlashTimeDelay);
	if(fDelta < 0.0f)
		fDelta = -fDelta;
	if(fBackFlash > fLastBackFlash)
		fCurrentBackFlash = (float) fLastBackFlash+fBackFlashDelta*fDelta;
	else
		fCurrentBackFlash = (float) fLastBackFlash+fBackFlashDelta*fDelta;

	return 0;
} // end GameMenuCheck()

void LoadGameMenuTextures(void)
{ // begin LoadGameMenuTextures()
	char byFilename[GAME_MENU_TEXTURES][256] = {"Water.jpg",
												"G_Particle1.jpg", "G_Particle2.jpg",
												"G_Cloud.jpg"},
		 byTemp[256];
	AS_PROGRESS_WINDOW ProgressWindow;
	short i;

	_AS->WriteLogMessage("Load game menu textures");
	ProgressWindow.CreateProgressWindow("Loading");
	ProgressWindow.SetTask("Game menu textures...");
	ProgressWindow.SetProgress(0);
	for(i = 0; i < GAME_MENU_TEXTURES; i++)
	{
		sprintf(byTemp, "%s%s\\%s", _AS->pbyProgramPath, _AS->pbyBitmapsFile, byFilename[i]);
		_AS->WriteLogMessage("Load bitmap: %s", byTemp);
		strcpy(GameMenuTexture[i].byFilename, byTemp);
		ProgressWindow.SetSubTask(byTemp);
 		ProgressWindow.SetProgress((UINT) (((float) i/GAME_MENU_TEXTURES)*100));
		ASLoadJpegRGB(&GameMenuTexture[i], byTemp);
		_AS->WriteLogMessage("OK", byTemp);
	}
} // begin LoadGameMenuTextures()

void DestroyGameMenuTextures(void)
{ // begin DestroyGameMenuTextures()
	for(short i = 0; i < GAME_MENU_TEXTURES; i++)
		free(GameMenuTexture[i].pbyData);
} // end DestroyGameMenuMenuTextures()

void GenOpenGLGameMenuTextures(void)
{ // begin GenOpenGLGameMenuTextures()
	AS_PROGRESS_WINDOW ProgressWindow;

	_AS->WriteLogMessage("Generate OpenGL main menu textures");
	if(!bInGameMenu)
		return; // We are not in the game menu!
	ProgressWindow.CreateProgressWindow("Loading menu");
	ProgressWindow.SetTask("Generate OpenGL menu textures...");
	ProgressWindow.SetProgress(0);
	for(short i = 0; i < GAME_MENU_TEXTURES; i++)
	{
		_AS->WriteLogMessage("Generate bitmap: %s", GameMenuTexture[i].byFilename);
		ProgressWindow.SetSubTask("%s", GameMenuTexture[i].byFilename);
		ProgressWindow.SetProgress((UINT) (((float) i/GAME_MENU_TEXTURES)*100));
		glGenTextures(1, &GameMenuTexture[i].iOpenGLID);
		glBindTexture(GL_TEXTURE_2D, GameMenuTexture[i].iOpenGLID);
		if(_ASConfig->bUseMipmaps)
		{
			if(_ASConfig->bFastTexturing)
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST_MIPMAP_NEAREST);
				gluBuild2DMipmaps(GL_TEXTURE_2D, 3, GameMenuTexture[i].iWidth, GameMenuTexture[i].iHeight, GL_RGB, GL_UNSIGNED_BYTE, GameMenuTexture[i].pbyData);
			}
			else
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);
				gluBuild2DMipmaps(GL_TEXTURE_2D, 3, GameMenuTexture[i].iWidth, GameMenuTexture[i].iHeight, GL_RGB, GL_UNSIGNED_BYTE, GameMenuTexture[i].pbyData);
			}
		}
		else
		{
			if(_ASConfig->bFastTexturing)
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
				glTexImage2D(GL_TEXTURE_2D, 0, 3, GameMenuTexture[i].iWidth, GameMenuTexture[i].iHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, GameMenuTexture[i].pbyData);
			}
			else
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
				glTexImage2D(GL_TEXTURE_2D, 0, 3, GameMenuTexture[i].iWidth, GameMenuTexture[i].iHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, GameMenuTexture[i].pbyData);
			}
		}
		_AS->WriteLogMessage("OK");
	}
} // end GenOpenGLGameMenuTextures()

void DestroyOpenGLGameMenuTextures(void)
{ // begin DestroyOpenGLGameMenuTextures()
	AS_PROGRESS_WINDOW ProgressWindow;
	short i;

	if(!bInGameMenu)
		return; // We are not in the game menu!
	ProgressWindow.CreateProgressWindow("Destroy menu");
	ProgressWindow.SetTask("Delete OpenGL menu textures...");
	ProgressWindow.SetProgress(0);
	for(i = 0; i < GAME_MENU_TEXTURES; i++)
	{
		ProgressWindow.SetSubTask("%s", GameMenuTexture[i].byFilename);
		ProgressWindow.SetProgress((UINT) (((float) i/GAME_MENU_TEXTURES)*100));
		glDeleteTextures(1, &GameMenuTexture[i].iOpenGLID);
	}
} // end DestroyOpenGLGameMenuTextures()

void EnumerateSingleLevels(void)
{ // begin EnumerateSingleLevels()
	WIN32_FIND_DATA FindFileData;
	char byTemp[256];
	BOOL bTemp;
	FILE *fp;
	HANDLE Find;
	                   
	_AS->WriteLogMessage("Enumerate single player levels");
	DestroySingleLevelList();
	sprintf(byTemp, "%s%s\\*.lev", _AS->pbyProgramPath, _AS->pbySingleLevelsFile);
	Find = FindFirstFile(byTemp, &FindFileData);
	for(;;)
	{	// We found a single level:
		// Check if it is an single level:
		sprintf(byTemp, "%s%s\\%s", _AS->pbyProgramPath, _AS->pbySingleLevelsFile, FindFileData.cFileName);
		fp = fopen(byTemp, "rb");
		if(!fp)
			goto Next;
		fread(&bTemp, sizeof(BOOL), 1, fp);
		fread(&byTemp, sizeof(char)*256, 1, fp);
		fread(&bTemp, sizeof(BOOL), 1, fp);
		fclose(fp);
		if(!bTemp)
			goto Next; // It's no single level!!
		iSingleLevels++;
		pbySingleLevels = (char **) realloc(pbySingleLevels, sizeof(char **)*iSingleLevels);
		pbySingleLevels[iSingleLevels-1] = new char[strlen(FindFileData.cFileName)+1];
		strcpy(pbySingleLevels[iSingleLevels-1], FindFileData.cFileName);
	Next:
		if(!FindNextFile(Find, &FindFileData))
			break;
	}
	FindClose(Find);
} // end EnumerateSingleLevels()

void DestroySingleLevelList(void)
{ // begin DestroySingleLevelList()
	short i;

	if(pbySingleLevels)
	{
		for(i = 0; i < iSingleLevels; i++)
			free(pbySingleLevels[i]);
		free(pbySingleLevels);
		pbySingleLevels = NULL;
	}
	iSingleLevels = 0;
} // end DestroySingleLevelList()

void EnumerateCampaigns(void)
{ // begin EnumerateCampaigns()
	WIN32_FIND_DATA FindFileData;
	char byTemp[256];
	HANDLE Find;
	                   
	_AS->WriteLogMessage("Enumerate campaigns");
	DestroyCampaignsList();
	sprintf(byTemp, "%s%s\\*.*", _AS->pbyProgramPath, _AS->pbyCampaignsFile);
	Find = FindFirstFile(byTemp, &FindFileData);
	for(;;)
	{
		if (FindFileData.cFileName[0] != '.' &&
			(FindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == FILE_ATTRIBUTE_DIRECTORY)
		{ // We found a campaigns:
			iCampaigns++;
			pbyCampaign = (char **) realloc(pbyCampaign, sizeof(char **)*iCampaigns);
			pbyCampaign[iCampaigns-1] = new char[strlen(FindFileData.cFileName)+1];
			strcpy(pbyCampaign[iCampaigns-1], FindFileData.cFileName);
		}
		if(!FindNextFile(Find, &FindFileData))
			break;
	}
	FindClose(Find);
} // end EnumerateCampaigns()

void DestroyCampaignsList(void)
{ // begin DestroyCampaignsList()
	short i;

	if(pbyCampaign)
	{
		for(i = 0; i < iCampaigns; i++)
			free(pbyCampaign[i]);
		free(pbyCampaign);
		pbyCampaign = NULL;
	}
	iCampaigns = 0;
} // end DestroyCampaignsList()

void EnumeratePlayerIDs(void)
{ // begin EnumeratePlayerIDs()
	WIN32_FIND_DATA FindFileData;
	char byTemp[256];
	HANDLE Find;
	FILE *fp;
	                   
	_AS->WriteLogMessage("Enumerate player IDs");
	DestroyPlayerIDList();
	sprintf(byTemp, "%s%s\\*.id", _AS->pbyProgramPath, _AS->pbyIdentityFile);
	Find = FindFirstFile(byTemp, &FindFileData);
	if(Find == INVALID_HANDLE_VALUE)
		return;
	for(;;)
	{	// We found a player ID:
		iPlayerIDs++;
		pbyPlayerID = (char **) realloc(pbyPlayerID, sizeof(char **)*iPlayerIDs);
		sprintf(byTemp, "%s%s\\%s", _AS->pbyProgramPath, _AS->pbyIdentityFile, FindFileData.cFileName);
		fp = fopen(byTemp, "rb");
		if(fp)
		{
			fread(&byTemp, sizeof(char)*PLAYER_NAME_LENGTH, 1, fp);
			fclose(fp);
		}
		pbyPlayerID[iPlayerIDs-1] = new char[strlen(byTemp)+1];
		strcpy(pbyPlayerID[iPlayerIDs-1], byTemp);
		if(!FindNextFile(Find, &FindFileData))
			break;
	}
	FindClose(Find);
} // end EnumeratePlayerIDs()

void DestroyPlayerIDList(void)
{ // begin DestroyPlayerIDsList()
	short i;

	if(pbyPlayerID)
	{
		for(i = 0; i < iPlayerIDs; i++)
			free(pbyPlayerID[i]);
		free(pbyPlayerID);
		pbyPlayerID = NULL;
	}
	iPlayerIDs = 0;
} // end DestroyPlayerIDList()

/*==========================================================================*/




/*==========================================================================*/
/*==========================================================================*/
/* The orginal galaxy code was taken from:									*/
/*																			*/
/*  Galaxy Demo                                                             */
/*  Author: Roman Podobedov                                                 */
/*  Email: romka@ut.ee                                                      */
/*  WEB: http://romka.demonews.com                                          */
/*==========================================================================*/

#define GALAXY_P 200
#define GALAXY_P1 800

typedef struct GALAXY_POINT
{
	float x, y, z;
	float r, g, b;
	float speed;
} GALAXY_POINT;

GALAXY_POINT p1[GALAXY_P];
GALAXY_POINT p2[GALAXY_P];
GALAXY_POINT p3[GALAXY_P1];
float fGalaxyAngle = 0.0f;


void InitGalaxy(void)
{ // begin InitGalaxy()
	float alpha, x, z, r, theta, a, b;
	AS_PROGRESS_WINDOW ProgressWindow;
	short i, j;
	
	_AS->WriteLogMessage("Init galaxy");
	ProgressWindow.CreateProgressWindow("Loading");
	ProgressWindow.SetTask("Init galaxy...");
	ProgressWindow.SetProgress(0);
	// Calculate central level (very condensed particles)
	for(j = 0; j < 4; j++)
	{
		a = 0.9f;
		b = 0.31f;
		theta = 0;
		for(i = 0; i < 50; i++)
		{
			// Spiral formula: r = a*exp(b*theta)
			r = a*(float) exp(b*theta);
			theta += 2.5f/(float)(i+1);
			// Particle coordinates in xz plane
			x = r*(float) cos(theta);
			z = r*(float) sin(theta);
			alpha = (float) (((float) j*90)*PI)/180;
			// Particle coordinates in xz plane + rotation
			p1[j*50+i].x = x*(float) cos(alpha)-z*(float) sin(alpha);
			p1[j*50+i].z = x*(float) sin(alpha)+z*(float) cos(alpha);
			// Particle color
			x = (float) (rand() % 256)/512;
			p1[j*50+i].r = x;
			p1[j*50+i].g = x;
			p1[j*50+i].b = x;
		}
	}
	ProgressWindow.SetProgress(30);

	// Next level of particles: normal condensation
	for(j = 0; j < 4; j++)
	{
		a = 1.9f;
		b = 0.3f;
		theta = 0;
		for(i = 0; i < 50; i++)
		{
			// r = a*exp(b*theta)
			r = a*(float) exp(b*theta);
			theta += 2.3f/(float) (i+1);
			x = r*(float) cos(theta);
			z = r*(float) sin(theta);
			alpha = (float) (((float) j*90+(float) (rand() % 180))*PI)/180;
			// Particle coordinates in xyz space + rotation
			p2[j*50+i].x = x*(float) cos(alpha)-z*(float) sin(alpha);
			p2[j*50+i].y = (float) (rand() % 40)-20;
			p2[j*50+i].z = x*(float) sin(alpha)+z*(float) cos(alpha);
			// Particle color
			x = (float) (rand() % 256)/512;
			p2[j*50+i].r = 0.2f+x;
			p2[j*50+i].g = 0.2f+x;
			p2[j*50+i].b = 0.5f+x;
			// Random speed of particles
			p2[j*50+i].speed = (float) (rand() % 100)/100+0.1f;
		}
	}
	ProgressWindow.SetProgress(60);

	for(j = 0; j < 4; j++)
	{
		a = 1.5f;
		b = 0.3f;
		theta = 0;
		for(i = 0; i < 200; i++)
		{
			// r = a*exp(b*theta)
			r = a*(float) exp(b*theta);
			theta += 2.2f/(float) (i+1);
			x = r*(float) cos(theta);
			z = r*(float) sin(theta);
			alpha = (float) (((float)j*90+(float) (rand() % 360))*PI)/180;
			// Particle coordinates in xyz space + rotation
			p3[j*50+i].x = x*(float) cos(alpha)-z*(float) sin(alpha);
			p3[j*50+i].y = (float) (rand() % 40)-20;
			p3[j*50+i].z = x*(float) sin(alpha)+z*(float) cos(alpha);
			// Particle color
			x = (float) (rand() % 256)/256;
			p3[j*50+i].r = 0.5f+x;
			p3[j*50+i].g = 0.5f+x;
			p3[j*50+i].b = 0.2f+x;
			// Random speed of particles
			p3[j*50+i].speed = (float) (rand() % 100)/100+0.1f;
		}
	}
	ProgressWindow.SetProgress(100);
	_AS->WriteLogMessage("OK");
} // end InitGalaxy()

void DrawGalaxy(void)
{ // begin DrawGalaxy()
	float a, b, ang1;
	short i;

	glClear(GL_COLOR_BUFFER_BIT);
	glLoadIdentity();
	glTranslatef(10.0f, -10.0f, -100.0f);
	glRotatef(45.0f, 1.0f, 0.0f, 0.0f);

	// Rotate galaxy:
	fGalaxyAngle -= 0.001f*g_lDeltatime;

	glColor4f(1.0f, 1.0f, 1.0f, 0.5f);
	// Draw inside part of galaxy (very condensed part)
	glBindTexture(GL_TEXTURE_2D, GameMenuTexture[1].iOpenGLID);
	for(i = 0; i < GALAXY_P; i++)
	{
		glColor3f(p1[i].r, p1[i].g, p1[i].b);
		glPushMatrix();
		a = p1[i].x*(float) cos(fGalaxyAngle*PI/180)-p1[i].z*(float) sin(fGalaxyAngle*PI/180);
		b = p1[i].x*(float) sin(fGalaxyAngle*PI/180)+p1[i].z*(float) cos(fGalaxyAngle*PI/180);
		glTranslatef(a, 0, b);
		DrawStar(6);
		glPopMatrix();
	}

	// Draw part of galaxy (normal condensed part)
	glBindTexture(GL_TEXTURE_2D, GameMenuTexture[2].iOpenGLID);
	for(i = 0; i < GALAXY_P; i++)
	{
		glColor4f(p2[i].r-0.5f, p2[i].g-0.5f, p2[i].b-0.5f, 1);
		glPushMatrix();
		ang1 = fGalaxyAngle*p2[i].speed;
		a = p2[i].x*(float) cos(ang1*PI/180)-p2[i].z*(float) sin(ang1*PI/180);
		b = p2[i].x*(float) sin(ang1*PI/180)+p2[i].z*(float) cos(ang1*PI/180);
		glTranslatef(a, p2[i].y, b);
		DrawStar(2);
		glPopMatrix();
	}

	// Draw part of galaxy (slightly condensed part)
	for(i = 0; i < GALAXY_P1; i++)
	{
		glColor4f(p3[i].r, p3[i].g, p3[i].b, 1);
		glPushMatrix();
		ang1 = fGalaxyAngle*p3[i].speed;
		a = p3[i].x*(float) cos(ang1*PI/180)-p3[i].z*(float) sin(ang1*PI/180);
		b = p3[i].x*(float) sin(ang1*PI/180)+p3[i].z*(float) cos(ang1*PI/180);
		glTranslatef(a, p3[i].y, b);
		DrawStar(1);
		glPopMatrix();
	}

	// Draw foggly part of galaxy (simply polygon with texture)
	glColor4f(0.7f, 0.7f, 0.7f, 1.0f);
	glBindTexture(GL_TEXTURE_2D, GameMenuTexture[3].iOpenGLID);
	glPushMatrix();
	glRotatef(-fGalaxyAngle, 0, 1, 0);
	glBegin(GL_QUADS);
		glTexCoord2f(0, 0); glVertex3f(-60, 0, -60);
		glTexCoord2f(1, 0); glVertex3f(-60, 0, 60);
		glTexCoord2f(1, 1); glVertex3f(60, 0, 60);
		glTexCoord2f(0, 1); glVertex3f(60, 0, -60);
	glEnd();
	glPopMatrix();

	// Draw background:
	glPushMatrix();
	// Flip to projection mode:
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	// Set new 2D projection
	gluOrtho2D(-1, 1, -1, 1);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	// Flip back to normal 3D mode
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
	glPopMatrix();
} // end DrawGalaxy()

void DrawStar(float psize)
{ // begin DrawStar()
    // Draw polygon and particle texture mapping
	glBegin(GL_QUADS);
		glTexCoord2f(0, 0); glVertex3f(-psize, 0, -psize);
		glTexCoord2f(1, 0); glVertex3f(-psize, 0, psize);
		glTexCoord2f(1, 1); glVertex3f(psize, 0, psize);
		glTexCoord2f(0, 1); glVertex3f(psize, 0, -psize);
	glEnd();
} // end DrawStar()
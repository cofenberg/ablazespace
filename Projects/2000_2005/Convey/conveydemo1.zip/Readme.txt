Convey - Pre-Demo               February 13, 2001 

Remeber: This is only a very early demo of my game 'Convey'! 




Game Status & Information
Technology and editor alone took me about two months time (counted in school-time...
as an hobby). The technology of Convey is finished up to 50 per cent at the moment.
After completing the game it will took me ca. one month again to build levels and their
textures.  


Planned Enhancements
- uncommon types of enemies
- beamer
- switches and doors
- Improved camera system with story script for telling a story and
for showing of important game objects and tasks
- particle system
- a thrilling story which is told in the progression of the game
- and many many more... 
 

Completion & Publication
I can only guess when I complete the game ... but I think about two months, but it is told
that a game is never completed. One day you stop working at it and throw it into the whole
wide world.
It is not standing firm as what kind I'll publish the game. Because I am still a pupil,
I don't have money to burn and so the game won't be freeware. And if the source-code
are published is not sure, too. But you can be certain that you can download new levels
and whole campaigns from this site for free.
If there's a publisher that wants to banish Convey commercial, please contact me.




I have published this demo because I'm waiting for reactions. In the demo
version there are only a few levels and only few elements of the whole game. Additionally
there will be a few nerved bugs which won't occur on every system.
And there will not be a complete help file, i.e. that you have to try the functions of the game. 
The demo is not representing the quality of the accomplished game!
 

On the AblazeSpace homepage you will find more levels and campaings for the Convey demo.




Christian Ofenberg
AblazeSpace

Homapage: AblazeSpace.exit.de
E-Mail: AblazeSpace@web.de
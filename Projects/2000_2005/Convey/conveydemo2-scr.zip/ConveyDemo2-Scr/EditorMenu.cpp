//-----------------------------------------------------------------------------
// File: EditorMenu.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
HWND hWndEditor,				 // The editor window handle
	 hWndEditorTab[EDITOR_TABS], // The tab handles
	 hWndKeyword;				 // The keyword dialog handle
short iCurrentEditorTab;		 // The current selected tab
char byKeyword[256];			 // The level keyword (temp)
BOOL bAlreadySaved = FALSE;
FIELD *pFieldLast = NULL;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern HRESULT EditorDraw(void);
extern HRESULT EditorCheck(void);
LRESULT CALLBACK EditorProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditorSelectProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditorBrushProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditorSurfacesProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditorObjectsProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditorTerrainProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditorEnvironmentProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditorCameraProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditorDecorationProc(HWND, UINT, WPARAM, LPARAM);
void SetupEditorTabs(void);
void SetEditorLanguage(void);
LRESULT CALLBACK KeywordProc(HWND, UINT, WPARAM, LPARAM);
void KeywordLanguage(void);
HRESULT SaveLevelQuestion(void);
LRESULT CALLBACK SetCameraVelocityProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK CopyCameraStepProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK SetCameraStepsProc(HWND, UINT, WPARAM, LPARAM);
///////////////////////////////////////////////////////////////////////////////


LRESULT CALLBACK EditorProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorProc()
	char *pbyTemp, byTemp[256];
	RECT Rect1, Rect2;
	BOOL bKeyword;
	short i, i2;

    switch(iMessage)
    {
        case WM_INITDIALOG:
			if(!hWndEditor)
				iCurrentEditorTab = -1;
			hWndEditor = hWnd;
			bPlayerCameraView = FALSE;
			bIndestructibleWallStandart = FALSE;
			// Setup the last size:
			if(_ASConfig->EditorWindow.left < 0)
			{
				_ASConfig->EditorWindow.right += -_ASConfig->EditorWindow.left;
				_ASConfig->EditorWindow.left = 0;
			}
			if(_ASConfig->EditorWindow.top < 0)
			{
				_ASConfig->EditorWindow.bottom += -_ASConfig->EditorWindow.top;
				_ASConfig->EditorWindow.top = 0;
			}
			SetWindowPos(hWndEditor, HWND_NOTOPMOST, _ASConfig->EditorWindow.left, _ASConfig->EditorWindow.top,
						 _ASConfig->EditorWindow.right-_ASConfig->EditorWindow.left,
						 _ASConfig->EditorWindow.bottom-_ASConfig->EditorWindow.top, 0);
			// Setup the level show area:
			hWndEditorShow = GetDlgItem(hWnd, IDC_EDITOR_LEVEL);
			ASInitOpenGL(NULL, hWndEditorShow, &hDCEditorShow, &hRCEditorShow, FALSE);
			GetWindowRect(hWndEditor, &Rect1);
			GetWindowRect(hWndEditorShow, &Rect2);
			SetWindowPos(hWndEditorShow, HWND_NOTOPMOST, Rect2.left, Rect2.top, Rect1.right-Rect2.left-10, Rect1.bottom-Rect2.top-10, 0);
			GetWindowRect(hWndEditorShow, &Rect2);
			wglMakeCurrent(hDCEditorShow, hRCEditorShow);

			ASConfigOpenGL(Rect2.right-Rect2.left, Rect2.bottom-Rect2.top);
			SendMessage(hWnd, WM_SIZE, 0, 0);
			//
			_AS->CreateDXInputDevices(hWnd, FALSE, TRUE, TRUE, FALSE);
			ASBuildFont();
			SetTimer(hWnd, 1, 1, NULL);
					
			// Init editor size:
			sprintf(byTemp, "1x1");
			SendDlgItemMessage(hWnd, IDC_EDITOR_SIZE, LB_ADDSTRING, 0, (LONG)(LPSTR) byTemp);
			sprintf(byTemp, "2x2");
			SendDlgItemMessage(hWnd, IDC_EDITOR_SIZE, LB_ADDSTRING, 0, (LONG)(LPSTR) byTemp);
			for(i = 1; i < 5; i++)
			{
				sprintf(byTemp, "%dx%d", i*2+1, i*2+1);
				SendDlgItemMessage(hWnd, IDC_EDITOR_SIZE, LB_ADDSTRING, 0, (LONG)(LPSTR) byTemp);
			}
 			byEditorBrushSize = 0;
			SendDlgItemMessage(hWnd, IDC_EDITOR_SIZE, LB_SETCURSEL, byEditorBrushSize, 0L);
			
			InitGameObjects();
			LoadGameTextures();
			ASGenOpenGLTextures(GAME_TEXTURES, GameTexture);
			CreateGameLists();
			InitGameParticleSystems();
	
			// Setup the current level:
			pLevel = new LEVEL;
			if(bEditorTestLevel)
				pLevel->Load(byCurrentLevelName);
			else
			{
				pPlayer->bActive = FALSE;
				memset(&Actor, 0, sizeof(ACTOR)*MAX_ACTORS);
				pLevel->Create(11, 11, -2, 1, 1);
			}
			bEditorTestLevel = FALSE;
			pLevel->GenTexturesOpenGL(hDCEditorShow, 
									  hRCEditorShow);
			

			// Setup the other stuff:
			TabCtrl_SetCurSel(GetDlgItem(hWnd, IDC_EDITOR_TAB), 0);
			SendMessage(hWnd, WM_NOTIFY, IDC_EDITOR_TAB, 0);
			g_lNow = GetTickCount();
			g_lLastlooptime = g_lNow;
			SetEditorLanguage();

			lCameraTimer = g_lNow;
			bCameraAnimation = 0;
			bPause = bCameraAnimation = FALSE;
			_AS->ShowMouseCursor(TRUE);
			UpdateWindow(hWnd);
		return TRUE;
		
		case WM_TIMER:
			pCamera->fPos[Z] = pCamera->fZ+STANDART_LEVEL_Z_POS;
			_AS->ReadDXInput(hWnd);
			EditorDraw();
			EditorCheck();
			_AS->UpdateWindows();
		break;

        case WM_SIZE:
			hWndEditorShow = GetDlgItem(hWnd, IDC_EDITOR_LEVEL);
			GetWindowRect(hWndEditor, &Rect1);
			GetWindowRect(hWndEditorShow, &Rect2);
			SetWindowPos(hWndEditorShow, NULL, Rect2.left, Rect2.top, Rect1.right-Rect2.left-10, Rect1.bottom-Rect2.top-10, SWP_NOMOVE);
			GetWindowRect(hWndEditorShow, &Rect2);
			wglMakeCurrent(hDCEditorShow, hRCEditorShow);
			ASConfigOpenGL(Rect2.right-Rect2.left, Rect2.bottom-Rect2.top);
		break;

		case WM_COMMAND:
            switch(LOWORD(wParam))
            {				
				case ID_EDITOR_FILE_TEXTURES:
					KillTimer(hWnd, 1);
					DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_TEXTURES), hWnd, (DLGPROC) TexturesProc);
					SetTimer(hWnd, 1, 1, NULL);
					ASInitOpenGL(NULL, hWndEditorShow, &hDCEditorShow, &hRCEditorShow, FALSE);
				break;
				
				case ID_EDITOR_FILE_CAMPAIGN_EDITOR:
					KillTimer(hWnd, 1);
					DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CAMPAIGN_EDITOR), hWnd, (DLGPROC) CampaignEditorProc);
					SetTimer(hWnd, 1, 1, NULL);
				break;

				case ID_EDITOR_FILE_TEXT_SCRIPT_EDITOR:
					KillTimer(hWnd, 1);
					DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_TEXT_SCRIPT_EDITOR), hWnd, (DLGPROC) TextScriptEditorProc);
					SetTimer(hWnd, 1, 1, NULL);
				break;

				case IDC_EDITOR_SIZE:
   					byEditorBrushSize = (char) SendDlgItemMessage(hWnd, IDC_EDITOR_SIZE, LB_GETCURSEL, 0, 0L);
				break;

			// Menu:
				case ID_EDITOR_FILE_GAME:
					_AS->SetNextModule(MODULE_GAME);
					SendMessage(hWndEditor, WM_CLOSE, 0, 0);
				break;

				case ID_EDITOR_FILE_QUIT:
					_AS->SetShutDown(TRUE);
					SendMessage(hWndEditor, WM_CLOSE, 0, 0);
				break;

				case ID_FILE_LEVEL_NEW:
					if(SaveLevelQuestion())
						break;
					KillTimer(hWnd, 1);
					NewLevelDialog();
					SetTimer(hWnd, 1, 1, NULL);
					TabCtrl_SetCurSel(GetDlgItem(hWnd, IDC_EDITOR_TAB), 0);
					SendMessage(hWnd, WM_NOTIFY, IDC_EDITOR_TAB, 0);
				break;

				case ID_FILE_LEVEL_SAVE:
					if(pLevel->Header.byFilename[0] == '\0')
						goto SaveAs;
					if(pLevel->Save(pLevel->Header.byFilename))
					{
						sprintf(byTemp, "%s: %s", pLevel->Header.byFilename, M_FileCouldNotSaved);
						KillTimer(hWnd, 1);
						MessageBox(hWnd, byTemp, T_Error, MB_OK | MB_ICONINFORMATION);
						SetTimer(hWnd, 1, 1, NULL);
						break;
					}
				break;

				case ID_FILE_LEVEL_SAVEAS:
				SaveAs:
					sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbySingleLevelsFile);
					KillTimer(hWnd, 1);
					pbyTemp = ASGetFileName(hWnd, T_SaveLevel, LEV_FILE, 1, FALSE, byTemp);
					SetTimer(hWnd, 1, 1, NULL);
					if(!pbyTemp)
						break;
					if(pLevel->Save(pbyTemp))
					{
						sprintf(byTemp, "%s: %s", pbyTemp, M_FileCouldNotSaved);
						KillTimer(hWnd, 1);
						MessageBox(hWnd, byTemp, T_Error, MB_OK | MB_ICONINFORMATION);
						SetTimer(hWnd, 1, 1, NULL);
						break;
					}
				break;

				case ID_FILE_LEVEL_LOAD:
					if(SaveLevelQuestion())
						break;
					sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbySingleLevelsFile);
					KillTimer(hWnd, 1);
					pbyTemp = ASGetFileName(hWnd, T_LoadLevel, LEV_FILE, 0, FALSE, byTemp);
					SetTimer(hWnd, 1, 1, NULL);
					if(!pbyTemp)
						break;
					bKeyword = GetLevelKeyword(pbyTemp, byKeyword);
					if(bKeyword && !bMasterAccess)
					{ // Check the keyword:
						bKeyword = DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_KEYWORD), hWnd, (DLGPROC) KeywordProc);
						if(!bKeyword)
						{ // Wrong keyword!!
							KillTimer(hWnd, 1);
							MessageBox(hWnd, M_WrongKeyword, GAME_NAME, MB_OK | MB_ICONINFORMATION);
							SetTimer(hWnd, 1, 1, NULL);
							break;
						}
						else
							if(bKeyword == -1)
								break;
					}
					pLevel->Load(pbyTemp);
					TabCtrl_SetCurSel(GetDlgItem(hWnd, IDC_EDITOR_TAB), 0);
					SendMessage(hWnd, WM_NOTIFY, IDC_EDITOR_TAB, 0);
				break;

				case ID_FILE_LEVEL_PLAY:
					_AS->WriteLogMessage("Editor: Play current level");
					if(pLevel->Header.byFilename[0] == '\0')
					{
						_AS->WriteLogMessage("Error: The current level has no filename");
						KillTimer(hWnd, 1);
						MessageBox(hWnd, M_TheLevelHasNoFilename, T_Error, MB_OK | MB_ICONINFORMATION);
						sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbySingleLevelsFile);
						pbyTemp = ASGetFileName(hWnd, T_SaveLevel, LEV_FILE, 1, FALSE, byTemp);
						SetTimer(hWnd, 1, 1, NULL);
						if(!pbyTemp)
							break;
						strcpy(byTemp, pbyTemp);
					}
					else
						strcpy(byTemp, pLevel->Header.byFilename);
					if(pLevel->Save(byTemp))
					{
						sprintf(byTemp, "%s: %s", byTemp, M_FileCouldNotSaved);
						KillTimer(hWnd, 1);
						MessageBox(hWnd, byTemp, T_Error, MB_OK | MB_ICONINFORMATION);
						SetTimer(hWnd, 1, 1, NULL);
						break;
					}
					_AS->WriteLogMessage("Save level %s", byTemp);
					bEditorTestLevel = TRUE;
					sprintf(byCurrentLevelName, pLevel->Header.byFilename);
					_AS->SetNextModule(MODULE_GAME);
					bAlreadySaved = TRUE;
					bShowLogos = FALSE;
					SendMessage(hWndEditor, WM_CLOSE, 0, 0);
				break;
				
				case ID_FILE_LEVEL_ADJUST:
					KillTimer(hWnd, 1);
					AdjustLevelDialog();
					SetTimer(hWnd, 1, 1, NULL);
				break;

			// Options:
				case ID_OPTIONS_CONFIG:
					KillTimer(hWnd, 1);
					OpenConfigDialog(hWnd);
					SetTimer(hWnd, 1, 1, NULL);
				break;

			// Help:
				case ID_HELP_HELP:
					OpenHelp();
				break;
				
				case ID_HELP_HOMEPAGE:
					_AS->WriteLogMessage("Open homepage");
					ShellExecute(0, "open", "http://www.ablazespace.de/", 0, 0, SW_SHOW);
				break;

				case ID_HELP_CREDITS:
					KillTimer(hWnd, 1);
					OpenCreditsDialog(hWnd);
					SetTimer(hWnd, 1, 1, NULL);
				break;
				
				case ID_FILE_SHOW_LOG:
					_AS->WriteLogMessage("Open Log");
					sprintf(byTemp, "%s"AS_LOG_FILE, _AS->pbyProgramPath);
					ShellExecute(0, "open", byTemp, 0, 0, SW_SHOW);				
				break;
            }
        break;

        case WM_NOTIFY: 
			switch(wParam)
			{
				case IDC_EDITOR_TAB:
					EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_SIZE), TRUE);
					i = TabCtrl_GetCurSel(GetDlgItem(hWnd, IDC_EDITOR_TAB));
					iCurrentEditorTab = i;
					for(i2 = 0; i2 < EDITOR_TABS; i2++)
					{
						ShowWindow(hWndEditorTab[i2], SW_HIDE);
						UpdateWindow(hWndEditorTab[i2]);
					}
					TabCtrl_SetCurSel(GetDlgItem(hWnd, IDC_EDITOR_TAB), i);
					ShowWindow(hWndEditorTab[i], SW_SHOW);
					UpdateWindow(hWndEditorTab[i]);
					UpdateWindow(hWnd);
					SetFocus(hWndEditorTab[i]);
					SendMessage(hWndEditorTab[i], WM_INITDIALOG, 0, 0);
				break;
			} 
		break; 

		case WM_CLOSE:
			if(_AS->GetNextModule() != MODULE_GAME)
				_AS->SetShutDown(TRUE);
			if(!bAlreadySaved && SaveLevelQuestion())
			{ // The user will not close the editor:
				_AS->SetShutDown(FALSE);
				break;
			}
			bAlreadySaved = FALSE;
			GetWindowRect(hWndEditor, &_ASConfig->EditorWindow);

			ASDestroyOpenGLTextures(GAME_TEXTURES, GameTexture);
			ASDestroyTextures(GAME_TEXTURES, GameTexture);
			DestroyGameParticleSystems();
			pLevel->DestroyTexturesOpenGL(hDCEditorShow, hRCEditorShow);
			ASKillFont();

			// This makes some trouble if you go to game and switch back to editor...
			if(_AS->GetNextModule() != MODULE_GAME)
				ASDestroyOpenGL(NULL, hWndEditorShow, hDCEditorShow, hRCEditorShow);

			_AS->FreeDXInputDevices();
			
			DestroyGameObjects();
			DestroyLevel(&pLevel);
			KillTimer(hWnd, 1);
			hWndEditor = NULL;
			hWndEditorShow = NULL;
			bShowLogos = FALSE;
			for(i2 = 0; i2 < EDITOR_TABS; i2++)
				hWndEditorTab[i2] = NULL;
			EndDialog(hWnd, FALSE);
			// Save the configuration:	
			sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyConfigFile);
			_ASConfig->Save(byTemp);
		break;
    }
    return FALSE;
} // end EditorProc()

LRESULT CALLBACK EditorSelectProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorSelectProc()
	char byTemp[256];
	FIELD *pFieldT;
	short i;
	
	EnableWindow(GetDlgItem(hWndEditor, IDC_EDITOR_SIZE), FALSE);
	if(!pLevel)
		return 0;
	pFieldT = pLevel->pCurrentField;
	if(pFieldLast != pFieldT)
	{
		pFieldLast = pFieldT;
		goto Init;
	}
	if(!pFieldT)
		return 0;
	switch(iMessage)
    {
        case WM_INITDIALOG:
  		Init:
			if(!pFieldT)
				return 0;
			// Texts:
			byEditorSelected = -1;
			SetDlgItemText(hWnd, IDD_EDITOR_SELECT_CAMERA, T_Camera);
			SetDlgItemText(hWnd, IDD_EDITOR_SELECT_CAMERA_ALWAYS, T_Always);
			SetDlgItemText(hWnd, IDD_EDITOR_SELECT_TEXT_SCRIPT, T_TextScript);
			SetDlgItemText(hWnd, IDD_EDITOR_SELECT_TEXT_SCRIPT_ALWAYS, T_Always);
			SetDlgItemText(hWnd, IDD_EDITOR_SELECT_INDESTRUCTIBLE_WALL, T_IndestructibleWall);
			SetDlgItemText(hWnd, IDD_EDITOR_SELECT_ALWAYS_WALL, T_AlwaysWall);
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_DECORATION_POSITION, T_Position);
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_DECORATION_ROTATION, T_Rotation);
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_DECORATION_SIZE, T_Size);
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_DECORATION_MODEL_T, T_Model);
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_SELECT, T_Select);
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_DECORATION_BEAMER_T, T_Beamer);
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_BEAMER_ENERGY_T, T_Energy);
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_BEAMER_SPEED_T, T_SpeedObj);
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_BEAMER_TARGET, T_Target);
			//
			sprintf(byTemp, "%d", pFieldT->iID);
			SetDlgItemText(hWnd, IDD_EDITOR_SELECT_FIELD_ID, byTemp);
			SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_CAMERA_LIST, CB_RESETCONTENT, 0, 0L);
			for(i = 0; i < pLevel->Header.iCameraScripts; i++)
			{
				sprintf(byTemp, "%s", pLevel->pCameraScript[i].byName);
				SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_CAMERA_LIST, CB_ADDSTRING, 0, (LPARAM) byTemp);
			}
			SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_CAMERA_LIST, CB_SETCURSEL, pFieldT->iCamera, 0L);
			if(pFieldT->iCamera == -1)
			{
				SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_CAMERA, BM_SETCHECK, FALSE, 0L);
				EnableWindow(GetDlgItem(hWnd, IDD_EDITOR_SELECT_CAMERA_ALWAYS), FALSE);
				EnableWindow(GetDlgItem(hWnd, IDD_EDITOR_SELECT_CAMERA_LIST), FALSE);
			}
			else
			{
				SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_CAMERA, BM_SETCHECK, TRUE, 0L);
				EnableWindow(GetDlgItem(hWnd, IDD_EDITOR_SELECT_CAMERA_ALWAYS), TRUE);
				EnableWindow(GetDlgItem(hWnd, IDD_EDITOR_SELECT_CAMERA_LIST), TRUE);
			}
			SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_CAMERA_ALWAYS, BM_SETCHECK, pFieldT->bCameraAlways, 0L);
			SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_ALWAYS_WALL, BM_SETCHECK, pFieldT->bAlwaysWall, 0L);

			//
			SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_TEXT_SCRIPT_LIST, CB_RESETCONTENT, 0, 0L);
			for(i = 0; i < pLevel->TextScriptsManager.iTextsScripts; i++)
			{
				sprintf(byTemp, "%s", pTextScript[i].byName);
				SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_TEXT_SCRIPT_LIST, CB_ADDSTRING, 0, (LPARAM) byTemp);
			}
			SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_TEXT_SCRIPT_LIST, CB_SETCURSEL, pFieldT->iTextScript, 0L);
			if(pFieldT->iTextScript == -1)
			{
				SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_TEXT_SCRIPT, BM_SETCHECK, FALSE, 0L);
				EnableWindow(GetDlgItem(hWnd, IDD_EDITOR_SELECT_TEXT_SCRIPT_ALWAYS), FALSE);
				EnableWindow(GetDlgItem(hWnd, IDD_EDITOR_SELECT_TEXT_SCRIPT_LIST), FALSE);
			}
			else
			{
				SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_TEXT_SCRIPT, BM_SETCHECK, TRUE, 0L);
				EnableWindow(GetDlgItem(hWnd, IDD_EDITOR_SELECT_TEXT_SCRIPT_ALWAYS), TRUE);
				EnableWindow(GetDlgItem(hWnd, IDD_EDITOR_SELECT_TEXT_SCRIPT_LIST), TRUE);
			}
			SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_TEXT_SCRIPT_ALWAYS, BM_SETCHECK, pFieldT->bTextScriptAlways, 0L);
			SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_INDESTRUCTIBLE_WALL, BM_SETCHECK, pFieldT->bIndestructibleWall, 0L);
			if(!pFieldT->pDecoration)
			{
				ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_DECORATION_POSITION), SW_HIDE);
				ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_DECORATION_ROTATION), SW_HIDE);
				ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_DECORATION_SIZE), SW_HIDE);
				ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_DECORATION_MODEL_T), SW_HIDE);
				ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_SELECT), SW_HIDE);
			}
			else
			{
				ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_DECORATION_POSITION), SW_SHOW);
				ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_DECORATION_ROTATION), SW_SHOW);
				ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_DECORATION_SIZE), SW_SHOW);
				ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_DECORATION_MODEL_T), SW_SHOW);
				ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_SELECT), SW_SHOW);
			}
			if(!pFieldT->pSurface[FACE_FLOOR][0]->Header.bBeamer || !pFieldT->bActive)
			{
				ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_DECORATION_BEAMER_T), SW_HIDE);
				ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_BEAMER_ENERGY_T), SW_HIDE);
				ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_BEAMER_ENERGY), SW_HIDE);
				ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_BEAMER_SPEED_T), SW_HIDE);
				ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_BEAMER_SPEED), SW_HIDE);
				ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_BEAMER_TARGET), SW_HIDE);
			}
			else
			{
				ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_DECORATION_BEAMER_T), SW_SHOW);
				ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_BEAMER_ENERGY_T), SW_SHOW);
				ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_BEAMER_ENERGY), SW_SHOW);
				ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_BEAMER_SPEED_T), SW_SHOW);
				ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_BEAMER_SPEED), SW_SHOW);
				ShowWindow(GetDlgItem(hWnd, IDC_EDITOR_SELECT_BEAMER_TARGET), SW_SHOW);
			}

			sprintf(byTemp, "%f", pFieldT->fBeamerPower);
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_BEAMER_ENERGY, byTemp);
			sprintf(byTemp, "%d", pFieldT->iBeamerRegenerationSpeed);
			SetDlgItemText(hWnd, IDC_EDITOR_SELECT_BEAMER_SPEED, byTemp);
			
			byEditorMenu = EDITOR_SELECT_MENU;
		return TRUE;

        case WM_COMMAND:
			if(!pFieldT)
				return 0; // No field is selected!!
            switch(LOWORD(wParam))
            {
				case IDD_EDITOR_SELECT_CAMERA_LIST:
					i = (short) SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_CAMERA_LIST, CB_GETCURSEL, 0, 0L);
					if(i < 0 || i >= pLevel->Header.iCameraScripts)
						break;
					pFieldT->iCamera = i;
				break;
				
				case IDD_EDITOR_SELECT_CAMERA:
					i = (short) SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_CAMERA, BM_GETCHECK, 0, 0L);
					if(!i)
						pFieldT->iCamera = -1;
					else
						pFieldT->iCamera = 0;
					goto Init;

				case IDD_EDITOR_SELECT_CAMERA_ALWAYS:
					pFieldT->bCameraAlways = SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_CAMERA_ALWAYS, BM_GETCHECK, 0, 0L);
				break;

				case IDD_EDITOR_SELECT_ALWAYS_WALL:
					pFieldT->bAlwaysWall = SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_ALWAYS_WALL, BM_GETCHECK, 0, 0L);
				break;

				case IDD_EDITOR_SELECT_TEXT_SCRIPT_LIST:
					i = (short) SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_TEXT_SCRIPT_LIST, CB_GETCURSEL, 0, 0L);
					if(i < 0 || i >= pLevel->TextScriptsManager.iTextsScripts)
						break;
					pFieldT->iTextScript = i;
				break;
				
				case IDD_EDITOR_SELECT_TEXT_SCRIPT:
					i = (short) SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_TEXT_SCRIPT, BM_GETCHECK, 0, 0L);
					if(!i)
						pFieldT->iTextScript = -1;
					else
						pFieldT->iTextScript = 0;
					goto Init;

				case IDD_EDITOR_SELECT_TEXT_SCRIPT_ALWAYS:
					pFieldT->bTextScriptAlways = SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_TEXT_SCRIPT_ALWAYS, BM_GETCHECK, 0, 0L);
				break;

				case IDD_EDITOR_SELECT_INDESTRUCTIBLE_WALL:
					pFieldT->bIndestructibleWall = SendDlgItemMessage(hWnd, IDD_EDITOR_SELECT_INDESTRUCTIBLE_WALL, BM_GETCHECK, 0, 0L);
				break;

				case IDC_EDITOR_SELECT_DECORATION_POSITION:
					byEditorSelected = EDITOR_SELECTED_DECORATION_POSITION;
				break;

				case IDC_EDITOR_SELECT_DECORATION_ROTATION:
					byEditorSelected = EDITOR_SELECTED_DECORATION_ROTATION;
				break;

				case IDC_EDITOR_SELECT_DECORATION_SIZE:
					byEditorSelected = EDITOR_SELECTED_DECORATION_SIZE;
				break;

				case IDC_EDITOR_SELECT_SELECT: byEditorSelected = -1; break;

				case IDC_EDITOR_SELECT_BEAMER_ENERGY:
					GetDlgItemText(hWnd, IDC_EDITOR_SELECT_BEAMER_ENERGY, byTemp, 256);
					pFieldT->fBeamerPower = (float) atof(byTemp);
				break;

				case IDC_EDITOR_SELECT_BEAMER_SPEED:
					GetDlgItemText(hWnd, IDC_EDITOR_SELECT_BEAMER_SPEED, byTemp, 256);
					pFieldT->iBeamerRegenerationSpeed = atoi(byTemp);
				break;

				case IDC_EDITOR_SELECT_BEAMER_TARGET:
					byEditorSelected = EDITOR_SELECTED_BEAMER_TARGET;
				break;
            }
            break;
    }
    return FALSE;
} // end EditorSelectProc()

LRESULT CALLBACK EditorBrushProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorBrushProc()
	if(!pLevel)
		return 0;
	switch(iMessage)
    {
        case WM_INITDIALOG:
  			// Texts:
			SetDlgItemText(hWnd, IDC_EDITOR_BRUSH_WALL, T_Wall);
			SetDlgItemText(hWnd, IDC_EDITOR_BRUSH_DEACTIVATE_FIELD, T_DeactivateField);
			SetDlgItemText(hWnd, IDC_EDITOR_BRUSH_2_SIDES, T_2Sides);
			SetDlgItemText(hWnd, IDC_EDITOR_BRUSH_CLEAR_FIELD, T_ClearField);
			SetDlgItemText(hWnd, IDC_EDITOR_BRUSH_WALL_HOLE, T_WallHole);
			//
			byEditorMenu = EDITOR_BRUSH_MENU;
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_EDITOR_BRUSH_WALL:
					byEditorSelected = EDITOR_SELECTED_WALL;
				break;
				
				case IDC_EDITOR_BRUSH_DEACTIVATE_FIELD:
					byEditorSelected = EDITOR_SELECTED_DEACTIVATE_FIELD;
				break;
				
				case IDC_EDITOR_BRUSH_2_SIDES:
					byEditorSelected = EDITOR_SELECTED_2_SIDES;
				break;

				case IDC_EDITOR_BRUSH_CLEAR_FIELD:
					byEditorSelected = EDITOR_SELECTED_CLEAR_FIELD;
				break;

				case IDC_EDITOR_BRUSH_WALL_HOLE:
					byEditorSelected = EDITOR_SELECTED_WALL_HOLE;
				break;
            }
            break;
    }
    return FALSE;
} // end EditorBrushProc()

LRESULT CALLBACK EditorSurfacesProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorSurfacesProc()
	char byTemp[256];
	
	if(!pLevel)
		return 0;
	switch(iMessage)
    {
        case WM_INITDIALOG:
  			// Texts:
			SetDlgItemText(hWnd, IDC_EDITOR_SURFACES_CHOOSE, T_Surface);
			SetDlgItemText(hWnd, IDC_EDITOR_SURFACES_ROTATION_T, T_Rotation);
			SetDlgItemText(hWnd, IDC_EDITOR_SURFACES_SURFACE, T_Surface);
			SetDlgItemText(hWnd, IDC_EDITOR_SURFACES_SECOND_SURFACE, T_SecondSurface);
			SetDlgItemText(hWnd, IDC_EDITOR_SURFACES_REMOVE_SECOND_SURFACE, T_RemoveSecondSurface);			
			byEditorMenu = EDITOR_SURFACE_MENU;
			//
		Init:
			switch(iEditorCurrentSurfaceType)
			{
				case 0: CheckRadioButton(hWnd, IDC_EDITOR_SURFACES_SURFACE, IDC_EDITOR_SURFACES_REMOVE_SECOND_SURFACE, IDC_EDITOR_SURFACES_SURFACE); break;
				case 1: CheckRadioButton(hWnd, IDC_EDITOR_SURFACES_SURFACE, IDC_EDITOR_SURFACES_REMOVE_SECOND_SURFACE, IDC_EDITOR_SURFACES_SECOND_SURFACE); break;
				case 2: CheckRadioButton(hWnd, IDC_EDITOR_SURFACES_SURFACE, IDC_EDITOR_SURFACES_REMOVE_SECOND_SURFACE, IDC_EDITOR_SURFACES_REMOVE_SECOND_SURFACE); break;
			}	

			sprintf(byTemp, "%d�", iEditorRotate*90);
			SetDlgItemText(hWnd, IDC_EDITOR_SURFACES_ROTATION, byTemp);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_EDITOR_SURFACES_CHOOSE:
					DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_SURFACES), hWnd, (DLGPROC) SurfacesProc);
					ASInitOpenGL(NULL, hWndEditorShow, &hDCEditorShow, &hRCEditorShow, FALSE);
				break;

				case IDC_EDITOR_SURFACES_PLUS:
					iEditorRotate++;
					if(iEditorRotate > 3)
						iEditorRotate = 0;
					goto Init;

				case IDC_EDITOR_SURFACES_MINUS:
					iEditorRotate--;
					if(iEditorRotate < 0)
						iEditorRotate = 3;
					goto Init;
		
				case IDC_EDITOR_SURFACES_SURFACE:
				case IDC_EDITOR_SURFACES_SECOND_SURFACE:
				case IDC_EDITOR_SURFACES_REMOVE_SECOND_SURFACE:
					if(IsDlgButtonChecked(hWnd, IDC_EDITOR_SURFACES_SURFACE))
						iEditorCurrentSurfaceType = 0;
					if(IsDlgButtonChecked(hWnd, IDC_EDITOR_SURFACES_SECOND_SURFACE))
						iEditorCurrentSurfaceType = 1;
					if(IsDlgButtonChecked(hWnd, IDC_EDITOR_SURFACES_REMOVE_SECOND_SURFACE))
						iEditorCurrentSurfaceType = 2;
				break;
            }
            break;
    }
    return FALSE;
} // end EditorSurfacesProc()

LRESULT CALLBACK EditorObjectsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorObjectsProc()
	char byTemp[256];
	short i;

	if(!pLevel)
		return 0;
	switch(iMessage)
    {
        case WM_INITDIALOG:
  			// Texts:
			SetDlgItemText(hWnd, IDC_EDITOR_OBJECTS_ROTATION_T, T_Rotation);
			SetDlgItemText(hWnd, IDC_EDITOR_OBJECTS_HEAVY, T_Heavy);
			SetDlgItemText(hWnd, IDC_EDITOR_OBJECTS_NUMBER_T, T_Number);
			SetDlgItemText(hWnd, IDC_EDITOR_OBJECTS_VELOCITY_T, T_Velocity);
			byEditorSelected = EDITOR_SELECTED_OBJECT_XE;
			//
		Init:
			// Objects list:
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_RESETCONTENT , 0, 0L);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_SETITEMDATA, SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) "Xe"), 0);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_SETITEMDATA, SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_BoxNormal), 1);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_SETITEMDATA, SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_BoxRed), 2);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_SETITEMDATA, SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_BoxGreen), 3);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_SETITEMDATA, SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_BoxBlue), 4);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_SETITEMDATA, SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_HealthObj), 5);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_SETITEMDATA, SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_LiveObj), 6);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_SETITEMDATA, SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_PullObj), 7);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_SETITEMDATA, SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_ThrowObj), 8);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_SETITEMDATA, SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_ForceObj), 9);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_SETITEMDATA, SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_WeaponObj), 10);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_SETITEMDATA, SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_PointObj), 11);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_SETITEMDATA, SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_GhostObj), 12);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_SETITEMDATA, SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_TimeObj), 13);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_SETITEMDATA, SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_StepObj), 14);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_SETITEMDATA, SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_SpeedObj), 15);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_SETITEMDATA, SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_WingsObj), 16);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_SETITEMDATA, SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_ShieldObj), 17);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_SETITEMDATA, SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_Jump), 18);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_SETITEMDATA, SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_Air), 19);
			for(i = 0; i < 19; i++)
			{
				if(SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_GETITEMDATA, i, 0L) == (byEditorSelected-EDITOR_SELECTED_OBJECT_XE))
				{
					SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_SETCURSEL, i, 0L);
					i  = -1;
					break;
				}
			}
			if(i != -1)
				SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_SETCURSEL, 0, 0L);

			SendDlgItemMessage(hWnd, IDC_EDITOR_ENEMIES_LIST, CB_RESETCONTENT , 0, 0L);
			SendDlgItemMessage(hWnd, IDC_EDITOR_ENEMIES_LIST, CB_ADDSTRING, 0, (LPARAM) "Hiro");
			SendDlgItemMessage(hWnd, IDC_EDITOR_ENEMIES_LIST, CB_ADDSTRING, 0, (LPARAM) "Mobmob");
			SendDlgItemMessage(hWnd, IDC_EDITOR_ENEMIES_LIST, CB_ADDSTRING, 0, (LPARAM) "X3");
			sprintf(byTemp, "%d", iEditorObjectsNumber);
			SetDlgItemText(hWnd, IDC_EDITOR_OBJECTS_NUMBER, byTemp);
			sprintf(byTemp, "%f", fEditorObjectVelocity);
			SetDlgItemText(hWnd, IDC_EDITOR_OBJECTS_VELOCITY, byTemp);

			// Rotation:
			sprintf(byTemp, "%d�", iEditorRotate*90);
			SetDlgItemText(hWnd, IDC_EDITOR_OBJECTS_ROTATION, byTemp);
			byEditorMenu = EDITOR_OBJECT_MENU;
			bEditorHeavy = FALSE;
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_EDITOR_OBJECTS_LIST:
					bEditorHeavy = SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_HEAVY, BM_GETCHECK, 0, 0L);
					byEditorSelectedType = OBJECT;
					i = (short) SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_GETCURSEL, 0, 0L);
					i = (short) SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_GETITEMDATA, i, 0L);
					if(i < 0)
						i = 0;
					if(i > 19)
						i = 19;
					switch(i)
					{
						case 0:
							byEditorSelected = EDITOR_SELECTED_OBJECT_XE;
							iEditorObjectsNumber = 1;
						break;
						
						case 1:
							byEditorSelected = EDITOR_SELECTED_OBJECT_BOX_NORMAL;
							iEditorObjectsNumber = 1;
						break;
						
						case 2:
							byEditorSelected = EDITOR_SELECTED_OBJECT_BOX_RED;
							iEditorObjectsNumber = 1;
						break;
						
						case 3:
							byEditorSelected = EDITOR_SELECTED_OBJECT_BOX_GREEN;
							iEditorObjectsNumber = 1;
						break;
						
						case 4:
							byEditorSelected = EDITOR_SELECTED_OBJECT_BOX_BLUE;
							iEditorObjectsNumber = 1;
						break;
						
						case 5:
							byEditorSelected = EDITOR_SELECTED_OBJECT_HEALTH;
							iEditorObjectsNumber = HEALTH_OBJ_NUMBER;
						break;
						
						case 6:	
							byEditorSelected = EDITOR_SELECTED_OBJECT_LIVE;
							iEditorObjectsNumber = LIVE_OBJ_NUMBER;
						break;
						
						case 7:
							byEditorSelected = EDITOR_SELECTED_OBJECT_PULL;
							iEditorObjectsNumber = PULL_OBJ_NUMBER;
						break;
						
						case 8:	
							byEditorSelected = EDITOR_SELECTED_OBJECT_THROW;
							iEditorObjectsNumber = THROW_OBJ_NUMBER;
						break;
						
						case 9:
							byEditorSelected = EDITOR_SELECTED_OBJECT_FORCE;
							iEditorObjectsNumber = FORCE_OBJ_NUMBER;
						break;
						
						case 10:
							byEditorSelected = EDITOR_SELECTED_OBJECT_WEAPON;
							iEditorObjectsNumber = WEAPON_OBJ_NUMBER;
						break;
						
						case 11:
							byEditorSelected = EDITOR_SELECTED_OBJECT_POINT;
							iEditorObjectsNumber = POINT_OBJ_NUMBER;
						break;
						
						case 12:
							byEditorSelected = EDITOR_SELECTED_OBJECT_GHOST;
							iEditorObjectsNumber = GHOST_TIME;
						break;
						
						case 13:
							byEditorSelected = EDITOR_SELECTED_OBJECT_TIME;
							iEditorObjectsNumber = TIME_OBJ_NUMBER;
						break;
						
						case 14:
							byEditorSelected = EDITOR_SELECTED_OBJECT_STEP;
							iEditorObjectsNumber = STEPS_OBJ_NUMBER;
						break;
						
						case 15:
							byEditorSelected = EDITOR_SELECTED_OBJECT_SPEED;
							iEditorObjectsNumber = SPEED_TIME;
						break;
						
						case 16:
							byEditorSelected = EDITOR_SELECTED_OBJECT_WING;
							iEditorObjectsNumber = WING_TIME;
						break;
						
						case 17:
							byEditorSelected = EDITOR_SELECTED_OBJECT_SHIELD;
							iEditorObjectsNumber = SHIELD_TIME;
						break;
						
						case 18:
							byEditorSelected = EDITOR_SELECTED_OBJECT_JUMP;
							iEditorObjectsNumber = JUMP_OBJ_NUMBER;
						break;
						
						case 19:
							byEditorSelected = EDITOR_SELECTED_OBJECT_AIR;
							iEditorObjectsNumber = 1;
						break;
					}
					sprintf(byTemp, "%d", iEditorObjectsNumber);
					SetDlgItemText(hWnd, IDC_EDITOR_OBJECTS_NUMBER, byTemp);
				break;

				case IDC_EDITOR_ENEMIES_LIST:
					bEditorHeavy = SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_HEAVY, BM_GETCHECK, 0, 0L);
					byEditorSelectedType = ENEMY;
					i = (short) SendDlgItemMessage(hWnd, IDC_EDITOR_ENEMIES_LIST, CB_GETCURSEL, 0, 0L);
					if(i < 0)
						i = 0;
					if(i > 2)
						i = 2;
					switch(i)
					{
						case 0: byEditorSelected = EDITOR_SELECTED_ENEMY_HIRO; break;
						case 1: byEditorSelected = EDITOR_SELECTED_ENEMY_MOBMOB; break;
						case 2: byEditorSelected = EDITOR_SELECTED_ENEMY_X3; break;
					}
					fEditorObjectVelocity = 1.0f;
					sprintf(byTemp, "%f", fEditorObjectVelocity);
					SetDlgItemText(hWnd, IDC_EDITOR_OBJECTS_VELOCITY, byTemp);
				break;

				case IDC_EDITOR_OBJECTS_PLUS:
					iEditorRotate++;
					if(iEditorRotate > 3)
						iEditorRotate = 0;
					goto Init;

				case IDC_EDITOR_OBJECTS_MINUS:
					iEditorRotate--;
					if(iEditorRotate < 0)
						iEditorRotate = 3;
					goto Init;
				
				case IDC_EDITOR_OBJECTS_HEAVY:
					bEditorHeavy = SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_HEAVY, BM_GETCHECK, 0, 0L);
				break;

				case IDC_EDITOR_OBJECTS_NUMBER:
					GetDlgItemText(hWnd, IDC_EDITOR_OBJECTS_NUMBER, byTemp, 256);
					iEditorObjectsNumber = atoi(byTemp);
				break;

				case IDC_EDITOR_OBJECTS_VELOCITY:
					GetDlgItemText(hWnd, IDC_EDITOR_OBJECTS_VELOCITY, byTemp, 256);
					fEditorObjectVelocity = (float) atof(byTemp);
				break;
            }
		break;
    }
    return FALSE;
} // end EditorObjectsProc()

LRESULT CALLBACK EditorTerrainProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorTerrainProc()
	if(!pLevel)
		return 0;

	switch(iMessage)
    {
        case WM_INITDIALOG:
  			// Texts:
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_COLOR, T_Color);
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_ALPHA, T_Alpha);
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_HEIGHT, T_Height);
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_POINT, T_Point);
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_MIDDLE_HEIGHT, T_MiddleHeight);
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_GREATEST_HEIGHT, T_GreatestHeight);
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_LOWEST_HEIGHT, T_LowestHeight);
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_TOP, T_Top);
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_FLOOR, T_Floor);
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_BOTH, T_Both);
			//
			byEditorMenu = EDITOR_TERRAIN_MENU;
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_EDITOR_TERRAIN_COLOR:
					byEditorSelected = EDITOR_SELECTED_COLOR;
				break;

				case IDC_EDITOR_TERRAIN_ALPHA:
					byEditorSelected = EDITOR_SELECTED_ALPHA;
				break;

				case IDC_EDITOR_TERRAIN_HEIGHT:
					byEditorSelected = EDITOR_SELECTED_HEIGHT;
				break;

				case IDC_EDITOR_TERRAIN_POINT:
					byEditorSelected = EDITOR_SELECTED_POINT;
				break;

				case IDC_EDITOR_TERRAIN_MIDDLE_HEIGHT:
					byEditorSelected = EDITOR_SELECTED_MIDDLE_HEIGHT;
				break;
				
				case IDC_EDITOR_TERRAIN_LOWEST_HEIGHT:
					byEditorSelected = EDITOR_SELECTED_LOWEST_HEIGHT;
				break;

				case IDC_EDITOR_TERRAIN_GREATEST_HEIGHT:
					byEditorSelected = EDITOR_SELECTED_GREATEST_HEIGHT;
				break;
            }
            break;
    }
    return FALSE;
} // end EditorTerrainProc()

LRESULT CALLBACK EditorEnvironmentProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorEnvironmentProc()
	char byTemp[256];
	short i;
	
	if(!pLevel)
		return 0;
	switch(iMessage)
    {
        case WM_INITDIALOG:
  			// Texts:
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_LIGHT, T_Color);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_FOG_T, T_Fog);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_FOG, T_Active);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_FOG_COLOR, T_Color);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_FOG_DENSITY, T_Density);
		    SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_FOG, BM_SETCHECK, pLevel->Environment.bFog, 0L);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_WATER_T, T_Water);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_WATER, T_Active);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_WATER_COLOR, T_Color);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_WATER_DENSITY, T_Density);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_WATER_HEIGHT, T_Height);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_WATER_AMPLITUDE, T_Amplitude);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_WATER_SPEED, T_SpeedObj);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_WATER_ENVIRONMENT_COLOR, T_EnvironmentColor);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_WATER_ENVIRONMENT, T_Environment);
		    SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_WATER, BM_SETCHECK, pLevel->Environment.bWater, 0L);
		    SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_WATER_ENVIRONMENT, BM_SETCHECK, pLevel->Environment.bWaterEnvironment, 0L);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_SKY_CUBE_T, T_SkyCube);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_SKY_CUBE, T_Active);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_SKY_CUBE_COLOR, T_Color);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SIZE, T_Size);
		    SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE, BM_SETCHECK, pLevel->Environment.bSkyCube, 0L);
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SIDE, CB_RESETCONTENT, 0, 0L);
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SIDE, CB_ADDSTRING, 0, (LPARAM) T_Floor);
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SIDE, CB_ADDSTRING, 0, (LPARAM) T_Sky);
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SIDE, CB_ADDSTRING, 0, (LPARAM) T_Back);
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SIDE, CB_ADDSTRING, 0, (LPARAM) T_Front);
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SIDE, CB_ADDSTRING, 0, (LPARAM) T_Right);
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SIDE, CB_ADDSTRING, 0, (LPARAM) T_Left);
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SIDE, CB_SETCURSEL, byCurrentSkyCubeSide, 0L);
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_ALL, CB_ADDSTRING, 0, (LPARAM) T_All);
			EnableWindow(GetDlgItem(hWnd, IDC_ENVIRONMENT_WATER_ENVIRONMENT), pLevel->Environment.bWater);
			//
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SURFACE, CB_RESETCONTENT, 0, 0L);
			for(i = 0; i < pLevel->Header.iSurfaces; i++)
			{
				sprintf(byTemp, "%s", pLevel->pSurface[i].Header.byName);
				SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SURFACE, CB_ADDSTRING, 0, (LPARAM) byTemp);
			}
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SURFACE, CB_SETCURSEL, pLevel->Environment.iSkyCubeSurface[byCurrentSkyCubeSide], 0L);
			byEditorMenu = EDITOR_ENVIRONMENT_MENU;
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_ENVIRONMENT_LIGHT: byEditorSelected = EDITOR_ENVIRONMENT_LIGHT; break;
				case IDC_ENVIRONMENT_FOG: pLevel->Environment.bFog = SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_FOG, BM_GETCHECK, 0, 0L); break;
		
				case IDC_ENVIRONMENT_WATER:
					pLevel->Environment.bWater = SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_WATER, BM_GETCHECK, 0, 0L);
					EnableWindow(GetDlgItem(hWnd, IDC_ENVIRONMENT_WATER_ENVIRONMENT), pLevel->Environment.bWater);
				break;
		
				case IDC_ENVIRONMENT_FOG_COLOR: byEditorSelected = EDITOR_ENVIRONMENT_FOG_COLOR; break;
				case IDC_ENVIRONMENT_FOG_DENSITY: byEditorSelected = EDITOR_ENVIRONMENT_FOG_DENSITY; break;
				case IDC_ENVIRONMENT_WATER_COLOR: byEditorSelected = EDITOR_ENVIRONMENT_WATER_COLOR; break;
				case IDC_ENVIRONMENT_WATER_DENSITY: byEditorSelected = EDITOR_ENVIRONMENT_WATER_DENSITY; break;
				case IDC_ENVIRONMENT_WATER_HEIGHT: byEditorSelected = EDITOR_ENVIRONMENT_WATER_HEIGHT; break;
				case IDC_ENVIRONMENT_WATER_AMPLITUDE: byEditorSelected = EDITOR_ENVIRONMENT_WATER_AMPLITUDE; break;
				case IDC_ENVIRONMENT_WATER_SPEED: byEditorSelected = EDITOR_ENVIRONMENT_WATER_SPEED; break;
				case IDC_ENVIRONMENT_WATER_ENVIRONMENT_COLOR: byEditorSelected = EDITOR_ENVIRONMENT_WATER_ENVIRONMENT_COLOR; break;
				case IDC_ENVIRONMENT_WATER_ENVIRONMENT: pLevel->Environment.bWaterEnvironment = SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_WATER_ENVIRONMENT, BM_GETCHECK, 0, 0L); break;

				case IDC_ENVIRONMENT_SKY_CUBE_SIDE:
					i = (short) SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SIDE, CB_GETCURSEL, 0, 0L);
					if(i < 0 || i > 6)
						byCurrentSkyCubeSide = 0;
					else
						byCurrentSkyCubeSide = (char) i;
					SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SURFACE, CB_SETCURSEL, pLevel->Environment.iSkyCubeSurface[byCurrentSkyCubeSide], 0L);
				break;

				case IDC_ENVIRONMENT_SKY_CUBE_SURFACE:
					i = (short) SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SURFACE, CB_GETCURSEL, 0, 0L);
					if(i < 0 || i > pLevel->Header.iSurfaces-1)
					{
						pLevel->iCurrentSurface	= -1;
						pLevel->pCurrentSurface = NULL;
					}
					else
						pLevel->Environment.iSkyCubeSurface[byCurrentSkyCubeSide] = pLevel->iCurrentSurface	= i;
				break;

				case IDC_ENVIRONMENT_SKY_CUBE: pLevel->Environment.bSkyCube = SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE, BM_GETCHECK, 0, 0L); break;
				case IDC_ENVIRONMENT_SKY_CUBE_COLOR: byEditorSelected = EDITOR_ENVIRONMENT_SKY_CUBE_COLOR; break;
				case IDC_ENVIRONMENT_SKY_CUBE_SIZE: byEditorSelected = EDITOR_ENVIRONMENT_SKY_CUBE_SIZE; break;

				case IDC_ENVIRONMENT_SKY_CUBE_PLUS:
					pLevel->Environment.iSkyCubeSurfaceRotation[byCurrentSkyCubeSide]++;
					if(pLevel->Environment.iSkyCubeSurfaceRotation[byCurrentSkyCubeSide] > 4)
						pLevel->Environment.iSkyCubeSurfaceRotation[byCurrentSkyCubeSide] = 0;
				break;

				case IDC_ENVIRONMENT_SKY_CUBE_MINUS:
					pLevel->Environment.iSkyCubeSurfaceRotation[byCurrentSkyCubeSide]--;
					if(pLevel->Environment.iSkyCubeSurfaceRotation[byCurrentSkyCubeSide] < 0)
						pLevel->Environment.iSkyCubeSurfaceRotation[byCurrentSkyCubeSide] = 4;
				break;

				case IDC_ENVIRONMENT_SKY_CUBE_ALL:
					for(i = 0; i < 6; i++)
					{
						pLevel->Environment.iSkyCubeSurface[i] = pLevel->iCurrentSurface;
						pLevel->Environment.iSkyCubeSurfaceRotation[i] = pLevel->Environment.iSkyCubeSurfaceRotation[byCurrentSkyCubeSide];
					}
				break;
            }
            break;
    }
    return FALSE;
} // end EditorEnvironmentProc()

LRESULT CALLBACK EditorCameraProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorCameraProc()
	char byTemp[256];
	BOOL bEnable;
	short i, i2;

	if(!pLevel)
		return 0;
	switch(iMessage)
    {
        case WM_INITDIALOG:
			// Texts:
			SetDlgItemText(hWnd, IDC_EDITOR_CAMERA_SET_VELOCITY, T_CameraVelocity);			

			if(!bCameraAnimation)
				SetDlgItemText(hWnd, IDC_EDITOR_CAMERA_PLAY, T_Play);
			else
				SetDlgItemText(hWnd, IDC_EDITOR_CAMERA_PLAY, T_Stop);
		Init:
  			if(!pLevel)
				break;
			SendDlgItemMessage(hWnd, ID_EDITOR_CAMERA_SELECTED, LB_RESETCONTENT, 0, 0L);
			for(i = 0; i < pLevel->Header.iCameraScripts; i++)
			{
				sprintf(byTemp, "%s", pLevel->pCameraScript[i].byName);
				SendDlgItemMessage(hWnd, ID_EDITOR_CAMERA_SELECTED, LB_ADDSTRING, 0, (LPARAM) byTemp);
			}
		Init2:
			if(pLevel->pCurrentCameraScript)
				SendDlgItemMessage(hWnd, IDC_EDITOR_CAMERA_TEXT_SCRIPT, LB_SETCURSEL, pLevel->pCurrentCameraScript->iTextScript+1, 0L);
			else
				SendDlgItemMessage(hWnd, IDC_EDITOR_CAMERA_TEXT_SCRIPT, LB_SETCURSEL, 0, 0L);
			if(pLevel->pCurrentCameraScript)
			{
				bEnable = TRUE;
				if(pLevel->Camera.iCurrentCameraStep < 0)
					pLevel->Camera.iCurrentCameraStep = 0;
				if(pLevel->Camera.iCurrentCameraStep >= pLevel->pCurrentCameraScript->iSteps)
					pLevel->Camera.iCurrentCameraStep = pLevel->pCurrentCameraScript->iSteps-1;
				SetDlgItemText(hWnd, IDC_EDITOR_CAMERA_NAME, pLevel->pCurrentCameraScript->byName);
				SendDlgItemMessage(hWnd, IDC_EDITOR_CAMERA_STEP_LIST, CB_RESETCONTENT, 0, 0L);
				for(i = 0; i < pLevel->pCurrentCameraScript->iSteps; i++)
				{
					sprintf(byTemp, "%d", i);
					SendDlgItemMessage(hWnd, IDC_EDITOR_CAMERA_STEP_LIST, CB_ADDSTRING, 0, (LPARAM) byTemp);
				}
				SendDlgItemMessage(hWnd, IDC_EDITOR_CAMERA_STEP_LIST, CB_SETCURSEL, pLevel->Camera.iCurrentCameraStep, 0L);
				sprintf(byTemp, "%d", pLevel->pCurrentCameraScript->pCamera[pLevel->Camera.iCurrentCameraStep].iTimeToNext);
				SetDlgItemText(hWnd, IDC_EDITOR_CAMERA_NEXT_TIME, byTemp);				

				SendDlgItemMessage(hWnd, IDC_EDITOR_CAMERA_TEXT_SCRIPT, CB_RESETCONTENT, 0, 0L);
				sprintf(byTemp, " - %s", T_NoTextScript);
				SendDlgItemMessage(hWnd, IDC_EDITOR_CAMERA_TEXT_SCRIPT, CB_ADDSTRING, 0, (LPARAM) byTemp);
				for(i = 0; i < pLevel->TextScriptsManager.iTextsScripts; i++)
				{
					sprintf(byTemp, "%d: %s", i, pTextScript[i].byName);
					SendDlgItemMessage(hWnd, IDC_EDITOR_CAMERA_TEXT_SCRIPT, CB_ADDSTRING, 0, (LPARAM) byTemp);
				}
				SendDlgItemMessage(hWnd, IDC_EDITOR_CAMERA_TEXT_SCRIPT, CB_SETCURSEL, pLevel->pCurrentCameraScript->iTextScript+1, 0L);
				
			}
			else
				bEnable = FALSE;
			EnableWindow(GetDlgItem(hWnd, ID_EDITOR_CAMERA_DUPLICATE), bEnable);
			EnableWindow(GetDlgItem(hWnd, ID_EDITOR_CAMERA_DELETE), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_NAME), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_COPY_LEFT), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_COPY), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_COPY_RIGHT), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_PLAY), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_STEPS), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_STEP_LIST), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_NEXT_TIME), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_NEXT_TIME_ALL), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_SET), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_TEXT_SCRIPT), bEnable);
			//
			byEditorMenu = EDITOR_CAMERA_MENU;
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_EDITOR_CAMERA_SET_VELOCITY:
					DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_SET_CAMERA_VELOCITY), hWnd, (DLGPROC) SetCameraVelocityProc);
				break;
				
				case ID_EDITOR_CAMERA_NEW:
					// Create a new camera script:
					pLevel->Header.iCameraScripts++;
					pLevel->pCameraScript = (AS_CAMERA_SCRIPT *) realloc(pLevel->pCameraScript, sizeof(AS_CAMERA_SCRIPT)*pLevel->Header.iCameraScripts);
					memset(&pLevel->pCameraScript[pLevel->Header.iCameraScripts-1], 0, sizeof(AS_CAMERA_SCRIPT));
					pLevel->iCurrentCameraScript = pLevel->Header.iCameraScripts-1;
					pLevel->pCurrentCameraScript = &pLevel->pCameraScript[pLevel->iCurrentCameraScript];
					// Create the temp camera:
					pLevel->pCurrentCameraScript->iSteps++;
					pLevel->pCurrentCameraScript->pCamera = (AS_CAMERA *) malloc(sizeof(AS_CAMERA)*pLevel->pCurrentCameraScript->iSteps);
					memset(&pLevel->pCurrentCameraScript->pCamera[0], 0, sizeof(AS_CAMERA));
					sprintf(pLevel->pCurrentCameraScript->byName, "Camera script %d", pLevel->iCurrentCameraScript);
					pLevel->pCurrentCameraScript->iTextScript = -1;
					goto Init;

				case ID_EDITOR_CAMERA_DUPLICATE:
					// Create a new camera script:
					pLevel->Header.iCameraScripts++;
					pLevel->pCameraScript = (AS_CAMERA_SCRIPT *) realloc(pLevel->pCameraScript, sizeof(AS_CAMERA_SCRIPT)*pLevel->Header.iCameraScripts);
					memset(&pLevel->pCameraScript[pLevel->Header.iCameraScripts-1], 0, sizeof(AS_CAMERA_SCRIPT));
					pLevel->pCurrentCameraScript = &pLevel->pCameraScript[pLevel->iCurrentCameraScript];
					// Copy the script into the duplicate:
					memcpy(&pLevel->pCameraScript[pLevel->Header.iCameraScripts-1], pLevel->pCurrentCameraScript, sizeof(AS_CAMERA_SCRIPT));
					pLevel->pCameraScript[pLevel->Header.iCameraScripts-1].pCamera = (AS_CAMERA *) malloc(sizeof(AS_CAMERA)*pLevel->pCameraScript[pLevel->Header.iCameraScripts-1].iSteps);
					for(i = 0; i < pLevel->pCurrentCameraScript->iSteps; i++)
						memcpy(&pLevel->pCameraScript[pLevel->Header.iCameraScripts-1].pCamera[i], &pLevel->pCurrentCameraScript->pCamera[i], sizeof(AS_CAMERA));
					// Setup new camera script:
					pLevel->iCurrentCameraScript = pLevel->Header.iCameraScripts-1;
					pLevel->pCurrentCameraScript = &pLevel->pCameraScript[pLevel->iCurrentCameraScript];
					sprintf(pLevel->pCurrentCameraScript->byName, "Camera script %d", pLevel->iCurrentCameraScript);
					goto Init;
				
				case ID_EDITOR_CAMERA_DELETE:
					// Update the camera users:
					if(pLevel->Camera.iStartCamera == pLevel->iCurrentCameraScript)
						pLevel->Camera.bStartCamera = FALSE;
					else
						if(pLevel->Camera.iStartCamera > pLevel->iCurrentCameraScript)
							pLevel->Camera.iStartCamera--;
					if(pLevel->Camera.iEndCamera == pLevel->iCurrentCameraScript)
						pLevel->Camera.bEndCamera = FALSE;
					else
						if(pLevel->Camera.iEndCamera > pLevel->iCurrentCameraScript)
							pLevel->Camera.iEndCamera--;
					for(i = 0; i < pLevel->Header.iFields; i++)
					{
						if(pLevel->pField[i].iCamera > pLevel->iCurrentCameraScript)
							pLevel->pField[i].iCamera--;
						if(pLevel->pField[i].iCamera == pLevel->iCurrentCameraScript)
							pLevel->pField[i].iCamera = -1;
					}

					// Delete the selected camera script:
					free(pLevel->pCurrentCameraScript->pCamera);
					for(i = pLevel->iCurrentCameraScript; i < pLevel->Header.iCameraScripts-1; i++)
						memcpy(&pLevel->pCameraScript[i], &pLevel->pCameraScript[i+1], sizeof(AS_CAMERA_SCRIPT));
					pLevel->Header.iCameraScripts--;
					pLevel->pCameraScript = (AS_CAMERA_SCRIPT *) realloc(pLevel->pCameraScript, sizeof(AS_CAMERA_SCRIPT)*pLevel->Header.iCameraScripts);
					if(pLevel->iCurrentCameraScript >= pLevel->Header.iCameraScripts)
						pLevel->iCurrentCameraScript = pLevel->Header.iCameraScripts-1;
					if(pLevel->iCurrentCameraScript != -1)
						pLevel->pCurrentCameraScript = &pLevel->pCameraScript[pLevel->iCurrentCameraScript];
					else
						pLevel->pCurrentCameraScript = NULL;
					goto Init;

				case ID_EDITOR_CAMERA_SELECTED:
					if(!pLevel)
						break;
					i = (short) SendDlgItemMessage(hWnd, ID_EDITOR_CAMERA_SELECTED, LB_GETCURSEL, 0, 0L);
					if(i < 0)
						i = 0;
					if(i >= pLevel->Header.iCameraScripts)
						i = pLevel->Header.iCameraScripts-1;
					pLevel->iCurrentCameraScript = i;
					if(pLevel->iCurrentCameraScript < 0)
					{
						pLevel->pCurrentCameraScript = NULL;
						break;
					}
					pLevel->pCurrentCameraScript = &pLevel->pCameraScript[pLevel->iCurrentCameraScript];
					goto Init2;

				case IDC_EDITOR_CAMERA_NAME:
					GetDlgItemText(hWnd, IDC_EDITOR_CAMERA_NAME, pLevel->pCurrentCameraScript->byName, 256);
					SendDlgItemMessage(hWnd, ID_EDITOR_CAMERA_SELECTED, LB_RESETCONTENT, 0, 0L);
					for(i = 0; i < pLevel->Header.iCameraScripts; i++)
					{
						sprintf(byTemp, "%s", pLevel->pCameraScript[i].byName);
						SendDlgItemMessage(hWnd, ID_EDITOR_CAMERA_SELECTED, LB_ADDSTRING, 0, (LPARAM) byTemp);
					}
					SendDlgItemMessage(hWnd, ID_EDITOR_CAMERA_SELECTED, LB_SETCURSEL, pLevel->iCurrentCameraScript, 0L);
				break;

				case IDC_EDITOR_CAMERA_COPY:
					if((i = DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_COPY_CAMERA_STEP), hWnd, (DLGPROC) CopyCameraStepProc)) == -1)
						break;
					memcpy(&pLevel->pCurrentCameraScript->pCamera[i], &pLevel->pCurrentCameraScript->pCamera[pLevel->Camera.iCurrentCameraStep], sizeof(AS_CAMERA));
					pLevel->Camera.iCurrentCameraStep = i;
					goto Init2;

				case IDC_EDITOR_CAMERA_COPY_LEFT:
					i = pLevel->Camera.iCurrentCameraStep-1;
					if(i < 0)
						i = pLevel->pCurrentCameraScript->iSteps-1;
					memcpy(&pLevel->pCurrentCameraScript->pCamera[i], &pLevel->pCurrentCameraScript->pCamera[pLevel->Camera.iCurrentCameraStep], sizeof(AS_CAMERA));
					pLevel->Camera.iCurrentCameraStep = i;
					goto Init2;

				case IDC_EDITOR_CAMERA_COPY_RIGHT:
					i = pLevel->Camera.iCurrentCameraStep+1;
					if(i >= pLevel->pCurrentCameraScript->iSteps)
						i = 0;
					memcpy(&pLevel->pCurrentCameraScript->pCamera[i], &pLevel->pCurrentCameraScript->pCamera[pLevel->Camera.iCurrentCameraStep], sizeof(AS_CAMERA));
					pLevel->Camera.iCurrentCameraStep = i;
					goto Init2;
				break;

				case IDC_EDITOR_CAMERA_STEPS:
					if((i = DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_SET_CAMERA_STEPS), hWnd, (DLGPROC) SetCameraStepsProc)) == -1)
						break;
					i2 = pLevel->pCurrentCameraScript->iSteps;
					pLevel->pCurrentCameraScript->iSteps = i;
					pLevel->pCurrentCameraScript->pCamera = (AS_CAMERA *) realloc(pLevel->pCurrentCameraScript->pCamera, sizeof(AS_CAMERA)*pLevel->pCurrentCameraScript->iSteps);
					for(; i2 < i; i2++)
						memset(&pLevel->pCurrentCameraScript->pCamera[i2], 0, sizeof(AS_CAMERA));
					if(pLevel->Camera.iCurrentCameraStep >= pLevel->pCurrentCameraScript->iSteps)
						pLevel->Camera.iCurrentCameraStep = pLevel->pCurrentCameraScript->iSteps-1;
					goto Init2;

				case IDC_EDITOR_CAMERA_NEXT_TIME:
					GetDlgItemText(hWnd, IDC_EDITOR_CAMERA_NEXT_TIME, byTemp, 256);
					pLevel->pCurrentCameraScript->pCamera[pLevel->Camera.iCurrentCameraStep].iTimeToNext = (short) atoi(byTemp);
				break;

				case IDC_EDITOR_CAMERA_NEXT_TIME_ALL:
					for(i = 0; i < pLevel->pCurrentCameraScript->iSteps; i++)
						pLevel->pCurrentCameraScript->pCamera[i].iTimeToNext = pLevel->pCurrentCameraScript->pCamera[pLevel->Camera.iCurrentCameraStep].iTimeToNext;
				break;

				case IDC_EDITOR_CAMERA_STEP_LIST:
					if(!pLevel || !pLevel->pCurrentCameraScript)
						goto Init;
					i = (short) SendDlgItemMessage(hWnd, IDC_EDITOR_CAMERA_STEP_LIST, CB_GETCURSEL, 0, 0L);
					if(i < 0)
						i = 0;
					if(i >= pLevel->pCurrentCameraScript->iSteps)
						i = pLevel->pCurrentCameraScript->iSteps-1;
					pLevel->Camera.iCurrentCameraStep = i;
					// Set the level camera to  this camera:
					memcpy(pCamera, &pLevel->pCurrentCameraScript->pCamera[pLevel->Camera.iCurrentCameraStep], sizeof(AS_CAMERA));
					goto Init2;
				
				case IDC_EDITOR_CAMERA_PLAY:
					lCameraTimer = g_lNow;
					bCameraAnimation = !bCameraAnimation;
					memset(&TempCamera, 0, sizeof(AS_CAMERA));
					if(!bCameraAnimation)
					{
						SetDlgItemText(hWnd, IDC_EDITOR_CAMERA_PLAY, T_Play);
						memcpy(pCamera, &pLevel->pCurrentCameraScript->pCamera[pLevel->Camera.iCurrentCameraStep], sizeof(AS_CAMERA));
					}
					else
					{
						SetDlgItemText(hWnd, IDC_EDITOR_CAMERA_PLAY, T_Stop);
						pLevel->Camera.iCurrentCameraStep = 0;
					}
				break;

				case IDC_EDITOR_CAMERA_SET:
					// Set the level camera to the camera from the script:
					memcpy(&pLevel->pCurrentCameraScript->pCamera[pLevel->Camera.iCurrentCameraStep], pCamera, sizeof(AS_CAMERA));
				break;

				case IDC_EDITOR_CAMERA_TEXT_SCRIPT:
					if(!pLevel || !pLevel->pCurrentCameraScript)
						goto Init;
					i = (short) SendDlgItemMessage(hWnd, IDC_EDITOR_CAMERA_TEXT_SCRIPT, CB_GETCURSEL, 0, 0L);
					if(i < 0 || i > pLevel->TextScriptsManager.iTextsScripts)
						break;
					pLevel->pCurrentCameraScript->iTextScript = i-1;
				break;
            }
            break;
    }
    return FALSE;
} // end EditorCameraProc()

LRESULT CALLBACK EditorDecorationProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorDecorationProc()
	if(!pLevel)
		return 0;
	switch(iMessage)
    {
        case WM_INITDIALOG:
			SetDlgItemText(hWnd, IDC_DECRATION_DECORATION, T_Decoration);
			if(!pLevel)
				break;
			//
			byEditorMenu = EDITOR_DECORATION_MENU;
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_DECRATION_DECORATION:
					KillTimer(hWndEditor, 1);
					DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_DECORATION), hWnd, (DLGPROC) DecorationProc);
					SetTimer(hWndEditor, 1, 1, NULL);
				break;
			}
            break;
    }
    return FALSE;
} // end EditorDecorationProc()

void SetupEditorTabs(void)
{ // begin SetupEditorTabs()
	HWND hWndTab;
	TC_ITEM tie; 

	// Setup editor tabs:
	hWndTab = GetDlgItem(hWndEditor, IDC_EDITOR_TAB);
	TabCtrl_DeleteAllItems(hWndTab);
	tie.mask = TCIF_TEXT;
	// Select:
	tie.pszText	= T_Select;
	TabCtrl_InsertItem(hWndTab, TAB_EDITOR_SELECT, &tie);
	if(hWndEditorTab[TAB_EDITOR_SELECT])
		DestroyWindow(hWndEditorTab[TAB_EDITOR_SELECT]);
	hWndEditorTab[TAB_EDITOR_SELECT] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_SELECT), hWndTab, (DLGPROC) EditorSelectProc, WM_INITDIALOG);
	// Brush:
	tie.pszText	= T_Brush;
	TabCtrl_InsertItem(hWndTab, TAB_EDITOR_BRUSH, &tie);
	if(hWndEditorTab[TAB_EDITOR_BRUSH])
		DestroyWindow(hWndEditorTab[TAB_EDITOR_BRUSH]);
	hWndEditorTab[TAB_EDITOR_BRUSH] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_BRUSH), hWndTab, (DLGPROC) EditorBrushProc, WM_INITDIALOG);
	// Surfaces:
	tie.pszText	= T_Surfaces;
	TabCtrl_InsertItem(hWndTab, TAB_EDITOR_SURFACES, &tie);
	if(hWndEditorTab[TAB_EDITOR_SURFACES])
		DestroyWindow(hWndEditorTab[TAB_EDITOR_SURFACES]);
	hWndEditorTab[TAB_EDITOR_SURFACES] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_SURFACES), hWndTab, (DLGPROC) EditorSurfacesProc, WM_INITDIALOG);
	// Objects:
	tie.pszText	= T_Objects;
	TabCtrl_InsertItem(hWndTab, TAB_EDITOR_OBJECTS, &tie);
	if(hWndEditorTab[TAB_EDITOR_OBJECTS])
		DestroyWindow(hWndEditorTab[TAB_EDITOR_OBJECTS]);
	hWndEditorTab[TAB_EDITOR_OBJECTS] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_OBJECTS), hWndTab, (DLGPROC) EditorObjectsProc, WM_INITDIALOG);
	// Terrain:
	tie.pszText	= T_Terrain;
	TabCtrl_InsertItem(hWndTab, TAB_EDITOR_TERRAIN, &tie);
	if(hWndEditorTab[TAB_EDITOR_TERRAIN])
		DestroyWindow(hWndEditorTab[TAB_EDITOR_TERRAIN]);
	hWndEditorTab[TAB_EDITOR_TERRAIN] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_TERRAIN), hWndTab, (DLGPROC) EditorTerrainProc, WM_INITDIALOG);
	// Environment:
	tie.pszText	= T_Environment;
	TabCtrl_InsertItem(hWndTab, TAB_EDITOR_ENVIRONMENT, &tie);
	if(hWndEditorTab[TAB_EDITOR_ENVIRONMENT])
		DestroyWindow(hWndEditorTab[TAB_EDITOR_ENVIRONMENT]);
	hWndEditorTab[TAB_EDITOR_ENVIRONMENT] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_ENVIRONMENT), hWndTab, (DLGPROC) EditorEnvironmentProc, WM_INITDIALOG);
	// Camera:
	tie.pszText	= T_Camera;
	TabCtrl_InsertItem(hWndTab, TAB_EDITOR_CAMERA, &tie);
	if(hWndEditorTab[TAB_EDITOR_CAMERA])
		DestroyWindow(hWndEditorTab[TAB_EDITOR_CAMERA]);
	hWndEditorTab[TAB_EDITOR_CAMERA] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_CAMERA), hWndTab, (DLGPROC) EditorCameraProc, WM_INITDIALOG);
	// Decoration:
	tie.pszText	= T_Decoration;
	TabCtrl_InsertItem(hWndTab, TAB_EDITOR_DECORATION, &tie);
	if(hWndEditorTab[TAB_EDITOR_DECORATION])
		DestroyWindow(hWndEditorTab[TAB_EDITOR_DECORATION]);
	hWndEditorTab[TAB_EDITOR_DECORATION] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_DECORATION), hWndTab, (DLGPROC) EditorDecorationProc, WM_INITDIALOG);

	//
	if(iCurrentEditorTab != -1 && iCurrentEditorTab < EDITOR_TABS)
	{
		TabCtrl_SetCurSel(GetDlgItem(hWndEditor, IDC_EDITOR_TAB), iCurrentEditorTab);
		ShowWindow(hWndEditorTab[iCurrentEditorTab], SW_SHOW);
	}
	SendMessage(hWndEditor, WM_NOTIFY, IDC_EDITOR_TAB, 0);
	ShowWindow(hWndEditor, _AS->GetCmdShow());
	UpdateWindow(hWndEditor);
} // end SetupEditorTabs()

void SetEditorLanguage(void)
{ // begin SetEditorLanguage()
	if(!hWndEditor)
		return;
	SetWindowText(hWndEditor, T_Editor);
	SetDlgItemText(hWndEditor, IDC_EDITOR_SIZE_TEXT, T_Size_);

	SetupEditorTabs();
} // end SetEditorLanguage()

LRESULT CALLBACK KeywordProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin KeywordProc()
	char byTemp[256];

    switch(iMessage)
    {
        case WM_INITDIALOG:
			hWndKeyword = hWnd;
			KeywordLanguage();
			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_KEYWORD_OK:
					hWndKeyword = NULL;
					// Check if this keyword is right:
					GetDlgItemText(hWnd, ID_KEYWORD_KEYWORD, byTemp, 256);
					if(!strcmp(byKeyword, byTemp))
						EndDialog(hWnd, 1);
					else
						EndDialog(hWnd, 0);
                return TRUE;

                case ID_KEYWORD_CANCEL:
					hWndKeyword = NULL;
					EndDialog(hWnd, -1);
                return TRUE;
            }
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_KEYWORD_CANCEL, 0);
		break;
    }
    return FALSE;
} // end KeywordProc()

void KeywordLanguage(void)
{ // begin KeywordLanguage()
	SetWindowText(hWndKeyword, T_Keyword);
	SetDlgItemText(hWndKeyword, ID_SET_ANIMATION_STEPS_OK, T_Ok);
	SetDlgItemText(hWndKeyword, ID_SET_ANIMATION_STEPS_CANCEL, T_Cancel);
} // end KeywordLanguage()

HRESULT SaveLevelQuestion(void)
{ // begin SaveLevelQuestion()
	char *pbyTemp, byTemp[256];
	int i;
	
	KillTimer(hWndEditor, 1);
	i = MessageBox(hWndEditor, M_SaveCurrentLevelQuestion, T_Question, MB_YESNOCANCEL | MB_ICONQUESTION);
	SetTimer(hWndEditor, 1, 1, NULL);
	if(i == IDCANCEL)
		return 1;
	if(i == IDYES)
	{ // Save the current level:
		_AS->WriteLogMessage("Save level %s", pLevel->Header.byFilename);
		sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbySingleLevelsFile);
		KillTimer(hWndEditor, 1);
		pbyTemp = ASGetFileName(hWndEditor, T_SaveLevel, LEV_FILE, 1, FALSE, byTemp);
		SetTimer(hWndEditor, 1, 1, NULL);
		if(!pbyTemp)
			return 1;
		pLevel->Save(pbyTemp);
	}
	return 0;
} // end SaveLevelQuestion();

LRESULT CALLBACK SetCameraVelocityProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin SetCameraVelocityProc()
	char byTemp[256];

    switch(iMessage)
    {
        case WM_INITDIALOG:
			SetWindowText(hWnd, T_CameraVelocity);
			SetDlgItemText(hWnd, ID_SET_CAMERA_VELOCITY_OK, T_Ok);
			SetDlgItemText(hWnd, ID_SET_CAMERA_VELOCITY_CANCEL, T_Cancel);
			sprintf(byTemp, "%f", fCameraVelocity);
			SetDlgItemText(hWnd, ID_SET_CAMERA_VELOCITY_NUMBER, byTemp);
			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_SET_CAMERA_VELOCITY_OK:
					GetDlgItemText(hWnd, ID_SET_CAMERA_VELOCITY_NUMBER, byTemp, 256);
					fCameraVelocity = (float) atof(byTemp);
					EndDialog(hWnd, 0);
                return TRUE;

                case ID_SET_CAMERA_VELOCITY_CANCEL:
					EndDialog(hWnd, 0);
                return TRUE;
            }
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_SET_CAMERA_VELOCITY_CANCEL, 0);
		break;
    }
    return FALSE;
} // end SetCameraVelocityProc()

LRESULT CALLBACK CopyCameraStepProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin CopyCameraStepProc()
	char byTemp[256];
	short i;

    switch(iMessage)
    {
        case WM_INITDIALOG:
			sprintf(byTemp, "%s (Nr. %d)", T_CopyTexturePos, pLevel->Camera.iCurrentCameraStep);
			SetWindowText(hWnd, byTemp);
			SetDlgItemText(hWnd, ID_COPY_CAMERA_STEP_OK, T_Ok);
			SetDlgItemText(hWnd, ID_COPY_CAMERA_STEP_CANCEL, T_Cancel);
			SendDlgItemMessage(hWnd, ID_COPY_CAMERA_STEP_LIST, CB_RESETCONTENT , 0, 0L);
			for(i = 0; i < pLevel->pCurrentCameraScript->iSteps; i++)
			{
				sprintf(byTemp, "%d", i);
				SendDlgItemMessage(hWnd, ID_COPY_CAMERA_STEP_LIST, CB_ADDSTRING, 0, (LPARAM) byTemp);
			}
			SendDlgItemMessage(hWnd, ID_COPY_CAMERA_STEP_LIST, CB_SETCURSEL, pLevel->Camera.iCurrentCameraStep, 0L);
			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_COPY_CAMERA_STEP_OK:
					EndDialog(hWnd, SendDlgItemMessage(hWnd, ID_COPY_CAMERA_STEP_LIST, CB_GETCURSEL, 0, 0L));
                return TRUE;

                case ID_COPY_CAMERA_STEP_CANCEL:
					EndDialog(hWnd, -1);
                return TRUE;
            }
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_COPY_CAMERA_STEP_CANCEL, 0);
		break;
    }
    return FALSE;
} // end CopyCameraStepProc()

LRESULT CALLBACK SetCameraStepsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin SetCameraStepsProc()
	char byTemp[256];
	short i;

    switch(iMessage)
    {
        case WM_INITDIALOG:
			SetWindowText(hWnd, T_SetCameraSteps);
			SetDlgItemText(hWnd, ID_SET_CAMERA_STEPS_OK, T_Ok);
			SetDlgItemText(hWnd, ID_SET_CAMERA_STEPS_CANCEL, T_Cancel);
			sprintf(byTemp, "%d", pLevel->pCurrentCameraScript->iSteps);
			SetDlgItemText(hWnd, ID_SET_CAMERA_STEPS_NUMBER, byTemp);
			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_SET_CAMERA_STEPS_OK:
					GetDlgItemText(hWnd, ID_SET_CAMERA_STEPS_NUMBER, byTemp, 256);
					i = (short) atoi(byTemp);
					if(!i)
						i++;
					EndDialog(hWnd, i);
                return TRUE;

                case ID_SET_CAMERA_STEPS_CANCEL:
					EndDialog(hWnd, -1);
                return TRUE;
            }
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_SET_CAMERA_STEPS_CANCEL, 0);
		break;
    }
    return FALSE;
} // end SetCameraStepsProc()
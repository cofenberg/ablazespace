//-----------------------------------------------------------------------------
// File: Enemies.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Functions: *****************************************************************
void DrawEnemyHiro(ACTOR *);
void CheckEnemyHiro(ACTOR *, BOOL);
void DrawEnemyMobmob(ACTOR *);
void CheckEnemyMobmob(ACTOR *, BOOL);
void DrawEnemyX3(ACTOR *);
void CheckEnemyX3(ACTOR *, BOOL);
///////////////////////////////////////////////////////////////////////////////


void DrawEnemyHiro(ACTOR *pActorT)
{ // begin DrawEnemyHiro()
	pActorT->fWorldPos[X] = pActorT->iFieldPos[X]*pLevel->Header.fFieldWidth+pActorT->fFieldPos[X];
	pActorT->fWorldPos[Y] = pActorT->iFieldPos[Y]*pLevel->Header.fFieldHeight+pActorT->fFieldPos[Y];
	ComputeActorHeight(pActorT, 0.2f);
	//
	glPushMatrix();
	glEnable(GL_TEXTURE_2D);
	glCullFace(GL_FRONT);

	glColor4f(pActorT->fColor[0], pActorT->fColor[1], pActorT->fColor[2], 0.99f);
	
	glTranslatef(pActorT->fWorldPos[X]+0.6f, pActorT->fWorldPos[Y]+0.4f, pActorT->fWorldPos[Z]-0.3f);
	glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
	glRotatef(-pActorT->fRot[Y]+50.0f, 0.0f, 1.0f, 0.0f);
	glScalef(0.04f, 0.04f, 0.04f);

	glBindTexture(GL_TEXTURE_2D, GameTexture[HIRO_TEXTURE].iOpenGLID);

	pActorT->fModelInterpolation = (float) (g_lNow-pActorT->dwAniTime)/(float) (PLAYER_ANIMATION_SPEED);
	ASDrawMd2FrameInt(pHiroModel, pActorT->iAniStep, pActorT->iNextAniStep, pActorT->fModelInterpolation);

	if(_ASConfig->bDrawBounding)
		DrawBoundingBox(pHiroModel->fBoundingBox, 0.025f);
	glCullFace(GL_BACK);
	glDisable(GL_BLEND);
	glPopMatrix();
	if(!bPause || pLevel->State.bLevelComplete)
	{
		if(pLevel->pField[pActorT->iFieldID].bOnScreen)
			AnimateActorModel(pActorT, *pHiroModel, 150, 1);
		else
			pActorT->dwAniTime = g_lNow; // The actor isn't on screen;
	}
} // end DrawEnemyHiro()

void CheckEnemyHiro(ACTOR *pActorT, BOOL bOnlyAnimate)
{ // begin CheckEnemyHiro()
	if(bOnlyAnimate)
		return;

	if(!ActorTurn(pActorT, 1.0f))
	{ // Move:
	}

	if(pActorT->iParticleSystemID == -1)
	{
		pActorT->iParticleSystemID = ParticleManager.AddNewSystem(PS_Smoke2, 50, pActorT, &GameTexture[12], NULL);
		ParticleManager.pSystem[pActorT->iParticleSystemID].bActive = TRUE;
		ParticleManager.pSystem[pActorT->iParticleSystemID].fStartPos[X] = pActorT->fWorldPos[X]+0.5f;
		ParticleManager.pSystem[pActorT->iParticleSystemID].fStartPos[Y] = pActorT->fWorldPos[Y]+0.5f;
		ParticleManager.pSystem[pActorT->iParticleSystemID].fStartPos[Z] = pActorT->fWorldPos[Z]-0.5f;
		ParticleManager.pSystem[pActorT->iParticleSystemID].pActor = pActorT;
		ParticleManager.pSystem[pActorT->iParticleSystemID].iVertex = 1;
	}
} // end CheckEnemyHiro()

void DrawEnemyMobmob(ACTOR *pActorT)
{ // begin DrawEnemyMobmob()
	float f;

	if(!bPause || pLevel->State.bLevelComplete)
	{
		if(!pActorT->bGoingDeath2)
		{
			if(pActorT->bGoingDeath)
				AnimateActorModel(pActorT, *pMobmobModel, 200, (char) pActorT->byAnimation);
			else
				AnimateActorModel(pActorT, *pMobmobModel, (long) (300*(50.0f/(pActorT->fPower+0.001f))*pActorT->fVelocity[1]), (char) pActorT->byAnimation);
		}
		else
			pActorT->dwAniTime = g_lNow; // The actor isn't on screen;
	}

	if(!pActorT->bBeaming)
	{
		pActorT->fWorldPos[X] = pActorT->iFieldPos[X]*pLevel->Header.fFieldWidth+pActorT->fFieldPos[X];
		pActorT->fWorldPos[Y] = pActorT->iFieldPos[Y]*pLevel->Header.fFieldHeight+pActorT->fFieldPos[Y];
		ComputeActorHeight(pActorT, 0.2f);
	}
	//
	glPushMatrix();
	glEnable(GL_TEXTURE_2D);
	glCullFace(GL_FRONT);

	glColor4f(pActorT->fColor[0], pActorT->fColor[1], pActorT->fColor[2], 0.99f);
	
	glTranslatef(pActorT->fWorldPos[X]+0.5f, pActorT->fWorldPos[Y]+0.5f, pActorT->fWorldPos[Z]-0.75f);
	glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
	glRotatef(-pActorT->fRot[Y], 0.0f, 1.0f, 0.0f);
	glScalef(0.03f, 0.03f, 0.03f);

	if(pActorT->bGoingDeath2)
		f = 1.0f-((float) (g_lNow-pActorT->lStartTime)/PLAYER_DEAD_FLOOR_TIME);
	if(pActorT->bBeaming)
		f = pActorT->fBeaming;
	if(pActorT->bGoingDeath2 || pActorT->bBeaming)
	{ // The player lies dead on the floor:
		glEnable(GL_BLEND);
		glColor4f(pActorT->fColor[0], pActorT->fColor[1], pActorT->fColor[2], f);
		glDepthMask(FALSE);
	}

	glBindTexture(GL_TEXTURE_2D, GameTexture[MOBMOB_TEXTURE].iOpenGLID);

	if(pActorT->bGoingDeath)
		pActorT->fModelInterpolation = (float) (g_lNow-pActorT->dwAniTime)/(float) (200);
	else
		pActorT->fModelInterpolation = (float) (g_lNow-pActorT->dwAniTime)/(float) (300*(50.0f/(pActorT->fPower+0.001f))*pActorT->fVelocity[1]);
	ASDrawMd2FrameInt(pMobmobModel, pActorT->iAniStep, pActorT->iNextAniStep, pActorT->fModelInterpolation);

	if(_ASConfig->bDrawBounding)
		DrawBoundingBox(pMobmobModel->fBoundingBox, 0.025f);
	glDepthMask(TRUE);
	glCullFace(GL_BACK);
	glDisable(GL_BLEND);
	glPopMatrix();
} // end DrawEnemyMobmob()

void CheckEnemyMobmob(ACTOR *pActorT, BOOL bOnlyAnimate)
{ // begin CheckEnemyMobmob()
	short iX, iY, iX2, iY2, i, i2, iTempDirection, iTempDirection2;
	FLOAT3 fPos, fPos2;
	float fX, fY;
	ACTOR *pActorT2;

	if(!pActorT->bActive ||
	   CheckBeamingProcess(pActorT))
		return;
	pLevel->pField[pActorT->iFieldID].pEnemy = pActorT;
	if(bOnlyAnimate)
	{
		if(pActorT->byAction != ACTION_STAND)
		{
			pActorT->byAction = ACTION_STAND;
			pActorT->byAnimation = 1;
			pActorT->iAniStep = pMobmobModel->Ani.anim[pActorT->byAnimation].firstFrame;
			pActorT->dwAniTime = g_lNow;
		}	
		return;
	}

	if(bPause)
		return;
	// Normalize the colors:
	for(i = 0; i < 3; i++)
		if(pActorT->fColor[i] < 1.0f)
		{
			pActorT->fColor[i] += (float) g_lDeltatime/PLAYER_PAINT_SPEED;
			if(pActorT->fColor[i] > 1.0f)
				pActorT->fColor[i] = 1.0f;
		}	
	if(pActorT->fPower != 100.0f)
		pActorT->fPower = pActorT->fPower;
	pActorT->fPower += (float) 100.0f*(g_lDeltatime/PLAYER_PAINT_SPEED);
	if(pActorT->fPower > 100.0f)
		pActorT->fPower = 100.0f;

	fPos2[X] = pPlayer->fWorldPos[X]+0.5f;
	fPos2[Y] = pPlayer->fWorldPos[Y]+0.5f;
	fPos2[Z] = pPlayer->fWorldPos[Z]-0.6f;
	ASGetMd2Vertex(pXeModel, pPlayer->iAniStep, pPlayer->iNextAniStep, pPlayer->fModelInterpolation, fPos2, 0.025f,
				   -90.0f, pPlayer->fRot[Y], 0.0f, 72, &fPos);
	if(pActorT->bGoingDeath)
	{ // The actor is death:
		if(pActorT->byAction != ACTION_PLAYER_DEATH)
		{
			pActorT->byAction = ACTION_PLAYER_DEATH;
			pActorT->byAnimation = 4;
			pActorT->iAniStep = 52;
			pActorT->dwAniTime = g_lNow;
			pLevel->pField[pActorT->iFieldID].pEnemy = NULL;
		}
		if(pActorT->iNextAniStep == 59 && !pActorT->bGoingDeath2)
		{ // The actor lies now a few seconds on the floor:
			pActorT->iAniStep = 59;
			pActorT->bGoingDeath2 = TRUE;
			pActorT->lStartTime = g_lNow;
			pLevel->pField[pActorT->iFieldID].pEnemy = NULL;
			if(pLevel->Missions.iKillMobmobs-pLevel->State.iKilledMobmobs >= 0)
				pLevel->State.iKilledMobmobs++;
		}
		if(pActorT->bGoingDeath2 && g_lNow-pActorT->lStartTime > PLAYER_DEAD_FLOOR_TIME)
			pActorT->bActive = FALSE;
		return;
	}
	else
	{ // Check if something could kill this actor:
		for(i = 0; i < MAX_ACTORS; i++)
		{
			pActorT2 = &Actor[i];
			if(!pActorT2->bActive || (pActorT2->byType != ACTOR_BOX_NORMAL &&
			   pActorT2->byType != ACTOR_BOX_RED &&
			   pActorT2->byType != ACTOR_BOX_GREEN &&
			   pActorT2->byType != ACTOR_BOX_BLUE &&
			   pActorT2->byType != ACTOR_PLAYER_SHOT) ||
			   pActorT2->bGoingDeath || pActorT2->bBridge)
				continue;
			// Yea, check it:
			fX = pActorT->fWorldPos[X]-pActorT2->fWorldPos[X];
			fY = pActorT->fWorldPos[Y]-pActorT2->fWorldPos[Y];
			if(fX < 0.0f)
				fX = -fX;
			if(fY < 0.0f)
				fY = -fY;
			if(fX < 0.6f && fY < 0.4f)
			{ // Yep, our fried is now DEAD
				pActorT2->bThrow = FALSE;
				DamageBox(pActorT2);
				if(pActorT2->byType == ACTOR_PLAYER_SHOT)
				{
					if(pActorT2->fWorldPos[Z] > pActorT->fWorldPos[Z]-1.0f)
					{
						pActorT2->bGoingDeath = TRUE;
						pActorT->fPower -= 30.0f;
						pActorT->fColor[1] -= 0.4f;
						if(pActorT->fColor[1] < 0.0f)
							pActorT->fColor[1] = 0.0f;
						pActorT->fColor[2] -= 0.4f;
						if(pActorT->fColor[2] < 0.0f)
							pActorT->fColor[2] = 0.0f;
						if(pActorT->fPower <= 0.0f)
							pActorT->bGoingDeath = TRUE;
					}
				}
				else
					pActorT->bGoingDeath = TRUE;
				return;
			}
		}
		if(!pLevel->pField[pActorT->iFieldID].bActive)
			pActorT->bGoingDeath = TRUE;
		// Check if he collide with the player:
		if(pPlayer->bActive && !PlayerInfo.bShield &&
		   !PlayerInfo.bGhost && !pPlayer->bGoingDeath &&
		   fPos[Z] > pActorT->fWorldPos[Z]-1.0f &&
		   !pPlayer->bBeaming)
		{
			fX = pActorT->fWorldPos[X]-pPlayer->fWorldPos[X];
			fY = pActorT->fWorldPos[Y]-pPlayer->fWorldPos[Y];
			if(fX < 0.0f)
				fX = -fX;
			if(fY < 0.0f)
				fY = -fY;
			if(fX < 0.6f && fY < 0.4f)
			{ // Yep:
				pPlayer->fPower -= (float) g_lDeltatime/10;
				if(pPlayer->fPower < 0.0f)
					pPlayer->fPower = 0.0f;
				return;
			}
		}
	}

// Move:
Top:
	iTempDirection = iTempDirection2 = -1;
	if(!ActorTurn(pActorT, 1.0f))
	{
		if(!pActorT->bMove)
		{ // Check what he should do now:
			if(CheckBeaming(pActorT))
				return;
			// Check, if the player is in range to ran to him:
			iX = pActorT->iFieldPos[X]-pPlayer->iFieldPos[X];
			iY = pActorT->iFieldPos[Y]-pPlayer->iFieldPos[Y];
			if(iX < 0)
				iX = -iX;
			if(iY < 0)
				iY = -iY;
			if(iX < 2 && iY < 2 && pPlayer->bActive && !pPlayer->bGoingDeath &&
			   !PlayerInfo.bGhost && !pPlayer->bBeaming)
			{ // Ok, check if we could go to him:
				if(!(rand() % 2))
				{
					if(pActorT->iFieldPos[X] > pPlayer->iFieldPos[X])
						iTempDirection2 = LEFT;
					else
						iTempDirection2 = RIGHT;
				}
				else
				{
					if(pActorT->iFieldPos[Y] > pPlayer->iFieldPos[Y])
						iTempDirection2 = UP;
					else
						iTempDirection2 = DOWN;
				}
			}
			//
			// Setup x/y direction:
			switch(pActorT->byDirection)
			{
				case RIGHT: iX = 1; iY = 0; break;
				case DOWN: iX = 0; iY = 1; break;
				case LEFT: iX = -1; iY = 0; break;
				case UP: iX = 0; iY = -1; break;
			}
			// Check if there is an wall is movement direction:
			if(pActorT->iFieldPos[X]+iX < 0 ||
			   pActorT->iFieldPos[Y]+iY < 0 || 
			   pActorT->iFieldPos[X]+iX >= pLevel->Header.iWidth-1 ||
			   pActorT->iFieldPos[Y]+iY >= pLevel->Header.iHeight-1 ||
			   pLevel->pField[pActorT->iFieldPos[Y]*pLevel->Header.iWidth+pActorT->iFieldPos[X]].bWall ||
			   pLevel->pField[(pActorT->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pActorT->iFieldPos[X]+iX].bWall ||
			   pLevel->pField[(pActorT->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pActorT->iFieldPos[X]+iX].pEnemy ||
			   !pLevel->pField[(pActorT->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pActorT->iFieldPos[X]+iX].bActive ||
			   iTempDirection2 != -1)
			{ // Yes, there is an wall:
				iTempDirection = pActorT->byDirection;
				pActorT->pVelocityFromActor = NULL;
				// Check free direction:
				if(iTempDirection2 == -1)
					i = (rand() % 4);
				else
					i = iTempDirection2;
				for(i2 = 0; i2 < 4; i++, i2++)
				{
					if(i >= 4)
						i = 0;
					switch(i)
					{
						case RIGHT: iX2 = 1; iY2 = 0; break;
						case DOWN: iX2 = 0; iY2 = 1; break;
						case LEFT: iX2 = -1; iY2 = 0; break;
						case UP: iX2= 0; iY2 = -1; break;
					}
					// Is it free?
					if(pActorT->iFieldPos[X]+iX2 >= 0 &&
					   pActorT->iFieldPos[Y]+iY2 >= 0 && 
					   pActorT->iFieldPos[X]+iX2 <= pLevel->Header.iWidth-2 &&
					   pActorT->iFieldPos[Y]+iY2 <= pLevel->Header.iHeight-2 &&
					   !pLevel->pField[pActorT->iFieldPos[Y]*pLevel->Header.iWidth+pActorT->iFieldPos[X]].bWall &&
					   !pLevel->pField[(pActorT->iFieldPos[Y]+iY2)*pLevel->Header.iWidth+pActorT->iFieldPos[X]+iX2].bWall &&
					   !pLevel->pField[(pActorT->iFieldPos[Y]+iY2)*pLevel->Header.iWidth+pActorT->iFieldPos[X]+iX2].pEnemy &&
					   pLevel->pField[(pActorT->iFieldPos[Y]+iY2)*pLevel->Header.iWidth+pActorT->iFieldPos[X]+iX2].bActive)
					{ // Yep!
						pActorT->byDirection = (char) i;
						pActorT->bShouldMove = TRUE;
						break;
					}
				}
				if(pActorT->byDirection == iTempDirection && pActorT->byAction != ACTION_WRONG)
				{ // The actor has no change to escape!
					pActorT->byAction = ACTION_WRONG;
					pActorT->byAnimation = 3;
					pActorT->iAniStep = pMobmobModel->Ani.anim[pActorT->byAnimation].firstFrame;
					pActorT->dwAniTime = g_lNow;
				}
			}
			else
			{ // What now?
				pActorT->bShouldMove = TRUE;
			}
		}
		
		// Check movement:
		if(pActorT->bShouldMove)
		{ // The actor is ready for moving:
			if(!(rand() % 10))
			{
				pActorT->bShouldMove = FALSE;
				pActorT->byDirection = rand() % 4;
				goto Top;
			}
			else
			{
				pActorT->bMove = TRUE;
				pActorT->bShouldMove = FALSE;
				pActorT->fVelocity[0] = (400*(50.0f/(pActorT->fPower+0.001f)));
				if(pActorT->byAction != ACTION_RUN_UP)
				{
					pActorT->byAction = ACTION_RUN_UP;
					pActorT->byAnimation = 2;
					pActorT->iAniStep = pMobmobModel->Ani.anim[pActorT->byAnimation].firstFrame;
					pActorT->dwAniTime = g_lNow;
				}
			}
		}
		pActorT->fFriction = pLevel->pField[pActorT->iFieldID].pSurface[FACE_FLOOR][0]->Header.fFriction;
		pLevel->pField[pActorT->iFieldID].pEnemy = NULL;
		MoveActor(pActorT, 8000);
		pLevel->pField[pActorT->iFieldID].pEnemy = pActorT;
		return;
	}
	else
	{
		pActorT->bShouldMove = pActorT->bMove = FALSE;
	}

	if(pActorT->byDirection != iTempDirection &&
	   !pActorT->bShouldMove && !pActorT->bMove && pActorT->byAction != ACTION_STAND)
	{
		pActorT->byAction = ACTION_STAND;
		pActorT->byAnimation = 1;
		pActorT->iAniStep = pMobmobModel->Ani.anim[pActorT->byAnimation].firstFrame;
		pActorT->dwAniTime = g_lNow;
	}
} // end CheckEnemyMobmob()

void DrawEnemyX3(ACTOR *pActorT)
{ // begin DrawEnemyX3()
	float f;
	
	if(!bPause || pLevel->State.bLevelComplete)
	{
		if(!pActorT->bGoingDeath2)
		{
			if(!pActorT->bGoingDeath)
			{
				if(pActorT->byAction == ACTION_PLAYER_PAIN_1)
					AnimateActorModel(pActorT, *pX3Model, 400, (char) pActorT->byAnimation);
				else
					AnimateActorModel(pActorT, *pX3Model, (long) (400*(50.0f/(pActorT->fPower+0.001f))*pActorT->fVelocity[1]), (char) pActorT->byAnimation);
			}
			else
				AnimateActorModel(pActorT, *pX3Model, 500, (char) pActorT->byAnimation);
		}
		else
			pActorT->dwAniTime = g_lNow; // The actor isn't on screen;
		if(pActorT->bGoingDeath2)
		{
			if(!pActorT->bHeavy)
				pActorT->iAniStep = 121;
			else
				pActorT->iAniStep = 116;
		}
	}

	if(!pActorT->bBeaming)
	{
		pActorT->fWorldPos[X] = pActorT->iFieldPos[X]*pLevel->Header.fFieldWidth+pActorT->fFieldPos[X];
		pActorT->fWorldPos[Y] = pActorT->iFieldPos[Y]*pLevel->Header.fFieldHeight+pActorT->fFieldPos[Y];
		ComputeActorHeight(pActorT, 0.2f);
	}
	//
	glPushMatrix();
	glEnable(GL_TEXTURE_2D);
	glCullFace(GL_FRONT);

	glColor4f(pActorT->fColor[0], pActorT->fColor[1], pActorT->fColor[2], 0.99f);
	
	glTranslatef(pActorT->fWorldPos[X]+0.5f, pActorT->fWorldPos[Y]+0.5f, pActorT->fWorldPos[Z]-0.4f);
	glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
	glRotatef(-pActorT->fRot[Y], 0.0f, 1.0f, 0.0f);
	glScalef(0.02f, 0.02f, 0.02f);

	if(pActorT->bGoingDeath2)
		f = 1.0f-((float) (g_lNow-pActorT->lStartTime)/PLAYER_DEAD_FLOOR_TIME);
	if(pActorT->bBeaming)
		f = pActorT->fBeaming;
	if(pActorT->bGoingDeath2 || pActorT->bBeaming)
	{ // The player lies dead on the floor:
		glEnable(GL_BLEND);
		glColor4f(pActorT->fColor[0], pActorT->fColor[1], pActorT->fColor[2], f);
		glDepthMask(FALSE);
	}

	glBindTexture(GL_TEXTURE_2D, GameTexture[X3_TEXTURE].iOpenGLID);

	if(!pActorT->bGoingDeath)
	{
		if(pActorT->byAction == ACTION_PLAYER_PAIN_1)
			pActorT->fModelInterpolation = (float) (g_lNow-pActorT->dwAniTime)/(float) (400);
		else
			pActorT->fModelInterpolation = (float) (g_lNow-pActorT->dwAniTime)/(float) (400*(50.0f/(pActorT->fPower+0.001f))*pActorT->fVelocity[1]);
	}
	else
		pActorT->fModelInterpolation = (float) (g_lNow-pActorT->dwAniTime)/(float) (500);
	ASDrawMd2FrameInt(pX3Model, pActorT->iAniStep, pActorT->iNextAniStep, pActorT->fModelInterpolation);

	if(_ASConfig->bDrawBounding)
		DrawBoundingBox(pX3Model->fBoundingBox, 0.025f);
	glDepthMask(TRUE);
	glCullFace(GL_BACK);
	glDisable(GL_BLEND);
	glPopMatrix();
} // end DrawEnemyX3()

void CheckEnemyX3(ACTOR *pActorT, BOOL bOnlyAnimate)
{ // begin CheckEnemyX3()
	short iX, iY, iX2, iY2, i, i2, iTempDirection, iTempDirection2;
	float fX, fY, fTemp;
	FLOAT3 fPos, fPos2;
	ACTOR *pActorT2;

	if(!pActorT->bActive ||
	   CheckBeamingProcess(pActorT))
		return;
	if(pLevel->pField[pActorT->iFieldID].pActor == pActorT)
		pLevel->pField[pActorT->iFieldID].pActor = NULL;
	

	if(bOnlyAnimate)
	{
		if(pActorT->byAction != ACTION_STAND)
		{
			pActorT->byAction = ACTION_STAND;
			if(!pActorT->bHeavy)
				pActorT->byAnimation = 1;
			else
				pActorT->byAnimation = 6;
			pActorT->iAniStep = pX3Model->Ani.anim[pActorT->byAnimation].firstFrame;
			pActorT->dwAniTime = g_lNow;
		}	
		return;
	}
	if(bPause)
		return;
	if(!pActorT->bHeavy)
	{
		if((pActorT->byAction == ACTION_PLAYER_PAIN_1 && 
			pActorT->iNextAniStep == 57) ||
		   (pActorT->byAction == ACTION_SHOT && 
			pActorT->iNextAniStep == 52))
		{
			pActorT->byAction = -1;
		}
	}
	else
	{
		if((pActorT->byAction == ACTION_PLAYER_PAIN_1 && 
			pActorT->iNextAniStep == 111) ||
		   (pActorT->byAction == ACTION_SHOT && 
			pActorT->iNextAniStep == 107))
		{
			pActorT->byAction = -1;
		}
	}
	fPos2[X] = pPlayer->fWorldPos[X]+0.5f;
	fPos2[Y] = pPlayer->fWorldPos[Y]+0.5f;
	fPos2[Z] = pPlayer->fWorldPos[Z]-0.6f;
	ASGetMd2Vertex(pXeModel, pPlayer->iAniStep, pPlayer->iNextAniStep, pPlayer->fModelInterpolation, fPos2, 0.025f,
				   -90.0f, pPlayer->fRot[Y], 0.0f, 72, &fPos);
	if(pActorT->bGoingDeath)
	{ // The actor is death:
		if(pActorT->byAction != ACTION_PLAYER_DEATH)
		{
   			pActorT->byAction = ACTION_PLAYER_DEATH;
			if(!pActorT->bHeavy)
				pActorT->byAnimation = 11;
			else
				pActorT->byAnimation = 10;
			pActorT->iAniStep = pX3Model->Ani.anim[pActorT->byAnimation].firstFrame;
			pActorT->dwAniTime = g_lNow;
			pLevel->pField[pActorT->iFieldID].pEnemy = NULL;
		}
		if(((!pActorT->bHeavy && pActorT->iNextAniStep == 121) ||
		    (pActorT->bHeavy && pActorT->iNextAniStep == 116)) &&
			!pActorT->bGoingDeath2)
		{ // The actor lies now a few seconds on the floor:
			if(!pActorT->bHeavy)
				pActorT->iAniStep = 121;
			else
				pActorT->iAniStep = 116;
			pActorT->bGoingDeath2 = TRUE;
			pActorT->lStartTime = g_lNow;
			pLevel->pField[pActorT->iFieldID].pEnemy = NULL;
			if(pLevel->Missions.iKillX3-pLevel->State.iKilledX3 >= 0)
				pLevel->State.iKilledX3++;
		}
		if(pActorT->bGoingDeath2 && g_lNow-pActorT->lStartTime > PLAYER_DEAD_FLOOR_TIME)
			pActorT->bActive = FALSE;
		return;
	}
	else
	{ // Check if something could kill this actor:
		for(i = 0; i < MAX_ACTORS; i++)
		{
			pActorT2 = &Actor[i];
			if(!pActorT2->bActive || (pActorT2->byType != ACTOR_BOX_NORMAL &&
			   pActorT2->byType != ACTOR_BOX_RED &&
			   pActorT2->byType != ACTOR_BOX_GREEN &&
			   pActorT2->byType != ACTOR_BOX_BLUE &&
			   pActorT2->byType != ACTOR_PLAYER_SHOT) ||
			   pActorT2->bGoingDeath || pActorT2->bBridge)
				continue;
			// Yea, check it:
			fX = pActorT->fWorldPos[X]-pActorT2->fWorldPos[X];
			fY = pActorT->fWorldPos[Y]-pActorT2->fWorldPos[Y];
			if(fX < 0.0f)
				fX = -fX;
			if(fY < 0.0f)
				fY = -fY;
			if(fX < 0.4f && fY < 0.4f)
			{ // Yep, our fried is now DEAD
				pActorT2->bThrow = FALSE;
				DamageBox(pActorT2);
				if(pActorT2->byType == ACTOR_PLAYER_SHOT)
				{
					if(!pActorT->bHeavy)
						fTemp = 0.45f;
					else
						fTemp = 0.05f;
					if(pActorT2->fWorldPos[Z] > pActorT->fWorldPos[Z]-fTemp)
					{
						pActorT2->bGoingDeath = TRUE;
						pActorT->fPower -= 30.0f;
						pActorT->fColor[0] -= 0.4f;
						if(pActorT->fColor[0] < 0.0f)
							pActorT->fColor[0] = 0.0f;
						pActorT->fColor[1] -= 0.4f;
						if(pActorT->fColor[1] < 0.0f)
							pActorT->fColor[1] = 0.0f;
						pActorT->fColor[2] -= 0.4f;
						if(pActorT->fColor[2] < 0.0f)
							pActorT->fColor[2] = 0.0f;
						if(pActorT->fPower <= 0.0f)
							pActorT->bGoingDeath = TRUE;
   						pActorT->byAction = ACTION_PLAYER_PAIN_1;
						if(!pActorT->bHeavy)
							pActorT->byAnimation = 4;
						else
							pActorT->byAnimation = 9;
						pActorT->iAniStep = pX3Model->Ani.anim[pActorT->byAnimation].firstFrame;
						pActorT->dwAniTime = g_lNow;
					}
				}
				else
					pActorT->bGoingDeath = TRUE;
				return;
			}
		}
		if(!pActorT->bHeavy)
			fTemp = 0.45f;
		else
			fTemp = 0.05f;
		if(!pLevel->pField[pActorT->iFieldID].bActive)
			pActorT->bGoingDeath = TRUE;
		// Check if he collide with the player:
		if(pPlayer->bActive && !PlayerInfo.bShield &&
		   !PlayerInfo.bGhost && !pPlayer->bGoingDeath &&
		   fPos[Z] > pActorT->fWorldPos[Z]-fTemp &&
		   !pPlayer->bBeaming)
		{
			fX = pActorT->fWorldPos[X]-pPlayer->fWorldPos[X];
			fY = pActorT->fWorldPos[Y]-pPlayer->fWorldPos[Y];
			if(fX < 0.0f)
				fX = -fX;
			if(fY < 0.0f)
				fY = -fY;
			if(fX < 0.4f && fY < 0.4f)
			{ // Yep:
				pPlayer->fPower -= (float) g_lDeltatime/10;
				if(pPlayer->fPower < 0.0f)
					pPlayer->fPower = 0.0f;
				return;
			}
		}
	}

// Move:
	iTempDirection = iTempDirection2 = -1;
	if(!ActorTurn(pActorT, 1.0f) && pActorT->byAction != ACTION_PLAYER_PAIN_1 &&
	   pActorT->byAction != ACTION_SHOT)
	{
		if(!pActorT->bMove)
		{ // Check what he should do now:
			if(CheckBeaming(pActorT))
				return;
			// Setup x/y direction:
			switch(pActorT->byDirection)
			{
				case RIGHT: iX = 1; iY = 0; break;
				case DOWN: iX = 0; iY = 1; break;
				case LEFT: iX = -1; iY = 0; break;
				case UP: iX = 0; iY = -1; break;
			}
			// Check if the player is in front of this actor:
			if(pActorT->iFieldPos[X]+iX == pPlayer->iFieldPos[X] &&
			   pActorT->iFieldPos[Y]+iY == pPlayer->iFieldPos[Y] &&
			   pPlayer->bActive && !pPlayer->bGoingDeath &&
			   !PlayerInfo.bGhost && pPlayer->fPower > 0.0f)
			{ // Yea, attack, him!!
				pActorT->byAction = ACTION_SHOT;
				if(!pActorT->bHeavy)
					pActorT->byAnimation = 3;
				else
					pActorT->byAnimation = 8;
				pActorT->iAniStep = pX3Model->Ani.anim[pActorT->byAnimation].firstFrame;
				pActorT->dwAniTime = g_lNow;
        		i = ParticleManager.AddNewSystem(PS_X3Acid, 10, pActorT, &GameTexture[23], NULL);
				ParticleManager.pSystem[i].bActive = TRUE;
				if(!PlayerInfo.bShield)
				{
					// Hurt the player:
					pPlayer->fPower -= (10.0f);
					MakePlayerCameraRotation(ACTION_PLAYER_PAIN_2);
					if(pPlayer->byAction != ACTION_PLAYER_PAIN_1 && pPlayer->byAction != ACTION_SHOT)
					{
						pPlayer->byAction = ACTION_PLAYER_PAIN_1;
						pPlayer->byAnimation = 4;
						pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
						pPlayer->dwAniTime = g_lNow;
					}
				}
				return;
			}
			// Check if there is an wall is movement direction:
			if(pActorT->iFieldPos[X]+iX < 0 ||
			   pActorT->iFieldPos[Y]+iY < 0 || 
			   pActorT->iFieldPos[X]+iX >= pLevel->Header.iWidth-1 ||
			   pActorT->iFieldPos[Y]+iY >= pLevel->Header.iHeight-1 ||
			   pLevel->pField[pActorT->iFieldPos[Y]*pLevel->Header.iWidth+pActorT->iFieldPos[X]].bWall ||
			   pLevel->pField[(pActorT->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pActorT->iFieldPos[X]+iX].bWall ||
			   pLevel->pField[(pActorT->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pActorT->iFieldPos[X]+iX].pEnemy ||
			   !pLevel->pField[(pActorT->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pActorT->iFieldPos[X]+iX].bActive)
			{ // Yes, there is an wall:
				iTempDirection = pActorT->byDirection;
				pActorT->pVelocityFromActor = NULL;
				// Check free direction:
				iTempDirection2 = (iTempDirection+2) % 4;
				if(pActorT->bHeavy)
				{
					i = iTempDirection2;
					iTempDirection2 = -1;
				}
				else
					i = (rand() % 4);
			Again:
				for(i2 = 0; i2 < 4; i++, i2++)
				{
					if(i == iTempDirection2)
						continue;
					if(i >= 4)
						i = 0;
					switch(i)
					{
						case RIGHT: iX2 = 1; iY2 = 0; break;
						case DOWN: iX2 = 0; iY2 = 1; break;
						case LEFT: iX2 = -1; iY2 = 0; break;
						case UP: iX2= 0; iY2 = -1; break;
					}
					// Is it free?
					if(pActorT->iFieldPos[X]+iX2 >= 0 &&
					   pActorT->iFieldPos[Y]+iY2 >= 0 && 
					   pActorT->iFieldPos[X]+iX2 <= pLevel->Header.iWidth-2 &&
					   pActorT->iFieldPos[Y]+iY2 <= pLevel->Header.iHeight-2 &&
					   !pLevel->pField[pActorT->iFieldPos[Y]*pLevel->Header.iWidth+pActorT->iFieldPos[X]].bWall &&
					   !pLevel->pField[(pActorT->iFieldPos[Y]+iY2)*pLevel->Header.iWidth+pActorT->iFieldPos[X]+iX2].bWall &&
					   !pLevel->pField[(pActorT->iFieldPos[Y]+iY2)*pLevel->Header.iWidth+pActorT->iFieldPos[X]+iX2].pEnemy &&
					   pLevel->pField[(pActorT->iFieldPos[Y]+iY2)*pLevel->Header.iWidth+pActorT->iFieldPos[X]+iX2].bActive)
					{ // Yep!
						pActorT->byDirection = (char) i;
						pActorT->bShouldMove = TRUE;
						break;
					}
				}
				if(!pActorT->bShouldMove && !pActorT->bHeavy &&
				   iTempDirection == pActorT->byDirection &&
				   iTempDirection2 != -1)
				{
					iTempDirection2 = -1;
					goto Again;
				}
				if(pActorT->byDirection == iTempDirection && pActorT->byAction != ACTION_WRONG)
				{ // The actor has no change to escape!
					pActorT->byAction = ACTION_WRONG;
					if(!pActorT->bHeavy)
						pActorT->byAnimation = 5;
					else
						pActorT->byAnimation = 6;
					pActorT->iAniStep = pX3Model->Ani.anim[pActorT->byAnimation].firstFrame;
					pActorT->dwAniTime = g_lNow;
				}
			}
			else
			{ // What now?
				pActorT->bShouldMove = TRUE;
			}
		}
		
		// Check movement:
		if(pActorT->bShouldMove)
		{ // The actor is ready for moving:
			pActorT->bMove = TRUE;
			pActorT->bShouldMove = FALSE;
			if(!pActorT->bHeavy)
				pActorT->fVelocity[0] = (800*(50.0f/(pActorT->fPower+0.001f)))*pActorT->fVelocity[1];
			else
				pActorT->fVelocity[0] = (2000*(50.0f/(pActorT->fPower+0.001f)))*pActorT->fVelocity[1];
			if(pActorT->byAction != ACTION_RUN_UP)
			{
				pActorT->byAction = ACTION_RUN_UP;
				if(!pActorT->bHeavy)
					pActorT->byAnimation = 2;
				else
					pActorT->byAnimation = 7;
				pActorT->iAniStep = pX3Model->Ani.anim[pActorT->byAnimation].firstFrame;
				pActorT->dwAniTime = g_lNow;
			}
		}
		pActorT->fFriction = pLevel->pField[pActorT->iFieldID].pSurface[FACE_FLOOR][0]->Header.fFriction;
		pLevel->pField[pActorT->iFieldID].pEnemy = NULL;
		MoveActor(pActorT, 8000);
		pLevel->pField[pActorT->iFieldID].pEnemy = pActorT;
		return;
	}
	else
	{
		pActorT->bShouldMove = pActorT->bMove = FALSE;
	}

	if(pActorT->byDirection != iTempDirection &&
	   !pActorT->bShouldMove && !pActorT->bMove && pActorT->byAction != ACTION_STAND &&
	   pActorT->byAction != ACTION_PLAYER_PAIN_1 &&
	   pActorT->byAction != ACTION_SHOT)
	{
		pActorT->byAction = ACTION_STAND;
		if(!pActorT->bHeavy)
			pActorT->byAnimation = 1;
		else
			pActorT->byAnimation = 6;
		pActorT->iAniStep = pX3Model->Ani.anim[pActorT->byAnimation].firstFrame;
		pActorT->dwAniTime = g_lNow;
	}
} // end CheckEnemyX3()
//-----------------------------------------------------------------------------
// File: Missions.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


void LEVEL::InitMissions(void)
{ // begin LEVEL::InitMissions()
	// Initalize the level missions state:
	State.bLevelComplete = FALSE;
	State.iUsedForAllAnchors = State.iUsedNormalAnchors = State.iUsedRedAnchors = State.iUsedGreenAnchors = State.iUsedBlueAnchors =
	State.iDestroyedNormalBoxes = State.iDestroyedRedBoxes = State.iDestroyedGreenBoxes = State.iDestroyedBlueBoxes = 
	State.iNoneFreeNormalBoxes = State.iNoneFreeRedBoxes = State.iNoneFreeGreenBoxes = State.iNoneFreeBlueBoxes = 0;
	State.iCollectedPoints = State.iKilledMobmobs = State.iKilledX3 = 0;

	if(Missions.bExit)
		State.bMissionExitComplete = FALSE;
	else
		State.bMissionExitComplete = TRUE;
	if(Missions.bAlcove)
		State.bMissionAlcoveComplete = FALSE;
	else
		State.bMissionAlcoveComplete = TRUE;

	// Collect objects:
	if(Missions.bCollectPoints)
		State.bMissionCollectPointsComplete = FALSE;
	else
		State.bMissionCollectPointsComplete = FALSE;
	if(Missions.bCollectHealth)
		State.bMissionCollectHealthComplete = FALSE;
	else
		State.bMissionCollectHealthComplete = FALSE;
	if(Missions.bKillMobmobs)
		State.bMissionKillMobmobsComplete = FALSE;
	else
		State.bMissionKillMobmobsComplete = FALSE;
	if(Missions.bKillX3)
		State.bMissionKillX3Complete = FALSE;
	else
		State.bMissionKillX3Complete = FALSE;
	
	// Anchors:
	if(Missions.bNoFreeForAllAnchor)
		State.bMissionNoFreeForAllAnchorComplete = FALSE;
	else
		State.bMissionNoFreeForAllAnchorComplete = TRUE;
	if(Missions.bNoFreeNormalAnchor)
		State.bMissionNoFreeNormalAnchorComplete = FALSE;
	else
		State.bMissionNoFreeNormalAnchorComplete = TRUE;
	if(Missions.bNoFreeRedAnchor)
		State.bMissionNoFreeRedAnchorComplete = FALSE;
	else
		State.bMissionNoFreeRedAnchorComplete = TRUE;
	if(Missions.bNoFreeGreenAnchor)
		State.bMissionNoFreeGreenAnchorComplete = FALSE;
	else
		State.bMissionNoFreeGreenAnchorComplete = TRUE;
	if(Missions.bNoFreeBlueAnchor)
		State.bMissionNoFreeBlueAnchorComplete = FALSE;
	else
		State.bMissionNoFreeBlueAnchorComplete = TRUE;

	// No free boxes:
	if(Missions.bNoFreeNormalBox)
		State.bMissionNoFreeNormalBoxesComplete = FALSE;
	else
		State.bMissionNoFreeNormalBoxesComplete = TRUE;
	if(Missions.bNoFreeRedBox)
		State.bMissionNoFreeRedBoxesComplete = FALSE;
	else
		State.bMissionNoFreeRedBoxesComplete = TRUE;
	if(Missions.bNoFreeGreenBox)
		State.bMissionNoFreeGreenBoxesComplete = FALSE;
	else
		State.bMissionNoFreeGreenBoxesComplete = TRUE;
	if(Missions.bNoFreeBlueBox)
		State.bMissionNoFreeBlueBoxesComplete = FALSE;
	else
		State.bMissionNoFreeBlueBoxesComplete = TRUE;

	// Destroyed boxes:
	if(Missions.bNoNormalBox)
		State.bMissionNoNormalBoxesComplete = FALSE;
	else
		State.bMissionNoNormalBoxesComplete = TRUE;
	if(Missions.bNoRedBox)
		State.bMissionNoRedBoxesComplete = FALSE;
	else
		State.bMissionNoRedBoxesComplete = TRUE;
	if(Missions.bNoGreenBox)
		State.bMissionNoGreenBoxesComplete = FALSE;
	else
		State.bMissionNoGreenBoxesComplete = TRUE;
	if(Missions.bNoBlueBox)
		State.bMissionNoBlueBoxesComplete = FALSE;
	else
		State.bMissionNoBlueBoxesComplete = TRUE;

} // end LEVEL::InitMissions()

void LEVEL::CheckMissions(void)
{ // begin LEVEL::CheckMissions()
	char byTemp[256];
	short i;

	if(State.bLevelComplete)
		return;
	if(Missions.bExit)
	{
		if(pField[pPlayer->iFieldID].pSurface[FACE_FLOOR][0]->Header.bExit && 
		   pPlayer->fFieldPos[X] == 0.0f && pPlayer->fFieldPos[Y] == 0.0f &&
		   pPlayer->byAction != ACTION_JUMP)
			State.bMissionExitComplete = TRUE;
		else
			State.bMissionExitComplete = FALSE;
	}
	else
		State.bMissionExitComplete = TRUE;
	if(Missions.bAlcove)
	{
		if(pField[pPlayer->iFieldID].pSurface[FACE_FLOOR][0]->Header.bAlcove && 
		   pPlayer->fFieldPos[X] == 0.0f && pPlayer->fFieldPos[Y] == 0.0f &&
		   pPlayer->byAction != ACTION_JUMP)
			State.bMissionAlcoveComplete = TRUE;
		else
			State.bMissionAlcoveComplete = FALSE;
	}
	else
		State.bMissionAlcoveComplete = TRUE;

	// Collect objects:
	if(Missions.bCollectPoints)
	{
		if(State.iCollectedPoints < Missions.iCollectPoints)
		{
			if(State.bMissionCollectPointsComplete)
			{
				sprintf(byTemp, "%s -> %s", T_CollectPoints, T_Incomplete);
				ShowSmallMessage(byTemp, 2000);
				State.bMissionCollectPointsComplete = FALSE;
			}
		}
		else
		{
			if(!State.bMissionCollectPointsComplete)
			{
				sprintf(byTemp, "%s -> %s", T_CollectPoints, T_Complete);
				ShowSmallMessage(byTemp, 2000);
				State.bMissionCollectPointsComplete = TRUE;
			}
		}
	}
	else
		State.bMissionCollectPointsComplete = TRUE;
	if(Missions.bCollectHealth)
	{
		if(pPlayer->fPower < Missions.iCollectHealth)
		{
			if(State.bMissionCollectHealthComplete)
			{
				sprintf(byTemp, "%s -> %s", T_CollectHealth, T_Incomplete);
				ShowSmallMessage(byTemp, 2000);
				State.bMissionCollectHealthComplete = FALSE;
			}
		}
		else
		{
			if(!State.bMissionCollectHealthComplete)
			{
				sprintf(byTemp, "%s -> %s", T_CollectHealth, T_Complete);
				ShowSmallMessage(byTemp, 2000);
				State.bMissionCollectHealthComplete = TRUE;
			}
		}
	}
	else
		State.bMissionCollectHealthComplete = TRUE;

	if(Missions.bKillMobmobs)
	{
		if(State.iKilledMobmobs >= Missions.iKillMobmobs && !State.bMissionKillMobmobsComplete)
		{
			sprintf(byTemp, "%s -> %s", T_KillMobmobs, T_Complete);
			ShowSmallMessage(byTemp, 2000);
			State.bMissionKillMobmobsComplete = TRUE;
		}
	}
	else
		State.bMissionKillMobmobsComplete = TRUE;
	if(Missions.bKillX3)
	{
		if(State.iKilledX3 >= Missions.iKillX3 && !State.bMissionKillX3Complete)
		{
			sprintf(byTemp, "%s -> %s", T_KillX3, T_Complete);
			ShowSmallMessage(byTemp, 2000);
			State.bMissionKillX3Complete = TRUE;
		}
	}
	else
		State.bMissionKillX3Complete = TRUE;

	// Check anchors:
	if(Missions.bNoFreeForAllAnchor && State.iUsedForAllAnchors == Header.iForAllAnchors)
	{
		if(!State.bMissionNoFreeForAllAnchorComplete)
		{
			sprintf(byTemp, "%s -> %s", T_FillAllForAllAnchors, T_Complete);
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeForAllAnchorComplete = TRUE;
		}
	}
	else
	{
		if(Missions.bNoFreeForAllAnchor && State.bMissionNoFreeForAllAnchorComplete)
		{
			sprintf(byTemp, "%s -> %s", T_FillAllForAllAnchors, T_Incomplete);
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeForAllAnchorComplete = FALSE;
		}
	}
	if(Missions.bNoFreeNormalAnchor && State.iUsedNormalAnchors == Header.iNormalAnchors)
	{
		if(!State.bMissionNoFreeNormalAnchorComplete)
		{
			sprintf(byTemp, "%s -> %s", T_FillAllNormalAnchors, T_Complete);
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeNormalAnchorComplete = TRUE;
		}
	}
	else
	{
		if(Missions.bNoFreeNormalAnchor && State.bMissionNoFreeNormalAnchorComplete)
		{
			sprintf(byTemp, "%s -> %s", T_FillAllNormalAnchors, T_Incomplete);
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeNormalAnchorComplete = FALSE;
		}
	}
	if(Missions.bNoFreeRedAnchor && State.iUsedRedAnchors == Header.iRedAnchors)
	{
		if(!State.bMissionNoFreeRedAnchorComplete)
		{
			sprintf(byTemp, "%s -> %s", T_FillAllRedAnchors, T_Complete);
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeRedAnchorComplete = TRUE;
		}
	}
	else
	{
		if(Missions.bNoFreeRedAnchor && State.bMissionNoFreeRedAnchorComplete)
		{
			sprintf(byTemp, "%s -> %s", T_FillAllRedAnchors, T_Incomplete);
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeRedAnchorComplete = FALSE;
		}
	}
	if(Missions.bNoFreeGreenAnchor && State.iUsedGreenAnchors == Header.iGreenAnchors)
	{
		if(!State.bMissionNoFreeGreenAnchorComplete)
		{
			sprintf(byTemp, "%s -> %s", T_FillAllGreenAnchors, T_Complete);
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeGreenAnchorComplete = TRUE;
		}
	}
	else
	{
		if(Missions.bNoFreeGreenAnchor && State.bMissionNoFreeGreenAnchorComplete)
		{
			sprintf(byTemp, "%s -> %s", T_FillAllGreenAnchors, T_Incomplete);
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeGreenAnchorComplete = FALSE;
		}
	}
	if(Missions.bNoFreeBlueAnchor && State.iUsedBlueAnchors == Header.iBlueAnchors)
	{
		if(!State.bMissionNoFreeBlueAnchorComplete)
		{
			sprintf(byTemp, "%s -> %s", T_FillAllBlueAnchors, T_Complete);
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeBlueAnchorComplete = TRUE;
		}
	}
	else
	{
		if(Missions.bNoFreeBlueAnchor && State.bMissionNoFreeBlueAnchorComplete)
		{
			sprintf(byTemp, "%s -> %s", T_FillAllBlueAnchors, T_Incomplete);
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeBlueAnchorComplete = FALSE;
		}
	}

	// Check free boxes:
	if(Missions.bNoFreeNormalBox && State.iNoneFreeNormalBoxes == Header.iNormalBoxes)
	{
		if(!State.bMissionNoFreeNormalBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", T_NoFreeNormalBox, T_Complete);
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeNormalBoxesComplete = TRUE;
		}
	}
	else
	{
		if(Missions.bNoFreeNormalBox && State.bMissionNoFreeNormalBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", T_NoFreeNormalBox, T_Incomplete);
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeNormalBoxesComplete = FALSE;
		}
	}
	if(Missions.bNoFreeRedBox && State.iNoneFreeRedBoxes == Header.iRedBoxes)
	{
		if(!State.bMissionNoFreeRedBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", T_NoFreeRedBox, T_Complete);
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeRedBoxesComplete = TRUE;
		}
	}
	else
	{
		if(Missions.bNoFreeRedBox && State.bMissionNoFreeRedBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", T_NoFreeRedBox, T_Incomplete);
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeRedBoxesComplete = FALSE;
		}
	}
	if(Missions.bNoFreeGreenBox && State.iNoneFreeGreenBoxes == Header.iGreenBoxes)
	{
		if(!State.bMissionNoFreeGreenBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", T_NoFreeGreenBox, T_Complete);
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeGreenBoxesComplete = TRUE;
		}
	}
	else
	{
		if(Missions.bNoFreeGreenBox && State.bMissionNoFreeGreenBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", T_NoFreeGreenBox, T_Incomplete);
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeGreenBoxesComplete = FALSE;
		}
	}
	if(Missions.bNoFreeBlueBox && State.iNoneFreeBlueBoxes == Header.iBlueBoxes)
	{
		if(!State.bMissionNoFreeBlueBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", T_NoFreeBlueBox, T_Complete);
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeBlueBoxesComplete = TRUE;
		}
	}
	else
	{
		if(Missions.bNoFreeBlueBox && State.bMissionNoFreeBlueBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", T_NoFreeBlueBox, T_Incomplete);
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoFreeBlueBoxesComplete = FALSE;
		}
	}

	// Check destroyed boxes:
	if(Missions.bNoNormalBox && State.iDestroyedNormalBoxes == Header.iNormalBoxes)
	{
		if(!State.bMissionNoNormalBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", T_DestroyAllNormalBoxes, T_Complete);
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoNormalBoxesComplete = TRUE;
		}
	}
	else
	{
		if(Missions.bNoNormalBox && State.bMissionNoNormalBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", T_DestroyAllNormalBoxes, T_Incomplete);
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoNormalBoxesComplete = FALSE;
		}
	}
	if(Missions.bNoRedBox && State.iDestroyedRedBoxes == Header.iRedBoxes)
	{
		if(!State.bMissionNoRedBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", T_DestroyAllRedBoxes, T_Complete);
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoRedBoxesComplete = TRUE;
		}
	}
	else
	{
		if(Missions.bNoRedBox && State.bMissionNoRedBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", T_DestroyAllRedBoxes, T_Incomplete);
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoRedBoxesComplete = FALSE;
		}
	}
	if(Missions.bNoGreenBox && State.iDestroyedGreenBoxes == Header.iGreenBoxes)
	{
		if(!State.bMissionNoGreenBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", T_DestroyAllGreenBoxes, T_Complete);
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoGreenBoxesComplete = TRUE;
		}
	}
	else
	{
		if(Missions.bNoGreenBox && State.bMissionNoGreenBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", T_DestroyAllGreenBoxes, T_Incomplete);
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoGreenBoxesComplete = FALSE;
		}
	}
	if(Missions.bNoBlueBox && State.iDestroyedBlueBoxes == Header.iBlueBoxes)
	{
		if(!State.bMissionNoBlueBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", T_DestroyAllBlueBoxes, T_Complete);
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoBlueBoxesComplete = TRUE;
		}
	}
	else
	{
		if(Missions.bNoBlueBox && State.bMissionNoBlueBoxesComplete)
		{
			sprintf(byTemp, "%s -> %s", T_DestroyAllBlueBoxes, T_Incomplete);
			ShowSmallMessage(byTemp, 2000);
			State.bMissionNoBlueBoxesComplete = FALSE;
		}
	}

	State.Check();
	if(State.bLevelJustComplete && _AS->GetModule() == MODULE_GAME)
	{ // The level is now finished:
		State.bLevelJustComplete = FALSE;
		lPauseTimer = g_lNow;
		bPause = TRUE;
		bCameraAnimation = Camera.bEndCamera;
		memset(&TempCamera, 0, sizeof(AS_CAMERA));
		lCameraTimer = g_lNow;
		Camera.iCurrentCameraStep = 0;
		if(Camera.bEndCamera && pLevel->Header.iCameraScripts)
		{
			pCurrentCameraScript = &pCameraScript[Camera.iEndCamera];
			if(pLevel->pCurrentCameraScript->iTextScript != -1)
				PlayTextScript(pLevel->pCurrentCameraScript->iTextScript);
		}
		bLevelPressAnyKey = FALSE;
		lLevelCompleteTimer = g_lNow;
		iLevelCompleteSpeed = 200;
		for(i = 0; i < 256; i++)
			ASKeys[i] = 0;
		// Player stand now:
		pPlayer->byAction = ACTION_STAND;
		pPlayer->byAnimation = 1;
		pPlayer->iAniStep = 0;
		pPlayer->dwAniTime = g_lNow;
	}

	if(((Missions.bTimeLimit && Missions.iTimeLimit <= 0) ||
	   (Missions.bStepsLimit && Missions.iStepsLimit <= 0)) &&
	   !OktaActor.bActive && !State.bLevelComplete)
	{ // Time out or steps out, wake up the Okta:
		OktaActor.bActive = TRUE;
		OktaActor.bThrow = FALSE;
		OktaActor.fWorldPos[X] = pPlayer->fWorldPos[X];
		OktaActor.fWorldPos[Y] = pPlayer->fWorldPos[Y];
		OktaActor.fWorldPos[Z] = pPlayer->fWorldPos[Z]+pCamera->fZ;
		OktaActor.iAniStep = pOktaModel->Ani.anim[2].firstFrame;
	}
} // end LEVEL::CheckMissions()

void LEVEL::ShowMissionState(AS_WINDOW *pWindow)
{ // begin LEVEL::ShowMissionState()
	char byTemp[256];
	short iY = 320;

	// Level information:
	if(!State.bLevelComplete)
	{
		pWindow->PrintAnimated(10, 390, Header.byName, 0, 1.0f, fFontAni, 0);
		if(Header.byAuthor[0] != '\0')
		{
			sprintf(byTemp, "%s: %s", T_Author, Header.byAuthor);
			pWindow->PrintAnimated(10, 370, byTemp, 0, 1.0f, fFontAni, 0);
		}
	}

	// Show missions state:
	if(State.bLevelComplete)
		pWindow->PrintAnimated(320, 340, T_LevelComplete, 0, 1.4f, fFontAni, 1);
	else
		pWindow->PrintAnimated(320, 340, T_Missions, 0, 1.4f, fFontAni, 1);
	
	if(Missions.bExit && !State.bMissionExitComplete)
	{
		pWindow->PrintAnimated(320, iY, T_GoToExit, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	if(Missions.bAlcove && !State.bMissionAlcoveComplete)
	{
		pWindow->PrintAnimated(320, iY, T_GoToAlcove, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	// Collect objects:
	if(Missions.bCollectPoints && !State.bMissionCollectPointsComplete)
	{
		sprintf(byTemp, "%s (%d)", T_CollectPoints, (short) Missions.iCollectPoints-State.iCollectedPoints);
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	if(Missions.bCollectHealth && !State.bMissionCollectHealthComplete)
	{
		sprintf(byTemp, "%s (%d)", T_CollectHealth, (short) (Missions.iCollectHealth-pPlayer->fPower));
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	if(Missions.bKillMobmobs && !State.bMissionKillMobmobsComplete)
	{
		sprintf(byTemp, "%s (%d)", T_KillMobmobs, (short) (Missions.iKillMobmobs-State.iKilledMobmobs));
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	if(Missions.bKillX3 && !State.bMissionKillX3Complete)
	{
		sprintf(byTemp, "%s (%d)", T_KillX3, (short) (Missions.iKillX3-State.iKilledX3));
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	// Anchors:
	if(Missions.bNoFreeForAllAnchor && !State.bMissionNoFreeForAllAnchorComplete)
	{
		
		sprintf(byTemp, "%s (%d)", T_FillAllForAllAnchors, Header.iForAllAnchors-State.iUsedForAllAnchors);
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	if(Missions.bNoFreeNormalAnchor && !State.bMissionNoFreeNormalAnchorComplete)
	{
		
		sprintf(byTemp, "%s (%d)", T_FillAllNormalAnchors, Header.iNormalAnchors-State.iUsedNormalAnchors);
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	if(Missions.bNoFreeRedAnchor &&!State.bMissionNoFreeRedAnchorComplete)
	{
		sprintf(byTemp, "%s (%d)", T_FillAllRedAnchors, Header.iRedAnchors-State.iUsedRedAnchors);
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	if(Missions.bNoFreeGreenAnchor &&!State.bMissionNoFreeGreenAnchorComplete)
	{
		sprintf(byTemp, "%s (%d)", T_FillAllGreenAnchors, Header.iGreenAnchors-State.iUsedGreenAnchors);
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	if(Missions.bNoFreeBlueAnchor &&!State.bMissionNoFreeBlueAnchorComplete)
	{
		sprintf(byTemp, "%s (%d)", T_FillAllBlueAnchors, Header.iBlueAnchors-State.iUsedBlueAnchors);
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}

	// Free boxes:
	if(Missions.bNoFreeNormalBox && !State.bMissionNoFreeNormalBoxesComplete)
	{
		sprintf(byTemp, "%s (%d)", T_NoFreeNormalBox, Header.iNormalBoxes-State.iNoneFreeNormalBoxes);
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	if(Missions.bNoFreeRedBox && !State.bMissionNoFreeRedBoxesComplete)
	{
		sprintf(byTemp, "%s (%d)", T_NoFreeRedBox, Header.iRedBoxes-State.iNoneFreeRedBoxes);
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	if(Missions.bNoFreeGreenBox && !State.bMissionNoFreeGreenBoxesComplete)
	{
		sprintf(byTemp, "%s (%d)", T_NoFreeGreenBox, Header.iGreenBoxes-State.iNoneFreeGreenBoxes);
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	if(Missions.bNoFreeBlueBox && !State.bMissionNoFreeBlueBoxesComplete)
	{
		sprintf(byTemp, "%s (%d)", T_NoFreeBlueBox, Header.iBlueBoxes-State.iNoneFreeBlueBoxes);
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}

	// Destroyed boxes:
	if(Missions.bNoNormalBox && !State.bMissionNoNormalBoxesComplete)
	{
		sprintf(byTemp, "%s (%d)", T_DestroyAllNormalBoxes, Header.iNormalBoxes-State.iDestroyedNormalBoxes);
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	if(Missions.bNoRedBox && !State.bMissionNoRedBoxesComplete)
	{
		sprintf(byTemp, "%s (%d)", T_DestroyAllRedBoxes, Header.iRedBoxes-State.iDestroyedRedBoxes);
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	if(Missions.bNoGreenBox && !State.bMissionNoGreenBoxesComplete)
	{
		sprintf(byTemp, "%s (%d)", T_DestroyAllGreenBoxes, Header.iGreenBoxes-State.iDestroyedGreenBoxes);
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
	if(Missions.bNoBlueBox && !State.bMissionNoBlueBoxesComplete)
	{
		sprintf(byTemp, "%s (%d)", T_DestroyAllBlueBoxes, Header.iBlueBoxes-State.iDestroyedBlueBoxes);
		pWindow->PrintAnimated(320, iY, byTemp, 0, 1.0f, fFontAni, 1);
		iY -= 20;
	}
} // end LEVEL::ShowMissionState()

void LEVEL_STATE::Check(void)
{ // begin LEVEL_STATE::Check()
	// Check if the mission is complete:
	if(bMissionNoFreeForAllAnchorComplete &&
	   bMissionNoFreeNormalAnchorComplete &&
	   bMissionNoFreeRedAnchorComplete &&
	   bMissionNoFreeGreenAnchorComplete &&
	   bMissionNoFreeBlueAnchorComplete &&
	   bMissionNoNormalBoxesComplete &&
	   bMissionNoRedBoxesComplete &&
	   bMissionNoGreenBoxesComplete &&
	   bMissionNoBlueBoxesComplete &&
	   bMissionNoFreeNormalBoxesComplete &&
	   bMissionNoFreeRedBoxesComplete &&
	   bMissionNoFreeGreenBoxesComplete &&
	   bMissionNoFreeBlueBoxesComplete &&
	   bMissionExitComplete &&
	   bMissionAlcoveComplete &&
	   bMissionCollectPointsComplete &&
	   bMissionCollectHealthComplete &&
	   bMissionKillMobmobsComplete &&
	   bMissionKillX3Complete)
	{ // Yea, the level is complete:
		bLevelComplete = TRUE;
		bLevelJustComplete = TRUE;
	}
	else
	{
		bLevelComplete = FALSE;
		bLevelJustComplete = FALSE;
	}
} // end LEVEL_STATE::Check()

void LEVEL_MISSIONS::CheckTime(void)
{ // begin LEVEL_MISSIONS::CheckTime()
	if(g_lNow-lTimeLimitTime > 1000)
	{
		lTimeLimitTime = g_lNow;
		if(bTimeLimit)
		{
			iTimeLimit--;
			if(iTimeLimit < 0)
				iTimeLimit = 0;
		}
		else
			iTimeLimit++;
	}
} // end LEVEL_MISSIONS::CheckTime()

void LEVEL_MISSIONS::CheckSteps(void)
{ // begin LEVEL_MISSIONS::CheckSteps()
	if(bStepsLimit)
	{
		iStepsLimit--;
		if(iStepsLimit < 0)
			iStepsLimit = 0;
	}
	else
		iStepsLimit++;
} // end LEVEL_MISSIONS::CheckSteps()

void LEVEL_MISSIONS::TimeObj(short iNumber)
{ // begin LEVEL_MISSIONS::TimeObj()
	if(bTimeLimit)
		iTimeLimit += iNumber;
	else
	{
		iTimeLimit -= iNumber;
		if(iTimeLimit < 0)
			iTimeLimit = 0;
	}
} // end LEVEL_MISSIONS::TimeObj()

void LEVEL_MISSIONS::StepsObj(short iNumber)
{ // begin LEVEL_MISSIONS::StepsObj()
	if(pLevel->Missions.bStepsLimit)
		pLevel->Missions.iStepsLimit += iNumber;
	else
	{
		pLevel->Missions.iStepsLimit -= iNumber;
		if(pLevel->Missions.iStepsLimit < 0)
			pLevel->Missions.iStepsLimit = 0;
	}
} // end LEVEL_MISSIONS::StepsObj()

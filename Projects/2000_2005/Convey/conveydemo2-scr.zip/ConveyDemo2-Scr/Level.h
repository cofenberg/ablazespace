//-----------------------------------------------------------------------------
// File: Level.h
//-----------------------------------------------------------------------------

#ifndef __LEVEL_H__
#define __LEVEL_H__


// Definitions: ***************************************************************
#define LEVEL_VERSION 2		// The level version is responsible to save for crashes if the level is to old or not correct
							// And the users couldn't create with the editor levels for the
							// second demo!!
							// 1 = The first demo
							// 2 = The second demo
							// 3 = The final version
#define STANDART_LEVEL_Z_POS (-1000.0f) // The standart height of each node point
										// 0 wasn't good because there could be an division through 0...

// Calculates the field matrix position of a world position:
#define COMPUTE_FIELD_POS(px, py, ix, iy)  { ix = (short) (px/pLevel->Header.fFieldWidth);\
										     iy = (short) (py/pLevel->Header.fFieldHeight); }

// Calculates the field ID of field matrix position:
#define GET_FIELD_ID(x, y, id) id = y*pLevel->Header.iWidth+x;

// The six field sides:
enum
{
			   FACE_FRONT,
			   FACE_TOP,
	FACE_LEFT,				FACE_RIGHT,
			   FACE_BOTTOM,
			   FACE_FLOOR,
};
///////////////////////////////////////////////////////////////////////////////

// Classes: *******************************************************************
// A decoration on a field:
typedef struct FIELD_DECORATION
{
	short iDecorationID; // The decoration number
	FLOAT3 fPos, // The world position of the decoration
		   fRot, // Decoration rotation
		   fSize; // Size of the decoration
	short iSpeed; // Animation speed
	short iTexture; // The decoration model texture
	char byTextureFilename[256]; // The filename of the texture
	char byAnimation; // Decoration animation
	
	// Animation:
	BOOL bAnimated; // Should the model be animated?
	float fModelInterpolation;
	DWORD dwAniTime, dwAniDeltaTime;
	short iAniStep, iNextAniStep;

} FIELD_DECORATION;

// The field stuff:
typedef struct FIELD
{
	BOOL bActive; // Is this field active?
	BOOL bNoBackfaceCulling; // Should the field have two faces?
	BOOL bWall; // Is there a wall on this field
	BOOL bAlwaysWall; // Is this always wall? (invisible walls possible...)
	BOOL bWallHole; // Is this a hole with walls around it??
	BOOL bIndestructibleWall; // The wall couldn't be destroyed!
	short iID; // The field ID
	short iXPos, iYPos;	// The world position
	short iXField, iYField; // The matrix field pos
	BOOL bFaceActive[6]; // Information about which field side is visible
	short iFace[6][4]; // Six faces every has 4 points, all clockwise sorted, evey first one is in the front
	FLOAT3 fNormal[6][2]; // Each face consist of two triangles that there are two normals for each face

	// The surfaces of this field: (the second is used for multitexturing)
	short iSurface[6][2]; // The sides surfaces
	SURFACE *pSurface[6][2]; // Pointer to the surfaces
	short iSurfaceRotation[6][2]; // The rotation of each surface
	short iCurrentAniStep[6][2]; // The animation step of each side
	long dwLastTime[6][2]; // The last animation step change of each side
	long dwLastChangeTime[6][2]; // Surface change timer


	FLOAT fBoundingBox[2][3]; // The fields bounding box min/max
	FLOAT fBoundingBoxX, fBoundingBoxY, fBoundingBoxZ, // The middle of the bounding box
		  fBoundingBoxSize; // The general size of the boundingbox
	BOOL bOnScreen;	// Is this field on the screen?

	ACTOR *pActor; // The actor on this field:
	ACTOR *pEnemy; // The enemy on this field
	ACTOR *pBridgeActor; // The actor which is now used as a bridge
	ACTOR *pObject;	// Is a object on this field? (e.g. health)

	BOOL bSelected; // Is this field selected?
	
	short iCamera; // The camera script which is played on this field (-1 = no camera)
	BOOL bCameraAlways; // Should the camera always occur?

	short iTextScript; // The text script which is played on this field (-1 = no text script)
	BOOL bTextScriptAlways; // Should the text script always occur?
	
	FIELD_DECORATION *pDecoration; // The decoration on this field

	// Beamer:
	float fBeamerPower; // The beamers power, only at 1.0 he could beam!
	int iBeamerRegenerationSpeed; // The beamer regeneration speed
	short iBeamerParticleSystemID; // The ID if the beamers particle system
	short iBeamerTarget; // The target field ID

} FIELD;

// General level information:
typedef struct LEVEL_HEADER
{
	// General informaiton:
	char byName[256]; // Level name (title)
	char byFilename[MAX_PATH]; // The levels filename ()
	char byAuthor[256]; // The creator of this level
	BOOL bSingle; // Is this level an single and none campaign level?
	BOOL bEndScreen; // Should the end screen appear? (only in campaign levels!!)

	// Keyword:
	BOOL bKeyword; // Has this level an keyword?
	char byKeyword[256]; // The keyword for this level
	
	// Music:
	BOOL bMusic; // Is there music in the level?
	char byMusicFile[256]; // The music file

	// Level size:
	short iWidth, iHeight, // The level size
		  iFields, iPoints; // The number of fields and points
	float fFieldWidth, fFieldHeight, fFieldDepth, // The size of a field
		  fWholeWidth, fWholeHeight; // The whole size of the level

	// Box information:
	SHORT2 iBoxSurface[6]; // The box surfaces for each side and each type (2 types, 6 sides)
	CHAR2 byBoxSurfaceRot[6]; // The box surface rotation for each side and each type (2 types, 6 sides)

	// General information:
	short iTextures; // The number of textures used in this level
	short iSurfaces; // The number of surfaces used in this level
	short iCameraScripts; // The number of camera scripts

	// Object information:
	short iPointsObj, // The number of points in the level
		  iMobmobs, // The number of Mobmobs in the level
		  iX3; // The number of X3 in the level
	short iNormalBoxes, // The number of normal boxes in this level
		  iRedBoxes, // The number of red boxes in this level
		  iGreenBoxes, // The number of green boxes in this level
		  iBlueBoxes; // The number of blue boxes in this level
   	short iForAllAnchors, // The number of for all anchors in this level
		  iNormalAnchors, // The number of normal anchors in this level
		  iRedAnchors, // The number of red anchors in this level
		  iGreenAnchors, // The number of green anchors in this level
		  iBlueAnchors; // The number of blue anchors in this level

} LEVEL_HEADER;

// Information about the levels environment:
typedef struct LEVEL_ENVIRONMENT
{
	float fGravity; // The gravitation (9.81 for earth gravitation)
	FLOAT3 fColor; // The general level light

	// Sky cube:
	BOOL bSkyCube; // Is the sky cube active?
	FLOAT3 fSkyCubeColor, // The color of the sky cube
		   fSkyCubeSize; // The size
	short iSkyCubeSurface[6], // The surface for each side of the sky cube
		  iSkyCubeSurfaceRotation[6], // The side surface rotation
		  iSkyCubeSurfaceAniStep[6]; // The current animaton step of each side surface
	long dwSkyCubeSurfaceLastTime[6]; // The last animation step change time

	// Fog:
	BOOL bFog; // Is the fog activated?
	float fFogDensity; // The fog density
	FLOAT3 fFogColor; // The color of the fog

	// Water:
	BOOL bWater; // Is there water in the level?
	BOOL bWaterAcid; // Is it acid?
	BOOL bWaterLava; // Is is lava?
	float fWaterDensity, // The water's density
		  fWaterHeight, // The height of the water (the middle of the amplitude)
		  fWaterActualHeight, // The current height
		  fWaterAmplitude, // The height amplitude
		  fWaterSpeed, // The water height change speed
		  fWaterVar; // Stores the angle for the sin function (for the smooth water change)
	FLOAT3 fWaterColor; // The color of the water
	BOOL bWaterSurface; // Has the water a surface?
	short iWaterSurface, // The waters surface
		  iWaterAniStep; // The current water surface animation step
	long lWaterAniTime; // The time were the last water change happened
	
	// Water environment:
	BOOL bWaterEnvironment;
	float fWaterEnvironmentDensity;
	FLOAT3 fWaterEnvironmentColor;
	short iWaterEnvironmentSurface,
		  iWaterEnvironmentAniStep;
	long lWaterEnvironmentAniTime;

} LEVEL_ENVIRONMENT;

// The tools the player will receive if he enter the level:
typedef struct LEVEL_TOOLS
{
	short iLives, // The number of lives the player will receive if he enter this level
		  iPoints, // The number of points the player will receive if he enter this level
		  iWeapon, // The number of weapons the player will receive if he enter this level
		  iPull, // The number of pulls the player will receive if he enter this level
		  iThrow, // The number of throws the player will receive if he enter this level
		  iForce, // The number of force the player will receive if he enter this level
		  iJump; // The number of jumps the player will receive if he enter this level
	
	BOOL bUnlimitedWeapon, // Has the player unlimited weapons?
		 bUnlimitedPull, // Has the player unlimited pulls?
		 bUnlimitedThrow, // Has the player unlimited throws?
		 bUnlimitedForce, // Has the player unlimited force?
		 bUnlimitedJump; // Has the player unlimited jumps?
	
	BOOL bGhost, // Should the ghost mode be activated if the player enter this level?
		 bSpeed, // Should the speed mode be activated if the player enter this level?
		 bWing, // Should the wing mode be activated if the player enter this level?
		 bShield; // Should the shield mode be activated if the player enter this level?
	
	long lGhostTime, // How long should the player have the start ghost?
		 lShieldTime, // How long should the player have the start shield?
		 lSpeedTime, // How long should the player have the start speed?
		 lWingTime; // How long should the player have the start wing?

} LEVEL_TOOLS;

// All level missions:
typedef class LEVEL_MISSIONS
{
	public:

		// Time:
		BOOL bTimeLimit; // Is there a time limit?
		short iTimeLimit; // The time limit
		long lTimeLimitTime; // Stores the last checked time

		// Steps:
		BOOL bStepsLimit; // Is there a step limit?
		short iStepsLimit; // The number of steps the player have

		BOOL bExit, // Should be player stand on an exit?
			 bAlcove, // Should be player stand on a alcove?
			 bCollectPoints, // Must the player collect points?
			 bCollectHealth,	// Must the player have an special number of health?
			 bKillMobmobs, // Should the player kill Mobmobs?
			 bKillX3; // Should the player kill X3?

		short iCollectPoints, // The number of points which must be collected
			  iCollectHealth, // The total number of heath which the player must have
			  iKillMobmobs, // The number of Mobmobs to be killed
			  iKillX3; // The number of X3 to be killed
		
		// No free anchor:
		BOOL bNoFreeForAllAnchor, // There should be no free for all anchor
			 bNoFreeNormalAnchor, // There should be no free normal anchor
			 bNoFreeRedAnchor, // There should be no free red anchor
			 bNoFreeGreenAnchor, // There should be no free green anchor
			 bNoFreeBlueAnchor; // There should be no free blue anchor

		// No free box:
		BOOL bNoFreeNormalBox, // There should be no free normal box
			 bNoFreeRedBox, // There should be no free red box
			 bNoFreeGreenBox, // There should be no free green box
			 bNoFreeBlueBox; // There should be no free blue box

		// No box:
		BOOL bNoNormalBox, // There should be no normal box
			 bNoRedBox, // There should be no red box
			 bNoGreenBox, // There should be no green box
			 bNoBlueBox; // There should be no blue box

		
		void CheckTime(void);
		void CheckSteps(void);
		void TimeObj(short);
		void StepsObj(short);
	
} LEVEL_MISSIONS;

typedef struct LEVEL_CAMERA
{
	AS_CAMERA StartCamera; // The level start camera (the last camera position)

	// The possible camera modes:
	BOOL bFreeCamera, // Is it possible to select the 'bird view' camera?
		 bPlayerCamera, // Is it possible to select the player camera?
		 bStandartCamera; // Which camera should be selected at the level start
						  // (0 = 'bird view'  1 = player camera)
	
	BOOL bStartCamera, // Should the level have an start camera
		 bEndCamera, // Should the level have an end camera
		 bEndCameraLoop; // Should the end camera be loop indefinitely?

	short iStartCamera, // The start camera ID
		  iEndCamera; // The end camera ID

	short iCurrentCameraStep;

} LEVEL_CAMERA;

// Level missions state:
typedef class LEVEL_STATE
{
	public:

		BOOL bLevelComplete; // Is the level finished?
		BOOL bLevelJustComplete; // Is the level just finished?
								 // (the fist time, for checking some stuff...)

		BOOL bMissionExitComplete, // The player must be on an 'exit'-field to finish the level
			 bMissionAlcoveComplete; // The player must be on an 'alcove'-field to finish the level

		// Collect objects:
		BOOL bMissionCollectPointsComplete, // Is the collect points mission complete?
			 bMissionCollectHealthComplete, // Is the collect health mission complete?
			 bMissionKillMobmobsComplete, // Is the kill Mobmobs mission complete?
			 bMissionKillX3Complete; // Is the kill Mobmobs X3 complete?
		short iCollectedPoints; // The number of collected points
		short iKilledMobmobs; // The number of killed mobmobs 
		short iKilledX3; // The number of killed X3 

		// Anchors:
		BOOL bMissionNoFreeForAllAnchorComplete,  // Is the no free for all anchors mission complete?
			 bMissionNoFreeNormalAnchorComplete,  // Is the no free normal anchors mission complete?
			 bMissionNoFreeRedAnchorComplete,  // Is the no free red anchors mission complete?
			 bMissionNoFreeGreenAnchorComplete,  // Is the no free green anchors mission complete?
			 bMissionNoFreeBlueAnchorComplete;  // Is the no free blue anchors mission complete?
		short iUsedForAllAnchors, // The number of used for all anchors
			  iUsedNormalAnchors, // The number of used normal anchors
			  iUsedRedAnchors, // The number of used red anchors
			  iUsedGreenAnchors, // The number of used green anchors
			  iUsedBlueAnchors; // The number of used blue anchors

		// Free boxes:
		BOOL bMissionNoFreeNormalBoxesComplete,  // Is the no free normal boxes mission complete?
			 bMissionNoFreeRedBoxesComplete,  // Is the no free red boxes mission complete?
			 bMissionNoFreeGreenBoxesComplete,  // Is the no free green boxes mission complete?
			 bMissionNoFreeBlueBoxesComplete;  // Is the no free blue boxes mission complete?
		short iNoneFreeNormalBoxes, // The number of none free normal boxes
			  iNoneFreeRedBoxes, // The number of none free red boxes
			  iNoneFreeGreenBoxes, // The number of none free green boxes
			  iNoneFreeBlueBoxes; // The number of none free blue boxes

		// Destroyed boxes:
		BOOL bMissionNoNormalBoxesComplete,  // Is the no normal boxes mission complete?
			 bMissionNoRedBoxesComplete,  // Is the no red boxes mission complete?
			 bMissionNoGreenBoxesComplete,  // Is the no green boxes mission complete?
			 bMissionNoBlueBoxesComplete;  // Is the no blue boxes mission complete?
		short iDestroyedNormalBoxes, // The number of destroyed normal boxes
			  iDestroyedRedBoxes, // The number of destroyed red boxes
			  iDestroyedGreenBoxes, // The number of destroyed green boxes
			  iDestroyedBlueBoxes; // The number of destroyed blue boxes


		void Check(void);

} LEVEL_STATE;

// The complete level information:
typedef class LEVEL
{

	public:

		short iVersion; // The level version

		// General level information:
		LEVEL_HEADER Header; // General information
		LEVEL_ENVIRONMENT Environment; // Environment information
		LEVEL_TOOLS	Tools; // Tools information
		LEVEL_MISSIONS Missions; // Missions information
		LEVEL_CAMERA Camera; // Camera information
		LEVEL_STATE State; // Information about the level and the missions state
		TEXT_SCRIPTS_MANAGER TextScriptsManager; // Text scripts:
		
		// Actors:
		ACTOR PlayerT; // The level start player information
		ACTOR ActorT[MAX_ACTORS]; // All actors (boxes, objects, enemies...)

		// Points:
		FLOAT3 *fPoint; // The level node points
		FLOAT4 *fColor; // The color and alpha value of each node point

		// Fields:
		FIELD *pField; // The fields the level consist of
		short iCurrentField; // The current field ID
		FIELD *pCurrentField; // Pointer to the current field

		// Textures:
		AS_TEXTURE *pTexture; // The textures
		short iCurrentTexture; // The current texture ID
		AS_TEXTURE *pCurrentTexture; // Pointer to the current texture

		// Surfaces:
		SURFACE *pSurface; // The surfaces
		short iCurrentSurface; // The current surface ID
		SURFACE *pCurrentSurface; // Pointer to the current surface

		// Camera scipts:
		AS_CAMERA_SCRIPT *pCameraScript; // The camera scripts
		short iCurrentCameraScript; // The current camera script ID
		AS_CAMERA_SCRIPT *pCurrentCameraScript; // Pointer to the current camera script


		// Functions:	
		LEVEL(void);
		~LEVEL(void);
		void SetLevelStandartValues(void);
		void GenTexturesOpenGL(HDC, HGLRC);
		void DestroyTexturesOpenGL(HDC, HGLRC);
		HRESULT CreateSurface(void);
		void DestroySurface(short);
		HRESULT LoadSurface(char *);
		void DestroyTexture(short);
		HRESULT LoadTexture(char *);
		void Create(short, short, float, float, float);
		void Destroy(void);
		void SetFieldWall(short, short, BOOL, BOOL);
		void CalculateFieldNormals(void);
		void CalculateFieldBoundingBoxes(void);

		void InitLevelDraw(void);
		void DeInitLevelDraw(void);
		void Draw(BOOL);
		void DrawTransparent(void);
		void DrawWater(void);
		void DrawSkyCube();

		void Load(char *);
		HRESULT Save(char *);
		void SetStandartView(void);
		FIELD *ComputeHeight(float, float, FLOAT3, FLOAT3 *, char, float);
		float FastComputeHeight(float, float, char);
		BOOL GetWall(float, float);
		void UpdateMissions(void);
		void InitMissions(void);
		void CheckMissions(void);
		void ShowMissionState(AS_WINDOW *);

} LEVEL;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern AS_CAMERA LevelTempCamera; // Used to find out if the camera has been moved
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern void CreateLevel(LEVEL **);
extern void DestroyLevel(LEVEL **);
extern BOOL GetLevelKeyword(char *, char *);
extern char GetLevelSingle(char *);
extern void GetLevelName(char *, char *);
extern void GetLevelFileName(char *, char *);
extern void StartLevel(char *, BOOL);
extern void StartCurrentLevel(void);
extern void StartLevelMusic(void);
extern void DestroyLevel(void);
///////////////////////////////////////////////////////////////////////////////


#endif // __LEVEL_H__
//-----------------------------------------------------------------------------
// File: Player.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


extern short iTemp;

// Variables: *****************************************************************
ACTOR *pPlayer;
PLAYER_INFO PlayerInfo;
PLAYER_IDENTITY PlayerIdentity;
// Xe skin animation:
DWORD dwXeSleepAniTime;
BOOL bXeSleep;
// Weapon skin animation:
DWORD dwWeaponAniTime;
char byWeaponAni;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
void CreateNewPlayerInfo(PLAYER_IDENTITY *, CAMPAIGN *);
void DestroyPlayerInfo(PLAYER_IDENTITY *);
void LoadPlayerIdentity(PLAYER_IDENTITY *, CAMPAIGN *);
void SavePlayerIdentity(PLAYER_IDENTITY *, CAMPAIGN *);
void DrawPlayer(void);
BOOL CheckPlayerKeys(void);
void CheckPlayer(BOOL);
BOOL CheckPlayerSurface(SURFACE *, short);
BOOL CheckPlayerPushBox(char, BOOL);
BOOL CheckPlayerPullBox(char);
BOOL CheckPlayerThrowBox(char);
BOOL CheckPlayerJump(char);
void SetPlayerToCheckpoint(void);
void MakePlayerCameraRotation(char);
///////////////////////////////////////////////////////////////////////////////


void CreateNewPlayerInfo(PLAYER_IDENTITY *pPlayerIdentity, CAMPAIGN *pCampaign)
{ // begin CreateNewPlayerInfo()
	DestroyPlayerInfo(pPlayerIdentity);
	memset(pPlayerIdentity, 0, sizeof(PLAYER_IDENTITY));
	strcpy(pPlayerIdentity->byName, "Xe");
	strcpy(pPlayerIdentity->byCampaignName, pCampaign->byName);
	pPlayerIdentity->iSelectedLevel = 1;
	if(pCampaign->iLevels)
	{
		pPlayerIdentity->iPoints = (int *) malloc(sizeof(int)*pCampaign->iLevels);
		memset(pPlayerIdentity->iPoints, 0, sizeof(int)*pCampaign->iLevels);
		pPlayerIdentity->iLives = (short *) malloc(sizeof(short)*pCampaign->iLevels);
		memset(pPlayerIdentity->iLives, 0, sizeof(short)*pCampaign->iLevels);
		pPlayerIdentity->fPower = (float *) malloc(sizeof(float)*pCampaign->iLevels);
		memset(pPlayerIdentity->fPower, 0, sizeof(float)*pCampaign->iLevels);
		pPlayerIdentity->iLives[0] = 3; // Game start lives
		pPlayerIdentity->fPower[0] = 100.0f; // Start power
	}
} // end CreateNewPlayerInfo()

void DestroyPlayerInfo(PLAYER_IDENTITY *pPlayerIdentity)
{ // begin DestroyPlayerInfo()
	SAFE_DELETE(pPlayerIdentity->iPoints);
	SAFE_DELETE(pPlayerIdentity->iLives);
	SAFE_DELETE(pPlayerIdentity->fPower);
} // end DestroyPlayerInfo()

void LoadPlayerIdentity(char *pbyName, PLAYER_IDENTITY *pPlayerIdentity, CAMPAIGN *pCampaign)
{ // begin LoadPlayerIdentity()
	char byFilename[256];
	FILE *fp;
	short i;

	sprintf(byFilename, "%s%s\\%s.id", _AS->pbyProgramPath, _AS->pbyIdentityFile, pbyName);
	_AS->WriteLogMessage("Load player identity: %s", byFilename);
	fp = fopen(byFilename, "rb");
	if(!fp)
		return;
	CreateNewPlayerInfo(pPlayerIdentity, pCampaign);
	// General info:		
	fread(&pPlayerIdentity->byName, sizeof(char)*PLAYER_NAME_LENGTH, 1, fp);
	fread(&pPlayerIdentity->byCampaignName, sizeof(char)*256, 1, fp);
	fread(&pPlayerIdentity->iFinishedLevels, sizeof(short), 1, fp);
	fread(&pPlayerIdentity->iSelectedLevel, sizeof(short), 1, fp);
	// Player info for each level of the campaign:
	for(i = 0; i < pCampaign->iLevels; i++)
	{
		fread(&pPlayerIdentity->iPoints[i], sizeof(int), 1, fp);
		fread(&pPlayerIdentity->iLives[i], sizeof(short), 1, fp);
		fread(&pPlayerIdentity->fPower[i], sizeof(float), 1, fp);
	}
	fclose(fp);
	// Check the 'all levels' cheat:
	if(bAllLevels)
	{
		// Set the not played level to standart:
		for(i = pPlayerIdentity->iFinishedLevels; i < pCampaign->iLevels; i++)
		{
			pPlayerIdentity->iPoints[i] = 0;
			pPlayerIdentity->iLives[i] = 3;
			pPlayerIdentity->fPower[i] = 100.0f;
		}
		pPlayerIdentity->iFinishedLevels = pCampaign->iLevels;
	}
	_AS->WriteLogMessage("OK");
} // end LoadPlayerIdentity()

void SavePlayerIdentity(PLAYER_IDENTITY *pPlayerIdentity, CAMPAIGN *pCampaign)
{ // begin SavePlayerIdentity()
	char byFilename[256];
	FILE *fp;
	short i;

	sprintf(byFilename, "%s%s\\%s.id", _AS->pbyProgramPath, _AS->pbyIdentityFile, pPlayerIdentity->byName);
	_AS->WriteLogMessage("Save player identity: %s", byFilename);
	fp = fopen(byFilename, "wb");
	if(!fp)
		return;
	// General info:		
	fwrite(&pPlayerIdentity->byName, sizeof(char)*PLAYER_NAME_LENGTH, 1, fp);
	fwrite(&pPlayerIdentity->byCampaignName, sizeof(char)*256, 1, fp);
	fwrite(&pPlayerIdentity->iFinishedLevels, sizeof(short), 1, fp);
	fwrite(&pPlayerIdentity->iSelectedLevel, sizeof(short), 1, fp);
	// Player info for each level of the campaign:
	for(i = 0; i < pCampaign->iLevels; i++)
	{
		fwrite(&pPlayerIdentity->iPoints[i], sizeof(int), 1, fp);
		fwrite(&pPlayerIdentity->iLives[i], sizeof(short), 1, fp);
		fwrite(&pPlayerIdentity->fPower[i], sizeof(float), 1, fp);
	}
	fclose(fp);
	_AS->WriteLogMessage("OK");
	// Create the folder for the levels information:
	sprintf(byFilename, "%s%s\\%s", _AS->pbyProgramPath, _AS->pbyIdentityFile, pPlayerIdentity->byName);
	CreateDirectory(byFilename, NULL);
} // end SavePlayerIdentity()

void DrawPlayer(void)
{ // begin DrawPlayer()
	float f;

	if(!pPlayer->bActive)
		return;
	float fSpeed;

	if(!PlayerInfo.bSpeed)
		fSpeed = 1.0f;
	else
		fSpeed = 3.0f;	
	if(pPlayer->byAction == ACTION_JUMP)
		fSpeed /= 2.0f;
	// Calculate the world position of the player
	if(!pPlayer->bGoingDeath2 && !pPlayer->bBeaming)
	{
		pPlayer->fWorldPos[X] = pPlayer->iFieldPos[X]*pLevel->Header.fFieldWidth+pPlayer->fFieldPos[X];
		pPlayer->fWorldPos[Y] = pPlayer->iFieldPos[Y]*pLevel->Header.fFieldHeight+pPlayer->fFieldPos[Y];
		ComputeActorHeight(pPlayer, 0.2f);
	}
	//
	glPushMatrix();
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_CULL_FACE);
	glCullFace(GL_FRONT);

	if(PlayerInfo.bGhost)
	{
		glEnable(GL_BLEND);
		glDepthMask(FALSE);
	}
	glColor4f(pPlayer->fColor[0], pPlayer->fColor[1], pPlayer->fColor[2], 0.99f);
	
	if(pPlayer->bGoingDeath)
		f = 1.0f-((float) (g_lNow-pPlayer->lStartTime)/PLAYER_DEAD_FLOOR_TIME);
	if(pPlayer->bBeaming)
		f = pPlayer->fBeaming;
	if(pPlayer->bGoingDeath || pPlayer->bBeaming)
	{ // The player lies dead on the floor:
		glEnable(GL_BLEND);
		glColor4f(pPlayer->fColor[0], pPlayer->fColor[1], pPlayer->fColor[2], f);
		glDepthMask(FALSE);
	}

	glTranslatef(pPlayer->fWorldPos[X]+0.5f, pPlayer->fWorldPos[Y]+0.5f, pPlayer->fWorldPos[Z]-0.6f);
	glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
	glRotatef(-pPlayer->fRot[Y], 0.0f, 1.0f, 0.0f);
	glScalef(0.025f, 0.025f, 0.025f);
	
	if(!PlayerInfo.bWeapon && pPlayer->byAction != ACTION_SHOT)
		glBindTexture(GL_TEXTURE_2D, GameTexture[XE_TEXTURE+bXeSleep].iOpenGLID);
	else
		glBindTexture(GL_TEXTURE_2D, GameTexture[RAMBO_XE_TEXTURE+bXeSleep].iOpenGLID);
	pPlayer->fModelInterpolation = (float) (g_lNow-pPlayer->dwAniTime)/(float) (PLAYER_ANIMATION_SPEED/fSpeed);
	ASDrawMd2FrameInt(pXeModel, pPlayer->iAniStep, pPlayer->iNextAniStep, pPlayer->fModelInterpolation);
	
	if(PlayerInfo.bWeapon || pPlayer->byAction == ACTION_SHOT)
	{
		glBindTexture(GL_TEXTURE_2D, GameTexture[19+byWeaponAni].iOpenGLID);
		if(pPlayer->iAniStep < pXeWeaponModel->header.numFrames &&
		   pPlayer->iNextAniStep < pXeWeaponModel->header.numFrames )
			ASDrawMd2FrameInt(pXeWeaponModel, pPlayer->iAniStep, pPlayer->iNextAniStep, pPlayer->fModelInterpolation);
	}

	if(PlayerInfo.bShield && _ASConfig->bHightRenderQuality)
	{
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		glEnable(GL_BLEND);
		if(pPlayer->bBeaming)
			glColor4f(1.0f, 1.0f, 1.0f, pPlayer->fBeaming-0.2f);
		else
			glColor4f(1.0f, 1.0f, 1.0f, 0.8f);
		glBindTexture(GL_TEXTURE_2D, GameTexture[DisplayActor[0].iAniStep].iOpenGLID);
		ASDrawMd2FrameInt(pXeModel, pPlayer->iAniStep, pPlayer->iNextAniStep, pPlayer->fModelInterpolation);
		if(PlayerInfo.bWeapon || pPlayer->byAction == ACTION_SHOT)
		{
			if(pPlayer->iAniStep < pXeWeaponModel->header.numFrames &&
			   pPlayer->iNextAniStep < pXeWeaponModel->header.numFrames )
				ASDrawMd2FrameInt(pXeWeaponModel, pPlayer->iAniStep, pPlayer->iNextAniStep, pPlayer->fModelInterpolation);
		}
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	}


	if(_ASConfig->bDrawBounding)
		DrawBoundingBox(pXeModel->fBoundingBox, 0.025f);
	glDepthMask(TRUE);
	glCullFace(GL_BACK);
	glDisable(GL_BLEND);
	glPopMatrix();


/////////// Show vertex pos test: //////////////////////////
/*	FLOAT3 fPos, fPos2;
	fPos2[X] = pPlayer->fWorldPos[X]+0.5f;
	fPos2[Y] = pPlayer->fWorldPos[Y]+0.5f;
	fPos2[Z] = pPlayer->fWorldPos[Z]-0.6f;
//	iTemp = 9;
	ASGetMd2Vertex(pXeModel, pPlayer->iAniStep, pPlayer->iNextAniStep, pPlayer->fModelInterpolation, fPos2, 0.025f,
				   -90.0f, pPlayer->fRot[Y], 0.0f, iTemp, &fPos);
	glDisable(GL_DEPTH_TEST);
	glPointSize(5.0f);
	glDisable(GL_TEXTURE_2D);
	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_POINTS);
		glVertex3fv(fPos);
	glEnd();
	glEnable(GL_DEPTH_TEST);*/
/////////////////////////////////////////////////////////////////


	if(bPause && !pLevel->State.bLevelComplete)
		return;
	pPlayer->dwAniDeltaTime = g_lNow-pPlayer->dwAniTime;
	// Animate the player:
	if(pPlayer->byAction2 == ACTION_PULL_RIGHT ||
	   pPlayer->byAction2 == ACTION_PULL_DOWN ||
	   pPlayer->byAction2 == ACTION_PULL_LEFT ||
	   pPlayer->byAction2 == ACTION_PULL_UP)
	{ // We pull something: (Turn animation replay)
		pPlayer->iNextAniStep = pPlayer->iAniStep-1;
		if(pPlayer->iNextAniStep < pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame)
			pPlayer->iNextAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].lastFrame-1;
		if(g_lNow-pPlayer->dwAniTime > PLAYER_ANIMATION_SPEED/fSpeed)
		{
			pPlayer->dwAniTime = g_lNow;
			pPlayer->iAniStep--;
			if(pPlayer->iAniStep < pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame)
				pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].lastFrame-1;
		}
	}
	else
	{
		pPlayer->iNextAniStep = pPlayer->iAniStep+1;
		if(pPlayer->byAction == ACTION_PLAYER_DEATH && pPlayer->iNextAniStep == 140)
		{ // The player lies now a few seconds on the floor:
			pPlayer->bGoingDeath = TRUE;
			pPlayer->lStartTime = g_lNow;
		}
		if(pPlayer->iNextAniStep >= pXeModel->Ani.anim[pPlayer->byAnimation].lastFrame)
		{
			if(pPlayer->byAction != ACTION_SHOT && pPlayer->byAction != ACTION_PLAYER_PAIN_2 &&
			   pPlayer->byAction != ACTION_PLAYER_CHECKPOINT && pPlayer->byAction != ACTION_PLAYER_PAIN_1 &&
			   pPlayer->byAction != ACTION_PLAYER_HEALTH)
				pPlayer->iNextAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
			else
				pPlayer->byAction = pPlayer->byAction2 = -1;
		}
		if(g_lNow-pPlayer->dwAniTime > ((float) PLAYER_ANIMATION_SPEED/fSpeed))
		{
			pPlayer->dwAniTime = g_lNow;
			pPlayer->iAniStep++;
			if(pPlayer->iAniStep >= pXeModel->Ani.anim[pPlayer->byAnimation].lastFrame)
				pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
		}
	}
} // end DrawPlayer()

BOOL CheckPlayerKeys(void)
{ // begin CheckPlayerKeys()
	int byMoveKeys[4] = {_ASConfig->iRightKey[0], _ASConfig->iDownKey[0], _ASConfig->iLeftKey[0], _ASConfig->iUpKey[0]};
	char byMoveRotation = 0;
	short i;
	BOOL bKeyPressed = FALSE;
	ACTOR *pActorT;

	// Check if the player could do something:
	if(!pPlayer->bMove && !pPlayer->bShouldMove && pPlayer->byAction != ACTION_PLAYER_DEATH &&
		pPlayer->byAction != ACTION_SHOT && pPlayer->byAction != ACTION_PLAYER_PAIN_2 &&
		pPlayer->byAction != ACTION_PLAYER_CHECKPOINT && pPlayer->byAction != ACTION_JUMP &&
		pPlayer->fFieldPos[X] == 0.0f && pPlayer->fFieldPos[Y] == 0.0f &&
		!pPlayer->fVelocity[Z]);
	else
		return 0;

	if(CHECK_KEY(ASKeys, _ASConfig->iJumpKey[0]))
	{ // Jump:
		if(PlayerInfo.bJump)
		{
			if(pPlayer->byDirection == RIGHT && pPlayer->fRot[Y] != 0.0f)
				return 0;
			else
			if(pPlayer->byDirection == DOWN && pPlayer->fRot[Y] != 90.0f)
				return 0;
			else
			if(pPlayer->byDirection == LEFT && pPlayer->fRot[Y] != 180.0f)
				return 0;
			else
			if(pPlayer->byDirection == UP && pPlayer->fRot[Y] != 270.0f)
				return 0;
			if(!CheckPlayerJump(pPlayer->byDirection))
				return 1;
			pCamera->fRot2Velocity[0] = 0.0f;
			pCamera->fRot2Velocity[1] = 0.0f;
			pCamera->fRot2Velocity[1] = 0.0f;
			MakePlayerCameraRotation(ACTION_SHOT);
			pPlayer->bShouldMove = TRUE;
			pPlayer->bThrow = TRUE;
			return 0;
		}
	}

	// View dependent control:
	if(pCamera->fRot[Z] >= 315 && pCamera->fRot[Z] < 45)
		byMoveRotation = 0;
	else
	if(pCamera->fRot[Z] >= 45 && pCamera->fRot[Z] < 135)
		byMoveRotation = 1;
	else
	if(pCamera->fRot[Z] >= 135 && pCamera->fRot[Z] < 225)
		byMoveRotation = 2;
	else
	if(pCamera->fRot[Z] >= 225 && pCamera->fRot[Z] < 315)
		byMoveRotation = 3;
	if(!bPlayerCameraView && !_ASConfig->bRotateMove && !_ASConfig->bBackCamera)
	{
		if(CHECK_KEY(ASKeys, byMoveKeys[(RIGHT+byMoveRotation)%4]))
		{
			pPlayer->byDirection = RIGHT;
			if(pPlayer->fRot[Y] != 0.0f)
				return 0;
			if(!CheckPlayerPushBox(pPlayer->byDirection, TRUE))
				return 1;
			if(pPlayer->byAction != ACTION_RUN_RIGHT)
			{
				pPlayer->byAction = ACTION_RUN_RIGHT;
				pPlayer->byAnimation = 2;
				pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
				pPlayer->dwAniTime = g_lNow;
			}
		}
		else
		if(CHECK_KEY(ASKeys, byMoveKeys[(DOWN+byMoveRotation)%4]))
		{
			pPlayer->byDirection = DOWN;
			if(pPlayer->fRot[Y] != 90.0f)
				return 0;
			if(!CheckPlayerPushBox(pPlayer->byDirection, TRUE))
				return 1;
			if(pPlayer->byAction != ACTION_RUN_DOWN)
			{
				pPlayer->byAction = ACTION_RUN_DOWN;
				pPlayer->byAnimation = 2;
				pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
				pPlayer->dwAniTime = g_lNow;
			}
		}
		else
		if(CHECK_KEY(ASKeys, byMoveKeys[(LEFT+byMoveRotation)%4]))
		{
			pPlayer->byDirection = LEFT;
			if(pPlayer->fRot[Y] != 180.0f)
				return 0;
			if(!CheckPlayerPushBox(pPlayer->byDirection, TRUE))
				return 1;
			if(pPlayer->byAction != ACTION_RUN_LEFT)
			{
				pPlayer->byAction = ACTION_RUN_LEFT;
				pPlayer->byAnimation = 2;
				pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
				pPlayer->dwAniTime = g_lNow;
			}
		}
		else
		if(CHECK_KEY(ASKeys, byMoveKeys[(UP+byMoveRotation)%4]))
		{
			pPlayer->byDirection = UP;
			if(pPlayer->fRot[Y] != 270.0f)
				return 0;
			if(!CheckPlayerPushBox(pPlayer->byDirection, TRUE))
				return 1;
			if(pPlayer->byAction != ACTION_RUN_UP)
			{
				pPlayer->byAction = ACTION_RUN_UP;
				pPlayer->byAnimation = 2;
				pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
				pPlayer->dwAniTime = g_lNow;
			}
		}
	}
	else
	{
		if(pPlayer->byDirection == RIGHT && pPlayer->fRot[Y] != 0.0f)
			return 0;
		else
		if(pPlayer->byDirection == DOWN && pPlayer->fRot[Y] != 90.0f)
			return 0;
		else
		if(pPlayer->byDirection == LEFT && pPlayer->fRot[Y] != 180.0f)
			return 0;
		else
		if(pPlayer->byDirection == UP && pPlayer->fRot[Y] != 270.0f)
			return 0;

		if(CHECK_KEY(ASKeys, byMoveKeys[RIGHT]) && pPlayer->byAction2 == -1)
		{
			pPlayer->byDirection++;
			if(pPlayer->byDirection > 3)
				pPlayer->byDirection = 0;
		}
		else
		if(CHECK_KEY(ASKeys, byMoveKeys[LEFT]) && pPlayer->byAction2 == -1)
		{
			pPlayer->byDirection--;
			if(pPlayer->byDirection < 0)
				pPlayer->byDirection = 3;
		}
		else
		if(CHECK_KEY(ASKeys, byMoveKeys[DOWN]))
		{
			if(!CheckPlayerPushBox((pPlayer->byDirection+2) % 4, TRUE))
			{
				pPlayer->byAction2 = ACTION_PULL_RIGHT+((pPlayer->byDirection+2) % 4);
				return 1;
			}
			if(pPlayer->byAction == ACTION_PLAYER_PAIN_1 ||
			   pPlayer->byAction == ACTION_PLAYER_HEALTH)
				pPlayer->byAction2 = -1;
			pPlayer->byAction = -1;				
			if(pPlayer->byAction2 != ACTION_PULL_RIGHT+((pPlayer->byDirection+2) % 4))
			{
				pPlayer->byAction2 = ACTION_PULL_RIGHT+((pPlayer->byDirection+2) % 4);
				pPlayer->byAnimation = 2;
				pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
				pPlayer->dwAniTime = g_lNow;
			}
			bKeyPressed = TRUE;
		}
		else
		{
			if(CHECK_KEY(ASKeys, byMoveKeys[UP]) && pPlayer->byAction2 == -1)
			{
				if(!CheckPlayerPushBox(pPlayer->byDirection, TRUE))
					return 1;
				if(pPlayer->byAction != ACTION_RUN_UP)
				{
					pPlayer->byAction = ACTION_RUN_UP;
					pPlayer->byAnimation = 2;
					pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
					pPlayer->dwAniTime = g_lNow;
				}
			}
		}
	}
	if(bKeyPressed)
		return 0;
	if(CHECK_KEY(ASKeys, _ASConfig->iPullKey[0]))
	{ // Pull a box:
		if(pPlayer->byAction == ACTION_PLAYER_PAIN_1 ||
		   pPlayer->byAction == ACTION_PLAYER_HEALTH)
			pPlayer->byAction2 = -1;
		if(pPlayer->byDirection == RIGHT && pPlayer->fRot[Y] != 0.0f)
			return 0;
		else
		if(pPlayer->byDirection == DOWN && pPlayer->fRot[Y] != 90.0f)
			return 0;
		else
		if(pPlayer->byDirection == LEFT && pPlayer->fRot[Y] != 180.0f)
			return 0;
		else
		if(pPlayer->byDirection == UP && pPlayer->fRot[Y] != 270.0f)
			return 0;
		switch(pPlayer->byDirection)
		{
			case RIGHT:
				if(!CheckPlayerPullBox(pPlayer->byDirection))
					return 1;
				// Move the player:
				pPlayer->bMove = TRUE;
				if(pPlayer->byAction2 != ACTION_PULL_LEFT)
				{
					pPlayer->byAction2 = ACTION_PULL_LEFT;
					pPlayer->byAnimation = 2;
					pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
					pPlayer->dwAniTime = g_lNow;
				}
			break;

			case DOWN:
				if(!CheckPlayerPullBox(pPlayer->byDirection))
					return 1;
				// Move the player:
				pPlayer->bMove = TRUE;
				if(pPlayer->byAction2 != ACTION_PULL_UP)
				{
					pPlayer->byAction2 = ACTION_PULL_UP;
					pPlayer->byAnimation = 2;
					pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
					pPlayer->dwAniTime = g_lNow;
				}
			break;

			case LEFT:
				if(!CheckPlayerPullBox(pPlayer->byDirection))
					return 1;
				// Move the player:
				pPlayer->bMove = TRUE;
				if(pPlayer->byAction2 != ACTION_PULL_RIGHT)
				{
					pPlayer->byAction2 = ACTION_PULL_RIGHT;
					pPlayer->byAnimation = 2;
					pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
					pPlayer->dwAniTime = g_lNow;
				}
			break;

			case UP:
				if(!CheckPlayerPullBox(pPlayer->byDirection))
					return 1;
	  			// Move the player:
				pPlayer->bMove = TRUE;
				if(pPlayer->byAction2 != ACTION_PULL_DOWN)
				{
					pPlayer->byAction2 = ACTION_PULL_DOWN;
					pPlayer->byAnimation = 2;
					pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
					pPlayer->dwAniTime = g_lNow;
				}
			break;
		}
	}
	else
	{
		if(pPlayer->byAction2 != -1)
		{
			pPlayer->byAction2 = -1;
			pPlayer->byAction = -1;
		}
		if(CHECK_KEY(ASKeys, _ASConfig->iThrowKey[0]))
		{ // Throw a box:
			if(pPlayer->byDirection == RIGHT && pPlayer->fRot[Y] != 0.0f)
				return 0;
			else
			if(pPlayer->byDirection == DOWN && pPlayer->fRot[Y] != 90.0f)
				return 0;
			else
			if(pPlayer->byDirection == LEFT && pPlayer->fRot[Y] != 180.0f)
				return 0;
			else
			if(pPlayer->byDirection == UP && pPlayer->fRot[Y] != 270.0f)
				return 0;
			if(!CheckPlayerThrowBox(pPlayer->byDirection))
				return 1;
			pCamera->fRot2Velocity[0] = 0.0f;
			pCamera->fRot2Velocity[1] = 0.0f;
			pCamera->fRot2Velocity[1] = 0.0f;
			MakePlayerCameraRotation(ACTION_PLAYER_PAIN_1);
		}
		else
		if(CHECK_KEY(ASKeys, _ASConfig->iSuicideKey[0]))
		{ // Self destruction:
			if(pPlayer->byAction != ACTION_PLAYER_PAIN_2)
			{
				pCamera->fRot2Velocity[0] = 0.0f;
				pCamera->fRot2Velocity[1] = 0.0f;
				pCamera->fRot2Velocity[1] = 0.0f;
				MakePlayerCameraRotation(ACTION_PLAYER_PAIN_2);
				pPlayer->fPower /= 2.0f;
				if(pPlayer->fPower < 2.0f)
					pPlayer->fPower = 0.0f;
				pPlayer->byAction = ACTION_PLAYER_PAIN_2;
				pPlayer->byAnimation = 4;
				pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
				pPlayer->dwAniTime = g_lNow;
			}
		}
		else
		if(CHECK_KEY(ASKeys, _ASConfig->iShotKey[0]) || (bPlayerCameraView && CHECK_KEY(ASMouse.byButtons, 0)))
		{ // Shot:
			if(PlayerInfo.bWeapon && !PlayerInfo.bGhost)
			{	// Create the shot:
				pActorT	= FindFreeActor();
				if(!pActorT)
					return 1;
				if(pPlayer->byDirection == RIGHT && pPlayer->fRot[Y] != 0.0f)
					return 0;
				else
				if(pPlayer->byDirection == DOWN && pPlayer->fRot[Y] != 90.0f)
					return 0;
				else
				if(pPlayer->byDirection == LEFT && pPlayer->fRot[Y] != 180.0f)
					return 0;
				else
				if(pPlayer->byDirection == UP && pPlayer->fRot[Y] != 270.0f)
					return 0;
				pActorT->bActive = TRUE;
				pActorT->fWorldPos[X] = pPlayer->fWorldPos[X];
				pActorT->fWorldPos[Y] = pPlayer->fWorldPos[Y];
				pActorT->fWorldPos[Z] = pPlayer->fWorldPos[Z]-0.1f;
				if(pPlayer->byDirection == RIGHT)
				{
					pActorT->fWorldPos[X] += 0.6f;
					pActorT->fWorldPos[Y] += 0.25f;
				}
				else
				if(pPlayer->byDirection == DOWN)
				{
					pActorT->fWorldPos[X] -= 0.25f;
					pActorT->fWorldPos[Y] += 0.6f;
				}
				else
				if(pPlayer->byDirection == LEFT)
				{
					pActorT->fWorldPos[X] -= 0.6f;
					pActorT->fWorldPos[Y] -= 0.25f;
				}
				else
				if(pPlayer->byDirection == UP)
				{
					pActorT->fWorldPos[X] += 0.25f;
					pActorT->fWorldPos[Y] -= 0.6f;
				}
				
				pActorT->fSize = 1.0f;
				pActorT->bMove = TRUE;
				pActorT->byType = ACTOR_PLAYER_SHOT;
				pActorT->byDirection = pPlayer->byDirection;

				// Create the shot particle system:
				// Shot trace:
        		i = ParticleManager.AddNewSystem(PS_ShotTrace1, 50, pActorT, &GameTexture[12], NULL);
				ParticleManager.pSystem[i].bActive = TRUE;
				
				// Weapon smoke:
				i = ParticleManager.AddNewSystem(PS_Smoke1, 50, pPlayer, &GameTexture[12], NULL);
				ParticleManager.pSystem[i].bActive = TRUE;
				ParticleManager.pSystem[i].fStartPos[X] = pActorT->fWorldPos[X]+0.5f;
				ParticleManager.pSystem[i].fStartPos[Y] = pActorT->fWorldPos[Y]+0.5f;
				ParticleManager.pSystem[i].fStartPos[Z] = pActorT->fWorldPos[Z]-0.5f;

				// Shot animation:
				pPlayer->byAction = ACTION_SHOT;
				pPlayer->byAnimation = 3;
				pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
				pPlayer->dwAniTime = g_lNow;
				pCamera->fRot2Velocity[0] = 0.0f;
				pCamera->fRot2Velocity[1] = 0.0f;
				pCamera->fRot2Velocity[1] = 0.0f;
				MakePlayerCameraRotation(ACTION_SHOT);
				if(!pLevel->Tools.bUnlimitedWeapon)
				{				
					PlayerInfo.iWeaponShots--;
					if(PlayerInfo.iWeaponShots <= 0)
						PlayerInfo.bWeapon = FALSE;
				}
				pPlayer->bMove = pPlayer->bShouldMove = FALSE;
			}
			else
				return 1;
		}
		else
		if(!pPlayer->bShouldMove && !pPlayer->bMove && pPlayer->byAction != ACTION_STAND &&
		   pPlayer->byAction != ACTION_SHOT && pPlayer->byAction != ACTION_PLAYER_PAIN_1 &&
		   pPlayer->byAction != ACTION_PLAYER_PAIN_2 && pPlayer->byAction != ACTION_PLAYER_PAIN_3 &&
		   pPlayer->byAction != ACTION_PLAYER_HEALTH && pPlayer->byAction !=ACTION_JUMP)
		{
			pPlayer->byAction = ACTION_STAND;
			pPlayer->byAnimation = 1;
			pPlayer->iAniStep = 0;
			pPlayer->dwAniTime = g_lNow;
		}
	}
	if(pPlayer->byAction == ACTION_STAND && pPlayer->byAction2 == -1)
		MakePlayerCameraRotation(ACTION_STAND);
	return 0;
} // end CheckPlayerKeys()

void CheckPlayer(BOOL bEditor)
{ // begin CheckPlayer()
	FIELD *pFieldT;
	SURFACE *pSurfaceT;
	short i, i2, iX, iY;
	float fSpeed, fSize, fF;
	FLOAT3 fPos, fPos2;
	char byTemp[256];

	
	if(!PlayerInfo.iWeaponShots && !pLevel->Tools.bUnlimitedWeapon)
		PlayerInfo.bWeapon = FALSE;
	if(!PlayerInfo.iPullBoxes && !pLevel->Tools.bUnlimitedPull)
		PlayerInfo.bPullBoxes = FALSE;
	if(!PlayerInfo.iThrowBoxes && !pLevel->Tools.bUnlimitedThrow)
		PlayerInfo.bThrowBoxes = FALSE;
	if(!PlayerInfo.iJump && !pLevel->Tools.bUnlimitedJump)
		PlayerInfo.bJump = FALSE;

	if(!pPlayer->bActive ||
	   CheckBeamingProcess(pPlayer))
		return;

	// Animate the players skin:
	if(pPlayer->bGoingDeath)
	{
		dwXeSleepAniTime = g_lNow;
		bXeSleep = TRUE;
	}
	else
	{
		if(!bXeSleep)
		{ // Should Xe close his eyes?
			if(g_lNow-dwXeSleepAniTime > 1000)
			{
				if(!(rand() % 150))
				{
					dwXeSleepAniTime = g_lNow;
					bXeSleep = TRUE;
				}
			}
		}
		else
		{ // Should Xe open his eyes?
			if(g_lNow-dwXeSleepAniTime > 300)
			{
				if(!(rand() % 30))
				{
					dwXeSleepAniTime = g_lNow;
					bXeSleep = FALSE;
				}
			}
		}
	}
	// Weapon skin animation:
	if(g_lNow-dwWeaponAniTime > 500)
	{
		dwWeaponAniTime = g_lNow;
		byWeaponAni++;
		if(byWeaponAni > 3)
			byWeaponAni = 0;
	}

	// Check if the player creates water waves:
	// Get the right water test vertix:
	fPos2[X] = pPlayer->fWorldPos[X]+0.5f;
	fPos2[Y] = pPlayer->fWorldPos[Y]+0.5f;
	fPos2[Z] = pPlayer->fWorldPos[Z]-0.6f;
	ASGetMd2Vertex(pXeModel, pPlayer->iAniStep, pPlayer->iNextAniStep, pPlayer->fModelInterpolation, fPos2, 0.025f,
				   -90.0f, pPlayer->fRot[Y], 0.0f, 72, &fPos);
	if(!pPlayer->bGoingDeath &&
	   !PlayerInfo.bGhost)
	{
		if(pLevel->Environment.bWater &&
		   fPos[Z] > pLevel->Environment.fWaterActualHeight &&
		   fPos[Z]-1.2f < pLevel->Environment.fWaterActualHeight)
		{
			if(!PlayerInfo.bSpeed)
				i = 40;
			else
				i = 20;
			if(!pPlayer->bMove)
				i *= 8;
			if(g_lNow-pPlayer->lLastWaterWaveTime > (unsigned) i)
			{
				pPlayer->lLastWaterWaveTime = g_lNow;
				fSize = 1.0f;
				fSize = fPos[Z]-pLevel->Environment.fWaterActualHeight;
				if(fSize > 0.5f)
					fSize = 1.0f-fSize;
				CreateWaterWave(pPlayer->fWorldPos[X]+0.5f, pPlayer->fWorldPos[Y]+0.5f, fSize);
			}
		}
	}

	if(!PlayerInfo.bSpeed)
		fSpeed = 1.0f;
	else
		fSpeed = 3.0f;	
	GET_FIELD_ID(pPlayer->iFieldPos[X], pPlayer->iFieldPos[Y], pPlayer->iFieldID)
	pFieldT = &pLevel->pField[pPlayer->iFieldID];

	if(bEditor)
	{
		pPlayer->byAnimation = 1;
		goto AnimatePlayer;
	}	
	pPlayer->fWorldPos[Z] += g_lDeltatime*pPlayer->fVelocity[Z];
	if(pPlayer->bGoingDeath)
		pCamera->fRot2Velocity[X] = -0.02f*g_lDeltatime;
	if(pPlayer->bGoingDeath)
	{
		// Check if the player press any key:
		for(i = 0; i < 256; i++)
		{
			if(ASKeyFirst[i])
			{
				ASKeyFirst[i] = ASKeys[i] = FALSE;
				pPlayer->lStartTime = g_lNow+PLAYER_DEAD_FLOOR_TIME;
				break;
			}
			ASKeyFirst[i] = FALSE;
		}
		goto AnimatePlayer;
	}

	// Check the field the player is on:
	GET_FIELD_ID(pPlayer->iFieldPos[X], pPlayer->iFieldPos[Y], pPlayer->iFieldID)
	pFieldT = &pLevel->pField[pPlayer->iFieldID];

	// Check if the player collects a object:
	if(pFieldT->pObject && pFieldT->pObject->bActive && !pFieldT->pObject->bGoingDeath && pPlayer->fFieldPos[X] == 0.0f &&
	   pPlayer->fFieldPos[Y] == 0.0f && !PlayerInfo.bGhost && pPlayer->byAction != ACTION_JUMP && !pPlayer->fVelocity[Z])
	{ // Yes, he do it:
		pFieldT->pObject->bGoingDeath = TRUE;
		switch(pFieldT->pObject->byType)
		{
			case ACTOR_HEALTH_OBJ:
				pPlayer->fPower += pFieldT->pObject->iNumber;
				if(pPlayer->fPower < 0.0f)
					pPlayer->fPower = 0.0f;
				sprintf(byTemp, "%s (%d)", T_HealthObj, pFieldT->pObject->iNumber);
				ShowSmallMessage(byTemp, 2000);
			break;

			case ACTOR_LIVE_OBJ:
				PlayerInfo.iLives += pFieldT->pObject->iNumber;
				if(PlayerInfo.iLives < -1)
					PlayerInfo.iLives = -1;
				sprintf(byTemp, "%s (%d)", T_LiveObj, pFieldT->pObject->iNumber);
				ShowSmallMessage(byTemp, 2000);
			break;
			
			case ACTOR_PULL_OBJ:
				PlayerInfo.bPullBoxes = TRUE;
				PlayerInfo.iPullBoxes += pFieldT->pObject->iNumber;
				if(PlayerInfo.iPullBoxes < 0)
				{
					PlayerInfo.iPullBoxes = 0;
					PlayerInfo.bPullBoxes = FALSE;
				}
				sprintf(byTemp, "%s (%d)", T_PullObj, pFieldT->pObject->iNumber);
				ShowSmallMessage(byTemp, 2000);
			break;
			
			case ACTOR_THROW_OBJ:
				PlayerInfo.bThrowBoxes = TRUE;
				PlayerInfo.iThrowBoxes += pFieldT->pObject->iNumber;
				if(PlayerInfo.iThrowBoxes < 0)
				{
					PlayerInfo.iThrowBoxes = 0;
					PlayerInfo.bThrowBoxes = FALSE;
				}
				sprintf(byTemp, "%s (%d)", T_ThrowObj, pFieldT->pObject->iNumber);
				ShowSmallMessage(byTemp, 2000);
			break;

			case ACTOR_FORCE_OBJ:
				PlayerInfo.iForce += pFieldT->pObject->iNumber;
				if(PlayerInfo.iForce < 1)
					PlayerInfo.iForce = 1;
				PlayerInfo.fForce = 1.0f;
				sprintf(byTemp, "%s (%d)", T_ForceObj, pFieldT->pObject->iNumber);
				ShowSmallMessage(byTemp, 2000);
			break;
			
			case ACTOR_WEAPON_OBJ:
				PlayerInfo.bWeapon = TRUE;
				PlayerInfo.iWeaponShots += pFieldT->pObject->iNumber;
				if(PlayerInfo.iWeaponShots < 0)
				{	
					PlayerInfo.iWeaponShots = 0;
					PlayerInfo.bWeapon = FALSE;
				}
				sprintf(byTemp, "%s (%d)", T_WeaponObj, pFieldT->pObject->iNumber);
				ShowSmallMessage(byTemp, 2000);
			break;

			case ACTOR_POINT_OBJ:
				PlayerInfo.iPoints += pFieldT->pObject->iNumber;
				if(PlayerInfo.iPoints < 0)
					PlayerInfo.iPoints = 0;
				pLevel->State.iCollectedPoints++;
				sprintf(byTemp, "%s (%d)", T_PointObj, pFieldT->pObject->iNumber);
				ShowSmallMessage(byTemp, 2000);
			break;

			case ACTOR_GHOST_OBJ:
				PlayerInfo.bGhost = TRUE;
				PlayerInfo.lGhostTime = g_lNow;
				PlayerInfo.lGhostWholeTime = pFieldT->pObject->iNumber;
				pLevel->pField[pPlayer->iFieldID].pActor = NULL;
				ParticleManager.pSystem[PS_PLAYER_GHOST].bActive = TRUE;
				sprintf(byTemp, "%s (%d)", T_GhostObj, pFieldT->pObject->iNumber);
				ShowSmallMessage(byTemp, 2000);
			break;

			case ACTOR_TIME_OBJ:
				pLevel->Missions.TimeObj(pFieldT->pObject->iNumber);
				sprintf(byTemp, "%s (%d)", T_TimeObj, pFieldT->pObject->iNumber);
				ShowSmallMessage(byTemp, 2000);
			break;

			case ACTOR_STEP_OBJ:
				pLevel->Missions.StepsObj(pFieldT->pObject->iNumber);
				sprintf(byTemp, "%s (%d)", T_StepObj, pFieldT->pObject->iNumber);
				ShowSmallMessage(byTemp, 2000);
			break;

			case ACTOR_SPEED_OBJ:
				pPlayer->fVelocity[0] = PLAYER_MOVE_SPEED/3;
				PlayerInfo.bSpeed = TRUE;
				PlayerInfo.lSpeedTime = g_lNow;
				PlayerInfo.lSpeedWholeTime = pFieldT->pObject->iNumber;
				ParticleManager.pSystem[PS_PLAYER_SPEED].bActive = TRUE;
				sprintf(byTemp, "%s (%d)", T_SpeedObj, pFieldT->pObject->iNumber);
				ShowSmallMessage(byTemp, 2000);
			break;

			case ACTOR_WING_OBJ:
				PlayerInfo.bWing = TRUE;
				PlayerInfo.lWingTime = g_lNow;
				PlayerInfo.lWingWholeTime = pFieldT->pObject->iNumber;
				sprintf(byTemp, "%s (%d)", T_WingsObj, pFieldT->pObject->iNumber);
				ShowSmallMessage(byTemp, 2000);
			break;

			case ACTOR_SHIELD_OBJ:
				PlayerInfo.bShield = TRUE;
				PlayerInfo.lShieldTime = g_lNow;
				PlayerInfo.lShieldWholeTime = pFieldT->pObject->iNumber;
				sprintf(byTemp, "%s (%d)", T_ShieldObj, pFieldT->pObject->iNumber);
				ShowSmallMessage(byTemp, 2000);
			break;

			case ACTOR_JUMP_OBJ:
				PlayerInfo.bJump = TRUE;
				PlayerInfo.iJump += pFieldT->pObject->iNumber;
				if(PlayerInfo.iJump < 0)
				{
					PlayerInfo.iJump = 0;
					PlayerInfo.bJump = FALSE;
				}
				sprintf(byTemp, "%s (%d)", T_Jump, pFieldT->pObject->iNumber);
				ShowSmallMessage(byTemp, 2000);
			break;

			case ACTOR_AIR_OBJ:
				pPlayer->fAir = 1.0f;
				ShowSmallMessage(T_Air, 2000);
			break;
		}
		pFieldT->pObject = NULL;
	}
	

	// Check the player keys:
	if(CheckPlayerKeys())
	{ // The player makes something stupied...
		// Is there a wall we have to check?
		// Setup x/y direction:
		if(pPlayer->byAction2 == ACTION_PULL_RIGHT ||
		   pPlayer->byAction2 == ACTION_PULL_DOWN ||
		   pPlayer->byAction2 == ACTION_PULL_LEFT ||
		   pPlayer->byAction2 == ACTION_PULL_UP)
		{
			switch(pPlayer->byDirection)
			{
				case RIGHT: iX = -1; iY = 0; break;
				case DOWN: iX = 0; iY = -1; break;
				case LEFT: iX = 1; iY = 0; break;
				case UP: iX = 0; iY = 1; break;
			}
		}
		else
		{
			switch(pPlayer->byDirection)
			{
				case RIGHT: iX = 1; iY = 0; break;
				case DOWN: iX = 0; iY = 1; break;
				case LEFT: iX = -1; iY = 0; break;
				case UP: iX = 0; iY = -1; break;
			}
		}
		if(pPlayer->iFieldPos[X]+iX < 0 || pPlayer->iFieldPos[X]+iX >= pLevel->Header.iWidth-1 ||
		   pPlayer->iFieldPos[Y]+iY < 0 || pPlayer->iFieldPos[Y]+iY >= pLevel->Header.iHeight-1 ||
		   (pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pPlayer->iFieldPos[X]+iX].bWall &&
   		    pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pPlayer->iFieldPos[X]+iX].pActor))
			goto WrongAction;
		// Yes! Check the wall surface:
		GET_FIELD_ID(pPlayer->iFieldPos[X]+iX, pPlayer->iFieldPos[Y]+iY, i);
		i = (pPlayer->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pPlayer->iFieldPos[X]+iX;

		if(pPlayer->byAction2 == ACTION_PULL_RIGHT ||
		   pPlayer->byAction2 == ACTION_PULL_DOWN ||
		   pPlayer->byAction2 == ACTION_PULL_LEFT ||
		   pPlayer->byAction2 == ACTION_PULL_UP)
		{
			switch(pPlayer->byDirection)
			{
				case RIGHT: pSurfaceT = &pLevel->pSurface[pLevel->pField[i].iSurface[FACE_RIGHT][0]]; break;
				case DOWN: pSurfaceT = &pLevel->pSurface[pLevel->pField[i].iSurface[FACE_BOTTOM][0]]; break;
				case LEFT: pSurfaceT = &pLevel->pSurface[pLevel->pField[i].iSurface[FACE_LEFT][0]]; break;
				case UP: pSurfaceT = &pLevel->pSurface[pLevel->pField[i].iSurface[FACE_TOP][0]]; break;
			}
		}
		else
		{
			switch(pPlayer->byDirection)
			{
				case RIGHT: pSurfaceT = &pLevel->pSurface[pLevel->pField[i].iSurface[FACE_LEFT][0]]; break;
				case DOWN: pSurfaceT = &pLevel->pSurface[pLevel->pField[i].iSurface[FACE_TOP][0]]; break;
				case LEFT: pSurfaceT = &pLevel->pSurface[pLevel->pField[i].iSurface[FACE_RIGHT][0]]; break;
				case UP: pSurfaceT = &pLevel->pSurface[pLevel->pField[i].iSurface[FACE_BOTTOM][0]]; break;
			}
		}
		if(CheckPlayerSurface(pSurfaceT, 0))
			goto Next;


	WrongAction:
		if(pPlayer->byAction2 != -1)
			pPlayer->byAction2 = -1;
		if(pPlayer->byAction != ACTION_WRONG && pPlayer->byAction2 == -1 && !pPlayer->bMove && !pPlayer->bShouldMove)
		{
			pPlayer->byAction = ACTION_WRONG;
			pPlayer->byAnimation = 6;
			pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
			pPlayer->dwAniTime = g_lNow;
		}
	}
Next:
	if(pPlayer->byAction == ACTION_JUMP)
	{
		fSpeed /= 2.0f;
		pPlayer->bUseFriction = FALSE;
	}
	else
		pPlayer->bUseFriction = TRUE;
	
	if(!ActorTurn(pPlayer, fSpeed))
	{ // Move the player:
		if(pPlayer->bShouldMove)
		{
			// The player is ready for moving:
			pPlayer->bShouldMove = FALSE;
			pPlayer->bMove = TRUE;
			// Ok, we could now move the boxes:
			for(i = 0; i < MAX_ACTORS; i++)
			{
				if(!Actor[i].bShouldMove)
					continue;
				Actor[i].bShouldMove = FALSE;
				Actor[i].bMove = TRUE;
			}
		}
		if(pPlayer->byAction != ACTION_PLAYER_CHECKPOINT)
		{
			if(pPlayer->bMove)
				MoveActor(pPlayer, PLAYER_MOVE_SPEED);
			if(pPlayer->bShouldMove || pPlayer->bMove)
				MakePlayerCameraRotation(ACTION_RUN_RIGHT);
		}
	}

	pLevel->CheckMissions();
	if(!pPlayer->fFieldPos[X] & !pPlayer->fFieldPos[Y])
		CheckBeaming(pPlayer);
	if(!PlayerInfo.bGhost && pPlayer->byAction != ACTION_PLAYER_DEATH && pPlayer->byAction != ACTION_JUMP)
	{
		GET_FIELD_ID(pPlayer->iFieldPos[X], pPlayer->iFieldPos[Y], i2)
		pFieldT = &pLevel->pField[i2];
		// Check if an camera should be played:
		if(pFieldT->iCamera != -1 && !PlayerInfo.bGhost && pLevel->Header.iCameraScripts)
		{ // Yes:
			bCameraAnimation = TRUE;
			memset(&TempCamera, 0, sizeof(AS_CAMERA));
			lCameraTimer = g_lNow;
			pLevel->Camera.iCurrentCameraStep = 0;
			pLevel->pCurrentCameraScript = &pLevel->pCameraScript[pFieldT->iCamera];
			if(pLevel->pCurrentCameraScript->iTextScript != -1)
				PlayTextScript(pLevel->pCurrentCameraScript->iTextScript);
			if(!pFieldT->bCameraAlways)
				pFieldT->iCamera = -1;
		}
		// Check if an text script should be played:
		if(pFieldT->iTextScript != -1 && !PlayerInfo.bGhost)
		{ // Yes:
			PlayTextScript(pFieldT->iTextScript);
			if(!pFieldT->bTextScriptAlways)
				pFieldT->iTextScript = -1;
		}
		// Check the fields it selves:
		for(i = 0; i < 2; i++)
		{
			if(!i)
				GET_FIELD_ID(pPlayer->iFieldPos[X], pPlayer->iFieldPos[Y], i2)
			else
			{
				if(pPlayer->bMove)
					break;
				if(pPlayer->byAction == ACTION_RUN_RIGHT)
					GET_FIELD_ID((pPlayer->iFieldPos[X]-1), pPlayer->iFieldPos[Y], i2)
				else
				if(pPlayer->byAction == ACTION_RUN_DOWN)
					GET_FIELD_ID(pPlayer->iFieldPos[X], (pPlayer->iFieldPos[Y]-1), i2)
				else
				if(pPlayer->byAction == ACTION_RUN_LEFT)
					GET_FIELD_ID((pPlayer->iFieldPos[X]+1), pPlayer->iFieldPos[Y], i2)
				else
				if(pPlayer->byAction == ACTION_RUN_UP)
					GET_FIELD_ID(pPlayer->iFieldPos[X], (pPlayer->iFieldPos[Y]+1), i2)
				else
					break;
			}
			pFieldT = &pLevel->pField[i2];
			if(!pFieldT->bActive)
				break;
			if(!pFieldT->pBridgeActor)
				CheckPlayerSurface(pFieldT->pSurface[FACE_FLOOR][0], pFieldT->iID);
		}
	}

	// Check ghost mode:
	if(g_lNow-PlayerInfo.lGhostTime > PlayerInfo.lGhostWholeTime && PlayerInfo.bGhost)
	{ // The ghost time is left!
		// Check if the player is in a wall or an actor:
		if(pLevel->pField[pPlayer->iFieldID].bWall ||
		   (pLevel->pField[pPlayer->iFieldID].pActor && pLevel->pField[pPlayer->iFieldID].pActor != pPlayer))
		{ // Yea, we are in a object... that hurts!
			pPlayer->fPower -= (float) g_lDeltatime/10;
		}
		else
		{ // Deactivate this mode:
			PlayerInfo.bGhost = FALSE;
			pLevel->pField[pPlayer->iFieldID].pActor = pPlayer;
			ParticleManager.pSystem[PS_PLAYER_GHOST].bGoingInActive = TRUE;
		}
	}
	// Check the speed modus:
	if(g_lNow-PlayerInfo.lSpeedTime > PlayerInfo.lSpeedWholeTime && PlayerInfo.bSpeed)
	{ // The speed time is left!
		PlayerInfo.bSpeed = FALSE;
		ParticleManager.pSystem[PS_PLAYER_SPEED].bGoingInActive = TRUE;
	}
	if(!pPlayer->bMove)
	{
		if(PlayerInfo.bSpeed)
			pPlayer->fVelocity[0] = PLAYER_MOVE_SPEED/3;
		else
			pPlayer->fVelocity[0] = PLAYER_MOVE_SPEED;
	}
	// Check the wing modus:
	if(g_lNow-PlayerInfo.lWingTime > PlayerInfo.lWingWholeTime && PlayerInfo.bWing)
	{ // The wing time is left!
		PlayerInfo.bWing = FALSE;
	}
	// Check the shield modus:
	if(g_lNow-PlayerInfo.lShieldTime > PlayerInfo.lShieldWholeTime && PlayerInfo.bShield)
	{ // The shield time is left!
		PlayerInfo.bShield = FALSE;
	}
	
	// Check the water:
	// Check the players air:
	fPos2[X] = pPlayer->fWorldPos[X]+0.5f;
	fPos2[Y] = pPlayer->fWorldPos[Y]+0.5f;
	fPos2[Z] = pPlayer->fWorldPos[Z]-0.6f;
	ASGetMd2Vertex(pXeModel, pPlayer->iAniStep, pPlayer->iNextAniStep, pPlayer->fModelInterpolation, fPos2, 0.025f,
				   -90.0f, pPlayer->fRot[Y], 0.0f, 19, &fPos);
	if(fPos[Z] > pLevel->Environment.fWaterActualHeight)
	{ // The player is under water:
		pPlayer->fAir -= (float) g_lDeltatime/10000;
		if(pPlayer->fAir < 0.0f)
		{
			pPlayer->fAir = 0.0f;
			pPlayer->fPower -= (float) g_lDeltatime/50;
		}
	}
	else
	{
		pPlayer->fAir += (float) g_lDeltatime/5000;
		if(pPlayer->fAir > 1.0f)
			pPlayer->fAir = 1.0f;
	}

	fPos2[X] = pPlayer->fWorldPos[X]+0.5f;
	fPos2[Y] = pPlayer->fWorldPos[Y]+0.5f;
	fPos2[Z] = pPlayer->fWorldPos[Z]-0.6f;
	ASGetMd2Vertex(pXeModel, pPlayer->iAniStep, pPlayer->iNextAniStep, pPlayer->fModelInterpolation, fPos2, 0.025f,
				   -90.0f, pPlayer->fRot[Y], 0.0f, 72, &fPos);
	if(fPos[Z] > pLevel->Environment.fWaterActualHeight &&
	   !PlayerInfo.bShield)
	{
		// Is the water acid?
		fF = 50*((fPos[Z]-pLevel->Environment.fWaterActualHeight));
		if(fF > 70.0f)
			fF = 70.0f;
		if(pLevel->Environment.bWaterAcid)
		{ // The player get hurt:
			pPlayer->fPower -= (float) g_lDeltatime/(100-fF);
		}
		else // Is the water lava?
		if(pLevel->Environment.bWaterLava)
		{ // The player is now dead!
			pPlayer->fPower = 0.0f;
		}
	}

	if(bInvulnerable)
	{ // The player could't die:
		pPlayer->fPower = 100.0f;
		pPlayer->fVelocity[Z] = 0.0f;
		pPlayer->bGoingDeath = FALSE;
		pPlayer->bGoingDeath2 = FALSE;
	}
	// Check the players power:
	if(pPlayer->fPower < 1.0f)
	{
		pPlayer->fPower = 0.0f;
		pPlayer->byAction2 = -1;
		if(pPlayer->byAction != ACTION_PLAYER_DEATH)
		{
			pPlayer->byAction = ACTION_PLAYER_DEATH;
			pPlayer->byAnimation = 11;
			pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame-1;
			pPlayer->dwAniTime = g_lNow;
		}
	}


AnimatePlayer:	
	// Rotate the shield:		
	PlayerInfo.fShieldRot[X] += (float) g_lDeltatime/SHIELD_ROTATE_SPEED;
	PlayerInfo.fShieldRot[Y] += (float) g_lDeltatime/SHIELD_ROTATE_SPEED;
	PlayerInfo.fShieldRot[Z] += (float) g_lDeltatime/SHIELD_ROTATE_SPEED;
	// Normalize the colors:
	for(i = 0; i < 3; i++)
		if(pPlayer->fColor[i] < 1.0f)
		{
			pPlayer->fColor[i] += (float) g_lDeltatime/PLAYER_PAINT_SPEED;
			if(pPlayer->fColor[i] > 1.0f)
				pPlayer->fColor[i] = 1.0f;
		}	
	if(pPlayer->bGoingDeath)
	{ // The player lies dead on the floor:
		pPlayer->dwAniTime = g_lNow;
		pPlayer->iNextAniStep = pPlayer->iAniStep = 140;
		if(g_lNow-pPlayer->lStartTime > PLAYER_DEAD_FLOOR_TIME)
		{ // Move the player to the last checkpoint:
			pPlayer->bGoingDeath = FALSE;
			
			// Was the player hunted by the Okta? If yes does he hit the player?
			if(OktaActor.bActive && OktaActor.bThrow)
			{ // Yes! Restart the Level:
				LoadAutosave();
				return;
			}
		
			PlayerInfo.iLives--;
			if(PlayerInfo.iLives < 0)
			{ // Game over!
				memset(pPlayer->fVelocity, 0, sizeof(FLOAT3));
				pPlayer->bActive = FALSE;
				bGameOver = TRUE;
				byGameMenuSelected = 2;
				return;
			}
			else
			{
				pPlayer->fPower = 100.0f;
				SetPlayerToCheckpoint();
			}
		}
		return;
	}
	GET_FIELD_ID(pPlayer->iFieldPos[X], pPlayer->iFieldPos[Y], pPlayer->iFieldID)
} // end CheckPlayer()

BOOL CheckPlayerSurface(SURFACE *pSurfaceT, short iFieldID)
{ // begin CheckPlayerSurface()
	if(pSurfaceT->Header.bRadioactive && !PlayerInfo.bShield && !bInvulnerable)
	{ // The player is on a radioactive field:	
		if(g_lNow-lGameTimer < 100)
			return 1;
		lGameTimer = g_lNow;
		pPlayer->fPower -= ((float) (rand() % 1000)/1000.0f);
		MakePlayerCameraRotation(ACTION_PLAYER_PAIN_2);
		if(pPlayer->byAction != ACTION_PLAYER_PAIN_1 && pPlayer->byAction != ACTION_SHOT)
		{
			pPlayer->byAction = ACTION_PLAYER_PAIN_1;
			pPlayer->byAnimation = 4;
			pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
			pPlayer->dwAniTime = g_lNow;
		}
		return 1;
	}
	else
	if((pSurfaceT->Header.bHealth ||
		pSurfaceT->Header.bAlcove))
	{ // The player is on a health field:	
		if(g_lNow-lGameTimer < 100)
			return 1;
		lGameTimer = g_lNow;
		if(pSurfaceT->Header.bAlcove)
		{ // Checkpoint:
			if(iFieldID == pPlayer->iFieldID &&
			   PlayerInfo.iCheckpointFieldID != iFieldID &&
			   !pPlayer->bShouldMove && !pPlayer->bMove)
			{ // We are on a new checkpoint:
				SaveAutosave();
				pCamera->fRot2Velocity[0] = 0.0f;
				pCamera->fRot2Velocity[1] = 0.0f;
				pCamera->fRot2Velocity[1] = 0.0f;
				MakePlayerCameraRotation(ACTION_SHOT);
				PlayerInfo.iCheckpointFieldID = pPlayer->iFieldID;
				if(pPlayer->byAction != ACTION_PLAYER_CHECKPOINT && pPlayer->byAction != ACTION_SHOT)
				{
					pPlayer->byAction = ACTION_PLAYER_CHECKPOINT;
					pPlayer->byAction2 = -1;
					pPlayer->byAnimation = 5;
					pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
					pPlayer->dwAniTime = g_lNow;
				}
				return 1;
			}
		}
		if(pPlayer->fPower < 100.0f && pPlayer->byAction != ACTION_PLAYER_CHECKPOINT)
		{
			MakePlayerCameraRotation(ACTION_RUN_RIGHT);
			if(pSurfaceT->Header.bHealth)
				pPlayer->fPower += ((float) (rand() % 1000)/100.0f);
			else
				pPlayer->fPower += ((float) (rand() % 1000)/5000.0f);
			if(pPlayer->fPower > 100.0f)
				pPlayer->fPower = 100.0f;
			else
			{
				if(pPlayer->byAction != ACTION_PLAYER_HEALTH && pPlayer->byAction != ACTION_SHOT)
				{
					pPlayer->byAction = ACTION_PLAYER_HEALTH;
					pPlayer->byAnimation = 9;
					pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
					pPlayer->dwAniTime = g_lNow;
				}
			}
			return 1;
		}
		else
		{
			if(pPlayer->byAction == ACTION_PLAYER_HEALTH)
				pPlayer->byAction = -1;
		}
	}
	return 0;
} // end CheckPlayerSurface()

// The player push a box (or more), if it's possible then do it and return 1 else return 0
BOOL CheckPlayerPushBox(char byDirection, BOOL bPushBox)
{ // begin CheckPlayerPushBox()
	short iX, iY, iXD, iYD, i, iForce;
	float fForce, fVelocity;
	ACTOR *pActorT;
	FIELD *FieldT, *pFieldT;

	// Setup x/y direction:
	switch(byDirection)
	{
		case RIGHT: iX = 1; iY = 0; break;
		case DOWN: iX = 0; iY = 1; break;
		case LEFT: iX = -1; iY = 0; break;
		case UP: iX = 0; iY = -1; break;
	}

	iForce = PlayerInfo.iForce;
	fForce = PlayerInfo.fForce;
	
	// Is it possible to move?
	if(pPlayer->iFieldPos[X]+iX < 0 || pPlayer->iFieldPos[X]+iX >= pLevel->Header.iWidth-1 ||
	   pPlayer->iFieldPos[Y]+iY < 0 || pPlayer->iFieldPos[Y]+iY >= pLevel->Header.iHeight-1)
		return 0; // It's absolutely not possible to move!!
	FieldT = &pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pPlayer->iFieldPos[X]+iX];
	if(PlayerInfo.bGhost)
	{ // Yep, move:
		pPlayer->bShouldMove = TRUE;
		if(PlayerInfo.iForce > 1)
		{ // This action costs a little of the force:
			PlayerInfo.fForce -= 0.005f;
			if(PlayerInfo.fForce <= 0.0f)
			{
				PlayerInfo.fForce = 1.0f;
				PlayerInfo.iForce--;
			}
		}
		return 1;
	}	
	if(!bPushBox)
		if(FieldT->bWall && FieldT->bActive)
			return 0; // It's absolutely not possible to move!!
	
	if(FieldT->bActive && FieldT->bWall && (!FieldT->pActor || FieldT->pActor->bMove || 
	   (FieldT->pActor->bBridge && FieldT->pActor->bBridgeMovement)))
		return 0; // It's absolutely not possible to move!!

	fVelocity = pPlayer->fVelocity[0];
	// Is there something to push?
	if(FieldT->bWall && FieldT->pActor)
	{ // Yes! Check it:
		for(i = 1;; i++)
		{
			iXD = iX*i;
			iYD = iY*i;
			pFieldT = &pLevel->pField[(pPlayer->iFieldPos[Y]+iYD)*pLevel->Header.iWidth+pPlayer->iFieldPos[X]+iXD];
			if(i-1 < iForce)
			{				
				if(pPlayer->iFieldPos[X]+iXD < 0 || pPlayer->iFieldPos[X]+iXD >= pLevel->Header.iWidth-1 ||
				   pPlayer->iFieldPos[Y]+iYD < 0 || pPlayer->iFieldPos[Y]+iYD >= pLevel->Header.iHeight-1 ||
				  ((pFieldT->bActive && pFieldT->bWall) && !pFieldT->pActor) ||
				   (pFieldT->pActor && pFieldT->pActor->bMove))
					return 0; // No chance to move this thing!!
				// Does we have enought force?
				if(iForce > 1 && pFieldT->pActor)
				{ // This action costs a little of the force:
					if(pFieldT->pActor->bHeavy)
						fForce -= 0.1f;
					else
						fForce -= 0.05f;
					if(fForce <= 0.0f)
					{
						fForce = 1.0f;
						iForce--;
					}
				}
				if(pFieldT->pActor &&
					pFieldT->pActor->bHeavy)
					fVelocity *= 1.6f*pFieldT->pSurface[FACE_FLOOR][0]->Header.fFriction;
				else
					fVelocity *= 1.1f*pFieldT->pSurface[FACE_FLOOR][0]->Header.fFriction;
			}
			else
			{
				if(pPlayer->iFieldPos[X]+iXD < 0 || pPlayer->iFieldPos[X]+iXD >= pLevel->Header.iWidth-1 ||
				   pPlayer->iFieldPos[Y]+iYD < 0 || pPlayer->iFieldPos[Y]+iYD >= pLevel->Header.iHeight-1 ||
				   (pFieldT->bActive && pFieldT->bWall))
					return 0; // No chance to move this thing!!
			}
			if(!pFieldT->bWall || !pFieldT->bActive)
				break; // There is a free field!
		}
		// Ok, now we now that we could push, do this now:
		for(i = 1; i < 1+PlayerInfo.iForce; i++)
		{
			iXD = iX*i;
			iYD = iY*i;
			pFieldT = &pLevel->pField[(pPlayer->iFieldPos[Y]+iYD)*pLevel->Header.iWidth+pPlayer->iFieldPos[X]+iXD];
			if(pPlayer->iFieldPos[X]+iXD < 0 || pPlayer->iFieldPos[X]+iXD >= pLevel->Header.iWidth-1 ||
			   pPlayer->iFieldPos[Y]+iYD < 0 || pPlayer->iFieldPos[Y]+iYD >= pLevel->Header.iHeight-1)
				break;
			pActorT = pFieldT->pActor;
			if(!pActorT)
				break;
			if(PlayerInfo.iForce > 1)
			{ // This action costs a little of the force:
				if(pActorT->bHeavy)
					PlayerInfo.fForce -= 0.1f;
				else
					PlayerInfo.fForce -= 0.05f;
				if(PlayerInfo.fForce <= 0.0f)
				{
					PlayerInfo.fForce = 1.0f;
					PlayerInfo.iForce--;
				}
			}
			pActorT->pVelocityFromActor = pPlayer;
			pActorT->bMove = TRUE;
			pActorT->byDirection = byDirection;
			DisableBoxDocking(pActorT);
		}
		// Give the next field this actor:
		for(i = 1; i < 1+PlayerInfo.iForce; i++)
		{
			iXD = iX*i;
			iYD = iY*i;
			pFieldT = &pLevel->pField[(pPlayer->iFieldPos[Y]+iYD)*pLevel->Header.iWidth+pPlayer->iFieldPos[X]+iXD];
			if(pPlayer->iFieldPos[X]+iXD < 0 || pPlayer->iFieldPos[X]+iXD >= pLevel->Header.iWidth-1 ||
			   pPlayer->iFieldPos[Y]+iYD < 0 || pPlayer->iFieldPos[Y]+iYD >= pLevel->Header.iHeight-1 ||
			   (pFieldT->bActive && pFieldT->bWall))
				break;
			pActorT = pFieldT->pActor;
			if(!pActorT ||
			   pActorT->iFieldPos[X]+iXD < 0 || pActorT->iFieldPos[X]+iXD >= pLevel->Header.iWidth-1 ||
			   pActorT->iFieldPos[Y]+iYD < 0 || pActorT->iFieldPos[Y]+iYD >= pLevel->Header.iHeight-1)
				break;
			if((!pFieldT->bActive || !pFieldT->bWall) &&
			   !pFieldT->pActor)
			   pFieldT->pActor = pActorT;
		}
	}

	if(!pLevel->Tools.bUnlimitedForce && PlayerInfo.iForce > 1)
	{ // This action costs a little of the force:
		PlayerInfo.fForce -= 0.005f;
		if(PlayerInfo.fForce <= 0.0f)
		{
			PlayerInfo.fForce = 1.0f;
			PlayerInfo.iForce--;
		}
	}
	else
		PlayerInfo.fForce = 1.0f;
	// Yep, move:
	pPlayer->fVelocity[0] = fVelocity;
	pPlayer->bShouldMove = TRUE;
	pLevel->Missions.CheckSteps();	
	// Give the next field this actor:
	if(!FieldT->pActor)
	   FieldT->pActor = pPlayer;
	return 1; // Yes, lets pushing!
} // end CheckPlayerPushBox()

// The player throw a box, if it's possible then do it and return 1 else return 0
BOOL CheckPlayerPullBox(char byDirection)
{ // begin CheckPlayerPullBox()
	short iX, iY;
	char byOtherDirection;
	ACTOR *pActorT;
	FIELD *pFieldT;

	// Could the player pull boxes?
	if(!PlayerInfo.bPullBoxes || PlayerInfo.bGhost)
		return 0; // Nope!

	// Setup x/y direction:
	switch(byDirection)
	{
		case RIGHT: iX = 1; iY = 0; byOtherDirection = LEFT; break;
		case DOWN: iX = 0; iY = 1; byOtherDirection = UP; break;
		case LEFT: iX = -1; iY = 0; byOtherDirection = RIGHT; break;
		case UP: iX = 0; iY = -1; byOtherDirection = DOWN; break;
	}

	// Check if we could push:
	if(pPlayer->iFieldPos[X]+iX < 0 || pPlayer->iFieldPos[X]+iX >= pLevel->Header.iWidth-1 ||
	   pPlayer->iFieldPos[Y]+iY < 0 || pPlayer->iFieldPos[Y]+iY >= pLevel->Header.iHeight-1 ||
	   pPlayer->iFieldPos[X]-iX < 0 || pPlayer->iFieldPos[X]-iX >= pLevel->Header.iWidth-1 ||
	   pPlayer->iFieldPos[Y]-iY < 0 || pPlayer->iFieldPos[Y]-iY >= pLevel->Header.iHeight-1 ||
	   !pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pPlayer->iFieldPos[X]+iX].bWall ||
	   pLevel->pField[(pPlayer->iFieldPos[Y]-iY)*pLevel->Header.iWidth+pPlayer->iFieldPos[X]-iX].bWall ||
	   (pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pPlayer->iFieldPos[X]+iX].bWall &&
   	   !pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pPlayer->iFieldPos[X]+iX].pActor) ||
	   pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pPlayer->iFieldPos[X]+iX].pActor->bBridge &&
	   pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pPlayer->iFieldPos[X]+iX].pActor->bBridgeMovement)
		return 0; // It's absolutely not possible to push!!
	// Push the box:
	pFieldT = &pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pPlayer->iFieldPos[X]+iX];
	pActorT = pFieldT->pActor;
	if(pActorT->bMove)
		return 0;
	if(pActorT->bHeavy)
	{
		PlayerInfo.fForce -= 0.1f;
		pPlayer->fVelocity[0] *= 1.6f*pFieldT->pSurface[FACE_FLOOR][0]->Header.fFriction;
	}
	else
	{
		PlayerInfo.fForce -= 0.05f;
		pPlayer->fVelocity[0] *= 1.1f*pFieldT->pSurface[FACE_FLOOR][0]->Header.fFriction;
	}
	if(PlayerInfo.fForce <= 0.0f)
	{
		PlayerInfo.fForce = 1.0f;
		PlayerInfo.iForce--;
	}
	pActorT->bMove = TRUE;
	pActorT->pVelocityFromActor = pPlayer;
	pActorT->byDirection = byOtherDirection;
	DisableBoxDocking(pActorT);
	pLevel->Missions.CheckSteps();	
	if(!pLevel->Tools.bUnlimitedPull)
	{
		PlayerInfo.iPullBoxes--;
		if(!PlayerInfo.iPullBoxes)
			PlayerInfo.bPullBoxes = FALSE;
	}
	return 1;
} // end CheckPlayerPullBox()

// The player throw a box, if it's possible then do it and return 1 else return 0
BOOL CheckPlayerThrowBox(char byDirection)
{ // begin CheckPlayerThrowBox()
	short iX, iY, iX2, iY2;
	ACTOR *pActorT;

	// Could the player pull boxes?
	if(!PlayerInfo.bThrowBoxes || PlayerInfo.bGhost)
		return 0; // Nope!

	// Setup x/y direction:
	switch(byDirection)
	{
		case RIGHT: iX = 1; iY = 0; break;
		case DOWN: iX = 0; iY = 1; break;
		case LEFT: iX = -1; iY = 0; break;
		case UP: iX = 0; iY = -1; break;
	}
	// Check if we could throw:
	if(pPlayer->iFieldPos[X]+iX < 0 || pPlayer->iFieldPos[X]+iX >= pLevel->Header.iWidth-1 ||
	   pPlayer->iFieldPos[Y]+iY < 0 || pPlayer->iFieldPos[Y]+iY >= pLevel->Header.iHeight-1 ||
	   !pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pPlayer->iFieldPos[X]+iX].pActor ||
	   (pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pPlayer->iFieldPos[X]+iX].pActor &&
	   !pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pPlayer->iFieldPos[X]+iX].bWall) ||
	   (!pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pPlayer->iFieldPos[X]+iX].pActor &&
	   pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pPlayer->iFieldPos[X]+iX].bWall) ||
	   pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pPlayer->iFieldPos[X]+iX].pActor->bBridge &&
	   pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pPlayer->iFieldPos[X]+iX].pActor->bBridgeMovement)
		return 0; // There is nothing to throw!
	iX2 = iX*2;
	iY2 = iY*2;
	// It's absolutely not possible to throw a box!!
	if(pPlayer->iFieldPos[X]+iX2 < 0 || pPlayer->iFieldPos[X]+iX2 >= pLevel->Header.iWidth-1 ||
	   pPlayer->iFieldPos[Y]+iY2 < 0 || pPlayer->iFieldPos[Y]+iY2 >= pLevel->Header.iHeight-1 ||
	   (pLevel->pField[(pPlayer->iFieldPos[Y]+iY2)*pLevel->Header.iWidth+pPlayer->iFieldPos[X]+iX2].bActive &&
	    pLevel->pField[(pPlayer->iFieldPos[Y]+iY2)*pLevel->Header.iWidth+pPlayer->iFieldPos[X]+iX2].bWall))
		return 0; // There is nothing to throw!
	
	// Throw the box:
	pActorT = pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pPlayer->iFieldPos[X]+iX].pActor;
	if(pActorT->bThrow || pActorT->bMove)
		return 0; // There is nothing to throw!
	if(pActorT->bHeavy)
	{
		PlayerInfo.fForce -= 0.2f;
		pActorT->fVelocity[0] = PLAYER_THROW_SPEED*1.6f;
	}
	else
	{
		PlayerInfo.fForce -= 0.1f;
		pActorT->fVelocity[0] = PLAYER_THROW_SPEED*1.1f;
	}
	pActorT->bMove = TRUE;
	pActorT->bThrow = TRUE;
	pActorT->pVelocityFromActor = NULL;
	pActorT->bUseFriction = TRUE;
	pActorT->fVelocity[0] = PLAYER_THROW_SPEED;
	pActorT->byDirection = byDirection;
	DisableBoxDocking(pActorT);
	if(!pLevel->Tools.bUnlimitedThrow)
	{
		PlayerInfo.iThrowBoxes--;
		if(!PlayerInfo.iThrowBoxes)
			PlayerInfo.bThrowBoxes = FALSE;
	}
	return 1;
} // end CheckPlayerThrowBox()

BOOL CheckPlayerJump(char byDirection)
{ // begin CheckPlayerJump()
	short iX, iY, iX2, iY2;

	// Setup x/y direction:
	switch(byDirection)
	{
		case RIGHT: iX = 1; iY = 0; break;
		case DOWN: iX = 0; iY = 1; break;
		case LEFT: iX = -1; iY = 0; break;
		case UP: iX = 0; iY = -1; break;
	}
	// Check if we could jump:
	if(pPlayer->iFieldPos[X]+iX < 0 || pPlayer->iFieldPos[X]+iX >= pLevel->Header.iWidth-1 ||
	   pPlayer->iFieldPos[Y]+iY < 0 || pPlayer->iFieldPos[Y]+iY >= pLevel->Header.iHeight-1 ||
	   (!PlayerInfo.bGhost && (pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pPlayer->iFieldPos[X]+iX].pActor ||
	    (pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pPlayer->iFieldPos[X]+iX].bActive &&
		 pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pPlayer->iFieldPos[X]+iX].bWall))))
	{
		FIELD *pFieldT;
		pFieldT = &pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pPlayer->iFieldPos[X]+iX];
		return 0; // It's not possible to jump!
	}
	iX2 = iX*2;
	iY2 = iY*2;

	// Jump animation:
	pPlayer->byAction = ACTION_JUMP;
	pPlayer->byAction2 = -1;
	pPlayer->byAnimation = 5;
	pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
	pPlayer->dwAniTime = g_lNow;
	pPlayer->iTempFieldID = pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pPlayer->iFieldPos[X]+iX].iID;
	if(!pLevel->Tools.bUnlimitedJump)
	{				
		PlayerInfo.iJump--;
		if(PlayerInfo.iJump <= 0)
			PlayerInfo.bJump = FALSE;
	}
	return 1;
} // end CheckPlayerJump()

void SetPlayerToCheckpoint(void)
{ // begin SetPlayerToCheckpoint()
	short i;

	if(pPlayer->iFieldID >= 0 && pPlayer->iFieldID < pLevel->Header.iFields &&
	   pLevel->pField[pPlayer->iFieldID].pActor == pPlayer)
		pLevel->pField[pPlayer->iFieldID].pActor = NULL;
	// Check if the field is free:
	pPlayer->iFieldID = PlayerInfo.iCheckpointFieldID;
	if(pLevel->pField[pPlayer->iFieldID].pActor &&
	  (pLevel->pField[pPlayer->iFieldID].pActor->byType == ACTOR_BOX_NORMAL ||
	   pLevel->pField[pPlayer->iFieldID].pActor->byType == ACTOR_BOX_RED ||
	   pLevel->pField[pPlayer->iFieldID].pActor->byType == ACTOR_BOX_GREEN ||
	   pLevel->pField[pPlayer->iFieldID].pActor->byType == ACTOR_BOX_BLUE))
	{
		DeleteActorType(pLevel->pField[pPlayer->iFieldID].pActor);
		pLevel->pField[pPlayer->iFieldID].pActor->bGoingDeath = TRUE;
	}
	memset(pPlayer->fFieldPos, 0, sizeof(FLOAT3));
	memset(pPlayer->fVelocity, 0, sizeof(FLOAT3));
	pPlayer->fVelocity[0] = PLAYER_MOVE_SPEED;
	pPlayer->iFieldPos[X] = pLevel->pField[pPlayer->iFieldID].iXField;
	pPlayer->iFieldPos[Y] = pLevel->pField[pPlayer->iFieldID].iYField;
	pPlayer->byType = ACTOR_PLAYER;
	pPlayer->byAction = -1;
	pPlayer->byAction2 = -1;
	if(!pPlayer->fPower)
		pPlayer->fPower = 0.1f;
	pPlayer->fColor[0] = 1.0f;
	pPlayer->fColor[1] = 1.0f;
	pPlayer->fColor[2] = 1.0f;
	pPlayer->fAir = 1.0f;
	pPlayer->fFieldPos[Z] = 0.0f;
	pPlayer->bGoingDeath = FALSE;
	pPlayer->bGoingDeath2 = FALSE;
	pPlayer->bShouldMove = FALSE;
	pPlayer->bMove = FALSE;
	pPlayer->byAction = ACTION_PLAYER_CHECKPOINT;
	pPlayer->byAction2 = -1;
	pPlayer->byAnimation = 5;
	pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
	pPlayer->dwAniTime = g_lNow;

	pPlayer->fWorldPos[X] = pPlayer->iFieldPos[X]*pLevel->Header.fFieldWidth+pPlayer->fFieldPos[X];
	pPlayer->fWorldPos[Y] = pPlayer->iFieldPos[Y]*pLevel->Header.fFieldHeight+pPlayer->fFieldPos[Y];

	// Set the camera to this new location:
	pCamera->fPos2[X] = pCamera->fPos[X]+pPlayer->fWorldPos[X]+0.5f;
	pCamera->fPos2[Y] = pCamera->fPos[Y]+pPlayer->fWorldPos[Y]+0.5f;
	pCamera->fPos2[Z] = -(pCamera->fPos[Z]-(pPlayer->fWorldPos[Z]-STANDART_LEVEL_Z_POS));
	ComputeActorHeight(pPlayer, 0.2f);
	
	if(bPlayerCameraView)
		for(i = 0; i < 3; i++)
			pCamera->fRot[i] = pCamera->fRot2[i] = pCamera->fRot2Velocity[i] = 0;

	if(!pLevel->pField[pPlayer->iFieldID].bActive && !PlayerInfo.bWing && pPlayer->byAction != ACTION_JUMP &&
	   !bInvulnerable)
	{ // The player falls in a hole:
		pPlayer->fPower = 0.0f;
		pPlayer->fVelocity[Z] = 0.005f;
	}
	
	// Give the player a shield for a few seconds:
	PlayerInfo.lShieldTime = g_lNow;
	if(!PlayerInfo.bShield)
	{
		PlayerInfo.bShield = TRUE;
		PlayerInfo.lShieldWholeTime = 4000;
	}
} // end SetPlayerToCheckpoint()

void MakePlayerCameraRotation(char byAction)
{ // begin MakePlayerCameraRotation()
	char i;

	switch(byAction)
	{
		case ACTION_SHOT:
			for(i = 1; i < 3; i++)
			{
				if(pCamera->fRot2Velocity[i] > 0.001f || pCamera->fRot2Velocity[i] < -0.001f)
					continue;
				if(!(rand() % 2))
					pCamera->fRot2Velocity[i] += (float) (rand() % 100)/10000;
				else
					pCamera->fRot2Velocity[i] -= (float) (rand() % 100)/10000;
			}
			if(pCamera->fRot2Velocity[X] < 0.001f && pCamera->fRot2Velocity[X] > -0.001f)
				pCamera->fRot2Velocity[X] -= 0.05f+((float) (rand() % 5)/50);
		break;
		
		case ACTION_RUN_RIGHT: case ACTION_RUN_DOWN: case ACTION_RUN_LEFT: case ACTION_RUN_UP:
			for(i = 0; i < 3; i++)
			{
				if(pCamera->fRot2Velocity[i] > 0.001f || pCamera->fRot2Velocity[i] < -0.001f)
					continue;
				if(!(rand() % 2))
					pCamera->fRot2Velocity[i] += (float) (rand() % 100)/10000;
				else
					pCamera->fRot2Velocity[i] -= (float) (rand() % 100)/10000;
			}
		break;

		case ACTION_STAND:
			for(i = 0; i < 3; i++)
			{
				if(pCamera->fRot2Velocity[i] > 0.001f || pCamera->fRot2Velocity[i] < -0.001f)
					continue;
				if(!(rand() % 2))
					pCamera->fRot2Velocity[i] += (float) (rand() % 100)/100000;
				else
					pCamera->fRot2Velocity[i] -= (float) (rand() % 100)/100000;
			}
		break;

		case ACTION_PLAYER_PAIN_1: case ACTION_PLAYER_PAIN_2: case ACTION_PLAYER_PAIN_3:
			for(i = 0; i < 3; i++)
			{
				if(pCamera->fRot2Velocity[i] > 0.001f || pCamera->fRot2Velocity[i] < -0.001f)
					continue;
				if(!(rand() % 2))
					pCamera->fRot2Velocity[i] += (float) (rand() % 100)/1000;
				else
					pCamera->fRot2Velocity[i] -= (float) (rand() % 100)/1000;
			}
		break;
	}
} // end MakePlayerCameraRotation()
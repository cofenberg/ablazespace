//-----------------------------------------------------------------------------
// File: Load_Save_Level.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


void LEVEL::Load(char *pbyFilename)
{ // begin LEVEL::Load()
	AS_PROGRESS_WINDOW ProgressWindow;
	LEVEL_HEADER HeaderT;
	char byTemp[256], byTemp2[256];
	short i, i2, i3;
	long lTimeTemp;
	BOOL bTemp;
	FILE *fp, *fp2;
	long l;

	_AS->WriteLogMessage("Load level: %s", pbyFilename);	
	ProgressWindow.CreateProgressWindow("Loading World");
	ProgressWindow.SetTask("Loading level %s...", pbyFilename);
	ProgressWindow.SetSubTask("Initialize level");
	ProgressWindow.SetProgress(0);
	
	// Open the level:
	if(!pbyFilename)
		return;
	fp = fopen(pbyFilename, "rb");
	if(!fp)
		return;

	// First, check if this is an correct level version:
	fread(&iVersion, sizeof(short), 1, fp);
	if(iVersion != LEVEL_VERSION)
	{ // This is an wrong level version!!
		_AS->WriteLogMessage("The level version(%d) is not correct! Couldn't load this level!", iVersion);	
		_AS->WriteLogMessage("The current Convey level version is %d!", LEVEL_VERSION);
		if(_AS->GetModule() == MODULE_EDITOR)  // Give out an message:
			MessageBox(NULL, M_WrongLevelVersion, T_Error, MB_OK | MB_ICONINFORMATION);
		fclose(fp);
		return;
	}
	// Ok, destroy now the old level:
	Destroy(); // Destroy the old level:

	// Load the general level information:
	fread(&HeaderT, sizeof(LEVEL_HEADER), 1, fp);

	// Update the current level filename:
	strcpy(HeaderT.byFilename, pbyFilename);

	// Create the level:
	Create(HeaderT.iWidth, HeaderT.iHeight, HeaderT.fFieldHeight, HeaderT.fFieldWidth, HeaderT.fFieldHeight);
	memcpy(&Header, &HeaderT, sizeof(LEVEL_HEADER));

	// Load the other general stuff:
	fread(&Environment, sizeof(LEVEL_ENVIRONMENT), 1, fp);
	fread(&Tools, sizeof(LEVEL_TOOLS), 1, fp);
	fread(&Missions, sizeof(LEVEL_MISSIONS), 1, fp);
	fread(&Camera, sizeof(LEVEL_CAMERA), 1, fp);

	// Are indestructible wall standart?
	fread(&bIndestructibleWallStandart, sizeof(BOOL), 1, fp);

	// Load the text scripts:
	fread(&TextScriptsManager, sizeof(TEXT_SCRIPTS_MANAGER), 1, fp);
	LoadTextScriptSource(TextScriptsManager.byFilename);
	pTextScript = (TEXT_SCRIPT *) malloc(sizeof(TEXT_SCRIPT)*TextScriptsManager.iTextsScripts);
	for(i = 0; i < TextScriptsManager.iTextsScripts; i++)
	{
		fread(&pTextScript[i].byName, sizeof(char)*256, 1, fp);
		fread(&pTextScript[i].iTexts, sizeof(short), 1, fp);
		pTextScript[i].pText = (TEXT_SCRIPT_TEXT *) malloc(sizeof(TEXT_SCRIPT)*pTextScript[i].iTexts);
		for(i2 = 0; i2 < pTextScript[i].iTexts; i2++)
			fread(&pTextScript[i].pText[i2], sizeof(TEXT_SCRIPT_TEXT), 1, fp);
	}

	InitMissions();

	// Load the surfaces:
	pSurface = (SURFACE *) realloc(pSurface, sizeof(SURFACE)*Header.iSurfaces);
	ProgressWindow.SetTask("Loading surfaces");
	for(i = 1; i < Header.iSurfaces; i++)
	{
		ProgressWindow.SetProgress((UINT) (((float) i/Header.iSurfaces)*100));
	
		memset(&pSurface[i], 0, sizeof(SURFACE)); 
		
		// Load the general surface information:
		fread(&pSurface[i].Header, sizeof(SURFACE_HEADER), 1, fp);
		ProgressWindow.SetSubTask("%s", pSurface[i].Header.byName);
		
		// Update the ID:
		pSurface[i].Header.iID = i;
		
		// Animation steps:
		pSurface[i].pTexturePos = (TEXTURE_POS *) malloc(sizeof(TEXTURE_POS)*pSurface[i].Header.iAniSteps);

		// Texture filename:
		pSurface[i].byTextureFilename = (char **) malloc(sizeof(char *)*pSurface[i].Header.iAniSteps);
		pSurface[i].iTextureID = (short *) malloc(sizeof(short)*pSurface[i].Header.iAniSteps);
		pSurface[i].pTexture = (AS_TEXTURE **) malloc(sizeof(AS_TEXTURE *)*pSurface[i].Header.iAniSteps);
		SURFACE *pSurfaceT = &pSurface[i];
		
		// Load the animation steps of this surface:
		for(i2 = 0; i2 < pSurface[i].Header.iAniSteps; i2++)
		{
			pSurface[i].byTextureFilename[i2] = (char *) malloc(sizeof(char)*MAX_PATH);
			fread(pSurface[i].byTextureFilename[i2], sizeof(char)*MAX_PATH, 1, fp);

			// Load the texture:
			LoadTexture(pSurface[i].byTextureFilename[i2]);
			pCurrentTexture->iUsed++;
			pSurface[i].iTextureID[i2] = iCurrentTexture;
			pSurface[i].pTexture[i2] = pCurrentTexture;

			// Texture positions:
			for(i3 = 0; i3 < 4; i3++)
				fread(&pSurface[i].pTexturePos[i2].iPos[i3], sizeof(SHORT2), 1, fp);
			fread(&pSurface[i].pTexturePos[i2].iTimeToNext, sizeof(long), 1, fp);
			fread(pSurface[i].pTexturePos[i2].fColor, sizeof(float)*4, 1, fp);
		}
		
		// Update the surface:
		pSurface[i].CalculateFloatTexturePos();
		strcpy(pSurface[i].Header.byFilename, "");
	}

	// Load decorations:
	fread(&iDecorationModels, sizeof(short), 1, fp);
	pDecorationModels = (DECORATION_MODEL *) malloc(sizeof(DECORATION_MODEL)*iDecorationModels);
	for(i = 0; i < iDecorationModels; i++)
	{
		memset(&pDecorationModels[i], 0, sizeof(DECORATION_MODEL));
		fread(pDecorationModels[i].byFilename, sizeof(char)*256, 1, fp);
		sprintf(byTemp, "%s%s", _AS->pbyProgramPath, pDecorationModels[i].byFilename);
		pDecorationModels[i].pModel = ASLoadMd2Model(byTemp);
	}

	ProgressWindow.SetTask("Setup level");
	ProgressWindow.SetSubTask(" ");
	ProgressWindow.SetProgress(0);
	
	// Load point information:
	fread(fPoint, sizeof(FLOAT3)*Header.iPoints, 1, fp);
	// Load color information:
	fread(fColor, sizeof(FLOAT4)*Header.iPoints, 1, fp);

	// Load field information:
	for(i = 0; i < Header.iFields; i++)
	{
		// Active:
		fread(&pField[i].bActive, sizeof(BOOL), 1, fp);
		bTemp = pField[i].bActive;
		// Wall:
		fread(&pField[i].bWall, sizeof(BOOL), 1, fp);
		fread(&pField[i].bWallHole, sizeof(BOOL), 1, fp);
		fread(&pField[i].bAlwaysWall, sizeof(BOOL), 1, fp);
		fread(&pField[i].bIndestructibleWall, sizeof(BOOL), 1, fp);
		if(pField[i].bWallHole)
			pField[i].bWall = TRUE;
		if(pField[i].bAlwaysWall)
			SetFieldWall(pField[i].iXField, pField[i].iYField, FALSE, FALSE);
		else
			SetFieldWall(pField[i].iXField, pField[i].iYField, pField[i].bWall, FALSE);
		pField[i].bActive = bTemp;
		// Beamer:
		fread(&pField[i].fBeamerPower, sizeof(float), 1, fp);
		fread(&pField[i].iBeamerRegenerationSpeed, sizeof(int), 1, fp);
		fread(&pField[i].iBeamerTarget, sizeof(short), 1, fp);
		// No backface culling:
		fread(&pField[i].bNoBackfaceCulling, sizeof(BOOL), 1, fp);
		// Camera script:
		fread(&pField[i].iCamera, sizeof(short), 1, fp);
		fread(&pField[i].bCameraAlways, sizeof(BOOL), 1, fp);
		// Text script:
		fread(&pField[i].iTextScript, sizeof(short), 1, fp);
		fread(&pField[i].bTextScriptAlways, sizeof(BOOL), 1, fp);
		pField[i].bSelected = FALSE;
		// Surfaces:
		for(i3 = 0; i3 < 2; i3++)
		{
			for(i2 = 0; i2 < 6; i2++)
			{
				fread(&pField[i].iSurface[i2][i3], sizeof(short), 1, fp);
				fread(&pField[i].iSurfaceRotation[i2][i3], sizeof(short), 1, fp);
				fread(&pField[i].iCurrentAniStep[i2][i3], sizeof(short), 1, fp);
			}
			for(i2 = 0; i2 < 6; i2++)
			{
				if(pField[i].iSurface[i2][i3] == -1)
					continue;
				pField[i].pSurface[i2][i3] = &pSurface[pField[i].iSurface[i2][i3]];
				if(pField[i].pSurface[i2][i3])
					pField[i].pSurface[i2][i3]->iUsed++;
			}
		}
		pField[i].pActor = pField[i].pBridgeActor = pField[i].pObject = NULL;
		// Decoration;
		fread(&bTemp, sizeof(BOOL), 1, fp);
		if(bTemp)
		{
			pField[i].pDecoration = (FIELD_DECORATION *) malloc(sizeof(FIELD_DECORATION));
			fread(pField[i].pDecoration, sizeof(FIELD_DECORATION), 1, fp);
			if(pField[i].pDecoration->iTexture != -1)
			{
				LoadTexture(pField[i].pDecoration->byTextureFilename);
				pCurrentTexture->iUsed++;
				pField[i].pDecoration->iTexture = iCurrentTexture;
			}
		}
	}
	for(i = 0; i < Header.iFields; i++)
	{
		if(!pField[i].bWallHole)
			continue;
		SetFieldWall(pField[i].iXField, pField[i].iYField, TRUE, FALSE);
	}
	
	// Setup the selected stuff to zero:
	if(Header.iFields)
	{
		iCurrentField = 0;
		pCurrentField = &pField[iCurrentField];
	}
	if(Header.iTextures)
	{
		iCurrentTexture = 0;
		pCurrentTexture = &pTexture[iCurrentTexture];
	}
	if(Header.iSurfaces)
	{
		iCurrentSurface = 0;
		pCurrentSurface = &pSurface[iCurrentSurface];
	}
	if(Header.iCameraScripts)
	{
		iCurrentCameraScript = 0;
		pCurrentCameraScript = &pCameraScript[iCurrentCameraScript];
	}

	// Camera scripts:
	pCameraScript = (AS_CAMERA_SCRIPT *) malloc(sizeof(AS_CAMERA_SCRIPT)*Header.iCameraScripts);
	for(i = 0; i < Header.iCameraScripts; i++)
	{
		// Name:
		fread(&pCameraScript[i].byName, sizeof(char)*256, 1, fp);
		// Steps:
		fread(&pCameraScript[i].iSteps, sizeof(short), 1, fp);
		// Text script:
		fread(&pCameraScript[i].iTextScript, sizeof(short), 1, fp);
		pCameraScript[i].pCamera = (AS_CAMERA *) malloc(sizeof(AS_CAMERA)*pCameraScript[i].iSteps);
		// Camera steps:
		for(i2 = 0; i2 < pCameraScript[i].iSteps; i2++)
			fread(&pCameraScript[i].pCamera[i2], sizeof(AS_CAMERA), 1, fp);
	}

	// Player
	fread(&PlayerT, sizeof(ACTOR), 1, fp);
	memcpy(pPlayer, &PlayerT, sizeof(ACTOR));
	PlayerInfo.iCheckpointFieldID = pPlayer->iFieldID;

	// Other actors:
	// Number of active actors:
	fread(&i, sizeof(short), 1, fp);
	// Load the actors:
	memset(&Actor, 0, sizeof(ACTOR)*MAX_ACTORS);

	for(i2 = 0; i2 < i; i2++)
	{
		fread(&ActorT[i2], sizeof(ACTOR), 1, fp);
		memcpy(&Actor[i2], &ActorT[i2], sizeof(ACTOR));
		Actor[i2].iID = i2;
		Actor[i2].iParticleSystemID = -1;
		Actor[i2].bDocked = FALSE;
		Actor[i2].fSize = BOX_NORMAL_SIZE;
		switch(Actor[i2].byType)
		{
			case ACTOR_BOX_NORMAL:
			case ACTOR_BOX_RED:
			case ACTOR_BOX_GREEN:
			case ACTOR_BOX_BLUE:
				if(!pField[Actor[i2].iFieldID].bActive && !pField[Actor[i2].iFieldID].pBridgeActor)
				{
					pField[Actor[i2].iFieldID].bActive = TRUE;
					pField[Actor[i2].iFieldID].pBridgeActor = &Actor[i2];
					SetNoneFreeBox(&Actor[i2]);
					continue;
				}
				if(pField[Actor[i2].iFieldID].pActor && pField[Actor[i2].iFieldID].pActor->iID != i2)
				{ // There's already a box!!
					Actor[i2].bActive = FALSE;
					continue;
				}
			break;

			case ACTOR_HEALTH_OBJ:
			case ACTOR_LIVE_OBJ:
			case ACTOR_PULL_OBJ:
			case ACTOR_THROW_OBJ:
			case ACTOR_FORCE_OBJ:
			case ACTOR_WEAPON_OBJ:
			case ACTOR_POINT_OBJ:
			case ACTOR_GHOST_OBJ:
			case ACTOR_TIME_OBJ:
			case ACTOR_STEP_OBJ:
			case ACTOR_SPEED_OBJ:
			case ACTOR_WING_OBJ:
			case ACTOR_SHIELD_OBJ:
				Actor[i2].fColor[0] = 1.0f;
				Actor[i2].fColor[1] = 1.0f;
				Actor[i2].fColor[2] = 1.0f;
				if(pLevel->pField[Actor[i2].iFieldID].pObject)
					Actor[i2].bActive = FALSE;
				else
					pLevel->pField[Actor[i2].iFieldID].pObject = &Actor[i2];
			break;
			
			case ACTOR_ENEMY_MOBMOB:
				Actor[i2].fColor[0] = 1.0f;
				Actor[i2].fColor[1] = 1.0f;
				Actor[i2].fColor[2] = 1.0f;
			break;
		}
		Actor[i2].dwAniTime = g_lNow;
		CheckActorField(&Actor[i2]);
	}
	//

	if(hWndEditor)
	{ // Update the textures if we are in the editor:
		DestroyTexturesOpenGL(hDCEditorShow, hRCEditorShow);
		GenTexturesOpenGL(hDCEditorShow, hRCEditorShow);
	}

	// Update the level:
	CalculateFieldNormals();
	CalculateFieldBoundingBoxes();
	UpdateAllActorFields();
	State.bLevelComplete = FALSE;
	State.bLevelJustComplete = FALSE;

	// Update the missions:
	UpdateMissions();
	CheckMissions();
	
	// Setup the player information:
	pPlayer->fLastHeightCheckWorldPos[X] = 
	pPlayer->fLastHeightCheckWorldPos[Y] = -1.0f;
	pPlayer->fAir = 1.0f;
	ComputeActorHeight(pPlayer, 0.2f);

	if(!bSingleLevel)
	{ // Get old player information:
		GetLevelFileName(pbyFilename, byTemp2);
		sprintf(byTemp, "%s%s\\%s\\%s", _AS->pbyProgramPath, _AS->pbyIdentityFile, PlayerIdentity.byName, byTemp2);
		fp2 = fopen(byTemp, "rb");
		if(fp2)
		{
			fread(&PlayerInfo, sizeof(PLAYER_INFO), 1, fp2);
			// Load the time dependent stuff:
			g_lNow = GetTickCount();
			fread(&l, sizeof(long), 1, fp2);
			PlayerInfo.lGhostTime = g_lNow-l;
			fread(&l, sizeof(long), 1, fp2);
			PlayerInfo.lSpeedTime = g_lNow-l;
			fread(&l, sizeof(long), 1, fp2);
			PlayerInfo.lWingTime = g_lNow-l;
			fread(&l, sizeof(long), 1, fp2);
			PlayerInfo.lShieldTime = g_lNow-l;
			fclose(fp2);
		}
	}

	PlayerInfo.iLives += Tools.iLives;
	PlayerInfo.iPoints += Tools.iPoints;
	PlayerInfo.iWeaponShots += Tools.iWeapon;
	if(Tools.iWeapon || Tools.bUnlimitedWeapon)
		PlayerInfo.bWeapon = TRUE;
	PlayerInfo.iPullBoxes += Tools.iPull;
	if(Tools.iPull || Tools.bUnlimitedPull)
		PlayerInfo.bPullBoxes = TRUE;
	PlayerInfo.iThrowBoxes += Tools.iThrow;
	if(Tools.iThrow || Tools.bUnlimitedThrow)
		PlayerInfo.bThrowBoxes = TRUE;
	PlayerInfo.iForce += Tools.iForce;
	if(Tools.bUnlimitedForce)
		PlayerInfo.iForce = Header.iWidth+Header.iHeight;
	PlayerInfo.iJump += Tools.iJump;
	if(Tools.iJump || Tools.bUnlimitedJump)
		PlayerInfo.bJump = TRUE;
	if(Tools.bGhost)
	{ // The player is at the level start in the ghost-mode:
		PlayerInfo.bGhost = TRUE;
		PlayerInfo.lGhostTime = g_lNow;
		PlayerInfo.lGhostWholeTime = Tools.lGhostTime;
		ParticleManager.pSystem[PS_PLAYER_GHOST].bActive = TRUE;
	}
	if(Tools.bSpeed)
	{ // The player is at the level start in the speed-mode:
		PlayerInfo.bSpeed = TRUE;
		PlayerInfo.lSpeedTime = g_lNow;
		ParticleManager.pSystem[PS_PLAYER_SPEED].bActive = TRUE;
		PlayerInfo.lSpeedWholeTime = Tools.lSpeedTime;
	}
	if(Tools.bWing)
	{ // The player is at the level start in the wing-mode:
		PlayerInfo.bWing = TRUE;
		PlayerInfo.lWingTime = g_lNow;
		PlayerInfo.lWingWholeTime = Tools.lWingTime;
	}
	if(Tools.bShield)
	{ // The player is at the level start in the shield-mode:
		PlayerInfo.bShield = TRUE;
		PlayerInfo.lShieldTime = g_lNow;
		PlayerInfo.lShieldWholeTime = Tools.lShieldTime;
	}

	// Setup the actors:
	for(i = 0; i < MAX_ACTORS; i++)
	{
		Actor[i].fLastHeightCheckWorldPos[X] = 
		Actor[i].fLastHeightCheckWorldPos[Y] = -1.0f;
	}
	OktaActor.bActive = FALSE;

	// Setup the camera:
	memset(&LevelTempCamera, 0, sizeof(AS_CAMERA));
	memcpy(pCamera, &Camera.StartCamera, sizeof(AS_CAMERA));
	pCamera->fPos[Z] = 0.0f;
	if(!Camera.bFreeCamera)
		Camera.bStandartCamera = 0;
	if(!Camera.bStandartCamera)
	{
		pCamera->fRot2[X] = -90.0f;
		bPlayerCameraView = TRUE;
	}
	if(Camera.bStandartCamera)
		bPlayerCameraView = FALSE;
	else
		if(Camera.bPlayerCamera)
			bPlayerCameraView = TRUE;

	bPlayTextScript = FALSE;
	// Get time:
	g_lNow = lGameTimer = Missions.lTimeLimitTime = Environment.lWaterAniTime = GetTickCount();

	// Now load the animation time:
	for(i = 0; i < Header.iFields; i++)
	{
		for(i3 = 0; i3 < 2; i3++)
			for(i2 = 0; i2 < 6; i2++)
			{
				fread(&lTimeTemp, sizeof(long), 1, fp);
				pField[i].dwLastTime[i2][i3] = g_lNow-lTimeTemp;
				fread(&lTimeTemp, sizeof(long), 1, fp);
				pField[i].dwLastChangeTime[i2][i3] = g_lNow-lTimeTemp;
			}
	}
	fclose(fp);
	_AS->WriteLogMessage("OK");
} // end LEVEL::Load()

HRESULT LEVEL::Save(char *pbyFilename)
{ // begin LEVEL::Save()
	short i, i2, i3, iVersion;
	long lTimeTemp;
	BOOL bTemp;
	FILE *fp;

	_AS->WriteLogMessage("Save level: %s", pbyFilename);	
	if(!pbyFilename)
		return 1;
	remove(pbyFilename); // Delete the old level file
	fp = fopen(pbyFilename, "wb");
	if(!fp)
		return 1;

	// Save the level version:
	iVersion = LEVEL_VERSION;
	fwrite(&iVersion, sizeof(short), 1, fp);

	// Update the current level filename:
	strcpy(Header.byFilename, pbyFilename);

	// Check if every texture is used:
	i2 = Header.iTextures;
	Header.iTextures = 1;

	// Save the general level information:
	fwrite(&Header, sizeof(LEVEL_HEADER), 1, fp);
	fwrite(&Environment, sizeof(LEVEL_ENVIRONMENT), 1, fp);
	fwrite(&Tools, sizeof(LEVEL_TOOLS), 1, fp);
	fwrite(&Missions, sizeof(LEVEL_MISSIONS), 1, fp);
	memcpy(&Camera.StartCamera, pCamera, sizeof(AS_CAMERA));
	fwrite(&Camera, sizeof(LEVEL_CAMERA), 1, fp);

	// Are indestructible wall standart?
	fwrite(&bIndestructibleWallStandart, sizeof(BOOL), 1, fp);

	Header.iTextures = i2;

	// Save the text scripts:
	fwrite(&TextScriptsManager, sizeof(TEXT_SCRIPTS_MANAGER), 1, fp);
	for(i = 0; i < TextScriptsManager.iTextsScripts; i++)
	{
		fwrite(&pTextScript[i].byName, sizeof(char)*256, 1, fp);
		fwrite(&pTextScript[i].iTexts, sizeof(short), 1, fp);
		for(i2 = 0; i2 < pTextScript[i].iTexts; i2++)
			fwrite(&pTextScript[i].pText[i2], sizeof(TEXT_SCRIPT_TEXT), 1, fp);
	}

	// Save the surfaces:
	for(i = 1; i < Header.iSurfaces; i++)
	{
		fwrite(&pSurface[i].Header, sizeof(SURFACE_HEADER), 1, fp);

		// Texture positions:
		for(i2 = 0; i2 < pSurface[i].Header.iAniSteps; i2++)
		{
			// Texture filename:
			fwrite(pSurface[i].byTextureFilename[i2], sizeof(char)*MAX_PATH, 1, fp);
			for(i3 = 0; i3 < 4; i3++)
				fwrite(&pSurface[i].pTexturePos[i2].iPos[i3], sizeof(SHORT2), 1, fp);
			fwrite(&pSurface[i].pTexturePos[i2].iTimeToNext, sizeof(long), 1, fp);
			fwrite(pSurface[i].pTexturePos[i2].fColor, sizeof(float)*4, 1, fp);
		}
	}

	// Save decorations:
	fwrite(&iDecorationModels, sizeof(short), 1, fp);
	for(i = 0; i < iDecorationModels; i++)
		fwrite(pDecorationModels[i].byFilename, sizeof(char)*256, 1, fp);

	// Point information:
	fwrite(fPoint, sizeof(FLOAT3)*Header.iPoints, 1, fp);
	// Color information:
	fwrite(fColor, sizeof(FLOAT4)*Header.iPoints, 1, fp);

	// Save field information:
	for(i = 0; i < Header.iFields; i++)
	{
		// Active:
		i2 = pField[i].bActive;
		if(pField[i].pBridgeActor)
			pField[i].bActive = FALSE;
		fwrite(&pField[i].bActive, sizeof(BOOL), 1, fp);
		pField[i].bActive = i2;
		// Wall:
		i2 = pField[i].bWall;
		if(pField[i].pActor || pField[i].bAlwaysWall)
			pField[i].bWall = 0;
		fwrite(&pField[i].bWall, sizeof(BOOL), 1, fp);
		fwrite(&pField[i].bWallHole, sizeof(BOOL), 1, fp);
		fwrite(&pField[i].bAlwaysWall, sizeof(BOOL), 1, fp);
		fwrite(&pField[i].bIndestructibleWall, sizeof(BOOL), 1, fp);
		pField[i].bWall = i2;
		// Beamer:
		fwrite(&pField[i].fBeamerPower, sizeof(float), 1, fp);
		fwrite(&pField[i].iBeamerRegenerationSpeed, sizeof(int), 1, fp);
		fwrite(&pField[i].iBeamerTarget, sizeof(short), 1, fp);
		// No backface culling:
		fwrite(&pField[i].bNoBackfaceCulling, sizeof(BOOL), 1, fp);
		// Camera script:
		fwrite(&pField[i].iCamera, sizeof(short), 1, fp);
		fwrite(&pField[i].bCameraAlways, sizeof(BOOL), 1, fp);
		// Text script:
		fwrite(&pField[i].iTextScript, sizeof(short), 1, fp);
		fwrite(&pField[i].bTextScriptAlways, sizeof(BOOL), 1, fp);
		// Surfaces:
		for(i3 = 0; i3 < 2; i3++)
		{
			for(i2 = 0; i2 < 6; i2++)
			{
				fwrite(&pField[i].iSurface[i2][i3], sizeof(short), 1, fp);
				fwrite(&pField[i].iSurfaceRotation[i2][i3], sizeof(short), 1, fp);
				fwrite(&pField[i].iCurrentAniStep[i2][i3], sizeof(short), 1, fp);
			}
			// Save the time to the next animation step:
		}
		// Decoration;
		if(!pField[i].pDecoration)
			bTemp = FALSE;
		else
			bTemp = TRUE;
		fwrite(&bTemp, sizeof(BOOL), 1, fp);
		if(bTemp)
			fwrite(pField[i].pDecoration, sizeof(FIELD_DECORATION), 1, fp);
	}


	// Save the camera scripts:
	for(i = 0; i < Header.iCameraScripts; i++)
	{
		// Name:
		fwrite(&pCameraScript[i].byName, sizeof(char)*256, 1, fp);
		// Steps:
		fwrite(&pCameraScript[i].iSteps, sizeof(short), 1, fp);
		// Text script:
		fwrite(&pCameraScript[i].iTextScript, sizeof(short), 1, fp);
		// Camera steps:
		for(i2 = 0; i2 < pCameraScript[i].iSteps; i2++)
			fwrite(&pCameraScript[i].pCamera[i2], sizeof(AS_CAMERA), 1, fp);
	}

	// Save the player:
	memcpy(&PlayerT, pPlayer, sizeof(ACTOR));
	fwrite(&PlayerT, sizeof(ACTOR), 1, fp);

	// Other actors:
	// Sort them to find out which actors we have to save: (makes the levels smaller)
	i = SortActors(ActorT);
	// Save the number of active actors:
	fwrite(&i, sizeof(short), 1, fp);
	// Save only the active the actors:
	for(i2 = 0; i2 < i; i2++)
		fwrite(&ActorT[i2], sizeof(ACTOR), 1, fp);

	g_lNow = GetTickCount();
	// Now save the animation time:
	for(i = 0; i < Header.iFields; i++)
		for(i3 = 0; i3 < 2; i3++)
			for(i2 = 0; i2 < 6; i2++)
			{
				lTimeTemp = g_lNow-pField[i].dwLastTime[i2][i3];
				fwrite(&lTimeTemp, sizeof(long), 1, fp);
				lTimeTemp = g_lNow-pField[i].dwLastChangeTime[i2][i3];
				fwrite(&lTimeTemp, sizeof(long), 1, fp);
			}

	fclose(fp);
	_AS->WriteLogMessage("OK");
	return 0;
} // end LEVEL::Save()
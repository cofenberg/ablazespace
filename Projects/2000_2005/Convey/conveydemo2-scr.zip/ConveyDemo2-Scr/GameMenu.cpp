//-----------------------------------------------------------------------------
// File: GameMenu.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"

// Variables: *****************************************************************

// Variables: *****************************************************************
BOOL bInGameMenu;
AS_TEXTURE GameMenuTexture[GAME_MENU_TEXTURES];
short iGameMenuBackgroundAniStep;
long lGameMenuBackgroundAniTimer, lPressNewKeyTimer, lCreditsTextTimer;
long lBackFlashTime, lBackFlashTimeDelay, lLastGameMenuKeyTime;
float fBackFlash, fBackFlashDelta, fCurrentBackFlash, fLastBackFlash,
	  fGameMenuBlend, fSelectedSize, fCreditsBlend;
char byGameMenuSelected, byGameMenuMenu, byLastGameMenuMenu, byGameMenuSelectedTemp;
char **pbySingleLevels; // The found single level names
short iSingleLevels;   // The number of found single player levels
char **pbyCampaign; // The found campaigns names
short iCampaigns;   // The number of found campaigns
char **pbyPlayerID; // The found player ID's
short iPlayerIDs, // The number of found player ID's
	  iCreditsTextY;
BOOL bGetPlayerName, // Does the player give in his name?
     bGetNewKey, // Does we wait for a new key definition?
	 bPressNewKeyText,
	 bAreYouSureQuestion,
	 bAreYouSureQuestionAnswer,
	 bSelectedSize,
	 bShowCredits,
	 bMenuChange;
char byGetPlayerName[256]; // The players name
DWORD dwMainMenuStartTime; //  The start time of the main menu
MENU_POINT MenuPoint[MENU_POINTS];

// For the animated font in the main menu:
float fFontAni[4][2]; // The current vertex position
float fFontAniLast[4][2]; // The last vertex position
float fFontAniT[4][2]; // The vertex target position
float fFontAniV[4][2]; // The vertex velocity
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
HRESULT GameMenuLoop(void);
void StartMenuMusic(void);
HRESULT GameMenuDraw(AS_WINDOW *);
void DrawMenuBackground(float, float, float, float,
						float, float, float, float,
						FLOAT3, float);
void ShowOptionMenu(AS_WINDOW *);
HRESULT GameMenuCheck(AS_WINDOW *);
void CheckOptionMenu(void);
void CheckDeletePlayerID(void);
void AnimateFont(void);
void EnumerateSingleLevels(void);
void DestroySingleLevelList(void);
void EnumerateCampaigns(void);
void DestroyCampaignsList(void);
void EnumeratePlayerIDs(void);
void DestroyPlayerIDList(void);
void InitMenuPoints(void);
void CheckMenuPoints(void);
///////////////////////////////////////////////////////////////////////////////
void InitGalaxy(void);
void DrawGalaxy(void);
void DrawStar(float);
///////////////////////////////////////////////////////////////////////////////

CSound *Test;


HRESULT GameMenuLoop(void)
{ // begin GameMenuLoop()
	MSG msg;
	short i;

	InitMenuPoints();
	InitGalaxy();
	bEditorTestLevel = FALSE;
	byGameMenuMenu = 0;
	iGameMenuBackgroundAniStep = byGameMenuSelected = 0;
	lGameMenuBackgroundAniTimer = lBackFlashTime = lLastGameMenuKeyTime = g_lNow;
	fGameMenuBlend = fCreditsBlend = 0.0f;
	dwMainMenuStartTime = g_lNow;
	bMenuChange = bSelectedSize = bShowCredits = FALSE;
	fSelectedSize = 0.5f;

	_AS->pWindow[GAME_WINDOW_ID].SetDrawFunction(GameMenuDraw);
	_AS->pWindow[GAME_WINDOW_ID].SetCheckFunction(GameMenuCheck);

	char byFilename[GAME_MENU_TEXTURES][256] = {"Water.jpg",
												"G_Cloud.jpg",
												"Title.jpg"};
	ASLoadTextures(byFilename, GAME_MENU_TEXTURES, GameMenuTexture);
	ASGenOpenGLTextures(GAME_MENU_TEXTURES, GameMenuTexture);

	StartMenuMusic();
	

	char byTemp[256];
	
	sprintf(byTemp, "%s%s\\Select.wav", _AS->pbyProgramPath, _AS->pbySoundFile);
	ASLoadDXSound(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), &Test, byTemp);


	// Go into the game menu loop:
	_AS->WriteLogMessage("Enter the game menu loop");
	for(;;)
	{
		if(PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
    	{
        	if(!GetMessage(&msg, NULL, 0, 0))
                break;
        	TranslateMessage(&msg);
        	DispatchMessage(&msg);
    	}
		else
		{	
			if(_AS->GetShutDown() || _AS->CheckModuleChange() || !bInGameMenu)
				PostQuitMessage(0);
			if(!_AS->GetActive())
			{
				pPlayer->dwAniTime = g_lNow;
				for(i = 0; i < MAX_ACTORS; i++)
					Actor[i].dwAniTime = g_lNow;
				continue;
			}
			_AS->UpdateWindows();
		}
	}
	_AS->WriteLogMessage("Left the game menu loop");

	ASDestroyDXSound(&Test);

	DestroySingleLevelList();
	DestroyCampaignsList();
	DestroyPlayerIDList();
	ASDestroyOpenGLTextures(GAME_MENU_TEXTURES, GameMenuTexture);
	ASDestroyTextures(GAME_MENU_TEXTURES, GameMenuTexture);

	return msg.wParam;
} // end GameMenuLoop()

void StartMenuMusic(void)
{ // begin StartMenuMusic()
	char byTemp[256];

	// Play the menu music:
	sprintf(byTemp, "%s%s\\CosmicAngel.mid", _AS->pbyProgramPath, _AS->pbyMusicFile);
	_AS->WriteLogMessage("Load music: %s", byTemp);
	ASDXShowPlay(byTemp, *_AS->pWindow[GAME_WINDOW_ID].GethWnd());
} // end StartMenuMusic()

HRESULT GameMenuDraw(AS_WINDOW *pWindow)
{ // begin GameMenuMenu()
	FLOAT3 fColor = {fCurrentBackFlash-0.3f, fCurrentBackFlash-0.3f, 0.2f+fCurrentBackFlash};
	short iX, iY, i, i2;
	float fX, fY, fSize;
	float fBackAni[4][2];

	
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glDisable(GL_FOG);
	glDisable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_DEPTH_TEST);
	
	if(fGameMenuBlend != 0.0f)
	{
		// Draw the galaxy:
		glEnable(GL_BLEND);
		glColor4f(1.0f, 1.0f, 1.0f, 0.99f);
		glBlendFunc(GL_ONE, GL_ONE);
		DrawGalaxy();
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);

		// Draw the water background:
		// Calculate the current frame:
		iY = (short) iGameMenuBackgroundAniStep/7;
		iX = iGameMenuBackgroundAniStep-iY*7;
		fX = (float) (1+65*iX)/512;
		fY = (float) (1+65*iY)/512;
		fSize = 0.125f;
		glColor4f(fCurrentBackFlash, fCurrentBackFlash, 0.5f+fCurrentBackFlash, 0.5f);
		glEnable(GL_BLEND);
		glLoadIdentity();
		glTranslatef(0.0f, 0.0f, -34.0f);
		glBindTexture(GL_TEXTURE_2D, GameMenuTexture[0].iOpenGLID);
		glBegin(GL_QUADS);
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(fX, fY); glVertex3f(-15.0f, -11.0f, 10.0f);
			glTexCoord2f(fX+fSize, fY); glVertex3f(15.0f, -11.0f, 10.0f);
			glTexCoord2f(fX+fSize, fY+fSize); glVertex3f(15.0f, 11.0f, 10.0f);
			glTexCoord2f(fX, fY+fSize); glVertex3f(-15.0f, 11.0f, 10.0f);
		glEnd();

		glLoadIdentity();
		glTranslatef(0.0f, 0.0f, -24.0f*fGameMenuBlend-10.0f);
		glColor4f(fCurrentBackFlash-0.3f, fCurrentBackFlash-0.3f, 0.2f+fCurrentBackFlash, 0.4f);
		glBlendFunc(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);
		
		for(i = 0; i < 4; i++)
			for(i2 = 0; i2 < 2; i2++)
				fBackAni[i][i2] = -fFontAni[i][i2]*0.1f;
			
		switch(byGameMenuMenu)
		{
			case 0: // Main menu background:
				DrawMenuBackground(fX, fY, fSize, 10.0f,
								   -4.5f+fBackAni[3][0], -7.5f+fBackAni[3][1],
								   5.0f+fBackAni[2][0], 1.0f+fBackAni[0][1],
								   fColor, 0.4f);
				// The info bar:
				DrawMenuBackground(fX, fY, fSize, 10.0f,
								   -14.0f, -9.0f,
								   14.0f, -12.0f,
								   fColor, 0.4f);
			break;

			case 6: case 8: // The options menu: // Are you sure question:
				DrawMenuBackground(fX, fY, fSize, 10.0f,
								   -5.0f+fBackAni[3][0], -3.0f+fBackAni[3][1],
								   5.5f+fBackAni[2][0], 1.0f+fBackAni[0][1],
								   fColor, 0.4f);
			break;

			case 7: // Keys setup menu:
				DrawMenuBackground(fX, fY, fSize, 10.0f,
								   -11.0f+fBackAni[3][0], -9.0f+fBackAni[3][1],
								   11.0f+fBackAni[2][0], 2.5f+fBackAni[0][1],
								   fColor, 0.4f);
			break;

			default:
				DrawMenuBackground(fX, fY, fSize, 10.0f,
								   -14.0f+fBackAni[3][0], -10.0f+fBackAni[3][1],
								   14.0f+fBackAni[2][0], 1.0f+fBackAni[0][1],
								   fColor, 0.4f);
			break;
		}
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);

		// Draw the game title:
		glEnable(GL_BLEND);
		glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
		glLoadIdentity();
		glTranslatef(-1.0f, 0.7f, -1.8f);
		glCallList(iGameTitleList);

		glEnable(GL_BLEND);
		// Draw the options:
		// Menu name:
		glColor3f(1.0f, 1.0f, 1.0f);	
		pWindow->Print(560, 300, GAME_VERSION, 0, 0);
		switch(byGameMenuMenu)
		{
			case 0: // Main menu:
				pWindow->Print(0, 5, "A game by AblazeSpace 2001                 All rights reserved!", 0, 0);
			
				pWindow->PrintAnimated(320, 230, T_MainMenu, 0, 2.0f*fGameMenuBlend, fFontAni, 1);
				// Start game:
				glColor3f(MenuPoint[0].fColor[R], MenuPoint[0].fColor[G], MenuPoint[0].fColor[B]);
				pWindow->PrintAnimated(320, 200, T_StartGame, 0, 1.2f*fGameMenuBlend*MenuPoint[0].fSize, fFontAni, 1);
				// Continue game:
				glColor3f(MenuPoint[1].fColor[R], MenuPoint[1].fColor[G], MenuPoint[1].fColor[B]);
				pWindow->PrintAnimated(320, 180, T_ContinueGame, 0, 1.2f*fGameMenuBlend*MenuPoint[1].fSize, fFontAni, 1);
				// Single level:
				glColor3f(MenuPoint[2].fColor[R], MenuPoint[2].fColor[G], MenuPoint[2].fColor[B]);
				pWindow->PrintAnimated(320, 160, T_SingleLevel, 0, 1.2f*fGameMenuBlend*MenuPoint[2].fSize, fFontAni, 1);
				// Options:
				glColor3f(MenuPoint[3].fColor[R], MenuPoint[3].fColor[G], MenuPoint[3].fColor[B]);
				pWindow->PrintAnimated(320, 140, T_Options, 0, 1.2f*fGameMenuBlend*MenuPoint[3].fSize, fFontAni, 1);
				// Editor:
				glColor3f(MenuPoint[4].fColor[R], MenuPoint[4].fColor[G], MenuPoint[4].fColor[B]);
				pWindow->PrintAnimated(320, 120, T_Editor, 0, 1.2f*fGameMenuBlend*MenuPoint[4].fSize, fFontAni, 1);
				// Help:
				glColor3f(MenuPoint[5].fColor[R], MenuPoint[5].fColor[G], MenuPoint[5].fColor[B]);
				pWindow->PrintAnimated(320, 100, T_Help, 0, 1.2f*fGameMenuBlend*MenuPoint[5].fSize, fFontAni, 1);
				// Credits:
				glColor3f(MenuPoint[6].fColor[R], MenuPoint[6].fColor[G], MenuPoint[6].fColor[B]);
				pWindow->PrintAnimated(320, 80, T_Credits, 0, 1.2f*fGameMenuBlend*MenuPoint[6].fSize, fFontAni, 1);
				// Quit:
				glColor3f(MenuPoint[7].fColor[R], MenuPoint[7].fColor[G], MenuPoint[7].fColor[B]);
				pWindow->PrintAnimated(320, 60, T_Quit, 0, 1.2f*fGameMenuBlend*MenuPoint[7].fSize, fFontAni, 1);
			break;

			case 1: // Select single level:
				pWindow->PrintAnimated(320, 230, T_SingleLevel, 0, 2.0f*fGameMenuBlend, fFontAni, 1);
				glColor3f(1.0f, 0.0f, 0.0f);	
				for(i = byGameMenuSelected-5, iY = 200; i < byGameMenuSelected+11; i++)
				{
					if(i < 0)
						continue;
					if(i >= iSingleLevels)
						break;
					glColor3f(1.0f, 1.0f, 1.0f);	
					if(i == byGameMenuSelected)
					{
						glColor3f(1.0f, 0.0f, 0.0f);
						pWindow->PrintAnimated(10, iY, pbySingleLevels[i], 0, 1.0f*fGameMenuBlend*fSelectedSize, fFontAni, 0);
					}
					else
						pWindow->PrintAnimated(10, iY, pbySingleLevels[i], 0, 1.0f*fGameMenuBlend, fFontAni, 0);
					iY -= 20;
				}
			break;

			case 2: // Select campaign:
				pWindow->PrintAnimated(320, 230, T_SelectCampaign, 0, 2.0f*fGameMenuBlend, fFontAni, 1);
				for(i = byGameMenuSelected-5, iY = 200; i < byGameMenuSelected+11; i++)
				{
					if(i < 0)
						continue;
					if(i >= iCampaigns)
						break;
					glColor3f(1.0f, 1.0f, 1.0f);	
					if(i == byGameMenuSelected)
					{
						glColor3f(1.0f, 0.0f, 0.0f);	
						pWindow->PrintAnimated(10, iY, pbyCampaign[i], 0, 1.0f*fGameMenuBlend*fSelectedSize, fFontAni, 0);
					}
					else
						pWindow->PrintAnimated(10, iY, pbyCampaign[i], 0, 1.0f*fGameMenuBlend, fFontAni, 0);
					iY -= 20;
				}
			break;

			case 3: // Select player ID: (for continue game)
				pWindow->PrintAnimated(320, 230, T_SelectYourID, 0, 2.0f*fGameMenuBlend, fFontAni, 1);
				for(i = byGameMenuSelected-5, iY = 200; i < byGameMenuSelected+11; i++)
				{
					if(i < 0)
						continue;
					if(i >= iPlayerIDs)
						break;
					if(i == byGameMenuSelected)
					{
						glColor3f(1.0f, 0.0f, 0.0f);	
						pWindow->PrintAnimated(10, iY, pbyPlayerID[i], 0, 1.0f*fGameMenuBlend*fSelectedSize, fFontAni, 0);
					}
					else
						pWindow->PrintAnimated(10, iY, pbyPlayerID[i], 0, 1.0f*fGameMenuBlend, fFontAni, 0);
					glColor3f(1.0f, 1.0f, 1.0f);	
					iY -= 20;
				}
			break;

			case 4: // Select level of the selected campaign:
				pWindow->PrintAnimated(320, 230, T_SelectLevel, 0, 2.0f*fGameMenuBlend, fFontAni, 1);
				for(i = byGameMenuSelected-5, iY = 200; i < byGameMenuSelected+11; i++)
				{
					if(i < 0)
						continue;
					if(i >= PlayerIdentity.iFinishedLevels+1 || !pbyCampaignLevelNames || i >= CurrentCampaign.iLevels || !pbyCampaignLevelNames[i])
						break;
					if(i == byGameMenuSelected)
					{
						glColor3f(1.0f, 0.0f, 0.0f);	
						pWindow->PrintAnimated(10, iY, pbyCampaignLevelNames[i], 0, 1.0f*fGameMenuBlend*fSelectedSize, fFontAni, 0);
					}
					else
						pWindow->PrintAnimated(10, iY, pbyCampaignLevelNames[i], 0, 1.0f*fGameMenuBlend, fFontAni, 0);
					glColor3f(1.0f, 1.0f, 1.0f);
					iY -= 20;
				}
			break;

			case 5: // Select player ID or create a new one:
				pWindow->PrintAnimated(320, 230, T_SelectYourID, 0, 2.0f*fGameMenuBlend, fFontAni, 1);
				for(i = byGameMenuSelected-5, iY = 200; i < byGameMenuSelected+11; i++)
				{
					if(i < 0)
						continue;
					if(i >= iPlayerIDs)
					{
						if(i == byGameMenuSelected)
						{
							glColor3f(1.0f, 0.0f, 0.0f);	
							if(!bGetPlayerName)
								pWindow->PrintAnimated(320, iY, T_CreateANewPlayerID, 0, 1.0f*fGameMenuBlend*fSelectedSize, fFontAni, 1);
							else
							{ // The player gives in his name:
								pWindow->PrintAnimated(10, iY, byGetPlayerName, 0, 1.0f*fGameMenuBlend, fFontAni, 0);
							}
						}
						else
						{
							if(!bGetPlayerName)
								pWindow->PrintAnimated(320, iY, T_CreateANewPlayerID, 0, 1.0f*fGameMenuBlend, fFontAni, 1);
							else
							{ // The player gives in his name:
								pWindow->PrintAnimated(10, iY, byGetPlayerName, 0, 1.0f*fGameMenuBlend, fFontAni, 0);
							}
						}
						break;
					}
					if(i == byGameMenuSelected)
					{
						glColor3f(1.0f, 0.0f, 0.0f);	
						pWindow->PrintAnimated(10, iY, pbyPlayerID[i], 0, 1.0f*fGameMenuBlend*fSelectedSize, fFontAni, 0);
					}
					else
						pWindow->PrintAnimated(10, iY, pbyPlayerID[i], 0, 1.0f*fGameMenuBlend, fFontAni, 0);
					glColor3f(1.0f, 1.0f, 1.0f);	
					iY -= 20;
				}
			break;

			case 8: // Are you sure question:
				pWindow->PrintAnimated(320, 230, M_AreYouSure, 0, 1.5f*fGameMenuBlend, fFontAni, 1);
				glColor3f(MenuPoint[8].fColor[R], MenuPoint[8].fColor[G], MenuPoint[8].fColor[B]);
				pWindow->PrintAnimated(320, 200, T_Yes, 0, 1.3f*fGameMenuBlend*MenuPoint[8].fSize, fFontAni, 1);
				glColor3f(MenuPoint[9].fColor[R], MenuPoint[9].fColor[G], MenuPoint[9].fColor[B]);
				pWindow->PrintAnimated(320, 185, T_No, 0, 1.3f*fGameMenuBlend*MenuPoint[9].fSize, fFontAni, 1);
			break;

			default:
				ShowOptionMenu(pWindow);
			break;
		}
	
	    // For smooth blend in and out:
		glClear(GL_DEPTH_BUFFER_BIT);
		glEnable(GL_BLEND);
		glDisable(GL_TEXTURE_2D);
		glBlendFunc(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);
		glColor4f(0.0f, 0.0f, 0.0f, fGameMenuBlend);
		glDisable(GL_CULL_FACE);
		glLoadIdentity();
		glTranslatef(0.0f, 0.0f, -34.0f);
		glBegin(GL_QUADS);
			glNormal3f(0.0f, 0.0f, 1.0f);
			glVertex3f(-15.0f, -11.0f, 10.0f);
			glVertex3f( 15.0f, -11.0f, 10.0f);
			glVertex3f( 15.0f,  11.0f, 10.0f);
			glVertex3f(-15.0f,  11.0f, 10.0f);
		glEnd();
		glEnable(GL_CULL_FACE);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	}
	else
	{

	}

	DisplaySmallMessage(pWindow);
	CheckSmallMessage();

	if(fCreditsBlend != 0.0f)
	{
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);
		glEnable(GL_BLEND);
		glEnable(GL_TEXTURE_2D);
		glColor4f(0.7f, 0.7f, 0.7f, fCreditsBlend);
		glLoadIdentity();
		glTranslatef(0.0f, 0.0f, -34.0f);
		glBindTexture(GL_TEXTURE_2D, GameMenuTexture[2].iOpenGLID);
		glBegin(GL_QUADS);
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.0f, 1.0f); glVertex3f(-13.5f, -10.0f, 10.0f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f(13.5f, -10.0f, 10.0f);
			glTexCoord2f(1.0f, 0.0f); glVertex3f(13.5f, 10.0f, 10.0f);
			glTexCoord2f(0.0f, 0.0f); glVertex3f(-13.5f, 10.0f, 10.0f);
		glEnd();

		glColor4f(1.0f, 1.0f, 1.0f, fCreditsBlend);

		for(i = 0, iY = iCreditsTextY; i < iASCreditsTexts; i++, iY -= 25)
		{
			pWindow->PrintAnimated(320, iY, pbyASCreditsText[i], 0, 1.8f, fFontAni, 1);
		}
	}
	if(bGetPlayerName && bPressNewKeyText)
	{
		glEnable(GL_TEXTURE_2D);
		glColor3f(1.0f, 1.0f, 1.0f);	
		pWindow->Print(320, 5, T_EnterName, 0, 1);
	}

	ASSwapBuffers(*pWindow->GethDC(), pWindow, TRUE);
	return 0;
} // end GameMenuMenu()

void DrawMenuBackground(float fX, float fY, float fSize, float fZ,
						float fLeft, float fTop, float fRight, float fBottom,
						FLOAT3 fColor, float fDensity)
{ // begin DrawMenuBackground()
	glDisable(GL_CULL_FACE);
	glBegin(GL_QUADS);
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(fX, fY); glVertex3f(fLeft, fTop, fZ);
		glTexCoord2f(fX+fSize, fY); glVertex3f(fRight, fTop, fZ);
		glTexCoord2f(fX+fSize, fY+fSize); glVertex3f(fRight, fBottom, fZ);
		glTexCoord2f(fX, fY+fSize); glVertex3f(fLeft, fBottom, fZ);
	glEnd();

	// Create a smooth bounding:
	glBegin(GL_QUADS);
		glNormal3f(0.0f, 0.0f, 1.0f);

		// Left:
		glColor4f(fColor[R], fColor[G], fColor[B], fDensity);
		glVertex3d(fRight, fBottom, fZ);
		glVertex3d(fRight, fTop, fZ);
		glColor4f(fColor[R], fColor[G], fColor[B], 1.0f);
		glVertex3d(fRight+0.5f, fTop-0.5f, fZ+1.0f);
		glVertex3d(fRight+0.5f, fBottom+0.5f, fZ+1.0f);

		// Top:
		glColor4f(fColor[R], fColor[G], fColor[B], 1.0f);
		glVertex3d(fLeft-0.5f, fBottom+0.5f, fZ+1.0f);
		glColor4f(fColor[R], fColor[G], fColor[B], fDensity);
		glVertex3d(fLeft, fBottom, fZ);
		glVertex3d(fRight, fBottom, fZ);
		glColor4f(fColor[R], fColor[G], fColor[B], 1.0f);
		glVertex3d(fRight+0.5f, fBottom+0.5f, fZ+1.0f);

		// Right:
		glColor4f(fColor[R], fColor[G], fColor[B], 1.0f);
		glVertex3d(fLeft-0.5f, fTop-0.5f, fZ+1.0f);
		glVertex3d(fLeft-0.5f, fBottom+0.5f, fZ+1.0f);
		glColor4f(fColor[R], fColor[G], fColor[B], fDensity);
		glVertex3d(fLeft, fBottom, fZ);
		glVertex3d(fLeft, fTop, fZ);

		// Bottom:
		glColor4f(fColor[R], fColor[G], fColor[B], 1.0f);
		glVertex3d(fLeft-0.5f, fTop-0.5f, fZ+1.0f);
		glColor4f(fColor[R], fColor[G], fColor[B], fDensity);
		glVertex3d(fLeft, fTop, fZ);
		glVertex3d(fRight, fTop, fZ);
		glColor4f(fColor[R], fColor[G], fColor[B], 1.0f);
		glVertex3d(fRight+0.5f, fTop-0.5f, fZ+1.0f);

	glEnd();
	glEnable(GL_CULL_FACE);
} // end DrawMenuBackground()

void ShowOptionMenu(AS_WINDOW *pWindow)
{ // begin ShowOptionMenu()
	switch(byGameMenuMenu)
	{
		case 6: // Options:
			pWindow->PrintAnimated(320, 230, T_Options, 0, 1.5f*fGameMenuBlend, fFontAni, 1);
			// Set keys:
			glColor3f(MenuPoint[10].fColor[R], MenuPoint[10].fColor[G], MenuPoint[10].fColor[B]);
			pWindow->PrintAnimated(320, 200, T_KeysSetup, 0, 1.0f*fGameMenuBlend*MenuPoint[10].fSize, fFontAni, 1);
			// Other Options:
			glColor3f(MenuPoint[11].fColor[R], MenuPoint[11].fColor[G], MenuPoint[11].fColor[B]);
			pWindow->PrintAnimated(320, 180, T_OtherOptions, 0, 1.0f*fGameMenuBlend*MenuPoint[11].fSize, fFontAni, 1);
		break;

		case 7: // Keys setup:
			pWindow->PrintAnimated(320, 270, T_KeysSetup, 0, 1.5f*fGameMenuBlend, fFontAni, 1);
			// Left:
			glColor3f(MenuPoint[12].fColor[R], MenuPoint[12].fColor[G], MenuPoint[12].fColor[B]);
			pWindow->PrintAnimated(100, 250, T_Left, 0, 1.0f*fGameMenuBlend*MenuPoint[12].fSize, fFontAni, 0);
			pWindow->PrintAnimated(380, 250, AS_DXInputKeys[_ASConfig->iLeftKey[1]].byName, 0, 1.0f*fGameMenuBlend*MenuPoint[12].fSize, fFontAni, 0);
			// Right:
			glColor3f(MenuPoint[13].fColor[R], MenuPoint[13].fColor[G], MenuPoint[13].fColor[B]);
			pWindow->PrintAnimated(100, 237, T_Right, 0, 1.0f*fGameMenuBlend*MenuPoint[13].fSize, fFontAni, 0);
			pWindow->PrintAnimated(380, 237, AS_DXInputKeys[_ASConfig->iRightKey[1]].byName, 0, 1.0f*fGameMenuBlend*MenuPoint[13].fSize, fFontAni, 0);
			// Up:
			glColor3f(MenuPoint[14].fColor[R], MenuPoint[14].fColor[G], MenuPoint[14].fColor[B]);
			pWindow->PrintAnimated(100, 224, T_Up, 0, 1.0f*fGameMenuBlend*MenuPoint[14].fSize, fFontAni, 0);
			pWindow->PrintAnimated(380, 224, AS_DXInputKeys[_ASConfig->iUpKey[1]].byName, 0, 1.0f*fGameMenuBlend*MenuPoint[14].fSize, fFontAni, 0);
			// Down:
			glColor3f(MenuPoint[15].fColor[R], MenuPoint[15].fColor[G], MenuPoint[15].fColor[B]);
			pWindow->PrintAnimated(100, 211, T_Down, 0, 1.0f*fGameMenuBlend*MenuPoint[15].fSize, fFontAni, 0);
			pWindow->PrintAnimated(380, 211, AS_DXInputKeys[_ASConfig->iDownKey[1]].byName, 0, 1.0f*fGameMenuBlend*MenuPoint[15].fSize, fFontAni, 0);
			// Shot:
			glColor3f(MenuPoint[16].fColor[R], MenuPoint[16].fColor[G], MenuPoint[16].fColor[B]);
			pWindow->PrintAnimated(100, 198, T_Shot, 0, 1.0f*fGameMenuBlend*MenuPoint[16].fSize, fFontAni, 0);
			pWindow->PrintAnimated(380, 198, AS_DXInputKeys[_ASConfig->iShotKey[1]].byName, 0, 1.0f*fGameMenuBlend*MenuPoint[16].fSize, fFontAni, 0);
			// Throw:
			glColor3f(MenuPoint[17].fColor[R], MenuPoint[17].fColor[G], MenuPoint[17].fColor[B]);
			pWindow->PrintAnimated(100, 185, T_ThrowObj, 0, 1.0f*fGameMenuBlend*MenuPoint[17].fSize, fFontAni, 0);
			pWindow->PrintAnimated(380, 185, AS_DXInputKeys[_ASConfig->iThrowKey[1]].byName, 0, 1.0f*fGameMenuBlend*MenuPoint[17].fSize, fFontAni, 0);
			// Pull:
			glColor3f(MenuPoint[18].fColor[R], MenuPoint[18].fColor[G], MenuPoint[18].fColor[B]);
			pWindow->PrintAnimated(100, 172, T_PullObj, 0, 1.0f*fGameMenuBlend*MenuPoint[18].fSize, fFontAni, 0);
			pWindow->PrintAnimated(380, 172, AS_DXInputKeys[_ASConfig->iPullKey[1]].byName, 0, 1.0f*fGameMenuBlend*MenuPoint[18].fSize, fFontAni, 0);
			// Suicide:
			glColor3f(MenuPoint[19].fColor[R], MenuPoint[19].fColor[G], MenuPoint[19].fColor[B]);
			pWindow->PrintAnimated(100, 159, T_Suicide, 0, 1.0f*fGameMenuBlend*MenuPoint[19].fSize, fFontAni, 0);
			pWindow->PrintAnimated(380, 159, AS_DXInputKeys[_ASConfig->iSuicideKey[1]].byName, 0, 1.0f*fGameMenuBlend*MenuPoint[19].fSize, fFontAni, 0);
			// Jump:
			glColor3f(MenuPoint[20].fColor[R], MenuPoint[20].fColor[G], MenuPoint[20].fColor[B]);
			pWindow->PrintAnimated(100, 146, T_Jump, 0, 1.0f*fGameMenuBlend*MenuPoint[20].fSize, fFontAni, 0);
			pWindow->PrintAnimated(380, 146, AS_DXInputKeys[_ASConfig->iJumpKey[1]].byName, 0, 1.0f*fGameMenuBlend*MenuPoint[20].fSize, fFontAni, 0);
			// Change perspective:
			glColor3f(MenuPoint[21].fColor[R], MenuPoint[21].fColor[G], MenuPoint[21].fColor[B]);
			pWindow->PrintAnimated(100, 133, T_ChangePerspective, 0, 1.0f*fGameMenuBlend*MenuPoint[21].fSize, fFontAni, 0);
			pWindow->PrintAnimated(380, 133, AS_DXInputKeys[_ASConfig->iChangePerspectiveKey[1]].byName, 0, 1.0f*fGameMenuBlend*MenuPoint[21].fSize, fFontAni, 0);
			// Back camera:
			glColor3f(MenuPoint[22].fColor[R], MenuPoint[22].fColor[G], MenuPoint[22].fColor[B]);
			pWindow->PrintAnimated(100, 120, T_BackCamera, 0, 1.0f*fGameMenuBlend*MenuPoint[22].fSize, fFontAni, 0);
			pWindow->PrintAnimated(380, 120, AS_DXInputKeys[_ASConfig->iBackCameraKey[1]].byName, 0, 1.0f*fGameMenuBlend*MenuPoint[22].fSize, fFontAni, 0);
			// Tilt camera:
			glColor3f(MenuPoint[23].fColor[R], MenuPoint[23].fColor[G], MenuPoint[23].fColor[B]);
			pWindow->PrintAnimated(100, 107, T_TiltCamera, 0, 1.0f*fGameMenuBlend*MenuPoint[23].fSize, fFontAni, 0);
			pWindow->PrintAnimated(380, 107, AS_DXInputKeys[_ASConfig->iTiltCameraKey[1]].byName, 0, 1.0f*fGameMenuBlend*MenuPoint[23].fSize, fFontAni, 0);
			// Standart view:
			glColor3f(MenuPoint[24].fColor[R], MenuPoint[24].fColor[G], MenuPoint[24].fColor[B]);
			pWindow->PrintAnimated(100, 94, T_StandartView, 0, 1.0f*fGameMenuBlend*MenuPoint[24].fSize, fFontAni, 0);
			pWindow->PrintAnimated(380, 94, AS_DXInputKeys[_ASConfig->iStandartViewKey[1]].byName, 0, 1.0f*fGameMenuBlend*MenuPoint[24].fSize, fFontAni, 0);
			// Pause:
			glColor3f(MenuPoint[25].fColor[R], MenuPoint[25].fColor[G], MenuPoint[25].fColor[B]);
			pWindow->PrintAnimated(100, 81, T_Pause, 0, 1.0f*fGameMenuBlend*MenuPoint[25].fSize, fFontAni, 0);
			pWindow->PrintAnimated(380, 81, AS_DXInputKeys[_ASConfig->iPauseKey[1]].byName, 0, 1.0f*fGameMenuBlend*MenuPoint[25].fSize, fFontAni, 0);
			// Load autosave:
			glColor3f(MenuPoint[26].fColor[R], MenuPoint[26].fColor[G], MenuPoint[26].fColor[B]);
			pWindow->PrintAnimated(100, 68, T_LoadAutosave, 0, 1.0f*fGameMenuBlend*MenuPoint[26].fSize, fFontAni, 0);
			pWindow->PrintAnimated(380, 68, AS_DXInputKeys[_ASConfig->iLoadAutosaveKey[1]].byName, 0, 1.0f*fGameMenuBlend*MenuPoint[26].fSize, fFontAni, 0);
			// Level restart:
			glColor3f(MenuPoint[27].fColor[R], MenuPoint[27].fColor[G], MenuPoint[27].fColor[B]);
			pWindow->PrintAnimated(100, 55, T_LevelRestart, 0, 1.0f*fGameMenuBlend*MenuPoint[27].fSize, fFontAni, 0);
			pWindow->PrintAnimated(380, 55, AS_DXInputKeys[_ASConfig->iLevelRestartKey[1]].byName, 0, 1.0f*fGameMenuBlend*MenuPoint[27].fSize, fFontAni, 0);
			// Standart configuration:
			glColor3f(MenuPoint[28].fColor[R], MenuPoint[28].fColor[G], MenuPoint[28].fColor[B]);
			pWindow->PrintAnimated(320, 30, T_StandartConfiguration, 0, 1.0f*fGameMenuBlend*MenuPoint[28].fSize, fFontAni, 1);
			if(bGetNewKey && bPressNewKeyText)
			{
				glColor3f(1.0f, 1.0f, 1.0f);	
				pWindow->Print(320, 5, T_PressNewKey, 0, 1);
			}
		break;
	}
} // end ShowOptionMenu()

HRESULT GameMenuCheck(AS_WINDOW *pWindow)
{ // begin GameMenuCheck()
	short i;
	USHORT iKey;
	char byTemp[256];
	float fDelta;
	
	_AS->ReadDXInput(*pWindow->GethWnd());
	
	for(i = 0; i < 256; i++)
		if(ASKeyFirst[i])
		{
			dwMainMenuStartTime = g_lNow;
			bShowLogos = FALSE;
			if(bMenuChange || bShowCredits)
			{
				byGameMenuSelected = 0;
				byGameMenuMenu = 0;
				ASKeyFirst[i] = FALSE;
			}
			bMenuChange	= FALSE;
			bShowCredits = FALSE;
			if(fGameMenuBlend < 0.0f)
				fGameMenuBlend = 0.0f;
			ASStopDXSound(Test);
			ASPlayDXSound(Test, FALSE);
			break;
		}
	CheckMenuPoints();
	// Game menu blend:
	if(!bShowLogos && fGameMenuBlend < 1.0f && !bShowCredits && !bMenuChange)
	{
		fGameMenuBlend += (float) g_lDeltatime/5000;
		if(fGameMenuBlend > 1.0f)
			fGameMenuBlend = 1.0f;
	}
	if(g_lNow-dwMainMenuStartTime > 30000 && !bMenuChange && !bShowCredits)
	{
		bMenuChange	= TRUE;
		bShowCredits = TRUE;
		bGetPlayerName = FALSE;
		iCreditsTextY = -10;
	}
	if(bMenuChange || bShowCredits)
	{
		// Game menu blend:
		fGameMenuBlend -= (float) g_lDeltatime/5000;
		if(fGameMenuBlend < 0.0f)
			fGameMenuBlend = 0.0f;
		if(bMenuChange && fGameMenuBlend <= 0.0f)
		{
			if(!bShowCredits && fCreditsBlend == 0.0f)
			{
				bShowLogos = TRUE;
				bInGameMenu = FALSE;
			}
		}
	}
	else
		bShowLogos = FALSE;

	// Credits blend:
	if(bShowCredits && fCreditsBlend < 1.0f)
	{
		fCreditsBlend += (float) g_lDeltatime/5000;
		if(fCreditsBlend > 1.0f)
			fCreditsBlend = 1.0f;
	}
	else
	{
		if(fCreditsBlend > 0.0f)
		{
			fCreditsBlend -= (float) g_lDeltatime/5000;
			if(fCreditsBlend < 0.0f)
				fCreditsBlend = 0.0f;
		}
	}
	if(fCreditsBlend != 0.0f)
	{
		if(g_lNow-lCreditsTextTimer > 50)
		{
			lCreditsTextTimer = g_lNow;
			iCreditsTextY++;
		}
	}

// Keys:
	if(ASKeyFirst[DIK_F1])
	{ // Open the help file:
	Help:
		if(_ASConfig->bFullScreen)
		{ // Switch to window mode:
			_ASConfig->bFullScreen = FALSE;
			ChangeDisplayMode();
		}
		OpenHelp();
		return 0;
	}
	if(ASKeyFirst[DIK_F12])
	{ // Open the configuration menu:
		SendMessage(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), WM_COMMAND, ID_OPTIONS_CONFIG, 0);
	}

	AnimateFont();

	// The select keys:
	if(!bShowCredits)
	{
		if(!bGetPlayerName && !bGetNewKey)
		{
			if(ASKeyFirst[DIK_UP])
				byGameMenuSelected--;
			if(ASKeyFirst[DIK_DOWN])
				byGameMenuSelected++;
		}
		switch(byGameMenuMenu)
		{
			case 0: // Main menu:
				if(byGameMenuSelected < 0)
					byGameMenuSelected = 7;
				else
					if(byGameMenuSelected >= 8)
						byGameMenuSelected = 0;
				switch(byGameMenuSelected)
				{
					case 0: MenuPoint[0].bSelected = TRUE; break;
					case 1: MenuPoint[1].bSelected = TRUE; break;
					case 2: MenuPoint[2].bSelected = TRUE; break;
					case 3: MenuPoint[3].bSelected = TRUE; break;
					case 4: MenuPoint[4].bSelected = TRUE; break;
					case 5: MenuPoint[5].bSelected = TRUE; break;
					case 6: MenuPoint[6].bSelected = TRUE; break;
					case 7: MenuPoint[7].bSelected = TRUE; break;
				}
				if(ASKeyFirst[DIK_ESCAPE])
					_AS->SetShutDown(TRUE);
				if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
				{ // Check what the player has selected:
					switch(byGameMenuSelected)
					{
						case 0: // New game:
							EnumerateCampaigns();
							if(!iCampaigns)
							{ // There is no campaign!!
								_AS->WriteLogMessage("There is no campaign!");
								ShowSmallMessage(M_ThereIsNoCampaign, 3000);
								break;
							}
							byGameMenuMenu = 2;
							byGameMenuSelected = 0;
						break;

						case 1: // Continue game:
							EnumeratePlayerIDs();
							if(!iPlayerIDs)
							{ // There is no player ID!!
								_AS->WriteLogMessage("There is no player ID!");
								ShowSmallMessage(M_ThereIsNoPlayerID, 3000);
								break;
							}
							byGameMenuMenu = 3;
							byGameMenuSelected = 0;
						break;

						case 2: // Single level:
							EnumerateSingleLevels();
							if(!iSingleLevels)
							{ // There is no single level!!
								_AS->WriteLogMessage("There is no single level!");
								ShowSmallMessage(M_ThereIsNoSingleLevel, 3000);
								break;
							}
							byGameMenuMenu = 1;
							byGameMenuSelected = 0;
						break;

						case 3: // Options:
							byGameMenuMenu = 6;
							byGameMenuSelected = 0;
						break;

						case 4: // Editor:
//							ShowSmallMessage(M_OnlyInFullVersion, 4000);
							_AS->SetNextModule(MODULE_EDITOR);
						break;

						case 5: // Help:
							goto Help;

						case 6:
							bShowCredits = TRUE;
							iCreditsTextY = -10;
						break;

						case 7: // Quit:
							_AS->SetShutDown(TRUE);
						break;
					}
				}
			break;

			case 1: // Select a single level:
				if(byGameMenuSelected < 0)
					byGameMenuSelected = iSingleLevels-1;
				else
					if(byGameMenuSelected >= iSingleLevels)
						byGameMenuSelected = 0;
				if(ASKeyFirst[DIK_ESCAPE])
				{
					byGameMenuSelected = 0;
					byGameMenuMenu = 0;
					break;
				}
				if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
				{ // Check what the player has selected:
					// Start the selected single level:
					bInGameMenu = FALSE;
					bSingleLevel = TRUE;
					CurrentCampaign.iLevels = 1;
					strcpy(bySelectedSingleLevel, pbySingleLevels[byGameMenuSelected]);
					CreateNewPlayerInfo(&PlayerIdentity, &CurrentCampaign);
				}
			break;

			case 2: // Select campaign:
				if(byGameMenuSelected < 0)
					byGameMenuSelected = iCampaigns-1;
				else
					if(byGameMenuSelected >= iCampaigns)
						byGameMenuSelected = 0;
				if(ASKeyFirst[DIK_ESCAPE])
				{
					byGameMenuSelected = 0;
					byGameMenuMenu = 0;
					break;
				}
				if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
				{ // Check what the player has selected:
					// Load the campaign:
					sprintf(byTemp, "%s%s\\%s\\%s.cam", _AS->pbyProgramPath, _AS->pbyCampaignsFile, pbyCampaign[byGameMenuSelected],
														pbyCampaign[byGameMenuSelected]);
					if(LoadCampaign(&CurrentCampaign, byTemp))
					{
						_AS->WriteLogMessage("Couldn't open %s!", byTemp);
						break;
					}
					// Go sure that there is the right campaign name:
					strcpy(CurrentCampaign.byName, pbyCampaign[byGameMenuSelected]);
					byGameMenuMenu = 5;
					byGameMenuSelected = 0;
					EnumeratePlayerIDs();
					bGetPlayerName = FALSE;
				}
			break;

			case 3: // Select player ID: (for continue game)
				if(byGameMenuSelected < 0)
					byGameMenuSelected = iPlayerIDs-1;
				else
					if(byGameMenuSelected >= iPlayerIDs)
						byGameMenuSelected = 0;
				if(ASKeyFirst[DIK_ESCAPE])
				{
					byGameMenuSelected = 0;
					byGameMenuMenu = 0;
					break;
				}
				CheckDeletePlayerID();
				if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
				{ // Check what the player has selected:
					// Load the player ID:
					DestroyCampaign(&CurrentCampaign);
					LoadPlayerIdentity(pbyPlayerID[byGameMenuSelected], &PlayerIdentity, &CurrentCampaign);
					sprintf(byTemp, "%s%s\\%s\\%s.cam", _AS->pbyProgramPath, _AS->pbyCampaignsFile, PlayerIdentity.byCampaignName, PlayerIdentity.byCampaignName);
					if(LoadCampaign(&CurrentCampaign, byTemp))
					{
						_AS->WriteLogMessage("Couldn't open %s!", byTemp);
						break;
					}
					// Setup now the final player identity:
					LoadPlayerIdentity(pbyPlayerID[byGameMenuSelected], &PlayerIdentity, &CurrentCampaign);
					byGameMenuSelected = (char) PlayerIdentity.iFinishedLevels;
					if(byGameMenuSelected >= CurrentCampaign.iLevels)
						byGameMenuSelected--;
					byGameMenuMenu = 4;
				}
			break;

			case 4: // Select level of the selected campaign:
				if(byGameMenuSelected < 0)
					byGameMenuSelected = (char) PlayerIdentity.iFinishedLevels;
				else
					if(byGameMenuSelected >= PlayerIdentity.iFinishedLevels+1 ||
					   byGameMenuSelected >= CurrentCampaign.iLevels)
						byGameMenuSelected = 0;
				if(ASKeyFirst[DIK_ESCAPE])
				{
					byGameMenuSelected = 0;
					byGameMenuMenu = 0;
					byGameMenuMenu = 3;
					break;
				}
				if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
				{ // Check what the player has selected:
					// Start the selected level:
					PlayerIdentity.iSelectedLevel = byGameMenuSelected+1;
					bInGameMenu = FALSE;
					bSingleLevel = FALSE;
				}
			break;

			case 5: // Select player ID or create a new one:
				if(byGameMenuSelected < 0)
					byGameMenuSelected = (char) iPlayerIDs;
				else
					if(byGameMenuSelected >= iPlayerIDs+1)
						byGameMenuSelected = 0;
				if(bGetPlayerName)
				{
					if(strlen(byGetPlayerName) < PLAYER_NAME_LENGTH-1)
					{
						for(i = 0; i < 256; i++)
						{
							if(ASKeyFirst[i])
							{
								ConvertScancodeToASCII(i, &iKey);
								sprintf(byGetPlayerName, "%s%c", byGetPlayerName, iKey);
							}
						}
					}
					if(ASKeyFirst[DIK_BACK] && strlen(byGetPlayerName) > 1)
						byGetPlayerName[strlen(byGetPlayerName)-2] = '\0';
					if(ASKeyFirst[DIK_ESCAPE])
						bGetPlayerName = FALSE;
					if(ASKeyFirst[DIK_RETURN])
					{ // Get the player name:
						bGetPlayerName = FALSE;
						if(byGetPlayerName[0] == 13)
							strcpy(byGetPlayerName, "Noname");
						else
							byGetPlayerName[strlen(byGetPlayerName)-1] = '\0';
						// Create a new player identity:
						CreateNewPlayerInfo(&PlayerIdentity, &CurrentCampaign);
						strcpy(PlayerIdentity.byName, byGetPlayerName);
						sprintf(byTemp, "%s%s\\%s\\", _AS->pbyProgramPath, _AS->pbyIdentityFile, PlayerIdentity.byName);
						ASRemoveDirectory(byTemp);
						SavePlayerIdentity(&PlayerIdentity, &CurrentCampaign);
						EnumeratePlayerIDs();
						for(byGameMenuSelected = 0;; byGameMenuSelected++)
						{
							if(!strcmp(PlayerIdentity.byName, byGetPlayerName))
								break;
						}
						goto StartSelectedCampaign;
					}
				}
				else
				{
					if(ASKeyFirst[DIK_ESCAPE])
					{
						byGameMenuSelected = 0;
						byGameMenuMenu = 2;
						bGetPlayerName = FALSE;
						break;
					}
					CheckDeletePlayerID();
					if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
					{ // Check what the player has selected:
						// Load the player ID:
						if(iPlayerIDs <= byGameMenuSelected)
						{ // Create a new player ID:
							bGetPlayerName = TRUE;
							strcpy(byGetPlayerName, "");
							break;
						}
						else
						{ // Use a old player ID:
							LoadPlayerIdentity(pbyPlayerID[byGameMenuSelected], &PlayerIdentity, &CurrentCampaign);
							strcpy(byGetPlayerName, PlayerIdentity.byName);
							DestroyPlayerInfo(&PlayerIdentity);
							CreateNewPlayerInfo(&PlayerIdentity, &CurrentCampaign);
							strcpy(PlayerIdentity.byName, byGetPlayerName);
							sprintf(byTemp, "%s%s\\%s\\", _AS->pbyProgramPath, _AS->pbyIdentityFile, PlayerIdentity.byName);
							ASRemoveDirectory(byTemp);
							SavePlayerIdentity(&PlayerIdentity, &CurrentCampaign);
						}
					StartSelectedCampaign:
						// Start the selected campaign:
						bInGameMenu = FALSE;
						bSingleLevel = FALSE;
					}
				}
			break;

			case 8: // Are you sure question:
				if(byGameMenuSelected < 0)
					byGameMenuSelected = 1;
				else
					if(byGameMenuSelected >= 2)
						byGameMenuSelected = 0;
				switch(byGameMenuSelected)
				{
					case 0: MenuPoint[8].bSelected = TRUE; break;
					case 1: MenuPoint[9].bSelected = TRUE; break;
				}
				if(ASKeyFirst[DIK_ESCAPE])
				{
					bAreYouSureQuestionAnswer = FALSE;
					byGameMenuSelected = 0;
					byGameMenuMenu = byLastGameMenuMenu;
				}
				if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
				{
					if(!byGameMenuSelected)
						bAreYouSureQuestionAnswer = TRUE;
					else
						bAreYouSureQuestionAnswer = FALSE;
					byGameMenuSelected = 0;
					byGameMenuMenu = byLastGameMenuMenu;
				}
			break;

			default:
				CheckOptionMenu();
			break;
		}
	}
	else
	{
		if(iCreditsTextY >= (iASCreditsTexts+20)*25)
			bShowCredits = FALSE;
	}
	if(g_lNow-lPressNewKeyTimer > 500)
	{
		lPressNewKeyTimer = g_lNow;
		bPressNewKeyText = !bPressNewKeyText;
	}
	// Animate the background:
	if(g_lNow-lGameMenuBackgroundAniTimer > 70)
	{ // Go to the next animation step:
		lGameMenuBackgroundAniTimer = g_lNow;
		iGameMenuBackgroundAniStep++;
		if(iGameMenuBackgroundAniStep >= 32)
			iGameMenuBackgroundAniStep = 0;
	}
	// Change the color of the background:
	if((g_lNow-lBackFlashTime) > lBackFlashTimeDelay)
	{
		lBackFlashTime = g_lNow;
		lBackFlashTimeDelay = rand() % 500+300;
		fLastBackFlash = fBackFlash;
		fBackFlash = (float) (rand() % 50)/100.0f;
		fBackFlashDelta = fBackFlash-fLastBackFlash;
	}
	fDelta = ((float) (g_lNow-lBackFlashTime+1)/lBackFlashTimeDelay);
	if(fDelta < 0.0f)
		fDelta = -fDelta;
	if(fBackFlash > fLastBackFlash)
		fCurrentBackFlash = (float) fLastBackFlash+fBackFlashDelta*fDelta;
	else
		fCurrentBackFlash = (float) fLastBackFlash+fBackFlashDelta*fDelta;
	return 0;
} // end GameMenuCheck()

void CheckOptionMenu(void)
{ // begin CheckOptionMenu()
	short i;

	if(g_lNow-lPressNewKeyTimer > 500)
	{
		lPressNewKeyTimer = g_lNow;
		bPressNewKeyText = !bPressNewKeyText;
	}
	switch(byGameMenuMenu)
	{
		case 6: // Options:
			if(byGameMenuSelected < 0)
				byGameMenuSelected = 1;
			else
				if(byGameMenuSelected >= 2)
					byGameMenuSelected = 0;
			switch(byGameMenuSelected)
			{
				case 0: MenuPoint[10].bSelected = TRUE; break;
				case 1: MenuPoint[11].bSelected = TRUE; break;
			}
			if(ASKeyFirst[DIK_ESCAPE])
			{
				byGameMenuSelected = 0;
				byGameMenuMenu = 0;
				break;
			}
			if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
			{ // Check what the player has selected:
				ASKeyFirst[DIK_SPACE] = ASKeyFirst[DIK_RETURN] = FALSE;
				switch(byGameMenuSelected)
				{
					case 0: // Setup keys
						byGameMenuSelected = 0;
						byGameMenuMenu = 7;
						bGetNewKey = FALSE;
					break;

					case 1: // Other options
						SendMessage(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), WM_COMMAND, ID_OPTIONS_CONFIG, 0);
					break;
				}
			}
		break;

		case 7: // Setup keys:
			if(byGameMenuSelected < 0)
				byGameMenuSelected = 16;
			else
				if(byGameMenuSelected >= 17)
					byGameMenuSelected = 0;
			if(ASKeyFirst[DIK_ESCAPE])
			{
				if(bGetNewKey)
					bGetNewKey = FALSE;
				else
				{
					byGameMenuSelected = 0;
					byGameMenuMenu = 6;
				}
				break;
			}
			switch(byGameMenuSelected)
			{
				case 0: MenuPoint[12].bSelected = TRUE; break;
				case 1: MenuPoint[13].bSelected = TRUE; break;
				case 2: MenuPoint[14].bSelected = TRUE; break;
				case 3: MenuPoint[15].bSelected = TRUE; break;
				case 4: MenuPoint[16].bSelected = TRUE; break;
				case 5: MenuPoint[17].bSelected = TRUE; break;
				case 6: MenuPoint[18].bSelected = TRUE; break;
				case 7: MenuPoint[19].bSelected = TRUE; break;
				case 8: MenuPoint[20].bSelected = TRUE; break;
				case 9: MenuPoint[21].bSelected = TRUE; break;
				case 10: MenuPoint[22].bSelected = TRUE; break;
				case 11: MenuPoint[23].bSelected = TRUE; break;
				case 12: MenuPoint[24].bSelected = TRUE; break;
				case 13: MenuPoint[25].bSelected = TRUE; break;
				case 14: MenuPoint[26].bSelected = TRUE; break;
				case 15: MenuPoint[27].bSelected = TRUE; break;
				case 16: MenuPoint[28].bSelected = TRUE; break;
			}
			if(bGetNewKey)
			{
				for(i = 0; i < 256; i++)
				{
					if(!ASKeyFirst[i])
						continue;
					// Set the new key:
					switch(byGameMenuSelected)
					{
						case 0: _ASConfig->iLeftKey[0] = i; break;
						case 1: _ASConfig->iRightKey[0] = i; break;
						case 2: _ASConfig->iUpKey[0] = i; break;
						case 3: _ASConfig->iDownKey[0] = i; break;
						case 4: _ASConfig->iShotKey[0] = i; break;
						case 5: _ASConfig->iThrowKey[0] = i; break;
						case 6: _ASConfig->iPullKey[0] = i; break;
						case 7: _ASConfig->iSuicideKey[0] = i; break;
						case 8: _ASConfig->iJumpKey[0] = i; break;
						case 9: _ASConfig->iChangePerspectiveKey[0] = i; break;
						case 10: _ASConfig->iBackCameraKey[0] = i; break;
						case 11: _ASConfig->iTiltCameraKey[0] = i; break;
						case 12: _ASConfig->iStandartViewKey[0] = i; break;
						case 13: _ASConfig->iPauseKey[0] = i; break;
						case 14: _ASConfig->iLoadAutosaveKey[0] = i; break;
						case 15: _ASConfig->iLevelRestartKey[0] = i; break;
					}
					bGetNewKey = FALSE;
					_ASConfig->Check();
				}
			}
			else
			{
				if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
				{ // Check what the player has selected:
					if(byGameMenuSelected == 16)
					{ // Set all key to standart:
						_ASConfig->iLeftKey[0] = STANDART_LEFT_KEY;
						_ASConfig->iRightKey[0] = STANDART_RIGHT_KEY;
						_ASConfig->iUpKey[0] = STANDART_UP_KEY;
						_ASConfig->iDownKey[0] = STANDART_DOWN_KEY;
						_ASConfig->iShotKey[0] = STANDART_SHOT_KEY;
						_ASConfig->iThrowKey[0] = STANDART_THROW_KEY;
						_ASConfig->iPullKey[0] = STANDART_PULL_KEY;
						_ASConfig->iSuicideKey[0] = STANDART_SUICIDE_KEY;
						_ASConfig->iJumpKey[0] = STANDART_JUMP_KEY;
						_ASConfig->iLevelRestartKey[0] = STANDART_LEVEL_RESTART_KEY;
						_ASConfig->iChangePerspectiveKey[0] = STANDART_CHANGE_PERSPECTIVE_KEY;
						_ASConfig->iBackCameraKey[0] = STANDART_BACK_CAMERA_KEY;
						_ASConfig->iTiltCameraKey[0] = STANDART_TILT_CAMERA_KEY;
						_ASConfig->iPauseKey[0] = STANDART_PAUSE_KEY;
						_ASConfig->iStandartViewKey[0] = STANDART_STANDART_VIEW_KEY;
						_ASConfig->iLoadAutosaveKey[0] = STANDART_LOAD_AUTOSAVE_KEY;
						_ASConfig->Check();
					}
					else // Get the new key:
						bGetNewKey = TRUE;
				}
			}
		break;
	}
} // end CheckOptionMenu()

void CheckDeletePlayerID(void)
{ // begin CheckDeletePlayerID()
	char byTemp[256];

	if(!iPlayerIDs)
		return;
	if(ASKeyFirst[DIK_DELETE])
	{ // Delete the selected ID:
		byLastGameMenuMenu = byGameMenuMenu;
		byGameMenuMenu = 8;
		byGameMenuSelectedTemp = byGameMenuSelected;
		byGameMenuSelected = 0;
		bAreYouSureQuestion = TRUE;
		bAreYouSureQuestionAnswer = FALSE;
		return;
	}
	if(bAreYouSureQuestion)
	{
		bAreYouSureQuestion = FALSE;
		if(bAreYouSureQuestionAnswer)
		{ // Delete this player ID:
			byGameMenuSelected = byGameMenuSelectedTemp;
			_AS->WriteLogMessage("Delete player ID: %s", pbyPlayerID[byGameMenuSelected]);
			sprintf(byTemp, "%s%s\\%s.id", _AS->pbyProgramPath, _AS->pbyIdentityFile, pbyPlayerID[byGameMenuSelected]);
			remove(byTemp);
			sprintf(byTemp, "%s%s\\%s\\", _AS->pbyProgramPath, _AS->pbyIdentityFile, pbyPlayerID[byGameMenuSelected]);
			ASRemoveDirectory(byTemp);
			EnumeratePlayerIDs();
			if(!iPlayerIDs)
			{
				if(byGameMenuMenu != 5)
					byGameMenuMenu = 0;
			}
			byGameMenuSelected = 0;
		}
	}
} // end CheckDeletePlayerID()

void AnimateFont(void)
{ // begin AnimateFont()
	short i, i2;

	if(!bSelectedSize)
	{
		fSelectedSize += (float) g_lDeltatime/3000;
		if(fSelectedSize > 1.0f)
		{
			fSelectedSize = 1.0f;
			bSelectedSize = TRUE;
		}
	}
	else
	{
		fSelectedSize -= (float) g_lDeltatime/3000;
		if(fSelectedSize < 0.8f)
		{
			fSelectedSize = 0.8f;
			bSelectedSize = FALSE;
		}
	}

	if(!bShowCredits)
	{
		for(i = 0; i < 4; i++)
			for(i2 = 0; i2 < 2; i2++)
			{
				fFontAni[i][i2] += fFontAniV[i][i2]*((float) g_lDeltatime/800);
				if(fFontAniLast[i][i2] >= fFontAniT[i][i2])
				{
					fFontAniV[i][i2] -= ((float) g_lDeltatime/200);
					if(fFontAniV[i][i2] < -1.2f)
						fFontAniV[i][i2] = -1.2f;
					if(fFontAni[i][i2] <= fFontAniT[i][i2])
					{
						fFontAniLast[i][i2] = fFontAni[i][i2];
						if(!(rand() % 2))
							fFontAniT[i][i2] = ((float) (rand() % 10)/8);
						else
							fFontAniT[i][i2] = -((float) (rand() % 10)/8);
					}
				}
				if(fFontAniLast[i][i2] < fFontAniT[i][i2])
				{
					fFontAniV[i][i2] += ((float) g_lDeltatime/200);
					if(fFontAniV[i][i2] > 1.2f)
						fFontAniV[i][i2] = 1.2f;
					if(fFontAni[i][i2] >= fFontAniT[i][i2])
					{
						fFontAniLast[i][i2] = fFontAni[i][i2];
						if(!(rand() % 2))
							fFontAniT[i][i2] = ((float) (rand() % 10)/8);
						else
							fFontAniT[i][i2] = -((float) (rand() % 10)/8);
					}
				}
			}
	}
	else
	{
		for(i = 0; i < 4; i++)
			for(i2 = 0; i2 < 2; i2++)
			{
				fFontAni[i][i2] += fFontAniV[i][i2]*((float) g_lDeltatime/800);
				if(fFontAniLast[i][i2] >= fFontAniT[i][i2])
				{
					fFontAniV[i][i2] -= ((float) g_lDeltatime/200);
					if(fFontAniV[i][i2] < -2.0f)
						fFontAniV[i][i2] = -2.0f;
					if(fFontAni[i][i2] <= fFontAniT[i][i2])
					{
						fFontAniLast[i][i2] = fFontAni[i][i2];
						if(!(rand() % 2))
							fFontAniT[i][i2] = ((float) (rand() % 10)/2);
						else
							fFontAniT[i][i2] = -((float) (rand() % 10)/2);
					}
				}
				if(fFontAniLast[i][i2] < fFontAniT[i][i2])
				{
					fFontAniV[i][i2] += ((float) g_lDeltatime/200);
					if(fFontAniV[i][i2] > 2.0f)
						fFontAniV[i][i2] = 2.0f;
					if(fFontAni[i][i2] >= fFontAniT[i][i2])
					{
						fFontAniLast[i][i2] = fFontAni[i][i2];
						if(!(rand() % 2))
							fFontAniT[i][i2] = ((float) (rand() % 10)/2);
						else
							fFontAniT[i][i2] = -((float) (rand() % 10)/2);
					}
				}
			}
	}
} // end AnimateFont()

void EnumerateSingleLevels(void)
{ // begin EnumerateSingleLevels()
	WIN32_FIND_DATA FindFileData;
	char byTemp[256], byResult;
	HANDLE Find;
	                   
	_AS->WriteLogMessage("Enumerate single player levels");
	DestroySingleLevelList();
	sprintf(byTemp, "%s%s\\*.lev", _AS->pbyProgramPath, _AS->pbySingleLevelsFile);
	Find = FindFirstFile(byTemp, &FindFileData);
	for(;;)
	{	// We found a single level:
		// Check if it is an single level:
		sprintf(byTemp, "%s%s\\%s", _AS->pbyProgramPath, _AS->pbySingleLevelsFile, FindFileData.cFileName);
		byResult = GetLevelSingle(byTemp);
		if(byResult != 0 && byResult != -1)
		{
			iSingleLevels++;
			pbySingleLevels = (char **) realloc(pbySingleLevels, sizeof(char **)*iSingleLevels);
			pbySingleLevels[iSingleLevels-1] = new char[strlen(FindFileData.cFileName)+1];
			strcpy(pbySingleLevels[iSingleLevels-1], FindFileData.cFileName);
		}
		if(!FindNextFile(Find, &FindFileData))
			break;
	}
	FindClose(Find);
} // end EnumerateSingleLevels()

void DestroySingleLevelList(void)
{ // begin DestroySingleLevelList()
	short i;

	if(pbySingleLevels)
	{
		for(i = 0; i < iSingleLevels; i++)
			free(pbySingleLevels[i]);
		free(pbySingleLevels);
		pbySingleLevels = NULL;
	}
	iSingleLevels = 0;
} // end DestroySingleLevelList()

void EnumerateCampaigns(void)
{ // begin EnumerateCampaigns()
	WIN32_FIND_DATA FindFileData;
	char byTemp[256];
	HANDLE Find;
	                   
	_AS->WriteLogMessage("Enumerate campaigns");
	DestroyCampaignsList();
	sprintf(byTemp, "%s%s\\*.*", _AS->pbyProgramPath, _AS->pbyCampaignsFile);
	Find = FindFirstFile(byTemp, &FindFileData);
	for(;;)
	{	
		if(FindFileData.cFileName[0] != '.' && FindFileData.dwFileAttributes == FILE_ATTRIBUTE_DIRECTORY)
		{ // We found a campaigns:
			iCampaigns++;
			pbyCampaign = (char **) realloc(pbyCampaign, sizeof(char **)*iCampaigns);
			pbyCampaign[iCampaigns-1] = new char[strlen(FindFileData.cFileName)+1];
			strcpy(pbyCampaign[iCampaigns-1], FindFileData.cFileName);
		}
		if(!FindNextFile(Find, &FindFileData))
			break;
	}
	FindClose(Find);
} // end EnumerateCampaigns()

void DestroyCampaignsList(void)
{ // begin DestroyCampaignsList()
	short i;

	if(pbyCampaign)
	{
		for(i = 0; i < iCampaigns; i++)
			free(pbyCampaign[i]);
		free(pbyCampaign);
		pbyCampaign = NULL;
	}
	iCampaigns = 0;
} // end DestroyCampaignsList()

void EnumeratePlayerIDs(void)
{ // begin EnumeratePlayerIDs()
	WIN32_FIND_DATA FindFileData;
	char byTemp[256];
	HANDLE Find;
	FILE *fp;
	                   
	_AS->WriteLogMessage("Enumerate player IDs");
	DestroyPlayerIDList();
	sprintf(byTemp, "%s%s\\*.id", _AS->pbyProgramPath, _AS->pbyIdentityFile);
	Find = FindFirstFile(byTemp, &FindFileData);
	if(Find == INVALID_HANDLE_VALUE)
		return;
	for(;;)
	{	// We found a player ID:
		iPlayerIDs++;
		pbyPlayerID = (char **) realloc(pbyPlayerID, sizeof(char **)*iPlayerIDs);
		sprintf(byTemp, "%s%s\\%s", _AS->pbyProgramPath, _AS->pbyIdentityFile, FindFileData.cFileName);
		fp = fopen(byTemp, "rb");
		if(fp)
		{
			fread(&byTemp, sizeof(char)*PLAYER_NAME_LENGTH, 1, fp);
			fclose(fp);
		}
		pbyPlayerID[iPlayerIDs-1] = new char[strlen(byTemp)+1];
		strcpy(pbyPlayerID[iPlayerIDs-1], byTemp);
		if(!FindNextFile(Find, &FindFileData))
			break;
	}
	FindClose(Find);
} // end EnumeratePlayerIDs()

void DestroyPlayerIDList(void)
{ // begin DestroyPlayerIDsList()
	short i;

	if(pbyPlayerID)
	{
		for(i = 0; i < iPlayerIDs; i++)
			free(pbyPlayerID[i]);
		free(pbyPlayerID);
		pbyPlayerID = NULL;
	}
	iPlayerIDs = 0;
} // end DestroyPlayerIDList()


void InitMenuPoints(void)
{ // begin InitMenuPoints()
	short i, i2;
	
	for(i = 0; i < MENU_POINTS; i++)
	{
		MenuPoint[i].fSize = 1.0f;
		for(i2 = 0; i2 < 3; i2++)
			MenuPoint[i].fColor[i2] = 1.0f;
	}
} // end InitMenuPoints()

void CheckMenuPoints(void)
{ // begin CheckMenuPoints()
	short i, i2;

	for(i = 0; i < MENU_POINTS; i++)
	{
		if(MenuPoint[i].bSelected)
		{
			for(i2 = 1; i2 < 3; i2++)
			{
				if(MenuPoint[i].fColor[i2] > 0.0f)
				{
					MenuPoint[i].fColor[i2] -= (float) g_lDeltatime/200;
					if(MenuPoint[i].fColor[i2] < 0.0f)
						MenuPoint[i].fColor[i2] = 0.0f;
				}
			}
			if(!MenuPoint[i].bSize)
			{
				MenuPoint[i].fSize += (float) g_lDeltatime/3000;
				if(MenuPoint[i].fSize > 1.0f)
				{
					MenuPoint[i].fSize = 1.0f;
					MenuPoint[i].bSize = TRUE;
				}
			}
			else
			{
				MenuPoint[i].fSize -= (float) g_lDeltatime/3000;
				if(MenuPoint[i].fSize < 0.8f)
				{
					MenuPoint[i].fSize = 0.8f;
					MenuPoint[i].bSize = FALSE;
				}
			}
		}
		else
		{
			for(i2 = 1; i2 < 3; i2++)
			{
				if(MenuPoint[i].fColor[i2] < 1.0f)
				{
					MenuPoint[i].fColor[i2] += (float) g_lDeltatime/200;
					if(MenuPoint[i].fColor[i2] > 1.0f)
						MenuPoint[i].fColor[i2] = 1.0f;
				}
			}
			if(MenuPoint[i].fSize > 1.0f)
			{
				MenuPoint[i].fSize -= (float) g_lDeltatime/3000;
				if(MenuPoint[i].fSize < 1.0f)
					MenuPoint[i].fSize = 1.0f;
			}
			if(MenuPoint[i].fSize < 1.0f)
			{
				MenuPoint[i].fSize += (float) g_lDeltatime/3000;
				if(MenuPoint[i].fSize > 1.0f)
					MenuPoint[i].fSize = 1.0f;
			}
		}
		MenuPoint[i].bSelected = FALSE;
	}
} // end CheckMenuPoints() 

/*==========================================================================*/




/*==========================================================================*/
/*==========================================================================*/
/* The orginal galaxy code was taken from:									*/
/*																			*/
/*  Galaxy Demo                                                             */
/*  Author: Roman Podobedov                                                 */
/*  Email: romka@ut.ee                                                      */
/*  WEB: http://romka.demonews.com                                          */
/*==========================================================================*/

#define GALAXY_P 200
#define GALAXY_P1 800

typedef struct GALAXY_POINT
{
	float x, y, z;
	float r, g, b;
	float speed;
} GALAXY_POINT;

GALAXY_POINT p1[GALAXY_P];
GALAXY_POINT p2[GALAXY_P];
GALAXY_POINT p3[GALAXY_P1];
float fGalaxyAngle = 0.0f;


void InitGalaxy(void)
{ // begin InitGalaxy()
	float alpha, x, z, r, theta, a, b;
	short i, j;
	
	_AS->WriteLogMessage("Init galaxy");
	// Calculate central level (very condensed particles)
	for(j = 0; j < 4; j++)
	{
		a = 0.9f;
		b = 0.31f;
		theta = 0;
		for(i = 0; i < 50; i++)
		{
			// Spiral formula: r = a*exp(b*theta)
			r = a*(float) exp(b*theta);
			theta += 2.5f/(float)(i+1);
			// Particle coordinates in xz plane
			x = r*(float) cos(theta);
			z = r*(float) sin(theta);
			alpha = (float) (((float) j*90)*PI)/180;
			// Particle coordinates in xz plane + rotation
			p1[j*50+i].x = x*(float) cos(alpha)-z*(float) sin(alpha);
			p1[j*50+i].z = x*(float) sin(alpha)+z*(float) cos(alpha);
			// Particle color
			x = (float) (rand() % 256)/512;
			p1[j*50+i].r = x;
			p1[j*50+i].g = x;
			p1[j*50+i].b = x;
		}
	}
	// Next level of particles: normal condensation
	for(j = 0; j < 4; j++)
	{
		a = 1.9f;
		b = 0.3f;
		theta = 0;
		for(i = 0; i < 50; i++)
		{
			// r = a*exp(b*theta)
			r = a*(float) exp(b*theta);
			theta += 2.3f/(float) (i+1);
			x = r*(float) cos(theta);
			z = r*(float) sin(theta);
			alpha = (float) (((float) j*90+(float) (rand() % 180))*PI)/180;
			// Particle coordinates in xyz space + rotation
			p2[j*50+i].x = x*(float) cos(alpha)-z*(float) sin(alpha);
			p2[j*50+i].y = (float) (rand() % 40)-20;
			p2[j*50+i].z = x*(float) sin(alpha)+z*(float) cos(alpha);
			// Particle color
			x = (float) (rand() % 256)/512;
			p2[j*50+i].r = 0.2f+x;
			p2[j*50+i].g = 0.2f+x;
			p2[j*50+i].b = 0.5f+x;
			// Random speed of particles
			p2[j*50+i].speed = (float) (rand() % 100)/100+0.1f;
		}
	}
	for(j = 0; j < 4; j++)
	{
		a = 1.5f;
		b = 0.3f;
		theta = 0;
		for(i = 0; i < 200; i++)
		{
			// r = a*exp(b*theta)
			r = a*(float) exp(b*theta);
			theta += 2.2f/(float) (i+1);
			x = r*(float) cos(theta);
			z = r*(float) sin(theta);
			alpha = (float) (((float)j*90+(float) (rand() % 360))*PI)/180;
			// Particle coordinates in xyz space + rotation
			p3[j*50+i].x = x*(float) cos(alpha)-z*(float) sin(alpha);
			p3[j*50+i].y = (float) (rand() % 40)-20;
			p3[j*50+i].z = x*(float) sin(alpha)+z*(float) cos(alpha);
			// Particle color
			x = (float) (rand() % 256)/256;
			p3[j*50+i].r = 0.5f+x;
			p3[j*50+i].g = 0.5f+x;
			p3[j*50+i].b = 0.2f+x;
			// Random speed of particles
			p3[j*50+i].speed = (float) (rand() % 100)/100+0.1f;
		}
	}
	_AS->WriteLogMessage("OK");
} // end InitGalaxy()

void DrawGalaxy(void)
{ // begin DrawGalaxy()
	float a, b, ang1;
	short i;

	glClear(GL_COLOR_BUFFER_BIT);
	glLoadIdentity();
	glTranslatef(10.0f, -10.0f, -100.0f);
	glRotatef(45.0f, 1.0f, 0.0f, 0.0f);

	// Rotate galaxy:
	fGalaxyAngle -= 0.001f*g_lDeltatime;

	glColor4f(1.0f, 1.0f, 1.0f, 0.5f);
	// Draw inside part of galaxy (very condensed part)
	glBindTexture(GL_TEXTURE_2D, GameTexture[11].iOpenGLID);
	for(i = 0; i < GALAXY_P; i++)
	{
		glColor3f(p1[i].r, p1[i].g, p1[i].b);
		glPushMatrix();
		a = p1[i].x*(float) cos(fGalaxyAngle*PI/180)-p1[i].z*(float) sin(fGalaxyAngle*PI/180);
		b = p1[i].x*(float) sin(fGalaxyAngle*PI/180)+p1[i].z*(float) cos(fGalaxyAngle*PI/180);
		glTranslatef(a, 0, b);
		DrawStar(6);
		glPopMatrix();
	}

	// Draw part of galaxy (normal condensed part)
	glBindTexture(GL_TEXTURE_2D, GameTexture[12].iOpenGLID);
	for(i = 0; i < GALAXY_P; i++)
	{
		glColor4f(p2[i].r-0.5f, p2[i].g-0.5f, p2[i].b-0.5f, 1);
		glPushMatrix();
		ang1 = fGalaxyAngle*p2[i].speed;
		a = p2[i].x*(float) cos(ang1*PI/180)-p2[i].z*(float) sin(ang1*PI/180);
		b = p2[i].x*(float) sin(ang1*PI/180)+p2[i].z*(float) cos(ang1*PI/180);
		glTranslatef(a, p2[i].y, b);
		DrawStar(2);
		glPopMatrix();
	}

	// Draw part of galaxy (slightly condensed part)
	for(i = 0; i < GALAXY_P1; i++)
	{
		glColor4f(p3[i].r, p3[i].g, p3[i].b, 1);
		glPushMatrix();
		ang1 = fGalaxyAngle*p3[i].speed;
		a = p3[i].x*(float) cos(ang1*PI/180)-p3[i].z*(float) sin(ang1*PI/180);
		b = p3[i].x*(float) sin(ang1*PI/180)+p3[i].z*(float) cos(ang1*PI/180);
		glTranslatef(a, p3[i].y, b);
		DrawStar(1);
		glPopMatrix();
	}

	// Draw foggly part of galaxy (simply polygon with texture)
	glColor4f(0.7f, 0.7f, 0.7f, 1.0f);
	glBindTexture(GL_TEXTURE_2D, GameMenuTexture[1].iOpenGLID);
	glPushMatrix();
	glRotatef(-fGalaxyAngle, 0, 1, 0);
	glBegin(GL_QUADS);
		glTexCoord2f(0, 0); glVertex3f(-60, 0, -60);
		glTexCoord2f(1, 0); glVertex3f(-60, 0, 60);
		glTexCoord2f(1, 1); glVertex3f(60, 0, 60);
		glTexCoord2f(0, 1); glVertex3f(60, 0, -60);
	glEnd();
	glPopMatrix();

	// Draw background:
	glPushMatrix();
	// Flip to projection mode:
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	// Set new 2D projection
	gluOrtho2D(-1, 1, -1, 1);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	// Flip back to normal 3D mode
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
	glPopMatrix();
} // end DrawGalaxy()

void DrawStar(float psize)
{ // begin DrawStar()
    // Draw polygon and particle texture mapping
	glBegin(GL_QUADS);
		glTexCoord2f(0, 0); glVertex3f(-psize, 0, -psize);
		glTexCoord2f(1, 0); glVertex3f(-psize, 0, psize);
		glTexCoord2f(1, 1); glVertex3f(psize, 0, psize);
		glTexCoord2f(0, 1); glVertex3f(psize, 0, -psize);
	glEnd();
} // end DrawStar()
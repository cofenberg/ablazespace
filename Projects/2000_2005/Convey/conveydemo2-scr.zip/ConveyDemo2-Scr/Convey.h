//-----------------------------------------------------------------------------
// File: Convey.h
//-----------------------------------------------------------------------------

#ifndef __CONVEY_H__
#define __CONVEY_H__


// Variables: *****************************************************************
extern AS_CONFIG *pConfig;
extern AS_CAMERA *pCamera;
extern BOOL bOnlyConfig, bLoader;
// Cheats:
extern BOOL bCheatsActivated,
			bInvulnerable,
			bFreeCamera,
			bAllLevels;
// Master access: (only for me!! ;-)
extern BOOL bMasterAccess;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern void ChangeDisplayMode(void);
extern void OpenCreditsDialog(HWND);
extern void SetCreditsLanguage(void);
///////////////////////////////////////////////////////////////////////////////


#endif // __CONVEY_H__
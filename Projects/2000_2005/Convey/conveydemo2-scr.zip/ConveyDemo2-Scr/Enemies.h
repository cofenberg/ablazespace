//-----------------------------------------------------------------------------
// File: Enemies.h
//-----------------------------------------------------------------------------

#ifndef __ENEMIES_H__
#define __ENEMIES_H__


// Functions: *****************************************************************
extern void DrawEnemyHiro(ACTOR *);
extern void CheckEnemyHiro(ACTOR *, BOOL);
extern void DrawEnemyMobmob(ACTOR *);
extern void CheckEnemyMobmob(ACTOR *, BOOL);
extern void DrawEnemyX3(ACTOR *);
extern void CheckEnemyX3(ACTOR *, BOOL);
///////////////////////////////////////////////////////////////////////////////


#endif // __ENEMIES_H__
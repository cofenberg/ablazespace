//-----------------------------------------------------------------------------
// File: Surface.h
//-----------------------------------------------------------------------------

#ifndef __SURFACE_H__
#define __SURFACE_H__


// Classes: *******************************************************************
typedef struct TEXTURE_POS
{
	SHORT2 iPos[4];	// The 'real' pixel position in the bitmap
	FLOAT2 fPos[4]; // The float position (1.0f is the maximum...)
	long iTimeToNext; // The time to the next animation step
	float fColor[4]; // The color (RGB) and the alpha (transparent)

} TEXTURE_POS;


typedef struct SURFACE_HEADER
{
	char byFilename[256]; // The surface filename
	char byName[256]; // The name of the surface (title)
	short iID; // The ID
	short iAniSteps; // The number of animation steps

	// Attributes:
	BOOL bAlcove, // Is this surface an alcove?
		 bRadioactive, // Is it radioactive?
		 bHealth, // Is it a health surface?
		 bExit, // Is this a exit?
		 bAnchor, // Is this surface an anchor?
		 bColorPainter,  // Is this an color painter?
		 bBeamer; // Is this a beamer?
	char byAnchorType; // If it's an anchor, then which type of anchor?
	char byColorPainterType; // If it's an color painter, then which type of color painter?

	BOOL bChange, // Should the surface change?
		 bChangeDestroy; // Should the field be deactivated at the change?
	char byChangeState; // If yes, then at which time? (0 = on enter  1 = on left  2 = on time)
	long lChangeTime; // The time till change
	short iChangeSurface; // If the surface should be changed to another, then is this the new surface
	float fFriction; // The friction of this surface

} SURFACE_HEADER;

typedef class SURFACE
{
	public:

		SURFACE_HEADER Header; // General information

		short iUsed; // How many times is this surface used?
		char **byTextureFilename; // The texture filenames
		TEXTURE_POS *pTexturePos; // The position in a texture (for each animation step)
		short *iTextureID; // The texture ID (for each animation step)
		AS_TEXTURE **pTexture; // A pointer to the texture (for each animation step)


		SURFACE(void);
		~SURFACE(void);
		HRESULT Load(char *);
		HRESULT Save(char *);
		void CalculateFloatTexturePos(void);
		void ChangeAnimationSteps(short);
		void Destroy(void);

} SURFACE;

///////////////////////////////////////////////////////////////////////////////
// Definitions: ***************************************************************
///////////////////////////////////////////////////////////////////////////////
// Variables: *****************************************************************
extern HWND hWndSurfaces, hWndSurface, hWndTextures, hWndObjects;
extern BOOL bSurfaceSave, bLoadTexture;
extern FLOAT3 fTextureViewPos;
extern short iCurrentTexturePos, iCurrentTextureAniStep;
extern char byFilenameTemp[MAX_PATH];
///////////////////////////////////////////////////////////////////////////////
// Functions: *****************************************************************
extern LRESULT CALLBACK SurfacesProc(HWND, UINT, WPARAM, LPARAM);
extern LRESULT CALLBACK SurfaceProc(HWND, UINT, WPARAM, LPARAM);
extern LRESULT CALLBACK TexturesProc(HWND, UINT, WPARAM, LPARAM);
///////////////////////////////////////////////////////////////////////////////


#endif // __SURFACE_H__
//-----------------------------------------------------------------------------
// File: Player.h
//-----------------------------------------------------------------------------

#ifndef __PLAYER_H__
#define __PLAYER_H__


// Definitions: ***************************************************************
#define PLAYER_NAME_LENGTH 40 // The length of the player name
// Actions:
enum
{
	ACTION_RUN_RIGHT, ACTION_RUN_DOWN, ACTION_RUN_LEFT, ACTION_RUN_UP,
	ACTION_PULL_RIGHT, ACTION_PULL_DOWN, ACTION_PULL_LEFT, ACTION_PULL_UP,
	ACTION_STAND, ACTION_WRONG, ACTION_FUNNY, ACTION_SHOT, ACTION_PLAYER_PAIN_1,
	ACTION_PLAYER_PAIN_2, ACTION_PLAYER_PAIN_3, ACTION_PLAYER_HEALTH, ACTION_PLAYER_DEATH,
	ACTION_PLAYER_CHECKPOINT, ACTION_JUMP,
};
///////////////////////////////////////////////////////////////////////////////

// Structures: ****************************************************************
// Structure which holds all what the player has and what not:
struct PLAYER_INFO
{
	int iPoints;		// The players score
	short iLives;		// The number of the players lives

	BOOL bWeapon;		// Has the player a weapon?
	short iWeaponShots; // The rest of the weapon shots

	BOOL bPullBoxes;	// Could the player pull boxes?
	short iPullBoxes;	// How many 'pulls'he have?

	BOOL bThrowBoxes;	// Could the player throw boxes?
	short iThrowBoxes;	// How many boxes could he throw?

	short iForce;		// How many boxes could the player push at the same time?
	float fForce;		// Unit force power. The player will lost the force
						// if we do something... if this is zero the force will
						// be decreased

	BOOL bGhost;		// Is the player a ghost amd could walk through things?
	long lGhostTime;	// Stores the start time of the ghost modus
	long lGhostWholeTime; // The whole ghost time

	BOOL bSpeed;		// Are we in the speed modus?
	long lSpeedTime;	// Stores the start time of the speed modus
	long lSpeedWholeTime; // The whole speed time

	BOOL bWing;			// Are we in the wing modus?
	long lWingTime;		// Stores the start time of the wing modus
	long lWingWholeTime; // The whole wing time

	BOOL bShield;		// Are we in the shield modus?
	long lShieldTime;	// Stores the start time of the shield modus
	long lShieldWholeTime; // The whole shield time
	FLOAT3 fShieldRot;  // The shield rotation

	BOOL bJump;			// Could the player jump?
	short iJump;		// How many times could he jump?

	short iCheckpointFieldID;		// The last checkpoint field
};

// Holds an player identity:
typedef struct
{
	char byName[PLAYER_NAME_LENGTH]; // The name of the player
	char byCampaignName[256]; // The name of the selected campaign
	short iFinishedLevels; // The number of finished levels (old could be selected, too)
	short iSelectedLevel; // The current selected level

	// Player info for each level of the campaign: (for replaying with the old player state)
	// (Only this stuff could be taken into another level!!)
	int *iPoints; // The points
	short *iLives; // The number of lives
	float *fPower; // The power state
} PLAYER_IDENTITY;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern ACTOR *pPlayer;
extern PLAYER_INFO PlayerInfo;
extern PLAYER_IDENTITY PlayerIdentity;
extern BOOL bXeSleep;
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern void CreateNewPlayerInfo(PLAYER_IDENTITY *, CAMPAIGN *);
extern void DestroyPlayerInfo(PLAYER_IDENTITY *);
extern void LoadPlayerIdentity(char *, PLAYER_IDENTITY *, CAMPAIGN *);
extern void SavePlayerIdentity(PLAYER_IDENTITY *, CAMPAIGN *);
extern void DrawPlayer(void);
extern BOOL CheckPlayerKeys(void);
extern void CheckPlayer(BOOL);
extern BOOL CheckPlayerPushBox(char, BOOL);
extern BOOL CheckPlayerPullBox(char);
extern BOOL CheckPlayerThrowBox(char);
extern void SetPlayerToCheckpoint(void);
extern void MakePlayerCameraRotation(char);
///////////////////////////////////////////////////////////////////////////////


#endif // __PLAYER_H__
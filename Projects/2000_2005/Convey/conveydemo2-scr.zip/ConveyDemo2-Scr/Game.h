//-----------------------------------------------------------------------------
// File: Game.h
//-----------------------------------------------------------------------------

#ifndef __AS_GAME_H__
#define __AS_GAME_H__


// Definitions: ***************************************************************
enum
{
	HEALTH_DISPLAY, LIVE_DISPLAY, PULL_DISPLAY, THROW_DISPLAY, FORCE_DISPLAY,
	WEAPON_DISPLAY, POINT_DISPLAY, GHOST_DISPLAY, SPEED_DISPLAY, TIME_DISPLAY,
	STEPS_DISPLAY, WING_DISPLAY, SHIELD_DISPLAY, JUMP_DISPLAY,
};

// The game particle systems:
enum
{
	PS_PLAYER_SPEED, PS_PLAYER_GHOST, PS_PLAYER_AUTOSAVE, PS_PLAYER_BUBBLE, PS_WATER_WAVES,
};

#define GAME_TEXTURES 26
#define WATER_TEMP_TEXTURE 4
#define MODELS 6
#define OBJECTS 15
#define DISPLAY_ACTORS 14
#define X_MOUSE_SCREEN_POS 320
#define Y_MOUSE_SCREEN_POS 240
#define SCROLL_SPEED 0.01f
#define PLAYER_TURN_SPEED 3.0f
#define PLAYER_ANIMATION_SPEED 150
#define PLAYER_MOVE_SPEED 400
#define PLAYER_THROW_SPEED 200
#define BOX_DOCKED_SIZE 0.6f
#define BOX_NORMAL_SIZE 1.0f
#define BOX_COLOR_CHANGE_SPEED 0.01f
#define OBJECT_KILLING_SPEED 1000.0f
#define OBJECTS_ANI_SPEED 100
#define OBJECT_ROTATE_SPEED 10
#define BOX_KILLING_SPEED 1000.0f
#define PLAYER_SHOT_SPEED 200.0f
#define SHOT_KILLING_SPEED 1000.0f
#define SHOT_ROTATE_SPEED 10.0f
#define OBJECT_PAINT_SPEED 100000.0f
#define PLAYER_DEAD_FLOOR_TIME 5000
#define PLAYER_PAINT_SPEED 100000.0f
#define PAUSE_BLEND_SPEED 2000
#define PAUSE_KEY_TIME 100
#define SHIELD_ROTATE_SPEED 10.0f
///////////////////////////////////////////////////////////////////////////////
#define HEALTH_OBJ_NUMBER 50  // The number of health points the player will receive if he collect a health object
#define POINT_OBJ_NUMBER 10      // The number of points the player will receive if he collect a point object
#define LIVE_OBJ_NUMBER 1	     // The number of lives the player will receive if he collect a live object
#define WEAPON_OBJ_NUMBER 10     // The number of shots the player will receive if he collect a weapon object
#define PULL_OBJ_NUMBER	10	     // The number of pulls the player will receive if he collect a pull object
#define THROW_OBJ_NUMBER 10	     // The number of throws the player will receive if he collect a throw object
#define FORCE_OBJ_NUMBER 1	     // The number of force units the player will receive if he collect a force object
#define GHOST_TIME 10000	     // The number of milliseconds of the ghost modus
#define SPEED_TIME 20000	     // The number of milliseconds of the speed modus
#define TIME_OBJ_NUMBER 20		 // The number of seconds the time will be increased/decreased
#define STEPS_OBJ_NUMBER 10		 // The number of steps the step counter will be increased/decreased
#define WING_TIME 20000			 // The number of milliseconds of the wing modus
#define SHIELD_TIME 20000		 // The number of milliseconds of the shield modus
#define JUMP_OBJ_NUMBER 10       // The number of jumps the player will receive if he collect a jump object

// Standart keys:
#define	STANDART_LEFT_KEY 203
#define	STANDART_RIGHT_KEY 205
#define	STANDART_UP_KEY 200
#define	STANDART_DOWN_KEY 208
#define	STANDART_SHOT_KEY 57
#define	STANDART_THROW_KEY 28
#define	STANDART_PULL_KEY 14
#define	STANDART_SUICIDE_KEY 15
#define	STANDART_JUMP_KEY 54
#define	STANDART_LEVEL_RESTART_KEY 87
#define	STANDART_CHANGE_PERSPECTIVE_KEY 60
#define	STANDART_BACK_CAMERA_KEY 61
#define	STANDART_TILT_CAMERA_KEY 62
#define	STANDART_PAUSE_KEY 25
#define	STANDART_STANDART_VIEW_KEY 76
#define	STANDART_LOAD_AUTOSAVE_KEY 66

// Game textures:
#define XE_TEXTURE 15
#define RAMBO_XE_TEXTURE 17
#define HIRO_TEXTURE 13
#define MOBMOB_TEXTURE 4 
#define X3_TEXTURE 5
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern AS_PARTICLE_MANAGER ParticleManager;
extern int GAME_WINDOW_ID;
extern short iLevelCompleteSpeed, iPauseBlendSpeed;
extern AS_TEXTURE GameTexture[GAME_TEXTURES];
extern AS_TEXTURE GameTitleTexture[4];
// The current level:
extern char byCurrentLevelName[256];
extern char bySelectedSingleLevel[256];
extern LEVEL *pLevel;
extern ACTOR DisplayActor[DISPLAY_ACTORS];
extern ACTOR PlayerTemp;
extern ACTOR OktaActor;
extern BOOL bSingleLevel,						// Are we playing an single level?
			bPlayerCameraView;
extern AS_MD2_MODEL *pXeModel, *pXeWeaponModel, *pDeadSmileyModel, *pOktaModel,
					*pHiroModel, *pMobmobModel, *pX3Model;
extern AS_OBJECT *pHealthObject, *pLiveObject, *pPullObject, *pThrowObject,
	   			 *pForceObject, *pWeaponObject, *pPointObject, *pGhostObject,
				 *pPlayerShot, *pTimeObject, *pStepsObject, *pSpeedObject,
				 *pWingObject, *pShieldObject, *pJumpObject, *pAirObject;

extern float fSin, fSin90, fCos, fCos90, fCameraVelocity, fPauseBlend,
	         fPauseTextBlend, fSmallMessageBlend;
extern BOOL bPause, bPauseTextBlend, bLevelPressAnyKey, bHurryUpText,
			bGameOver, bUnderWater;
extern long lGameTimer, lPauseTimer, lLevelCompleteTimer, lKeyTimer, lCameraTimerT, lHurryUpTimer,
            lCameraPauseTimerT;
extern long lGhostTimeSave, lSpeedTimeSave, lWingTimeSave, lShieldTimeSave;
extern AS_CAMERA TempCamera;
extern GLuint iGameTitleList, iWaveList, iShieldList, iHealthObjList, iLiveObjList, iPullObjList,
			  iThrowObjList, iForceObjList, iPointObjList, iGhostObjList,
			  iPlayerShotObjList, iTimeObjList, iStepsObjList, iSpeedObjList,
			  iWingObjList, iShieldObjList, iJumpObjList, iAirObjList, iParticleList;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern HRESULT Game(void);
extern void LoadGameTextures(void);
extern HRESULT GameLoop(void);
extern HRESULT GameDraw(AS_WINDOW *);
extern HRESULT GameCheck(AS_WINDOW *);
extern void UpdateAllTextures(void);
extern void LoadGameTextures(void);
extern void DestroyGameTextures(void);
extern void GenOpenGLGameTextures(void);
extern void DestroyOpenGLGameTextures(void);
extern void UpdateRenderQuality(void);
extern void CreateGameLists(void);
extern void DestroyGameLists(void);
extern void InitGameObjects(void);
extern void DestroyGameObjects(void);
extern void InitGameParticleSystems(void);
extern void DestroyGameParticleSystems(void);
extern void CreateWaterWave(float, float, float);
extern void CalculateCamersSinCos(void);
extern void CheckCameraKeys(BOOL);
extern BOOL PlayCameraScript(BOOL);
extern void SetCameraTranslation(BOOL);
extern void InitDisplayActors(void);
extern void OpenHelp(void);
extern void LoadAutosave(void);
extern void SaveAutosave(void);
extern void DestroyAutosave(void);
extern void ShowSmallMessage(char *, long);
extern void DisplaySmallMessage(AS_WINDOW *);
extern void CheckSmallMessage(void);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_GAME_H__
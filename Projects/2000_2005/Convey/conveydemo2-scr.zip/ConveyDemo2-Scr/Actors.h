//-----------------------------------------------------------------------------
// File: Actors.h
//-----------------------------------------------------------------------------

#ifndef __ACTORS_H__
#define __ACTORS_H__


// Definitions: ***************************************************************
#define MAX_ACTORS 500

// Actor types:
enum
{
	ACTOR_PLAYER, ACTOR_BOX_NORMAL, ACTOR_BOX_RED, ACTOR_BOX_GREEN, ACTOR_BOX_BLUE,
	ACTOR_HEALTH_OBJ, ACTOR_LIVE_OBJ, ACTOR_PULL_OBJ, ACTOR_THROW_OBJ,
	ACTOR_FORCE_OBJ, ACTOR_WEAPON_OBJ, ACTOR_POINT_OBJ, ACTOR_GHOST_OBJ,
	ACTOR_PLAYER_SHOT, ACTOR_TIME_OBJ, ACTOR_STEP_OBJ, ACTOR_SPEED_OBJ,
	ACTOR_WING_OBJ, ACTOR_SHIELD_OBJ, ACTOR_JUMP_OBJ, ACTOR_AIR_OBJ,
	ACTOR_ENEMY_HIRO, ACTOR_ENEMY_MOBMOB, ACTOR_ENEMY_X3,
};
///////////////////////////////////////////////////////////////////////////////

// Classes: *******************************************************************
typedef class ACTOR
{
	public:
		BOOL bActive;		// Is the actor active?
		short iID;			// The ID of this actor
		short byType;		// The actor type
		BOOL bHeavy;		// Used for example to decide if a box is heavy or not
		int iNumber;        // E.g. the number of objects the player will receive

		SHORT2 iFieldPos; // The field position in the level matrix
		FLOAT3 fFieldPos; // The position in the current field
		FLOAT3 fWorldPos; // The world pos
		FLOAT3 fLastHeightCheckWorldPos; // The last world pos were a height check was done

		char byDirection, // The actors direction
			 byAction,	  // What does the actor do?
			 byAction2;	  // What does the actor do? (for back moving actions)
		BOOL bShouldMove, // Should this actor move?
			 bMove,		  // Does the actor move at the moment?
			 bThrow,	  // Is this actor thrown?
			 bGoingDeath,
			 bGoingDeath2; // Is the actor to be going death?

		FLOAT3 fColor;
		FLOAT3 fVelocity; // The velocity: 0 = Current velocity
						  //               1 = Velocity factor (for slowing down the actor...)
		BOOL bUseFriction; // Should the friction be used??
		float fFriction; // The actors friction (e.g. from a suface)
		ACTOR *pVelocityFromActor; // Pointer to the actor which 'give's' the velocity
		float fAir; // The air of this actor. Under water this will be decreased

		char bySurfaceType;


		// E.g. for a 'fly' effect:
		FLOAT3 fPosTemp; // A position which is added to the normal
		FLOAT3 fPosTempTo; // The position which should ge gone to
		FLOAT3 fPosTempVelocity; // The velocity for the temp pos

		// Beaming:
		BOOL bBeaming;
		BOOL bBeamingStep;
		float fBeaming;

		FLOAT3 fRot;
		float fSize; // Te size of something (e.g. a box)


		short iParticleSystemID; // If this actor have an particle system then this is not -1
		float fRadius;

		DWORD lStartTime;
		char byLives;
		
		// For the animaiton;
		short byAnimation;		// The current animation depends on the current action
		short iAniStep,			// The current animation step
			  iNextAniStep,		// The next animation step
			  iMultiAniStep[6]; // The animation steps for more elements (e.g. for the box surfaces)
		DWORD dwAniTime,		// The time since the last animation step change
			  dwAniDeltaTime,	// The past ani time (for pausing the animation)
			  dwMultiAniTime[6];// The same for the multi animation
		float fModelInterpolation;
		//
		short iFieldID,	// The field ID of the current field the actor is on
			  iTempFieldID;

		float fPower,		// The power of this actor
			  fMaxPower;	// The maximum power

		DWORD lLastWaterWaveTime; // Water wave time control

		BOOL bDocked,	// Is it docked (e.g. for boxes)
			 bGoingDocked, // Is to actor to be going docked
			 bBridge,   // Is this actor a bridge?
			 bBridgeMovement;   // Does the actor at the moment fall into a gap?

		DWORD dwDockedStartTime;

		ACTOR(void);
		~ACTOR(void);

		void Init(void);

} ACTOR;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern ACTOR Actor[MAX_ACTORS];
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern ACTOR *FindFreeActor(void);
extern short SortActors(ACTOR *);
extern void ComputeActorHeight(ACTOR *, float);
extern void SetActorsLights(void);
extern void MoveActor(ACTOR *, short);
extern void UpdateAllActorFields(void);
extern void DrawEffects(void);
extern void CheckActorField(ACTOR *);
extern void DrawActors(void);
extern void CheckActors(BOOL);
extern void AnimateActorModel(ACTOR *, AS_MD2_MODEL, long, char);
extern void CheckBoxThrow(ACTOR *);
extern void DamageBox(ACTOR *);
extern void DrawBoundingBox(float [2][3], float);
extern void DisableBoxDocking(ACTOR *);
extern void DeleteActorType(ACTOR *);
extern void SetNoneFreeBox(ACTOR *);
extern BOOL ActorTurn(ACTOR *, float);
extern BOOL CheckBeaming(ACTOR *);
extern BOOL CheckBeamingProcess(ACTOR *);
///////////////////////////////////////////////////////////////////////////////


#endif // __ACTORS_H__
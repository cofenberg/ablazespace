//-----------------------------------------------------------------------------
// File: LevelDraw.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
float fPlayerTempZPos; // Used to find out if the camera has been moved (players height)
///////////////////////////////////////////////////////////////////////////////

void LEVEL::InitLevelDraw(void)
{ // begin LEVEL::InitLevelDraw()
    GLfloat	fogColor[4] = {Environment.fFogColor[R], Environment.fFogColor[G], Environment.fFogColor[B], 1.0f};
	GLfloat afLightData[4]  = {0.0f, 0.0f, 0.0f, 0.0f};
	
 	if(Environment.bFog)
	{
		glFogfv(GL_FOG_COLOR, fogColor);
		glFogf(GL_FOG_DENSITY, Environment.fFogDensity);
		glFogf(GL_FOG_START, 0.0f);
		glFogf(GL_FOG_END, 10.0f);
		glEnable(GL_FOG);
		glClearColor(Environment.fFogColor[R], Environment.fFogColor[G], Environment.fFogColor[B], 1.0f);
	}
	else
		glDisable(GL_FOG);
	afLightData[0] = 0.0f;
	afLightData[1] = 0.0f;
	afLightData[2] = 0.0f;
	afLightData[3] = 1.0f;
	glLightfv(GL_LIGHT1, GL_POSITION, afLightData);
	afLightData[0] = Environment.fColor[R];
	afLightData[1] = Environment.fColor[G];
	afLightData[2] = Environment.fColor[B];
	afLightData[3] = 1.0f;
	glLightfv(GL_LIGHT1, GL_AMBIENT, afLightData);
	glEnable(GL_LIGHT1);
} // end LEVEL::InitLevelDraw()

void LEVEL::DeInitLevelDraw(void)
{ // begin LEVEL::DeInitLevelDraw()
	GLfloat afLightData[4]  = {0.0f, 0.0f, 0.0f, 0.0f};

	glDisable(GL_FOG);
	afLightData[0] = 0.0f;
	afLightData[1] = 0.0f;
	afLightData[2] = 0.0f;
	afLightData[3] = 1.0f;
	glLightfv(GL_LIGHT1, GL_POSITION, afLightData);
	afLightData[0] = 1.0f;
	afLightData[1] = 1.0f;
	afLightData[2] = 1.0f;
	afLightData[3] = 1.0f;
	glLightfv(GL_LIGHT1, GL_AMBIENT, afLightData);
	glEnable(GL_LIGHT1);
} // end LEVEL::DeInitLevelDraw()

void LEVEL::Draw(BOOL bTempBackground)
{ // begin LEVEL::Draw()
	float fHalfFieldWidth, fHalfFieldHeight;
	short i, i2, i3, i4, iAniStep = 0;
	TEXTURE_POS *pTexturePos;
	FIELD_DECORATION *pDecorationT;
	AS_MD2_MODEL *pModelT;	
	FLOAT3 fRayDirection;
	SURFACE *pSurfaceT;
	FIELD *pFieldT;
	FLOAT3 fPointT;
	HWND hWndT;

	glLineWidth(3.0f);
	if(_ASConfig->bFrustumCulling)
	{ // Check if the camera has been changed:
		if(pCamera->fPos[X] != LevelTempCamera.fPos[X] ||
		   pCamera->fPos[Y] != LevelTempCamera.fPos[Y] ||
		   pCamera->fPos[Z] != LevelTempCamera.fPos[Z] ||
		   pCamera->fRot[X] != LevelTempCamera.fRot[X] ||
		   pCamera->fRot[Y] != LevelTempCamera.fRot[Y] ||
		   pCamera->fRot[Z] != LevelTempCamera.fRot[Z] ||
		   pPlayer->fWorldPos[Z] != fPlayerTempZPos)
		{
			for(i = 0; i < 3; i++)
			{
				LevelTempCamera.fPos[i] = pCamera->fPos[i];
				LevelTempCamera.fRot[i] = pCamera->fRot[i];
			}
			fPlayerTempZPos = pPlayer->fWorldPos[Z];
			// Check if this field is on screen:
			for(i = 0; i < Header.iFields; i++)
			{
				pFieldT = &pField[i];
				if(!CubeInFrustum(pFieldT->fBoundingBoxX, pFieldT->fBoundingBoxY,
								  pFieldT->fBoundingBoxZ, pFieldT->fBoundingBoxSize))
					pFieldT->bOnScreen = FALSE;
				else
					pFieldT->bOnScreen = TRUE;
			}
		}
	}
	else
	{
		for(i = 0; i < Header.iFields; i++)
			pField[i].bOnScreen = TRUE;
	}
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
	glDisableClientState(GL_NORMAL_ARRAY);
	if(!_ASConfig->bUseLevelVertexColor || !_ASConfig->bHightRenderQuality)
		glDisableClientState(GL_COLOR_ARRAY);
	else
	{
		glEnableClientState(GL_COLOR_ARRAY);
		if(!_ASConfig->bMultitexturing)
			glColorPointer(3, GL_FLOAT, 0, fColor);
		else
			glColorPointer(4, GL_FLOAT, 0, fColor);
	}
	glVertexPointer(3, GL_FLOAT, 0, fPoint);
	glEnable(GL_TEXTURE_2D);
	// Draw now all walls:
	glCullFace(GL_FRONT);
	// Draw all none transparent stuff:
	for(i2 = 0; i2 < Header.iTextures+1; i2++)
	{
		if(i2 < Header.iTextures)
			glBindTexture(GL_TEXTURE_2D, pTexture[i2].iOpenGLID);
		for(i = 0; i < Header.iFields; i++)
		{
			pFieldT = &pField[i];
			if((!pFieldT->bActive && !pFieldT->bWallHole) || !pFieldT->bOnScreen || (pFieldT->pBridgeActor && !pFieldT->bWallHole))
				continue;
			if(pFieldT->bNoBackfaceCulling)
				glDisable(GL_CULL_FACE);
			else
				glEnable(GL_CULL_FACE);
			if(!pFieldT->bFaceActive[FACE_FRONT] && pFieldT->bFaceActive[FACE_FLOOR] && !pFieldT->bWallHole)
			{ // Draw the floor:
				i3 = FACE_FLOOR;
				for(i4 = 0; i4 < 1+_ASConfig->bMultitexturing; i4++)
				{
					if(pFieldT->pSurface[i3][i4] && pFieldT->pSurface[i3][i4]->iTextureID[pFieldT->iCurrentAniStep[i3][i4]] == i2)
					{
						if(i4)
							glEnable(GL_BLEND);
						pTexturePos = &pFieldT->pSurface[i3][i4]->pTexturePos[pFieldT->iCurrentAniStep[i3][i4]];
						if(pTexturePos->fColor[3] != 1.0f && !i4)
							continue;
						glColor4fv(pTexturePos->fColor);
						glBegin(GL_TRIANGLES);
							glNormal3fv(pFieldT->fNormal[i3][0]);
							glTexCoord2fv(pTexturePos->fPos[(1+pFieldT->iSurfaceRotation[i3][i4]) % 4]);
							glArrayElement(pFieldT->iFace[i3][0]);
							glTexCoord2fv(pTexturePos->fPos[(2+pFieldT->iSurfaceRotation[i3][i4]) % 4]);
							glArrayElement(pFieldT->iFace[i3][1]);
							glTexCoord2fv(pTexturePos->fPos[(3+pFieldT->iSurfaceRotation[i3][i4]) % 4]);
							glArrayElement(pFieldT->iFace[i3][2]);
							
							glNormal3fv(pFieldT->fNormal[i3][1]);
							glTexCoord2fv(pTexturePos->fPos[(1+pFieldT->iSurfaceRotation[i3][i4]) % 4]);
							glArrayElement(pFieldT->iFace[i3][0]);
							glTexCoord2fv(pTexturePos->fPos[(3+pFieldT->iSurfaceRotation[i3][i4]) % 4]);
							glArrayElement(pFieldT->iFace[i3][2]);
							glTexCoord2fv(pTexturePos->fPos[(pFieldT->iSurfaceRotation[i3][i4]) % 4]);
							glArrayElement(pFieldT->iFace[i3][3]);
						glEnd();
						if(i4)
							glDisable(GL_BLEND);
					}
				}
			}
			if((pFieldT->bWall || pFieldT->bWallHole) && !pFieldT->bAlwaysWall)
			{ // Draw the sided around the field: 
				for(i4 = 0; i4 < 1+_ASConfig->bMultitexturing; i4++)
				{
					if(i4)
						glEnable(GL_BLEND);
					for(i3 = FACE_FRONT; i3 < FACE_BOTTOM+2; i3++)
					{
						if(!pFieldT->bFaceActive[i3] ||
						   !pFieldT->pSurface[i3][i4] || pFieldT->pSurface[i3][i4]->iTextureID[pFieldT->iCurrentAniStep[i3][i4]] != i2)
							continue;
						pTexturePos = &pFieldT->pSurface[i3][i4]->pTexturePos[pFieldT->iCurrentAniStep[i3][i4]];
						if(pTexturePos->fColor[3] != 1.0f && !i4)
							continue;
						glColor4fv(pTexturePos->fColor);
						glBegin(GL_TRIANGLES);
							glNormal3fv(pFieldT->fNormal[i3][0]);

							glTexCoord2fv(pTexturePos->fPos[(1+pFieldT->iSurfaceRotation[i3][i4]) % 4]);
							glArrayElement(pFieldT->iFace[i3][0]);
							glTexCoord2fv(pTexturePos->fPos[(2+pFieldT->iSurfaceRotation[i3][i4]) % 4]);
							glArrayElement(pFieldT->iFace[i3][1]);
							glTexCoord2fv(pTexturePos->fPos[(3+pFieldT->iSurfaceRotation[i3][i4]) % 4]);
							glArrayElement(pFieldT->iFace[i3][2]);
							
							glNormal3fv(pFieldT->fNormal[i3][1]);
							glTexCoord2fv(pTexturePos->fPos[(1+pFieldT->iSurfaceRotation[i3][i4]) % 4]);
							glArrayElement(pFieldT->iFace[i3][0]);
							glTexCoord2fv(pTexturePos->fPos[(3+pFieldT->iSurfaceRotation[i3][i4]) % 4]);
							glArrayElement(pFieldT->iFace[i3][2]);
							glTexCoord2fv(pTexturePos->fPos[(pFieldT->iSurfaceRotation[i3][i4]) % 4]);
							glArrayElement(pFieldT->iFace[i3][3]);
						glEnd();
					}
					if(i4)
						glDisable(GL_BLEND);
				}
			}
		}
	}
	glCullFace(GL_BACK);
	if(!_ASConfig->bUseLevelVertexColor || !_ASConfig->bHightRenderQuality)
		glEnableClientState(GL_COLOR_ARRAY);
	glEnableClientState(GL_NORMAL_ARRAY);
	glDisable(GL_TEXTURE_2D);	
	glColor3f(1.0f, 1.0f, 1.0f);
	glLineWidth(1.0f);
	fRayDirection[X] = 0.0f;
	fRayDirection[Y] = 0.0f;
	fRayDirection[Z] = 1.0f;
	g_lNow = GetTickCount();
	// Animate:
	if(!bPause || State.bLevelComplete)
	{
		for(i = 0; i < Header.iFields; i++)
		{
			pFieldT = &pField[i];
			// Beamer:
			if(pFieldT->pSurface[FACE_FLOOR][0]->Header.bBeamer)
			{
				if(pFieldT->fBeamerPower != 1.0f)
				{
					pFieldT->fBeamerPower += (float) g_lDeltatime/(pFieldT->iBeamerRegenerationSpeed+10000);
					if(pFieldT->fBeamerPower > 1.0f)
						pFieldT->fBeamerPower = 1.0f;
				}
				if(pFieldT->iBeamerParticleSystemID == -1 && pFieldT->iBeamerTarget != -1 && pFieldT->bActive)
				{
					pFieldT->iBeamerParticleSystemID = ParticleManager.AddNewSystem(PS_Beamer, 50, NULL, &GameTexture[9], NULL);
					ParticleManager.pSystem[pFieldT->iBeamerParticleSystemID].bActive = TRUE;
					ParticleManager.pSystem[pFieldT->iBeamerParticleSystemID].fStartPos[X] = pFieldT->iXField*pLevel->Header.fFieldWidth+0.5f;
					ParticleManager.pSystem[pFieldT->iBeamerParticleSystemID].fStartPos[Y] = pFieldT->iYField*pLevel->Header.fFieldHeight+0.5f;
					fPointT[X] = fPointT[Y] = 0.0f;
					fPointT[Z] = STANDART_LEVEL_Z_POS;
					pLevel->ComputeHeight(ParticleManager.pSystem[pFieldT->iBeamerParticleSystemID].fStartPos[X], 
										  ParticleManager.pSystem[pFieldT->iBeamerParticleSystemID].fStartPos[Y],
										  fRayDirection, &fPointT, FACE_FLOOR, 0.2f);
					ParticleManager.pSystem[pFieldT->iBeamerParticleSystemID].fStartPos[Z] = fPointT[Z];
					ParticleManager.pSystem[pFieldT->iBeamerParticleSystemID].iVertex = i;
				}
				else
					if(!ParticleManager.pSystem[pFieldT->iBeamerParticleSystemID].bActive)
						pFieldT->iBeamerParticleSystemID = -1;
			}
			else
				if(pFieldT->iBeamerParticleSystemID != -1 && !ParticleManager.pSystem[pFieldT->iBeamerParticleSystemID].bActive)
					pFieldT->iBeamerParticleSystemID = -1;
			//
			for(i3 = FACE_FRONT; i3 < FACE_FLOOR+1; i3++)
			{
				for(i4 = 0; i4 < 2; i4++)
				{
					if(pFieldT->iSurface[i3][i4] == -1)
						break;
					for(;;)
					{
						pSurfaceT = &pSurface[pFieldT->iSurface[i3][i4]];
						if(!pSurfaceT->Header.bChange || pSurfaceT->Header.byChangeState != 2)
							break;
						// Yes, we have to change the surface:
						if(g_lNow-pFieldT->dwLastChangeTime[i3][i4] < pSurfaceT->Header.lChangeTime)
							break;
						pFieldT->dwLastChangeTime[i3][i4] += pSurfaceT->Header.lChangeTime;
						if(pSurfaceT->Header.bChangeDestroy && i3 == FACE_FLOOR)
						{ // Destroy the field:
							if(!pField[i].pBridgeActor && !i4)
							{
								pField[i].bActive = FALSE;
								SetFieldWall(pFieldT->iXPos, pFieldT->iYPos, FALSE, TRUE);
								if(pField[i].pActor)
									UpdateAllActorFields();
							}
							pField[i].iSurface[i3][i4] = pSurfaceT->Header.iChangeSurface;
							pField[i].pSurface[i3][i4] = &pSurface[pSurfaceT->Header.iChangeSurface];
						}
						else
						{
							if(i3 == FACE_FLOOR && !i4)
							{
								pField[i].bActive = TRUE;
								if(pField[i].pActor && !pField[i].pBridgeActor)
								{ // Destroy the actor:
									if(pField[i].bWall)
									{
										pField[i].pActor->bGoingDeath = TRUE;
										pField[i].pActor->fPower = 0.0f;
									}
									if(pField[i].pActor->byType == ACTOR_BOX_NORMAL ||
									   pField[i].pActor->byType == ACTOR_BOX_RED ||
									   pField[i].pActor->byType == ACTOR_BOX_GREEN ||
									   pField[i].pActor->byType == ACTOR_BOX_BLUE)
									   pField[i].bWall = FALSE;
									pField[i].pActor = NULL;
								}
								if(!pField[i].pBridgeActor)
									SetFieldWall(pFieldT->iXPos, pFieldT->iYPos, pField[i].bWall, TRUE);
							}
							pField[i].iSurface[i3][i4] = pSurfaceT->Header.iChangeSurface;
							pField[i].pSurface[i3][i4] = &pSurface[pSurfaceT->Header.iChangeSurface];
						}
						if(pField[i].pActor)
							CheckActorField(pField[i].pActor);
					}
				}
			}
			// Animate the decorations:
			if(pFieldT->pDecoration && pFieldT->bOnScreen)
			{
				pDecorationT = pFieldT->pDecoration;
				pModelT = pDecorationModels[pDecorationT->iDecorationID].pModel;
				if(pModelT)
				{
					if(!pDecorationT->bAnimated)
					{
						pDecorationT->dwAniTime = g_lNow;
						pDecorationT->fModelInterpolation = (float) (g_lNow-pDecorationT->dwAniTime)/(float) pDecorationT->iSpeed;
					}
					else
					{
						pDecorationT->dwAniDeltaTime = g_lNow-pDecorationT->dwAniTime;
						pDecorationT->iNextAniStep = pDecorationT->iAniStep+1;
						if(pDecorationT->iNextAniStep >= pModelT->Ani.anim[pDecorationT->byAnimation].lastFrame)
							pDecorationT->iNextAniStep = pModelT->Ani.anim[pDecorationT->byAnimation].firstFrame;
						if(g_lNow-pDecorationT->dwAniTime > ((DWORD) pDecorationT->iSpeed))
						{
							pDecorationT->dwAniTime = g_lNow;
							pDecorationT->iAniStep++;
							if(pDecorationT->iAniStep >= pModelT->Ani.anim[pDecorationT->byAnimation].lastFrame)
								pDecorationT->iAniStep = pModelT->Ani.anim[pDecorationT->byAnimation].firstFrame;
						}
						pDecorationT->fModelInterpolation = (float) (g_lNow-pDecorationT->dwAniTime)/(float) pDecorationT->iSpeed;
						if(pDecorationT->iAniStep < 0 || pDecorationT->iAniStep >= pModelT->header.numFrames ||
						   pDecorationT->iNextAniStep < 0 || pDecorationT->iNextAniStep >= pModelT->header.numFrames)
						{
							pDecorationT->iAniStep = 0;
							pDecorationT->iNextAniStep = 1;
						}
					}
				}
			}
			if((!pFieldT->bActive && !pFieldT->bWallHole) || !pFieldT->bOnScreen)
				continue;
			// Animate the surface textures:
			for(i2 = 0; i2 < 6; i2++)
			{
				for(i3 = 0; i3 < 1+_ASConfig->bMultitexturing; i3++)
				{
					if(!pFieldT->bFaceActive[i2] ||
					   !pFieldT->pSurface[i2][i3])
						continue;
					if(g_lNow-pFieldT->dwLastTime[i2][i3] >
					   pFieldT->pSurface[i2][i3]->pTexturePos[pFieldT->iCurrentAniStep[i2][i3]].iTimeToNext)
					{
						pFieldT->dwLastTime[i2][i3] = g_lNow;
						// It's time for a animation frame update:
						pFieldT->iCurrentAniStep[i2][i3]++;
					}
					// Check if this is a correct animation step:
					if(pFieldT->iCurrentAniStep[i2][i3] >= pFieldT->pSurface[i2][i3]->Header.iAniSteps)
						pFieldT->iCurrentAniStep[i2][i3] = 0;
				}
			}
		}
	}
	glCullFace(GL_FRONT);
	// Draw decoration:
	for(i = 0; i < Header.iFields; i++)
	{
		pFieldT = &pField[i];
		if(pFieldT->bAlwaysWall)
			pFieldT->bWall = TRUE;
		if(!pFieldT->pDecoration)
			continue;
		pDecorationT = pFieldT->pDecoration;
		pModelT = pDecorationModels[pDecorationT->iDecorationID].pModel;
		if(!pModelT)
			continue;
		if(!CubeInFrustum(pDecorationT->fPos[X], pDecorationT->fPos[Y], pDecorationT->fPos[Z],
						  pModelT->fBoundigBoxSize*0.03f))
			continue; // Not visible!
		glPushMatrix();
		if(pDecorationT->iTexture == -1)
		{
			glDisable(GL_TEXTURE_2D);
			glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
		}
		else
		{
			glEnable(GL_TEXTURE_2D);
			glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
			glBindTexture(GL_TEXTURE_2D, pTexture[pDecorationT->iTexture].iOpenGLID);
		}
		glTranslatef(pDecorationT->fPos[X], pDecorationT->fPos[Y], pDecorationT->fPos[Z]);
		glRotatef(pDecorationT->fRot[X], 1.0f, 0.0f, 0.0f);
		glRotatef(pDecorationT->fRot[Y], 0.0f, 1.0f, 0.0f);
		glRotatef(pDecorationT->fRot[Z], 0.0f, 0.0f, 1.0f);
		glScalef(0.04f, 0.04f, 0.04f);
		glScalef(pDecorationT->fSize[0], pDecorationT->fSize[1], pDecorationT->fSize[2]);
		ASDrawMd2FrameInt(pModelT,
						  pDecorationT->iAniStep, pDecorationT->iNextAniStep,
						  pDecorationT->fModelInterpolation);
		glPopMatrix();
	}
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	glCullFace(GL_BACK);
	glLineWidth(3.0f);
	glDisable(GL_TEXTURE_2D);	
	glColor3f(1.0f, 1.0f, 1.0f);
	glDisable(GL_DEPTH_TEST);
	if(bTempBackground)
	{
		// Draw draw the selection around the fields:
		if(byEditorMenu == EDITOR_TERRAIN_MENU)
		{
			fHalfFieldWidth = Header.fFieldWidth/2;
			fHalfFieldHeight = Header.fFieldHeight/2;
			hWndT = hWndEditorTab[TAB_EDITOR_TERRAIN];
			// Draw selected field bounds:
			glColor3f(1.0f, 0.0f, 0.0f);
			for(i = 0; i < Header.iFields; i++)
			{
				pFieldT = &pField[i];
				if(!pFieldT->bOnScreen)
					continue;
				if(pFieldT->bSelected)
				{
					if(IsDlgButtonChecked(hWndT, IDC_EDITOR_TERRAIN_FLOOR) ||
					   IsDlgButtonChecked(hWndT, IDC_EDITOR_TERRAIN_BOTH))
					{
						// Show the floor point:
						glBegin(GL_LINE_LOOP);
							glVertex3f(fPoint[pFieldT->iFace[FACE_FLOOR][0]][X]-fHalfFieldWidth,
									   fPoint[pFieldT->iFace[FACE_FLOOR][0]][Y]-fHalfFieldHeight,
									   fPoint[pFieldT->iFace[FACE_FLOOR][0]][Z]);
							glVertex3f(fPoint[pFieldT->iFace[FACE_FLOOR][1]][X]-fHalfFieldWidth,
									   fPoint[pFieldT->iFace[FACE_FLOOR][1]][Y]-fHalfFieldHeight,
									   fPoint[pFieldT->iFace[FACE_FLOOR][1]][Z]);
							glVertex3f(fPoint[pFieldT->iFace[FACE_FLOOR][2]][X]-fHalfFieldWidth,
									   fPoint[pFieldT->iFace[FACE_FLOOR][2]][Y]-fHalfFieldHeight,
									   fPoint[pFieldT->iFace[FACE_FLOOR][2]][Z]);
							glVertex3f(fPoint[pFieldT->iFace[FACE_FLOOR][3]][X]-fHalfFieldWidth,
									   fPoint[pFieldT->iFace[FACE_FLOOR][3]][Y]-fHalfFieldHeight,
									   fPoint[pFieldT->iFace[FACE_FLOOR][3]][Z]);
						glEnd();
					}
					if(IsDlgButtonChecked(hWndT, IDC_EDITOR_TERRAIN_TOP) ||
					   IsDlgButtonChecked(hWndT, IDC_EDITOR_TERRAIN_BOTH))
					{
						// Show the front point:
						glBegin(GL_LINE_LOOP);
							glVertex3f(fPoint[pFieldT->iFace[FACE_FRONT][0]][X]-fHalfFieldWidth,
									   fPoint[pFieldT->iFace[FACE_FRONT][0]][Y]-fHalfFieldHeight,
									   fPoint[pFieldT->iFace[FACE_FRONT][0]][Z]);
							glVertex3f(fPoint[pFieldT->iFace[FACE_FRONT][1]][X]-fHalfFieldWidth,
									   fPoint[pFieldT->iFace[FACE_FRONT][1]][Y]-fHalfFieldHeight,
									   fPoint[pFieldT->iFace[FACE_FRONT][1]][Z]);
							glVertex3f(fPoint[pFieldT->iFace[FACE_FRONT][2]][X]-fHalfFieldWidth,
									   fPoint[pFieldT->iFace[FACE_FRONT][2]][Y]-fHalfFieldHeight,
									   fPoint[pFieldT->iFace[FACE_FRONT][2]][Z]);
							glVertex3f(fPoint[pFieldT->iFace[FACE_FRONT][3]][X]-fHalfFieldWidth,
									   fPoint[pFieldT->iFace[FACE_FRONT][3]][Y]-fHalfFieldHeight,
									   fPoint[pFieldT->iFace[FACE_FRONT][3]][Z]);
						glEnd();
					}
				}
			}
		}
		else
		{ // Draw selected field bounds:
			// Show beamer target:
			glColor3f(1.0f, 0.5f, 0.5f);
			if(pCurrentField->pSurface[FACE_FLOOR][0]->Header.bBeamer &&
			   pCurrentField->iBeamerTarget != -1)
			{
				glBegin(GL_LINES);
					glVertex3f(fPoint[pCurrentField->iFace[FACE_FLOOR][0]][X]-0.5f,
							   fPoint[pCurrentField->iFace[FACE_FLOOR][0]][Y]+0.5f,
							   fPoint[pCurrentField->iFace[FACE_FLOOR][0]][Z]);
					glVertex3f(fPoint[pField[pCurrentField->iBeamerTarget].iFace[FACE_FLOOR][0]][X]-0.5f,
							   fPoint[pField[pCurrentField->iBeamerTarget].iFace[FACE_FLOOR][0]][Y]+0.5f,
							   fPoint[pField[pCurrentField->iBeamerTarget].iFace[FACE_FLOOR][0]][Z]);
				glEnd();
			}

			glColor3f(1.0f, 0.0f, 0.0f);
			if(!bPause || State.bLevelComplete)
			{
				for(i = 0; i < Header.iFields; i++)
				{
					pFieldT = &pField[i];
					
					if(pFieldT->iXPos == Header.iWidth-1 || pFieldT->iYPos == Header.iHeight-1)
						continue; 

					 // Check if a field is selected:
					if(pFieldT->bSelected)
					{
						for(i3 = FACE_FRONT; i3 < FACE_BOTTOM+2; i3++)
						{
							glBegin(GL_LINE_LOOP);
								for(i2 = 0; i2 < 4; i2++)
									glVertex3f(fPoint[pFieldT->iFace[i3][i2]][X], fPoint[pFieldT->iFace[i3][i2]][Y],
											   fPoint[pFieldT->iFace[i3][i2]][Z]);
							glEnd();
						}
					}
					if(pFieldT->iCamera != -1 || pFieldT->iTextScript != -1 || pFieldT->pDecoration ||
					   pFieldT->bAlwaysWall || (!bIndestructibleWallStandart && pFieldT->bIndestructibleWall) ||
					   (bIndestructibleWallStandart && !pFieldT->bIndestructibleWall))
					{
						glBegin(GL_LINE_LOOP);
							glVertex3f(fPoint[pFieldT->iFace[FACE_FLOOR][0]][X]-0.5f, fPoint[pFieldT->iFace[FACE_FLOOR][0]][Y]+0.5f,
									   fPoint[pFieldT->iFace[FACE_FLOOR][0]][Z]-1.0f);
							glVertex3f(fPoint[pFieldT->iFace[FACE_FLOOR][0]][X]-0.5f, fPoint[pFieldT->iFace[FACE_FLOOR][0]][Y]+0.5f,
									   fPoint[pFieldT->iFace[FACE_FLOOR][0]][Z]+1.0f);
						glEnd();
					}
				}
			}
			else
			{ // Check only if a field is selected:
				for(i = 0; i < Header.iFields; i++)
				{
					pFieldT = &pField[i];
					if(pFieldT->iXPos == Header.iWidth-1 || pFieldT->iYPos == Header.iHeight-1 ||
					   !pFieldT->bSelected)
						continue; 
					for(i3 = FACE_FRONT; i3 < FACE_BOTTOM+2; i3++)
					{
						glBegin(GL_LINE_LOOP);
							for(i2 = 0; i2 < 4; i2++)
								glVertex3f(fPoint[pFieldT->iFace[i3][i2]][X], fPoint[pFieldT->iFace[i3][i2]][Y],
										   fPoint[pFieldT->iFace[i3][i2]][Z]);
						glEnd();
					}
				}
			}
		}
	}

	glEnable(GL_DEPTH_TEST);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
} // end LEVEL::Draw()

void LEVEL::DrawTransparent(void)
{ // begin LEVEL::DrawTransparent()
	short i, i2, i3, iAniStep = 0;
	TEXTURE_POS *pTexturePos;
	FIELD *pFieldT;
	
	// Draw the transparent stuff:
	glCullFace(GL_FRONT);
	glDisableClientState(GL_NORMAL_ARRAY);
	if(!_ASConfig->bUseLevelVertexColor || !_ASConfig->bHightRenderQuality)
		glDisableClientState(GL_COLOR_ARRAY);
	else
		glColorPointer(3, GL_FLOAT, 0, fColor);
	glVertexPointer(3, GL_FLOAT, 0, fPoint);
	glEnable(GL_TEXTURE_2D);
	glDepthMask(FALSE);
	glEnable(GL_BLEND);											// Enable Blending       (disable alpha testing)
	for(i2 = 0; i2 < Header.iTextures+1; i2++)
	{
		if(i2 < Header.iTextures)
			glBindTexture(GL_TEXTURE_2D, pTexture[i2].iOpenGLID);
		for(i = 0; i < Header.iFields; i++)
		{
			pFieldT = &pField[i];
			if((!pFieldT->bActive && !pFieldT->bWallHole) || !pFieldT->bOnScreen || (pFieldT->pBridgeActor && !pFieldT->bWallHole))
				continue;
			if(pFieldT->bNoBackfaceCulling)
				glDisable(GL_CULL_FACE);
			else
				glEnable(GL_CULL_FACE);
			if(!pFieldT->bFaceActive[FACE_FRONT] && pFieldT->bFaceActive[FACE_FLOOR] && !pFieldT->bWallHole)
			{ // Draw the floor:
				i3 = FACE_FLOOR;
				if(pFieldT->pSurface[i3][0] && pFieldT->pSurface[i3][0]->iTextureID[pFieldT->iCurrentAniStep[i3][0]] == i2)
				{
					pTexturePos = &pFieldT->pSurface[i3][0]->pTexturePos[pFieldT->iCurrentAniStep[i3][0]];
					if(pTexturePos->fColor[3] == 1.0f || pTexturePos->fColor[3] == 0.0f)
						continue;

					glColor4fv(pTexturePos->fColor);
					glBegin(GL_TRIANGLES);
						glNormal3fv(pFieldT->fNormal[i3][0]);
						
						glTexCoord2fv(pTexturePos->fPos[(1+pFieldT->iSurfaceRotation[i3][0]) % 4]);
						glArrayElement(pFieldT->iFace[i3][0]);
						glTexCoord2fv(pTexturePos->fPos[(2+pFieldT->iSurfaceRotation[i3][0]) % 4]);
						glArrayElement(pFieldT->iFace[i3][1]);
						glTexCoord2fv(pTexturePos->fPos[(3+pFieldT->iSurfaceRotation[i3][0]) % 4]);
						glArrayElement(pFieldT->iFace[i3][2]);
						
						glNormal3fv(pFieldT->fNormal[i3][1]);
						glTexCoord2fv(pTexturePos->fPos[(1+pFieldT->iSurfaceRotation[i3][0]) % 4]);
						glArrayElement(pFieldT->iFace[i3][0]);
						glTexCoord2fv(pTexturePos->fPos[(3+pFieldT->iSurfaceRotation[i3][0]) % 4]);
						glArrayElement(pFieldT->iFace[i3][2]);
						glTexCoord2fv(pTexturePos->fPos[(pFieldT->iSurfaceRotation[i3][0]) % 4]);
						glArrayElement(pFieldT->iFace[i3][3]);
					glEnd();
				}
			}
			if((pFieldT->bWall || pFieldT->bWallHole) && !pFieldT->bAlwaysWall)
			{ // Draw the sided around the field: 
				for(i3 = FACE_FRONT; i3 < FACE_BOTTOM+2; i3++)
				{
					if(!pFieldT->bFaceActive[i3] ||
					   !pFieldT->pSurface[i3][0] || pFieldT->pSurface[i3][0]->iTextureID[pFieldT->iCurrentAniStep[i3][0]] != i2)
						continue;
					pTexturePos = &pFieldT->pSurface[i3][0]->pTexturePos[pFieldT->iCurrentAniStep[i3][0]];
					if(pTexturePos->fColor[3] == 1.0f || pTexturePos->fColor[3] == 0.0f)
						continue;

					glColor4fv(pTexturePos->fColor);
					glBegin(GL_TRIANGLES);
						glNormal3fv(pFieldT->fNormal[i3][0]);

						glTexCoord2fv(pTexturePos->fPos[(1+pFieldT->iSurfaceRotation[i3][0]) % 4]);
						glArrayElement(pFieldT->iFace[i3][0]);
						glTexCoord2fv(pTexturePos->fPos[(2+pFieldT->iSurfaceRotation[i3][0]) % 4]);
						glArrayElement(pFieldT->iFace[i3][1]);
						glTexCoord2fv(pTexturePos->fPos[(3+pFieldT->iSurfaceRotation[i3][0]) % 4]);
						glArrayElement(pFieldT->iFace[i3][2]);
						
						glNormal3fv(pFieldT->fNormal[i3][1]);
						glTexCoord2fv(pTexturePos->fPos[(1+pFieldT->iSurfaceRotation[i3][0]) % 4]);
						glArrayElement(pFieldT->iFace[i3][0]);
						glTexCoord2fv(pTexturePos->fPos[(3+pFieldT->iSurfaceRotation[i3][0]) % 4]);
						glArrayElement(pFieldT->iFace[i3][2]);
						glTexCoord2fv(pTexturePos->fPos[(pFieldT->iSurfaceRotation[i3][0]) % 4]);
						glArrayElement(pFieldT->iFace[i3][3]);
					glEnd();
				}
			}
		}
	}
	glCullFace(GL_BACK);
	glDepthMask(TRUE);
	glDisable(GL_BLEND);
	glCullFace(GL_BACK);
	if(!_ASConfig->bUseLevelVertexColor || !_ASConfig->bHightRenderQuality)
		glEnableClientState(GL_COLOR_ARRAY);
	glEnableClientState(GL_NORMAL_ARRAY);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_TEXTURE_2D);	
} // end LEVEL::DrawTransparent()

void LEVEL::DrawWater(void)
{ // begin LEVEL::DrawWater()
	TEXTURE_POS *pTexturePosT;
	float fLeft, fRight, fTop, fBottom, fHeight, fRed, fGreen, fBlue, fDensity;
	SURFACE *pSurfaceT;

	if(!Environment.bWater)
		return;

	if(!bPause || State.bLevelComplete)
		Environment.fWaterVar += 0.005f*g_lDeltatime*Environment.fWaterSpeed;
	Environment.fWaterActualHeight = (float) (sin(Environment.fWaterVar)/50.0f)*Environment.fWaterAmplitude+Environment.fWaterHeight;

	if(bUnderWater)
		return;

	fLeft = 0.01f;
	fRight = (Header.iWidth-1)*Header.fFieldWidth-0.01f;
	fTop = 0.01f;
	fBottom = (Header.iHeight-1)*Header.fFieldHeight-0.01f;
	fHeight = Environment.fWaterActualHeight;
	fRed = Environment.fWaterColor[R];
	fGreen = Environment.fWaterColor[G];
	fBlue = Environment.fWaterColor[B];
	fDensity = Environment.fWaterDensity;

	glEnable(GL_DEPTH_TEST);
	glDisable(GL_CULL_FACE);

	glEnable(GL_BLEND);
	glDisable(GL_TEXTURE_2D);
	// Create a smooth 'water end':
	glDepthMask(FALSE);
	glBegin(GL_QUADS);
		glNormal3f(0.0f, 0.0f, 1.0f);
	
		// Left:
		glColor4f(fRed, fGreen, fBlue, 0.0f);
		glVertex3d(fLeft-10.0f, fTop-10.0f, fHeight+10.0f);
		glVertex3d(fLeft-10.0f, fBottom+10.0f, fHeight+10.0f);
		glColor4f(fRed, fGreen, fBlue, fDensity);
		glVertex3d(fLeft, fBottom, fHeight);
		glVertex3d(fLeft, fTop, fHeight);

		// Top:
		glColor4f(fRed, fGreen, fBlue, 0.0f);
		glVertex3d(fLeft-10.0f, fTop-10.0f, fHeight+10.0f);
		glColor4f(fRed, fGreen, fBlue, fDensity);
		glVertex3d(fLeft, fTop, fHeight);
		glVertex3d(fRight, fTop, fHeight);
		glColor4f(fRed, fGreen, fBlue, 0.0f);
		glVertex3d(fRight+10.0f, fTop-10.0f, fHeight+10.0f);

		// Right:
		glColor4f(fRed, fGreen, fBlue, 0.0f);
		glVertex3d(fRight+10.0f, fTop-10.0f, fHeight+10.0f);
		glVertex3d(fRight+10.0f, fBottom+10.0f, fHeight+10.0f);
		glColor4f(fRed, fGreen, fBlue, fDensity);
		glVertex3d(fRight, fBottom, fHeight);
		glVertex3d(fRight, fTop, fHeight);

		// Bottom:
		glColor4f(fRed, fGreen, fBlue, 0.0f);
		glVertex3d(fLeft-10.0f, fBottom+10.0f, fHeight+10.0f);
		glColor4f(fRed, fGreen, fBlue, fDensity);
		glVertex3d(fLeft, fBottom, fHeight);
		glVertex3d(fRight, fBottom, fHeight);
		glColor4f(fRed, fGreen, fBlue, 0.0f);
		glVertex3d(fRight+10.0f, fBottom+10.0f, fHeight+10.0f);

	glEnd();
	glDepthMask(TRUE);

	if(Environment.fWaterDensity != 1.0f)
		glEnable(GL_BLEND);
	else
		glDisable(GL_BLEND);
	glColor4f(fRed, fGreen, fBlue, fDensity);
	if(!Environment.bWaterSurface)
	{ // Draw none textured water:
		glBegin(GL_QUADS);
			glNormal3f(0.0f, 0.0f, 1.0f);
			glVertex3d(fLeft, fTop, fHeight);
			glVertex3d(fLeft, fBottom, fHeight);
			glVertex3d(fRight, fBottom, fHeight);
			glVertex3d(fRight, fTop, fHeight);
		glEnd();
		glEnable(GL_TEXTURE_2D);
	}
	else
	{ // Draw textured water:
		// Animate the water:
		pSurfaceT = &pSurface[Environment.iWaterSurface];
		if(Environment.iWaterAniStep >= pSurfaceT->Header.iAniSteps)
			Environment.iWaterAniStep = 0;
		pTexturePosT = &pSurfaceT->pTexturePos[Environment.iWaterAniStep];
		if(!bPause && Environment.bWaterSurface && g_lNow-Environment.lWaterAniTime > pTexturePosT->iTimeToNext)
		{
			Environment.lWaterAniTime = g_lNow;
			Environment.iWaterAniStep++;
			if(Environment.iWaterAniStep >= pSurfaceT->Header.iAniSteps)
				Environment.iWaterAniStep = 0;
		}
				
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, pSurfaceT->pTexture[Environment.iWaterAniStep]->iOpenGLID);
		pTexturePosT = &pSurfaceT->pTexturePos[Environment.iWaterAniStep];
		glBegin(GL_QUADS);
			glNormal3f(0.0f, 0.0f, -1.0f);
			glTexCoord2f(pTexturePosT->fPos[0][X], pTexturePosT->fPos[0][Y]);
			glVertex3d(fLeft, fTop, Environment.fWaterActualHeight);
			glTexCoord2f(pTexturePosT->fPos[1][X], pTexturePosT->fPos[1][Y]);
			glVertex3d(fLeft, fBottom, Environment.fWaterActualHeight);
			glTexCoord2f(pTexturePosT->fPos[2][X], pTexturePosT->fPos[2][Y]);
			glVertex3d(fRight, fBottom, Environment.fWaterActualHeight);
			glTexCoord2f(pTexturePosT->fPos[3][X], pTexturePosT->fPos[3][Y]);
			glVertex3d(fRight, fTop, Environment.fWaterActualHeight);
		glEnd();
	}
	if(Environment.bWaterEnvironment && _ASConfig->bHightRenderQuality)
	{ // Water environment:
		if(Environment.fWaterEnvironmentDensity != 1.0f)
			glEnable(GL_BLEND);
		else
			glDisable(GL_BLEND);
		pSurfaceT = &pSurface[Environment.iWaterEnvironmentSurface];
		if(Environment.iWaterEnvironmentAniStep >= pSurfaceT->Header.iAniSteps)
			Environment.iWaterEnvironmentAniStep = 0;
		if(!bPause && Environment.bWaterEnvironment && g_lNow-Environment.lWaterEnvironmentAniTime > pTexturePosT->iTimeToNext)
		{
			Environment.lWaterEnvironmentAniTime = g_lNow;
			Environment.iWaterEnvironmentAniStep++;
			if(Environment.iWaterEnvironmentAniStep >= pSurfaceT->Header.iAniSteps)
				Environment.iWaterEnvironmentAniStep = 0;
		}
		pTexturePosT = &pSurfaceT->pTexturePos[Environment.iWaterEnvironmentAniStep];
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, pSurfaceT->pTexture[Environment.iWaterEnvironmentAniStep]->iOpenGLID);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		glColor4f(Environment.fWaterEnvironmentColor[R], Environment.fWaterEnvironmentColor[G], Environment.fWaterEnvironmentColor[B], Environment.fWaterEnvironmentDensity);
		glBegin(GL_QUADS);
			glNormal3f(0.0f, 0.0f, -1.0f);
			glTexCoord2f(pTexturePosT->fPos[0][X], pTexturePosT->fPos[0][Y]);
			glVertex3d(0.01f, 0.01f, Environment.fWaterActualHeight);
			glTexCoord2f(pTexturePosT->fPos[1][X], pTexturePosT->fPos[1][Y]);
			glVertex3d(0.01f, (Header.iHeight-1)*Header.fFieldHeight-0.01f, Environment.fWaterActualHeight);
			glTexCoord2f(pTexturePosT->fPos[2][X], pTexturePosT->fPos[2][Y]);
			glVertex3d((Header.iWidth-1)*Header.fFieldWidth-0.01f, (Header.iHeight-1)*Header.fFieldHeight-0.01f, Environment.fWaterActualHeight);
			glTexCoord2f(pTexturePosT->fPos[3][X], pTexturePosT->fPos[3][Y]);
			glVertex3d((Header.iWidth-1)*Header.fFieldWidth-0.01f, 0.01f, Environment.fWaterActualHeight);
		glEnd();
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	}
	glDisable(GL_BLEND);
	glEnable(GL_CULL_FACE);
} // end LEVEL::DrawWater()

void LEVEL::DrawSkyCube(void)
{ // begin LEVEL::DrawSkyCube();
	TEXTURE_POS *pTexturePos;
	short i;

	if(!Environment.bSkyCube)
		return;

	// Animate the sky cube:
	for(i = 0; i < 6; i++)
	{
		if(Environment.iSkyCubeSurface[i] >= Header.iSurfaces)
			Environment.iSkyCubeSurface[i] = 0;
		if(g_lNow-Environment.dwSkyCubeSurfaceLastTime[i] >
		   pSurface[Environment.iSkyCubeSurface[i]].pTexturePos[Environment.iSkyCubeSurfaceAniStep[i]].iTimeToNext)
		{
			Environment.dwSkyCubeSurfaceLastTime[i] = g_lNow;
			// It's time for a animation frame update:
			Environment.iSkyCubeSurfaceAniStep[i]++;
		}
	    // Go sure that the animation step is a correct one:
		if(Environment.iSkyCubeSurfaceAniStep[i] >= pSurface[Environment.iSkyCubeSurface[i]].Header.iAniSteps)
			Environment.iSkyCubeSurfaceAniStep[i] = 0;
	}

	// Draw the sky cube:
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_LIGHTING);
	glDisable(GL_CULL_FACE);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);
	glDisable(GL_FOG);
	glColor3fv(Environment.fSkyCubeColor);

	glDisableClientState(GL_COLOR_ARRAY);
	glDisableClientState(GL_NORMAL_ARRAY);

	FLOAT3 fSkyPoints[8] = 
	{
		{-1.0f, -1.0f, -1.0f}, // 0
		{1.0f, -1.0f, -1.0f}, // 1
		{1.0f, 1.0f, -1.0f}, // 2
		{-1.0f, 1.0f, -1.0f}, // 3
		{-1.0f, -1.0f, 1.0f}, // 4
		{1.0f, -1.0f, 1.0f}, // 5
		{1.0f, 1.0f, 1.0f}, // 6
		{-1.0f, 1.0f, 1.0f}, // 7
	};
	glVertexPointer(3, GL_FLOAT, 0, fSkyPoints);

	glScalef(Environment.fSkyCubeSize[0], Environment.fSkyCubeSize[1], Environment.fSkyCubeSize[2]);
	glPolygonMode(GL_BACK, GL_FILL);
	// Floor Face
	glBindTexture(GL_TEXTURE_2D, pSurface[Environment.iSkyCubeSurface[0]].pTexture[Environment.iSkyCubeSurfaceAniStep[0]]->iOpenGLID);
	pTexturePos = &pSurface[Environment.iSkyCubeSurface[0]].pTexturePos[Environment.iSkyCubeSurfaceAniStep[0]];
	glBegin(GL_QUADS);
		glTexCoord2fv(pTexturePos->fPos[(0+Environment.iSkyCubeSurfaceRotation[0]) % 4]); glArrayElement(4);
		glTexCoord2fv(pTexturePos->fPos[(1+Environment.iSkyCubeSurfaceRotation[0]) % 4]); glArrayElement(5);
		glTexCoord2fv(pTexturePos->fPos[(2+Environment.iSkyCubeSurfaceRotation[0]) % 4]); glArrayElement(6);
		glTexCoord2fv(pTexturePos->fPos[(3+Environment.iSkyCubeSurfaceRotation[0]) % 4]); glArrayElement(7);
	glEnd();

	// Sky Face
	glBindTexture(GL_TEXTURE_2D, pSurface[Environment.iSkyCubeSurface[1]].pTexture[Environment.iSkyCubeSurfaceAniStep[1]]->iOpenGLID);
	pTexturePos = &pSurface[Environment.iSkyCubeSurface[1]].pTexturePos[Environment.iSkyCubeSurfaceAniStep[1]];
	glBegin(GL_QUADS);
		glTexCoord2fv(pTexturePos->fPos[(3+Environment.iSkyCubeSurfaceRotation[1]) % 4]); glArrayElement(0);
		glTexCoord2fv(pTexturePos->fPos[(0+Environment.iSkyCubeSurfaceRotation[1]) % 4]); glArrayElement(3);
		glTexCoord2fv(pTexturePos->fPos[(1+Environment.iSkyCubeSurfaceRotation[1]) % 4]); glArrayElement(2);
		glTexCoord2fv(pTexturePos->fPos[(2+Environment.iSkyCubeSurfaceRotation[1]) % 4]); glArrayElement(1);
	glEnd();

	// Back Face
	glBindTexture(GL_TEXTURE_2D, pSurface[Environment.iSkyCubeSurface[2]].pTexture[Environment.iSkyCubeSurfaceAniStep[2]]->iOpenGLID);
	pTexturePos = &pSurface[Environment.iSkyCubeSurface[2]].pTexturePos[Environment.iSkyCubeSurfaceAniStep[2]];
	glBegin(GL_QUADS);
		glTexCoord2fv(pTexturePos->fPos[(1+Environment.iSkyCubeSurfaceRotation[2]) % 4]); glArrayElement(3);
		glTexCoord2fv(pTexturePos->fPos[(2+Environment.iSkyCubeSurfaceRotation[2]) % 4]); glArrayElement(7);
		glTexCoord2fv(pTexturePos->fPos[(3+Environment.iSkyCubeSurfaceRotation[2]) % 4]); glArrayElement(6);
		glTexCoord2fv(pTexturePos->fPos[(0+Environment.iSkyCubeSurfaceRotation[2]) % 4]); glArrayElement(2);
	glEnd();

	// Front Face
	glBindTexture(GL_TEXTURE_2D, pSurface[Environment.iSkyCubeSurface[3]].pTexture[Environment.iSkyCubeSurfaceAniStep[3]]->iOpenGLID);
	pTexturePos = &pSurface[Environment.iSkyCubeSurface[3]].pTexturePos[Environment.iSkyCubeSurfaceAniStep[3]];
	glBegin(GL_QUADS);
		glTexCoord2fv(pTexturePos->fPos[(0+Environment.iSkyCubeSurfaceRotation[3]) % 4]); glArrayElement(0);
		glTexCoord2fv(pTexturePos->fPos[(1+Environment.iSkyCubeSurfaceRotation[3]) % 4]); glArrayElement(1);
		glTexCoord2fv(pTexturePos->fPos[(2+Environment.iSkyCubeSurfaceRotation[3]) % 4]); glArrayElement(5);
		glTexCoord2fv(pTexturePos->fPos[(3+Environment.iSkyCubeSurfaceRotation[3]) % 4]); glArrayElement(4);
	glEnd();

	// Right face
	glBindTexture(GL_TEXTURE_2D, pSurface[Environment.iSkyCubeSurface[4]].pTexture[Environment.iSkyCubeSurfaceAniStep[4]]->iOpenGLID);
	pTexturePos = &pSurface[Environment.iSkyCubeSurface[4]].pTexturePos[Environment.iSkyCubeSurfaceAniStep[4]];
	glBegin(GL_QUADS);
		glTexCoord2fv(pTexturePos->fPos[(0+Environment.iSkyCubeSurfaceRotation[4]) % 4]); glArrayElement(1);
		glTexCoord2fv(pTexturePos->fPos[(1+Environment.iSkyCubeSurfaceRotation[4]) % 4]); glArrayElement(2);
		glTexCoord2fv(pTexturePos->fPos[(2+Environment.iSkyCubeSurfaceRotation[4]) % 4]); glArrayElement(6);
		glTexCoord2fv(pTexturePos->fPos[(3+Environment.iSkyCubeSurfaceRotation[4]) % 4]); glArrayElement(5);
	glEnd();

    // Left Face
	glBindTexture(GL_TEXTURE_2D, pSurface[Environment.iSkyCubeSurface[5]].pTexture[Environment.iSkyCubeSurfaceAniStep[5]]->iOpenGLID);
	pTexturePos = &pSurface[Environment.iSkyCubeSurface[5]].pTexturePos[Environment.iSkyCubeSurfaceAniStep[5]];
	glBegin(GL_QUADS);
		glTexCoord2fv(pTexturePos->fPos[(1+Environment.iSkyCubeSurfaceRotation[5]) % 4]); glArrayElement(0);
		glTexCoord2fv(pTexturePos->fPos[(2+Environment.iSkyCubeSurfaceRotation[5]) % 4]); glArrayElement(4);
		glTexCoord2fv(pTexturePos->fPos[(3+Environment.iSkyCubeSurfaceRotation[5]) % 4]); glArrayElement(7);
		glTexCoord2fv(pTexturePos->fPos[(0+Environment.iSkyCubeSurfaceRotation[5]) % 4]); glArrayElement(3);
	glEnd();

	glEnable(GL_CULL_FACE);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_FOG);
	ASEnableLighting();
} // end LEVEL::DrawSkyCube()












/*
void LEVEL::DrawSkyCube(void)
{ // begin LEVEL::DrawSkyCube();
	TEXTURE_POS *pTexturePos;
	short i;

	if(!Environment.bSkyCube)
		return;

	// Animate the sky cube:
	for(i = 0; i < 6; i++)
	{
		if(Environment.iSkyCubeSurface[i] >= Header.iSurfaces)
			Environment.iSkyCubeSurface[i] = 0;
		if(g_lNow-Environment.dwSkyCubeSurfaceLastTime[i] >
		   pSurface[Environment.iSkyCubeSurface[i]].pTexturePos[Environment.iSkyCubeSurfaceAniStep[i]].iTimeToNext)
		{
			Environment.dwSkyCubeSurfaceLastTime[i] = g_lNow;
			// It's time for a animation frame update:
			Environment.iSkyCubeSurfaceAniStep[i]++;
		}
	    // Go sure that the animation step is a correct one:
		if(Environment.iSkyCubeSurfaceAniStep[i] >= pSurface[Environment.iSkyCubeSurface[i]].Header.iAniSteps)
			Environment.iSkyCubeSurfaceAniStep[i] = 0;
	}

	// Draw the sky cube:
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_LIGHTING);
	glDisable(GL_CULL_FACE);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);
	glDisable(GL_FOG);
	glColor3fv(Environment.fSkyCubeColor);

	glScalef(Environment.fSkyCubeSize[0], Environment.fSkyCubeSize[1], Environment.fSkyCubeSize[2]);
	glPolygonMode(GL_BACK, GL_FILL);
	// Floor Face
	glBindTexture(GL_TEXTURE_2D, pSurface[Environment.iSkyCubeSurface[0]].pTexture[Environment.iSkyCubeSurfaceAniStep[0]]->iOpenGLID);
	pTexturePos = &pSurface[Environment.iSkyCubeSurface[0]].pTexturePos[Environment.iSkyCubeSurfaceAniStep[0]];
	glBegin(GL_QUADS);
		glTexCoord2fv(pTexturePos->fPos[(0+Environment.iSkyCubeSurfaceRotation[0]) % 4]); glVertex3f(-1.0f, -1.0f,  1.0f);
		glTexCoord2fv(pTexturePos->fPos[(1+Environment.iSkyCubeSurfaceRotation[0]) % 4]); glVertex3f( 1.0f, -1.0f,  1.0f);
		glTexCoord2fv(pTexturePos->fPos[(2+Environment.iSkyCubeSurfaceRotation[0]) % 4]); glVertex3f( 1.0f,  1.0f,  1.0f);
		glTexCoord2fv(pTexturePos->fPos[(3+Environment.iSkyCubeSurfaceRotation[0]) % 4]); glVertex3f(-1.0f,  1.0f,  1.0f);
	glEnd();

	// Sky Face
	glBindTexture(GL_TEXTURE_2D, pSurface[Environment.iSkyCubeSurface[1]].pTexture[Environment.iSkyCubeSurfaceAniStep[1]]->iOpenGLID);
	pTexturePos = &pSurface[Environment.iSkyCubeSurface[1]].pTexturePos[Environment.iSkyCubeSurfaceAniStep[1]];
	glBegin(GL_QUADS);
		glTexCoord2fv(pTexturePos->fPos[(3+Environment.iSkyCubeSurfaceRotation[1]) % 4]); glVertex3f(-1.0f, -1.0f, -1.0f);
		glTexCoord2fv(pTexturePos->fPos[(0+Environment.iSkyCubeSurfaceRotation[1]) % 4]); glVertex3f(-1.0f,  1.0f, -1.0f);
		glTexCoord2fv(pTexturePos->fPos[(1+Environment.iSkyCubeSurfaceRotation[1]) % 4]); glVertex3f( 1.0f,  1.0f, -1.0f);
		glTexCoord2fv(pTexturePos->fPos[(2+Environment.iSkyCubeSurfaceRotation[1]) % 4]); glVertex3f( 1.0f, -1.0f, -1.0f);
	glEnd();

	// Back Face
	glBindTexture(GL_TEXTURE_2D, pSurface[Environment.iSkyCubeSurface[2]].pTexture[Environment.iSkyCubeSurfaceAniStep[2]]->iOpenGLID);
	pTexturePos = &pSurface[Environment.iSkyCubeSurface[2]].pTexturePos[Environment.iSkyCubeSurfaceAniStep[2]];
	glBegin(GL_QUADS);
		glTexCoord2fv(pTexturePos->fPos[(1+Environment.iSkyCubeSurfaceRotation[2]) % 4]); glVertex3f(-1.0f,  1.0f, -1.0f);
		glTexCoord2fv(pTexturePos->fPos[(2+Environment.iSkyCubeSurfaceRotation[2]) % 4]); glVertex3f(-1.0f,  1.0f,  1.0f);
		glTexCoord2fv(pTexturePos->fPos[(3+Environment.iSkyCubeSurfaceRotation[2]) % 4]); glVertex3f( 1.0f,  1.0f,  1.0f);
		glTexCoord2fv(pTexturePos->fPos[(0+Environment.iSkyCubeSurfaceRotation[2]) % 4]); glVertex3f( 1.0f,  1.0f, -1.0f);
	glEnd();

	// Front Face
	glBindTexture(GL_TEXTURE_2D, pSurface[Environment.iSkyCubeSurface[3]].pTexture[Environment.iSkyCubeSurfaceAniStep[3]]->iOpenGLID);
	pTexturePos = &pSurface[Environment.iSkyCubeSurface[3]].pTexturePos[Environment.iSkyCubeSurfaceAniStep[3]];
	glBegin(GL_QUADS);
		glTexCoord2fv(pTexturePos->fPos[(0+Environment.iSkyCubeSurfaceRotation[3]) % 4]); glVertex3f(-1.0f, -1.0f, -1.0f);
		glTexCoord2fv(pTexturePos->fPos[(1+Environment.iSkyCubeSurfaceRotation[3]) % 4]); glVertex3f( 1.0f, -1.0f, -1.0f);
		glTexCoord2fv(pTexturePos->fPos[(2+Environment.iSkyCubeSurfaceRotation[3]) % 4]); glVertex3f( 1.0f, -1.0f,  1.0f);
		glTexCoord2fv(pTexturePos->fPos[(3+Environment.iSkyCubeSurfaceRotation[3]) % 4]); glVertex3f(-1.0f, -1.0f,  1.0f);
	glEnd();

	// Right face
	glBindTexture(GL_TEXTURE_2D, pSurface[Environment.iSkyCubeSurface[4]].pTexture[Environment.iSkyCubeSurfaceAniStep[4]]->iOpenGLID);
	pTexturePos = &pSurface[Environment.iSkyCubeSurface[4]].pTexturePos[Environment.iSkyCubeSurfaceAniStep[4]];
	glBegin(GL_QUADS);
		glTexCoord2fv(pTexturePos->fPos[(0+Environment.iSkyCubeSurfaceRotation[4]) % 4]); glVertex3f( 1.0f, -1.0f, -1.0f);
		glTexCoord2fv(pTexturePos->fPos[(1+Environment.iSkyCubeSurfaceRotation[4]) % 4]); glVertex3f( 1.0f,  1.0f, -1.0f);
		glTexCoord2fv(pTexturePos->fPos[(2+Environment.iSkyCubeSurfaceRotation[4]) % 4]); glVertex3f( 1.0f,  1.0f,  1.0f);
		glTexCoord2fv(pTexturePos->fPos[(3+Environment.iSkyCubeSurfaceRotation[4]) % 4]); glVertex3f( 1.0f, -1.0f,  1.0f);
	glEnd();

    // Left Face
	glBindTexture(GL_TEXTURE_2D, pSurface[Environment.iSkyCubeSurface[5]].pTexture[Environment.iSkyCubeSurfaceAniStep[5]]->iOpenGLID);
	pTexturePos = &pSurface[Environment.iSkyCubeSurface[5]].pTexturePos[Environment.iSkyCubeSurfaceAniStep[5]];
	glBegin(GL_QUADS);
		glTexCoord2fv(pTexturePos->fPos[(1+Environment.iSkyCubeSurfaceRotation[5]) % 4]); glVertex3f(-1.0f, -1.0f, -1.0f);
		glTexCoord2fv(pTexturePos->fPos[(2+Environment.iSkyCubeSurfaceRotation[5]) % 4]); glVertex3f(-1.0f, -1.0f,  1.0f);
		glTexCoord2fv(pTexturePos->fPos[(3+Environment.iSkyCubeSurfaceRotation[5]) % 4]); glVertex3f(-1.0f,  1.0f,  1.0f);
		glTexCoord2fv(pTexturePos->fPos[(0+Environment.iSkyCubeSurfaceRotation[5]) % 4]); glVertex3f(-1.0f,  1.0f, -1.0f);

	glEnd();

	glEnable(GL_CULL_FACE);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_FOG);
	ASEnableLighting();
} // end LEVEL::DrawSkyCube()
*/

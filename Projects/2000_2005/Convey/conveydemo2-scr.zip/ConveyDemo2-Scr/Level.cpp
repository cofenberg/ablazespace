//-----------------------------------------------------------------------------
// File: Level.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Definitions: ***************************************************************
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
AS_CAMERA LevelTempCamera; // Used to find out if the camera has been moved
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
void CreateLevel(LEVEL **);
void DestroyLevel(LEVEL **);
BOOL GetLevelKeyword(char *, char *);
char GetLevelSingle(char *);
void GetLevelName(char *, char *);
void GetLevelFileName(char *, char *);
void StartLevel(char *, BOOL);
void StartCurrentLevel(void);
void StartLevelMusic(void);
void DestroyLevel(void);
///////////////////////////////////////////////////////////////////////////////


// LEVEL functions: ***********************************************************
LEVEL::LEVEL(void)
{ // begin LEVEL::LEVEL()
	// Setup the standart setup:
	memset(this, 0, sizeof(LEVEL));
	SetLevelStandartValues();
} // end LEVEL::LEVEL()

LEVEL::~LEVEL(void)
{ // begin LEVEL::~LEVEL()
} // end LEVEL::~LEVEL()

void LEVEL::SetLevelStandartValues(void)
{ // begin LEVEL::SetLevelStandartValues()
	short i;
	
	Header.iWidth = 11; 
	Header.iHeight = 11;
	Header.fFieldWidth = 1.0f;
	Header.fFieldHeight = 1.0f;
	Header.fFieldDepth = -2.0f;
	Header.bSingle = TRUE;
	Header.bEndScreen = TRUE;
	strcpy(Header.byName, "Noname");

	for(i = 0; i < 3; i++)
	{
		Environment.fSkyCubeColor[i] = 1.0f;
		Environment.fSkyCubeSize[i] = 1000.0f;
		Environment.fFogColor[i] = 0.5f;
		Environment.fColor[i] = 0.7f;
		Environment.fWaterEnvironmentColor[i] = 1.0f;
	}
	Environment.fFogDensity = 0.05f;
	
	Environment.fWaterDensity = 0.8f;
	Environment.fWaterEnvironmentDensity = 0.8f;
	Environment.fWaterColor[B] = 1.0f;
	Environment.fWaterHeight = STANDART_LEVEL_Z_POS-0.3f;

	Missions.bExit = TRUE;

	Camera.bFreeCamera = TRUE;
	Camera.bPlayerCamera = TRUE;
	Camera.bStandartCamera = TRUE;

	Tools.lGhostTime = GHOST_TIME;
	Tools.lSpeedTime = SPEED_TIME;
	Tools.lWingTime = WING_TIME;
	Tools.lShieldTime = SHIELD_TIME;
} // end LEVEL::SetLevelStandartValues()

void LEVEL::GenTexturesOpenGL(HDC hDC, HGLRC hRC)
{ // begin LEVEL::GenTextures()
	AS_PROGRESS_WINDOW ProgressWindow;

	ProgressWindow.CreateProgressWindow("Loading World");
	ProgressWindow.SetTask("Generate OpenGL level textures...");
	ProgressWindow.SetProgress(0);
	if(!wglMakeCurrent(hDC, hRC))
		return;

	for(short i = 0; i < Header.iTextures; i++)
	{
		ProgressWindow.SetSubTask("%s", pTexture[i].byFilename);
		ProgressWindow.SetProgress((UINT) (((float) i/Header.iTextures)*100));
		// First delete the old textures:
		if(pTexture[i].iOpenGLID > 2)
			glDeleteTextures(1, &pTexture[i].iOpenGLID);
		// Now generate the new:
		glGenTextures(1, &pTexture[i].iOpenGLID);
		glBindTexture(GL_TEXTURE_2D, pTexture[i].iOpenGLID);
		if(_ASConfig->bUseMipmaps)
		{
			if(_ASConfig->bFastTexturing)
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST_MIPMAP_NEAREST);
				gluBuild2DMipmaps(GL_TEXTURE_2D, 3, pTexture[i].iWidth, pTexture[i].iHeight, GL_RGB, GL_UNSIGNED_BYTE, pTexture[i].pbyData);
			}
			else
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);
				gluBuild2DMipmaps(GL_TEXTURE_2D, 3, pTexture[i].iWidth, pTexture[i].iHeight, GL_RGB, GL_UNSIGNED_BYTE, pTexture[i].pbyData);
			}
		}
		else
		{
			if(_ASConfig->bFastTexturing)
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
				glTexImage2D(GL_TEXTURE_2D, 0, 3, pTexture[i].iWidth, pTexture[i].iHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, pTexture[i].pbyData);
			}
			else
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
				glTexImage2D(GL_TEXTURE_2D, 0, 3, pTexture[i].iWidth, pTexture[i].iHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, pTexture[i].pbyData);
			}
		}
	}
} // end LEVEL::GenTextures()

void LEVEL::DestroyTexturesOpenGL(HDC hDC, HGLRC hRC)
{ // begin LEVEL::DestroyTexturesOpenGL()
	if(!hDC || !hRC || !wglMakeCurrent(hDC, hRC))
		return;
	AS_PROGRESS_WINDOW ProgressWindow;

	ProgressWindow.CreateProgressWindow("Update World");
	ProgressWindow.SetTask("Delete OpenGL level textures...");
	ProgressWindow.SetProgress(0);

	for(short i = 0; i < Header.iTextures; i++)
	{
		ProgressWindow.SetSubTask("%s", pTexture[i].byFilename);
		ProgressWindow.SetProgress((UINT) (((float) i/Header.iTextures)*100));
		glDeleteTextures(1, &pTexture[i].iOpenGLID);
	}
} // end LEVEL::DestroyTexturesOpenGL()

HRESULT LEVEL::CreateSurface(void)
{ // begin LEVEL::CreateSurface()
	FIELD *pFieldT;
	short i, i2, i3;

	Header.iSurfaces++;
	pSurface = (SURFACE *) realloc(pSurface, sizeof(SURFACE)*Header.iSurfaces);
	iCurrentSurface = Header.iSurfaces-1;
	pCurrentSurface = &pSurface[iCurrentSurface];
	memset(pCurrentSurface, 0, sizeof(SURFACE));
	pCurrentSurface->Header.iID = Header.iSurfaces-1;
	pCurrentSurface->Header.iAniSteps = 1;
	pCurrentSurface->Header.fFriction = 1.0f;
	pCurrentSurface->pTexturePos = (TEXTURE_POS *) malloc(sizeof(TEXTURE_POS)*pCurrentSurface->Header.iAniSteps);
	pCurrentSurface->byTextureFilename = (char **) malloc(sizeof(char *)*pCurrentSurface->Header.iAniSteps);
	pCurrentSurface->iTextureID = (short *) malloc(sizeof(short)*pCurrentSurface->Header.iAniSteps);
	pCurrentSurface->pTexture = (AS_TEXTURE **) malloc(sizeof(AS_TEXTURE)*pCurrentSurface->Header.iAniSteps);
	for(i = 0; i < pCurrentSurface->Header.iAniSteps; i++)
	{
		pCurrentSurface->byTextureFilename[i] = (char *) malloc(sizeof(char)*MAX_PATH);
		strcpy(pCurrentSurface->byTextureFilename[i], pLevel->pTexture[0].byFilename);
		pCurrentSurface->iTextureID[i] = 0;
		pCurrentSurface->pTexture[i] = &pTexture[pCurrentSurface->iTextureID[i]];
		pCurrentSurface->pTexture[0]->iUsed++;
	}
	memset(&pCurrentSurface->pTexturePos[0], 0, sizeof(TEXTURE_POS));
	pCurrentSurface->pTexturePos[0].iPos[0][X] = 0;
	pCurrentSurface->pTexturePos[0].iPos[0][Y] = 0;
	pCurrentSurface->pTexturePos[0].iPos[1][X] = pCurrentSurface->pTexture[0]->iWidth-1;
	pCurrentSurface->pTexturePos[0].iPos[1][Y] = 0;
	pCurrentSurface->pTexturePos[0].iPos[2][X] = pCurrentSurface->pTexture[0]->iWidth-1;
	pCurrentSurface->pTexturePos[0].iPos[2][Y] = pCurrentSurface->pTexture[0]->iHeight-2;
	pCurrentSurface->pTexturePos[0].iPos[3][X] = 0;
	pCurrentSurface->pTexturePos[0].iPos[3][Y] = pCurrentSurface->pTexture[0]->iHeight-2;
	for(i = 0; i < 4; i++)
		pCurrentSurface->pTexturePos[0].fColor[i] = 1.0f;
	
	// Update the fields:
	for(i = 0; i < Header.iFields; i++)
	{
		pFieldT = &pField[i];
		// This is required for every field side:
		for(i2 = 0; i2 < 6; i2++)
		{
			for(i3 = 0; i3 < 2; i3++)
			{
				if(pFieldT->pSurface[i2][i3])
					pFieldT->pSurface[i2][i3] = &pSurface[pFieldT->iSurface[i2][i3]];
			}
		}
	}
	return 0;
} // end LEVEL::CreateSurface()

void LEVEL::DestroySurface(short iSurface)
{ // begin LEVEL::DestroySurface()
	short i, i2, i3;
	FIELD *pFieldT;

	pSurface[iSurface].Destroy();

	// The given surface is replaced through the next one and so on:
	for(i = iSurface; i < Header.iSurfaces-1; i++)
	{
		memcpy(&pSurface[i], &pSurface[i+1], sizeof(SURFACE));
		pSurface[i].Header.iID--;
		if(pSurface[i].Header.iChangeSurface == iSurface)
			pSurface[i].Header.iChangeSurface = 0;
	}
	for(i = 0; i < TextScriptsManager.iTextsScripts; i++)
	{
		for(i2 = 0; i2 < pTextScript[i].iTexts; i2++)
		{
			if(pTextScript[i].pText[i2].iSurface > iSurface)
				pTextScript[i].pText[i2].iSurface--;
			if(pTextScript[i].pText[i2].iSurface == iSurface)
				pTextScript[i].pText[i2].iSurface = -1;
		}
	}

	// Reorganize the surfaces:
	Header.iSurfaces--;
	pSurface = (SURFACE *) realloc(pSurface, sizeof(SURFACE)*Header.iSurfaces);
	
	// Update the current surface pointer:
	if(iCurrentSurface >= Header.iSurfaces)
	{
		iCurrentSurface--;
		pCurrentSurface = &pSurface[iCurrentSurface];
	}
	else
		if(!pSurface)
		{ // There are no surfaces:
			iCurrentSurface = -1;
			pCurrentSurface = NULL;
		}
	
	// Update the fields:
	for(i = 0; i < Header.iFields; i++)
	{
		pFieldT = &pField[i];
		// This is required for every field side:
		for(i2 = 0; i2 < 6; i2++)
		{
			for(i3 = 0; i3 < 2; i3++)
			{
				// Update the field pointers:
				if(pFieldT->iSurface[i2][i3] == iSurface)
				{
					// This side has now the default:
					pFieldT->iSurface[i2][i3] = 0;
					pFieldT->pSurface[i2][i3] = &pSurface[0];
					pSurface[0].iUsed++;
					continue;
				}
				if(pFieldT->iSurface[i2][i3] > iSurface)
				{
					pFieldT->iSurface[i2][i3]--;
					pFieldT->pSurface[i2][i3] = &pSurface[pFieldT->iSurface[i2][i3]];
				}
			}
		}
	}

	// Update water surface:
	if(Environment.iWaterSurface == iSurface)
		Environment.iWaterSurface = 0;
	else
		if(Environment.iWaterSurface > iSurface)
			Environment.iWaterSurface--;
	
	// Update the sky-cube:
	for(i = 0; i < 6; i++)
	{
		if(Environment.iSkyCubeSurface[i] == iSurface)
			Environment.iSkyCubeSurface[i] = 0; // Set the default surface
		if(Environment.iSkyCubeSurface[i] > iSurface)
			Environment.iSkyCubeSurface[i]--; // Set the new surface
	}

	// Update box surface:
	for(i2 = 0; i2 < 2; i2++)
		for(i = 0; i < 6; i++)
		{
			if(Header.iBoxSurface[i][i2] == iSurface)
				Header.iBoxSurface[i][i2] = 0;
			else
				if(Header.iBoxSurface[i][i2] > iSurface)
					Header.iBoxSurface[i][i2]--;
		}
} // end LEVEL::DestroySurface()

HRESULT LEVEL::LoadSurface(char *pbyFilename)
{ // begin LEVEL::LoadSurface()
	short i, i2, i3;
	FIELD *pFieldT;

	if(!pbyFilename || CreateSurface())
		return 1;
	
	// Now load the surface:
	if(pCurrentSurface->Load(pbyFilename))
		return 1;
	
	// Update the field pointer the surfaces:
	for(i = 0; i < Header.iFields; i++)
	{
		pFieldT = &pField[i];
		for(i2 = 0; i2 < 6; i2++)
		{
			for(i3 = 0; i3 < 2; i3++)
			{
				if(pFieldT->iSurface[i2][i3] == -1)
					continue;
				pFieldT->pSurface[i2][i3] = &pSurface[pFieldT->iSurface[i2][i3]];
			}
		}
		break;
	}
	return 0;
} // end LEVEL::LoadSurface()

void LEVEL::DestroyTexture(short iTexture)
{ // begin LEVEL::DestroyTexture()
	short i, i2;

	// The given texture is replaced through the next one and so on:
	for(i = iTexture; i < Header.iTextures-1; i++)
	{
		memcpy(&pTexture[i], &pTexture[i+1], sizeof(AS_TEXTURE));
		pTexture[i].iID--;
	
	}
	// Reorganize the textures:
	Header.iTextures--;
	pTexture = (AS_TEXTURE *) realloc(pTexture, sizeof(AS_TEXTURE)*Header.iTextures);
	
	// Update the current texture pointer:
	if(iCurrentTexture >= Header.iTextures)
	{
		iCurrentTexture--;
		pCurrentTexture = &pTexture[iCurrentTexture];
	}
	else
		if(!pTexture)
		{ // There are no textures:
			iCurrentTexture = -1;
			pCurrentTexture = NULL;
		}

	// Update the surface pointers:
	for(i = 0; i < Header.iSurfaces; i++)
	{
		for(i2 = 0; i2 < pSurface[i].Header.iAniSteps; i2++)
		{
			if(pSurface[i].iTextureID[i2] == iTexture)
			{ // Give this surface the default texture:
				pSurface[i].iTextureID[i2] = 0;
				pSurface[i].pTexture[i2] = &pTexture[0];
				continue;
			}
			if(pSurface[i].iTextureID[i2] > iTexture)
			{
				pSurface[i].iTextureID[i2]--;
				pSurface[i].pTexture[i2] = &pTexture[pSurface[i].iTextureID[i2]];
			}
		}
	}
	for(i = 0; i < Header.iFields; i++)
	{
		if(!pField[i].pDecoration)
			continue;
		if(pField[i].pDecoration->iTexture > iTexture)
			pField[i].pDecoration->iTexture--;
		if(pField[i].pDecoration->iTexture == iTexture)
			pField[i].pDecoration->iTexture = -1;
	}
} // end LEVEL::DestroySurface()

HRESULT LEVEL::LoadTexture(char *pbyFilename)
{ // begin LEVEL::LoadTexture()
	char byTemp[MAX_PATH];
	short i, i2;
	FILE *fp;

	if(!pbyFilename)
		return 1;

	// Add the main path:
	sprintf(byTemp, "%s%s", _AS->pbyProgramPath, pbyFilename);
	
	// Check if the texture is already loaded:
	for(i = 0; i < Header.iTextures; i++)
		if(!strcmp(pTexture[i].byFilename, pbyFilename))
		{
			iCurrentTexture = i;
			pCurrentTexture = &pTexture[iCurrentTexture];
			return 0; // This texture is already loaded:
		}

	// Check if the texture is there:
	fp = fopen(byTemp, "r");
	if(!fp)
	{ // A texture was not found!!
		sprintf(byTemp, "%s: %s ", byTemp, M_TextureWasNotFound);
		_AS->WriteLogMessage(byTemp);	
		iCurrentTexture = 0;
		pCurrentTexture = &pTexture[0];
		return 0;
	}
	fclose(fp);

	// Add the new texture:
	Header.iTextures++;
	pTexture = (AS_TEXTURE *) realloc(pTexture, sizeof(AS_TEXTURE)*Header.iTextures);
	iCurrentTexture = Header.iTextures-1;
	pCurrentTexture = &pTexture[iCurrentTexture];
	memset(pCurrentTexture, 0, sizeof(AS_TEXTURE));
	pCurrentTexture->iID = Header.iTextures-1;
	strcpy(pCurrentTexture->byFilename, pbyFilename);
	
	// Now load the texture:
	ASLoadJpegRGB(pCurrentTexture, byTemp);
	
	// Update the surfaces:
	for(i = 0; i < Header.iSurfaces; i++)
	{
		for(i2 = 0; i2 < pSurface[i].Header.iAniSteps; i2++)
		{
			if(pSurface[i].iTextureID[i2] == -1)
				continue;
			pSurface[i].pTexture[i2] = &pTexture[pSurface[i].iTextureID[i2]];
		}
	}
	return 0;
} // end LEVEL::LoadTexture()

void LEVEL::Create(short iWidthT, short iHeightT, float fFieldDepthT, float fFieldWidthT, float fFieldHeightT)
{ // begin LEVEL::Create()
	short i, i2, i3, i4, i5,  x, y;
	char byTemp[256];

	// Setup the general level information:
	memset(&Header, 0, sizeof(LEVEL_HEADER));
	memset(&Environment, 0, sizeof(LEVEL_ENVIRONMENT));
	memset(&Tools, 0, sizeof(LEVEL_TOOLS));
	memset(&Missions, 0, sizeof(LEVEL_MISSIONS));
	memset(&Camera, 0, sizeof(LEVEL_CAMERA));
	memset(&State, 0, sizeof(LEVEL_STATE));
	SetLevelStandartValues();
	Header.iWidth = iWidthT;
	Header.iHeight = iHeightT;
	Header.fFieldWidth = fFieldWidthT;
	Header.fFieldHeight = fFieldHeightT;
	Header.fFieldDepth = fFieldDepthT;
	Header.iFields = Header.iWidth*Header.iHeight;
	Header.fWholeWidth = (float) Header.iWidth*Header.fFieldWidth;
	Header.fWholeHeight = (float) Header.iHeight*Header.fFieldHeight;
	
	// Create the level vertices:
	Header.iPoints = (Header.iFields+Header.iWidth+Header.iHeight+1)*2;
	fPoint = new FLOAT3[Header.iPoints];
	fColor = new FLOAT4[Header.iPoints];
	i2 = Header.iPoints/2;
	for(i = 0, y = 0; y < Header.iHeight+1; y++)
		for(x = 0; x < Header.iWidth+1; x++, i++)
		{
			if(i >= i2)
			{
				x = Header.iWidth+1;
				y = Header.iHeight+1;
				continue;
			}
			// Front point:
			fPoint[i][X] = (float) x*Header.fFieldWidth;
			fPoint[i][Y] = (float) y*Header.fFieldHeight;
			fPoint[i][Z] = (float) Header.fFieldDepth+STANDART_LEVEL_Z_POS;
			fColor[i][R] = 1.0f;
			fColor[i][G] = 1.0f;
			fColor[i][B] = 1.0f;
			fColor[i][B] = 1.0f;
			fColor[i][A] = 0.9f;
			// Back point:
			fPoint[i2+i][X] = (float) x*Header.fFieldWidth;
			fPoint[i2+i][Y] = (float) y*Header.fFieldHeight;
			fPoint[i2+i][Z] = (float) STANDART_LEVEL_Z_POS;
			fColor[i2+i][R] = 1.0f;
			fColor[i2+i][G] = 1.0f;
			fColor[i2+i][B] = 1.0f;
			fColor[i2+i][A] = 0.9f;
		}

	// Create the fields:
	pField = new FIELD[Header.iFields];
	memset(pField, 0, sizeof(FIELD)*Header.iFields);
	for(i = 0, i3 = 0, y = 0; y < Header.iHeight; y++)
	{
		for(x = 0; x < Header.iWidth; x++, i++, i3++)
		{
			pCurrentField = &pField[i];
			pCurrentField->iXField = x;
			pCurrentField->iYField = y;
			pCurrentField->iXPos = (short) (x*Header.fFieldWidth);
			pCurrentField->iYPos = (short) (y*Header.fFieldHeight);
			pCurrentField->iID = i;
			if(!pSurface)
				for(i4 = 0; i4 < 6; i4++)
					pCurrentField->iSurface[i4][0] = -1;
			else
				for(i4 = 0; i4 < 6; i4++)
					pCurrentField->pSurface[i4][0] = &pSurface[0];
			for(i4 = 0; i4 < 6; i4++)
				pCurrentField->iSurface[i4][1] = -1;
			for(i5 = 0; i5 < 2; i5++)
			{
				for(i4 = 0; i4 < 6; i4++)
					pCurrentField->dwLastTime[i4][i5] = g_lNow;
			}
			
			// Setup the field faces;
			// Front face:
			pCurrentField->iFace[FACE_FRONT][0] = i3+1;
			pCurrentField->iFace[FACE_FRONT][1] = i3+Header.iWidth+2;
			pCurrentField->iFace[FACE_FRONT][2] = i3+Header.iWidth+1;
			pCurrentField->iFace[FACE_FRONT][3] = i3;
			// Floor face:
			pCurrentField->iFace[FACE_FLOOR][0] = i3+1+i2;
			pCurrentField->iFace[FACE_FLOOR][1] = i3+Header.iWidth+2+i2;
			pCurrentField->iFace[FACE_FLOOR][2] = i3+Header.iWidth+1+i2;
			pCurrentField->iFace[FACE_FLOOR][3] = i3+i2;
			// Left face:
			pCurrentField->iFace[FACE_LEFT][0] = i3+Header.iWidth+1;
			pCurrentField->iFace[FACE_LEFT][1] = i3+i2+Header.iWidth+1;
			pCurrentField->iFace[FACE_LEFT][2] = i3+i2;
			pCurrentField->iFace[FACE_LEFT][3] = i3;
			// Right face:
			pCurrentField->iFace[FACE_RIGHT][0] = i3+1;
			pCurrentField->iFace[FACE_RIGHT][1] = i3+i2+1;
			pCurrentField->iFace[FACE_RIGHT][2] = i3+i2+Header.iWidth+2;
			pCurrentField->iFace[FACE_RIGHT][3] = i3+Header.iWidth+2;
			// Top face:
			pCurrentField->iFace[FACE_TOP][0] = i3;
			pCurrentField->iFace[FACE_TOP][1] = i3+i2;
			pCurrentField->iFace[FACE_TOP][2] = i3+i2+1;
			pCurrentField->iFace[FACE_TOP][3] = i3+1;
			// Bottom face:
			pCurrentField->iFace[FACE_BOTTOM][0] = i3+Header.iWidth+2;
			pCurrentField->iFace[FACE_BOTTOM][1] = i3+i2+Header.iWidth+2;
			pCurrentField->iFace[FACE_BOTTOM][2] = i3+i2+Header.iWidth+1;
			pCurrentField->iFace[FACE_BOTTOM][3] = i3+Header.iWidth+1;
			
			// Is this field active?
			if(x != Header.iWidth-1 && y != Header.iHeight-1)
				pCurrentField->bActive = TRUE;
			pCurrentField->bFaceActive[FACE_FLOOR] = TRUE;
			pCurrentField->iCamera = -1;
			pCurrentField->iTextScript = -1;
			pCurrentField->bIndestructibleWall = bIndestructibleWallStandart;
			pCurrentField->fBeamerPower = 1.0f;
			pCurrentField->iBeamerRegenerationSpeed = 100;
			pCurrentField->iBeamerParticleSystemID = -1;
			pCurrentField->iBeamerTarget = -1;
		}
		i3++;
	}

	// Level outline
	for(y = 0; y < Header.iHeight-1; y++)
		SetFieldWall(0, y, TRUE, FALSE);
	for(x = 0; x < Header.iWidth-1; x++)
		SetFieldWall(x, 0, TRUE, FALSE);
	for(y = 0; y < Header.iHeight-1; y++)
		SetFieldWall(Header.iWidth-2, y, TRUE, FALSE);
	for(x = 0; x < Header.iWidth-1; x++)
		SetFieldWall(x, Header.iHeight-2, TRUE, FALSE);
	
	pCurrentField = &pField[0];
	SetStandartView();
	if(!pTexture)
	{
		// Load default texture:
		sprintf(byTemp, "%s\\FieldTemp.jpg", _AS->pbyBitmapsFile);
		LoadTexture(byTemp);

		// Create the default surface:
		CreateSurface();
		strcpy(pCurrentSurface->Header.byName, "Default");
		strcpy(pCurrentSurface->byTextureFilename[0], byTemp);		
		pCurrentSurface->iTextureID[0] = 0;
		pCurrentSurface->pTexture[0] = &pTexture[0];
		pCurrentSurface->pTexturePos->iPos[0][X] = 0;
		pCurrentSurface->pTexturePos->iPos[0][Y] = 0;
		pCurrentSurface->pTexturePos->iPos[1][X] = 64;
		pCurrentSurface->pTexturePos->iPos[1][Y] = 0;
		pCurrentSurface->pTexturePos->iPos[2][X] = 64;
		pCurrentSurface->pTexturePos->iPos[2][Y] = 64;
		pCurrentSurface->pTexturePos->iPos[3][X] = 0;
		pCurrentSurface->pTexturePos->iPos[3][Y] = 64;
		pCurrentSurface->CalculateFloatTexturePos();

		// Set the default surface:
		for(i = 0; i < Header.iFields; i++)
		{
			pCurrentField = &pField[i];
			for(i2 = 0; i2 < 6; i2++)
			{
				pCurrentField->iSurface[i2][0] = 0;
				pCurrentField->pSurface[i2][0] = pCurrentSurface;
				pCurrentSurface->iUsed++;
			}
		}
	}

	// Update level:
	memset(&LevelTempCamera, 0, sizeof(AS_CAMERA));
	Environment.lWaterAniTime = g_lNow;
	CalculateFieldNormals();
	CalculateFieldBoundingBoxes();
} // end LEVEL::Create()

void LEVEL::Destroy(void)
{ // begin LEVEL::Destroy()
	short i;

	if(pField)
	{
		for(i = 0; i < Header.iFields; i++)
		{
			if(!pField[i].pDecoration)
				continue;
			free(pField[i].pDecoration);
		}
		free(pField);
	}
	if(fPoint)
		free(fPoint);
	if(fColor)
		free(fColor);
	if(pSurface)
	{
		for(i = 0; i < Header.iSurfaces; i++)
			pSurface[i].Destroy();
		free(pSurface);
	}
	if(pTexture)
	{
		for(i = 0; i < Header.iTextures; i++)
			if(pTexture[i].pbyData)
				free(pTexture[i].pbyData);
		free(pTexture);
	}
	for(i = 0; i < Header.iCameraScripts; i++)
		free(pCameraScript[i].pCamera);
	free(pCameraScript);
	memset(this, 0, sizeof(LEVEL));
	bCameraAnimation = FALSE;
} // end LEVEL::Destroy()

void LEVEL::SetFieldWall(short x, short y, BOOL bStatus, BOOL bOnlyCheck)
{ // begin LEVEL::SetFieldWall()
	short i, i2;

	if(x < 0 || x > Header.iWidth-2 || y < 0 || y > Header.iHeight-2)
		return;
	i = y*Header.iWidth+x;
	if(!bOnlyCheck)
	{
		if(!pField[i].bWallHole)
			pField[i].bActive = TRUE;
		pField[i].bWall = bStatus;
		if(pField[i].pActor)
		{
			for(i2 = 0; i2 < 6; i2++)
				pField[i].bFaceActive[i2] = FALSE;
		}
		else
		{
			for(i2 = 0; i2 < 6; i2++)
				pField[i].bFaceActive[i2] = bStatus;
		}
		if(pField[i].bWallHole)
			pField[i].bFaceActive[FACE_FRONT] = TRUE;
	}
	else
	{
		if(!pField[i].bActive)
			bStatus = FALSE;
		else
			bStatus = pField[i].bWall;
	}
	// Activate/Deactivate the field sides around this field:
	if(bStatus)
	{ // Check if the sides of the other walls around this are visible:
		pField[i].bFaceActive[FACE_FLOOR] = FALSE;
		if(!pField[i].bWallHole)
		{
			if(x > 0 && pField[i-1].bWall && pField[i-1].bActive && !pField[i-1].pActor)
			{ // Check left wall:
				pField[i-1].bFaceActive[FACE_RIGHT] = FALSE;
				pField[i].bFaceActive[FACE_LEFT] = FALSE;
			}
			if(x < Header.iWidth-1 && pField[i+1].bWall && pField[i+1].bActive && !pField[i+1].pActor)
			{ // Check right wall:
				pField[i+1].bFaceActive[FACE_LEFT] = FALSE;
				pField[i].bFaceActive[FACE_RIGHT] = FALSE;
			}
			if(y > 0 && pField[i-Header.iWidth].bWall && pField[i-Header.iWidth].bActive && !pField[i-Header.iWidth].pActor)
			{ // Check top wall:
				pField[i-Header.iWidth].bFaceActive[FACE_BOTTOM] = FALSE;
				pField[i].bFaceActive[FACE_TOP] = FALSE;
			}
			if(y < Header.iHeight-1 && pField[i+Header.iWidth].bWall && pField[i+Header.iWidth].bActive && !pField[i+Header.iWidth].pActor)
			{ // Check bottom wall:
				pField[i+Header.iWidth].bFaceActive[FACE_TOP] = FALSE;
				pField[i].bFaceActive[FACE_BOTTOM] = FALSE;
			}
		}
		else
		{
			if(!x)
				pField[i].bFaceActive[FACE_LEFT] = FALSE;
			if(x == Header.iWidth-2)
				pField[i].bFaceActive[FACE_RIGHT] = FALSE;
			if(!y)
				pField[i].bFaceActive[FACE_TOP] = FALSE;
			if(y == Header.iHeight-2)
				pField[i].bFaceActive[FACE_BOTTOM] = FALSE;
			if(x > 0 && (!pField[i-1].bActive || pField[i-1].pBridgeActor))
			{ // Check left wall:
				pField[i-1].bFaceActive[FACE_RIGHT] = FALSE;
				pField[i].bFaceActive[FACE_LEFT] = FALSE;
			}
			if(x < Header.iWidth-1 && (!pField[i+1].bActive || pField[i+1].pBridgeActor))
			{ // Check right wall
				pField[i+1].bFaceActive[FACE_LEFT] = FALSE;
				pField[i].bFaceActive[FACE_RIGHT] = FALSE;
			}
			if(y > 0 && (!pField[i-Header.iWidth].bActive || pField[i-Header.iWidth].pBridgeActor))
			{ // Check top wall:
				pField[i-Header.iWidth].bFaceActive[FACE_BOTTOM] = FALSE;
				pField[i].bFaceActive[FACE_TOP] = FALSE;
			}
			if(y < Header.iHeight-1 && (!pField[i+Header.iWidth].bActive || pField[i+Header.iWidth].pBridgeActor))
			{ // Check bottom wall:
				pField[i+Header.iWidth].bFaceActive[FACE_TOP] = FALSE;
				pField[i].bFaceActive[FACE_BOTTOM] = FALSE;
			}
		}
	}
	else
	{ // Check if the sides of the other walls around this are visible:
		pField[i].bFaceActive[FACE_FLOOR] = TRUE;
		if(x > 0 && ((pField[i-1].bActive && pField[i-1].bWall && !pField[i-1].pActor) || pField[i-1].bWallHole))
		{ // Check left wall:
			pField[i-1].bFaceActive[FACE_RIGHT] = TRUE;
		}
		if(x < Header.iWidth-1 && ((pField[i+1].bActive && pField[i+1].bWall && !pField[i+1].pActor) || pField[i+1].bWallHole))
		{ // Check right wall:
			pField[i+1].bFaceActive[FACE_LEFT] = TRUE;
		}
		if(y > 0 && ((pField[i-Header.iWidth].bActive && pField[i-Header.iWidth].bWall && !pField[i-Header.iWidth].pActor) || pField[i-Header.iWidth].bWallHole))
		{ // Check top wall:
			pField[i-Header.iWidth].bFaceActive[FACE_BOTTOM] = TRUE;
		}
		if(y < Header.iHeight-1 && ((pField[i+Header.iWidth].bActive && pField[i+Header.iWidth].bWall && !pField[i+Header.iWidth].pActor) || pField[i+Header.iWidth].bWallHole))
		{ // Check bottom wall:
			pField[i+Header.iWidth].bFaceActive[FACE_TOP] = TRUE;
		}
	}
} // end LEVEL::SetFieldWall()

void LEVEL::CalculateFieldNormals(void)
{ // begin LEVEL::CalculateFieldNormals()
	short i, i2, i3;
	FIELD *pFieldT;

	// Calculate all normals for the fields:
	for(i = 0; i < Header.iFields; i++)
	{
		pFieldT = &pField[i];
		for(i2 = 0; i2 < 6; i2++)
		{
			NormalizeFace(&pFieldT->fNormal[i2][0], fPoint[pFieldT->iFace[i2][0]],
			              fPoint[pFieldT->iFace[i2][1]], fPoint[pFieldT->iFace[i2][2]]);
			NormalizeFace(&pFieldT->fNormal[i2][1], fPoint[pFieldT->iFace[i2][0]],
			              fPoint[pFieldT->iFace[i2][2]], fPoint[pFieldT->iFace[i2][3]]);
			
			// Turn the normals, because the level goes to the negative space:
			for(i3 = 0; i3 < 3; i3++)
			{
				pFieldT->fNormal[i2][0][i3] = -pFieldT->fNormal[i2][0][i3];
				pFieldT->fNormal[i2][1][i3] = -pFieldT->fNormal[i2][1][i3];
			}
		}
	}
} // end LEVEL::CalculateFieldNormals()

void LEVEL::CalculateFieldBoundingBoxes(void)
{ // begin LEVEL::CalculateFieldBoundingBoxes()
	short i, i2, i3, i4;
	FLOAT3 *pfPointT;
	FIELD *pFieldT;

	// Calculate the field bounding boxes: (for frustum culling)
	// This technique is not the best, but it is good and fast enought for this game world:
	for(i = 0; i < Header.iFields; i++)
	{
		pFieldT = &pField[i];
		// Setup:
		for(i2 = 0; i2 < 3; i2++)
		{
			pFieldT->fBoundingBox[0][i2] = Header.iWidth*Header.fFieldWidth+Header.iHeight*Header.fFieldHeight;
			pFieldT->fBoundingBox[1][i2] = STANDART_LEVEL_Z_POS;
		}
		// Check:
		for(i2 = 0; i2 < 6; i2++)
		{ // Go through each field side:
			for(i3 = 0; i3 < 4; i3++)
			{ // Go through each point of this field side:
				pfPointT = &fPoint[pFieldT->iFace[i2][i3]];
				// Check now each coordinate:
				for(i4 = 0; i4 < 3; i4++)
				{
					if((*pfPointT)[i4] < pFieldT->fBoundingBox[0][i4])
						pFieldT->fBoundingBox[0][i4] = (*pfPointT)[i4];
					if((*pfPointT)[i4] > pFieldT->fBoundingBox[1][i4])
						pFieldT->fBoundingBox[1][i4] = (*pfPointT)[i4];
				}
			}
		}
		// Setup stuff for culling:
		pFieldT->fBoundingBoxX = (pFieldT->fBoundingBox[1][X]+pFieldT->fBoundingBox[0][X])/2;
		pFieldT->fBoundingBoxY = (pFieldT->fBoundingBox[1][Y]+pFieldT->fBoundingBox[0][Y])/2;
		pFieldT->fBoundingBoxZ = (pFieldT->fBoundingBox[0][Z]+pFieldT->fBoundingBox[1][Z])/2;
		// Calculate bounding box size: (cube):
		pFieldT->fBoundingBoxSize = (pFieldT->fBoundingBox[1][X]-pFieldT->fBoundingBox[0][X]);
		if((pFieldT->fBoundingBox[1][Y]-pFieldT->fBoundingBox[0][Y]) > pFieldT->fBoundingBoxSize)
			pFieldT->fBoundingBoxSize = (pFieldT->fBoundingBox[1][Y]-pFieldT->fBoundingBox[0][Y]);
		// '-' Because our world z goes into the negative space:
		if(-(pFieldT->fBoundingBox[0][Z]-pFieldT->fBoundingBox[1][Z]) > pFieldT->fBoundingBoxSize)
			pFieldT->fBoundingBoxSize = (pFieldT->fBoundingBox[0][Z]-pFieldT->fBoundingBox[1][Z]);
		pFieldT->fBoundingBoxSize /= 2;
		if(pFieldT->fBoundingBoxSize < 0.0f)
			pFieldT->fBoundingBoxSize *= -1;
	}
} // end LEVEL::CalculateFieldBoundingBoxes()

void LEVEL::SetStandartView(void)
{ // begin LEVEL::SetStandartView()
	memset(pCamera, 0, sizeof(AS_CAMERA));
	pCamera->fPos[X] = -Header.fWholeWidth/2;
	pCamera->fPos[Y] = -Header.fWholeHeight/2;
	pCamera->fPos[Z] = -15.0f+STANDART_LEVEL_Z_POS;
	pCamera->fZ = -10.0f;
} // end LEVEL::SetStandartView()

BOOL CheckTriangleCollision(AS_VECTOR StartPoint, AS_VECTOR RayDirection, AS_VECTOR *pIntersectionPoint,
							FLOAT3 Point1, FLOAT3 Point2, FLOAT3 Point3, FLOAT3 Normal)
{ // begin CheckTriangleCollision()
	AS_VECTOR p1, p2, p3, // The current triangle
			  v1, v2, // The distances between the triangle points
			  pNormal, // The normal of the triangle
			  pOrigin; // The trianlges origin
	double fDistToPlaneIntersection; // The distance from the ray start point to the triangle

	p1.x = Point1[X];
	p1.y = Point1[Y];
	p1.z = Point1[Z];

	p2.x = Point2[X];
	p2.y = Point2[Y];
	p2.z = Point2[Z];

	p3.x = Point3[X];
	p3.y = Point3[Y];
	p3.z = Point3[Z];

	// Get the triangle normal:
	pNormal.x = Normal[X];
	pNormal.y = Normal[Y];
	pNormal.z = Normal[Z];

	// Make the plane containing this triangle:
	pOrigin = p1;
	v1 = p2-p1;
	v2 = p3-p1;

	// Shoot ray along the velocity vector:
	fDistToPlaneIntersection = ASIntersectRayPlane(StartPoint, RayDirection, pOrigin, pNormal);

	// Calculate plane intersection point:
	(*pIntersectionPoint).x = (float) (StartPoint.x+fDistToPlaneIntersection*RayDirection.x);
	(*pIntersectionPoint).y = (float) (StartPoint.y+fDistToPlaneIntersection*RayDirection.y);
	(*pIntersectionPoint).z = (float) (StartPoint.z+fDistToPlaneIntersection*RayDirection.z);

	if(((*pIntersectionPoint).z < p1.z &&
	   (*pIntersectionPoint).z < p2.z &&
	   (*pIntersectionPoint).z < p3.z) ||
	   ((*pIntersectionPoint).z > p1.z &&
	    (*pIntersectionPoint).z > p2.z &&
	    (*pIntersectionPoint).z > p3.z))
		return 0; // There is something wrong!?!

	// Check if the intersection point is in the triangle:
	if(!ASCheckPointInTriangle(*pIntersectionPoint, p1, p2, p3))
		return 0; // It's not in the triangle!
	return 1; // It's in the triangle!
} // end CheckTriangleCollision()

FIELD *LEVEL::ComputeHeight(float fX, float fY, FLOAT3 fRayDirection, FLOAT3 *pfPoint, char bySide, float fSize)
{ // begin LEVEL::ComputeHeight()
	AS_VECTOR StartPoint, // The ray start point
			  RayDirection, // The ray direction (normalized)
			  pIntersectionPoint; // The found triangle intersection point
	short i, iXPos, iYPos, // Counter variables
		  iXFieldPos, iYFieldPos, // Field x/y position in the level matrix
		  iFieldID; // The field ID
	FLOAT3 fPoint1, fPoint2, fPoint3, fPoint4, fNormal;
	FIELD *pFieldT; // A pointer to the current field:
	ACTOR *pActorT;

	// Check if this is a correct point:
	if(fX < 0.0f || fY < 0.0f ||
	   fX >= Header.fWholeWidth || fY >= Header.fWholeHeight)
		return NULL;

	// Set the start point of the ray:
	(*pfPoint)[X] = StartPoint.x = fX;
	(*pfPoint)[Y] = StartPoint.y = fY;
	(*pfPoint)[Z] = StartPoint.z = 0.0f;

	// Set the ray direction:
	RayDirection.x = fRayDirection[X];
	RayDirection.y = fRayDirection[Y];
	RayDirection.z = fRayDirection[Z];

	// Compute the current field the given point is on:
	COMPUTE_FIELD_POS(fX, fY, iXFieldPos, iYFieldPos);

	// Check the field and the fields around:
	for(iYPos = iYFieldPos-1; iYPos < iYFieldPos+3; iYPos++)
	{
		// Check if this coordinate is a correct one:
		if(iYPos < 0 || iYPos > Header.iHeight-2)
			continue; // No correct field!
		for(iXPos = iXFieldPos-1; iXPos < iXFieldPos+3; iXPos++)
		{
			// Check if this coordinate is a correct one:
			if(iXPos < 0 || iXPos > Header.iWidth-2)
				continue; // No correct field!

			// Get a pointer to this field:
			GET_FIELD_ID(iXPos, iYPos, iFieldID);
			pFieldT = &pLevel->pField[iFieldID];
			if(((!pFieldT->bFaceActive[bySide] && bySide != FACE_FLOOR) ||
			    (bySide != FACE_FLOOR && !pFieldT->bWall) ||
			    !pFieldT->bActive) && !pFieldT->pBridgeActor)
				continue;
			// Check the terrain:
			if(!pFieldT->pBridgeActor || pFieldT->pBridgeActor->bBridgeMovement)
			{
				for(i = 0; i < 2; i++)
				{
					if(CheckTriangleCollision(StartPoint, RayDirection, &pIntersectionPoint,
											  pLevel->fPoint[pFieldT->iFace[bySide][0]],
											  pLevel->fPoint[pFieldT->iFace[bySide][1+i]],
											  pLevel->fPoint[pFieldT->iFace[bySide][2+i]],
											  pFieldT->fNormal[bySide][i]))
					{
						if((*pfPoint)[Z] >= pIntersectionPoint.z &&
						   pIntersectionPoint.x > fX-fSize &&
						   pIntersectionPoint.y > fY-fSize &&
						   pIntersectionPoint.x < fX+fSize &&
						   pIntersectionPoint.y < fY+fSize)
						{
							(*pfPoint)[X] = pIntersectionPoint.x;
							(*pfPoint)[Y] = pIntersectionPoint.y;
							(*pfPoint)[Z] = pIntersectionPoint.z;
							return pFieldT;
						}
					}
				}
			}
			pActorT = pFieldT->pBridgeActor;
			if(pActorT)
				pActorT = pActorT;
			if(pActorT && !pActorT->bBridgeMovement)
			{ // There is a bridge, check it too:
				fPoint1[X] = pActorT->fWorldPos[X];
				fPoint1[Y] = pActorT->fWorldPos[Y];
				fPoint1[Z] = pActorT->fWorldPos[Z]-1.0f;

				fPoint2[X] = pActorT->fWorldPos[X]+1.0f;
				fPoint2[Y] = pActorT->fWorldPos[Y];
				fPoint2[Z] = pActorT->fWorldPos[Z]-1.0f;

				fPoint3[X] = pActorT->fWorldPos[X]+1.0f;
				fPoint3[Y] = pActorT->fWorldPos[Y]+1.0f;
				fPoint3[Z] = pActorT->fWorldPos[Z]-1.0f;

				fPoint4[X] = pActorT->fWorldPos[X];
				fPoint4[Y] = pActorT->fWorldPos[Y]+1.0f;
				fPoint4[Z] = pActorT->fWorldPos[Z]-1.0f;

				fNormal[X] = 0.0f;
				fNormal[Y] = 0.0f;
				fNormal[Z] = -1.0f;

				if(CheckTriangleCollision(StartPoint, RayDirection, &pIntersectionPoint,
									      fPoint1, fPoint2, fPoint3, fNormal) ||
				   CheckTriangleCollision(StartPoint, RayDirection, &pIntersectionPoint,
									      fPoint1, fPoint3, fPoint4, fNormal))
				{
					if((*pfPoint)[Z] > pIntersectionPoint.z)
					{
						(*pfPoint)[X] = pIntersectionPoint.x;
						(*pfPoint)[Y] = pIntersectionPoint.y;
						(*pfPoint)[Z] = pIntersectionPoint.z;
						return pFieldT;
					}
				}
			}
		}
	}
	
	// No collision:
	(*pfPoint)[X] = StartPoint.x = fX;
	(*pfPoint)[Y] = StartPoint.y = fY;
	(*pfPoint)[Z] = StartPoint.z = STANDART_LEVEL_Z_POS;
	return NULL;
} // end LEVEL::ComputeHeight()

float LEVEL::FastComputeHeight(float fX, float fY, char bySide)
{ // begin LEVEL::FastComputeHeight()
	short iXFieldPos, iYFieldPos, iFieldID;
	float fFieldXPos, fFieldYPos,
	      fHeight, fLeftFieldHeight, fRightFieldHeight;
	FIELD *pFieldT;
	FLOAT3 pLTPoint, pRTPoint, pRBPoint, pLBPoint;

	if(fX < 0.0f || fY < 0.0f ||
	   fX >= pLevel->Header.fWholeWidth || fY >= pLevel->Header.fWholeHeight)
		return -1.0f;
	// Compute the current field we are on:
	COMPUTE_FIELD_POS(fX, fY, iXFieldPos, iYFieldPos);
	// Get a pointer to this field:
	GET_FIELD_ID(iXFieldPos, iYFieldPos, iFieldID);
	pFieldT = &pLevel->pField[iFieldID];
	// Get a pointer to the field points:
	memcpy(&pLTPoint, pLevel->fPoint[pFieldT->iFace[bySide][3]], sizeof(FLOAT3));
	memcpy(&pRTPoint, pLevel->fPoint[pFieldT->iFace[bySide][0]], sizeof(FLOAT3));
	memcpy(&pRBPoint, pLevel->fPoint[pFieldT->iFace[bySide][1]], sizeof(FLOAT3));
	memcpy(&pLBPoint, pLevel->fPoint[pFieldT->iFace[bySide][2]], sizeof(FLOAT3));
	// Compute the x and y pos in the field:
	fFieldXPos = pLevel->Header.fFieldWidth-(fX-iXFieldPos*pLevel->Header.fFieldWidth);
	fFieldYPos = (fY-iYFieldPos*pLevel->Header.fFieldHeight);
	// Now compute the heigt on this field position:
	// First we compute the left and right field height on this field y pos:
	if(!(pLBPoint[Z]-pLTPoint[Z]))
		fLeftFieldHeight = pLTPoint[Z];
	else
		fLeftFieldHeight = pLTPoint[Z]+(pLBPoint[Z]-pLTPoint[Z])/(pLBPoint[Y]-pLTPoint[Y])*fFieldYPos;
	if(!(pRBPoint[Z]-pRTPoint[Z]))
		fRightFieldHeight = pRTPoint[Z];
	else
		fRightFieldHeight = pRTPoint[Z]+(pRBPoint[Z]-pRTPoint[Z])/(pRBPoint[Y]-pRTPoint[Y])*fFieldYPos;
	// Compute now the hight on the x positon on the field:
	if(!(fLeftFieldHeight-fRightFieldHeight))
		fHeight = fLeftFieldHeight;
	else
		fHeight = fRightFieldHeight+(fLeftFieldHeight-fRightFieldHeight)/(pRTPoint[X]-pLTPoint[X])*fFieldXPos;
	// Yea, we calculated the corresponding height of this x and y position in the level,
	// give the height back;
	return fHeight;
} // end LEVEL::FastComputeHeight()

BOOL LEVEL::GetWall(float fX, float fY)
{ // begin LEVEL::GetWall()
	short iXFieldPos, iYFieldPos;

	COMPUTE_FIELD_POS(fX, fY, iXFieldPos, iYFieldPos);
	if(iXFieldPos < 0 || iYFieldPos < 0 || iXFieldPos >= Header.iWidth ||
		iYFieldPos >= Header.iHeight)
		return 0;
	return pField[iYFieldPos*Header.iWidth+iXFieldPos].bWall;
} // end LEVEL::GetWall()

void LEVEL::UpdateMissions(void)
{ // begin LEVEL::UpdateMissions()
	short i;
	
	Header.iPointsObj = Header.iNormalBoxes = Header.iRedBoxes = Header.iGreenBoxes = Header.iBlueBoxes =
	Header.iForAllAnchors = Header.iNormalAnchors = Header.iRedAnchors = Header.iGreenAnchors =
	Header.iBlueAnchors = Header.iMobmobs = Header.iX3 = 0;
	for(i = 0; i < Header.iFields; i++)
	{
		if((pField[i].bWall && !pField[i].pActor) || !pField[i].bActive)
			continue; // This is a wrong mission target!!
		if(pSurface[pField[i].iSurface[FACE_FLOOR][0]].Header.bAnchor)
		{
			switch(pSurface[pField[i].iSurface[FACE_FLOOR][0]].Header.byAnchorType)
			{
				case 0: Header.iForAllAnchors++; break;
				case 1: Header.iNormalAnchors++; break;
				case 2: Header.iRedAnchors++; break;
				case 3: Header.iGreenAnchors++; break;
				case 4: Header.iBlueAnchors++; break;
			}
		}
	}
	for(i = 0; i < MAX_ACTORS; i++)
	{
		if(!Actor[i].bActive)
			continue;
		switch(Actor[i].byType)
		{
			case ACTOR_BOX_NORMAL: Header.iNormalBoxes++; break;
			case ACTOR_BOX_RED: Header.iRedBoxes++; break;
			case ACTOR_BOX_GREEN: Header.iGreenBoxes++; break;
			case ACTOR_BOX_BLUE: Header.iBlueBoxes++; break;
			case ACTOR_POINT_OBJ: Header.iPointsObj++; break;
			case ACTOR_ENEMY_MOBMOB: Header.iMobmobs++; break;
			case ACTOR_ENEMY_X3: Header.iX3++; break;
		}
	}
} // end LEVEL::UpdateMissions()

// Functions: *****************************************************************
void CreateLevel(LEVEL **pLevel)
{ // begin CreateLevel()
} // end CreateLevel()

void DestroyLevel(LEVEL **pLevel)
{ // begin DestroyLevel()
	short i;
	
	if(pTextScript)
	{
		for(i = 0; i < (*pLevel)->TextScriptsManager.iTextsScripts; i++)
			if(pTextScript[i].pText)
				free(pTextScript[i].pText);
		free(pTextScript);
		pTextScript = NULL;
	}
	DestroyTextScriptSource();
	DestroyAllDecorations();
	(*pLevel)->Destroy();
	delete *pLevel;
	*pLevel = NULL;
} // end DestroyLevel()

BOOL GetLevelKeyword(char *pbyFilename, char *pbyKeyword)
{ // begin GetLevelKeyword()
	LEVEL_HEADER Header;
	short iVersion;
	FILE *fp;

	// Open the level:
	if(!pbyFilename)
		return 0;
	fp = fopen(pbyFilename, "rb");
	if(!fp)
		return 0;

	// First, check if this is an correct level version:
	fread(&iVersion, sizeof(short), 1, fp);
	if(iVersion != LEVEL_VERSION)
	{ // This is an wrong level version!!
		_AS->WriteLogMessage("The level version(%d) is not correct! Couldn't load this level!", iVersion);	
		return 0;
	}

	// Load the general level information:
	fread(&Header, sizeof(LEVEL_HEADER), 1, fp);

	// Check the keyword:
	if(Header.bKeyword)
	{ // Give the keyword back:
		strcpy(pbyKeyword, Header.byKeyword);
		return 1;
	}
	return 0;
} // end GetLevelKeyword()

char GetLevelSingle(char *pbyFilename)
{ // begin GetLevelSingle()
	LEVEL_HEADER Header;
	short iVersion;
	FILE *fp;

	// Open the level:
	if(!pbyFilename)
		return 0;
	fp = fopen(pbyFilename, "rb");
	if(!fp)
		return 0;

	// First, check if this is an correct level version:
	fread(&iVersion, sizeof(short), 1, fp);
	if(iVersion != LEVEL_VERSION)
	{ // This is an wrong level version!!
		_AS->WriteLogMessage("The level version(%d) is not correct! Couldn't load this level!", iVersion);	
		return -1;
	}

	// Load the general level information:
	fread(&Header, sizeof(LEVEL_HEADER), 1, fp);

	return Header.bSingle;
} // end GetLevelSingle()

void GetLevelName(char *pbyFilename, char *pbyName)
{ // begin GetLevelName()
	LEVEL_HEADER Header;
	short iVersion;
	FILE *fp;

	// Open the level:
	if(!pbyFilename)
		return;
	fp = fopen(pbyFilename, "rb");
	if(!fp)
		return;

	// First, check if this is an correct level version:
	fread(&iVersion, sizeof(short), 1, fp);
	if(iVersion != LEVEL_VERSION)
	{ // This is an wrong level version!!
		_AS->WriteLogMessage("The level version(%d) is not correct! Couldn't load this level!", iVersion);	
		return;
	}

	// Load the general level information:
	fread(&Header, sizeof(LEVEL_HEADER), 1, fp);

	strcpy(pbyName, Header.byName);
} // end GetLevelName()

void GetLevelFileName(char *byCompleteName, char *byName)
{ // begin GetLevelFileName()
	short i, i2;

	for(i = strlen(byCompleteName)-1, i2 = 0; ; i--, i2++)
	{
		if(byCompleteName[i] == '\\')
			break;
		byName[i2] = byCompleteName[i];
	}
	byName[i2] = '\0';
	strcpy(byName, _strrev(byName));
} // end GetLevelFileName()

void StartLevel(char *pbyFilename, BOOL bInitPlayerInfo)
{ // begin StartLevel()
	char byOldMusic[256];
	short iX, iY;
	int i;

	bGameOver = FALSE;
	byGameMenuSelected = 0;
	// Player game init settings:
	if(bInitPlayerInfo)
	{
		memset(&PlayerInfo, 0, sizeof(PLAYER_INFO));
		PlayerInfo.iForce = 1;
	}
	bPlayerCameraView = FALSE;
	if(pLevel) // Backup the old music file:
		strcpy(byOldMusic, pLevel->Header.byMusicFile);	

	// Destroy the old level:
	if(pLevel)
		DestroyLevel();

	DestroyGameParticleSystems();
	InitGameParticleSystems();

	// Setup the new level:
	pLevel = new LEVEL;

	// Load the level:
	pLevel->Load(pbyFilename);
	pLevel->GenTexturesOpenGL(*_AS->pWindow[GAME_WINDOW_ID].GethDC(), 
							  *_AS->pWindow[GAME_WINDOW_ID].GethRC());

	// Compare if this music is still running:
	if(strcmp(byOldMusic, pLevel->Header.byMusicFile) && pLevel->Header.bMusic)
	{ // Nope, start the new level music:	
		ASDXShowClose();
		StartLevelMusic();
	}
	else
		if(!pLevel->Header.bMusic)
			ASDXShowClose();

	pLevel->State.bLevelComplete = FALSE;
	if(pPlayer->bActive)
		SetPlayerToCheckpoint();
	else
	{ // Set the player per random into the level:
		for(i = 0; i < pLevel->Header.iFields*10; i++)
		{
			iX = rand() % (pLevel->Header.iWidth-1);
			iY = rand() % (pLevel->Header.iHeight-1);
			if(!pLevel->pField[iY*pLevel->Header.iWidth+iX].bActive ||
			   pLevel->pField[iY*pLevel->Header.iWidth+iX].bWall ||
			   pLevel->pField[iY*pLevel->Header.iWidth+iX].pActor)
				continue; // No good start position!!
			pPlayer->iFieldPos[X] = iX;
			pPlayer->iFieldPos[Y] = iY;
			GET_FIELD_ID(iX, iY, pPlayer->iFieldID);
			pPlayer->bActive = TRUE;
			pPlayer->byType = ACTOR_PLAYER;
			pPlayer->fColor[0] = 1.0f;
			pPlayer->fColor[1] = 1.0f;
			pPlayer->fColor[2] = 1.0f;
			pLevel->pField[pPlayer->iFieldID].pActor = pPlayer;
			PlayerInfo.iCheckpointFieldID = pPlayer->iFieldID;
		}
	}

	// Initalize some other stuff:
	g_lNow = lGameTimer = GetTickCount();
	g_lLastlooptime = g_lNow;
	SetCursorPos(X_MOUSE_SCREEN_POS, Y_MOUSE_SCREEN_POS);
	bPause = bLevelPressAnyKey = FALSE;
	fSmallMessageBlend = 0.0f;
	fPauseBlend	= 1.0f;
	fPauseTextBlend	= 1.0f;
	iPauseBlendSpeed = 5000;
	InitDisplayActors();
	OktaActor.bActive = FALSE;
	pPlayer->bGoingDeath2 = FALSE;

	// Camera:
	pLevel->Camera.iCurrentCameraStep = 0;
	lCameraTimer = g_lNow;
	bCameraAnimation = pLevel->Camera.bStartCamera;
	memset(&TempCamera, 0, sizeof(AS_CAMERA));
	if(pLevel->Camera.bStartCamera && pLevel->Header.iCameraScripts)
	{
		pLevel->pCurrentCameraScript = &pLevel->pCameraScript[pLevel->Camera.iStartCamera];
		if(pLevel->pCurrentCameraScript->iTextScript != -1)
			PlayTextScript(pLevel->pCurrentCameraScript->iTextScript);
	}
	for(i = 0; i < 256; i++)
		ASKeys[i] = 0;

	if(!bEditorTestLevel)
	{	// Setup the current player stuff:
		PlayerInfo.iPoints += PlayerIdentity.iPoints[PlayerIdentity.iSelectedLevel-1];
		PlayerInfo.iLives += PlayerIdentity.iLives[PlayerIdentity.iSelectedLevel-1];
		pPlayer->fPower += PlayerIdentity.fPower[PlayerIdentity.iSelectedLevel-1];
	}
	else
	{
		pPlayer->fPower += 100.0f;
		PlayerInfo.iLives += 3;
	}
	for(i = 0; i < 256; i++)
	{
		ASKeyFirst[i] = FALSE;
		ASKeyPressed[i] = TRUE;
	}
} // end StartLevel()

void StartCurrentLevel(void)
{ // begin StartCurrentLevel()
	fGameMenuBlend = 1.f;
	byGameMenuMenu = 0;
	DestroyAutosave();
	// Start the level:
	if(!bEditorTestLevel)
	{
		if(!bSingleLevel)
			sprintf(byCurrentLevelName, "%s%s", _AS->pbyProgramPath, CurrentCampaign.byLevelFilename[PlayerIdentity.iSelectedLevel-1]);
		else
			sprintf(byCurrentLevelName, "%s%s\\%s", _AS->pbyProgramPath, _AS->pbySingleLevelsFile, bySelectedSingleLevel);
	}
	else
		bSingleLevel = TRUE;
	StartLevel(byCurrentLevelName, TRUE);
	SaveAutosave();
	lKeyTimer = g_lNow = g_lLastlooptime = GetTickCount();
} // end StartCurrentLevel()

void StartLevelMusic(void)
{ // begin StartLevelMusic()
	char byTemp[256];

	sprintf(byTemp, "%s%s", _AS->pbyProgramPath, pLevel->Header.byMusicFile);
	_AS->WriteLogMessage("Load music: %s", byTemp);
	ASDXShowPlay(byTemp, *_AS->pWindow[GAME_WINDOW_ID].GethWnd());
} // end StartLevelMusic()

void DestroyLevel(void)
{ // begin DestroyLevel()
	pLevel->DestroyTexturesOpenGL(*_AS->pWindow[GAME_WINDOW_ID].GethDC(), 
								  *_AS->pWindow[GAME_WINDOW_ID].GethRC());
	DestroyLevel(&pLevel);
} // end DestroyLevel()
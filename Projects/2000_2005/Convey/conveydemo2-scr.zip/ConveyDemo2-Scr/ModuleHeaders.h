//-----------------------------------------------------------------------------
// File: ModuleHeaders.h
//-----------------------------------------------------------------------------

#ifndef __MODULE_HEADRES_H__
#define __MODULE_HEADRES_H__


// Includes: ******************************************************************
#include "Convey.h"
#include "Missions.h"
#include "Campaign.h"
#include "Player.h"
#include "Surface.h"
#include "TextScripts.h"
#include "Decoration.h"
#include "Level.h"
#include "LevelDraw.h"
#include "LevelDialogs.h"
#include "Game.h"
#include "GameMenu.h"
#include "Pathfinding.h"
#include "Enemies.h"
#include "Editor.h"
#include "WindowProc.h"
#include "Logos.h"
///////////////////////////////////////////////////////////////////////////////


#endif // __MODULE_HEADRES_H__
//-----------------------------------------------------------------------------
// File: GameMenu.h
//-----------------------------------------------------------------------------

#ifndef __GAME_MENU_H__
#define __GAME_MENU_H__


// Definitions: ***************************************************************
#define GAME_MENU_TEXTURES 3
#define MENU_POINTS 35
///////////////////////////////////////////////////////////////////////////////

// Structures: ****************************************************************
typedef struct MENU_POINT
{
	BOOL bSelected; // Is this menu point current selected?
	float fSize; // The size of the text
	BOOL bSize; // For the size animation
	FLOAT3 fColor; // The text color
} MENU_POINT;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern BOOL bInGameMenu;
extern AS_TEXTURE GameMenuTexture[GAME_MENU_TEXTURES];
extern char byGameMenuSelected, byGameMenuMenu, byLastGameMenuMenu;
extern float fFontAni[4][2], fSelectedSize;
extern DWORD dwMainMenuStartTime;
extern BOOL bSelectedSize;
extern float fGameMenuBlend;
extern MENU_POINT MenuPoint[MENU_POINTS];
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern HRESULT GameMenuLoop(void);
extern void StartMenuMusic(void);
extern HRESULT GameMenuDraw(AS_WINDOW *);
extern void ShowOptionMenu(AS_WINDOW *);
extern HRESULT GameMenuCheck(AS_WINDOW *);
extern void CheckDeletePlayerID(void);
extern void CheckOptionMenu(void);
extern void AnimateFont(void);
extern void InitMenuPoints(void);
extern void CheckMenuPoints(void);
///////////////////////////////////////////////////////////////////////////////


#endif // __GAME_MENU_H__
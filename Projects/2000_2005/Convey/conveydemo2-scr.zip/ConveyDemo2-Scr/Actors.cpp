//-----------------------------------------------------------------------------
// File: Actors.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"



// Variables: *****************************************************************
ACTOR Actor[MAX_ACTORS];
extern char byWeaponAni;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
ACTOR *FindFreeActor(void);
short SortActors(ACTOR *);
void ComputeActorHeight(ACTOR *, float);
void SetActorsLights(void);
void MoveActor(ACTOR *, short);
void UpdateAllActorFields(void);
void CheckActorField(ACTOR *);
void DrawEffects(void);
void DrawActors(void);
void CheckActors(BOOL, float);
void AnimateActorModel(ACTOR *, AS_MD2_MODEL, long, char);
void KillBox(ACTOR *);
void CheckBoxThrow(ACTOR *);
void DamageBox(ACTOR *);
void DrawBoundingBox(float [2][3], float);
void DisableBoxDocking(ACTOR *);
void DeleteActorType(ACTOR *);
void DisableNoneFreeBox(ACTOR *);
void SetNoneFreeBox(ACTOR *);
BOOL ActorTurn(ACTOR *);
BOOL CheckBeaming(ACTOR *);
BOOL CheckBeamingProcess(ACTOR *);
///////////////////////////////////////////////////////////////////////////////

// ACTOR functions: ***********************************************************
ACTOR::ACTOR(void)
{ // begin ACTOR()
	memset(this, 0, sizeof(ACTOR));
	iParticleSystemID = -1;
} // end ACTOR()

ACTOR::~ACTOR(void)
{ // begin ~ACTOR()
} // end ~ACTOR()

void ACTOR::Init(void)
{ // begin Init()
	memset(this, 0, sizeof(ACTOR));
	iParticleSystemID = -1;
} // end Init()
///////////////////////////////////////////////////////////////////////////////


ACTOR *FindFreeActor(void)
{ // begin FindFreeActor()
	ACTOR *pActorT;

	// Find a none active actor and give a pointer to it back:
	for(short i = 0; i < MAX_ACTORS; i++)
	{
		pActorT = &Actor[i];
		if(pActorT->bActive)
			continue;
		memset(pActorT, 0, sizeof(ACTOR));	
		pActorT->iID = i;
		pActorT->dwAniTime = g_lNow;
		pActorT->fColor[0] = 1.0f;
		pActorT->fColor[1] = 1.0f;
		pActorT->fColor[2] = 1.0f;
		pActorT->fAir = 1.0f;
		pActorT->iTempFieldID = -1;
		pActorT->iParticleSystemID = -1;
		return pActorT;
	}
	return 0;
} // end FindFreeActor()

short SortActors(ACTOR *ActorT)
{ // begin SortActors()
	short i, i2;
	
	// Sort all actors that all active are on the top, and
	// give the number of active actors back:
	memset(ActorT, 0, sizeof(ACTOR)*MAX_ACTORS);
	for(i = 0, i2 = 0; i < MAX_ACTORS; i++)
	{
		if(!Actor[i].bActive)
			continue;
		memcpy(&ActorT[i2], &Actor[i], sizeof(ACTOR));
		ActorT[i2].iID = i2;
		i2++;
	}
	return i2;
} // end SortActors()

void ComputeActorHeight(ACTOR *pActorT, float fSize)
{ // begin ComputeActorHeight()
	short iXPos, iYPos, iXFieldPos, iYFieldPos, i, iFieldID, iNoField = 0;
	FIELD *pFieldT;
	FLOAT3 fPoint;
	FLOAT3 fRayDirection;
	
	fSize -= 0.01f; // To avoid a null problem...
	if(pActorT->byType == ACTOR_PLAYER && !pLevel->pField[pActorT->iFieldID].bActive);
	else
	if(pActorT->bGoingDeath2 || pActorT->bDocked ||
	  (pActorT->fWorldPos[X] == pActorT->fLastHeightCheckWorldPos[X] &&
	   pActorT->fWorldPos[Y] == pActorT->fLastHeightCheckWorldPos[Y] &&
	   pActorT->fWorldPos[Z] == pActorT->fLastHeightCheckWorldPos[Z]))
	{
		if(!pActorT->bMove)
			return;
	}

	// Update the last check pos: (we only have to check if the position has changed)
	pActorT->fLastHeightCheckWorldPos[X] = pActorT->fWorldPos[X];
	pActorT->fLastHeightCheckWorldPos[Y] = pActorT->fWorldPos[Y];
	pActorT->fLastHeightCheckWorldPos[Z] = pActorT->fWorldPos[Z];

	// Ray direction for the 'normal' test points:
	fRayDirection[X] = 0.0f;
	fRayDirection[Y] = 0.0f;
	fRayDirection[Z] = 1.0f;

	fPoint[X] = fPoint[Y] = 0.0f;
	fPoint[Z] = pActorT->fWorldPos[Z];

	pActorT->fFriction = 1.0f;
	// Get the height of the center:
	pFieldT = pLevel->ComputeHeight(pActorT->fWorldPos[X]+0.5f, pActorT->fWorldPos[Y]+0.5f, fRayDirection, &fPoint, FACE_FLOOR, fSize);
	if(!pFieldT)
		iNoField++;
	if(pActorT->byAction != ACTION_JUMP && pFieldT)
	{
		if(!pActorT->fVelocity[Z])
			pActorT->fWorldPos[Z] = fPoint[Z];
		else
		{
			if(pActorT->fWorldPos[Z] >= fPoint[Z] && !pActorT->bGoingDeath)
			{
				pActorT->fWorldPos[Z] = fPoint[Z];
				pActorT->fVelocity[Z] = 0.0f;
			}
		}
	}
	if(pFieldT)
		pActorT->fFriction = pFieldT->pSurface[FACE_FLOOR][0]->Header.fFriction;

	// The four points around the floor:
	pFieldT = pLevel->ComputeHeight(pActorT->fWorldPos[X]+0.5f-fSize, pActorT->fWorldPos[Y]+0.5f-fSize, fRayDirection, &fPoint, FACE_FLOOR, fSize);
	if(!pFieldT)
		iNoField++;
	if(pActorT->fWorldPos[Z] > fPoint[Z])
	{
		pActorT->fWorldPos[Z] = fPoint[Z];	
		pActorT->fVelocity[Z] = 0.0f;
		if(pFieldT)
			pActorT->fFriction = pFieldT->pSurface[FACE_FLOOR][0]->Header.fFriction;
	}
	pFieldT = pLevel->ComputeHeight(pActorT->fWorldPos[X]+0.5f+fSize, pActorT->fWorldPos[Y]+0.5f-fSize, fRayDirection, &fPoint, FACE_FLOOR, fSize);
	if(!pFieldT)
		iNoField++;
	if(pActorT->fWorldPos[Z] > fPoint[Z])
	{
		pActorT->fWorldPos[Z] = fPoint[Z];
		pActorT->fVelocity[Z] = 0.0f;
		if(pFieldT)
			pActorT->fFriction = pFieldT->pSurface[FACE_FLOOR][0]->Header.fFriction;
	}
	pFieldT = pLevel->ComputeHeight(pActorT->fWorldPos[X]+0.5f+fSize, pActorT->fWorldPos[Y]+0.5f+fSize, fRayDirection, &fPoint, FACE_FLOOR, fSize);
	if(!pFieldT)
		iNoField++;
	if(pActorT->fWorldPos[Z] > fPoint[Z])
	{
		pActorT->fWorldPos[Z] = fPoint[Z];
		pActorT->fVelocity[Z] = 0.0f;
		if(pFieldT)
			pActorT->fFriction = pFieldT->pSurface[FACE_FLOOR][0]->Header.fFriction;
	}
	pFieldT = pLevel->ComputeHeight(pActorT->fWorldPos[X]+0.5f-fSize, pActorT->fWorldPos[Y]+0.5f+fSize, fRayDirection, &fPoint, FACE_FLOOR, fSize);
	if(!pFieldT)
		iNoField++;
	if(pActorT->fWorldPos[Z] > fPoint[Z])
	{
		pActorT->fWorldPos[Z] = fPoint[Z];
		pActorT->fVelocity[Z] = 0.0f;
		if(pFieldT)
			pActorT->fFriction = pFieldT->pSurface[FACE_FLOOR][0]->Header.fFriction;
	}

	if(iNoField == 5 && pActorT == pPlayer && !PlayerInfo.bWing && pPlayer->byAction != ACTION_JUMP &&
	   !bInvulnerable)
	{
		// The player falls in a hole:
		pPlayer->fPower = 0.0f;
		pPlayer->fVelocity[Z] = 0.005f;
		pPlayer->bGoingDeath2 = TRUE;
		return;
	}

	// Because we only checked the bounding points it's possible that a terrain point is inside the box,
	// and then the box is inside a hill... now we have to check if a terrain point is inside the box if
	// yes then check it's height:

	// Compute the current field the given point is on:
	COMPUTE_FIELD_POS(pActorT->fWorldPos[X]+0.5f, pActorT->fWorldPos[Y]+0.5f, iXFieldPos, iYFieldPos);

	// Check the field and the fields around:
	for(iYPos = iYFieldPos-1; iYPos < iYFieldPos+2; iYPos++)
	{
		// Check if this coordinate is a correct one:
		if(iYPos < 0 || iYPos > pLevel->Header.iHeight-2)
			continue; // No correct field!

		for(iXPos = iXFieldPos-1; iXPos < iXFieldPos+2; iXPos++)
		{
			// Check if this coordinate is a correct one:
			if(iXPos < 0 || iXPos > pLevel->Header.iWidth-2)
				continue; // No correct field!

			// Get a pointer to this field:
			GET_FIELD_ID(iXFieldPos, iYFieldPos, iFieldID);
			pFieldT = &pLevel->pField[iFieldID];

			// Check if one of the points is in the bounding box:
			for(i = 0; i < 4; i++)
			{
				if(pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][i]][X] > pActorT->fWorldPos[X]+0.5-fSize-0.1f &&
				   pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][i]][Y] > pActorT->fWorldPos[Y]+0.5-fSize-0.1f &&
				   pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][i]][X] < pActorT->fWorldPos[X]+0.5+fSize+0.1f &&
				   pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][i]][Y] < pActorT->fWorldPos[Y]+0.5+fSize+0.1f)
				{ // Check the height;
					if(pActorT->fWorldPos[Z] > pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][i]][Z])
					{
						pActorT->fWorldPos[Z] = pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][i]][Z];
						pActorT->fVelocity[Z] = 0.0f;
					}
				}
			}
		}
	}
} // end ComputeActorHeight()

void SetActorsLights(void)
{ // begin SetActorsLights()
	GLfloat afLightData[4]  = {0.0f, 0.0f, 0.0f, 0.0f};
	ACTOR *pActorT;
	short i, i2;
	float fScale;

	i2 = 0;
	if(_ASConfig->byLight)
	{ // Setup the players 'aura':
		afLightData[0] = pPlayer->fWorldPos[X]+0.5f;
		afLightData[1] = pPlayer->fWorldPos[Y]+0.5f;
		afLightData[2] = pPlayer->fWorldPos[Z]-1.5f;
		afLightData[3] = 1.0f;
		glLightfv(GL_LIGHT2, GL_POSITION, afLightData);
		afLightData[0] = 1.0f;
		afLightData[1] = 1.0f;
		afLightData[2] = 1.0f;
		afLightData[3] = 1.0f;
		glLightfv(GL_LIGHT2, GL_DIFFUSE, afLightData);
		glEnable(GL_LIGHT2);
	}
	if(OktaActor.bActive)
	{
		afLightData[0] = OktaActor.fWorldPos[X]+0.5f;
		afLightData[1] = OktaActor.fWorldPos[Y]+0.5f;
		afLightData[2] = OktaActor.fWorldPos[Z];
		afLightData[3] = 1.0f;
		glLightfv(GL_LIGHT3+i2, GL_POSITION, afLightData);
		afLightData[0] = 1.0f;
		afLightData[1] = 0.1f;
		afLightData[2] = 0.1f;
		afLightData[3] = 1.0f;
		glLightfv(GL_LIGHT3+i2, GL_DIFFUSE, afLightData);
		glEnable(GL_LIGHT3+i2);
		i2++;
	}
	if(PlayerInfo.bShield)
	{
		afLightData[0] = pPlayer->fWorldPos[X]+0.5f;
		afLightData[1] = pPlayer->fWorldPos[Y]+0.5f;
		afLightData[2] = pPlayer->fWorldPos[Z]-0.5f;
		afLightData[3] = 1.0f;
		glLightfv(GL_LIGHT3+i2, GL_POSITION, afLightData);
		afLightData[0] = 0.4f;
		afLightData[1] = 1.0f;
		afLightData[2] = 0.4f;
		afLightData[3] = 1.0f;
		glLightfv(GL_LIGHT3+i2, GL_DIFFUSE, afLightData);
		glEnable(GL_LIGHT3+i2);
		i2++;
	}
	for(i = 0; i < MAX_ACTORS; i++)
	{
		if(i2 >= _AS->iMaxLights)
			break;
		pActorT = &Actor[i];
		if(!pActorT->bActive)
			continue;
		if(pActorT->byType == ACTOR_PLAYER_SHOT)
		{ // Setup the shot light:
			fScale = pActorT->fSize;
			afLightData[0] = pActorT->fWorldPos[X]+0.5f;
			afLightData[1] = pActorT->fWorldPos[Y]+0.5f;
			afLightData[2] = pActorT->fWorldPos[Z]-0.5f;
			afLightData[3] = 1.0f;
			glLightfv(GL_LIGHT3+i2, GL_POSITION, afLightData);
			afLightData[0] = 1.0f*fScale;
			afLightData[1] = 0.3f*fScale;
			afLightData[2] = 0.3f*fScale;
			afLightData[3] = 1.0f;
			glLightfv(GL_LIGHT3+i2, GL_DIFFUSE, afLightData);
			glEnable(GL_LIGHT3+i2);
			i2++;
		}
		if(pActorT->bGoingDeath)
		{ // Setup the death light:
			fScale = pActorT->fSize;
			afLightData[0] = pActorT->fWorldPos[X]+0.5f;
			afLightData[1] = pActorT->fWorldPos[Y]+0.5f;
			afLightData[2] = pActorT->fWorldPos[Z]-0.5f;
			afLightData[3] = 1.0f;
			glLightfv(GL_LIGHT3+i2, GL_POSITION, afLightData);
			afLightData[0] = pActorT->fColor[0]*fScale;
			afLightData[1] = pActorT->fColor[1]*fScale;
			afLightData[2] = pActorT->fColor[2]*fScale;
			afLightData[3] = 1.0f;
			glLightfv(GL_LIGHT3+i2, GL_DIFFUSE, afLightData);
			glEnable(GL_LIGHT3+i2);
			i2++;
		}
	}
} // end SetActorsLights()

void MoveActor(ACTOR *pActorT, short iSpeed)
{ // begin MoveActor()
	// Should we move?
	if(!pActorT->bMove)
		return;
	char byTempDirection = -1;
	short iBackupField, i;
	float fVelocity;
	BOOL bJumpEnd = FALSE;
	SURFACE *pSurfaceT;
	FIELD *pFieldT;

	// Yes we should:
	// Check is we pull something:
	if(pActorT->byAction == ACTION_PULL_RIGHT || pActorT->byAction2 == ACTION_PULL_RIGHT)
	{
		byTempDirection = pActorT->byDirection;
		pActorT->byDirection = RIGHT;
	}
	else
	if(pActorT->byAction == ACTION_PULL_DOWN || pActorT->byAction2 == ACTION_PULL_DOWN)
	{
		byTempDirection = pActorT->byDirection;
		pActorT->byDirection = DOWN;
	}
	else
	if(pActorT->byAction == ACTION_PULL_LEFT || pActorT->byAction2 == ACTION_PULL_LEFT)
	{
		byTempDirection = pActorT->byDirection;
		pActorT->byDirection = LEFT;
	}
	else
	if(pActorT->byAction == ACTION_PULL_UP || pActorT->byAction2 == ACTION_PULL_UP)
	{
		byTempDirection = pActorT->byDirection;
		pActorT->byDirection = UP;
	}
	if(pActorT->pVelocityFromActor)
	{
		if(pActorT->pVelocityFromActor->bUseFriction)
		{
			for(i = 0; i < 3; i++)
				pActorT->fVelocity[i] = pActorT->pVelocityFromActor->fVelocity[i]*pActorT->pVelocityFromActor->fFriction;
		}
		else
		{
			for(i = 0; i < 3; i++)
				pActorT->fVelocity[i] = pActorT->pVelocityFromActor->fVelocity[i];
		}
	}
	if(pActorT->bUseFriction && !pActorT->pVelocityFromActor)
		fVelocity = pActorT->fVelocity[0]*pActorT->fFriction;
	else
		fVelocity = pActorT->fVelocity[0];
	// Move now:
	switch(pActorT->byDirection)
	{
		case RIGHT:
			if(pActorT->byType == ACTOR_BOX_NORMAL ||
			   pActorT->byType == ACTOR_BOX_RED ||
			   pActorT->byType == ACTOR_BOX_GREEN ||
			   pActorT->byType == ACTOR_BOX_BLUE)
				pLevel->pField[pActorT->iFieldID].bWall = FALSE;
			pLevel->pField[pActorT->iFieldID].pActor = NULL;
			GET_FIELD_ID((pActorT->iFieldPos[X]+1), pActorT->iFieldPos[Y], pActorT->iFieldID)
			pLevel->pField[pActorT->iFieldID].pActor = pActorT;
			if(pActorT->byType == ACTOR_BOX_NORMAL ||
			   pActorT->byType == ACTOR_BOX_RED ||
			   pActorT->byType == ACTOR_BOX_GREEN ||
			   pActorT->byType == ACTOR_BOX_BLUE)
				pLevel->pField[pActorT->iFieldID].bWall = TRUE;
			pActorT->fFieldPos[X] += (float) g_lDeltatime/fVelocity;
			if(pActorT->fFieldPos[X] >= pLevel->Header.fFieldWidth)
			{
				pActorT->fFieldPos[X] = 0.0f;
				pActorT->iFieldPos[X]++;
				goto MoveEnd;
			}
			if(pActorT->fFieldPos[Y] < 0.0f)
			{
				pActorT->fFieldPos[Y] += (float) g_lDeltatime/fVelocity;
				if(pActorT->fFieldPos[Y] >= 0.0f)
					pActorT->fFieldPos[Y] = 0.0f;
			}
			if(pActorT->fFieldPos[Y] > 0.0f)
			{
				pActorT->fFieldPos[Y] -= (float) g_lDeltatime/fVelocity;
				if(pActorT->fFieldPos[Y] <= 0.0f)
					pActorT->fFieldPos[Y] = 0.0f;
			}
		break;

		case DOWN:
			if(pActorT->byType == ACTOR_BOX_NORMAL ||
			   pActorT->byType == ACTOR_BOX_RED ||
			   pActorT->byType == ACTOR_BOX_GREEN ||
			   pActorT->byType == ACTOR_BOX_BLUE)
				pLevel->pField[pActorT->iFieldID].bWall = FALSE;
			pLevel->pField[pActorT->iFieldID].pActor = NULL;
			GET_FIELD_ID(pActorT->iFieldPos[X], (pActorT->iFieldPos[Y]+1), pActorT->iFieldID)
			pLevel->pField[pActorT->iFieldID].pActor = pActorT;
			if(pActorT->byType == ACTOR_BOX_NORMAL ||
			   pActorT->byType == ACTOR_BOX_RED ||
			   pActorT->byType == ACTOR_BOX_GREEN ||
			   pActorT->byType == ACTOR_BOX_BLUE)
				pLevel->pField[pActorT->iFieldID].bWall = TRUE;
			pActorT->fFieldPos[Y] += (float) g_lDeltatime/fVelocity;
			if(pActorT->fFieldPos[Y] >= pLevel->Header.fFieldHeight)
			{
				pActorT->fFieldPos[Y] = 0.0f;
				pActorT->iFieldPos[Y]++;
				goto MoveEnd;
			}
			if(pActorT->fFieldPos[X] < 0.0f)
			{
				pActorT->fFieldPos[X] += (float) g_lDeltatime/fVelocity;
				if(pActorT->fFieldPos[X] >= 0.0f)
					pActorT->fFieldPos[X] = 0.0f;
			}
			if(pActorT->fFieldPos[X] > 0.0f)
			{
				pActorT->fFieldPos[X] -= (float) g_lDeltatime/fVelocity;
				if(pActorT->fFieldPos[X] <= 0.0f)
					pActorT->fFieldPos[X] = 0.0f;
			}
		break;

		case LEFT:
			if(pActorT->byType == ACTOR_BOX_NORMAL ||
			   pActorT->byType == ACTOR_BOX_RED ||
			   pActorT->byType == ACTOR_BOX_GREEN ||
			   pActorT->byType == ACTOR_BOX_BLUE)
				pLevel->pField[pActorT->iFieldID].bWall = FALSE;
			pLevel->pField[pActorT->iFieldID].pActor = NULL;
			GET_FIELD_ID((pActorT->iFieldPos[X]-1), pActorT->iFieldPos[Y], pActorT->iFieldID)
			pLevel->pField[pActorT->iFieldID].pActor = pActorT;
			if(pActorT->byType == ACTOR_BOX_NORMAL ||
			   pActorT->byType == ACTOR_BOX_RED ||
			   pActorT->byType == ACTOR_BOX_GREEN ||
			   pActorT->byType == ACTOR_BOX_BLUE)
				pLevel->pField[pActorT->iFieldID].bWall = TRUE;
			pActorT->fFieldPos[X] -= (float) g_lDeltatime/fVelocity;
			if(pActorT->fFieldPos[X] <= -pLevel->Header.fFieldWidth)
			{
				pActorT->fFieldPos[X] = 0.0f;
				pActorT->iFieldPos[X]--;
				goto MoveEnd;
			}
			if(pActorT->fFieldPos[Y] < 0.0f)
			{
				pActorT->fFieldPos[Y] += (float) g_lDeltatime/fVelocity;
				if(pActorT->fFieldPos[Y] >= 0.0f)
					pActorT->fFieldPos[Y] = 0.0f;
			}
			if(pActorT->fFieldPos[Y] > 0.0f)
			{
				pActorT->fFieldPos[Y] -= (float) g_lDeltatime/fVelocity;
				if(pActorT->fFieldPos[Y] <= 0.0f)
					pActorT->fFieldPos[Y] = 0.0f;
			}
		break;

		case UP:
			if(pActorT->byType == ACTOR_BOX_NORMAL ||
			   pActorT->byType == ACTOR_BOX_RED ||
			   pActorT->byType == ACTOR_BOX_GREEN ||
			   pActorT->byType == ACTOR_BOX_BLUE)
				pLevel->pField[pActorT->iFieldID].bWall = FALSE;
			pLevel->pField[pActorT->iFieldID].pActor = NULL;
			GET_FIELD_ID(pActorT->iFieldPos[X], (pActorT->iFieldPos[Y]-1), pActorT->iFieldID)
			pLevel->pField[pActorT->iFieldID].pActor = pActorT;
			if(pActorT->byType == ACTOR_BOX_NORMAL ||
			   pActorT->byType == ACTOR_BOX_RED ||
			   pActorT->byType == ACTOR_BOX_GREEN ||
			   pActorT->byType == ACTOR_BOX_BLUE)
				pLevel->pField[pActorT->iFieldID].bWall = TRUE;
			pActorT->fFieldPos[Y] -= (float) g_lDeltatime/fVelocity;
			if(pActorT->fFieldPos[Y] <= -pLevel->Header.fFieldHeight)
			{
				pActorT->fFieldPos[Y] = 0.0f;
				pActorT->iFieldPos[Y]--;
				goto MoveEnd;
			}
			if(pActorT->fFieldPos[X] < 0.0f)
			{
				pActorT->fFieldPos[X] += (float) g_lDeltatime/fVelocity;
				if(pActorT->fFieldPos[X] >= 0.0f)
					pActorT->fFieldPos[X] = 0.0f;
			}
			if(pActorT->fFieldPos[X] > 0.0f)
			{
				pActorT->fFieldPos[X] -= (float) g_lDeltatime/fVelocity;
				if(pActorT->fFieldPos[X] <= 0.0f)
					pActorT->fFieldPos[X] = 0.0f;
			}
		break;
	}
	if(byTempDirection != -1)
		pActorT->byDirection = byTempDirection;
	return;

MoveEnd:

	if(byTempDirection != -1)
		pActorT->byDirection = byTempDirection;
	// Remove the actor from the old field:
	if(pActorT->byType == ACTOR_BOX_NORMAL ||
	   pActorT->byType == ACTOR_BOX_RED ||
	   pActorT->byType == ACTOR_BOX_GREEN ||
	   pActorT->byType == ACTOR_BOX_BLUE)
		pLevel->pField[pActorT->iFieldID].bWall = FALSE;
	if(pActorT->byType != ACTOR_ENEMY_MOBMOB &&
	   pActorT->byType != ACTOR_ENEMY_X3)
		pLevel->pField[pActorT->iFieldID].pActor = NULL;
	if(pActorT->byAction == ACTION_JUMP)
	{ // The actor jumps:
		if(pActorT->bThrow)
		{ // We are on the overjumped field:
			pActorT->bThrow = FALSE;
			if(!CheckPlayerPushBox(pActorT->byDirection, FALSE))
			{ // The actor jumps againt a wall:
				if(!pLevel->pField[pActorT->iFieldID].bActive)
				{ // The actor falls into a gap:
					pActorT->fPower = 0.0f;
				}
				pActorT->byAction = -1;
				pActorT->iTempFieldID = -1;
			}
		}
		else
		{
			pActorT->byAction = -1;
			bJumpEnd = TRUE;
			pActorT->fVelocity[Z] = 0.005f;
		}
	}
	if(pActorT->byAction != ACTION_JUMP)
	{
		pActorT->bMove = FALSE;
		if(pActorT->byAction == ACTION_JUMP)
			pActorT->byAction = -1;
	}
	//
	iBackupField = pActorT->iFieldID;
	GET_FIELD_ID(pActorT->iFieldPos[X], pActorT->iFieldPos[Y], pActorT->iFieldID)
	pFieldT = &pLevel->pField[pActorT->iFieldID];
	if(pActorT->byType == ACTOR_PLAYER && !PlayerInfo.bGhost)
	{ // Check if the surface of one field should be changed:
		// Check the last field:
		for(i = 0; i < 2; i++)
		{
			if(pLevel->pField[iBackupField].iSurface[FACE_FLOOR][i] == -1)
				break;
			pSurfaceT = &pLevel->pSurface[pLevel->pField[iBackupField].iSurface[FACE_FLOOR][i]];
			if(pSurfaceT->Header.bChange && pSurfaceT->Header.byChangeState && pActorT->iTempFieldID != iBackupField &&
			   pSurfaceT->Header.byChangeState != 2)
			{ // Yes, we have to change the surface:
				if(pSurfaceT->Header.bChangeDestroy)
				{ // Destroy the field:
					pLevel->pField[iBackupField].bActive = FALSE;
					pLevel->pField[iBackupField].iSurface[FACE_FLOOR][i] = pSurfaceT->Header.iChangeSurface;
					pLevel->pField[iBackupField].pSurface[FACE_FLOOR][i] = &pLevel->pSurface[pSurfaceT->Header.iChangeSurface];
				}
				else
				{
					pLevel->pField[iBackupField].iSurface[FACE_FLOOR][i] = pSurfaceT->Header.iChangeSurface;
					pLevel->pField[iBackupField].pSurface[FACE_FLOOR][i] = &pLevel->pSurface[pSurfaceT->Header.iChangeSurface];
				}
				pLevel->pField[iBackupField].dwLastChangeTime[FACE_FLOOR][i] = g_lNow;
			}
			// Check the new field:
			pSurfaceT = &pLevel->pSurface[pLevel->pField[pActorT->iFieldID].iSurface[FACE_FLOOR][i]];
			if(pSurfaceT->Header.bChange && !pSurfaceT->Header.byChangeState && pActorT->iTempFieldID != pActorT->iFieldID &&
			   pSurfaceT->Header.byChangeState != 2)
			{ // Yes, we have to change the surface:
				if(pSurfaceT->Header.bChangeDestroy)
				{ // Destroy the field:
					pLevel->pField[pActorT->iFieldID].bActive = FALSE;
					pLevel->pField[pActorT->iFieldID].iSurface[FACE_FLOOR][i] = pSurfaceT->Header.iChangeSurface;
					pLevel->pField[pActorT->iFieldID].pSurface[FACE_FLOOR][i] = &pLevel->pSurface[pSurfaceT->Header.iChangeSurface];
				}
				else
				{
					pLevel->pField[pActorT->iFieldID].iSurface[FACE_FLOOR][i] = pSurfaceT->Header.iChangeSurface;
					pLevel->pField[pActorT->iFieldID].pSurface[FACE_FLOOR][i] = &pLevel->pSurface[pSurfaceT->Header.iChangeSurface];
				}
				pLevel->pField[pActorT->iFieldID].dwLastChangeTime[FACE_FLOOR][i] = g_lNow;
			}
		}
	}
	if(bJumpEnd)
		pActorT->iTempFieldID = -1;
	if(pActorT->byType != ACTOR_ENEMY_MOBMOB &&
	   pActorT->byType != ACTOR_ENEMY_X3)
		CheckActorField(pActorT);
	else
		pLevel->pField[pActorT->iFieldID].pActor = NULL;
	UpdateAllActorFields();
} // end MoveActor()

void UpdateAllActorFields(void)
{ // begin UpdateAllActorFields()
	FIELD *pFieldT;
	ACTOR *pActorT;
	short i, i2;
	
	// Clear all actors from the fields:
	for(i = 0; i < pLevel->Header.iFields; i++)
	{
		pFieldT = &pLevel->pField[i];
		if(pFieldT->pActor)
		{
			if(pFieldT->pActor->byType == ACTOR_BOX_NORMAL ||
			   pFieldT->pActor->byType == ACTOR_BOX_RED ||
			   pFieldT->pActor->byType == ACTOR_BOX_GREEN ||
			   pFieldT->pActor->byType == ACTOR_BOX_BLUE)
				pFieldT->bWall = FALSE;
			if(pFieldT->pActor->bDocked)
				DisableNoneFreeBox(pFieldT->pActor);
		}
		if(pFieldT->pBridgeActor)
		{
			pFieldT->bActive = FALSE;
			DisableNoneFreeBox(pFieldT->pBridgeActor);
			pFieldT->pBridgeActor->bBridge = FALSE;
		}
		pFieldT->pBridgeActor = NULL;
		if(pFieldT->pActor && pFieldT->pActor->bMove)
			pFieldT->pActor = NULL;
		pFieldT->pObject = NULL;
		pFieldT->pEnemy = NULL;
	}

	// Set all actors to the fields:
	for(i = 0; i < MAX_ACTORS; i++)
	{
		pActorT = &Actor[i];
		if(!pActorT->bActive)
			continue;
		GET_FIELD_ID(pActorT->iFieldPos[X], pActorT->iFieldPos[Y], pActorT->iFieldID);
		pFieldT = &pLevel->pField[pActorT->iFieldID];
		switch(pActorT->byType)
		{
			case ACTOR_BOX_NORMAL:
			case ACTOR_BOX_RED:
			case ACTOR_BOX_GREEN:
			case ACTOR_BOX_BLUE:
				// Check if another box is already in this hole:
				for(i2 = 0; i2 < MAX_ACTORS; i2++)
				{
					if(i2 == i || !Actor[i2].bActive)
						continue;
					if(Actor[i2].iFieldID == pFieldT->iID &&
					   Actor[i2].fFieldPos[Z] != 0.0f)
						goto Next; // There is already a bridge!
				}
				if(!pFieldT->bActive)
				{ // The box falls into a hole:
					pFieldT->bActive = TRUE;
					pFieldT->pBridgeActor = pActorT;
					pFieldT->bWall = TRUE;
					pActorT->bBridge = TRUE;
					pActorT->bBridgeMovement = TRUE;
					pActorT->fFieldPos[Z] = 1.0f;
					SetNoneFreeBox(pActorT);
					pActorT->bThrow = FALSE;
				}
				else
				{
			Next:
					if(pActorT->bDocked)
						SetNoneFreeBox(pActorT);
					if(pActorT->fFieldPos[Z] != 0.0f && !pActorT->bDocked)
						pActorT->bActive = FALSE;
					else
					{
						if(!pActorT->bGoingDeath)
						{
							pFieldT->bWall = TRUE;
							pFieldT->pActor = pActorT;
						}
					}
				}
			break;

			case ACTOR_HEALTH_OBJ:
			case ACTOR_LIVE_OBJ:
			case ACTOR_PULL_OBJ:
			case ACTOR_THROW_OBJ:
			case ACTOR_FORCE_OBJ:
			case ACTOR_WEAPON_OBJ:
			case ACTOR_POINT_OBJ:
			case ACTOR_GHOST_OBJ:
			case ACTOR_TIME_OBJ:
			case ACTOR_STEP_OBJ:
			case ACTOR_SPEED_OBJ:
			case ACTOR_WING_OBJ:
			case ACTOR_SHIELD_OBJ:
			case ACTOR_JUMP_OBJ:
			case ACTOR_AIR_OBJ:
				if(pFieldT->pObject)
					pActorT->bActive = FALSE;
				else
					pFieldT->pObject = pActorT;
			break;
		}
	}

	if(!pPlayer->bActive)
		return;
	// Set the player into the level:
	if(!PlayerInfo.bGhost)
		pLevel->pField[pPlayer->iFieldID].pActor = pPlayer;
} // end UpdateAllActorFields()

void CheckActorField(ACTOR *pActorT)
{ // begin CheckActorField()
	FIELD *pFieldT;
	SURFACE *pSurfaceT;
	
	if(!pActorT->bActive)
		return;
	if(pActorT->byType != ACTOR_BOX_NORMAL &&
	   pActorT->byType != ACTOR_BOX_RED &&
	   pActorT->byType != ACTOR_BOX_GREEN &&
	   pActorT->byType != ACTOR_BOX_BLUE)
	   return;
	pFieldT = &pLevel->pField[pActorT->iFieldID];
	pFieldT->pActor = pActorT;
	pSurfaceT = &pLevel->pSurface[pFieldT->iSurface[FACE_FLOOR][0]];
	if(pSurfaceT->Header.bColorPainter)
	{ // Change the color of this box:
		DeleteActorType(pActorT);
		switch(pSurfaceT->Header.byColorPainterType)
		{
			case 0: // Change the color to normal
				pActorT->byType = ACTOR_BOX_NORMAL;
				pLevel->Header.iNormalBoxes++;
			break;

			case 1: // Change the color to red
				pActorT->byType = ACTOR_BOX_RED;
				pLevel->Header.iRedBoxes++;
			break;

			case 2: // Change the color to green
				pActorT->byType = ACTOR_BOX_GREEN;
				pLevel->Header.iGreenBoxes++;
			break;

			case 3: // Change the color to blue
				pActorT->byType = ACTOR_BOX_BLUE;
				pLevel->Header.iBlueBoxes++;
			break;
		}
	}
	// Check if the box is now in a anchor:
	if(pSurfaceT->Header.bAnchor && !pActorT->bDocked && 
	  (((pSurfaceT->Header.byAnchorType == 0 || pSurfaceT->Header.byAnchorType == 1) && pActorT->byType == ACTOR_BOX_NORMAL) ||
	   ((pSurfaceT->Header.byAnchorType == 0 || pSurfaceT->Header.byAnchorType == 2) && pActorT->byType == ACTOR_BOX_RED) ||
	   ((pSurfaceT->Header.byAnchorType == 0 || pSurfaceT->Header.byAnchorType == 3) && pActorT->byType == ACTOR_BOX_GREEN) ||
	   ((pSurfaceT->Header.byAnchorType == 0 || pSurfaceT->Header.byAnchorType == 4) && pActorT->byType == ACTOR_BOX_BLUE)))
	{
		pActorT->bGoingDocked = TRUE;
		pActorT->dwDockedStartTime = g_lNow;
	}
	else
	{
		DisableBoxDocking(pActorT);
		pActorT->bDocked = FALSE;
		pActorT->bGoingDocked = FALSE;
	}
} // end CheckActorField()

void DrawEffects(void)
{ // begin DrawEffects()
	ACTOR *pActorT;
	FLOAT3 fPos, fPos2;
	float fScale;
	short i;

	glEnable(GL_BLEND);
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_CULL_FACE);
	glDepthMask(FALSE);

	// Effects are drawn over the complete scene:
	for(i = 0; i < MAX_ACTORS; i++)
	{
		pActorT = &Actor[i];
		if(!pActorT->bActive || !pActorT->bGoingDeath)
			continue;
		// Draw the dead wave:
		glPushMatrix();
		glTranslatef(pActorT->fWorldPos[X]+0.5f, pActorT->fWorldPos[Y]+0.5f, pActorT->fWorldPos[Z]-0.5f);
		glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(pActorT->fRot[X], 0.0f, 1.0f, 0.0f);
		glRotatef(pActorT->fRot[Y], 0.0f, 1.0f, 0.0f);
		glRotatef(pActorT->fRot[Z], 0.0f, 1.0f, 0.0f);
		if(pActorT->byType == ACTOR_BOX_NORMAL ||
		   pActorT->byType == ACTOR_BOX_RED ||
		   pActorT->byType == ACTOR_BOX_GREEN ||
		   pActorT->byType == ACTOR_BOX_BLUE)
		{
			glScalef(pActorT->fSize, pActorT->fSize, pActorT->fSize);
			glColor4f(pActorT->fColor[0]+0.1f, pActorT->fColor[1]+0.1f, pActorT->fColor[2]+0.1f, pActorT->fSize);
		}
		else
		{
			glScalef(pActorT->fSize*0.2f, pActorT->fSize*0.2f, pActorT->fSize*0.2f);
			glColor4f(1.0f, 1.0f, 1.0f, pActorT->fSize);
		}
		fScale = (1.0f-pActorT->fSize)/0.3f*10.0f;
		glScalef(fScale, fScale, fScale);
		glCallList(iWaveList);
		glRotatef(45.0f, 1.0f, 0.0f, 0.0f);
		glCallList(iWaveList);
		glRotatef(45.0f, 1.0f, 0.0f, 0.0f);
		glCallList(iWaveList);
		glRotatef(45.0f, 1.0f, 0.0f, 0.0f);
		glCallList(iWaveList);
		glPopMatrix();
	}
	
	// Draw the players shield:
	if(PlayerInfo.bShield && pPlayer->bActive)
	{		
		// Get the right vertex for the shield pos:
		fPos2[X] = pPlayer->fWorldPos[X]+0.5f;
		fPos2[Y] = pPlayer->fWorldPos[Y]+0.5f;
		fPos2[Z] = pPlayer->fWorldPos[Z]-0.6f;
		ASGetMd2Vertex(pXeModel, pPlayer->iAniStep, pPlayer->iNextAniStep, pPlayer->fModelInterpolation, fPos2, 0.025f,
					   -90.0f, pPlayer->fRot[Y], 0.0f, 87, &fPos);
		glColor4f(0.5f, 1.0f, 0.5f, 0.99f);
		glPushMatrix();
		glTranslatef(fPos[X], fPos[Y], fPos[Z]);
		glRotatef(PlayerInfo.fShieldRot[X], 1.0f, 0.0f, 0.0f);
		glRotatef(PlayerInfo.fShieldRot[Y], 0.0f, 1.0f, 0.0f);
		glRotatef(PlayerInfo.fShieldRot[Z], 0.0f, 0.0f, 1.0f);
		glCallList(iShieldList);
		glRotatef(45.0f, 1.0f, 0.0f, 0.0f);
		glCallList(iShieldList);
		glRotatef(45.0f, 1.0f, 0.0f, 0.0f);
		glCallList(iShieldList);
		glRotatef(45.0f, 1.0f, 0.0f, 0.0f);
		glCallList(iShieldList);
		glPopMatrix();
	}

	glDepthMask(TRUE);
	glDisable(GL_BLEND);
	glEnable(GL_CULL_FACE);
	if(pLevel->Environment.bFog)
		glEnable(GL_FOG);
} // end DrawEffects()

void DrawActors(void)
{ // begin DrawActors()
	float fSize, fPos;
	short i, i2;
	GLuint iLastTexture = 0;
	ACTOR *pActorT;
	SURFACE *pSurfaceT;
	TEXTURE_POS *pTexturePosT;

	glEnable(GL_TEXTURE_2D);
	// Draw all actors:
	for(i = 0; i < MAX_ACTORS; i++)
	{
		pActorT = &Actor[i];
		if(!pActorT->bActive)
			continue;
		if(!pLevel->pField[pActorT->iFieldID].bOnScreen)
		{ // The actor isn't on screen;
			iCulledObjects++;
			continue;
		}
		switch(pActorT->byType)
		{
			case ACTOR_BOX_NORMAL:
			case ACTOR_BOX_RED:
			case ACTOR_BOX_GREEN:
			case ACTOR_BOX_BLUE:
				fSize = pActorT->fSize;
				fPos = -(fSize-1.0f)/2;
				glPushMatrix();
				if(!pActorT->bBeaming || (pActorT->bBeaming && pActorT->bBeamingStep))
				{	// Calculate the world position of the box:
					pActorT->fWorldPos[X] = pActorT->iFieldPos[X]*pLevel->Header.fFieldWidth+pActorT->fFieldPos[X]+pActorT->fPosTemp[X];
					pActorT->fWorldPos[Y] = pActorT->iFieldPos[Y]*pLevel->Header.fFieldHeight+pActorT->fFieldPos[Y]+pActorT->fPosTemp[Y];
					if(!pActorT->bBridge)
						ComputeActorHeight(pActorT, 0.5f);
				}
				//
				if(pActorT->bGoingDeath)
					glTranslatef(pActorT->fWorldPos[X]+0.5f-(pActorT->fSize/2), pActorT->fWorldPos[Y]+0.5f-(pActorT->fSize/2), pActorT->fWorldPos[Z]-(0.5f-(pActorT->fSize/2)));
				else
				{
					if(pActorT->bDocked)
						glTranslatef(pActorT->fWorldPos[X]+fPos, pActorT->fWorldPos[Y]+fPos, pActorT->fWorldPos[Z]-fPos+pActorT->fPosTemp[Z]);
					else
						glTranslatef(pActorT->fWorldPos[X]+fPos, pActorT->fWorldPos[Y]+fPos, pActorT->fWorldPos[Z]);
				}
				switch(pActorT->byType)
				{
					case ACTOR_BOX_NORMAL:
						glColor3f(pActorT->fColor[X]-0.3f+(pActorT->fPower*3), pActorT->fColor[Y]-0.3f+(pActorT->fPower*3), pActorT->fColor[Z]-0.3f+(pActorT->fPower*3));
					break;
					
					case ACTOR_BOX_GREEN:
						glColor3f(pActorT->fColor[X]-0.3f+(pActorT->fPower*2), pActorT->fColor[Y]-0.3f+(pActorT->fPower*2), pActorT->fColor[Z]-0.3f+(pActorT->fPower*2));
					break;
					
					case ACTOR_BOX_BLUE:
						glColor3f(pActorT->fColor[X]-0.3f+(pActorT->fPower*1.5f), pActorT->fColor[Y]-0.3f+(pActorT->fPower*1.5f), pActorT->fColor[Z]-0.3f+(pActorT->fPower*1.5f));
					break;

					default:
						glColor3f(pActorT->fColor[X]-0.3f+pActorT->fPower, pActorT->fColor[Y]-0.3f+pActorT->fPower, pActorT->fColor[Z]-0.3f+pActorT->fPower);
					break;
				}

				if(pActorT->bBeaming)
				{
					glEnable(GL_BLEND);
					glColor4f(pActorT->fColor[0], pActorT->fColor[1], pActorT->fColor[2], pActorT->fBeaming);
					glDepthMask(FALSE);
				}
				// Check if all animation steps are vaild:
				for(i2 = 0; i2 < 6; i2++)
				{
					pSurfaceT = &pLevel->pSurface[pLevel->Header.iBoxSurface[i2][pActorT->bHeavy]];
					if(pActorT->iMultiAniStep[i2] >= pSurfaceT->Header.iAniSteps)
						pActorT->iMultiAniStep[i2] = 0;
				}

				glScalef(fSize, fSize, fSize);

				// Floor face
				pSurfaceT = &pLevel->pSurface[pLevel->Header.iBoxSurface[0][pActorT->bHeavy]];
				pTexturePosT = &pSurfaceT->pTexturePos[pActorT->iMultiAniStep[0]];
				glBindTexture(GL_TEXTURE_2D, pSurfaceT->pTexture[pActorT->iMultiAniStep[0]]->iOpenGLID);
				glBegin(GL_QUADS);
					glNormal3f(0.0f, 0.0f, 1.0f);
					glTexCoord2fv(pTexturePosT->fPos[(0+pLevel->Header.byBoxSurfaceRot[i2][0]) % 4]); glVertex3f(1.0f, 0.0f, 0.0f);
					glTexCoord2fv(pTexturePosT->fPos[(1+pLevel->Header.byBoxSurfaceRot[i2][0]) % 4]); glVertex3f(1.0f, 1.0f, 0.0f);
					glTexCoord2fv(pTexturePosT->fPos[(2+pLevel->Header.byBoxSurfaceRot[i2][0]) % 4]); glVertex3f(0.0f, 1.0f, 0.0f);
					glTexCoord2fv(pTexturePosT->fPos[(3+pLevel->Header.byBoxSurfaceRot[i2][0]) % 4]); glVertex3f(0.0f, 0.0f, 0.0f);
				glEnd();

				// Sky face
				pSurfaceT = &pLevel->pSurface[pLevel->Header.iBoxSurface[1][pActorT->bHeavy]];
				pTexturePosT = &pSurfaceT->pTexturePos[pActorT->iMultiAniStep[1]];
				glBindTexture(GL_TEXTURE_2D, pSurfaceT->pTexture[pActorT->iMultiAniStep[1]]->iOpenGLID);
				glBegin(GL_QUADS);
					glNormal3f(0.0f, 0.0f, -1.0f);
					glTexCoord2fv(pTexturePosT->fPos[(0+pLevel->Header.byBoxSurfaceRot[i2][1]) % 4]); glVertex3f(0.0f, 1.0f, -1.0f);
					glTexCoord2fv(pTexturePosT->fPos[(1+pLevel->Header.byBoxSurfaceRot[i2][1]) % 4]); glVertex3f(1.0f, 1.0f, -1.0f);
					glTexCoord2fv(pTexturePosT->fPos[(2+pLevel->Header.byBoxSurfaceRot[i2][1]) % 4]); glVertex3f(1.0f, 0.0f, -1.0f);
					glTexCoord2fv(pTexturePosT->fPos[(3+pLevel->Header.byBoxSurfaceRot[i2][1]) % 4]); glVertex3f(0.0f, 0.0f, -1.0f);
				glEnd();
					
				// Back face
				pSurfaceT = &pLevel->pSurface[pLevel->Header.iBoxSurface[2][pActorT->bHeavy]];
				pTexturePosT = &pSurfaceT->pTexturePos[pActorT->iMultiAniStep[2]];
				glBindTexture(GL_TEXTURE_2D, pSurfaceT->pTexture[pActorT->iMultiAniStep[2]]->iOpenGLID);
				glBegin(GL_QUADS);
					glNormal3f(0.0f, 1.0f, 0.0f);
					glTexCoord2fv(pTexturePosT->fPos[(0+pLevel->Header.byBoxSurfaceRot[i2][2]) % 4]); glVertex3f(1.0f, 1.0f, 0.0f);
					glTexCoord2fv(pTexturePosT->fPos[(1+pLevel->Header.byBoxSurfaceRot[i2][2]) % 4]); glVertex3f(1.0f, 1.0f, -1.0f);
					glTexCoord2fv(pTexturePosT->fPos[(2+pLevel->Header.byBoxSurfaceRot[i2][2]) % 4]); glVertex3f(0.0f, 1.0f, -1.0f);
					glTexCoord2fv(pTexturePosT->fPos[(3+pLevel->Header.byBoxSurfaceRot[i2][2]) % 4]); glVertex3f(0.0f, 1.0f, 0.0f);
				glEnd();

				// Bottom Face
				pSurfaceT = &pLevel->pSurface[pLevel->Header.iBoxSurface[3][pActorT->bHeavy]];
				pTexturePosT = &pSurfaceT->pTexturePos[pActorT->iMultiAniStep[3]];
				glBindTexture(GL_TEXTURE_2D, pSurfaceT->pTexture[pActorT->iMultiAniStep[3]]->iOpenGLID);
				glBegin(GL_QUADS);
					glNormal3f(0.0f, -1.0f, 0.0f);
					glTexCoord2fv(pTexturePosT->fPos[(0+pLevel->Header.byBoxSurfaceRot[i2][3]) % 4]); glVertex3f(0.0f, 0.0f, -1.0f);
					glTexCoord2fv(pTexturePosT->fPos[(1+pLevel->Header.byBoxSurfaceRot[i2][3]) % 4]); glVertex3f(1.0f, 0.0f, -1.0f);
					glTexCoord2fv(pTexturePosT->fPos[(2+pLevel->Header.byBoxSurfaceRot[i2][3]) % 4]); glVertex3f(1.0f, 0.0f, 0.0f);
					glTexCoord2fv(pTexturePosT->fPos[(3+pLevel->Header.byBoxSurfaceRot[i2][3]) % 4]); glVertex3f(0.0f, 0.0f, 0.0f);
				glEnd();
					
				// Right face
				pSurfaceT = &pLevel->pSurface[pLevel->Header.iBoxSurface[4][pActorT->bHeavy]];
				pTexturePosT = &pSurfaceT->pTexturePos[pActorT->iMultiAniStep[4]];
				glBindTexture(GL_TEXTURE_2D, pSurfaceT->pTexture[pActorT->iMultiAniStep[4]]->iOpenGLID);
				glBegin(GL_QUADS);
					glNormal3f(1.0f, 0.0f, 0.0f);
					glTexCoord2fv(pTexturePosT->fPos[(0+pLevel->Header.byBoxSurfaceRot[i2][4]) % 4]); glVertex3f(1.0f, 0.0f, -1.0f);
					glTexCoord2fv(pTexturePosT->fPos[(1+pLevel->Header.byBoxSurfaceRot[i2][4]) % 4]); glVertex3f(1.0f, 1.0f, -1.0f);
					glTexCoord2fv(pTexturePosT->fPos[(2+pLevel->Header.byBoxSurfaceRot[i2][4]) % 4]); glVertex3f(1.0f, 1.0f, 0.0f);
					glTexCoord2fv(pTexturePosT->fPos[(3+pLevel->Header.byBoxSurfaceRot[i2][4]) % 4]); glVertex3f(1.0f, 0.0f, 0.0f);
				glEnd();

				// Left Face
				pSurfaceT = &pLevel->pSurface[pLevel->Header.iBoxSurface[5][pActorT->bHeavy]];
				pTexturePosT = &pSurfaceT->pTexturePos[pActorT->iMultiAniStep[5]];
				glBindTexture(GL_TEXTURE_2D, pSurfaceT->pTexture[pActorT->iMultiAniStep[5]]->iOpenGLID);
				glBegin(GL_QUADS);
					glNormal3f(-1.0f, 0.0f, 0.0f);
					glTexCoord2fv(pTexturePosT->fPos[(0+pLevel->Header.byBoxSurfaceRot[i2][5]) % 4]); glVertex3f(0.0f, 1.0f, 0.0f);
					glTexCoord2fv(pTexturePosT->fPos[(1+pLevel->Header.byBoxSurfaceRot[i2][5]) % 4]); glVertex3f(0.0f, 1.0f, -1.0f);
					glTexCoord2fv(pTexturePosT->fPos[(2+pLevel->Header.byBoxSurfaceRot[i2][5]) % 4]); glVertex3f(0.0f, 0.0f, -1.0f);
					glTexCoord2fv(pTexturePosT->fPos[(3+pLevel->Header.byBoxSurfaceRot[i2][5]) % 4]); glVertex3f(0.0f, 0.0f, 0.0f);
				glEnd();
				
				iLastTexture = -1;
				glPopMatrix();
				glDepthMask(TRUE);
				glDisable(GL_BLEND);
			break;
			
			case ACTOR_HEALTH_OBJ:
			case ACTOR_LIVE_OBJ:
			case ACTOR_PULL_OBJ:
			case ACTOR_THROW_OBJ:
			case ACTOR_FORCE_OBJ:
			case ACTOR_WEAPON_OBJ:
			case ACTOR_POINT_OBJ:
			case ACTOR_GHOST_OBJ:
			case ACTOR_PLAYER_SHOT:
			case ACTOR_TIME_OBJ:
			case ACTOR_STEP_OBJ:
			case ACTOR_SPEED_OBJ:
			case ACTOR_WING_OBJ:
			case ACTOR_SHIELD_OBJ:
			case ACTOR_JUMP_OBJ:
			case ACTOR_AIR_OBJ:
				if(!bPause || pLevel->State.bLevelComplete)
				{ // Animate the object:
					pActorT->dwAniDeltaTime = g_lNow-pPlayer->dwAniTime;
					if(pActorT->byType == ACTOR_WEAPON_OBJ)
						AnimateActorModel(pActorT, *pXeWeaponModel, PLAYER_ANIMATION_SPEED, 1);
					else
					if(g_lNow-pActorT->dwAniTime > OBJECTS_ANI_SPEED)
					{
						pActorT->dwAniTime = g_lNow;
						pActorT->iAniStep++;
						if(pActorT->iAniStep > 3)
							pActorT->iAniStep = 0;
						if(pActorT->iAniStep < 0)
							pActorT->iAniStep = 0;
					}
				}
				if(pActorT->byType != ACTOR_PLAYER_SHOT)
				{
					if(pLevel->pField[pActorT->iFieldID].pActor &&
					   pLevel->pField[pActorT->iFieldID].pActor->fFieldPos[X] == 0.0f &&
					   pLevel->pField[pActorT->iFieldID].pActor->fFieldPos[Y] == 0.0f &&
					   !pLevel->pField[pActorT->iFieldID].pActor->bGoingDeath &&
					   (pLevel->pField[pActorT->iFieldID].pActor->byType == ACTOR_BOX_NORMAL ||
						pLevel->pField[pActorT->iFieldID].pActor->byType == ACTOR_BOX_RED ||
						pLevel->pField[pActorT->iFieldID].pActor->byType == ACTOR_BOX_GREEN ||
						pLevel->pField[pActorT->iFieldID].pActor->byType == ACTOR_BOX_BLUE))
					{ // A box is over this actor... maybe a secret??
						iCulledObjects++;
						break;
					}
				}
				// Draw the object:
				glPushMatrix();
				if(pActorT->byType != ACTOR_PLAYER_SHOT)
				{
					// Calculate the world position of the object:
					pActorT->fWorldPos[X] = pActorT->iFieldPos[X]*pLevel->Header.fFieldWidth+pActorT->fFieldPos[X]+pActorT->fPosTemp[X];
					pActorT->fWorldPos[Y] = pActorT->iFieldPos[Y]*pLevel->Header.fFieldHeight+pActorT->fFieldPos[Y]+pActorT->fPosTemp[Y];
					ComputeActorHeight(pActorT, 0.1f);
				}
				if(pActorT->byType == ACTOR_POINT_OBJ)
					glTranslatef(pActorT->fWorldPos[X]+0.5f, pActorT->fWorldPos[Y]+0.5f, pActorT->fWorldPos[Z]+0.5f-(1.0f/(pActorT->fSize)));
				else
					glTranslatef(pActorT->fWorldPos[X]+0.5f, pActorT->fWorldPos[Y]+0.5f, pActorT->fWorldPos[Z]-0.5f);
				if(pActorT->byType == ACTOR_WEAPON_OBJ)
					glTranslatef(-0.6f, -0.5f, 0.0f);
				glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
				if(pActorT->byType != ACTOR_WEAPON_OBJ && pActorT->byType != ACTOR_PLAYER_SHOT)
					glRotatef(pActorT->fRot[Y], 0.0f, 1.0f, 0.0f);
				glScalef(pActorT->fSize*0.2f, pActorT->fSize*0.2f, pActorT->fSize*0.2f);
				if(iLastTexture != GameTexture[pActorT->iAniStep].iOpenGLID)
				{ // We have to change the texture:
					iLastTexture = GameTexture[pActorT->iAniStep].iOpenGLID;
					glBindTexture(GL_TEXTURE_2D, GameTexture[pActorT->iAniStep].iOpenGLID);
				}
				glColor3f(pActorT->fColor[0], pActorT->fColor[1], pActorT->fColor[2]);
				if(pActorT->fColor[0] == 1.0f && pActorT->fColor[1] == 1.0f && pActorT->fColor[2] == 1.0f)
				{
					switch(pActorT->byType)
					{
						case ACTOR_HEALTH_OBJ:
							glCallList(iHealthObjList);
						break;

						case ACTOR_LIVE_OBJ:
							glCallList(iLiveObjList);
						break;

						case ACTOR_PULL_OBJ:
							glCallList(iPullObjList);
						break;

						case ACTOR_THROW_OBJ:
							glCallList(iThrowObjList);
						break;

						case ACTOR_FORCE_OBJ:
							glCallList(iForceObjList);
						break;

						case ACTOR_WEAPON_OBJ:
							glCullFace(GL_FRONT);
							glColor3f(1.0f, 1.0f, 1.0f);
							glScalef(0.2f, 0.2f, 0.2f);
							glBindTexture(GL_TEXTURE_2D, GameTexture[19+byWeaponAni].iOpenGLID);
							iLastTexture = 19+byWeaponAni;
							ASDrawMd2FrameInt(pXeWeaponModel, pActorT->iAniStep, pActorT->iNextAniStep, (float) (g_lNow-pActorT->dwAniTime)/(float) PLAYER_ANIMATION_SPEED);
							glCullFace(GL_BACK);
						break;

						case ACTOR_POINT_OBJ:
							glCallList(iPointObjList);
						break;

						case ACTOR_GHOST_OBJ:
							glCallList(iGhostObjList);
						break;

						case ACTOR_PLAYER_SHOT:
							glScalef(0.2f, 0.2f, 0.2f);
							glCallList(iPlayerShotObjList);
						break;

						case ACTOR_TIME_OBJ:
							glCallList(iTimeObjList);
						break;

						case ACTOR_STEP_OBJ:
							glCallList(iStepsObjList);
						break;

						case ACTOR_SPEED_OBJ:
							glCallList(iSpeedObjList);
						break;

						case ACTOR_WING_OBJ:
							glCallList(iWingObjList);
						break;

						case ACTOR_SHIELD_OBJ:
							glCallList(iShieldObjList);
						break;
						
						case ACTOR_JUMP_OBJ:
							glCallList(iJumpObjList);
						break;

						case ACTOR_AIR_OBJ:
							glCallList(iAirObjList);
						break;
					}
				}
				else
				{
					if(_ASConfig->bUseLevelVertexColor || _ASConfig->bHightRenderQuality)
						glDisableClientState(GL_COLOR_ARRAY);
					glEnable(GL_TEXTURE_GEN_S);
					glEnable(GL_TEXTURE_GEN_T);
					switch(pActorT->byType)
					{
						case ACTOR_HEALTH_OBJ:
							pHealthObject->Draw(TRUE, TRUE, FALSE);
						break;

						case ACTOR_LIVE_OBJ:
							pLiveObject->Draw(TRUE, TRUE, FALSE);
						break;

						case ACTOR_PULL_OBJ:
							pPullObject->Draw(TRUE, TRUE, FALSE);
						break;

						case ACTOR_THROW_OBJ:
							pThrowObject->Draw(TRUE, TRUE, FALSE);
						break;

						case ACTOR_FORCE_OBJ:
							pForceObject->Draw(TRUE, TRUE, FALSE);
						break;

						case ACTOR_WEAPON_OBJ:
							glCullFace(GL_FRONT);
							glScalef(0.2f, 0.2f, 0.2f);
							glBindTexture(GL_TEXTURE_2D, GameTexture[19+byWeaponAni].iOpenGLID);
							ASDrawMd2FrameInt(pXeWeaponModel, pActorT->iAniStep, pActorT->iNextAniStep, (float) (g_lNow-pActorT->dwAniTime)/(float) PLAYER_ANIMATION_SPEED);
							glCullFace(GL_BACK);
						break;

						case ACTOR_POINT_OBJ:
							pPointObject->Draw(TRUE, TRUE, FALSE);
						break;

						case ACTOR_GHOST_OBJ:
							pGhostObject->Draw(TRUE, TRUE, FALSE);
						break;

						case ACTOR_PLAYER_SHOT:
							pPlayerShot->Draw(TRUE, TRUE, FALSE);
						break;

						case ACTOR_TIME_OBJ:
							pTimeObject->Draw(TRUE, TRUE, FALSE);
						break;

						case ACTOR_STEP_OBJ:
							pStepsObject->Draw(TRUE, TRUE, FALSE);
						break;

						case ACTOR_SPEED_OBJ:
							pSpeedObject->Draw(TRUE, TRUE, FALSE);
						break;

						case ACTOR_WING_OBJ:
							pWingObject->Draw(TRUE, TRUE, FALSE);
						break;

						case ACTOR_SHIELD_OBJ:
							pShieldObject->Draw(TRUE, TRUE, FALSE);
						break;

						case ACTOR_JUMP_OBJ:
							pJumpObject->Draw(TRUE, TRUE, FALSE);
						break;

						case ACTOR_AIR_OBJ:
							pAirObject->Draw(TRUE, TRUE, FALSE);
						break;
					}
					if(_ASConfig->bHightRenderQuality && _ASConfig->bUseLevelVertexColor)  
						glEnableClientState(GL_COLOR_ARRAY);
					glDisable(GL_TEXTURE_GEN_S);
					glDisable(GL_TEXTURE_GEN_T);
				}
				glPopMatrix();
			break;

			case ACTOR_ENEMY_HIRO:
				DrawEnemyHiro(pActorT);
				iLastTexture = -1;
			break;
			
			case ACTOR_ENEMY_MOBMOB:
				DrawEnemyMobmob(pActorT);
				iLastTexture = -1;
			break;

			case ACTOR_ENEMY_X3:
				DrawEnemyX3(pActorT);
				iLastTexture = -1;
			break;
		}
	}

	// Draw the Okta:
	if(OktaActor.bActive)
	{
		glPushMatrix();
		glCullFace(GL_FRONT);
		glTranslatef(OktaActor.fWorldPos[X]+0.5f, OktaActor.fWorldPos[Y]+0.5f, OktaActor.fWorldPos[Z]-0.6f);
		glColor3f(1.0f, 1.0f, 1.0f);
		glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
		glScalef(0.024f, 0.024f, 0.024f);
		glBindTexture(GL_TEXTURE_2D, GameTexture[10].iOpenGLID);
		ASDrawMd2FrameInt(pOktaModel, OktaActor.iAniStep, OktaActor.iNextAniStep, (float) (g_lNow-OktaActor.dwAniTime)/(float) 150);
		glCullFace(GL_BACK);
		glPopMatrix();
		if((bPause && pLevel->State.bLevelComplete) || (!bPause && !pLevel->State.bLevelComplete))
			AnimateActorModel(&OktaActor, *pOktaModel, 150, 2);
	}
} // end DrawActors()

void CheckActors(BOOL bEditor)
{ // begin CheckActors()
	ACTOR *pActorT;
	FIELD *pFieldT;
	SURFACE *pSurfaceT;
	short i, i2, iX, iY, iXT, iYT;
	FLOAT3 fRayDirection, fPoint;
	float fHeight, fSize, fZ;

	if(bPause && !pLevel->State.bLevelComplete)
		return;
	for(i = 0; i < MAX_ACTORS; i++)
	{
		pActorT = &Actor[i];
		if(!pActorT->bActive)
			continue;
		// Setup x/y direction:
		switch(pActorT->byDirection)
		{
			case RIGHT: iX = 1; iY = 0; break;
			case DOWN: iX = 0; iY = 1; break;
			case LEFT: iX = -1; iY = 0; break;
			case UP: iX = 0; iY = -1; break;
		}
		// Check the water:
		if(pLevel->Environment.bWater &&
		   pActorT->fWorldPos[Z] > pLevel->Environment.fWaterActualHeight)
		{
			if(pLevel->Environment.bWaterLava && !pActorT->bHeavy)
			{
				if(bEditor)
					pActorT->bGoingDeath = TRUE;
				else
				{
					switch(pActorT->byType)
					{
						case ACTOR_BOX_NORMAL:
						case ACTOR_BOX_RED:
						case ACTOR_BOX_GREEN:
						case ACTOR_BOX_BLUE:				
							KillBox(pActorT);
						break;

						default:
							pActorT->bGoingDeath = TRUE;
						break;
					}
				}
			}
			else
			{
				if(pActorT->byType == ACTOR_ENEMY_X3 && pActorT->bHeavy)
					fZ = -0.5f;
				else
					fZ = -1.2f;
				if(pActorT->bMove &&
				   pActorT->fWorldPos[Z]+fZ < pLevel->Environment.fWaterActualHeight &&
		   		   pLevel->pField[pActorT->iFieldID].bOnScreen &&
				   !pActorT->bGoingDeath)
				{ // Create water waves:
					if(g_lNow-pActorT->lLastWaterWaveTime > 50)
					{
						pActorT->lLastWaterWaveTime = g_lNow;
						fSize = pActorT->fWorldPos[Z]-pLevel->Environment.fWaterActualHeight;
						if(fSize > 0.5f)
							fSize = 1.0f-fSize;
						CreateWaterWave(pActorT->fWorldPos[X]+0.5f, pActorT->fWorldPos[Y]+0.5f, fSize+0.3f);
					}
				}
			}

		}

		// Check the actor:
		switch(pActorT->byType)
		{
			case ACTOR_BOX_NORMAL:
			case ACTOR_BOX_RED:
			case ACTOR_BOX_GREEN:
			case ACTOR_BOX_BLUE:				
				// Animate the surfaces of this actor:
				for(i2 = 0; i2 < 6; i2++)
				{
					pSurfaceT = &pLevel->pSurface[pLevel->Header.iBoxSurface[i2][pActorT->bHeavy]];
					if(g_lNow-pActorT->dwMultiAniTime[i2] >= (DWORD) pSurfaceT->pTexturePos[pActorT->iMultiAniStep[i2]].iTimeToNext)
					{ // It's time for a animation frame update:
						pActorT->dwMultiAniTime[i2] = g_lNow;
						pActorT->iMultiAniStep[i2]++;
						if(pActorT->iMultiAniStep[i2] >= pSurfaceT->Header.iAniSteps)
							pActorT->iMultiAniStep[i2] = 0;
					}
				}
				if(CheckBeamingProcess(pActorT) && !pActorT->bBeamingStep)
					break;
				if(pActorT->bGoingDeath)
				{ // Yes: (Killing sequenze)
					pActorT->fSize -= g_lDeltatime/BOX_KILLING_SPEED;
					if(pActorT->fSize < 0.0f)
					{
						pActorT->bActive = FALSE;
						pLevel->pField[pActorT->iFieldID].bWall = FALSE;
						if(pActorT->bBridge)
						{
							pLevel->pField[pActorT->iFieldID].pBridgeActor = NULL;
							pLevel->pField[pActorT->iFieldID].bActive = FALSE;
						}
						else
							pLevel->pField[pActorT->iFieldID].pActor = NULL;
					}
					break;
				}
				if(pActorT->bBridge && pActorT->bBridgeMovement)
				{	
					fHeight = pLevel->fPoint[pLevel->pField[pActorT->iFieldID].iFace[FACE_FLOOR][0]][Z];
					fHeight += pLevel->fPoint[pLevel->pField[pActorT->iFieldID].iFace[FACE_FLOOR][1]][Z];
					fHeight += pLevel->fPoint[pLevel->pField[pActorT->iFieldID].iFace[FACE_FLOOR][2]][Z];
					fHeight += pLevel->fPoint[pLevel->pField[pActorT->iFieldID].iFace[FACE_FLOOR][3]][Z];
					fHeight /= 4.0f;
					if(pActorT->fWorldPos[Z] > fHeight+1.0f)
					{
						pActorT->fWorldPos[Z] -= g_lDeltatime/200.0f;
						if(pActorT->fWorldPos[Z] < fHeight+1.0f)
						{
							pActorT->bBridgeMovement = FALSE;
							pActorT->fWorldPos[Z] = fHeight+1.0f;
						}
						else
							pActorT->bBridgeMovement = TRUE;
					}
					else
					{
						pActorT->fWorldPos[Z] += g_lDeltatime/200.0f;
						if(pActorT->fWorldPos[Z] > fHeight+1.0f)
						{
							pActorT->bBridgeMovement = FALSE;
							pActorT->fWorldPos[Z] = fHeight+1.0f;
						}
						else
							pActorT->bBridgeMovement = TRUE;
					}
					if(pActorT->fWorldPos[Z] == fHeight+1.0f && !pLevel->pField[pActorT->iFieldID].pActor)
						pLevel->pField[pActorT->iFieldID].bWall = FALSE;
					if(pLevel->pField[pActorT->iFieldID].pActor == pActorT)
						pLevel->pField[pActorT->iFieldID].pActor = FALSE;
				}
				if(!pActorT->fFieldPos[X] & !pActorT->fFieldPos[Y])
					if(CheckBeaming(pActorT))
						break;
				MoveActor(pActorT, (short) pActorT->fVelocity[0]);				
				CheckBoxThrow(pActorT);

				// Check if we should make the 'fly' animation:
				if(pActorT->bGoingDocked && pActorT->bMove)
					pActorT->dwDockedStartTime = g_lNow;
				if(pActorT->bGoingDocked && g_lNow-pActorT->dwDockedStartTime > 500)
				{ // The box should now going docked:
					pActorT->bGoingDocked = FALSE;
					pSurfaceT = pLevel->pField[pActorT->iFieldID].pSurface[FACE_FLOOR][0];
					switch(pSurfaceT->Header.byAnchorType)
					{
						case 0: // A anchor for all boxes
							pActorT->bDocked = TRUE;
							pLevel->State.iUsedForAllAnchors++;
							goto Docked;

						case 1: // A anchor for normal boxes
							if(pActorT->byType != ACTOR_BOX_NORMAL)
								break;
							pLevel->State.iUsedNormalAnchors++;
							goto Docked;

						case 2: // A anchor for red boxes
							if(pActorT->byType != ACTOR_BOX_RED)
								break;
							pLevel->State.iUsedRedAnchors++;
							goto Docked;

						case 3: // A anchor for green boxes
							if(pActorT->byType != ACTOR_BOX_GREEN)
								break;
							pLevel->State.iUsedGreenAnchors++;
							goto Docked;

						case 4: // A anchor for blue boxes
							if(pActorT->byType != ACTOR_BOX_BLUE)
								break;
							pLevel->State.iUsedBlueAnchors++;
						Docked:
							pActorT->bDocked = TRUE;
							for(i = 0; i < 3; i++)
							{
								pActorT->fPosTemp[i] = 0.0f;
								pActorT->fPosTempTo[i] = 0.0f;
								pActorT->fPosTempVelocity[i] = 0.0f;

							}
							SetNoneFreeBox(pActorT);
						break;
					}
				}
				if(pActorT->bDocked)
				{ // Yep:
					for(i2 = 0; i2 < 3; i2++)
					{
						pActorT->fPosTemp[i2] += pActorT->fPosTempVelocity[i2]*g_lDeltatime/1000.0f;
						if(pActorT->fPosTemp[i2] <= pActorT->fPosTempTo[i2]+0.1f &&
						   pActorT->fPosTemp[i2] >= pActorT->fPosTempTo[i2]-0.1f)
						{ // Change the direction:
							if(pActorT->fPosTempVelocity[i2] > 0.25f)
								pActorT->fPosTempVelocity[i2] = 0.25f;
							if(pActorT->fPosTempVelocity[i2] < -0.25f)
								pActorT->fPosTempVelocity[i2] = -0.25f;
							if(!(rand() % 2))
								pActorT->fPosTempTo[i2] = -(float) (rand() % 200)/1000.0f;
							else
								pActorT->fPosTempTo[i2] = (float) (rand() % 200)/1000.0f;
						}
						else
						{ // Increase the velocity:
							if(pActorT->fPosTemp[i2] < pActorT->fPosTempTo[i2])
								pActorT->fPosTempVelocity[i2] += g_lDeltatime/3000.0f;
							else
								pActorT->fPosTempVelocity[i2] -= g_lDeltatime/3000.0f;
						}
					}
					if(pActorT->fSize > BOX_DOCKED_SIZE)
					{
						pActorT->fSize -= g_lDeltatime/2000.0f;
						if(pActorT->fSize < BOX_DOCKED_SIZE)
						{
							pActorT->fSize = BOX_DOCKED_SIZE;
							// Get a new position:
							if(!(rand() % 2))
								pActorT->fPosTempTo[i2] = -(float) (rand() % 200)/1000.0f;
							else
								pActorT->fPosTempTo[i2] = (float) (rand() % 200)/1000.0f;
						}
					}
				}
				else
				{
					for(i2 = 0; i2 < 3; i2++)
					{
						pActorT->fPosTemp[i2] += pActorT->fPosTempVelocity[i2]*g_lDeltatime/1000.0f;
						if(pActorT->fPosTemp[i2] <= 0.05f &&
						   pActorT->fPosTemp[i2] >= -0.05f)
						{ // Set all to zero:
							pActorT->fPosTemp[i2] = pActorT->fPosTempTo[i2] = pActorT->fPosTempVelocity[i2] = 0.0f;
						}
						else
						{ // Increase the velocity:
							if(pActorT->fPosTemp[i2] < pActorT->fPosTempTo[i2])
								pActorT->fPosTempVelocity[i2] += g_lDeltatime/1000.0f;
							else
								pActorT->fPosTempVelocity[i2] -= g_lDeltatime/1000.0f;
						}
					}
					if(pActorT->fSize < BOX_NORMAL_SIZE)
					{
						pActorT->fSize += g_lDeltatime/1000.0f;
						if(pActorT->fSize > BOX_NORMAL_SIZE)
							pActorT->fSize = BOX_NORMAL_SIZE;
					}
				}

				switch(pActorT->byType)
				{
					case ACTOR_BOX_NORMAL:
						// Check if we should change the box color:
						for(i2 = 0; i2 < 3; i2++)
							if(pActorT->fColor[i2] < 1.0f)
							{
								pActorT->fColor[i2] += (float) BOX_COLOR_CHANGE_SPEED*g_lDeltatime/10.0f;
								if(pActorT->fColor[i2] > 1.0f)
									pActorT->fColor[i2] = 1.0f;
							}
					break;

					case ACTOR_BOX_RED:
						// Check if we should change the box color:
						for(i2 = 1; i2 < 3; i2++)
							if(pActorT->fColor[i2] > 0.0f)
							{
								pActorT->fColor[i2] -= (float) BOX_COLOR_CHANGE_SPEED*g_lDeltatime/10.0f;
								if(pActorT->fColor[i2] < 0.0f)
									pActorT->fColor[i2] = 0.0f;
							}
						if(pActorT->fColor[0] < 1.0f)
						{
							pActorT->fColor[0] += (float) BOX_COLOR_CHANGE_SPEED*g_lDeltatime/10.0f;
							if(pActorT->fColor[0] > 1.0f)
								pActorT->fColor[0] = 1.0f;
						}
					break;

					case ACTOR_BOX_GREEN:
						if(pActorT->fColor[0] > 0.0f)
						{
							pActorT->fColor[0] -= (float) BOX_COLOR_CHANGE_SPEED*g_lDeltatime/10.0f;
							if(pActorT->fColor[0] < 0.0f)
								pActorT->fColor[0] = 0.0f;
						}
						if(pActorT->fColor[1] < 1.0f)
						{
							pActorT->fColor[1] += (float) BOX_COLOR_CHANGE_SPEED*g_lDeltatime/10.0f;
							if(pActorT->fColor[1] > 1.0f)
								pActorT->fColor[1] = 1.0f;
						}
						if(pActorT->fColor[2] > 0.0f)
						{
							pActorT->fColor[2] -= (float) BOX_COLOR_CHANGE_SPEED*g_lDeltatime/10.0f;
							if(pActorT->fColor[2] < 0.0f)
								pActorT->fColor[2] = 0.0f;
						}
					break;

					case ACTOR_BOX_BLUE:
						// Check if we should change the box color:
						for(i2 = 0; i2 < 2; i2++)
							if(pActorT->fColor[i2] > 0.0f)
							{
								pActorT->fColor[i2] -= (float) BOX_COLOR_CHANGE_SPEED*g_lDeltatime/10.0f;
								if(pActorT->fColor[i2] < 0.0f)
									pActorT->fColor[i2] = 0.0f;
							}
						if(pActorT->fColor[2] < 1.0f)
						{
							pActorT->fColor[2] += (float) BOX_COLOR_CHANGE_SPEED*g_lDeltatime/10.0f;
							if(pActorT->fColor[2] > 1.0f)
								pActorT->fColor[2] = 1.0f;
						}
					break;
				}
			break;

			case ACTOR_HEALTH_OBJ:
			case ACTOR_LIVE_OBJ:
			case ACTOR_PULL_OBJ:
			case ACTOR_THROW_OBJ:
			case ACTOR_FORCE_OBJ:
			case ACTOR_WEAPON_OBJ:
			case ACTOR_POINT_OBJ:
			case ACTOR_GHOST_OBJ:
			case ACTOR_TIME_OBJ:
			case ACTOR_STEP_OBJ:
			case ACTOR_SPEED_OBJ:
			case ACTOR_WING_OBJ:
			case ACTOR_SHIELD_OBJ:
			case ACTOR_JUMP_OBJ:
			case ACTOR_AIR_OBJ:
				// Normalize the actors color:
				for(i2 = 0; i2 < 3; i2++)
					if(pActorT->fColor[i2] < 1.0f)
					{
						pActorT->fColor[i2] += (float) g_lDeltatime/OBJECT_PAINT_SPEED;
						if(pActorT->fColor[i2] > 1.0f)
							pActorT->fColor[i2] = 1.0f;
					}

				// Has the player this object collected?
				if(pActorT->bGoingDeath)
				{ // Yes: (Killing sequenze)
					pActorT->fSize -= g_lDeltatime/OBJECT_KILLING_SPEED;
					if(pActorT->fSize < 0.0f)
					{
						pActorT->bActive = FALSE;
						pLevel->pField[pActorT->iFieldID].pObject = FALSE;
					}
				}
				else
				if(pActorT->byType == ACTOR_LIVE_OBJ)
				{ // Change the size:
					if(pActorT->fSize > pActorT->fPosTempTo[X]+0.001f ||
					   pActorT->fSize < pActorT->fPosTempTo[X]-0.001f)
						pActorT->fPosTempTo[X] = 1.0f+(rand() % 100)/200.0f;
					pActorT->fSize += (float) g_lDeltatime*pActorT->fPosTempVelocity[X]/500.0f;
					if(pActorT->fSize > pActorT->fPosTempTo[X])
						pActorT->fPosTempVelocity[X] -= (float) g_lDeltatime/800;
					else
						pActorT->fPosTempVelocity[X] += (float) g_lDeltatime/800;
					if(pActorT->fPosTempVelocity[X] > 0.5f)
						pActorT->fPosTempVelocity[X] = 0.5f;
					if(pActorT->fPosTempVelocity[X] < -0.5f)
						pActorT->fPosTempVelocity[X] = -0.5f;
				}
				
				// Rotate the object:
				pActorT->fRot[Y] += (float) g_lDeltatime/OBJECT_ROTATE_SPEED;
			break;

			case ACTOR_PLAYER_SHOT:
				// Rotate the object:
				pActorT->fRot[X] += (float) g_lDeltatime/SHOT_ROTATE_SPEED;
				pActorT->fRot[Y] += (float) g_lDeltatime/SHOT_ROTATE_SPEED;
				pActorT->fRot[Z] += (float) g_lDeltatime/SHOT_ROTATE_SPEED;
				if(pActorT->bGoingDeath)
				{ // Yes: (Killing sequenze)
					pActorT->fSize -= g_lDeltatime/SHOT_KILLING_SPEED;
					if(pActorT->fSize < 0.0f)
					{
						pActorT->bActive = FALSE;
						ParticleManager.pSystem[pActorT->iTempFieldID].bGoingInActive = TRUE;
					}
					break;
				}
				// Move the shot:
				if(pActorT->byDirection == RIGHT)
					pActorT->fWorldPos[X] += (float) g_lDeltatime/PLAYER_SHOT_SPEED;
				else
				if(pActorT->byDirection == DOWN)
					pActorT->fWorldPos[Y] += (float) g_lDeltatime/PLAYER_SHOT_SPEED;
				else
				if(pActorT->byDirection == LEFT)
					pActorT->fWorldPos[X] -= (float) g_lDeltatime/PLAYER_SHOT_SPEED;
				else
				if(pActorT->byDirection == UP)
					pActorT->fWorldPos[Y] -= (float) g_lDeltatime/PLAYER_SHOT_SPEED;
				if(pActorT->fWorldPos[X] < 0.0f-pLevel->Header.fFieldWidth/2 || 
				   pActorT->fWorldPos[Y] < 0.0f-pLevel->Header.fFieldHeight/2 ||
				   pActorT->fWorldPos[X] > pLevel->Header.fWholeWidth-pLevel->Header.fFieldWidth*1.5f ||
				   pActorT->fWorldPos[Y] > pLevel->Header.fWholeHeight-pLevel->Header.fFieldHeight*1.5f)
				{ // The shot is now outside of the level:
					pActorT->bGoingDeath = TRUE;
					break;
				}
				// Check if the shot has hit something:
				COMPUTE_FIELD_POS(pActorT->fWorldPos[X]+0.5f, pActorT->fWorldPos[Y]+0.5f, iXT, iYT);
				GET_FIELD_ID(iXT, iYT, i2);
				pActorT->iFieldID = i2;
				pFieldT = &pLevel->pField[i2];
				if(pFieldT->bWall)
				{ // We hit a wall:
					// Does we hit a box?
					if(pFieldT->pActor &&
					   pActorT->fWorldPos[Z] < pFieldT->pActor->fWorldPos[Z]+pActorT->fSize/2 &&
				       pActorT->fWorldPos[Z] > pFieldT->pActor->fWorldPos[Z]-pActorT->fSize/2)
					{ // Yes. Make damage:
						pActorT->bGoingDeath = TRUE;
					    pActorT = pFieldT->pActor;
					   // Make the shock effect:
						pActorT->fPosTemp[X] += (float) iX/10.0f;
						pActorT->fPosTemp[Y] += (float) iY/10.0f;
						pActorT->fPosTempVelocity[X] += (float) iX/15.0f;
						pActorT->fPosTempVelocity[Y] += (float) iY/15.0f;
						DamageBox(pActorT);
					}
					else
					{ // Check if the shot is about a wall:
						if(!pFieldT->pActor)
						{
							fRayDirection[X] = 0.0f;
							fRayDirection[Y] = 0.0f;
							fRayDirection[Z] = 1.0f;

							// Get the height of the center:
							pLevel->ComputeHeight(pActorT->fWorldPos[X]+0.5f, pActorT->fWorldPos[Y]+0.5f, fRayDirection, &fPoint, FACE_FRONT, 0.1f);
							if(fPoint[Z] <= pActorT->fWorldPos[Z]-0.5f)
								pActorT->bGoingDeath = TRUE;
						}
					}
				}
				else
				{
					// Did we hit the floor? (a very height one...)
					fRayDirection[X] = 0.0f;
					fRayDirection[Y] = 0.0f;
					fRayDirection[Z] = 1.0f;

					// Get the height of the center:
					pLevel->ComputeHeight(pActorT->fWorldPos[X]+0.5f, pActorT->fWorldPos[Y]+0.5f, fRayDirection, &fPoint, FACE_FLOOR, 0.1f);
					if(fPoint[Z] <= pActorT->fWorldPos[Z]-0.5f)
						pActorT->bGoingDeath = TRUE;
				}
			break;

			case ACTOR_ENEMY_HIRO:
				CheckEnemyHiro(pActorT, bEditor);
			break;

			case ACTOR_ENEMY_MOBMOB:
				CheckEnemyMobmob(pActorT, bEditor);
			break;

			case ACTOR_ENEMY_X3:
				CheckEnemyX3(pActorT, bEditor);
			break;
		}
	}
	if(bEditor)
	{
		OktaActor.bActive = FALSE;
		return;
	}
	// Check the Okta:
	if(OktaActor.bActive && !pLevel->State.bLevelComplete)
	{ // The Okta hunts the player and trie to kill him:
		if((pLevel->Missions.bTimeLimit && pLevel->Missions.iTimeLimit > 0) ||
		   (pLevel->Missions.bStepsLimit && pLevel->Missions.iStepsLimit > 0) ||
		   PlayerInfo.bGhost || PlayerInfo.bShield)
		{ // Ok, give the player a second change:
			OktaActor.fWorldPos[Z] -= (float) g_lDeltatime/70;
			if(OktaActor.fWorldPos[Z] < pPlayer->fWorldPos[Z]+pCamera->fZ)
				OktaActor.bActive = FALSE;
		}
		else
		{
			if(OktaActor.fWorldPos[Z] >= pPlayer->fWorldPos[Z])
			{ // Yea, the Okta has the player!!
				OktaActor.bThrow = TRUE;
				pPlayer->fPower = 0.0f;
			}
			else
			{
				if((OktaActor.fWorldPos[X] == pPlayer->fWorldPos[X] && 
				   OktaActor.fWorldPos[Y] == pPlayer->fWorldPos[Y]) || 
				   OktaActor.fWorldPos[Z] < pPlayer->fWorldPos[Z]-4.0f)
				{
					OktaActor.fWorldPos[Z] += (float) g_lDeltatime/100;
					FLOAT3 fRayDirection, fPoint;

					// Ray direction for the 'normal' test points:
					fRayDirection[X] = 0.0f;
					fRayDirection[Y] = 0.0f;
					fRayDirection[Z] = 1.0f;

					pFieldT = pLevel->ComputeHeight(OktaActor.fWorldPos[X]+0.5f, OktaActor.fWorldPos[Y]+0.5f, fRayDirection, &fPoint, FACE_FRONT, 3.0f);
					if(pFieldT && OktaActor.fWorldPos[Z] > fPoint[Z])
						OktaActor.fWorldPos[Z] = fPoint[Z];
					pFieldT = pLevel->ComputeHeight(OktaActor.fWorldPos[X]+0.2f, OktaActor.fWorldPos[Y]+0.2f, fRayDirection, &fPoint, FACE_FRONT, 3.0f);
					if(pFieldT && OktaActor.fWorldPos[Z] > fPoint[Z])
						OktaActor.fWorldPos[Z] = fPoint[Z];
					pFieldT = pLevel->ComputeHeight(OktaActor.fWorldPos[X]+0.8f, OktaActor.fWorldPos[Y]+0.2f, fRayDirection, &fPoint, FACE_FRONT, 3.0f);
					if(pFieldT && OktaActor.fWorldPos[Z] > fPoint[Z])
						OktaActor.fWorldPos[Z] = fPoint[Z];
					pFieldT = pLevel->ComputeHeight(OktaActor.fWorldPos[X]+0.8f, OktaActor.fWorldPos[Y]+0.8f, fRayDirection, &fPoint, FACE_FRONT, 3.0f);
					if(pFieldT && OktaActor.fWorldPos[Z] > fPoint[Z])
						OktaActor.fWorldPos[Z] = fPoint[Z];
					pFieldT = pLevel->ComputeHeight(OktaActor.fWorldPos[X]+0.2f, OktaActor.fWorldPos[Y]+0.8f, fRayDirection, &fPoint, FACE_FRONT, 3.0f);
					if(pFieldT && OktaActor.fWorldPos[Z] > fPoint[Z])
						OktaActor.fWorldPos[Z] = fPoint[Z];
				}
				else
				{
					OktaActor.fWorldPos[Z] -= (float) g_lDeltatime/70;
					if(OktaActor.fWorldPos[Z] <= pPlayer->fWorldPos[Z]-4.0f)
					{
						OktaActor.fWorldPos[Z] = pPlayer->fWorldPos[Z]-4.0f;
						if(OktaActor.fWorldPos[X] < pPlayer->fWorldPos[X])
						{
							OktaActor.fWorldPos[X] += (float) g_lDeltatime/100;
							if(OktaActor.fWorldPos[X] > pPlayer->fWorldPos[X])
								OktaActor.fWorldPos[X] = pPlayer->fWorldPos[X];
						}
						else
						if(OktaActor.fWorldPos[X] > pPlayer->fWorldPos[X])
						{
							OktaActor.fWorldPos[X] -= (float) g_lDeltatime/100;
							if(OktaActor.fWorldPos[X] < pPlayer->fWorldPos[X])
								OktaActor.fWorldPos[X] = pPlayer->fWorldPos[X];
						}
						if(OktaActor.fWorldPos[Y] < pPlayer->fWorldPos[Y])
						{
							OktaActor.fWorldPos[Y] += (float) g_lDeltatime/100;
							if(OktaActor.fWorldPos[Y] > pPlayer->fWorldPos[Y])
								OktaActor.fWorldPos[Y] = pPlayer->fWorldPos[Y];
						}
						else
						if(OktaActor.fWorldPos[Y] > pPlayer->fWorldPos[Y])
						{
							OktaActor.fWorldPos[Y] -= (float) g_lDeltatime/100;
							if(OktaActor.fWorldPos[Y] < pPlayer->fWorldPos[Y])
								OktaActor.fWorldPos[Y] = pPlayer->fWorldPos[Y];
						}
					}
				}
			}
		}
	}
} // end CheckActors()

void AnimateActorModel(ACTOR *pActorT, AS_MD2_MODEL pModel, long lSpeed, char byAnimation)
{ // begin AnimateActorModel()
	pActorT->dwAniDeltaTime = g_lNow-pActorT->dwAniTime;
	// Animate the md2 model:
	pActorT->iNextAniStep = pActorT->iAniStep+1;
	if(pActorT->iNextAniStep >= pModel.Ani.anim[byAnimation].lastFrame)
		pActorT->iNextAniStep = pModel.Ani.anim[byAnimation].firstFrame;
	if(g_lNow-pActorT->dwAniTime > ((DWORD) lSpeed))
	{
		pActorT->dwAniTime = g_lNow;
		pActorT->iAniStep++;
		if(pActorT->iAniStep >= pModel.Ani.anim[byAnimation].lastFrame)
			pActorT->iAniStep = pModel.Ani.anim[byAnimation].firstFrame;
	}
} // end AnimateActorModel()

void KillBox(ACTOR *pActorT)
{ // begin KillBox()
	FIELD *pFieldT;
	ACTOR *pActorT2;
	short i, i2, i3, i4, x, y;

 	if(pActorT->bGoingDeath || pActorT->bHeavy)
		return;
   	DisableBoxDocking(pActorT);
	pActorT->bGoingDeath = TRUE;
	DeleteActorType(pActorT);
	// Check the box type:
	if(pActorT->byType == ACTOR_BOX_RED)
	{ // Kill all other actors around this box, too:
		for(y = -1; y < 2; y++)
		{
			for(x = -1; x < 2; x++)
			{
				if(pActorT->iFieldPos[X]+x < 0 ||
				   pActorT->iFieldPos[X]+x > pLevel->Header.iWidth-2 ||
				   pActorT->iFieldPos[Y]+y < 0 ||
				   pActorT->iFieldPos[Y]+y > pLevel->Header.iHeight-2)
					continue;
				// Check the field:
				GET_FIELD_ID((pActorT->iFieldPos[X]+x), (pActorT->iFieldPos[Y]+y), i2);
				pFieldT = &pLevel->pField[i2];
				pActorT2 = pFieldT->pActor;
				if(pActorT2 && !pActorT2->bGoingDeath)
				{
					if(pActorT2->byType == ACTOR_BOX_NORMAL ||
					   pActorT2->byType == ACTOR_BOX_RED ||
					   pActorT2->byType == ACTOR_BOX_GREEN ||
					   pActorT2->byType == ACTOR_BOX_BLUE)
							KillBox(pActorT2);
					else
					{
						if(pActorT2->byType == ACTOR_PLAYER)
						{
							if(!PlayerInfo.bShield)
								pActorT2->fPower = 0.0f; // Kill the player:
						}
						else
							pActorT2->bGoingDeath = TRUE;
					}
				}
				else
					if(pFieldT->bWall && !pFieldT->bIndestructibleWall && !pFieldT->bWallHole)
						pLevel->SetFieldWall(pFieldT->iXField, pFieldT->iYField, FALSE, FALSE);  // Destroy this wall:
				if(pFieldT->pBridgeActor)
					KillBox(pFieldT->pBridgeActor);
				if(pFieldT->pObject)
					pFieldT->pObject->bGoingDeath = TRUE;

				for(i = 0; i < MAX_ACTORS; i++)
				{
					pActorT2 = &Actor[i];
					if(!pActorT2->bActive || pActorT2->iFieldID != i2)
						continue;
					if(pActorT2->byType == ACTOR_ENEMY_MOBMOB ||
					   pActorT2->byType == ACTOR_ENEMY_X3)
						pActorT2->bGoingDeath = TRUE;
				}
			}
		}
	}
	else
	if(pActorT->byType == ACTOR_BOX_GREEN)
	{ // Deactivate this field:
		GET_FIELD_ID(pActorT->iFieldPos[X], pActorT->iFieldPos[Y], i2);
		pFieldT = &pLevel->pField[i2];
		pFieldT->bActive = FALSE;
		if(pLevel->pSurface[pFieldT->iSurface[FACE_FLOOR][0]].Header.bAnchor)
		{
			switch(pLevel->pSurface[pFieldT->iSurface[FACE_FLOOR][0]].Header.byAnchorType)
			{
				case 0: pLevel->Header.iForAllAnchors--; break;
				case 1: pLevel->Header.iNormalAnchors--; break;
				case 2: pLevel->Header.iRedAnchors--; break;
				case 3: pLevel->Header.iGreenAnchors--; break;
				case 4: pLevel->Header.iBlueAnchors--; break;
			}
		}
		if(pFieldT->pBridgeActor)
		{		
			KillBox(pFieldT->pBridgeActor);
			pFieldT->bActive = FALSE;
		}
		pFieldT->pBridgeActor = NULL;
		if(pFieldT->pObject)
			pFieldT->pObject->bActive = NULL;
   		pFieldT->pObject = NULL;

		// Damage the boxes (and player) around this green box:
   		for(y = -1; y < 2; y++)
		{
			for(x = -1; x < 2; x++)
			{
				if(pActorT->iFieldPos[X]+x < 0 ||
				   pActorT->iFieldPos[X]+x > pLevel->Header.iWidth-2 ||
				   pActorT->iFieldPos[Y]+y < 0 ||
				   pActorT->iFieldPos[Y]+y > pLevel->Header.iHeight-2)
					continue;
				// Check the field:
				GET_FIELD_ID((pActorT->iFieldPos[X]+x), (pActorT->iFieldPos[Y]+y), i2);
				pFieldT = &pLevel->pField[i2];
				if(pFieldT->pActor)
				{
					switch(pFieldT->pActor->byType)
					{
						// Damage the box if there is one:
						case ACTOR_BOX_NORMAL:
						case ACTOR_BOX_RED:
						case ACTOR_BOX_GREEN:
						case ACTOR_BOX_BLUE:
							DamageBox(pFieldT->pActor);
						break;
					
						// If the player is near this green box he will be damaged, too!
						case ACTOR_PLAYER:
							pPlayer->fPower -= 20.0f;
							MakePlayerCameraRotation(ACTION_PLAYER_PAIN_2);
							if(pPlayer->byAction != ACTION_PLAYER_PAIN_2)
							{
								pPlayer->byAction = ACTION_PLAYER_PAIN_2;
								pPlayer->byAnimation = 4;
								pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
								pPlayer->dwAniTime = g_lNow;
							}
						break;
					}
					// Make the actor a little bit green:
					pFieldT->pActor->fColor[0] -= 0.3f;
					pFieldT->pActor->fColor[1] += 0.3f;
					pFieldT->pActor->fColor[2] -= 0.3f;
					for(i3 = 0; i3 < 3; i3++)
					{
						if(pFieldT->pActor->fColor[i3] < 0.0f)
							pFieldT->pActor->fColor[i3] = 0.0f;
						if(pFieldT->pActor->fColor[i3] > 1.0f)
							pFieldT->pActor->fColor[i3] = 1.0f;
					}
				}
				// Make the fields a little bit green:
				for(i3 = 0; i3 < 6; i3++)
					for(i4 = 0; i4 < 3; i4++)
					{
						pLevel->fColor[pFieldT->iFace[i3][i4]][0] -= 0.05f;
						if(pLevel->fColor[pFieldT->iFace[i3][i4]][0] < 0.0f)
							pLevel->fColor[pFieldT->iFace[i3][i4]][0] = 0.0f;
						pLevel->fColor[pFieldT->iFace[i3][i4]][1] += 0.05f;
						if(pLevel->fColor[pFieldT->iFace[i3][i4]][1] > 1.0f)
							pLevel->fColor[pFieldT->iFace[i3][i4]][1] = 1.0f;
						pLevel->fColor[pFieldT->iFace[i3][i4]][2] -= 0.05f;
						if(pLevel->fColor[pFieldT->iFace[i3][i4]][2] < 0.0f)
							pLevel->fColor[pFieldT->iFace[i3][i4]][2] = 0.0f;
					}
			}
		}
	}
	else
	if(pActorT->byType == ACTOR_BOX_BLUE)
	{ // Paint all other actors around this box blue:
   		for(y = -1; y < 2; y++)
		{
			for(x = -1; x < 2; x++)
			{
				if(pActorT->iFieldPos[X]+x < 0 ||
				   pActorT->iFieldPos[X]+x > pLevel->Header.iWidth-2 ||
				   pActorT->iFieldPos[Y]+y < 0 ||
				   pActorT->iFieldPos[Y]+y > pLevel->Header.iHeight-2)
					continue;
				// Check the field:
				GET_FIELD_ID((pActorT->iFieldPos[X]+x), (pActorT->iFieldPos[Y]+y), i2);
				pFieldT = &pLevel->pField[i2];
				if(pFieldT->pActor)
				{
					pActorT2 = pFieldT->pActor;
					if(pActorT2->byType == ACTOR_BOX_NORMAL ||
					   pActorT2->byType == ACTOR_BOX_RED ||
					   pActorT2->byType == ACTOR_BOX_GREEN)
					{
						if(!pActorT2->bGoingDeath)
						{
							DeleteActorType(pActorT2);
							pActorT2->byType = ACTOR_BOX_BLUE;
							CheckActorField(pActorT2);
							pLevel->Header.iBlueBoxes++;
							if(pActorT2->bBridge)
								pLevel->State.iNoneFreeBlueBoxes++;
						}
					}
					else
					{
						pActorT2->fColor[0] = 0.0f;
						pActorT2->fColor[1] = 0.0f;
						pActorT2->fColor[2] = 1.0f;
					}
				}
				if(pFieldT->pObject)
				{
					pActorT2 = pFieldT->pObject;
					pActorT2->fColor[0] = 0.0f;
					pActorT2->fColor[1] = 0.0f;
					pActorT2->fColor[2] = 1.0f;
				}

				for(i = 0; i < MAX_ACTORS; i++)
				{
					pActorT2 = &Actor[i];
					if(!pActorT2->bActive || pActorT2->iFieldID != i2)
						continue;
					if(pActorT2->byType == ACTOR_ENEMY_MOBMOB ||
					   pActorT2->byType == ACTOR_ENEMY_X3)
					{
						pActorT2->fColor[0] = 0.0f;
						pActorT2->fColor[1] = 0.0f;
						pActorT2->fColor[2] = 1.0f;
					}
				}

				if(pFieldT->pBridgeActor && !pFieldT->pBridgeActor->bGoingDeath &&
				   pFieldT->pBridgeActor->byType != ACTOR_BOX_BLUE)
				{
					DeleteActorType(pFieldT->pBridgeActor);
					pFieldT->pBridgeActor->byType = ACTOR_BOX_BLUE;
					pLevel->Header.iBlueBoxes++;
					if(pActorT2->bBridge)
						pLevel->State.iNoneFreeBlueBoxes++;
				}
				// Make the field blue:
				for(i3 = 0; i3 < 6; i3++)
					for(i4 = 0; i4 < 3; i4++)
					{
						pLevel->fColor[pFieldT->iFace[i3][i4]][0] -= 0.4f;
						if(pLevel->fColor[pFieldT->iFace[i3][i4]][0] < 0.0f)
							pLevel->fColor[pFieldT->iFace[i3][i4]][0] = 0.0f;
						pLevel->fColor[pFieldT->iFace[i3][i4]][1] -= 0.4f;
						if(pLevel->fColor[pFieldT->iFace[i3][i4]][1] < 0.0f)
							pLevel->fColor[pFieldT->iFace[i3][i4]][1] = 0.0f;
						pLevel->fColor[pFieldT->iFace[i3][i4]][2] += 0.4f;
						if(pLevel->fColor[pFieldT->iFace[i3][i4]][2] > 1.0f)
							pLevel->fColor[pFieldT->iFace[i3][i4]][2] = 1.0f;
					}
			}
		}
	}
} // end KillBox()

void CheckBoxThrow(ACTOR *pActorT)
{ // begin CheckBoxThrow()
	ACTOR *pActorT2;

	// Check if this box was thrown:
	if(!pActorT->bThrow || pActorT->bMove)
		return;

	// Yes! It should fly till a wall or an actor is stopping it!
	short iX, iY;
	FIELD *pFieldT;

	// Setup x/y direction:
	switch(pActorT->byDirection)
	{
		case RIGHT: iX = 1; iY = 0; break;
		case DOWN: iX = 0; iY = 1; break;
		case LEFT: iX = -1; iY = 0; break;
		case UP: iX = 0; iY = -1; break;
	}
	pFieldT = &pLevel->pField[(pActorT->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pActorT->iFieldPos[X]+iX];

	// Check if we could fly:
	if(pActorT->iFieldPos[X]+iX < 0 || pActorT->iFieldPos[X]+iX >= pLevel->Header.iWidth-1 ||
	   pActorT->iFieldPos[Y]+iY < 0 || pActorT->iFieldPos[Y]+iY >= pLevel->Header.iHeight-1 ||
	   (!pLevel->pField[(pActorT->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pActorT->iFieldPos[X]+iX].pBridgeActor &&
	    pLevel->pField[(pActorT->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pActorT->iFieldPos[X]+iX].bWall))
	{
		pActorT->fPosTemp[X] += (float) iX/10.0f;
		pActorT->fPosTemp[Y] += (float) iY/10.0f;
		pActorT->fPosTempVelocity[X] += (float) iX/15.0f;
		pActorT->fPosTempVelocity[Y] += (float) iY/15.0f;
		if(pActorT->iFieldPos[X]+iX >= 0 && pActorT->iFieldPos[X]+iX < pLevel->Header.iWidth-1 &&
		   pActorT->iFieldPos[Y]+iY >= 0 && pActorT->iFieldPos[Y]+iY < pLevel->Header.iHeight-1 &&
	       pLevel->pField[(pActorT->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pActorT->iFieldPos[X]+iX].pActor)
		{ // A other holds the box: (shock effect)
			pActorT2 = pLevel->pField[(pActorT->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pActorT->iFieldPos[X]+iX].pActor;
			pActorT2->fPosTemp[X] += (float) iX/10.0f;
			pActorT2->fPosTemp[Y] += (float) iY/10.0f;
			pActorT2->fPosTempVelocity[X] += (float) iX/10.0f;
			pActorT2->fPosTempVelocity[Y] += (float) iY/10.0f;
			// Damage the hit box:
			DamageBox(pActorT2);
		};
		// Damage the thrown box:
		DamageBox(pActorT);
		pActorT->bThrow = FALSE;
		return; // The box is stopped by a wall!!
	}
	// The box fly 'again':
	pActorT->bMove = TRUE;
	DisableBoxDocking(pActorT);
	// Check if we kill or hit now a actor:
	pFieldT = &pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->Header.iWidth+pPlayer->iFieldPos[X]+iX];
	if(!pFieldT->pActor)
	{ // There is nothing to kill ;-(
		pFieldT->pActor = pActorT;
		return; 
	}
	// Yep, Yep, Yep!! TERMINATE it!! ;->

} // end CheckBoxThrow()

void DamageBox(ACTOR *pActorT)
{ // begin DamageBox()
	float fDeadDamage;
	
	if(pActorT->byType != ACTOR_BOX_NORMAL &&
	   pActorT->byType != ACTOR_BOX_RED &&
	   pActorT->byType != ACTOR_BOX_GREEN &&
	   pActorT->byType != ACTOR_BOX_BLUE)
		return;
	if(pActorT->bHeavy)
		return; // Could not be damaged!
	pActorT->fPower -= 0.1f;
	fDeadDamage = 0.0f;
	switch(pActorT->byType)
	{
		case ACTOR_BOX_NORMAL: fDeadDamage -= 0.1f; break;
		case ACTOR_BOX_GREEN: fDeadDamage -= 0.2f; break;
		case ACTOR_BOX_BLUE: fDeadDamage -= 0.3f; break;
	}
	// Check the power:
	if(pActorT->fPower < fDeadDamage)
   	   KillBox(pActorT); // The box is no longer!
} // end DamageBox()

void DrawBoundingBox(float fBox[2][3], float fScale)
{ // begin DrawBoundingBox()
	glDisable(GL_TEXTURE_2D);
	glColor3f(1.0f, 1.0f, 1.0f);
	glLineWidth(3.0f);
	// Left side:
	glBegin(GL_LINE_LOOP);
		glVertex3f(fBox[0][X], fBox[0][Y], fBox[0][Z]);
		glVertex3f(fBox[0][X], fBox[1][Y], fBox[0][Z]);
		glVertex3f(fBox[1][X], fBox[1][Y], fBox[0][Z]);
		glVertex3f(fBox[1][X], fBox[0][Y], fBox[0][Z]);
	glEnd();
	// Right side:
	glBegin(GL_LINE_LOOP);
		glVertex3f(fBox[0][X], fBox[0][Y], fBox[1][Z]);
		glVertex3f(fBox[0][X], fBox[1][Y], fBox[1][Z]);
		glVertex3f(fBox[1][X], fBox[1][Y], fBox[1][Z]);
		glVertex3f(fBox[1][X], fBox[0][Y], fBox[1][Z]);
	glEnd();
	// The other four lines:
	glBegin(GL_LINES);
		glVertex3f(fBox[0][X], fBox[0][Y], fBox[0][Z]);
		glVertex3f(fBox[0][X], fBox[0][Y], fBox[1][Z]);
		glVertex3f(fBox[0][X], fBox[1][Y], fBox[0][Z]);
		glVertex3f(fBox[0][X], fBox[1][Y], fBox[1][Z]);
		glVertex3f(fBox[1][X], fBox[1][Y], fBox[0][Z]);
		glVertex3f(fBox[1][X], fBox[1][Y], fBox[1][Z]);
		glVertex3f(fBox[1][X], fBox[0][Y], fBox[0][Z]);
		glVertex3f(fBox[1][X], fBox[0][Y], fBox[1][Z]);
	glEnd();
	glEnable(GL_TEXTURE_2D);
} // end DrawBoundingBox()

void DisableBoxDocking(ACTOR *pActorT)
{ // begin DisableBoxDocking()
	// Was the box already docked?
	if(!pActorT->bDocked)
		return;
	// Yes:
	switch(pLevel->pField[pActorT->iFieldID].pSurface[FACE_FLOOR][0]->Header.byAnchorType)
	{
		case 0: pLevel->State.iUsedForAllAnchors--; break;
		case 1: pLevel->State.iUsedNormalAnchors--; break;
		case 2: pLevel->State.iUsedRedAnchors--; break;
		case 3: pLevel->State.iUsedGreenAnchors--; break;
		case 4: pLevel->State.iUsedBlueAnchors--; break;
	}
	pActorT->bDocked = FALSE;
	pActorT->fFieldPos[Z] = 0.0f;
	switch(pActorT->byType)
	{
		case ACTOR_BOX_NORMAL: pLevel->State.iNoneFreeNormalBoxes--; break;
		case ACTOR_BOX_RED: pLevel->State.iNoneFreeRedBoxes--; break;
		case ACTOR_BOX_GREEN: pLevel->State.iNoneFreeGreenBoxes--; break;
		case ACTOR_BOX_BLUE: pLevel->State.iNoneFreeBlueBoxes--; break;
	}
} // end DisableBoxDocking()

void DeleteActorType(ACTOR *pActorT)
{ // begin DeleteActorType()
	switch(pActorT->byType)
	{
		case ACTOR_BOX_NORMAL: pLevel->Header.iNormalBoxes--; break;
		case ACTOR_BOX_RED: pLevel->Header.iRedBoxes--; break;
		case ACTOR_BOX_GREEN: pLevel->Header.iGreenBoxes--; break;
		case ACTOR_BOX_BLUE: pLevel->Header.iBlueBoxes--; break;
	}
   	if(pActorT->bBridge || pActorT->bDocked)
		DisableNoneFreeBox(pActorT);
} // end DeleteActorType()

void DisableNoneFreeBox(ACTOR *pActorT)
{ // begin DisableNoneFreeBox()
	switch(pActorT->byType)
	{
		case ACTOR_BOX_NORMAL: pLevel->State.iNoneFreeNormalBoxes--; break;
		case ACTOR_BOX_RED: pLevel->State.iNoneFreeRedBoxes--; break;
		case ACTOR_BOX_GREEN: pLevel->State.iNoneFreeGreenBoxes--; break;
		case ACTOR_BOX_BLUE: pLevel->State.iNoneFreeBlueBoxes--; break;
	}
} // end DisableNoneFreeBox()

void SetNoneFreeBox(ACTOR *pActorT)
{ // begin SetNoneFreeBox()
	switch(pActorT->byType)
	{
		case ACTOR_BOX_NORMAL: pLevel->State.iNoneFreeNormalBoxes++; break;
		case ACTOR_BOX_RED: pLevel->State.iNoneFreeRedBoxes++; break;
		case ACTOR_BOX_GREEN: pLevel->State.iNoneFreeGreenBoxes++; break;
		case ACTOR_BOX_BLUE: pLevel->State.iNoneFreeBlueBoxes++; break;
	}
} // end SetNoneFreeBox()

BOOL ActorTurn(ACTOR *pActorT, float fSpeed)
{ // begin ActorTurn()
	// Turn the players direction smoothly:
	if(pActorT->byDirection == RIGHT && pActorT->fRot[Y] != 0.0f)
	{ // Turn to right:
		if(pActorT->fRot[Y] > 180.0f)
		{
			pActorT->fRot[Y] += g_lDeltatime/PLAYER_TURN_SPEED*fSpeed;
			if(pActorT->fRot[Y] > 360.0f)
				pActorT->fRot[Y] = 0.0f;
		}
		else
		if(pActorT->fRot[Y] > 0.0f)
		{
			pActorT->fRot[Y] -= g_lDeltatime/PLAYER_TURN_SPEED*fSpeed;
			if(pActorT->fRot[Y] < 0.0f)
				pActorT->fRot[Y] = 0.0f;
		}
		else
		{
			pActorT->fRot[Y] += g_lDeltatime/PLAYER_TURN_SPEED*fSpeed;
			if(pActorT->fRot[Y] > 0.0f)
				pActorT->fRot[Y] = 0.0f;
		}
		return 1;
	}
	else
	if(pActorT->byDirection == DOWN && pActorT->fRot[Y] != 90.0f)
	{ // Turn to down:
		if(pActorT->fRot[Y] > 90.0f)
		{
			pActorT->fRot[Y] -= g_lDeltatime/PLAYER_TURN_SPEED*fSpeed;
			if(pActorT->fRot[Y] < 90.0f)
				pActorT->fRot[Y] = 90.0f;
		}
		else
		{
			pActorT->fRot[Y] += g_lDeltatime/PLAYER_TURN_SPEED*fSpeed;
			if(pActorT->fRot[Y] > 90.0f)
				pActorT->fRot[Y] = 90.0f;
		}
		return 1;
	}
	else
	if(pActorT->byDirection == LEFT && pActorT->fRot[Y] != 180.0f)
	{ // Turn to left:
		if(pActorT->fRot[Y] > 180.0f)
		{
			pActorT->fRot[Y] -= g_lDeltatime/PLAYER_TURN_SPEED*fSpeed;
			if(pActorT->fRot[Y] < 180.0f)
				pActorT->fRot[Y] = 180.0f;
		}
		else
		{
			pActorT->fRot[Y] += g_lDeltatime/PLAYER_TURN_SPEED*fSpeed;
			if(pActorT->fRot[Y] > 180.0f)
				pActorT->fRot[Y] = 180.0f;
		}
		return 1;
	}
	else
	if(pActorT->byDirection == UP && pActorT->fRot[Y] != 270.0f)
	{ // Turn to up:
		if(pActorT->fRot[Y] < 90.0f)
		{
			pActorT->fRot[Y] -= g_lDeltatime/PLAYER_TURN_SPEED*fSpeed;
			if(pActorT->fRot[Y] < -90.0f)
				pActorT->fRot[Y] = 270.0f;
		}
		else
		if(pActorT->fRot[Y] > 270.0f)
		{
			pActorT->fRot[Y] -= g_lDeltatime/PLAYER_TURN_SPEED*fSpeed;
			if(pActorT->fRot[Y] < 270.0f)
				pActorT->fRot[Y] = 270.0f;
		}
		else
		{
			pActorT->fRot[Y] += g_lDeltatime/PLAYER_TURN_SPEED*fSpeed;
			if(pActorT->fRot[Y] > 270.0f)
				pActorT->fRot[Y] = 270.0f;
		}
		return 1;
	}
	return 0;
} // end ActorTurn()

BOOL CheckBeaming(ACTOR *pActorT)
{ // begin CheckBeaming()
	SURFACE *pSurfaceT;
	FIELD *pFieldT;

	pFieldT = &pLevel->pField[pActorT->iFieldID];
	pSurfaceT = &pLevel->pSurface[pFieldT->iSurface[FACE_FLOOR][0]];
	if(!pSurfaceT->Header.bBeamer || pFieldT->iBeamerTarget == -1 ||
	   pFieldT->fBeamerPower != 1.0f || 
	   pFieldT->pBridgeActor ||
	   !pFieldT->bActive || pActorT->bBeaming)
		return FALSE;
	if(pActorT == pPlayer && PlayerInfo.bGhost)
		return FALSE;

	// Check, if the other side is free:
	if(pLevel->pField[pFieldT->iBeamerTarget].pActor ||
	   pLevel->pField[pFieldT->iBeamerTarget].pEnemy ||
	   pLevel->pField[pFieldT->iBeamerTarget].bWall)
	   return 0; // NO!!
	
	pFieldT->fBeamerPower = 0.0f;
	if(pActorT->byType == ACTOR_ENEMY_MOBMOB ||
	   pActorT->byType == ACTOR_ENEMY_X3)
		pFieldT->pEnemy = NULL;
	else
		pFieldT->pActor = NULL;
	pFieldT->bWall = FALSE;
	pActorT->iFieldID = pFieldT->iBeamerTarget;
	pActorT->iFieldPos[X] = pLevel->pField[pFieldT->iBeamerTarget].iXField;
	pActorT->iFieldPos[Y] = pLevel->pField[pFieldT->iBeamerTarget].iYField;
	if(pActorT->byType == ACTOR_ENEMY_MOBMOB ||
	   pActorT->byType == ACTOR_ENEMY_X3)
		pLevel->pField[pFieldT->iBeamerTarget].pEnemy = pActorT;
	else
	{
		pLevel->pField[pFieldT->iBeamerTarget].pActor = pActorT;
		if(pActorT->byType == ACTOR_BOX_NORMAL ||
		   pActorT->byType == ACTOR_BOX_RED ||
		   pActorT->byType == ACTOR_BOX_GREEN ||
		   pActorT->byType == ACTOR_BOX_BLUE)
			pLevel->pField[pFieldT->iBeamerTarget].bWall = TRUE;
	}
	if(pLevel->pField[pFieldT->iBeamerTarget].pSurface[FACE_FLOOR][0]->Header.bBeamer)
		pLevel->pField[pFieldT->iBeamerTarget].fBeamerPower = 0.0f;
	pActorT->bBeaming = TRUE;
	pActorT->bBeamingStep = 0;
	pActorT->fBeaming = 1.0;
	return TRUE;
} // end CheckBeaming()

BOOL CheckBeamingProcess(ACTOR *pActorT)
{ // begin CheckBeamingProcess()
	FIELD *pFieldT;

	if(!pActorT->bBeaming)
		return 0;
	pActorT->dwAniTime = g_lNow;
	if(!pActorT->bBeamingStep)
	{
		pActorT->fBeaming -= (float) g_lDeltatime/1000;
		if(pActorT->fBeaming < 0.0f)
		{
			pActorT->fBeaming = 0.0f;
			pActorT->bBeamingStep = 1;
			pFieldT = &pLevel->pField[pActorT->iFieldID];
			pActorT->fWorldPos[X] = pActorT->iFieldPos[X]*pLevel->Header.fFieldWidth+pActorT->fFieldPos[X];
			pActorT->fWorldPos[Y] = pActorT->iFieldPos[Y]*pLevel->Header.fFieldHeight+pActorT->fFieldPos[Y];
			if(pActorT == pPlayer)
			{
				float fTemp = pPlayer->fWorldPos[Z];
				ComputeActorHeight(pPlayer, 0.2f);
				pCamera->fPos2[X] = pCamera->fPos[X]+pPlayer->fWorldPos[X]+0.5f;
				pCamera->fPos2[Y] = pCamera->fPos[Y]+pPlayer->fWorldPos[Y]+0.5f;
				pCamera->fPos2[Z] = fTemp-pPlayer->fWorldPos[Z];
			}
		}
	}
	else
	{
		pActorT->fBeaming += (float) g_lDeltatime/1000;
		if(pActorT->fBeaming > 1.0f)
		{
			pActorT->fBeaming = 1.0f;
			pActorT->bBeaming = FALSE;
			if(pActorT == pPlayer && pActorT->byAction == ACTION_JUMP)
			{
				if(!CheckPlayerPushBox(pActorT->byDirection, FALSE))
				{ // The actor jumps againt a wall:
					if(!pLevel->pField[pActorT->iFieldID].bActive)
					{ // The actor falls into a gap:
						pActorT->fPower = 0.0f;
						pActorT->fVelocity[Z] = 0.005f;
					}
					pActorT->byAction = -1;
					pActorT->iTempFieldID = -1;
					pActorT->bMove = FALSE;
					pActorT->bShouldMove = FALSE;
				}
			}
		}
	}
	return 1;
} // end CheckBeamingProcess()
//-----------------------------------------------------------------------------
// File: Level.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Definitions: ***************************************************************
enum {NEW_LEVEL_DIALOG, LEVEL_DIALOG};
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
char byLevelDialogMode,			// In which level dialog we are?
	 byLevelSelecedSide,		// The selected side of something
	 byLevelSelecedType,		// The selected type of something
	 byLevelRotation;			// Rotation storage of something
LEVEL *pLevelT, *pOldLevelTemp; // Level backups
HWND hWndLevel,					// The level dialog handle
	 hWndLevelMissions,			// The level missions dialog handle
	 hWndLevelTools;			// The level tools dialog handle
short iMoveX, iMoveY;			// Move the level
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
LRESULT CALLBACK LevelProc(HWND, UINT, WPARAM, LPARAM);
void NewLevelDialog(void);
void AdjustLevelDialog(void);
LRESULT CALLBACK LevelMissionsProc(HWND, UINT, WPARAM, LPARAM);
void UpdateLevelMissions(void);
LRESULT CALLBACK LevelToolsProc(HWND, UINT, WPARAM, LPARAM);
void UpdateLevelTools(void);
///////////////////////////////////////////////////////////////////////////////


// Functions: *****************************************************************
void UpdateLevelMenuButtons(void)
{ // begin UpdateLevelMenuButtons()
	// Music:
    SendDlgItemMessage(hWndLevel, IDC_LEVEL_MUSIC, BM_SETCHECK, pLevelT->Header.bMusic, 0L);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_MUSIC_FILE), pLevelT->Header.bMusic);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_FIND_MUSIC_FILE), pLevelT->Header.bMusic);
	// Keyword:
    SendDlgItemMessage(hWndLevel, IDC_LEVEL_KEYWORD_CHECKED, BM_SETCHECK, pLevelT->Header.bKeyword, 0L);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_KEYWORD), pLevelT->Header.bKeyword);
	// Fog:
    SendDlgItemMessage(hWndLevel, IDC_LEVEL_FOG, BM_SETCHECK, pLevelT->Environment.bFog, 0L);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_FOG_COLOR_R), pLevelT->Environment.bFog);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_FOG_COLOR_G), pLevelT->Environment.bFog);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_FOG_COLOR_B), pLevelT->Environment.bFog);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_FOG_DENSITY), pLevelT->Environment.bFog);
	// Water:
    SendDlgItemMessage(hWndLevel, IDC_LEVEL_WATER, BM_SETCHECK, pLevelT->Environment.bWater, 0L);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_WATER_COLOR_R), pLevelT->Environment.bWater);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_WATER_COLOR_G), pLevelT->Environment.bWater);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_WATER_COLOR_B), pLevelT->Environment.bWater);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_WATER_HEIGHT), pLevelT->Environment.bWater);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_WATER_DENSITY), pLevelT->Environment.bWater);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_WATER_TEXTURE), pLevelT->Environment.bWater);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_WATER_ACID), pLevelT->Environment.bWater);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_WATER_LAVA), pLevelT->Environment.bWater);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_WATER_ENVIRONMENT_COLOR_R), pLevelT->Environment.bWater);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_WATER_ENVIRONMENT_COLOR_G), pLevelT->Environment.bWater);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_WATER_ENVIRONMENT_COLOR_B), pLevelT->Environment.bWater);
    SendDlgItemMessage(hWndLevel, IDC_LEVEL_WATER_ACID, BM_SETCHECK, pLevelT->Environment.bWaterAcid, 0L);
    SendDlgItemMessage(hWndLevel, IDC_LEVEL_WATER_LAVA, BM_SETCHECK, pLevelT->Environment.bWaterLava, 0L);
	SendDlgItemMessage(hWndLevel, IDC_LEVEL_WATER_TEXTURE, BM_SETCHECK, pLevelT->Environment.bWaterSurface, 0L);
    SendDlgItemMessage(hWndLevel, IDC_LEVEL_WATER_ENVIRONMENT, BM_SETCHECK, pLevelT->Environment.bWaterEnvironment, 0L);
    if(pLevelT->Environment.bWater)
		EnableWindow(GetDlgItem(hWndLevel, ID_LEVEL_WATER_SURFACE_LIST), pLevelT->Environment.bWaterSurface);
	else
		EnableWindow(GetDlgItem(hWndLevel, ID_LEVEL_WATER_SURFACE_LIST), FALSE);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_WATER_ENVIRONMENT), pLevelT->Environment.bWater);
    if(pLevelT->Environment.bWaterEnvironment && pLevelT->Environment.bWater)
	{
		EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_WATER_ENVIRONMENT_DENSITY), TRUE);
		EnableWindow(GetDlgItem(hWndLevel, ID_LEVEL_WATER_ENVIRONMENT_SURFACE_LIST), TRUE);
	}
	else
	{
		EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_WATER_ENVIRONMENT_DENSITY), FALSE);
		EnableWindow(GetDlgItem(hWndLevel, ID_LEVEL_WATER_ENVIRONMENT_SURFACE_LIST), FALSE);
	}
	// Camera:
    SendDlgItemMessage(hWndLevel, IDC_LEVEL_FREE_CAMERA, BM_SETCHECK, pLevelT->Camera.bFreeCamera, 0L);
    SendDlgItemMessage(hWndLevel, IDC_LEVEL_PLAYER_CAMERA, BM_SETCHECK, pLevelT->Camera.bPlayerCamera, 0L);
    SendDlgItemMessage(hWndLevel, IDC_LEVEL_STANDART_CAMERA, BM_SETCHECK, pLevelT->Camera.bStandartCamera, 0L);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_STANDART_CAMERA), pLevelT->Camera.bFreeCamera);
	if(!pLevelT->Header.iCameraScripts)
	{
		EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_CAMERA_START), FALSE);
		EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_CAMERA_END), FALSE);
		pLevelT->Camera.bStartCamera = pLevelT->Camera.bEndCamera = FALSE;
	}
	else
	{
		EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_CAMERA_START), TRUE);
		EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_CAMERA_END), TRUE);
	}
    SendDlgItemMessage(hWndLevel, IDC_LEVEL_CAMERA_START, BM_SETCHECK, pLevelT->Camera.bStartCamera, 0L);
    SendDlgItemMessage(hWndLevel, IDC_LEVEL_CAMERA_END, BM_SETCHECK, pLevelT->Camera.bEndCamera, 0L);
    SendDlgItemMessage(hWndLevel, IDC_LEVEL_CAMERA_END_LOOP, BM_SETCHECK, pLevelT->Camera.bEndCameraLoop, 0L);
    SendDlgItemMessage(hWndLevel, IDC_LEVEL_SINGLE, BM_SETCHECK, pLevelT->Header.bSingle, 0L);
	if(pLevelT->Header.bSingle)
	{
		EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_END_SCREEN), FALSE);
		pLevelT->Header.bEndScreen = TRUE;
	}
	else
		EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_END_SCREEN), TRUE);
    SendDlgItemMessage(hWndLevel, IDC_LEVEL_END_SCREEN, BM_SETCHECK, pLevelT->Header.bEndScreen, 0L);
	EnableWindow(GetDlgItem(hWndLevel, ID_LEVEL_CAMERA_START_CAMERA), pLevelT->Camera.bStartCamera);
	EnableWindow(GetDlgItem(hWndLevel, ID_LEVEL_CAMERA_END_CAMERA), pLevelT->Camera.bEndCamera);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_CAMERA_END_LOOP), pLevelT->Camera.bEndCamera);
    SendDlgItemMessage(hWndLevel, IDD_LEVEL_INDESTRUCTIBLE_WALL, BM_SETCHECK, bIndestructibleWallStandart, 0L);
} // end UpdateLevelMenuButtons()

LRESULT CALLBACK LevelProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin LevelProc()
    char byTemp[256];
	char *pbyTemp;
	short i, i2;

	switch(iMessage)
    {
        case WM_INITDIALOG:
				_AS->WriteLogMessage("Open level dialog");
				hWndLevel = hWnd;
				byLevelSelecedSide = 0;
				byLevelSelecedType = 0;
				byLevelRotation = 0;
				// Texts:
				if(byLevelDialogMode == NEW_LEVEL_DIALOG)
					SetWindowText(hWnd, T_CreateANewLevel);
				else
					SetWindowText(hWnd, T_AdjustLevel);	
				SetDlgItemText(hWnd, IDC_LEVEL_KEYWORD_CHECKED, T_Keyword);
				SetDlgItemText(hWnd, IDC_LEVEL_MUSIC, T_Music);
				SetDlgItemText(hWnd, IDC_LEVEL_FOG, T_Fog);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER, T_Water);
				SetDlgItemText(hWnd, IDC_LEVEL_LEVEL_T, T_Level);
				SetDlgItemText(hWnd, IDC_LEVEL_FIELD_T, T_Field);
				SetDlgItemText(hWnd, IDC_LEVEL_FILE_T, T_File);
				SetDlgItemText(hWnd, IDC_LEVEL_NAME_T, T_Name);
				SetDlgItemText(hWnd, IDC_LEVEL_AUTHOR_T, T_Author);
				SetDlgItemText(hWnd, IDC_LEVEL_MUSIC_T, T_Music);
				SetDlgItemText(hWnd, IDC_LEVEL_WIDTH_T, T_Width);
				SetDlgItemText(hWnd, IDC_LEVEL_HEIGHT_T, T_Height);
				SetDlgItemText(hWnd, IDC_LEVEL_FIELD_WIDTH_T, T_Width);
				SetDlgItemText(hWnd, IDC_LEVEL_FIELD_HEIGHT_T, T_Height);
				SetDlgItemText(hWnd, IDC_LEVEL_FIELD_DEPTH_T, T_Depth);
				SetDlgItemText(hWnd, IDC_LEVEL_FOG_T, T_Fog);
				SetDlgItemText(hWnd, IDC_LEVEL_FOG_DENSITY_T, T_Density);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_T, T_Water);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_DENSITY_T, T_Density);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_HEIGHT_T, T_Height);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_TEXTURE, T_Texture);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_ACID, T_Acid);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_LAVA, T_Lava);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_ENVIRONMENT_DENSITY_T, T_Density);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_ENVIRONMENT_T, T_Environment);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_ENVIRONMENT, T_Environment);
				SetDlgItemText(hWnd, IDC_LEVEL_LIGHT_T, T_Light);
				SetDlgItemText(hWnd, IDC_LEVEL_FREE_CAMERA, T_FreeCamera);
				SetDlgItemText(hWnd, IDC_LEVEL_PLAYER_CAMERA, T_PlayerCamera);
				SetDlgItemText(hWnd, IDC_LEVEL_STANDART_CAMERA, T_StandartCamera);
				SetDlgItemText(hWnd, IDC_LEVEL_BOX_SURFACE_ALL, T_All);
				SetDlgItemText(hWnd, ID_LEVEL_CANCEL, T_Cancel);
				SetDlgItemText(hWnd, ID_LEVEL_OK, T_Ok);
				SetDlgItemText(hWnd, ID_LEVEL_START_TOOLS, T_StartTools);
				SetDlgItemText(hWnd, ID_LEVEL_MISSIONS, T_LevelMissions);
				SetDlgItemText(hWnd, IDD_LEVEL_INDESTRUCTIBLE_WALL, T_IndestructibleWall);
				SetDlgItemText(hWnd, IDC_LEVEL_MOVE_X_T, T_MoveX);
				SetDlgItemText(hWnd, IDC_LEVEL_MOVE_Y_T, T_MoveY);
				SetDlgItemText(hWnd, IDC_LEVEL_END_SCREEN, T_EndScreen);
				if(byLevelDialogMode == NEW_LEVEL_DIALOG)
				{
					ShowWindow(GetDlgItem(hWnd, IDC_LEVEL_MOVE_X), SW_HIDE);
					ShowWindow(GetDlgItem(hWnd, IDC_LEVEL_MOVE_X_T), SW_HIDE);
					ShowWindow(GetDlgItem(hWnd, IDC_LEVEL_MOVE_Y), SW_HIDE);
					ShowWindow(GetDlgItem(hWnd, IDC_LEVEL_MOVE_Y_T), SW_HIDE);
				}
				else
				{
					ShowWindow(GetDlgItem(hWnd, IDC_LEVEL_MOVE_X), SW_SHOW);
					ShowWindow(GetDlgItem(hWnd, IDC_LEVEL_MOVE_X_T), SW_SHOW);
					ShowWindow(GetDlgItem(hWnd, IDC_LEVEL_MOVE_Y), SW_SHOW);
					ShowWindow(GetDlgItem(hWnd, IDC_LEVEL_MOVE_Y_T), SW_SHOW);
				}
				//
				// Level:
				SetDlgItemText(hWnd, IDC_LEVEL_FILENAME, pLevelT->Header.byFilename);
				SetDlgItemText(hWnd, IDC_LEVEL_NAME, pLevelT->Header.byName);
				SetDlgItemText(hWnd, IDC_LEVEL_AUTHOR, pLevelT->Header.byAuthor);
				SetDlgItemText(hWnd, IDC_LEVEL_MUSIC_FILE, pLevelT->Header.byMusicFile);
				sprintf(byTemp, "%d", pLevelT->Header.iWidth-1);
				SetDlgItemText(hWnd, IDC_LEVEL_WIDTH, byTemp);
				sprintf(byTemp, "%d", pLevelT->Header.iHeight-1);
				SetDlgItemText(hWnd, IDC_LEVEL_HEIGHT, byTemp);
				sprintf(byTemp, "%s", pLevelT->Header.byKeyword);
				SetDlgItemText(hWnd, IDC_LEVEL_KEYWORD, byTemp);				
				SetDlgItemText(hWnd, IDC_LEVEL_MOVE_X, "0");
				SetDlgItemText(hWnd, IDC_LEVEL_MOVE_Y, "0");
				iMoveX = iMoveY = 0;
				// Fog:
				sprintf(byTemp, "%f", pLevelT->Environment.fFogDensity);
				SetDlgItemText(hWnd, IDC_LEVEL_FOG_DENSITY, byTemp);
				sprintf(byTemp, "%f", pLevelT->Environment.fFogColor[R]);
				SetDlgItemText(hWnd, IDC_LEVEL_FOG_COLOR_R, byTemp);
				sprintf(byTemp, "%f", pLevelT->Environment.fFogColor[G]);
				SetDlgItemText(hWnd, IDC_LEVEL_FOG_COLOR_G, byTemp);
				sprintf(byTemp, "%f", pLevelT->Environment.fFogColor[B]);
				SetDlgItemText(hWnd, IDC_LEVEL_FOG_COLOR_B, byTemp);
				// Water:
				sprintf(byTemp, "%f", pLevelT->Environment.fWaterDensity);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_DENSITY, byTemp);
				sprintf(byTemp, "%f", pLevelT->Environment.fWaterHeight);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_HEIGHT, byTemp);
				sprintf(byTemp, "%f", pLevelT->Environment.fWaterColor[R]);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_COLOR_R, byTemp);
				sprintf(byTemp, "%f", pLevelT->Environment.fWaterColor[G]);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_COLOR_G, byTemp);
				sprintf(byTemp, "%f", pLevelT->Environment.fWaterColor[B]);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_COLOR_B, byTemp);
				// Water texture:
				SendDlgItemMessage(hWnd, ID_LEVEL_WATER_SURFACE_LIST, CB_RESETCONTENT , 0, 0L);
				for(i = 0; i < pLevelT->Header.iSurfaces; i++)
				{
					sprintf(byTemp, "%s (Used:%d)", pLevelT->pSurface[i].Header.byName, pLevelT->pSurface[i].iUsed);
					SendDlgItemMessage(hWnd, ID_LEVEL_WATER_SURFACE_LIST, CB_ADDSTRING, 0, (LPARAM) byTemp);
				}
				if(pLevelT->Environment.bWaterSurface && pLevelT->Environment.iWaterSurface != -1)
					SendDlgItemMessage(hWnd, ID_LEVEL_WATER_SURFACE_LIST, CB_SETCURSEL, pLevelT->Environment.iWaterSurface, 0L);
				sprintf(byTemp, "%f", pLevelT->Environment.fWaterEnvironmentDensity);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_ENVIRONMENT_DENSITY, byTemp);
				// Water environment texture:
				SendDlgItemMessage(hWnd, ID_LEVEL_WATER_ENVIRONMENT_SURFACE_LIST, CB_RESETCONTENT , 0, 0L);
				for(i = 0; i < pLevelT->Header.iSurfaces; i++)
				{
					sprintf(byTemp, "%s (Used:%d)", pLevelT->pSurface[i].Header.byName, pLevelT->pSurface[i].iUsed);
					SendDlgItemMessage(hWnd, ID_LEVEL_WATER_ENVIRONMENT_SURFACE_LIST, CB_ADDSTRING, 0, (LPARAM) byTemp);
				}
				if(pLevelT->Environment.iWaterEnvironmentSurface != -1)
					SendDlgItemMessage(hWnd, ID_LEVEL_WATER_ENVIRONMENT_SURFACE_LIST, CB_SETCURSEL, pLevelT->Environment.iWaterEnvironmentSurface, 0L);
				sprintf(byTemp, "%f", pLevelT->Environment.fWaterEnvironmentColor[R]);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_ENVIRONMENT_COLOR_R, byTemp);
				sprintf(byTemp, "%f", pLevelT->Environment.fWaterEnvironmentColor[G]);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_ENVIRONMENT_COLOR_G, byTemp);
				sprintf(byTemp, "%f", pLevelT->Environment.fWaterEnvironmentColor[B]);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_ENVIRONMENT_COLOR_B, byTemp);
				// Level color:
				sprintf(byTemp, "%f", pLevelT->Environment.fColor[R]);
				SetDlgItemText(hWnd, IDC_LEVEL_COLOR_R, byTemp);
				sprintf(byTemp, "%f", pLevelT->Environment.fColor[G]);
				SetDlgItemText(hWnd, IDC_LEVEL_COLOR_G, byTemp);
				sprintf(byTemp, "%f", pLevelT->Environment.fColor[B]);
				SetDlgItemText(hWnd, IDC_LEVEL_COLOR_B, byTemp);
				// Field:
				sprintf(byTemp, "%f", pLevelT->Header.fFieldWidth);
				SetDlgItemText(hWnd, IDC_LEVEL_FIELD_WIDTH, byTemp);
				sprintf(byTemp, "%f", pLevelT->Header.fFieldHeight);
				SetDlgItemText(hWnd, IDC_LEVEL_FIELD_HEIGHT, byTemp);
				sprintf(byTemp, "%f", pLevelT->Header.fFieldDepth);
				SetDlgItemText(hWnd, IDC_LEVEL_FIELD_DEPTH_LENGTH, byTemp);
				// Camera:
				SetDlgItemText(hWnd, IDC_LEVEL_CAMERA, T_Camera);
				SetDlgItemText(hWnd, IDC_LEVEL_CAMERA_START, T_Start);
				SendDlgItemMessage(hWnd, ID_LEVEL_CAMERA_START_CAMERA, CB_RESETCONTENT , 0, 0L);
				for(i = 0; i < pLevelT->Header.iCameraScripts; i++)
				{
					sprintf(byTemp, "%s", pLevelT->pCameraScript[i].byName);
					SendDlgItemMessage(hWnd, ID_LEVEL_CAMERA_START_CAMERA, CB_ADDSTRING, 0, (LPARAM) byTemp);
				}
				SendDlgItemMessage(hWnd, ID_LEVEL_CAMERA_START_CAMERA, CB_SETCURSEL, pLevelT->Camera.iStartCamera, 0L);
				SetDlgItemText(hWnd, IDC_LEVEL_CAMERA_END, T_End);
				SetDlgItemText(hWnd, IDC_LEVEL_CAMERA_END_LOOP, T_Loop);
				SendDlgItemMessage(hWnd, ID_LEVEL_CAMERA_END_CAMERA, CB_RESETCONTENT, 0, 0L);
				for(i = 0; i < pLevelT->Header.iCameraScripts; i++)
				{
					sprintf(byTemp, "%s", pLevelT->pCameraScript[i].byName);
					SendDlgItemMessage(hWnd, ID_LEVEL_CAMERA_END_CAMERA, CB_ADDSTRING, 0, (LPARAM) byTemp);
				}
				SendDlgItemMessage(hWnd, ID_LEVEL_CAMERA_END_CAMERA, CB_SETCURSEL, pLevelT->Camera.iEndCamera, 0L);
				// Box:
				SetDlgItemText(hWnd, IDC_LEVEL_BOX_T, T_Box);
				SetDlgItemText(hWnd, IDC_LEVEL_BOX_ROTATION_T, T_Rotation);
				sprintf(byTemp, "%d", byLevelRotation*90);
				SetDlgItemText(hWnd, IDC_LEVEL_BOX_ROTATION, byTemp);
				pLevelT->Header.byBoxSurfaceRot[byLevelSelecedSide][byLevelSelecedType] = byLevelRotation;
			Init:
				// Box type:
				SendDlgItemMessage(hWnd, ID_LEVEL_BOX_TYPE, CB_RESETCONTENT, 0, 0L);
				SendDlgItemMessage(hWnd, ID_LEVEL_BOX_TYPE, CB_ADDSTRING, 0, (LPARAM) T_Normal);
				SendDlgItemMessage(hWnd, ID_LEVEL_BOX_TYPE, CB_ADDSTRING, 0, (LPARAM) T_Heavy);
				SendDlgItemMessage(hWnd, ID_LEVEL_BOX_TYPE, CB_SETCURSEL, byLevelSelecedType, 0L);
				// Box side:
				SendDlgItemMessage(hWnd, ID_LEVEL_BOX_SIDE, CB_RESETCONTENT, 0, 0L);
				SendDlgItemMessage(hWnd, ID_LEVEL_BOX_SIDE, CB_ADDSTRING, 0, (LPARAM) T_Floor);
				SendDlgItemMessage(hWnd, ID_LEVEL_BOX_SIDE, CB_ADDSTRING, 0, (LPARAM) T_Sky);
				SendDlgItemMessage(hWnd, ID_LEVEL_BOX_SIDE, CB_ADDSTRING, 0, (LPARAM) T_Back);
				SendDlgItemMessage(hWnd, ID_LEVEL_BOX_SIDE, CB_ADDSTRING, 0, (LPARAM) T_Front);
				SendDlgItemMessage(hWnd, ID_LEVEL_BOX_SIDE, CB_ADDSTRING, 0, (LPARAM) T_Right);
				SendDlgItemMessage(hWnd, ID_LEVEL_BOX_SIDE, CB_ADDSTRING, 0, (LPARAM) T_Left);
				SendDlgItemMessage(hWnd, ID_LEVEL_BOX_SIDE, CB_SETCURSEL, byLevelSelecedSide, 0L);
				// Box surface:
				SendDlgItemMessage(hWnd, ID_LEVEL_BOX_SURFACE, CB_RESETCONTENT, 0, 0L);
				for(i = 0; i < pLevelT->Header.iSurfaces; i++)
				{
					sprintf(byTemp, "%s", pLevelT->pSurface[i].Header.byName, pLevelT->pSurface[i].iUsed);
					SendDlgItemMessage(hWnd, ID_LEVEL_BOX_SURFACE, CB_ADDSTRING, 0, (LPARAM) byTemp);
				}
				SendDlgItemMessage(hWnd, ID_LEVEL_BOX_SURFACE, CB_SETCURSEL, pLevelT->Header.iBoxSurface[byLevelSelecedSide][byLevelSelecedType], 0L);

				UpdateLevelMenuButtons();
				
				ShowWindow(hWnd, _AS->GetCmdShow());
				UpdateWindow(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_LEVEL_OK:
					if(byLevelDialogMode == LEVEL_DIALOG && 
					   (pLevelT->Header.iWidth != pLevel->Header.iWidth || pLevelT->Header.iHeight != pLevel->Header.iHeight))
					{ // Yes the level must be resize inform the user:
						sprintf(byTemp, "%s %dx%d)", M_ChangeLevelSize, pLevel->Header.iWidth, pLevel->Header.iHeight);
						if(MessageBox(hWnd, byTemp, T_Question, MB_YESNO | MB_ICONINFORMATION) == IDNO)
							break;
					}
					EndDialog(hWnd, TRUE);
					_AS->WriteLogMessage("Close level dialog(OK)");
                return TRUE;

                case ID_LEVEL_CANCEL:
					EndDialog(hWnd, FALSE);
					_AS->WriteLogMessage("Close level dialog(Cancel)");
                return TRUE;

			// Level:
				case IDC_LEVEL_FILENAME:
					GetDlgItemText(hWnd, IDC_LEVEL_FILENAME, pLevelT->Header.byFilename, 256);
				break;

				case IDC_LEVEL_SINGLE:
				    pLevelT->Header.bSingle = SendDlgItemMessage(hWnd, IDC_LEVEL_SINGLE, BM_GETCHECK, 0, 0L);
					UpdateLevelMenuButtons();
				break;

				case IDC_LEVEL_END_SCREEN:
				    pLevelT->Header.bEndScreen = SendDlgItemMessage(hWnd, IDC_LEVEL_END_SCREEN, BM_GETCHECK, 0, 0L);
				break;

				case IDC_LEVEL_FIND_FILENAME:
					sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbySingleLevelsFile);
					pbyTemp = ASGetFileName(hWnd, "Get level file name", LEV_FILE, 0, TRUE, byTemp);
					if(!pbyTemp)
						break;
					if(strlen(pbyTemp) > strlen(_AS->pbyProgramPath))
						strcpy(pLevelT->Header.byFilename, &pbyTemp[strlen(_AS->pbyProgramPath)]);
					SetDlgItemText(hWnd, IDC_LEVEL_FILENAME, pLevelT->Header.byFilename);
				break;

				case IDC_LEVEL_NAME:
					GetDlgItemText(hWnd, IDC_LEVEL_NAME, pLevelT->Header.byName, 256);
				break;

				case IDC_LEVEL_AUTHOR:
					GetDlgItemText(hWnd, IDC_LEVEL_AUTHOR, pLevelT->Header.byAuthor, 256);
				break;

				case IDC_LEVEL_MUSIC:
				    pLevelT->Header.bMusic = SendDlgItemMessage(hWnd, IDC_LEVEL_MUSIC, BM_GETCHECK, 0, 0L);
					UpdateLevelMenuButtons();
				break;

				case IDC_LEVEL_MUSIC_FILE:
					GetDlgItemText(hWnd, IDC_LEVEL_MUSIC_FILE, pLevelT->Header.byMusicFile, 256);
					UpdateLevelMenuButtons();
				break;

				case IDC_LEVEL_FIND_MUSIC_FILE:
					sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyMusicFile);
					pbyTemp = ASGetFileName(hWnd, "Load music", MUSIC_FILES, 0, TRUE, byTemp);
					if(!pbyTemp)
						break;
					if(strlen(pbyTemp) > strlen(_AS->pbyProgramPath))
						strcpy(pLevelT->Header.byMusicFile, &pbyTemp[strlen(_AS->pbyProgramPath)]);
					SetDlgItemText(hWnd, IDC_LEVEL_MUSIC_FILE, pLevelT->Header.byMusicFile);
				break;
				
				case IDC_LEVEL_KEYWORD_CHECKED:
				    pLevelT->Header.bKeyword = SendDlgItemMessage(hWnd, IDC_LEVEL_KEYWORD_CHECKED, BM_GETCHECK, 0, 0L);
					UpdateLevelMenuButtons();
				break;

				case IDC_LEVEL_KEYWORD:
					GetDlgItemText(hWnd, IDC_LEVEL_KEYWORD, pLevelT->Header.byKeyword, 256);
				break;
				
				case IDC_LEVEL_WIDTH:
					GetDlgItemText(hWnd, IDC_LEVEL_WIDTH, byTemp, 256);
					pLevelT->Header.iWidth = atoi(byTemp)+1;
				break;

				case IDC_LEVEL_HEIGHT:
					GetDlgItemText(hWnd, IDC_LEVEL_HEIGHT, byTemp, 256);
					pLevelT->Header.iHeight = atoi(byTemp)+1;
				break;

				case IDC_LEVEL_MOVE_X:
					GetDlgItemText(hWnd, IDC_LEVEL_MOVE_X, byTemp, 256);
					iMoveX = atoi(byTemp);
				break;

				case IDC_LEVEL_MOVE_Y:
					GetDlgItemText(hWnd, IDC_LEVEL_MOVE_Y, byTemp, 256);
					iMoveY = atoi(byTemp);
				break;
		
			// Fog:
				case IDC_LEVEL_FOG:
				    pLevelT->Environment.bFog = SendDlgItemMessage(hWnd, IDC_LEVEL_FOG, BM_GETCHECK, 0, 0L);
					UpdateLevelMenuButtons();
				break;

				case IDC_LEVEL_FOG_DENSITY:
					GetDlgItemText(hWnd, IDC_LEVEL_FOG_DENSITY, byTemp, 256);
					pLevelT->Environment.fFogDensity = (float) atof(byTemp);
				break;

				case IDC_LEVEL_FOG_COLOR_R:
					GetDlgItemText(hWnd, IDC_LEVEL_FOG_COLOR_R, byTemp, 256);
					pLevelT->Environment.fFogColor[R] = (float) atof(byTemp);
				break;

				case IDC_LEVEL_FOG_COLOR_G:
					GetDlgItemText(hWnd, IDC_LEVEL_FOG_COLOR_G, byTemp, 256);
					pLevelT->Environment.fFogColor[G] = (float) atof(byTemp);
				break;

				case IDC_LEVEL_FOG_COLOR_B:
					GetDlgItemText(hWnd, IDC_LEVEL_FOG_COLOR_B, byTemp, 256);
					pLevelT->Environment.fFogColor[B] = (float) atof(byTemp);
				break;

			// Water:
				case IDC_LEVEL_WATER:
				    pLevelT->Environment.bWater = SendDlgItemMessage(hWnd, IDC_LEVEL_WATER, BM_GETCHECK, 0, 0L);
					UpdateLevelMenuButtons();
				break;
				
				case IDC_LEVEL_WATER_DENSITY:
					GetDlgItemText(hWnd, IDC_LEVEL_WATER_DENSITY, byTemp, 256);
					pLevelT->Environment.fWaterDensity = (float) atof(byTemp);
				break;

				case IDC_LEVEL_WATER_HEIGHT:
					GetDlgItemText(hWnd, IDC_LEVEL_WATER_HEIGHT, byTemp, 256);
					pLevelT->Environment.fWaterHeight = (float) atof(byTemp);
				break;

				case IDC_LEVEL_WATER_COLOR_R:
					GetDlgItemText(hWnd, IDC_LEVEL_WATER_COLOR_R, byTemp, 256);
					pLevelT->Environment.fWaterColor[R] = (float) atof(byTemp);
				break;

				case IDC_LEVEL_WATER_COLOR_G:
					GetDlgItemText(hWnd, IDC_LEVEL_WATER_COLOR_G, byTemp, 256);
					pLevelT->Environment.fWaterColor[G] = (float) atof(byTemp);
				break;

				case IDC_LEVEL_WATER_COLOR_B:
					GetDlgItemText(hWnd, IDC_LEVEL_WATER_COLOR_B, byTemp, 256);
					pLevelT->Environment.fWaterColor[B] = (float) atof(byTemp);
				break;
				
				case IDC_LEVEL_WATER_TEXTURE:
				    pLevelT->Environment.bWaterSurface = SendDlgItemMessage(hWnd, IDC_LEVEL_WATER_TEXTURE, BM_GETCHECK, 0, 0L);
					UpdateLevelMenuButtons();
				break;

				case IDC_LEVEL_WATER_ACID:
				    pLevelT->Environment.bWaterAcid = SendDlgItemMessage(hWnd, IDC_LEVEL_WATER_ACID, BM_GETCHECK, 0, 0L);
					if(pLevelT->Environment.bWaterAcid && pLevelT->Environment.bWaterLava)
						pLevelT->Environment.bWaterLava = FALSE;
					UpdateLevelMenuButtons();
				break;

				case IDC_LEVEL_WATER_LAVA:
				    pLevelT->Environment.bWaterLava = SendDlgItemMessage(hWnd, IDC_LEVEL_WATER_LAVA, BM_GETCHECK, 0, 0L);
					if(pLevelT->Environment.bWaterAcid && pLevelT->Environment.bWaterLava)
						pLevelT->Environment.bWaterAcid = FALSE;
					UpdateLevelMenuButtons();
				break;

			// Water texture:
				case ID_LEVEL_WATER_SURFACE_LIST:
					i = (short) SendDlgItemMessage(hWnd, ID_LEVEL_WATER_SURFACE_LIST, CB_GETCURSEL, 0, 0L);
					if(i == -1 || i >= pLevelT->Header.iSurfaces)
						break;
					pLevelT->Environment.iWaterSurface = i;
				break;

				case IDC_LEVEL_WATER_ENVIRONMENT:
				    pLevelT->Environment.bWaterEnvironment = SendDlgItemMessage(hWnd, IDC_LEVEL_WATER_ENVIRONMENT, BM_GETCHECK, 0, 0L);
					UpdateLevelMenuButtons();
				break;
				
				case ID_LEVEL_WATER_ENVIRONMENT_SURFACE_LIST:
					i = (short) SendDlgItemMessage(hWnd, ID_LEVEL_WATER_ENVIRONMENT_SURFACE_LIST, CB_GETCURSEL, 0, 0L);
					if(i == -1 || i >= pLevelT->Header.iSurfaces)
						break;
					pLevelT->Environment.iWaterEnvironmentSurface = i;
				break;

				case IDC_LEVEL_WATER_ENVIRONMENT_DENSITY:
					GetDlgItemText(hWnd, IDC_LEVEL_WATER_ENVIRONMENT_DENSITY, byTemp, 256);
					pLevelT->Environment.fWaterEnvironmentDensity = (float) atof(byTemp);
				break;

				case IDC_LEVEL_WATER_ENVIRONMENT_COLOR_R:
					GetDlgItemText(hWnd, IDC_LEVEL_WATER_ENVIRONMENT_COLOR_R, byTemp, 256);
					pLevelT->Environment.fWaterEnvironmentColor[R] = (float) atof(byTemp);
				break;

				case IDC_LEVEL_WATER_ENVIRONMENT_COLOR_G:
					GetDlgItemText(hWnd, IDC_LEVEL_WATER_ENVIRONMENT_COLOR_G, byTemp, 256);
					pLevelT->Environment.fWaterEnvironmentColor[G] = (float) atof(byTemp);
				break;

				case IDC_LEVEL_WATER_ENVIRONMENT_COLOR_B:
					GetDlgItemText(hWnd, IDC_LEVEL_WATER_ENVIRONMENT_COLOR_B, byTemp, 256);
					pLevelT->Environment.fWaterEnvironmentColor[B] = (float) atof(byTemp);
				break;

			// Level color
				case IDC_LEVEL_COLOR_R:
					GetDlgItemText(hWnd, IDC_LEVEL_COLOR_R, byTemp, 256);
					pLevelT->Environment.fColor[R] = (float) atof(byTemp);
				break;

				case IDC_LEVEL_COLOR_G:
					GetDlgItemText(hWnd, IDC_LEVEL_COLOR_G, byTemp, 256);
					pLevelT->Environment.fColor[G] = (float) atof(byTemp);
				break;

				case IDC_LEVEL_COLOR_B:
					GetDlgItemText(hWnd, IDC_LEVEL_COLOR_B, byTemp, 256);
					pLevelT->Environment.fColor[B] = (float) atof(byTemp);
				break;

			// Field:
				case IDC_LEVEL_FIELD_WIDTH:
					GetDlgItemText(hWnd, IDC_LEVEL_FIELD_WIDTH, byTemp, 256);
					pLevelT->Header.fFieldWidth = (float) atof(byTemp);
					if(pLevelT->Header.fFieldWidth < 0.0f)
					{
						pLevelT->Header.fFieldWidth = 0.0f;
						sprintf(byTemp, "%f", pLevelT->Header.fFieldWidth);
						SetDlgItemText(hWnd, IDC_LEVEL_FIELD_WIDTH, byTemp);
					}
				break;

				case IDC_LEVEL_FIELD_HEIGHT:
					GetDlgItemText(hWnd, IDC_LEVEL_FIELD_HEIGHT, byTemp, 256);
					pLevelT->Header.fFieldHeight = (float) atof(byTemp);
					if(pLevelT->Header.fFieldHeight < 0.0f)
					{
						pLevelT->Header.fFieldHeight = 0.0f;
						sprintf(byTemp, "%f", pLevelT->Header.fFieldHeight);
						SetDlgItemText(hWnd, IDC_LEVEL_FIELD_HEIGHT, byTemp);
					}
				break;
				
				case IDC_LEVEL_FIELD_DEPTH_LENGTH:
					GetDlgItemText(hWnd, IDC_LEVEL_FIELD_DEPTH_LENGTH, byTemp, 256);
					pLevelT->Header.fFieldDepth = (float) atof(byTemp);
				break;

				// Camera:
				case IDC_LEVEL_FREE_CAMERA:
				    pLevelT->Camera.bFreeCamera = SendDlgItemMessage(hWnd, IDC_LEVEL_FREE_CAMERA, BM_GETCHECK, 0, 0L);
					if(!pLevelT->Camera.bFreeCamera && !pLevelT->Camera.bPlayerCamera)
					{
						pLevelT->Camera.bFreeCamera = TRUE;
						SendDlgItemMessage(hWnd, IDC_LEVEL_FREE_CAMERA, BM_SETCHECK, TRUE, 0L);
					}
					UpdateLevelMenuButtons();
				break;

				case IDC_LEVEL_PLAYER_CAMERA:
				    pLevelT->Camera.bPlayerCamera = SendDlgItemMessage(hWnd, IDC_LEVEL_PLAYER_CAMERA, BM_GETCHECK, 0, 0L);
					if(!pLevelT->Camera.bFreeCamera && !pLevelT->Camera.bPlayerCamera)
					{
						pLevelT->Camera.bPlayerCamera = TRUE;
						SendDlgItemMessage(hWnd, IDC_LEVEL_PLAYER_CAMERA, BM_SETCHECK, TRUE, 0L);
					}
				break;

				case IDC_LEVEL_STANDART_CAMERA:
				    pLevelT->Camera.bStandartCamera = SendDlgItemMessage(hWnd, IDC_LEVEL_STANDART_CAMERA, BM_GETCHECK, 0, 0L);
				break;

				case IDC_LEVEL_CAMERA_START:
				    pLevelT->Camera.bStartCamera = SendDlgItemMessage(hWnd, IDC_LEVEL_CAMERA_START, BM_GETCHECK, 0, 0L);
					UpdateLevelMenuButtons();
				break;

				case ID_LEVEL_CAMERA_START_CAMERA:
					i = (short) SendDlgItemMessage(hWnd, ID_LEVEL_CAMERA_START_CAMERA, CB_GETCURSEL, 0, 0L);
					if(i == -1 || i >= pLevelT->Header.iCameraScripts)
						break;
					pLevelT->Camera.iStartCamera = i;
				break;

				case IDC_LEVEL_CAMERA_END:
				    pLevelT->Camera.bEndCamera = SendDlgItemMessage(hWnd, IDC_LEVEL_CAMERA_END, BM_GETCHECK, 0, 0L);
					UpdateLevelMenuButtons();
				break;

				case IDC_LEVEL_CAMERA_END_LOOP:
				    pLevelT->Camera.bEndCameraLoop = SendDlgItemMessage(hWnd, IDC_LEVEL_CAMERA_END_LOOP, BM_GETCHECK, 0, 0L);
				break;

				case ID_LEVEL_CAMERA_END_CAMERA:
					i = (short) SendDlgItemMessage(hWnd, ID_LEVEL_CAMERA_END_CAMERA, CB_GETCURSEL, 0, 0L);
					if(i == -1 || i >= pLevelT->Header.iCameraScripts)
						break;
					pLevelT->Camera.iEndCamera = i;
				break;
			
				// Box:
				case ID_LEVEL_BOX_TYPE:
					i = (short) SendDlgItemMessage(hWnd, ID_LEVEL_BOX_TYPE, CB_GETCURSEL, 0, 0L);
					if(i == -1 || i >= 2)
						break;
					byLevelSelecedType = (char) i;
					goto Init;
				
				case ID_LEVEL_BOX_SIDE:
					i = (short) SendDlgItemMessage(hWnd, ID_LEVEL_BOX_SIDE, CB_GETCURSEL, 0, 0L);
					if(i == -1 || i >= 6)
						break;
					byLevelSelecedSide = (char) i;
					goto Init;

				case ID_LEVEL_BOX_SURFACE:
					i = (short) SendDlgItemMessage(hWnd, ID_LEVEL_BOX_SURFACE, CB_GETCURSEL, 0, 0L);
					if(i == -1 || i >= pLevelT->Header.iSurfaces)
						break;
					pLevelT->Header.iBoxSurface[byLevelSelecedSide][byLevelSelecedType] = i;
				break;

				case IDC_LEVEL_BOX_SURFACE_ALL:
					i = (short) SendDlgItemMessage(hWnd, ID_LEVEL_BOX_SURFACE, CB_GETCURSEL, 0, 0L);
					if(i == -1 || i >= pLevelT->Header.iSurfaces)
						break;
					for(i2 = 0; i2 < 6; i2++)
						pLevelT->Header.iBoxSurface[i2][byLevelSelecedType] = i;
				break;

				case IDC_LEVEL_BOX_ROTATION_PLUS:
					byLevelRotation--;
					if(byLevelRotation < 0)
						byLevelRotation = 3;
					pLevelT->Header.byBoxSurfaceRot[byLevelSelecedSide][byLevelSelecedType] = byLevelRotation;
					sprintf(byTemp, "%d", byLevelRotation*90);
					SetDlgItemText(hWnd, IDC_LEVEL_BOX_ROTATION, byTemp);
				break;

				case IDC_LEVEL_BOX_ROTATION_MINUS:
					byLevelRotation++;
					if(byLevelRotation > 3)
						byLevelRotation = 0;
					pLevelT->Header.byBoxSurfaceRot[byLevelSelecedSide][byLevelSelecedType] = byLevelRotation;
					sprintf(byTemp, "%d", byLevelRotation*90);
					SetDlgItemText(hWnd, IDC_LEVEL_BOX_ROTATION, byTemp);
				break;

				case ID_LEVEL_MISSIONS:
					DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_LEVEL_MISSIONS), hWnd, (DLGPROC) LevelMissionsProc);
				break;

				case ID_LEVEL_START_TOOLS:
					DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_LEVEL_TOOLS), hWnd, (DLGPROC) LevelToolsProc);
				break;

				case IDD_LEVEL_INDESTRUCTIBLE_WALL:
				    bIndestructibleWallStandart = SendDlgItemMessage(hWnd, IDD_LEVEL_INDESTRUCTIBLE_WALL, BM_GETCHECK, 0, 0L);
				break;
            }
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_LEVEL_CANCEL, 0);
		break;
    }
    return FALSE;
} // end LevelProc()

void NewLevelDialog(void)
{ // begin NewLevelDialog()
	BOOL bIndestructibleWallStandartT;
	short i;
	
	bIndestructibleWallStandartT = bIndestructibleWallStandart;
	bIndestructibleWallStandart = FALSE;
	_AS->WriteLogMessage("Create a new level");
	pLevelT = new LEVEL;
	strcpy(pLevelT->Header.byName, "Noname");
	byLevelDialogMode = NEW_LEVEL_DIALOG;
	if(!DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_LEVEL), hWndEditor, (DLGPROC) LevelProc))
	{ // The user canceled the creation of a new level:
		_AS->WriteLogMessage("Create a new level is canceled");
		DestroyLevel(&pLevelT);
		bIndestructibleWallStandart = bIndestructibleWallStandartT;
		return;
	}
	pPlayer->bActive = FALSE;
	for(i = 0; i < MAX_ACTORS; i++)
		memset(&Actor[i], 0, sizeof(ACTOR));
	// OK, now destroy the old level and make the new to the current:
	memset(pPlayer, 0, sizeof(ACTOR));
	memset(&Actor, 0, sizeof(ACTOR)*MAX_ACTORS);
	DestroyLevel(&pLevel);
	pLevel = pLevelT;
	// Now setup the level:
	pLevel->Create(pLevel->Header.iWidth, pLevel->Header.iHeight, pLevel->Header.fFieldDepth, pLevel->Header.fFieldWidth, pLevel->Header.fFieldHeight);
	if(!wglMakeCurrent(hDCEditorShow, hRCEditorShow))
		return;
	pLevel->DestroyTexturesOpenGL(hDCEditorShow, hRCEditorShow);
	pLevel->GenTexturesOpenGL(hDCEditorShow, hRCEditorShow);
	pLevel->Environment.lWaterAniTime = g_lNow;
	memset(&LevelTempCamera, 0, sizeof(AS_CAMERA));
} // end NewLevelDialog()

void AdjustLevelDialog(void)
{ // begin AdjustLevelDialog()
	BOOL bIndestructibleWallStandartT;
	
	bIndestructibleWallStandartT = bIndestructibleWallStandart;
	byLevelDialogMode = LEVEL_DIALOG;
	pLevelT = new LEVEL;
	pOldLevelTemp = new LEVEL;
	memcpy(pOldLevelTemp, pLevel, sizeof(LEVEL)); // Save the old level
	memcpy(pLevelT, pLevel, sizeof(LEVEL)); // Save the old level
	if(!DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_LEVEL), hWndEditor, (DLGPROC) LevelProc))
	{ // The user canceled the changes of the level:
		_AS->WriteLogMessage("Change level attributes is canceled");
		delete pLevelT;
		delete pOldLevelTemp;
		return;
	}
	// Update the level data:
	memcpy(pLevel, pLevelT, sizeof(LEVEL));
	pLevel->Environment.iWaterAniStep = 0;
	// Now check if the level points must be updated:
	short i, i2 = pLevelT->Header.iPoints/2, i3, x, y, iX, iY;
	FIELD *pNewFieldT, *pOldFieldT, *pCurrentField, *pLastField;

	if(pLevel->Header.fFieldWidth != pOldLevelTemp->Header.fFieldWidth ||
	   pLevel->Header.fFieldHeight != pOldLevelTemp->Header.fFieldHeight)
	{
		for(i = 0, y = 0; y < pLevel->Header.iHeight+1; y++)
			for(x = 0; x < pLevel->Header.iWidth+1; x++, i++)
			{
				if(i >= i2)
				{
					x = pLevel->Header.iWidth+1;
					y = pLevel->Header.iHeight+1;
					continue;
				}
				// Front point:
				pLevel->fPoint[i][X] = (float) x*pLevel->Header.fFieldWidth;
				pLevel->fPoint[i][Y] = (float) y*pLevel->Header.fFieldHeight;
				pLevel->fPoint[i][Z] = (float) pLevel->Header.fFieldDepth/2;
				// Back point:
				pLevel->fPoint[i2+i][X] = (float) x*pLevel->Header.fFieldWidth;
				pLevel->fPoint[i2+i][Y] = (float) y*pLevel->Header.fFieldHeight;
				pLevel->fPoint[i2+i][Z] = (float) -pLevel->Header.fFieldDepth/2;
			}
	}
	// Check indestructibl wall:
	if(bIndestructibleWallStandart != bIndestructibleWallStandartT)
	{ // Switch indestructibl walls:
		for(i = 0; i < pLevel->Header.iFields; i++)
		{
			if(!pLevel->pField[i].bIndestructibleWall)
				pLevel->pField[i].bIndestructibleWall = TRUE;
			else
				pLevel->pField[i].bIndestructibleWall = FALSE;
		}
	}

	// Check field depth:
	if(pLevel->Header.fFieldDepth != pOldLevelTemp->Header.fFieldDepth)
	{
		i2 = pLevel->Header.iPoints/2;
		for(i = 0; i < i2; i++)
		{
			pLevel->fPoint[i+i2][Z] = 0.0f;
			pLevel->fPoint[i][Z] = pLevel->Header.fFieldDepth;
		}
		pLevel->CalculateFieldNormals();
		pLevel->CalculateFieldBoundingBoxes();
	}

	if(pLevel->Header.iWidth != pOldLevelTemp->Header.iWidth || pLevel->Header.iHeight != pOldLevelTemp->Header.iHeight)
	{ // Yes, the level must be resized:
		if(pPlayer->iFieldPos[X] >= pLevel->Header.iWidth-1 ||
		   pPlayer->iFieldPos[Y] >= pLevel->Header.iHeight-1)
			pPlayer->bActive = FALSE;
		for(i = 0; i < MAX_ACTORS; i++)
		{
			if(Actor[i].iFieldPos[X] >= pLevel->Header.iWidth-1 ||
			   Actor[i].iFieldPos[Y] >= pLevel->Header.iHeight-1)
				Actor[i].bActive = FALSE;
		}
		// Create now a new level with the old information:
		pLevelT->pField = NULL; pLevelT->fPoint = NULL; pLevelT->fColor = NULL;
		 // Create the new level:
		pLevelT->Create(pLevel->Header.iWidth, pLevel->Header.iHeight, pLevel->Header.fFieldDepth, 
						pLevel->Header.fFieldWidth, pLevel->Header.fFieldHeight);
		memcpy(&pLevelT->Header, &pLevel->Header, sizeof(LEVEL_HEADER));
		pLevelT->Header.iFields = pLevelT->Header.iWidth*pLevelT->Header.iHeight;
		pLevelT->Header.iPoints = (pLevelT->Header.iFields+pLevelT->Header.iWidth+pLevelT->Header.iHeight+1)*2;
		pLevelT->Header.fWholeWidth = (float) pLevelT->Header.iWidth*pLevelT->Header.fFieldWidth;
		pLevelT->Header.fWholeHeight = (float) pLevelT->Header.iHeight*pLevelT->Header.fFieldHeight;

		memcpy(&pLevelT->Environment, &pLevel->Environment, sizeof(LEVEL_ENVIRONMENT));
		memcpy(&pLevelT->Tools, &pLevel->Tools, sizeof(LEVEL_TOOLS));
		memcpy(&pLevelT->Missions, &pLevel->Missions, sizeof(LEVEL_MISSIONS));
		memcpy(&pLevelT->Camera, &pLevel->Camera, sizeof(LEVEL_CAMERA));
		memcpy(&pLevelT->State, &pLevel->State, sizeof(LEVEL_STATE));
		memcpy(&pLevelT->TextScriptsManager, &pLevel->TextScriptsManager, sizeof(TEXT_SCRIPTS_MANAGER));

		DestroyGameParticleSystems();
		// Copy the old fields info into the new level:
		for(y = 0; y < pOldLevelTemp->Header.iHeight-1; y++)
		{
			if(y > pLevelT->Header.iHeight-1)
				break;
			for(x = 0; x < pOldLevelTemp->Header.iWidth-1; x++)
			{
				if(x > pLevelT->Header.iWidth-1)
					break;
				pNewFieldT = &pLevelT->pField[y*pLevelT->Header.iWidth+x];
				pOldFieldT = &pOldLevelTemp->pField[y*pOldLevelTemp->Header.iWidth+x];
				pNewFieldT->bWall = pOldFieldT->bWall;
				pNewFieldT->bAlwaysWall = pOldFieldT->bAlwaysWall;
				pNewFieldT->bWallHole = pOldFieldT->bWallHole;
				pNewFieldT->bIndestructibleWall = pOldFieldT->bIndestructibleWall;
				pNewFieldT->fBeamerPower = pOldFieldT->fBeamerPower;
				pNewFieldT->iBeamerRegenerationSpeed = pOldFieldT->iBeamerRegenerationSpeed;
				
				if(!pOldFieldT->pSurface[FACE_FLOOR][0]->Header.bBeamer &&
					pOldFieldT->iBeamerTarget != -1)
					pOldFieldT->iBeamerTarget = -1;
				
				if(pOldFieldT->iBeamerTarget != -1)
					GET_FIELD_ID(pOldLevelTemp->pField[pOldFieldT->iBeamerTarget].iXField,
								 pOldLevelTemp->pField[pOldFieldT->iBeamerTarget].iYField, pNewFieldT->iBeamerTarget);
				pNewFieldT->bActive = pOldFieldT->bActive;
				pNewFieldT->bNoBackfaceCulling = pOldFieldT->bNoBackfaceCulling;
				pNewFieldT->iCamera = pOldFieldT->iCamera;
				pNewFieldT->bCameraAlways = pOldFieldT->bCameraAlways;
				pNewFieldT->iTextScript = pOldFieldT->iTextScript;
				pNewFieldT->bTextScriptAlways = pOldFieldT->bTextScriptAlways;
				pNewFieldT->pActor = pOldFieldT->pActor;
				pNewFieldT->pBridgeActor = pOldFieldT->pBridgeActor;
				pNewFieldT->pEnemy = pOldFieldT->pEnemy;
				pNewFieldT->pObject = pOldFieldT->pObject;
				for(i2 = 0; i2 < 6; i2++)
					for(i = 0; i < 6; i++)
					{
						pNewFieldT->iSurface[i][i2] = pOldFieldT->iSurface[i][i2];
						pNewFieldT->pSurface[i][i2] = pOldFieldT->pSurface[i][i2];
					}
				// Copy the points: (some point's are copied more than 1 time... I think that's no problem...)
				for(i = 0; i < 6; i++)
					for(i2 = 0; i2 < 4; i2++)
					{
						memcpy(&pLevelT->fPoint[pNewFieldT->iFace[i][i2]], &pOldLevelTemp->fPoint[pOldFieldT->iFace[i][i2]], sizeof(FLOAT3));
						memcpy(&pLevelT->fColor[pNewFieldT->iFace[i][i2]], &pOldLevelTemp->fColor[pOldFieldT->iFace[i][i2]], sizeof(FLOAT4));
					}
				// Decoration:
				if(!pOldFieldT->pDecoration)
					continue;
				pNewFieldT->pDecoration = (FIELD_DECORATION *) malloc(sizeof(FIELD_DECORATION));
				memcpy(&pNewFieldT->pDecoration, &pOldFieldT->pDecoration, sizeof(FIELD_DECORATION));
			}
		}	
		for(x = 0; x < pLevelT->Header.iWidth; x++)
			pLevelT->pField[(pLevelT->Header.iHeight-1)*pLevelT->Header.iWidth+x].bActive = FALSE;
		for(y = 0; y < pLevelT->Header.iHeight; y++)
			pLevelT->pField[y*pLevelT->Header.iWidth+pLevelT->Header.iWidth-1].bActive = FALSE;
		//
		// Destroy the old stuff:
		if(pLevel->pField)
		{
			for(i = 0; i < pLevel->Header.iFields; i++)
			{
				if(!pLevel->pField[i].pDecoration)
					continue;
				free(pLevel->pField[i].pDecoration);
			}
			free(pLevel->pField);
		}
		if(pLevel->fPoint)
			free(pLevel->fPoint);
		delete pLevel;
		pLevel = pLevelT;
		delete pOldLevelTemp;
		pOldLevelTemp = NULL;

		// Update the actors:
		for(i = 0; i < MAX_ACTORS; i++)
		{
			if(!Actor[i].bActive)
				continue;
			GET_FIELD_ID(Actor[i].iFieldPos[X], Actor[i].iFieldPos[Y], Actor[i].iFieldID);
			if(Actor[i].iFieldID >= pLevel->Header.iFields)
			{
				Actor[i].bActive = FALSE;
				continue;
			}
			if(Actor[i].bBridge)
			{
				pLevel->pField[Actor[i].iFieldID].pBridgeActor = &Actor[i];
				pLevel->pField[Actor[i].iFieldID].bActive = FALSE;
			}
			else
			{
				if(Actor[i].byType == ACTOR_BOX_NORMAL ||
				   Actor[i].byType == ACTOR_BOX_RED ||
				   Actor[i].byType == ACTOR_BOX_GREEN ||
				   Actor[i].byType == ACTOR_BOX_BLUE)
					pLevel->pField[Actor[i].iFieldID].pActor = &Actor[i];
				else
					pLevel->pField[Actor[i].iFieldID].pObject = &Actor[i];
			}
		}
		GET_FIELD_ID(pPlayer->iFieldPos[X], pPlayer->iFieldPos[Y], pPlayer->iFieldID);
		if(pPlayer->iFieldID >= pLevel->Header.iFields)
			pPlayer->bActive = FALSE;
		else
			pLevel->pField[pPlayer->iFieldID].pActor = pPlayer;
		UpdateAllActorFields();
		// Update all walls:
		for(i = 0, y = 0; y < pLevel->Header.iHeight; y++)
			for(x = 0; x < pLevel->Header.iWidth; x++, i++)
			{
				if(pLevelT->pField[i].bWallHole)
					pLevelT->SetFieldWall(pLevelT->pField[i].iXField, pLevelT->pField[i].iYField, TRUE, FALSE);
				if(!pLevel->pField[i].bActive)
					continue;
				if(pLevel->pField[i].pActor)
				{
					pLevel->pField[i].pActor = pLevel->pField[i].pActor;
					pLevelT->SetFieldWall(x, y, FALSE, FALSE);
				}
				else
					pLevelT->SetFieldWall(x, y, pLevel->pField[i].bWall, FALSE);
			}
		InitGameParticleSystems();
	}
	else
	{
		if(pLevelT)
		{
			delete pLevelT;
			pLevelT = NULL;
		}
	}

	// Check move level:
	if(iMoveX || iMoveY)
	{
		FLOAT3 *fPoint;
		FLOAT4 *fColor;
		short iTemp1, iTemp2;
		
		i2 = pLevelT->Header.iPoints/2;
		DestroyGameParticleSystems();
		fPoint = new FLOAT3[pLevel->Header.iPoints];
		fColor = new FLOAT4[pLevel->Header.iPoints];
		memcpy(fPoint, pLevel->fPoint, sizeof(FLOAT3)*pLevel->Header.iPoints);
		memcpy(fColor, pLevel->fColor, sizeof(FLOAT4)*pLevel->Header.iPoints);
		pNewFieldT = (FIELD *) malloc(sizeof(FIELD)*pLevel->Header.iFields);
		memcpy(pNewFieldT, pLevel->pField, sizeof(FIELD)*pLevel->Header.iFields);
		for(y = 0; y < pLevel->Header.iHeight; y++)
		{
			for(x = 0; x < pLevel->Header.iWidth; x++)
			{
				iX = x+iMoveX;
				iY = y+iMoveY;
				if(iX >= pLevel->Header.iWidth-1 ||
				   iY >= pLevel->Header.iHeight-1 ||
				   iX < 0 || iY < 0)
					continue;
				pCurrentField = &pLevel->pField[iY*pLevel->Header.iWidth+iX];
				pLastField = &pNewFieldT[y*pLevel->Header.iWidth+x];
				// Copy field information:
				memcpy(pCurrentField, pLastField, sizeof(FIELD));
				pCurrentField->iBeamerParticleSystemID = -1;
				pCurrentField->iBeamerTarget += iMoveY*pLevel->Header.iWidth+iMoveX;
			}
		}
		// Update fields:
		for(i = 0, i3 = 0, y = 0; y < pLevel->Header.iHeight; y++)
		{
			for(x = 0; x < pLevel->Header.iWidth; x++, i++, i3++)
			{
				pCurrentField = &pLevel->pField[i];
				pCurrentField->iXField = x;
				pCurrentField->iYField = y;
				pCurrentField->iXPos = (short) (x*pLevel->Header.fFieldWidth);
				pCurrentField->iYPos = (short) (y*pLevel->Header.fFieldHeight);
				pCurrentField->iID = i;

				// Setup the field faces;
				// Front face:
				pCurrentField->iFace[FACE_FRONT][0] = i3+1;
				pCurrentField->iFace[FACE_FRONT][1] = i3+pLevel->Header.iWidth+2;
				pCurrentField->iFace[FACE_FRONT][2] = i3+pLevel->Header.iWidth+1;
				pCurrentField->iFace[FACE_FRONT][3] = i3;
				// Floor face:
				pCurrentField->iFace[FACE_FLOOR][0] = i3+1+i2;
				pCurrentField->iFace[FACE_FLOOR][1] = i3+pLevel->Header.iWidth+2+i2;
				pCurrentField->iFace[FACE_FLOOR][2] = i3+pLevel->Header.iWidth+1+i2;
				pCurrentField->iFace[FACE_FLOOR][3] = i3+i2;
				// Left face:
				pCurrentField->iFace[FACE_LEFT][0] = i3+pLevel->Header.iWidth+1;
				pCurrentField->iFace[FACE_LEFT][1] = i3+i2+pLevel->Header.iWidth+1;
				pCurrentField->iFace[FACE_LEFT][2] = i3+i2;
				pCurrentField->iFace[FACE_LEFT][3] = i3;
				// Right face:
				pCurrentField->iFace[FACE_RIGHT][0] = i3+1;
				pCurrentField->iFace[FACE_RIGHT][1] = i3+i2+1;
				pCurrentField->iFace[FACE_RIGHT][2] = i3+i2+pLevel->Header.iWidth+2;
				pCurrentField->iFace[FACE_RIGHT][3] = i3+pLevel->Header.iWidth+2;
				// Top face:
				pCurrentField->iFace[FACE_TOP][0] = i3;
				pCurrentField->iFace[FACE_TOP][1] = i3+i2;
				pCurrentField->iFace[FACE_TOP][2] = i3+i2+1;
				pCurrentField->iFace[FACE_TOP][3] = i3+1;
				// Bottom face:
				pCurrentField->iFace[FACE_BOTTOM][0] = i3+pLevel->Header.iWidth+2;
				pCurrentField->iFace[FACE_BOTTOM][1] = i3+i2+pLevel->Header.iWidth+2;
				pCurrentField->iFace[FACE_BOTTOM][2] = i3+i2+pLevel->Header.iWidth+1;
				pCurrentField->iFace[FACE_BOTTOM][3] = i3+pLevel->Header.iWidth+1;
			}
			i3++;
		}
		for(y = 0; y < pLevel->Header.iHeight; y++)
		{
			for(x = 0; x < pLevel->Header.iWidth; x++)
			{
				iX = x+iMoveX;
				iY = y+iMoveY;
				if(iX >= pLevel->Header.iWidth-1 ||
				   iY >= pLevel->Header.iHeight-1 ||
				   iX < 0 || iY < 0)
					continue;
				pCurrentField = &pLevel->pField[iY*pLevel->Header.iWidth+iX];
				pLastField = &pNewFieldT[y*pLevel->Header.iWidth+x];
				// Copy point information:
				for(iTemp1 = 0; iTemp1 < 6; iTemp1++)
					for(iTemp2 = 0; iTemp2 < 4; iTemp2++)
					{
						memcpy(pLevel->fPoint[pCurrentField->iFace[iTemp1][iTemp2]],
							   fPoint[pLastField->iFace[iTemp1][iTemp2]], sizeof(FLOAT3));
						pLevel->fPoint[pCurrentField->iFace[iTemp1][iTemp2]][X] += pLevel->Header.fFieldWidth*iMoveX;
						pLevel->fPoint[pCurrentField->iFace[iTemp1][iTemp2]][Y] += pLevel->Header.fFieldWidth*iMoveY;
						memcpy(pLevel->fColor[pCurrentField->iFace[iTemp1][iTemp2]],
							   fColor[pLastField->iFace[iTemp1][iTemp2]], sizeof(FLOAT4));
					}
			}
		}
		free(pNewFieldT);
		pNewFieldT = NULL;
		free(fPoint);
		free(fColor);
		pPlayer->iFieldPos[X] += iMoveX;
		pPlayer->iFieldPos[Y] += iMoveY;
		if(pPlayer->iFieldPos[X] >= pLevel->Header.iWidth-1 ||
		   pPlayer->iFieldPos[Y] >= pLevel->Header.iHeight-1 ||
		   pPlayer->iFieldPos[X] < 0 || pPlayer->iFieldPos[Y] < 0)
			pPlayer->bActive = FALSE;
		for(i = 0; i < MAX_ACTORS; i++)
		{
			Actor[i].iFieldPos[X] += iMoveX;
			Actor[i].iFieldPos[Y] += iMoveY;
			if(Actor[i].iFieldPos[X] >= pLevel->Header.iWidth-1 ||
			   Actor[i].iFieldPos[Y] >= pLevel->Header.iHeight-1 ||
			   Actor[i].iFieldPos[X] < 0 || Actor[i].iFieldPos[Y] < 0)
				Actor[i].bActive = FALSE;
		}
		pLevel->CalculateFieldNormals();
		pLevel->CalculateFieldBoundingBoxes();
		UpdateAllActorFields();
		InitGameParticleSystems();
	}

	if(pOldLevelTemp)
		delete pOldLevelTemp;

	pLevel->Environment.lWaterAniTime = g_lNow;
	UpdateAllActorFields();
	if(!wglMakeCurrent(hDCEditorShow, hRCEditorShow))
		return;
} // end AdjustLevelDialog()	

LRESULT CALLBACK LevelMissionsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin LevelMissionsProc()
	char byTemp[256];
	short i;
	
	switch(iMessage)
    {
        case WM_INITDIALOG:
				pLevelT->UpdateMissions();
				hWndLevelMissions = hWnd;
				_AS->WriteLogMessage("Open level missions dialog");
				SetWindowText(hWnd, T_LevelMissions);
				SetDlgItemText(hWnd, ID_LEVEL_MISSIONS_OK, T_Ok);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_TIME_LIMIT, T_TimeLimit);
				sprintf(byTemp, "%d", pLevelT->Missions.iTimeLimit);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_TIME_LIMIT_TIME, byTemp);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_STEP_LIMIT, T_StepsLimit);
				sprintf(byTemp, "%d", pLevelT->Missions.iStepsLimit);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_STEP_LIMIT_LIMIT, byTemp);
				sprintf(byTemp, "%d", pLevelT->Missions.iCollectPoints);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_COLLECT_POINTS, byTemp);
				sprintf(byTemp, "%d", pLevelT->Missions.iCollectHealth);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_COLLECT_HEALTH, byTemp);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_EXIT, T_Exit);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_ALCOVE, T_Alcove);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_COLLECT_POINTS_CHECKED, T_CollectPoints);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_COLLECT_HEALTH_CHECKED, T_CollectHealth);
				sprintf(byTemp, "(%d)", pLevelT->Header.iPointsObj);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_POINTS, byTemp);
				sprintf(byTemp, "(%d)", pLevelT->Header.iMobmobs);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_KILL_MOBMOBS_T, byTemp);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_KILL_MOBMOBS_CHECKED, T_KillMobmobs);
				sprintf(byTemp, "%d", pLevelT->Missions.iKillMobmobs);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_KILL_MOBMOBS, byTemp);
				sprintf(byTemp, "(%d)", pLevelT->Header.iX3);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_KILL_X3_T, byTemp);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_KILL_X3_CHECKED, T_KillX3);
				sprintf(byTemp, "%d", pLevelT->Missions.iKillX3);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_KILL_X3, byTemp);
				// No free anchor:
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_ANCHOR, T_NoFreeAnchor);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_FOR_ALL_ANCHOR, T_ForAll);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_RED_ANCHOR, T_Red);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_GREEN_ANCHOR, T_Green);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_BLUE_ANCHOR, T_Blue);
				// No free box:
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_BOX, T_NoFreeBox);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_BOX, T_Normal);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_RED_BOX, T_Red);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_GREEN_BOX, T_Green);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_BLUE_BOX, T_Blue);
				// No box:
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_BOX, T_NoBox);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_NORMAL_BOX, T_Normal);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_RED_BOX, T_Red);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_GREEN_BOX, T_Green);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_BLUE_BOX, T_Blue);				

				UpdateLevelMissions();
				
				ShowWindow(hWnd, _AS->GetCmdShow());
				UpdateWindow(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_LEVEL_MISSIONS_OK:
					EndDialog(hWnd, FALSE);
					hWndLevelMissions = NULL;
					_AS->WriteLogMessage("Close level missions dialog");
				break;
			 
			    case IDC_LEVEL_MISSIONS_TIME_LIMIT:
					pLevelT->Missions.bTimeLimit = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_TIME_LIMIT, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_TIME_LIMIT_TIME:
					GetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_TIME_LIMIT_TIME, byTemp, 256);
					i = atoi(byTemp)		;
					if(i < 0)
					{
						i = 0;
						SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_TIME_LIMIT_TIME, "0");
					}
					pLevelT->Missions.iTimeLimit = i;
				break;

			    case IDC_LEVEL_MISSIONS_STEP_LIMIT:
					pLevelT->Missions.bStepsLimit = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_STEP_LIMIT, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_STEP_LIMIT_LIMIT:
					GetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_STEP_LIMIT_LIMIT, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
					{
						i = 0;
						SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_STEP_LIMIT_LIMIT, "0");
					}
					pLevelT->Missions.iStepsLimit = i;
				break;

			    case IDC_LEVEL_MISSIONS_EXIT:
					pLevelT->Missions.bExit = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_EXIT, BM_GETCHECK, 0, 0L);
					pLevelT->Missions.bAlcove = FALSE;
					UpdateLevelMissions();
				break;
			    
				case IDC_LEVEL_MISSIONS_ALCOVE:
					pLevelT->Missions.bAlcove = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_ALCOVE, BM_GETCHECK, 0, 0L);
					pLevelT->Missions.bExit = FALSE;
					UpdateLevelMissions();
				break;

				case IDC_LEVEL_MISSIONS_COLLECT_POINTS_CHECKED:
					pLevelT->Missions.bCollectPoints = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_COLLECT_POINTS_CHECKED, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

				case IDC_LEVEL_MISSIONS_COLLECT_POINTS:
					GetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_COLLECT_POINTS, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
					{
						i = 0;
						SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_COLLECT_POINTS, "0");
					}
					pLevelT->Missions.iCollectPoints = i;
				break;

				case IDC_LEVEL_MISSIONS_COLLECT_HEALTH_CHECKED:
					pLevelT->Missions.bCollectHealth = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_COLLECT_HEALTH_CHECKED, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

				case IDC_LEVEL_MISSIONS_COLLECT_HEALTH:
					GetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_COLLECT_HEALTH, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
					{
						i = 0;
						SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_COLLECT_HEALTH, "0");
					}
					pLevelT->Missions.iCollectHealth = i;
				break;

				case IDC_LEVEL_MISSIONS_KILL_MOBMOBS_CHECKED:
					pLevelT->Missions.bKillMobmobs = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_KILL_MOBMOBS_CHECKED, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

				case IDC_LEVEL_MISSIONS_KILL_MOBMOBS:
					GetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_KILL_MOBMOBS, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
					{
						i = 0;
						SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_KILL_MOBMOBS, "0");
					}
					pLevelT->Missions.iKillMobmobs = i;
				break;

				case IDC_LEVEL_MISSIONS_KILL_X3_CHECKED:
					pLevelT->Missions.bKillX3 = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_KILL_X3_CHECKED, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

				case IDC_LEVEL_MISSIONS_KILL_X3:
					GetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_KILL_X3, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
					{
						i = 0;
						SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_KILL_X3, "0");
					}
					pLevelT->Missions.iKillX3 = i;
				break;

			// No free anchor:
			    case IDC_LEVEL_MISSIONS_NO_FREE_FOR_ALL_ANCHOR:
					pLevelT->Missions.bNoFreeForAllAnchor = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_FOR_ALL_ANCHOR, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_ANCHOR:
					pLevelT->Missions.bNoFreeNormalAnchor = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_ANCHOR, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_NO_FREE_RED_ANCHOR:
					pLevelT->Missions.bNoFreeRedAnchor = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_RED_ANCHOR, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_NO_FREE_GREEN_ANCHOR:
					pLevelT->Missions.bNoFreeGreenAnchor = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_GREEN_ANCHOR, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_NO_FREE_BLUE_ANCHOR:
					pLevelT->Missions.bNoFreeBlueAnchor = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_BLUE_ANCHOR, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			// No free box:
			    case IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_BOX:
					pLevelT->Missions.bNoFreeNormalBox = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_BOX, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_NO_FREE_RED_BOX:
					pLevelT->Missions.bNoFreeRedBox = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_RED_BOX, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_NO_FREE_GREEN_BOX:
					pLevelT->Missions.bNoFreeGreenBox = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_GREEN_BOX, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_NO_FREE_BLUE_BOX:
					pLevelT->Missions.bNoFreeBlueBox = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_BLUE_BOX, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			// No box:
			    case IDC_LEVEL_MISSIONS_NO_NORMAL_BOX:
					pLevelT->Missions.bNoNormalBox = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_NORMAL_BOX, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_NO_RED_BOX:
					pLevelT->Missions.bNoRedBox = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_RED_BOX, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_NO_GREEN_BOX:
					pLevelT->Missions.bNoGreenBox = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_GREEN_BOX, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_NO_BLUE_BOX:
					pLevelT->Missions.bNoBlueBox = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_BLUE_BOX, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;
			}
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_LEVEL_MISSIONS_OK, 0);
		break;
    }
    return FALSE;
} // end LevelMissionsProc()

void UpdateLevelMissions(void)
{ // begin UpdateLevelMissions()
	if(!hWndLevelMissions)
		return;
	// Time limit:
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_TIME_LIMIT, BM_SETCHECK, pLevelT->Missions.bTimeLimit, 0L);
	EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_TIME_LIMIT_TIME), pLevelT->Missions.bTimeLimit);
	// Step limit:
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_STEP_LIMIT, BM_SETCHECK, pLevelT->Missions.bStepsLimit, 0L);
	EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_STEP_LIMIT_LIMIT), pLevelT->Missions.bStepsLimit);
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_EXIT, BM_SETCHECK, pLevelT->Missions.bExit, 0L);
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_ALCOVE, BM_SETCHECK, pLevelT->Missions.bAlcove, 0L);
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_COLLECT_POINTS_CHECKED, BM_SETCHECK, pLevelT->Missions.bCollectPoints, 0L);
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_COLLECT_HEALTH_CHECKED, BM_SETCHECK, pLevelT->Missions.bCollectHealth, 0L);
	EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_COLLECT_POINTS), pLevelT->Missions.bCollectPoints);
	EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_COLLECT_HEALTH), pLevelT->Missions.bCollectHealth);
	if(pLevelT->Missions.bNoNormalBox && pLevelT->Missions.bNoRedBox && pLevelT->Missions.bNoGreenBox && pLevelT->Missions.bNoBlueBox)
	{
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_FOR_ALL_ANCHOR), FALSE);
		pLevelT->Missions.bNoFreeForAllAnchor = FALSE;
	}
	else
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_FOR_ALL_ANCHOR), TRUE);
	if(pLevelT->Missions.bNoNormalBox)
	{
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_ANCHOR), FALSE);
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_BOX), FALSE);
		pLevelT->Missions.bNoFreeNormalAnchor = FALSE;
		pLevelT->Missions.bNoFreeNormalBox = FALSE;
	}
	else
	{
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_ANCHOR), TRUE);
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_BOX), TRUE);
	}
	if(pLevelT->Missions.bNoRedBox)
	{
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_RED_ANCHOR), FALSE);
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_RED_BOX), FALSE);
		pLevelT->Missions.bNoFreeRedAnchor = FALSE;
		pLevelT->Missions.bNoFreeRedBox = FALSE;
	}
	else
	{
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_RED_ANCHOR), TRUE);
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_RED_BOX), TRUE);
	}
	if(pLevelT->Missions.bNoGreenBox)
	{
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_GREEN_ANCHOR), FALSE);
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_GREEN_BOX), FALSE);
		pLevelT->Missions.bNoFreeGreenAnchor = FALSE;
		pLevelT->Missions.bNoFreeGreenBox = FALSE;
	}
	else
	{
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_GREEN_ANCHOR), TRUE);
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_GREEN_BOX), TRUE);
	}
	if(pLevelT->Missions.bNoBlueBox)
	{
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_BLUE_ANCHOR), FALSE);
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_BLUE_BOX), FALSE);
		pLevelT->Missions.bNoFreeBlueAnchor = FALSE;
		pLevelT->Missions.bNoFreeBlueBox = FALSE;
	}
	else
	{
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_BLUE_ANCHOR), TRUE);
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_BLUE_BOX), TRUE);
	}
	// No free anchor:
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_FOR_ALL_ANCHOR, BM_SETCHECK, pLevelT->Missions.bNoFreeForAllAnchor, 0L);
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_ANCHOR, BM_SETCHECK, pLevelT->Missions.bNoFreeNormalAnchor, 0L);
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_RED_ANCHOR, BM_SETCHECK, pLevelT->Missions.bNoFreeRedAnchor, 0L);
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_GREEN_ANCHOR, BM_SETCHECK, pLevelT->Missions.bNoFreeGreenAnchor, 0L);
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_BLUE_ANCHOR, BM_SETCHECK, pLevelT->Missions.bNoFreeBlueAnchor, 0L);
	// No free box:
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_BOX, BM_SETCHECK, pLevelT->Missions.bNoFreeNormalBox, 0L);
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_RED_BOX, BM_SETCHECK, pLevelT->Missions.bNoFreeRedBox, 0L);
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_GREEN_BOX, BM_SETCHECK, pLevelT->Missions.bNoFreeGreenBox, 0L);
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_BLUE_BOX, BM_SETCHECK, pLevelT->Missions.bNoFreeBlueBox, 0L);
	// No box:
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_NORMAL_BOX, BM_SETCHECK, pLevelT->Missions.bNoNormalBox, 0L);
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_RED_BOX, BM_SETCHECK, pLevelT->Missions.bNoRedBox, 0L);
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_GREEN_BOX, BM_SETCHECK, pLevelT->Missions.bNoGreenBox, 0L);
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_BLUE_BOX, BM_SETCHECK, pLevelT->Missions.bNoBlueBox, 0L);
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_KILL_MOBMOBS_CHECKED, BM_SETCHECK, pLevelT->Missions.bKillMobmobs, 0L);
	if(pLevelT->Missions.bKillMobmobs)
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_KILL_MOBMOBS), TRUE);
	else
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_KILL_MOBMOBS), FALSE);
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_KILL_X3_CHECKED, BM_SETCHECK, pLevelT->Missions.bKillX3, 0L);
	if(pLevelT->Missions.bKillX3)
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_KILL_X3), TRUE);
	else
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_KILL_X3), FALSE);
} // end UpdateLevelMissions()

LRESULT CALLBACK LevelToolsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin LevelToolsProc()
	char byTemp[256];
	int i;
	
	switch(iMessage)
    {
        case WM_INITDIALOG:
				_AS->WriteLogMessage("Open level tools dialog");
				hWndLevelTools = hWnd;
				SetWindowText(hWnd, T_StartTools);
				SetDlgItemText(hWnd, ID_LEVEL_TOOLS_OK, T_Ok);

				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_LIVES_T, T_LiveObj);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_POINTS_T, T_PointObj);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_WEAPON_T, T_WeaponObj);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_PULL_BOXES_T, T_PullObj);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_THROW_BOXES_T, T_ThrowObj);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_FORCE_T, T_ForceObj);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_JUMP_T, T_Jump);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_GHOST, T_GhostObj);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_SPEED, T_SpeedObj);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_WING, T_WingsObj);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_SHIELD, T_ShieldObj);

				sprintf(byTemp, "%d", pLevelT->Tools.iLives);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_LIVES, byTemp);
				sprintf(byTemp, "%d", pLevelT->Tools.iPoints);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_POINTS, byTemp);
				sprintf(byTemp, "%d", pLevelT->Tools.iWeapon);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_WEAPON, byTemp);
				sprintf(byTemp, "%d", pLevelT->Tools.iPull);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_PULL, byTemp);
				sprintf(byTemp, "%d", pLevelT->Tools.iThrow);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_THROW, byTemp);
				sprintf(byTemp, "%d", pLevelT->Tools.iForce);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_FORCE, byTemp);
				sprintf(byTemp, "%d", pLevelT->Tools.iJump);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_JUMP, byTemp);

				sprintf(byTemp, "%d", pLevelT->Tools.lGhostTime);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_GHOST_TIME, byTemp);
				sprintf(byTemp, "%d", pLevelT->Tools.lSpeedTime);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_SPEED_TIME, byTemp);
				sprintf(byTemp, "%d", pLevelT->Tools.lWingTime);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_WING_TIME, byTemp);
				sprintf(byTemp, "%d", pLevelT->Tools.lShieldTime);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_SHIELD_TIME, byTemp);

				UpdateLevelTools();
				
				ShowWindow(hWnd, _AS->GetCmdShow());
				UpdateWindow(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_LEVEL_TOOLS_OK:
					EndDialog(hWnd, FALSE);
					hWndLevelTools = NULL;
					_AS->WriteLogMessage("Close level tools dialog");
				break;
					
				case IDC_LEVEL_TOOLS_LIVES:
					GetDlgItemText(hWnd, IDC_LEVEL_TOOLS_LIVES, byTemp, 256);
					i = atoi(byTemp);
					pLevelT->Tools.iLives = i;
				break;

				case IDC_LEVEL_TOOLS_POINTS:
					GetDlgItemText(hWnd, IDC_LEVEL_TOOLS_POINTS, byTemp, 256);
					i = atoi(byTemp);
					pLevelT->Tools.iPoints = i;
				break;

				case IDC_LEVEL_TOOLS_WEAPON_UNLIMITED:
					pLevelT->Tools.bUnlimitedWeapon = SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_WEAPON_UNLIMITED, BM_GETCHECK, 0, 0L);
					PlayerInfo.bWeapon = pLevelT->Tools.bUnlimitedWeapon;
					if(pLevelT->Tools.iWeapon)
						PlayerInfo.bWeapon = TRUE;
					UpdateLevelTools();
				break;

				case IDC_LEVEL_TOOLS_WEAPON:
					GetDlgItemText(hWnd, IDC_LEVEL_TOOLS_WEAPON, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
						i = 0;
					pLevelT->Tools.iWeapon = i;
					if(pLevelT->Tools.iWeapon)
						PlayerInfo.bWeapon = TRUE;
				break;

				case IDC_LEVEL_TOOLS_PULL_UNLIMITED:
					pLevelT->Tools.bUnlimitedPull = SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_PULL_UNLIMITED, BM_GETCHECK, 0, 0L);
					UpdateLevelTools();
				break;

				case IDC_LEVEL_TOOLS_PULL:
					GetDlgItemText(hWnd, IDC_LEVEL_TOOLS_PULL, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
						i = 0;
					pLevelT->Tools.iPull = i;
				break;

				case IDC_LEVEL_TOOLS_THROW_UNLIMITED:
					pLevelT->Tools.bUnlimitedThrow = SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_THROW_UNLIMITED, BM_GETCHECK, 0, 0L);
					UpdateLevelTools();
				break;

				case IDC_LEVEL_TOOLS_THROW:
					GetDlgItemText(hWnd, IDC_LEVEL_TOOLS_THROW, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
						i = 0;
					pLevelT->Tools.iThrow = i;
				break;

				case IDC_LEVEL_TOOLS_FORCE_UNLIMITED:
					pLevelT->Tools.bUnlimitedForce = SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_FORCE_UNLIMITED, BM_GETCHECK, 0, 0L);
					UpdateLevelTools();
				break;

				case IDC_LEVEL_TOOLS_FORCE:
					GetDlgItemText(hWnd, IDC_LEVEL_TOOLS_FORCE, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
						i = 0;
					pLevelT->Tools.iForce = i;
				break;

				case IDC_LEVEL_TOOLS_JUMP_UNLIMITED:
					pLevelT->Tools.bUnlimitedJump = SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_JUMP_UNLIMITED, BM_GETCHECK, 0, 0L);
					UpdateLevelTools();
				break;

				case IDC_LEVEL_TOOLS_JUMP:
					GetDlgItemText(hWnd, IDC_LEVEL_TOOLS_JUMP, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
						i = 0;
					pLevelT->Tools.iJump = i;
				break;

				case IDC_LEVEL_TOOLS_GHOST:
					pLevelT->Tools.bGhost = SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_GHOST, BM_GETCHECK, 0, 0L);
					PlayerInfo.bGhost = pLevelT->Tools.bGhost;
					ParticleManager.pSystem[PS_PLAYER_GHOST].bActive = PlayerInfo.bGhost;
				break;

				case IDC_LEVEL_TOOLS_SPEED:
					pLevelT->Tools.bSpeed = SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_SPEED, BM_GETCHECK, 0, 0L);
					PlayerInfo.bSpeed = pLevelT->Tools.bSpeed;
					ParticleManager.pSystem[PS_PLAYER_SPEED].bActive = PlayerInfo.bSpeed;
				break;

				case IDC_LEVEL_TOOLS_WING:
					pLevelT->Tools.bWing = SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_WING, BM_GETCHECK, 0, 0L);
				break;

				case IDC_LEVEL_TOOLS_SHIELD:
					pLevelT->Tools.bShield = SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_SHIELD, BM_GETCHECK, 0, 0L);
					PlayerInfo.bShield = pLevelT->Tools.bShield;
				break;

				case IDC_LEVEL_TOOLS_GHOST_TIME:
					GetDlgItemText(hWnd, IDC_LEVEL_TOOLS_GHOST_TIME, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
						i = 0;
					pLevelT->Tools.lGhostTime = i;
				break;

				case IDC_LEVEL_TOOLS_SPEED_TIME:
					GetDlgItemText(hWnd, IDC_LEVEL_TOOLS_SPEED_TIME, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
						i = 0;
					pLevelT->Tools.lSpeedTime = i;
				break;

				case IDC_LEVEL_TOOLS_WING_TIME:
					GetDlgItemText(hWnd, IDC_LEVEL_TOOLS_WING_TIME, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
						i = 0;
					pLevelT->Tools.lWingTime = i;
				break;

				case IDC_LEVEL_TOOLS_SHIELD_TIME:
					GetDlgItemText(hWnd, IDC_LEVEL_TOOLS_SHIELD_TIME, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
						i = 0;
					pLevelT->Tools.lShieldTime = i;
				break;
			}
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_LEVEL_TOOLS_OK, 0);
		break;
    }
    return FALSE;
} // end LevelToolsProc()

void UpdateLevelTools(void)
{ // begin UpdateLevelTools()
	if(!hWndLevelTools)
		return;
	SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_WEAPON_UNLIMITED, BM_SETCHECK, pLevelT->Tools.bUnlimitedWeapon, 0L);
	SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_PULL_UNLIMITED, BM_SETCHECK, pLevelT->Tools.bUnlimitedPull, 0L);
	SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_THROW_UNLIMITED, BM_SETCHECK, pLevelT->Tools.bUnlimitedThrow, 0L);
	SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_FORCE_UNLIMITED, BM_SETCHECK, pLevelT->Tools.bUnlimitedForce, 0L);
	SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_JUMP_UNLIMITED, BM_SETCHECK, pLevelT->Tools.bUnlimitedJump, 0L);
	if(pLevelT->Tools.bUnlimitedWeapon)
		EnableWindow(GetDlgItem(hWndLevelTools, IDC_LEVEL_TOOLS_WEAPON), FALSE);
	else
		EnableWindow(GetDlgItem(hWndLevelTools, IDC_LEVEL_TOOLS_WEAPON), TRUE);
	if(pLevelT->Tools.bUnlimitedPull)
		EnableWindow(GetDlgItem(hWndLevelTools, IDC_LEVEL_TOOLS_PULL), FALSE);
	else
		EnableWindow(GetDlgItem(hWndLevelTools, IDC_LEVEL_TOOLS_PULL), TRUE);
	if(pLevelT->Tools.bUnlimitedThrow)
		EnableWindow(GetDlgItem(hWndLevelTools, IDC_LEVEL_TOOLS_THROW), FALSE);
	else
		EnableWindow(GetDlgItem(hWndLevelTools, IDC_LEVEL_TOOLS_THROW), TRUE);
	if(pLevelT->Tools.bUnlimitedForce)
		EnableWindow(GetDlgItem(hWndLevelTools, IDC_LEVEL_TOOLS_FORCE), FALSE);
	else
		EnableWindow(GetDlgItem(hWndLevelTools, IDC_LEVEL_TOOLS_FORCE), TRUE);
	if(pLevelT->Tools.bUnlimitedJump)
		EnableWindow(GetDlgItem(hWndLevelTools, IDC_LEVEL_TOOLS_JUMP), FALSE);
	else
		EnableWindow(GetDlgItem(hWndLevelTools, IDC_LEVEL_TOOLS_JUMP), TRUE);
	SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_GHOST, BM_SETCHECK, pLevelT->Tools.bGhost, 0L);
	SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_SPEED, BM_SETCHECK, pLevelT->Tools.bSpeed, 0L);
	SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_WING, BM_SETCHECK, pLevelT->Tools.bWing, 0L);
	SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_SHIELD, BM_SETCHECK, pLevelT->Tools.bShield, 0L);
} // end UpdateLevelTools()
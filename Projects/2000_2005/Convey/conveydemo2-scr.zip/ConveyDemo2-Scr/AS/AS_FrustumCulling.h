#ifndef __AS_FRUSTUM_CULLING_H__
#define __AS_FRUSTUM_CULLING_H__


// Functions: *****************************************************************
extern void ASExtractFrustum(void);
extern bool ASPointInFrustum(float, float, float);
extern bool SphereInFrustum(float, float, float, float);
extern bool CubeInFrustum(float, float, float, float);
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern float ASFrustum[6][4];		// Holds The Current Frustum Plane Equations
extern short iCulledObjects;
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_FRUSTUM_CULLING_H__
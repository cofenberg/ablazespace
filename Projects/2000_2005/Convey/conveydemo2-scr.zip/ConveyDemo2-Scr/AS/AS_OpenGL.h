//-----------------------------------------------------------------------------
// File: AS_OpenGL.h
//-----------------------------------------------------------------------------

#ifndef __AS_OPENGL_H__
#define __AS_OPENGL_H__


// Functions: *****************************************************************
extern LRESULT CALLBACK OpenGLInfoProc(HWND, UINT, WPARAM, LPARAM);
extern HRESULT ASInitOpenGL(AS_WINDOW *, HWND, HDC *, HGLRC *, BOOL);
extern void ASConfigOpenGL(int, int);
extern HRESULT ASDestroyOpenGL(AS_WINDOW *, HWND, HDC, HGLRC);
extern void ASBuildFont(void);
extern void ASKillFont(void);
extern void ASPrint(short, short, char *, short);
extern void ASSimplePrint(short, short, char *, GLuint);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_OPENGL_H__
//-----------------------------------------------------------------------------
// File: AS_Collision.cpp
//-----------------------------------------------------------------------------

#include "AS_Engine.h"


// Functions: *****************************************************************
double ASIntersectRayPlane(AS_VECTOR, AS_VECTOR, AS_VECTOR, AS_VECTOR);
BOOL ASCheckPointInTriangle(AS_VECTOR, AS_VECTOR, AS_VECTOR, AS_VECTOR);
///////////////////////////////////////////////////////////////////////////////

// ----------------------------------------------------------------------
// Name  : ASIntersectRayPlane()
// Input : rOrigin - origin of ray in world space
//         rVector - vector describing direction of ray in world space
//         pOrigin - Origin of plane 
//         pNormal - Normal to plane
// Notes : Normalized directional vectors expected
// Return: distance to plane in world units, -1 if no intersection.
// -----------------------------------------------------------------------  
double ASIntersectRayPlane(AS_VECTOR rOrigin, AS_VECTOR rVector, AS_VECTOR pOrigin, AS_VECTOR pNormal)
{ // begin ASIntersectRayPlane()
	double d = - (dot(pNormal,pOrigin));

	double numer = dot(pNormal,rOrigin)+d;
	double denom = dot(pNormal,rVector);

	if(!denom) // normal is orthogonal to vector, cant intersect
		return (-1.0f);

	return -(numer/denom);	
} // end ASIntersectRayPlane()


// ----------------------------------------------------------------------
// Name  : ASCheckPointInTriangle()
// Input : point - point we wish to check for inclusion
//         a - first vertex in triangle
//         b - second vertex in triangle 
//         c - third vertex in triangle
// Notes : Triangle should be defined in clockwise order a,b,c
// Return: TRUE if point is in triangle, FALSE if not.
// -----------------------------------------------------------------------  
BOOL ASCheckPointInTriangle(AS_VECTOR point, AS_VECTOR a, AS_VECTOR b, AS_VECTOR c)
{ // begin ASCheckPointInTriangle()
	double total_angles = 0.0f, t;
   
	// make the 3 vectors
	AS_VECTOR v1 = point-a;
	AS_VECTOR v2 = point-b;
	AS_VECTOR v3 = point-c;

	normalizeVector(v1);
	normalizeVector(v2);
	normalizeVector(v3);

	t = dot(v1,v2);
	if(t < -1.0f)
		t = -1.0f;
	if(t > 1.0f)
		1.0f;
	total_angles += acos(t);
	t = dot(v2,v3);
	if(t < -1.0f)
		t = -1.0f;
	if(t > 1.0f)
		1.0f;
	total_angles += acos(t);
	t = dot(v3,v1);
	if(t < -1.0f)
		t = -1.0f;
	if(t > 1.0f)
		1.0f;
	total_angles += acos(t);

	if(fabs(total_angles-2*PI) <= 0.005)
		return TRUE;
 
	return FALSE;
} // end ASCheckPointInTriangle()
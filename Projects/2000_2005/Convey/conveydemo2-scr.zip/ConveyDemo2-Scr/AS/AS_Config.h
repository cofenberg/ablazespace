//-----------------------------------------------------------------------------
// File: AS_Config.h
//-----------------------------------------------------------------------------

#ifndef __AS_CONFIG_H__
#define __AS_CONFIG_H__


// Structures: ****************************************************************
typedef struct
{
	int Number;
	DEVMODE *pDevMode;
} DISPLAY_MODE_INFO;
///////////////////////////////////////////////////////////////////////////////

// Classes: *******************************************************************
typedef class AS_CONFIG
{
	public:
		// General:
		BOOL bFirstRun;
		BOOL bError, bSetError;
		BOOL bMouseScroll;
		BOOL bSound;
		BOOL bMusic;
		BOOL bDrawBounding;
		BOOL bFrustumCulling;
		BOOL bShowCulledObjects;
		BOOL bShowFPS;
		BOOL bLog;
		RECT EditorWindow;
		char byLanguage[256];
		BOOL bRotateMove;
		BOOL bBackCamera;
		BOOL bTiltCamera;
		float fMouseSensibility;
		long iMusicVolume; // The volume of the music
		
		// Graphic:
		BOOL bFullScreen;
		BOOL bUseLevelVertexColor;
		BOOL bFastTexturing;
		BOOL bUseMipmaps;
		BOOL bMultitexturing;
		BOOL bHightRenderQuality;
		DWORD dwMode;
		char byZBuffer; // The z buffer bit depth
		char byLight; // 0 = none, 1 = flat, 2 = smooth
		short iWindowWidth, iWindowHeight;
		short iModeIndex; 
		DEVMODE DevMode;
		short iScreenPixels, iScreenSize;
		BOOL bParticles; // Are the particles activated?
		float fParticleDensity; // The number of partilces (1.0 = full)

		// Keys:
		// [0] = Key array position
		// [1] = Key description array position
		short iLeftKey[2], iRightKey[2], iUpKey[2], iDownKey[2],
			  iShotKey[2], iThrowKey[2], iPullKey[2], iSuicideKey[2],
			  iJumpKey[2], iChangePerspectiveKey[2], iBackCameraKey[2],
			  iTiltCameraKey[2], iStandartViewKey[2], iPauseKey[2],
			  iLoadAutosaveKey[2], iLevelRestartKey[2];


		AS_CONFIG(void);
		~AS_CONFIG(void);

		void Check(void);
        HRESULT Load(char *);
	    HRESULT Save(char *);
} AS_CONFIG;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern AS_CONFIG *_ASConfig;
extern DISPLAY_MODE_INFO DisplayModeInfo;
extern BOOL bFirstRunConfigDialog;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern void OpenConfigDialog(HWND);
extern void SetConfigLanguage(void);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_CONFIG_H__
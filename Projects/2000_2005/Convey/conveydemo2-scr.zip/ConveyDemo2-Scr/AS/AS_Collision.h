//-----------------------------------------------------------------------------
// File: AS_Collsison.h
//-----------------------------------------------------------------------------

#ifndef __AS_COLLISION_H__
#define __AS_COLLISION_H__


// Functions: *****************************************************************
extern double ASIntersectRayPlane(AS_VECTOR, AS_VECTOR, AS_VECTOR, AS_VECTOR);
extern BOOL ASCheckPointInTriangle(AS_VECTOR, AS_VECTOR, AS_VECTOR, AS_VECTOR);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_COLLISION_H__
//-----------------------------------------------------------------------------
// File: AS_Math.cpp
//-----------------------------------------------------------------------------

#include "AS_Engine.h"


// Functions: *****************************************************************
void ASAddVec(FLOAT3, FLOAT3, FLOAT3 *);
void ASSubVec(FLOAT3, FLOAT3, FLOAT3 *);
void ASMulVec(FLOAT3, FLOAT3, FLOAT3 *);
void ASScaleVec(FLOAT3, float, FLOAT3 *);
void ASInvertVec(FLOAT3, FLOAT3 *);
void ASRotateVectorX(FLOAT3, float, FLOAT3 *);
void ASRotateVectorY(FLOAT3, float, FLOAT3 *);
void ASRotateVectorZ(FLOAT3, float, FLOAT3 *);
///////////////////////////////////////////////////////////////////////////////

void ASAddVec(FLOAT3 v1, FLOAT3 v2, FLOAT3 *res)
{ // begin ASAddVec()
	(*res)[0] = v1[0]+v2[0];
	(*res)[1] = v1[1]+v2[1];
	(*res)[2] = v1[2]+v2[2];
} // end ASAddVec()

void ASSubVec(FLOAT3 v1, FLOAT3 v2, FLOAT3 *res)
{ // begin ASSubVec()
	(*res)[0] = v1[0]-v2[0];
	(*res)[1] = v1[1]-v2[1];
	(*res)[2] = v1[2]-v2[2];
} // end ASSubVec()

void ASMulVec(FLOAT3 v, FLOAT3 v2, FLOAT3 *res)
{ // begin ASMulVec()
	(*res)[0] = v[0]*v2[0];
	(*res)[1] = v[1]*v2[1];
	(*res)[2] = v[2]*v2[2];
} // end ASMulVec()

void ASScaleVec(FLOAT3 v, float fScale, FLOAT3 *res)
{ // begin ASScaleVec()
	(*res)[0] = v[0]*fScale;
	(*res)[1] = v[1]*fScale;
	(*res)[2] = v[2]*fScale;
} // end ASScaleVec()

void ASInvertVec(FLOAT3 v, FLOAT3 *res)
{ // begin ASInvertVec()
	(*res)[0] = -v[0];
	(*res)[1] = -v[1];
	(*res)[2] = -v[2];
} // end ASInvertVec()

void ASRotateVectorX(FLOAT3 fVec, float amnt, FLOAT3 *fDestVec)
{ // begin ASRotateVectorX()
   amnt *= (float) PI/180;
   float s = (float) sin(amnt);
   float c = (float) cos(amnt);
   float y = fVec[1];
   float z = fVec[2];

   (*fDestVec)[0] = fVec[0];
   (*fDestVec)[1] = (y * c) - (z * s);
   (*fDestVec)[2] = (y * s) + (z * c);
} // ned ASRotateVectorX()

void ASRotateVectorY(FLOAT3 fVec, float amnt, FLOAT3 *fDestVec)
{ // begin ASRotateVectorY()
   amnt *= (float) PI/180;
   float s = (float) sin(amnt);
   float c = (float) cos(amnt);
   float x = fVec[0];
   float z = fVec[2];

   (*fDestVec)[0] = (x * c) + (z * s);
   (*fDestVec)[1] = fVec[1];
   (*fDestVec)[2] = (z * c) - (x * s);
} // end ASRotateVectorY()

void ASRotateVectorZ(FLOAT3 fVec, float amnt, FLOAT3 *fDestVec)
{ // begin ASRotateVectorZ()
   amnt *= (float) PI/180;
   float s = (float) sin(amnt);
   float c = (float) cos(amnt);
   float x = fVec[0];
   float y = fVec[1];

   (*fDestVec)[0] = (x * c) - (y * s);
   (*fDestVec)[1] = (y * c) + (x * s);
   (*fDestVec)[2] = fVec[2];
} // end  // begin ASRotateVectorZ()
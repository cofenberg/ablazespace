//-----------------------------------------------------------------------------
// File: AS_Config.cpp
//-----------------------------------------------------------------------------

#include "AS_ENGINE.h"


// Definations: ***************************************************************
enum {TAB_CONFIG_GENERAL, TAB_CONFIG_GRAPHIC, TAB_CONFIG_SOUND, TAB_CONFIG_CONTROL,
	  TAB_CONFIG_CHEATS};
#define CONFIG_TABS 5
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
AS_CONFIG *_ASConfig;
AS_CONFIG ConfigT;
DISPLAY_MODE_INFO DisplayModeInfo;
HWND hWndConfig, hWndCheats;
HWND hWndConfigTab[CONFIG_TABS];
short iCurrentConfigTab;
long g_lTestTime;
BOOL bFirstRunConfigDialog;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
// HRESULT CONFIG::Check(void);
// HRESULT CONFIG::Load(char *);
// HRESULT CONFIG::Save(char *)
void OpenConfigDialog(HWND);
LRESULT CALLBACK ConfigProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK ConfigGeneralProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK ConfigGraphicProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK ConfigSoundProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK ConfigCheatsProc(HWND, UINT, WPARAM, LPARAM);
void UpdateCheats(void);
void SetupConfigTabs(void);
void SetConfigLanguage(void);
///////////////////////////////////////////////////////////////////////////////


// AS_CONFIG functions: *******************************************************
AS_CONFIG::AS_CONFIG(void)
{ // begin AS_CONFIG::AS_CONFIG()
	memset(this, 0, sizeof(AS_CONFIG));
} // end AS_CONFIG::AS_CONFIG()

AS_CONFIG::~AS_CONFIG(void)
{ // begin AS_CONFIG::~AS_CONFIG()
} // end AS_CONFIG::~AS_CONFIG()

void AS_CONFIG::Check(void)
{ // begin AS_CONFIG::Check()
	// Update the general information:
	if(!DevMode.dmSize)
		DevMode.dmSize = sizeof(DEVMODE);
	iScreenPixels = (short) (DevMode.dmPelsWidth*DevMode.dmPelsHeight);
	iScreenSize = (short) (DevMode.dmPelsWidth*DevMode.dmPelsHeight*(DevMode.dmBitsPerPel/8));
	DevMode.dmFields = DM_BITSPERPEL | DM_PELSWIDTH | DM_PELSHEIGHT;
	// Find the current display mode id:
	for(short i = 0; i < DisplayModeInfo.Number; i++)
	{
		if(DevMode.dmPelsWidth == DisplayModeInfo.pDevMode[i].dmPelsWidth && 
		   DevMode.dmPelsHeight == DisplayModeInfo.pDevMode[i].dmPelsHeight && 	
		   DevMode.dmBitsPerPel == DisplayModeInfo.pDevMode[i].dmBitsPerPel && 
		   DevMode.dmDisplayFrequency == DisplayModeInfo.pDevMode[i].dmDisplayFrequency)
		{
			iModeIndex = i;
			CopyMemory(&DevMode, &DisplayModeInfo.pDevMode[iModeIndex], sizeof(DEVMODE));
			break;
		}
	}
	if(iWindowWidth < 100)
		iWindowWidth = 100;
	if(iWindowHeight < 100)
		iWindowHeight = 100;
	if(_ASConfig->fParticleDensity > 1.0f)
		_ASConfig->fParticleDensity = 1.0f;
	
	// Check keys:
	iLeftKey[1] = GetDXInputKey(iLeftKey[0]);
	iRightKey[1] = GetDXInputKey(iRightKey[0]);
	iUpKey[1] = GetDXInputKey(iUpKey[0]);
	iDownKey[1] = GetDXInputKey(iDownKey[0]);
	iShotKey[1] = GetDXInputKey(iShotKey[0]);
	iThrowKey[1] = GetDXInputKey(iThrowKey[0]);
	iPullKey[1] = GetDXInputKey(iPullKey[0]);
	iSuicideKey[1] = GetDXInputKey(iSuicideKey[0]);
	iJumpKey[1] = GetDXInputKey(iJumpKey[0]);
	iChangePerspectiveKey[1] = GetDXInputKey(iChangePerspectiveKey[0]);
	iBackCameraKey[1] = GetDXInputKey(iBackCameraKey[0]);
	iTiltCameraKey[1] = GetDXInputKey(iTiltCameraKey[0]);
	iStandartViewKey[1] = GetDXInputKey(iStandartViewKey[0]);
	iPauseKey[1] = GetDXInputKey(iPauseKey[0]);
	iLoadAutosaveKey[1] = GetDXInputKey(iLoadAutosaveKey[0]);
	iLevelRestartKey[1] = GetDXInputKey(iLevelRestartKey[0]);
} // end AS_CONFIG::Check()

HRESULT AS_CONFIG::Load(char *pbyFilename)
{ // begin CONFIG::Load()
	char byTemp[256];

	if(!pbyFilename)
		return 1;
	// Load the configurations from the given file:

	// General:
	bFirstRun = GetPrivateProfileInt("General", "firstrun", 1, pbyFilename);
	bError = GetPrivateProfileInt("General", "error", 1, pbyFilename);
	bSound = GetPrivateProfileInt("General", "sound", 1, pbyFilename);
	bMusic = GetPrivateProfileInt("General", "music", 1, pbyFilename);
	bDrawBounding = GetPrivateProfileInt("General", "draw_bounding", 0, pbyFilename);
	bFrustumCulling = GetPrivateProfileInt("General", "frustum_culling", 1, pbyFilename);	
	bShowCulledObjects = GetPrivateProfileInt("General", "show_culled_objects", 0, pbyFilename);	
	bShowFPS = GetPrivateProfileInt("General", "show_fps", 0, pbyFilename);
	bLog = GetPrivateProfileInt("General", "log", 1, pbyFilename);
	bMouseScroll = GetPrivateProfileInt("General", "mouse_scroll", 0, pbyFilename);
	iWindowWidth = GetPrivateProfileInt("General", "window_width", DevMode.dmPelsWidth, pbyFilename);
	iWindowHeight = GetPrivateProfileInt("General", "window_height", DevMode.dmPelsHeight, pbyFilename);
	_ASConfig->EditorWindow.left = GetPrivateProfileInt("General", "editor_window_x", 0, pbyFilename);
	_ASConfig->EditorWindow.right = GetPrivateProfileInt("General", "editor_window_width", GetSystemMetrics(SM_CXSCREEN), pbyFilename)+
									_ASConfig->EditorWindow.left;
	_ASConfig->EditorWindow.top = GetPrivateProfileInt("General", "editor_window_x", 0, pbyFilename);
	_ASConfig->EditorWindow.bottom = GetPrivateProfileInt("General", "editor_window_height", GetSystemMetrics(SM_CYSCREEN), pbyFilename)+
									 _ASConfig->EditorWindow.top;
	GetPrivateProfileString("General", "language", "Gb", byLanguage, MAX_PATH, pbyFilename);
	bRotateMove = GetPrivateProfileInt("General", "rotate_move", 0, pbyFilename);
	bBackCamera = GetPrivateProfileInt("General", "back_camera", 0, pbyFilename);
	bTiltCamera = GetPrivateProfileInt("General", "tilt_camera", 0, pbyFilename);
	GetPrivateProfileString("General", "mouse_sensibility", "1.0f", byTemp, MAX_PATH, pbyFilename);
	fMouseSensibility = (float) atof(byTemp);
	iMusicVolume = GetPrivateProfileInt("General", "music_volume", AS_DX_SHOW_VOLUME_FULL, pbyFilename);

	// Graphic:
	bFullScreen = GetPrivateProfileInt("Graphic", "fullscreen", 1, pbyFilename);
	bUseLevelVertexColor = GetPrivateProfileInt("Graphic", "use_level_vertex_color", 1, pbyFilename);
	byZBuffer = GetPrivateProfileInt("Graphic", "z_buffer", 2, pbyFilename);
	byLight = GetPrivateProfileInt("Graphic", "light_mode", 2, pbyFilename);
	bFastTexturing = GetPrivateProfileInt("Graphic", "fast_texturing", 0, pbyFilename);
	bUseMipmaps = GetPrivateProfileInt("Graphic", "use_mipmaps", 0, pbyFilename);
	bMultitexturing = GetPrivateProfileInt("Graphic", "multitexturing", 1, pbyFilename);
	bHightRenderQuality = GetPrivateProfileInt("Graphic", "hight_render_quality", 1, pbyFilename);
	DevMode.dmPelsWidth = GetPrivateProfileInt("Graphic", "width", 640, pbyFilename);
	DevMode.dmPelsHeight = GetPrivateProfileInt("Graphic", "height", 480, pbyFilename);
	DevMode.dmBitsPerPel = GetPrivateProfileInt("Graphic", "colordepth", 16, pbyFilename);
	DevMode.dmDisplayFrequency = GetPrivateProfileInt("Graphic", "refresh_rate", 0, pbyFilename);
	bParticles = GetPrivateProfileInt("Graphic", "particles", DevMode.dmPelsHeight, pbyFilename);
	GetPrivateProfileString("Graphic", "particle_density", "1.0f", byTemp, MAX_PATH, pbyFilename);
	fParticleDensity = (float) atof(byTemp);

	// Keys:
	iLeftKey[0] = GetPrivateProfileInt("Keys", "left", STANDART_LEFT_KEY, pbyFilename);
	iRightKey[0] = GetPrivateProfileInt("Keys", "right", STANDART_RIGHT_KEY, pbyFilename);
	iUpKey[0] = GetPrivateProfileInt("Keys", "top", STANDART_UP_KEY, pbyFilename);
	iDownKey[0] = GetPrivateProfileInt("Keys", "down", STANDART_DOWN_KEY, pbyFilename);
	iShotKey[0] = GetPrivateProfileInt("Keys", "shot", STANDART_SHOT_KEY, pbyFilename);
	iThrowKey[0] = GetPrivateProfileInt("Keys", "throw", STANDART_THROW_KEY, pbyFilename);
	iPullKey[0] = GetPrivateProfileInt("Keys", "pull", STANDART_PULL_KEY, pbyFilename);
	iSuicideKey[0] = GetPrivateProfileInt("Keys", "suicide", STANDART_SUICIDE_KEY, pbyFilename);
	iJumpKey[0] = GetPrivateProfileInt("Keys", "jump", STANDART_JUMP_KEY, pbyFilename);
	iChangePerspectiveKey[0] = GetPrivateProfileInt("Keys", "change_perspective", STANDART_CHANGE_PERSPECTIVE_KEY, pbyFilename);
	iBackCameraKey[0] = GetPrivateProfileInt("Keys", "back_camera", STANDART_BACK_CAMERA_KEY, pbyFilename);
	iTiltCameraKey[0] = GetPrivateProfileInt("Keys", "tilt_camera", STANDART_TILT_CAMERA_KEY, pbyFilename);
	iStandartViewKey[0] = GetPrivateProfileInt("Keys", "standart_view", STANDART_STANDART_VIEW_KEY, pbyFilename);
	iPauseKey[0] = GetPrivateProfileInt("Keys", "pause", STANDART_PAUSE_KEY, pbyFilename);
	iLoadAutosaveKey[0] = GetPrivateProfileInt("Keys", "load_autosave", STANDART_LOAD_AUTOSAVE_KEY, pbyFilename);
	iLevelRestartKey[0] = GetPrivateProfileInt("Keys", "level_restart", STANDART_LEVEL_RESTART_KEY, pbyFilename);

	Check(); // Update the configurations
	if(!_AS->bStartErrorMessage)
		_ASConfig->bError = FALSE;
	return 0;
} // end AS_CONFIG::Load()

HRESULT AS_CONFIG::Save(char *pbyFilename)
{ // begin AS_CONFIG::Save()
	FILE *pFile;

	if(!pbyFilename)
		return 1;
	// Save the current configurations:
	pFile = fopen(pbyFilename, "wt");
	if(!pFile)
		return 1;
	if(iWindowWidth < 100)
		iWindowWidth = 100;
	if(iWindowHeight < 100)
		iWindowHeight = 100;
	
	// General:
	fprintf(pFile, "[General]\n");
    fprintf(pFile, "firstrun=%d\n", bFirstRun);
    fprintf(pFile, "error=%d\n", bError);
    fprintf(pFile, "mouse_scroll=%d\n", bMouseScroll);
    fprintf(pFile, "sound=%d\n", bSound);
    fprintf(pFile, "music=%d\n", bMusic);
    fprintf(pFile, "show_fps=%d\n", bShowFPS);
    fprintf(pFile, "frustum_culling=%d\n", bFrustumCulling);
    fprintf(pFile, "draw_bounding=%d\n", bDrawBounding);
    fprintf(pFile, "show_culled_objects=%d\n", bShowCulledObjects);
    fprintf(pFile, "log=%d\n", bLog);
	fprintf(pFile, "window_width=%d\n", iWindowWidth);
	fprintf(pFile, "window_height=%d\n", iWindowHeight);
	fprintf(pFile, "editor_window_x=%d\n", _ASConfig->EditorWindow.left);
	fprintf(pFile, "editor_window_y=%d\n", _ASConfig->EditorWindow.top);
	fprintf(pFile, "editor_window_width=%d\n", _ASConfig->EditorWindow.right-_ASConfig->EditorWindow.left);
	fprintf(pFile, "editor_window_height=%d\n", _ASConfig->EditorWindow.bottom-_ASConfig->EditorWindow.top);
	fprintf(pFile, "language=%s\n", byLanguage);
	fprintf(pFile, "rotate_move=%d\n", bRotateMove);
	fprintf(pFile, "back_camera=%d\n", bBackCamera);
	fprintf(pFile, "tilt_camera=%d\n", bTiltCamera);
	fprintf(pFile, "mouse_sensibility=%f\n", fMouseSensibility);
	fprintf(pFile, "music_volume=%d\n", iMusicVolume);

	// Graphic:
	fprintf(pFile, "\n[Graphic]\n");
    fprintf(pFile, "fullscreen=%d\n", bFullScreen);
    fprintf(pFile, "use_level_vertex_color=%d\n", bUseLevelVertexColor);
    fprintf(pFile, "z_buffer=%d\n", byZBuffer);
    fprintf(pFile, "light_mode=%d\n", byLight);
    fprintf(pFile, "fast_texturing=%d\n", bFastTexturing);
    fprintf(pFile, "use_mipmaps=%d\n", bUseMipmaps);
    fprintf(pFile, "multitexturing=%d\n", bMultitexturing);
	fprintf(pFile, "hight_render_quality=%d\n", bHightRenderQuality);	
	fprintf(pFile, "width=%d\n", DevMode.dmPelsWidth);
	fprintf(pFile, "height=%d\n", DevMode.dmPelsHeight);
	fprintf(pFile, "colordepth=%d\n", DevMode.dmBitsPerPel);
	fprintf(pFile, "refresh_rate=%d HZ\n", DevMode.dmDisplayFrequency);
	fprintf(pFile, "particles=%d\n", bParticles);
	fprintf(pFile, "particle_density=%f\n", fParticleDensity);
	
	// Keys:
	fprintf(pFile, "\n[Keys]\n");
	fprintf(pFile, "left=%d\n", iLeftKey[0]);
	fprintf(pFile, "right=%d\n", iRightKey[0]);
	fprintf(pFile, "up=%d\n", iUpKey[0]);
	fprintf(pFile, "down=%d\n", iDownKey[0]);
	fprintf(pFile, "shot=%d\n", iShotKey[0]);
	fprintf(pFile, "throw=%d\n", iThrowKey[0]);
	fprintf(pFile, "pull=%d\n", iPullKey[0]);
	fprintf(pFile, "suicide=%d\n", iSuicideKey[0]);
	fprintf(pFile, "jump=%d\n", iJumpKey[0]);
	fprintf(pFile, "change_perspective=%d\n", iChangePerspectiveKey[0]);
	fprintf(pFile, "back_camera=%d\n", iBackCameraKey[0]);
	fprintf(pFile, "tilt_camera=%d\n", iTiltCameraKey[0]);
	fprintf(pFile, "standart_view=%d\n", iStandartViewKey[0]);
	fprintf(pFile, "pause=%d\n", iPauseKey[0]);
	fprintf(pFile, "load_autosave=%d\n", iLoadAutosaveKey[0]);
	fprintf(pFile, "level_restart=%d\n", iLevelRestartKey[0]);

	fclose(pFile);
	return 0;
} // end AS_CONFIG::Save()


// Functions: *****************************************************************
void OpenConfigDialog(HWND hWnd)
{ // begin OpenConfigDialog()
	DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CONFIG), hWnd, (DLGPROC) ConfigProc);
} // begin OpenConfigDialog()

LRESULT CALLBACK ConfigProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin ConfigProc()
	char byTemp[256];
	short i, i2;

	switch(iMessage)
    {
        case WM_INITDIALOG:
			g_lNow = GetTickCount();
			if(!PlayerInfo.bGhost)
				PlayerInfo.lGhostTime = g_lNow;
			if(!PlayerInfo.bSpeed)
				PlayerInfo.lSpeedTime = g_lNow;
			if(!PlayerInfo.bWing)
				PlayerInfo.lWingTime = g_lNow;
			if(!PlayerInfo.bShield)
				PlayerInfo.lShieldTime = g_lNow;
			lGhostTimeSave = g_lNow-PlayerInfo.lGhostTime;
			lSpeedTimeSave = g_lNow-PlayerInfo.lSpeedTime;
			lWingTimeSave = g_lNow-PlayerInfo.lWingTime;
			lShieldTimeSave =  g_lNow-PlayerInfo.lShieldTime;
			_AS->WriteLogMessage("Open config dialog");
			memcpy(&ConfigT, _ASConfig, sizeof(AS_CONFIG));
			if(!hWndConfig)
				iCurrentConfigTab = -1;
			hWndConfig = hWnd;
			SetConfigLanguage();
			g_lTestTime = GetTickCount();
			if(bOnlyConfig)
				ShowWindow(GetDlgItem(hWnd, ID_CONFIG_QUIT), FALSE);			
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_CONFIG_OK:
					if(GetTickCount()-g_lTestTime < 500)
						break; // The user probably hadn't the change to do this selection!
					if(IsDlgButtonChecked(hWndConfigTab[TAB_CONFIG_GRAPHIC], IDC_CONFIG_GRAPHIC_LIGHT_NONE))
						_ASConfig->byLight = 0;
					else
					if(IsDlgButtonChecked(hWndConfigTab[TAB_CONFIG_GRAPHIC], IDC_CONFIG_GRAPHIC_LIGHT_FLAT))
						_ASConfig->byLight = 1;
					else
					if(IsDlgButtonChecked(hWndConfigTab[TAB_CONFIG_GRAPHIC], IDC_CONFIG_GRAPHIC_LIGHT_SMOOTH))
						_ASConfig->byLight = 2;
					EndDialog(hWnd, FALSE);
					hWndConfig = NULL;
					for(i2 = 0; i2 < CONFIG_TABS; i2++)
						hWndConfigTab[i2] = NULL;
					if(pLevel)
					{
						pLevel->DestroyTexturesOpenGL(hDCEditorShow, hRCEditorShow);
						pLevel->GenTexturesOpenGL(hDCEditorShow, hRCEditorShow);
					}
					// Save the configuration:	
					sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyConfigFile);
					_ASConfig->Save(byTemp);
					ParticleManager.UpdateSystems();
					_AS->WriteLogMessage("Close config dialog (ok)");
					LoadTextScriptSource(pLevel->TextScriptsManager.byFilename);
					g_lNow = GetTickCount();
					PlayerInfo.lGhostTime = g_lNow-lGhostTimeSave;
					PlayerInfo.lSpeedTime = g_lNow-lSpeedTimeSave;
					PlayerInfo.lWingTime = g_lNow-lWingTimeSave;
					PlayerInfo.lShieldTime = g_lNow-lShieldTimeSave;
                return TRUE;

				case ID_CONFIG_CANCEL:
					memcpy(_ASConfig, &ConfigT, sizeof(AS_CONFIG));
					EndDialog(hWnd, FALSE);
					hWndConfig = NULL;
					for(i2 = 0; i2 < CONFIG_TABS; i2++)
						hWndConfigTab[i2] = NULL;;
					_AS->WriteLogMessage("Close config dialog (cancel)");
					g_lNow = GetTickCount();
					PlayerInfo.lGhostTime = g_lNow-lGhostTimeSave;
					PlayerInfo.lSpeedTime = g_lNow-lSpeedTimeSave;
					PlayerInfo.lWingTime = g_lNow-lWingTimeSave;
					PlayerInfo.lShieldTime = g_lNow-lShieldTimeSave;
				break;
				
				case ID_CONFIG_QUIT:
					_AS->WriteLogMessage("Close config dialog (quit)");
					EndDialog(hWnd, FALSE);
					hWndConfig = NULL;
					_AS->SetShutDown(TRUE);
					EndDialog(hWndEditor, FALSE);
				break;

				case IDC_CONFIG_OPENGL:
					DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_OPENGL), hWnd, (DLGPROC) OpenGLInfoProc);
				break;

				case IDC_CONFIG_CREDITS:
					OpenCreditsDialog(hWnd);
				break;

				case IDC_HOMEPAGE:
					ShellExecute(0, "open", "http://www.ablazespace.de/", 0, 0, SW_SHOW);
				break;

				case IDC_MSPANG_HOMEPAGE:
					ShellExecute(0, "open", "http://www.mspang.de/", 0, 0, SW_SHOW);
				break;

				case IDC_NEHE_HOMEPAGE:
					ShellExecute(0, "open", "http://nehe.gamedev.net/", 0, 0, SW_SHOW);
				break;

				case IDC_CONFIG_HELP:
					OpenHelp();
				break;
            }
            break;

        case WM_NOTIFY: 
			switch(wParam)
			{
				case IDC_CONFIG_TAB:
					i = TabCtrl_GetCurSel(GetDlgItem(hWnd, IDC_CONFIG_TAB));
					if(i == iCurrentConfigTab)
						break; // This tab is already opend
					iCurrentConfigTab = i;
					for(i2 = 0; i2 < CONFIG_TABS; i2++)
						ShowWindow(hWndConfigTab[i2], SW_HIDE);
					UpdateWindow(hWndConfigTab[i]);
					ShowWindow(hWndConfigTab[i], SW_SHOW);
					SetFocus(hWndConfigTab[i]);
					SendMessage(hWndConfigTab[i], WM_INITDIALOG, 0, 0);
				break;
			} 
		break; 

		case WM_CLOSE:
			SendMessage(hWnd, WM_COMMAND, ID_CONFIG_OK, 0);
		break;
    }
    return FALSE;
} // end ConfigProc()

LRESULT CALLBACK ConfigGeneralProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin ConfigGeneralProc()
	short i;
	BOOL bTemp;

	switch(iMessage)
    {
        case WM_INITDIALOG:
			// Texts:
			SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_LOG, T_Log);
  			SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_MOUSE_SCROLL, T_MouseScroll_Editor);
  			SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_SHOW_FPS, T_ShowFPS);
  			SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_LANGUAGE_TEXT, T_Language);
  			SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_FRUSTUM_CULLING, T_FrustumCulling);
  			SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_BACK_CAMERA, T_BackCamera);
  			SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_TILT_CAMERA, T_TiltCamera);

			if(!_AS->bDebugMode)
			{
  				SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_SHOW_BOUNDING_BOXES, T_ShowBoundingBoxes);
  				SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_SHOW_CULLED_OBJECTS, T_ShowCulledObjects);
				ShowWindow(GetDlgItem(hWnd, IDC_CONFIG_GENERAL_SHOW_BOUNDING_BOXES), FALSE);
				ShowWindow(GetDlgItem(hWnd, IDC_CONFIG_GENERAL_SHOW_CULLED_OBJECTS), FALSE);
			}

			//
 			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LANGUAGE, CB_RESETCONTENT, 0, 0);
			for(i = 0; i < iASLanguages; i++)
 			{
				SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LANGUAGE, CB_ADDSTRING, 0, (LONG)(LPSTR) pbyASLanguage[i]);
				if(!strcmp(pbyASLanguage[i], _ASConfig->byLanguage))
					SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LANGUAGE, CB_SETCURSEL, i, 0L);
			}
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_SHOW_FPS, BM_SETCHECK, _ASConfig->bShowFPS, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LOG, BM_SETCHECK, _ASConfig->bLog, 0L);
			if(!_AS->bLog)
				EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GENERAL_LOG), FALSE);
			else
				EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GENERAL_LOG), TRUE);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_MOUSE_SCROLL, BM_SETCHECK, _ASConfig->bMouseScroll, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_SHOW_BOUNDING_BOXES, BM_SETCHECK, _ASConfig->bDrawBounding, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_FRUSTUM_CULLING, BM_SETCHECK, _ASConfig->bFrustumCulling, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_SHOW_CULLED_OBJECTS, BM_SETCHECK, _ASConfig->bShowCulledObjects, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_BACK_CAMERA, BM_SETCHECK, _ASConfig->bBackCamera, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_TILT_CAMERA, BM_SETCHECK, _ASConfig->bTiltCamera, 0L);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_CONFIG_GENERAL_SHOW_FPS:
					_ASConfig->bShowFPS = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_SHOW_FPS, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_GENERAL_LOG:
					_ASConfig->bLog = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LOG, BM_GETCHECK, 0, 0L);
					bTemp = _ASConfig->bLog;
					_ASConfig->bLog = TRUE;
					if(!bTemp)
						_AS->WriteLogMessage("Deactivate the log");
					else
						_AS->WriteLogMessage("Activate the log");
					_ASConfig->bLog = bTemp;
				break;

				case IDC_CONFIG_GENERAL_MOUSE_SCROLL:
					_ASConfig->bMouseScroll = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_MOUSE_SCROLL, BM_GETCHECK, 0, 0L);
				break;
	
				case IDC_CONFIG_GENERAL_LANGUAGE:
					i = (short) SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LANGUAGE, CB_GETCURSEL, 0, 0L);
					if(i == -1)
						break;
					if(!strcmp(_ASConfig->byLanguage, pbyASLanguage[i]))
						break; // This language is already selected
					strcpy(_ASConfig->byLanguage, pbyASLanguage[i]);
					iCurrentConfigTab = -1;
					SetLanguage(_ASConfig->byLanguage);
				break;

				case IDC_CONFIG_GENERAL_SHOW_BOUNDING_BOXES:
					_ASConfig->bDrawBounding = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_SHOW_BOUNDING_BOXES, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_GENERAL_FRUSTUM_CULLING:
					_ASConfig->bFrustumCulling = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_FRUSTUM_CULLING, BM_GETCHECK, 0, 0L);
				break;
				
				case IDC_CONFIG_GENERAL_SHOW_CULLED_OBJECTS:
					_ASConfig->bShowCulledObjects = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_SHOW_CULLED_OBJECTS, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_GENERAL_BACK_CAMERA:
					_ASConfig->bBackCamera = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_BACK_CAMERA, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_GENERAL_TILT_CAMERA:
					_ASConfig->bTiltCamera = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_TILT_CAMERA, BM_GETCHECK, 0, 0L);
				break;
            }
            break;
    }
    return FALSE;
} // end ConfigGeneralProc()

LRESULT CALLBACK ConfigGraphicProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin ConfigGraphicProc()
	short i, i2;
    LPSTR byTemp = new char[MAX_PATH];

	switch(iMessage)
    {
        case WM_INITDIALOG:
			// Texts:
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_LIGHTING, T_Lighting);
  			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_LIGHT_NONE, T_None);
  			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_LIGHT_FLAT, T_Flat);
  			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_LIGHT_SMOOTH, T_Smooth);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_FAST_TEXTURING, T_FastTexturing);
  			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_USE_MIPMAPS, T_UseMipmaps);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_USE_LEVEL_VERTEX_COLOR, T_UseLevelVertexColor);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_MULTITEXTURING, T_Multitexturing);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_HIGHT_RENDER_QUALITY, T_HightRenderQuality);
  			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_DISPLAY_MODE, T_DisplayMode);
  			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_FULLSCREEN, T_Fullscreen);

			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_PARTICLES, T_Particles);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY_T, T_ParticleDensity);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY_LOW, T_Low);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY_MIDDLE, T_Middle);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY_ALL, T_All);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER_T, T_ZBuffer);
			//
 			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER, CB_RESETCONTENT, 0, 0);
    		SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER, CB_ADDSTRING, 0, (LONG)(LPSTR) "8");
    		SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER, CB_ADDSTRING, 0, (LONG)(LPSTR) "16");
    		SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER, CB_ADDSTRING, 0, (LONG)(LPSTR) "24");
    		SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER, CB_ADDSTRING, 0, (LONG)(LPSTR) "32");
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER, CB_SETCURSEL, _ASConfig->byZBuffer/8-1, 0L);

			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_FULLSCREEN, BM_SETCHECK, _ASConfig->bFullScreen, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_USE_LEVEL_VERTEX_COLOR, BM_SETCHECK, _ASConfig->bUseLevelVertexColor, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_FAST_TEXTURING, BM_SETCHECK, _ASConfig->bFastTexturing, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_USE_MIPMAPS, BM_SETCHECK, _ASConfig->bUseMipmaps, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_HIGHT_RENDER_QUALITY, BM_SETCHECK, _ASConfig->bHightRenderQuality, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MULTITEXTURING, BM_SETCHECK, _ASConfig->bMultitexturing, 0L);
			
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_PARTICLES, BM_SETCHECK, _ASConfig->bParticles, 0L);
			if(!_ASConfig->bHightRenderQuality)
			{
				EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_USE_LEVEL_VERTEX_COLOR), FALSE);
				EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_MULTITEXTURING), FALSE);
			}
			else
			{
				EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_USE_LEVEL_VERTEX_COLOR), TRUE);
				EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_MULTITEXTURING), TRUE);
			}
			switch(_ASConfig->byLight)
			{
				case 0: CheckRadioButton(hWnd, IDC_CONFIG_GRAPHIC_LIGHT_NONE, IDC_CONFIG_GRAPHIC_LIGHT_SMOOTH, IDC_CONFIG_GRAPHIC_LIGHT_NONE); break;
				case 1: CheckRadioButton(hWnd, IDC_CONFIG_GRAPHIC_LIGHT_NONE, IDC_CONFIG_GRAPHIC_LIGHT_SMOOTH, IDC_CONFIG_GRAPHIC_LIGHT_FLAT); break;
				case 2: CheckRadioButton(hWnd, IDC_CONFIG_GRAPHIC_LIGHT_NONE, IDC_CONFIG_GRAPHIC_LIGHT_SMOOTH, IDC_CONFIG_GRAPHIC_LIGHT_SMOOTH); break;
			}	
 			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MODES, CB_RESETCONTENT, 0, 0);
			wsprintf(byTemp, "All");
			// Put in the new entries:
			for(i = 0, i2 = 0; i < DisplayModeInfo.Number-1; i++)
			{
				if(DisplayModeInfo.pDevMode[i].dmBitsPerPel < (unsigned char) 16)
					continue;
				wsprintf(byTemp, "%dx%dx%d  %d HZ", 
						DisplayModeInfo.pDevMode[i].dmPelsWidth, 
						DisplayModeInfo.pDevMode[i].dmPelsHeight, 
						DisplayModeInfo.pDevMode[i].dmBitsPerPel, 
						DisplayModeInfo.pDevMode[i].dmDisplayFrequency);
     			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MODES, CB_ADDSTRING, 0, (LONG)(LPSTR) byTemp);
     			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MODES, CB_SETITEMDATA, i2, i);
				i2++;
			}
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MODES, CB_SETCURSEL, _ASConfig->iModeIndex, 0L);
		    SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY, TBM_SETRANGE, FALSE, MAKELONG(1, 100));
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY, TBM_SETTIC, TRUE, 50);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY, TBM_SETPOS, TRUE, (long) ((float) _ASConfig->fParticleDensity*100.0f));
			EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY), _ASConfig->bParticles);
		return TRUE;

		case WM_NOTIFY:
            switch(wParam)
            {
				case IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY:
					i = (short) SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY, TBM_GETPOS, 0, 0);
					_ASConfig->fParticleDensity = (float) i/100;
					if(_ASConfig->fParticleDensity > 1.0f)
						_ASConfig->fParticleDensity = 1.0f;
				break;
			}
		break;

		case WM_COMMAND:
            switch(LOWORD(wParam))
            {

				case IDC_CONFIG_GRAPHIC_FULLSCREEN:
				    _ASConfig->bFullScreen = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_FULLSCREEN, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_GRAPHIC_MODES:
   					i = (short) SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MODES, CB_GETCURSEL, 0, 0L);
					i = (short) SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MODES, CB_GETITEMDATA, i, 0);
					_ASConfig->iModeIndex = i;                         	
					CopyMemory(&_ASConfig->DevMode, &DisplayModeInfo.pDevMode[_ASConfig->iModeIndex], sizeof(DEVMODE));
				break;

				case IDC_CONFIG_GRAPHIC_USE_LEVEL_VERTEX_COLOR:
					_ASConfig->bUseLevelVertexColor = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_USE_LEVEL_VERTEX_COLOR, BM_GETCHECK, 0, 0L);
					UpdateRenderQuality();
				break;

				case IDC_CONFIG_GRAPHIC_FAST_TEXTURING:
					_ASConfig->bFastTexturing = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_FAST_TEXTURING, BM_GETCHECK, 0, 0L);
					UpdateAllTextures();
				break;

				case IDC_CONFIG_GRAPHIC_USE_MIPMAPS:
					_ASConfig->bUseMipmaps = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_USE_MIPMAPS, BM_GETCHECK, 0, 0L);
					UpdateAllTextures();
				break;

				case IDC_CONFIG_GRAPHIC_HIGHT_RENDER_QUALITY:
					_ASConfig->bHightRenderQuality = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_HIGHT_RENDER_QUALITY, BM_GETCHECK, 0, 0L);
					if(!_ASConfig->bHightRenderQuality)
					{
						EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_USE_LEVEL_VERTEX_COLOR), FALSE);
						EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_MULTITEXTURING), FALSE);
						SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MULTITEXTURING, BM_SETCHECK, FALSE, 0L);
					}
					else
					{
						EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_USE_LEVEL_VERTEX_COLOR), TRUE);
						EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_MULTITEXTURING), TRUE);
					}
					if(!_ASConfig->bHightRenderQuality)
						_ASConfig->bMultitexturing = FALSE;
					UpdateRenderQuality();
				break;				
				
				case IDC_CONFIG_GRAPHIC_MULTITEXTURING:
					_ASConfig->bMultitexturing = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MULTITEXTURING, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_GRAPHIC_PARTICLES:
					_ASConfig->bParticles = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_PARTICLES, BM_GETCHECK, 0, 0L);
					EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_PARTICLE_DENSITY), _ASConfig->bParticles);
				break;
				
   				case IDC_CONFIG_GRAPHIC_Z_BUFFER:
					i = (short) SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_Z_BUFFER, CB_GETCURSEL, 0, 0L);
					if(i < 0)
						break;
					_ASConfig->byZBuffer = (i+1)*8;
				break;
            }
            break;
    }
    return FALSE;
} // end ConfigGraphicProc()

LRESULT CALLBACK ConfigSoundProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin ConfigSoundProc()
	short i;

	switch(iMessage)
    {
        case WM_INITDIALOG:
  			// Texts:
  			SetDlgItemText(hWnd, IDC_CONFIG_SOUND_MUSIC, T_Music);
  			SetDlgItemText(hWnd, IDC_CONFIG_SOUND_SOUND, T_Sound);
  			SetDlgItemText(hWnd, IDC_CONFIG_SOUND_MUSIC_VOLUME_T, T_MusicVolume);
			//
			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MUSIC, BM_SETCHECK, _ASConfig->bMusic, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_SOUND, BM_SETCHECK, _ASConfig->bSound, 0L);

		    SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MUSIC_VOLUME, TBM_SETRANGE, FALSE, MAKELONG(1, -(AS_DX_SHOW_VOLUME_SILENCE)));
			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MUSIC_VOLUME, TBM_SETTIC, TRUE, (-AS_DX_SHOW_VOLUME_SILENCE)/2);
			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MUSIC_VOLUME, TBM_SETPOS, TRUE, (long) -_ASConfig->iMusicVolume);
		
		Init:
			EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_SOUND_MUSIC_VOLUME), _ASConfig->bMusic);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_CONFIG_SOUND_MUSIC:
					_ASConfig->bMusic = SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MUSIC, BM_GETCHECK, 0, 0L);
					ASDXShowPause();
					goto Init;
				break;

				case IDC_CONFIG_SOUND_SOUND:
					_ASConfig->bSound = SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_SOUND, BM_GETCHECK, 0, 0L);
				break;
            }
        break;

        case WM_NOTIFY:
            switch(wParam)
            {
				case IDC_CONFIG_SOUND_MUSIC_VOLUME:
					i = (short) SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MUSIC_VOLUME, TBM_GETPOS, 0, 0);
					_ASConfig->iMusicVolume = -i;
				    if(pBA)
						pBA->put_Volume(_ASConfig->iMusicVolume);
				break;
			}
		break;
    }
    return FALSE;
} // end ConfigSoundProc()

LRESULT CALLBACK ConfigControlProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin ConfigControlProc()
	short i;
	
	switch(iMessage)
    {
        case WM_INITDIALOG:
  			// Texts:
  			SetDlgItemText(hWnd, IDC_CONFIG_CONTROL_ROTATE_MOVE, T_RotateMove);
  			SetDlgItemText(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY_T, T_MouseSensibility);
			SetDlgItemText(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY_SLOW, T_Slow);
  			SetDlgItemText(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY_NORMAL, T_Normal);
  			SetDlgItemText(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY_FAST, T_Fast);
			//
			SendDlgItemMessage(hWnd, IDC_CONFIG_CONTROL_ROTATE_MOVE, BM_SETCHECK, _ASConfig->bRotateMove, 0L);

		    SendDlgItemMessage(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY, TBM_SETRANGE, FALSE, MAKELONG(1, 100));
			SendDlgItemMessage(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY, TBM_SETTIC, TRUE, 50);
			SendDlgItemMessage(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY, TBM_SETPOS, TRUE, (long) ((float) _ASConfig->fMouseSensibility*50.0f));
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_CONFIG_CONTROL_ROTATE_MOVE:
					_ASConfig->bRotateMove = SendDlgItemMessage(hWnd, IDC_CONFIG_CONTROL_ROTATE_MOVE, BM_GETCHECK, 0, 0L);
				break;
            }
        break;

        case WM_NOTIFY:
            switch(wParam)
            {
				case IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY:
					i = (short) SendDlgItemMessage(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY, TBM_GETPOS, 0, 0);
					_ASConfig->fMouseSensibility = (float) i/50;
				break;
			}
		break;
    }
    return FALSE;
} // end ConfigControlProc()

LRESULT CALLBACK ConfigCheatsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin ConfigCheatsProc()
	char byTemp[256];
	float f;
	int i;
	
	switch(iMessage)
    {
        case WM_INITDIALOG:
			hWndCheats = hWnd;
			// Texts:
  			SetDlgItemText(hWnd, IDC_CONFIG_CHEATS_INVULNERABLE, T_Invulnerable);
  			SetDlgItemText(hWnd, IDC_CONFIG_CHEATS_ALL_LEVELS, T_AllLevels);
			SetDlgItemText(hWnd, IDC_CONFIG_CHEATS_FREE_CAMERA, T_FreeCamera);
			SetDlgItemText(hWnd, IDC_CONFIG_CHEATS_LIVES_T, T_LiveObj);
			SetDlgItemText(hWnd, IDC_CONFIG_CHEATS_POINTS_T, T_PointObj);
			SetDlgItemText(hWnd, IDC_CONFIG_CHEATS_WEAPON_T, T_WeaponObj);
			SetDlgItemText(hWnd, IDC_CONFIG_CHEATS_PULL_BOXES_T, T_PullObj);
			SetDlgItemText(hWnd, IDC_CONFIG_CHEATS_THROW_BOXES_T, T_ThrowObj);
			SetDlgItemText(hWnd, IDC_CONFIG_CHEATS_FORCE_T, T_ForceObj);
			SetDlgItemText(hWnd, IDC_CONFIG_CHEATS_JUMP_T, T_Jump);
			SetDlgItemText(hWnd, IDC_CONFIG_CHEATS_GHOST, T_GhostObj);
			SetDlgItemText(hWnd, IDC_CONFIG_CHEATS_SPEED, T_SpeedObj);
			SetDlgItemText(hWnd, IDC_CONFIG_CHEATS_WING, T_WingsObj);
			SetDlgItemText(hWnd, IDC_CONFIG_CHEATS_SHIELD, T_ShieldObj);
			SetDlgItemText(hWnd, IDC_CONFIG_CHEATS_HEALTH_T, T_Health);
			//
			SendDlgItemMessage(hWnd, IDC_CONFIG_CHEATS_INVULNERABLE, BM_SETCHECK, bInvulnerable, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_CHEATS_ALL_LEVELS, BM_SETCHECK, bAllLevels, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_CHEATS_FREE_CAMERA, BM_SETCHECK, bFreeCamera, 0L);
			sprintf(byTemp, "%d", PlayerInfo.iLives);
			SetDlgItemText(hWnd, IDC_CONFIG_CHEATS_LIVES, byTemp);
			sprintf(byTemp, "%d", PlayerInfo.iPoints);
			SetDlgItemText(hWnd, IDC_CONFIG_CHEATS_POINTS, byTemp);
			sprintf(byTemp, "%d", PlayerInfo.iWeaponShots);
			SetDlgItemText(hWnd, IDC_CONFIG_CHEATS_WEAPON, byTemp);
			sprintf(byTemp, "%d", PlayerInfo.iPullBoxes);
			SetDlgItemText(hWnd, IDC_CONFIG_CHEATS_PULL, byTemp);
			sprintf(byTemp, "%d", PlayerInfo.iThrowBoxes);
			SetDlgItemText(hWnd, IDC_CONFIG_CHEATS_THROW, byTemp);
			sprintf(byTemp, "%d", PlayerInfo.iForce);
			SetDlgItemText(hWnd, IDC_CONFIG_CHEATS_FORCE, byTemp);
			sprintf(byTemp, "%d", PlayerInfo.iJump);
			SetDlgItemText(hWnd, IDC_CONFIG_CHEATS_JUMP, byTemp);
			sprintf(byTemp, "%d", PlayerInfo.lGhostWholeTime-lGhostTimeSave);
			SetDlgItemText(hWnd, IDC_CONFIG_CHEATS_GHOST_TIME, byTemp);
			sprintf(byTemp, "%d", PlayerInfo.lSpeedWholeTime-lSpeedTimeSave);
			SetDlgItemText(hWnd, IDC_CONFIG_CHEATS_SPEED_TIME, byTemp);
			sprintf(byTemp, "%d", PlayerInfo.lWingWholeTime-lWingTimeSave);
			SetDlgItemText(hWnd, IDC_CONFIG_CHEATS_WING_TIME, byTemp);
			sprintf(byTemp, "%d", PlayerInfo.lShieldWholeTime-lShieldTimeSave);
			SetDlgItemText(hWnd, IDC_CONFIG_CHEATS_SHIELD_TIME, byTemp);
			if(pPlayer)
			{
				sprintf(byTemp, "%f", pPlayer->fPower);
				SetDlgItemText(hWnd, IDC_CONFIG_CHEATS_HEALTH, byTemp);
			}
			UpdateCheats();
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_CONFIG_CHEATS_INVULNERABLE:
					bInvulnerable = SendDlgItemMessage(hWnd, IDC_CONFIG_CHEATS_INVULNERABLE, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_CHEATS_ALL_LEVELS:
					bAllLevels = SendDlgItemMessage(hWnd, IDC_CONFIG_CHEATS_ALL_LEVELS, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_CHEATS_FREE_CAMERA:
					bFreeCamera = SendDlgItemMessage(hWnd, IDC_CONFIG_CHEATS_FREE_CAMERA, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_CHEATS_LIVES:
					GetDlgItemText(hWnd, IDC_CONFIG_CHEATS_LIVES, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
						i = 0;
					PlayerInfo.iLives = i;
				break;

				case IDC_CONFIG_CHEATS_POINTS:
					GetDlgItemText(hWnd, IDC_CONFIG_CHEATS_POINTS, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
						i = 0;
					PlayerInfo.iPoints = i;
				break;

				case IDC_CONFIG_CHEATS_WEAPON_UNLIMITED:
					pLevel->Tools.bUnlimitedWeapon = SendDlgItemMessage(hWndCheats, IDC_CONFIG_CHEATS_WEAPON_UNLIMITED, BM_GETCHECK, 0, 0L);
					PlayerInfo.bWeapon = pLevel->Tools.bUnlimitedWeapon;
					if(pLevel->Tools.iWeapon)
						PlayerInfo.bWeapon = TRUE;
					UpdateCheats();
				break;

				case IDC_CONFIG_CHEATS_WEAPON:
					GetDlgItemText(hWnd, IDC_CONFIG_CHEATS_WEAPON, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
						i = 0;
					PlayerInfo.iWeaponShots = i;
					if(PlayerInfo.iWeaponShots)
						PlayerInfo.bWeapon = TRUE;
				break;

				case IDC_CONFIG_CHEATS_PULL_UNLIMITED:
					pLevel->Tools.bUnlimitedPull = SendDlgItemMessage(hWndCheats, IDC_CONFIG_CHEATS_PULL_UNLIMITED, BM_GETCHECK, 0, 0L);
					if(pLevel->Tools.bUnlimitedPull)
						PlayerInfo.bPullBoxes = TRUE;
					UpdateCheats();
				break;

				case IDC_CONFIG_CHEATS_PULL:
					GetDlgItemText(hWnd, IDC_CONFIG_CHEATS_PULL, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
						i = 0;
					PlayerInfo.iPullBoxes = i;
				break;

				case IDC_CONFIG_CHEATS_THROW_UNLIMITED:
					pLevel->Tools.bUnlimitedThrow = SendDlgItemMessage(hWndCheats, IDC_CONFIG_CHEATS_THROW_UNLIMITED, BM_GETCHECK, 0, 0L);
					if(pLevel->Tools.bUnlimitedThrow)
						PlayerInfo.bThrowBoxes = TRUE;
					UpdateCheats();
				break;

				case IDC_CONFIG_CHEATS_THROW:
					GetDlgItemText(hWnd, IDC_CONFIG_CHEATS_THROW, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
						i = 0;
					PlayerInfo.iThrowBoxes = i;
				break;

				case IDC_CONFIG_CHEATS_FORCE_UNLIMITED:
					pLevel->Tools.bUnlimitedForce = SendDlgItemMessage(hWndCheats, IDC_CONFIG_CHEATS_FORCE_UNLIMITED, BM_GETCHECK, 0, 0L);
					if(pLevel->Tools.bUnlimitedForce)
						PlayerInfo.iForce = pLevel->Header.iWidth+pLevel->Header.iHeight;
					UpdateCheats();
				break;

				case IDC_CONFIG_CHEATS_FORCE:
					GetDlgItemText(hWnd, IDC_CONFIG_CHEATS_FORCE, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
						i = 0;
					PlayerInfo.iForce = i;
					PlayerInfo.fForce = 1.0f;
				break;

				case IDC_CONFIG_CHEATS_JUMP_UNLIMITED:
					pLevel->Tools.bUnlimitedJump = SendDlgItemMessage(hWndCheats, IDC_CONFIG_CHEATS_JUMP_UNLIMITED, BM_GETCHECK, 0, 0L);
					if(pLevel->Tools.bUnlimitedJump)
						PlayerInfo.bJump = TRUE;
					UpdateCheats();
				break;

				case IDC_CONFIG_CHEATS_JUMP:
					GetDlgItemText(hWnd, IDC_CONFIG_CHEATS_JUMP, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
						i = 0;
					PlayerInfo.iJump = i;
				break;

				case IDC_CONFIG_CHEATS_GHOST:
					PlayerInfo.bGhost = SendDlgItemMessage(hWndCheats, IDC_CONFIG_CHEATS_GHOST, BM_GETCHECK, 0, 0L);
					ParticleManager.pSystem[PS_PLAYER_GHOST].bActive = PlayerInfo.bGhost;
					UpdateCheats();
				break;

				case IDC_CONFIG_CHEATS_SPEED:
					PlayerInfo.bSpeed = SendDlgItemMessage(hWndCheats, IDC_CONFIG_CHEATS_SPEED, BM_GETCHECK, 0, 0L);
					ParticleManager.pSystem[PS_PLAYER_SPEED].bActive = PlayerInfo.bSpeed;
					UpdateCheats();
				break;

				case IDC_CONFIG_CHEATS_WING:
					PlayerInfo.bWing = SendDlgItemMessage(hWndCheats, IDC_CONFIG_CHEATS_WING, BM_GETCHECK, 0, 0L);
					UpdateCheats();
				break;

				case IDC_CONFIG_CHEATS_SHIELD:
					PlayerInfo.bShield = SendDlgItemMessage(hWndCheats, IDC_CONFIG_CHEATS_SHIELD, BM_GETCHECK, 0, 0L);
					UpdateCheats();
				break;

				case IDC_CONFIG_CHEATS_GHOST_TIME:
					GetDlgItemText(hWnd, IDC_CONFIG_CHEATS_GHOST_TIME, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
						i = 0;
					PlayerInfo.lGhostWholeTime = i;
					PlayerInfo.lGhostTime = GetTickCount();
					lGhostTimeSave = 0;
				break;

				case IDC_CONFIG_CHEATS_SPEED_TIME:
					GetDlgItemText(hWnd, IDC_CONFIG_CHEATS_SPEED_TIME, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
						i = 0;
					PlayerInfo.lSpeedWholeTime = i;
					PlayerInfo.lSpeedTime = GetTickCount();
					lSpeedTimeSave = 0;
				break;

				case IDC_CONFIG_CHEATS_WING_TIME:
					GetDlgItemText(hWnd, IDC_CONFIG_CHEATS_WING_TIME, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
						i = 0;
					PlayerInfo.lWingWholeTime = i;
					PlayerInfo.lWingTime = GetTickCount();
					lWingTimeSave = 0;
				break;

				case IDC_CONFIG_CHEATS_SHIELD_TIME:
					GetDlgItemText(hWnd, IDC_CONFIG_CHEATS_SHIELD_TIME, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
						i = 0;
					PlayerInfo.lShieldWholeTime = i;
					PlayerInfo.lShieldTime = GetTickCount();
					lShieldTimeSave = 0;
				break;

				case IDC_CONFIG_CHEATS_HEALTH:
					if(!pPlayer)
						break;
					GetDlgItemText(hWnd, IDC_CONFIG_CHEATS_HEALTH, byTemp, 256);
					f = (float) atof(byTemp);
					if(f < 0.0)
						f = 0.0;
					pPlayer->fPower = f;
            }
        break;
    }
    return FALSE;
} // end ConfigCheatsProc()

void UpdateCheats(void)
{ // begin UpdateCheats()
	if(!hWndCheats)
		return;
	SendDlgItemMessage(hWndCheats, IDC_CONFIG_CHEATS_WEAPON_UNLIMITED, BM_SETCHECK, pLevel->Tools.bUnlimitedWeapon, 0L);
	SendDlgItemMessage(hWndCheats, IDC_CONFIG_CHEATS_PULL_UNLIMITED, BM_SETCHECK, pLevel->Tools.bUnlimitedPull, 0L);
	SendDlgItemMessage(hWndCheats, IDC_CONFIG_CHEATS_THROW_UNLIMITED, BM_SETCHECK, pLevel->Tools.bUnlimitedThrow, 0L);
	SendDlgItemMessage(hWndCheats, IDC_CONFIG_CHEATS_FORCE_UNLIMITED, BM_SETCHECK, pLevel->Tools.bUnlimitedForce, 0L);
	SendDlgItemMessage(hWndCheats, IDC_CONFIG_CHEATS_JUMP_UNLIMITED, BM_SETCHECK, pLevel->Tools.bUnlimitedJump, 0L);
	if(pLevel->Tools.bUnlimitedWeapon)
		EnableWindow(GetDlgItem(hWndCheats, IDC_CONFIG_CHEATS_WEAPON), FALSE);
	else
		EnableWindow(GetDlgItem(hWndCheats, IDC_CONFIG_CHEATS_WEAPON), TRUE);
	if(pLevel->Tools.bUnlimitedPull)
		EnableWindow(GetDlgItem(hWndCheats, IDC_CONFIG_CHEATS_PULL), FALSE);
	else
		EnableWindow(GetDlgItem(hWndCheats, IDC_CONFIG_CHEATS_PULL), TRUE);
	if(pLevel->Tools.bUnlimitedThrow)
		EnableWindow(GetDlgItem(hWndCheats, IDC_CONFIG_CHEATS_THROW), FALSE);
	else
		EnableWindow(GetDlgItem(hWndCheats, IDC_CONFIG_CHEATS_THROW), TRUE);
	if(pLevel->Tools.bUnlimitedForce)
		EnableWindow(GetDlgItem(hWndCheats, IDC_CONFIG_CHEATS_FORCE), FALSE);
	else
		EnableWindow(GetDlgItem(hWndCheats, IDC_CONFIG_CHEATS_FORCE), TRUE);
	if(pLevel->Tools.bUnlimitedJump)
		EnableWindow(GetDlgItem(hWndCheats, IDC_CONFIG_CHEATS_JUMP), FALSE);
	else
		EnableWindow(GetDlgItem(hWndCheats, IDC_CONFIG_CHEATS_JUMP), TRUE);
	SendDlgItemMessage(hWndCheats, IDC_CONFIG_CHEATS_GHOST, BM_SETCHECK, PlayerInfo.bGhost, 0L);
	SendDlgItemMessage(hWndCheats, IDC_CONFIG_CHEATS_SPEED, BM_SETCHECK, PlayerInfo.bSpeed, 0L);
	SendDlgItemMessage(hWndCheats, IDC_CONFIG_CHEATS_WING, BM_SETCHECK, PlayerInfo.bWing, 0L);
	SendDlgItemMessage(hWndCheats, IDC_CONFIG_CHEATS_SHIELD, BM_SETCHECK, PlayerInfo.bShield, 0L);
	g_lNow = GetTickCount();
	if(PlayerInfo.bGhost)
		EnableWindow(GetDlgItem(hWndCheats, IDC_CONFIG_CHEATS_GHOST_TIME), TRUE);
	else
		EnableWindow(GetDlgItem(hWndCheats, IDC_CONFIG_CHEATS_GHOST_TIME), FALSE);
	if(PlayerInfo.bSpeed)
		EnableWindow(GetDlgItem(hWndCheats, IDC_CONFIG_CHEATS_SPEED_TIME), TRUE);
	else
		EnableWindow(GetDlgItem(hWndCheats, IDC_CONFIG_CHEATS_SPEED_TIME), FALSE);
	if(PlayerInfo.bWing)
		EnableWindow(GetDlgItem(hWndCheats, IDC_CONFIG_CHEATS_WING_TIME), TRUE);
	else
		EnableWindow(GetDlgItem(hWndCheats, IDC_CONFIG_CHEATS_WING_TIME), FALSE);
	if(PlayerInfo.bShield)
		EnableWindow(GetDlgItem(hWndCheats, IDC_CONFIG_CHEATS_SHIELD_TIME), TRUE);
	else
		EnableWindow(GetDlgItem(hWndCheats, IDC_CONFIG_CHEATS_SHIELD_TIME), FALSE);
} // end UpdateCheats()

void SetupConfigTabs(void)
{ // begin SetupConfigTabs()
	HWND hWndTab;
	TC_ITEM tie; 

	// Setup config tabs:
	hWndTab = GetDlgItem(hWndConfig, IDC_CONFIG_TAB);
	TabCtrl_DeleteAllItems(hWndTab);
	tie.mask = TCIF_TEXT;
	// General:
	tie.pszText	= T_General;
	TabCtrl_InsertItem(hWndTab, TAB_CONFIG_GENERAL, &tie);
	if(hWndConfigTab[TAB_CONFIG_GENERAL])
		DestroyWindow(hWndConfigTab[TAB_CONFIG_GENERAL]);
	hWndConfigTab[TAB_CONFIG_GENERAL] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CONFIG_GENERAL), hWndTab, (DLGPROC) ConfigGeneralProc, WM_INITDIALOG);
	// Graphic:
	tie.pszText	= T_Graphic;
	TabCtrl_InsertItem(hWndTab, TAB_CONFIG_GRAPHIC, &tie);
	if(hWndConfigTab[TAB_CONFIG_GRAPHIC])
		DestroyWindow(hWndConfigTab[TAB_CONFIG_GRAPHIC]);
	hWndConfigTab[TAB_CONFIG_GRAPHIC] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CONFIG_GRAPHIC), hWndTab, (DLGPROC) ConfigGraphicProc, WM_INITDIALOG);
	// Sound:
	tie.pszText	= T_Sound;
	TabCtrl_InsertItem(hWndTab, TAB_CONFIG_SOUND, &tie);
	if(hWndConfigTab[TAB_CONFIG_SOUND])
		DestroyWindow(hWndConfigTab[TAB_CONFIG_SOUND]);
	hWndConfigTab[TAB_CONFIG_SOUND] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CONFIG_SOUND), hWndTab, (DLGPROC) ConfigSoundProc, WM_INITDIALOG);
	// Control:
	tie.pszText	= T_Control;
	TabCtrl_InsertItem(hWndTab, TAB_CONFIG_CONTROL, &tie);
	if(hWndConfigTab[TAB_CONFIG_CONTROL])
		DestroyWindow(hWndConfigTab[TAB_CONFIG_CONTROL]);
	hWndConfigTab[TAB_CONFIG_CONTROL] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CONFIG_CONTROL), hWndTab, (DLGPROC) ConfigControlProc, WM_INITDIALOG);
	if(bCheatsActivated)
	{ // Cheats:
		tie.pszText	= T_Cheats;
		TabCtrl_InsertItem(hWndTab, TAB_CONFIG_CHEATS, &tie);
		if(hWndConfigTab[TAB_CONFIG_CHEATS])
			DestroyWindow(hWndConfigTab[TAB_CONFIG_CHEATS]);
		hWndConfigTab[TAB_CONFIG_CHEATS] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CONFIG_CHEATS), hWndTab, (DLGPROC) ConfigCheatsProc, WM_INITDIALOG);
	}
	//
	if(iCurrentConfigTab != -1 && iCurrentConfigTab < CONFIG_TABS)
		TabCtrl_SetCurSel(GetDlgItem(hWndConfig, IDC_CONFIG_TAB), iCurrentConfigTab);
	SendMessage(hWndConfig, WM_NOTIFY, IDC_CONFIG_TAB, 0);
	ShowWindow(hWndConfig, _AS->GetCmdShow());
	UpdateWindow(hWndConfig);
} // end SetupConfigTabs()

void SetConfigLanguage(void)
{ // begin SetConfigLanguage()
	if(!hWndConfig)
		return;
	SetWindowText(hWndConfig, T_Configuration);
  	SetDlgItemText(hWndConfig, ID_CONFIG_OK, T_Ok);
  	SetDlgItemText(hWndConfig, ID_CONFIG_CANCEL, T_Cancel);
  	SetDlgItemText(hWndConfig, ID_CONFIG_QUIT, T_Quit);
  	SetDlgItemText(hWndConfig, IDC_CONFIG_HELP, T_Help);
  	SetDlgItemText(hWndConfig, IDC_CONFIG_CREDITS, T_Credits);
  	SetDlgItemText(hWndConfig, IDC_HOMEPAGE, T_Homepage);  	
	SetupConfigTabs();
} // end SetConfigLanguage()
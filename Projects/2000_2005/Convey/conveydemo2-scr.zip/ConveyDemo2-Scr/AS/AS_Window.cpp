//-----------------------------------------------------------------------------
// File: AS_Window.cpp
//-----------------------------------------------------------------------------

#include "AS_Engine.h"


GLvoid AS_WINDOW::BuildFont(GLvoid)								// Build Our Font Display List
{ // begin AS_WINDOW::BuildFont()
	float	cx;											// Holds Our X Character Coord
	float	cy;											// Holds Our Y Character Coord
	short loop;
	AS_TEXTURE Texture;
	char byTemp[256];

	sprintf(byTemp, "%s%s\\Font.jpg", _AS->pbyProgramPath, _AS->pbyBitmapsFile);
	ASLoadJpegRGB(&Texture, byTemp);
	glPixelStorei(GL_UNPACK_ALIGNMENT,3);
	glGenTextures(1, &iFontTexture[0]);
	glBindTexture(GL_TEXTURE_2D, iFontTexture[0]);

	if(_ASConfig->bUseMipmaps)
	{
		if(_ASConfig->bFastTexturing)
		{
			glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
			glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST_MIPMAP_NEAREST);
			gluBuild2DMipmaps(GL_TEXTURE_2D, 3, Texture.iWidth, Texture.iHeight, GL_RGB, GL_UNSIGNED_BYTE, Texture.pbyData);
		}
		else
		{
			glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
			glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);
			gluBuild2DMipmaps(GL_TEXTURE_2D, 3, Texture.iWidth, Texture.iHeight, GL_RGB, GL_UNSIGNED_BYTE, Texture.pbyData);
		}
	}
	else
	{
		if(_ASConfig->bFastTexturing)
		{
			glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
			glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
			glTexImage2D(GL_TEXTURE_2D, 0, 3, Texture.iWidth, Texture.iHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, Texture.pbyData);
		}
		else
		{
			glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
			glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
			glTexImage2D(GL_TEXTURE_2D, 0, 3, Texture.iWidth, Texture.iHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, Texture.pbyData);
		}
	}

	SAFE_DELETE(Texture.pbyData);

	iFontBase=glGenLists(256);							// Creating 256 Display Lists
	glBindTexture(GL_TEXTURE_2D, iFontTexture[0]);		// Select Our Font Texture
	for (loop=0; loop<256; loop++)						// Loop Through All 256 Lists
	{
		cx=(float)(loop%16)/16.0f;						// X Position Of Current Character
		cy=(float) (loop/16)/16.0f;						// Y Position Of Current Character

		glNewList(iFontBase+loop,GL_COMPILE);			// Start Building A List
			glBegin(GL_QUADS);							// Use A Quad For Each Character
				glTexCoord2f(cx,1-cy-0.0625f);			// Texture Coord (Bottom Left)
				glVertex2i(0,0);						// Vertex Coord (Bottom Left)
				glTexCoord2f(cx+0.0625f,1-cy-0.0625f);	// Texture Coord (Bottom Right)
				glVertex2i(16,0);						// Vertex Coord (Bottom Right)
				glTexCoord2f(cx+0.0625f,1-cy);			// Texture Coord (Top Right)
				glVertex2i(16,16);						// Vertex Coord (Top Right)
				glTexCoord2f(cx,1-cy);					// Texture Coord (Top Left)
				glVertex2i(0,16);						// Vertex Coord (Top Left)
			glEnd();									// Done Building Our Quad (Character)
			glTranslated(10,0,0);						// Move To The Right Of The Character
		glEndList();									// Done Building The Display List
	}													// Loop Until All 256 Are Built
} // end AS_WINDOW::BuildFont()

void AS_WINDOW::KillFont(void)
{ // begin AS_WINDOW::KillFont()
	glDeleteTextures(1, &iFontTexture[0]);
	glDeleteLists(iFontBase,256);
} // end AS_WINDOW::KillFont()

void AS_WINDOW::Print(short x, short y, char *string, short set, BOOL bCentered)
{ // begin AS_WINDOW::Print()
	glBindTexture(GL_TEXTURE_2D, iFontTexture[set]);
	if(bCentered)
		x -= (short) ((float) 10*strlen(string)/2.0f);
	ASSimplePrint(x, y, string, iFontBase);
} // end AS_WINDOW::Print()
	
void AS_WINDOW::PrintAnimated(short x, short y, char *string, short set,
							  float fScale, float fVertexT[4][2], BOOL bCentered)
{ // begin AS_WINDOW::PrintAnimated()
	float fXSize = 16*fScale,
		  fYSize = 16*fScale,
	      fTrans = 10.0f*fScale,
		  cx, cy, fVertex[4][2];
	short i, i2, x2, y2;

	for(i = 0; i < 4; i++)
		for(i2 = 0; i2 < 2; i2++)
			fVertex[i][i2] = fVertexT[i][i2]*fScale;
	glBindTexture(GL_TEXTURE_2D, iFontTexture[set]);
	glDisable(GL_DEPTH_TEST);
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	glOrtho(0, 640, 0, 480, -100, 100);
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();
	if(bCentered)
		glTranslated(x-((float) (10.0f*fScale*strlen(string)/2.0f)), y, 0);
	else
		glTranslated(x, y, 0);
	for(i = 0; i < (signed) strlen(string); i++)
	{
		y2 = (short) ((UCHAR) string[i])/16;
		x2 = ((UCHAR) string[i])-y2*16;
		cx = (float) (32*x2)/512;
		cy = (float) (32*y2)/512;
		glBegin(GL_QUADS);
			glTexCoord2f(cx, 1-cy-0.0625f);
			glVertex2f(fVertex[0][0], fVertex[0][1]);
			glTexCoord2f(cx+0.0625f, 1-cy-0.0625f);
			glVertex2f(fXSize+fVertex[1][0], fVertex[1][1]);
			glTexCoord2f(cx+0.0625f, 1-cy);
			glVertex2f(fXSize+fVertex[2][0], fYSize+fVertex[2][1]);
			glTexCoord2f(cx, 1-cy);
			glVertex2f(fVertex[3][0], fXSize+fVertex[3][1]);
		glEnd();
		glTranslated(fTrans, 0, 0);
	}
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
	glPopMatrix();
	glEnable(GL_DEPTH_TEST);
} // end AS_WINDOW::PrintAnimated()


// AS_WINDOW functions: *******************************************************
HWND AS_WINDOW::ASCreateWindow(WNDPROC WindowProc,
							   LPCTSTR pbyTitle,
							   LPCTSTR pbyName,
							   DWORD dwWidth,
							   DWORD dwHeight,
			   				   HMENU Menu,
							   BOOL bFullScreen,
							   HRESULT (*pDrawTemp)(AS_WINDOW *),
							   HRESULT (*pCheckTemp)(AS_WINDOW *),
							   HBRUSH hBackground, 
							   BOOL bIsMainWindowT)
{ // begin AS_WINDOW::ASCreateWindow()
    WNDCLASS wc;
	DWORD dwStyle = 0, dwExStyle = 0;

	memset(this, 0, sizeof(AS_WINDOW));
	bIsMainWindow = bIsMainWindowT;
	pDraw = pDrawTemp;
	pCheck = pCheckTemp;
	if(bFullScreen)
	{
		dwExStyle = WS_EX_APPWINDOW | WS_EX_TOPMOST;
		dwStyle = WS_POPUP;
		_AS->ShowMouseCursor(FALSE);
		Menu = FALSE;
		dwWidth = _ASConfig->DevMode.dmPelsWidth;
		dwHeight = _ASConfig->DevMode.dmPelsHeight;
	}
	else
	{
		dwExStyle = WS_EX_APPWINDOW | WS_EX_WINDOWEDGE |
					WS_SIZEBOX | WS_SYSMENU;
		dwStyle = WS_OVERLAPPEDWINDOW | WS_CLIPSIBLINGS | WS_CLIPCHILDREN;
		SetCursor(LoadCursor(NULL, IDC_ARROW));
		_AS->ShowMouseCursor(TRUE);
	}
	// Set up and register window class
    wc.style = CS_HREDRAW | CS_VREDRAW | CS_OWNDC | CS_PARENTDC;
    wc.lpfnWndProc = WindowProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = _AS->hInstance;
    wc.hIcon = LoadIcon(_AS->hInstance, MAKEINTRESOURCE(IDI_GAME_ICON));
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = (HBRUSH) hBackground;
    wc.lpszMenuName = NULL;
    wc.lpszClassName = pbyName;
    RegisterClass(&wc);
	hWnd = CreateWindowEx(dwExStyle,
						  pbyName,
						  pbyTitle,
						  dwStyle |
						  WS_CLIPSIBLINGS |
						  WS_CLIPCHILDREN,
						  0,
						  0,
						  dwWidth,
						  dwHeight,
						  NULL,
						  Menu,
						  _AS->hInstance,
						  NULL);
	iWidth = dwWidth;
	iHeight = dwHeight;
    // Set the icon for this dialog.
    HICON hIcon = LoadIcon(_AS->GetInstance(), MAKEINTRESOURCE(IDI_GAME_ICON));
    PostMessage(hWnd, WM_SETICON, ICON_BIG,   (LPARAM) hIcon);  // Set big icon
    PostMessage(hWnd, WM_SETICON, ICON_SMALL, (LPARAM) hIcon);  // Set small icon
	// Send the WM_INITDIALOG message: 
	SendMessage(hWnd, WM_INITDIALOG, 0, 0);
	if(bFullScreen)
		SetFocus(hWnd);
	return hWnd;
} // end AS_WINDOW::ASCreateWindow()

HRESULT AS_WINDOW::ASDestroyWindow(HWND *hWnd, LPCTSTR pbyName)
{ // begin AS_WINDOW::ASDestroyWindow()
	if(*hWnd && !DestroyWindow(*hWnd))
	{
		_AS->WriteLogMessage("Could not release hWnd");
		return 1;
	}
	if(!UnregisterClass(pbyName, _AS->hInstance))
	{
		_AS->WriteLogMessage("Could not unregister class");
		return 1;
 	}
	*hWnd = NULL;
	return 0;
} // end AS_WINDOW::ASDestroyWindow()

HRESULT AS_WINDOW::Draw(void)
{ // begin AS_WINDOW::Draw()
	if(_AS->iWindows > 1) // We have more than 1 window so switch between them
		if(!wglMakeCurrent(hDC, hRC))
			return 1;
	if(!pDraw)
		return 0;
	return pDraw(this);
} // end AS_WINDOW::Draw()

HRESULT AS_WINDOW::Check(void)
{ // begin AS_WINDOW::Check()
	if(_AS->iWindows > 1) // We have more than 1 window so switch between them
		if(!wglMakeCurrent(hDC, hRC))
			return 1;
	if(pCheck)
		return pCheck(this);
	return 0;
} // end AS_WINDOW::Check()

void AS_WINDOW::Resize(int iWidthT, int iHeightT)
{ // begin AS_WINDOW::Resize()
	_AS->WriteLogMessage("Resizing window(ID: %d)", iID);
	if(!wglMakeCurrent(hDC, hRC))
		return;
	iWidth = iWidthT;
	iHeight = iHeightT;
	ASConfigOpenGL(iWidth, iHeight);
} // end AS_WINDOW::Resize()


typedef struct
{
   byte numIden;
   byte colorMapType;
   byte imageType;
   byte colorMapSpec[5]; // not used, just here to take up space
   byte origX[2];
   byte origY[2];
   byte width[2];
   byte height[2];
   byte bpp;
   byte imageDes; // don't use, space eater
} tgaHeader_t;

// not tested, probably broken so use at your own risk
void Write(char *dest, BYTE *buff, int w, int h, int pbits)
{
   byte *tempBuff = 0;
   tgaHeader_t header;
   int bit = 0;
   int type = 0;
   BYTE temp;

   switch (pbits)
   {
      case 16:
         tempBuff = new BYTE[w * h * (bit = 3)];
         type = 2;
      break;
      case 32:
         tempBuff = new BYTE[w * h * (bit = 4)];   
         type = 2;
      break;
      case 8:
         tempBuff = new BYTE[w * h * (bit = 1)];
         type = 3;
      break;
   }

   if (!buff)
      return;

	FILE *out = fopen(dest, "wb");
    
   memset(&header, 0, sizeof(tgaHeader_t));
   header.imageType = type;
   header.width[0] = w % 256; header.width[1] = w / 256;
   header.height[0] = h % 256; header.height[1] = h / 256;
   header.bpp = pbits;
   
   fwrite(&header, 1, sizeof(tgaHeader_t), out);

   memcpy(tempBuff, buff, w * h * bit);
	
   if (bit != 1)     
   {
	   for (int i = 0; i < (w * h * bit); i += bit)
	   {
   		temp = buff[i];
		   tempBuff[i] = buff[i + 2];
		   tempBuff[i + 2] = temp;
	   }
   }

   fwrite(tempBuff, 1, w * h * bit, out);
   fclose(out);
   delete [] tempBuff;
}

void AS_WINDOW::MakeScreenshot(char *pbyFilename)
{ // begin AS_WINDOW::MakeScreenshot()
	FILE *fp;
	char byTemp[256], byFilename[256];
	int i;
	BYTE *pbyBuffer;

	if(!wglMakeCurrent(hDC, hRC))
		return;
	_AS->WriteLogMessage("Make screenshot from window(ID: %d)", iID);
	pbyBuffer = (BYTE *) malloc(iWidth*iHeight*3);
	if(!pbyBuffer)
	{
		_AS->WriteLogMessage("Couldn't make screenshot from window(ID: %d)", iID);
		return;
	}
	if(!pbyFilename)
	{ // Use default screenshot name:
		for(i = 0;; i++)
		{
			sprintf(byTemp, "shot%d.tga", i);
			fp = fopen(byTemp, "r");
			if(!fp)
				break;
		}
		strcpy(byFilename, byTemp);		
	}
	else
		strcpy(byFilename, pbyFilename);
	// Save screenshot:
    // Set the pixel storage modes:
    glPixelStorei(GL_PACK_ALIGNMENT, 1);
	glPixelStorei(GL_PACK_ROW_LENGTH, 0);
	glPixelStorei(GL_PACK_SKIP_ROWS, 0);
	glPixelStorei(GL_PACK_SKIP_PIXELS, 0);
	// Read in the current OpenGL framebuffer:
	glReadBuffer(GL_BACK);
	glReadPixels(0, 0, iWidth, iHeight, GL_RGB, GL_UNSIGNED_BYTE, pbyBuffer);
	Write(byFilename, pbyBuffer, iWidth, iHeight, 16);
	free(pbyBuffer);
	_AS->WriteLogMessage("Screenshot success");
} // end AS_WINDOW::MakeScreenshot()
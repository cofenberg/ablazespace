//-----------------------------------------------------------------------------
// File: AS_DXInput.h
//-----------------------------------------------------------------------------

#ifndef __AS_DXINPUT_H__
#define __AS_DXINPUT_H__


// Definitions: ***************************************************************
#define AS_DX_INPUT_KEYS 256
///////////////////////////////////////////////////////////////////////////////

// Structures: ****************************************************************
typedef struct
{
	char byName[256]; // Name of this key
	int iCode; // Key code
} AS_DX_INPUT_KEY;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern AS_DX_INPUT_KEY AS_DXInputKeys[AS_DX_INPUT_KEYS];
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
// HRESULT AS_ENGINE::CreateDXInputDevices(HWND, BOOL, BOOL, BOOL, BOOL);
// HRESULT AS_ENGINE::ReadDXInput(HWND);
// void AS_ENGINE::FreeDXInputDevices(void);
extern short ConvertScancodeToASCII(DWORD, USHORT *);
extern short GetDXInputKey(short);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_DXINPUT_H__
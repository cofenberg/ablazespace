//-----------------------------------------------------------------------------
// File: AS.cpp
//-----------------------------------------------------------------------------

#include "AS_Engine.h"


// Variables: *****************************************************************
AS_PROGRAM_INFO _ASProgramInfo;
AS_ENGINE *_AS;
AS_CAMERA *_ASCamera;
UCHAR ASKeys[256];
BOOL ASKeyPressed[256], ASKeyFirst[256];
AS_MOUSE ASMouse;
int iASResult;
DEVMODE	ASSavedDisplayMode;
// OpenGL info
char *pbyOpenGLVersion, *pbyOpenGLChipInfo, *pbyOpenGLRendererInfo, *pbyOpenGLExtensionInfo;
// General speed variables
long g_lProgramStartTime	= 0;		// The Program Start Time
long g_lGameLength			= 0;		// Application Run Time Variable
long g_lNow	                = 0;		// The Actual Time
long g_lLastlooptime		= 0;		// Time When Last Loop Was Started
long g_lDeltatime			= 0;		// Change In Time Since Last Iteration
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
void NormalizeFace(FLOAT3 *, FLOAT3, FLOAT3, FLOAT3);
HRESULT ASDraw(AS_WINDOW *);
HRESULT ASCheck(AS_WINDOW *);
void ASSwapBuffers(HDC, AS_WINDOW *, BOOL);
char *ASGetFileName(HWND,  char *, char *, BOOL, BOOL, char *);
char ASGetCameraSector(AS_CAMERA *, char);
void ASLoadTextures(char (*)[256], short, AS_TEXTURE *);
void ASDestroyTextures(short, AS_TEXTURE *);
void ASGenOpenGLTextures(short, AS_TEXTURE *);
void ASDestroyOpenGLTextures(short, AS_TEXTURE *);
BOOL ASLoadJpegRGB(AS_TEXTURE *, char *);
DWORD ASGetCpuSpeed(void);
void ASRemoveDirectory(char *);
///////////////////////////////////////////////////////////////////////////////

void NormalizeFace(FLOAT3 *ResultV, FLOAT3 V1, FLOAT3 V2, FLOAT3 V3)
{
	FLOAT3 V1_V2, V1_V3;
	float fLength;

	SubtVer(V1_V2, V1, V2);
	SubtVer(V1_V3, V1, V3);
	CrossProductVer(*ResultV, V1_V2, V1_V3);
	fLength = (float) sqrt((*ResultV)[X]*(*ResultV)[X]+(*ResultV)[Y]*(*ResultV)[Y]+(*ResultV)[Z]*(*ResultV)[Z]);
	(*ResultV)[X] /= fLength;
	(*ResultV)[Y] /= fLength;
	(*ResultV)[Z] /= fLength;
}



// AS_PROGRAM_INFO functions: *************************************************
void AS_PROGRAM_INFO::Init(void)
{ // begin AS_PROGRAM_INFO()
	strcpy(byVersion, GAME_VERSION);
	strcpy(byDate, __DATE__);
	strcpy(byTime, __TIME__);
} // end AS_PROGRAM_INFO()

// AS_ENGINE functions: *******************************************************
AS_ENGINE::AS_ENGINE(HINSTANCE hInstanceT, LPSTR lpCmdLineT, int iCmdShowT, BOOL bOnlyOne)
{ // begin AS_ENGINE::AS_ENGINE()
	DWORD i = MAX_PATH;
	char byTemp[256];
	short AS_WINDOW_ID;
	BOOL bTemp, bTemp2;

	// Init all:
	memset((this), 0, sizeof(AS_ENGINE));
	_AS = this;
	GetLocalTime(&StartTime);
	// Set important stuff
	hInstance = hInstanceT;
	lpCmdLine = lpCmdLineT;
	iCmdShow = iCmdShowT;
    hMutex = OpenMutex(SYNCHRONIZE, FALSE, GAME_NAME);
    if(hMutex)
    {
        if(bOnlyOne)
		{
			CloseHandle(hMutex);
			MessageBox(0, M_TheProgramIsAlreadyRunning, GAME_NAME, MB_ICONERROR | MB_OK);
			bShutDown = TRUE;
			return;
		}
    }
    else
        hMutex = CreateMutex(NULL, TRUE, GAME_NAME);
	SetPriorityClass(hInstance, 31);
	SetThreadPriority(hInstance, 31);
	_ASProgramInfo.Init();
	iWindows = 0;
	pWindow = NULL;
	bShutDown = FALSE;
	bActive = TRUE;
	// Initalize the random generator
	srand((unsigned) time(NULL));
  	pbyProgramPath = new char[_MAX_DRIVE+_MAX_DIR];
	pbyProgramExeName = new char[MAX_PATH];
	pbyProgramDrive = new char[_MAX_DRIVE];
	pbyProgramDir = new char[_MAX_DIR];
  	pbyUserName = new char[MAX_PATH];
	pbyConfigFile = new char[MAX_PATH];
	pbyLanguagesFile = new char[MAX_PATH];
  	pbyHighscoreFile = new char[MAX_PATH];
  	pbyDecorationsFile = new char[MAX_PATH];
  	pbyCampaignsFile = new char[MAX_PATH];
  	pbySingleLevelsFile = new char[MAX_PATH];
  	pbyObjectsFile = new char[MAX_PATH];
  	pbyBitmapsFile = new char[MAX_PATH];
  	pbyMusicFile = new char[MAX_PATH];
  	pbySoundFile = new char[MAX_PATH];
  	pbyTexturesFile = new char[MAX_PATH];
  	pbySurfacesFile = new char[MAX_PATH];
  	pbyIdentityFile = new char[MAX_PATH];
	// Find path info
	GetModuleFileName(hInstance, pbyProgramExeName, MAX_PATH);
	_splitpath(pbyProgramExeName, pbyProgramDrive, pbyProgramDir, NULL, NULL);
	sprintf(pbyProgramPath, "%s%s", pbyProgramDrive, pbyProgramDir);
	SetCurrentDirectory(pbyProgramPath);
	GetUserName(pbyUserName, &i);
    // Loads the game stuff:
	sprintf(byTemp, "%s"AS_GAME_INFO_FILE"", _AS->pbyProgramPath);
	bLog = GetPrivateProfileInt("General", "log", 1, byTemp);
	bDebugMode = GetPrivateProfileInt("General", "debug_mode", 0, byTemp);
	bStartErrorMessage = GetPrivateProfileInt("General", "start_error_message", 1, byTemp);
	GetPrivateProfileString("General", "config_file", "Config.ini", pbyConfigFile, MAX_PATH, byTemp);
	GetPrivateProfileString("General", "languages_file", "Data\\Languages", pbyLanguagesFile, MAX_PATH, byTemp);
	GetPrivateProfileString("General", "highscore_file", "Highscore.dat", pbyHighscoreFile, MAX_PATH, byTemp);
	GetPrivateProfileString("General", "decorations_file", "Data\\Decorations", pbyDecorationsFile, MAX_PATH, byTemp);
	GetPrivateProfileString("General", "campaigns_file", "Data\\Campaigns", pbyCampaignsFile, MAX_PATH, byTemp);
	GetPrivateProfileString("General", "single_levels_file", "Data\\SingleLevels", pbySingleLevelsFile, MAX_PATH, byTemp);
	GetPrivateProfileString("General", "objects_file", "Data\\Objects", pbyObjectsFile, MAX_PATH, byTemp);
	GetPrivateProfileString("General", "bitmaps_file", "Data\\Bitmaps", pbyBitmapsFile, MAX_PATH, byTemp);
	GetPrivateProfileString("General", "music_file", "Data\\Music", pbyMusicFile, MAX_PATH, byTemp);
	GetPrivateProfileString("General", "sound_file", "Data\\Sound", pbySoundFile, MAX_PATH, byTemp);
	GetPrivateProfileString("General", "textures_file", "Data\\Textures", pbyTexturesFile, MAX_PATH, byTemp);
	GetPrivateProfileString("General", "surfaces_file", "Data\\Surfaces", pbySurfacesFile, MAX_PATH, byTemp);
	GetPrivateProfileString("General", "identity_file", "Data\\Identities", pbyIdentityFile, MAX_PATH, byTemp);
	// Load the configuration:	
	_ASConfig = new AS_CONFIG;
	sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyConfigFile);
	_ASConfig->Load(byTemp);
	// 
	// Open the log:
	bTemp2 = _ASConfig->bLog;
	_ASConfig->bLog = TRUE;
	pLogFile = fopen(AS_LOG_FILE, "wt");
	if(!pLogFile)
	{
		sprintf(byTemp, "Couldn't open the log (%s)\nGo sure that all program-files ready for writing!", AS_LOG_FILE);
		MessageBox(NULL, byTemp, T_Error, MB_OK | MB_ICONINFORMATION);
		bLog = FALSE; // Disable the log
	}
	// Create header:
	WriteLog("<HTML>");
	WriteLog("<HEAD>");
	WriteLog("<TITLE>Log</TITLE>");
	WriteLog("</HEAD>");
	WriteLog("<BODY>");
	////////////////////////////////////
	WriteLog("<P ALIGN=\"CENTER\"><FONT SIZE=\"+1\" COLOR=\"#0080FF\"><U><B>Log-System activated</B></U></FONT></P>");
	WriteLog("<P ALIGN=\"CENTER\"><B><FONT SIZE=\"+1\"><B><U>Program start time:</B></U> Date: %d.%d.%d - Time: %d:%d:%d:%d</FONT></B></P>", StartTime.wMonth, StartTime.wDay, StartTime.wYear, 
																										  StartTime.wHour, StartTime.wMinute, 
																										  StartTime.wSecond, StartTime.wMilliseconds);
	////////////////////////////////////
	WriteLog("<P ALIGN=\"CENTER\"><FONT SIZE=\"+4\"><U><B><I><FONT COLOR=\"#FF0000\">%s %s<FONT></I></B></U></FONT></FONT></P>", GAME_NAME, GAME_VERSION);
	WriteLog("<P ALIGN=\"CENTER\"><B><FONT SIZE=\"+1\">Build: %s %s</FONT></B></P>", _ASProgramInfo.byDate, _ASProgramInfo.byTime);
	// Print out the general system info:
	WriteLog("<P ALIGN=\"CENTER\"><FONT SIZE=\"+2\"><U><B>General system info:</B></U></FONT></P>");
	WriteLog("<TABLE WIDTH=\"1000\">");
	WriteLogMessage("User name: %s", pbyUserName);
	WriteLogMessage("CPU: %d Mhz", ASGetCpuSpeed());
	if(GetSystemMetrics(SM_MOUSEPRESENT))
		WriteLogMessage("There is a mouse");
	else
		WriteLogMessage("There is no mouse");
	sprintf(byTemp, "Number of mouse buttons: %d", GetSystemMetrics(SM_CMOUSEBUTTONS));
	WriteLogMessage(byTemp);	
	sprintf(byTemp, "Display resolution: %dx%d", GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN));
	WriteLogMessage(byTemp);
	WriteLog("</TABLE>");
	// Print out path info:
	WriteLog("<P ALIGN=\"CENTER\"><FONT SIZE=\"+2\"><U><B>File info:</B></U></FONT></P>");
	WriteLog("<TABLE WIDTH=\"1000\">");
	WriteLog("<TR><TD><B><U>Program path:</B></U> %s</TD></TR>", pbyProgramPath);
	WriteLog("<TR><TD><B><U>Game info file:</B></U> "AS_GAME_INFO_FILE"</TD></TR>");
	WriteLog("<TR><TD><B><U>Config file:</B></U> %s</TD></TR>", pbyConfigFile);
	WriteLog("<TR><TD><B><U>Languages file:</B></U> %s</TD></TR>", pbyLanguagesFile);
	WriteLog("<TR><TD><B><U>Highscore file:</B></U> %s</TD></TR>", pbyHighscoreFile);
	WriteLog("<TR><TD><B><U>Levels file:</B></U> %s</TD></TR>", pbyCampaignsFile);
	WriteLog("<TR><TD><B><U>User Levels file:</B></U> %s</TD></TR>", pbySingleLevelsFile);
	WriteLog("<TR><TD><B><U>Objects file:</B></U> %s</TD></TR>", pbyObjectsFile);
	WriteLog("<TR><TD><B><U>Bitmaps file:</B></U> %s</TD></TR>", pbyBitmapsFile);
	WriteLog("<TR><TD><B><U>Music file:</B></U> %s</TD></TR>", pbyMusicFile);
	WriteLog("<TR><TD><B><U>Sound file:</B></U> %s</TD></TR>", pbySoundFile);
	WriteLog("<TR><TD><B><U>Textures file:</B></U> %s</TD></TR>", pbyTexturesFile);
	WriteLog("<TR><TD><B><U>Surfaces file:</B></U> %s</TD></TR>", pbySurfacesFile);
	WriteLog("<TR><TD><B><U>Identities file:</B></U> %s</TD></TR>", pbyIdentityFile);	
	WriteLog("</TABLE>");
	WriteLog("<P ALIGN=\"CENTER\"><FONT SIZE=\"+2\"><U><B>Messages:</B></U></FONT></P>");
	WriteLog("<TABLE WIDTH=\"1000\">");
    // Init FPS:
	dwFPSTimeNow = GetTickCount();
	dwFPSTimeLast = GetTickCount();
	dwFPSTimeDifference = 0;
	iFPSRenderedFrames = iFPSFramesSinceCheck = iFPS = 0;
	EnumerateDisplayModeInfos();
	// Enumerate the languages:
	EnumerateLanguages();
	// Initalize DirectInput:
	WriteLogMessage("Initalize DirectInput");
	// Get the OpenGL stuff:
	WriteLogMessage("Get OpenGL information");
	bTemp = _ASConfig->bFullScreen; 
	_ASConfig->bFullScreen = 0; 
	ASCreateWindow(WindowProc, AS_WINDOW_NAME, AS_WINDOW_NAME, _ASConfig->iWindowWidth, _ASConfig->iWindowHeight, NULL, FALSE, ASDraw, ASCheck, NULL, TRUE);
	AS_WINDOW_ID = _AS->GetWindows()-1;
	ASInitOpenGL(&_AS->pWindow[AS_WINDOW_ID],
				 NULL,
				 _AS->pWindow[AS_WINDOW_ID].GethDC(),
				 _AS->pWindow[AS_WINDOW_ID].GethRC(), FALSE);
	glGetIntegerv(GL_MAX_LIGHTS, &iMaxLights);
	ShowWindow(*_AS->pWindow[AS_WINDOW_ID].GethWnd(), SW_SHOW);	
	ASDestroyOpenGL(&_AS->pWindow[AS_WINDOW_ID],
					NULL,
				    *_AS->pWindow[AS_WINDOW_ID].GethDC(),
				    *_AS->pWindow[AS_WINDOW_ID].GethRC());
	ASDestroyWindow(_AS->pWindow[AS_WINDOW_ID].GethWnd(), AS_WINDOW_NAME);
	_ASConfig->bFullScreen = bTemp; 
	WriteLogMessage("OpenGL information received");
	// Print out the OpenGL information:
	WriteLogMessage("Show OpenGL information");
	WriteLogMessage("Version:");
	WriteLogMessage(pbyOpenGLVersion);
	WriteLogMessage("Chip info:");
	WriteLogMessage(pbyOpenGLChipInfo);
	WriteLogMessage("Renderer info:");
	WriteLogMessage(pbyOpenGLRendererInfo);
	WriteLogMessage("Extensions info:");
	WriteLogMessageS(pbyOpenGLExtensionInfo);
	WriteLogMessage("That's all from OpenGL");
	// Init complete:
	g_lProgramStartTime = GetTickCount();
	WriteLogMessage("AS-Engine init complete");
	_ASConfig->bLog = bTemp2;
} // end AS_ENGINE::AS_ENGINE()

AS_ENGINE::~AS_ENGINE(void)
{ // begin AS_ENGINE::~AS_ENGINE()
	char byTemp[256];
	BOOL bTemp;

	// Shut down the program:
	_AS->WriteLogMessage("Program loop left");
	_AS->WriteLogMessage("Shut down program");
	// Check if there was an error:
	if(!_ASConfig->bSetError)
		_ASConfig->bError = FALSE;
	else
		_ASConfig->bError = TRUE;
	_ASConfig->bFirstRun = FALSE;
	if(_ASConfig->bError)
		MessageBox(NULL, M_ProgramEndErrorDetected, GAME_NAME, MB_OK | MB_ICONINFORMATION);
	// Save the configuration:	
	sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyConfigFile);
	_ASConfig->Save(byTemp);
	// Delete OpenGL information
	SAFE_DELETE(pbyOpenGLVersion);
	SAFE_DELETE(pbyOpenGLChipInfo);
	SAFE_DELETE(pbyOpenGLRendererInfo);
	SAFE_DELETE(pbyOpenGLExtensionInfo);
	// Delete last stuff:
	SAFE_DELETE(pbyProgramPath);
	SAFE_DELETE(pbyProgramExeName);
	SAFE_DELETE(pbyProgramDrive);
	SAFE_DELETE(pbyProgramDir);
	SAFE_DELETE(pbyUserName);
	SAFE_DELETE(pbyConfigFile);
	SAFE_DELETE(pbyLanguagesFile);
	SAFE_DELETE(pbyHighscoreFile);
	SAFE_DELETE(pbyDecorationsFile);
	SAFE_DELETE(pbyCampaignsFile);
	SAFE_DELETE(pbySingleLevelsFile);
	SAFE_DELETE(pbyObjectsFile);
	SAFE_DELETE(pbyMusicFile);
	SAFE_DELETE(pbySoundFile);
	SAFE_DELETE(pbyTexturesFile);
	SAFE_DELETE(pbySurfacesFile);
	SAFE_DELETE(pbyIdentityFile);	
	DestroyDisplayModeInfo();
	////////////////////////////////////
	DestroyLanguage();
	// Close the Log:
	bTemp = _ASConfig->bLog;
	_ASConfig->bLog = TRUE;
	WriteLogMessage("Shut down AS-Engine");
	WriteLog("</TABLE>");
	WriteLog("<P ALIGN=\"CENTER\"><FONT SIZE=\"+1\" COLOR=\"#0080FF\"><U><B>Log-System closed</B></U></FONT></P>");
	WriteLog("</BODY>\n");
	WriteLog("</HTML>\n");
	if(pLogFile)
		fclose(pLogFile);
	_ASConfig->bLog = bTemp;
	delete _ASConfig;
	////////////////////////////////////
} // end AS_ENGINE::~AS_ENGINE()

void AS_ENGINE::WriteLog(const char *pbyMessage, ...)
{ // begin AS_ENGINE::WriteLog()
	char byText[1000];
	va_list	list;

	if(!bLog || !pLogFile || !_ASConfig->bLog)
		return;
	va_start(list, pbyMessage);
		vsprintf(byText, pbyMessage, list);
	va_end(list);
	fprintf(pLogFile, byText);
	fflush(pLogFile);
} // end AS_ENGINE::WriteLog()

void AS_ENGINE::WriteLogMessage(const char *pbyMessage, ...)
{ // begin AS_ENGINE::WriteLogMessage()
	char byText[1000];
	va_list	list;

	if(!bLog || !pLogFile || !_ASConfig->bLog)
		return;
	va_start(list, pbyMessage);
		vsprintf(byText, pbyMessage, list);
	va_end(list);
	fprintf(pLogFile, "<TR><TD><FONT SIZE=\"+1\">%s</FONT></TD</TR>", byText);
	fflush(pLogFile);
} // end AS_ENGINE::WriteLogMessage()

void AS_ENGINE::WriteLogMessageS(char *pbyMessage)
{ // begin AS_ENGINE::WriteLogMessageS()
	if(!bLog || !pLogFile || !_ASConfig->bLog)
		return;
	fprintf(pLogFile, "<TR><TD><FONT SIZE=\"+1\">%s</FONT></TD</TR>", pbyMessage);
	fflush(pLogFile);
} // end AS_ENGINE::WriteLogMessageS()

HWND AS_ENGINE::ASCreateWindow(WNDPROC WindowProc,
							   LPCTSTR pbyTitle,
							   LPCTSTR pbyName,
							   DWORD dwWidth,
							   DWORD dwHeight,
			   				   HMENU Menu,
							   BOOL bFullScreen,
							   HRESULT (*pDrawTemp)(AS_WINDOW *),
							   HRESULT (*pCheckTemp)(AS_WINDOW *),
							   HBRUSH hBackground,
							   BOOL bIsMainWindowT)
{ // begin AS_ENGINE::ASCreateWindow()
	HWND hWnd;
		
	WriteLogMessage("Create window");
	if(bMainWindow && bIsMainWindowT)
	{
		WriteLogMessage("There is already a main window!");
		return NULL;
	}
	WriteLogMessage("Titel: %s", pbyTitle);
	WriteLogMessage("Name: %s", pbyName);
	WriteLogMessage("Width: %d", dwWidth);
	WriteLogMessage("Height: %d", dwHeight);
	WriteLogMessage("Full screen: %d", bFullScreen);
	iWindows++;
	pWindow = (AS_WINDOW *) realloc(pWindow, sizeof(AS_WINDOW)*iWindows);
	hWnd = pWindow[iWindows-1].ASCreateWindow(WindowProc, 
											  pbyTitle,
											  pbyName,
											  dwWidth,
											  dwHeight,
											  Menu,
											  bFullScreen,
											  pDrawTemp,
											  pCheckTemp,
											  hBackground,
											  bIsMainWindowT);
	pWindow[iWindows-1].SetID(iWindows-1);
	WriteLogMessage("Window(ID: %d) successful created", iWindows-1);
	if(!bMainWindow && bIsMainWindowT)
		bMainWindow = TRUE;
	return hWnd;
} // end AS_ENGINE::ASCreateWindow()

HRESULT AS_ENGINE::ASDestroyWindow(HWND *hWnd, LPCTSTR pbyName)
{ // begin AS_ENGINE::ASDestroyWindow()
	short i;
	LPTSTR lpClassName = new char[MAX_PATH];
	
	WriteLogMessage("Destroy window");
	WriteLogMessage("Name: %s", pbyName);
	if(!hWnd)
	{ // Find the window self:
		for(i = 0; i < iWindows; i++)
		{
			GetClassName(*pWindow[i].GethWnd(), lpClassName, MAX_PATH);
			if(!strcmp(lpClassName, pbyName))
			{ // We�ve found the window!
				HWND hTemp; 

				hTemp = *pWindow[i].GethWnd();
				hWnd = &hTemp;
				break;
			}
		}
	}
	if(!hWnd)
		return 1;
	for(i = 0; i < iWindows; i++)
		if(*pWindow[i].GethWnd() == *hWnd)
		{
			WriteLogMessage("ID: %d", i);
			if(pWindow[i].GetIsMainWindow())
				bMainWindow = FALSE;
			pWindow[i].ASDestroyWindow(hWnd, pbyName);			
			pWindow[i] = pWindow[iWindows-1];
			iWindows--;
			pWindow = (AS_WINDOW *) realloc(pWindow, sizeof(AS_WINDOW)*iWindows);
			WriteLogMessage("Window successful destroyed");
			return 0;
		}
	return 1;
} // end AS_ENGINE::ASDestroyWindow()

HRESULT AS_ENGINE::EnumerateDisplayModeInfos(void)
{ // begin AS_ENGINE::EnumerateDisplayModeInfos()
	DEVMODE devMode;

	DestroyDisplayModeInfo();
	WriteLogMessage("Enumerate display modes...");
	for(short i = 0;;i++) 
	{
		if(!EnumDisplaySettings(NULL, i, &devMode)) 
			break;
		AddDisplayModeInfo(devMode);
	}
	WriteLogMessage("Complete");
    return 0;
} // end AS_ENGINE::EnumerateDisplayModeInfos()

HRESULT AS_ENGINE::AddDisplayModeInfo(DEVMODE lpDevMode)
{ // begin AS_ENGINE::AddDisplayModeInfo()
	if(lpDevMode.dmBitsPerPel < 16)
		return 1;
	DisplayModeInfo.Number++;
	DisplayModeInfo.pDevMode = (DEVMODE *) realloc(DisplayModeInfo.pDevMode, sizeof(DEVMODE)*DisplayModeInfo.Number);
	if(!DisplayModeInfo.pDevMode)
		return 1;
	CopyMemory(&DisplayModeInfo.pDevMode[DisplayModeInfo.Number-1], &lpDevMode, sizeof(DEVMODE));
	WriteLogMessage("Found: %dx%dx%d", DisplayModeInfo.pDevMode[DisplayModeInfo.Number-1].dmPelsWidth,
									   DisplayModeInfo.pDevMode[DisplayModeInfo.Number-1].dmPelsHeight,
									   DisplayModeInfo.pDevMode[DisplayModeInfo.Number-1].dmBitsPerPel);
	return 0;
} // end AS_ENGINE::AddDisplayModeInfo()

HRESULT AS_ENGINE::DestroyDisplayModeInfo(void)
{ // begin AS_ENGINE::DestroyDisplayModeInfo()
	if(DisplayModeInfo.pDevMode)
		free(DisplayModeInfo.pDevMode);
	DisplayModeInfo.pDevMode = NULL;
	DisplayModeInfo.Number = 0;
	return 0;
} // end AS_ENGINE::DestroyDisplayModeInfo()

void AS_ENGINE::UpdateWindows(void)
{ // begin AS_ENGINE::UpdateWindows()
	// Check the speed control stuff
	g_lNow = GetTickCount();
	g_lDeltatime = g_lNow-g_lLastlooptime;
	if(!g_lDeltatime)
		g_lDeltatime = 1;
	g_lLastlooptime = g_lNow;
	g_lGameLength = (g_lNow-g_lProgramStartTime)/1000;	
	if(g_lDeltatime > 100)
		g_lDeltatime = 100;
	// Check the windows
	for(short i = 0; i < iWindows; i++)
	{
		pWindow[i].Check();
		pWindow[i].Draw();
	}
	UpdateFPS();
} // end AS_ENGINE::UpdateWindows()

int AS_ENGINE::FindWindowID(HWND hWnd)
{ // begin AS_ENGINE::FindWindowID()
	for(short i = 0; i < iWindows; i++)
		if(*pWindow[i].GethWnd() == hWnd)
			return i;
	return -1;
} // end AS_ENGINE::FindWindowID()

int AS_ENGINE::UpdateFPS(void)
{ // begin AS_ENGINE::UpdateFPS()
	dwFPSTimeNow = GetTickCount();
	dwFPSTimeDifference = dwFPSTimeNow-dwFPSTimeLast;
	iFPSRenderedFrames++;
	iFPSFramesSinceCheck++;
	if(dwFPSTimeDifference > 1000)
	{
		dwFPSTimeLast = dwFPSTimeNow;
		iFPS = iFPSFramesSinceCheck;
		iFPSFramesSinceCheck = 0;
	}
    return iFPS;
} // end AS_ENGINE::UpdateFPS()

void AS_ENGINE::ShowMouseCursor(BOOL bState)
{ // begin AS_ENGINE::ShowMouseCursor()
	int i;
	
	// Disables/Enables the mouse cursor:
	if(!bState)
	{
		for(;;)
		{
			i = ShowCursor(FALSE);
			if(i < 0)
				break;
		}
	}
	else
	{
		for(;;)
		{
			i = ShowCursor(TRUE);
			if(i >= 0)
				break;
		}
	}
} // end AS_ENGINE::ShowMouseCursor()


// Functions: *****************************************************************
HRESULT ASDraw(AS_WINDOW *pWindow)
{ // begin ASDraw()
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	ASSwapBuffers(*pWindow->GethDC(), pWindow, FALSE);
	return 0;
} // end ASDraw()

HRESULT ASCheck(AS_WINDOW *pWindow)
{ // begin ASCheck()
	return 0;
} // end ASCheck()

void ASSwapBuffers(HDC hDC, AS_WINDOW *pWindow, BOOL bShowInfo)
{ // begin ASSwapBuffers()
	char byTemp[256];

	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glDisable(GL_LIGHTING);
	glColor4f(1.0f, 1.0f, 1.0f, 0.95f);
	if(_ASConfig->bShowFPS && bShowInfo)
	{ // Display FPS:
		sprintf(byTemp, "FPS: %d", _AS->GetFPS());
		if(!pWindow)
			ASPrint(0, 10, byTemp, 0);
		else
			pWindow->Print(0, 10, byTemp, 0, 0);
	}
	if(_ASConfig->bShowCulledObjects && bShowInfo)
	{ // Display FPS:

		sprintf(byTemp, "Culled: %d", iCulledObjects);
		if(!pWindow)
			ASPrint(100, 10, byTemp, 0);
		else
			pWindow->Print(100, 10, byTemp, 0, 0);
	}
	glFlush();
	SwapBuffers(hDC);
} // end ASSwapBuffers()

char *ASGetFileName(HWND hWnd, char *pbyTitle, char *pbyFilter, BOOL bMode, BOOL bMultiSelect, char *pbyInitalDir)
{ // begin ASGetFileName()
    static char file[256];
    static char fileTitle[256];
    OPENFILENAME ofn;

    lstrcpy( file, "");
    lstrcpy( fileTitle, "");
    ofn.lStructSize       = sizeof(OPENFILENAME);
    ofn.hwndOwner         = hWnd;
#ifdef WIN32
    ofn.hInstance         = (HINSTANCE) GetWindowLong(hWnd, GWL_HINSTANCE);
#else
    ofn.hInstance         = (HINSTANCE) GetWindowWord(hWnd, GWW_HINSTANCE);
#endif
    ofn.lpstrFilter       = pbyFilter;
    ofn.lpstrCustomFilter = (LPSTR) NULL;
    ofn.nMaxCustFilter    = 0L;
    ofn.nFilterIndex      = 1L;
    ofn.lpstrFile         = file;
    ofn.nMaxFile          = sizeof(file);
    ofn.lpstrFileTitle    = fileTitle;
    ofn.nMaxFileTitle     = sizeof(fileTitle);
    ofn.lpstrInitialDir   = pbyInitalDir;
    ofn.lpstrTitle        = pbyTitle;
    ofn.nFileOffset       = 0;
    ofn.nFileExtension    = 0;
    ofn.lpstrDefExt       = pbyFilter;
	ofn.lCustData         = 0;
	ofn.Flags = OFN_PATHMUSTEXIST | OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_NONETWORKBUTTON;
    if(!bMode) // We load a file...
		ofn.Flags |= OFN_FILEMUSTEXIST;
	if(bMultiSelect)
		ofn.Flags |= OFN_ALLOWMULTISELECT;
    if (GetOpenFileName(&ofn))
	    return (char *) ofn.lpstrFile;
	return NULL;
} // end ASGetFileName()

char ASGetCameraSector(AS_CAMERA *pCameraT, char byAxe)
{ // begin ASGetCameraSector()
	if(pCameraT->fRot[byAxe] >= 0 && pCameraT->fRot[byAxe] < 90)
		return 0;
	if(pCameraT->fRot[byAxe] >= 90 && pCameraT->fRot[byAxe] < 180)
		return 1;
	if(pCameraT->fRot[byAxe] >= 180 && pCameraT->fRot[byAxe] < 270)
		return 2;
	if(pCameraT->fRot[byAxe] >= 270 && pCameraT->fRot[byAxe] < 360)
		return 3;
	return -1;
} // end ASGetCameraSector()

void ASLoadTextures(char (*byFilename)[256], short iTextures, AS_TEXTURE *Texture)
{ // begin ASLoadTextures()
	char byTemp[256];
	short i;

	_AS->WriteLogMessage("Load textures");
	for(i = 0; i < iTextures; i++)
	{
		sprintf(byTemp, "%s%s\\%s", _AS->pbyProgramPath, _AS->pbyBitmapsFile, byFilename[i]);
		strcpy(Texture[i].byFilename, byTemp);
		ASLoadJpegRGB(&Texture[i], byTemp);
	}
} // begin ASLoadTextures()

void ASDestroyTextures(short iTextures, AS_TEXTURE *Texture)
{ // begin ASDestroyTextures()
	if(!Texture[0].pbyData)
		return;
	for(short i = 0; i < iTextures; i++)
	{
		free(Texture[i].pbyData);
		Texture[i].pbyData = NULL;
	}
} // end ASDestroyTextures()

void ASGenOpenGLTextures(short iTextures, AS_TEXTURE *Texture)
{ // begin ASGenOpenGLTextures()
	if(!Texture[0].pbyData)
		return;
	_AS->WriteLogMessage("Generate OpenGL textures");
	for(short i = 0; i < iTextures; i++)
	{
		glGenTextures(1, &Texture[i].iOpenGLID);
		glBindTexture(GL_TEXTURE_2D, Texture[i].iOpenGLID);
		if(_ASConfig->bUseMipmaps)
		{
			if(_ASConfig->bFastTexturing)
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST_MIPMAP_NEAREST);
				gluBuild2DMipmaps(GL_TEXTURE_2D, 3, Texture[i].iWidth, Texture[i].iHeight, GL_RGB, GL_UNSIGNED_BYTE, Texture[i].pbyData);
			}
			else
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);
				gluBuild2DMipmaps(GL_TEXTURE_2D, 3, Texture[i].iWidth, Texture[i].iHeight, GL_RGB, GL_UNSIGNED_BYTE, Texture[i].pbyData);
			}
		}
		else
		{
			if(_ASConfig->bFastTexturing)
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
				glTexImage2D(GL_TEXTURE_2D, 0, 3, Texture[i].iWidth, Texture[i].iHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, Texture[i].pbyData);
			}
			else
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
				glTexImage2D(GL_TEXTURE_2D, 0, 3, Texture[i].iWidth, Texture[i].iHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, Texture[i].pbyData);
			}
		}
	}
} // end ASGenOpenGLTextures()

void ASDestroyOpenGLTextures(short iTextures, AS_TEXTURE *Texture)
{ // begin ASDestroyOpenGLTextures()
	if(!Texture[0].pbyData)
		return;
	for(short i = 0; i < iTextures; i++)
		glDeleteTextures(1, &Texture[i].iOpenGLID);
} // end ASDestroyOpenGLTextures()

BOOL ASLoadJpegRGB(AS_TEXTURE *texture, char* fileName)
{ // begin ASLoadJpegRGB()
	JPEG_CORE_PROPERTIES jcProps;
	
	memset(&jcProps, 0, sizeof(JPEG_CORE_PROPERTIES));
	ijlInit(&jcProps);
	jcProps.JPGFile = fileName;
	ijlRead(&jcProps, IJL_JFILE_READPARAMS);
	texture->iWidth = (short) jcProps.JPGWidth;
	texture->iHeight = (short) jcProps.JPGHeight;
	texture->pbyData = (BYTE *) malloc(sizeof(BYTE)*texture->iWidth*texture->iHeight*3);
	jcProps.DIBWidth = jcProps.JPGWidth;
	jcProps.DIBHeight = jcProps.JPGHeight;
	jcProps.DIBChannels = 3;
	jcProps.DIBColor = IJL_RGB;
	jcProps.DIBPadBytes = 0;
	jcProps.DIBBytes = (BYTE *) texture->pbyData;
	jcProps.JPGColor = IJL_YCBCR;
	if(ijlRead(&jcProps, IJL_JFILE_READWHOLEIMAGE) != IJL_OK)
		return 1;
	ijlFree(&jcProps);
	return 0;
} // end ASLoadJpegRGB()

DWORD ASGetCpuSpeed(void)
{ // begin ASGetCpuSpeed()
  int timeStart = 0;
  int timeStop = 0;
  unsigned long StartTicks = 0;
  unsigned long EndTicks = 0;
  unsigned long TotalTicks = 0;
  unsigned long cpuSpeed = 0;

  timeStart = timeGetTime();
  for(;;)
  {
    timeStop = timeGetTime();
    if((timeStop-timeStart) > 1)
	{ // rollover past 1
		__asm
		{
			xor eax, eax
			xor ebx, ebx
			xor ecx, ecx
			xor edx, edx
			_emit 0x0f // CPUID
			_emit 0xa2
			_emit 0x0f // RTDSC
			_emit 0x31
			mov [StartTicks], eax // Tick counter starts here
		}
		break;
    }
  }
  timeStart = timeStop;
  for(;;)
  {
    timeStop = timeGetTime();
    if((timeStop-timeStart) > 1000)
	{ // one second
		__asm
		{
			xor eax, eax
			xor ebx, ebx
			xor ecx, ecx
			xor edx, edx
			_emit 0x0f
			_emit 0xa2
			_emit 0x0f
			_emit 0x31
			mov [EndTicks], eax
		}
      break;
    }
  }
  TotalTicks = EndTicks-StartTicks; // total
  cpuSpeed = TotalTicks/1000000; // speed
  return((DWORD) cpuSpeed);
} // end ASGetCpuSpeed()

void ASRemoveDirectory(char *pbyFilename)
{ // begin ASRemoveDirectory()
	WIN32_FIND_DATA FindFileData;
	char byTemp[256];
	HANDLE Find;
	                   
	// Delete all files in this dictory:
    sprintf(byTemp, "%s*.*", pbyFilename);
	Find = FindFirstFile(byTemp, &FindFileData);
	for(;;)
	{
	    sprintf(byTemp, "%s%s", pbyFilename, FindFileData.cFileName);
		remove(byTemp);
		if(!FindNextFile(Find, &FindFileData))
			break;
	}
	FindClose(Find);
	// Remove the empty dictory:
	RemoveDirectory(pbyFilename);
} // end ASRemoveDirectory()
//-----------------------------------------------------------------------------
// File: AS_Particle.cpp
//-----------------------------------------------------------------------------

#include "AS_Engine.h"


// Functions: *****************************************************************
void ASParticleSystemDraw_Standart(AS_PARTICLE_SYSTEM *);
void ASParticleSystemDraw_WaterWaves(AS_PARTICLE_SYSTEM *);
void ASParticleSystemCheck_Md2Trace(AS_PARTICLE_SYSTEM *);
void ASParticleSystemCheck_ShotTrace1(AS_PARTICLE_SYSTEM *);
void ASParticleSystemCheck_Smoke1(AS_PARTICLE_SYSTEM *);
void ASParticleSystemCheck_ASLogo(AS_PARTICLE_SYSTEM *);
void ASParticleSystemCheck_Autosave(AS_PARTICLE_SYSTEM *);
void ASParticleSystemCheck_WaterWaves(AS_PARTICLE_SYSTEM *);
void ASParticleSystemCheck_Beamer(AS_PARTICLE_SYSTEM *);
void ASParticleSystemCheck_X3Acid(AS_PARTICLE_SYSTEM *);
void ASParticleSystemCheck_Bubbles(AS_PARTICLE_SYSTEM *);
///////////////////////////////////////////////////////////////////////////////


//////////          AS_PARTICLE_SYSTEM          ///////////////////////////////

// Get's the vertices positions of a md2 model and creat's particles:
void AS_PARTICLE_SYSTEM::CreateMd2Vertices(AS_MD2_MODEL *model, int frame1, int frame2, float pol, FLOAT3 fPos)
{ // begin AS_PARTICLE_SYSTEM::CreateMd2Vertices()
	AS_MD2_FRAME *f1 = &model->frames[frame1];
	AS_MD2_FRAME *f2 = &model->frames[frame2];
	float x1, y1, z1, x2, y2, z2;
	AS_PARTICLE *pParticleT;
	short i, i2;
	
	if(frame1 < 0 || frame2 < 0 ||
	   frame1 >= model->header.numFrames || frame2 >= model->header.numFrames)
	   return;
	for(i = 0, i2 = 0; i < model->header.numVertices; i += iMaxParticles/iParticles)
	{
		if(pParticle[i2].bAlive)
		{ // Find the next free particle:
			for(i2++;; i2++)
			{
				if(i2 >= iParticles)
				{
					i = model->header.numVertices;
					break;
				}
				if(!pParticle[i2].bAlive)
				{ // We've found an none active particle:
					break;
				}
			}
			if(i2 >= iParticles)
			{ // There is no active particle!
				break;
			}
		}

		// Create a particle on this md2 vertex:
		pParticleT = &pParticle[i2];
		pParticleT->bAlive = TRUE;

		// Calculate the position of the particle:
		x1 = f1->vertices[i].vertex[0];
		y1 = f1->vertices[i].vertex[1];
		z1 = f1->vertices[i].vertex[2];
		x2 = f2->vertices[i].vertex[0];
		y2 = f2->vertices[i].vertex[1];
		z2 = f2->vertices[i].vertex[2];
		pParticleT->fPos[X] = (x1+pol*(x2-x1));
		pParticleT->fPos[Y] = (y1+pol*(y2-y1));
		pParticleT->fPos[Z] = (z1+pol*(z2-z1));

		ASRotateVectorX(pParticleT->fPos, -90.0f, &pParticleT->fPos);
		ASRotateVectorZ(pParticleT->fPos, pPlayer->fRot[Y], &pParticleT->fPos);

		pParticleT->fPos[X] *= 0.025f;
		pParticleT->fPos[Y] *= 0.025f;
		pParticleT->fPos[Z] *= 0.025f;

		pParticleT->fPos[X] += fPos[X];
		pParticleT->fPos[Y] += fPos[Y];
		pParticleT->fPos[Z] += fPos[Z];
		pParticleT->fVelocity[X] = 0.0f;
		pParticleT->fVelocity[Y] = 0.0f;
		pParticleT->fVelocity[Z] = 0.5f;
		if(Type != PS_Autosave || !bChecked)
		{
			pParticleT->fEngine = (float) (rand() % 100)/100;
			pParticleT->fSize = (float) (rand() % 100)/80;
			pParticleT->fColor[0] = (float) (rand() % 100)/100;
			pParticleT->fColor[1] = (float) (rand() % 100)/100;
			pParticleT->fColor[2] = (float) (rand() % 100)/100;

			pParticleT->fFadeSpeed = (float) (rand() % 100)/5000;
			if(!pParticleT->fFadeSpeed)
				pParticleT->fFadeSpeed = 0.01f;
			pParticleT->fFixPos[X] = pParticleT->fLastPos[X] = pParticleT->fPos[X];
			pParticleT->fFixPos[Y] = pParticleT->fLastPos[Y] = pParticleT->fPos[Y];
			pParticleT->fFixPos[Z] = pParticleT->fLastPos[Z] = pParticleT->fPos[Z];
		}
	}
} // end AS_PARTICLE_SYSTEM::CreateMd2Vertices()

short AS_PARTICLE_SYSTEM::GetFreeParticle(void)
{ // begin AS_PARTICLE_SYSTEM::GetFreeParticle()
	short i;

	for(i = 0; i < iParticles; i++)
		if(!pParticle[i].bAlive)
			return i;
	return -1;
} // end AS_PARTICLE_SYSTEM::GetFreeParticle()


//////////          AS_PARTICLE_MANAGER          //////////////////////////////

void AS_PARTICLE_MANAGER::Check(void)
{ // begin AS_PARTICLE_MANAGER::Check()
	short i;

	if(!_ASConfig->bParticles)
		return;
	for(i = 0; i < iSystems; i++)
	{
		if(!pSystem[i].Check)
			continue;
		pSystem[i].Check(&pSystem[i]);
	}
} // end AS_PARTICLE_MANAGER::Check()

void AS_PARTICLE_MANAGER::Draw(void)
{ // begin AS_PARTICLE_MANAGER::Drawk()
	short i;

	if(!_ASConfig->bParticles)
		return;
	glEnable(GL_BLEND);
	glDisable(GL_CULL_FACE);
	glDisable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);
	glDepthMask(FALSE);
	glEnable(GL_DEPTH_TEST);

	for(i = 0; i < iSystems; i++)
	{
		if(!pSystem[i].Check)
			continue;
		pSystem[i].Draw(&pSystem[i]);
	}

	ASEnableLighting();
	glDepthMask(TRUE);
	glDisable(GL_BLEND);
	glEnable(GL_CULL_FACE);
	if(pLevel && pLevel->Environment.bFog)
		glEnable(GL_FOG);
} // end AS_PARTICLE_MANAGER::Draw()

short AS_PARTICLE_MANAGER::AddNewSystem(AS_PARTICLE_SYSTEM_TYPE Type, short iParticles, ACTOR *pActor, AS_TEXTURE *pTexture, AS_TEXTURE *pSourceTexture)
{ // begin AS_PARTICLE_MANAGER::AddNewSystem()
	AS_PARTICLE_SYSTEM *pSystemT;
	AS_PARTICLE *pParticleT;
	short i, i2, x, y;
	BYTE *pbyData;

	// Add the new system:
	iSystems++;
	pSystem = (AS_PARTICLE_SYSTEM *) realloc(pSystem, sizeof(AS_PARTICLE_SYSTEM)*iSystems);

	pSystemT = &pSystem[iSystems-1];
	memset(pSystemT, 0, sizeof(AS_PARTICLE_SYSTEM));
	
	// Setup the system:		
	pSystemT->iID = iSystems-1;
	pSystemT->pActor = pActor;
	pSystemT->pTexture = pTexture;
	pSystemT->Type = Type;
	pSystemT->iMaxParticles = iParticles;
	if(pSystemT->Type == PS_ASLogo || pSystemT->Type == PS_Autosave)
		pSystemT->iParticles = pSystemT->iMaxParticles;
	else
	{
		pSystemT->iParticles = (short) (pSystemT->iMaxParticles*_ASConfig->fParticleDensity);
		if(!pSystemT->iParticles)
			pSystemT->iParticles = 1;
	}
	pSystemT->pParticle = (AS_PARTICLE *) malloc(sizeof(AS_PARTICLE)*pSystemT->iParticles);
	memset(pSystemT->pParticle, 0, sizeof(AS_PARTICLE)*pSystemT->iParticles);

	switch(pSystemT->Type)
	{
		case PS_Md2Trace:
			pSystemT->Check = ASParticleSystemCheck_Md2Trace;
			pSystemT->Draw = ASParticleSystemDraw_Standart;

			pSystemT->bRandomDelay = FALSE;
			pSystemT->lTimeDelay = pSystemT->lMaxRandomDelay = 30;
			pSystemT->lLiveStartTime = g_lNow;
			pSystemT->lLiveEndTime = -1;
		break;

		case PS_ShotTrace1:
			pSystemT->Check = ASParticleSystemCheck_ShotTrace1;
			pSystemT->Draw = ASParticleSystemDraw_Standart;

			pSystemT->bRandomDelay = FALSE;
			pSystemT->lTimeDelay = pSystemT->lMaxRandomDelay = 10;
			pSystemT->lLiveStartTime = g_lNow;
			pSystemT->lLiveEndTime = -1;
		break;

		case PS_Smoke1:
			pSystemT->Check = ASParticleSystemCheck_Smoke1;
			pSystemT->Draw = ASParticleSystemDraw_Standart;

			pSystemT->bRandomDelay = FALSE;
			pSystemT->lTimeDelay = pSystemT->lMaxRandomDelay = 1;
			pSystemT->lLiveStartTime = g_lNow;
			pSystemT->lLiveEndTime = g_lNow+500;
		break;

		case PS_Smoke2:
			pSystemT->Check = ASParticleSystemCheck_Smoke1;
			pSystemT->Draw = ASParticleSystemDraw_Standart;

			pSystemT->bRandomDelay = FALSE;
			pSystemT->lTimeDelay = pSystemT->lMaxRandomDelay = 50;
			pSystemT->lLiveStartTime = g_lNow;
			pSystemT->lLiveEndTime = -1;
		break;

		case PS_ASLogo:
			for(i = 0, i2 = 0, x = 0, y = 0; i < pSystemT->iParticles; i++, i2 += 3, x++)
			{
				if(x >= pSourceTexture->iWidth)
				{
					y++;
					x = 0;
				}
				pbyData = pSourceTexture->pbyData;
				if(!pbyData[i2] && !pbyData[i2+1] && !pbyData[i2])
					continue;
				pParticleT = &pSystemT->pParticle[i];
				memset(pParticleT, 0, sizeof(AS_PARTICLE));
				pParticleT->fPos[X] = pParticleT->fLastPos[X] = pParticleT->fFixPos[X] = (float) x;
				pParticleT->fPos[Y] = pParticleT->fLastPos[Y] = pParticleT->fFixPos[Y] = (float) y;
				pParticleT->fColor[0] = (float) pbyData[i2]/255;
				pParticleT->fColor[1] = (float) pbyData[i2+1]/255;
				pParticleT->fColor[2] = (float) pbyData[i2+2]/255;
				pParticleT->fSize = 11.0f;
				pParticleT->bAlive = TRUE;
			}
			pSystemT->Check = ASParticleSystemCheck_ASLogo;
			pSystemT->Draw = ASParticleSystemDraw_Standart;
			pSystemT->lTimeDelay = pSystemT->lMaxRandomDelay = 1;
			pSystemT->lLiveStartTime = g_lNow;
		break;

		case PS_Autosave:
			pSystemT->Check = ASParticleSystemCheck_Autosave;
			pSystemT->Draw = ASParticleSystemDraw_Standart;

			pSystemT->lTimeDelay = pSystemT->lMaxRandomDelay = 30;
			pSystemT->lLiveStartTime = g_lNow;
			pSystemT->lLiveEndTime = -1;
		break;

		case PS_WaterWaves:
			pSystemT->Check = ASParticleSystemCheck_WaterWaves;
			pSystemT->Draw = ASParticleSystemDraw_WaterWaves;

			pSystemT->lTimeDelay = pSystemT->lMaxRandomDelay = 30;
			pSystemT->lLiveStartTime = g_lNow;
			pSystemT->lLiveEndTime = -1;
		break;

		case PS_Beamer:
			pSystemT->Check = ASParticleSystemCheck_Beamer;
			pSystemT->Draw = ASParticleSystemDraw_Standart;

			pSystemT->lTimeDelay = pSystemT->lMaxRandomDelay = 30;
		break;

		case PS_X3Acid:
			pSystemT->Check = ASParticleSystemCheck_X3Acid;
			pSystemT->Draw = ASParticleSystemDraw_Standart;

			pSystemT->bRandomDelay = FALSE;
			pSystemT->lTimeDelay = pSystemT->lMaxRandomDelay = 1;
			pSystemT->lLiveStartTime = g_lNow;
			pSystemT->lLiveEndTime = g_lNow+500;
		break;

		case PS_Bubbles:
			pSystemT->Check = ASParticleSystemCheck_Bubbles;
			pSystemT->Draw = ASParticleSystemDraw_Standart;

			pSystemT->bRandomDelay = FALSE;
			pSystemT->lTimeDelay = pSystemT->lMaxRandomDelay = 1;
			pSystemT->lLiveStartTime = g_lNow;
			pSystemT->lLiveEndTime = g_lNow+500;
		break;
	}
	return iSystems-1;
} // end AS_PARTICLE_MANAGER::AddNewSystem()

void AS_PARTICLE_MANAGER::DeleteSystem(short iID)
{ // begin AS_PARTICLE_MANAGER::DeleteSystem()
	short i;

	// Destroy the system:
	SAFE_DELETE(pSystem[iID].pParticle);

	// Update all systems:
	for(i = iID; i < iSystems-1; i++)
	{
		memcpy(&pSystem[i], &pSystem[i+1], sizeof(AS_PARTICLE_SYSTEM));
		pSystem[i].iID--;
	}

	// Romove the last system:
	iSystems--;
	pSystem = (AS_PARTICLE_SYSTEM *) realloc(pSystem, sizeof(AS_PARTICLE_SYSTEM)*iSystems);
} // end AS_PARTICLE_MANAGER::DeleteSystem()

void AS_PARTICLE_MANAGER::Destroy(void)
{ // begin AS_PARTICLE_MANAGER::Destroy()
	short i;

	for(i = 0; i < iSystems; i++)
		SAFE_DELETE(pSystem[i].pParticle);
	SAFE_DELETE(pSystem);
	memset(this, 0, sizeof(AS_PARTICLE_MANAGER));
} // end AS_PARTICLE_MANAGER::Destroy()

void AS_PARTICLE_MANAGER::UpdateSystems(void)
{ // begin AS_PARTICLE_MANAGER::UpdateSystems()
	AS_PARTICLE_SYSTEM *pSystemT;
	short i, i2, iTemp;

	for(i = 0; i < iSystems; i++)
	{
		pSystemT = &pSystem[i];
		if(pSystemT->Type == PS_Autosave)
		{
			iTemp = (short) (pSystemT->iMaxParticles*_ASConfig->fParticleDensity);
			for(i2 = 0; i2 < iTemp; i2++)
				pSystemT->pParticle[i2].bAlive = TRUE;
			for(i2 = iTemp; i2 < pSystemT->iMaxParticles; i2++)
				pSystemT->pParticle[i2].bAlive = FALSE;
			continue;
		}
		iTemp = pSystemT->iParticles;
		pSystemT->iParticles = (short) (pSystemT->iMaxParticles*_ASConfig->fParticleDensity);
		if(!pSystemT->iParticles)
			pSystemT->iParticles = 1;
		pSystemT->pParticle = (AS_PARTICLE *) realloc(pSystemT->pParticle, sizeof(AS_PARTICLE)*pSystemT->iParticles);
		for(i2 = iTemp; i2 < pSystemT->iParticles; i2++)
			memset(&pSystemT->pParticle[i2], 0, sizeof(AS_PARTICLE));
	}
} // end AS_PARTICLE_MANAGER::UpdateSystems()

//////////          Types of partcile systems        //////////////////////////
//////////          Md2Trace       ////////////////////////////////////////////

void ASParticleSystemDraw_Standart(AS_PARTICLE_SYSTEM *pSystemT)
{ // begin ASParticleSystemDraw_Standart)
	AS_PARTICLE *pParticleT;
	short i;

	if(!pSystemT->bActive || (pSystemT->Type != PS_ASLogo && pSystemT->Type != PS_Beamer && !pSystemT->pActor))
		return;
	if(pSystemT->iVertex < 0 || (pLevel && pSystemT->iVertex >= pLevel->Header.iFields))
		return;
	if(pSystemT->Type == PS_Beamer && pLevel && !pLevel->pField[pSystemT->iVertex].bOnScreen)
		return;
	if(pSystemT->Type == PS_Bubbles && !pLevel->Environment.bWater)
		return;
	if(pSystemT->pTexture)
		glBindTexture(GL_TEXTURE_2D, pSystemT->pTexture->iOpenGLID);

	FLOAT3 tl, tr, bl, br;
	FLOAT3 tlT, trT, blT, brT;
	FLOAT3 ptl, ptr, pbl, pbr;
	FLOAT3 x, y;
	float m[16];

	// Get the billboard information: (The particle looks always into the camera)
	glGetFloatv(GL_MODELVIEW_MATRIX, m);
	x[0] = m[0];
	x[1] = m[4];
	x[2] = m[8];
	y[0] = m[1];
	y[1] = m[5];
	y[2] = m[9];
	ASSubVec(x, y, &tl);
	ASAddVec(x, y, &tr);
	ASInvertVec(x, &x);
	ASSubVec(x, y, &bl);
	ASAddVec(x, y, &br);
	ASScaleVec(tl, 0.2f, &tl);
	ASScaleVec(tr, 0.2f, &tr);
	ASScaleVec(bl, 0.2f, &bl);
	ASScaleVec(br, 0.2f, &br);

  	glBegin(GL_QUADS);
		for(i = 0; i < pSystemT->iParticles; i++)
		{
			pParticleT = &pSystemT->pParticle[i];

			if(!pParticleT->bAlive)
				continue;

			// Draw the particle:
			glColor4f(pParticleT->fColor[0], pParticleT->fColor[1], pParticleT->fColor[2], pParticleT->fEngine);

			ASScaleVec(tl, pParticleT->fSize, &tlT);
			ASScaleVec(tr, pParticleT->fSize, &trT);
			ASScaleVec(bl, pParticleT->fSize, &blT);
			ASScaleVec(br, pParticleT->fSize, &brT);

			ASAddVec(pParticleT->fPos, tlT, &ptl);
			ASAddVec(pParticleT->fPos, trT, &ptr);
			ASAddVec(pParticleT->fPos, blT, &pbl);
			ASAddVec(pParticleT->fPos, brT, &pbr);

			glTexCoord2f(0.0f, 1.0f);
			glVertex3fv(ptl);

			glTexCoord2f(1.0f, 1.0f);
			glVertex3fv(ptr);

			glTexCoord2f(1.0f, 0.0f);
			glVertex3fv(pbr);

			glTexCoord2f(0.0f, 0.0f);
			glVertex3fv(pbl);
		}
	glEnd();} // end ASParticleSystemDraw_Standart()

void ASParticleSystemDraw_WaterWaves(AS_PARTICLE_SYSTEM *pSystemT)
{ // begin ASParticleSystemDraw_WaterWaves)
	AS_PARTICLE *pParticleT;
	short i;

	if(!pSystemT->bActive)
		return;
	if(pSystemT->pTexture)
		glBindTexture(GL_TEXTURE_2D, pSystemT->pTexture->iOpenGLID);

	for(i = 0; i < pSystemT->iParticles; i++)
	{
		pParticleT = &pSystemT->pParticle[i];

		if(!pParticleT->bAlive)
			continue;

		// Draw the particle:
		glColor4f(pParticleT->fColor[0], pParticleT->fColor[1], pParticleT->fColor[2], pParticleT->fEngine/10);

		glPushMatrix();
		glTranslatef(pParticleT->fPos[X], pParticleT->fPos[Y], pParticleT->fPos[Z]);
		glScalef(pParticleT->fSize, pParticleT->fSize, pParticleT->fSize);

		glBegin(GL_QUADS);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(-0.5f, -0.5f, 0.0f);

			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(0.5f, -0.5f, 0.0f);

			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(0.5f, 0.5f, 0.0f);

			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(-0.5f, 0.5f, 0.0f);
		glEnd();
		
		glPopMatrix();
	}
} // end ASParticleSystemDraw_WaterWaves()

void ASParticleSystemCheck_Md2Trace(AS_PARTICLE_SYSTEM *pSystemT)
{ // begin ASParticleSystemCheck_Md2Trace()
	AS_PARTICLE *pParticleT;
	ACTOR *pActorT;
	FLOAT3 fPos;
	float fTime;
	short i;

	if(!pSystemT->bActive || !pSystemT->pActor || !pSystemT->pActor->bActive)
		return;
	pActorT = pSystemT->pActor;

	// Check the system:
	if(pSystemT->lLiveEndTime != -1 && g_lNow > pSystemT->lLiveEndTime)
		pSystemT->bGoingInActive = TRUE;
	if(pSystemT->bGoingInActive)
	{
		for(i = 0; i < pSystemT->iParticles; i++)
		{
			if(pSystemT->pParticle[i].bAlive)
				break;
		}
		if(i >= pSystemT->iParticles)
		{
			pSystemT->bActive = FALSE;
			pSystemT->bGoingInActive = FALSE;
			return;
		}
	}
	else
	if(g_lNow > pSystemT->lNextTime)
	{ // The system should be updated:
		if(pSystemT->bRandomDelay)
		{ // Get the time do the next update per random:
			pSystemT->lTimeDelay = rand() % pSystemT->lMaxRandomDelay;
		}
		pSystemT->lLastTime = g_lNow;
		pSystemT->lNextTime = pSystemT->lLastTime+pSystemT->lTimeDelay;
		// 
		switch(pActorT->byType)
		{
			case ACTOR_PLAYER:
				fPos[X] = pPlayer->fWorldPos[X]+0.5f;
				fPos[Y] = pPlayer->fWorldPos[Y]+0.5f;
				fPos[Z] = pPlayer->fWorldPos[Z]-0.6f;
				pSystemT->CreateMd2Vertices(pXeModel, pActorT->iAniStep, pActorT->iNextAniStep, pPlayer->fModelInterpolation, fPos);
			break;
		}
	}

	fTime = (float) g_lDeltatime/1000;
	FLOAT3 fRayDirection;
	
	// Ray direction for the 'normal' test points:
	fRayDirection[X] = 0.0f;
	fRayDirection[Y] = 0.0f;
	fRayDirection[Z] = 1.0f;

	FLOAT3 fPoint;
	float fHeight;
	fPoint[X] = fPoint[Y] = fPoint[Z] = 0.0f;


	// Check each particle:
	for(i = 0; i < pSystemT->iParticles; i++)
	{
		pParticleT = &pSystemT->pParticle[i];

		if(!pParticleT->bAlive)
			continue;
		
		// Check the particle:
		pParticleT->fEngine -= (float) pParticleT->fFadeSpeed*g_lDeltatime/10.0f;
		if(pParticleT->fEngine <= 0.0f)
		{ // The particle is now 'death':
			pParticleT->bAlive = FALSE;
			continue;
		}
		memcpy(pParticleT->fLastPos, pParticleT->fPos, sizeof(FLOAT3));

		pParticleT->fVelocity[X] += pParticleT->fVelocity[X]*fTime;
		pParticleT->fVelocity[Y] += pParticleT->fVelocity[Y]*fTime;
		pParticleT->fVelocity[Z] += pParticleT->fVelocity[Z]*fTime;
		pParticleT->fPos[X] += pParticleT->fVelocity[X]*fTime;
		pParticleT->fPos[Y] += pParticleT->fVelocity[Y]*fTime;
		pParticleT->fPos[Z] += pParticleT->fVelocity[Z]*fTime;
		
		fHeight = pLevel->FastComputeHeight(pParticleT->fPos[X], pParticleT->fPos[Y], FACE_FLOOR);
		if(fHeight < pParticleT->fPos[Z])
			pParticleT->bAlive = FALSE;
	}
} // end ASParticleSystemCheck_Md2Trace()

void ASParticleSystemCheck_ShotTrace1(AS_PARTICLE_SYSTEM *pSystemT)
{ // begin ASParticleSystemCheck_ShotTrace1()
	AS_PARTICLE *pParticleT;
	ACTOR *pActorT;
	short i, i2;

	if(!pSystemT->bActive || !pSystemT->pActor)
		return;
	pActorT = pSystemT->pActor;

	if(!pActorT->bActive || pActorT->bGoingDeath)
		pSystemT->bGoingInActive = TRUE;
	if(pSystemT->lLiveEndTime != -1 && g_lNow > pSystemT->lLiveEndTime)
		pSystemT->bGoingInActive = TRUE;
	// Check the system:
	if(pSystemT->bGoingInActive)
	{
		for(i = 0; i < pSystemT->iParticles; i++)
		{
			if(pSystemT->pParticle[i].bAlive)
				break;
		}
		if(i >= pSystemT->iParticles)
		{ // Destroy this system:
   			ParticleManager.DeleteSystem(pSystemT->iID);
			return;
		}
	}
	else
	if(g_lNow > pSystemT->lNextTime)
	{ // The system should be updated:
		if(pSystemT->bRandomDelay)
		{ // Get the time do the next update per random:
			pSystemT->lTimeDelay = rand() % pSystemT->lMaxRandomDelay;
		}
		pSystemT->lLastTime = g_lNow;
		pSystemT->lNextTime = pSystemT->lLastTime+pSystemT->lTimeDelay;
		// 
		i2 = pSystemT->GetFreeParticle();
		if(i2 != -1)
		{
			pParticleT = &pSystemT->pParticle[i2];
			pParticleT->bAlive = TRUE;
			pParticleT->fEngine = 3.0f;
			pParticleT->fColor[0] = 1.0f;
			pParticleT->fColor[1] = 0.5f;
			pParticleT->fColor[2] = 0.5f;
			pParticleT->fFadeSpeed = 0.1f;
			pParticleT->fSize = 2.0f;
			pParticleT->fPos[X] = pSystemT->pActor->fWorldPos[X]+0.5f;
			pParticleT->fPos[Y] = pSystemT->pActor->fWorldPos[Y]+0.5f;
			pParticleT->fPos[Z] = pSystemT->pActor->fWorldPos[Z]-0.5f;
		}
	}

	// Check each particle:
	for(i = 0; i < pSystemT->iParticles; i++)
	{
		pParticleT = &pSystemT->pParticle[i];

		if(!pParticleT->bAlive)
			continue;
		
		// Check the particle:
		pParticleT->fEngine -= (float) pParticleT->fFadeSpeed*g_lDeltatime/10.0f;
		if(pParticleT->fEngine <= 0.0f)
		{ // The particle is now 'death':
			pParticleT->bAlive = FALSE;
			continue;
		}
		memcpy(pParticleT->fLastPos, pParticleT->fPos, sizeof(FLOAT3));
		pParticleT->fPos[Z] += (float) g_lDeltatime/5000;
	}
} // end ASParticleSystemCheck_ShotTrace1()

void ASParticleSystemCheck_Smoke1(AS_PARTICLE_SYSTEM *pSystemT)
{ // begin ASParticleSystemCheck_Smoke1()
	AS_PARTICLE *pParticleT;
	ACTOR *pActorT;
	short i, i2;
	float fTime, fHeight;

	pSystemT->iVertex = 0;
	
	if(!pSystemT->bActive)
		return;
	pActorT = pSystemT->pActor;

	if(!pActorT->bActive || pActorT->bGoingDeath)
		pSystemT->bGoingInActive = TRUE;
	// Check the system:
	if(pSystemT->lLiveEndTime != -1 && g_lNow > pSystemT->lLiveEndTime)
		pSystemT->bGoingInActive = TRUE;
	if(pSystemT->bGoingInActive)
	{
		for(i = 0; i < pSystemT->iParticles; i++)
		{
			if(pSystemT->pParticle[i].bAlive)
				break;
		}
		if(i >= pSystemT->iParticles)
		{ // Destroy this system:
   			ParticleManager.DeleteSystem(pSystemT->iID);
			return;
		}
	}
	else
	if(g_lNow > pSystemT->lNextTime)
	{ // The system should be updated:
		if(pSystemT->bRandomDelay)
		{ // Get the time do the next update per random:
			pSystemT->lTimeDelay = rand() % pSystemT->lMaxRandomDelay;
		}
		pSystemT->lLastTime = g_lNow;
		pSystemT->lNextTime = pSystemT->lLastTime+pSystemT->lTimeDelay;
		// 
		i2 = pSystemT->GetFreeParticle();
		if(i2 != -1)
		{
			pParticleT = &pSystemT->pParticle[i2];
			pParticleT->bAlive = TRUE;
			pParticleT->fEngine = (float) (pSystemT->lLiveEndTime-g_lNow)/(pSystemT->lLiveEndTime-pSystemT->lLiveStartTime)*2;
			pParticleT->fColor[0] = 1.0f;
			pParticleT->fColor[1] = 1.0f;
			pParticleT->fColor[2] = 1.0f;
			pParticleT->fFadeSpeed = 0.01f;
			pParticleT->fSize = 5.0f;
			if(pActorT)
			{ // The smoke is connected with an point of an actor:
				FLOAT3 fPos;
				
				if(pActorT->byType == ACTOR_PLAYER)
				{
					pParticleT->fSize = 1.0f;
					fPos[X] = pActorT->fWorldPos[X]+0.5f;
					fPos[Y] = pActorT->fWorldPos[Y]+0.5f;
					fPos[Z] = pActorT->fWorldPos[Z]-0.6f;
					if(pActorT->iAniStep < pXeWeaponModel->header.numFrames &&
					   pActorT->iNextAniStep < pXeWeaponModel->header.numFrames )
						ASGetMd2Vertex(pXeWeaponModel, pActorT->iAniStep, pActorT->iNextAniStep, pActorT->fModelInterpolation, fPos, 0.025f,
									   -90.0f, pPlayer->fRot[Y], 0.0f, pSystemT->iVertex, &pParticleT->fPos);
					pParticleT->fVelocity[Z] = -0.5f;
				}
				if(pActorT->byType == ACTOR_ENEMY_HIRO)
				{
					pParticleT->fSize = 5.0f;
					fPos[X] = pActorT->fWorldPos[X]+0.3f;
					fPos[Y] = pActorT->fWorldPos[Y]+0.2f;
					fPos[Z] = pActorT->fWorldPos[Z]-0.3f;
					pSystemT->iVertex = 141;
					if(pActorT->iAniStep < pHiroModel->header.numFrames &&
					   pActorT->iNextAniStep < pHiroModel->header.numFrames )
						ASGetMd2Vertex(pHiroModel, pActorT->iAniStep, pActorT->iNextAniStep, pActorT->fModelInterpolation, fPos, 0.025f,
									   -90.0f, pActorT->fRot[Y], 0.0f, pSystemT->iVertex, &pParticleT->fPos);
					if(!(rand() % 2))
						pParticleT->fVelocity[X] = (float) (rand() % 100)/100;
					else
						pParticleT->fVelocity[X] = (float) -(rand() % 100)/100;
					if(!(rand() % 2))
						pParticleT->fVelocity[Y] = (float) (rand() % 100)/100;
					else
						pParticleT->fVelocity[Y] = (float) -(rand() % 100)/100;
					pParticleT->fVelocity[Z] = 0.3f;
				}
			}
			else
			{
				pParticleT->fPos[X] = pSystemT->fStartPos[X];
				pParticleT->fPos[Y] = pSystemT->fStartPos[Y];
				pParticleT->fPos[Z] = pSystemT->fStartPos[Z];
			}
		}
	}

	fTime = (float) g_lDeltatime/1000;
	// Check each particle:
	if(pActorT->byType == ACTOR_PLAYER)
	{
		for(i = 0; i < pSystemT->iParticles; i++)
		{
			pParticleT = &pSystemT->pParticle[i];

			if(!pParticleT->bAlive)
				continue;
			
			// Check the particle:
			pParticleT->fEngine -= (float) pParticleT->fFadeSpeed*g_lDeltatime/10.0f;
			if(pParticleT->fEngine <= 0.0f)
			{ // The particle is now 'death':
				pParticleT->bAlive = FALSE;
				continue;
			}
			pParticleT->fSize = 1/pParticleT->fEngine;

			pParticleT->fColor[0] = 1/pParticleT->fSize;
			pParticleT->fColor[1] = 1/pParticleT->fSize;
			pParticleT->fColor[2] = 1/pParticleT->fSize;
			pParticleT->fVelocity[X] += pParticleT->fVelocity[X]*fTime;
			pParticleT->fVelocity[Y] += pParticleT->fVelocity[Y]*fTime;
			pParticleT->fVelocity[Z] += pParticleT->fVelocity[Z]*fTime;
			pParticleT->fPos[X] += pParticleT->fVelocity[X]*fTime;
			pParticleT->fPos[Y] += pParticleT->fVelocity[Y]*fTime;
			pParticleT->fPos[Z] += pParticleT->fVelocity[Z]*fTime;
		}
	}
	if(pActorT->byType == ACTOR_ENEMY_HIRO)
	{
		for(i = 0; i < pSystemT->iParticles; i++)
		{
			pParticleT = &pSystemT->pParticle[i];

			if(!pParticleT->bAlive)
				continue;
			
			// Check the particle:
			pParticleT->fEngine -= (float) pParticleT->fFadeSpeed*g_lDeltatime/10.0f;
			if(pParticleT->fEngine <= 0.0f)
			{ // The particle is now 'death':
				pParticleT->bAlive = FALSE;
				continue;
			}
			pParticleT->fColor[0] = 1/pParticleT->fSize;
			pParticleT->fColor[1] = 1/pParticleT->fSize;
			pParticleT->fColor[2] = 1/pParticleT->fSize;
			pParticleT->fVelocity[X] += pParticleT->fVelocity[X]*fTime;
			pParticleT->fVelocity[Y] += pParticleT->fVelocity[Y]*fTime;
			pParticleT->fVelocity[Z] += pParticleT->fVelocity[Z]*fTime;
			pParticleT->fPos[X] += pParticleT->fVelocity[X]*fTime;
			pParticleT->fPos[Y] += pParticleT->fVelocity[Y]*fTime;
			pParticleT->fPos[Z] += pParticleT->fVelocity[Z]*fTime;

			fHeight = pLevel->FastComputeHeight(pParticleT->fPos[X], pParticleT->fPos[Y], FACE_FLOOR);
			if(fHeight < pParticleT->fPos[Z])
				pParticleT->bAlive = FALSE;
		}
	}
} // end ASParticleSystemCheck_Smoke1()

void ASParticleSystemCheck_ASLogo(AS_PARTICLE_SYSTEM *pSystemT)
{ // begin ASParticleSystemCheck_ASLogo()
	AS_PARTICLE *pParticleT;
	ACTOR *pActorT;
	float fTime;
	short i, i2;

	if(!pSystemT->bActive)
		return;
	pActorT = pSystemT->pActor;

	if(pSystemT->bGoingInActive)
	{
		for(i = 0; i < pSystemT->iParticles; i++)
		{
			if(pSystemT->pParticle[i].bAlive)
				break;
		}
		if(i >= pSystemT->iParticles)
		{ // Destroy this system:
   			pSystemT->bActive = FALSE;
			return;
		}
	}
	fTime = (float) g_lDeltatime/1000;
	// Check each particle:
	for(i = 0; i < pSystemT->iParticles; i++)
	{
		pParticleT = &pSystemT->pParticle[i];

		if(!pParticleT->bAlive)
			continue;
		for(i2 = 0; i2 < 3; i2++)
		{
			if(pParticleT->fPos[i2] > pParticleT->fLastPos[i2])
			{
				pParticleT->fVelocity[i2] -= (float) g_lDeltatime/10000;
				if(!pParticleT->bTemp[i2])
				{
					if(pParticleT->fPos[i2]+pParticleT->fVelocity[i2]*((float) g_lDeltatime/100) 
					  < pParticleT->fLastPos[i2])
					{
						pParticleT->bTemp[i2] = TRUE;
						pParticleT->fVelocity[i2] = 0.0f;
					}
				}
			}
			else
			if(pParticleT->fPos[i2] < pParticleT->fLastPos[i2])
			{
				pParticleT->fVelocity[i2] += (float) g_lDeltatime/10000;
				if(!pParticleT->bTemp[i2])
				{
					if(pParticleT->fPos[i2]+pParticleT->fVelocity[i2]*((float) g_lDeltatime/100) 
					  > pParticleT->fLastPos[i2])
					{
						pParticleT->bTemp[i2] = TRUE;
						pParticleT->fVelocity[i2] = 0.0f;
					}
				}
			}

			if(pParticleT->fVelocity[i2] > 1.5f)
				pParticleT->fVelocity[i2] = 1.5f;
			if(pParticleT->fVelocity[i2] < -1.5f)
				pParticleT->fVelocity[i2] = -1.5f;

			pParticleT->fPos[i2] += pParticleT->fVelocity[i2]*((float) g_lDeltatime/100);

			if((pParticleT->fPos[i2] <= pParticleT->fLastPos[i2]+1.0f &&
			    pParticleT->fPos[i2] >= pParticleT->fLastPos[i2]-1.0f) ||
				pParticleT->fPos[i2] >= pParticleT->fFixPos[i2]+0.3f ||
				pParticleT->fPos[i2] <= pParticleT->fFixPos[i2]-0.3f)
			{
				if(pParticleT->fLastPos[i2] != pParticleT->fFixPos[i2] && !pSystemT->bGoingInActive)
					pParticleT->fVelocity[i2] *= 0.2f;
				if((pParticleT->fPos[i2] > pParticleT->fFixPos[i2]+0.3f ||
				    pParticleT->fPos[i2] < pParticleT->fFixPos[i2]-0.3f) &&
					!pSystemT->bGoingInActive)
				   pParticleT->fLastPos[i2] = pParticleT->fFixPos[i2];
				else
				{
					if(!(rand() % 2))
						pParticleT->fLastPos[i2] += (float) 10+(rand() % 1000)/100;
					else
						pParticleT->fLastPos[i2] -= (float) 10+(rand() % 1000)/100;
				}
			}
			if(!pSystemT->bGoingInActive)
			{
				if(pParticleT->fEngine != 1.0f)
				{
					pParticleT->fEngine += (float) g_lDeltatime/100000;
					if(pParticleT->fEngine > 1.0f)
						pParticleT->fEngine = 1.0f;
				}
			}
			else
			{
				pParticleT->fEngine -= (float) g_lDeltatime/50000;
				if(pParticleT->fEngine < 0.0f)
					pParticleT->bAlive = FALSE;
			}
		}
	}
} // end ASParticleSystemCheck_ASLogo()

void ASParticleSystemCheck_Autosave(AS_PARTICLE_SYSTEM *pSystemT)
{ // begin ASParticleSystemCheck_Autosave()
	AS_PARTICLE *pParticleT;
	ACTOR *pActorT;
	short i, i2;
	float fTime;

	if(!pSystemT->bActive || !pSystemT->pActor || !pSystemT->pActor->bActive)
		return;
	pActorT = pSystemT->pActor;

	// Check the system:
	if(pSystemT->lLiveEndTime != -1 && g_lNow > pSystemT->lLiveEndTime)
		pSystemT->bGoingInActive = TRUE;
	if(pSystemT->bGoingInActive)
	{
		for(i = 0; i < pSystemT->iParticles; i++)
		{
			if(pSystemT->pParticle[i].bAlive)
				break;
		}
		if(i >= pSystemT->iParticles)
		{
			pSystemT->bActive = FALSE;
			pSystemT->bGoingInActive = FALSE;
			return;
		}
	}
	else
	if(pSystemT->bUpdate)
	{ // The system should be updated:
		pSystemT->bUpdate = FALSE;
		if(pSystemT->bRandomDelay)
		{ // Get the time do the next update per random:
			pSystemT->lTimeDelay = rand() % pSystemT->lMaxRandomDelay;
		}
		pSystemT->lLastTime = g_lNow;
		pSystemT->lNextTime = pSystemT->lLastTime+pSystemT->lTimeDelay;
		// 
		switch(pActorT->byType)
		{
			case ACTOR_PLAYER:

				FLOAT3 fPos;
				
				fPos[X] = pActorT->fWorldPos[X]+0.5f;
				fPos[Y] = pActorT->fWorldPos[Y]+0.5f;
				fPos[Z] = pActorT->fWorldPos[Z]-0.6f;
				for(i = 0; i < pSystemT->iParticles; i++)
				{
					pParticleT = &pSystemT->pParticle[i];
					for(i2 = 0; i2 < 3; i2++)
						pParticleT->fLastPos[i2] = pParticleT->fPos[i2];
					pParticleT->bAlive = FALSE;
				}
				if(pActorT->fModelInterpolation > 1.0f)
					pActorT->fModelInterpolation = 0.0f;
				pSystemT->CreateMd2Vertices(pXeModel, pActorT->iAniStep, pActorT->iNextAniStep, pActorT->fModelInterpolation, fPos);
				pSystemT->bChecked = TRUE;
				for(i = 0; i < pSystemT->iParticles; i++)
				{
					pParticleT = &pSystemT->pParticle[i];
					for(i2 = 0; i2 < 3; i2++)
					{
						pParticleT->fFixPos[i2] = pParticleT->fPos[i2];
						pParticleT->fPos[i2] = pParticleT->fLastPos[i2];
					}
				}

			break;
		}
	}

	fTime = (float) g_lDeltatime/1000;

	// Check each particle:
	for(i = 0; i < pSystemT->iParticles; i++)
	{
		pParticleT = &pSystemT->pParticle[i];

		if(!pParticleT->bAlive)
			continue;
		
		for(i2 = 0; i2 < 3; i2++)
		{
			if(pParticleT->fPos[i2] > pParticleT->fLastPos[i2])
				pParticleT->fVelocity[i2] -= (float) g_lDeltatime/100;
			else
			if(pParticleT->fPos[i2] < pParticleT->fLastPos[i2])
				pParticleT->fVelocity[i2] += (float) g_lDeltatime/100;

			if(pParticleT->fPos[i2] < pParticleT->fFixPos[i2]+0.5f &&
			   pParticleT->fPos[i2] > pParticleT->fFixPos[i2]-0.5f)
		    {
				if(pParticleT->fVelocity[i2] > 1.5f)
					pParticleT->fVelocity[i2] = 1.5f;
				if(pParticleT->fVelocity[i2] < -1.5f)
					pParticleT->fVelocity[i2] = -1.5f;
			}
			else
			{
				pParticleT->fVelocity[i2] *= g_lDeltatime/5;
				if(pParticleT->fVelocity[i2] > 500.0f)
					pParticleT->fVelocity[i2] = 500.0f;
				if(pParticleT->fVelocity[i2] < -500.0f)
					pParticleT->fVelocity[i2] = -500.0f;
			}
			pParticleT->fPos[i2] += pParticleT->fVelocity[i2]*((float) g_lDeltatime/10000);

			if((pParticleT->fPos[i2] <= pParticleT->fLastPos[i2]+0.4f &&
			    pParticleT->fPos[i2] >= pParticleT->fLastPos[i2]-0.4f) ||
				pParticleT->fPos[i2] >= pParticleT->fFixPos[i2]+0.1f ||
				pParticleT->fPos[i2] <= pParticleT->fFixPos[i2]-0.1)
			{
				if(pParticleT->fLastPos[i2] != pParticleT->fFixPos[i2] && !pSystemT->bGoingInActive)
					pParticleT->fVelocity[i2] *= 0.2f;
			    if(pParticleT->fVelocity[i2] >= 500.0f || pParticleT->fVelocity[i2] <= -500.0f)
				{
					pParticleT->fPos[i2] = pParticleT->fFixPos[i2];
					pParticleT->fLastPos[i2] = pParticleT->fFixPos[i2];
				}
				if(pParticleT->fPos[i2] > pParticleT->fFixPos[i2]+0.01f ||
				    pParticleT->fPos[i2] < pParticleT->fFixPos[i2]-0.01f)
				   pParticleT->fLastPos[i2] = pParticleT->fFixPos[i2];
				else
				{
					if(!(rand() % 2))
						pParticleT->fLastPos[i2] += (float) 10+(rand() % 100)/10000;
					else
						pParticleT->fLastPos[i2] -= (float) 10+(rand() % 100)/10000;
				}
			}
		}
	}
} // end ASParticleSystemCheck_Autosave()

void ASParticleSystemCheck_WaterWaves(AS_PARTICLE_SYSTEM *pSystemT)
{ // begin ASParticleSystemCheck_WaterWaves()
	AS_PARTICLE *pParticleT;
	ACTOR *pActorT;
	short i;

	if(!pSystemT->bActive)
		return;
	pActorT = pSystemT->pActor;
	if(!pLevel->Environment.bWater)
	{
		for(i = 0; i < pSystemT->iParticles; i++)
			pSystemT->pParticle[i].bAlive = FALSE;
		return;
	}
	// Check each particle:
	for(i = 0; i < pSystemT->iParticles; i++)
	{
		pParticleT = &pSystemT->pParticle[i];

		if(!pParticleT->bAlive)
			continue;
		
		// Check the particle:
		pParticleT->fPos[Z] = pLevel->Environment.fWaterActualHeight;
		pParticleT->fEngine -= (float) pParticleT->fFadeSpeed*g_lDeltatime/10.0f;
		pParticleT->fSize += (float) pParticleT->fFadeSpeed*g_lDeltatime/3.0f;
		if(pParticleT->fEngine <= 0.0f)
		{ // The particle is now 'death':
			pParticleT->bAlive = FALSE;
			continue;
		}
	}
} // end ASParticleSystemCheck_WaterWaves()

void ASParticleSystemCheck_Beamer(AS_PARTICLE_SYSTEM *pSystemT)
{ // begin ASParticleSystemCheck_Beamer()
	AS_PARTICLE *pParticleT;
	float fTime, fHeight;
	short i, i2;

	if(pSystemT->iVertex < 0 || pSystemT->iVertex >= pLevel->Header.iFields)
   	{
		ParticleManager.DeleteSystem(pSystemT->iID);
		return;
	}
	if(!pSystemT->bActive || !pLevel->pField[pSystemT->iVertex].bOnScreen)
		return;
	if(!pLevel->pField[pSystemT->iVertex].bActive ||
	   pLevel->pField[pSystemT->iVertex].pBridgeActor ||
	   !pLevel->pField[pSystemT->iVertex].pSurface[FACE_FLOOR][0]->Header.bBeamer ||
	    pLevel->pField[pSystemT->iVertex].iBeamerTarget == -1)
	{
		for(i = 0; i < pSystemT->iParticles; i++)
		{
			if(pSystemT->pParticle[i].bAlive)
				break;
		}
		if(i >= pSystemT->iParticles)
		{ // Destroy this system:
   			ParticleManager.DeleteSystem(pSystemT->iID);
			return;
		}
	}
	fTime = (float) g_lDeltatime/1000;
	// Check each particle:
	for(i = 0; i < pSystemT->iParticles; i++)
	{
		pParticleT = &pSystemT->pParticle[i];

		if(!pParticleT->bAlive)
		{
			if(!pLevel->pField[pSystemT->iVertex].bActive ||
			   pLevel->pField[pSystemT->iVertex].pBridgeActor ||
			   !pLevel->pField[pSystemT->iVertex].pSurface[FACE_FLOOR][0]->Header.bBeamer ||
			    pLevel->pField[pSystemT->iVertex].iBeamerTarget == -1)
				continue;
			pParticleT->fEngine = 0.1f+(rand() % 100)/50;
			pParticleT->fSize = 0.1f;
			pParticleT->bAlive = TRUE;
			memcpy(pParticleT->fPos, pSystemT->fStartPos, sizeof(FLOAT3));
			pParticleT->fPos[Z] -= 2.0f;
			if(pLevel->pField[pSystemT->iVertex].fBeamerPower == 1.0f &&
			   !(rand() % 5))
			{
				pParticleT->fPos[Z] += 0.2f;
				pParticleT->fVelocity[Z] = -0.2f+(rand() % 50)/1000;
				for(i2 = 0; i2 < 2; i2++)
				{
					if(!(rand() % 2))
						pParticleT->fVelocity[i2] = (float) (rand() % 50)/100;
					else
						pParticleT->fVelocity[i2] = -(float) (rand() % 50)/100;
				}
				pParticleT->fFadeSpeed = (float) (rand() % 100)/10000;
				if(pParticleT->fFadeSpeed > 0.02f || pParticleT->fFadeSpeed < 0.005f)
					pParticleT->fFadeSpeed = 0.01f;
				pParticleT->fColor[0] = 0.2f;
				pParticleT->fColor[1] = 1.0f;
				pParticleT->fColor[2] = 0.2f;
			}
			else
			{
				pParticleT->fVelocity[Z] = 0.2f+(rand() % 50)/1000;
				for(i2 = 0; i2 < 2; i2++)
				{
					if(!(rand() % 2))
						pParticleT->fVelocity[i2] = (float) (rand() % 50)/1000;
					else
						pParticleT->fVelocity[i2] = -(float) (rand() % 50)/1000;
				}
				pParticleT->fFadeSpeed = (float) (rand() % 100)/10000;
				if(pParticleT->fFadeSpeed > 0.02f || pParticleT->fFadeSpeed < 0.005f)
					pParticleT->fFadeSpeed = 0.001f;
				pParticleT->fColor[0] = pLevel->pField[pSystemT->iVertex].fBeamerPower*1.5f;
				pParticleT->fColor[1] = pLevel->pField[pSystemT->iVertex].fBeamerPower;
				pParticleT->fColor[2] = pLevel->pField[pSystemT->iVertex].fBeamerPower;
			}
			// Check, if the other side is free:
			if((pLevel->pField[pLevel->pField[pSystemT->iVertex].iBeamerTarget].pActor ||
			    pLevel->pField[pLevel->pField[pSystemT->iVertex].iBeamerTarget].pEnemy ||
			    pLevel->pField[pLevel->pField[pSystemT->iVertex].iBeamerTarget].bWall) &&
			    pLevel->pField[pSystemT->iVertex].fBeamerPower == 1.0f)
			{ // NO!!
				pParticleT->fColor[0] = 1.0f;
				pParticleT->fColor[1] = 0.0f;
				pParticleT->fColor[2] = 0.0f;
				pParticleT->fSize *= 0.2f;
				for(i2 = 0; i2 < 2; i2++)
				{
					pParticleT->fVelocity[i2] *= 20.0f;
				}
			}
			continue;
		}
		// Check the particle:
		pParticleT->fEngine -= (float) pParticleT->fFadeSpeed*g_lDeltatime/10.0f;
		pParticleT->fSize += (float) pParticleT->fFadeSpeed*g_lDeltatime/2.0f;
		if(pParticleT->fEngine <= 0.0f)
		{ // The particle is now 'death':
			pParticleT->bAlive = FALSE;
			continue;
		}

		if(pParticleT->fVelocity[2] > 0.0f)
			pParticleT->fVelocity[2] += (float) g_lDeltatime/1000;
		else
			pParticleT->fVelocity[2] -= (float) g_lDeltatime/1000;
		pParticleT->fVelocity[2] += pParticleT->fVelocity[2]*fTime;
		pParticleT->fPos[2] += (float) pParticleT->fVelocity[2]*fTime;
		for(i2 = 0; i2 < 2; i2++)
		{
			if(pParticleT->fVelocity[i2] > 0.0f)
				pParticleT->fVelocity[i2] += (float) g_lDeltatime/1000;
			else
				pParticleT->fVelocity[i2] -= (float) g_lDeltatime/1000;
			pParticleT->fVelocity[i2] += pParticleT->fVelocity[i2]*fTime;
			pParticleT->fPos[i2] += pParticleT->fVelocity[i2]*fTime/10;
		}
		fHeight = pLevel->FastComputeHeight(pParticleT->fPos[X], pParticleT->fPos[Y], FACE_FLOOR);
		if(fHeight < pParticleT->fPos[Z])
			pParticleT->bAlive = FALSE;
	}
} // end ASParticleSystemCheck_Beamer()

void ASParticleSystemCheck_X3Acid(AS_PARTICLE_SYSTEM *pSystemT)
{ // begin ASParticleSystemCheck_X3Acid()
	AS_PARTICLE *pParticleT;
	ACTOR *pActorT;
	short i, i2;
	float fTime;

	if(!pSystemT->bActive)
		return;
	pActorT = pSystemT->pActor;

	if(!pActorT->bActive || pActorT->bGoingDeath)
		pSystemT->bGoingInActive = TRUE;
	// Check the system:
	if(pSystemT->lLiveEndTime != -1 && g_lNow > pSystemT->lLiveEndTime)
		pSystemT->bGoingInActive = TRUE;
	if(pSystemT->bGoingInActive)
	{
		for(i = 0; i < pSystemT->iParticles; i++)
		{
			if(pSystemT->pParticle[i].bAlive)
				break;
		}
		if(i >= pSystemT->iParticles)
		{ // Destroy this system:
   			ParticleManager.DeleteSystem(pSystemT->iID);
			return;
		}
	}
	else
	if(g_lNow > pSystemT->lNextTime)
	{ // The system should be updated:
		if(pSystemT->bRandomDelay)
		{ // Get the time do the next update per random:
			pSystemT->lTimeDelay = rand() % pSystemT->lMaxRandomDelay;
		}
		pSystemT->lLastTime = g_lNow;
		pSystemT->lNextTime = pSystemT->lLastTime+pSystemT->lTimeDelay;
		// 
		i2 = pSystemT->GetFreeParticle();
		if(i2 != -1)
		{
			pParticleT = &pSystemT->pParticle[i2];
			pParticleT->bAlive = TRUE;
			pParticleT->fEngine = (float) (pSystemT->lLiveEndTime-g_lNow)/(pSystemT->lLiveEndTime-pSystemT->lLiveStartTime)*2;
			pParticleT->fColor[0] = 1.0f;
			pParticleT->fColor[1] = 1.0f;
			pParticleT->fColor[2] = 1.0f;
			pParticleT->fFadeSpeed = 0.005f;
			pParticleT->fSize = 5.0f;
			if(pActorT)
			{ // The smoke is connected with an point of an actor:
				FLOAT3 fPos;
				
				pParticleT->fSize = 5.0f;
				fPos[X] = pActorT->fWorldPos[X]+0.5f;
				fPos[Y] = pActorT->fWorldPos[Y]+0.5f;
				fPos[Z] = pActorT->fWorldPos[Z]-0.4f;
				pSystemT->iVertex = 161;
				if(pActorT->iAniStep < pX3Model->header.numFrames &&
				   pActorT->iNextAniStep < pX3Model->header.numFrames)
					ASGetMd2Vertex(pX3Model, pActorT->iAniStep, pActorT->iNextAniStep, pActorT->fModelInterpolation, fPos, 0.02f,
								   -90.0f, pActorT->fRot[Y], 0.0f, pSystemT->iVertex, &pParticleT->fPos);
				if(!(rand() % 2))
					pParticleT->fVelocity[X] = (float) (rand() % 100)/100;
				else
					pParticleT->fVelocity[X] = (float) -(rand() % 100)/100;
				if(!(rand() % 2))
					pParticleT->fVelocity[Y] = (float) (rand() % 100)/100;
				else
					pParticleT->fVelocity[Y] = (float) -(rand() % 100)/100;
				pParticleT->fVelocity[Z] = 0.3f;
				switch(pActorT->byDirection)
				{
					case 0:
						pParticleT->fVelocity[X] *= 2;
						if(pParticleT->fVelocity[X] < 0.0f)
							pParticleT->fVelocity[X] = -pParticleT->fVelocity[X];
					break;

					case 1:
						pParticleT->fVelocity[Y] *= 2;
						if(pParticleT->fVelocity[Y] < 0.0f)
							pParticleT->fVelocity[Y] = -pParticleT->fVelocity[Y];
					break;

					case 2:
						pParticleT->fVelocity[X] *= 2;
						if(pParticleT->fVelocity[X] > 0.0f)
							pParticleT->fVelocity[X] = -pParticleT->fVelocity[X];
					break;

					case 3:
						pParticleT->fVelocity[Y] *= 2;
						if(pParticleT->fVelocity[Y] > 0.0f)
							pParticleT->fVelocity[Y] = -pParticleT->fVelocity[Y];
					break;
				}
			}
			else
			{
				pParticleT->fPos[X] = pSystemT->fStartPos[X];
				pParticleT->fPos[Y] = pSystemT->fStartPos[Y];
				pParticleT->fPos[Z] = pSystemT->fStartPos[Z];
			}
		}
	}

	fTime = (float) g_lDeltatime/1000;
	// Check each particle:
	for(i = 0; i < pSystemT->iParticles; i++)
	{
		pParticleT = &pSystemT->pParticle[i];

		if(!pParticleT->bAlive)
			continue;
		
		// Check the particle:
		pParticleT->fEngine -= (float) pParticleT->fFadeSpeed*g_lDeltatime/10.0f;
		if(pParticleT->fEngine <= 0.8f)
		{ // The particle is now 'death':
			pParticleT->bAlive = FALSE;
			continue;
		}
		pParticleT->fSize = 4/pParticleT->fEngine;

		pParticleT->fColor[0] = 1/pParticleT->fSize;
		pParticleT->fColor[1] = 1/pParticleT->fSize;
		pParticleT->fColor[2] = 1/pParticleT->fSize;
		pParticleT->fVelocity[X] += pParticleT->fVelocity[X]*fTime;
		pParticleT->fVelocity[Y] += pParticleT->fVelocity[Y]*fTime;
		pParticleT->fVelocity[Z] += pParticleT->fVelocity[Z]*fTime;
		pParticleT->fPos[X] += pParticleT->fVelocity[X]*fTime;
		pParticleT->fPos[Y] += pParticleT->fVelocity[Y]*fTime;
		pParticleT->fPos[Z] += pParticleT->fVelocity[Z]*fTime;
	}
} // end ASParticleSystemCheck_X3Acid()

void ASParticleSystemCheck_Bubbles(AS_PARTICLE_SYSTEM *pSystemT)
{ // begin ASParticleSystemCheck_Bubbles()
	AS_PARTICLE *pParticleT;
	ACTOR *pActorT;
	short i, i2;
	float fTime;
	FLOAT3 fPos2;
	FLOAT3 fPos;

	if(!pSystemT->bActive || !pLevel->Environment.bWater)
		return;
	pActorT = pSystemT->pActor;

	if(!pActorT->bActive || pActorT->bGoingDeath)
		pSystemT->bGoingInActive = TRUE;
	else
		pSystemT->bGoingInActive = FALSE;
	// Check the system:
	if(pSystemT->bGoingInActive)
	{
		for(i = 0; i < pSystemT->iParticles; i++)
		{
			if(pSystemT->pParticle[i].bAlive)
				break;
		}
	}
	else
	if(g_lNow > pSystemT->lNextTime)
	{ // The system should be updated:
		if(pSystemT->bRandomDelay)
		{ // Get the time do the next update per random:
			pSystemT->lTimeDelay = rand() % pSystemT->lMaxRandomDelay;
		}
		pSystemT->lTimeDelay = 100;
		pSystemT->lLastTime = g_lNow;
		pSystemT->lNextTime = pSystemT->lLastTime+pSystemT->lTimeDelay;
		fPos2[X] = pActorT->fWorldPos[X]+0.5f;
		fPos2[Y] = pActorT->fWorldPos[Y]+0.5f;
		fPos2[Z] = pActorT->fWorldPos[Z]-0.6f;
		ASGetMd2Vertex(pXeModel, pActorT->iAniStep, pActorT->iNextAniStep, pActorT->fModelInterpolation, fPos2, 0.025f,
					   -90.0f, pActorT->fRot[Y], 0.0f, 19, &fPos);
		if(fPos[Z] > pLevel->Environment.fWaterActualHeight && pActorT->bActive &&
		   !pActorT->bGoingDeath)
		{
			i2 = pSystemT->GetFreeParticle();
			if(i2 != -1)
			{
				pParticleT = &pSystemT->pParticle[i2];
				pParticleT->bAlive = TRUE;
				pParticleT->fEngine = 1.0f;
				pParticleT->fColor[0] = 1.0f;
				pParticleT->fColor[1] = 1.0f;
				pParticleT->fColor[2] = 1.0f;
				pParticleT->fFadeSpeed = 0.005f;
				pParticleT->fSize = (float) (rand() % 100)/200;
				if(pParticleT->fSize < 0.1f)
					pParticleT->fSize = 0.1f;
				if(pActorT)
				{ // The smoke is connected with an point of an actor:
					fPos[X] = pActorT->fWorldPos[X]+0.5f;
					fPos[Y] = pActorT->fWorldPos[Y]+0.5f;
					fPos[Z] = pActorT->fWorldPos[Z]-0.6f;
					pSystemT->iVertex = 19;
					if(pActorT->iAniStep < pXeModel->header.numFrames &&
					   pActorT->iNextAniStep < pXeModel->header.numFrames)
						ASGetMd2Vertex(pXeModel, pActorT->iAniStep, pActorT->iNextAniStep, pActorT->fModelInterpolation, fPos, 0.02f,
									   -90.0f, pActorT->fRot[Y], 0.0f, pSystemT->iVertex, &pParticleT->fPos);
					if(!(rand() % 2))
						pParticleT->fVelocity[X] = (float) (rand() % 100)/200;
					else
						pParticleT->fVelocity[X] = (float) -(rand() % 100)/200;
					if(!(rand() % 2))
						pParticleT->fVelocity[Y] = (float) (rand() % 100)/200;
					else
						pParticleT->fVelocity[Y] = (float) -(rand() % 100)/200;
					pParticleT->fVelocity[Z] = (float) -(rand() % 100)/100;
					if(!pParticleT->fVelocity[Z])
						pParticleT->fVelocity[Z] = 0.01f;
					switch(pActorT->byDirection)
					{
						case 0:
							pParticleT->fVelocity[X] *= 2;
							if(pParticleT->fVelocity[X] < 0.0f)
								pParticleT->fVelocity[X] = -pParticleT->fVelocity[X];
						break;

						case 1:
							pParticleT->fVelocity[Y] *= 2;
							if(pParticleT->fVelocity[Y] < 0.0f)
								pParticleT->fVelocity[Y] = -pParticleT->fVelocity[Y];
						break;

						case 2:
							pParticleT->fVelocity[X] *= 2;
							if(pParticleT->fVelocity[X] > 0.0f)
								pParticleT->fVelocity[X] = -pParticleT->fVelocity[X];
						break;

						case 3:
							pParticleT->fVelocity[Y] *= 2;
							if(pParticleT->fVelocity[Y] > 0.0f)
								pParticleT->fVelocity[Y] = -pParticleT->fVelocity[Y];
						break;
					}
				}
				else
				{
					pParticleT->fPos[X] = pSystemT->fStartPos[X];
					pParticleT->fPos[Y] = pSystemT->fStartPos[Y];
					pParticleT->fPos[Z] = pSystemT->fStartPos[Z];
				}
			}
		}
	}

	fTime = (float) g_lDeltatime/1000;
	// Check each particle:
	for(i = 0; i < pSystemT->iParticles; i++)
	{
		pParticleT = &pSystemT->pParticle[i];

		if(!pParticleT->bAlive)
			continue;
		// Check if the bubble is under water:
		if(pParticleT->fPos[Z] < pLevel->Environment.fWaterActualHeight+0.2f)
		{
			pParticleT->fEngine -= (float) pParticleT->fFadeSpeed*g_lDeltatime;
			if(pParticleT->fEngine <= 0.0f)
			{ // The particle is now 'death':
				pParticleT->bAlive = FALSE;
				continue;
			}
			pParticleT->fSize = 0.2f/pParticleT->fEngine;
			pParticleT->fColor[0] = 1/pParticleT->fEngine;
			pParticleT->fColor[1] = 1/pParticleT->fEngine;
			pParticleT->fColor[2] = 1/pParticleT->fEngine;
		}
		//
		pParticleT->fVelocity[X] -= pParticleT->fVelocity[X]*fTime;
		pParticleT->fVelocity[Y] -= pParticleT->fVelocity[Y]*fTime;
		pParticleT->fVelocity[Z] += pParticleT->fVelocity[Z]*fTime;
		pParticleT->fPos[X] += pParticleT->fVelocity[X]*fTime;
		pParticleT->fPos[Y] += pParticleT->fVelocity[Y]*fTime;
		pParticleT->fPos[Z] += pParticleT->fVelocity[Z]*fTime;
	}
} // end ASParticleSystemCheck_Bubble()
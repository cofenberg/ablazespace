//-----------------------------------------------------------------------------
// File: Surface.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Structures: ****************************************************************
typedef struct ANIMATION_TOOL
{
	short iColumns, iRows, iMoveX, iMoveY, iSteps;
} ANIMATION_TOOL;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
ANIMATION_TOOL AnimationTool;
HWND hWndBitmap, hWndBitmap2, hWndBitmap3, hWndBitmap4, hWndBitmap5;
HDC hDCBitmap, hDCBitmap2, hDCBitmap3, hDCBitmap4, hDCBitmap5;
HWND hWndSurfaces, hWndSurface, hWndTextures;
BOOL bSurfaceSave, bAnimation;
FLOAT3 fTextureViewPos, fTextureViewPos2, fTextureViewPos3, fTextureViewRot;
short iCurrentTexturePos, iCurrentTextureAniStep, iCurrentTextureAniStep2;
char byFilenameTemp[MAX_PATH];
FLOAT2 fCursorPos;
long lTimer, lTimer2;
BOOL bNewSurface;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
LRESULT CALLBACK SurfacesProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK SurfaceProc(HWND, UINT, WPARAM, LPARAM);
void SurfaceUpdate(void);
LRESULT CALLBACK TexturesProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK CopyTexturePosProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK SetAnimationStepsProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK AnimationToolProc(HWND, UINT, WPARAM, LPARAM);
///////////////////////////////////////////////////////////////////////////////


// SURFACE functions: *********************************************************
SURFACE::SURFACE(void)
{ // begin SURFACE::SURFACE()
	memset(this, 0, sizeof(SURFACE));
} // end SURFACE::SURFACE()

SURFACE::~SURFACE(void)
{ // begin SURFACE::~SURFACE()
} // end SURFACE::~SURFACE()

HRESULT SURFACE::Load(char *pbyFilename)
{ // begin SURFACE::Load()
	FILE *fp;
	short i, i2;

	char byTemp[256];

	_AS->WriteLogMessage("Load surface: %s", pbyFilename);	
	fp = fopen(pbyFilename, "rb");
	if(!fp)
		return 1;

	// Load general information:
	fread(&Header, sizeof(SURFACE_HEADER), 1, fp);

	// Update the surface filename:
	strcpy(Header.byFilename, pbyFilename);

	pTexturePos = (TEXTURE_POS *) malloc(sizeof(TEXTURE_POS)*Header.iAniSteps);
	byTextureFilename = (char **) malloc(sizeof(char *)*Header.iAniSteps);
	iTextureID = (short *) malloc(sizeof(short)*Header.iAniSteps);
	pTexture = (AS_TEXTURE **) malloc(sizeof(AS_TEXTURE *)*Header.iAniSteps);

	// Load the animation steps:
	for(i2 = 0; i2 < Header.iAniSteps; i2++)
	{
		byTextureFilename[i2] = (char *) malloc(sizeof(char)*MAX_PATH);
		fread(byTextureFilename[i2], sizeof(char)*MAX_PATH, 1, fp);
		strcpy(byTemp, byTextureFilename[i2]);
		for(i = 0; i < 4; i++)
			fread(&pTexturePos[i2].iPos[i], sizeof(SHORT2), 1, fp);
		fread(&pTexturePos[i2].iTimeToNext, sizeof(long), 1, fp);
		fread(pTexturePos[i2].fColor, sizeof(float)*4, 1, fp);
		iTextureID[i2] = 0;
		pTexture[i2] = NULL;
	}
	fclose(fp);

	// Check if we have to load a texture:
	for(i2 = 0; i2 < Header.iAniSteps; i2++)
	{
		pLevel->LoadTexture(byTextureFilename[i2]);
		iTextureID[i2] = pLevel->iCurrentTexture;
		pTexture[i2] = pLevel->pCurrentTexture;
	}
	
	// Give this surface the right texture:
	CalculateFloatTexturePos();
	return 0;
} // end SURFACE::Load()

HRESULT SURFACE::Save(char *pbyFilename)
{ // begin SURFACE::Save()
	FILE *fp;
	short i, i2;

	_AS->WriteLogMessage("Save surface: %s", pbyFilename);	
	fp = fopen(pbyFilename, "wb");
	if(!fp)
		return 1;

	// Update the surface filename:
	strcpy(Header.byFilename, pbyFilename);

	// Load general information:
	fwrite(&Header, sizeof(SURFACE_HEADER), 1, fp);

	// Save the animation steps:
	for(i2 = 0; i2 < Header.iAniSteps; i2++)
	{
		fwrite(byTextureFilename[i2], sizeof(char)*MAX_PATH, 1, fp);
		for(i = 0; i < 4; i++)
			fwrite(&pTexturePos[i2].iPos[i], sizeof(SHORT2), 1, fp);
		fwrite(&pTexturePos[i2].iTimeToNext, sizeof(long), 1, fp);
		fwrite(pTexturePos[i2].fColor, sizeof(float)*4, 1, fp);
	}
	fclose(fp);
	return 0;
} // end SURFACE::Save()

void SURFACE::CalculateFloatTexturePos(void)
{ // begin SURFACE::CalculateFloatTexturePos()
	short i, i2;

	for(i2 = 0; i2 < Header.iAniSteps; i2++)
	{
		for(i = 0; i < 4; i++)
		{
			pTexturePos[i2].fPos[i][X] = ((float) pTexturePos[i2].iPos[i][X])/pTexture[i2]->iWidth;
			pTexturePos[i2].fPos[i][Y] = ((float) pTexturePos[i2].iPos[i][Y])/pTexture[i2]->iHeight;
		}
		
		// Looks more fine: (because there is not enough precision)
		pTexturePos[i2].fPos[0][X] += 0.001f;
		pTexturePos[i2].fPos[0][Y] -= 0.001f;
		
		pTexturePos[i2].fPos[1][X] -= 0.001f;
		pTexturePos[i2].fPos[1][Y] -= 0.001f;

		pTexturePos[i2].fPos[2][X] -= 0.001f;
		pTexturePos[i2].fPos[2][Y] += 0.001f;
		
		pTexturePos[i2].fPos[3][X] += 0.001f;
		pTexturePos[i2].fPos[3][Y] += 0.001f;
	}
} // end SURFACE::CalculateFloatTexturePos()

void SURFACE::Destroy(void)
{ // begin SURFACE::Destroy()
	short i;

	for(i = 0; i < Header.iAniSteps; i++)
		SAFE_DELETE(byTextureFilename[i]);
	SAFE_DELETE(byTextureFilename);
	for(i = 0; i < Header.iAniSteps; i++)
		pTexture[i]->iUsed--;
	SAFE_DELETE(pTexture);
	SAFE_DELETE(pTexturePos);
	SAFE_DELETE(iTextureID);
} // end SURFACE::Destroy()

void SURFACE::ChangeAnimationSteps(short iAniStepsT)
{ // begin SURFACE::AddAnimationStep()
	short i, i2;
	
	if(iAniStepsT < Header.iAniSteps)
	{ // Delete the old filenames:
		for(i =	iAniStepsT; i < Header.iAniSteps; i++)
			free(byTextureFilename[i]);
	}
	byTextureFilename = (char **) realloc(byTextureFilename, sizeof(char *)*iAniStepsT);
	pTexturePos = (TEXTURE_POS *) realloc(pTexturePos, sizeof(TEXTURE_POS)*iAniStepsT);
	iTextureID = (short *) realloc(iTextureID, sizeof(short)*iAniStepsT);
	pTexture = (AS_TEXTURE **) realloc(pTexture, sizeof(AS_TEXTURE *)*iAniStepsT);
	for(i =	Header.iAniSteps; i < iAniStepsT; i++)
	{
		byTextureFilename[i] = (char *) malloc(sizeof(char)*MAX_PATH);
		memset(&pTexturePos[i], 0, sizeof(TEXTURE_POS));
		for(i2 = 0; i2 < 4; i2++)
			pTexturePos[i].fColor[i2] = 1.0f;
		iTextureID[i] = 0;
		pTexture[i] = &pLevel->pTexture[iTextureID[i]];
		strcpy(byTextureFilename[i], pLevel->pTexture[iTextureID[i]].byFilename);
	}
	Header.iAniSteps = iAniStepsT;
	CalculateFloatTexturePos();
} // end SURFACE::AddAnimationStep()

// Functions: *****************************************************************
LRESULT CALLBACK SurfacesProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin SurfacesProc()
	char *pbyTemp, byTemp[256], byTemp2[256], byTemp3[256], byTemp4[256];
	static POINT MousePos, OldMousePos;
	TEXTURE_POS *pTexturePos;
	FLOAT3 *pFloat;
	RECT Rect;
	FILE *fp;
	short i;

    switch(iMessage)
    {
        case WM_INITDIALOG:
				if(hWndSurfaces)
				{
					EndDialog(hWnd, FALSE);
					break;
				}
				hWndSurfaces = hWnd;
				SetWindowText(hWnd, T_Surfaces);
				SetDlgItemText(hWnd, ID_SURFACES_OK, T_Ok);
				SetDlgItemText(hWnd, ID_SURFACES_NEW, T_New);
				SetDlgItemText(hWnd, ID_SURFACES_ADJUST, T_Adjust);
				SetDlgItemText(hWnd, ID_SURFACES_LOAD, T_Load);
				SetDlgItemText(hWnd, ID_SURFACES_UNLOAD, T_Unload);
				SetDlgItemText(hWnd, ID_SURFACES_RESET_TEXTURE_VIEW, T_Reset);
				iCurrentTextureAniStep = 0;
				lTimer = g_lNow;
			    hWndBitmap3 = GetDlgItem(hWnd, ID_SURFACES_SHOW);
				ASInitOpenGL(NULL, hWndBitmap3, &hDCBitmap3, &hRCEditorShow, FALSE);
				SetTimer(hWnd, 1, 1, NULL);
				_AS->WriteLogMessage("Open surfaces dialog");
				if(pLevel->iCurrentSurface < 0 || pLevel->iCurrentSurface > pLevel->Header.iSurfaces-1)
					pLevel->iCurrentSurface = 0;
				fTextureViewPos[X] = fTextureViewPos[Y] = 0.0f;
				fTextureViewPos[Z] = -3.0f;
			Init:
				SendDlgItemMessage(hWnd, ID_SURFACES_LIST, LB_RESETCONTENT , 0, 0L);
				for(i = 0; i < pLevel->Header.iSurfaces; i++)
				{
					sprintf(byTemp, "%s (Used:%d)", pLevel->pSurface[i].Header.byName, pLevel->pSurface[i].iUsed);
					SendDlgItemMessage(hWnd, ID_SURFACES_LIST, LB_ADDSTRING, 0, (LPARAM) byTemp);
				}
				SendDlgItemMessage(hWnd, ID_SURFACES_LIST, LB_SETCURSEL, pLevel->iCurrentSurface, 0L);
				if(!pLevel->Header.iSurfaces)
				{	
					EnableWindow(GetDlgItem(hWnd, ID_SURFACES_ADJUST), FALSE);
					EnableWindow(GetDlgItem(hWnd, ID_SURFACES_UNLOAD), FALSE);
					pLevel->iCurrentSurface = 0;
				}
				else
				{
					i = (short) SendDlgItemMessage(hWnd, ID_SURFACES_LIST, LB_GETCURSEL, 0, 0L);
					if(i >= 0 && i <= pLevel->Header.iSurfaces-1)
					{
						pLevel->iCurrentSurface = i;
						EnableWindow(GetDlgItem(hWnd, ID_SURFACES_ADJUST), TRUE);
						EnableWindow(GetDlgItem(hWnd, ID_SURFACES_UNLOAD), TRUE);
					}
					else
						pLevel->iCurrentSurface = 0;
				}
				pLevel->pCurrentSurface = &pLevel->pSurface[pLevel->iCurrentSurface];
				if(!pLevel->iCurrentSurface)
				{	
					EnableWindow(GetDlgItem(hWnd, ID_SURFACES_ADJUST), FALSE);
					EnableWindow(GetDlgItem(hWnd, ID_SURFACES_UNLOAD), FALSE);
				}
				ShowWindow(hWnd, _AS->GetCmdShow());
				UpdateWindow(hWnd);
		return TRUE;

        case WM_LBUTTONDOWN: case WM_LBUTTONUP: case WM_RBUTTONDOWN:
        case WM_RBUTTONUP: case WM_MOUSEMOVE:
			i = wParam;
			memcpy(&OldMousePos, &MousePos, sizeof(POINT));
			GetCursorPos(&MousePos);
			GetWindowRect(hWnd, &Rect);
			GetWindowRect(hWndBitmap2, &Rect);
			pFloat = &fTextureViewPos;
			if(MousePos.x > Rect.left && MousePos.x < Rect.right &&
			   MousePos.y > Rect.top && MousePos.y < Rect.bottom)
			{ // The mouse is over the window enable view control:
				if(i & MK_LBUTTON && i & MK_RBUTTON)
					(*pFloat)[Z] -= (float) (MousePos.x-OldMousePos.x+MousePos.y-OldMousePos.y)/20;
				else
					if(i & MK_RBUTTON)
					{
						(*pFloat)[X] -= (float) (OldMousePos.x-MousePos.x)/100;
						(*pFloat)[Y] -= (float) (MousePos.y-OldMousePos.y)/100;
					}
			}
        break;

		case WM_TIMER:
			if(iCurrentTextureAniStep >= pLevel->pCurrentSurface->Header.iAniSteps)
				iCurrentTextureAniStep = 0;
			if(!wglMakeCurrent(hDCBitmap3, hRCEditorShow))
				break;
			glDisable(GL_LIGHTING);
			glDisable(GL_FOG);
			glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
			glLoadIdentity();
			glTranslatef(fTextureViewPos[X], fTextureViewPos[Y], fTextureViewPos[Z]);
			glEnable(GL_TEXTURE_2D);
			if(pLevel->pCurrentSurface && pLevel->pCurrentSurface->pTexture && pLevel->pCurrentSurface->pTexturePos)
			{
				pTexturePos = &pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep];
				glColor4fv(pTexturePos->fColor);
				glBindTexture(GL_TEXTURE_2D, pLevel->pCurrentSurface->pTexture[iCurrentTextureAniStep]->iOpenGLID);
				glBegin(GL_QUADS);
					glTexCoord2f((float) pTexturePos->fPos[3][X], 
								 (float) pTexturePos->fPos[3][Y]);
					glVertex3f(-1.0f,  -1.0f, 1.0f);
					glTexCoord2f((float) pTexturePos->fPos[2][X], 
								 (float) pTexturePos->fPos[2][Y]);
					glVertex3f(1.0f, -1.0f, 1.0f);
					glTexCoord2f((float) pTexturePos->fPos[1][X], 
								 (float) pTexturePos->fPos[1][Y]);
					glVertex3f( 1.0f, 1.0f, 1.0f);
					glTexCoord2f((float) pTexturePos->fPos[0][X], 
								 (float) pTexturePos->fPos[0][Y]);
					glVertex3f( -1.0f,  1.0f, 1.0f);
				glEnd();
			}
			ASSwapBuffers(hDCBitmap3, NULL, FALSE);
			// Animate the preview:
			if(g_lNow-lTimer < pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep].iTimeToNext)
				break;
			lTimer = g_lNow;
			iCurrentTextureAniStep++;
			if(iCurrentTextureAniStep >= pLevel->pCurrentSurface->Header.iAniSteps)
				iCurrentTextureAniStep = 0;
		break;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_SURFACES_OK:
					if(hDCBitmap3 && !ReleaseDC(hWnd, hDCBitmap3))
						hDCBitmap3 = NULL;
					EndDialog(hWnd, FALSE);
	 				KillTimer(hWnd, 1);
					hWndSurfaces = NULL;
					_AS->WriteLogMessage("Close surfaces dialog");
                return TRUE;

				case ID_SURFACES_NEW:
					if(hWndSurface)
						break;
					pLevel->CreateSurface();
					bNewSurface = TRUE;
					KillTimer(hWnd, 1);
					if(DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_SURFACE), hWnd, (DLGPROC) SurfaceProc) == TRUE)
					{
						SetTimer(hWnd, 1, 1, NULL);
						// Insert the surface into the surface list:
						sprintf(byTemp, "%s (Used:%d)", pLevel->pCurrentSurface->Header.byName, pLevel->pCurrentSurface->iUsed);
						SendDlgItemMessage(hWnd, ID_SURFACES_LIST, LB_ADDSTRING, 0, (LPARAM) byTemp);
						SendDlgItemMessage(hWnd, ID_SURFACES_LIST, LB_SETCURSEL, pLevel->iCurrentSurface, 0L);
					}
					else
					{
						SetTimer(hWnd, 1, 1, NULL);
						goto DestroySurface;
					}
				break;

				case ID_SURFACES_ADJUST:
					bNewSurface = FALSE;
					if(!pLevel->pCurrentSurface->Header.iID || hWndSurface)
						break;
					
					// Test is this surface already exist:
					if(!strcmp(pLevel->pCurrentSurface->Header.byFilename, "") || !(fp = fopen(pLevel->pCurrentSurface->Header.byFilename, "r")))
					{ // No. Ask the user if we should create it now:
						// Get filename:s
						bSurfaceSave = TRUE;
						sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbySurfacesFile);
						KillTimer(hWndSurfaces, 1);
						pbyTemp = ASGetFileName(hWnd, T_SaveSurface, ASS_FILE, 1, FALSE, byTemp);
						SetTimer(hWndSurfaces, 1, 1, NULL);
						bSurfaceSave = FALSE;
						if(!pbyTemp)
							break;
						strcpy(pLevel->pCurrentSurface->Header.byFilename, pbyTemp);
					}
					else
						fclose(fp);

					if(pLevel->pCurrentSurface->Save(pLevel->pCurrentSurface->Header.byFilename))
					{
						sprintf(byTemp, "%s: %s", pLevel->pCurrentSurface->Header.byFilename, M_SaveSurfaceFailed);
						KillTimer(hWndSurfaces, 1);
						if(MessageBox(hWndSurfaces, byTemp, T_Error, MB_YESNO | MB_ICONINFORMATION) == IDNO)
						{
							SetTimer(hWndSurfaces, 1, 1, NULL);
							_AS->WriteLogMessage("Save  %s  failed! User didn't left the surface dialog.", pLevel->pCurrentSurface->Header.byFilename);
							break;
						}
						SetTimer(hWndSurfaces, 1, 1, NULL);
						_AS->WriteLogMessage("Save  %s  failed! User left surface dialog without saving.", pLevel->pCurrentSurface->Header.byFilename);
						break;
					}
					KillTimer(hWnd, 1);
					if(DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_SURFACE), hWnd, (DLGPROC) SurfaceProc) == TRUE)
					{
						SetTimer(hWnd, 1, 1, NULL);
						goto Init;
					}
					SetTimer(hWnd, 1, 1, NULL);
				break;

				case ID_SURFACES_LOAD:
					sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbySurfacesFile);
					KillTimer(hWndSurfaces, 1);
					pbyTemp = ASGetFileName(hWnd, T_LoadSurface, ASS_FILE, 0, TRUE, byTemp);
					SetTimer(hWndSurfaces, 1, 1, NULL);
					if(!pbyTemp)
						break;
					// 	
					fp = fopen(pbyTemp, "rb");
					if(fp) // It's only one file:
					{
						fclose(fp);
						pLevel->LoadSurface(pbyTemp);
						// Insert the surface into the surface list:
						sprintf(byTemp, "%s (Used:%d)", pLevel->pCurrentSurface->Header.byName, pLevel->pCurrentSurface->iUsed);
						SendDlgItemMessage(hWnd, ID_SURFACES_LIST, LB_ADDSTRING, 0, (LPARAM) byTemp);
						SendDlgItemMessage(hWnd, ID_SURFACES_LIST, LB_SETCURSEL, pLevel->iCurrentSurface, 0L);
						pLevel->DestroyTexturesOpenGL(hDCEditorShow, 
												  hRCEditorShow);
						pLevel->GenTexturesOpenGL(hDCEditorShow, 
												  hRCEditorShow);
						goto Init;
					}
					//
					sscanf(pbyTemp, "%s", byTemp); // Read the path
					pbyTemp += strlen(byTemp)+1;
					// Load the selected files:
					for(;;)
					{
						if(sscanf(pbyTemp, "%s", byTemp2) == EOF)
							break;
						if(byTemp[strlen(byTemp)-1] != '\\')
							sprintf(byTemp3, "%s\\%s", byTemp, byTemp2);
						else
							sprintf(byTemp3, "%s%s", byTemp, byTemp2);
						if(pLevel->LoadSurface(byTemp3))
							break;
						// Insert the surface into the surface list:
						sprintf(byTemp4, "%s (Used:%d)", pLevel->pCurrentSurface->Header.byName, pLevel->pCurrentSurface->iUsed);
						SendDlgItemMessage(hWnd, ID_SURFACES_LIST, LB_ADDSTRING, 0, (LPARAM) byTemp4);
						SendDlgItemMessage(hWnd, ID_SURFACES_LIST, LB_SETCURSEL, pLevel->iCurrentSurface, 0L);
						if(*(pbyTemp+strlen(byTemp2)) == 0)
							break;
						pbyTemp += strlen(byTemp2)+1;
					}
					pLevel->DestroyTexturesOpenGL(hDCEditorShow, 
										  hRCEditorShow);
					pLevel->GenTexturesOpenGL(hDCEditorShow, 
											  hRCEditorShow);
					goto Init;

				case ID_SURFACES_UNLOAD:
					if(!pLevel->pCurrentSurface->Header.iID)
						break;
				DestroySurface: // Destroy the surface:
					if(pLevel->pCurrentSurface->iUsed)
					{
						sprintf(byTemp, "%s %s %d)", pLevel->pCurrentSurface->Header.byName,
													 M_SurfaceIsUsed, pLevel->pCurrentSurface->iUsed);
						KillTimer(hWndSurfaces, 1);
						if(MessageBox(hWndSurfaces, byTemp, T_Question, MB_YESNO | MB_ICONINFORMATION) == IDNO)
						{
							SetTimer(hWndSurfaces, 1, 1, NULL);
							break;
						}
						SetTimer(hWndSurfaces, 1, 1, NULL);
					}
					pLevel->DestroySurface(pLevel->iCurrentSurface);
					goto Init;

				case ID_SURFACES_LIST:
					i = (short) SendDlgItemMessage(hWnd, ID_SURFACES_LIST, LB_GETCURSEL, 0, 0L);
					if(i < 0 || i > pLevel->Header.iSurfaces-1)
					{
						pLevel->iCurrentSurface	= -1;
						pLevel->pCurrentSurface = NULL;
					}
					else
					{
						pLevel->iCurrentSurface	= i;
						pLevel->pCurrentSurface = &pLevel->pSurface[pLevel->iCurrentSurface];
					}
					if(pLevel->iCurrentSurface >= 0 || pLevel->iCurrentSurface <= pLevel->Header.iSurfaces)
					{
						EnableWindow(GetDlgItem(hWnd, ID_SURFACES_ADJUST), TRUE);
						EnableWindow(GetDlgItem(hWnd, ID_SURFACES_UNLOAD), TRUE);
					}
					else
					{
						EnableWindow(GetDlgItem(hWnd, ID_SURFACES_ADJUST), FALSE);
						EnableWindow(GetDlgItem(hWnd, ID_SURFACES_UNLOAD), FALSE);
					}
					iCurrentTextureAniStep = 0;
					lTimer = g_lNow;
					goto Init;

				case ID_SURFACES_RESET_TEXTURE_VIEW:
					fTextureViewPos[X] = fTextureViewPos[Y] = 0.0f;
					fTextureViewPos[Z] = -5.0f;
				break;
            }
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_SURFACES_OK, 0);
		break;
    }
    return FALSE;
} // end SurfacesProc()

LRESULT CALLBACK SurfaceProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin SurfaceProc()
	short i, i2, iX, iY, x, y, iDeltaX, iDeltaY, iT;
	TEXTURE_POS *pTexturePosT, *pTexturePosT2;
	static POINT MousePos, OldMousePos;
    char *pbyTemp, byTemp[256];
	TEXTURE_POS *pTexturePos;
	static short iMouseButton;
	FLOAT3 *pFloat;
	RECT Rect;

	switch(iMessage)
    {
        case WM_INITDIALOG:
				if(hWndSurface)
				{
					EndDialog(hWnd, FALSE);
					break;
				}
				fCursorPos[X] = 0.0f;
				fCursorPos[Y] = 0.0f;
				iCurrentTextureAniStep2 = 0;
				hWndSurface = hWnd;
				// Texts
				SetWindowText(hWnd, T_Surface);
				SetDlgItemText(hWnd, ID_SURFACE_OK, T_Ok);
				SetDlgItemText(hWnd, ID_SURFACE_CANCEL, T_Cancel);
				SetDlgItemText(hWnd, ID_SURFACE_RESET_TEXTURE_VIEW, T_Reset);
				SetDlgItemText(hWnd, ID_SURFACE_RESET_TEXTURE_VIEW2, T_Reset);
				SetDlgItemText(hWnd, IDC_SURFACE_TEXTURE_T, T_Texture);
				SetDlgItemText(hWnd, IDC_SURFACE_WHOLE_TEXTURE, T_WholeTexture);
				SetDlgItemText(hWnd, IDC_SURFACE_NAME_T, T_Name);
				SetDlgItemText(hWnd, IDC_SURFACE_FILENAME_T, T_File);
				SetDlgItemText(hWnd, IDC_SURFACE_TEXTURE_SELECTION_T, T_Texture);
				SetDlgItemText(hWnd, IDC_SURFACE_TEXTURE_POS_T, T_TexturePos);
				SetDlgItemText(hWnd, ID_SURFACE_TEXTURE_ANI_STEPS, T_Steps);
				SetDlgItemText(hWnd, IDC_SURFACE_ANIMATE, T_Play);
				SetDlgItemText(hWnd, IDC_SURFACE_COPY, T_Copy);
				SetDlgItemText(hWnd, IDC_SURFACE_MOVE, T_Move);
				SetDlgItemText(hWnd, IDC_SURFACE_NEXT_TIME_T, T_NextTime);
				SetDlgItemText(hWnd, IDC_SURFACE_NEXT_TIME_ALL, T_All);
				SetDlgItemText(hWnd, IDC_SURFACE_ANIMATION_T, T_Animation);
				SetDlgItemText(hWnd, IDC_SURFACE_COLOR_R_ALL, T_All);
				SetDlgItemText(hWnd, IDC_SURFACE_COLOR_G_ALL, T_All);
				SetDlgItemText(hWnd, IDC_SURFACE_COLOR_B_ALL, T_All);
				SetDlgItemText(hWnd, IDC_SURFACE_ALPHA_ALL, T_All);
				SetDlgItemText(hWnd, IDC_SURFACE_ANIMATION_TOOL, T_AnimationTool);
				// Attributes:				
				SetDlgItemText(hWnd, IDC_SURFACE_ATTRIBUTES_T, T_Attributes);
				SetDlgItemText(hWnd, IDC_SURFACE_FRICTION_T, T_Friction);
				SetDlgItemText(hWnd, IDC_SURFACE_AT_ALCOVE, T_Alcove);
				SetDlgItemText(hWnd, IDC_SURFACE_AT_RADIOACTIVE, T_Radioactive);
				SetDlgItemText(hWnd, IDC_SURFACE_AT_HEALTH, T_Health);
				SetDlgItemText(hWnd, IDC_SURFACE_AT_ANCHOR, T_Anchor);
				SetDlgItemText(hWnd, IDC_SURFACE_AT_CHANGE, T_Change);
				SetDlgItemText(hWnd, IDC_SURFACE_ATTRIBUTES_CHANGE_T, T_Change);
				SetDlgItemText(hWnd, IDC_SURFACE_AT_CHANGE_ON_ENTER, T_Enter);
				SetDlgItemText(hWnd, IDC_SURFACE_AT_CHANGE_ON_LEAVE, T_Leave);
				SetDlgItemText(hWnd, IDC_SURFACE_AT_CHANGE_ON_TIME, T_TimeObj);
				SetDlgItemText(hWnd, IDC_SURFACE_AT_CHANGE_SURFACE, T_Surface);
				SetDlgItemText(hWnd, IDC_SURFACE_AT_CHANGE_DESTROY, T_Destroy);
				SetDlgItemText(hWnd, IDC_SURFACE_AT_BEAMER, T_Beamer);
				//
				_AS->WriteLogMessage("Open surface dialog");
			    hWndBitmap = GetDlgItem(hWnd, ID_SURFACE_TEXTURE_SHOW);
			    hWndBitmap5 = GetDlgItem(hWnd, ID_SURFACE_TEXTURE_SHOW2);
				ASInitOpenGL(NULL, hWndBitmap, &hDCBitmap, &hRCEditorShow, FALSE);
				ASInitOpenGL(NULL, hWndBitmap5, &hDCBitmap5, &hRCEditorShow, FALSE);
				SetTimer(hWnd, 1, 1, NULL);
				iCurrentTexturePos = 0;
				strcpy(byFilenameTemp, pLevel->pCurrentSurface->Header.byFilename);
				if(pLevel->pCurrentSurface->iTextureID[iCurrentTextureAniStep2] != -1)
					iCurrentTexturePos = 0;
				else
					iCurrentTexturePos = -1;
				fTextureViewPos2[X] = 0.0f;
				fTextureViewPos2[Y] = 0.0f;
				fTextureViewPos2[Z] = -5.0f;
				fTextureViewPos3[X] = 0.0f;
				fTextureViewPos3[Y] = (float) -pLevel->pCurrentSurface->pTexture[iCurrentTextureAniStep2]->iHeight;
				fTextureViewPos3[Z] = 500.0f;
				bAnimation = 0;
				lTimer2 = g_lNow;
			    SendDlgItemMessage(hWnd, IDC_SURFACE_MOVE, BM_SETCHECK, 0, 0L);
				// Attributes:
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_ALCOVE, BM_SETCHECK, pLevel->pCurrentSurface->Header.bAlcove, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_RADIOACTIVE, BM_SETCHECK, pLevel->pCurrentSurface->Header.bRadioactive, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_HEALTH, BM_SETCHECK, pLevel->pCurrentSurface->Header.bHealth, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_EXIT, BM_SETCHECK, pLevel->pCurrentSurface->Header.bExit, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_ANCHOR, BM_SETCHECK, pLevel->pCurrentSurface->Header.bAnchor, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_COLOR_PAINTER, BM_SETCHECK, pLevel->pCurrentSurface->Header.bColorPainter, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_ANCHOR_TYPE, CB_RESETCONTENT , 0, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_ANCHOR_TYPE, CB_ADDSTRING, 0, (LPARAM) T_ForAll);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_ANCHOR_TYPE, CB_ADDSTRING, 0, (LPARAM) T_Normal);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_ANCHOR_TYPE, CB_ADDSTRING, 0, (LPARAM) T_Red);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_ANCHOR_TYPE, CB_ADDSTRING, 0, (LPARAM) T_Green);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_ANCHOR_TYPE, CB_ADDSTRING, 0, (LPARAM) T_Blue);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_ANCHOR_TYPE, CB_SETCURSEL, pLevel->pCurrentSurface->Header.byAnchorType, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_COLOR_PAINTER_TYPE, CB_RESETCONTENT , 0, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_COLOR_PAINTER_TYPE, CB_ADDSTRING, 0, (LPARAM) T_Normal);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_COLOR_PAINTER_TYPE, CB_ADDSTRING, 0, (LPARAM) T_Red);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_COLOR_PAINTER_TYPE, CB_ADDSTRING, 0, (LPARAM) T_Green);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_COLOR_PAINTER_TYPE, CB_ADDSTRING, 0, (LPARAM) T_Blue);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_COLOR_PAINTER_TYPE, CB_SETCURSEL, pLevel->pCurrentSurface->Header.byColorPainterType, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_SURFACE, CB_RESETCONTENT , 0, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE, BM_SETCHECK, pLevel->pCurrentSurface->Header.bChange, 0L);
				for(i = 0; i < pLevel->Header.iSurfaces; i++)
				{
					sprintf(byTemp, "%s", pLevel->pSurface[i].Header.byName, pLevel->pSurface[i].iUsed);
					SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_SURFACE, CB_ADDSTRING, 0, (LPARAM) byTemp);
				}
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_SURFACE, CB_SETCURSEL, pLevel->pCurrentSurface->Header.iChangeSurface, 0L);
				switch(pLevel->pCurrentSurface->Header.byChangeState)
				{
					case 0: CheckRadioButton(hWnd, IDC_SURFACE_AT_CHANGE_ON_ENTER, IDC_SURFACE_AT_CHANGE_ON_TIME, IDC_SURFACE_AT_CHANGE_ON_ENTER); break;
					case 1: CheckRadioButton(hWnd, IDC_SURFACE_AT_CHANGE_ON_ENTER, IDC_SURFACE_AT_CHANGE_ON_TIME, IDC_SURFACE_AT_CHANGE_ON_LEAVE); break;
					case 2: CheckRadioButton(hWnd, IDC_SURFACE_AT_CHANGE_ON_ENTER, IDC_SURFACE_AT_CHANGE_ON_TIME, IDC_SURFACE_AT_CHANGE_ON_TIME); break;
				}
				sprintf(byTemp, "%d", pLevel->pCurrentSurface->Header.lChangeTime);
				SetDlgItemText(hWnd, IDC_SURFACE_AT_CHANGE_ON_TIME_TIME, byTemp);
				sprintf(byTemp, "%f", pLevel->pCurrentSurface->Header.fFriction);
				SetDlgItemText(hWnd, IDC_SURFACE_FRICTION, byTemp);

			Init:
				SurfaceUpdate();
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_BEAMER, BM_SETCHECK, pLevel->pCurrentSurface->Header.bBeamer, 0L);
				SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_DESTROY, BM_SETCHECK, pLevel->pCurrentSurface->Header.bChangeDestroy, 0L);
				SetDlgItemText(hWnd, ID_SURFACE_NAME, pLevel->pCurrentSurface->Header.byName);
				SetDlgItemText(hWnd, ID_SURFACE_FILENAME, pLevel->pCurrentSurface->Header.byFilename);
				SendDlgItemMessage(hWnd, ID_SURFACE_TEXTURE, CB_RESETCONTENT , 0, 0L);
				for(i = 0; i < pLevel->Header.iTextures; i++)
				{
					sprintf(byTemp, "%s (Used:%d)", pLevel->pTexture[i].byFilename, pLevel->pTexture[i].iUsed);
					SendDlgItemMessage(hWnd, ID_SURFACE_TEXTURE, CB_ADDSTRING, 0, (LPARAM) byTemp);
				}
				if(pLevel->pCurrentSurface->iTextureID[iCurrentTextureAniStep2] != -1)
					SendDlgItemMessage(hWnd, ID_SURFACE_TEXTURE, CB_SETCURSEL, pLevel->pCurrentSurface->iTextureID[iCurrentTextureAniStep2], 0L);
				EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_1), TRUE);
				EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_2), TRUE);
				EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_3), TRUE);
				EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_4), TRUE);
				switch(iCurrentTexturePos)
				{
					case 0:	EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_1), FALSE); break;
					case 1:	EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_2), FALSE); break;
					case 2:	EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_3), FALSE); break;
					case 3:	EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_4), FALSE); break;
				}
				fCursorPos[X] = (float) pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].iPos[iCurrentTexturePos][X];
				fCursorPos[Y] = (float) pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].iPos[iCurrentTexturePos][Y];
				sprintf(byTemp, "%d", pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].iTimeToNext);
				SetDlgItemText(hWnd, IDC_SURFACE_NEXT_TIME, byTemp);
				sprintf(byTemp, "%d", pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].iPos[iCurrentTexturePos][X]);
				SetDlgItemText(hWnd, ID_SURFACE_TEXTURE_POS_X, byTemp);
				sprintf(byTemp, "%d", pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].iPos[iCurrentTexturePos][Y]);
				SetDlgItemText(hWnd, ID_SURFACE_TEXTURE_POS_Y, byTemp);
				
				// Texture color:
				sprintf(byTemp, "%f", pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].fColor[0]);
				SetDlgItemText(hWnd, IDC_SURFACE_COLOR_R, byTemp);
				sprintf(byTemp, "%f", pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].fColor[1]);
				SetDlgItemText(hWnd, IDC_SURFACE_COLOR_G, byTemp);
				sprintf(byTemp, "%f", pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].fColor[2]);
				SetDlgItemText(hWnd, IDC_SURFACE_COLOR_B, byTemp);
				sprintf(byTemp, "%f", pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].fColor[3]);
				SetDlgItemText(hWnd, IDC_SURFACE_ALPHA, byTemp);

				EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_X), TRUE);
				EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_Y), TRUE);
				if(pLevel->pCurrentSurface->iTextureID[iCurrentTextureAniStep2] == -1)
				{
					EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_1), FALSE);
					EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_2), FALSE);
					EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_3), FALSE);
					EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_4), FALSE);
					EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_X), FALSE);
					EnableWindow(GetDlgItem(hWnd, ID_SURFACE_TEXTURE_POS_Y), FALSE);
				}
				SendDlgItemMessage(hWnd, ID_SURFACE_TEXTURE_ANIS, CB_RESETCONTENT , 0, 0L);
				for(i = 0; i < pLevel->pCurrentSurface->Header.iAniSteps; i++)
				{
					sprintf(byTemp, "%d", i);
					SendDlgItemMessage(hWnd, ID_SURFACE_TEXTURE_ANIS, CB_ADDSTRING, 0, (LPARAM) byTemp);
				}
				SendDlgItemMessage(hWnd, ID_SURFACE_TEXTURE_ANIS, CB_SETCURSEL, iCurrentTextureAniStep2, 0L);
				ShowWindow(hWnd, _AS->GetCmdShow());
				UpdateWindow(hWnd);
		return TRUE;

        case WM_LBUTTONDOWN: case WM_LBUTTONUP: case WM_RBUTTONDOWN:
        case WM_RBUTTONUP: case WM_MOUSEMOVE:
			iMouseButton = wParam;
			memcpy(&OldMousePos, &MousePos, sizeof(POINT));
			GetCursorPos(&MousePos);
			GetWindowRect(hWndBitmap, &Rect);
			pFloat = &fTextureViewPos3;
			if(MousePos.x > Rect.left && MousePos.x < Rect.right &&
			   MousePos.y > Rect.top && MousePos.y < Rect.bottom)
			{ // The mouse is over the window enable view control:
				if(iMouseButton & MK_LBUTTON && iMouseButton & MK_RBUTTON)
					(*pFloat)[Z] -= (float) (MousePos.x-OldMousePos.x+MousePos.y-OldMousePos.y);
				else
					if(iMouseButton & MK_LBUTTON)
					{
						fCursorPos[X] -= (float) (OldMousePos.x-MousePos.x);
						fCursorPos[Y] += (float) (MousePos.y-OldMousePos.y);
						if(fCursorPos[X] < 0.0f)
							fCursorPos[X] = 0.0f;
						if(fCursorPos[X] >= pLevel->pCurrentSurface->pTexture[iCurrentTextureAniStep2]->iWidth)
							fCursorPos[X] = (float) pLevel->pCurrentSurface->pTexture[iCurrentTextureAniStep2]->iWidth-1;
						if(fCursorPos[Y] < 0.0f)
							fCursorPos[Y] = 0.0f;
						if(fCursorPos[Y] >= pLevel->pCurrentSurface->pTexture[iCurrentTextureAniStep2]->iHeight)
							fCursorPos[Y] = (float) pLevel->pCurrentSurface->pTexture[iCurrentTextureAniStep2]->iHeight-1;
					}
				else
					if(iMouseButton & MK_RBUTTON)
					{
						(*pFloat)[X] -= (float) (OldMousePos.x-MousePos.x);
						(*pFloat)[Y] -= (float) (MousePos.y-OldMousePos.y);
					}
			}
			GetWindowRect(hWndBitmap5, &Rect);
			pFloat = &fTextureViewPos2;
			if(MousePos.x > Rect.left && MousePos.x < Rect.right &&
			   MousePos.y > Rect.top && MousePos.y < Rect.bottom)
			{ // The mouse is over the window enable view control:
				if(iMouseButton & MK_LBUTTON && iMouseButton & MK_RBUTTON)
					(*pFloat)[Z] -= (float) (MousePos.x-OldMousePos.x+MousePos.y-OldMousePos.y)/20.0f;
				else
					if(iMouseButton & MK_RBUTTON)
					{
						(*pFloat)[X] -= (float) (OldMousePos.x-MousePos.x)/100.0f;
						(*pFloat)[Y] -= (float) (MousePos.y-OldMousePos.y)/100.0f;
					}
			}
        break;

		case WM_TIMER:
			if(iCurrentTextureAniStep2 >= pLevel->pCurrentSurface->Header.iAniSteps)
			{
				iCurrentTextureAniStep2 = 0;
				goto Init;
			}
			// Show the whole texture:
			if(!wglMakeCurrent(hDCBitmap, hRCEditorShow))
				break;
			glDisable(GL_LIGHTING);
			glDisable(GL_FOG);
			glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
			if(iMouseButton & MK_LBUTTON)
			{
				// Check if the mouse in in the texture view:
				GetWindowRect(hWndBitmap, &Rect);
				if(MousePos.x > Rect.left &&
				   MousePos.x < Rect.right &&
				   MousePos.y > Rect.top &&
				   MousePos.y < Rect.bottom)
				{ // Yea, we are inside:
					// Set this texture coordinate:
					if(SendDlgItemMessage(hWnd, IDC_SURFACE_MOVE, BM_GETCHECK, 0, 0L))
					{ // We move the whole current animation step:
						iX = pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].iPos[0][X];
						iY = pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].iPos[0][Y];
						pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].iPos[0][X] = (short) fCursorPos[X];
						pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].iPos[0][Y] = (short) fCursorPos[Y];
						iDeltaX = iX-(short) fCursorPos[X];
						iDeltaY = iY-(short) fCursorPos[Y];
						for(i = 1; i < 4; i++)
						{
							pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].iPos[i][X] -= iDeltaX;
							pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].iPos[i][Y] -= iDeltaY;
						}
					}
					else
					{ // Move only one point:
						pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].iPos[iCurrentTexturePos][X] = (short) fCursorPos[X];
						pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].iPos[iCurrentTexturePos][Y] = (short) fCursorPos[Y];
					}										
					pLevel->pCurrentSurface->CalculateFloatTexturePos();
					sprintf(byTemp, "%d", pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].iPos[iCurrentTexturePos][X]);
					SetDlgItemText(hWnd, ID_SURFACE_TEXTURE_POS_X, byTemp);
					sprintf(byTemp, "%d", pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].iPos[iCurrentTexturePos][Y]);
					SetDlgItemText(hWnd, ID_SURFACE_TEXTURE_POS_Y, byTemp);
				}
			}
			//
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
			glLoadIdentity();
			glTranslatef(fTextureViewPos3[X], fTextureViewPos3[Y], fTextureViewPos3[Z]);
			glEnable(GL_TEXTURE_2D);
			if(pLevel->pCurrentSurface && pLevel->pCurrentSurface->pTexture)
			{
				glBindTexture(GL_TEXTURE_2D, pLevel->pCurrentSurface->pTexture[iCurrentTextureAniStep2]->iOpenGLID);
				glBegin(GL_TRIANGLE_FAN);
					glTexCoord2f(0.0f, 1.0f);
					glVertex3f(0.0f, 0.0f, -1000.0f);
					glTexCoord2f(1.0f, 1.0f);
					glVertex3f((float) pLevel->pCurrentSurface->pTexture[iCurrentTextureAniStep2]->iWidth, 0.0f, -1000.0f);
					glTexCoord2f(1.0f, 0.0f);
					glVertex3f((float) pLevel->pCurrentSurface->pTexture[iCurrentTextureAniStep2]->iWidth, (float) pLevel->pCurrentSurface->pTexture[iCurrentTextureAniStep2]->iHeight, -1000.0f);
					glTexCoord2f(0.0f, 0.0f);
					glVertex3f(0.0f, (float) pLevel->pCurrentSurface->pTexture[iCurrentTextureAniStep2]->iHeight, -1000.0f);
				glEnd();
			}
			// Draw the cursor:
			glLineWidth(3.0f);
			glColor3f((rand() % 100)/100.0f, 1.0f, 0.5f);
			glDisable(GL_TEXTURE_2D);
			glDisable(GL_BLEND);
			glDisable(GL_DEPTH_TEST);
			glBegin(GL_LINES);
				glVertex3f(fCursorPos[X]-10.0f, pLevel->pCurrentSurface->pTexture[iCurrentTextureAniStep2]->iHeight-fCursorPos[Y], -1000.0f);
				glVertex3f(fCursorPos[X]+10.0f, pLevel->pCurrentSurface->pTexture[iCurrentTextureAniStep2]->iHeight-fCursorPos[Y], -1000.0f);
				glVertex3f(fCursorPos[X], pLevel->pCurrentSurface->pTexture[iCurrentTextureAniStep2]->iHeight-fCursorPos[Y]-10.0f, -1000.0f);
				glVertex3f(fCursorPos[X], pLevel->pCurrentSurface->pTexture[iCurrentTextureAniStep2]->iHeight-fCursorPos[Y]+10.0f, -1000.0f);
			glEnd();
			// Draw a frame around the selected area:
			glLineWidth(1.0f);
			pTexturePos = &pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2];
			glBegin(GL_LINE_STRIP);
				for(i = 0; i < 4; i++)
					glVertex3f((float) pTexturePos->iPos[i][X], (float) pLevel->pCurrentSurface->pTexture[iCurrentTextureAniStep2]->iHeight-pTexturePos->iPos[i][Y], -1000.0f);
				glVertex3f((float) pTexturePos->iPos[0][X], (float) pLevel->pCurrentSurface->pTexture[iCurrentTextureAniStep2]->iHeight-pTexturePos->iPos[0][Y], -1000.0f);
			glEnd();
			glEnable(GL_DEPTH_TEST);
			ASSwapBuffers(hDCBitmap, NULL, FALSE);
			
			// Show the texture:
			if(!wglMakeCurrent(hDCBitmap5, hRCEditorShow))
				break;
			glDisable(GL_LIGHTING);
			glDisable(GL_FOG);
			glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
			glLoadIdentity();
			glTranslatef(fTextureViewPos2[X], fTextureViewPos2[Y], fTextureViewPos2[Z]);
			glEnable(GL_TEXTURE_2D);
			if(pLevel->pCurrentSurface && pLevel->pCurrentSurface->pTexture)
			{
				pTexturePos = &pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2];
				glColor4fv(pTexturePos->fColor);
				glBindTexture(GL_TEXTURE_2D, pLevel->pCurrentSurface->pTexture[iCurrentTextureAniStep2]->iOpenGLID);
				glBegin(GL_TRIANGLE_FAN);
					glTexCoord2f((float) pTexturePos->fPos[3][X], 
								 (float) pTexturePos->fPos[3][Y]);
					glVertex3f(-1.0f, -1.0f, 1.0f);
					glTexCoord2f((float) pTexturePos->fPos[2][X], 
								 (float) pTexturePos->fPos[2][Y]);
					glVertex3f(1.0f, -1.0f, 1.0f);
					glTexCoord2f((float) pTexturePos->fPos[1][X], 
								 (float) pTexturePos->fPos[1][Y]);
					glVertex3f(1.0f, 1.0f, 1.0f);
					glTexCoord2f((float) pTexturePos->fPos[0][X], 
								 (float) pTexturePos->fPos[0][Y]);
					glVertex3f(-1.0f, 1.0f, 1.0f);
				glEnd();
			}
			ASSwapBuffers(hDCBitmap5, NULL, FALSE);
			if(!bAnimation)
				break;
			// Animate the preview:
			if(g_lNow-lTimer2 < pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].iTimeToNext)
				break;
			lTimer2 = g_lNow;
			iCurrentTextureAniStep2++;
			if(iCurrentTextureAniStep2 >= pLevel->pCurrentSurface->Header.iAniSteps)
				iCurrentTextureAniStep2 = 0;
			goto Init;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_SURFACE_OK:
					if(IsDlgButtonChecked(hWnd, IDC_SURFACE_AT_CHANGE_ON_ENTER))
						pLevel->pCurrentSurface->Header.byChangeState = 0;
					else
					if(IsDlgButtonChecked(hWnd, IDC_SURFACE_AT_CHANGE_ON_LEAVE))
						pLevel->pCurrentSurface->Header.byChangeState = 1;
					else
					if(IsDlgButtonChecked(hWnd, IDC_SURFACE_AT_CHANGE_ON_TIME))
						pLevel->pCurrentSurface->Header.byChangeState = 2;

					// Save the surface:
					if(pLevel->pCurrentSurface->Header.byFilename[0] == '\0')
					{ // Get an filename:
						bSurfaceSave = TRUE;
						sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbySurfacesFile);
						KillTimer(hWndSurface, 1);
						pbyTemp = ASGetFileName(hWnd, T_SaveSurface, ASS_FILE, 1, FALSE, byTemp);
						SetTimer(hWndSurface, 1, 1, NULL);
						bSurfaceSave = FALSE;
						if(!pbyTemp)
							break;
						if(strlen(pbyTemp) > strlen(_AS->pbyProgramPath))
							strcpy(pLevel->pCurrentSurface->Header.byFilename, &pbyTemp[strlen(_AS->pbyProgramPath)]);
					}
					else
						if(strlen(pLevel->pCurrentSurface->Header.byFilename) > strlen(_AS->pbyProgramPath))
							strcpy(pLevel->pCurrentSurface->Header.byFilename, &pLevel->pCurrentSurface->Header.byFilename[strlen(_AS->pbyProgramPath)]);
					sprintf(byTemp, "%s%s", _AS->pbyProgramPath, pLevel->pCurrentSurface->Header.byFilename);
					if(pLevel->pCurrentSurface->Save(byTemp))
					{
						sprintf(byTemp, "%s: %s", pLevel->pCurrentSurface->Header.byFilename, M_SaveSurfaceFailed);
						KillTimer(hWndSurface, 1);
						if(MessageBox(hWndSurface, byTemp, T_Error, MB_YESNO | MB_ICONINFORMATION) == IDNO)
						{
							SetTimer(hWndSurface, 1, 1, NULL);
							_AS->WriteLogMessage("Save  %s  failed! User didn't left the surface dialog.", pLevel->pCurrentSurface->Header.byFilename);
							break;
						}
						SetTimer(hWndSurface, 1, 1, NULL);
						_AS->WriteLogMessage("Save  %s  failed! User left surface dialog without saving.", pLevel->pCurrentSurface->Header.byFilename);
						goto LeftWithoutSave;
					}
					// Close dialog:
	 				KillTimer(hWnd, 1);
					if(hDCBitmap && !ReleaseDC(hWnd, hDCBitmap))
						hDCBitmap = NULL;
					if(hDCBitmap5 && !ReleaseDC(hWnd, hDCBitmap5))
						hDCBitmap5 = NULL;
					EndDialog(hWnd, TRUE);
					hWndSurface = NULL;
					//				
					_AS->WriteLogMessage("Close surface dialog(OK)");
                return TRUE;

                case ID_SURFACE_CANCEL:
				LeftWithoutSave:
					// Close dialog:
	 				KillTimer(hWnd, 1);
					if(hDCBitmap && !ReleaseDC(hWnd, hDCBitmap))
						hDCBitmap = NULL;
					if(hDCBitmap5 && !ReleaseDC(hWnd, hDCBitmap5))
						hDCBitmap5 = NULL;
					hWndSurface = NULL;
					EndDialog(hWnd, FALSE);
					if(!bNewSurface)
					{
						pLevel->pCurrentSurface->Destroy();
						pLevel->pCurrentSurface->Load(byFilenameTemp);
					}
					//
					_AS->WriteLogMessage("Close surface dialog(CANCEL)");
                return TRUE;

				case ID_SURFACE_NAME:
					GetDlgItemText(hWnd, ID_SURFACE_NAME, pLevel->pCurrentSurface->Header.byName, 256);
					SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_SURFACE, CB_RESETCONTENT , 0, 0L);
					for(i = 0; i < pLevel->Header.iSurfaces; i++)
					{
						sprintf(byTemp, "%s", pLevel->pSurface[i].Header.byName, pLevel->pSurface[i].iUsed);
						SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_SURFACE, CB_ADDSTRING, 0, (LPARAM) byTemp);
					}
					SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_SURFACE, CB_SETCURSEL, pLevel->pCurrentSurface->Header.iChangeSurface, 0L);
				break;

				case ID_SURFACE_FILENAME:
					GetDlgItemText(hWnd, ID_SURFACE_FILENAME, pLevel->pCurrentSurface->Header.byFilename, 256);
				break;

				case ID_SURFACE_TEXTURE:
					if(!pLevel->Header.iTextures)
						break;
					if(pLevel->pCurrentSurface->iTextureID[iCurrentTextureAniStep2] != -1 && pLevel->pCurrentTexture)
						pLevel->pCurrentTexture->iUsed--;
					i = (short) SendDlgItemMessage(hWnd, ID_SURFACE_TEXTURE, CB_GETCURSEL, 0, 0L);
					if(i < 0 || i > pLevel->Header.iTextures-1 || pLevel->iCurrentTexture == i)
						break;
					pLevel->iCurrentTexture = i;
					pLevel->pCurrentTexture = &pLevel->pTexture[pLevel->iCurrentTexture];
					pLevel->pCurrentSurface->iTextureID[iCurrentTextureAniStep2] = pLevel->iCurrentTexture;
					pLevel->pCurrentSurface->pTexture[iCurrentTextureAniStep2] = pLevel->pCurrentTexture;
					pLevel->pCurrentTexture->iUsed++;
					strcpy(pLevel->pCurrentSurface->byTextureFilename[iCurrentTextureAniStep2], pLevel->pCurrentTexture->byFilename);
					iCurrentTexturePos = 0;
					fTextureViewPos3[X] = 0.0f;
					fTextureViewPos3[Y] = (float) -pLevel->pCurrentSurface->pTexture[iCurrentTextureAniStep2]->iHeight;
					fTextureViewPos3[Z] = 500.0f;
					goto Init;
			
				case ID_SURFACE_TEXTURE_ANI_STEPS:
					KillTimer(hWnd, 1);
					if((i = DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_SET_ANIMATION_STEPS), hWnd, (DLGPROC) SetAnimationStepsProc)) == -1)
					{
						SetTimer(hWnd, 1, 1, NULL);
						break;
					}
					SetTimer(hWnd, 1, 1, NULL);
					pLevel->pCurrentSurface->ChangeAnimationSteps(i);
					goto Init;

				case ID_SURFACE_TEXTURE_ANIS:
					i = (short) SendDlgItemMessage(hWnd, ID_SURFACE_TEXTURE_ANIS, CB_GETCURSEL, 0, 0L);
					if(i < 0 || i >= pLevel->pCurrentSurface->Header.iAniSteps)
						break;
					iCurrentTextureAniStep2 = i;
					goto Init;

				case ID_SURFACE_TEXTURE_POS_1: case IDC_SURFACE_MOVE:
					iCurrentTexturePos = 0;
					goto Init;

				case ID_SURFACE_TEXTURE_POS_2:
					if(SendDlgItemMessage(hWnd, IDC_SURFACE_MOVE, BM_GETCHECK, 0, 0L))
						break;
					iCurrentTexturePos = 1;
					goto Init;

				case ID_SURFACE_TEXTURE_POS_3:
					if(SendDlgItemMessage(hWnd, IDC_SURFACE_MOVE, BM_GETCHECK, 0, 0L))
						break;
					iCurrentTexturePos = 2;
					goto Init;

				case ID_SURFACE_TEXTURE_POS_4:
					if(SendDlgItemMessage(hWnd, IDC_SURFACE_MOVE, BM_GETCHECK, 0, 0L))
						break;
					iCurrentTexturePos = 3;
					goto Init;

				case ID_SURFACE_TEXTURE_POS_X:
					GetDlgItemText(hWnd, ID_SURFACE_TEXTURE_POS_X, byTemp, 256);
					pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].iPos[iCurrentTexturePos][X] = atoi(byTemp);
					if(!pLevel->pCurrentSurface->pTexture)
						break;
					pLevel->pCurrentSurface->CalculateFloatTexturePos();
					fCursorPos[X] = pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].iPos[iCurrentTexturePos][X];
				break;

				case ID_SURFACE_TEXTURE_POS_Y:
					GetDlgItemText(hWnd, ID_SURFACE_TEXTURE_POS_Y, byTemp, 256);
					pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].iPos[iCurrentTexturePos][Y] = atoi(byTemp);
					if(!pLevel->pCurrentSurface->pTexture)
						break;
					pLevel->pCurrentSurface->CalculateFloatTexturePos();
					fCursorPos[Y] = pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].iPos[iCurrentTexturePos][Y];
				break;

				case IDC_SURFACE_COLOR_R: case IDC_SURFACE_COLOR_G: case IDC_SURFACE_COLOR_B: case IDC_SURFACE_ALPHA:
					switch(LOWORD(wParam))
					{
						case IDC_SURFACE_COLOR_R: GetDlgItemText(hWnd, IDC_SURFACE_COLOR_R, byTemp, 256); i = 0; break;
						case IDC_SURFACE_COLOR_G: GetDlgItemText(hWnd, IDC_SURFACE_COLOR_G, byTemp, 256); i = 1; break;
						case IDC_SURFACE_COLOR_B: GetDlgItemText(hWnd, IDC_SURFACE_COLOR_B, byTemp, 256); i = 2; break;
						case IDC_SURFACE_ALPHA: GetDlgItemText(hWnd, IDC_SURFACE_ALPHA, byTemp, 256); i = 3; break;
					}
					pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].fColor[i] = (float) atof(byTemp);
					if(pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].fColor[i] < 0.0f)
						pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].fColor[i] = 0.0f;
					if(pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].fColor[i] > 1.0f)
						pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].fColor[i] = 1.0f;
				break;

				case IDC_SURFACE_COLOR_R_ALL: case IDC_SURFACE_COLOR_G_ALL: case IDC_SURFACE_COLOR_B_ALL: case IDC_SURFACE_ALPHA_ALL:
					switch(LOWORD(wParam))
					{
						case IDC_SURFACE_COLOR_R_ALL: GetDlgItemText(hWnd, IDC_SURFACE_COLOR_R, byTemp, 256); i = 0; break;
						case IDC_SURFACE_COLOR_G_ALL: GetDlgItemText(hWnd, IDC_SURFACE_COLOR_G, byTemp, 256); i = 1; break;
						case IDC_SURFACE_COLOR_B_ALL: GetDlgItemText(hWnd, IDC_SURFACE_COLOR_B, byTemp, 256); i = 2; break;
						case IDC_SURFACE_ALPHA_ALL: GetDlgItemText(hWnd, IDC_SURFACE_ALPHA, byTemp, 256); i = 3; break;
					}
					for(i2 = 0; i2 < pLevel->pCurrentSurface->Header.iAniSteps; i2++)
					{
						pLevel->pCurrentSurface->pTexturePos[i2].fColor[i] = (float) atof(byTemp);
						if(pLevel->pCurrentSurface->pTexturePos[i2].fColor[i] < 0.0f)
							pLevel->pCurrentSurface->pTexturePos[i2].fColor[i] = 0.0f;
						if(pLevel->pCurrentSurface->pTexturePos[i2].fColor[i] > 1.0f)
							pLevel->pCurrentSurface->pTexturePos[i2].fColor[i] = 1.0f;
					}
				break;

				case ID_SURFACE_RESET_TEXTURE_VIEW:
					fTextureViewPos3[X] = fTextureViewPos3[Y] = 0.0f;
					fTextureViewPos3[Z] = 500.0f;
					fCursorPos[X] = 0.0f;
					fCursorPos[Y] = 0.0f;
				break;

				case ID_SURFACE_RESET_TEXTURE_VIEW2:
					fTextureViewPos2[X] = fTextureViewPos2[Y] = 0.0f;
					fTextureViewPos2[Z] = -5.0f;
				break;

				case IDC_SURFACE_NEXT_TIME:
					GetDlgItemText(hWnd, IDC_SURFACE_NEXT_TIME, byTemp, 256);
					pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].iTimeToNext = atoi(byTemp);
				break;

				case IDC_SURFACE_NEXT_TIME_ALL:
					for(i = 0; i < pLevel->pCurrentSurface->Header.iAniSteps; i++)
						pLevel->pCurrentSurface->pTexturePos[i].iTimeToNext = pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2].iTimeToNext;
				break;

				case IDC_SURFACE_ANIMATE:
					lTimer2 = g_lNow;
					bAnimation = !bAnimation;
					SurfaceUpdate();
				break;

				case IDC_SURFACE_COPY:
					KillTimer(hWnd, 1);
					if((i = DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_COPY_TEXTURE_POS), hWnd, (DLGPROC) CopyTexturePosProc)) == -1)
					{
						SetTimer(hWnd, 1, 1, NULL);
						break;
					}
					SetTimer(hWnd, 1, 1, NULL);
					memcpy(pLevel->pCurrentSurface->byTextureFilename[i], pLevel->pCurrentSurface->byTextureFilename[iCurrentTextureAniStep2], strlen(pLevel->pCurrentSurface->byTextureFilename[iCurrentTextureAniStep2]));
					memcpy(&pLevel->pCurrentSurface->pTexturePos[i], &pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2], sizeof(TEXTURE_POS));
					pLevel->pCurrentSurface->iTextureID[iCurrentTextureAniStep2] = pLevel->pCurrentSurface->iTextureID[i];
					pLevel->pCurrentSurface->pTexture[i] = pLevel->pCurrentSurface->pTexture[iCurrentTextureAniStep2];
					iCurrentTextureAniStep2 = i;
					goto Init;

				case IDC_SURFACE_COPY_LEFT:
					i = iCurrentTextureAniStep2;
					iCurrentTextureAniStep2--;
					if(iCurrentTextureAniStep2 < 0)
						iCurrentTextureAniStep2 = pLevel->pCurrentSurface->Header.iAniSteps-1;
					memset(pLevel->pCurrentSurface->byTextureFilename[iCurrentTextureAniStep2], 0, 256);
					memcpy(pLevel->pCurrentSurface->byTextureFilename[iCurrentTextureAniStep2], pLevel->pCurrentSurface->byTextureFilename[i], strlen(pLevel->pCurrentSurface->byTextureFilename[i]));
					memcpy(&pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2], &pLevel->pCurrentSurface->pTexturePos[i], sizeof(TEXTURE_POS));
					pLevel->pCurrentSurface->iTextureID[iCurrentTextureAniStep2] = pLevel->pCurrentSurface->iTextureID[i];
					pLevel->pCurrentSurface->pTexture[iCurrentTextureAniStep2] = pLevel->pCurrentSurface->pTexture[i];
					goto Init;

				case IDC_SURFACE_COPY_RIGHT:
					i = iCurrentTextureAniStep2;
					iCurrentTextureAniStep2++;
					if(iCurrentTextureAniStep2 >= pLevel->pCurrentSurface->Header.iAniSteps)
						iCurrentTextureAniStep2 = 0;
					memset(pLevel->pCurrentSurface->byTextureFilename[iCurrentTextureAniStep2], 0, 256);
					memcpy(pLevel->pCurrentSurface->byTextureFilename[iCurrentTextureAniStep2], pLevel->pCurrentSurface->byTextureFilename[i], strlen(pLevel->pCurrentSurface->byTextureFilename[i]));
					memcpy(&pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2], &pLevel->pCurrentSurface->pTexturePos[i], sizeof(TEXTURE_POS));
					pLevel->pCurrentSurface->iTextureID[iCurrentTextureAniStep2] = pLevel->pCurrentSurface->iTextureID[i];
					pLevel->pCurrentSurface->pTexture[iCurrentTextureAniStep2] = pLevel->pCurrentSurface->pTexture[i];
					goto Init;

					// Attributes:
					case IDC_SURFACE_AT_ALCOVE:
						pLevel->pCurrentSurface->Header.bAlcove = SendDlgItemMessage(hWnd, IDC_SURFACE_AT_ALCOVE, BM_GETCHECK, 0, 0L);
					break;

					case IDC_SURFACE_AT_RADIOACTIVE:
						pLevel->pCurrentSurface->Header.bRadioactive = SendDlgItemMessage(hWnd, IDC_SURFACE_AT_RADIOACTIVE, BM_GETCHECK, 0, 0L);
					break;

					case IDC_SURFACE_AT_HEALTH:
						pLevel->pCurrentSurface->Header.bHealth = SendDlgItemMessage(hWnd, IDC_SURFACE_AT_HEALTH, BM_GETCHECK, 0, 0L);
					break;

					case IDC_SURFACE_AT_EXIT:
						pLevel->pCurrentSurface->Header.bExit = SendDlgItemMessage(hWnd, IDC_SURFACE_AT_EXIT, BM_GETCHECK, 0, 0L);
					break;

					case IDC_SURFACE_AT_ANCHOR:
						pLevel->pCurrentSurface->Header.bAnchor = SendDlgItemMessage(hWnd, IDC_SURFACE_AT_ANCHOR, BM_GETCHECK, 0, 0L);
						SurfaceUpdate();
					break;

					case IDC_SURFACE_AT_COLOR_PAINTER:
						pLevel->pCurrentSurface->Header.bColorPainter = SendDlgItemMessage(hWnd, IDC_SURFACE_AT_COLOR_PAINTER, BM_GETCHECK, 0, 0L);
						SurfaceUpdate();
					break;

					case IDC_SURFACE_AT_BEAMER:
						pLevel->pCurrentSurface->Header.bBeamer = SendDlgItemMessage(hWnd, IDC_SURFACE_AT_BEAMER, BM_GETCHECK, 0, 0L);
						SurfaceUpdate();
					break;

					case IDC_SURFACE_AT_ANCHOR_TYPE:
						i = (short) SendDlgItemMessage(hWnd, IDC_SURFACE_AT_ANCHOR_TYPE, CB_GETCURSEL, 0, 0L);
						if(i < 0)
							i = 0;
						if(i > 4)
							i = 4;
						pLevel->pCurrentSurface->Header.byAnchorType = (char) i;
					break;

					case IDC_SURFACE_AT_COLOR_PAINTER_TYPE:
						i = (short) SendDlgItemMessage(hWnd, IDC_SURFACE_AT_COLOR_PAINTER_TYPE, CB_GETCURSEL, 0, 0L);
						if(i < 0)
							i = 0;
						if(i > 4)
							i = 4;
						pLevel->pCurrentSurface->Header.byColorPainterType = (char) i;
					break;

					case IDC_SURFACE_AT_CHANGE:
						pLevel->pCurrentSurface->Header.bChange = SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE, BM_GETCHECK, 0, 0L);
						SurfaceUpdate();
					break;

					case IDC_SURFACE_AT_CHANGE_ON_TIME_TIME:
						GetDlgItemText(hWnd, IDC_SURFACE_AT_CHANGE_ON_TIME_TIME, byTemp, 256);
						pLevel->pCurrentSurface->Header.lChangeTime = atoi(byTemp);
					break;

					case IDC_SURFACE_FRICTION:
						GetDlgItemText(hWnd, IDC_SURFACE_FRICTION, byTemp, 256);
						pLevel->pCurrentSurface->Header.fFriction = (float) atof(byTemp);
					break;

					case IDC_SURFACE_AT_CHANGE_SURFACE:
						i = (short) SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_SURFACE, CB_GETCURSEL, 0, 0L);
						if(i == -1 || i >= pLevel->Header.iSurfaces)
							break;
						pLevel->pCurrentSurface->Header.iChangeSurface = i;
					break;

					case IDC_SURFACE_AT_CHANGE_DESTROY:
						pLevel->pCurrentSurface->Header.bChangeDestroy = SendDlgItemMessage(hWnd, IDC_SURFACE_AT_CHANGE_DESTROY, BM_GETCHECK, 0, 0L);
						SurfaceUpdate();
					break;

					case IDC_SURFACE_ANIMATION_TOOL:
						if(iCurrentTextureAniStep2 < 0 || iCurrentTextureAniStep2 >= pLevel->pCurrentSurface->Header.iAniSteps)
							break;
						KillTimer(hWnd, 1);
						if(!DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_ANIMATION_TOOL), hWnd, (DLGPROC) AnimationToolProc))
						{
							SetTimer(hWnd, 1, 1, NULL);
							break;
						}
						SetTimer(hWnd, 1, 1, NULL);
						// Ok, we have the required information, now
						// create the animation:						
						iT = iCurrentTextureAniStep2;
						pTexturePosT = &pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2];
						iY = 0;
						for(i2 = 0, y = 0; y < AnimationTool.iRows; y++, iY += AnimationTool.iMoveY)
						{
							iX = 0;
							for(x = 0; x < AnimationTool.iColumns; x++, iCurrentTextureAniStep2++, iX += AnimationTool.iMoveX, i2++)
							{
								
								if(iT == iCurrentTextureAniStep2)
									continue;
								if(iCurrentTextureAniStep2 >= pLevel->pCurrentSurface->Header.iAniSteps ||
								  i2 >= AnimationTool.iSteps)
								{
									iCurrentTextureAniStep2 = iT;
									return TRUE;
								}
								// Setup the animation step:
								pTexturePosT2 = &pLevel->pCurrentSurface->pTexturePos[iCurrentTextureAniStep2];
								for(i = 0; i < 4; i++)
								{
									pTexturePosT2->iPos[i][X] = pTexturePosT->iPos[i][X]+iX;
									pTexturePosT2->iPos[i][Y] = pTexturePosT->iPos[i][Y]+iY;
								}
								pTexturePosT2->iTimeToNext = pTexturePosT->iTimeToNext;
								pLevel->pCurrentSurface->iTextureID[iCurrentTextureAniStep2] =
								pLevel->pCurrentSurface->iTextureID[iT];
								pLevel->pCurrentSurface->pTexture[iCurrentTextureAniStep2] =
								pLevel->pCurrentSurface->pTexture[iT];
								memset(pLevel->pCurrentSurface->byTextureFilename[iCurrentTextureAniStep2], 0, 256);
								strcpy(pLevel->pCurrentSurface->byTextureFilename[iCurrentTextureAniStep2],
									   pLevel->pCurrentSurface->byTextureFilename[iT]);
							}
						}
						pLevel->pCurrentSurface->CalculateFloatTexturePos();
						iCurrentTextureAniStep2 = iT;
					break;
            }
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_SURFACE_OK, 0);
		break;
    }
    return FALSE;
} // end SurfaceProc()

void SurfaceUpdate(void)
{ // begin SurfaceUpdate()
	if(!pLevel->pCurrentSurface->Header.bAnchor)
		EnableWindow(GetDlgItem(hWndSurface, IDC_SURFACE_AT_ANCHOR_TYPE), FALSE);
	else
		EnableWindow(GetDlgItem(hWndSurface, IDC_SURFACE_AT_ANCHOR_TYPE), TRUE);
	if(!pLevel->pCurrentSurface->Header.bColorPainter)
		EnableWindow(GetDlgItem(hWndSurface, IDC_SURFACE_AT_COLOR_PAINTER_TYPE), FALSE);
	else
		EnableWindow(GetDlgItem(hWndSurface, IDC_SURFACE_AT_COLOR_PAINTER_TYPE), TRUE);
	if(!bAnimation)
		SetDlgItemText(hWndSurface, IDC_SURFACE_ANIMATE, T_Play);
	else
		SetDlgItemText(hWndSurface, IDC_SURFACE_ANIMATE, T_Stop);
	// Change:
	if(!pLevel->pCurrentSurface->Header.bChange)
	{
		EnableWindow(GetDlgItem(hWndSurface, IDC_SURFACE_AT_CHANGE_DESTROY), FALSE);
		EnableWindow(GetDlgItem(hWndSurface, IDC_SURFACE_AT_CHANGE_ON_ENTER), FALSE);
		EnableWindow(GetDlgItem(hWndSurface, IDC_SURFACE_AT_CHANGE_ON_LEAVE), FALSE);
		EnableWindow(GetDlgItem(hWndSurface, IDC_SURFACE_AT_CHANGE_ON_TIME), FALSE);
		EnableWindow(GetDlgItem(hWndSurface, IDC_SURFACE_AT_CHANGE_ON_TIME_TIME), FALSE);
	}
	else
	{
		EnableWindow(GetDlgItem(hWndSurface, IDC_SURFACE_AT_CHANGE_DESTROY), TRUE);
		EnableWindow(GetDlgItem(hWndSurface, IDC_SURFACE_AT_CHANGE_ON_ENTER), TRUE);
		EnableWindow(GetDlgItem(hWndSurface, IDC_SURFACE_AT_CHANGE_ON_LEAVE), TRUE);
		EnableWindow(GetDlgItem(hWndSurface, IDC_SURFACE_AT_CHANGE_ON_TIME), TRUE);
		EnableWindow(GetDlgItem(hWndSurface, IDC_SURFACE_AT_CHANGE_ON_TIME_TIME), TRUE);
	}
} // end SurfaceUpdate()

LRESULT CALLBACK TexturesProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin TexturesProc()
    char *pbyTemp, byTemp[256], byTemp2[256], byTemp3[256];
	static POINT MousePos, OldMousePos;
	FLOAT3 *pFloat;
	RECT Rect;
	FILE *fp;
	short i;

	switch(iMessage)
    {
        case WM_INITDIALOG:
			if(hWndTextures)
			{
				EndDialog(hWnd, FALSE);
				break;
			}
		WholeInit:
			hWndTextures = hWnd;
			// Texts:
			SetWindowText(hWnd, T_Textures);
			SetDlgItemText(hWnd, ID_TEXTURES_OK, T_Ok);
			SetDlgItemText(hWnd, ID_TEXTURES_LOAD, T_Load);
			SetDlgItemText(hWnd, ID_TEXTURES_UNLOAD, T_Unload);
			SetDlgItemText(hWnd, ID_TEXTURES_UPDATE, T_Update);
			SetDlgItemText(hWnd, ID_TEXTURES_RESET_VIEW, T_Reset);
			//
			_AS->WriteLogMessage("Open textures dialog");
			hWndBitmap2 = GetDlgItem(hWnd, ID_TEXTURES_VIEW);
			ASInitOpenGL(NULL, hWndBitmap2, &hDCBitmap2, &hRCEditorShow, FALSE);
			SetTimer(hWnd, 1, 1, NULL);
			fTextureViewPos[X] = fTextureViewPos[Y] = 0.0f;
			fTextureViewPos[Z] = -3.0f;
		Init:
			if(!pLevel->Header.iTextures)
			{	
				EnableWindow(GetDlgItem(hWnd, ID_TEXTURES_UNLOAD), FALSE);
				pLevel->iCurrentTexture = 0;
				pLevel->pCurrentTexture = &pLevel->pTexture[pLevel->iCurrentTexture];
			}
			else
				if(pLevel->iCurrentTexture >= 0 || pLevel->iCurrentTexture <= pLevel->Header.iTextures)
					EnableWindow(GetDlgItem(hWnd, ID_TEXTURES_UNLOAD), TRUE);
			if(!pLevel->iCurrentTexture)
				EnableWindow(GetDlgItem(hWnd, ID_TEXTURES_UNLOAD), FALSE);
			SendDlgItemMessage(hWnd, ID_TEXTURE_LIST, LB_RESETCONTENT , 0, 0L);
			for(i = 0; i < pLevel->Header.iTextures; i++)
			{
				sprintf(byTemp, "%s (Used:%d)", pLevel->pTexture[i].byFilename, pLevel->pTexture[i].iUsed);
				SendDlgItemMessage(hWnd, ID_TEXTURE_LIST, LB_ADDSTRING, 0, (LPARAM) byTemp);
			}
			SendDlgItemMessage(hWnd, ID_TEXTURE_LIST, LB_SETCURSEL, pLevel->iCurrentTexture, 0L);
			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
		return TRUE;

		case WM_TIMER:
			if(!wglMakeCurrent(hDCBitmap2, hRCEditorShow))
				break;
			glDisable(GL_LIGHTING);
			glDisable(GL_FOG);
			glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
			glLoadIdentity();
			glTranslatef(fTextureViewPos[X], fTextureViewPos[Y], fTextureViewPos[Z]);
			glEnable(GL_TEXTURE_2D);
			if(pLevel->pCurrentTexture)
			{
				glBindTexture(GL_TEXTURE_2D, pLevel->pCurrentTexture->iOpenGLID);
				glBegin(GL_QUADS);
					glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f, -1.0f,  1.0f);
					glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f, -1.0f,  1.0f);
					glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f,  1.0f,  1.0f);
					glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f,  1.0f,  1.0f);
				glEnd();
			}
			ASSwapBuffers(hDCBitmap2, NULL, FALSE);
		break;

        case WM_LBUTTONDOWN: case WM_LBUTTONUP: case WM_RBUTTONDOWN:
        case WM_RBUTTONUP: case WM_MOUSEMOVE:
			i = wParam;
			memcpy(&OldMousePos, &MousePos, sizeof(POINT));
			GetCursorPos(&MousePos);
			GetWindowRect(hWnd, &Rect);
			GetWindowRect(hWndBitmap2, &Rect);
			pFloat = &fTextureViewPos;
			if(MousePos.x > Rect.left && MousePos.x < Rect.right &&
			   MousePos.y > Rect.top && MousePos.y < Rect.bottom)
			{ // The mouse is over the window enable view control:
				if(i & MK_LBUTTON && i & MK_RBUTTON)
					(*pFloat)[Z] -= (float) (MousePos.x-OldMousePos.x+MousePos.y-OldMousePos.y)/20;
				else
					if(i & MK_RBUTTON)
					{
						(*pFloat)[X] -= (float) (OldMousePos.x-MousePos.x)/100;
						(*pFloat)[Y] -= (float) (MousePos.y-OldMousePos.y)/100;
					}
			}
        break;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_TEXTURES_OK:
					if(hDCBitmap2 && !ReleaseDC(hWnd, hDCBitmap2))
						hDCBitmap2 = NULL;
					if(hWndTextures)
					{
						hWndTextures = NULL;
						EndDialog(hWnd, FALSE);
	 				}
					KillTimer(hWnd, 1);
					_AS->WriteLogMessage("Close textures dialog");
				return TRUE;
				
				case ID_TEXTURES_LOAD:
					sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyTexturesFile);
					KillTimer(hWnd, 1);
					pbyTemp = ASGetFileName(hWnd, T_LoadTexture, JPG_FILE, 0, TRUE, byTemp);
					SetTimer(hWndTextures, 1, 1, NULL);
					if(!pbyTemp)
						break;
					// 	
					fp = fopen(pbyTemp, "rb");
					if(fp) // It's only oen file:
					{
						fclose(fp);
						// Cut off the main path:
						strcpy(byTemp3, &pbyTemp[strlen(_AS->pbyProgramPath)]);
						//
						// Check if the texture is already loaded:
						for(i = 0; i < pLevel->Header.iTextures; i++)
						{
							if(!strcmp(pLevel->pTexture[i].byFilename, byTemp3))
							{ // This texture is already loaded:
								sprintf(byTemp, "%s: %s", byTemp3, M_TextureIsAlreadyLoaded);
								KillTimer(hWndTextures, 1);
								MessageBox(hWndTextures, byTemp, T_Info, MB_OK | MB_ICONINFORMATION);
								SetTimer(hWndTextures, 1, 1, NULL);
								return 0;
							}
						}
						pLevel->LoadTexture(byTemp3);
						SendDlgItemMessage(hWnd, ID_TEXTURE_LIST, LB_SETCURSEL, pLevel->iCurrentTexture, 0L);
						pLevel->DestroyTexturesOpenGL(hDCEditorShow, 
												  hRCEditorShow);
						pLevel->GenTexturesOpenGL(hDCEditorShow, 
												  hRCEditorShow);
						goto WholeInit;
					}
					//
					sscanf(pbyTemp, "%s", byTemp); // Read the path
					pbyTemp += strlen(byTemp)+1;
					// Load the selected files:
					for(;;)
					{
						if(sscanf(pbyTemp, "%s", byTemp2) == EOF)
							break;
						if(byTemp[strlen(byTemp)-1] != '\\')
							sprintf(byTemp3, "%s\\%s", byTemp, byTemp2);
						else
							sprintf(byTemp3, "%s%s", byTemp, byTemp2);
						// Check if the texture is already loaded:
						for(i = 0; i < pLevel->Header.iTextures; i++)
						{
							if(!strcmp(pLevel->pTexture[i].byFilename, byTemp3))
							{ // This texture is already loaded:
								sprintf(byTemp, "%s: %s", byTemp3, M_TextureIsAlreadyLoaded);
								KillTimer(hWndTextures, 1);
								MessageBox(hWndTextures, byTemp, T_Info, MB_OK | MB_ICONINFORMATION);
								SetTimer(hWndTextures, 1, 1, NULL);
								goto NextFile;
							}
						}
						// Cut off the main path:
						strcpy(byTemp3, &byTemp3[strlen(_AS->pbyProgramPath)]);
						//
						if(pLevel->LoadTexture(byTemp3))
							break;
					NextFile:
						if(*(pbyTemp+strlen(byTemp2)) == 0)
							break;
						pbyTemp += strlen(byTemp2)+1;
					}
					pLevel->DestroyTexturesOpenGL(hDCEditorShow, 
											  hRCEditorShow);
					pLevel->GenTexturesOpenGL(hDCEditorShow, 
											  hRCEditorShow);
					goto WholeInit;

				case ID_TEXTURES_UNLOAD:
					if(!pLevel->pCurrentTexture->iID)
						break;
					if(pLevel->pCurrentTexture->iUsed)
					{
						sprintf(byTemp, "%s %s %d)", pLevel->pCurrentTexture->byFilename,
													 M_TextureIsUsed, pLevel->pCurrentTexture->iUsed);
						KillTimer(hWndTextures, 1);
						if(MessageBox(hWndTextures, byTemp, T_Question, MB_YESNO | MB_ICONINFORMATION) == IDNO)
						{
							SetTimer(hWndTextures, 1, 1, NULL);
							break;
						}
						SetTimer(hWndTextures, 1, 1, NULL);
					}
					pLevel->DestroyTexture(pLevel->iCurrentTexture);
					goto WholeInit;

				case ID_TEXTURES_UPDATE:
					// Destroy old level bitmaps:
					pLevel->DestroyTexturesOpenGL(hDCEditorShow, hRCEditorShow);
					for(i = 0; i < pLevel->Header.iTextures; i++)
						if(pLevel->pTexture[i].pbyData)
							free(pLevel->pTexture[i].pbyData);

					// Load new level bitmaps:
					for(i = 0; i < pLevel->Header.iTextures; i++)
					{
						// Add the main path:
						sprintf(byTemp, "%s%s", _AS->pbyProgramPath, pLevel->pTexture[i].byFilename);
						// Check if the texture is there:
						fp = fopen(byTemp, "r");
						if(!fp)
						{ // A texture was not found!!
							sprintf(byTemp, "%s: %s ", pLevel->pTexture[i].byFilename, M_TextureWasNotFound);
							KillTimer(hWndTextures, 1);
							MessageBox(hWnd, byTemp, T_Error, MB_OK | MB_ICONINFORMATION);							
							SetTimer(hWndTextures, 1, 1, NULL);
							pLevel->DestroyTexture(i);
							goto Init;
							continue;
						}
						fclose(fp);
						ASLoadJpegRGB(&pLevel->pTexture[i], byTemp);
					}
					pLevel->GenTexturesOpenGL(hDCEditorShow, hRCEditorShow);
					goto WholeInit;

				case ID_TEXTURE_LIST:
					i = (short) SendDlgItemMessage(hWnd, ID_TEXTURE_LIST, LB_GETCURSEL, 0, 0L);
					if(i < 0 || i > pLevel->Header.iTextures-1)
					{
						pLevel->iCurrentTexture = -1;
						pLevel->pCurrentTexture = NULL;
					}
					else
					{
						pLevel->iCurrentTexture = i;
						pLevel->pCurrentTexture = &pLevel->pTexture[pLevel->iCurrentTexture];
					}
					if(pLevel->iCurrentTexture >= 0 || pLevel->iCurrentSurface <= pLevel->Header.iTextures)
						EnableWindow(GetDlgItem(hWnd, ID_TEXTURES_UNLOAD), TRUE);
					else
						EnableWindow(GetDlgItem(hWnd, ID_TEXTURES_UNLOAD), FALSE);
					goto Init;

				case ID_TEXTURES_RESET_VIEW:
					fTextureViewPos[X] = fTextureViewPos[Y] = 0.0f;
					fTextureViewPos[Z] = -5.0f;
				break;
			}
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_TEXTURES_OK, 0);
		break;
    }
    return FALSE;
} // end TexturesProc()

LRESULT CALLBACK CopyTexturePosProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin CopyTexturePosProc()
	char byTemp[256];
	short i;

    switch(iMessage)
    {
        case WM_INITDIALOG:
			sprintf(byTemp, "%s (Nr. %d)", T_CopyTexturePos, iCurrentTextureAniStep);
			SetWindowText(hWnd, byTemp);
			SetDlgItemText(hWnd, ID_COPY_TEXTURE_POS_OK, T_Ok);
			SetDlgItemText(hWnd, ID_COPY_TEXTURE_POS_CANCEL, T_Cancel);
			SendDlgItemMessage(hWnd, ID_COPY_TEXTURE_POS_LIST, CB_RESETCONTENT , 0, 0L);
			for(i = 0; i < pLevel->pCurrentSurface->Header.iAniSteps; i++)
			{
				sprintf(byTemp, "%d", i);
				SendDlgItemMessage(hWnd, ID_COPY_TEXTURE_POS_LIST, CB_ADDSTRING, 0, (LPARAM) byTemp);
			}
			SendDlgItemMessage(hWnd, ID_COPY_TEXTURE_POS_LIST, CB_SETCURSEL, iCurrentTextureAniStep2, 0L);
			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_COPY_TEXTURE_POS_OK:
					EndDialog(hWnd, SendDlgItemMessage(hWnd, ID_COPY_TEXTURE_POS_LIST, CB_GETCURSEL, 0, 0L));
                return TRUE;

                case ID_COPY_TEXTURE_POS_CANCEL:
					EndDialog(hWnd, -1);
                return TRUE;
            }
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_COPY_TEXTURE_POS_CANCEL, 0);
		break;
    }
    return FALSE;
} // end CopyTexturePosProc()

LRESULT CALLBACK SetAnimationStepsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin SetAnimationStepsProc()
	char byTemp[256];
	short i;

    switch(iMessage)
    {
        case WM_INITDIALOG:
			SetWindowText(hWnd, T_SetAnimationSteps);
			SetDlgItemText(hWnd, ID_SET_ANIMATION_STEPS_OK, T_Ok);
			SetDlgItemText(hWnd, ID_SET_ANIMATION_STEPS_CANCEL, T_Cancel);
			sprintf(byTemp, "%d", pLevel->pCurrentSurface->Header.iAniSteps);
			SetDlgItemText(hWnd, ID_SET_ANIMATION_STEPS_NUMBER, byTemp);
			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_SET_ANIMATION_STEPS_OK:
					GetDlgItemText(hWnd, ID_SET_ANIMATION_STEPS_NUMBER, byTemp, 256);
					i = (short) atoi(byTemp);
					if(!i)
						i++;
					EndDialog(hWnd, i);
                return TRUE;

                case ID_SET_ANIMATION_STEPS_CANCEL:
					EndDialog(hWnd, -1);
                return TRUE;
            }
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_SET_ANIMATION_STEPS_CANCEL, 0);
		break;
    }
    return FALSE;
} // end SetAnimationStepsProc()

LRESULT CALLBACK AnimationToolProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin AnimationToolProc()
	char byTemp[256];
	short i;

    switch(iMessage)
    {
        case WM_INITDIALOG:
			SetWindowText(hWnd, T_SetAnimationSteps);
			SetDlgItemText(hWnd, ID_ANIMATION_TOOL_OK, T_Ok);
			SetDlgItemText(hWnd, ID_ANIMATION_TOOL_CANCEL, T_Cancel);
			SetDlgItemText(hWnd, ID_ANIMATION_TOOL_ROWS_T, T_Rows);
			SetDlgItemText(hWnd, ID_ANIMATION_TOOL_COLUMNS_T, T_Columns);
			SetDlgItemText(hWnd, ID_ANIMATION_TOOL_MOVE_X_T, T_MoveX);
			SetDlgItemText(hWnd, ID_ANIMATION_TOOL_MOVE_Y_T, T_MoveY);
			SetDlgItemText(hWnd, ID_ANIMATION_TOOL_STEPS_T, T_Steps);

			if(AnimationTool.iRows <= 0)
				AnimationTool.iRows = 1;
			if(AnimationTool.iColumns <= 0)
				AnimationTool.iColumns = 1;
			if(AnimationTool.iSteps <= 0)
				AnimationTool.iSteps = 1;
			
			sprintf(byTemp, "%d", AnimationTool.iRows);
			SetDlgItemText(hWnd, ID_ANIMATION_TOOL_ROWS, byTemp);
			sprintf(byTemp, "%d", AnimationTool.iColumns);
			SetDlgItemText(hWnd, ID_ANIMATION_TOOL_COLUMNS, byTemp);
			sprintf(byTemp, "%d", AnimationTool.iMoveX);
			SetDlgItemText(hWnd, ID_ANIMATION_TOOL_MOVE_X, byTemp);
			sprintf(byTemp, "%d", AnimationTool.iMoveY);
			SetDlgItemText(hWnd, ID_ANIMATION_TOOL_MOVE_Y, byTemp);
			sprintf(byTemp, "%d", AnimationTool.iSteps);
			SetDlgItemText(hWnd, ID_ANIMATION_TOOL_STEPS, byTemp);

			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_ANIMATION_TOOL_OK:
					EndDialog(hWnd, TRUE);
                return TRUE;

                case ID_ANIMATION_TOOL_CANCEL:
					EndDialog(hWnd, FALSE);
                return FALSE;

				case ID_ANIMATION_TOOL_ROWS:
					GetDlgItemText(hWnd, ID_ANIMATION_TOOL_ROWS, byTemp, 256);
					i = (short) atoi(byTemp);
					if(i <= 0)
					{
						i = 1;
						SetDlgItemText(hWnd, ID_ANIMATION_TOOL_ROWS, "1");
					}
					AnimationTool.iRows = i;
				break;

				case ID_ANIMATION_TOOL_COLUMNS:
					GetDlgItemText(hWnd, ID_ANIMATION_TOOL_COLUMNS, byTemp, 256);
					i = (short) atoi(byTemp);
					if(i <= 0)
					{
						i = 1;
						SetDlgItemText(hWnd, ID_ANIMATION_TOOL_COLUMNS, "1");
					}
					AnimationTool.iColumns = i;
				break;

				case ID_ANIMATION_TOOL_MOVE_X:
					GetDlgItemText(hWnd, ID_ANIMATION_TOOL_MOVE_X, byTemp, 256);
					i = (short) atoi(byTemp);
					AnimationTool.iMoveX = i;
				break;

				case ID_ANIMATION_TOOL_MOVE_Y:
					GetDlgItemText(hWnd, ID_ANIMATION_TOOL_MOVE_Y, byTemp, 256);
					i = (short) atoi(byTemp);
					AnimationTool.iMoveY = i;
				break;

				case ID_ANIMATION_TOOL_STEPS:
					GetDlgItemText(hWnd, ID_ANIMATION_TOOL_STEPS, byTemp, 256);
					i = (short) atoi(byTemp);
					if(i <= 0)
					{
						i = 1;
						SetDlgItemText(hWnd, ID_ANIMATION_TOOL_STEPS, "1");
					}
					AnimationTool.iSteps = i;
				break;
            }
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_ANIMATION_TOOL_CANCEL, 0);
		break;
    }
    return FALSE;
} // end AnimationToolProc()
//-----------------------------------------------------------------------------
// File: Convey.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
AS_CAMERA *pCamera;			// The main game camera
HWND hWndCredits;			// The dialog handle of the credits dialog
BOOL bOnlyConfig,			// Should only the config dialog be shown? (no game run after this...)
	 bLoader;				// Started with the loader program?
// Cheats:
BOOL bCheatsActivated,		// Are the cheats active?
	 bInvulnerable,			// Are we invulnerable?
	 bFreeCamera,			// Is it allowed to move/rotate the camera absolutely free?
	 bAllLevels;			// Is it possible to select all levels?
// Master access: (only for me!! ;-)
BOOL bMasterAccess;			// Is the master access activated? (no keywords... hehe)
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int);
void ChangeDisplayMode(void);
void OpenCreditsDialog(HWND);
LRESULT CALLBACK CreditsProc(HWND, UINT, WPARAM, LPARAM);
///////////////////////////////////////////////////////////////////////////////


int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine, int iCmdShow)
{ // begin WinMain()
	BOOL bTemp, bOpenConfig, bGame, bEditor, bLanguage;
	char byTemp[MAX_PATH];
	LPSTR lpTemp;
	short i;

	// Startup the engine:
	_AS = new AS_ENGINE(hInstance, lpCmdLine, iCmdShow, TRUE);
	if(_AS->GetShutDown())
		return 1;
	
	// Setup the camera:
	pCamera = new AS_CAMERA;
	_ASCamera = pCamera;
	
	// Should we deactivate the program log?
	bTemp = _ASConfig->bLog;
	 _ASConfig->bLog = TRUE;
	if(!bTemp)
		_AS->WriteLogMessage("Deactivate the log");
	_ASConfig->bLog = bTemp;

	// Check if the selected language is available:
	bLanguage = FALSE;
	for(i = 0; i < iASLanguages; i++)
		if(!strcmp(pbyASLanguage[i], _ASConfig->byLanguage))
		{
			bLanguage = TRUE;
			break;
		}
	if(!bLanguage)
	{ // No this language isn't available:
		if(!iASLanguages)
		{ // Oh, no! There is no other language!!
			MessageBox(NULL, "There are no languages!!\nAs result there are no text's!",
					   GAME_NAME, MB_OK | MB_ICONINFORMATION);
		}
		else
		{ // Change to the first best language:
			sprintf(byTemp, "The selected language (%s) isn't available!!\nPlease choose an other language.\n",
					_ASConfig->byLanguage);
			MessageBox(NULL, byTemp, GAME_NAME, MB_OK | MB_ICONINFORMATION);
			strcpy(_ASConfig->byLanguage, pbyASLanguage[0]);
			SetLanguage(_ASConfig->byLanguage);
		}
	}
	else
		SetLanguage(_ASConfig->byLanguage);
	
	// Is this the first program start?:
	if(_ASConfig->bFirstRun)
	{ // Yep!
		_AS->WriteLogMessage("First program start detected");
		MessageBox(NULL, M_FirstProgramStart, GAME_NAME, MB_OK | MB_ICONINFORMATION);
	}

	// Check the given program parameters:
	bCheatsActivated = FALSE;
	bInvulnerable = FALSE;
	bFreeCamera = FALSE;
	bAllLevels = FALSE;
	bMasterAccess = FALSE;
	bOpenConfig = FALSE;
	bOnlyConfig = FALSE;
	bGame = FALSE;
	bEditor = FALSE;
	lpTemp = lpCmdLine;
	for(;;)
	{
		if(sscanf(lpTemp, "%s", byTemp) == EOF)
			break;
		// Check the program parameter:
		if(!strcmp(byTemp, "-config"))
			bOpenConfig = TRUE;
		if(!strcmp(byTemp, "-onlyconfig"))
			bOnlyConfig = TRUE;
		if(!strcmp(byTemp, "-loader"))
			bLoader = TRUE;
		if(!strcmp(byTemp, "-game"))
			bGame = TRUE;
		if(!strcmp(byTemp, "-editor"))
			bEditor = TRUE;
		// Check the cheats:
		if(!strcmp(byTemp, "-cheats"))
			bCheatsActivated = TRUE;
		if(!strcmp(byTemp, "-invulnerable"))
			bInvulnerable = TRUE;
		if(!strcmp(byTemp, "-free_camera"))
			bFreeCamera = TRUE;	
		if(!strcmp(byTemp, "-all_levels"))
			bAllLevels = TRUE;	
		// Check the master access:
		if(!strcmp(byTemp, "-MasterAccess"))
			bMasterAccess = TRUE;
		if(*(lpTemp+strlen(byTemp)) == 0)
			break;
		lpTemp += strlen(byTemp)+1;
	}
	
	// Is an error detected? (from the last run)
	if(_ASConfig->bError)
		MessageBox(NULL, M_ProgramWasNotSutDownCorrectlyAtLastTime, GAME_NAME, MB_OK | MB_ICONINFORMATION);
	
	// Check if we want to show the config dialog:
	if(bOpenConfig || bOnlyConfig || !bLanguage || _ASConfig->bFirstRun || _ASConfig->bError)
	{
		bFirstRunConfigDialog = TRUE;
		OpenConfigDialog(NULL);
		bFirstRunConfigDialog = FALSE;
	}
	

//	bAllLevels = TRUE;


	if(!bOnlyConfig)
	{


//		bCheatsActivated = TRUE;
//		bMasterAccess = TRUE;


		// Set the current program module:
//		_AS->SetModule(MODULE_EDITOR);
		_AS->SetModule(MODULE_GAME);

		// The given program parameter forces the program to go into the required game module:
		bShowLogos = TRUE;
		DestroyAutosave();
		if(bGame)
			_AS->SetModule(MODULE_GAME);
		else
			if(bEditor)
			{
				bShowLogos = FALSE;
				_AS->SetModule(MODULE_EDITOR);
			}

		// Go into the main loop:
		_ASConfig->bError = TRUE;
		_AS->WriteLogMessage("Go into program loop");
		for(;;)
		{
			if(_AS->GetShutDown())
				break;
			_AS->SetModule(_AS->GetNextModule());
			// Go into the current program module:
			
//			_AS->SetModule(MODULE_GAME);
			
			switch(_AS->GetModule())
			{
				case MODULE_GAME: Game(); break;
				case MODULE_EDITOR: Editor(); bShowLogos = FALSE; break;
			}
		}
	}
	if(bLoader)
	{
		sprintf(byTemp, "%sConveyLoader.exe", _AS->pbyProgramPath);
		ShellExecute(0, "open", byTemp, 0, 0, SW_SHOW);
	}
		
	// Delete the rest:
	delete pCamera;
	delete _AS;
	
	// That's all!
	return 0;
} // end WinMain()

void ChangeDisplayMode(void)
{ // begin ChangeDisplayMode()
	switch(_AS->GetModule())
	{
		case MODULE_GAME:
			// Destroy the old window:
			_AS->FreeDXInputDevices();
			_AS->DestroyDXAudio();
			ASDXShowClose();
			ASDestroyOpenGLTextures(GAME_TEXTURES, GameTexture);
			ASDestroyOpenGLTextures(4, GameTitleTexture);
			ASDestroyOpenGLTextures(GAME_MENU_TEXTURES, GameMenuTexture);
			ASDestroyOpenGLTextures(LOGOS_TEXTURES, LogosTexture);
			DestroyGameLists();

			if(pLevel)
				pLevel->DestroyTexturesOpenGL(*_AS->pWindow[GAME_WINDOW_ID].GethDC(), 
										      *_AS->pWindow[GAME_WINDOW_ID].GethRC());
			ASDestroyOpenGL(&_AS->pWindow[GAME_WINDOW_ID], 
							NULL,
							*_AS->pWindow[GAME_WINDOW_ID].GethDC(),
							*_AS->pWindow[GAME_WINDOW_ID].GethRC());
			_AS->ASDestroyWindow(_AS->pWindow[GAME_WINDOW_ID].GethWnd(), GAME_WINDOW_NAME);
			// Create the new window:
			_AS->ASCreateWindow(WindowProc, GAME_WINDOW_NAME, GAME_WINDOW_NAME, _ASConfig->iWindowWidth,
								_ASConfig->iWindowHeight, LoadMenu(_AS->GetInstance(), MAKEINTRESOURCE(IDR_GAME)),
								_ASConfig->bFullScreen, GameMenuDraw, GameMenuCheck, NULL, TRUE);
			if(!bInGameMenu)
			{
				_AS->pWindow[GAME_WINDOW_ID].SetDrawFunction(GameDraw);
				_AS->pWindow[GAME_WINDOW_ID].SetCheckFunction(GameCheck);
			}
			GAME_WINDOW_ID = _AS->GetWindows()-1;
			ASInitOpenGL(&_AS->pWindow[GAME_WINDOW_ID], 
  						 NULL,
						 _AS->pWindow[GAME_WINDOW_ID].GethDC(),
						 _AS->pWindow[GAME_WINDOW_ID].GethRC(), _ASConfig->bFullScreen);
			_AS->CreateDXInputDevices(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), FALSE, TRUE, TRUE, FALSE);
			_AS->CreateDXAudio(*_AS->pWindow[GAME_WINDOW_ID].GethWnd());
			if(pLevel)
			{	
				pLevel->GenTexturesOpenGL(*_AS->pWindow[GAME_WINDOW_ID].GethDC(), 
										  *_AS->pWindow[GAME_WINDOW_ID].GethRC());
				StartLevelMusic();
			}
			ASGenOpenGLTextures(GAME_TEXTURES, GameTexture);
			ASGenOpenGLTextures(4, GameTitleTexture);
			ASGenOpenGLTextures(GAME_MENU_TEXTURES, GameMenuTexture);
			ASGenOpenGLTextures(LOGOS_TEXTURES, LogosTexture);
			CreateGameLists();
			if(bInGameMenu)
				StartMenuMusic();
			Sleep(1); // If this isn't done the system will crash... maybe an windows message error??
			ShowWindow(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), SW_SHOW);
		break;
	}
} // end ChangeDisplayMode()

void OpenCreditsDialog(HWND hWnd)
{ // begin OpenCreditsDialog()
	DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CREDITS), hWnd, (DLGPROC) CreditsProc);
} // end OpenCreditsDialog()

LRESULT CALLBACK CreditsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin CreditsProc()
	char byTemp[256];

	switch(iMessage)
    {
        case WM_INITDIALOG:
				_AS->WriteLogMessage("Open credits dialog");
			    hWndCredits = hWnd;
				ShowWindow(hWnd, _AS->GetCmdShow());
				UpdateWindow(hWnd);
            	SetDlgItemText(hWnd, IDC_CREDITS_VERSION, _ASProgramInfo.byVersion);
            	SetDlgItemText(hWnd, IDC_CREDITS_BUILD_DATE, _ASProgramInfo.byDate);
            	SetDlgItemText(hWnd, IDC_CREDITS_BUILD_TIME, _ASProgramInfo.byTime);
				// Texts:
				SetWindowText(hWnd, T_Credits);
				SetDlgItemText(hWnd, IDC_CREDITS_VERSION_TEXT, T_Version_);
  				SetDlgItemText(hWnd, IDC_CREDITS_PROGRAMMING_AND_DESIGN, T_ProgrammingAndDesign_);
  				SetDlgItemText(hWnd, IDC_CREDITS_MUSIC, T_Music_);
  				SetDlgItemText(hWnd, IDC_CREDITS_HOMEPAGE, T_Homepage_);
  				SetDlgItemText(hWnd, IDC_CREDITS_E_MAIL, T_EMail_);
  				SetDlgItemText(hWnd, IDC_CREDITS_PROGRAM_INFO, T_ProgramInfo_);
  				SetDlgItemText(hWnd, IDC_CREDITS_BUILD, T_Build_);
  				SetDlgItemText(hWnd, IDC_CREDITS_OK, T_Ok);
  				SetDlgItemText(hWnd, IDC_CREDITS_MORE, T_MoreCredits);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case IDC_CREDITS_OK:
					EndDialog(hWnd, FALSE);
					hWndCredits = NULL;
					_AS->WriteLogMessage("Close credits dialog(OK)");
                return TRUE;

				case IDC_CREDITS_MORE:
					_AS->WriteLogMessage("Open help file");
					sprintf(byTemp, "%s%s", _AS->pbyProgramPath, T_CreditsFile);
					ShellExecute(0, "open", byTemp, 0, 0, SW_SHOW);
				break;
            }
        break;

		case WM_CLOSE:
			SendMessage(hWnd, WM_COMMAND, IDC_CREDITS_OK, 0);
		break;
    }
    return FALSE;
} // end CreditsProc()
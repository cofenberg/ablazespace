//-----------------------------------------------------------------------------
// File: Logos.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
AS_TEXTURE LogosTexture[LOGOS_TEXTURES];
BOOL bShowLogos;
// Logos sequence:
float fPublisherBox[3],
	  fBox[2][3];
ACTOR XeActor;
short iStep, iASLogoPSSystem;
long lLogoWaitTime;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
void Logos(void);
HRESULT LogosDraw(AS_WINDOW *);
HRESULT LogosCheck(AS_WINDOW *);
void DrawLogoBox(short [6]);
void InitLogos(void);
void SetLogosCamera(void);
///////////////////////////////////////////////////////////////////////////////


void Logos(void)
{ // begin Logos()
	MSG msg;


	DestroyGameParticleSystems();
	bShowLogos = TRUE;
	InitLogos();

	_AS->pWindow[GAME_WINDOW_ID].SetDrawFunction(LogosDraw);
	_AS->pWindow[GAME_WINDOW_ID].SetCheckFunction(LogosCheck);
	
	char byFilename[LOGOS_TEXTURES][256] = {"Box.jpg",
										    "Publisher.jpg",
											"AS.jpg"};
	ASLoadTextures(byFilename, LOGOS_TEXTURES, LogosTexture);
	ASGenOpenGLTextures(LOGOS_TEXTURES, LogosTexture);

	StartMenuMusic();

	
//	bShowLogos = FALSE;


	for(;;)
	{
		if(PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
		{
			if(!GetMessage(&msg, NULL, 0, 0))
				break;
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else
		{	
			if(_AS->GetShutDown() || _AS->CheckModuleChange() || !bShowLogos)
				PostQuitMessage(0);
			if(!_AS->GetActive())
				continue;
			_AS->UpdateWindows();
		}
	}

	ParticleManager.Destroy();
	ASDestroyOpenGLTextures(LOGOS_TEXTURES, LogosTexture);
	ASDestroyTextures(LOGOS_TEXTURES, LogosTexture);

	bInGameMenu = TRUE;

} // end Logos()

HRESULT LogosDraw(AS_WINDOW *pWindow)
{ // begin LogosDraw()
	GLfloat afLightData[4]  = {0.0f, 0.0f, 0.0f, 0.0f};
	short iTexture[6], i;
	
	afLightData[0] = 0.0f;
	afLightData[1] = 0.0f;
	afLightData[2] = 0.0f;
	afLightData[3] = 1.0f;
	glLightfv(GL_LIGHT1, GL_POSITION, afLightData);
	afLightData[0] = 1.0f;
	afLightData[1] = 1.0f;
	afLightData[2] = 1.0f;
	afLightData[3] = 1.0f;
	glLightfv(GL_LIGHT1, GL_AMBIENT, afLightData);
	glEnable(GL_LIGHT1);

	glEnable(GL_TEXTURE_2D);
	glEnable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);
	ASEnableLighting();

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	// Xe;
	glCullFace(GL_FRONT);
	SetLogosCamera();
	glTranslatef(XeActor.fWorldPos[X], XeActor.fWorldPos[Y]-0.15f, XeActor.fWorldPos[Z]-0.25f);
	glRotatef(XeActor.fRot[Y], 0.0f, 1.0f, 0.0f);
	glScalef(0.015f, 0.015f, 0.015f);
	glBindTexture(GL_TEXTURE_2D, GameTexture[XE_TEXTURE].iOpenGLID);
	ASDrawMd2FrameInt(pXeModel, XeActor.iAniStep, XeActor.iNextAniStep, XeActor.fModelInterpolation);
	glCullFace(GL_BACK);

	// Publisher box:
	SetLogosCamera();
	glRotatef(90.0f, 0.0f, 0.0f, 1.0f);
	glTranslatef(-0.6f+fPublisherBox[X], -0.5f+fPublisherBox[Y], 0.0f+fPublisherBox[Z]);
	for(i = 0; i < 6; i++)
		iTexture[i] = 0;
	iTexture[0] = 1;
	DrawLogoBox(iTexture);

	// Box:
	if(iStep >= 1 && iStep < 3)
	{
		for(i = 0; i < 6; i++)
			iTexture[i] = 0;
		SetLogosCamera();
		glRotatef(90.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(-0.6f+fBox[0][X], 0.5f+fBox[0][Y], 0.0f+fBox[0][Z]);
		DrawLogoBox(iTexture);

		SetLogosCamera();
		glRotatef(90.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(-0.6f+fBox[1][X], -1.5f+fBox[1][Y], 0.0f+fBox[1][Z]);
		DrawLogoBox(iTexture);
	}

	glLoadIdentity();
	glTranslatef(-50.0f, -20.0f, -110.0f);
	glDisable(GL_FOG);
	ParticleManager.Draw();
	
	ASSwapBuffers(*pWindow->GethDC(), pWindow, TRUE);

	glDisable(GL_LIGHT1);
	return 0;
} // end LogosDraw()

HRESULT LogosCheck(AS_WINDOW *pWindow)
{ // begin LogosCheck()
	AS_PARTICLE *pParticleT;
	short i, i2, i3;
	
	_AS->ReadDXInput(*pWindow->GethWnd());

	AnimateFont();
	ParticleManager.Check();

	// Publisher box;
	switch(iStep)
	{
		case 0: // Pull in publisher box:
			for(i = 0; i < 3; i++)
			{
				if(fPublisherBox[i] > 0.0f)
				{
					fPublisherBox[i] -= (float) g_lDeltatime/2000;
					if(fPublisherBox[i] < 0.0f)
					{
						fPublisherBox[i] = 0.0f;
						iStep++;
					}
				}
				else
				if(fPublisherBox[i] < 0.0f)
				{
					fPublisherBox[i] += (float) g_lDeltatime/2000;
					if(fPublisherBox[i] > 0.0f)
						fPublisherBox[i] = 0.0f;
					iStep++;
				}
			}
			XeActor.fWorldPos[X] = -(fPublisherBox[Y]+0.78f);
			if(XeActor.byAnimation != 2)
			{
				XeActor.byAnimation = 2;
				XeActor.iAniStep = pXeModel->Ani.anim[XeActor.byAnimation].firstFrame;
				XeActor.dwAniTime = g_lNow;
			}
			// Show the AS logo:
        	if(iASLogoPSSystem == -1)
			{
				iASLogoPSSystem = ParticleManager.AddNewSystem(PS_ASLogo, LogosTexture[2].iWidth*LogosTexture[2].iHeight, NULL, &GameTexture[12], &LogosTexture[2]);
				ParticleManager.pSystem[iASLogoPSSystem].bActive = TRUE;
				// Disort particles:
				for(i = 0; i < ParticleManager.pSystem[iASLogoPSSystem].iParticles; i++)
				{
					pParticleT = &ParticleManager.pSystem[iASLogoPSSystem].pParticle[i];
					for(i2 = 0; i2 < 3; i2++)
					{
						pParticleT->fPos[i2] = (float) (rand() % 200);
						pParticleT->fLastPos[i2] = pParticleT->fFixPos[i2];
					}
				}
			}
		break;
		
		case 1: // Pull in other boxes:
			for(i = 0; i < 2; i++)
			{
				for(i2 = 0; i2 < 3; i2++)
				{
					if(fBox[i][i2] > 0.0f)
					{
						fBox[i][i2] -= (float) g_lDeltatime/1000;
						if(fBox[i][i2] < 0.0f)
							fBox[i][i2] = 0.0f;
					}
					else
					if(fBox[i][i2] < 0.0f)
					{
						fBox[i][i2] += (float) g_lDeltatime/1000;
						if(fBox[i][i2] > 0.0f)
							fBox[i][i2] = 0.0f;
					}
				}
			}
			for(i = 0, i3 = 0; i < 2; i++)
			{
				for(i2 = 0; i2 < 3; i2++)
				{
					if(fBox[i][i2] == 0.0f)
						i3++;
				}
			}
			if(i3 >= 6)
			{
				iStep++;
				XeActor.fRot[Y] = 180.0f;
			}

			if(XeActor.byAnimation != 1)
			{
				XeActor.byAnimation = 1;
				XeActor.iAniStep = pXeModel->Ani.anim[XeActor.byAnimation].firstFrame;
				XeActor.dwAniTime = g_lNow;
			}
		break;
		
		case 2: // Pull out all boxes:
			fPublisherBox[Y] += (float) g_lDeltatime/2000;
			for(i = 0; i < 2; i++)
				fBox[i][Y] += (float) g_lDeltatime/2000;
			XeActor.fWorldPos[X] = -(fPublisherBox[Y]-1.8f);
			if(XeActor.fWorldPos[X] < (-2.0f))
			{
				iStep++;
			}
			if(XeActor.byAnimation != 2)
			{
				XeActor.byAnimation = 2;
				XeActor.iAniStep = pXeModel->Ani.anim[XeActor.byAnimation].firstFrame;
				XeActor.dwAniTime = g_lNow;
			}
		break;

		case 3:
			iStep++;
			lLogoWaitTime = g_lNow;
		break;

		case 4:
			if(g_lNow-lLogoWaitTime > 25000)
			{
				iStep++;
				ParticleManager.pSystem[iASLogoPSSystem].bGoingInActive = TRUE;
			}
		break;

		case 5:
			if(!ParticleManager.pSystem[iASLogoPSSystem].bActive)
				bShowLogos = FALSE;
		break;
	}

	// Xe:
	AnimateActorModel(&XeActor, *pXeModel, PLAYER_ANIMATION_SPEED, (char) XeActor.byAnimation);
	XeActor.fModelInterpolation = (float) (g_lNow-XeActor.dwAniTime)/PLAYER_ANIMATION_SPEED;

	for(i = 0; i < 256; i++)
		if(ASKeyFirst[i])
		{
			bShowLogos = FALSE;
			break;
		}

	return 0;
} // end LogosCheck()

void DrawLogoBox(short iTexture[6])
{ // begin DrawLogoBox()
	// Floor face
	glBindTexture(GL_TEXTURE_2D, LogosTexture[iTexture[0]].iOpenGLID);
	glBegin(GL_QUADS);
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 0.f); glVertex3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f(1.0f, 1.0f, 0.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f(0.0f, 1.0f, 0.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f(0.0f, 0.0f, 0.0f);
	glEnd();

	// Sky face
	glBindTexture(GL_TEXTURE_2D, LogosTexture[iTexture[1]].iOpenGLID);
	glBegin(GL_QUADS);
		glNormal3f(0.0f, 0.0f, -1.0f);
		glTexCoord2f(0.0f, 0.0f); glVertex3f(0.0f, 1.0f, -1.0f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f(1.0f, 1.0f, -1.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f(1.0f, 0.0f, -1.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f(0.0f, 0.0f, -1.0f);
	glEnd();
		
	// Back face
	glBindTexture(GL_TEXTURE_2D, LogosTexture[iTexture[2]].iOpenGLID);
	glBegin(GL_QUADS);
		glNormal3f(0.0f, 1.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f); glVertex3f(1.0f, 1.0f, 0.0f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f(1.0f, 1.0f, -1.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f(0.0f, 1.0f, -1.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f(0.0f, 1.0f, 0.0f);
	glEnd();

	// Bottom Face
	glBindTexture(GL_TEXTURE_2D, LogosTexture[iTexture[3]].iOpenGLID);
	glBegin(GL_QUADS);
		glNormal3f(0.0f, -1.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f); glVertex3f(0.0f, 0.0f, -1.0f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f(1.0f, 0.0f, -1.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f(0.0f, 0.0f, 0.0f);
	glEnd();
		
	// Right face
	glBindTexture(GL_TEXTURE_2D, LogosTexture[iTexture[4]].iOpenGLID);
	glBegin(GL_QUADS);
		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f); glVertex3f(1.0f, 0.0f, -1.0f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f(1.0f, 1.0f, -1.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f(1.0f, 1.0f, 0.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f(1.0f, 0.0f, 0.0f);
	glEnd();

	// Left Face
	glBindTexture(GL_TEXTURE_2D, LogosTexture[iTexture[5]].iOpenGLID);
	glBegin(GL_QUADS);
		glNormal3f(-1.0f, 0.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f); glVertex3f(0.0f, 1.0f, 0.0f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f(0.0f, 1.0f, -1.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f(0.0f, 0.0f, -1.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f(0.0f, 0.0f, 0.0f);
	glEnd();
} // end DrawLogoBox()

void InitLogos(void)
{ // begin InitLogos()
	short i;

	for(i = 0; i < 3; i++)
	{
		XeActor.fWorldPos[i] = XeActor.fRot[i] = fPublisherBox[i] =
		fBox[0][i] = fBox[1][i] = 0.0f;
	}
	fPublisherBox[Y] = 2.0f;
	fBox[0][Z] = 2.0f;
	fBox[1][Z] = -2.0f;
	fBox[1][Y] = -2.0f;
	
	
	iStep = 0; // 0


	XeActor.fWorldPos[X] = -(fPublisherBox[Y]+0.78f);
	iASLogoPSSystem = -1;
} // end InitLogos()

void SetLogosCamera(void)
{ // begin SetLogosCamera()
	glLoadIdentity();
	glTranslatef(0.0f, 0.0f, -1.5f);
	glRotatef(20.0f, 1.0f, 0.0f, 0.0f);
} // end SetLogosCamera()
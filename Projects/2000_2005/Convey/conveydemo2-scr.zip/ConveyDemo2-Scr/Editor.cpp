//-----------------------------------------------------------------------------
// File: Editor.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
extern short iCurrentEditorTab;
HWND hWndEditorShow;	   // The window handle for the level view window
HDC hDCEditorShow;		   // Private GDI device context for the level view window
HGLRC hRCEditorShow;	   // Permanent rendering context for the level view window
BOOL bEditorTestLevel,	   // Do we test a level at the moment?
	 bCameraAnimation,	   // Should we play a camera script?
	 bEditorHeavy,		   // Does we set a normal or a heavy box?
	 bIndestructibleWallStandart; // Is it standart that walls couldn't be destroyed?
char byEditorBrushSize,    // The brush size (radius)
     byEditorMenu,		   // The selected menu (in the editor dialog)
	 byEditorSelected,	   // The selected action (e.g. set a wall, set a object...)
	 byEditorSelectedID,   // The selected ID (e.g. from a field, object...)
	 byCurrentSkyCubeSide, // The selected sky-cube side
	 iEditorRotate,		   // The selected rotation (e.g. for surface rotating)
	 byEditorSelectedType; // The type of the selected thing (object, enemy)
int iEditorObjectsNumber, // The number of objects
	iEditorCurrentSurfaceType; // The selected surface (first or second)
long lCameraTimer;		   // The time variable for the camera script animation
short iFieldX, iFieldY;	   // The position of the current selected field (were the mouse is over)
float fEditorObjectVelocity; // The velocity of an object
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern LRESULT CALLBACK EditorProc(HWND, UINT, WPARAM, LPARAM);
HRESULT Editor(void);
HRESULT EditorDraw(void);
HRESULT EditorCheck(void);
void ManipulateColor(FLOAT3 *, short);
void ManipulateDensity(FLOAT *, short);
///////////////////////////////////////////////////////////////////////////////


HRESULT Editor(void)
{ // begin Editor()
//	return 0;

	_AS->WriteLogMessage("Enter editor module");
	// Open now the editor dialog:
	DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR), NULL, (DLGPROC) EditorProc);
	return 0;
} // end Editor()

HRESULT EditorDraw(void)
{ // begin EditorDraw()
//	char byTemp[256];
	// Check if we should update the level view window:
	if(hWndSurfaces || hWndSurface || hWndTextures ||
	   !wglMakeCurrent(hDCEditorShow, hRCEditorShow))
		return 0;

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	SetCameraTranslation(TRUE);
	pLevel->DrawSkyCube();
	pLevel->InitLevelDraw();
	ASEnableLighting();

	// Draw the level:
	glEnable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);
	SetCameraTranslation(FALSE);
	ASExtractFrustum();

	SetActorsLights();

	glColor3f(1.0f, 1.0f, 1.0f);
	pLevel->Draw(1);

	DrawActors();
	DrawPlayer();
	DrawEffects();

	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	SetCameraTranslation(FALSE);
	ParticleManager.Draw();
	ParticleManager.Check();

	pLevel->DrawTransparent();

	// Draw the water:
	SetCameraTranslation(FALSE);
	pLevel->DrawWater();

	// Draw a temporary background.
	glEnable(GL_BLEND);
	glEnable(GL_DEPTH_TEST);
	glColor4f(0.5f, 0.5f, 0.5f, 0.01f);
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_LIGHTING);
	glBegin(GL_QUADS);
		glVertex3d(0.0f, 0.0f, 1.0f+STANDART_LEVEL_Z_POS);
		glVertex3d(0.0f, (pLevel->Header.iHeight-1)*pLevel->Header.fFieldHeight, 1.0f+STANDART_LEVEL_Z_POS);
		glVertex3d((pLevel->Header.iWidth-1)*pLevel->Header.fFieldWidth, (pLevel->Header.iHeight-1)*pLevel->Header.fFieldHeight, 1.0f+STANDART_LEVEL_Z_POS);
		glVertex3d((pLevel->Header.iWidth-1)*pLevel->Header.fFieldWidth, 0.0f, 1.0f+STANDART_LEVEL_Z_POS);
	glEnd();
	glDisable(GL_BLEND);
	ASEnableLighting();


	// Show text:	
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glColor4f(1.0f, 1.0f, 1.0f, 0.95f);

/*
	 = x;
	pPlayer->iMultiAniStep[1] = y;
	sprintf(byTemp, "ID: %d   x: %d    y:%d", SelectedField, pLevel->pField[SelectedField].iXField, pLevel->pField[SelectedField].iYField);
	glPrint(10, 400, byTemp, 0);
*/

	ASSwapBuffers(hDCEditorShow, NULL, TRUE);
	pLevel->DeInitLevelDraw();
	return 0;
} // end EditorDraw()

HRESULT EditorCheck(void)
{ // begin EditorCheck()
	short i;

	// Check if we should update the level view window:
	if(hWndSurfaces || hWndSurface || hWndTextures || GetForegroundWindow() != hWndEditor)
		return 0;

	// Check the keys:
	if(CHECK_KEY(ASKeys, DIK_ESCAPE))
	{
		ASKeys[DIK_ESCAPE] = 0;
		if(!SaveLevelQuestion())
		{
			_AS->SetShutDown(TRUE);
			EndDialog(hWndEditor, FALSE);
		}
	}
	if(CHECK_KEY(ASKeys, DIK_F1))
	{ // Open the help file:
		ASKeys[DIK_F1] = 0;
		OpenHelp();
	}
	if(CHECK_KEY(ASKeys, DIK_F2))
	{ // Load a level:
		ASKeys[DIK_F2] = 0;
		SendMessage(hWndEditor, WM_COMMAND, ID_FILE_LEVEL_SAVE, 0);
	}
	if(CHECK_KEY(ASKeys, DIK_F3))
	{ // Save a level:
		ASKeys[DIK_F3] = 0;
		SendMessage(hWndEditor, WM_COMMAND, ID_FILE_LEVEL_LOAD, 0);
	}
	if(CHECK_KEY(ASKeys, DIK_F12))
	{ // Open the configuration menu:
		ASKeys[DIK_F12] = 0;
		SendMessage(hWndEditor, WM_COMMAND, ID_OPTIONS_CONFIG, 0);
	}

	if(CHECK_KEY(ASKeys, DIK_SPACE))
	{ // Open the configuration menu:
		for(i = 0; i < ParticleManager.pSystem[0].iParticles; i++)
			ParticleManager.pSystem[0].pParticle[i].bAlive = FALSE;
	}


	CheckCameraKeys(TRUE);
	CalculateCamersSinCos(); // Update the sin/cos for the camera

// Actors:
	CheckPlayer(TRUE);
	CheckActors(TRUE);
		
	if(PlayCameraScript(TRUE))
		return 0;
// Mouse usage for the level manipulaion:
	double fX, fY, fZ;
	char byColor, byColors;
	BOOL bTop, bFloor, bBoth, bTerrainChange = 0, bFieldChange = 0, iSurface;
	short iX, iY, iSize, iIncrease, iPoint, iSizeOne, iTemp, iActorType;
	float fDepth, fTopMiddle, fFloorMiddle, fGreatestTopHeight, fLowestTopHeight,
		  fGreatestFloorHeight, fLowestFloorHeight;
	double fModelViewMatrix[16], fProjectionMatrix[16];
	int iViewport[4];
	POINT MousePos;
	static POINT LastMousePos;
	FIELD *pFieldT;
	FLOAT3 *fPosT;
	RECT Rect;
	HWND hWndT;
	ACTOR *pActorT;

	// Disable all field selection:
	for(i = 0; i < pLevel->Header.iFields; i++)
		pLevel->pField[i].bSelected = FALSE;

	if(g_lNow-DisplayActor[0].dwAniTime > OBJECTS_ANI_SPEED)
	{
		DisplayActor[0].dwAniTime = g_lNow;
		DisplayActor[0].iAniStep++;
		if(DisplayActor[0].iAniStep > 3)
			DisplayActor[0].iAniStep = 0;
	}
	
	GetCursorPos(&MousePos);
	GetWindowRect(hWndEditorShow, &Rect);
	// Check if the mouse is in the level view area:
	if(MousePos.x > Rect.left &&
	   MousePos.x < Rect.right &&
	   MousePos.y > Rect.top &&
	   MousePos.y < Rect.bottom)
	{ // Yea, we are inside:
		goto ManipulateLevel;
	}
	else // Nope, the mouse isn't in the level view area:
		return 0;
	
ManipulateLevel:
	// Check mouse scrolling:
	if(_ASConfig->bMouseScroll)
	{
		if(MousePos.x < Rect.left+10)
		{
			pCamera->fPos[X] += fSin90*SCROLL_SPEED*g_lDeltatime;
			pCamera->fPos[Y] += fCos90*SCROLL_SPEED*g_lDeltatime;
		}
		if(MousePos.x > Rect.right-10)
		{
			pCamera->fPos[X] -= fSin90*SCROLL_SPEED*g_lDeltatime;
			pCamera->fPos[Y] -= fCos90*SCROLL_SPEED*g_lDeltatime;
		}
		if(MousePos.y < Rect.top+10)
		{
			pCamera->fPos[X] += fSin*SCROLL_SPEED*g_lDeltatime;
			pCamera->fPos[Y] += fCos*SCROLL_SPEED*g_lDeltatime;
		}
		if(MousePos.y > Rect.bottom-10)
		{
			pCamera->fPos[X] -= fSin*SCROLL_SPEED*g_lDeltatime;
			pCamera->fPos[Y] -= fCos*SCROLL_SPEED*g_lDeltatime;
		}
	}

	// Check the mouse on the level:
	// Get the 'real' mouse position in the level view area:
	MousePos.x -= Rect.left;
	MousePos.y -= Rect.top;

	// Check if the mouse should not be moved: (e.g. for changing terrain height)
	if((byEditorMenu == EDITOR_TERRAIN_MENU || byEditorMenu == EDITOR_ENVIRONMENT_MENU ||
	    byEditorMenu == EDITOR_SELECT_MENU)
	   && (CHECK_KEY(ASMouse.byButtons, 0) ||
	   CHECK_KEY(ASMouse.byButtons, 1) || CHECK_KEY(ASMouse.byButtons, 2)))
	{ // The user change the hight of some points or something like that:
		iIncrease = (short) ASMouse.lY;
		SetCursorPos(LastMousePos.x+Rect.left, LastMousePos.y+Rect.top);
	}
	else
	{
		memcpy(&LastMousePos, &MousePos, sizeof(POINT));
		iIncrease = 0;
		// Get the 'real' mouse position in the level view area:
		GetCursorPos(&MousePos);
		MousePos.x -= Rect.left;
		MousePos.y -= Rect.top;
		MousePos.y = Rect.bottom-Rect.top-MousePos.y;

		// Get the mouse position in our 3D world:
		glReadBuffer(GL_FRONT);
		glReadPixels(MousePos.x, MousePos.y, 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, &fDepth);
		glGetDoublev(GL_MODELVIEW_MATRIX, fModelViewMatrix);
		glGetDoublev(GL_PROJECTION_MATRIX, fProjectionMatrix);
		glGetIntegerv(GL_VIEWPORT, iViewport);
		gluUnProject(MousePos.x, MousePos.y, fDepth, fModelViewMatrix, fProjectionMatrix, iViewport, &fX, &fY, &fZ);

		// Calculate the current field we are on:
		if(byEditorMenu == EDITOR_TERRAIN_MENU) // We select points:
			COMPUTE_FIELD_POS(fX+pLevel->Header.fFieldWidth/2, fY+pLevel->Header.fFieldHeight/2, iFieldX, iFieldY)
		else // We select fields:
			COMPUTE_FIELD_POS(fX, fY, iFieldX, iFieldY)
	}
		
	// Setup some other stuff:
	iSize = byEditorBrushSize;
	if(pLevel->pCurrentField && byEditorMenu == EDITOR_SELECT_MENU)
		pLevel->pCurrentField->bSelected = TRUE;
	hWndT = hWndEditorTab[TAB_EDITOR_TERRAIN];
	bTop = IsDlgButtonChecked(hWndT, IDC_EDITOR_TERRAIN_TOP);
	bFloor = IsDlgButtonChecked(hWndT, IDC_EDITOR_TERRAIN_FLOOR);
	bBoth = IsDlgButtonChecked(hWndT, IDC_EDITOR_TERRAIN_BOTH);

	if(byEditorMenu == EDITOR_ENVIRONMENT_MENU)
	{ // We change the environment of our world:
		switch(byEditorSelected)
		{
			case EDITOR_ENVIRONMENT_LIGHT: // Change the world's light
				ManipulateColor(&pLevel->Environment.fColor, iIncrease);
			break;

			case EDITOR_ENVIRONMENT_FOG_COLOR: // Change the fog light
				ManipulateColor(&pLevel->Environment.fFogColor, iIncrease);
			break;

			case EDITOR_ENVIRONMENT_FOG_DENSITY: // Change the fog density
				ManipulateDensity(&pLevel->Environment.fFogDensity, iIncrease);
			break;

			case EDITOR_ENVIRONMENT_WATER_COLOR: // Change the water color
				ManipulateColor(&pLevel->Environment.fWaterColor, iIncrease);
			break;

			case EDITOR_ENVIRONMENT_WATER_DENSITY: // Change the water density
				ManipulateDensity(&pLevel->Environment.fWaterDensity, iIncrease);
			break;

			case EDITOR_ENVIRONMENT_WATER_HEIGHT: // Change the water height
				if(CHECK_KEY(ASMouse.byButtons, 0))
				{
					pLevel->Environment.fWaterHeight += iIncrease/500.0f;
					break;
				}
				if(CHECK_KEY(ASMouse.byButtons, 1))
					pLevel->Environment.fWaterHeight = STANDART_LEVEL_Z_POS-0.3f;
			break;

			case EDITOR_ENVIRONMENT_WATER_AMPLITUDE: // Change the water amplitude
				if(CHECK_KEY(ASMouse.byButtons, 0))
				{
					pLevel->Environment.fWaterAmplitude += iIncrease/50.0f;
					if(pLevel->Environment.fWaterAmplitude < 0.0f)
						pLevel->Environment.fWaterAmplitude = 0.0f;
					break;
				}
				if(CHECK_KEY(ASMouse.byButtons, 1))
					pLevel->Environment.fWaterAmplitude = 1.0f;
			break;

			case EDITOR_ENVIRONMENT_WATER_SPEED: // Change the water speed
				if(CHECK_KEY(ASMouse.byButtons, 0))
				{
					pLevel->Environment.fWaterSpeed += iIncrease/500.0f;
					if(pLevel->Environment.fWaterSpeed < 0.0f)
						pLevel->Environment.fWaterSpeed = 0.0f;
					break;
				}
				if(CHECK_KEY(ASMouse.byButtons, 1))
					pLevel->Environment.fWaterSpeed = 1.0f;
			break;
			
			case EDITOR_ENVIRONMENT_WATER_ENVIRONMENT_COLOR:
				ManipulateColor(&pLevel->Environment.fWaterEnvironmentColor, iIncrease);
			break;

			case EDITOR_ENVIRONMENT_SKY_CUBE_COLOR: // Change the sky-cube color
				ManipulateColor(&pLevel->Environment.fSkyCubeColor, iIncrease);
			break;

			case EDITOR_ENVIRONMENT_SKY_CUBE_SIZE: // Change the sky-cube size
				byColor = -1;
				byColors = 1;
				// Which color we have to manipulate?
				if(CHECK_KEY(ASMouse.byButtons, 0) && CHECK_KEY(ASMouse.byButtons, 1))
					byColors = 3;
				if(CHECK_KEY(ASMouse.byButtons, 0))
					byColor = R;
				else
				if(CHECK_KEY(ASMouse.byButtons, 1))
					byColor = G;
				else
				if(CHECK_KEY(ASMouse.byButtons, 2))
					byColor = B;
				if(byColor == -1 && byColors == 1)
					break;
				for(i = 0; i < byColors; i++)
				{
					if(byColors == 3)
						byColor = (char) i;
					pLevel->Environment.fSkyCubeSize[byColor] += iIncrease;
				}
			break;
		}
		return 0;
	}

	// Is the mouse in the level?
	if(iFieldX < 0 || iFieldY < 0 || iFieldX >= pLevel->Header.iWidth || iFieldY >= pLevel->Header.iHeight)
		return 0; // The mouse is not on the level
	
	// The mouse is on a field:
	fTopMiddle = fFloorMiddle = fGreatestTopHeight = fLowestTopHeight = fGreatestFloorHeight =
	fLowestFloorHeight = STANDART_LEVEL_Z_POS;
	i = 0;
	
	// Get some data from the selected field's: (middle hight, greatest hight...)
	if(byEditorMenu == EDITOR_SELECT_MENU)
		iSize = 0;
	if(!iSize)
	{
		iY = iFieldY;
		iSizeOne = 1;
	}
	else
	{
		iSizeOne = 0;
		iY = iFieldY-iSize;
		if(iSize > 1)
			iY++;
	}
	if(iY < 0)
		iY = 0;
	
	pPlayer->iMultiAniStep[0] = iFieldX;
	pPlayer->iMultiAniStep[1] = iFieldY;

	if(byEditorMenu == EDITOR_TERRAIN_MENU)
		iTemp = 0;
	else
		iTemp = -1;
	for(iPoint = 3; iY < iFieldY+iSize+iSizeOne; iY++)
	{
		if(iY >= pLevel->Header.iHeight+iTemp)
			break;
		if(!iSize)
			iX = iFieldX;
		else
		{
			iX = iFieldX-iSize;
			if(iSize > 1)
				iX++;
		}
		if(iX < 0)
			iX = 0;
		for(; iX < iFieldX+iSize+iSizeOne; iX++)
		{
			if(iX >= pLevel->Header.iWidth+iTemp)
				continue;
			pFieldT = &pLevel->pField[iY*pLevel->Header.iWidth+iX];
			if(byEditorMenu != EDITOR_ENVIRONMENT_MENU)
				pFieldT->bSelected = TRUE;
			// Calculate the middle value:
			fTopMiddle += pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z];
			if(pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] < fGreatestTopHeight)
				fGreatestTopHeight = pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z];
			if(pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] > fLowestTopHeight)
				fLowestTopHeight = pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z];
			fFloorMiddle += pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z];
			if(pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] < fGreatestFloorHeight)
				fGreatestFloorHeight = pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z];
			if(pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] > fLowestFloorHeight)
				fLowestFloorHeight = pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z];
			i++;
		}
	}
	fTopMiddle /= i;
	fFloorMiddle /= i;
	
	// Now find out what we should do and make it:
	if(!iSize)
		iY = iFieldY;
	else
	{
		iY = iFieldY-iSize;
		if(iSize > 1)
			iY++;
	}
	if(iY < 0)
		iY = 0;

	for(i = 0; i < MAX_ACTORS; i++)
	{
		if(!Actor[i].bActive)
			continue;
		if(Actor[i].byType != ACTOR_ENEMY_MOBMOB &&
		   Actor[i].byType != ACTOR_ENEMY_X3 &&
		   Actor[i].byType != ACTOR_ENEMY_HIRO)
			continue;
		pLevel->pField[Actor[i].iFieldID].pEnemy = &Actor[i];
	}

	for(iPoint = 3; iY < iFieldY+iSize+iSizeOne; iY++)
	{
		if(iY >= pLevel->Header.iHeight+iTemp)
			break;
		if(!iSize)
			iX = iFieldX;
		else
		{
			iX = iFieldX-iSize;
			if(iSize > 1)
				iX++;
		}
		if(iX < 0)
			iX = 0;
		for(; iX < iFieldX+iSize+iSizeOne; iX++)
		{
			if(iX >= pLevel->Header.iWidth+iTemp)
				continue;
			pFieldT = &pLevel->pField[iY*pLevel->Header.iWidth+iX];
			
			// Now what should be done?
			if(byEditorMenu == EDITOR_SELECT_MENU)
			{
				if(!pLevel->pCurrentField->pDecoration && byEditorSelected != EDITOR_SELECTED_BEAMER_TARGET)
					byEditorSelected = -1;
				switch(byEditorSelected)
				{
					case EDITOR_SELECTED_DECORATION_POSITION:
						if(CHECK_KEY(ASMouse.byButtons, 2))
						{
							pLevel->pCurrentField->pDecoration->fPos[X] = (float) (pLevel->pCurrentField->iXPos*pLevel->Header.fFieldWidth)+0.5f;
							pLevel->pCurrentField->pDecoration->fPos[Y] = (float) (pLevel->pCurrentField->iYPos*pLevel->Header.fFieldHeight)+0.5f;
							pLevel->pCurrentField->pDecoration->fPos[Z] = pLevel->FastComputeHeight(pLevel->pCurrentField->pDecoration->fPos[X],
																									pLevel->pCurrentField->pDecoration->fPos[Y],
																									FACE_FLOOR);
							pLevel->pCurrentField->pDecoration->fPos[Z] -= (pDecorationModels[iCurrentDecorationModel].pModel->fBoundingBox[1][Z]-
															  pDecorationModels[iCurrentDecorationModel].pModel->fBoundingBox[0][Z])*0.03f;
						}
						else
						if(CHECK_KEY(ASMouse.byButtons, 0) && CHECK_KEY(ASMouse.byButtons, 1))
						{
							pLevel->pCurrentField->pDecoration->fPos[Z] += (float) iIncrease/100;
						}
						else
						{
							if(CHECK_KEY(ASMouse.byButtons, 0))
							{
								pLevel->pCurrentField->pDecoration->fPos[X] += (float) iIncrease/100;
							}
							if(CHECK_KEY(ASMouse.byButtons, 1))
							{
								pLevel->pCurrentField->pDecoration->fPos[Y] += (float) iIncrease/100;
							}
						}
					break;

					case EDITOR_SELECTED_DECORATION_ROTATION:
						if(CHECK_KEY(ASMouse.byButtons, 2))
						{
							pLevel->pCurrentField->pDecoration->fRot[X] = -90.0f;
							pLevel->pCurrentField->pDecoration->fRot[Y] = 0.0f;
							pLevel->pCurrentField->pDecoration->fRot[Z] = 0.0f;
						}
						else
						if(CHECK_KEY(ASMouse.byButtons, 0) && CHECK_KEY(ASMouse.byButtons, 1))
						{
							pLevel->pCurrentField->pDecoration->fRot[Z] += (float) iIncrease/5;
						}
						else
						{
							if(CHECK_KEY(ASMouse.byButtons, 0))
							{
								pLevel->pCurrentField->pDecoration->fRot[X] += (float) iIncrease/5;
							}
							if(CHECK_KEY(ASMouse.byButtons, 1))
							{
								pLevel->pCurrentField->pDecoration->fRot[Y] += (float) iIncrease/5;
							}
						}
					break;

					case EDITOR_SELECTED_DECORATION_SIZE:
						if(CHECK_KEY(ASMouse.byButtons, 2))
						{
							pLevel->pCurrentField->pDecoration->fSize[0] = 
							pLevel->pCurrentField->pDecoration->fSize[1] = 
							pLevel->pCurrentField->pDecoration->fSize[2] = 1.0f;
						}
						else
						if(CHECK_KEY(ASMouse.byButtons, 0) && CHECK_KEY(ASMouse.byButtons, 1))
						{
							pLevel->pCurrentField->pDecoration->fSize[Z] += (float) iIncrease/100;
						}
						else
						{
							if(CHECK_KEY(ASMouse.byButtons, 0))
							{
								pLevel->pCurrentField->pDecoration->fSize[X] += (float) iIncrease/100;
							}
							if(CHECK_KEY(ASMouse.byButtons, 1))
							{
								pLevel->pCurrentField->pDecoration->fSize[Y] += (float) iIncrease/100;
							}
						}
					break;
				
					default:
						if(!CHECK_KEY(ASMouse.byButtons, 0))
							break;
						if(byEditorSelected == EDITOR_SELECTED_BEAMER_TARGET)
						{
							byEditorSelected = -1;
							if(pLevel->pCurrentField->iID == pFieldT->iID)
							{
								pLevel->pCurrentField->iBeamerTarget = -1;
								pLevel->pCurrentField->iBeamerParticleSystemID = -1;
							}
							else
								pLevel->pCurrentField->iBeamerTarget = pFieldT->iID;
							break;
						}
						pLevel->pCurrentField = pFieldT;
						iCurrentEditorTab = -1;
						SendMessage(hWndEditor, WM_NOTIFY, IDC_EDITOR_TAB, 0);
					break;
				}
				continue;
			}
			if(byEditorMenu == EDITOR_DECORATION_MENU)
			{
				if(CHECK_KEY(ASMouse.byButtons, 0) &&
				   iCurrentDecorationModel != -1 &&
				   !pFieldT->pDecoration)
				{ // Set decoration:
					pFieldT->pDecoration = (FIELD_DECORATION *) malloc(sizeof(FIELD_DECORATION));
					memset(pFieldT->pDecoration, 0, sizeof(FIELD_DECORATION));
					pFieldT->pDecoration->fPos[X] = (float) (pFieldT->iXPos*pLevel->Header.fFieldWidth)+0.5f;
					pFieldT->pDecoration->fPos[Y] = (float) (pFieldT->iYPos*pLevel->Header.fFieldHeight)+0.5f;
					pFieldT->pDecoration->fPos[Z] = pLevel->FastComputeHeight(pFieldT->pDecoration->fPos[X],
																			  pFieldT->pDecoration->fPos[Y],
																			  FACE_FLOOR);
					pFieldT->pDecoration->fRot[X] = -90.0f;
					pFieldT->pDecoration->fSize[0] = 
					pFieldT->pDecoration->fSize[1] = 
					pFieldT->pDecoration->fSize[2] = 1.0f;
					pFieldT->pDecoration->bAnimated = bDecorationModelAnimated;
					pFieldT->pDecoration->iDecorationID = iCurrentDecorationModel;
					pFieldT->pDecoration->iSpeed = iDecorationModelSpeed;
					pFieldT->pDecoration->iTexture = iCurrentModelTexture;
					pFieldT->pDecoration->byAnimation = (char) iCurrentDecorationModelAnimation;
					if(pFieldT->pDecoration->iTexture >= 0)
					{
						pLevel->pTexture[pFieldT->pDecoration->iTexture].iUsed++;
						strcpy(pFieldT->pDecoration->byTextureFilename, pLevel->pTexture[pFieldT->pDecoration->iTexture].byFilename);
					}
				}
				if(CHECK_KEY(ASMouse.byButtons, 1))
				{ // Delete decoration:
					if(pFieldT->pDecoration)
					{
						if(pFieldT->pDecoration->iTexture >= 0)
							pLevel->pTexture[pFieldT->pDecoration->iTexture].iUsed++;
						SAFE_DELETE(pFieldT->pDecoration);
					}
				}
				continue;
			}
			if(byEditorMenu == EDITOR_OBJECT_MENU)
			{ // We set some stuff into your level:
				switch(byEditorSelectedType)
				{
					case OBJECT:
						switch(byEditorSelected)
						{
							case EDITOR_SELECTED_OBJECT_XE:
								if(CHECK_KEY(ASMouse.byButtons, 1))
								{
									bFieldChange = TRUE;
									pPlayer->bActive = FALSE;
									pLevel->pField[pPlayer->iFieldID].pActor = NULL;
									break;
								}
								if(!CHECK_KEY(ASMouse.byButtons, 0))
									break;
								if(pFieldT->bWall || !pFieldT->bActive || (pFieldT->pBridgeActor && pFieldT->pBridgeActor->bBridgeMovement))
									break;
								bFieldChange = TRUE;
								if(pPlayer->iFieldID > 0 && pPlayer->iFieldID < pLevel->Header.iFields)
									pLevel->pField[pPlayer->iFieldID].pActor = NULL;
								memset(pPlayer, 0, sizeof(ACTOR));
								pPlayer->bActive = TRUE;
								pPlayer->fPower = 1.0f;
								pPlayer->iFieldPos[X] = iX;
								pPlayer->iFieldPos[Y] = iY;
								pPlayer->byType = ACTOR_PLAYER;
								pPlayer->byDirection = iEditorRotate;
								pPlayer->fLastHeightCheckWorldPos[X] = -1.0f;
								pPlayer->fLastHeightCheckWorldPos[Y] = -1.0f;
								pPlayer->fRot[Y] = pPlayer->byDirection*90.0f;
								pPlayer->iFieldID = pFieldT->iID;
								pPlayer->fColor[0] = 1.0f;
								pPlayer->fColor[1] = 1.0f;
								pPlayer->fColor[2] = 1.0f;
								pPlayer->fAir = 1.0f;
							break;

							case EDITOR_SELECTED_OBJECT_BOX_NORMAL:
							case EDITOR_SELECTED_OBJECT_BOX_RED:
							case EDITOR_SELECTED_OBJECT_BOX_GREEN:
							case EDITOR_SELECTED_OBJECT_BOX_BLUE:
								if(CHECK_KEY(ASMouse.byButtons, 1))
								{
									bFieldChange = TRUE;
									if(pFieldT->pActor && 
									  (pFieldT->pActor->byType == ACTOR_BOX_NORMAL ||
									   pFieldT->pActor->byType == ACTOR_BOX_RED ||
									   pFieldT->pActor->byType == ACTOR_BOX_GREEN ||
									   pFieldT->pActor->byType == ACTOR_BOX_BLUE))
									{ // Delete this box;
										pFieldT->pActor->bActive = FALSE;
										pFieldT->bWall = FALSE;
										pFieldT->pActor = NULL;
									}
									else
									if(pFieldT->pBridgeActor)
									{ // Delete the bridge actor;
										pFieldT->pBridgeActor->bActive = FALSE;
										pFieldT->pBridgeActor = NULL;
										pFieldT->bActive = FALSE;
									}
									break;
								}
								if(!CHECK_KEY(ASMouse.byButtons, 0))
									break;
								if((pFieldT->bWall && pFieldT->bActive) || pFieldT->pActor ||
								   (pFieldT->pBridgeActor && pFieldT->pBridgeActor->bBridgeMovement) ||
								   pFieldT->pEnemy)
									break;
								bFieldChange = TRUE;
								// Set a box on this field:
								pActorT	= FindFreeActor();
								if(!pActorT)
									break;
								pActorT->bActive = TRUE;
								pActorT->iFieldPos[X] = iX;
								pActorT->iFieldPos[Y] = iY;
								pActorT->fWorldPos[X] = pActorT->iFieldPos[X]*pLevel->Header.fFieldWidth+pActorT->fFieldPos[X]+pActorT->fPosTemp[X];
								pActorT->fWorldPos[Y] = pActorT->iFieldPos[Y]*pLevel->Header.fFieldHeight+pActorT->fFieldPos[Y]+pActorT->fPosTemp[Y];
								pActorT->fSize = 1.0f;
								pActorT->bHeavy = bEditorHeavy;
								switch(byEditorSelected)
								{
									case EDITOR_SELECTED_OBJECT_BOX_NORMAL:
										pActorT->byType = ACTOR_BOX_NORMAL;
										pActorT->fColor[0] = 1.0f; pActorT->fColor[1] = 1.0f; pActorT->fColor[2] = 1.0f;
									break;
									
									case EDITOR_SELECTED_OBJECT_BOX_RED:
										pActorT->byType = ACTOR_BOX_RED;
										pActorT->fColor[0] = 1.0f; pActorT->fColor[1] = 0.0f; pActorT->fColor[2] = 0.0f;
									break;
									
									case EDITOR_SELECTED_OBJECT_BOX_GREEN:
										pActorT->byType = ACTOR_BOX_GREEN;
										pActorT->fColor[0] = 0.0f; pActorT->fColor[1] = 1.0f; pActorT->fColor[2] = 0.0f;
									break;
									
									case EDITOR_SELECTED_OBJECT_BOX_BLUE:
										pActorT->byType = ACTOR_BOX_BLUE;
										pActorT->fColor[0] = 0.0f; pActorT->fColor[1] = 0.0f; pActorT->fColor[2] = 1.0f;
									break;
								}						
								pActorT->iFieldID = pFieldT->iID;
								pActorT->fLastHeightCheckWorldPos[X] = -1.0f;
								pActorT->fLastHeightCheckWorldPos[Y] = -1.0f;
								if(!pFieldT->bActive)
								{
									pFieldT->bActive = TRUE;
									ComputeActorHeight(pActorT, 0.5f);
									pFieldT->bActive = FALSE;
								}
								else
									ComputeActorHeight(pActorT, 0.5f);
							break;

							case EDITOR_SELECTED_OBJECT_HEALTH:
							case EDITOR_SELECTED_OBJECT_LIVE:
							case EDITOR_SELECTED_OBJECT_PULL:
							case EDITOR_SELECTED_OBJECT_THROW:
							case EDITOR_SELECTED_OBJECT_FORCE:
							case EDITOR_SELECTED_OBJECT_WEAPON:
							case EDITOR_SELECTED_OBJECT_POINT:
							case EDITOR_SELECTED_OBJECT_GHOST:
							case EDITOR_SELECTED_OBJECT_TIME:
							case EDITOR_SELECTED_OBJECT_STEP:
							case EDITOR_SELECTED_OBJECT_SPEED:
							case EDITOR_SELECTED_OBJECT_WING:
							case EDITOR_SELECTED_OBJECT_SHIELD:
							case EDITOR_SELECTED_OBJECT_JUMP:
							case EDITOR_SELECTED_OBJECT_AIR:
								if(CHECK_KEY(ASMouse.byButtons, 1))
								{
									if(pFieldT->pObject)
										pFieldT->pObject->bActive = FALSE;
									pFieldT->pObject = NULL;
									break;
								}
								if(!CHECK_KEY(ASMouse.byButtons, 0))
									break;
								if((pFieldT->bWall && !pFieldT->pActor) || pFieldT->pObject)
									break;
								pActorT	= FindFreeActor();
								if(!pActorT)
									break;
								pActorT->bActive = TRUE;
								pActorT->iFieldPos[X] = iX;
								pActorT->iFieldPos[Y] = iY;
								pActorT->fSize = 1.0f;
								pActorT->iFieldID = pFieldT->iID;
								pActorT->iNumber = iEditorObjectsNumber;
								switch(byEditorSelected)
								{
									case EDITOR_SELECTED_OBJECT_HEALTH: pActorT->byType = ACTOR_HEALTH_OBJ; break;
									case EDITOR_SELECTED_OBJECT_LIVE: pActorT->byType = ACTOR_LIVE_OBJ; break;
									case EDITOR_SELECTED_OBJECT_PULL: pActorT->byType = ACTOR_PULL_OBJ; break;
									case EDITOR_SELECTED_OBJECT_THROW: pActorT->byType = ACTOR_THROW_OBJ; break;
									case EDITOR_SELECTED_OBJECT_FORCE: pActorT->byType = ACTOR_FORCE_OBJ; break;
									case EDITOR_SELECTED_OBJECT_WEAPON: pActorT->byType = ACTOR_WEAPON_OBJ; break;
									case EDITOR_SELECTED_OBJECT_POINT: pActorT->byType = ACTOR_POINT_OBJ; break;
									case EDITOR_SELECTED_OBJECT_GHOST: pActorT->byType = ACTOR_GHOST_OBJ; break;
									case EDITOR_SELECTED_OBJECT_TIME: pActorT->byType = ACTOR_TIME_OBJ; break;
									case EDITOR_SELECTED_OBJECT_STEP: pActorT->byType = ACTOR_STEP_OBJ; break;
									case EDITOR_SELECTED_OBJECT_SPEED: pActorT->byType = ACTOR_SPEED_OBJ; break;
									case EDITOR_SELECTED_OBJECT_WING: pActorT->byType = ACTOR_WING_OBJ; break;
									case EDITOR_SELECTED_OBJECT_SHIELD: pActorT->byType = ACTOR_SHIELD_OBJ; break;
									case EDITOR_SELECTED_OBJECT_JUMP: pActorT->byType = ACTOR_JUMP_OBJ; break;
									case EDITOR_SELECTED_OBJECT_AIR: pActorT->byType = ACTOR_AIR_OBJ; break;
								}
								pFieldT->pObject = pActorT;
							break;
						}
					break;

					case ENEMY:
						switch(byEditorSelected)
						{
							case EDITOR_SELECTED_ENEMY_HIRO:
								iActorType = ACTOR_ENEMY_HIRO;
								goto SetEnemy;

							case EDITOR_SELECTED_ENEMY_X3:
								iActorType = ACTOR_ENEMY_X3;
								goto SetEnemy;

							case EDITOR_SELECTED_ENEMY_MOBMOB:
								iActorType = ACTOR_ENEMY_MOBMOB;
							SetEnemy:
								if(CHECK_KEY(ASMouse.byButtons, 1))
								{
									bFieldChange = TRUE;
									for(i = 0; i < MAX_ACTORS; i++)
									{
										if(Actor[i].byType == iActorType && 
										   Actor[i].iFieldID == pFieldT->iID)
										{
											Actor[i].bActive = FALSE;
											pFieldT->pEnemy = NULL;
										}
									}
									break;
								}
								if(!CHECK_KEY(ASMouse.byButtons, 0))
									break;
								if(pFieldT->bWall || !pFieldT->bActive || (pFieldT->pBridgeActor && pFieldT->pBridgeActor->bBridgeMovement) ||
								   pFieldT->pEnemy)
									break;								
								for(i = 0; i < MAX_ACTORS; i++)
								{
									if(Actor[i].bActive &&
									   Actor[i].byType == iActorType && 
									   Actor[i].iFieldID == pFieldT->iID)
									{
										i = -1;
										break;
									}
								}
								if(i == -1)
									break;


								pActorT	= FindFreeActor();
								if(!pActorT)
									break;
								pActorT->bActive = TRUE;
								pActorT->byType = iActorType;
								pActorT->iFieldPos[X] = iX;
								pActorT->iFieldPos[Y] = iY;
								pActorT->fSize = 1.0f;
								pActorT->bHeavy = bEditorHeavy;
								pActorT->fPower = 100.0f;
								pActorT->byAction = -1;
								pActorT->fVelocity[1] = fEditorObjectVelocity;
								pActorT->byDirection = iEditorRotate;
								pActorT->fRot[Y] =  pActorT->byDirection*90.0f;
								pActorT->fColor[0] = 1.0f;
								pActorT->fColor[1] = 1.0f;
								pActorT->fColor[2] = 1.0f;
								pActorT->iFieldID = pFieldT->iID;
								bFieldChange = TRUE;
								pLevel->pField[pPlayer->iFieldID].pActor = NULL;
							break;
						}
					break;
				}
			}
			if(byEditorMenu == EDITOR_TERRAIN_MENU)
			{ // We should manipulate the terrain:
				hWndT = hWndEditorTab[TAB_EDITOR_TERRAIN];
				switch(byEditorSelected)
				{
					case EDITOR_SELECTED_COLOR: // Change the vertex colors
						byColor = -1;
						byColors = 1;
						// Which color we have to manipulate?
						if(CHECK_KEY(ASMouse.byButtons, 0) && CHECK_KEY(ASMouse.byButtons, 1))
							byColors = 3;
						else
						if(CHECK_KEY(ASMouse.byButtons, 0))
							byColor = R;
						else
						if(CHECK_KEY(ASMouse.byButtons, 1))
							byColor = G;
						else
						if(CHECK_KEY(ASMouse.byButtons, 2))
							byColor = B;
						if(byColor == -1 && byColors == 1)
							break;
						for(i = 0; i < byColors; i++)
						{
							if(byColors == 3)
								byColor = (char) i;
							if(bTop || bBoth)
								pLevel->fColor[pFieldT->iFace[FACE_FRONT][iPoint]][byColor] += iIncrease/500.0f;
							if(bFloor || bBoth)
								pLevel->fColor[pFieldT->iFace[FACE_FLOOR][iPoint]][byColor] += iIncrease/500.0f;
							if(pLevel->fColor[pFieldT->iFace[FACE_FRONT][iPoint]][byColor] > 1.0f)
								pLevel->fColor[pFieldT->iFace[FACE_FRONT][iPoint]][byColor] = 1.0f;
							if(pLevel->fColor[pFieldT->iFace[FACE_FRONT][iPoint]][byColor] < 0.0f)
								pLevel->fColor[pFieldT->iFace[FACE_FRONT][iPoint]][byColor] = 0.0f;
							if(pLevel->fColor[pFieldT->iFace[FACE_FLOOR][iPoint]][byColor] > 1.0f)
								pLevel->fColor[pFieldT->iFace[FACE_FLOOR][iPoint]][byColor] = 1.0f;
							if(pLevel->fColor[pFieldT->iFace[FACE_FLOOR][iPoint]][byColor] < 0.0f)
								pLevel->fColor[pFieldT->iFace[FACE_FLOOR][iPoint]][byColor] = 0.0f;
						}
					break;

					case EDITOR_SELECTED_ALPHA: // Change the vertex alpha value
						if(!CHECK_KEY(ASMouse.byButtons, 0))
							break;
						if(bTop || bBoth)
							pLevel->fColor[pFieldT->iFace[FACE_FRONT][iPoint]][3] += iIncrease/500.0f;
						if(bFloor || bBoth)
							pLevel->fColor[pFieldT->iFace[FACE_FLOOR][iPoint]][3] += iIncrease/500.0f;
						if(pLevel->fColor[pFieldT->iFace[FACE_FRONT][iPoint]][3] > 1.0f)
							pLevel->fColor[pFieldT->iFace[FACE_FRONT][iPoint]][3] = 1.0f;
						if(pLevel->fColor[pFieldT->iFace[FACE_FRONT][iPoint]][3] < 0.0f)
							pLevel->fColor[pFieldT->iFace[FACE_FRONT][iPoint]][3] = 0.0f;
						if(pLevel->fColor[pFieldT->iFace[FACE_FLOOR][iPoint]][3] > 1.0f)
							pLevel->fColor[pFieldT->iFace[FACE_FLOOR][iPoint]][3] = 1.0f;
						if(pLevel->fColor[pFieldT->iFace[FACE_FLOOR][iPoint]][3] < 0.0f)
							pLevel->fColor[pFieldT->iFace[FACE_FLOOR][iPoint]][3] = 0.0f;
					break;

					case EDITOR_SELECTED_HEIGHT: // Change the heights
						if(CHECK_KEY(ASMouse.byButtons, 2))
						{ // Set to the standart height:
							bTerrainChange = TRUE;
							if(bTop || bBoth)
								pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] = pLevel->Header.fFieldDepth+STANDART_LEVEL_Z_POS;
							if(bFloor || bBoth)
								pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] = STANDART_LEVEL_Z_POS;
						}
						if(!CHECK_KEY(ASMouse.byButtons, 0))
							break;
						bTerrainChange = TRUE;
						if(bTop || bBoth)
							pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] += iIncrease/50.0f;
						if(bFloor || bBoth)
							pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] += iIncrease/50.0f;
					break;
					
					case EDITOR_SELECTED_POINT: // Change the point positions
						if(CHECK_KEY(ASMouse.byButtons, 0))
						{ // Manipulate x position:
							if(bTop || bBoth)
								pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][X] += iIncrease/50.0f;
							if(bFloor || bBoth)
								pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][X] += iIncrease/50.0f;
						}
						if(CHECK_KEY(ASMouse.byButtons, 1))
						{ // Manipulate y position:
							if(bTop || bBoth)
								pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Y] += iIncrease/50.0f;
							if(bFloor || bBoth)
								pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Y] += iIncrease/50.0f;
						}
						// This effect should be not to extreme:
						for(i = 0; i < 2; i++)
						{
							if(!i)
								fPosT = &pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]];
							else
								fPosT = &pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]];
							
							if((*fPosT)[X] > iX*pLevel->Header.fFieldWidth+0.5f)
								(*fPosT)[X] = iX*pLevel->Header.fFieldWidth+0.5f;
							if((*fPosT)[X] < iX*pLevel->Header.fFieldWidth-0.5f)
								(*fPosT)[X] = iX*pLevel->Header.fFieldWidth-0.5f;
							
							if((*fPosT)[Y] > iY*pLevel->Header.fFieldHeight+0.5f)
								(*fPosT)[Y] = iY*pLevel->Header.fFieldHeight+0.5f;
							if((*fPosT)[Y] < iY*pLevel->Header.fFieldHeight-0.5f)
								(*fPosT)[Y] = iY*pLevel->Header.fFieldHeight-0.5f;
						}
						if(CHECK_KEY(ASMouse.byButtons, 2))
						{ // Set to standart position:
							if(bTop || bBoth)
							{
								pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][X] = iX*pLevel->Header.fFieldWidth;
								pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Y] = iY*pLevel->Header.fFieldHeight;
							}
							if(bFloor || bBoth)
							{
								pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][X] = iX*pLevel->Header.fFieldWidth;
								pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Y] = iY*pLevel->Header.fFieldHeight;
							}
						}
						bTerrainChange = TRUE;
					break;

					case EDITOR_SELECTED_MIDDLE_HEIGHT: // Middle the heights
						if(!CHECK_KEY(ASMouse.byButtons, 0))
							break;
						bTerrainChange = TRUE;
						if(bTop || bBoth)
						{
							if(pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] > fTopMiddle)
							{
								pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] -= iIncrease/50.0f;
								if(pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] < fTopMiddle)
									pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] = fTopMiddle;
							}
							else
								if(pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] < fTopMiddle)
								{
									pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] += iIncrease/50.0f;
									if(pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] > fTopMiddle)
										pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] = fTopMiddle;
								}
						}
						if(bFloor || bBoth)
						{
							if(pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] > fFloorMiddle)
							{
								pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] -= iIncrease/50.0f;
								if(pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] < fFloorMiddle)
									pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] = fFloorMiddle;
							}
							else
								if(pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] < fFloorMiddle)
								{
									pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] += iIncrease/50.0f;
									if(pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] > fFloorMiddle)
										pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] = fFloorMiddle;
								}
						}
					break;
					
					case EDITOR_SELECTED_LOWEST_HEIGHT: // Set to the lowest height
						if(!CHECK_KEY(ASMouse.byButtons, 0))
							break;
						bTerrainChange = TRUE;
						if(bTop || bBoth)
						{
							if(pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] < fLowestTopHeight)
							{
								pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] += iIncrease/50.0f;
								if(pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] > fLowestTopHeight)
									pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] = fLowestTopHeight;
							}
						}
						if(bFloor || bBoth)
						{
							if(pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] < fLowestFloorHeight)
							{
								pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] += iIncrease/50.0f;
								if(pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] > fLowestFloorHeight)
									pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] = fLowestFloorHeight;
							}
						}
					break;

					case EDITOR_SELECTED_GREATEST_HEIGHT: // Set to the greatest height
						if(!CHECK_KEY(ASMouse.byButtons, 0))
							break;
						bTerrainChange = TRUE;
						if(bTop || bBoth)
						{
							if(pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] > fGreatestTopHeight)
							{
								pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] -= iIncrease/50.0f;
								if(pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] < fGreatestTopHeight)
									pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] = fGreatestTopHeight;
							}
						}
						if(bFloor || bBoth)
						{
							if(pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] > fGreatestFloorHeight)
							{
								pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] -= iIncrease/50.0f;
								if(pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] < fGreatestFloorHeight)
									pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] = fGreatestFloorHeight;
							}
						}
					break;
				}
				continue;
			}
			if(CHECK_KEY(ASMouse.byButtons, 0))
			{
				switch(byEditorMenu)
				{
					case EDITOR_SURFACE_MENU: // We setup surfaces on the field faces:
						bFieldChange = TRUE;
						if(!pFieldT->bActive)
						{
							if(CHECK_KEY(ASMouse.byButtons, 1) && !iEditorCurrentSurfaceType)
								pFieldT->bActive = TRUE;
						}
						hWndT = hWndEditorTab[TAB_EDITOR_SURFACES];
						for(i = 0; i < 6; i++)
						{
							iSurface = -1;
							if(i == 0 && SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_FLOOR, BM_GETCHECK, 0, 0L))
							{
								iSurface = FACE_FLOOR;
								pFieldT->iBeamerTarget = -1;
							}
							if(i == 1 && SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_FRONT, BM_GETCHECK, 0, 0L))
								iSurface = FACE_FRONT;
							if(i == 2 && SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_TOP, BM_GETCHECK, 0, 0L))
								iSurface = FACE_TOP;
							if(i == 3 && SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_RIGHT, BM_GETCHECK, 0, 0L))
								iSurface = FACE_RIGHT;
							if(i == 4 && SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_BOTTOM, BM_GETCHECK, 0, 0L))
								iSurface = FACE_BOTTOM;
							if(i == 5 && SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_LEFT, BM_GETCHECK, 0, 0L))
								iSurface = FACE_LEFT;
							if(iSurface == -1)
								continue;
							if(iEditorCurrentSurfaceType != 2)
							{
								if(pFieldT->pSurface[iSurface][iEditorCurrentSurfaceType])
									pFieldT->pSurface[iSurface][iEditorCurrentSurfaceType]->iUsed--;
								pFieldT->iSurface[iSurface][iEditorCurrentSurfaceType] = pLevel->iCurrentSurface;
								pFieldT->pSurface[iSurface][iEditorCurrentSurfaceType] = pLevel->pCurrentSurface;
								pFieldT->pSurface[iSurface][iEditorCurrentSurfaceType]->iUsed++;
								pFieldT->iSurfaceRotation[iSurface][iEditorCurrentSurfaceType] = iEditorRotate;
								pFieldT->iCurrentAniStep[iSurface][iEditorCurrentSurfaceType] = 0;
								pFieldT->dwLastTime[iSurface][iEditorCurrentSurfaceType] = g_lNow;
								pFieldT->dwLastChangeTime[iSurface][iEditorCurrentSurfaceType] = g_lNow;
							}
							else
							{ // Remove the second surface:
								if(pFieldT->pSurface[iSurface][1])
								{
									pFieldT->pSurface[iSurface][1]->iUsed--;
									pFieldT->iSurface[iSurface][1] = -1;
									pFieldT->pSurface[iSurface][1] = NULL;
								}
							}
						}
					break;

					case EDITOR_BRUSH_MENU: // We set something into the level: (a wall, or deactivate a field...)
						bFieldChange = TRUE;
						switch(byEditorSelected)
						{
							case EDITOR_SELECTED_WALL: // Set a wall
								if(pFieldT->pActor || pFieldT->pBridgeActor ||pFieldT->pObject ||
								   pFieldT->pEnemy)
									break;
								pFieldT->bWallHole = FALSE;
								pLevel->SetFieldWall(iX, iY, TRUE, FALSE);
							break;
			
							case EDITOR_SELECTED_DEACTIVATE_FIELD: // Deactivate a field
								pFieldT->bWallHole = FALSE;
								pLevel->SetFieldWall(iX, iY, FALSE, FALSE);
								pFieldT->bActive = FALSE;
								pFieldT->bWall = FALSE;
							goto FreeField;
							
							case EDITOR_SELECTED_2_SIDES:
								pFieldT->bNoBackfaceCulling = TRUE;
							break;

							case EDITOR_SELECTED_CLEAR_FIELD:
							FreeField:
								// Destroy all actors on this field;
								if(pPlayer->iFieldID == pFieldT->iID)
									pPlayer->bActive = FALSE;
								for(i = 0; i < MAX_ACTORS; i++)
								{
									if(Actor[i].iFieldID == pFieldT->iID)
										Actor[i].bActive = FALSE;
								}
								if(pFieldT->pActor && pFieldT->bWall)
									pFieldT->bWall = FALSE;
								if(pFieldT->pBridgeActor)
									pFieldT->bActive = FALSE;
								pFieldT->pActor = pFieldT->pBridgeActor = 
								pFieldT->pEnemy = pFieldT->pObject = NULL;
								if(pFieldT->pDecoration)
								{
									if(pFieldT->pDecoration->iTexture >= 0)
										pLevel->pTexture[pFieldT->pDecoration->iTexture].iUsed++;
									SAFE_DELETE(pFieldT->pDecoration);
								}
							break;

							case EDITOR_SELECTED_WALL_HOLE:
								pFieldT->bActive = FALSE;
								pFieldT->bWallHole = TRUE;
								pFieldT->bWall = TRUE;
								pLevel->SetFieldWall(iX, iY, pFieldT->bWall, FALSE);
							goto FreeField;
						}
					break;
				}
			}
			if(CHECK_KEY(ASMouse.byButtons, 1))
			{
				bFieldChange = TRUE;
				switch(byEditorSelected)
				{
					case EDITOR_SELECTED_WALL: // Delete a wall
						if(pFieldT->pActor || pFieldT->pBridgeActor ||pFieldT->pObject ||
						   pFieldT->pEnemy)
							break;
						pFieldT->bWallHole = FALSE;
						pLevel->SetFieldWall(iX, iY, FALSE, FALSE);
					break;

					case EDITOR_SELECTED_DEACTIVATE_FIELD: // Activate a field
						if(iX != pLevel->Header.iWidth-1 && iY != pLevel->Header.iHeight-1)						
							pFieldT->bActive = TRUE;
						pFieldT->bWallHole = FALSE;
						pLevel->SetFieldWall(iX, iY, TRUE, TRUE);
					break;

					case EDITOR_SELECTED_2_SIDES:
						pFieldT->bNoBackfaceCulling = FALSE;
					break;

					case EDITOR_SELECTED_WALL_HOLE:
						if(pFieldT->bActive)
							break;
						pFieldT->bWallHole = FALSE;
						pLevel->SetFieldWall(iX, iY, FALSE, FALSE);
						pFieldT->bActive = FALSE;
					break;
				}
			}							
		}
	}

	// Camera speed adjust keys:
	if(CHECK_KEY(ASKeys, DIK_1))
		fCameraVelocity = 0.1f;
	if(CHECK_KEY(ASKeys, DIK_2))
		fCameraVelocity = 0.2f;
	if(CHECK_KEY(ASKeys, DIK_3))
		fCameraVelocity = 0.3f;
	if(CHECK_KEY(ASKeys, DIK_4))
		fCameraVelocity = 0.4f;
	if(CHECK_KEY(ASKeys, DIK_5))
		fCameraVelocity = 0.5f;
	if(CHECK_KEY(ASKeys, DIK_6))
		fCameraVelocity = 0.6f;
	if(CHECK_KEY(ASKeys, DIK_7))
		fCameraVelocity = 0.7f;
	if(CHECK_KEY(ASKeys, DIK_8))
		fCameraVelocity = 0.8f;
	if(CHECK_KEY(ASKeys, DIK_9))
		fCameraVelocity = 0.9f;
	if(CHECK_KEY(ASKeys, DIK_0))
		fCameraVelocity = 1.0f;

	// Check if something on the fields has changed:
	if(bFieldChange)
	{
		for(i = 0; i < MAX_ACTORS; i++)
			CheckActorField(&Actor[i]);
		pLevel->UpdateMissions();
		UpdateAllActorFields();
	}

	
	if(!bTerrainChange)
		return 0;	


	FLOAT3 fPoint;
	FLOAT3 fRayDirection;

	fRayDirection[X] = 0.0f;
	fRayDirection[Y] = 0.0f;
	fRayDirection[Z] = 1.0f;
	for(i = 0; i < pLevel->Header.iFields; i++)
	{
		if(pLevel->pField[i].iBeamerParticleSystemID == -1)
			continue;
		ParticleManager.pSystem[pLevel->pField[i].iBeamerParticleSystemID].fStartPos[X] = pLevel->pField[i].iXField*pLevel->Header.fFieldWidth+0.5f;
		ParticleManager.pSystem[pLevel->pField[i].iBeamerParticleSystemID].fStartPos[Y] = pLevel->pField[i].iYField*pLevel->Header.fFieldHeight+0.5f;
		fPoint[X] = fPoint[Y] = fPoint[Z] = 0.0f;
		pLevel->ComputeHeight(ParticleManager.pSystem[pLevel->pField[i].iBeamerParticleSystemID].fStartPos[X], 
							  ParticleManager.pSystem[pLevel->pField[i].iBeamerParticleSystemID].fStartPos[Y],
							  fRayDirection, &fPoint, FACE_FLOOR, 0.2f);
		ParticleManager.pSystem[pLevel->pField[i].iBeamerParticleSystemID].fStartPos[Z] = fPoint[Z];
	}
	// Recalculate all if something on the terrain has changed:
	for(i = 0; i < MAX_ACTORS; i++)
	{
		Actor[i].fLastHeightCheckWorldPos[X] = 
		Actor[i].fLastHeightCheckWorldPos[Y] = -1.0f;
	}
	pPlayer->fLastHeightCheckWorldPos[X] = 
	pPlayer->fLastHeightCheckWorldPos[Y] = -1.0f;
	pLevel->CalculateFieldNormals();
	pLevel->CalculateFieldBoundingBoxes();
	return 0;
} // end EditorCheck()

void ManipulateColor(FLOAT3 *fColor, short iIncrease)
{ // begin ManipulateColor()
	char byColor = -1, byColors = 1, i;
	
	// Which color we have to manipulate?
	if(CHECK_KEY(ASMouse.byButtons, 0) && CHECK_KEY(ASMouse.byButtons, 1))
		byColors = 3;
	if(CHECK_KEY(ASMouse.byButtons, 0))
		byColor = R;
	else
	if(CHECK_KEY(ASMouse.byButtons, 1))
		byColor = G;
	else
	if(CHECK_KEY(ASMouse.byButtons, 2))
		byColor = B;
	if(byColor == -1 && byColors == 1)
		return;
	for(i = 0; i < byColors; i++)
	{
		if(byColors == 3)
			byColor = i;
		(*fColor)[byColor] += iIncrease/500.0f;
		if((*fColor)[byColor] < 0.0f)
			(*fColor)[byColor] = 0.0f;
		if((*fColor)[byColor] > 1.0f)
			(*fColor)[byColor] = 1.0f;
	}
} // end ManipulateColor()

void ManipulateDensity(FLOAT *fColor, short iIncrease)
{ // begin ManipulateDensity()
	if(!CHECK_KEY(ASMouse.byButtons, 0))
		return;
	*fColor += iIncrease/500.0f;
	if(*fColor < 0.0f)
		*fColor = 0.0f;
	if(*fColor > 1.0f)
		*fColor = 1.0f;
} // end ManipulateDensity()
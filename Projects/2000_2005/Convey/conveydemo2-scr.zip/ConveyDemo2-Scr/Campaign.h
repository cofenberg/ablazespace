//-----------------------------------------------------------------------------
// File: Campaign.h
//-----------------------------------------------------------------------------

#ifndef __CAMPAIGN_H__
#define __CAMPAIGN_H__


// Structures: ****************************************************************
typedef struct CAMPAIGN
{
	BOOL bKeyword;			// Is there a keyword?
	char byKeyword[256],	// The keyword for the editing access
		 byFilename[256],	// The filename of this campaign
		 byName[256];		// The name of this campaign
	short iLevels;			// The number of Levels
	char **byLevelFilename; // The level filenames
} CAMPAIGN;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern CAMPAIGN CurrentCampaign;
extern short iCurrentCampaignLevel;
extern char **pbyCampaignLevelNames;
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern LRESULT CALLBACK CampaignEditorProc(HWND, UINT, WPARAM, LPARAM);
extern BOOL LoadCampaign(CAMPAIGN *, char *);
extern void SaveCampaign(CAMPAIGN *, char *);
extern void DestroyCampaign(CAMPAIGN *);
///////////////////////////////////////////////////////////////////////////////


#endif // __CAMPAIGN_H__
//-----------------------------------------------------------------------------
// File: TextScripts.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
short iNumberTemp, iSelectedTextScript, iSelectedTextScriptText;
short iTextScriptSourceTexts; // The number of texts
char **byTextScriptSourceTexts; // All texts from the text script file
TEXT_SCRIPT *pTextScript;
HWND hWndTextScriptEditor;
// Text script playback:
BOOL bPlayTextScript; // Should a text script be played??
short iPlayTextScriptID; // The current text script
short iPlayTextScriptStep; // Step of the playback
DWORD dwPlayTextScriptTime; // Playback timer
short iPlayTextScriptAniStep; // The surface animation step
DWORD iPlayTextScriptAniTime; // The surface animation time
///////////////////////////////////////////////////////////////////////////////


// Functions: *****************************************************************
void LoadTextScriptSource(char *);
void DestroyTextScriptSource(void);
LRESULT CALLBACK TextScriptEditorProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK SetNumberOfTextScriptsProc(HWND, UINT, WPARAM, LPARAM);
void PlayTextScript(short);
void DisplayTextScript(AS_WINDOW *);
void CheckPlayTextScript(void);
///////////////////////////////////////////////////////////////////////////////


void LoadTextScriptSource(char *pbyFilename)
{ // begin LoadTextScriptSource()
	char byTemp[256], byFilename[256];
	short i;

	if(!pLevel)
		return;
	sprintf(byFilename, "%s%s", _AS->pbyProgramPath, pbyFilename);
	DestroyTextScriptSource();
	strcpy(pLevel->TextScriptsManager.byFilename, pbyFilename);
	iTextScriptSourceTexts = GetPrivateProfileInt("General", "texts", 0, byFilename);
	if(iTextScriptSourceTexts)
		byTextScriptSourceTexts = (char **) malloc(sizeof(char **)*iTextScriptSourceTexts);
	// Load now the texts:
	for(i = 0; i < iTextScriptSourceTexts; i++)
	{
		sprintf(byTemp, "%d", i+1);
		byTextScriptSourceTexts[i] = (char *) malloc(sizeof(char *)*256);
		GetPrivateProfileString(_ASConfig->byLanguage, byTemp, "", byTextScriptSourceTexts[i], 256, byFilename);
	}
} // end begin LoadTextScriptSource()

void DestroyTextScriptSource(void)
{ // end begin DestroyTextScriptSource()
	short i;
	
	if(byTextScriptSourceTexts)
	{
		for(i = 0; i < iTextScriptSourceTexts; i++)
			if(byTextScriptSourceTexts[i])
				free(byTextScriptSourceTexts[i]);
		free(byTextScriptSourceTexts);
		byTextScriptSourceTexts = NULL;
	}
	iTextScriptSourceTexts = 0;
} // end begin DestroyTextScriptSource()

void PlayTextScript(short iPlayTextScriptIDTemp)
{ // begin PlayTextScript()
	iPlayTextScriptID = iPlayTextScriptIDTemp;
	bPlayTextScript = TRUE;
	iPlayTextScriptStep = iPlayTextScriptAniStep = 0;
	dwPlayTextScriptTime = g_lNow;
} // end PlayTextScript()

void DisplayTextScript(AS_WINDOW *pWindow)
{ // begin DisplayTextScript()
	TEXTURE_POS *pTexturePos;
	SURFACE *pSurfaceT;
	char byText[1000];
	char byRowText[8][53];
	short iRows, i, i2, iX, iY;

	if(!bPlayTextScript || !byTextScriptSourceTexts)
		return;
	glDisable(GL_LIGHTING);
	glDisable(GL_FOG);
	glClear(GL_DEPTH_BUFFER_BIT);
	glEnable(GL_BLEND);
	glDisable(GL_TEXTURE_2D);
	glBlendFunc(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);
	glColor4f(0.1f, 0.1f, 0.1f, 0.2f);
	glDisable(GL_CULL_FACE);
	glLoadIdentity();
	glTranslatef(-1.0f, 0.0f, -34.0f);
	glBegin(GL_QUADS);
		glNormal3f(0.0f, 0.0f, 1.0f);
		glVertex3f(-15.0f, -9.0f, 10.0f);
		glVertex3f( 15.0f, -9.0f, 10.0f);
		glVertex3f( 15.0f,  -5.0f, 10.0f);
		glVertex3f(-15.0f,  -5.0f, 10.0f);
	glEnd();
	glEnable(GL_CULL_FACE);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glColor4f(1.0f, 1.0f, 1.0f, 0.95f);
	// Draw the text:
	strcpy(byText, byTextScriptSourceTexts[pTextScript[iPlayTextScriptID].pText[iPlayTextScriptStep].iTextID]);
	// Get the number of rows and setup them:
	for(i = 0; i < 8; i++)
		memset(byRowText[i], 0, sizeof(char)*53);
	for(iRows = 0, i = 0, i2 = 0; i < (signed) strlen(byText); i++, i2++)
	{
		// Check if we should go into the next row:
		if(byText[i] == '/' && 
		   i+1 < (signed) strlen(byText) && byText[i+1] == 'n' &&
		   i+2 < (signed) strlen(byText) && byText[i+2] == '/')
		{ // Go into the next row:
			i2 = 0;
			if(iRows < 8)
				iRows++;
			else
				break;
			i += 3;
		}
		// Check if this row is full:
		if(i2 >= 52)
		{ // Yea, it's full:
			i2 = 0;
			if(iRows < 8)
				iRows++;
			else
				break;
		}
		byRowText[iRows][i2] = byText[i];
	}
	// Draw each row:
	iY = 55+((iRows+1)/2)*10;
	if(pTextScript[iPlayTextScriptID].pText[iPlayTextScriptStep].iSurface == -1)
		iX = 320;
	else
		iX = 360;
	for(i = 0; i < iRows+1; i++)
		pWindow->PrintAnimated(iX, iY-i*10, byRowText[i], 0, 1.0f, fFontAni, 1);
	
	// Draw the surface, if there is one:
	if(pTextScript[iPlayTextScriptID].pText[iPlayTextScriptStep].iSurface == -1)
		return;
	pSurfaceT = &pLevel->pSurface[pTextScript[iPlayTextScriptID].pText[iPlayTextScriptStep].iSurface];
	pTexturePos = &pSurfaceT->pTexturePos[iPlayTextScriptAniStep];
	glColor4fv(pTexturePos->fColor);
	if(iPlayTextScriptAniStep >= pSurfaceT->Header.iAniSteps)
		iPlayTextScriptAniStep = 0;
	glBindTexture(GL_TEXTURE_2D, pSurfaceT->pTexture[iPlayTextScriptAniStep]->iOpenGLID);
	glLoadIdentity();
	glTranslatef(-6.5f, -4.1f, -15.0f);
	glBegin(GL_QUADS);
		glTexCoord2f((float) pTexturePos->fPos[3][X], 
					 (float) pTexturePos->fPos[3][Y]);
		glVertex3f(-1.0f,  -1.0f, 1.0f);
		glTexCoord2f((float) pTexturePos->fPos[2][X], 
					 (float) pTexturePos->fPos[2][Y]);
		glVertex3f(1.0f, -1.0f, 1.0f);
		glTexCoord2f((float) pTexturePos->fPos[1][X], 
					 (float) pTexturePos->fPos[1][Y]);
		glVertex3f( 1.0f, 1.0f, 1.0f);
		glTexCoord2f((float) pTexturePos->fPos[0][X], 
					 (float) pTexturePos->fPos[0][Y]);
		glVertex3f( -1.0f,  1.0f, 1.0f);
	glEnd();
} // end DisplayTextScript()

void CheckPlayTextScript(void)
{ // begin CheckPlayTextScript()
	SURFACE *pSurfaceT;

	if(!bPlayTextScript)
		return;
	if(g_lNow-dwPlayTextScriptTime > (unsigned) pTextScript[iPlayTextScriptID].pText[iPlayTextScriptStep].dwWait)
	{
		dwPlayTextScriptTime = g_lNow;
		iPlayTextScriptStep++;
		iPlayTextScriptAniTime = g_lNow;
		iPlayTextScriptAniStep = 0;
		if(iPlayTextScriptStep >= pTextScript[iPlayTextScriptID].iTexts)
		{ // Playback is finished:
			bPlayTextScript = FALSE;
			return;
		}
	}
	// Animate the surface, if there is one:
	if(pTextScript[iPlayTextScriptID].pText[iPlayTextScriptStep].iSurface == -1)
		return;
	pSurfaceT = &pLevel->pSurface[pTextScript[iPlayTextScriptID].pText[iPlayTextScriptStep].iSurface];
	if(g_lNow-iPlayTextScriptAniTime < (unsigned) pSurfaceT->pTexturePos[iPlayTextScriptAniStep].iTimeToNext)
		return;
	iPlayTextScriptAniTime = g_lNow;
	iPlayTextScriptAniStep++;
	if(iPlayTextScriptAniStep >= pSurfaceT->Header.iAniSteps)
		iPlayTextScriptAniStep = 0;
} // end CheckPlayTextScript()

LRESULT CALLBACK TextScriptEditorProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin TextScriptEditorProc()
    char byTemp[256], *pbyTemp;
	short i, i2;

	switch(iMessage)
    {
        case WM_INITDIALOG:
				_AS->WriteLogMessage("Open text script editor");
				hWndTextScriptEditor = hWnd;
				// Texts:
				SetWindowText(hWnd, T_TextScriptEditor);
				SetDlgItemText(hWnd, IDC_TS_EDITOR_UPDATE, T_Update);
				SetDlgItemText(hWnd, IDC_TS_EDITOR_TEXT_SCRIPTS_T, T_TextScripts);
				SetDlgItemText(hWnd, IDC_TS_EDITOR_TEXT_SCRIPTS_NUMBER, T_Number);
				SetDlgItemText(hWnd, IDC_TS_EDITOR_DELETE_TEXT_SCRIPT, T_Delete);
				SetDlgItemText(hWnd, IDC_TS_EDITOR_SELECTED_TEXT_SCRIPT_T, T_SelectedTextScript);
				SetDlgItemText(hWnd, IDC_TS_EDITOR_SELECTED_TEXTS_NUMBER, T_Number);
				SetDlgItemText(hWnd, IDC_TS_EDITOR_SELECTED_DELETE, T_Delete);
				SetDlgItemText(hWnd, IDC_TS_EDITOR_OK, T_Ok);
				SetDlgItemText(hWnd, IDC_TS_EDITOR_NEXT_TIME_T, T_NextTime);
				SetDlgItemText(hWnd, IDC_TS_EDITOR_SELECTED_NAME_T, T_Name);
				SetDlgItemText(hWnd, IDC_TS_EDITOR_TIME_TO_NEXT_ALL, T_All);
				SendDlgItemMessage(hWnd, IDC_TS_EDITOR_SELECTED_SURFACE, CB_RESETCONTENT , 0, 0L);
				sprintf(byTemp, " - %s", T_NoSurface);
				SendDlgItemMessage(hWnd, IDC_TS_EDITOR_SELECTED_SURFACE, CB_ADDSTRING, 0, (LPARAM) byTemp);
				for(i = 0; i < pLevel->Header.iSurfaces; i++)
				{
					sprintf(byTemp, "%s", pLevel->pSurface[i].Header.byName);
					SendDlgItemMessage(hWnd, IDC_TS_EDITOR_SELECTED_SURFACE, CB_ADDSTRING, 0, (LPARAM) byTemp);
				}
				SendDlgItemMessage(hWnd, IDC_TS_EDITOR_SELECTED_SURFACE, CB_SETCURSEL, 0, 0);
				iSelectedTextScript = iSelectedTextScriptText = -1;
				//
			Init:
				// Check if all texts are right:
				for(i = 0; i < pLevel->TextScriptsManager.iTextsScripts; i++)
				{
					for(i2 = 0; i2 < pTextScript[i].iTexts; i2++)
					{
						if(pTextScript[i].pText[i2].iTextID >= iTextScriptSourceTexts)
							pTextScript[i].pText[i2].iTextID = 0;
					}
				}

				//
				if(!byTextScriptSourceTexts)
				{
					iSelectedTextScript = iSelectedTextScriptText = -1;
					EnableWindow(GetDlgItem(hWnd, IDC_TS_EDITOR_TEXT_SCRIPTS_LIST), FALSE);
					EnableWindow(GetDlgItem(hWnd, IDC_TS_EDITOR_TEXT_SCRIPTS_NUMBER), FALSE);
				}
				else
				{
					EnableWindow(GetDlgItem(hWnd, IDC_TS_EDITOR_TEXT_SCRIPTS_LIST), TRUE);
					EnableWindow(GetDlgItem(hWnd, IDC_TS_EDITOR_TEXT_SCRIPTS_NUMBER), TRUE);
				}

				SetDlgItemText(hWnd, IDC_TS_EDITOR_FILE_NAME, pLevel->TextScriptsManager.byFilename);
				SendDlgItemMessage(hWnd, IDC_TS_EDITOR_LIST, LB_RESETCONTENT , 0, 0L);
				for(i = 0; i < iTextScriptSourceTexts; i++)
				{
					sprintf(byTemp, "%d: %s", i, byTextScriptSourceTexts[i]);
					SendDlgItemMessage(hWnd, IDC_TS_EDITOR_LIST, LB_ADDSTRING, 0, (LPARAM) byTemp);
				}
				if(iSelectedTextScript != -1 && iSelectedTextScriptText != -1)
					SendDlgItemMessage(hWnd, IDC_TS_EDITOR_LIST, LB_SETCURSEL, pTextScript[iSelectedTextScript].pText[iSelectedTextScriptText].iTextID, 0);
				else
					SendDlgItemMessage(hWnd, IDC_TS_EDITOR_LIST, LB_SETCURSEL, 0, 0);

				SendDlgItemMessage(hWnd, IDC_TS_EDITOR_TEXT_SCRIPTS_LIST, LB_RESETCONTENT , 0, 0L);
				for(i = 0; i < pLevel->TextScriptsManager.iTextsScripts; i++)
				{
					sprintf(byTemp, "%d: %s", i, pTextScript[i].byName);
					SendDlgItemMessage(hWnd, IDC_TS_EDITOR_TEXT_SCRIPTS_LIST, LB_ADDSTRING, 0, (LPARAM) byTemp);
				}
				SendDlgItemMessage(hWnd, IDC_TS_EDITOR_TEXT_SCRIPTS_LIST, LB_SETCURSEL, iSelectedTextScript, 0);

				SendDlgItemMessage(hWnd, IDC_TS_EDITOR_SELECTED_LIST, LB_RESETCONTENT , 0, 0L);
				if(iSelectedTextScript != -1)
					for(i = 0; i < pTextScript[iSelectedTextScript].iTexts; i++)
					{
						sprintf(byTemp, "%d: %s", i, byTextScriptSourceTexts[pTextScript[iSelectedTextScript].pText[i].iTextID]);
						SendDlgItemMessage(hWnd, IDC_TS_EDITOR_SELECTED_LIST, LB_ADDSTRING, 0, (LPARAM) byTemp);
					}
				SendDlgItemMessage(hWnd, IDC_TS_EDITOR_SELECTED_LIST, LB_SETCURSEL, iSelectedTextScriptText, 0);
				
				if(iSelectedTextScript == -1)
				{
					EnableWindow(GetDlgItem(hWnd, IDC_TS_EDITOR_SELECTED_TEXTS_NUMBER), FALSE);
					EnableWindow(GetDlgItem(hWnd, IDC_TS_EDITOR_SELECTED_NAME), FALSE);
					EnableWindow(GetDlgItem(hWnd, IDC_TS_EDITOR_SELECTED_LIST), FALSE);
					EnableWindow(GetDlgItem(hWnd, IDC_TS_EDITOR_DELETE_TEXT_SCRIPT), FALSE);
				}
				else
				{
					EnableWindow(GetDlgItem(hWnd, IDC_TS_EDITOR_SELECTED_TEXTS_NUMBER), TRUE);
					EnableWindow(GetDlgItem(hWnd, IDC_TS_EDITOR_SELECTED_NAME), TRUE);
					EnableWindow(GetDlgItem(hWnd, IDC_TS_EDITOR_SELECTED_LIST), TRUE);
					EnableWindow(GetDlgItem(hWnd, IDC_TS_EDITOR_DELETE_TEXT_SCRIPT), TRUE);
				}

				if(iSelectedTextScriptText == -1)
				{
					EnableWindow(GetDlgItem(hWnd, IDC_TS_EDITOR_TIME_TO_NEXT), FALSE);
					EnableWindow(GetDlgItem(hWnd, IDC_TS_EDITOR_SELECTED_SURFACE), FALSE);
					EnableWindow(GetDlgItem(hWnd, IDC_TS_EDITOR_LIST), FALSE);
					EnableWindow(GetDlgItem(hWnd, IDC_TS_EDITOR_SELECTED_DELETE), FALSE);
				}
				else
				{
					EnableWindow(GetDlgItem(hWnd, IDC_TS_EDITOR_TIME_TO_NEXT), TRUE);
					EnableWindow(GetDlgItem(hWnd, IDC_TS_EDITOR_SELECTED_SURFACE), TRUE);
					EnableWindow(GetDlgItem(hWnd, IDC_TS_EDITOR_LIST), TRUE);
					EnableWindow(GetDlgItem(hWnd, IDC_TS_EDITOR_SELECTED_DELETE), TRUE);
				}

				ShowWindow(hWnd, _AS->GetCmdShow());
				UpdateWindow(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_TS_EDITOR_OK:
					EndDialog(hWnd, 0);
					return TRUE;

				case IDC_TS_EDITOR_FILE:
					sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbySingleLevelsFile);
					pbyTemp = ASGetFileName(hWnd, T_LoadTextScriptSource, TXT_FILE, 0, FALSE, byTemp);
					if(!pbyTemp)
						break;
					// Cut off the main path:
					strcpy(byTemp, &pbyTemp[strlen(_AS->pbyProgramPath)]);
					LoadTextScriptSource(byTemp);
				    goto Init;
				
				case IDC_TS_EDITOR_UPDATE:
					LoadTextScriptSource(pLevel->TextScriptsManager.byFilename);
				    goto Init;

				case IDC_TS_EDITOR_TEXT_SCRIPTS_NUMBER:
					iNumberTemp = pLevel->TextScriptsManager.iTextsScripts;
					if((iNumberTemp = DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_TS_EDITOR_SET_NUMBER), hWnd, (DLGPROC) SetNumberOfTextScriptsProc)) == -1)
						break;
					for(i = iNumberTemp; i < pLevel->TextScriptsManager.iTextsScripts; i++)
						if(pTextScript[i].pText)
							free(pTextScript[i].pText);
					pTextScript = (TEXT_SCRIPT *) realloc(pTextScript, sizeof(TEXT_SCRIPT)*iNumberTemp);
					for(i = pLevel->TextScriptsManager.iTextsScripts; i < iNumberTemp; i++)
					{
						memset(&pTextScript[i], 0, sizeof(TEXT_SCRIPT));
						sprintf(pTextScript[i].byName, "Text script %d", i);
					}
					pLevel->TextScriptsManager.iTextsScripts = iNumberTemp;
					iSelectedTextScript = iSelectedTextScriptText = -1;
				    goto Init;

				case IDC_TS_EDITOR_TEXT_SCRIPTS_LIST:
					i = (short) SendDlgItemMessage(hWnd, IDC_TS_EDITOR_TEXT_SCRIPTS_LIST, LB_GETCURSEL, 0, 0L);
					if(i < 0 || i >= pLevel->TextScriptsManager.iTextsScripts)
						break;
					iSelectedTextScript = i;
					iSelectedTextScriptText = -1;
					SetDlgItemText(hWnd, IDC_TS_EDITOR_SELECTED_NAME, pTextScript[iSelectedTextScript].byName);
				    goto Init;

				case IDC_TS_EDITOR_SELECTED_NAME:
					GetDlgItemText(hWnd, IDC_TS_EDITOR_SELECTED_NAME, pTextScript[iSelectedTextScript].byName, 256);
				    goto Init;

				case IDC_TS_EDITOR_SELECTED_TEXTS_NUMBER:
					iNumberTemp = pTextScript[iSelectedTextScript].iTexts;
					if((iNumberTemp = DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_TS_EDITOR_SET_NUMBER), hWnd, (DLGPROC) SetNumberOfTextScriptsProc)) == -1)
						break;
					pTextScript[iSelectedTextScript].pText = (TEXT_SCRIPT_TEXT *) realloc(pTextScript[iSelectedTextScript].pText, sizeof(TEXT_SCRIPT_TEXT)*iNumberTemp);
					for(i = pTextScript[iSelectedTextScript].iTexts; i < iNumberTemp; i++)
					{
						memset(&pTextScript[iSelectedTextScript].pText[i], 0, sizeof(TEXT_SCRIPT_TEXT));
						pTextScript[iSelectedTextScript].pText[i].iSurface = -1;
					}
					pTextScript[iSelectedTextScript].iTexts = iNumberTemp;
					iSelectedTextScriptText = -1;
				    goto Init;
				
				case IDC_TS_EDITOR_SELECTED_LIST:
					i = (short) SendDlgItemMessage(hWnd, IDC_TS_EDITOR_SELECTED_LIST, LB_GETCURSEL, 0, 0L);
					if(i < 0 || i >= pTextScript[iSelectedTextScript].iTexts)
						break;
					iSelectedTextScriptText = i;
					sprintf(byTemp, "%d", pTextScript[iSelectedTextScript].pText[iSelectedTextScriptText].dwWait);
					SetDlgItemText(hWnd, IDC_TS_EDITOR_TIME_TO_NEXT, byTemp);
					SendDlgItemMessage(hWnd, IDC_TS_EDITOR_SELECTED_SURFACE, CB_SETCURSEL, pTextScript[iSelectedTextScript].pText[iSelectedTextScriptText].iSurface+1, 0);
				    goto Init;

				case IDC_TS_EDITOR_LIST:
					i = (short) SendDlgItemMessage(hWnd, IDC_TS_EDITOR_LIST, LB_GETCURSEL, 0, 0L);
					if(i < 0 || i >= iTextScriptSourceTexts)
						break;
				    pTextScript[iSelectedTextScript].pText[iSelectedTextScriptText].iTextID = i;
					goto Init;

				case IDC_TS_EDITOR_TIME_TO_NEXT:
					GetDlgItemText(hWnd, IDC_TS_EDITOR_TIME_TO_NEXT, byTemp, 256);
					pTextScript[iSelectedTextScript].pText[iSelectedTextScriptText].dwWait = atoi(byTemp);
				break;
			
				case IDC_TS_EDITOR_SELECTED_SURFACE:
					i = (short) SendDlgItemMessage(hWnd, IDC_TS_EDITOR_SELECTED_SURFACE, CB_GETCURSEL, 0, 0L);
					if(i < 0 || i > pLevel->Header.iSurfaces)
						break;
				    pTextScript[iSelectedTextScript].pText[iSelectedTextScriptText].iSurface = i-1;
				break;

				case IDC_TS_EDITOR_TIME_TO_NEXT_ALL:
					for(i = 0; i < pTextScript[iSelectedTextScript].iTexts; i++)
						pTextScript[iSelectedTextScript].pText[i].dwWait = pTextScript[iSelectedTextScript].pText[iSelectedTextScriptText].dwWait;
				break;

				case IDC_TS_EDITOR_DELETE_TEXT_SCRIPT:
					if(pTextScript[iSelectedTextScript].pText)
						free(pTextScript[iSelectedTextScript].pText);
					for(i = iSelectedTextScript; i < pLevel->TextScriptsManager.iTextsScripts-1; i++)
						memcpy(&pTextScript[i], &pTextScript[i+1], sizeof(TEXT_SCRIPT));
					// Update the stuff which used this text script:
					for(i = 0; i < pLevel->Header.iCameraScripts; i++)
					{
						if(pLevel->pCameraScript[i].iTextScript > iSelectedTextScript)
							pLevel->pCameraScript[i].iTextScript--;
						if(pLevel->pCameraScript[i].iTextScript == iSelectedTextScript)
							pLevel->pCameraScript[i].iTextScript = -1;
					}
					for(i = 0; i < pLevel->Header.iFields; i++)
					{
						if(pLevel->pField[i].iTextScript > iSelectedTextScript)
							pLevel->pField[i].iTextScript--;
						if(pLevel->pField[i].iTextScript == iSelectedTextScript)
							pLevel->pField[i].iTextScript = -1;
					}
					//
					pLevel->TextScriptsManager.iTextsScripts--;
					pTextScript = (TEXT_SCRIPT *) realloc(pTextScript, sizeof(TEXT_SCRIPT)*pLevel->TextScriptsManager.iTextsScripts);
					iSelectedTextScript = iSelectedTextScriptText = -1;
					goto Init;

				case IDC_TS_EDITOR_SELECTED_DELETE:
					for(i = iSelectedTextScriptText; i < pTextScript[iSelectedTextScript].iTexts; i++)
						memcpy(&pTextScript[iSelectedTextScript].pText[i], &pTextScript[iSelectedTextScript].pText[i+1], sizeof(TEXT_SCRIPT_TEXT));
					pTextScript[iSelectedTextScript].iTexts--;
					pTextScript[iSelectedTextScript].pText = (TEXT_SCRIPT_TEXT *) realloc(pTextScript[iSelectedTextScript].pText, sizeof(TEXT_SCRIPT_TEXT)*pTextScript[iSelectedTextScript].iTexts);
					iSelectedTextScriptText = -1;
					goto Init;
			}
        break;

		case WM_CLOSE: case WM_DESTROY:
			_AS->WriteLogMessage("Close text script editor");
			SendMessage(hWnd, WM_COMMAND, IDC_TS_EDITOR_OK, 0);
			 hWndTextScriptEditor = NULL;
			SendMessage(hWndEditorTab[iCurrentEditorTab], WM_INITDIALOG, 0, 0);
		break;
    }
    return FALSE;
} // end TextScriptEditorProc()

LRESULT CALLBACK SetNumberOfTextScriptsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin SetNumberOfTextScriptsProc()
	char byTemp[256];
	short i;

    switch(iMessage)
    {
        case WM_INITDIALOG:
			SetWindowText(hWnd, T_SetNumberOfTextScripts);
			SetDlgItemText(hWnd, IDD_TS_EDITOR_SET_NUMBER_OK, T_Ok);
			SetDlgItemText(hWnd, IDD_TS_EDITOR_SET_NUMBER_CANCEL, T_Cancel);
			sprintf(byTemp, "%d", iNumberTemp);
			SetDlgItemText(hWnd, IDD_TS_EDITOR_SET_NUMBER, byTemp);
			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case IDD_TS_EDITOR_SET_NUMBER_OK:
					GetDlgItemText(hWnd, IDD_TS_EDITOR_SET_NUMBER, byTemp, 256);
					i = (short) atoi(byTemp);
					if(!i)
						i++;
					EndDialog(hWnd, i);
                return TRUE;

                case IDD_TS_EDITOR_SET_NUMBER_CANCEL:
					EndDialog(hWnd, -1);
                return TRUE;
            }
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, IDD_TS_EDITOR_SET_NUMBER_CANCEL, 0);
		break;
    }
    return FALSE;
} // end SetNumberOfTextScriptsProc()

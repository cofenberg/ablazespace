//-----------------------------------------------------------------------------
// File: TextScripts.h
//-----------------------------------------------------------------------------

#ifndef __TEXT_SCRIPTS_H__
#define __TEXT_SCRIPTS_H__


// Structures: ****************************************************************
typedef struct TEXT_SCRIPT_TEXT
{
	short iTextID; // The number of the text
	int dwWait; // The text show time
	short iSurface; // The surface whuch is used as an picture

} TEXT_SCRIPT_TEXT;

typedef struct TEXT_SCRIPT
{
	char byName[256]; // The name of the text script
	short iTexts; // The number of texts
	TEXT_SCRIPT_TEXT *pText; // The texts

} TEXT_SCRIPT;

typedef struct TEXT_SCRIPTS_MANAGER
{
	char byFilename[256]; // Filename of the source text
	short iTextsScripts; // The number of text scripts
} TEXT_SCRIPTS_MANAGER;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern short iTextScriptSourceTexts;
extern char **byTextScriptSourceTexts;
extern TEXT_SCRIPT *pTextScript;
extern BOOL bPlayTextScript;
extern short iPlayTextScriptID;
extern short iPlayTextScriptStep;
extern DWORD dwPlayTextScriptTime;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern void LoadTextScriptSource(char *);
extern void DestroyTextScriptSource(void);
extern LRESULT CALLBACK TextScriptEditorProc(HWND, UINT, WPARAM, LPARAM);
extern void PlayTextScript(short);
extern void DisplayTextScript(AS_WINDOW *);
extern void CheckPlayTextScript(void);
///////////////////////////////////////////////////////////////////////////////


#endif // __TEXT_SCRIPTS_H__
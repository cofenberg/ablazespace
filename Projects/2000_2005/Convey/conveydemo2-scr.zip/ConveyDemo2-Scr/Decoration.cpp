//-----------------------------------------------------------------------------
// File: Decoration.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
DECORATION_MODEL *pDecorationModels;
short iDecorationModels; // The number of decoration models
HWND hWndDecoration, hWndModelBitmap;
short iCurrentDecorationModel,
	  iCurrentModelTexture,
	  iCurrentDecorationModelAnimation,
	  iDecorationCurrentAniStep,
	  iDecorationModelSpeed;
BOOL bDecorationModelAnimated;
HDC hDCModelBitmap;
FLOAT3 fModelViewPos, fModelViewRot;
ACTOR DecorationActor;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
void AddDecoration(char *);
void DestroyAllDecorations(void);
LRESULT CALLBACK DecorationProc(HWND, UINT, WPARAM, LPARAM);
///////////////////////////////////////////////////////////////////////////////


void AddDecoration(char *pbyFilename)
{ // begin AddDecoration()
	char byTemp[256];

	// Add the main path:
	sprintf(byTemp, "%s%s", _AS->pbyProgramPath, pbyFilename);

	iDecorationModels++;
	pDecorationModels = (DECORATION_MODEL *) realloc(pDecorationModels, sizeof(DECORATION_MODEL)*iDecorationModels);
	strcpy(pDecorationModels[iDecorationModels-1].byFilename, pbyFilename);

	pDecorationModels[iDecorationModels-1].pModel = ASLoadMd2Model(byTemp);
} // end AddDecoration()

void DestroyAllDecorations(void)
{ // begin DestroyAllDecorations()
	for(short i = 0; i < iDecorationModels; i++)
		ASFreeMd2Model(pDecorationModels[i].pModel);
	SAFE_DELETE(pDecorationModels);
	iDecorationModels = 0;
} // end DestroyAllDecorations()
	

LRESULT CALLBACK DecorationProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin DecorationProc()
	char byTemp[256], byTemp2[256], byTemp3[256], *pbyTemp;
	static POINT MousePos, OldMousePos;
	FLOAT3 *pFloat;
	RECT Rect;
	FILE *fp;
	short i;

	switch(iMessage)
    {
        case WM_INITDIALOG:
				_AS->WriteLogMessage("Open decoration dialog");
				hWndDecoration = hWnd;
				// Texts:
				SetWindowText(hWnd, T_Decoration);
				SetDlgItemText(hWnd, ID_DECORATION_OK, T_Ok);
				SetDlgItemText(hWnd, ID_DECORATION_UPDATE, T_Update);
				SetDlgItemText(hWnd, ID_DECORATION_LOAD, T_Load);
				SetDlgItemText(hWnd, ID_DECORATION_UNLOAD, T_Unload);
				SetDlgItemText(hWnd, ID_DECORATION_RESET_VIEW, T_Reset);
				SetDlgItemText(hWnd, IDC_DECORATION_T, T_Decoration);
				SetDlgItemText(hWnd, IDC_DECORATION_TEXTURE_T, T_Texture);
				SetDlgItemText(hWnd, IDC_DECORATION_ANIMATION_T, T_Animation);
				SetDlgItemText(hWnd, ID_DECORATION_SPEED_T, T_SpeedObj);
				SetDlgItemText(hWnd, ID_DECORATION_ANIMATED, T_Animated);
				hWndModelBitmap = GetDlgItem(hWnd, ID_DECORATION_SHOW);
				ASInitOpenGL(NULL, hWndModelBitmap, &hDCModelBitmap, &hRCEditorShow, FALSE);
				SetTimer(hWnd, 1, 1, NULL);
				fModelViewPos[X] = fModelViewPos[Y] = 0.0f;
				fModelViewPos[Z] = -7.0f;
				//
			Init:
				memset(&DecorationActor, 0, sizeof(ACTOR));
				if(iCurrentDecorationModel >= iDecorationModels || iCurrentDecorationModel == -1 ||
				   !iDecorationModelSpeed || iCurrentModelTexture >= pLevel->Header.iTextures)
				{
					iCurrentDecorationModelAnimation = 0;
					iCurrentDecorationModel = -1;
					iDecorationCurrentAniStep = 0;
					iDecorationModelSpeed = 150;
					iCurrentModelTexture = -1;
					bDecorationModelAnimated = TRUE;
				}
				else
					iDecorationCurrentAniStep = pDecorationModels[iCurrentDecorationModel].pModel->Ani.anim[iCurrentDecorationModelAnimation].firstFrame;
				sprintf(byTemp, "%d", iDecorationModelSpeed);
				SetDlgItemText(hWnd, ID_DECORATION_SPEED, byTemp);
				SendDlgItemMessage(hWnd, ID_DECORATION_TEXTURE, CB_RESETCONTENT, 0, 0L);
				SendDlgItemMessage(hWnd, ID_DECORATION_TEXTURE, CB_ADDSTRING, 0, (LPARAM) "-");
				for(i = 0; i < pLevel->Header.iTextures; i++)
				{
					sprintf(byTemp, "%s", pLevel->pTexture[i].byFilename, pLevel->pTexture[i].iUsed);
					SendDlgItemMessage(hWnd, ID_DECORATION_TEXTURE, CB_ADDSTRING, 0, (LPARAM) byTemp);
				}
				SendDlgItemMessage(hWnd, ID_DECORATION_TEXTURE, CB_SETCURSEL, iCurrentModelTexture+1, 0L);

				SendDlgItemMessage(hWnd, ID_DECORATION_LIST, LB_RESETCONTENT, 0, 0L);
				for(i = 0; i < iDecorationModels; i++)
				{
					sprintf(byTemp, "%s", pDecorationModels[i].byFilename);
					SendDlgItemMessage(hWnd, ID_DECORATION_LIST, LB_ADDSTRING, 0, (LPARAM) byTemp);
				}
				SendDlgItemMessage(hWnd, ID_DECORATION_LIST, LB_SETCURSEL, iCurrentDecorationModel, 0L);
				if(iCurrentDecorationModel != -1)
					EnableWindow(GetDlgItem(hWnd, ID_DECORATION_UNLOAD), TRUE);
				else
					EnableWindow(GetDlgItem(hWnd, ID_DECORATION_UNLOAD), FALSE);

				SendDlgItemMessage(hWnd, ID_DECORATION_ANIMATION, CB_RESETCONTENT, 0, 0L);
				if(iCurrentDecorationModel != -1)
				{
					for(i = 0; i < pDecorationModels[iCurrentDecorationModel].pModel->Ani.count_anim; i++)
					{
						sprintf(byTemp, "%s", pDecorationModels[iCurrentDecorationModel].pModel->Ani.anim[i].nameAnimation);
						SendDlgItemMessage(hWnd, ID_DECORATION_ANIMATION, CB_ADDSTRING, 0, (LPARAM) byTemp);
					}
					SendDlgItemMessage(hWnd, ID_DECORATION_ANIMATION, CB_SETCURSEL, iCurrentDecorationModelAnimation, 0L);
				}
				else
				{
					EnableWindow(GetDlgItem(hWnd, ID_DECORATION_TEXTURE), TRUE);
					EnableWindow(GetDlgItem(hWnd, ID_DECORATION_ANIMATION), TRUE);
				}
				SendDlgItemMessage(hWnd, ID_DECORATION_ANIMATED, BM_SETCHECK, bDecorationModelAnimated, 0L);				

				ShowWindow(hWnd, _AS->GetCmdShow());
				UpdateWindow(hWnd);
		return TRUE;

		case WM_TIMER:
			if(!wglMakeCurrent(hDCModelBitmap, hRCEditorShow))
				break;
			g_lNow = GetTickCount();
			glDisable(GL_LIGHTING);
			glDisable(GL_FOG);
			glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
			glLoadIdentity();
			glTranslatef(fModelViewPos[X], fModelViewPos[Y], fModelViewPos[Z]);
			glRotatef(fModelViewRot[X], 1.0f, 0.0f, 0.0f);
			glRotatef(fModelViewRot[Y], 0.0f, 1.0f, 0.0f);
			glRotatef(fModelViewRot[Z], 0.0f, 0.0f, 1.0f);
			glScalef(0.1f, 0.1f, 0.1f);
			glDisable(GL_BLEND);
			glCullFace(GL_FRONT);
			if(iCurrentModelTexture == -1)
			{
				glDisable(GL_TEXTURE_2D);
				glLineWidth(1.0f);
				glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
			}
			else
			{
				glEnable(GL_TEXTURE_2D);
				glBindTexture(GL_TEXTURE_2D, pLevel->pTexture[iCurrentModelTexture].iOpenGLID);
			}

			if(iCurrentDecorationModel != -1 &&
			   pDecorationModels[iCurrentDecorationModel].pModel && 
			   iDecorationCurrentAniStep >= 0)
			{
				DecorationActor.fModelInterpolation = (float) (g_lNow-DecorationActor.dwAniTime)/(float) iDecorationModelSpeed;
				DecorationActor.byAnimation = (char) iCurrentDecorationModelAnimation;
				AnimateActorModel(&DecorationActor, *pDecorationModels[iCurrentDecorationModel].pModel, iDecorationModelSpeed, (char) DecorationActor.byAnimation);
				ASDrawMd2FrameInt(pDecorationModels[iCurrentDecorationModel].pModel,
								  DecorationActor.iAniStep, DecorationActor.iNextAniStep,
								  DecorationActor.fModelInterpolation);
			}
			glCullFace(GL_BACK);
			glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
			ASSwapBuffers(hDCModelBitmap, NULL, FALSE);
			break;

        case WM_LBUTTONDOWN: case WM_LBUTTONUP: case WM_RBUTTONDOWN:
        case WM_RBUTTONUP: case WM_MOUSEMOVE:
			i = wParam;
			memcpy(&OldMousePos, &MousePos, sizeof(POINT));
			GetCursorPos(&MousePos);
			GetWindowRect(hWnd, &Rect);
			GetWindowRect(hWndModelBitmap, &Rect);
			pFloat = &fModelViewPos;
			if(MousePos.x > Rect.left && MousePos.x < Rect.right &&
			   MousePos.y > Rect.top && MousePos.y < Rect.bottom)
			{ // The mouse is over the window enable view control:
				if(i & MK_LBUTTON && i & MK_RBUTTON)
					(*pFloat)[Z] -= (float) (MousePos.x-OldMousePos.x+MousePos.y-OldMousePos.y)/20;
				else
				{
					if(i & MK_RBUTTON)
					{
						(*pFloat)[X] -= (float) (OldMousePos.x-MousePos.x)/20;
						(*pFloat)[Y] -= (float) (MousePos.y-OldMousePos.y)/20;
					}
					else
					{
						pFloat = &fModelViewRot;
						if(i & MK_LBUTTON)
						{
							(*pFloat)[X] -= (float) (MousePos.y-OldMousePos.y);
							(*pFloat)[Y] -= (float) (OldMousePos.x-MousePos.x);
						}
						else
						if(i & MK_MBUTTON)
						{
							(*pFloat)[Z] -= (float) (OldMousePos.x-MousePos.x);
						}
					}
				}
			}
        break;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case ID_DECORATION_OK:
					SendMessage(hWnd, WM_CLOSE, 0, 0);
					return TRUE;
				
				case ID_DECORATION_LIST:
					i = (short) SendDlgItemMessage(hWnd, ID_DECORATION_LIST, LB_GETCURSEL, 0, 0L);
					if(i < 0 || i >= iDecorationModels)
						break;
					iCurrentDecorationModel = i;
					goto Init;
				
				case ID_DECORATION_UPDATE:
					// Reload all models:
					for(i = 0; i < iDecorationModels; i++)
					{
						if(pDecorationModels[i].pModel)
							ASFreeMd2Model(pDecorationModels[i].pModel);
						sprintf(byTemp, "%s%s", _AS->pbyProgramPath, pDecorationModels[i].byFilename);
						pDecorationModels[i].pModel = ASLoadMd2Model(byTemp);
					}
				break;

				case ID_DECORATION_LOAD:
					sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyDecorationsFile);
					KillTimer(hWnd, 1);
					pbyTemp = ASGetFileName(hWnd, T_LoadDecoration, MD2_FILE, 0, TRUE, byTemp);
					SetTimer(hWnd, 1, 1, NULL);
					if(!pbyTemp)
						break;
					// 	
					fp = fopen(pbyTemp, "rb");
					if(fp) // It's only one file:
					{
						fclose(fp);
						// Cut off the main path:
						strcpy(pbyTemp, &pbyTemp[strlen(_AS->pbyProgramPath)]);
						//
						AddDecoration(pbyTemp);
						goto Init;
					}
					//
					sscanf(pbyTemp, "%s", byTemp); // Read the path
					pbyTemp += strlen(byTemp)+1;
					// Load the selected files:
					for(;;)
					{
						if(sscanf(pbyTemp, "%s", byTemp2) == EOF)
							break;
						if(byTemp[strlen(byTemp)-1] != '\\')
							sprintf(byTemp3, "%s\\%s", byTemp, byTemp2);
						else
							sprintf(byTemp3, "%s%s", byTemp, byTemp2);
						// Cut off the main path:
						strcpy(byTemp3, &byTemp3[strlen(_AS->pbyProgramPath)]);
						//
						AddDecoration(byTemp3);
						if(*(pbyTemp+strlen(byTemp2)) == 0)
							break;
						pbyTemp += strlen(byTemp2)+1;
					}
					goto Init;

				case ID_DECORATION_UNLOAD:
					if(iCurrentDecorationModel  < 0 || iCurrentDecorationModel >= iDecorationModels)
						break;
					// Update all stuff using decorations:
					for(i = 0; i < pLevel->Header.iFields; i++)
					{
						if(!pLevel->pField[i].pDecoration)
							continue;
						if(pLevel->pField[i].pDecoration->iDecorationID > iCurrentDecorationModel)
							pLevel->pField[i].pDecoration->iDecorationID--;
						else
							if(pLevel->pField[i].pDecoration->iDecorationID == iCurrentDecorationModel)
							{
								if(pLevel->pField[i].pDecoration->iTexture >= 0)
									pLevel->pTexture[pLevel->pField[i].pDecoration->iTexture].iUsed--;
								SAFE_DELETE(pLevel->pField[i].pDecoration);
							}
					}
					//
					if(pDecorationModels[iCurrentDecorationModel].pModel)
						ASFreeMd2Model(pDecorationModels[iCurrentDecorationModel].pModel);
					for(i = iCurrentDecorationModel; i < iDecorationModels-1; i++)
						memcpy(&pDecorationModels[i], &pDecorationModels[i+1], sizeof(DECORATION_MODEL));
					iDecorationModels--;
					pDecorationModels = (DECORATION_MODEL *) realloc(pDecorationModels, sizeof(DECORATION_MODEL)*iDecorationModels);
					if(!iDecorationModels)
						iCurrentDecorationModel = -1;
					else
						iCurrentDecorationModel = 0;
					goto Init;

				case ID_DECORATION_RESET_VIEW:
					fModelViewPos[X] = fModelViewPos[Y] = 0.0f;
					fModelViewPos[Z] = -7.0f;
					fModelViewRot[X] = fModelViewRot[Y] =
					fModelViewRot[Z] = 0;
				break;

				case ID_DECORATION_TEXTURE:
					i = (short) SendDlgItemMessage(hWnd, ID_DECORATION_TEXTURE, CB_GETCURSEL, 0, 0L);
					if(i < 0 || i >= pLevel->Header.iTextures+1)
						break;
					iCurrentModelTexture = i-1;
				break;

				case ID_DECORATION_ANIMATION:
					i = (short) SendDlgItemMessage(hWnd, ID_DECORATION_ANIMATION, CB_GETCURSEL, 0, 0L);
					if(i < 0 || i >= pDecorationModels[iCurrentDecorationModel].pModel->Ani.count_anim)
						break;
					iCurrentDecorationModelAnimation = i;
					memset(&DecorationActor, 0, sizeof(ACTOR));
					DecorationActor.iAniStep = iDecorationCurrentAniStep = pDecorationModels[iCurrentDecorationModel].pModel->Ani.anim[iCurrentDecorationModelAnimation].firstFrame;
				break;

				case ID_DECORATION_SPEED:
					GetDlgItemText(hWnd, ID_DECORATION_SPEED, byTemp, 256);
					iDecorationModelSpeed = (short) atoi(byTemp);
					if(iDecorationModelSpeed < 0)
						iDecorationModelSpeed = 0;
				break;

				case ID_DECORATION_ANIMATED:
					bDecorationModelAnimated = SendDlgItemMessage(hWnd, ID_DECORATION_ANIMATED, BM_SETCHECK, 0, 0L);
				break;
			}
        break;

		case WM_CLOSE: case WM_DESTROY:
			_AS->WriteLogMessage("Close decoration dialog");
			if(hDCModelBitmap && !ReleaseDC(hWnd, hDCModelBitmap))
				hDCModelBitmap = NULL;
			hWndModelBitmap = NULL;
			KillTimer(hWnd, 1);
			EndDialog(hWnd, 0);
			SendMessage(hWndEditor, WM_SIZE, 0, 0);
			hWndDecoration = NULL;
		break;
    }
    return FALSE;
} // end DecorationProc()
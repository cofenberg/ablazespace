26 September, 2003


Fixed problems under WinXP
- Language enumeration
- Campaigns enumeration
- Window mode
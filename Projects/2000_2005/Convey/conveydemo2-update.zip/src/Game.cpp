//-----------------------------------------------------------------------------
// File: Game.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"

//short iTemp = 0;
//BOOL bTemp;

// Variables: *****************************************************************
AS_PARTICLE_MANAGER ParticleManager;
int GAME_WINDOW_ID;
short iLevelCompleteSpeed, iPauseBlendSpeed;
ACTOR DisplayActor[DISPLAY_ACTORS];
ACTOR PlayerTemp;
ACTOR OktaActor;
AS_TEXTURE GameTexture[GAME_TEXTURES];	// The game textures
AS_TEXTURE GameTitleTexture[4];			// The game titel texture
char byCurrentLevelName[256];			// The name of the current level
char bySelectedSingleLevel[256];		// The name of the selected single player level
LEVEL *pLevel;							// The 'main' level
BOOL bSingleLevel,						// Are we playing an single level?
	 bPlayerCameraView,					// Are we in the ego-shooter camera perspective??
	 bUnderWater;						// Is the camera under water?
AS_MD2_MODEL *pXeModel, *pXeWeaponModel, *pOktaModel,
             *pHiroModel, *pMobmobModel, *pX3Model;
AS_MD2_MODEL **pModels[] = {&pXeModel, &pXeWeaponModel,  &pOktaModel,
			                &pHiroModel, &pMobmobModel, &pX3Model};
AS_OBJECT *pHealthObject, *pLiveObject, *pPullObject, *pThrowObject,
	   	   *pForceObject, *pPointObject, *pGhostObject, *pPlayerShot,
		   *pTimeObject, *pStepsObject, *pSpeedObject, *pWingObject,
		   *pShieldObject, *pJumpObject, *pAirObject;
AS_OBJECT **pObjects[] = {&pHealthObject, &pLiveObject, &pPullObject,
						  &pThrowObject, &pForceObject, &pPointObject,
						  &pGhostObject, &pPlayerShot, &pTimeObject,
						  &pStepsObject, &pSpeedObject, &pWingObject,
						  &pShieldObject, &pJumpObject, &pAirObject};
float fSin, fSin90, fCos, fCos90, fCameraVelocity = 1.0f, fPauseBlend,
	  fPauseTextBlend;
float fWaterScale[3], fWaterLastScale[3], fWaterToScale[3], fWaterScaleVelocity[3];
BOOL bPause, bPauseTextBlend, bLevelPressAnyKey, bHurryUpText, bDraw,
	 bGameOver;
long lGameTimer, lPauseTimer, lLevelCompleteTimer, lKeyTimer, lCameraTimerT, lHurryUpTimer,
     lCameraPauseTimerT;
long lGhostTimeSave, lSpeedTimeSave, lWingTimeSave, lShieldTimeSave;
AS_CAMERA TempCamera;
// OpenGL lists:
GLuint iGameTitleList, iWaveList, iShieldList, iHealthObjList, iLiveObjList, iPullObjList,
	   iThrowObjList, iForceObjList, iPointObjList, iGhostObjList, iPlayerShotObjList,
	   iTimeObjList, iStepsObjList, iSpeedObjList, iWingObjList, iShieldObjList,
	   iJumpObjList, iAirObjList, iParticleList;
// Small message:
long lSmallMessageShowTime, lSmallMessageTimer, lSmallMessageTempTimer;
float fSmallMessageBlend;
char bySmallMessageText[256], bySmallMessageNewText[256];
BOOL bSmallMessageChangeText, bSmallMessageShowText;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
HRESULT Game(void);
void LoadGameTextures(void);
HRESULT GameLoop(void);
HRESULT GameDraw(AS_WINDOW *);
HRESULT GameCheck(AS_WINDOW *);
void UpdateAllTextures(void);
void UpdateRenderQuality(void);
void CreateGameLists(void);
void DestroyGameLists(void);
void InitGameObjects(void);
void DestroyGameObjects(void);
void InitGameParticleSystems(void);
void DestroyGameParticleSystems(void);
void CreateWaterWave(float, float, float);
void CalculateCamersSinCos(void);
void CheckCameraKeys(BOOL);
BOOL PlayCameraScript(BOOL);
void SetCameraTranslation(BOOL);
void WaterEntry(void);
void InitDisplayActors(void);
void OpenHelp(void);
void LoadAutosave(void);
void SaveAutosave(void);
void DestroyAutosave(void);
void ShowSmallMessage(char *, long);
void DisplaySmallMessage(AS_WINDOW *);
void CheckSmallMessage(void);
///////////////////////////////////////////////////////////////////////////////


HRESULT Game(void)
{ // begin Game()
	MSG msg;

	_AS->WriteLogMessage("Enter game module");

	// Create the game window and create the DirectInput stuff:
	_AS->ASCreateWindow(WindowProc, GAME_WINDOW_NAME, GAME_WINDOW_NAME, _ASConfig->iWindowWidth,
					    _ASConfig->iWindowHeight, LoadMenu(_AS->GetInstance(), MAKEINTRESOURCE(IDR_GAME)),
						_ASConfig->bFullScreen, GameMenuDraw, GameMenuCheck, NULL, TRUE);
	GAME_WINDOW_ID = _AS->GetWindows()-1;
	ASInitOpenGL(&_AS->pWindow[GAME_WINDOW_ID],
				 NULL,
				 _AS->pWindow[GAME_WINDOW_ID].GethDC(),
				 _AS->pWindow[GAME_WINDOW_ID].GethRC(), _ASConfig->bFullScreen);
	_AS->CreateDXInputDevices(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), FALSE, TRUE, TRUE, FALSE);
	_AS->CreateDXAudio(*_AS->pWindow[GAME_WINDOW_ID].GethWnd());
	ASCreatDXSoundManager(*_AS->pWindow[GAME_WINDOW_ID].GethWnd());
	ShowWindow(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), SW_SHOW);	

	// Load and create the game objects and textures:
	InitGameObjects();
	LoadGameTextures();
	ASGenOpenGLTextures(GAME_TEXTURES, GameTexture);
	ASGenOpenGLTextures(4, GameTitleTexture);
	CreateGameLists();
	InitGameParticleSystems();
	
	// Fist, show the logos:
	if(!bEditorTestLevel)
		bInGameMenu	= TRUE;
	else
		bInGameMenu = FALSE;

	_AS->WriteLogMessage("Enter game main loop");

	for(;;)
	{
		if(_AS->GetShutDown() || _AS->CheckModuleChange())
			break;
		if(bShowLogos)
			Logos();
		else
			if(bInGameMenu)
			{ // We are in the game menu:
				msg.wParam = GameMenuLoop();
			}
			else
			{ // We are in the game:
				ASDXShowClose();
				msg.wParam = GameLoop();
				if(bEditorTestLevel && !bInGameMenu)
					_AS->SetNextModule(MODULE_EDITOR);
				ASDXShowClose();
				byGameMenuMenu = 0;
			}
	}
	_AS->WriteLogMessage("Left game main loop");

	ASDXShowClose();
	DestroyCampaign(&CurrentCampaign);
	DestroyGameObjects();
	ASDestroyOpenGLTextures(GAME_TEXTURES, GameTexture);
	ASDestroyTextures(GAME_TEXTURES, GameTexture);
	ASDestroyOpenGLTextures(4, GameTitleTexture);
	ASDestroyTextures(4, GameTitleTexture);
	DestroyGameLists();
	DestroyGameParticleSystems();

	
	// Destroy the game window and the corresponding DirectInput stuff:
	_AS->FreeDXInputDevices();
	_AS->DestroyDXAudio();
	ASDestroyDXSoundManager();
	ASDestroyOpenGL(&_AS->pWindow[GAME_WINDOW_ID],
					NULL,
				    *_AS->pWindow[GAME_WINDOW_ID].GethDC(),
				    *_AS->pWindow[GAME_WINDOW_ID].GethRC());
	_AS->ASDestroyWindow(_AS->pWindow[GAME_WINDOW_ID].GethWnd(), GAME_WINDOW_NAME);
	// Left the game module:
	_AS->SetModule(MODULE_EDITOR);
	return msg.wParam;
} // end Game()

void LoadGameTextures(void)
{ // begin LoadGameTextures()
	char byFilename[GAME_TEXTURES][256] = {"Fire1.jpg", "Fire2.jpg", "Fire3.jpg",
										   "Fire4.jpg", "Mobmob.jpg", "X3.jpg",
										   "Fire.jpg", "Wave.jpg", "Shield.jpg",
										   "Beam.jpg", "Okta.jpg",
										   "G_Particle1.jpg", "G_Particle2.jpg",
										   "Hiro.jpg", "Wave2.jpg",
										   "Xe.jpg", "Xe_.jpg",
										   "XeRambo.jpg", "XeRambo_.jpg",
										   "XeWeapon.jpg", "XeWeapon_.jpg",
										   "XeWeapon__.jpg", "XeWeapon___.jpg",
										   "Acid.jpg", "Autosave.jpg",
										   "Bubble.jpg"};
	ASLoadTextures(byFilename, GAME_TEXTURES, GameTexture);
	char byFilename2[4][256] = {"Convey1.jpg", "Convey2.jpg",
								"Convey3.jpg", "Convey4.jpg"};
	ASLoadTextures(byFilename2, 4, GameTitleTexture);
} // end LoadGameTextures()

HRESULT GameLoop(void)
{ // begin GameLoop()
	char byTemp[256];
	MSG msg;
	short i;

	InitMenuPoints();
	bDraw = FALSE;
	_AS->pWindow[GAME_WINDOW_ID].SetDrawFunction(GameDraw);
	_AS->pWindow[GAME_WINDOW_ID].SetCheckFunction(GameCheck);

	ASDXShowClose();
	StartCurrentLevel();	
	Sleep(1); // If this isn't done the system will crash... maybe an windows message error??
	lKeyTimer = g_lNow = g_lLastlooptime = GetTickCount();
	bDraw = TRUE;

	// Go into the game loop:
	_AS->WriteLogMessage("Enter the game loop");
	for(;;)
	{
		if(PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
    	{
        	if(!GetMessage(&msg, NULL, 0, 0))
                break;
        	TranslateMessage(&msg);
        	DispatchMessage(&msg);
    	}
		else
		{	
			if(_AS->GetShutDown() || _AS->CheckModuleChange() || bInGameMenu)
				PostQuitMessage(0);
			if(!_AS->GetActive())
			{
				pPlayer->dwAniTime = g_lNow;
				for(i = 0; i < MAX_ACTORS; i++)
					Actor[i].dwAniTime = g_lNow;
				continue;
			}
			_AS->UpdateWindows();
		}
	}
	_AS->WriteLogMessage("Left the game loop");
	DestroyLevel();
	// Save the configuration:	
	sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyConfigFile);
	_ASConfig->Save(byTemp);
	
	if(!bSingleLevel) // Save the player identity:
		SavePlayerIdentity(&PlayerIdentity, &CurrentCampaign);

	DestroyAutosave();
	return msg.wParam;
} // end GameLoop()

HRESULT GameDraw(AS_WINDOW *pWindow)
{ // begin GameDraw()
	float fBlend, f, fScale, fZ;
	char byTemp[256];
	short i, iX, iY;

	if(!bDraw)
		return 0;
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	SetCameraTranslation(TRUE);
	pLevel->DrawSkyCube();
	pLevel->InitLevelDraw();
	ASEnableLighting();

	// Draw the level:
	glEnable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);
	
	SetCameraTranslation(FALSE);
	ASExtractFrustum();

	SetActorsLights();

	glColor3f(1.0f, 1.0f, 1.0f);
	pLevel->Draw(FALSE);

	DrawActors();
	DrawPlayer();
	DrawEffects();

	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	SetCameraTranslation(FALSE);
	ParticleManager.Draw();

	pLevel->DrawTransparent();

	// Draw the water:
	SetCameraTranslation(FALSE);
	pLevel->DrawWater();	

	glDisable(GL_FOG);
	glDisable(GL_LIGHTING);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.f, (GLfloat)_ASConfig->iWindowWidth/(GLfloat)_ASConfig->iWindowHeight, 0.1f, 10000.0f);
	glMatrixMode(GL_MODELVIEW);

	if(bUnderWater)
	{
		glDisable(GL_DEPTH_TEST);
		glEnable(GL_BLEND);
		glDisable(GL_TEXTURE_2D);
		glBlendFunc(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);
		fZ = 1.0f-pLevel->Environment.fWaterDensity;
		if(fZ < 0.1f)
			fZ += 0.2f;
		glColor4f(pLevel->Environment.fWaterColor[0], pLevel->Environment.fWaterColor[1], pLevel->Environment.fWaterColor[2], fZ);
		glDisable(GL_CULL_FACE);
		glLoadIdentity();
		glTranslatef(0.0f, 0.0f, -34.0f);
		glBegin(GL_QUADS);
			glNormal3f(0.0f, 0.0f, 1.0f);
			glVertex3f(-15.0f, -11.0f, 10.0f);
			glVertex3f( 15.0f, -11.0f, 10.0f);
			glVertex3f( 15.0f,  11.0f, 10.0f);
			glVertex3f(-15.0f,  11.0f, 10.0f);
		glEnd();
		glEnable(GL_CULL_FACE);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	}
	if(pPlayer->bGoingDeath)
	{ // Thr player is going death:
		f = ((float) (g_lNow-pPlayer->lStartTime)/PLAYER_DEAD_FLOOR_TIME);
	}		
			
	if(fPauseBlend != 0.0f)
		DisplayTextScript(pWindow);
	if(fPauseBlend != 0.0f)
	{ // Draw the game title:
		glDisable(GL_LIGHTING);
		glDisable(GL_FOG);
		glClear(GL_DEPTH_BUFFER_BIT);
		glEnable(GL_BLEND);
		glDisable(GL_TEXTURE_2D);
		glBlendFunc(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);
		glColor4f(0.1f, 0.1f, 0.1f, 1.0f-fPauseBlend+0.2f);
		glDisable(GL_CULL_FACE);
		glLoadIdentity();
		glTranslatef(0.0f, 0.0f, -34.0f);
		glBegin(GL_QUADS);
			glNormal3f(0.0f, 0.0f, 1.0f);
			glVertex3f(-15.0f, -11.0f, 10.0f);
			glVertex3f( 15.0f, -11.0f, 10.0f);
			glVertex3f( 15.0f,  11.0f, 10.0f);
			glVertex3f(-15.0f,  11.0f, 10.0f);
		glEnd();
		glEnable(GL_CULL_FACE);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);

		glEnable(GL_TEXTURE_2D);
		glDisable(GL_DEPTH_TEST);
		glColor4f(1.0f, 1.0f, 1.0f, fPauseBlend);
		glLoadIdentity();
		if(!bGameOver)
			glTranslatef(-1.0f, 0.4f, -1.8f);
		else
			glTranslatef(-1.0f, 0.6f, -1.8f);
		glRotatef(70.0f, 1.0f, 0.0f, 0.0f);
		glEnable(GL_DEPTH_TEST);
		if(pLevel->State.bLevelComplete)
		{ // Draw the 'dancing' alien:
			glCullFace(GL_FRONT);
			glLoadIdentity();
			if(fPauseBlend == 1.0f)
				glDisable(GL_BLEND);
			glTranslatef(0.0f, 0.0f, -20.0f);
			glRotatef(-90.0f, 0.0f, 1.0f, 0.0f);
			glScalef(0.1f, 0.1f, 0.1f);
			glBindTexture(GL_TEXTURE_2D, GameTexture[XE_TEXTURE+bXeSleep].iOpenGLID);
			ASDrawMd2FrameInt(pXeModel, PlayerTemp.iAniStep, PlayerTemp.iNextAniStep, (float) (g_lNow-PlayerTemp.dwAniTime)/(float) PLAYER_ANIMATION_SPEED);
			glCullFace(GL_BACK);
		}
		glEnable(GL_BLEND);
		
		if(!pLevel->State.bLevelComplete && !bCameraAnimation)
		{
			// Show menu and mission information:
			if(!byGameMenuMenu)
			{ // Game main menu:
				if(!bGameOver)
				{
					iX = iY = 0;
					pLevel->ShowMissionState(pWindow);
					glColor4f(MenuPoint[29].fColor[R], MenuPoint[29].fColor[G], MenuPoint[29].fColor[B], fPauseBlend);
					pWindow->PrintAnimated(500, 450, T_Continue, 0, 1.2f*MenuPoint[29].fSize, fFontAni, 1);
				}
				else
				{
					iX = -180;
					iY = -250;
					pWindow->PrintAnimated(320, 200, T_GameOver, 0, 5.0f, fFontAni, 1);
				}
				if(!bGameOver)
				{
					glColor4f(MenuPoint[30].fColor[R], MenuPoint[30].fColor[G], MenuPoint[30].fColor[B], fPauseBlend);
					pWindow->PrintAnimated(500+iX, 430+iY, T_LoadAutosave, 0, 1.2f*MenuPoint[30].fSize, fFontAni, 1);
				}
				glColor4f(MenuPoint[31].fColor[R], MenuPoint[31].fColor[G], MenuPoint[31].fColor[B], fPauseBlend);
				pWindow->PrintAnimated(500+iX, 410+iY, T_LevelRestart, 0, 1.2f*MenuPoint[31].fSize, fFontAni, 1);
				if(!bSingleLevel)
				{
					glColor4f(MenuPoint[32].fColor[R], MenuPoint[32].fColor[G], MenuPoint[32].fColor[B], fPauseBlend);
					pWindow->PrintAnimated(500+iX, 390+iY, T_RestartCampaign, 0, 1.2f*MenuPoint[32].fSize, fFontAni, 1);
					i = 370;
				}
				else
					i = 390;
				if(!bGameOver)
				{
					glColor4f(MenuPoint[33].fColor[R], MenuPoint[33].fColor[G], MenuPoint[33].fColor[B], fPauseBlend);
					pWindow->PrintAnimated(500+iX, i+iY, T_Options, 0, 1.2f*MenuPoint[33].fSize, fFontAni, 1);
				}
				else
					i += 20;
				glColor4f(MenuPoint[34].fColor[R], MenuPoint[34].fColor[G], MenuPoint[34].fColor[B], fPauseBlend);
				pWindow->PrintAnimated(500+iX, i-20+iY, T_Exit, 0, 1.2f*MenuPoint[34].fSize, fFontAni, 1);
			}
			else
			{ // Something other:
				ShowOptionMenu(pWindow);
			}
		}
		glDisable(GL_BLEND);
	}

	if(pPlayer->fAir != 1.0f && fPauseBlend != 1.0f && !pPlayer->bGoingDeath)
	{ // Show the players air:
		if(fPauseBlend != 0.0f)
			glEnable(GL_BLEND);
		else
			glDisable(GL_BLEND);
		glLoadIdentity();
		glDisable(GL_TEXTURE_2D);
		glDisable(GL_DEPTH_TEST);
		glTranslatef(-.5f, -0.7f, -2.0f);
		glColor4f(0.0f, 0.0f, 0.0f, 1.0f-fPauseBlend);
		glBegin(GL_QUADS);
			glNormal3f(0.0f, 0.0f, 1.0f);

			glVertex3f(-0.01f, -0.01f, 0.0f);
			glVertex3f(1.0f*pPlayer->fAir+0.11f, -0.01f, 0.0f);
			glVertex3f(1.0f*pPlayer->fAir+0.11f, 0.06f, 0.0f);
			glVertex3f(-0.01f, 0.06f, 0.0f);
		glEnd();
		glColor4f(1.0f-pPlayer->fAir, 0.0f, pPlayer->fAir, 1.0f-fPauseBlend);
		glBegin(GL_QUADS);
			glNormal3f(0.0f, 0.0f, 1.0f);

			glVertex3f(0.0f, 0.0f, 0.0f);
			glVertex3f(1.0f*pPlayer->fAir+0.1f, 0.0f, 0.0f);
			glVertex3f(1.0f*pPlayer->fAir+0.1f, 0.05f, 0.0f);
			glVertex3f(0.0f, 0.05f, 0.0f);
		glEnd();
		glEnable(GL_TEXTURE_2D);
		glEnable(GL_DEPTH_TEST);
		glEnable(GL_BLEND);
	}

	if(bCameraAnimation && (pLevel->pCurrentCameraScript == &pLevel->pCameraScript[pLevel->Camera.iStartCamera]))
	{
	}
	else
	if(fPauseBlend != 1.0f || pLevel->State.bLevelComplete)
	{ // Display player info:	
		glEnable(GL_TEXTURE_2D);
		glEnable(GL_BLEND);
		glDisable(GL_FOG);
		glClear(GL_DEPTH_BUFFER_BIT);
		if(!pLevel->State.bLevelComplete)
			fBlend = 1.0f-fPauseBlend;
		else
			fBlend = 1.0f;
		// Display the texts:
		glColor4f(1.0f, 1.0f, 1.0f, fBlend);
		// Lives:
		if(PlayerInfo.iLives < 0)
			sprintf(byTemp, "* 0");
		else
			sprintf(byTemp, "* %d", PlayerInfo.iLives);
		pWindow->PrintAnimated(60, 425, byTemp, 0, 1.0f, fFontAni, 0);
		// Health:
		if(pPlayer->fPower <= 20.0f)
			glColor4f(1.0f, 0.0f, 0.0f, fBlend);
		sprintf(byTemp, "* %0.0f", pPlayer->fPower);
		pWindow->PrintAnimated(60, 385, byTemp, 0, 1.0f, fFontAni, 0);
		glColor4f(1.0f, 1.0f, 1.0f, fBlend);
		// Points:
		sprintf(byTemp, "* %d", PlayerInfo.iPoints);
		pWindow->PrintAnimated(60, 345, byTemp, 0, 1.0f, fFontAni, 0);

		// Display this stuff if it is available:
		// Force:
		if(PlayerInfo.iForce != 1)
		{
			if(!pLevel->Tools.bUnlimitedForce)
			{
				sprintf(byTemp, "* %d", PlayerInfo.iForce);
				pWindow->PrintAnimated(60, 235, byTemp, 0, 1.0f, fFontAni, 0);
			}
			DisplayActor[FORCE_DISPLAY].bActive = TRUE;
		}
		else
			DisplayActor[FORCE_DISPLAY].bActive = FALSE;
		// Throw:
		if(PlayerInfo.bThrowBoxes)
		{
			if(!pLevel->Tools.bUnlimitedThrow)
			{
				sprintf(byTemp, "* %d", PlayerInfo.iThrowBoxes);
				pWindow->PrintAnimated(60, 195, byTemp, 0, 1.0f, fFontAni, 0);
			}
			DisplayActor[THROW_DISPLAY].bActive = TRUE;
		}
		else
			DisplayActor[THROW_DISPLAY].bActive = FALSE;
		// Weapon:
		if(PlayerInfo.bWeapon)
		{
			if(!pLevel->Tools.bUnlimitedWeapon)
			{
				sprintf(byTemp, "* %d", PlayerInfo.iWeaponShots);
				pWindow->PrintAnimated(60, 155, byTemp, 0, 1.0f, fFontAni, 0);
			}
			DisplayActor[WEAPON_DISPLAY].bActive = TRUE;
		}
		else
			DisplayActor[WEAPON_DISPLAY].bActive = FALSE;
		// Pull:
		if(PlayerInfo.bPullBoxes)
		{
			if(!pLevel->Tools.bUnlimitedPull)
			{
				sprintf(byTemp, "* %d", PlayerInfo.iPullBoxes);
				pWindow->PrintAnimated(60, 115, byTemp, 0, 1.0f, fFontAni, 0);
			}
			DisplayActor[PULL_DISPLAY].bActive = TRUE;
		}
		else
			DisplayActor[PULL_DISPLAY].bActive = FALSE;
		// Ghost:
		if(PlayerInfo.bGhost)
		{
			if(PlayerInfo.lGhostWholeTime-(g_lNow-PlayerInfo.lGhostTime) <= 5000)
			{
				glColor4f(1.0f, 0.0f, 0.0f, fBlend);
				fScale = 1.2f;
			}
			else
				fScale = 1.0f;
			sprintf(byTemp, "* %d", PlayerInfo.lGhostWholeTime-(g_lNow-PlayerInfo.lGhostTime));
			pWindow->PrintAnimated(60, 75, byTemp, 0, fScale, fFontAni, 0);
			DisplayActor[GHOST_DISPLAY].bActive = TRUE;
		}
		else
			DisplayActor[GHOST_DISPLAY].bActive = FALSE;
		// Speed:
		if(PlayerInfo.bSpeed)
		{
			if(PlayerInfo.lSpeedWholeTime-(g_lNow-PlayerInfo.lSpeedTime) <= 5000)
			{
				glColor4f(1.0f, 0.0f, 0.0f, fBlend);
				fScale = 1.2f;
			}
			else
				fScale = 1.0f;
			sprintf(byTemp, "* %d", PlayerInfo.lSpeedWholeTime-(g_lNow-PlayerInfo.lSpeedTime));
			pWindow->PrintAnimated(60, 35, byTemp, 0, fScale, fFontAni, 0);
			DisplayActor[SPEED_DISPLAY].bActive = TRUE;
		}
		else
			DisplayActor[SPEED_DISPLAY].bActive = FALSE;
		glColor4f(1.0f, 1.0f, 1.0f, fBlend);
		// Wing:
		if(PlayerInfo.bWing)
		{
			if(PlayerInfo.lWingWholeTime-(g_lNow-PlayerInfo.lWingTime) <= 5000)
			{
				glColor4f(1.0f, 0.0f, 0.0f, fBlend);
				fScale = 1.2f;
			}
			else
				fScale = 1.0f;
			sprintf(byTemp, "* %d", PlayerInfo.lWingWholeTime-(g_lNow-PlayerInfo.lWingTime));
			pWindow->PrintAnimated(550, 230, byTemp, 0, fScale, fFontAni, 0);
			DisplayActor[WING_DISPLAY].bActive = TRUE;
		}
		else
			DisplayActor[WING_DISPLAY].bActive = FALSE;
		glColor4f(1.0f, 1.0f, 1.0f, fBlend);
		// Shield:
		if(PlayerInfo.bShield)
		{
			if(PlayerInfo.lShieldWholeTime-(g_lNow-PlayerInfo.lShieldTime) <= 5000)
			{
				glColor4f(1.0f, 0.0f, 0.0f, fBlend);
				fScale = 1.2f;
			}
			else
				fScale = 1.0f;
			sprintf(byTemp, "* %d", PlayerInfo.lShieldWholeTime-(g_lNow-PlayerInfo.lShieldTime));
			pWindow->PrintAnimated(550, 195, byTemp, 0, fScale, fFontAni, 0);
			DisplayActor[SHIELD_DISPLAY].bActive = TRUE;
		}
		else
			DisplayActor[SHIELD_DISPLAY].bActive = FALSE;
		// Jump:
		if(PlayerInfo.bJump)
		{
			if(!pLevel->Tools.bUnlimitedJump)
			{
				sprintf(byTemp, "* %d", PlayerInfo.iJump);
				pWindow->PrintAnimated(550, 160, byTemp, 0, 1.0f, fFontAni, 0);
			}
			DisplayActor[JUMP_DISPLAY].bActive = TRUE;
		}
		else
			DisplayActor[JUMP_DISPLAY].bActive = FALSE;
		glColor4f(1.0f, 1.0f, 1.0f, fBlend);
		if((pLevel->State.bLevelComplete && pLevel->Missions.iTimeLimit) || !pLevel->State.bLevelComplete)
		{ // Time:
			if(pLevel->Missions.bTimeLimit && pLevel->Missions.iTimeLimit < 10)
			{
				glColor4f(1.0f, 0.0f, 0.0f, fBlend);
				fScale = 1.2f;
			}
			else
				fScale = 1.0f;
			sprintf(byTemp, "* %d", pLevel->Missions.iTimeLimit);
			pWindow->PrintAnimated(550, 425, byTemp, 0, fScale, fFontAni, 0);
		}
		else
			DisplayActor[TIME_DISPLAY].bActive = FALSE;
		glColor4f(1.0f, 1.0f, 1.0f, fBlend);
		if((pLevel->State.bLevelComplete && pLevel->Missions.iStepsLimit) || !pLevel->State.bLevelComplete)
		{ // Steps:
			if(pLevel->Missions.bStepsLimit && pLevel->Missions.iStepsLimit < 10)
			{
				glColor4f(1.0f, 0.0f, 0.0f, fBlend);
				fScale = 1.2f;
			}
			else
				fScale = 1.0f;
			sprintf(byTemp, "* %d", pLevel->Missions.iStepsLimit);
			pWindow->PrintAnimated(550, 385, byTemp, 0, fScale, fFontAni, 0);
		}
		else
			DisplayActor[STEPS_DISPLAY].bActive = FALSE;
		// Draw the symbol:
		glColor4f(1.0f, 1.0f, 1.0f, fBlend);
		for(i = 0; i < DISPLAY_ACTORS; i++)
		{
			if(!DisplayActor[i].bActive)
				continue;
			glLoadIdentity();
			glTranslatef(DisplayActor[i].fWorldPos[X], DisplayActor[i].fWorldPos[Y], DisplayActor[i].fWorldPos[Z]);
			if(i != WEAPON_DISPLAY)
			{
				glRotatef(DisplayActor[i].fRot[X], 1.0f, 0.0f, 0.0f);
				glRotatef(DisplayActor[i].fRot[Y], 0.0f, 1.0f, 0.0f);
				glRotatef(DisplayActor[i].fRot[Z], 0.0f, 0.0f, 1.0f);
			}
			glScalef(DisplayActor[i].fSize*0.2f, DisplayActor[i].fSize*0.2f, DisplayActor[i].fSize*0.2f);
			glBindTexture(GL_TEXTURE_2D, GameTexture[DisplayActor[i].iAniStep].iOpenGLID);
			switch(i)
			{
				case HEALTH_DISPLAY:
					glCallList(iHealthObjList);
				break;

				case LIVE_DISPLAY:
					glCallList(iLiveObjList);
				break;

				case PULL_DISPLAY:
					glCallList(iPullObjList);
				break;

				case THROW_DISPLAY:
					glCallList(iThrowObjList);
				break;

				case FORCE_DISPLAY:
					glCallList(iForceObjList);
				break;

				case WEAPON_DISPLAY:
					glCullFace(GL_FRONT);
					glColor4f(1.0f, 1.0f, 1.0f, fBlend);
					glScalef(0.2f, 0.2f, 0.2f);
					glBindTexture(GL_TEXTURE_2D, GameTexture[19].iOpenGLID);
					ASDrawMd2FrameInt(pXeWeaponModel, DisplayActor[i].iAniStep, DisplayActor[i].iNextAniStep, (float) (g_lNow-DisplayActor[i].dwAniTime)/(float) PLAYER_ANIMATION_SPEED);
					glCullFace(GL_BACK);
				break;

				case POINT_DISPLAY:
					glCallList(iPointObjList);
				break;

				case GHOST_DISPLAY:
					if(GHOST_TIME-(g_lNow-PlayerInfo.lGhostTime) <= 0)
						glScalef(2.0f, 2.0f, 2.0f);
					glCallList(iGhostObjList);
				break;

				case TIME_DISPLAY:
					glCallList(iTimeObjList);
				break;

				case STEPS_DISPLAY:
					glCallList(iStepsObjList);
				break;

				case SPEED_DISPLAY:
					glCallList(iSpeedObjList);
				break;
				
				case WING_DISPLAY:
					glCallList(iWingObjList);
				break;

				case SHIELD_DISPLAY:
					glCallList(iShieldObjList);
				break;

				case JUMP_DISPLAY:
					glCallList(iJumpObjList);
				break;
			}
		}
	}

	if(fPauseBlend == 0.0f)
		DisplayTextScript(pWindow);

	// Show text:	
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glColor4f(1.0f, 1.0f, 1.0f, 0.95f);
	if(!bGameOver)
		DisplaySmallMessage(pWindow);
	
	if(bPause)
	{
		if(fPauseBlend < 1.0f)
		{
			fPauseBlend += (float) g_lDeltatime/iPauseBlendSpeed;
			if(fPauseBlend > 1.0f)
			{
				fPauseBlend = 1.0f;
				iPauseBlendSpeed = PAUSE_BLEND_SPEED;
			}
		}
	}
	else
	{
		if(fPauseBlend > 0.0f)
		{
			fPauseBlend -= (float) g_lDeltatime/iPauseBlendSpeed;
			if(fPauseBlend < 0.0f)
			{
				fPauseBlend = 0.0f;
				iPauseBlendSpeed = PAUSE_BLEND_SPEED;
			}
		}
	}
	if(fPauseBlend != 0.0f && !pLevel->State.bLevelComplete && !bGameOver)
	{
		glColor4f(1.0f, 1.0f, 1.0f, fPauseTextBlend);
		pWindow->Print(320, 450, T_Pause, 0, 1);
	}
	

/////////// Show vertex pos test: //////////////////////////
//	glColor4f(1.0f, 1.0f, 1.0f, 0.9f);
//	sprintf(byTemp, "%d", iTemp);
//	pWindow->Print(300, 450, byTemp, 0, 0);
/////////////////////////////////////////////////////////////////

	
	if(bLevelPressAnyKey && pLevel->State.bLevelComplete)
	{
		glColor4f(1.0f, 1.0f, 1.0f, fPauseTextBlend);
		pWindow->Print(320, 120, M_PressAnyKeyToContinue, 0, 1);
	}
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	if(OktaActor.bActive && !pPlayer->bGoingDeath && !pLevel->State.bLevelComplete
	   && bHurryUpText && !bPause && fPauseBlend == 0.0f && !bGameOver)
		pWindow->Print(320, 10, T_HurryUp, 0, 1);

//	sprintf(byTemp, "%f", pPlayer->fAir);
//	pWindow->Print(150, 450, byTemp, 0);

	ASSwapBuffers(*pWindow->GethDC(), pWindow, TRUE);
	pLevel->DeInitLevelDraw();
	if(_ASConfig->byLight)
	{
		for(i = 0; i < 8; i++)
			glDisable(GL_LIGHT0+i);
	}
	return 0;
} // end GameDraw()

HRESULT GameCheck(AS_WINDOW *pWindow)
{ // begin GameCheck()
	float fXAcceleration = 0.0f, fYAcceleration = 0.0f;
	char byTemp[256], byTemp2[256];
	FLOAT3 fRotT;
	BOOL bLoop;
	short i, iFastLoop;
	FILE *fp;
	long l;

	_AS->ReadDXInput(*pWindow->GethWnd());

	AnimateFont();
	if(bGameOver)
		bPause = TRUE;
	if(!bPause || (bPause && pLevel->State.bLevelComplete))
		ParticleManager.Check();
	if(pLevel->State.bLevelComplete)
	{ 
		if(!pLevel->Header.bEndScreen)
			goto LeaveLevel;
		if(!bLevelPressAnyKey)
		{ // Take all tools like the weapon shots and give the player points for this:
			if(g_lNow-lLevelCompleteTimer > iLevelCompleteSpeed)
			{
				iFastLoop = 1;
				if(iLevelCompleteSpeed == 0)
				{
					for(i = 0; i < 256; i++)
					{
						if(ASKeyFirst[i])
						{
							iFastLoop = -1;;
							break;
						}
					}
				}
				lLevelCompleteTimer = g_lNow;
				for(i = 0; i < 2; i++)
				{
					if(iFastLoop == -1)
						i = 0;
					if(!pLevel->Tools.bUnlimitedWeapon && PlayerInfo.iWeaponShots > 0)
					{
						PlayerInfo.iPoints += 5;
						PlayerInfo.iWeaponShots--;
					}
					else
						PlayerInfo.bWeapon = FALSE;
					if(!pLevel->Tools.bUnlimitedPull && PlayerInfo.iPullBoxes > 0)
					{
						PlayerInfo.iPoints += 5;
						PlayerInfo.iPullBoxes--;
					}
					else
						PlayerInfo.bPullBoxes = FALSE;
					if(!pLevel->Tools.bUnlimitedThrow && PlayerInfo.iThrowBoxes > 0)
					{
						PlayerInfo.iPoints += 5;
						PlayerInfo.iThrowBoxes--;
					}
					else
						PlayerInfo.bThrowBoxes = FALSE;
					if(!pLevel->Tools.bUnlimitedJump && PlayerInfo.iJump > 0)
					{
						PlayerInfo.iPoints += 5;
						PlayerInfo.iJump--;
					}
					else
						PlayerInfo.bJump = FALSE;
					if(!pLevel->Tools.bUnlimitedForce && PlayerInfo.iForce > 1)
					{
						PlayerInfo.iPoints += 5;
						PlayerInfo.iForce--;
					}
					else
						PlayerInfo.iForce = 1;
					if(PlayerInfo.bGhost && GHOST_TIME-(g_lNow-PlayerInfo.lGhostTime) > 0)
					{
						PlayerInfo.iPoints += 1;
						PlayerInfo.lGhostTime -= 500;
					}
					else
					{
						PlayerInfo.lGhostTime = g_lNow;
						PlayerInfo.bGhost = FALSE;
						ParticleManager.pSystem[PS_PLAYER_GHOST].bGoingInActive = TRUE;
					}
					if(PlayerInfo.bSpeed && SPEED_TIME-(g_lNow-PlayerInfo.lSpeedTime) > 0)
					{
						PlayerInfo.iPoints += 1;
						PlayerInfo.lSpeedTime -= 500;
					}
					else
					{
						PlayerInfo.lSpeedTime = g_lNow;
						PlayerInfo.bSpeed = FALSE;
						ParticleManager.pSystem[PS_PLAYER_SPEED].bGoingInActive = TRUE;
					}
					if(PlayerInfo.bWing && WING_TIME-(g_lNow-PlayerInfo.lWingTime) > 0)
					{
						PlayerInfo.iPoints += 1;
						PlayerInfo.lWingTime -= 500;
					}
					else
					{
						PlayerInfo.lWingTime = g_lNow;
						PlayerInfo.bWing = FALSE;
					}
					if(PlayerInfo.bShield && SHIELD_TIME-(g_lNow-PlayerInfo.lShieldTime) > 0)
					{
						PlayerInfo.iPoints += 1;
						PlayerInfo.lShieldTime -= 500;
					}
					else
					{
						PlayerInfo.lShieldTime = g_lNow;
						PlayerInfo.bShield = FALSE;
					}
					if(!pLevel->Missions.bTimeLimit)
						pLevel->Missions.iTimeLimit = 0;
					else
					{
						if(pLevel->Missions.iTimeLimit > 0)
						{
							PlayerInfo.iPoints += 1;
							pLevel->Missions.iTimeLimit -= 5;
						}
						else
							pLevel->Missions.iTimeLimit = 0;
					}
					if(!pLevel->Missions.bStepsLimit)
						pLevel->Missions.iStepsLimit = 0;
					else
					{
						if(pLevel->Missions.iStepsLimit > 0)
						{
							PlayerInfo.iPoints += 1;
							pLevel->Missions.iStepsLimit -= 2;
						}
						else
							pLevel->Missions.iStepsLimit = 0;
					}
					// Check if the player could now go to the next level:
					if(!PlayerInfo.bWeapon &&
					   !PlayerInfo.bPullBoxes &&
					   !PlayerInfo.bThrowBoxes && 
					   PlayerInfo.iForce == 1 &&		
					   !PlayerInfo.bGhost &&
					   !PlayerInfo.bSpeed &&
					   !PlayerInfo.bWing &&
					   !PlayerInfo.bJump &&
					   !PlayerInfo.bShield &&
					   !pLevel->Missions.iTimeLimit &&
					   !pLevel->Missions.iStepsLimit)
					{
						bLevelPressAnyKey = TRUE; // The player could now go to the next level
						return 0;
					}
				}
				// Stop now:
				if(ASKeyFirst[_ASConfig->iLevelRestartKey[0]])
				{ // Restart the current level:
					StartCurrentLevel();
					return 0;
				}
				if(CHECK_KEY(ASKeys, _ASConfig->iLoadAutosaveKey[0]))
				{
					LoadAutosave();
					return 0;
				}
				for(i = 0; i < 256; i++)
				{
					if(CHECK_KEY(ASKeys, i))
					{
						iLevelCompleteSpeed = 0;
						break;
					}
				}
			}
		}
		else
		{ // Left this level now?
			if(ASKeyFirst[_ASConfig->iLevelRestartKey[0]])
			{ // Restart the current level:
				StartCurrentLevel();
				return 0;
			}
			if(CHECK_KEY(ASKeys, _ASConfig->iLoadAutosaveKey[0]))
			{
				LoadAutosave();
				return 0;
			}
			for(i = 0; i < 256; i++)
			{
				if(ASKeyFirst[i])
				{ // Go into the next level:
				LeaveLevel:
					if(bEditorTestLevel)
					{
						_AS->SetNextModule(MODULE_EDITOR);
						return 0;					
					}
					PlayerIdentity.iSelectedLevel++;
					PlayerIdentity.iFinishedLevels++;
					
					if(PlayerIdentity.iSelectedLevel > CurrentCampaign.iLevels || bSingleLevel)
					{ // The game is finished!
						bInGameMenu = TRUE;
						PlayerIdentity.iSelectedLevel--;
						PlayerIdentity.iFinishedLevels--;
						return 0;
					}
					// Setup the current player stuff:
					PlayerIdentity.iPoints[PlayerIdentity.iSelectedLevel-1] = PlayerInfo.iPoints;
					PlayerIdentity.iLives[PlayerIdentity.iSelectedLevel-1] = PlayerInfo.iLives;
					PlayerIdentity.fPower[PlayerIdentity.iSelectedLevel-1] = pPlayer->fPower;
					if(!bSingleLevel) // Save the player identity:
						SavePlayerIdentity(&PlayerIdentity, &CurrentCampaign);

					sprintf(byCurrentLevelName, "%s%s", _AS->pbyProgramPath, CurrentCampaign.byLevelFilename[PlayerIdentity.iSelectedLevel-1]);
					StartLevel(byCurrentLevelName, pLevel->Header.bEndScreen);

					if(!bSingleLevel)
					{ // Save player information:
						GetLevelFileName(CurrentCampaign.byLevelFilename[PlayerIdentity.iSelectedLevel-1], byTemp2);
						sprintf(byTemp, "%s%s\\%s\\%s", _AS->pbyProgramPath, _AS->pbyIdentityFile, PlayerIdentity.byName, byTemp2);
						remove(byTemp); // Delete the old file
						fp = fopen(byTemp, "wb");
						if(!fp)
							return 0;
						fwrite(&PlayerInfo, sizeof(PLAYER_INFO), 1, fp);
						// Save the time dependent stuff:
						g_lNow = GetTickCount();
						l = g_lNow-PlayerInfo.lGhostTime;
						fwrite(&l, sizeof(long), 1, fp);
						l = g_lNow-PlayerInfo.lSpeedTime;
						fwrite(&l, sizeof(long), 1, fp);
						l = g_lNow-PlayerInfo.lWingTime;
						fwrite(&l, sizeof(long), 1, fp);
						l = g_lNow-PlayerInfo.lShieldTime;
						fwrite(&l, sizeof(long), 1, fp);
						fclose(fp);
					}
					break;
				}
			}
		}
	}
	if(bPause)
	{
		if(!pLevel->State.bLevelComplete)
		{
			PlayerInfo.lGhostTime = g_lNow-lGhostTimeSave;
			PlayerInfo.lSpeedTime = g_lNow-lSpeedTimeSave;
			PlayerInfo.lWingTime = g_lNow-lWingTimeSave;
			PlayerInfo.lShieldTime = g_lNow-lShieldTimeSave;
			pPlayer->dwAniTime = g_lNow-pPlayer->dwAniDeltaTime;
			for(i = 0; i < MAX_ACTORS; i++)
				Actor[i].dwAniTime = g_lNow-Actor[i].dwAniDeltaTime;
			OktaActor.dwAniTime = g_lNow-OktaActor.dwAniDeltaTime;
			lSmallMessageTimer = g_lNow-lSmallMessageTempTimer;
		}
		if(fPauseBlend != 1.0f)
			fPauseTextBlend = fPauseBlend;
		else
		{
			if(!bPauseTextBlend)
			{
				fPauseTextBlend += (float) g_lDeltatime/1000;
				if(fPauseTextBlend > 1.0f)
				{
					fPauseTextBlend = 1.0f;
					bPauseTextBlend = 1;
				}
			}
			else
			{
				fPauseTextBlend -= (float) g_lDeltatime/1000;
				if(fPauseTextBlend < 0.0f)
				{
					fPauseTextBlend = 0.0f;
					bPauseTextBlend = 0;
				}
			}
		}
		if(PlayerTemp.byAction != ACTION_FUNNY)
		{
			PlayerTemp.byAction = ACTION_FUNNY;
			PlayerTemp.byAnimation = 8;
			PlayerTemp.iAniStep = pXeModel->Ani.anim[PlayerTemp.byAnimation].firstFrame;
			PlayerTemp.dwAniTime = g_lNow;
		}
		PlayerTemp.iNextAniStep = PlayerTemp.iAniStep+1;
		if(PlayerTemp.iNextAniStep >= pXeModel->Ani.anim[PlayerTemp.byAnimation].lastFrame)
			PlayerTemp.iNextAniStep = pXeModel->Ani.anim[PlayerTemp.byAnimation].firstFrame;
		if(g_lNow-PlayerTemp.dwAniTime > PLAYER_ANIMATION_SPEED)
		{
			PlayerTemp.dwAniTime = g_lNow;
			PlayerTemp.iAniStep++;
			if(PlayerTemp.iAniStep >= pXeModel->Ani.anim[PlayerTemp.byAnimation].lastFrame)
				PlayerTemp.iAniStep = pXeModel->Ani.anim[PlayerTemp.byAnimation].firstFrame;
		}
	}
	if(fPauseBlend != 1.0f)
		fPauseTextBlend = fPauseBlend;

	// Animate the display actors:
	if(!bPause || pLevel->State.bLevelComplete)
	{
		for(i = 0; i < DISPLAY_ACTORS; i++)
		{
			if(!DisplayActor[i].bActive)
				continue;
			if(i == WEAPON_DISPLAY)
			{	
				DisplayActor[i].iNextAniStep = DisplayActor[i].iAniStep+1;
				if(DisplayActor[i].iNextAniStep >= pXeWeaponModel->Ani.anim[1].lastFrame)
					DisplayActor[i].iNextAniStep = pXeWeaponModel->Ani.anim[1].firstFrame;
				if(g_lNow-DisplayActor[i].dwAniTime > PLAYER_ANIMATION_SPEED)
				{
					DisplayActor[i].dwAniTime = g_lNow;
					DisplayActor[i].iAniStep++;
					if(DisplayActor[i].iAniStep >= pXeWeaponModel->Ani.anim[1].lastFrame)
						DisplayActor[i].iAniStep = pXeWeaponModel->Ani.anim[1].firstFrame;
				}
			}
			else
			if(g_lNow-DisplayActor[i].dwAniTime > OBJECTS_ANI_SPEED)
			{
				DisplayActor[i].dwAniTime = g_lNow;
				DisplayActor[i].iAniStep++;
				if(DisplayActor[i].iAniStep > 3)
					DisplayActor[i].iAniStep = 0;
			}
			// Rotate the object:
			DisplayActor[i].fRot[X] += (float) g_lDeltatime/OBJECT_ROTATE_SPEED;
			DisplayActor[i].fRot[Y] += (float) g_lDeltatime/OBJECT_ROTATE_SPEED;
			DisplayActor[i].fRot[Z] += (float) g_lDeltatime/OBJECT_ROTATE_SPEED;
		}
	}
		
// Camera:
	if(!bCameraAnimation)
	{
		CheckCameraKeys(FALSE);
		//	Mouse camera movement and rotate:
		// Compute the player acceleration corresponding the mouse movement:
		fXAcceleration = ((float) ASMouse.lX/g_lDeltatime)*_ASConfig->fMouseSensibility*0.35f;
		fYAcceleration = ((float) ASMouse.lY/g_lDeltatime)*_ASConfig->fMouseSensibility*0.35f;
		if(CHECK_KEY(ASMouse.byButtons, 0) && CHECK_KEY(ASMouse.byButtons, 1) && !bPlayerCameraView)
			pCamera->fZ -= fYAcceleration;
		else
		{
			if(!bPlayerCameraView)
			{
				if(CHECK_KEY(ASMouse.byButtons, 1))
				{
					pCamera->fZ -= fYAcceleration*1.5f;
					pCamera->fRot[Y] += fXAcceleration*10.0f;
				}
				if(CHECK_KEY(ASMouse.byButtons, 0))
				{
					if(fXAcceleration)
					{
						pCamera->fPos2[X] -= fSin90*fXAcceleration;
						pCamera->fPos2[Y] -= fCos90*fXAcceleration;
					}
					if(fYAcceleration)
					{
						pCamera->fPos2[X] -= fSin*fYAcceleration;
						pCamera->fPos2[Y] -= fCos*fYAcceleration;
					}
				}
				if((!CHECK_KEY(ASMouse.byButtons, 0) && !CHECK_KEY(ASMouse.byButtons, 1)) ||
				   CHECK_KEY(ASMouse.byButtons, 2))
				{
					pCamera->fRot[Z] -= fXAcceleration*10.0f;
					pCamera->fRot[X] += -pCamera->fRot2[X]+fYAcceleration*10.0f;
				}
			}
			else
			{
				pCamera->fRot2[Z] -= fXAcceleration*4;
				pCamera->fRot2[X] += fYAcceleration*4;
				if(CHECK_KEY(ASMouse.byButtons, 1))
					pCamera->fRot2[Y] += fXAcceleration*4;
			}
		}
	}
	CalculateCamersSinCos(); // Update the sin/cos for the camera
	if(pLevel->Camera.bEndCameraLoop && pLevel->State.bLevelComplete)
		bLoop = TRUE;
	else
		bLoop = FALSE;
	if(!bPause || pLevel->State.bLevelComplete)
	{
		CheckSmallMessage();
		CheckPlayTextScript();
	}
	if(PlayCameraScript(bLoop))
	{
		if(!bPause)
		{
			CheckPlayer(TRUE);
			CheckActors(FALSE);
		}
		return 0;
	}
	if(!bPlayerCameraView)
	{ // We are in the free camera perspective:
		if(pCamera->fZ > -2.0f)
			pCamera->fZ = -2.0f;
		if(pCamera->fZ < -20.5f)
			pCamera->fZ = -20.5f;
		if(pCamera->fRot[Y] > 90.0f)
			pCamera->fRot[Y] = 90.0f;
		if(pCamera->fRot[Y] < -90.0f)
			pCamera->fRot[Y] = -90.0f;
		if(_ASConfig->bTiltCamera)
		{ // Tilt the camera dependent on the players position:
			if(pPlayer->fWorldPos[X] > pLevel->Header.fWholeWidth/2)
			{
				if(!(pPlayer->fWorldPos[X]-pLevel->Header.fWholeWidth/2))
					fRotT[Y] = 0.0f;
				else
					fRotT[Y] = 100.0f*((pPlayer->fWorldPos[X]-pLevel->Header.fWholeWidth/2)/pLevel->Header.fWholeWidth/2);
			}
			else
			{
				if(!(pLevel->Header.fWholeWidth/2-pPlayer->fWorldPos[X]))
					fRotT[Y] = 0.0f;
				else
					fRotT[Y] = -100.0f*((pLevel->Header.fWholeWidth/2-pPlayer->fWorldPos[X])/pLevel->Header.fWholeWidth/2);
			}
			if(pPlayer->fWorldPos[Y] > pLevel->Header.fWholeHeight/2)
			{
				if(!(pPlayer->fWorldPos[Y]-pLevel->Header.fWholeHeight/2))
					fRotT[X] = 0.0f;
				else
					fRotT[X] = 100.0f*((pPlayer->fWorldPos[Y]-pLevel->Header.fWholeHeight/2)/pLevel->Header.fWholeHeight/2);
			}
			else
			{
				if(!(pLevel->Header.fWholeHeight/2-pPlayer->fWorldPos[Y]))
					fRotT[X] = 0.0f;
				else
					fRotT[X] = -100.0f*((pLevel->Header.fWholeHeight/2-pPlayer->fWorldPos[Y])/pLevel->Header.fWholeHeight/2);
			}
			pCamera->fRot[X] = fRotT[X]*fCos+fRotT[Y]*fSin;
			pCamera->fRot[Y] = fRotT[Y]*fCos+fRotT[X]*fSin;
		}
		// Set the current camera view:
		pCamera->fPos[X] = -pPlayer->fWorldPos[X]+pCamera->fPos2[X]-0.5f;
		pCamera->fPos[Y] = -pPlayer->fWorldPos[Y]+pCamera->fPos2[Y]-0.5f;
		pCamera->fPos[Z] = pCamera->fZ+pCamera->fPos2[Z];
		if(g_lNow-lCameraTimerT > 10)
		{
			lCameraTimerT = g_lNow;
			pCamera->fPos2[X] = pCamera->fPos2[X]/1.03f;
			pCamera->fPos2[Y] = pCamera->fPos2[Y]/1.03f;
			pCamera->fPos2[Z] = pCamera->fPos2[Z]/1.03f;
		}
		if(_ASConfig->bBackCamera)
		{ // Set the back camera:
			pCamera->fRot[Z] = -pPlayer->fRot[Y]-90.0f;
		}
	}
	else
	{ // We are in the ego-shooter perspective:
		pCamera->fPos[X] = -pPlayer->fWorldPos[X]-0.5f;
		pCamera->fPos[Y] = -pPlayer->fWorldPos[Y]-0.5f;
		pCamera->fPos[Z] = pPlayer->fWorldPos[Z]-0.8f;
		
		// Check the rotation boundings:
		for(i = 0; i < 3; i++)
		{
			if(pCamera->fRot2[i] > 70)
				pCamera->fRot2[i] = 70;
			if(pCamera->fRot2[i] < -70)
				pCamera->fRot2[i] = -70;
		}
		if(pCamera->fRot2[X] > 35)
			pCamera->fRot2[X] = 35;
		pCamera->fRot[X] = 90.0f+pCamera->fRot2[X];
		pCamera->fRot[Y] = 0.0f+pCamera->fRot2[Y];
		pCamera->fRot[Z] = -pPlayer->fRot[Y]+270.0f+pCamera->fRot2[Z];
		if(g_lNow-lCameraTimerT > 10)
		{
			lCameraTimerT = g_lNow;
			for(i = 0; i < 3; i++)
			{
				pCamera->fRot2[i] /= 1.001f;
				pCamera->fRot2Velocity[i] /= 1.03f;
				pCamera->fRot2[i] += (float) pCamera->fRot2Velocity[i]*g_lDeltatime/10;
			}
		}
	}

	if(pLevel->State.bLevelComplete)
	{
		CheckPlayer(TRUE);
		CheckActors(FALSE);
		return 0;
	}
// Keys:
	if(!byGameMenuMenu && ASKeyFirst[_ASConfig->iLevelRestartKey[0]])
	{ // Restart the current level:
		StartCurrentLevel();
		return 0;
	}
	
	
/////////// Show vertex pos test: //////////////////////////
/*	if(ASKeyFirst[DIK_A])
	{
		if(iTemp > 1)
			iTemp--;
	}
	if(ASKeyFirst[DIK_S])
	{
		if(iTemp < 250)
			iTemp++;
	}*/
/////////////////////////////////////////////////////////////////



	if(ASKeyFirst[DIK_ESCAPE])
	{ // Pause the game:
		bPlayTextScript = FALSE;
		ASKeyFirst[_ASConfig->iPauseKey[0]] = TRUE;
	}
	if(bPause && !pLevel->State.bLevelComplete)
	{ // The player has some options in the pause screen:
		CheckMenuPoints();
		if(!byGameMenuMenu)
		{ // Game main menu:
			if(ASKeyFirst[DIK_UP])
			{
				byGameMenuSelected--;
				if(bGameOver && byGameMenuSelected == 4)
					byGameMenuSelected--;
				if(bSingleLevel && byGameMenuSelected == 3)
					byGameMenuSelected--;
			}
			if(ASKeyFirst[DIK_DOWN])
			{
				byGameMenuSelected++;
				if(bSingleLevel && byGameMenuSelected == 3)
					byGameMenuSelected++;
				if(bGameOver && byGameMenuSelected == 4)
					byGameMenuSelected++;
			}
			if(!bGameOver)
			{
				if(byGameMenuSelected < 0)
					byGameMenuSelected = 5;
				if(byGameMenuSelected >= 6)
					byGameMenuSelected = 0;
			}
			else
			{
				if(byGameMenuSelected < 2)
					byGameMenuSelected = 5;
				if(byGameMenuSelected >= 6)
					byGameMenuSelected = 2;
			}
			switch(byGameMenuSelected)
			{
				case 0: MenuPoint[29].bSelected = TRUE; break;
				case 1: MenuPoint[30].bSelected = TRUE; break;
				case 2: MenuPoint[31].bSelected = TRUE; break;
				case 3: MenuPoint[32].bSelected = TRUE; break;
				case 4: MenuPoint[33].bSelected = TRUE; break;
				case 5: MenuPoint[34].bSelected = TRUE; break;
			}
			if(ASKeyFirst[DIK_SPACE] || ASKeyFirst[DIK_RETURN])
			{
				switch(byGameMenuSelected)
				{
					case 0: // Continue game:
						ASKeyFirst[_ASConfig->iPauseKey[0]] = TRUE;
					break;

					case 1: // Load autosave:
						LoadAutosave();
					break;

					case 2: // Restart level:
						StartCurrentLevel();
					break;

					case 3: // Restart campaign:
						strcpy(byTemp, PlayerIdentity.byName);
						CreateNewPlayerInfo(&PlayerIdentity, &CurrentCampaign);
						strcpy(PlayerIdentity.byName, byTemp);
						StartCurrentLevel();
					break;

					case 4: // Options:
						byGameMenuMenu = 6;
						byGameMenuSelected = 0;
					break;

					case 5: // Quit:
						if(!bEditorTestLevel)
							SendMessage(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), WM_COMMAND, ID_GAME_FILE_GAME_MENU, 0);
						else
							_AS->SetNextModule(MODULE_EDITOR);
					break;
				}
			}
		}
		else
		{ // Something other:
			if(ASKeyFirst[DIK_UP])
				byGameMenuSelected--;
			if(ASKeyFirst[DIK_DOWN])
				byGameMenuSelected++;
			CheckOptionMenu();
			ASKeyFirst[_ASConfig->iPauseKey[0]] = FALSE;
		}
	}
	if(!byGameMenuMenu && ASKeyFirst[_ASConfig->iPauseKey[0]] && !pLevel->State.bLevelComplete && !pPlayer->bGoingDeath &&
		!bGameOver)
	{
		InitMenuPoints();
		lPauseTimer = g_lNow;
		bPause = !bPause;
		byGameMenuSelected = 0;
		lGhostTimeSave = g_lNow-PlayerInfo.lGhostTime;
		lSpeedTimeSave = g_lNow-PlayerInfo.lSpeedTime;
		lWingTimeSave = g_lNow-PlayerInfo.lWingTime;
		lShieldTimeSave =  g_lNow-PlayerInfo.lShieldTime;
		lSmallMessageTempTimer = g_lNow-lSmallMessageTimer;
	}
	if(ASKeyFirst[DIK_F1])
	{ // Open the help file:
		if(_ASConfig->bFullScreen)
		{ // Switch to window mode:
			_ASConfig->bFullScreen = FALSE;
			ChangeDisplayMode();
		}
		ASKeys[DIK_F1] = 0;
		OpenHelp();
		ASKeyFirst[_ASConfig->iPauseKey[0]] = TRUE; // Pause the game
	}
	if(!byGameMenuMenu)
	{
		if(ASKeyFirst[_ASConfig->iChangePerspectiveKey[0]])
		{ // Change the perscective:
			if(!bPlayerCameraView && pLevel->Camera.bPlayerCamera)
			{
				memcpy(&TempCamera, pCamera, sizeof(AS_CAMERA));
				bPlayerCameraView = TRUE;
				for(i = 0; i < 3; i++)
					pCamera->fRot[i] = pCamera->fRot2[i] = pCamera->fRot2Velocity[i] = 0;
			}
			else
			if(bPlayerCameraView && pLevel->Camera.bFreeCamera)
			{
				memcpy(pCamera, &TempCamera, sizeof(AS_CAMERA));
				pCamera->fPos2[Z] = -pCamera->fPos[Z];
				bPlayerCameraView = FALSE;
			}
		}
		if(ASKeyFirst[_ASConfig->iBackCameraKey[0]])
		{ // Change the camera mode: (back camera or not)
			_ASConfig->bBackCamera = !_ASConfig->bBackCamera;
		}
		if(ASKeyFirst[_ASConfig->iTiltCameraKey[0]])
		{ // Change the camera mode: (back camera or not)
			_ASConfig->bTiltCamera = !_ASConfig->bTiltCamera;
		}
		if(CHECK_KEY(ASKeys, _ASConfig->iLoadAutosaveKey[0]))
			LoadAutosave();
	}
	
	if(ASKeyFirst[DIK_F12])
	{ // Open the configuration menu:
		SendMessage(*_AS->pWindow[GAME_WINDOW_ID].GethWnd(), WM_COMMAND, ID_OPTIONS_CONFIG, 0);
	}

	if(bPause)
		return 0;
// Actors:
	CheckActors(FALSE);
	CheckPlayer(FALSE);

	// Level time limit:
	pLevel->Missions.CheckTime();
	pLevel->CheckMissions();
	if(OktaActor.bActive && g_lNow-lHurryUpTimer > 500)
	{
		lHurryUpTimer = g_lNow;
		bHurryUpText = !bHurryUpText;
	}
	return 0;
} // end GameCheck()

void UpdateAllTextures(void)
{ // begin UpdateAllTextures()
	if(bFirstRunConfigDialog)
		return;
	ASDestroyOpenGLTextures(GAME_TEXTURES, GameTexture);
	ASDestroyOpenGLTextures(4, GameTitleTexture);
	ASDestroyOpenGLTextures(GAME_MENU_TEXTURES, GameMenuTexture);
	ASDestroyOpenGLTextures(LOGOS_TEXTURES, LogosTexture);
	ASGenOpenGLTextures(GAME_TEXTURES, GameTexture);
	ASGenOpenGLTextures(4, GameTitleTexture);
	ASGenOpenGLTextures(GAME_MENU_TEXTURES, GameMenuTexture);
	ASGenOpenGLTextures(LOGOS_TEXTURES, LogosTexture);
	switch(_AS->GetModule())
	{
		case MODULE_GAME:
			_AS->pWindow[GAME_WINDOW_ID].KillFont();
			_AS->pWindow[GAME_WINDOW_ID].BuildFont();
			if(pLevel)
			{
				pLevel->DestroyTexturesOpenGL(*_AS->pWindow[GAME_WINDOW_ID].GethDC(), 
											  *_AS->pWindow[GAME_WINDOW_ID].GethRC());
				pLevel->GenTexturesOpenGL(*_AS->pWindow[GAME_WINDOW_ID].GethDC(), 
										  *_AS->pWindow[GAME_WINDOW_ID].GethRC());
			}
		break;

		case MODULE_EDITOR:
			ASKillFont();
			ASBuildFont();
			if(pLevel)
			{
				pLevel->DestroyTexturesOpenGL(hDCEditorShow, hRCEditorShow);
				pLevel->GenTexturesOpenGL(hDCEditorShow, hRCEditorShow);
			}
		break;
	}
} // end UpdateAllTextures()

void UpdateRenderQuality(void)
{ // begin UpdateRenderQuality()
	RECT Rect;

	if(bFirstRunConfigDialog)
		return;
	switch(_AS->GetModule())
	{
		case MODULE_GAME:
			ASConfigOpenGL(_AS->pWindow[GAME_WINDOW_ID].GetWidth(), _AS->pWindow[GAME_WINDOW_ID].GetWidth());
		break;

		case MODULE_EDITOR:
			GetWindowRect(hWndEditorShow, &Rect);
			wglMakeCurrent(hDCEditorShow, hRCEditorShow);
			ASConfigOpenGL(Rect.right-Rect.left, Rect.bottom-Rect.top);
		break;
	}
} // end UpdateRenderQuality()

void CreateGameLists(void)
{ // begin CreateGameLists()
	short i;

	_AS->WriteLogMessage("Create game lists");
	// Game title list:
	iGameTitleList = glGenLists(20);
	glNewList(iGameTitleList, GL_COMPILE);
		for(i = 0; i < 4; i++)
		{
			glTranslatef(0.5, 0.0f, 0.0f);
			glBindTexture(GL_TEXTURE_2D, GameTitleTexture[i].iOpenGLID);
			glBegin(GL_QUADS);
				// Left bottom
				glNormal3f( 0.0f, 0.0f, 1.0f);
				glTexCoord2f(0.01f, 0.99f); glVertex3f(-0.5f, -0.5f, 0.0f);
				glTexCoord2f(0.99f, 0.99f); glVertex3f(0.0f, -0.5f, 0.0f);
				glTexCoord2f(0.99f, 0.01f); glVertex3f(0.0f, 0.0f, 0.0f);
				glTexCoord2f(0.01f, 0.01f); glVertex3f(-0.5f, 0.0f, 0.0f);
			glEnd();
		}
	glEndList();
	// Wave list:
	iWaveList = iGameTitleList+1;
	glNewList(iWaveList, GL_COMPILE);
		glBindTexture(GL_TEXTURE_2D, GameTexture[7].iOpenGLID);
		glBegin(GL_QUADS);
			// Left bottom
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f(-0.5f, -0.5f, 0.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f(0.0f, -0.5f, 0.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f(0.0f, 0.0f, 0.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f(-0.5f, 0.0f, 0.0f);
			// Right bottom
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f(0.0f, -0.5f, 0.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f(0.5f, -0.5f, 0.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f(0.5f, 0.0f, 0.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f(0.0f, 0.0f, 0.0f);
			// Left Top
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f(-0.5f, 0.0f, 0.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f(0.0f, 0.0f, 0.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f(0.0f, 0.5f, 0.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f(-0.5f, 0.5f, 0.0f);
			// Right Top
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f(0.0f, 0.0f, 0.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f(0.5f, 0.0f, 0.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f(0.5f, 0.5f, 0.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f(0.0f, 0.5f, 0.0f);
		glEnd();
	glEndList();
	// Shield list:
	iShieldList = iWaveList+1;
	glNewList(iShieldList, GL_COMPILE);
		glBindTexture(GL_TEXTURE_2D, GameTexture[8].iOpenGLID);
		glBegin(GL_QUADS);
			glNormal3f( 0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.01f, 0.01f); glVertex3f(-0.8f, -0.8f, 0.0f);
			glTexCoord2f(0.01f, 0.99f); glVertex3f(0.8f, -0.8f, 0.0f);
			glTexCoord2f(0.99f, 0.99f); glVertex3f(0.8f, 0.8f, 0.0f);
			glTexCoord2f(0.99f, 0.01f); glVertex3f(-0.8f, 0.8f, 0.0f);
		glEnd();
	glEndList();
	// Health object list:
	iHealthObjList = iShieldList+1;
	glNewList(iHealthObjList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		if(pHealthObject)
			pHealthObject->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
	// Live object list:
	iLiveObjList = iHealthObjList+1;
	glNewList(iLiveObjList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		if(pLiveObject)
			pLiveObject->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
	//  object list:
	iPullObjList = iLiveObjList+1;
	glNewList(iPullObjList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		if(pPullObject)
			pPullObject->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
	// Throw object list:
	iThrowObjList = iPullObjList+1;
	glNewList(iThrowObjList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		if(pThrowObject)
			pThrowObject->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
	// Force object list:
	iForceObjList = iThrowObjList+1;
	glNewList(iForceObjList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		if(pForceObject)
			pForceObject->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
	// Point object list:
	iPointObjList = iForceObjList+1;
	glNewList(iPointObjList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		if(pPointObject)
			pPointObject->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
	// Ghost object list:
	iGhostObjList = iPointObjList+1;
	glNewList(iGhostObjList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		if(pGhostObject)
			pGhostObject->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
	// Player shot object list:
	iPlayerShotObjList = iGhostObjList+1;
	glNewList(iPlayerShotObjList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		if(pPlayerShot)
			pPlayerShot->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
	// Time object list::
	iTimeObjList = iPlayerShotObjList+1;
	glNewList(iTimeObjList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		if(pTimeObject)
			pTimeObject->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
	// Step object list::
	iStepsObjList = iTimeObjList+1;
	glNewList(iStepsObjList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		if(pStepsObject)
			pStepsObject->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
	// Speed object list::
	iSpeedObjList = iStepsObjList+1;
	glNewList(iSpeedObjList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		if(pSpeedObject)
			pSpeedObject->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
	// Wing object list::
	iWingObjList = iSpeedObjList+1;
	glNewList(iWingObjList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		if(pWingObject)
			pWingObject->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
	// Shield object list::
	iShieldObjList = iWingObjList+1;
	glNewList(iShieldObjList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		if(pShieldObject)
			pShieldObject->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
	// Jump object list::
	iJumpObjList = iShieldObjList+1;
	glNewList(iJumpObjList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		if(pJumpObject)
			pJumpObject->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
	// Air object list::
	iAirObjList = iJumpObjList+1;
	glNewList(iAirObjList, GL_COMPILE);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		if(pAirObject)
			pAirObject->Draw(TRUE, TRUE, FALSE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	glEndList();
	// Particle list::
	iParticleList = iAirObjList+1;
	glNewList(iParticleList, GL_COMPILE);
		glBegin(GL_QUADS);
			glTexCoord2f(0.0f, 0.0f); glVertex3f(-0.2f, -0.2f, 0.0f);
			glTexCoord2f(1.0f, 0.0f); glVertex3f(0.2f, -0.2f, 0.0f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f(0.2f, 0.2f, 0.0f);
			glTexCoord2f(0.0f, 1.0f); glVertex3f(-0.2f, 0.2f, 0.0f);
		glEnd();
	glEndList();
	_AS->WriteLogMessage("Ok");
} // end CreateGameLists()()

void DestroyGameLists(void)
{ // begin DestroyGameLists()
	glDeleteLists(iGameTitleList, 20);
} // end DestroyeGameLists()()

void InitGameObjects(void)
{ // begin InitGameObjects()
	char byModelFileTemp[MODELS][256] = {"Xe.md2", "XeWeapon.md2", "Okta.md2",
										 "Hiro.md2", "Mobmob.md2", "X3.md2"};
	char byObjectFileTemp[OBJECTS][256] = {"HealthObj.aso", "LiveObj.aso", "PullObj.aso",
										   "ThrowObj.aso", "ForceObj.aso", "PointObj.aso",
										   "GhostObj.aso", "PlayerShotObj.aso",
										   "TimeObj.aso", "StepsObj.aso", "SpeedObj.aso",
										   "WingObj.aso", "ShieldObj.aso",
										   "JumpObj.aso", "AirObj.aso"};
	char byTemp[256], byTemp2[256];
	short i;

	// Load all models:
	for(i = 0; i < MODELS; i++)
	{
		sprintf(byTemp, "%s%s\\%s", _AS->pbyProgramPath, _AS->pbyObjectsFile, byModelFileTemp[i]);
		sprintf(byTemp2, "Load model: %s", byTemp);
		_AS->WriteLogMessage(byTemp2);
		if(!((*pModels[i]) = ASLoadMd2Model(byTemp)))
		{
			_AS->WriteLogMessage("------------------------------------------");
			_AS->WriteLogMessage("Couldn't load: %s   program couldn't run!!", byTemp);
			_AS->WriteLogMessage("------------------------------------------");
			_ASConfig->bError = TRUE;
			_ASConfig->bSetError = TRUE;
			_AS->SetShutDown(TRUE);
			return;
		}
	}
	// Setup the right texture size for the models:
	for(i = 0; i < pHiroModel->header.numTexCoords; i++)
		pHiroModel->texCoords[i].s = (short) (pHiroModel->texCoords[i].s*((float) 256/320));
	pHiroModel->header.skinWidth = 256;
	pHiroModel->header.skinHeight = 256;
	for(i = 0; i < pX3Model->header.numTexCoords; i++)
		pX3Model->texCoords[i].s = (short) (pX3Model->texCoords[i].s*((float) 256/308));
	pMobmobModel->header.skinWidth = 256;
	pMobmobModel->header.skinHeight = 256;
	pOktaModel->header.skinHeight = 256;
	// Load all objects:
	for(i = 0; i < OBJECTS; i++)
	{
		*pObjects[i] = new AS_OBJECT;
		sprintf(byTemp, "%s%s\\%s", _AS->pbyProgramPath, _AS->pbyObjectsFile, byObjectFileTemp[i]);
		sprintf(byTemp2, "Load object: %s", byTemp);
		_AS->WriteLogMessage(byTemp2);
		if((*pObjects[i])->Load(byTemp) == -1)
		{
			_AS->WriteLogMessage("------------------------------------------");
			_AS->WriteLogMessage("Couldn't load: %s   program couldn't run!!", byTemp);
			_AS->WriteLogMessage("------------------------------------------");
			_ASConfig->bError = TRUE;
			_ASConfig->bSetError = TRUE;
			_AS->SetShutDown(TRUE);
			return;
		}
	}
	// Create and initalize the player:
	pPlayer = new ACTOR;
	memset(&PlayerInfo, 0, sizeof(PLAYER_INFO));
} // end InitGameObjects()

void DestroyGameObjects(void)
{ // begin DestroyGameObjects()
	short i;
	
	// Destroy all game objects:
	for(i = 0; i < MODELS; i++)
	{
		if(!(*pModels[i]))
			continue;
		ASFreeMd2Model(*pModels[i]);
	}
	// Destroy all objects:
	for(i = 0; i < OBJECTS; i++)
	{
		if(!(*pObjects[i]))
			continue;
		(*pObjects[i])->Destroy();
		delete *pObjects[i];
	}

	// 'Destroy' the player:
	delete pPlayer;
} // end DestroyGameObjects()

void InitGameParticleSystems(void)
{ // begin InitGameParticleSystems()
	// PS_PLAYER_SPEED
	ParticleManager.AddNewSystem(PS_Md2Trace, 2000, pPlayer, &GameTexture[6], NULL);
	// PS_PLAYER_GHOST
	ParticleManager.AddNewSystem(PS_Md2Trace, 2000, pPlayer, &GameTexture[12], NULL);
	// PS_PLAYER_AUTOSAVE
	ParticleManager.AddNewSystem(PS_Autosave, 224, pPlayer, &GameTexture[24], NULL);
	// PS_PLAYER_BUBBLE
	ParticleManager.AddNewSystem(PS_Bubbles, 19, pPlayer, &GameTexture[25], NULL);
	ParticleManager.pSystem[PS_PLAYER_BUBBLE].bActive = TRUE;
	// PS_WATER_WAVES
	ParticleManager.AddNewSystem(PS_WaterWaves, 200, NULL, &GameTexture[14], NULL);
	ParticleManager.pSystem[PS_WATER_WAVES].bActive = TRUE;
} // end InitGameParticleSystems()

void DestroyGameParticleSystems(void)
{ // begin DestroyGameParticleSystems()
	ParticleManager.Destroy();
} // end DestroyGameParticleSystems()

void CreateWaterWave(float fXPos, float fYPos, float fSize)
{ // begin CreateWaterWave()
	AS_PARTICLE *pParticleT;
	short i;
	
	i = ParticleManager.pSystem[PS_WATER_WAVES].GetFreeParticle();
	if(i == -1)
		return;
	pParticleT = &ParticleManager.pSystem[PS_WATER_WAVES].pParticle[i];
	pParticleT->bAlive = TRUE;
	pParticleT->fEngine = (float) 1.0;
	pParticleT->fColor[0] = 1.0f;
	pParticleT->fColor[1] = 1.0f;
	pParticleT->fColor[2] = 1.0f;
	pParticleT->fFadeSpeed = 0.004f;
	pParticleT->fSize = fSize;
	pParticleT->fPos[X] = fXPos;
	pParticleT->fPos[Y] = fYPos;
} // end CreateWaterWave()

void CalculateCamersSinCos(void)
{ // begin CalculateCamersSinCos()
	// We should be in the range of 0.0 and 360.0:
	for(;;)
	{
		if(pCamera->fRot[Z] < 0.0f)
			pCamera->fRot[Z] += 360.0f;
		if(pCamera->fRot[Z] > 360.0f)
			pCamera->fRot[Z] -= 360.0f;
		if(pCamera->fRot[Z] >= 0.0f && pCamera->fRot[Z] <= 360.0f)
			break;
	}
	// This are the sin/cos depending of the current camera direction:
	fSin = (float) sin(pCamera->fRot[Z]*PI180);
	fSin90 = (float) sin((pCamera->fRot[Z]+90.0f)*PI180);
	fCos = (float) cos(pCamera->fRot[Z]*PI180);
	fCos90 = (float) cos((pCamera->fRot[Z]+90.0f)*PI180);
} // end CalculateCamersSinCos()

void CheckCameraKeys(BOOL bEditor)
{ // begin CheckCameraKeys()
	// Camera movement keys:
	if(bEditor)
	{
		if(CHECK_KEY(ASKeys, DIK_LEFT))
		{
			if(hWndEditorShow)
			{
				SetActiveWindow(hWndEditorShow);
				SetFocus(hWndEditorShow);
			}
			pCamera->fPos[X] += fSin90*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
			pCamera->fPos[Y] += fCos90*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
			pCamera->fPos2[X] += fSin90*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
			pCamera->fPos2[Y] += fCos90*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
		}
		if(CHECK_KEY(ASKeys, DIK_RIGHT))
		{
			if(hWndEditorShow)
			{
				SetActiveWindow(hWndEditorShow);
				SetFocus(hWndEditorShow);
			}
			pCamera->fPos[X] -= fSin90*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
			pCamera->fPos[Y] -= fCos90*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
			pCamera->fPos2[X] -= fSin90*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
			pCamera->fPos2[Y] -= fCos90*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
		}
		if(CHECK_KEY(ASKeys, DIK_UP))
		{
			if(hWndEditorShow)
			{
				SetActiveWindow(hWndEditorShow);
				SetFocus(hWndEditorShow);
			}
			pCamera->fPos[X] += fSin*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
			pCamera->fPos[Y] += fCos*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
			pCamera->fPos2[X] += fSin*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
			pCamera->fPos2[Y] += fCos*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
		}
		if(CHECK_KEY(ASKeys, DIK_DOWN))
		{
			if(hWndEditorShow)
			{
				SetActiveWindow(hWndEditorShow);
				SetFocus(hWndEditorShow);
			}
			pCamera->fPos[X] -= fSin*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
			pCamera->fPos[Y] -= fCos*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
			pCamera->fPos2[X] -= fSin*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
			pCamera->fPos2[Y] -= fCos*SCROLL_SPEED*g_lDeltatime*fCameraVelocity;
		}
	}

	// Rotate and move the camera:
	if(CHECK_KEY(ASKeys, DIK_NUMPAD4))
		pCamera->fRot[Y] += 0.05f*g_lDeltatime*fCameraVelocity;
	if(CHECK_KEY(ASKeys, DIK_NUMPAD6))
		pCamera->fRot[Y] -= 0.05f*g_lDeltatime*fCameraVelocity;
	if(CHECK_KEY(ASKeys, DIK_NUMPAD8))
	{
		pCamera->fRot[X] += -pCamera->fRot2[X]+0.05f*g_lDeltatime*fCameraVelocity;
		pCamera->fRot2[X] = 0.0f;
	}
	if(CHECK_KEY(ASKeys, DIK_NUMPAD2))
		pCamera->fRot[X] -= 0.05f*g_lDeltatime*fCameraVelocity;
	if(CHECK_KEY(ASKeys, DIK_NUMPAD9))
		pCamera->fRot[Z] -= 0.05f*g_lDeltatime*fCameraVelocity;
	if(CHECK_KEY(ASKeys, DIK_NUMPAD3))
		pCamera->fRot[Z] += 0.05f*g_lDeltatime*fCameraVelocity;
	
	// Check the standart view key:
	if(CHECK_KEY(ASKeys, _ASConfig->iStandartViewKey[0]) && !pPlayer->bGoingDeath)
		pLevel->SetStandartView();
		
	// Zoom in and out:
	if(CHECK_KEY(ASKeys, DIK_ADD))
		pCamera->fZ += 0.01f*g_lDeltatime*fCameraVelocity;
	if(CHECK_KEY(ASKeys, DIK_SUBTRACT))
		pCamera->fZ -= 0.01f*g_lDeltatime*fCameraVelocity;
} // end CheckCameraKeys()

BOOL PlayCameraScript(BOOL bLoop)
{ // begin PlayCameraScript()
	AS_CAMERA *pCameraNow, *pCameraNext;
	float fDeltaT;
	short i, i2;

	if(bCameraAnimation && pLevel->pCurrentCameraScript)
	{ // We play a camera script:
		if(pPlayer->byAction != ACTION_STAND)
		{
			pPlayer->byAction = ACTION_STAND;
			pPlayer->byAnimation = 1;
			pPlayer->iAniStep = 0;
			pPlayer->dwAniTime = g_lNow;
		}
		if(bPause && !pLevel->State.bLevelComplete)
			lCameraTimer = g_lNow-lCameraPauseTimerT;
		if(!bPause || pLevel->State.bLevelComplete)
		{
			// Make a smooth camera movement:
			// Get the camera positions:
			pCameraNow = &pLevel->pCurrentCameraScript->pCamera[pLevel->Camera.iCurrentCameraStep];
			i2 = pLevel->Camera.iCurrentCameraStep+1;
			if(i2 >= pLevel->pCurrentCameraScript->iSteps)
				i2 = 0;
			pCameraNext = &pLevel->pCurrentCameraScript->pCamera[i2];
			
			// No division throught zero!!
			if(!pCameraNow->iTimeToNext)
				pCameraNow->iTimeToNext = 1;
			if(!pCameraNext->iTimeToNext)
				pCameraNext->iTimeToNext = 1;

			// Calculate the current camera pos:
			fDeltaT = (float) (g_lNow-lCameraTimer)/pCameraNow->iTimeToNext;
			if(fDeltaT > 1.0f)
				fDeltaT = 1.0f;
			for(i = 0; i < 3; i++)
			{
				pCamera->fPos[i] = pCameraNow->fPos[i]-(pCameraNow->fPos[i]-pCameraNext->fPos[i])*fDeltaT;
					
				float fD = pCameraNow->fRot[i]-pCameraNext->fRot[i];
				float fDistance;
				
				// The rotation is a little more complex...
				if(fD > 180 || fD < -180)
				{
					// Calculate the 'real' distance:
					if(pCameraNow->fRot[i] < 180)
						fDistance = pCameraNow->fRot[i];
					else
						fDistance = 360-pCameraNow->fRot[i];
					if(pCameraNext->fRot[i] < 180)
						fDistance += pCameraNext->fRot[i];
					else
						fDistance += 360-pCameraNext->fRot[i];

					// Check how we have to turn:
					if(fD < 0)  // We have to turn left:
						pCamera->fRot[i] = pCameraNow->fRot[i]-(fDistance*fDeltaT);
					else // We have to turn right:
						pCamera->fRot[i] = pCameraNow->fRot[i]+(fDistance*fDeltaT);
				}
				else
					pCamera->fRot[i] = pCameraNow->fRot[i]-(pCameraNow->fRot[i]-pCameraNext->fRot[i])*fDeltaT;
			}
			pCamera->fZ = pCameraNow->fZ-(pCameraNow->fZ-pCameraNext->fZ)*fDeltaT+TempCamera.fZ;
			// Check if we have to go to the next camera step:
			if(g_lNow-lCameraTimer >= pLevel->pCurrentCameraScript->pCamera[pLevel->Camera.iCurrentCameraStep].iTimeToNext)
			{ // Go to the next animation step:
				lCameraTimer = g_lNow;
				pLevel->Camera.iCurrentCameraStep++;
				if(pLevel->Camera.iCurrentCameraStep >= pLevel->pCurrentCameraScript->iSteps-1 && !bLoop)
				{
					pCamera->fPos2[X] = pCamera->fPos[X]+pPlayer->fWorldPos[X]+0.5f;
					pCamera->fPos2[Y] = pCamera->fPos[Y]+pPlayer->fWorldPos[Y]+0.5f;
					pCamera->fPos2[Z] = (pCamera->fPos[Z]-pPlayer->fWorldPos[Z]);
					bCameraAnimation = FALSE;
					lKeyTimer = g_lNow = g_lLastlooptime = GetTickCount();
				}
				else
				{
					if(pLevel->Camera.iCurrentCameraStep >= pLevel->pCurrentCameraScript->iSteps)
						pLevel->Camera.iCurrentCameraStep = 0;
				}
			}
		}
		if(ASKeyFirst[_ASConfig->iPauseKey[0]] && !pLevel->State.bLevelComplete)
		{
			lPauseTimer = g_lNow;
			bPause = !bPause;
			if(bPause)
				lCameraPauseTimerT = g_lNow-lCameraTimer;
		}
		if(!bLoop && !bPause)
		{
			// Stop the camera script?
			for(i = 0; i < 256; i++)
			{
				if(i == _ASConfig->iPauseKey[0] && !pLevel->State.bLevelComplete)
					continue;
				if(ASKeyFirst[i])
				{
					pLevel->Camera.iCurrentCameraStep = pLevel->pCurrentCameraScript->iSteps-1;
					memcpy(pCamera, &pLevel->pCurrentCameraScript->pCamera[pLevel->Camera.iCurrentCameraStep], sizeof(AS_CAMERA));
					bCameraAnimation = FALSE;
					memset(&pCamera->fPos2, 0, sizeof(FLOAT3));
					lKeyTimer = g_lNow = g_lLastlooptime = GetTickCount();
					return 0;
				}
			}
		}
		return 1;
	}
	return 0;
} // end PlayCameraScript()

void SetCameraTranslation(BOOL bOnlyRot)
{ // begin SetCameraTranslation(()
	FLOAT3 fPoint, fPos[5], fRayDirection;
	FLOAT3 fPosT, fPos2;
	float fRotT, fRotCos;
	FIELD *pFieldT;
	short i, i2;

	if(_AS->GetModule() != MODULE_EDITOR)
	{
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		gluPerspective(45.f+fWaterScale[0], (GLfloat)(_ASConfig->iWindowWidth+fWaterScale[1])/(GLfloat)(_ASConfig->iWindowHeight+fWaterScale[2]), 0.1f, 10000.0f);
		glMatrixMode(GL_MODELVIEW);
	}
	else
		bUnderWater = FALSE;
	if(bCameraAnimation || _AS->GetModule() == MODULE_EDITOR)
	{
		glLoadIdentity();
		glRotatef(pCamera->fRot[X]-pCamera->fRot2[X], 1.0f, 0.0f, 0.0f);
		glRotatef(pCamera->fRot[Y]+180.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(pCamera->fRot[Z]+180.0f, 0.0f, 0.0f, 1.0f);
		if(!bOnlyRot)
			glTranslatef(pCamera->fPos[X], pCamera->fPos[Y], -pCamera->fPos[Z]);

		// Check if the camera is under water:
		if(pCamera->fPos[Z] >= pLevel->Environment.fWaterActualHeight-0.2f &&
		   -pCamera->fPos[X] >= 0.0f && -pCamera->fPos[Y] >= 0.0f && -pCamera->fPos[X] <= pLevel->Header.fWholeWidth &&
		   -pCamera->fPos[Y] <= pLevel->Header.fWholeHeight)
		{ // Yes!:
			if(!bUnderWater)
			{
				WaterEntry();
				bUnderWater = TRUE; // Yes!:
			}
		}
		else
			bUnderWater = FALSE;

	}
	else
	{
		glLoadIdentity();
		if(!bPlayerCameraView)
		{
			if(!bFreeCamera)
			{	// Check the camera height:
				if(pCamera->fRot[X] > 0.0f)
					pCamera->fRot[X] = 0.0f;
				// Calculate the camera point position in the level:
				fRotCos = (float) cos(-pCamera->fRot[X]*PI/180);
				if(fRotCos > 0.0f)
					fRotCos = 1.0f-fRotCos;
				else
					fRotCos = 1.0f;
				fPos[0][X] = (pPlayer->fWorldPos[X]-pCamera->fPos2[X]+0.5f)-fSin*pCamera->fPos[Z]*fRotCos;
				fPos[0][Y] = (pPlayer->fWorldPos[Y]-pCamera->fPos2[Y]+0.5f)-fCos*pCamera->fPos[Z]*fRotCos;
				fPos[1][X] = (pPlayer->fWorldPos[X]-pCamera->fPos2[X]+0.4f)-fSin*pCamera->fPos[Z]*fRotCos;
				fPos[1][Y] = (pPlayer->fWorldPos[Y]-pCamera->fPos2[Y]+0.4f)-fCos*pCamera->fPos[Z]*fRotCos;
				fPos[2][X] = (pPlayer->fWorldPos[X]-pCamera->fPos2[X]+0.6f)-fSin*pCamera->fPos[Z]*fRotCos;
				fPos[2][Y] = (pPlayer->fWorldPos[Y]-pCamera->fPos2[Y]+0.4f)-fCos*pCamera->fPos[Z]*fRotCos;
				fPos[3][X] = (pPlayer->fWorldPos[X]-pCamera->fPos2[X]+0.4f)-fSin*pCamera->fPos[Z]*fRotCos;
				fPos[3][Y] = (pPlayer->fWorldPos[Y]-pCamera->fPos2[Y]+0.6f)-fCos*pCamera->fPos[Z]*fRotCos;
				fPos[4][X] = (pPlayer->fWorldPos[X]-pCamera->fPos2[X]+0.6f)-fSin*pCamera->fPos[Z]*fRotCos;
				fPos[4][Y] = (pPlayer->fWorldPos[Y]-pCamera->fPos2[Y]+0.6f)-fCos*pCamera->fPos[Z]*fRotCos;
				fRotCos = (float) cos(-pCamera->fRot[X]*PI/180);
				fPos[0][Z] = fPos[1][Z] = fPos[2][Z] = fPos[3][Z] = fPos[4][Z] =
				pPlayer->fWorldPos[Z]+pCamera->fPos[Z]*fRotCos;

				// Ray direction for the 'normal' test points:
				fRayDirection[X] = 0.0f;
				fRayDirection[Y] = 0.0f;
				fRayDirection[Z] = 1.0f;
				fPoint[X] = fPoint[Y] = fPoint[Z] = 0.0f;
				pCamera->fRot2[X] = 0.0f;
				// Get the height of the center:
				for(i2 = 0; i2 < 5; i2++)
				{
					for(i = 0; i < 2; i++)
					{
						if(!i)
							pFieldT = pLevel->ComputeHeight(fPos[i2][X], fPos[i2][Y], fRayDirection, &fPoint, FACE_FLOOR, 0.5f);
						else
						{
							pFieldT = pLevel->ComputeHeight(fPos[i2][X], fPos[i2][Y], fRayDirection, &fPoint, FACE_FRONT, 0.5f);
							if(!pFieldT)
								continue;
						}
						if(pFieldT)
						{
							if(fPoint[Z] < fPos[i2][Z])
							{
								// Calculate the rotation angle:
								fPoint[Z] -= pPlayer->fWorldPos[Z];
								fPoint[Z] /= pCamera->fPos[Z];
								fRotT = (float) (pCamera->fRot[X]-(-acos(fPoint[Z])*180/PI));
								if(pCamera->fRot2[X] > fRotT)
									pCamera->fRot2[X] = fRotT;
							}
						}
						else
						{
							if(!bFreeCamera && STANDART_LEVEL_Z_POS < fPos[i2][Z])
							{
								fPoint[Z] = STANDART_LEVEL_Z_POS;
								// Calculate the rotation angle:
								fPoint[Z] -= pPlayer->fWorldPos[Z];
								fPoint[Z] /= pCamera->fPos[Z];
								fRotT = (float) (pCamera->fRot[X]-(-acos(fPoint[Z])*180/PI));
								if(pCamera->fRot2[X] > fRotT)
									pCamera->fRot2[X] = fRotT;
							}
						}
					}
				}
				
				// Because we only checked the bounding points it's possible that a terrain point is inside the box,
				// and then the box is inside a hill... now we have to check if a terrain point is inside the box if
				// yes then check it's height:

				// Compute the current field the given point is on:
				short iXFieldPos, iYFieldPos, iXPos, iYPos, iFieldID;
				
				COMPUTE_FIELD_POS(fPos[0][X], fPos[0][Y], iXFieldPos, iYFieldPos);

				// Check the field and the fields around:
				for(iYPos = iYFieldPos-1; iYPos < iYFieldPos+1; iYPos++)
				{
					// Check if this coordinate is a correct one:
					if(iYPos < 0 || iYPos > pLevel->Header.iHeight-2)
						continue; // No correct field!

					for(iXPos = iXFieldPos-1; iXPos < iXFieldPos+1; iXPos++)
					{
						// Check if this coordinate is a correct one:
						if(iXPos < 0 || iXPos > pLevel->Header.iWidth-2)
							continue; // No correct field!

						// Get a pointer to this field:
						GET_FIELD_ID(iXFieldPos, iYFieldPos, iFieldID);
						pFieldT = &pLevel->pField[iFieldID];

						// Check if one of the points is in the bounding box:
						for(i = 0; i < 4; i++)
						{
							if(pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][i]][X] > fPos[0][X]-0.1f &&
							   pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][i]][Y] > fPos[0][Y]-0.1f &&
							   pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][i]][X] < fPos[0][X]+0.1f &&
							   pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][i]][Y] < fPos[0][Y]+0.1f)
							{ // Check the height;
								if(fPos[0][Z] > pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][i]][Z])
								{
									fPoint[Z] = pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][i]][Z];
									fPoint[Z] -= pPlayer->fWorldPos[Z];
									fPoint[Z] /= pCamera->fPos[Z];
									fRotT = (float) (pCamera->fRot[X]-(-acos(fPoint[Z])*180/PI));
									if(pCamera->fRot2[X] >= fRotT)
										pCamera->fRot2[X] = fRotT;
								}
							}
						}
					}
				}
			}

			// Check if the camera is under water:
			fRotCos = (float) cos(-(pCamera->fRot[X])*PI/180);
			if(pPlayer->fWorldPos[Z]+pCamera->fPos[Z]*fRotCos >= pLevel->Environment.fWaterActualHeight+0.5f)
			{
				if(fRotCos > 0.0f)
					fRotCos = 1.0f-fRotCos;
				else
					fRotCos = 1.0f;
				fPos[0][X] = (pPlayer->fWorldPos[X]-pCamera->fPos2[X]+0.5f)-fSin*pCamera->fPos[Z]*fRotCos;
				fPos[0][Y] = (pPlayer->fWorldPos[Y]-pCamera->fPos2[Y]+0.5f)-fCos*pCamera->fPos[Z]*fRotCos;
				if(fPos[0][X] >= 0.0f && fPos[0][Y] >= 0.0f && fPos[0][X] <= pLevel->Header.fWholeWidth &&
				   fPos[0][Y] <= pLevel->Header.fWholeHeight)
				{
					if(!bUnderWater)
					{
						WaterEntry();
						bUnderWater = TRUE; // Yes!:
					}
				}
				else
					bUnderWater = FALSE;
			}
			else
				bUnderWater = FALSE;

			// Set camera:
			if(!bOnlyRot)
				glTranslatef(0.0f, 0.0f, pCamera->fPos[Z]);
			glRotatef(pCamera->fRot[X]-pCamera->fRot2[X], 1.0f, 0.0f, 0.0f);
			glRotatef(pCamera->fRot[Y]+180.0f, 0.0f, 1.0f, 0.0f);
			glRotatef(pCamera->fRot[Z]+180.0f, 0.0f, 0.0f, 1.0f);
			if(!bOnlyRot)
				glTranslatef(pCamera->fPos[X], pCamera->fPos[Y], -pPlayer->fWorldPos[Z]+0.5f);
		}
		else
		{ // Player view:
			glMatrixMode(GL_PROJECTION);
			glLoadIdentity();
			gluPerspective(90.f+fWaterScale[0], (GLfloat)(_ASConfig->iWindowWidth+fWaterScale[1])/(GLfloat)(_ASConfig->iWindowHeight-((float) _ASConfig->iWindowHeight*0.2f+fWaterScale[2])), 0.1f, 10000.0f);
			glMatrixMode(GL_MODELVIEW);
			
			glRotatef(pCamera->fRot[X], 1.0f, 0.0f, 0.0f);
			glRotatef(pCamera->fRot[Y], 0.0f, 1.0f, 0.0f);
			glRotatef(pCamera->fRot[Z], 0.0f, 0.0f, 1.0f);

			fPos2[X] = pPlayer->fWorldPos[X]+0.5f;
			fPos2[Y] = pPlayer->fWorldPos[Y]+0.5f;
			fPos2[Z] = pPlayer->fWorldPos[Z]-0.6f;
			ASGetMd2Vertex(pXeModel, pPlayer->iAniStep, pPlayer->iNextAniStep, pPlayer->fModelInterpolation, fPos2, 0.025f,
						   -90.0f, pPlayer->fRot[Y], 0.0f, 9, &fPosT);
			if(!bOnlyRot)
				glTranslatef(-fPosT[X], -fPosT[Y], -fPosT[Z]-0.13f);

			// Check if the camera is under water:
			if(fPosT[Z] >= pLevel->Environment.fWaterActualHeight-0.2f)
			{ // Yes!:
				if(!bUnderWater)
				{
					WaterEntry();
					bUnderWater = TRUE; // Yes!:
				}
			}
			else
				bUnderWater = FALSE;
		}
	}

	if(!bUnderWater)
	{
		for(i = 0; i < 3; i++)
		{
			fWaterScale[i] = fWaterLastScale[i] =
			fWaterToScale[i] = fWaterScaleVelocity[i] = 0.0f;
		}
		return;
	}
	// Create the under water effect:
	if(fWaterLastScale[0] > fWaterToScale[0])
	{
		fWaterScaleVelocity[0] -= (float) g_lDeltatime/100000;
		fWaterScale[0] += fWaterScaleVelocity[0];
		if(fWaterScale[0] <= fWaterToScale[0])
		{
			fWaterScaleVelocity[0] *= 0.6f;
			if(!(rand() % 2))
				fWaterToScale[0] = -(float) (rand() % 1000)/1000;
			else
				fWaterToScale[0] = (float) (rand() % 1000)/1000;
		}
	}
	else
	{
		fWaterScaleVelocity[0] += (float) g_lDeltatime/100000;
		fWaterScale[0] += fWaterScaleVelocity[0];
		if(fWaterScale[0] >= fWaterToScale[0])
		{
			fWaterScaleVelocity[0] *= 0.6f;
			if(!(rand() % 2))
				fWaterToScale[0] = -(float) (rand() % 1000)/1000;
			else
				fWaterToScale[0] = (float) (rand() % 1000)/1000;
		}
	}
	for(i = 1; i < 3; i++)
	{
		if(fWaterLastScale[i] > fWaterToScale[i])
		{
			fWaterScaleVelocity[i] -= (float) g_lDeltatime/10000;
			fWaterScale[i] += fWaterScaleVelocity[i];
			if(fWaterScale[i] <= fWaterToScale[i])
			{
				fWaterScaleVelocity[i] *= 0.8f;
				if(!(rand() % 2))
					fWaterToScale[i] = -(float) (rand() % 1000)/50;
				else
					fWaterToScale[i] = (float) (rand() % 1000)/50;
			}
		}
		else
		{
			fWaterScaleVelocity[i] += (float) g_lDeltatime/10000;
			fWaterScale[i] += fWaterScaleVelocity[i];
			if(fWaterScale[i] >= fWaterToScale[i])
			{
				fWaterScaleVelocity[i] *= 0.8f;
				if(!(rand() % 2))
					fWaterToScale[i] = -(float) (rand() % 1000)/50;
				else
					fWaterToScale[i] = (float) (rand() % 1000)/50;
			}
		}
	}
} // end SetCameraTranslation()

void WaterEntry(void)
{ // begin WaterEntry()
	short i;

	if(!(rand() % 2))
	{
		fWaterToScale[0] = -10.0f;
		fWaterScaleVelocity[0] = 0.05f;
	}
	else
	{
		fWaterToScale[0] = 10.0f;
		fWaterScaleVelocity[0] = -0.05f;
	}
	for(i = 1; i < 3; i++)
	{
		if(!(rand() % 2))
		{
			fWaterToScale[i] = -100.0f;
			fWaterScaleVelocity[i] = 0.1f;
		}
		else
		{
			fWaterToScale[i] = 100.0f;
			fWaterScaleVelocity[i] = -0.1f;
		}
	}
} // end WaterEntry()

void InitDisplayActors(void)
{ // begin InitDisplayActors()
	float f;
	short i;

	for(i = 0; i < DISPLAY_ACTORS; i++)
		DisplayActor[i].fSize = 1.0f;

	for(i = 0; i < DISPLAY_ACTORS; i++)
	{
		DisplayActor[i].bActive = TRUE;
		DisplayActor[i].fWorldPos[X] = -7.0f;
		DisplayActor[i].fWorldPos[Y] = 5.0f-i;
		DisplayActor[i].fWorldPos[Z] = -15.0f;
		if(i > 2)
			DisplayActor[i].fWorldPos[Y] -= 2.0f;
	}
	f = DisplayActor[HEALTH_DISPLAY].fWorldPos[Y]; 
	DisplayActor[HEALTH_DISPLAY].fWorldPos[Y] = DisplayActor[LIVE_DISPLAY].fWorldPos[Y];
	DisplayActor[LIVE_DISPLAY].fWorldPos[Y] = f;

	f = DisplayActor[POINT_DISPLAY].fWorldPos[Y]; 
	DisplayActor[POINT_DISPLAY].fWorldPos[Y] = DisplayActor[PULL_DISPLAY].fWorldPos[Y];
	DisplayActor[PULL_DISPLAY].fWorldPos[Y] = f;

	f = DisplayActor[FORCE_DISPLAY].fWorldPos[Y]; 
	DisplayActor[FORCE_DISPLAY].fWorldPos[Y] = DisplayActor[THROW_DISPLAY].fWorldPos[Y];
	DisplayActor[THROW_DISPLAY].fWorldPos[Y] = f;

	DisplayActor[TIME_DISPLAY].fWorldPos[X] = 6.0f;
	DisplayActor[TIME_DISPLAY].fWorldPos[Y] = 5.0f;
	DisplayActor[STEPS_DISPLAY].fWorldPos[X] = 6.0f;
	DisplayActor[STEPS_DISPLAY].fWorldPos[Y] = 4.0f;

	DisplayActor[WING_DISPLAY].fWorldPos[X] = 6.0f;
	DisplayActor[WING_DISPLAY].fWorldPos[Y] = 0.0f;
	DisplayActor[SHIELD_DISPLAY].fWorldPos[X] = 6.0f;
	DisplayActor[SHIELD_DISPLAY].fWorldPos[Y] = -1.0f;
	DisplayActor[JUMP_DISPLAY].fWorldPos[X] = 6.0f;
	DisplayActor[JUMP_DISPLAY].fWorldPos[Y] = -2.0f;
} // end InitDisplayActors()

void OpenHelp(void)
{ // begin OpenHelp()
	char byTemp[256];

	_AS->WriteLogMessage("Open help file");
	sprintf(byTemp, "%s%s", _AS->pbyProgramPath, T_HelpFile);
	ShellExecute(0, "open", byTemp, 0, 0, SW_SHOW);
} // end OpenHelp()

void LoadAutosave(void)
{ // begin LoadAutosave()
	short iVersion;
	char byTemp[256];
	FILE *fp;
	long l;

	if(PlayerInfo.iLives < 0)
		return;
	_AS->WriteLogMessage("Load autosave");	
	
	// Load the level:
	sprintf(byTemp, "%sData\\Autosave.sav", _AS->pbyProgramPath);
	StartLevel(byTemp, TRUE);
	bCameraAnimation = bPlayTextScript = FALSE;
	// Load additional information:
	sprintf(byTemp, "%sData\\Autosave.inf", _AS->pbyProgramPath);
	fp = fopen(byTemp, "rb");
	if(!fp)
		return;
	fread(&iVersion, sizeof(short), 1, fp);
	if(iVersion != LEVEL_VERSION)
		return;
	fread(&pLevel->Header, sizeof(LEVEL_HEADER), 1, fp);
	fread(&pLevel->Environment, sizeof(LEVEL_ENVIRONMENT), 1, fp);
	fread(&pLevel->Tools, sizeof(LEVEL_TOOLS), 1, fp);
	fread(&pLevel->Missions, sizeof(LEVEL_MISSIONS), 1, fp);
	fread(&pLevel->State, sizeof(LEVEL_STATE), 1, fp);
	fread(&pLevel->Camera, sizeof(LEVEL_CAMERA), 1, fp);
	fread(pPlayer, sizeof(ACTOR), 1, fp);
	fread(&PlayerInfo, sizeof(PLAYER_INFO), 1, fp);
	fread(&PlayerIdentity, sizeof(PLAYER_IDENTITY), 1, fp);
	// Load the time dependent stuff:
	g_lNow = GetTickCount();
	fread(&l, sizeof(long), 1, fp);
	PlayerInfo.lGhostTime = g_lNow-l;
	fread(&l, sizeof(long), 1, fp);
	PlayerInfo.lSpeedTime = g_lNow-l;
	fread(&l, sizeof(long), 1, fp);
	PlayerInfo.lWingTime = g_lNow-l;
	fread(&l, sizeof(long), 1, fp);
	PlayerInfo.lShieldTime = g_lNow-l;
	fclose(fp);
	if(PlayerInfo.bGhost)
		ParticleManager.pSystem[PS_PLAYER_GHOST].bActive = TRUE;
	else
		ParticleManager.pSystem[PS_PLAYER_GHOST].bActive = FALSE;
	if(PlayerInfo.bSpeed)
		ParticleManager.pSystem[PS_PLAYER_SPEED].bActive = TRUE;
	else
		ParticleManager.pSystem[PS_PLAYER_SPEED].bActive = FALSE;
	PlayerInfo.iCheckpointFieldID = pPlayer->iFieldID;
	ParticleManager.pSystem[PS_PLAYER_AUTOSAVE].bActive = TRUE;
	ParticleManager.pSystem[PS_PLAYER_AUTOSAVE].bUpdate = TRUE;
	
	// Decrease lives:
	PlayerInfo.iLives--;
	if(PlayerInfo.iLives < 0)
		pPlayer->fPower = 0.0f;
	SaveAutosave();
} // end LoadAutosave()

void SaveAutosave(void)
{ // begin SaveAutosave()
	short iVersion;
	char byTemp[256];
	FILE *fp;
	long l;

	_AS->WriteLogMessage("Save autosave");
	
	// Save the level:
	sprintf(byTemp, "%sData\\Autosave.sav", _AS->pbyProgramPath);
	pLevel->Save(byTemp);

	// Save additional information:
	sprintf(byTemp, "%sData\\Autosave.inf", _AS->pbyProgramPath);
	remove(byTemp); // Delete the old file
	fp = fopen(byTemp, "wb");
	if(!fp)
		return;
	iVersion = LEVEL_VERSION;
	fwrite(&iVersion, sizeof(short), 1, fp);
	fwrite(&pLevel->Header, sizeof(LEVEL_HEADER), 1, fp);
	fwrite(&pLevel->Environment, sizeof(LEVEL_ENVIRONMENT), 1, fp);
	fwrite(&pLevel->Tools, sizeof(LEVEL_TOOLS), 1, fp);
	fwrite(&pLevel->Missions, sizeof(LEVEL_MISSIONS), 1, fp);
	fwrite(&pLevel->State, sizeof(LEVEL_STATE), 1, fp);
	fwrite(&pLevel->Camera, sizeof(LEVEL_CAMERA), 1, fp);
	fwrite(pPlayer, sizeof(ACTOR), 1, fp);
	fwrite(&PlayerInfo, sizeof(PLAYER_INFO), 1, fp);
	fwrite(&PlayerIdentity, sizeof(PLAYER_IDENTITY), 1, fp);
	// Save the time dependent stuff:
	g_lNow = GetTickCount();
	l = g_lNow-PlayerInfo.lGhostTime;
	fwrite(&l, sizeof(long), 1, fp);
	l = g_lNow-PlayerInfo.lSpeedTime;
	fwrite(&l, sizeof(long), 1, fp);
	l = g_lNow-PlayerInfo.lWingTime;
	fwrite(&l, sizeof(long), 1, fp);
	l = g_lNow-PlayerInfo.lShieldTime;
	fwrite(&l, sizeof(long), 1, fp);
	fclose(fp);
	ParticleManager.pSystem[PS_PLAYER_AUTOSAVE].bActive = TRUE;
	ParticleManager.pSystem[PS_PLAYER_AUTOSAVE].bUpdate = TRUE;
	ShowSmallMessage(T_Autosave, 2000);
} // end SaveAutosave()

void DestroyAutosave(void)
{ // begin DestroyAutosave()
	char byTemp[256];

	sprintf(byTemp, "%s\\Data\\Autosave.sav", _AS->pbyProgramPath);
	remove(byTemp);
	sprintf(byTemp, "%s\\Data\\Autosave.inf", _AS->pbyProgramPath);
	remove(byTemp);
} // end DestroyAutosave()

void ShowSmallMessage(char *pbyText, long lShowTime)
{ // begin ShowSmallMessage()
	strcpy(bySmallMessageNewText, pbyText);
	lSmallMessageShowTime = lShowTime;
	bSmallMessageShowText = bSmallMessageChangeText = TRUE;
} // end ShowSmallMessage()

void DisplaySmallMessage(AS_WINDOW *pWindow)
{ // begin DisplaySmallMessage()
	if(fSmallMessageBlend <= 0.0f)
		return; // Show no message!
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glColor4f(1.0f, 1.0f, 1.0f, fSmallMessageBlend);
	pWindow->PrintAnimated(10, 450, bySmallMessageText, 0, fSmallMessageBlend, fFontAni, 0);
} // end DisplaySmallMessage()

void CheckSmallMessage(void)
{ // begin CheckSmallMessage()
	if(bSmallMessageChangeText)
	{ // Change to the next text:
		fSmallMessageBlend -= (float) g_lDeltatime/300;
		if(fSmallMessageBlend <= 0.0f)
		{ // Show the new text:
			fSmallMessageBlend = 0.0f;
			lSmallMessageTimer = g_lNow;
			bSmallMessageChangeText = FALSE;
			strcpy(bySmallMessageText, bySmallMessageNewText);
		}
		return;
	}
	if(bSmallMessageShowText)
	{ // Blend in/show the text:
		if(fSmallMessageBlend != 1.0f)
		{
			fSmallMessageBlend += (float) g_lDeltatime/((float) (fSmallMessageBlend+0.01f)*4000);
			if(fSmallMessageBlend >= 1.0f)
				fSmallMessageBlend = 1.0f;
		}
		if(g_lNow-lSmallMessageTimer >= lSmallMessageShowTime)
		{ // Time out, disable the text:
			bSmallMessageShowText = FALSE;
		}
	}
	else
	{ // Blend out the text:
		fSmallMessageBlend -= (float) g_lDeltatime/5000;
		if(fSmallMessageBlend <= 0.0f)
		{
			fSmallMessageBlend = 0.0f;
		}
	}
} // end CheckSmallMessage()
#include "AS_Engine.h"

// Static member variables
HWND AS_PROGRESS_WINDOW::m_hWndProgressBar = 0;
HWND AS_PROGRESS_WINDOW::m_hWndStatic = 0;
HWND AS_PROGRESS_WINDOW::m_hWndStatic2 = 0;


AS_PROGRESS_WINDOW::AS_PROGRESS_WINDOW()
{ // bwgin AS_PROGRESS_WINDOW::AS_PROGRESS_WINDOW()
	m_hWndProgress = 0;
} // end AS_PROGRESS_WINDOW::AS_PROGRESS_WINDOW()

AS_PROGRESS_WINDOW::~AS_PROGRESS_WINDOW()
{ // begin AS_PROGRESS_WINDOW::~AS_PROGRESS_WINDOW()()
	// Destroy the progress window
	if (m_hWndProgress)
	{
		// Destroy the static control's font:
		DeleteObject((HFONT) SendMessage(m_hWndStatic, WM_GETFONT, 0, 0));

		// Destroy the progress window:
		DestroyWindow(m_hWndProgress);
		UnregisterClass("ProgressWindowClass", _AS->GetInstance());
	}
} // end AS_PROGRESS_WINDOW::~AS_PROGRESS_WINDOW()

bool AS_PROGRESS_WINDOW::CreateProgressWindow(PSTR pszTitle)
{ // begin AS_PROGRESS_WINDOW::CreateProgressWindow()
	// Create the progress window
	WNDCLASSEX wcex;    // Window class structure
	HFONT hFont;
	
	// Register the window class
	wcex.cbSize			= sizeof(WNDCLASSEX); 
	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC) ProgressWndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= _AS->GetInstance();
	wcex.hIcon			= NULL;
	wcex.hCursor		= NULL;
	wcex.hbrBackground	= (HBRUSH) GetSysColorBrush(COLOR_MENU);
	wcex.lpszMenuName	= NULL;
	wcex.lpszClassName	= "ProgressWindowClass";
	wcex.hIconSm		= NULL;

	if(!RegisterClassEx(&wcex))
		return false;

	// Create the window and center it on the screen
	m_hWndProgress = CreateWindowEx(WS_EX_TOOLWINDOW, "ProgressWindowClass", 
		pszTitle, WS_POPUP | WS_CLIPCHILDREN | WS_CAPTION, 
		GetSystemMetrics(SM_CXSCREEN) / 2 - 150, 
		GetSystemMetrics(SM_CYSCREEN) / 2 - 55, 
		300, 110, NULL, NULL, _AS->GetInstance(), NULL);

	if(!m_hWndProgress)
		return false;

	// Init the common controls libary
	InitCommonControls();

	// Create the progress bar control
	m_hWndProgressBar = CreateWindowEx(0, PROGRESS_CLASS, (LPSTR) NULL, 
									   WS_CHILD | WS_VISIBLE | PBS_SMOOTH, 10, 10, 275, 22,
									   m_hWndProgress, (HMENU) 0, _AS->GetInstance(), NULL);

	if(!m_hWndProgressBar)
		return false;

	// Set range to 0 - 100
	SendMessage(m_hWndProgressBar, PBM_SETRANGE, 0, MAKELPARAM(0, 100));

	// Create the static control
	m_hWndStatic = CreateWindow("STATIC", (LPSTR) 0, SS_CENTER |
								WS_VISIBLE | WS_CHILD, 10, 42, 275, 20, m_hWndProgress,
								(HMENU) 0, _AS->GetInstance(), NULL);

	if(!m_hWndStatic)
		return false;

	// Set the static control's font
	hFont = CreateFont(-11 , 0, 0, 0, FW_NORMAL,
					   0, 0, 0, 0, 0, 0, 0, 0, "MS Sans Serif");
	SendMessage(m_hWndStatic, WM_SETFONT, (WPARAM) hFont, MAKELPARAM(FALSE, 0));

	// Create the static control
	m_hWndStatic2 = CreateWindow("STATIC", (LPSTR) 0, SS_CENTER |
								 WS_VISIBLE | WS_CHILD, 5, 62, 275, 20, m_hWndProgress,
								 (HMENU) 0, _AS->GetInstance(), NULL);

	if(!m_hWndStatic2)
		return false;

	// Set the static control's font
	hFont = CreateFont(-11 , 0, 0, 0, FW_NORMAL,
					   0, 0, 0, 0, 0, 0, 0, 0, "MS Sans Serif");
	SendMessage(m_hWndStatic2, WM_SETFONT, (WPARAM) hFont, MAKELPARAM(FALSE, 0));
	
	// Show the window
	ShowWindow(m_hWndProgress, SW_SHOW);
	UpdateWindow(m_hWndProgress);

	return true;
} //  end AS_PROGRESS_WINDOW::CreateProgressWindow()

void AS_PROGRESS_WINDOW::SetTask(PSTR pszTaskDescription, ...)
{ // begin AS_PROGRESS_WINDOW::SetTask()
	// Change the progress window task
	char byText[1000];
	va_list	list;

	if(m_hWndProgressBar)
	{
		va_start(list, pszTaskDescription);
			vsprintf(byText, pszTaskDescription, list);
		va_end(list);
		SetWindowText(m_hWndStatic, byText);
	}
} // end AS_PROGRESS_WINDOW::SetTask()

void AS_PROGRESS_WINDOW::SetSubTask(PSTR pszTaskDescription, ...)
{ // begin AS_PROGRESS_WINDOW::SetSubTask()
	// Change the progress window sub task
	char byText[1000];
	va_list	list;

	if(m_hWndProgressBar)
	{
		va_start(list, pszTaskDescription);
			vsprintf(byText, pszTaskDescription, list);
		va_end(list);
		SetWindowText(m_hWndStatic2, byText);
	}
} // end AS_PROGRESS_WINDOW::SetSubTask()
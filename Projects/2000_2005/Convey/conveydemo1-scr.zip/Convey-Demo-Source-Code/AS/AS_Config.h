//-----------------------------------------------------------------------------
// File: AS_Config.h
//-----------------------------------------------------------------------------

#ifndef __AS_CONFIG_H__
#define __AS_CONFIG_H__


// Structures: ****************************************************************
typedef struct
{
	int Number;
	DEVMODE *pDevMode;
} DISPLAY_MODE_INFO;
///////////////////////////////////////////////////////////////////////////////

// Classes: *******************************************************************
typedef class AS_CONFIG
{
	public:
		// General:
		BOOL bFirstRun;
		BOOL bError, bSetError;
		BOOL bMouseScroll;
		BOOL bSound;
		BOOL bMusic;
		BOOL bDrawBounding;
		BOOL bFrustumCulling;
		BOOL bShowCulledObjects;
		BOOL bShowFPS;
		BOOL bLog;
		RECT EditorWindow;
		char byLanguage[256];
		BOOL bRotateMove;
		BOOL bBackCamera;
		BOOL bTiltCamera;
		float fMouseSensibility;
		
		// Graphic:
		BOOL bFullScreen;
		BOOL bUseLevelVertexColor;
		BOOL bFastTexturing;
		BOOL bUseMipmaps;
		BOOL bHightRenderQuality;
		DWORD dwMode;
		char byLight; // 0 = none, 1 = flat, 2 = smooth
		short iColorDepthFilter;
		short iWindowWidth, iWindowHeight;
		short iModeIndex; 
		DEVMODE DevMode;
		short iScreenPixels, iScreenSize;

		// Keys:
		short iLeftKey, iRightKey, iUpKey, iDownKey,
			  iShotKey, iThrowKey, iPullKey, iSuicideKey,
			  iJumpKey, iLevelRestartKey, iChangePerspectiveKey,
			  iBackCameraKey, iPauseKey, iStandartViewKey;


		AS_CONFIG(void);
		~AS_CONFIG(void);

		void Check(void);
        HRESULT Load(char *);
	    HRESULT Save(char *);
} AS_CONFIG;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern AS_CONFIG *_ASConfig;
extern DISPLAY_MODE_INFO DisplayModeInfo;
extern BOOL bFirstRunConfigDialog;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern void OpenConfigDialog(HWND);
extern void SetConfigLanguage(void);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_CONFIG_H__
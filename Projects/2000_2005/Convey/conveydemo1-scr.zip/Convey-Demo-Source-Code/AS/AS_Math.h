#ifndef __AS_MATH_H__
#define __AS_MATH_H__


#define EPSILON 0.05f
#define PLANE_BACKSIDE 0x000001
#define PLANE_FRONT    0x000010
#define ON_PLANE       0x000100


typedef class AS_VECTOR
{
	public:
		float x, y, z;

		AS_VECTOR operator + (AS_VECTOR &Vec) { AS_VECTOR t; t.x = x+Vec.x; t.y = y+Vec.y; t.z = z+Vec.z; return t; }
		AS_VECTOR operator - (AS_VECTOR &Vec) { AS_VECTOR t; t.x = x-Vec.x; t.y = y-Vec.y; t.z = z-Vec.z; return t; }
		AS_VECTOR operator * (AS_VECTOR &Vec) { AS_VECTOR t; t.x = x*Vec.x; t.y = y*Vec.y; t.z = z*Vec.z; return t; }
		AS_VECTOR operator / (AS_VECTOR &Vec) { AS_VECTOR t; t.x = x/Vec.x; t.y = y/Vec.y; t.z = z/Vec.z; return t; }

} AS_VECTOR;

// basic vector operations (inlined)
inline float dot(AS_VECTOR &v1, AS_VECTOR &v2)
{
	return (v1.x*v2.x+v1.y*v2.y+v1.z*v2.z);
}

inline void normalizeVector(AS_VECTOR &v)
{
	float len = (float) sqrt(v.x*v.x+v.y*v.y+v.z*v.z);
	
	v.x /= len;
	v.y /= len;
	v.z /= len;
}

inline double lengthOfVector(AS_VECTOR v)
{
	return (sqrt(v.x*v.x+v.y*v.y+v.z*v.z));
}

inline void setLength(AS_VECTOR &v, float l)
{
	float len = (float) sqrt(v.x*v.x+v.y*v.y+v.z*v.z);
	
	v.x *= l/len;
	v.y *= l/len;
	v.z *= l/len;
} 

inline BOOL isZeroVector(AS_VECTOR &v)
{
	if ((v.x == 0.0f) && (v.y == 0.0f) && (v.z == 0.0f))
		return TRUE;

	return FALSE;	
}

inline AS_VECTOR wedge(AS_VECTOR v1, AS_VECTOR v2)
{
	AS_VECTOR result;

	result.x = (v1.y*v2.z)-(v2.y*v1.z);
	result.y = (v1.z*v2.x)-(v2.z*v1.x);
	result.z = (v1.x*v2.y)-(v2.x*v1.y); 	

	return (result);	
}


#endif // __AS_MATH_H__
//-----------------------------------------------------------------------------
// File: AS_Language.cpp
//-----------------------------------------------------------------------------

#include "AS_ENGINE.h"


// Variables: *****************************************************************
char *pbyASText[AS_TEXTS];
char *pbyASMessage[AS_MESSAGES];
short iASLanguages;  // The number of languages
char **pbyASLanguage; // All found languages names
// Here are all pointers to the texts:
char *T_HelpFile,
	 *T_Ok, *T_Cancel, *T_Fullscreen, *T_DisplayMode, *T_Language,
     *T_Help, *T_ShowedColorDepth, *T_Music, *T_Sound, *T_ShowFPS,
	 *T_Log, *T_Lighting, *T_None, *T_Flat, *T_Smooth, *T_FastTexturing,
	 *T_UseMipmaps, *T_MouseScroll_Editor, *T_Credits, *T_Configuration,
	 *T_Homepage, *T_Version_, *T_ProgrammingAndDesign_, *T_Music_,
	 *T_Homepage_, *T_EMail_, *T_ProgramInfo_, *T_Build_, *T_Size_,
	 *T_Select, *T_Brush, *T_Surfaces, *T_Surface, *T_Objects, *T_Selected_, *T_Wall,
	 *T_NoWall, *T_DeactivateField, *T_ClearField, *T_Objects_, *T_Turn_,
	 *T_Top, *T_Floor, *T_Both, *T_Editor, *T_Height, *T_UseLevelVertexColor,
	 *T_Point, *T_Color, *T_General, *T_Graphic, *T_Programming, *T_Terrain,
	 *T_MiddleHeight, *T_GreatestHeight, *T_LowestHeight, *T_CreateANewLevel,
	 *T_AdjustLevel, *T_Level, *T_Field, *T_Name, *T_Width, *T_Depth, *T_Fog, *T_Density,
	 *T_Water, *T_Texture, *T_File, *T_Light, *T_New, *T_Adjust, *T_Load, *T_Unload,
	 *T_Reset, *T_Textures, *T_WaterHeight, *T_HightRenderQuality, *T_MouseSensibility,
     *T_WholeTexture, *T_TexturePos, *T_Steps, *T_Play, *T_Stop, *T_Copy, *T_Move, *T_NextTime,
	 *T_All, *T_Attributes, *T_SetAnimationSteps, *T_CopyTexturePos, *T_Keyword, *T_Quit,
	 *T_Question, *T_SaveSurface, *T_Error, *T_Info, *T_ShutdownError, *T_SaveLevel,
	 *T_LoadLevel, *T_Environment, *T_Active, *T_SkyCube, *T_Sky, *T_Front, *T_Back, *T_Right,
	 *T_Left, *T_Animation, *T_Size, *T_2Sides, *T_Camera, *T_CameraVelocity,
	 *T_SetCameraSteps, *T_Start, *T_End, *T_Alcove, *T_Radioactive, *T_Health, *T_Anchor,
	 *T_ForAll, *T_Normal, *T_Red, *T_Green, *T_Blue, *T_Box, *T_Rotation,
	 *T_BoxNormal, *T_BoxRed, *T_BoxGreen, *T_BoxBlue, *T_ShowBoundingBoxes,
	 *T_FrustumCulling, *T_ShowCulledObjects, *T_HealthObj, *T_LiveObj, *T_PullObj,
	 *T_ThrowObj, *T_ForceObj, *T_WeaponObj, *T_PointObj, *T_GhostObj, *T_Pause,
	 *T_TimeObj, *T_StepObj, *T_SpeedObj, *T_Change, *T_Enter, *T_Leave, *T_Destroy,
	 *T_LevelMissions, *T_CreditsFile, *T_MoreCredits, *T_NoFreeAnchor, *T_NoFreeBox, *T_NoBox,
	 *T_Exit, *T_Author, *T_WingsObj, *T_ShieldObj, *T_TimeLimit, *T_StepsLimit, *T_Missions,
	 *T_LevelComplete, *T_GoToExit, *T_GoToAlcove, *T_FillAllForAllAnchors, *T_FillAllNormalAnchors,
	 *T_FillAllRedAnchors, *T_FillAllGreenAnchors, *T_FillAllBlueAnchors, *T_NoFreeNormalBox,
	 *T_NoFreeRedBox, *T_NoFreeGreenBox, *T_NoFreeBlueBox, *T_DestroyAllNormalBoxes,
	 *T_DestroyAllRedBoxes, *T_DestroyAllGreenBoxes, *T_DestroyAllBlueBoxes, *T_StartTools,
	 *T_Loop, *T_CampaignEditor, *T_LoadCampaign, *T_SaveCampaign, *T_Levels,
	 *T_GetACampaignFilename, *T_GetALevelFilename, *T_GetMusicFilename, *T_SetNumberOfCampaignLevels,
	 *T_Save, *T_CollectPoints, *T_CollectHealth, *T_MainMenu, *T_StartGame, *T_SingleLevel,
	 *T_SelectCampaign, *T_Heavy, *T_FreeCamera, *T_PlayerCamera,  *T_StandartCamera,
	 *T_Jump, *T_ContinueGame, *T_SelectYourID, *T_SelectLevel, *T_Control, *T_RotateMove,
	 *T_BackCamera, *T_TiltCamera, *T_HurryUp, *T_CreateANewPlayerID, *T_Slow, *T_Fast, *T_Air,
	 *T_Acid, *T_Lava, *T_Update, *T_Options, *T_KeysSetup, *T_OtherOptions,
	 *T_Up, *T_Down, *T_Shot, *T_Suicide, *T_LevelRestart, *T_ChangePerspective, *T_StandartConfiguration,
	 *T_PressNewKey, *T_Amplitude, *T_StandartView;

// Pointer to messages:	
char *M_FirstProgramStart, *M_ProgramWasNotSutDownCorrectlyAtLastTime,
	 *M_ProgramEndErrorDetected, *M_ChangeLevelSize, *M_SurfaceIsUsed,
	 *M_SaveSurfaceFailed, *M_TextureIsAlreadyLoaded, *M_TextureIsUsed,
	 *M_WrongKeyword, *M_TheLevelHasNoFilename, *M_TheProgramIsAlreadyRunning,
	 *M_CouldNotInitializeOpenGLGraphic, *M_SaveCurrentLevelQuestion,
	 *M_SaveThisSurfaceUnderThisPathQuestion, *M_TextureWasNotFound,
	 *M_PressAnyKeyToContinue;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
void EnumerateLanguages(void);
void SetLanguage(char *);
void DestroyLanguage(void);
///////////////////////////////////////////////////////////////////////////////


void EnumerateLanguages(void)
{ // begin EnumerateLanguages()
	WIN32_FIND_DATA FindFileData;
    short i;
	char byTemp[256];
	HANDLE Find;
	                   
	_AS->WriteLogMessage("Enumerate languages");
	if(pbyASLanguage)
	{
		for(i = 0; i < iASLanguages; i++)
			free(pbyASLanguage[i]);
		free(pbyASLanguage);
	}
	iASLanguages = 0;
	sprintf(byTemp, "%s%s\\*.*", _AS->pbyProgramPath, _AS->pbyLanguagesFile);
	Find = FindFirstFile(byTemp, &FindFileData);
	for(;;)
	{
		if(FindFileData.cFileName[0] != '.' && FindFileData.dwFileAttributes == FILE_ATTRIBUTE_DIRECTORY)
		{ // We found a dictory:
			iASLanguages++;
			pbyASLanguage = (char **) realloc(pbyASLanguage, sizeof(char **)*iASLanguages);
			pbyASLanguage[iASLanguages-1] = new char[strlen(FindFileData.cFileName)+1];
			strcpy(pbyASLanguage[iASLanguages-1], FindFileData.cFileName);
		}
		if(!FindNextFile(Find, &FindFileData))
			break;
	}
	FindClose(Find);
} // end EnumerateLanguages()

void SetLanguage(char *pbyLanguage)
{ // begin SetLanguage()
    short i;
	char byFile[256], byTemp[256];

	sprintf(byTemp, "Set language to %s", pbyLanguage);
	_AS->WriteLogMessage(byTemp);
	DestroyLanguage();
	sprintf(byFile, "%s%s\\%s\\general.txt", _AS->pbyProgramPath, _AS->pbyLanguagesFile, pbyLanguage);
	GetPrivateProfileString("help", "file", "", byTemp, MAX_PATH, byFile);
	pbyASText[0] = (char *) malloc(strlen(byTemp)+1);
	strcpy(pbyASText[0], byTemp);
	// Load all texts:
	for(i = 1; i < AS_TEXTS; i++)
	{
		sprintf(byTemp, "%d", i-1);
		GetPrivateProfileString("general", byTemp, "", byTemp, MAX_PATH, byFile);
		pbyASText[i] = (char *) malloc(strlen(byTemp)+1);
		strcpy(pbyASText[i], byTemp);
	}
	// Load all messages:
	for(i = 0; i < AS_MESSAGES; i++)
	{
		sprintf(byTemp, "%d", i);
		GetPrivateProfileString("messages", byTemp, "", byTemp, MAX_PATH, byFile);
		pbyASMessage[i] = (char *) malloc(strlen(byTemp)+1);
		strcpy(pbyASMessage[i], byTemp);
	}
	
	#include "AS_LanguageText.h"
	
	// Update the dialogs and so on:
	SetConfigLanguage();
	SetEditorLanguage();
} // end SetLanguage()

void DestroyLanguage(void)
{ // begin DestroyLanguage()
	for(short i = 0; i < AS_TEXTS; i++)
		SAFE_DELETE(pbyASText[i]);
	for(i = 0; i < AS_MESSAGES; i++)
		SAFE_DELETE(pbyASMessage[i]);
} // end DestroyLanguage()
//-----------------------------------------------------------------------------
// File: AS_DXInput.h
//-----------------------------------------------------------------------------

#ifndef __AS_DXINPUT_H__
#define __AS_DXINPUT_H__


// Functions: *****************************************************************
// HRESULT AS_ENGINE::CreateDXInputDevices(HWND, BOOL, BOOL, BOOL, BOOL);
// HRESULT AS_ENGINE::ReadDXInput(HWND);
// void AS_ENGINE::FreeDXInputDevices(void);
extern short ConvertScancodeToASCII(DWORD, USHORT *);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_DXINPUT_H__
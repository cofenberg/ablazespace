//-----------------------------------------------------------------------------
// File: AS_Object.cpp
//-----------------------------------------------------------------------------

#include "AS_Engine.h"


FLOAT3 fTextCoordTemp[3] = {{0.0f, 0.0f}, {1.0f, 0.0f}, {1.0f, 1.0f}};
int iObjectsT = 0;


AS_OBJECT::AS_OBJECT(void)
{ // begin AS_OBJECT::AS_OBJECT()
	memset(this, 0, sizeof(AS_OBJECT));
} // end AS_OBJECT::AS_OBJECT()

AS_OBJECT::~AS_OBJECT(void)
{ // begin AS_OBJECT::~AS_OBJECT()
} // end AS_OBJECT::~AS_OBJECT()

void AS_OBJECT::SetFrameT(short iID)
{ // begin AS_OBJECT::SetFrameT()
	int i;

	for(i = 0; i < Header.iChildren; i++)
		pChild[i]->SetFrameT(iID);
	if(iID < 0 || iID >= Header.iFrames)
		pFrameT = NULL;
	else
		pFrameT = &pFrame[iID];
} // end AS_OBJECT::SetFrameT()

void AS_OBJECT::SetAnimationT(short iID)
{ // begin AS_OBJECT::SetAnimationT()
	int i;

	for(i = 0; i < Header.iChildren; i++)
		pChild[i]->SetAnimationT(iID);
	if(iID < 0 || iID >= Header.iAnimations)
		pAnimationT = NULL;
	else
		pAnimationT = &pAnimation[iID];
} // end AS_OBJECT::SetAnimationT()

void AS_OBJECT::SetAnimationStepT(short iID)
{ // begin AS_OBJECT::SetAnimationStepT()
	int i;

	if(!pAnimationT)
		return;
	for(i = 0; i < Header.iChildren; i++)
		pChild[i]->SetAnimationStepT(iID);
	if(iID < 0 || iID >= pAnimationT->iSteps)
		pAnimationT->pStepT = NULL;
	else
		pAnimationT->pStepT = &pAnimationT->pStep[iID];
} // end AS_OBJECT::SetAnimationStepT()

void AS_OBJECT::SetInterpolateTime(DWORD dwTime)
{ // begin AS_OBJECT::SetInterpolateTime()
	int i;

	for(i = 0; i < Header.iChildren; i++)
		pChild[i]->SetInterpolateTime(dwTime);
	if(!pAnimationT || !pAnimationT->pStepT)
		return;
	pAnimationT->pStepT->dwInterpolateTime = dwTime;
} // end AS_OBJECT::SetInterpolateTime()

void AS_OBJECT::CalculateInterpolations(void)
{ // begin AS_OBJECT::CalculateInterpolations()
	AS_OBJECT_ANIMATION_STEP *pAniStepTemp, *pNextAniStepTemp;
	int i, i2, i3, i4;

	// Precalculate the constant interpolation data:
	for(i3 = 0; i3 < Header.iAnimations; i3++)
	{
		for(i4 = 0; i4 < pAnimation[i3].iSteps; i4++)
		{
			pAniStepTemp = &pAnimation[i3].pStep[i4];
			if(i4 >= pAnimation[i3].iSteps-1)
				pNextAniStepTemp = &pAnimation[i3].pStep[0];
			else
				pNextAniStepTemp = &pAnimation[i3].pStep[i4+1];
			if(!pAniStepTemp->pFrame)
				continue;
			for(i = 0; i < pAniStepTemp->pFrame->iTextureCoords; i++)
				for(i2 = 0; i2 < 2; i2++)
					pAniStepTemp->fTextureCoordIncreasePos[i][i2] = (pNextAniStepTemp->pFrame->fTextureCoord[i][i2]-pAniStepTemp->pFrame->fTextureCoord[i][i2])/pAniStepTemp->dwInterpolateTime;
			for(i2 = 0; i2 < 3; i2++)
			{
				for(i = 0; i < pAniStepTemp->pFrame->iDiffuseColors; i++)
					pAniStepTemp->fDiffuseColorIncreasePos[i][i2] = (pNextAniStepTemp->pFrame->fDiffuseColor[i][i2]-pAniStepTemp->pFrame->fDiffuseColor[i][i2])/pAniStepTemp->dwInterpolateTime;
				for(i = 0; i < pAniStepTemp->pFrame->iNormals; i++)
					pAniStepTemp->fNormalIncreasePos[i][i2] = (pNextAniStepTemp->pFrame->fNormal[i][i2]-pAniStepTemp->pFrame->fNormal[i][i2])/pAniStepTemp->dwInterpolateTime;
				for(i = 0; i < pAniStepTemp->pFrame->iVertices; i++)
					pAniStepTemp->fVertexIncreasePos[i][i2] = (pNextAniStepTemp->pFrame->fVertex[i][i2]-pAniStepTemp->pFrame->fVertex[i][i2])/pAniStepTemp->dwInterpolateTime;
			}
			// Now calculate the matrix:
			for(i2 = 0; i2 < 4; i2++)
				for(i = 0; i < 4; i++)
					pAniStepTemp->MatrixIncrease[i][i2] = (pNextAniStepTemp->pFrame->Matrix[i][i2]-pAniStepTemp->pFrame->Matrix[i][i2])/pAniStepTemp->dwInterpolateTime;
		}
	}
} // end AS_OBJECT::CalculateInterpolations()

void AS_OBJECT::CalculateCurrentFrame(void)
{ // begin AS_OBJECT::CalculateCurrentFrame()
	short i, i2;
	AS_OBJECT_ANIMATION_STEP *pCurrentAniStep;
	AS_OBJECT_ANIMATION_STEP *pNextAniStep;
	AS_OBJECT_FRAME *pFrameTemp;
	
	// Calculates the current frame:
	pCurrentAniStep = pAnimationT->pStepT;
	dwCurrentTime = GetTickCount();
	dwTimeDifference = dwCurrentTime-dwLastTime;
	if(pCurrentAniStep->dwInterpolateTime < dwTimeDifference)
		dwTimeDifference = pCurrentAniStep->dwInterpolateTime;
	if(pCurrentAniStep->dwInterpolateTime == dwTimeDifference)
	{ // Go to the next frame:
		dwTimeDifference = 0;
		dwCurrentTime = dwLastTime = GetTickCount();
		if(pCurrentAniStep->iID >= pAnimationT->iSteps-1)
			pCurrentAniStep = &pAnimationT->pStep[0];
		else
			pCurrentAniStep = &pAnimationT->pStep[pCurrentAniStep->iID+1];
		pAnimationT->pStepT = pCurrentAniStep;
	}
	pFrameTemp = pCurrentAniStep->pFrame;
	CurrentFrame.iFace = pFrameTemp->iFace;
	if(pCurrentAniStep->iID >= pAnimationT->iSteps-1)
		pNextAniStep = &pAnimationT->pStep[0];
	else
		pNextAniStep = &pAnimationT->pStep[pCurrentAniStep->iID+1];
	if(!pCurrentAniStep || !pNextAniStep)
		return;
	if(CurrentFrame.fDiffuseColor)
		for(i2 = 0; i2 < 3; i2++)
			for(i = 0; i < pFrameTemp->iDiffuseColors; i++)
				CurrentFrame.fDiffuseColor[i][i2] = pFrameTemp->fDiffuseColor[i][i2]+(pCurrentAniStep->fDiffuseColorIncreasePos[i][i2]*dwTimeDifference);
	if(CurrentFrame.fVertex)
		for(i2 = 0; i2 < 3; i2++)
			for(i = 0; i < pFrameTemp->iVertices; i++)
				CurrentFrame.fVertex[i][i2] = pFrameTemp->fVertex[i][i2]+(pCurrentAniStep->fVertexIncreasePos[i][i2]*dwTimeDifference);
	if(CurrentFrame.fNormal)
		for(i2 = 0; i2 < 3; i2++)
			for(i = 0; i < pFrameTemp->iNormals; i++)
				CurrentFrame.fNormal[i][i2] = pFrameTemp->fNormal[i][i2]+(pCurrentAniStep->fNormalIncreasePos[i][i2]*dwTimeDifference);
	for(i = 0; i < pFrameTemp->iTextureCoords; i++)
		for(i2 = 0; i2 < 2; i2++)
			CurrentFrame.fTextureCoord[i][i2] = pFrameTemp->fTextureCoord[i][i2]+(pCurrentAniStep->fTextureCoordIncreasePos[i][i2]*dwTimeDifference);
	// Now calculate the current matrix:
	for(i = 0; i < 4; i++)
		for(i2 = 0; i2 < 4; i2++)
			CurrentFrame.Matrix[i][i2] = pFrameTemp->Matrix[i][i2]+(pCurrentAniStep->MatrixIncrease[i][i2]*dwTimeDifference);
} // end AS_OBJECT::CalculateCurrentFrame()

void AS_OBJECT::Draw(BOOL bChildrenToo, BOOL bTextured, BOOL bDrawBounding)
{ // begin AS_OBJECT::Draw()
	SHORT3 *pFaceTemp;
	short i;
	static MATRIX Matrix;
	AS_OBJECT_FRAME *pFrameT;
	
	if(!pAnimationT || !pAnimationT->iSteps)
		return;
	if(!pAnimationT->pStepT)
		pAnimationT->pStepT = &pAnimationT->pStep[0];
	if(bChildrenToo)
		if(Header.bChildrenActive && pChild)
		{
			for(i = 0; i < Header.iChildren; i++)
			{
				if(!pChild[i])
					continue;
				pChild[i]->Draw(bChildrenToo, bTextured, bDrawBounding);
			}
		}
	if(!Header.bActive)
		return;
	if(!pAnimationT->iSteps == 1)
		pFrameT = pAnimationT->pStep[0].pFrame;
	else
	{
		CalculateCurrentFrame();
		pFrameT = &CurrentFrame;
	}
	glGetFloatv(GL_MODELVIEW_MATRIX, Matrix[0]);
	glMultMatrixf(pFrameT->Matrix[0]);
	if(pTemp) // Draw the temp object
		pTemp->Draw(bChildrenToo, bTextured, bDrawBounding);
	if(bDrawBounding)
		DrawBounding();
	glColorPointer(3, GL_FLOAT, 0, pFrameT->fDiffuseColor);
	glVertexPointer(3, GL_FLOAT, 0, pFrameT->fVertex);
	glNormalPointer(GL_FLOAT, 0, pFrameT->fNormal);
	if(!bTextured)
	{
		pFaceTemp = &pFrameT->iFace[0];
		glBegin(GL_TRIANGLES);
			for(i = 0; i < pFrameT->iFaces; i++, pFaceTemp++)
			{
				glArrayElement((*pFaceTemp)[0]);
				glArrayElement((*pFaceTemp)[1]);
				glArrayElement((*pFaceTemp)[2]);
			}
		glEnd();
	}
	else
	{
		pFaceTemp = &pFrameT->iFace[0];
		glBegin(GL_TRIANGLES);
			for(i = 0; i < pFrameT->iFaces; i++, pFaceTemp++)
			{
				glTexCoord2fv(fTextCoordTemp[0]);
				glArrayElement((*pFaceTemp)[0]);
				glTexCoord2fv(fTextCoordTemp[1]);
				glArrayElement((*pFaceTemp)[1]);
				glTexCoord2fv(fTextCoordTemp[2]);
				glArrayElement((*pFaceTemp)[2]);
			}
		glEnd();
	}
	glLoadMatrixf(Matrix[0]);;
} // end AS_OBJECT::Draw()

void AS_OBJECT::DrawBounding(void)
{ // begin AS_OBJECT::DrawBounding()
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	glDisable(GL_CULL_FACE);
	glColor3f(1.0f, 0.0f, 0.0f);
	glColor4f(1.0f, 0.0f, 0.0f, 0.0f);
	glLineWidth(3.f);
	glBegin(GL_QUADS);
		glVertex3f(CurrentFrame.fMin[X],
				   CurrentFrame.fMin[Y],
				   CurrentFrame.fMin[Z]);
		glVertex3f(CurrentFrame.fMin[X],
				   CurrentFrame.fMax[Y],
				   CurrentFrame.fMin[Z]);
		glVertex3f(CurrentFrame.fMax[X],
				   CurrentFrame.fMax[Y],
				   CurrentFrame.fMin[Z]);
		glVertex3f(CurrentFrame.fMax[X],
				   CurrentFrame.fMin[Y],
				   CurrentFrame.fMin[Z]);

		glVertex3f(CurrentFrame.fMin[X],
				   CurrentFrame.fMin[Y],
				   CurrentFrame.fMax[Z]);
		glVertex3f(CurrentFrame.fMin[X],
				   CurrentFrame.fMax[Y],
				   CurrentFrame.fMax[Z]);
		glVertex3f(CurrentFrame.fMax[X],
				   CurrentFrame.fMax[Y],
				   CurrentFrame.fMax[Z]);
		glVertex3f(CurrentFrame.fMax[X],
				   CurrentFrame.fMin[Y],
				   CurrentFrame.fMax[Z]);

		glVertex3f(CurrentFrame.fMin[X],
				   CurrentFrame.fMin[Y],
				   CurrentFrame.fMin[Z]);
		glVertex3f(CurrentFrame.fMin[X],
				   CurrentFrame.fMin[Y],
				   CurrentFrame.fMax[Z]);
		glVertex3f(CurrentFrame.fMax[X],
				   CurrentFrame.fMin[Y],
				   CurrentFrame.fMax[Z]);
		glVertex3f(CurrentFrame.fMax[X],
				   CurrentFrame.fMin[Y],
				   CurrentFrame.fMin[Z]);

		glVertex3f(CurrentFrame.fMin[X],
				   CurrentFrame.fMax[Y],
				   CurrentFrame.fMin[Z]);
		glVertex3f(CurrentFrame.fMin[X],
				   CurrentFrame.fMax[Y],
				   CurrentFrame.fMax[Z]);
		glVertex3f(CurrentFrame.fMax[X],
				   CurrentFrame.fMax[Y],
				   CurrentFrame.fMax[Z]);
		glVertex3f(CurrentFrame.fMax[X],
				   CurrentFrame.fMax[Y],
				   CurrentFrame.fMin[Z]);
	glEnd();
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	glEnable(GL_CULL_FACE);
} // end AS_OBJECT::DrawBounding()

void AS_OBJECT::Destroy(void)
{ // begin AS_OBJECT::Destroy()
	int i, i2;
	AS_OBJECT_FRAME *pFrameT;
	AS_OBJECT_ANIMATION_STEP *pStepT;

	if(pChild)
	{
		for(i = 0; i < Header.iChildren; i++)
		{
			if(!pChild[i])
				continue;
			pChild[i]->Destroy();	
			free(pChild[i]);
		}
		free(pChild);
	}
	if(pAnimation)
	{
		for(i = 0; i < Header.iAnimations; i++)
		{
			pAnimationT = &pAnimation[i];
			for(i2 = 0; i2 < pAnimationT->iSteps; i2++)
			{
				pStepT = &pAnimationT->pStep[i2];
				if(pStepT->fDiffuseColorIncreasePos)
					free(pStepT->fDiffuseColorIncreasePos);
				if(pStepT->fVertexIncreasePos)
					free(pStepT->fVertexIncreasePos);
				if(pStepT->fNormalIncreasePos)
					free(pStepT->fNormalIncreasePos);
				if(pStepT->fTextureCoordIncreasePos)
					free(pStepT->fTextureCoordIncreasePos);
			}
			if(pAnimationT->pStep)
				free(pAnimationT->pStep);
		}
		free(pAnimation);
	}
	if(pFrame)
	{
		for(i = 0; i < Header.iFrames; i++)
		{
			pFrameT = &pFrame[i];
			if(pFrameT->fDiffuseColor)
				free(pFrameT->fDiffuseColor);
			if(pFrameT->fVertex)
				free(pFrameT->fVertex);
			if(pFrameT->fNormal)
				free(pFrameT->fNormal);
			if(pFrameT->fTextureCoord)
				free(pFrameT->fTextureCoord);
			if(pFrameT->iFace)
				free(pFrameT->iFace);
		}
		free(pFrame);
	}
} // end AS_OBJECT::Destroy()

HRESULT AS_OBJECT::Load(char *pbyFilenameT)
{ // begin AS_OBJECT::Load()
	FILE *fp;

	if(!pbyFilenameT)
		return 1;
	fp = fopen(pbyFilenameT, "rb");
	if(!fp)
		return 1;
	strcpy(byFilename, pbyFilenameT);
	iObjectsT = LoadPart(fp); // Load now the object
	fclose(fp);
	SetupAnimationData(TRUE);
	SetFrameT(0);
	SetAnimationT(0);
	SetAnimationStepT(0);
	return iObjectsT;
} // end AS_OBJECT::Load()

HRESULT AS_OBJECT::LoadPart(FILE *fp)
{ // begin AS_OBJECT::LoadPart()
	int i, i2, i3;

	// Read the header:
	fread(&Header, sizeof(AS_OBJECT_HEADER), 1, fp);
	iID = iObjectsT;
	// Read the main matrix:
	fread(&Matrix, sizeof(MATRIX), 1, fp);
	// Read the object:
	if(Header.iFrames)
	{
		// Read the frames:
		pFrame = new AS_OBJECT_FRAME[Header.iFrames];
		memset(pFrame, 0, sizeof(AS_OBJECT_FRAME)*Header.iFrames);
		for(i = 0; i < Header.iFrames; i++)
		{
			pFrameT = &pFrame[i];
			// Name:
			fread(&pFrameT->byName, sizeof(char)*256, 1, fp);
			// ID:
			pFrameT->iID = i;
			// Transformation matrix:
			fread(&pFrameT->Matrix, sizeof(MATRIX), 1, fp);
			// Diffuse colors:
			if(Header.bUseVertexColorData)
			{
				fread(&pFrameT->iDiffuseColors, sizeof(short), 1, fp);
				pFrameT->fDiffuseColor = new FLOAT3[pFrameT->iDiffuseColors];
				for(i2 = 0; i2 < pFrameT->iDiffuseColors; i2++)
					fread(&pFrameT->fDiffuseColor[i2], sizeof(FLOAT3), 1, fp);
			}
			// Vertices:
			fread(&pFrameT->iVertices, sizeof(short), 1, fp);
			pFrameT->fVertex = new FLOAT3[pFrameT->iVertices];
			for(i2 = 0; i2 < pFrameT->iVertices; i2++)
			{
				fread(&pFrameT->fVertex[i2], sizeof(FLOAT3), 1, fp);
				for(i3 = 0; i3 < 3; i3++)
				{
					// Max:
					if(pFrameT->fVertex[i2][i3] > pFrameT->fMax[i3])
						pFrameT->fMax[i3] = pFrameT->fVertex[i2][i3];
					// Min:
					if(pFrameT->fVertex[i2][i3] < pFrameT->fMin[i3])
						pFrameT->fMin[i3] = pFrameT->fVertex[i2][i3];
				}
			}
			// Middle bounding size:
			for(i3 = 0; i3 < 3; i3++)
				if(pFrameT->fMin[i3] > 0.0f)
				{
					if(pFrameT->fMax[i3] > 0.0f)
						pFrameT->fMiddle[i3] = (pFrameT->fMin[i3]+pFrameT->fMax[i3])/2;
					else
						pFrameT->fMiddle[i3] = (pFrameT->fMin[i3]-pFrameT->fMax[i3])/2;
				}
				else
				{
					if(pFrameT->fMax[i3] > 0.0f)
						pFrameT->fMiddle[i3] = (-pFrameT->fMin[i3]+pFrameT->fMax[i3])/2;
					else
						pFrameT->fMiddle[i3] = (-pFrameT->fMin[i3]-pFrameT->fMax[i3])/2;
				}
			// Texture coords:
			if(Header.bUseVertexTexturePosData)
			{
				fread(&pFrameT->iTextureCoords, sizeof(short), 1, fp);
				pFrameT->fTextureCoord = new FLOAT2[pFrameT->iTextureCoords];
				for(i2 = 0; i2 < pFrameT->iTextureCoords; i2++)
					fread(&pFrameT->fTextureCoord[i2], sizeof(FLOAT2), 1, fp);
			}
			// Faces:
			fread(&pFrameT->iFaces, sizeof(short), 1, fp);
			pFrameT->iFace = new SHORT3[pFrameT->iFaces];
			for(i2 = 0; i2 < pFrameT->iFaces; i2++)
				fread(&pFrameT->iFace[i2], sizeof(SHORT3), 1, fp);
			// Calculate normals:
			pFrameT->iNormals = pFrameT->iFaces;
			pFrameT->fNormal = new FLOAT3[pFrameT->iNormals];
			for(i2 = 0; i2 < pFrameT->iFaces; i2++)
				NormalizeFace(&pFrameT->fNormal[i2], pFrameT->fVertex[pFrameT->iFace[i2][0]],
							  pFrameT->fVertex[pFrameT->iFace[i2][1]],
							  pFrameT->fVertex[pFrameT->iFace[i2][2]]);
		}
		// Read the animations:
		if(Header.iAnimations)
		{
			pAnimation = new AS_OBJECT_ANIMATION[Header.iAnimations];
			memset(pAnimation, 0, sizeof(AS_OBJECT_ANIMATION)*Header.iAnimations);
			for(i = 0; i < Header.iAnimations; i++)
			{
				pAnimationT = &pAnimation[i];
				// Name:
				fread(&pAnimationT->byName, sizeof(char)*256, 1, fp);
				// ID:
				pAnimationT->iID = i;
				// Animation steps:
				fread(&pAnimationT->iSteps, sizeof(short), 1, fp);
				// Read the animation steps:
				pAnimationT->pStep = new AS_OBJECT_ANIMATION_STEP[pAnimationT->iSteps];
				memset(pAnimationT->pStep, 0, sizeof(AS_OBJECT_ANIMATION_STEP)*pAnimationT->iSteps);
				for(i2 = 0; i2 < pAnimationT->iSteps; i2++)
				{
					// Interpolation time:
					fread(&pAnimationT->pStep[i2].dwInterpolateTime, sizeof(DWORD), 1, fp);
					// Step ID;
					pAnimationT->pStep[i2].iID = i2;
					// Frame ID:
					fread(&pAnimationT->pStep[i2].iFrameID, sizeof(short), 1, fp);
					pAnimationT->pStep[i2].pFrame = &pFrame[pAnimationT->pStep[i2].iFrameID];
					pAnimationT->pStep[i2].pFrame->iUsed++;
					// Precalculated data:
					pAnimationT->pStep[i2].fDiffuseColorIncreasePos = new FLOAT3[pFrameT->iDiffuseColors];
					pAnimationT->pStep[i2].fVertexIncreasePos = new FLOAT3[pFrameT->iVertices];
					pAnimationT->pStep[i2].fNormalIncreasePos = new FLOAT3[pFrameT->iNormals];
					pAnimationT->pStep[i2].fTextureCoordIncreasePos = new FLOAT2[pFrameT->iTextureCoords];
				}
			}
		}
	}
	// Read now all the children whith their children:
	if(!Header.iChildren)
		return 0;
	pChild = (AS_OBJECT **) malloc(sizeof(AS_OBJECT)*Header.iChildren);
	for(i = 0; i < Header.iChildren; i++)
	{
		pChild[i] = new AS_OBJECT;
		memset(pChild[i], 0, sizeof(AS_OBJECT));
		iObjectsT++;
		pChild[i]->LoadPart(fp);
	}
	return iObjectsT;
} // end AS_OBJECT::LoadPart()

void AS_OBJECT::SetupAnimationData(BOOL bChildrenToo)
{ // begin AS_OBJECT::SetupAnimationData()
	AS_OBJECT_ANIMATION *pTempAnimation;
	AS_OBJECT_ANIMATION_STEP *pTempObjAnimationStep;
	int i, i2;

	if(bChildrenToo)
		for(i = 0; i < Header.iChildren; i++)
			pChild[i]->SetupAnimationData(bChildrenToo);
	// Setup precalculated data:
	for(i2 = 0; i2 < Header.iAnimations; i2++)
	{
		pTempAnimation = &pAnimation[i2];
		for(i = 0; i < pTempAnimation->iSteps; i++)
		{
			pTempObjAnimationStep = &pTempAnimation->pStep[i];
			if(!pTempObjAnimationStep->pFrame)
				continue;
			if(!pTempObjAnimationStep->fDiffuseColorIncreasePos)
				pTempObjAnimationStep->fDiffuseColorIncreasePos = new FLOAT3[pTempObjAnimationStep->pFrame->iDiffuseColors];
			if(!pTempObjAnimationStep->fVertexIncreasePos)
				pTempObjAnimationStep->fVertexIncreasePos = new FLOAT3[pTempObjAnimationStep->pFrame->iVertices];
			if(!pTempObjAnimationStep->fNormalIncreasePos)
				pTempObjAnimationStep->fNormalIncreasePos = new FLOAT3[pTempObjAnimationStep->pFrame->iNormals];
			if(!pTempObjAnimationStep->fTextureCoordIncreasePos)
				pTempObjAnimationStep->fTextureCoordIncreasePos = new FLOAT2[pTempObjAnimationStep->pFrame->iTextureCoords];
		}
	}
	// Setup current frame info:
	if(!Header.iFrames)
		return;
	// Each frame has the same number of elements...
	CurrentFrame.iDiffuseColors = pFrame[0].iDiffuseColors;
	CurrentFrame.iVertices = pFrame[0].iVertices;
	CurrentFrame.iTextureCoords = pFrame[0].iTextureCoords;
	CurrentFrame.iNormals = pFrame[0].iNormals;
	CurrentFrame.iFaces = pFrame[0].iFaces;
	if(!CurrentFrame.fDiffuseColor)
		CurrentFrame.fDiffuseColor = new FLOAT3[CurrentFrame.iDiffuseColors];
	if(!CurrentFrame.fVertex)
		CurrentFrame.fVertex = new FLOAT3[CurrentFrame.iVertices];
	if(!CurrentFrame.fTextureCoord)
		CurrentFrame.fTextureCoord = new FLOAT2[CurrentFrame.iTextureCoords];
	if(!CurrentFrame.fNormal)
		CurrentFrame.fNormal = new FLOAT3[CurrentFrame.iNormals];
	CalculateInterpolations();
} // end AS_OBJECT::SetupAnimationData()
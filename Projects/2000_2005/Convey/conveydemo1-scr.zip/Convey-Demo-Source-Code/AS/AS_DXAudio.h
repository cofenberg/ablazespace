//-----------------------------------------------------------------------------
// File: AS_DXAudio.h
//-----------------------------------------------------------------------------

#ifndef __AS_DXAUDIO_H__
#define __AS_DXAUDIO_H__


// Functions: *****************************************************************
// HRESULT AS_ENGINE::CreateDXAudio(HWND);
// void AS_ENGINE::DestroyDXAudio(void);
// HRESULT AS_ENGINE::LoadMusic(char *);
// HRESULT AS_ENGINE::PlayMusic(HWND);
// void AS_ENGINE::StopMusic(void);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_DXAUDIO_H__
//-----------------------------------------------------------------------------
// File: AS_Config.cpp
//-----------------------------------------------------------------------------

#include "AS_ENGINE.h"


// Definations: ***************************************************************
enum {TAB_CONFIG_GENERAL, TAB_CONFIG_GRAPHIC, TAB_CONFIG_SOUND, TAB_CONFIG_CONTROL};
#define CONFIG_TABS 4
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
AS_CONFIG *_ASConfig;
AS_CONFIG ConfigT;
DISPLAY_MODE_INFO DisplayModeInfo;
HWND hWndConfig;
HWND hWndConfigTab[CONFIG_TABS];
short iCurrentConfigTab;
long g_lTestTime;
BOOL bFirstRunConfigDialog;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
// HRESULT CONFIG::Check(void);
// HRESULT CONFIG::Load(char *);
// HRESULT CONFIG::Save(char *)
void OpenConfigDialog(HWND);
LRESULT CALLBACK ConfigProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK ConfigGeneralProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK ConfigGraphicProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK ConfigSoundProc(HWND, UINT, WPARAM, LPARAM);
void SetupConfigTabs(void);
void SetConfigLanguage(void);
///////////////////////////////////////////////////////////////////////////////


// AS_CONFIG functions: *******************************************************
AS_CONFIG::AS_CONFIG(void)
{ // begin AS_CONFIG::AS_CONFIG()
	memset(this, 0, sizeof(AS_CONFIG));
} // end AS_CONFIG::AS_CONFIG()

AS_CONFIG::~AS_CONFIG(void)
{ // begin AS_CONFIG::~AS_CONFIG()
} // end AS_CONFIG::~AS_CONFIG()

void AS_CONFIG::Check(void)
{ // begin AS_CONFIG::Check()
	// Update the general information:
	if(!DevMode.dmSize)
		DevMode.dmSize = sizeof(DEVMODE);
	iScreenPixels = (short) (DevMode.dmPelsWidth*DevMode.dmPelsHeight);
	iScreenSize = (short) (DevMode.dmPelsWidth*DevMode.dmPelsHeight*(DevMode.dmBitsPerPel/8));
	DevMode.dmFields = DM_BITSPERPEL | DM_PELSWIDTH | DM_PELSHEIGHT;
	// Find the current display mode id:
	for(short i = 0; i < DisplayModeInfo.Number; i++)
	{
		if(DevMode.dmPelsWidth == DisplayModeInfo.pDevMode[i].dmPelsWidth && 
		   DevMode.dmPelsHeight == DisplayModeInfo.pDevMode[i].dmPelsHeight && 	
		   DevMode.dmBitsPerPel == DisplayModeInfo.pDevMode[i].dmBitsPerPel && 
		   DevMode.dmDisplayFrequency == DisplayModeInfo.pDevMode[i].dmDisplayFrequency)
		{
			iModeIndex = i;
			CopyMemory(&DevMode, &DisplayModeInfo.pDevMode[iModeIndex], sizeof(DEVMODE));
			break;
		}
	}
} // end AS_CONFIG::Check()

HRESULT AS_CONFIG::Load(char *pbyFilename)
{ // begin CONFIG::Load()
	char byTemp[256];

	if(!pbyFilename)
		return 1;
	// Load the configurations from the given file:

	// General:
	bFirstRun = GetPrivateProfileInt("General", "firstrun", 1, pbyFilename);
	bError = GetPrivateProfileInt("General", "error", 1, pbyFilename);
	bSound = GetPrivateProfileInt("General", "sound", 1, pbyFilename);
	bMusic = GetPrivateProfileInt("General", "music", 1, pbyFilename);
	bDrawBounding = GetPrivateProfileInt("General", "draw_bounding", 0, pbyFilename);
	bFrustumCulling = GetPrivateProfileInt("General", "frustum_culling", 1, pbyFilename);	
	bShowCulledObjects = GetPrivateProfileInt("General", "show_culled_objects", 0, pbyFilename);	
	bShowFPS = GetPrivateProfileInt("General", "show_fps", 0, pbyFilename);
	bLog = GetPrivateProfileInt("General", "log", 1, pbyFilename);
	bMouseScroll = GetPrivateProfileInt("General", "mouse_scroll", 0, pbyFilename);
	_ASConfig->EditorWindow.left = GetPrivateProfileInt("General", "editor_window_x", 0, pbyFilename);
	_ASConfig->EditorWindow.right = GetPrivateProfileInt("General", "editor_window_width", GetSystemMetrics(SM_CXSCREEN), pbyFilename)+
									_ASConfig->EditorWindow.left;
	_ASConfig->EditorWindow.top = GetPrivateProfileInt("General", "editor_window_x", 0, pbyFilename);
	_ASConfig->EditorWindow.bottom = GetPrivateProfileInt("General", "editor_window_height", GetSystemMetrics(SM_CYSCREEN), pbyFilename)+
									 _ASConfig->EditorWindow.top;
	GetPrivateProfileString("General", "language", "English", byLanguage, MAX_PATH, pbyFilename);
	bRotateMove = GetPrivateProfileInt("General", "rotate_move", 0, pbyFilename);
	bBackCamera = GetPrivateProfileInt("General", "back_camera", 0, pbyFilename);
	bTiltCamera = GetPrivateProfileInt("General", "tilt_camera", 0, pbyFilename);
	GetPrivateProfileString("General", "mouse_sensibility", "1.0f", byTemp, MAX_PATH, pbyFilename);
	fMouseSensibility = (float) atof(byTemp);

	// Graphic:
	bFullScreen = GetPrivateProfileInt("Graphic", "fullscreen", 1, pbyFilename);
	bUseLevelVertexColor = GetPrivateProfileInt("Graphic", "use_level_vertex_color", 1, pbyFilename);
	byLight = GetPrivateProfileInt("Graphic", "light_mode", 2, pbyFilename);
	bFastTexturing = GetPrivateProfileInt("Graphic", "fast_texturing", 0, pbyFilename);
	bUseMipmaps = GetPrivateProfileInt("Graphic", "use_mipmaps", 0, pbyFilename);
	bHightRenderQuality = GetPrivateProfileInt("Graphic", "hight_render_quality", 1, pbyFilename);
	DevMode.dmPelsWidth = GetPrivateProfileInt("Graphic", "width", 640, pbyFilename);
	DevMode.dmPelsHeight = GetPrivateProfileInt("Graphic", "height", 480, pbyFilename);
	DevMode.dmBitsPerPel = GetPrivateProfileInt("Graphic", "colordepth", 16, pbyFilename);
	DevMode.dmDisplayFrequency = GetPrivateProfileInt("Graphic", "refresh_rate", 0, pbyFilename);
	iColorDepthFilter = GetPrivateProfileInt("Graphic", "color_depth_filter", 16, pbyFilename);
	iWindowWidth = GetPrivateProfileInt("Graphic", "window_width", DevMode.dmPelsWidth, pbyFilename);
	iWindowHeight = GetPrivateProfileInt("Graphic", "window_height", DevMode.dmPelsHeight, pbyFilename);

	// Keys:
	iLeftKey = GetPrivateProfileInt("Keys", "left", STANDART_LEFT_KEY, pbyFilename);
	iRightKey = GetPrivateProfileInt("Keys", "right", STANDART_RIGHT_KEY, pbyFilename);
	iUpKey = GetPrivateProfileInt("Keys", "top", STANDART_UP_KEY, pbyFilename);
	iDownKey = GetPrivateProfileInt("Keys", "down", STANDART_DOWN_KEY, pbyFilename);
	iShotKey = GetPrivateProfileInt("Keys", "shot", STANDART_SHOT_KEY, pbyFilename);
	iThrowKey = GetPrivateProfileInt("Keys", "throw", STANDART_THROW_KEY, pbyFilename);
	iPullKey = GetPrivateProfileInt("Keys", "pull", STANDART_PULL_KEY, pbyFilename);
	iSuicideKey = GetPrivateProfileInt("Keys", "suicide", STANDART_SUICIDE_KEY, pbyFilename);
	iJumpKey = GetPrivateProfileInt("Keys", "jump", STANDART_JUMP_KEY, pbyFilename);
	iLevelRestartKey = GetPrivateProfileInt("Keys", "level_restart", STANDART_LEVEL_RESTART_KEY, pbyFilename);
	iChangePerspectiveKey = GetPrivateProfileInt("Keys", "change_perspective", STANDART_CHANGE_PERSPECTIVE_KEY, pbyFilename);
	iBackCameraKey = GetPrivateProfileInt("Keys", "back_camera", STANDART_BACK_CAMERA_KEY, pbyFilename);
	iPauseKey = GetPrivateProfileInt("Keys", "pause", STANDART_PAUSE_KEY, pbyFilename);
	iStandartViewKey = GetPrivateProfileInt("Keys", "standart_view", STANDART_STANDART_VIEW_KEY, pbyFilename);

	Check(); // Update the configurations
	if(iWindowWidth < 100)
		iWindowWidth = 100;
	if(iWindowHeight < 100)
		iWindowHeight = 100;
	return 0;
} // end AS_CONFIG::Load()

HRESULT AS_CONFIG::Save(char *pbyFilename)
{ // begin AS_CONFIG::Save()
	FILE *pFile;

	if(!pbyFilename)
		return 1;
	// Save the current configurations:
	pFile = fopen(pbyFilename, "wt");
	if(!pFile)
		return 1;
	if(iWindowWidth < 100)
		iWindowWidth = 100;
	if(iWindowHeight < 100)
		iWindowHeight = 100;
	
	// General:
	fprintf(pFile, "[General]\n");
    fprintf(pFile, "firstrun=%d\n", bFirstRun);
    fprintf(pFile, "error=%d\n", bError);
    fprintf(pFile, "mouse_scroll=%d\n", bMouseScroll);
    fprintf(pFile, "sound=%d\n", bSound);
    fprintf(pFile, "music=%d\n", bMusic);
    fprintf(pFile, "show_fps=%d\n", bShowFPS);
    fprintf(pFile, "frustum_culling=%d\n", bFrustumCulling);
    fprintf(pFile, "draw_bounding=%d\n", bDrawBounding);
    fprintf(pFile, "show_culled_objects=%d\n", bShowCulledObjects);
    fprintf(pFile, "log=%d\n", bLog);
	fprintf(pFile, "window_width=%d\n", iWindowWidth);
	fprintf(pFile, "window_height=%d\n", iWindowHeight);
	fprintf(pFile, "editor_window_x=%d\n", _ASConfig->EditorWindow.left);
	fprintf(pFile, "editor_window_y=%d\n", _ASConfig->EditorWindow.top);
	fprintf(pFile, "editor_window_widtht=%d\n", _ASConfig->EditorWindow.right-_ASConfig->EditorWindow.left);
	fprintf(pFile, "editor_window_height=%d\n", _ASConfig->EditorWindow.bottom-_ASConfig->EditorWindow.top);
	fprintf(pFile, "language=%s\n", byLanguage);
	fprintf(pFile, "rotate_move=%d\n", bRotateMove);
	fprintf(pFile, "back_camera=%d\n", bBackCamera);
	fprintf(pFile, "tilt_camera=%d\n", bTiltCamera);
	fprintf(pFile, "mouse_sensibility=%f\n", fMouseSensibility);

	// Graphic:
	fprintf(pFile, "\n[Graphic]\n");
    fprintf(pFile, "fullscreen=%d\n", bFullScreen);
    fprintf(pFile, "use_level_vertex_color=%d\n", bUseLevelVertexColor);
    fprintf(pFile, "light_mode=%d\n", byLight);
    fprintf(pFile, "fast_texturing=%d\n", bFastTexturing);
    fprintf(pFile, "use_mipmaps=%d\n", bUseMipmaps);
    fprintf(pFile, "hight_render_quality=%d\n", bHightRenderQuality);	
	fprintf(pFile, "width=%d\n", DevMode.dmPelsWidth);
	fprintf(pFile, "height=%d\n", DevMode.dmPelsHeight);
	fprintf(pFile, "colordepth=%d\n", DevMode.dmBitsPerPel);
	fprintf(pFile, "refresh_rate=%d HZ\n", DevMode.dmDisplayFrequency);
	fprintf(pFile, "color_depth_filter=%d Bit\n", iColorDepthFilter);

	// Keys:
	fprintf(pFile, "\n[Keys]\n");
	fprintf(pFile, "left=%d\n", iLeftKey);
	fprintf(pFile, "right=%d\n", iRightKey);
	fprintf(pFile, "up=%d\n", iUpKey);
	fprintf(pFile, "down=%d\n", iDownKey);
	fprintf(pFile, "shot=%d\n", iShotKey);
	fprintf(pFile, "throw=%d\n", iThrowKey);
	fprintf(pFile, "pull=%d\n", iPullKey);
	fprintf(pFile, "suicide=%d\n", iSuicideKey);
	fprintf(pFile, "jump=%d\n", iJumpKey);
	fprintf(pFile, "level_restart=%d\n", iLevelRestartKey);
	fprintf(pFile, "change_perspective=%d\n", iChangePerspectiveKey);
	fprintf(pFile, "back_camera=%d\n", iBackCameraKey);
	fprintf(pFile, "pause=%d\n", iPauseKey);
	fprintf(pFile, "standart_view=%d\n", iStandartViewKey);

	fclose(pFile);
	return 0;
} // end AS_CONFIG::Save()


// Functions: *****************************************************************
void OpenConfigDialog(HWND hWnd)
{ // begin OpenConfigDialog()
	DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CONFIG), hWnd, (DLGPROC) ConfigProc);
} // begin OpenConfigDialog()

LRESULT CALLBACK ConfigProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin ConfigProc()
	char byTemp[256];
	short i, i2;

	switch(iMessage)
    {
        case WM_INITDIALOG:
			_AS->WriteLogMessage("Open config dialog");
			memcpy(&ConfigT, _ASConfig, sizeof(AS_CONFIG));
			if(!hWndConfig)
				iCurrentConfigTab = -1;
			hWndConfig = hWnd;
			SetConfigLanguage();
			g_lTestTime = GetTickCount();
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_CONFIG_OK:
					if(GetTickCount()-g_lTestTime < 500)
						break; // The user probably hadn't the change to do this selection!
					if(IsDlgButtonChecked(hWndConfigTab[TAB_CONFIG_GRAPHIC], IDC_CONFIG_GRAPHIC_LIGHT_NONE))
						_ASConfig->byLight = 0;
					else
					if(IsDlgButtonChecked(hWndConfigTab[TAB_CONFIG_GRAPHIC], IDC_CONFIG_GRAPHIC_LIGHT_FLAT))
						_ASConfig->byLight = 1;
					else
					if(IsDlgButtonChecked(hWndConfigTab[TAB_CONFIG_GRAPHIC], IDC_CONFIG_GRAPHIC_LIGHT_SMOOTH))
						_ASConfig->byLight = 2;
					EndDialog(hWnd, FALSE);
					hWndConfig = NULL;
					for(i2 = 0; i2 < CONFIG_TABS; i2++)
						hWndConfigTab[i2] = NULL;;
					if(pLevel)
					{
						pLevel->DestroyTexturesOpenGL(hDCEditorShow, hRCEditorShow);
						pLevel->GenTexturesOpenGL(hDCEditorShow, hRCEditorShow);
					}
					// Save the configuration:	
					sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyConfigFile);
					_ASConfig->Save(byTemp);
					_AS->WriteLogMessage("Close config dialog (ok)");
                return TRUE;

				case ID_CONFIG_CANCEL:
					memcpy(_ASConfig, &ConfigT, sizeof(AS_CONFIG));
					EndDialog(hWnd, FALSE);
					hWndConfig = NULL;
					for(i2 = 0; i2 < CONFIG_TABS; i2++)
						hWndConfigTab[i2] = NULL;;
					_AS->WriteLogMessage("Close config dialog (cancel)");
				break;
				
				case ID_CONFIG_QUIT:
					EndDialog(hWnd, FALSE);
					hWndConfig = NULL;
					_AS->SetShutDown(TRUE);
					EndDialog(hWndEditor, FALSE);
				break;

				case IDC_CONFIG_OPENGL:
					DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_OPENGL), hWnd, (DLGPROC) OpenGLInfoProc);
				break;

				case IDC_CONFIG_CREDITS:
					OpenCreditsDialog(hWnd);
				break;

				case IDC_HOMEPAGE:
					ShellExecute(0, "open", "http://ablazespace.exit.de/", 0, 0, SW_SHOW);
				break;

				case IDC_MSPANG_HOMEPAGE:
					ShellExecute(0, "open", "http://www.mspang.de/", 0, 0, SW_SHOW);
				break;

				case IDC_NEHE_HOMEPAGE:
					ShellExecute(0, "open", "http://nehe.gamedev.net/", 0, 0, SW_SHOW);
				break;

				case IDC_BLENDER_HOMEPAGE:
					ShellExecute(0, "open", "http://www.blender.nl/", 0, 0, SW_SHOW);
				break;

				case IDC_CONFIG_HELP:
					OpenHelp();
				break;
            }
            break;

        case WM_NOTIFY: 
			switch(wParam)
			{
				case IDC_CONFIG_TAB:
					i = TabCtrl_GetCurSel(GetDlgItem(hWnd, IDC_CONFIG_TAB));
					if(i == iCurrentConfigTab)
						break; // This tab is already opend
					iCurrentConfigTab = i;
					for(i2 = 0; i2 < CONFIG_TABS; i2++)
						ShowWindow(hWndConfigTab[i2], SW_HIDE);
					UpdateWindow(hWndConfigTab[i]);
					ShowWindow(hWndConfigTab[i], SW_SHOW);
					SetFocus(hWndConfigTab[i]);
					SendMessage(hWndConfigTab[i], WM_INITDIALOG, 0, 0);
				break;
			} 
		break; 

		case WM_CLOSE:
			SendMessage(hWnd, WM_COMMAND, ID_CONFIG_OK, 0);
		break;
    }
    return FALSE;
} // end ConfigProc()

LRESULT CALLBACK ConfigGeneralProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin ConfigGeneralProc()
	short i;
	BOOL bTemp;

	switch(iMessage)
    {
        case WM_INITDIALOG:
			// Texts:
			SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_LOG, T_Log);
  			SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_MOUSE_SCROLL, T_MouseScroll_Editor);
  			SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_SHOW_FPS, T_ShowFPS);
  			SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_LANGUAGE_TEXT, T_Language);
  			SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_SHOW_BOUNDING_BOXES, T_ShowBoundingBoxes);
  			SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_FRUSTUM_CULLING, T_FrustumCulling);
  			SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_SHOW_CULLED_OBJECTS, T_ShowCulledObjects);
  			SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_BACK_CAMERA, T_BackCamera);
  			SetDlgItemText(hWnd, IDC_CONFIG_GENERAL_TILT_CAMERA, T_TiltCamera);
			//
 			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LANGUAGE, CB_RESETCONTENT, 0, 0);
			for(i = 0; i < iASLanguages; i++)
 			{
				SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LANGUAGE, CB_ADDSTRING, 0, (LONG)(LPSTR) pbyASLanguage[i]);
				if(!strcmp(pbyASLanguage[i], _ASConfig->byLanguage))
					SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LANGUAGE, CB_SETCURSEL, i, 0L);
			}
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_SHOW_FPS, BM_SETCHECK, _ASConfig->bShowFPS, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LOG, BM_SETCHECK, _ASConfig->bLog, 0L);
			if(!_AS->bLog)
				EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GENERAL_LOG), FALSE);
			else
				EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GENERAL_LOG), TRUE);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_MOUSE_SCROLL, BM_SETCHECK, _ASConfig->bMouseScroll, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_SHOW_BOUNDING_BOXES, BM_SETCHECK, _ASConfig->bDrawBounding, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_FRUSTUM_CULLING, BM_SETCHECK, _ASConfig->bFrustumCulling, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_SHOW_CULLED_OBJECTS, BM_SETCHECK, _ASConfig->bShowCulledObjects, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_BACK_CAMERA, BM_SETCHECK, _ASConfig->bBackCamera, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_TILT_CAMERA, BM_SETCHECK, _ASConfig->bTiltCamera, 0L);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_CONFIG_GENERAL_SHOW_FPS:
					_ASConfig->bShowFPS = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_SHOW_FPS, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_GENERAL_LOG:
					_ASConfig->bLog = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LOG, BM_GETCHECK, 0, 0L);
					bTemp = _ASConfig->bLog;
					_ASConfig->bLog = TRUE;
					if(!bTemp)
						_AS->WriteLogMessage("Deactivate the log");
					else
						_AS->WriteLogMessage("Activate the log");
					_ASConfig->bLog = bTemp;
				break;

				case IDC_CONFIG_GENERAL_MOUSE_SCROLL:
					_ASConfig->bMouseScroll = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_MOUSE_SCROLL, BM_GETCHECK, 0, 0L);
				break;
	
				case IDC_CONFIG_GENERAL_LANGUAGE:
					i = (short) SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_LANGUAGE, CB_GETCURSEL, 0, 0L);
					if(i == -1)
						break;
					if(!strcmp(_ASConfig->byLanguage, pbyASLanguage[i]))
						break; // This language is already selected
					strcpy(_ASConfig->byLanguage, pbyASLanguage[i]);
					iCurrentConfigTab = -1;
					SetLanguage(_ASConfig->byLanguage);
				break;

				case IDC_CONFIG_GENERAL_SHOW_BOUNDING_BOXES:
					_ASConfig->bDrawBounding = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_SHOW_BOUNDING_BOXES, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_GENERAL_FRUSTUM_CULLING:
					_ASConfig->bFrustumCulling = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_FRUSTUM_CULLING, BM_GETCHECK, 0, 0L);
				break;
				
				case IDC_CONFIG_GENERAL_SHOW_CULLED_OBJECTS:
					_ASConfig->bShowCulledObjects = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_SHOW_CULLED_OBJECTS, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_GENERAL_BACK_CAMERA:
					_ASConfig->bBackCamera = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_BACK_CAMERA, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_GENERAL_TILT_CAMERA:
					_ASConfig->bTiltCamera = SendDlgItemMessage(hWnd, IDC_CONFIG_GENERAL_TILT_CAMERA, BM_GETCHECK, 0, 0L);
				break;
            }
            break;
    }
    return FALSE;
} // end ConfigGeneralProc()

LRESULT CALLBACK ConfigGraphicProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin ConfigGraphicProc()
	short i, i2, i3;
    LPSTR byTemp = new char[MAX_PATH];

	switch(iMessage)
    {
        case WM_INITDIALOG:
			// Texts:
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_LIGHTING, T_Lighting);
  			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_LIGHT_NONE, T_None);
  			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_LIGHT_FLAT, T_Flat);
  			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_LIGHT_SMOOTH, T_Smooth);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_FAST_TEXTURING, T_FastTexturing);
  			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_USE_MIPMAPS, T_UseMipmaps);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_USE_LEVEL_VERTEX_COLOR, T_UseLevelVertexColor);
			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_HIGHT_RENDER_QUALITY, T_HightRenderQuality);
  			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_DISPLAY_MODE, T_DisplayMode);
  			SetDlgItemText(hWnd, IDC_CONFIG_GRAPHIC_FULLSCREEN, T_Fullscreen);
			//
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_FULLSCREEN, BM_SETCHECK, _ASConfig->bFullScreen, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_USE_LEVEL_VERTEX_COLOR, BM_SETCHECK, _ASConfig->bUseLevelVertexColor, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_FAST_TEXTURING, BM_SETCHECK, _ASConfig->bFastTexturing, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_USE_MIPMAPS, BM_SETCHECK, _ASConfig->bUseMipmaps, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_HIGHT_RENDER_QUALITY, BM_SETCHECK, _ASConfig->bHightRenderQuality, 0L);
			if(!_ASConfig->bHightRenderQuality)
				EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_USE_LEVEL_VERTEX_COLOR), FALSE);
			else
				EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_USE_LEVEL_VERTEX_COLOR), TRUE);
			switch(_ASConfig->byLight)
			{
				case 0: CheckRadioButton(hWnd, IDC_CONFIG_GRAPHIC_LIGHT_NONE, IDC_CONFIG_GRAPHIC_LIGHT_SMOOTH, IDC_CONFIG_GRAPHIC_LIGHT_NONE); break;
				case 1: CheckRadioButton(hWnd, IDC_CONFIG_GRAPHIC_LIGHT_NONE, IDC_CONFIG_GRAPHIC_LIGHT_SMOOTH, IDC_CONFIG_GRAPHIC_LIGHT_FLAT); break;
				case 2: CheckRadioButton(hWnd, IDC_CONFIG_GRAPHIC_LIGHT_NONE, IDC_CONFIG_GRAPHIC_LIGHT_SMOOTH, IDC_CONFIG_GRAPHIC_LIGHT_SMOOTH); break;
			}	
 			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MODES, CB_RESETCONTENT, 0, 0);
			wsprintf(byTemp, "All");
			// Put in the new entries:
			for(i = 0, i2 = 0; i < DisplayModeInfo.Number-1; i++)
			{
				if(_ASConfig->iColorDepthFilter)
				{
					if(DisplayModeInfo.pDevMode[i].dmBitsPerPel != (unsigned char) _ASConfig->iColorDepthFilter)
						continue;
				}
				wsprintf(byTemp, "%dx%dx%d  %d HZ", 
						DisplayModeInfo.pDevMode[i].dmPelsWidth, 
						DisplayModeInfo.pDevMode[i].dmPelsHeight, 
						DisplayModeInfo.pDevMode[i].dmBitsPerPel, 
						DisplayModeInfo.pDevMode[i].dmDisplayFrequency);
     			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MODES, CB_ADDSTRING, 0, (LONG)(LPSTR) byTemp);
     			SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MODES, CB_SETITEMDATA, i2, i);
				i2++;
			}
			if(_ASConfig->iColorDepthFilter)
			{
				if(DisplayModeInfo.pDevMode[_ASConfig->iModeIndex].dmBitsPerPel == (unsigned char) _ASConfig->iColorDepthFilter)
				{			
					for(i = 0; i < i2; i++)
					{
						i3 = (short) SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MODES, CB_GETITEMDATA, i, 0);
						if(i3 == _ASConfig->iModeIndex)
							break;
					}
					SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MODES, CB_SETCURSEL, i, 0L);
				}
			}
			else
				SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MODES, CB_SETCURSEL, _ASConfig->iModeIndex, 0L);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {

				case IDC_CONFIG_GRAPHIC_FULLSCREEN:
				    _ASConfig->bFullScreen = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_FULLSCREEN, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_GRAPHIC_MODES:
   					i = (short) SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MODES, CB_GETCURSEL, 0, 0L);
					i = (short) SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_MODES, CB_GETITEMDATA, i, 0);
					_ASConfig->iModeIndex = i;                         	
					CopyMemory(&_ASConfig->DevMode, &DisplayModeInfo.pDevMode[_ASConfig->iModeIndex], sizeof(DEVMODE));
				break;

				case IDC_CONFIG_GRAPHIC_USE_LEVEL_VERTEX_COLOR:
					_ASConfig->bUseLevelVertexColor = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_USE_LEVEL_VERTEX_COLOR, BM_GETCHECK, 0, 0L);
					UpdateRenderQuality();
				break;

				case IDC_CONFIG_GRAPHIC_FAST_TEXTURING:
					_ASConfig->bFastTexturing = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_FAST_TEXTURING, BM_GETCHECK, 0, 0L);
					UpdateAllTextures();
				break;

				case IDC_CONFIG_GRAPHIC_USE_MIPMAPS:
					_ASConfig->bUseMipmaps = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_USE_MIPMAPS, BM_GETCHECK, 0, 0L);
					UpdateAllTextures();
				break;

				case IDC_CONFIG_GRAPHIC_HIGHT_RENDER_QUALITY:
					_ASConfig->bHightRenderQuality = SendDlgItemMessage(hWnd, IDC_CONFIG_GRAPHIC_HIGHT_RENDER_QUALITY, BM_GETCHECK, 0, 0L);
					if(!_ASConfig->bHightRenderQuality)
						EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_USE_LEVEL_VERTEX_COLOR), FALSE);
					else
						EnableWindow(GetDlgItem(hWnd, IDC_CONFIG_GRAPHIC_USE_LEVEL_VERTEX_COLOR), TRUE);
					UpdateRenderQuality();
				break;				
            }
            break;
    }
    return FALSE;
} // end ConfigGraphicProc()

LRESULT CALLBACK ConfigSoundProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin ConfigSoundProc()
	switch(iMessage)
    {
        case WM_INITDIALOG:
  			// Texts:
  			SetDlgItemText(hWnd, IDC_CONFIG_SOUND_MUSIC, T_Music);
  			SetDlgItemText(hWnd, IDC_CONFIG_SOUND_SOUND, T_Sound);
			//
			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MUSIC, BM_SETCHECK, _ASConfig->bMusic, 0L);
			SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_SOUND, BM_SETCHECK, _ASConfig->bSound, 0L);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_CONFIG_SOUND_MUSIC:
					_ASConfig->bMusic = SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_MUSIC, BM_GETCHECK, 0, 0L);
				break;

				case IDC_CONFIG_SOUND_SOUND:
					_ASConfig->bSound = SendDlgItemMessage(hWnd, IDC_CONFIG_SOUND_SOUND, BM_GETCHECK, 0, 0L);
				break;
            }
            break;
    }
    return FALSE;
} // end ConfigSoundProc()

LRESULT CALLBACK ConfigControlProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin ConfigControlProc()
	short i;
	
	switch(iMessage)
    {
        case WM_INITDIALOG:
  			// Texts:
  			SetDlgItemText(hWnd, IDC_CONFIG_CONTROL_ROTATE_MOVE, T_RotateMove);
  			SetDlgItemText(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY_T, T_MouseSensibility);
			SetDlgItemText(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY_SLOW, T_Slow);
  			SetDlgItemText(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY_NORMAL, T_Normal);
  			SetDlgItemText(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY_FAST, T_Fast);
			//
			SendDlgItemMessage(hWnd, IDC_CONFIG_CONTROL_ROTATE_MOVE, BM_SETCHECK, _ASConfig->bRotateMove, 0L);

		    SendDlgItemMessage(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY, TBM_SETRANGE, FALSE, MAKELONG(1, 100));
			SendDlgItemMessage(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY, TBM_SETTIC, TRUE, 50);
			SendDlgItemMessage(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY, TBM_SETPOS, TRUE, (long) ((float) _ASConfig->fMouseSensibility*50.0f));
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_CONFIG_CONTROL_ROTATE_MOVE:
					_ASConfig->bRotateMove = SendDlgItemMessage(hWnd, IDC_CONFIG_CONTROL_ROTATE_MOVE, BM_GETCHECK, 0, 0L);
				break;
            }
            break;

        case WM_NOTIFY:
            switch(wParam)
            {
				case IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY:
					i = (short) SendDlgItemMessage(hWnd, IDC_CONFIG_CONTROL_MOUSE_SENSIBILITY, TBM_GETPOS, 0, 0);
					_ASConfig->fMouseSensibility = (float) i/50;
				break;
			}
		break;
    }
    return FALSE;
} // end ConfigControlProc()

void SetupConfigTabs(void)
{ // begin SetupConfigTabs()
	HWND hWndTab;
	TC_ITEM tie; 

	// Setup config tabs:
	hWndTab = GetDlgItem(hWndConfig, IDC_CONFIG_TAB);
	TabCtrl_DeleteAllItems(hWndTab);
	tie.mask = TCIF_TEXT;
	// General:
	tie.pszText	= T_General;
	TabCtrl_InsertItem(hWndTab, TAB_CONFIG_GENERAL, &tie);
	if(hWndConfigTab[TAB_CONFIG_GENERAL])
		DestroyWindow(hWndConfigTab[TAB_CONFIG_GENERAL]);
	hWndConfigTab[TAB_CONFIG_GENERAL] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CONFIG_GENERAL), hWndTab, (DLGPROC) ConfigGeneralProc, WM_INITDIALOG);
	// Graphic:
	tie.pszText	= T_Graphic;
	TabCtrl_InsertItem(hWndTab, TAB_CONFIG_GRAPHIC, &tie);
	if(hWndConfigTab[TAB_CONFIG_GRAPHIC])
		DestroyWindow(hWndConfigTab[TAB_CONFIG_GRAPHIC]);
	hWndConfigTab[TAB_CONFIG_GRAPHIC] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CONFIG_GRAPHIC), hWndTab, (DLGPROC) ConfigGraphicProc, WM_INITDIALOG);
	// Sound:
	tie.pszText	= T_Sound;
	TabCtrl_InsertItem(hWndTab, TAB_CONFIG_SOUND, &tie);
	if(hWndConfigTab[TAB_CONFIG_SOUND])
		DestroyWindow(hWndConfigTab[TAB_CONFIG_SOUND]);
	hWndConfigTab[TAB_CONFIG_SOUND] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CONFIG_SOUND), hWndTab, (DLGPROC) ConfigSoundProc, WM_INITDIALOG);
	// Control:
	tie.pszText	= T_Control;
	TabCtrl_InsertItem(hWndTab, TAB_CONFIG_CONTROL, &tie);
	if(hWndConfigTab[TAB_CONFIG_CONTROL])
		DestroyWindow(hWndConfigTab[TAB_CONFIG_CONTROL]);
	hWndConfigTab[TAB_CONFIG_CONTROL] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CONFIG_CONTROL), hWndTab, (DLGPROC) ConfigControlProc, WM_INITDIALOG);
	//
	if(iCurrentConfigTab != -1 && iCurrentConfigTab < CONFIG_TABS)
		TabCtrl_SetCurSel(GetDlgItem(hWndConfig, IDC_CONFIG_TAB), iCurrentConfigTab);
	SendMessage(hWndConfig, WM_NOTIFY, IDC_CONFIG_TAB, 0);
	ShowWindow(hWndConfig, _AS->GetCmdShow());
	UpdateWindow(hWndConfig);
} // end SetupConfigTabs()

void SetConfigLanguage(void)
{ // begin SetConfigLanguage()
	if(!hWndConfig)
		return;
	SetWindowText(hWndConfig, T_Configuration);
  	SetDlgItemText(hWndConfig, ID_CONFIG_OK, T_Ok);
  	SetDlgItemText(hWndConfig, ID_CONFIG_CANCEL, T_Cancel);
  	SetDlgItemText(hWndConfig, ID_CONFIG_QUIT, T_Quit);
  	SetDlgItemText(hWndConfig, IDC_CONFIG_HELP, T_Help);
  	SetDlgItemText(hWndConfig, IDC_CONFIG_CREDITS, T_Credits);
  	SetDlgItemText(hWndConfig, IDC_HOMEPAGE, T_Homepage);  	
	SetupConfigTabs();
} // end SetConfigLanguage()
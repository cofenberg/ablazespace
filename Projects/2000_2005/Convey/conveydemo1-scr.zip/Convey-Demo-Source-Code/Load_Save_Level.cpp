//-----------------------------------------------------------------------------
// File: Load_Save_Level.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


void LEVEL::Load(char *pbyFilename)
{ // begin LEVEL::Load()
	FILE *fp;
	short i, i2, i3, iVersion;
	AS_PROGRESS_WINDOW ProgressWindow;

	_AS->WriteLogMessage("Load level: %s", pbyFilename);	
	ProgressWindow.CreateProgressWindow("Loading World");
	ProgressWindow.SetTask("Loading level %s...", pbyFilename);
	ProgressWindow.SetSubTask("Initialize level");
	ProgressWindow.SetProgress(0);

	bCameraAnimation = FALSE;
	Destroy();
	if(!pbyFilename)
		return;
	fp = fopen(pbyFilename, "rb");
	if(!fp)
		return;
	InitMissions();
	// Filename:
	strcpy(byFilename, pbyFilename);
	// Keyword:
	fread(&bKeyword, sizeof(BOOL), 1, fp);
	fread(&byKeyword, sizeof(char)*256, 1, fp);
	// Single level:
	fread(&bSingleLevel, sizeof(BOOL), 1, fp);
	// Level version:
	fread(&iVersion, sizeof(short), 1, fp);
	if(iVersion != LEVEL_VERSION)
	{
		_AS->WriteLogMessage("The level version(%d) is not correct! Couldn't load this level!", iVersion);	
		return;
	}
	// Name:
	fread(&byName, sizeof(char)*256, 1, fp);
	// Autor:
	fread(&byAuthor, sizeof(char)*256, 1, fp);
	// Midi file:
	fread(&bMusic, sizeof(BOOL), 1, fp);
	fread(&byMusicFile, sizeof(char)*256, 1, fp);
	// Size Data:
	fread(&iWidth, sizeof(short), 1, fp);
	fread(&iHeight, sizeof(short), 1, fp);
	fread(&fFieldWidth, sizeof(float), 1, fp);
	fread(&fFieldHeight, sizeof(float), 1, fp);
	fread(&fFieldDepth, sizeof(float), 1, fp);
	Create(iWidth, iHeight, fFieldDepth, fFieldWidth, fFieldHeight);
	// Sky cube:
	fread(&bSkyCube, sizeof(BOOL), 1, fp);
	fread(&fSkyCubeColor, sizeof(FLOAT3), 1, fp);
	fread(&fSkyCubeSize, sizeof(FLOAT3), 1, fp);
	fread(&iSkyCubeSurface, sizeof(short)*6, 1, fp);
	fread(&iSkyCubeSurfaceRotation, sizeof(short)*6, 1, fp);
	fread(&iSkyCubeSurfaceAniStep, sizeof(short)*6, 1, fp);
	// Fog:
	fread(&bFog, sizeof(BOOL), 1, fp);
	fread(&fFogDensity, sizeof(float), 1, fp);
	fread(&fFogColor, sizeof(FLOAT3), 1, fp);
	// Water:
	fread(&bWater, sizeof(BOOL), 1, fp);
	fread(&bWaterAcid, sizeof(BOOL), 1, fp);
	fread(&bWaterLava, sizeof(BOOL), 1, fp);
	fread(&fWaterDensity, sizeof(float), 1, fp);
	fread(&fWaterHeight, sizeof(float), 1, fp);
	fread(&fWaterColor, sizeof(FLOAT3), 1, fp);
	fread(&fWaterAmplitude, sizeof(FLOAT3), 1, fp);
	fread(&fWaterSpeed, sizeof(FLOAT3), 1, fp);
	// Water texture:
	fread(&bWaterSurface, sizeof(BOOL), 1, fp);
	fread(&iWaterSurface, sizeof(short), 1, fp);
	// Water texture repeat:
	fread(&fWaterTextureRepeat, sizeof(FLOAT2), 1, fp);	
	// Box surface:
	fread(&iBoxSurface, sizeof(SHORT2)*6, 1, fp);	
	fread(&byBoxSurfaceRot, sizeof(CHAR2)*6, 1, fp);	
	// Level color:
	fread(&fLevelColor, sizeof(FLOAT3), 1, fp);
	// Start camera:
	fread(&bFreeCamera, sizeof(BOOL), 1, fp);	
	fread(&bPlayerCamera, sizeof(BOOL), 1, fp);	
	fread(&bStandartCamera, sizeof(BOOL), 1, fp);	
	fread(&StartCamera, sizeof(AS_CAMERA), 1, fp);	
	memcpy(_ASCamera, &StartCamera, sizeof(AS_CAMERA));

// Missions:
	fread(&bTimeLimit, sizeof(BOOL), 1, fp);
	fread(&iTimeLimit, sizeof(short), 1, fp);
	fread(&bStepsLimit, sizeof(BOOL), 1, fp);
	fread(&iStepsLimit, sizeof(short), 1, fp);
	fread(&bMissionExit, sizeof(BOOL), 1, fp);
	fread(&bMissionAlcove, sizeof(BOOL), 1, fp);
	fread(&bMissionCollectPoints, sizeof(BOOL), 1, fp);
	fread(&bMissionCollectHealth, sizeof(BOOL), 1, fp);
	fread(&iCollectPoints, sizeof(short), 1, fp);
	fread(&iCollectHealth, sizeof(short), 1, fp);
	// No free anchor:
	fread(&bMissionNoFreeForAllAnchor, sizeof(BOOL), 1, fp);
	fread(&bMissionNoFreeNormalAnchor, sizeof(BOOL), 1, fp);
	fread(&bMissionNoFreeRedAnchor, sizeof(BOOL), 1, fp);
	fread(&bMissionNoFreeGreenAnchor, sizeof(BOOL), 1, fp);
	fread(&bMissionNoFreeBlueAnchor, sizeof(BOOL), 1, fp);
	// No box:
	fread(&bMissionNoFreeNormalBox, sizeof(BOOL), 1, fp);
	fread(&bMissionNoFreeRedBox, sizeof(BOOL), 1, fp);
	fread(&bMissionNoFreeGreenBox, sizeof(BOOL), 1, fp);
	fread(&bMissionNoFreeBlueBox, sizeof(BOOL), 1, fp);
	// No free box:
	fread(&bMissionNoNormalBox, sizeof(BOOL), 1, fp);
	fread(&bMissionNoRedBox, sizeof(BOOL), 1, fp);
	fread(&bMissionNoGreenBox, sizeof(BOOL), 1, fp);
	fread(&bMissionNoBlueBox, sizeof(BOOL), 1, fp);

// Start tools:
	fread(&iToolsLives, sizeof(short), 1, fp);
	fread(&iToolsPoints, sizeof(short), 1, fp);
	fread(&iToolsWeapon, sizeof(short), 1, fp);
	fread(&iToolsPull, sizeof(short), 1, fp);
	fread(&iToolsThrow, sizeof(short), 1, fp);
	fread(&iToolsForce, sizeof(short), 1, fp);
	fread(&iToolsJump, sizeof(short), 1, fp);
	// Unlimited:
	fread(&bUnlimitedWeapon, sizeof(BOOL), 1, fp);
	fread(&bUnlimitedPull, sizeof(BOOL), 1, fp);
	fread(&bUnlimitedThrow, sizeof(BOOL), 1, fp);
	fread(&bUnlimitedForce, sizeof(BOOL), 1, fp);
	fread(&bUnlimitedJump, sizeof(BOOL), 1, fp);
	//
	fread(&bToolsGhost, sizeof(BOOL), 1, fp);
	fread(&bToolsSpeed, sizeof(BOOL), 1, fp);
	fread(&bToolsWing, sizeof(BOOL), 1, fp);
	fread(&bToolsShield, sizeof(BOOL), 1, fp);

	// Surfaces:
	fread(&iSurfaces, sizeof(short), 1, fp);
	pSurface = (SURFACE *) malloc(sizeof(SURFACE)*iSurfaces);
	memset(pSurface, 0, sizeof(SURFACE)*iSurfaces); 
	// Load the surfaces:
	ProgressWindow.SetTask("Loading surfaces");
	for(i = 0; i < iSurfaces; i++)
	{
		ProgressWindow.SetProgress((UINT) (((float) i/iSurfaces)*100));
		// Filename:
		fread(&pSurface[i].byFilename, sizeof(char)*MAX_PATH, 1, fp);
		// Name:
		fread(&pSurface[i].byName, sizeof(char)*256, 1, fp);
		ProgressWindow.SetSubTask("%s", pSurface[i].byName);
		// ID:
		pSurface[i].iID = i;
		// Animation steps:
		fread(&pSurface[i].iAniSteps, sizeof(short), 1, fp);
		pSurface[i].pTexturePos = (TEXTURE_POS *) malloc(sizeof(TEXTURE_POS)*pSurface[i].iAniSteps);
		// Texture filename:
		pSurface[i].byTextureFilename = (char **) malloc(sizeof(char *)*pSurface[i].iAniSteps);
		pSurface[i].iTextureID = (short *) malloc(sizeof(short)*pSurface[i].iAniSteps);
		pSurface[i].pTexture = (AS_TEXTURE **) malloc(sizeof(AS_TEXTURE *)*pSurface[i].iAniSteps);
		for(i2 = 0; i2 < pSurface[i].iAniSteps; i2++)
		{
			pSurface[i].byTextureFilename[i2] = (char *) malloc(sizeof(char)*MAX_PATH);
			fread(pSurface[i].byTextureFilename[i2], sizeof(char)*MAX_PATH, 1, fp);
			// Load the texture:
			LoadTexture(pSurface[i].byTextureFilename[i2]);
			pCurrentTexture->iUsed++;
			pSurface[i].iTextureID[i2] = iCurrentTexture;
			pSurface[i].pTexture[i2] = pCurrentTexture;
		// Texture positions:
			for(i3 = 0; i3 < 4; i3++)
				fread(&pSurface[i].pTexturePos[i2].iPos[i3], sizeof(SHORT2), 1, fp);
			fread(&pSurface[i].pTexturePos[i2].iTimeToNext, sizeof(short), 1, fp);
		}
		pSurface[i].CalculateFloatTexturePos();
		// Attributes:
		fread(&pSurface[i].bAlcove, sizeof(BOOL), 1, fp);
		fread(&pSurface[i].bRadioactive, sizeof(BOOL), 1, fp);
		fread(&pSurface[i].bHealth, sizeof(BOOL), 1, fp);
		fread(&pSurface[i].bExit, sizeof(BOOL), 1, fp);
		fread(&pSurface[i].bAnchor, sizeof(BOOL), 1, fp);
		fread(&pSurface[i].bColorPainter, sizeof(BOOL), 1, fp);
		fread(&pSurface[i].byAnchorType, sizeof(char), 1, fp);
		fread(&pSurface[i].byColorPainterType, sizeof(char), 1, fp);
		// Change:
		fread(&pSurface[i].bChange, sizeof(BOOL), 1, fp);
		fread(&pSurface[i].bChangeState, sizeof(BOOL), 1, fp);
		fread(&pSurface[i].bChangeDestroy, sizeof(BOOL), 1, fp);
		fread(&pSurface[i].iChangeSurface, sizeof(short), 1, fp);
	}
	ProgressWindow.SetTask("Setup level");
	ProgressWindow.SetSubTask(" ");
	ProgressWindow.SetProgress(0);
	lWaterAniTime = g_lNow;
	// Point information:
	fread(fPoint, sizeof(FLOAT3)*iPoints, 1, fp);
	// Color information:
	fread(fColor, sizeof(FLOAT3)*iPoints, 1, fp);
	// Field information:
	for(i = 0; i < iFields; i++)
	{
		// Wall:
		fread(&pField[i].bWall, sizeof(BOOL), 1, fp);
		SetFieldWall(pField[i].iXField, pField[i].iYField, pField[i].bWall, FALSE);
		// Active:
		fread(&pField[i].bActive, sizeof(BOOL), 1, fp);
		// No backface culling:
		fread(&pField[i].bNoBackfaceCulling, sizeof(BOOL), 1, fp);
		// Surface:
		fread(&pField[i].iSurface, sizeof(short)*6, 1, fp);
		fread(&pField[i].iSurfaceRotation, sizeof(short)*6, 1, fp);
		pField[i].bSelected = FALSE;
		for(i2 = 0; i2 < 6; i2++)
		{
			if(pField[i].iSurface[i2] == -1)
				continue;
			pField[i].pSurface[i2] = &pSurface[pField[i].iSurface[i2]];
			if(pField[i].pSurface[i2])
				pField[i].pSurface[i2]->iUsed++;
		}
		for(i2 = 0; i2 < 6; i2++)
		{
			pField[i].dwLastTime[i2] = g_lNow;
			fread(&pField[i].iCurrentAniStep[i2], sizeof(short), 1, fp);
		}
	}
	if(iFields)
	{
		iCurrentField = 0;
		pCurrentField = &pField[iCurrentField];
	}
	if(iTextures)
	{
		iCurrentTexture = 0;
		pCurrentTexture = &pTexture[iCurrentTexture];
	}
	if(iSurfaces)
	{
		iCurrentSurface = 0;
		pCurrentSurface = &pSurface[iCurrentSurface];
	}
	// Camera scripts:
	fread(&iCameraScripts, sizeof(short), 1, fp);
	pCameraScript = (AS_CAMERA_SCRIPT *) malloc(sizeof(AS_CAMERA_SCRIPT)*iCameraScripts);
	for(i = 0; i < iCameraScripts; i++)
	{
		// Name:
		fread(&pCameraScript[i].byName, sizeof(char)*256, 1, fp);
		// Steps:
		fread(&pCameraScript[i].iSteps, sizeof(short), 1, fp);
		pCameraScript[i].pCamera = (AS_CAMERA *) malloc(sizeof(AS_CAMERA)*pCameraScript[i].iSteps);
		// Camera steps:
		for(i2 = 0; i2 < pCameraScript[i].iSteps; i2++)
			fread(&pCameraScript[i].pCamera[i2], sizeof(AS_CAMERA), 1, fp);
	}
	if(iCameraScripts)
	{
		iCurrentCameraScript = 0;
		pCurrentCameraScript = &pCameraScript[iCurrentCameraScript];
	}
	// Start camera:
	fread(&bStartCamera, sizeof(BOOL), 1, fp);
	fread(&iStartCamera, sizeof(short), 1, fp);
	// End camera:
	fread(&bEndCamera, sizeof(BOOL), 1, fp);
	fread(&bEndCameraLoop, sizeof(BOOL), 1, fp);
	fread(&iEndCamera, sizeof(short), 1, fp);
	// Actors:
	// Player
	fread(&PlayerT, sizeof(ACTOR), 1, fp);
	memcpy(pPlayer, &PlayerT, sizeof(ACTOR));
	PlayerInfo.iCheckpointFieldID = pPlayer->iFieldID;
	// Number of active actors:
	fread(&i, sizeof(short), 1, fp);
	// Load the actors:
	memset(&Actor, 0, sizeof(ACTOR)*MAX_ACTORS);
	for(i2 = 0; i2 < i; i2++)
	{
		fread(&ActorT[i2], sizeof(ACTOR), 1, fp);
		memcpy(&Actor[i2], &ActorT[i2], sizeof(ACTOR));
		Actor[i2].iID = i2;
		if(Actor[i2].bDocked)
			Actor[i2].fSize = BOX_DOCKED_SIZE;
		else
			Actor[i2].fSize = BOX_NORMAL_SIZE;
		switch(Actor[i2].byType)
		{
			case ACTOR_BOX_NORMAL:
			case ACTOR_BOX_RED:
			case ACTOR_BOX_GREEN:
			case ACTOR_BOX_BLUE:
				if(!pField[Actor[i2].iFieldID].bActive && !pField[Actor[i2].iFieldID].pBridgeActor)
				{
					pField[Actor[i2].iFieldID].bActive = TRUE;
					pField[Actor[i2].iFieldID].pBridgeActor = &Actor[i2];
					SetNoneFreeBox(&Actor[i2]);
					continue;
				}
				if(pField[Actor[i2].iFieldID].pActor && pField[Actor[i2].iFieldID].pActor->iID != i2)
				{ // There's already a box!!
					Actor[i2].bActive = FALSE;
					continue;
				}
			break;

			case ACTOR_HEALTH_OBJ:
			case ACTOR_LIVE_OBJ:
			case ACTOR_PULL_OBJ:
			case ACTOR_THROW_OBJ:
			case ACTOR_FORCE_OBJ:
			case ACTOR_WEAPON_OBJ:
			case ACTOR_POINT_OBJ:
			case ACTOR_GHOST_OBJ:
			case ACTOR_TIME_OBJ:
			case ACTOR_STEP_OBJ:
			case ACTOR_SPEED_OBJ:
			case ACTOR_WING_OBJ:
			case ACTOR_SHIELD_OBJ:
				Actor[i2].fColor[0] = 1.0f;
				Actor[i2].fColor[1] = 1.0f;
				Actor[i2].fColor[2] = 1.0f;
				if(pLevel->pField[Actor[i2].iFieldID].pObject)
					Actor[i2].bActive = FALSE;
				else
					pLevel->pField[Actor[i2].iFieldID].pObject = &Actor[i2];
			break;
		}
		Actor[i2].dwAniTime = g_lNow;
		CheckActorField(&Actor[i2]);
	}
	//
	fclose(fp);
	if(hWndEditor)
	{
		DestroyTexturesOpenGL(hDCEditorShow, hRCEditorShow);
		GenTexturesOpenGL(hDCEditorShow, hRCEditorShow);
	}
	lTimeLimitTime = g_lNow;
	CalculateFieldNormals();
	CalculateFieldBoundingBoxes();
	UpdateAllActorFields();
	UpdateMissions();
	if(bStandartCamera)
		bPlayerCameraView = FALSE;
	else
		if(bPlayerCamera)
			bPlayerCameraView = TRUE;

// Setup the player information:
	PlayerInfo.iLives += iToolsLives;
	PlayerInfo.iPoints += iToolsPoints;
	PlayerInfo.iWeaponShots += iToolsWeapon;
	if(iToolsWeapon || bUnlimitedWeapon)
		PlayerInfo.bWeapon = TRUE;
	PlayerInfo.iPullBoxes += iToolsPull;
	if(iToolsPull || bUnlimitedPull)
		PlayerInfo.bPullBoxes = TRUE;
	PlayerInfo.iThrowBoxes += iToolsThrow;
	if(iToolsThrow || bUnlimitedThrow)
		PlayerInfo.bThrowBoxes = TRUE;
	PlayerInfo.iForce += iToolsForce;
	if(bUnlimitedForce)
		PlayerInfo.iForce = iWidth+iHeight;
	PlayerInfo.iJump += iToolsJump;
	if(iToolsJump || bUnlimitedJump)
		PlayerInfo.bJump = TRUE;
	if(bToolsGhost)
	{
		PlayerInfo.bGhost = TRUE;
		PlayerInfo.lGhostTime = g_lNow;
	}
	if(bToolsSpeed)
	{
		PlayerInfo.bSpeed = TRUE;
		PlayerInfo.lSpeedTime = g_lNow;
	}
	if(bToolsWing)
	{
		PlayerInfo.bWing = TRUE;
		PlayerInfo.lWingTime = g_lNow;
	}
	if(bToolsShield)
	{
		PlayerInfo.bShield = TRUE;
		PlayerInfo.lShieldTime = g_lNow;
	}
	CheckMissions();
	for(i = 0; i < MAX_ACTORS; i++)
	{
		Actor[i].fLastHeightCheckWorldPos[X] = 
		Actor[i].fLastHeightCheckWorldPos[Y] = -1.0f;
	}
	pPlayer->fLastHeightCheckWorldPos[X] = 
	pPlayer->fLastHeightCheckWorldPos[Y] = -1.0f;
	pCamera->fPos[Z] = 0.0f;
	OktaActor.bActive = FALSE;
	ComputeActorHeight(pPlayer, 0.2f);
	_AS->WriteLogMessage("OK");
	g_lNow = lGameTimer = GetTickCount();
	if(!bFreeCamera)
		bStandartCamera = 0;
	if(!bStandartCamera)
	{
		pCamera->fRot2[X] = -90.0f;
		bPlayerCameraView = TRUE;
	}
} // end LEVEL::Load()

void LEVEL::Save(char *pbyFilename)
{ // begin LEVEL::Save()
	FILE *fp;
	short i, i2, i3, iVersion;

	_AS->WriteLogMessage("Save level: %s", pbyFilename);	
	if(!pbyFilename)
		return;
	remove(pbyFilename);
	fp = fopen(pbyFilename, "wb");
	if(!fp)
		return;
	// Keyword:
	fwrite(&bKeyword, sizeof(BOOL), 1, fp);
	fwrite(&byKeyword, sizeof(char)*256, 1, fp);
	// Single level:
	fwrite(&bSingleLevel, sizeof(BOOL), 1, fp);
	// Level version:
	iVersion = LEVEL_VERSION;
	fwrite(&iVersion, sizeof(short), 1, fp);
	// Name:
	fwrite(&byName, sizeof(char)*256, 1, fp);
	// Autor:
	fwrite(&byAuthor, sizeof(char)*256, 1, fp);
	// Midi file:
	fwrite(&bMusic, sizeof(BOOL), 1, fp);
	fwrite(&byMusicFile, sizeof(char)*256, 1, fp);
	// Size Data:
	fwrite(&iWidth, sizeof(short), 1, fp);
	fwrite(&iHeight, sizeof(short), 1, fp);
	fwrite(&fFieldWidth, sizeof(float), 1, fp);
	fwrite(&fFieldHeight, sizeof(float), 1, fp);
	fwrite(&fFieldDepth, sizeof(float), 1, fp);
	// Sky cube:
	fwrite(&bSkyCube, sizeof(BOOL), 1, fp);
	fwrite(&fSkyCubeColor, sizeof(FLOAT3), 1, fp);
	fwrite(&fSkyCubeSize, sizeof(FLOAT3), 1, fp);
	fwrite(&iSkyCubeSurface, sizeof(short)*6, 1, fp);
	fwrite(&iSkyCubeSurfaceRotation, sizeof(short)*6, 1, fp);
	fwrite(&iSkyCubeSurfaceAniStep, sizeof(short)*6, 1, fp);
	// Fog:
	fwrite(&bFog, sizeof(BOOL), 1, fp);
	fwrite(&fFogDensity, sizeof(float), 1, fp);
	fwrite(&fFogColor, sizeof(FLOAT3), 1, fp);
	// Water:
	fwrite(&bWater, sizeof(BOOL), 1, fp);
	fwrite(&bWaterAcid, sizeof(BOOL), 1, fp);
	fwrite(&bWaterLava, sizeof(BOOL), 1, fp);
	fwrite(&fWaterDensity, sizeof(float), 1, fp);
	fwrite(&fWaterHeight, sizeof(float), 1, fp);
	fwrite(&fWaterColor, sizeof(FLOAT3), 1, fp);
	fwrite(&fWaterAmplitude, sizeof(FLOAT3), 1, fp);
	fwrite(&fWaterSpeed, sizeof(FLOAT3), 1, fp);
	// Water texture:
	fwrite(&bWaterSurface, sizeof(BOOL), 1, fp);
	fwrite(&iWaterSurface, sizeof(short), 1, fp);
	// Water texture repeat:
	fwrite(&fWaterTextureRepeat, sizeof(FLOAT2), 1, fp);	
	// Box surface:
	fwrite(&iBoxSurface, sizeof(SHORT2)*6, 1, fp);	
	fwrite(&byBoxSurfaceRot, sizeof(CHAR2)*6, 1, fp);	
	// Level color:
	fwrite(&fLevelColor, sizeof(FLOAT3), 1, fp);
	// Start camera:
	fwrite(&bFreeCamera, sizeof(BOOL), 1, fp);	
	fwrite(&bPlayerCamera, sizeof(BOOL), 1, fp);	
	fwrite(&bStandartCamera, sizeof(BOOL), 1, fp);	
	memcpy(&StartCamera, _ASCamera, sizeof(AS_CAMERA));
	fwrite(&StartCamera, sizeof(AS_CAMERA), 1, fp);	

// Missions:
	fwrite(&bTimeLimit, sizeof(BOOL), 1, fp);	
	fwrite(&iTimeLimit, sizeof(short), 1, fp);	
	fwrite(&bStepsLimit, sizeof(BOOL), 1, fp);	
	fwrite(&iStepsLimit, sizeof(short), 1, fp);	
	fwrite(&bMissionExit, sizeof(BOOL), 1, fp);
	fwrite(&bMissionAlcove, sizeof(BOOL), 1, fp);
	fwrite(&bMissionCollectPoints, sizeof(BOOL), 1, fp);
	fwrite(&bMissionCollectHealth, sizeof(BOOL), 1, fp);
	fwrite(&iCollectPoints, sizeof(short), 1, fp);
	fwrite(&iCollectHealth, sizeof(short), 1, fp);
	// No free anchor:
	fwrite(&bMissionNoFreeForAllAnchor, sizeof(BOOL), 1, fp);
	fwrite(&bMissionNoFreeNormalAnchor, sizeof(BOOL), 1, fp);
	fwrite(&bMissionNoFreeRedAnchor, sizeof(BOOL), 1, fp);
	fwrite(&bMissionNoFreeGreenAnchor, sizeof(BOOL), 1, fp);
	fwrite(&bMissionNoFreeBlueAnchor, sizeof(BOOL), 1, fp);
	// No box:
	fwrite(&bMissionNoFreeNormalBox, sizeof(BOOL), 1, fp);
	fwrite(&bMissionNoFreeRedBox, sizeof(BOOL), 1, fp);
	fwrite(&bMissionNoFreeGreenBox, sizeof(BOOL), 1, fp);
	fwrite(&bMissionNoFreeBlueBox, sizeof(BOOL), 1, fp);
	// No free box:
	fwrite(&bMissionNoNormalBox, sizeof(BOOL), 1, fp);
	fwrite(&bMissionNoRedBox, sizeof(BOOL), 1, fp);
	fwrite(&bMissionNoGreenBox, sizeof(BOOL), 1, fp);
	fwrite(&bMissionNoBlueBox, sizeof(BOOL), 1, fp);

// Start tools:
	fwrite(&iToolsLives, sizeof(short), 1, fp);
	fwrite(&iToolsPoints, sizeof(short), 1, fp);
	fwrite(&iToolsWeapon, sizeof(short), 1, fp);
	fwrite(&iToolsPull, sizeof(short), 1, fp);
	fwrite(&iToolsThrow, sizeof(short), 1, fp);
	fwrite(&iToolsForce, sizeof(short), 1, fp);
	fwrite(&iToolsJump, sizeof(short), 1, fp);
	// Unlimited:
	fwrite(&bUnlimitedWeapon, sizeof(BOOL), 1, fp);
	fwrite(&bUnlimitedPull, sizeof(BOOL), 1, fp);
	fwrite(&bUnlimitedThrow, sizeof(BOOL), 1, fp);
	fwrite(&bUnlimitedForce, sizeof(BOOL), 1, fp);
	fwrite(&bUnlimitedJump, sizeof(BOOL), 1, fp);
	//
	fwrite(&bToolsGhost, sizeof(BOOL), 1, fp);
	fwrite(&bToolsSpeed, sizeof(BOOL), 1, fp);
	fwrite(&bToolsWing, sizeof(BOOL), 1, fp);
	fwrite(&bToolsShield, sizeof(BOOL), 1, fp);

	// Surfaces:
	fwrite(&iSurfaces, sizeof(short), 1, fp);
	// Save the surfaces:
	for(i = 0; i < iSurfaces; i++)
	{
		// Filename:
		fwrite(&pSurface[i].byFilename, sizeof(char)*MAX_PATH, 1, fp);
		// Name
		fwrite(&pSurface[i].byName, sizeof(char)*256, 1, fp);
		// Animation steps:
		fwrite(&pSurface[i].iAniSteps, sizeof(short), 1, fp);
		// Texture positions:
		for(i2 = 0; i2 < pSurface[i].iAniSteps; i2++)
		{
			// Texture filename:
		char byTemp[256];
		strcpy(byTemp, pSurface[i].byTextureFilename[i2]);
			fwrite(pSurface[i].byTextureFilename[i2], sizeof(char)*MAX_PATH, 1, fp);
			for(i3 = 0; i3 < 4; i3++)
				fwrite(&pSurface[i].pTexturePos[i2].iPos[i3], sizeof(SHORT2), 1, fp);
			fwrite(&pSurface[i].pTexturePos[i2].iTimeToNext, sizeof(short), 1, fp);
		}
		// Attributes:
		fwrite(&pSurface[i].bAlcove, sizeof(BOOL), 1, fp);
		fwrite(&pSurface[i].bRadioactive, sizeof(BOOL), 1, fp);
		fwrite(&pSurface[i].bHealth, sizeof(BOOL), 1, fp);
		fwrite(&pSurface[i].bExit, sizeof(BOOL), 1, fp);
		fwrite(&pSurface[i].bAnchor, sizeof(BOOL), 1, fp);
		fwrite(&pSurface[i].bColorPainter, sizeof(BOOL), 1, fp);
		fwrite(&pSurface[i].byAnchorType, sizeof(char), 1, fp);
		fwrite(&pSurface[i].byColorPainterType, sizeof(char), 1, fp);
		// Change:
		fwrite(&pSurface[i].bChange, sizeof(BOOL), 1, fp);
		fwrite(&pSurface[i].bChangeState, sizeof(BOOL), 1, fp);
		fwrite(&pSurface[i].bChangeDestroy, sizeof(BOOL), 1, fp);
		fwrite(&pSurface[i].iChangeSurface, sizeof(short), 1, fp);
	}
	// Point information:
	fwrite(fPoint, sizeof(FLOAT3)*iPoints, 1, fp);
	// Color information:
	fwrite(fColor, sizeof(FLOAT3)*iPoints, 1, fp);
	// Field information:
	for(i = 0; i < iFields; i++)
	{
		// Wall:
		i2 = pField[i].bWall;
		if(pField[i].pActor)
			pField[i].bWall = 0;
		fwrite(&pField[i].bWall, sizeof(BOOL), 1, fp);
		pField[i].bWall = i2;
		// Active:
		i2 = pField[i].bActive;
		if(pField[i].pBridgeActor)
			pField[i].bActive = FALSE;
		fwrite(&pField[i].bActive, sizeof(BOOL), 1, fp);
		pField[i].bActive = i2;
		// No backface culling:
		fwrite(&pField[i].bNoBackfaceCulling, sizeof(BOOL), 1, fp);
		// Surface:
		fwrite(&pField[i].iSurface, sizeof(short)*6, 1, fp);
		fwrite(&pField[i].iSurfaceRotation, sizeof(short)*6, 1, fp);
		for(i2 = 0; i2 < 6; i2++)
			fwrite(&pField[i].iCurrentAniStep[i2], sizeof(short), 1, fp);
	}
	// Camera scripts:
	fwrite(&iCameraScripts, sizeof(short), 1, fp);
	for(i = 0; i < iCameraScripts; i++)
	{
		// Name:
		fwrite(&pCameraScript[i].byName, sizeof(char)*256, 1, fp);
		// Steps:
		fwrite(&pCameraScript[i].iSteps, sizeof(short), 1, fp);
		// Camera steps:
		for(i2 = 0; i2 < pCameraScript[i].iSteps; i2++)
			fwrite(&pCameraScript[i].pCamera[i2], sizeof(AS_CAMERA), 1, fp);
	}
	// Start camera:
	fwrite(&bStartCamera, sizeof(BOOL), 1, fp);
	fwrite(&iStartCamera, sizeof(short), 1, fp);
	// End camera:
	fwrite(&bEndCamera, sizeof(BOOL), 1, fp);
	fwrite(&bEndCameraLoop, sizeof(BOOL), 1, fp);
	fwrite(&iEndCamera, sizeof(short), 1, fp);
	// Actors:
	// Player
	memcpy(&PlayerT, pPlayer, sizeof(ACTOR));
	fwrite(&PlayerT, sizeof(ACTOR), 1, fp);
	// All other actors:
	// Sort them to find out which actors we have to save: (makes the levels smaller)
	i = SortActors();
	memcpy(&ActorT, Actor, sizeof(ACTOR)*MAX_ACTORS);
	// Number of active actors:
	fwrite(&i, sizeof(short), 1, fp);
	// Save the actors:
	for(i2 = 0; i2 < i; i2++)
		fwrite(&Actor[i2], sizeof(ACTOR), 1, fp);
	//
	fclose(fp);
	// Filename:
	strcpy(byFilename, pbyFilename);
	_AS->WriteLogMessage("OK");
} // end LEVEL::Save()
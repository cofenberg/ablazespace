//-----------------------------------------------------------------------------
// File: Level.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Definitions: ***************************************************************
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
AS_CAMERA LevelTempCamera;
float fPlayerTempZPos;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
void CreateLevel(LEVEL **);
void DestroyLevel(LEVEL **);
///////////////////////////////////////////////////////////////////////////////


// LEVEL functions: ***********************************************************
LEVEL::LEVEL(void)
{ // begin LEVEL::LEVEL()
	memset(this, 0, sizeof(LEVEL));
	iWidth = 11; 
	iHeight = 11;
	fFieldWidth = 1.0f;
	fFieldHeight = 1.0f;
	fFieldDepth = -2.0f;
	strcpy(byName, "Noname");
	fSkyCubeColor[0] = 1.0f;
	fSkyCubeColor[1] = 1.0f;
	fSkyCubeColor[2] = 1.0f;
	fSkyCubeSize[0] = 1000.0f;
	fSkyCubeSize[1] = 1000.0f;
	fSkyCubeSize[2] = 1000.0f;
	fFogDensity = 0.05f;
	fFogColor[R] = 0.5f;
	fFogColor[G] = 0.5f;
	fFogColor[B] = 0.5f;
	bSingleLevel = TRUE;
	fWaterDensity = 0.95f;
	fWaterColor[B] = 1.0f;
	fWaterHeight = STANDART_LEVEL_Z_POS-0.3f;
	fWaterTextureRepeat[X] = 1.0f;
	fWaterTextureRepeat[Y] = 1.0f;
	fLevelColor[R] = 1.0f;
	fLevelColor[G] = 1.0f;
	fLevelColor[B] = 1.0f;
	bFreeCamera = TRUE;
	bPlayerCamera = TRUE;
	bStandartCamera = TRUE;
} // end LEVEL::LEVEL()

LEVEL::~LEVEL(void)
{ // begin LEVEL::~LEVEL()
} // end LEVEL::~LEVEL()

void LEVEL::GenTexturesOpenGL(HDC hDC, HGLRC hRC)
{ // begin LEVEL::GenTextures()
	AS_PROGRESS_WINDOW ProgressWindow;

	ProgressWindow.CreateProgressWindow("Loading World");
	ProgressWindow.SetTask("Generate OpenGL level textures...");
	ProgressWindow.SetProgress(0);
	if(!wglMakeCurrent(hDC, hRC))
		return;
	for(short i = 0; i < iTextures; i++)
	{
		ProgressWindow.SetSubTask("%s", pTexture[i].byFilename);
		ProgressWindow.SetProgress((UINT) (((float) i/iTextures)*100));
		// First delete the old textures:
		if(pTexture[i].iOpenGLID > 2)
			glDeleteTextures(1, &pTexture[i].iOpenGLID);
		// Now generate the new:
		glGenTextures(1, &pTexture[i].iOpenGLID);
		glBindTexture(GL_TEXTURE_2D, pTexture[i].iOpenGLID);
		if(_ASConfig->bUseMipmaps)
		{
			if(_ASConfig->bFastTexturing)
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST_MIPMAP_NEAREST);
				gluBuild2DMipmaps(GL_TEXTURE_2D, 3, pTexture[i].iWidth, pTexture[i].iHeight, GL_RGB, GL_UNSIGNED_BYTE, pTexture[i].pbyData);
			}
			else
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);
				gluBuild2DMipmaps(GL_TEXTURE_2D, 3, pTexture[i].iWidth, pTexture[i].iHeight, GL_RGB, GL_UNSIGNED_BYTE, pTexture[i].pbyData);
			}
		}
		else
		{
			if(_ASConfig->bFastTexturing)
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
				glTexImage2D(GL_TEXTURE_2D, 0, 3, pTexture[i].iWidth, pTexture[i].iHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, pTexture[i].pbyData);
			}
			else
			{
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
				glTexImage2D(GL_TEXTURE_2D, 0, 3, pTexture[i].iWidth, pTexture[i].iHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, pTexture[i].pbyData);
			}
		}
	}
} // end LEVEL::GenTextures()

void LEVEL::DestroyTexturesOpenGL(HDC hDC, HGLRC hRC)
{ // begin LEVEL::DestroyTexturesOpenGL()
	if(!hDC || !hRC || !wglMakeCurrent(hDC, hRC))
		return;
	AS_PROGRESS_WINDOW ProgressWindow;

	ProgressWindow.CreateProgressWindow("Update World");
	ProgressWindow.SetTask("Delete OpenGL level textures...");
	ProgressWindow.SetProgress(0);
	for(short i = 0; i < iTextures; i++)
	{
		ProgressWindow.SetSubTask("%s", pTexture[i].byFilename);
		ProgressWindow.SetProgress((UINT) (((float) i/iTextures)*100));
		glDeleteTextures(1, &pTexture[i].iOpenGLID);
	}
} // end LEVEL::DestroyTexturesOpenGL()

HRESULT LEVEL::CreateSurface(void)
{ // begin LEVEL::CreateSurface()
	FIELD *pFieldT;
	short i, i2;

	iSurfaces++;
	pSurface = (SURFACE *) realloc(pSurface, sizeof(SURFACE)*iSurfaces);
	iCurrentSurface = iSurfaces-1;
	pCurrentSurface = &pSurface[iCurrentSurface];
	memset(pCurrentSurface, 0, sizeof(SURFACE));
	pCurrentSurface->iID = iSurfaces-1;
	pCurrentSurface->iAniSteps = 1;
	pCurrentSurface->pTexturePos = (TEXTURE_POS *) malloc(sizeof(TEXTURE_POS)*pCurrentSurface->iAniSteps);
	pCurrentSurface->byTextureFilename = (char **) malloc(sizeof(char *)*pCurrentSurface->iAniSteps);
	pCurrentSurface->iTextureID = (short *) malloc(sizeof(short)*pCurrentSurface->iAniSteps);
	pCurrentSurface->pTexture = (AS_TEXTURE **) malloc(sizeof(AS_TEXTURE)*pCurrentSurface->iAniSteps);
	for(i = 0; i < pCurrentSurface->iAniSteps; i++)
	{
		pCurrentSurface->byTextureFilename[i] = (char *) malloc(sizeof(char)*MAX_PATH);
		pCurrentSurface->iTextureID[i] = 0;
		pCurrentSurface->pTexture[i] = &pTexture[pCurrentSurface->iTextureID[i]];
		pCurrentSurface->pTexture[0]->iUsed++;
	}
	memset(&pCurrentSurface->pTexturePos[0], 0, sizeof(TEXTURE_POS));
	pCurrentSurface->pTexturePos[0].iPos[0][X] = 0;
	pCurrentSurface->pTexturePos[0].iPos[0][Y] = 0;
	pCurrentSurface->pTexturePos[0].iPos[1][X] = pCurrentSurface->pTexture[0]->iWidth-1;
	pCurrentSurface->pTexturePos[0].iPos[1][Y] = 0;
	pCurrentSurface->pTexturePos[0].iPos[2][X] = pCurrentSurface->pTexture[0]->iWidth-1;
	pCurrentSurface->pTexturePos[0].iPos[2][Y] = pCurrentSurface->pTexture[0]->iHeight-2;
	pCurrentSurface->pTexturePos[0].iPos[3][X] = 0;
	pCurrentSurface->pTexturePos[0].iPos[3][Y] = pCurrentSurface->pTexture[0]->iHeight-2;
	// Update the fields:
	for(i = 0; i < iFields; i++)
	{
		pFieldT = &pField[i];
		// This is required for every field side:
		for(i2 = 0; i2 < 6; i2++)
		{
			if(pFieldT->pSurface[i2])
				pFieldT->pSurface[i2] = &pSurface[pFieldT->iSurface[i2]];
		}
	}
	return 0;
} // end LEVEL::CreateSurface()

void LEVEL::DestroySurface(short iSurface)
{ // begin LEVEL::DestroySurface()
	short i, i2;
	FIELD *pFieldT;

	pSurface[iSurface].Destroy();
	// The given surface is replaced through the next one and so on:
	for(i = iSurface; i < iSurfaces-1; i++)
	{
		memcpy(&pSurface[i], &pSurface[i+1], sizeof(SURFACE));
		pSurface[i].iID--;
		if(pSurface[i].iChangeSurface == iSurface)
			pSurface[i].iChangeSurface = 0;
	}
	// Reorganize the surfaces:
	iSurfaces--;
	pSurface = (SURFACE *) realloc(pSurface, sizeof(SURFACE)*iSurfaces);
	// Update the current surface pointer:
	if(iCurrentSurface >= iSurfaces)
	{
		iCurrentSurface--;
		pCurrentSurface = &pSurface[iCurrentSurface];
	}
	else
		if(!pSurface)
		{ // There are no surfaces:
			iCurrentSurface = -1;
			pCurrentSurface = NULL;
		}
	// Update the fields:
	for(i = 0; i < iFields; i++)
	{
		pFieldT = &pField[i];
		// This is required for every field side:
		for(i2 = 0; i2 < 6; i2++)
		{
			// Update the field pointers:
			if(pFieldT->iSurface[i2] == iSurface)
			{
				// This side has now the default:
				pFieldT->iSurface[i2] = 0;
				pFieldT->pSurface[i2] = &pSurface[0];
				pSurface[0].iUsed++;
				continue;
			}
			if(pFieldT->iSurface[i2] > iSurface)
			{
				pFieldT->iSurface[i2]--;
				pFieldT->pSurface[i2] = &pSurface[pFieldT->iSurface[i2]];
			}
		}
	}
	// Update water surface:
	if(iWaterSurface == iSurface)
		iWaterSurface = 0;
	else
	if(iWaterSurface > iSurface)
		iWaterSurface--;
	// Update the sky-cube:
	for(i = 0; i < 6; i++)
	{
		if(iSkyCubeSurface[i] == iSurface)
			iSkyCubeSurface[i] = 0; // Set the default surface
		if(iSkyCubeSurface[i] > iSurface)
			iSkyCubeSurface[i]--; // Set the new surface
	}
	// Update box surface:
	for(i2 = 0; i2 < 2; i2++)
		for(i = 0; i < 6; i++)
		{
			if(iBoxSurface[i][i2] == iSurface)
				iBoxSurface[i][i2] = 0;
			else
			if(iBoxSurface[i][i2] > iSurface)
				iBoxSurface[i][i2]--;
		}
} // end LEVEL::DestroySurface()

HRESULT LEVEL::LoadSurface(char *pbyFilename)
{ // begin LEVEL::LoadSurface()
	short i, i2;
	FIELD *pFieldT;

	if(!pbyFilename || CreateSurface())
		return 1;
	// Now load the surface:
	if(pCurrentSurface->Load(pbyFilename))
		return 1;
	// Check if we have to load a texture:
	for(i2 = 0; i2 < pCurrentSurface->iAniSteps; i2++)
	{
		for(i = 0; i < iTextures; i++)
		{
			if(!strcmp(pTexture[i].byFilename, pCurrentSurface->byTextureFilename[i2]))
			{ // Good the texture is already loaded:
				// Set the current texture:
				iCurrentTexture = i;
				pCurrentTexture = &pTexture[i];
				pCurrentTexture->iUsed++;
				pCurrentSurface->iTextureID[i2] = iCurrentTexture;
				pCurrentSurface->pTexture[i2] = pCurrentTexture;
				goto NoLoad;
			}
		}
		// The texture is not loaded that load it:
		LoadTexture(pCurrentSurface->byTextureFilename[i2]);
		pCurrentTexture->iUsed++;
		pCurrentSurface->iTextureID[i2] = iCurrentTexture;
		pCurrentSurface->pTexture[i2] = pCurrentTexture;
	NoLoad:;
	}
	// Give this surface the right texture:
	pCurrentSurface->CalculateFloatTexturePos();
	// Update the field pointer the surfaces:
	for(i = 0; i < iFields; i++)
	{
		pFieldT = &pField[i];
		for(i2 = 0; i2 < 6; i2++)
		{
			if(pFieldT->iSurface[i2] == -1)
				continue;
			pFieldT->pSurface[i2] = &pSurface[pFieldT->iSurface[i2]];
		}
		break;
	}
	return 0;
} // end LEVEL::LoadSurface()

void LEVEL::DestroyTexture(short iTexture)
{ // begin LEVEL::DestroyTexture()
	short i, i2;

	// The given texture is replaced through the next one and so on:
	for(i = iTexture; i < iTextures-1; i++)
	{
		memcpy(&pTexture[i], &pTexture[i+1], sizeof(AS_TEXTURE));
		pTexture[i].iID--;
	}
	// Reorganize the textures:
	iTextures--;
	pTexture = (AS_TEXTURE *) realloc(pTexture, sizeof(AS_TEXTURE)*iTextures);
	// Update the current texture pointer:
	if(iCurrentTexture >= iTextures)
	{
		iCurrentTexture--;
		pCurrentTexture = &pTexture[iCurrentTexture];
	}
	else
		if(!pTexture)
		{ // There are no textures:
			iCurrentTexture = -1;
			pCurrentTexture = NULL;
		}
	// Update the surface pointers:
	for(i = 0; i < pLevel->iSurfaces; i++)
	{
		for(i2 = 0; i2 < pLevel->pSurface[i].iAniSteps; i2++)
		{
			if(pLevel->pSurface[i].iTextureID[i2] == iTexture)
			{ // Give this surface the default texture:
				pLevel->pSurface[i].iTextureID[i2] = 0;
				pLevel->pSurface[i].pTexture[i2] = &pTexture[0];
				continue;
			}
			if(pLevel->pSurface[i].iTextureID[i2] > iTexture)
			{
				pLevel->pSurface[i].iTextureID[i2]--;
				pLevel->pSurface[i].pTexture[i2] = &pLevel->pTexture[pLevel->pSurface[i].iTextureID[i2]];
			}
		}
	}	
} // end LEVEL::DestroySurface()

HRESULT LEVEL::LoadTexture(char *pbyFilename)
{ // begin LEVEL::LoadTexture()
	short i, i2;
	char byTemp[256];
	FILE *fp;

	if(!pbyFilename)
		return 1;
	// Add the main path:
	sprintf(byTemp, "%s%s", _AS->pbyProgramPath, pbyFilename);
	// Check if the texture is already loaded:
	for(i = 0; i < pLevel->iTextures; i++)
		if(!strcmp(pLevel->pTexture[i].byFilename, pbyFilename))
		{
			iCurrentTexture = i;
			pCurrentTexture = &pTexture[iCurrentTexture];
			return 0; // This texture is already loaded:
		}
	// Check if the texture is there:
	fp = fopen(byTemp, "r");
	if(!fp)
	{ // A texture was not found!!
		sprintf(byTemp, "%s: %s ", byTemp, M_TextureWasNotFound);
		_AS->WriteLogMessage(byTemp);	
		iCurrentTexture = 0;
		pCurrentTexture = &pTexture[0];
		return 0;
	}
	fclose(fp);
	// Add the new texture:
	iTextures++;
	pTexture = (AS_TEXTURE *) realloc(pTexture, sizeof(AS_TEXTURE)*iTextures);
	iCurrentTexture = iTextures-1;
	pCurrentTexture = &pTexture[iCurrentTexture];
	memset(pCurrentTexture, 0, sizeof(AS_TEXTURE));
	pCurrentTexture->iID = iTextures-1;
	strcpy(pCurrentTexture->byFilename, pbyFilename);
	// Now load the texture:
	ASLoadJpegRGB(pCurrentTexture, byTemp);
	// Update the surfaces:
	for(i = 0; i < pLevel->iSurfaces; i++)
	{
		for(i2 = 0; i2 < pLevel->pSurface[i].iAniSteps; i2++)
		{
			if(pLevel->pSurface[i].iTextureID[i2] == -1)
				continue;
			pLevel->pSurface[i].pTexture[i2] = &pLevel->pTexture[pLevel->pSurface[i].iTextureID[i2]];
		}
	}
	return 0;
} // end LEVEL::LoadTexture()

void LEVEL::Create(short iWidthT, short iHeightT, float fFieldDepthT, float fFieldWidthT, float fFieldHeightT)
{ // begin LEVEL::Create()
	short i, i2, i3, i4,  x, y;
	char byTemp[256];

	iWidth = iWidthT;
	iHeight = iHeightT;
	fFieldDepth = fFieldDepthT;
	fFieldWidth = fFieldWidthT;
	fFieldHeight = fFieldHeightT;
	iFields = iWidth*iHeight;
	fWholeWidth = (float) iWidth*fFieldWidth;
	fWholeHeight = (float) iHeight*fFieldHeight;
	// Create the level vertices:
	iPoints = (iFields+iWidth+iHeight+1)*2;
	fPoint = new FLOAT3[iPoints];
	fColor = new FLOAT3[iPoints];
	i2 = iPoints/2;
	for(i = 0, y = 0; y < iHeight+1; y++)
		for(x = 0; x < iWidth+1; x++, i++)
		{
			if(i >= i2)
				goto PointsEnd;
			// Front point:
			fPoint[i][X] = (float) x*fFieldWidth;
			fPoint[i][Y] = (float) y*fFieldHeight;
			fPoint[i][Z] = (float) fFieldDepth+STANDART_LEVEL_Z_POS;
			fColor[i][R] = 1.0f;
			fColor[i][G] = 1.0f;
			fColor[i][B] = 1.0f;
			// Back point:
			fPoint[i2+i][X] = (float) x*fFieldWidth;
			fPoint[i2+i][Y] = (float) y*fFieldHeight;
			fPoint[i2+i][Z] = (float) STANDART_LEVEL_Z_POS;
			fColor[i2+i][R] = 1.0f;
			fColor[i2+i][G] = 1.0f;
			fColor[i2+i][B] = 1.0f;
		}
PointsEnd:
	// Create the fields:
	pField = new FIELD[iFields];
	memset(pField, 0, sizeof(FIELD)*iFields);
	for(i = 0, i3 = 0, y = 0; y < iHeight; y++)
	{
		for(x = 0; x < iWidth; x++, i++, i3++)
		{
			pCurrentField = &pField[i];
			pCurrentField->iXField = x;
			pCurrentField->iYField = y;
			pCurrentField->iXPos = (short) (x*fFieldWidth);
			pCurrentField->iYPos = (short) (y*fFieldHeight);
			pCurrentField->iID = i;
			for(i4 = 0; i4 < 6; i4++)
				pCurrentField->dwLastTime[i4] = g_lNow;
			if(!pSurface)
				for(i4 = 0; i4 < 6; i4++)
					pCurrentField->iSurface[i4] = -1;
			else
				for(i4 = 0; i4 < 6; i4++)
					pCurrentField->pSurface[i4] = &pSurface[0];
			// Setup the field faces;
			// Front face:
			pCurrentField->iFace[FACE_FRONT][0] = i3+1;
			pCurrentField->iFace[FACE_FRONT][1] = i3+iWidth+2;
			pCurrentField->iFace[FACE_FRONT][2] = i3+iWidth+1;
			pCurrentField->iFace[FACE_FRONT][3] = i3;
			// Floor face:
			pCurrentField->iFace[FACE_FLOOR][0] = i3+1+i2;
			pCurrentField->iFace[FACE_FLOOR][1] = i3+iWidth+2+i2;
			pCurrentField->iFace[FACE_FLOOR][2] = i3+iWidth+1+i2;
			pCurrentField->iFace[FACE_FLOOR][3] = i3+i2;
			// Left face:
			pCurrentField->iFace[FACE_LEFT][0] = i3+iWidth+1;
			pCurrentField->iFace[FACE_LEFT][1] = i3+i2+iWidth+1;
			pCurrentField->iFace[FACE_LEFT][2] = i3+i2;
			pCurrentField->iFace[FACE_LEFT][3] = i3;
			// Right face:
			pCurrentField->iFace[FACE_RIGHT][0] = i3+1;
			pCurrentField->iFace[FACE_RIGHT][1] = i3+i2+1;
			pCurrentField->iFace[FACE_RIGHT][2] = i3+i2+iWidth+2;
			pCurrentField->iFace[FACE_RIGHT][3] = i3+iWidth+2;
			// Top face:
			pCurrentField->iFace[FACE_TOP][0] = i3;
			pCurrentField->iFace[FACE_TOP][1] = i3+i2;
			pCurrentField->iFace[FACE_TOP][2] = i3+i2+1;
			pCurrentField->iFace[FACE_TOP][3] = i3+1;
			// Bottom face:
			pCurrentField->iFace[FACE_BOTTOM][0] = i3+iWidth+2;
			pCurrentField->iFace[FACE_BOTTOM][1] = i3+i2+iWidth+2;
			pCurrentField->iFace[FACE_BOTTOM][2] = i3+i2+iWidth+1;
			pCurrentField->iFace[FACE_BOTTOM][3] = i3+iWidth+1;
			// Is this field active?
			if(x != iWidth-1 && y != iHeight-1)
				pCurrentField->bActive = TRUE;
			pCurrentField->bFaceActive[FACE_FLOOR] = TRUE;
		}
		i3++;
	}
	// Level outline
	for(y = 0; y < iHeight-1; y++)
		SetFieldWall(0, y, TRUE, FALSE);
	for(x = 0; x < iWidth-1; x++)
		SetFieldWall(x, 0, TRUE, FALSE);
	for(y = 0; y < iHeight-1; y++)
		SetFieldWall(iWidth-2, y, TRUE, FALSE);
	for(x = 0; x < iWidth-1; x++)
		SetFieldWall(x, iHeight-2, TRUE, FALSE);
	pCurrentField = &pField[0];
	SetStandartView();
	if(!pTexture)
	{
		// Load default texture:
		sprintf(byTemp, "%s\\FieldTemp.jpg", _AS->pbyBitmapsFile);
		LoadTexture(byTemp);
		// Create the default surface:
		CreateSurface();
		strcpy(pCurrentSurface->byName, "Default");
		strcpy(pCurrentSurface->byTextureFilename[0], byTemp);		
		pCurrentSurface->iTextureID[0] = 0;
		pCurrentSurface->pTexture[0] = &pTexture[0];
		pCurrentSurface->pTexturePos->iPos[0][X] = 0;
		pCurrentSurface->pTexturePos->iPos[0][Y] = 0;
		pCurrentSurface->pTexturePos->iPos[1][X] = 64;
		pCurrentSurface->pTexturePos->iPos[1][Y] = 0;
		pCurrentSurface->pTexturePos->iPos[2][X] = 64;
		pCurrentSurface->pTexturePos->iPos[2][Y] = 64;
		pCurrentSurface->pTexturePos->iPos[3][X] = 0;
		pCurrentSurface->pTexturePos->iPos[3][Y] = 64;
		pCurrentSurface->CalculateFloatTexturePos();
		// Set the default surface:
		for(i = 0; i < iFields; i++)
		{
			pCurrentField = &pField[i];
			for(i2 = 0; i2 < 6; i2++)
			{
				pCurrentField->iSurface[i2] = 0;
				pCurrentField->pSurface[i2] = pCurrentSurface;
				pCurrentSurface->iUsed++;
			}
		}
	}
	lWaterAniTime = g_lNow;
	CalculateFieldNormals();
	CalculateFieldBoundingBoxes();
} // end LEVEL::Create()

void LEVEL::Destroy(void)
{ // begin LEVEL::Destroy()
	short i;

	if(pField)
		free(pField);
	if(fPoint)
		free(fPoint);
	if(fColor)
		free(fColor);
	if(pSurface)
	{
		for(i = 0; i < iSurfaces; i++)
			pSurface[i].Destroy();
		free(pSurface);
	}
	if(pTexture)
	{
		for(i = 0; i < iTextures; i++)
			if(pTexture[i].pbyData)
				free(pTexture[i].pbyData);
		free(pTexture);
	}
	for(i = 0; i < iCameraScripts; i++)
		free(pCameraScript[i].pCamera);
	free(pCameraScript);
	memset(this, 0, sizeof(LEVEL));
} // end LEVEL::Destroy()

void LEVEL::SetFieldWall(short x, short y, BOOL bStatus, BOOL bOnlyCheck)
{ // begin LEVEL::SetFieldWall()
	short i, i2;

	if(x < 0 || x > iWidth-2 || y < 0 || y > iHeight-2)
		return;
	i = y*iWidth+x;
	if(pField[i].pActor)
		return;
	if(!bOnlyCheck)
	{
		pField[i].bActive = TRUE;
		pField[i].bWall = bStatus;
		for(i2 = 0; i2 < 6; i2++)
			pField[i].bFaceActive[i2] = bStatus;
	}
	else
	{
		if(!pField[i].bActive)
			bStatus = FALSE;
		else
			bStatus = pField[i].bWall;
	}
	// Activate/Deactivate the field sides around this field:
	if(bStatus)
	{ // Check if the sides of the other walls around this are visible:
		pField[i].bFaceActive[FACE_FLOOR] = FALSE;
		if(x > 0 && pField[i-1].bWall && pField[i-1].bActive && !pField[i-1].pActor)
		{ // Check left wall:
			pField[i-1].bFaceActive[FACE_RIGHT] = FALSE;
			pField[i].bFaceActive[FACE_LEFT] = FALSE;
		}
		if(x < iWidth-1 && pField[i+1].bWall && pField[i+1].bActive && !pField[i+1].pActor)
		{ // Check right wall:
			pField[i+1].bFaceActive[FACE_LEFT] = FALSE;
			pField[i].bFaceActive[FACE_RIGHT] = FALSE;
		}
		if(y > 0 && pField[i-iWidth].bWall && pField[i-iWidth].bActive && !pField[i-iWidth].pActor)
		{ // Check top wall:
			pField[i-iWidth].bFaceActive[FACE_BOTTOM] = FALSE;
			pField[i].bFaceActive[FACE_TOP] = FALSE;
		}
		if(y < iHeight-1 && pField[i+iWidth].bWall && pField[i+iWidth].bActive && !pField[i+iWidth].pActor)
		{ // Check bottom wall:
			pField[i+iWidth].bFaceActive[FACE_TOP] = FALSE;
			pField[i].bFaceActive[FACE_BOTTOM] = FALSE;
		}
	}
	else
	{ // Check if the sides of the other walls around this are visible:
		pField[i].bFaceActive[FACE_FLOOR] = TRUE;
		if(x > 0 && pField[i-1].bActive && pField[i-1].bWall && !pField[i-1].pActor)
		{ // Check left wall:
			pField[i-1].bFaceActive[FACE_RIGHT] = TRUE;
		}
		if(x < iWidth-1 && pField[i+1].bActive && pField[i+1].bWall && !pField[i+1].pActor)
		{ // Check right wall:
			pField[i+1].bFaceActive[FACE_LEFT] = TRUE;
		}
		if(y > 0 && pField[i-iWidth].bActive && pField[i-iWidth].bWall && !pField[i-iWidth].pActor)
		{ // Check top wall:
			pField[i-iWidth].bFaceActive[FACE_BOTTOM] = TRUE;
		}
		if(y < iHeight-1 && pField[i+iWidth].bActive && pField[i+iWidth].bWall && !pField[i+iWidth].pActor)
		{ // Check bottom wall:
			pField[i+iWidth].bFaceActive[FACE_TOP] = TRUE;
		}
	}
} // end LEVEL::SetFieldWall()

void LEVEL::CalculateFieldNormals(void)
{ // begin LEVEL::CalculateFieldNormals()
	short i, i2, i3;
	FIELD *pFieldT;

	// Calculate all normals for the fields:
	for(i = 0; i < iFields; i++)
	{
		pFieldT = &pField[i];
		for(i2 = 0; i2 < 6; i2++)
		{
			NormalizeFace(&pFieldT->fNormal[i2][0], fPoint[pFieldT->iFace[i2][0]],
			              fPoint[pFieldT->iFace[i2][1]], fPoint[pFieldT->iFace[i2][2]]);
			NormalizeFace(&pFieldT->fNormal[i2][1], fPoint[pFieldT->iFace[i2][0]],
			              fPoint[pFieldT->iFace[i2][2]], fPoint[pFieldT->iFace[i2][3]]);
			// Turn the normals, because the level goes to the negative space:
			for(i3 = 0; i3 < 3; i3++)
			{
				pFieldT->fNormal[i2][0][i3] = -pFieldT->fNormal[i2][0][i3];
				pFieldT->fNormal[i2][1][i3] = -pFieldT->fNormal[i2][1][i3];
			}
		}
	}
} // end LEVEL::CalculateFieldNormals()

void LEVEL::CalculateFieldBoundingBoxes(void)
{ // begin LEVEL::CalculateFieldBoundingBoxes()
	short i, i2, i3, i4;
	FLOAT3 *pfPointT;
	FIELD *pFieldT;

	// Calculate the field bounding boxes: (for frustum culling)
	// This technique is not the best, but it is good and fast enought for this game world:
	for(i = 0; i < iFields; i++)
	{
		pFieldT = &pField[i];
		// Setup:
		for(i2 = 0; i2 < 3; i2++)
		{
			pFieldT->fBoundingBox[0][i2] = iWidth*fFieldWidth+iHeight*fFieldHeight;
			pFieldT->fBoundingBox[1][i2] = STANDART_LEVEL_Z_POS;
		}
		// Check:
		for(i2 = 0; i2 < 6; i2++)
		{ // Go through each field side:
			for(i3 = 0; i3 < 4; i3++)
			{ // Go through each point of this field side:
				pfPointT = &fPoint[pFieldT->iFace[i2][i3]];
				// Check now each coordinate:
				for(i4 = 0; i4 < 3; i4++)
				{
					if((*pfPointT)[i4] < pFieldT->fBoundingBox[0][i4])
						pFieldT->fBoundingBox[0][i4] = (*pfPointT)[i4];
					if((*pfPointT)[i4] > pFieldT->fBoundingBox[1][i4])
						pFieldT->fBoundingBox[1][i4] = (*pfPointT)[i4];
				}
			}
		}
		// Setup stuff for culling:
		pFieldT->fBoundingBoxX = (pFieldT->fBoundingBox[1][X]+pFieldT->fBoundingBox[0][X])/2;
		pFieldT->fBoundingBoxY = (pFieldT->fBoundingBox[1][Y]+pFieldT->fBoundingBox[0][Y])/2;
		pFieldT->fBoundingBoxZ = (pFieldT->fBoundingBox[0][Z]+pFieldT->fBoundingBox[1][Z])/2;
		// Calculate bounding box size: (cube):
		pFieldT->fBoundingBoxSize = (pFieldT->fBoundingBox[1][X]-pFieldT->fBoundingBox[0][X]);
		if((pFieldT->fBoundingBox[1][Y]-pFieldT->fBoundingBox[0][Y]) > pFieldT->fBoundingBoxSize)
			pFieldT->fBoundingBoxSize = (pFieldT->fBoundingBox[1][Y]-pFieldT->fBoundingBox[0][Y]);
		// '-' Because our world z goes into the negative space:
		if(-(pFieldT->fBoundingBox[0][Z]-pFieldT->fBoundingBox[1][Z]) > pFieldT->fBoundingBoxSize)
			pFieldT->fBoundingBoxSize = (pFieldT->fBoundingBox[0][Z]-pFieldT->fBoundingBox[1][Z]);
		pFieldT->fBoundingBoxSize /= 2;
		if(pFieldT->fBoundingBoxSize < 0.0f)
			pFieldT->fBoundingBoxSize *= -1;
	}
} // end LEVEL::CalculateFieldBoundingBoxes()

void LEVEL::DeInitLevelDraw(void)
{ // begin LEVEL::DeInitLevelDraw()
	GLfloat afLightData[4]  = {0.0f, 0.0f, 0.0f, 0.0f};

	glDisable(GL_FOG);
	afLightData[0] = 0.0f;
	afLightData[1] = 0.0f;
	afLightData[2] = 0.0f;
	afLightData[3] = 1.0f;
	glLightfv(GL_LIGHT1, GL_POSITION, afLightData);
	afLightData[0] = 1.0f;
	afLightData[1] = 1.0f;
	afLightData[2] = 1.0f;
	afLightData[3] = 1.0f;
	glLightfv(GL_LIGHT1, GL_AMBIENT, afLightData);
	glEnable(GL_LIGHT1);
} // end LEVEL::DeInitLevelDraw()

void LEVEL::InitLevelDraw(void)
{ // begin LEVEL::InitLevelDraw()
    GLfloat	fogColor[4] = {fFogColor[R], fFogColor[G], fFogColor[B], 1.0f};
	GLfloat afLightData[4]  = {0.0f, 0.0f, 0.0f, 0.0f};
	
 	if(pLevel->bFog)
	{
		glFogfv(GL_FOG_COLOR, fogColor);
		glFogf(GL_FOG_DENSITY, fFogDensity);
		glFogf(GL_FOG_START, 0.0f);
		glFogf(GL_FOG_END, 10.0f);
		glEnable(GL_FOG);
		glClearColor(fFogColor[R], fFogColor[G], fFogColor[B], 1.0f);
	}
	else
		glDisable(GL_FOG);
	afLightData[0] = 0.0f;
	afLightData[1] = 0.0f;
	afLightData[2] = 0.0f;
	afLightData[3] = 1.0f;
	glLightfv(GL_LIGHT1, GL_POSITION, afLightData);
	afLightData[0] = fLevelColor[R];
	afLightData[1] = fLevelColor[G];
	afLightData[2] = fLevelColor[B];
	afLightData[3] = 1.0f;
	glLightfv(GL_LIGHT1, GL_AMBIENT, afLightData);
	glEnable(GL_LIGHT1);
} // end LEVEL::InitLevelDraw()

void LEVEL::Draw(BOOL bTempBackground)
{ // begin LEVEL::Draw()
	short i, i2, i3, iAniStep = 0;
	float fHalfFieldWidth, fHalfFieldHeight;
	FIELD *pFieldT;
	TEXTURE_POS *pTexturePos;
	HWND hWndT;

	glLineWidth(3.0f);
	if(bTempBackground)
	{
		glColor3f(0.5f, 0.5f, 0.5f);
		glDisable(GL_TEXTURE_2D);
		glBegin(GL_QUADS);
			glVertex3d(0.0f, 0.0f, 1.0f+STANDART_LEVEL_Z_POS);
			glVertex3d(0.0f, (pLevel->iHeight-1)*pLevel->fFieldHeight, 1.0f+STANDART_LEVEL_Z_POS);
			glVertex3d((pLevel->iWidth-1)*pLevel->fFieldWidth, (pLevel->iHeight-1)*pLevel->fFieldHeight, 1.0f+STANDART_LEVEL_Z_POS);
			glVertex3d((pLevel->iWidth-1)*pLevel->fFieldWidth, 0.0f, 1.0f+STANDART_LEVEL_Z_POS);
		glEnd();
	}
	glDisableClientState(GL_NORMAL_ARRAY);
	if(!_ASConfig->bUseLevelVertexColor || !_ASConfig->bHightRenderQuality)
		glDisableClientState(GL_COLOR_ARRAY);
	else
		glColorPointer(3, GL_FLOAT, 0, fColor);
	glVertexPointer(3, GL_FLOAT, 0, fPoint);
	glEnable(GL_TEXTURE_2D);
	glColor3f(1.0f, 1.0f, 1.0f);
	
	if(_ASConfig->bFrustumCulling)
	{
		// Check if the camera has been changed:
		if(pCamera->fPos[X] != LevelTempCamera.fPos[X] ||
		   pCamera->fPos[Y] != LevelTempCamera.fPos[Y] ||
		   pCamera->fPos[Z] != LevelTempCamera.fPos[Z] ||
		   pCamera->fRot[X] != LevelTempCamera.fRot[X] ||
		   pCamera->fRot[Y] != LevelTempCamera.fRot[Y] ||
		   pCamera->fRot[Z] != LevelTempCamera.fRot[Z] ||
		   pPlayer->fWorldPos[Z] != fPlayerTempZPos)
		{
			for(i = 0; i < 3; i++)
			{
				LevelTempCamera.fPos[i] = pCamera->fPos[i];
				LevelTempCamera.fRot[i] = pCamera->fRot[i];
			}
			fPlayerTempZPos = pPlayer->fWorldPos[Z];
			// Check if this field is on screen:
			for(i = 0; i < iFields; i++)
			{
				pFieldT = &pField[i];
				if(!CubeInFrustum(pFieldT->fBoundingBoxX, pFieldT->fBoundingBoxY,
								  pFieldT->fBoundingBoxZ, pFieldT->fBoundingBoxSize))
					pFieldT->bOnScreen = FALSE;
				else
					pFieldT->bOnScreen = TRUE;
			}
		}
	}


	glCullFace(GL_FRONT);
	for(i2 = 0; i2 < iTextures+1; i2++)
	{
		if(i2 < iTextures)
			glBindTexture(GL_TEXTURE_2D, pTexture[i2].iOpenGLID);
		for(i = 0; i < iFields; i++)
		{
			pFieldT = &pField[i];
			if(!pFieldT->bActive || !pFieldT->bOnScreen || pFieldT->pBridgeActor)
				continue;
			if(pFieldT->bNoBackfaceCulling)
				glDisable(GL_CULL_FACE);
			if(!pFieldT->bFaceActive[FACE_FRONT] && pFieldT->bFaceActive[FACE_FLOOR])
			{ // Draw the floor:
				i3 = FACE_FLOOR;
				if(!pFieldT->pSurface[i3] || pFieldT->pSurface[i3]->iTextureID[pFieldT->iCurrentAniStep[i3]] != i2)
					goto Next;
				pTexturePos = &pFieldT->pSurface[i3]->pTexturePos[pFieldT->iCurrentAniStep[i3]];
				glBegin(GL_TRIANGLES);
					glNormal3fv(pFieldT->fNormal[i3][0]);
					
					glTexCoord2fv(pTexturePos->fPos[(1+pFieldT->iSurfaceRotation[i3]) % 4]);
					glArrayElement(pFieldT->iFace[i3][0]);
					glTexCoord2fv(pTexturePos->fPos[(2+pFieldT->iSurfaceRotation[i3]) % 4]);
					glArrayElement(pFieldT->iFace[i3][1]);
					glTexCoord2fv(pTexturePos->fPos[(3+pFieldT->iSurfaceRotation[i3]) % 4]);
					glArrayElement(pFieldT->iFace[i3][2]);
					
					glNormal3fv(pFieldT->fNormal[i3][1]);
					glTexCoord2fv(pTexturePos->fPos[(1+pFieldT->iSurfaceRotation[i3]) % 4]);
					glArrayElement(pFieldT->iFace[i3][0]);
					glTexCoord2fv(pTexturePos->fPos[(3+pFieldT->iSurfaceRotation[i3]) % 4]);
					glArrayElement(pFieldT->iFace[i3][2]);
					glTexCoord2fv(pTexturePos->fPos[(pFieldT->iSurfaceRotation[i3]) % 4]);
					glArrayElement(pFieldT->iFace[i3][3]);
				glEnd();
			}
			if(!pFieldT->bWall || pFieldT->pActor)
				goto Next;
			// Draw the sided around the field: 
			for(i3 = FACE_FRONT; i3 < FACE_BOTTOM+2; i3++)
			{
				if(!pFieldT->bFaceActive[i3] ||
				   !pFieldT->pSurface[i3] || pFieldT->pSurface[i3]->iTextureID[pFieldT->iCurrentAniStep[i3]] != i2)
					continue;
				pTexturePos = &pFieldT->pSurface[i3]->pTexturePos[pFieldT->iCurrentAniStep[i3]];
				glBegin(GL_TRIANGLES);
					glNormal3fv(pFieldT->fNormal[i3][0]);

					glTexCoord2fv(pTexturePos->fPos[(1+pFieldT->iSurfaceRotation[i3]) % 4]);
					glArrayElement(pFieldT->iFace[i3][0]);
					glTexCoord2fv(pTexturePos->fPos[(2+pFieldT->iSurfaceRotation[i3]) % 4]);
					glArrayElement(pFieldT->iFace[i3][1]);
					glTexCoord2fv(pTexturePos->fPos[(3+pFieldT->iSurfaceRotation[i3]) % 4]);
					glArrayElement(pFieldT->iFace[i3][2]);
					
					glNormal3fv(pFieldT->fNormal[i3][1]);
					glTexCoord2fv(pTexturePos->fPos[(1+pFieldT->iSurfaceRotation[i3]) % 4]);
					glArrayElement(pFieldT->iFace[i3][0]);
					glTexCoord2fv(pTexturePos->fPos[(3+pFieldT->iSurfaceRotation[i3]) % 4]);
					glArrayElement(pFieldT->iFace[i3][2]);
					glTexCoord2fv(pTexturePos->fPos[(pFieldT->iSurfaceRotation[i3]) % 4]);
					glArrayElement(pFieldT->iFace[i3][3]);
				glEnd();
			}
		Next:;
			if(pFieldT->bNoBackfaceCulling)
				glEnable(GL_CULL_FACE);
		}
	}
	glCullFace(GL_BACK);
	if(!_ASConfig->bUseLevelVertexColor || !_ASConfig->bHightRenderQuality)
		glEnableClientState(GL_COLOR_ARRAY);
	glEnableClientState(GL_NORMAL_ARRAY);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_TEXTURE_2D);	
	glColor3f(1.0f, 1.0f, 1.0f);

	if(byEditorMenu == EDITOR_TERRAIN_MENU)
	{
		fHalfFieldWidth = fFieldWidth/2;
		fHalfFieldHeight = fFieldHeight/2;
		hWndT = hWndEditorTab[TAB_EDITOR_TERRAIN];
		// Draw selected field bounds:
		glColor3f(1.0f, 0.0f, 0.0f);
		for(i = 0; i < iFields; i++)
		{
			pFieldT = &pField[i];
			if(!pFieldT->bOnScreen)
				continue;
			if(pFieldT->bSelected)
			{
				if(IsDlgButtonChecked(hWndT, IDC_EDITOR_TERRAIN_FLOOR) ||
				   IsDlgButtonChecked(hWndT, IDC_EDITOR_TERRAIN_BOTH))
				{
					// Show the floor point:
					glBegin(GL_LINE_LOOP);
						glVertex3f(fPoint[pFieldT->iFace[FACE_FLOOR][0]][X]-fHalfFieldWidth,
								   fPoint[pFieldT->iFace[FACE_FLOOR][0]][Y]-fHalfFieldHeight,
								   fPoint[pFieldT->iFace[FACE_FLOOR][0]][Z]);
						glVertex3f(fPoint[pFieldT->iFace[FACE_FLOOR][1]][X]-fHalfFieldWidth,
								   fPoint[pFieldT->iFace[FACE_FLOOR][1]][Y]-fHalfFieldHeight,
								   fPoint[pFieldT->iFace[FACE_FLOOR][1]][Z]);
						glVertex3f(fPoint[pFieldT->iFace[FACE_FLOOR][2]][X]-fHalfFieldWidth,
								   fPoint[pFieldT->iFace[FACE_FLOOR][2]][Y]-fHalfFieldHeight,
								   fPoint[pFieldT->iFace[FACE_FLOOR][2]][Z]);
						glVertex3f(fPoint[pFieldT->iFace[FACE_FLOOR][3]][X]-fHalfFieldWidth,
								   fPoint[pFieldT->iFace[FACE_FLOOR][3]][Y]-fHalfFieldHeight,
								   fPoint[pFieldT->iFace[FACE_FLOOR][3]][Z]);
					glEnd();
				}
				if(IsDlgButtonChecked(hWndT, IDC_EDITOR_TERRAIN_TOP) ||
				   IsDlgButtonChecked(hWndT, IDC_EDITOR_TERRAIN_BOTH))
				{
					// Show the front point:
					glBegin(GL_LINE_LOOP);
						glVertex3f(fPoint[pFieldT->iFace[FACE_FRONT][0]][X]-fHalfFieldWidth,
								   fPoint[pFieldT->iFace[FACE_FRONT][0]][Y]-fHalfFieldHeight,
								   fPoint[pFieldT->iFace[FACE_FRONT][0]][Z]);
						glVertex3f(fPoint[pFieldT->iFace[FACE_FRONT][1]][X]-fHalfFieldWidth,
								   fPoint[pFieldT->iFace[FACE_FRONT][1]][Y]-fHalfFieldHeight,
								   fPoint[pFieldT->iFace[FACE_FRONT][1]][Z]);
						glVertex3f(fPoint[pFieldT->iFace[FACE_FRONT][2]][X]-fHalfFieldWidth,
								   fPoint[pFieldT->iFace[FACE_FRONT][2]][Y]-fHalfFieldHeight,
								   fPoint[pFieldT->iFace[FACE_FRONT][2]][Z]);
						glVertex3f(fPoint[pFieldT->iFace[FACE_FRONT][3]][X]-fHalfFieldWidth,
								   fPoint[pFieldT->iFace[FACE_FRONT][3]][Y]-fHalfFieldHeight,
								   fPoint[pFieldT->iFace[FACE_FRONT][3]][Z]);
					glEnd();
				}
			}
			if(!pFieldT->bActive)
				continue;
			// Animate the surface textures:
			for(i2 = 0; i2 < 6; i2++)
			{
				if(!pFieldT->bFaceActive[i2] ||
				   !pFieldT->pSurface[i2])
					continue;
				if(g_lNow-pFieldT->dwLastTime[i2] <
				   pFieldT->pSurface[i2]->pTexturePos[pFieldT->iCurrentAniStep[i2]].iTimeToNext)
					goto CheckAni2;
				pFieldT->dwLastTime[i2] = g_lNow;
				// It's time for a animation frame update:
				pFieldT->iCurrentAniStep[i2]++;
			CheckAni2: // Check if this is a correct animation step:
				if(pFieldT->iCurrentAniStep[i2] >= pFieldT->pSurface[i2]->iAniSteps)
					pFieldT->iCurrentAniStep[i2] = 0;
			}
		}
	}
	else
	{ // Draw selected field bounds:
		glColor3f(1.0f, 0.0f, 0.0f);
		
		if(!bPause || bLevelComplete)
		{
			for(i = 0; i < iFields; i++)
			{
				pFieldT = &pField[i];
				
				if(pFieldT->iXPos == iWidth-1 || pFieldT->iYPos == iHeight-1)
					continue; 

				 // Check if a field is selected:
				if(pFieldT->bSelected)
				{
					for(i3 = FACE_FRONT; i3 < FACE_BOTTOM+2; i3++)
					{
						glBegin(GL_LINE_LOOP);
							for(i2 = 0; i2 < 4; i2++)
								glVertex3f(fPoint[pFieldT->iFace[i3][i2]][X], fPoint[pFieldT->iFace[i3][i2]][Y],
										   fPoint[pFieldT->iFace[i3][i2]][Z]);
						glEnd();
					}
				}

				if(!pFieldT->bActive || !pFieldT->bOnScreen)
					continue;
				// Animate the surface textures:
				for(i2 = 0; i2 < 6; i2++)
				{
					if(!pFieldT->bFaceActive[i2] ||
					   !pFieldT->pSurface[i2])
						continue;
					if(g_lNow-pFieldT->dwLastTime[i2] <
					   pFieldT->pSurface[i2]->pTexturePos[pFieldT->iCurrentAniStep[i2]].iTimeToNext)
						goto CheckAni;
					pFieldT->dwLastTime[i2] = g_lNow;
					// It's time for a animation frame update:
					pFieldT->iCurrentAniStep[i2]++;
				CheckAni: // Check if this is a correct animation step:
					if(pFieldT->iCurrentAniStep[i2] >= pFieldT->pSurface[i2]->iAniSteps)
						pFieldT->iCurrentAniStep[i2] = 0;
				}
			}
		}
		else
		{ // Check only if a field is selected:
			for(i = 0; i < iFields; i++)
			{
				pFieldT = &pField[i];

				if(pFieldT->iXPos == iWidth-1 || pFieldT->iYPos == iHeight-1)
					continue; 

				if(pFieldT->bSelected)
				{
					for(i3 = FACE_FRONT; i3 < FACE_BOTTOM+2; i3++)
					{
						glBegin(GL_LINE_LOOP);
							for(i2 = 0; i2 < 4; i2++)
								glVertex3f(fPoint[pFieldT->iFace[i3][i2]][X], fPoint[pFieldT->iFace[i3][i2]][Y],
										   fPoint[pFieldT->iFace[i3][i2]][Z]);
						glEnd();
					}
				}
			}
		}
	}
	glEnable(GL_DEPTH_TEST);
} // end LEVEL::Draw()

void LEVEL::DrawWater(void)
{ // begin LEVEL::DrawWater()
	TEXTURE_POS *pTexturePosT;
	SURFACE *pSurfaceT;

	if(!bWater)
		return;
	pSurfaceT = &pSurface[iWaterSurface];
	if(iWaterAniStep >= pSurfaceT->iAniSteps)
		iWaterAniStep = 0;
	pTexturePosT = &pSurfaceT->pTexturePos[iWaterAniStep];
	glDisable(GL_CULL_FACE);
	if(pLevel->fWaterDensity != 1.0f)
		glEnable(GL_BLEND);
	else
		glDisable(GL_BLEND);
	if(!bPause || bLevelComplete)
		pLevel->fWaterVar += 0.005f*g_lDeltatime*fWaterSpeed;
	pLevel->fWaterActualHeight = (float) (sin(pLevel->fWaterVar)/50.0f)*fWaterAmplitude+pLevel->fWaterHeight;
	glColor4f(pLevel->fWaterColor[R], pLevel->fWaterColor[G], pLevel->fWaterColor[B], pLevel->fWaterDensity);
	if(!bWaterSurface)
	{
		glDisable(GL_TEXTURE_2D);
		glBegin(GL_QUADS);
			glNormal3f(0.0f, 0.0f, 1.0f);
			glVertex3d(0.01f, 0.01f, pLevel->fWaterActualHeight);
			glVertex3d(0.01f, (pLevel->iHeight-1)*pLevel->fFieldHeight-0.01f, pLevel->fWaterActualHeight);
			glVertex3d((pLevel->iWidth-1)*pLevel->fFieldWidth-0.01f, (pLevel->iHeight-1)*pLevel->fFieldHeight-0.01f, pLevel->fWaterActualHeight);
			glVertex3d((pLevel->iWidth-1)*pLevel->fFieldWidth-0.01f, 0.01f, pLevel->fWaterActualHeight);
		glEnd();
		glEnable(GL_TEXTURE_2D);
	}
	else
	{
		// Animate the water:
		if(!bPause && bWaterSurface && g_lNow-lWaterAniTime > pTexturePosT->iTimeToNext)
		{
			lWaterAniTime = g_lNow;
			iWaterAniStep++;
			if(iWaterAniStep >= pSurfaceT->iAniSteps)
				iWaterAniStep = 0;
		}
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, pSurfaceT->pTexture[iWaterAniStep]->iOpenGLID);
	
	/*	// Create the water temp texture. We need it to repead the water texture:
		
		glBindTexture(GL_TEXTURE_2D, iGameTexture[WATER_TEMP_TEXTURE]);*/

		pTexturePosT = &pSurfaceT->pTexturePos[iWaterAniStep];
		glBegin(GL_QUADS);
			glNormal3f(0.0f, 0.0f, -1.0f);
	
			glTexCoord2f(pTexturePosT->fPos[0][X], pTexturePosT->fPos[0][Y]);
			glVertex3d(0.01f, 0.01f, fWaterActualHeight);

			glTexCoord2f(pTexturePosT->fPos[1][X], pTexturePosT->fPos[1][Y]);
			glVertex3d(0.01f, (iHeight-1)*fFieldHeight-0.01f, fWaterActualHeight);
			
			glTexCoord2f(pTexturePosT->fPos[2][X]*fWaterTextureRepeat[X], pTexturePosT->fPos[2][Y]*fWaterTextureRepeat[Y]);
			glVertex3d((iWidth-1)*fFieldWidth-0.01f, (iHeight-1)*fFieldHeight-0.01f, fWaterActualHeight);
			
			glTexCoord2f(pTexturePosT->fPos[3][X], pTexturePosT->fPos[3][Y]*fWaterTextureRepeat[Y]);
			glVertex3d((iWidth-1)*fFieldWidth-0.01f, 0.01f, fWaterActualHeight);
		glEnd();
	}

	glDisable(GL_BLEND);
	glEnable(GL_CULL_FACE);
} // end LEVEL::DrawWater()

void LEVEL::DrawSkyCube(void)
{ // begin LEVEL::DrawSkyCube();
	TEXTURE_POS *pTexturePos;
	short i;

	if(!bSkyCube)
		return;
	// Animate:
	for(i = 0; i < 6; i++)
	{
		if(iSkyCubeSurface[i] >= iSurfaces)
			iSkyCubeSurface[i] = 0;
		if(g_lNow-dwSkyCubeSurfaceLastTime[i] <
		   pSurface[iSkyCubeSurface[i]].pTexturePos[iSkyCubeSurfaceAniStep[i]].iTimeToNext)
			goto Next;
		dwSkyCubeSurfaceLastTime[i] = g_lNow;
		// It's time for a animation frame update:
		iSkyCubeSurfaceAniStep[i]++;
	Next: // Go sure that the animation step is a correct one:
		if(iSkyCubeSurfaceAniStep[i] >= pSurface[iSkyCubeSurface[i]].iAniSteps)
			iSkyCubeSurfaceAniStep[i] = 0;
	}

	// Sky cube:
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_LIGHTING);
	glDisable(GL_CULL_FACE);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);
	glDisable(GL_FOG);
	glColor3fv(fSkyCubeColor);

	glScalef(fSkyCubeSize[0], fSkyCubeSize[1], fSkyCubeSize[2]);
	glPolygonMode(GL_BACK, GL_FILL);
	// Floor Face
	glBindTexture(GL_TEXTURE_2D, pSurface[iSkyCubeSurface[0]].pTexture[iSkyCubeSurfaceAniStep[0]]->iOpenGLID);
	pTexturePos = &pSurface[iSkyCubeSurface[0]].pTexturePos[iSkyCubeSurfaceAniStep[0]];
	glBegin(GL_QUADS);
		glTexCoord2fv(pTexturePos->fPos[(0+iSkyCubeSurfaceRotation[0]) % 4]); glVertex3f(-1.0f, -1.0f,  1.0f);
		glTexCoord2fv(pTexturePos->fPos[(1+iSkyCubeSurfaceRotation[0]) % 4]); glVertex3f( 1.0f, -1.0f,  1.0f);
		glTexCoord2fv(pTexturePos->fPos[(2+iSkyCubeSurfaceRotation[0]) % 4]); glVertex3f( 1.0f,  1.0f,  1.0f);
		glTexCoord2fv(pTexturePos->fPos[(3+iSkyCubeSurfaceRotation[0]) % 4]); glVertex3f(-1.0f,  1.0f,  1.0f);
	glEnd();

	// Sky Face
	glBindTexture(GL_TEXTURE_2D, pSurface[iSkyCubeSurface[1]].pTexture[iSkyCubeSurfaceAniStep[1]]->iOpenGLID);
	pTexturePos = &pSurface[iSkyCubeSurface[1]].pTexturePos[iSkyCubeSurfaceAniStep[1]];
	glBegin(GL_QUADS);
		glTexCoord2fv(pTexturePos->fPos[(3+iSkyCubeSurfaceRotation[1]) % 4]); glVertex3f(-1.0f, -1.0f, -1.0f);
		glTexCoord2fv(pTexturePos->fPos[(0+iSkyCubeSurfaceRotation[1]) % 4]); glVertex3f(-1.0f,  1.0f, -1.0f);
		glTexCoord2fv(pTexturePos->fPos[(1+iSkyCubeSurfaceRotation[1]) % 4]); glVertex3f( 1.0f,  1.0f, -1.0f);
		glTexCoord2fv(pTexturePos->fPos[(2+iSkyCubeSurfaceRotation[1]) % 4]); glVertex3f( 1.0f, -1.0f, -1.0f);
	glEnd();

	// Back Face
	glBindTexture(GL_TEXTURE_2D, pSurface[iSkyCubeSurface[2]].pTexture[iSkyCubeSurfaceAniStep[2]]->iOpenGLID);
	pTexturePos = &pSurface[iSkyCubeSurface[2]].pTexturePos[iSkyCubeSurfaceAniStep[2]];
	glBegin(GL_QUADS);
		glTexCoord2fv(pTexturePos->fPos[(1+iSkyCubeSurfaceRotation[2]) % 4]); glVertex3f(-1.0f,  1.0f, -1.0f);
		glTexCoord2fv(pTexturePos->fPos[(2+iSkyCubeSurfaceRotation[2]) % 4]); glVertex3f(-1.0f,  1.0f,  1.0f);
		glTexCoord2fv(pTexturePos->fPos[(3+iSkyCubeSurfaceRotation[2]) % 4]); glVertex3f( 1.0f,  1.0f,  1.0f);
		glTexCoord2fv(pTexturePos->fPos[(0+iSkyCubeSurfaceRotation[2]) % 4]); glVertex3f( 1.0f,  1.0f, -1.0f);
	glEnd();

	// Front Face
	glBindTexture(GL_TEXTURE_2D, pSurface[iSkyCubeSurface[3]].pTexture[iSkyCubeSurfaceAniStep[3]]->iOpenGLID);
	pTexturePos = &pSurface[iSkyCubeSurface[3]].pTexturePos[iSkyCubeSurfaceAniStep[3]];
	glBegin(GL_QUADS);
		glTexCoord2fv(pTexturePos->fPos[(0+iSkyCubeSurfaceRotation[3]) % 4]); glVertex3f(-1.0f, -1.0f, -1.0f);
		glTexCoord2fv(pTexturePos->fPos[(1+iSkyCubeSurfaceRotation[3]) % 4]); glVertex3f( 1.0f, -1.0f, -1.0f);
		glTexCoord2fv(pTexturePos->fPos[(2+iSkyCubeSurfaceRotation[3]) % 4]); glVertex3f( 1.0f, -1.0f,  1.0f);
		glTexCoord2fv(pTexturePos->fPos[(3+iSkyCubeSurfaceRotation[3]) % 4]); glVertex3f(-1.0f, -1.0f,  1.0f);
	glEnd();

	// Right face
	glBindTexture(GL_TEXTURE_2D, pSurface[iSkyCubeSurface[4]].pTexture[iSkyCubeSurfaceAniStep[4]]->iOpenGLID);
	pTexturePos = &pSurface[iSkyCubeSurface[4]].pTexturePos[iSkyCubeSurfaceAniStep[4]];
	glBegin(GL_QUADS);
		glTexCoord2fv(pTexturePos->fPos[(0+iSkyCubeSurfaceRotation[4]) % 4]); glVertex3f( 1.0f, -1.0f, -1.0f);
		glTexCoord2fv(pTexturePos->fPos[(1+iSkyCubeSurfaceRotation[4]) % 4]); glVertex3f( 1.0f,  1.0f, -1.0f);
		glTexCoord2fv(pTexturePos->fPos[(2+iSkyCubeSurfaceRotation[4]) % 4]); glVertex3f( 1.0f,  1.0f,  1.0f);
		glTexCoord2fv(pTexturePos->fPos[(3+iSkyCubeSurfaceRotation[4]) % 4]); glVertex3f( 1.0f, -1.0f,  1.0f);
	glEnd();

    // Left Face
	glBindTexture(GL_TEXTURE_2D, pSurface[iSkyCubeSurface[5]].pTexture[iSkyCubeSurfaceAniStep[5]]->iOpenGLID);
	pTexturePos = &pSurface[iSkyCubeSurface[5]].pTexturePos[iSkyCubeSurfaceAniStep[5]];
	glBegin(GL_QUADS);
		glTexCoord2fv(pTexturePos->fPos[(1+iSkyCubeSurfaceRotation[5]) % 4]); glVertex3f(-1.0f, -1.0f, -1.0f);
		glTexCoord2fv(pTexturePos->fPos[(2+iSkyCubeSurfaceRotation[5]) % 4]); glVertex3f(-1.0f, -1.0f,  1.0f);
		glTexCoord2fv(pTexturePos->fPos[(3+iSkyCubeSurfaceRotation[5]) % 4]); glVertex3f(-1.0f,  1.0f,  1.0f);
		glTexCoord2fv(pTexturePos->fPos[(0+iSkyCubeSurfaceRotation[5]) % 4]); glVertex3f(-1.0f,  1.0f, -1.0f);

	glEnd();

	glEnable(GL_CULL_FACE);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_FOG);
	ASEnableLighting();
} // end LEVEL::DrawSkyCube()

void LEVEL::SetStandartView(void)
{ // begin LEVEL::SetStandartView()
	memset(pCamera, 0, sizeof(AS_CAMERA));
	pCamera->fPos[Z] = -15.0f+STANDART_LEVEL_Z_POS;
	pCamera->fPos[X] -= 0.0f;
	pCamera->fPos[Y] -= 0.0f;
	pCamera->fPos2[Z] = 0.0f;
	pCamera->fPos2[X] = 0.0f;
	pCamera->fPos2[Y] = 0.0f;
	pCamera->fZ = -8.0f;
} // end LEVEL::SetStandartView()

BOOL CheckTriangleCollision(AS_VECTOR StartPoint, AS_VECTOR RayDirection, AS_VECTOR *pIntersectionPoint,
							FLOAT3 Point1, FLOAT3 Point2, FLOAT3 Point3, FLOAT3 Normal)
{ // begin CheckTriangleCollision()
	AS_VECTOR p1, p2, p3, // The current triangle
			  v1, v2, // The distances between the triangle points
			  pNormal, // The normal of the triangle
			  pOrigin; // The trianlges origin
	double fDistToPlaneIntersection; // The distance from the ray start point to the triangle

	p1.x = Point1[X];
	p1.y = Point1[Y];
	p1.z = Point1[Z];

	p2.x = Point2[X];
	p2.y = Point2[Y];
	p2.z = Point2[Z];

	p3.x = Point3[X];
	p3.y = Point3[Y];
	p3.z = Point3[Z];

	// Get the triangle normal:
	pNormal.x = Normal[X];
	pNormal.y = Normal[Y];
	pNormal.z = Normal[Z];

	// Make the plane containing this triangle:
	pOrigin = p1;
	v1 = p2-p1;
	v2 = p3-p1;

	// Shoot ray along the velocity vector:
	fDistToPlaneIntersection = ASIntersectRayPlane(StartPoint, RayDirection, pOrigin, pNormal);

	// Calculate plane intersection point:
	(*pIntersectionPoint).x = (float) (StartPoint.x+fDistToPlaneIntersection*RayDirection.x);
	(*pIntersectionPoint).y = (float) (StartPoint.y+fDistToPlaneIntersection*RayDirection.y);
	(*pIntersectionPoint).z = (float) (StartPoint.z+fDistToPlaneIntersection*RayDirection.z);

	if(((*pIntersectionPoint).z < p1.z &&
	   (*pIntersectionPoint).z < p2.z &&
	   (*pIntersectionPoint).z < p3.z) ||
	   ((*pIntersectionPoint).z > p1.z &&
	    (*pIntersectionPoint).z > p2.z &&
	    (*pIntersectionPoint).z > p3.z))
		return 0; // There is something wrong!?!

	// Check if the intersection point is in the triangle:
	if(!ASCheckPointInTriangle(*pIntersectionPoint, p1, p2, p3))
		return 0; // It's not in the triangle!
	return 1; // It's in the triangle!
} // end CheckTriangleCollision()

void LEVEL::ComputeHeight(float fX, float fY, FLOAT3 fRayDirection, FLOAT3 *pfPoint, char bySide, float fSize)
{ // begin LEVEL::ComputeHeight()
	AS_VECTOR StartPoint, // The ray start point
			  RayDirection, // The ray direction (normalized)
			  pIntersectionPoint; // The found triangle intersection point
	short i, iXPos, iYPos, // Counter variables
		  iXFieldPos, iYFieldPos, // Field x/y position in the level matrix
		  iFieldID; // The field ID
	FLOAT3 fPoint1, fPoint2, fPoint3, fPoint4, fNormal;
	FIELD *pFieldT; // A pointer to the current field:
	ACTOR *pActorT;

	// Check if this is a correct point:
	if(fX < 0.0f || fY < 0.0f ||
	   fX >= pLevel->fWholeWidth || fY >= pLevel->fWholeHeight)
		return;

	// Set the start point of the ray:
	(*pfPoint)[X] = StartPoint.x = fX;
	(*pfPoint)[Y] = StartPoint.y = fY;
	(*pfPoint)[Z] = StartPoint.z = 0.0f;

	// Set the ray direction:
	RayDirection.x = fRayDirection[X];
	RayDirection.y = fRayDirection[Y];
	RayDirection.z = fRayDirection[Z];

	// Compute the current field the given point is on:
	COMPUTE_FIELD_POS(fX, fY, iXFieldPos, iYFieldPos);

	// Check the field and the fields around:
	for(iYPos = iYFieldPos-1; iYPos < iYFieldPos+1; iYPos++)
	{
		// Check if this coordinate is a correct one:
		if(iYPos < 0 || iYPos > pLevel->iHeight-2)
			continue; // No correct field!

		for(iXPos = iXFieldPos-1; iXPos < iXFieldPos+1; iXPos++)
		{
			// Check if this coordinate is a correct one:
			if(iXPos < 0 || iXPos > pLevel->iWidth-2)
				continue; // No correct field!

			// Get a pointer to this field:
			GET_FIELD_ID(iXPos, iYPos, iFieldID);
			pFieldT = &pLevel->pField[iFieldID];
			// Check the terrain:
			if(!pFieldT->pBridgeActor || pFieldT->pBridgeActor->bBridgeMovement)
			{
				for(i = 0; i < 2; i++)
				{
					if(CheckTriangleCollision(StartPoint, RayDirection, &pIntersectionPoint,
											  pLevel->fPoint[pFieldT->iFace[bySide][0]],
											  pLevel->fPoint[pFieldT->iFace[bySide][1+i]],
											  pLevel->fPoint[pFieldT->iFace[bySide][2+i]],
											  pFieldT->fNormal[bySide][i]))
					{
						if((*pfPoint)[Z] > pIntersectionPoint.z &&
						   pIntersectionPoint.x > fX-fSize &&
						   pIntersectionPoint.y > fY-fSize &&
						   pIntersectionPoint.x < fX+fSize &&
						   pIntersectionPoint.y < fY+fSize)
						{
							(*pfPoint)[X] = pIntersectionPoint.x;
							(*pfPoint)[Y] = pIntersectionPoint.y;
							(*pfPoint)[Z] = pIntersectionPoint.z;
						}
					}
				}
			}
			pActorT = pFieldT->pBridgeActor;
			if(pActorT)
				pActorT = pActorT;
			if(pActorT && !pActorT->bBridgeMovement)
			{ // There is a bridge, check it too:
				fPoint1[X] = pActorT->fWorldPos[X];
				fPoint1[Y] = pActorT->fWorldPos[Y];
				fPoint1[Z] = pActorT->fWorldPos[Z]-1.0f;

				fPoint2[X] = pActorT->fWorldPos[X]+1.0f;
				fPoint2[Y] = pActorT->fWorldPos[Y];
				fPoint2[Z] = pActorT->fWorldPos[Z]-1.0f;

				fPoint3[X] = pActorT->fWorldPos[X]+1.0f;
				fPoint3[Y] = pActorT->fWorldPos[Y]+1.0f;
				fPoint3[Z] = pActorT->fWorldPos[Z]-1.0f;

				fPoint4[X] = pActorT->fWorldPos[X];
				fPoint4[Y] = pActorT->fWorldPos[Y]+1.0f;
				fPoint4[Z] = pActorT->fWorldPos[Z]-1.0f;

				fNormal[X] = 0.0f;
				fNormal[Y] = 0.0f;
				fNormal[Z] = -1.0f;

				if(CheckTriangleCollision(StartPoint, RayDirection, &pIntersectionPoint,
									      fPoint1, fPoint2, fPoint3, fNormal) ||
				   CheckTriangleCollision(StartPoint, RayDirection, &pIntersectionPoint,
									      fPoint1, fPoint3, fPoint4, fNormal))
				{
					if((*pfPoint)[Z] > pIntersectionPoint.z)
					{
						(*pfPoint)[X] = pIntersectionPoint.x;
						(*pfPoint)[Y] = pIntersectionPoint.y;
						(*pfPoint)[Z] = pIntersectionPoint.z;
					}
				}
			}
		}
	}

	return;
} // end LEVEL::ComputeHeight()

BOOL LEVEL::GetWall(float fX, float fY)
{ // begin LEVEL::GetWall()
	short iXFieldPos, iYFieldPos;

	COMPUTE_FIELD_POS(fX, fY, iXFieldPos, iYFieldPos);
	if(iXFieldPos < 0 || iYFieldPos < 0 || iXFieldPos >= pLevel->iWidth ||
		iYFieldPos >= pLevel->iHeight)
		return 0;
	return pField[iYFieldPos*iWidth+iXFieldPos].bWall;
} // end LEVEL::GetWall()

void LEVEL::UpdateMissions(void)
{ // begin LEVEL::UpdateMissions()
	short i;
	
	iNormalBoxes = iRedBoxes = iGreenBoxes = iBlueBoxes = iForAllAnchors =
	iNormalAnchors = iRedAnchors = iGreenAnchors = iBlueAnchors = 0;
	for(i = 0; i < iFields; i++)
	{
		if((pField[i].bWall && !pField[i].pActor) || !pField[i].bActive)
			continue; // This is a wrong mission target!!
		if(pSurface[pField[i].iSurface[FACE_FLOOR]].bAnchor)
		{
			switch(pSurface[pField[i].iSurface[FACE_FLOOR]].byAnchorType)
			{
				case 0: iForAllAnchors++; break;
				case 1: iNormalAnchors++; break;
				case 2: iRedAnchors++; break;
				case 3: iGreenAnchors++; break;
				case 4: iBlueAnchors++; break;
			}
		}
	}
	for(i = 0; i < MAX_ACTORS; i++)
	{
		switch(Actor[i].byType)
		{
			case ACTOR_BOX_NORMAL: iNormalBoxes++; break;
			case ACTOR_BOX_RED: iRedBoxes++; break;
			case ACTOR_BOX_GREEN: iGreenBoxes++; break;
			case ACTOR_BOX_BLUE: iBlueBoxes++; break;
		}
	}
} // end LEVEL::UpdateMissions()

// Functions: *****************************************************************
void CreateLevel(LEVEL **pLevel)
{ // begin CreateLevel()
} // end CreateLevel()

void DestroyLevel(LEVEL **pLevel)
{ // begin DestroyLevel()
	(*pLevel)->Destroy();
	delete *pLevel;
	*pLevel = NULL;
} // end DestroyLevel()
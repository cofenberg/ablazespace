//-----------------------------------------------------------------------------
// File: Player.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"



// Variables: *****************************************************************
ACTOR *pPlayer;
PLAYER_INFO PlayerInfo;
PLAYER_IDENTITY PlayerIdentity;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
void CreateNewPlayerInfo(PLAYER_IDENTITY *, CAMPAIGN *);
void DestroyPlayerInfo(PLAYER_IDENTITY *);
void LoadPlayerIdentity(PLAYER_IDENTITY *, CAMPAIGN *);
void SavePlayerIdentity(PLAYER_IDENTITY *, CAMPAIGN *);
void DrawPlayer(void);
BOOL CheckPlayerKeys(void);
void CheckPlayer(BOOL);
BOOL CheckPlayerSurface(SURFACE *, short);
BOOL CheckPlayerPushBox(char, BOOL);
BOOL CheckPlayerPullBox(char);
BOOL CheckPlayerThrowBox(char);
BOOL CheckPlayerJump(char);
void SetPlayerToCheckpoint(void);
void MakePlayerCameraRotation(char);
///////////////////////////////////////////////////////////////////////////////


void CreateNewPlayerInfo(PLAYER_IDENTITY *pPlayerIdentity, CAMPAIGN *pCampaign)
{ // begin CreateNewPlayerInfo()
	DestroyPlayerInfo(pPlayerIdentity);
	memset(pPlayerIdentity, 0, sizeof(PLAYER_IDENTITY));
	strcpy(pPlayerIdentity->byName, "Xe");
	strcpy(pPlayerIdentity->byCampaignName, pCampaign->byName);
	pPlayerIdentity->iSelectedLevel = 1;
	if(pCampaign->iLevels)
	{
		pPlayerIdentity->iPoints = (int *) malloc(sizeof(int)*pCampaign->iLevels);
		memset(pPlayerIdentity->iPoints, 0, sizeof(int)*pCampaign->iLevels);
		pPlayerIdentity->iLives = (short *) malloc(sizeof(short)*pCampaign->iLevels);
		memset(pPlayerIdentity->iLives, 0, sizeof(short)*pCampaign->iLevels);
		pPlayerIdentity->fPower = (float *) malloc(sizeof(float)*pCampaign->iLevels);
		memset(pPlayerIdentity->fPower, 0, sizeof(float)*pCampaign->iLevels);
		pPlayerIdentity->iLives[0] = 3; // Game start lives
		pPlayerIdentity->fPower[0] = 100.0f; // Start power
	}
} // end CreateNewPlayerInfo()

void DestroyPlayerInfo(PLAYER_IDENTITY *pPlayerIdentity)
{ // begin DestroyPlayerInfo()
	SAFE_DELETE(pPlayerIdentity->iPoints);
	SAFE_DELETE(pPlayerIdentity->iLives);
	SAFE_DELETE(pPlayerIdentity->fPower);
} // end DestroyPlayerInfo()

void LoadPlayerIdentity(char *pbyName, PLAYER_IDENTITY *pPlayerIdentity, CAMPAIGN *pCampaign)
{ // begin LoadPlayerIdentity()
	char byFilename[256];
	FILE *fp;
	short i;

	sprintf(byFilename, "%s%s\\%s.id", _AS->pbyProgramPath, _AS->pbyIdentityFile, pbyName);
	_AS->WriteLogMessage("Load player identity: %s", byFilename);
	fp = fopen(byFilename, "rb");
	if(!fp)
		return;
	CreateNewPlayerInfo(pPlayerIdentity, pCampaign);
	// General info:		
	fread(&pPlayerIdentity->byName, sizeof(char)*PLAYER_NAME_LENGTH, 1, fp);
	fread(&pPlayerIdentity->byCampaignName, sizeof(char)*256, 1, fp);
	fread(&pPlayerIdentity->iFinishedLevels, sizeof(short), 1, fp);
	fread(&pPlayerIdentity->iSelectedLevel, sizeof(short), 1, fp);
	// Player info for each level of the campaign:
	for(i = 0; i < pCampaign->iLevels; i++)
	{
		fread(&pPlayerIdentity->iPoints[i], sizeof(int), 1, fp);
		fread(&pPlayerIdentity->iLives[i], sizeof(short), 1, fp);
		fread(&pPlayerIdentity->fPower[i], sizeof(float), 1, fp);
	}
	fclose(fp);
	// Check the 'all levels' cheat:
	if(bAllLevels)
	{
		// Set the not played level to standart:
		for(i = pPlayerIdentity->iFinishedLevels; i < pCampaign->iLevels; i++)
		{
			pPlayerIdentity->iPoints[i] = 0;
			pPlayerIdentity->iLives[i] = 3;
			pPlayerIdentity->fPower[i] = 100.0f;
		}
		pPlayerIdentity->iFinishedLevels = pCampaign->iLevels;
	}
	_AS->WriteLogMessage("OK");
} // end LoadPlayerIdentity()

void SavePlayerIdentity(PLAYER_IDENTITY *pPlayerIdentity, CAMPAIGN *pCampaign)
{ // begin SavePlayerIdentity()
	char byFilename[256];
	FILE *fp;
	short i;

	sprintf(byFilename, "%s%s\\%s.id", _AS->pbyProgramPath, _AS->pbyIdentityFile, pPlayerIdentity->byName);
	_AS->WriteLogMessage("Save player identity: %s", byFilename);
	fp = fopen(byFilename, "wb");
	if(!fp)
		return;
	// General info:		
	fwrite(&pPlayerIdentity->byName, sizeof(char)*PLAYER_NAME_LENGTH, 1, fp);
	fwrite(&pPlayerIdentity->byCampaignName, sizeof(char)*256, 1, fp);
	fwrite(&pPlayerIdentity->iFinishedLevels, sizeof(short), 1, fp);
	fwrite(&pPlayerIdentity->iSelectedLevel, sizeof(short), 1, fp);
	// Player info for each level of the campaign:
	for(i = 0; i < pCampaign->iLevels; i++)
	{
		fwrite(&pPlayerIdentity->iPoints[i], sizeof(int), 1, fp);
		fwrite(&pPlayerIdentity->iLives[i], sizeof(short), 1, fp);
		fwrite(&pPlayerIdentity->fPower[i], sizeof(float), 1, fp);
	}
	fclose(fp);
	_AS->WriteLogMessage("OK");
} // end SavePlayerIdentity()

void DrawPlayer(void)
{ // begin DrawPlayer()
	if(!pPlayer->bActive)
		return;
	// The player should be alway's on the screen: (if he jump's it could happen that he will be not on the screen...)
	/*
	if(!pLevel->pField[pPlayer->iFieldID].bOnScreen && !bPlayerCameraView)
	{ // The player isn't on screen;
		iCulledObjects++;
		return;
	}*/

	float fSpeed;

	if(!PlayerInfo.bSpeed)
		fSpeed = 1.0f;
	else
		fSpeed = 3.0f;	
	if(pPlayer->byAction == ACTION_JUMP)
		fSpeed /= 2.0f;
	// Calculate the world position of the player
	pPlayer->fWorldPos[X] = pPlayer->iFieldPos[X]*pLevel->fFieldWidth+pPlayer->fFieldPos[X];
	pPlayer->fWorldPos[Y] = pPlayer->iFieldPos[Y]*pLevel->fFieldHeight+pPlayer->fFieldPos[Y];
	ComputeActorHeight(pPlayer, 0.2f);
	//
	glPushMatrix();
	glEnable(GL_TEXTURE_2D);
	glCullFace(GL_FRONT);
	if(PlayerInfo.bGhost)
		glEnable(GL_BLEND);
	if(PlayerInfo.bShield)
	{
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
	}

	glColor4f(pPlayer->fColor[0], pPlayer->fColor[1], pPlayer->fColor[2], 0.99f);
	
	if(pPlayer->bGoingDeath)
	{ // The player lies dead on the floor:
		glEnable(GL_BLEND);
		float f = 1.0f-((float) (g_lNow-pPlayer->lStartTime)/PLAYER_DEAD_FLOOR_TIME);
		glColor4f(pPlayer->fColor[0], pPlayer->fColor[1], pPlayer->fColor[2], f);
	}

	glTranslatef(pPlayer->fWorldPos[X]+0.5f, pPlayer->fWorldPos[Y]+0.5f, pPlayer->fWorldPos[Z]-0.6f);
	glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
	glRotatef(-pPlayer->fRot[Y], 0.0f, 1.0f, 0.0f);
	glScalef(0.025f, 0.025f, 0.025f);
	
	if(!PlayerInfo.bShield)
	{
		if(!PlayerInfo.bWeapon && pPlayer->byAction != ACTION_SHOT)
			glBindTexture(GL_TEXTURE_2D, GameTexture[4].iOpenGLID);
		else
			glBindTexture(GL_TEXTURE_2D, GameTexture[5].iOpenGLID);
	}
	else
		glBindTexture(GL_TEXTURE_2D, GameTexture[DisplayActor[0].iAniStep].iOpenGLID);

	ASDrawMd2FrameInt(pXeModel, pPlayer->iAniStep, pPlayer->iNextAniStep, (float) (g_lNow-pPlayer->dwAniTime)/(float) (PLAYER_ANIMATION_SPEED/fSpeed));
	
	if(PlayerInfo.bWeapon || pPlayer->byAction == ACTION_SHOT)
	{
		if(!PlayerInfo.bShield)
			glBindTexture(GL_TEXTURE_2D, GameTexture[6].iOpenGLID);
		else
			glBindTexture(GL_TEXTURE_2D, GameTexture[DisplayActor[0].iAniStep].iOpenGLID);
		if(pPlayer->iAniStep < pXeWeaponModel->header.numFrames &&
		   pPlayer->iNextAniStep < pXeWeaponModel->header.numFrames )
			ASDrawMd2FrameInt(pXeWeaponModel, pPlayer->iAniStep, pPlayer->iNextAniStep, (float) (g_lNow-pPlayer->dwAniTime)/(float) (PLAYER_ANIMATION_SPEED/fSpeed));
	}
	if(_ASConfig->bDrawBounding)
		DrawBoundingBox(pXeModel->fBoundingBox, 0.025f);
	glCullFace(GL_BACK);
	glDisable(GL_BLEND);
	glPopMatrix();
	if(PlayerInfo.bShield)
	{
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	}
} // end DrawPlayer()

BOOL CheckPlayerKeys(void)
{ // begin CheckPlayerKeys()
	int byMoveKeys[4] = {_ASConfig->iRightKey, _ASConfig->iDownKey, _ASConfig->iLeftKey, _ASConfig->iUpKey};
	char byMoveRotation = 0;
	BOOL bKeyPressed = FALSE;
	ACTOR *pActorT;

	// Check if the player could do something:
	if(!pPlayer->bMove && !pPlayer->bShouldMove && pPlayer->byAction != ACTION_PLAYER_DEATH &&
		pPlayer->byAction != ACTION_SHOT && pPlayer->byAction != ACTION_PLAYER_PAIN_2 &&
		pPlayer->byAction != ACTION_PLAYER_CHECKPOINT && pPlayer->byAction != ACTION_JUMP &&
		pPlayer->fFieldPos[X] == 0.0f && pPlayer->fFieldPos[Y] == 0.0f &&
		!pPlayer->fVelocity[Z]);
	else
		return 0;

	// View dependent control:
	if(pCamera->fRot[Z] >= 315 && pCamera->fRot[Z] < 45)
		byMoveRotation = 0;
	else
	if(pCamera->fRot[Z] >= 45 && pCamera->fRot[Z] < 135)
		byMoveRotation = 1;
	else
	if(pCamera->fRot[Z] >= 135 && pCamera->fRot[Z] < 225)
		byMoveRotation = 2;
	else
	if(pCamera->fRot[Z] >= 225 && pCamera->fRot[Z] < 315)
		byMoveRotation = 3;
	if(!bPlayerCameraView && !_ASConfig->bRotateMove && !_ASConfig->bBackCamera)
	{
		if(CHECK_KEY(ASKeys, byMoveKeys[(RIGHT+byMoveRotation)%4]))
		{
			pPlayer->byDirection = RIGHT;
			if(pPlayer->fRot[Y] != 0.0f)
				return 0;
			if(!CheckPlayerPushBox(pPlayer->byDirection, TRUE))
				return 1;
			if(pPlayer->byAction != ACTION_RUN_RIGHT)
			{
				pPlayer->byAction = ACTION_RUN_RIGHT;
				pPlayer->byAnimation = 2;
				pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
				pPlayer->dwAniTime = g_lNow;
			}
		}
		else
		if(CHECK_KEY(ASKeys, byMoveKeys[(DOWN+byMoveRotation)%4]))
		{
			pPlayer->byDirection = DOWN;
			if(pPlayer->fRot[Y] != 90.0f)
				return 0;
			if(!CheckPlayerPushBox(pPlayer->byDirection, TRUE))
				return 1;
			if(pPlayer->byAction != ACTION_RUN_DOWN)
			{
				pPlayer->byAction = ACTION_RUN_DOWN;
				pPlayer->byAnimation = 2;
				pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
				pPlayer->dwAniTime = g_lNow;
			}
		}
		else
		if(CHECK_KEY(ASKeys, byMoveKeys[(LEFT+byMoveRotation)%4]))
		{
			pPlayer->byDirection = LEFT;
			if(pPlayer->fRot[Y] != 180.0f)
				return 0;
			if(!CheckPlayerPushBox(pPlayer->byDirection, TRUE))
				return 1;
			if(pPlayer->byAction != ACTION_RUN_LEFT)
			{
				pPlayer->byAction = ACTION_RUN_LEFT;
				pPlayer->byAnimation = 2;
				pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
				pPlayer->dwAniTime = g_lNow;
			}
		}
		else
		if(CHECK_KEY(ASKeys, byMoveKeys[(UP+byMoveRotation)%4]))
		{
			pPlayer->byDirection = UP;
			if(pPlayer->fRot[Y] != 270.0f)
				return 0;
			if(!CheckPlayerPushBox(pPlayer->byDirection, TRUE))
				return 1;
			if(pPlayer->byAction != ACTION_RUN_UP)
			{
				pPlayer->byAction = ACTION_RUN_UP;
				pPlayer->byAnimation = 2;
				pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
				pPlayer->dwAniTime = g_lNow;
			}
		}
	}
	else
	{
		if(pPlayer->byDirection == RIGHT && pPlayer->fRot[Y] != 0.0f)
			return 0;
		else
		if(pPlayer->byDirection == DOWN && pPlayer->fRot[Y] != 90.0f)
			return 0;
		else
		if(pPlayer->byDirection == LEFT && pPlayer->fRot[Y] != 180.0f)
			return 0;
		else
		if(pPlayer->byDirection == UP && pPlayer->fRot[Y] != 270.0f)
			return 0;

		if(CHECK_KEY(ASKeys, byMoveKeys[RIGHT]) && pPlayer->byAction2 == -1)
		{
			pPlayer->byDirection++;
			if(pPlayer->byDirection > 3)
				pPlayer->byDirection = 0;
		}
		else
		if(CHECK_KEY(ASKeys, byMoveKeys[LEFT]) && pPlayer->byAction2 == -1)
		{
			pPlayer->byDirection--;
			if(pPlayer->byDirection < 0)
				pPlayer->byDirection = 3;
		}
		else
		if(CHECK_KEY(ASKeys, byMoveKeys[DOWN]))
		{
			if(!CheckPlayerPushBox((pPlayer->byDirection+2) % 4, TRUE))
			{
				pPlayer->byAction2 = ACTION_PULL_RIGHT+((pPlayer->byDirection+2) % 4);
				return 1;
			}
			if(pPlayer->byAction == ACTION_PLAYER_PAIN_1 ||
			   pPlayer->byAction == ACTION_PLAYER_HEALTH)
				pPlayer->byAction2 = -1;
			pPlayer->byAction = -1;				
			if(pPlayer->byAction2 != ACTION_PULL_RIGHT+((pPlayer->byDirection+2) % 4))
			{
				pPlayer->byAction2 = ACTION_PULL_RIGHT+((pPlayer->byDirection+2) % 4);
				pPlayer->byAnimation = 2;
				pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
				pPlayer->dwAniTime = g_lNow;
			}
			bKeyPressed = TRUE;
		}
		else
		{
			if(CHECK_KEY(ASKeys, byMoveKeys[UP]) && pPlayer->byAction2 == -1)
			{
				if(!CheckPlayerPushBox(pPlayer->byDirection, TRUE))
					return 1;
				if(pPlayer->byAction != ACTION_RUN_UP)
				{
					pPlayer->byAction = ACTION_RUN_UP;
					pPlayer->byAnimation = 2;
					pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
					pPlayer->dwAniTime = g_lNow;
				}
			}
		}
	}
	if(bKeyPressed)
		return 0;
	if(CHECK_KEY(ASKeys, _ASConfig->iPullKey))
	{ // Pull a box:
		if(pPlayer->byAction == ACTION_PLAYER_PAIN_1 ||
		   pPlayer->byAction == ACTION_PLAYER_HEALTH)
			pPlayer->byAction2 = -1;
		if(pPlayer->byDirection == RIGHT && pPlayer->fRot[Y] != 0.0f)
			return 0;
		else
		if(pPlayer->byDirection == DOWN && pPlayer->fRot[Y] != 90.0f)
			return 0;
		else
		if(pPlayer->byDirection == LEFT && pPlayer->fRot[Y] != 180.0f)
			return 0;
		else
		if(pPlayer->byDirection == UP && pPlayer->fRot[Y] != 270.0f)
			return 0;
		switch(pPlayer->byDirection)
		{
			case RIGHT:
				if(!CheckPlayerPullBox(pPlayer->byDirection))
					return 1;
				// Move the player:
				pPlayer->bMove = TRUE;
				if(pPlayer->byAction2 != ACTION_PULL_LEFT)
				{
					pPlayer->byAction2 = ACTION_PULL_LEFT;
					pPlayer->byAnimation = 2;
					pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
					pPlayer->dwAniTime = g_lNow;
				}
			break;

			case DOWN:
				if(!CheckPlayerPullBox(pPlayer->byDirection))
					return 1;
				// Move the player:
				pPlayer->bMove = TRUE;
				if(pPlayer->byAction2 != ACTION_PULL_UP)
				{
					pPlayer->byAction2 = ACTION_PULL_UP;
					pPlayer->byAnimation = 2;
					pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
					pPlayer->dwAniTime = g_lNow;
				}
			break;

			case LEFT:
				if(!CheckPlayerPullBox(pPlayer->byDirection))
					return 1;
				// Move the player:
				pPlayer->bMove = TRUE;
				if(pPlayer->byAction2 != ACTION_PULL_RIGHT)
				{
					pPlayer->byAction2 = ACTION_PULL_RIGHT;
					pPlayer->byAnimation = 2;
					pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
					pPlayer->dwAniTime = g_lNow;
				}
			break;

			case UP:
				if(!CheckPlayerPullBox(pPlayer->byDirection))
					return 1;
	  			// Move the player:
				pPlayer->bMove = TRUE;
				if(pPlayer->byAction2 != ACTION_PULL_DOWN)
				{
					pPlayer->byAction2 = ACTION_PULL_DOWN;
					pPlayer->byAnimation = 2;
					pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
					pPlayer->dwAniTime = g_lNow;
				}
			break;
		}
	}
	else
	{
		if(pPlayer->byAction2 != -1)
		{
			pPlayer->byAction2 = -1;
			pPlayer->byAction = -1;
		}
		if(CHECK_KEY(ASKeys, _ASConfig->iThrowKey))
		{ // Throw a box:
			if(pPlayer->byDirection == RIGHT && pPlayer->fRot[Y] != 0.0f)
				return 0;
			else
			if(pPlayer->byDirection == DOWN && pPlayer->fRot[Y] != 90.0f)
				return 0;
			else
			if(pPlayer->byDirection == LEFT && pPlayer->fRot[Y] != 180.0f)
				return 0;
			else
			if(pPlayer->byDirection == UP && pPlayer->fRot[Y] != 270.0f)
				return 0;
			if(!CheckPlayerThrowBox(pPlayer->byDirection))
				return 1;
			pCamera->fRot2Velocity[0] = 0.0f;
			pCamera->fRot2Velocity[1] = 0.0f;
			pCamera->fRot2Velocity[1] = 0.0f;
			MakePlayerCameraRotation(ACTION_PLAYER_PAIN_1);
		}
		else
		if(CHECK_KEY(ASKeys, _ASConfig->iJumpKey))
		{ // Jump:
			if(PlayerInfo.bJump)
			{
				if(pPlayer->byDirection == RIGHT && pPlayer->fRot[Y] != 0.0f)
					return 0;
				else
				if(pPlayer->byDirection == DOWN && pPlayer->fRot[Y] != 90.0f)
					return 0;
				else
				if(pPlayer->byDirection == LEFT && pPlayer->fRot[Y] != 180.0f)
					return 0;
				else
				if(pPlayer->byDirection == UP && pPlayer->fRot[Y] != 270.0f)
					return 0;
				if(!CheckPlayerJump(pPlayer->byDirection))
					return 1;
				pCamera->fRot2Velocity[0] = 0.0f;
				pCamera->fRot2Velocity[1] = 0.0f;
				pCamera->fRot2Velocity[1] = 0.0f;
				MakePlayerCameraRotation(ACTION_SHOT);
				pPlayer->bShouldMove = TRUE;
				pPlayer->bThrow = TRUE;
			}
		}
		else
		if(CHECK_KEY(ASKeys, _ASConfig->iSuicideKey))
		{ // Self destruction:
			if(pPlayer->byAction != ACTION_PLAYER_PAIN_2)
			{
				pCamera->fRot2Velocity[0] = 0.0f;
				pCamera->fRot2Velocity[1] = 0.0f;
				pCamera->fRot2Velocity[1] = 0.0f;
				MakePlayerCameraRotation(ACTION_PLAYER_PAIN_2);
				pPlayer->fPower /= 2.0f;
				if(pPlayer->fPower < 2.0f)
					pPlayer->fPower = 0.0f;
				pPlayer->byAction = ACTION_PLAYER_PAIN_2;
				pPlayer->byAnimation = 4;
				pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
				pPlayer->dwAniTime = g_lNow;
			}
		}
		else
		if(CHECK_KEY(ASKeys, _ASConfig->iShotKey) || (bPlayerCameraView && CHECK_KEY(ASMouse.byButtons, 0)))
		{ // Shot:
			if(PlayerInfo.bWeapon && !PlayerInfo.bGhost)
			{	// Create the shot:
				pActorT	= FindFreeActor();
				if(!pActorT)
					return 1;
				if(pPlayer->byDirection == RIGHT && pPlayer->fRot[Y] != 0.0f)
					return 0;
				else
				if(pPlayer->byDirection == DOWN && pPlayer->fRot[Y] != 90.0f)
					return 0;
				else
				if(pPlayer->byDirection == LEFT && pPlayer->fRot[Y] != 180.0f)
					return 0;
				else
				if(pPlayer->byDirection == UP && pPlayer->fRot[Y] != 270.0f)
					return 0;
				pActorT->bActive = TRUE;
				pActorT->fWorldPos[X] = pPlayer->fWorldPos[X];
				pActorT->fWorldPos[Y] = pPlayer->fWorldPos[Y];
				pActorT->fWorldPos[Z] = pPlayer->fWorldPos[Z]-0.1f;
				if(pPlayer->byDirection == RIGHT)
				{
					pActorT->fWorldPos[X] += 0.6f;
					pActorT->fWorldPos[Y] += 0.25f;
				}
				else
				if(pPlayer->byDirection == DOWN)
				{
					pActorT->fWorldPos[X] -= 0.25f;
					pActorT->fWorldPos[Y] += 0.6f;
				}
				else
				if(pPlayer->byDirection == LEFT)
				{
					pActorT->fWorldPos[X] -= 0.6f;
					pActorT->fWorldPos[Y] -= 0.25f;
				}
				else
				if(pPlayer->byDirection == UP)
				{
					pActorT->fWorldPos[X] += 0.25f;
					pActorT->fWorldPos[Y] -= 0.6f;
				}
				
				pActorT->fSize = 1.0f;
				pActorT->byType = ACTOR_PLAYER_SHOT;
				pActorT->byDirection = pPlayer->byDirection;

				// Shot animation:
				pPlayer->byAction = ACTION_SHOT;
				pPlayer->byAnimation = 3;
				pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
				pPlayer->dwAniTime = g_lNow;
				pCamera->fRot2Velocity[0] = 0.0f;
				pCamera->fRot2Velocity[1] = 0.0f;
				pCamera->fRot2Velocity[1] = 0.0f;
				MakePlayerCameraRotation(ACTION_SHOT);
				if(!pLevel->bUnlimitedWeapon)
				{				
					PlayerInfo.iWeaponShots--;
					if(PlayerInfo.iWeaponShots <= 0)
						PlayerInfo.bWeapon = FALSE;
				}
				pPlayer->bMove = pPlayer->bShouldMove = FALSE;
			}
			else
				return 1;
		}
		else
		if(!pPlayer->bShouldMove && !pPlayer->bMove && pPlayer->byAction != ACTION_STAND &&
		   pPlayer->byAction != ACTION_SHOT && pPlayer->byAction != ACTION_PLAYER_PAIN_1 &&
		   pPlayer->byAction != ACTION_PLAYER_PAIN_2 && pPlayer->byAction != ACTION_PLAYER_PAIN_3 &&
		   pPlayer->byAction != ACTION_PLAYER_HEALTH && pPlayer->byAction !=ACTION_JUMP)
		{
			pPlayer->byAction = ACTION_STAND;
			pPlayer->byAnimation = 1;
			pPlayer->iAniStep = 0;
			pPlayer->dwAniTime = g_lNow;
		}
	}
	if(pPlayer->byAction == ACTION_STAND && pPlayer->byAction2 == -1)
		MakePlayerCameraRotation(ACTION_STAND);
	return 0;
} // end CheckPlayerKeys()

void CheckPlayer(BOOL bEditor)
{ // begin CheckPlayer()
	FIELD *pFieldT;
	SURFACE *pSurfaceT;
	short i, i2, iX, iY;
	float fSpeed;

	if(!pPlayer->bActive)
		return;
	
	if(!PlayerInfo.bSpeed)
		fSpeed = 1.0f;
	else
		fSpeed = 3.0f;	
	GET_FIELD_ID(pPlayer->iFieldPos[X], pPlayer->iFieldPos[Y], pPlayer->iFieldID)
	pFieldT = &pLevel->pField[pPlayer->iFieldID];

	if(bEditor)
	{
		pPlayer->byAnimation = 1;
		goto AnimatePlayer;
	}	
	pPlayer->fWorldPos[Z] += g_lDeltatime*pPlayer->fVelocity[Z];
	if(pPlayer->bGoingDeath)
		pCamera->fRot2Velocity[X] = -0.02f*g_lDeltatime;
	if(pPlayer->bGoingDeath)
	{
		// Check if the player press any key:
		for(i = 0; i < 256; i++)
		{
			if(ASKeyFirst[i])
			{
				ASKeyFirst[i] = ASKeys[i] = FALSE;
				pPlayer->lStartTime = g_lNow+PLAYER_DEAD_FLOOR_TIME;
				break;
			}
			ASKeyFirst[i] = FALSE;
		}
		goto AnimatePlayer;
	}

	// Check the player keys:
	if(CheckPlayerKeys())
	{ // The player makes something stupied...
		// Is there a wall we have to check?
		// Setup x/y direction:
		if(pPlayer->byAction2 == ACTION_PULL_RIGHT ||
		   pPlayer->byAction2 == ACTION_PULL_DOWN ||
		   pPlayer->byAction2 == ACTION_PULL_LEFT ||
		   pPlayer->byAction2 == ACTION_PULL_UP)
		{
			switch(pPlayer->byDirection)
			{
				case RIGHT: iX = -1; iY = 0; break;
				case DOWN: iX = 0; iY = -1; break;
				case LEFT: iX = 1; iY = 0; break;
				case UP: iX = 0; iY = 1; break;
			}
		}
		else
		{
			switch(pPlayer->byDirection)
			{
				case RIGHT: iX = 1; iY = 0; break;
				case DOWN: iX = 0; iY = 1; break;
				case LEFT: iX = -1; iY = 0; break;
				case UP: iX = 0; iY = -1; break;
			}
		}
		if(pPlayer->iFieldPos[X]+iX < 0 || pPlayer->iFieldPos[X]+iX >= pLevel->iWidth-1 ||
		   pPlayer->iFieldPos[Y]+iY < 0 || pPlayer->iFieldPos[Y]+iY >= pLevel->iHeight-1 ||
		   (pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->iWidth+pPlayer->iFieldPos[X]+iX].bWall &&
   		    pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->iWidth+pPlayer->iFieldPos[X]+iX].pActor))
			goto WrongAction;
		// Yes! Check the wall surface:
		GET_FIELD_ID(pPlayer->iFieldPos[X]+iX, pPlayer->iFieldPos[Y]+iY, i);
		i = (pPlayer->iFieldPos[Y]+iY)*pLevel->iWidth+pPlayer->iFieldPos[X]+iX;

		if(pPlayer->byAction2 == ACTION_PULL_RIGHT ||
		   pPlayer->byAction2 == ACTION_PULL_DOWN ||
		   pPlayer->byAction2 == ACTION_PULL_LEFT ||
		   pPlayer->byAction2 == ACTION_PULL_UP)
		{
			switch(pPlayer->byDirection)
			{
				case RIGHT: pSurfaceT = &pLevel->pSurface[pLevel->pField[i].iSurface[FACE_RIGHT]]; break;
				case DOWN: pSurfaceT = &pLevel->pSurface[pLevel->pField[i].iSurface[FACE_BOTTOM]]; break;
				case LEFT: pSurfaceT = &pLevel->pSurface[pLevel->pField[i].iSurface[FACE_LEFT]]; break;
				case UP: pSurfaceT = &pLevel->pSurface[pLevel->pField[i].iSurface[FACE_TOP]]; break;
			}
		}
		else
		{
			switch(pPlayer->byDirection)
			{
				case RIGHT: pSurfaceT = &pLevel->pSurface[pLevel->pField[i].iSurface[FACE_LEFT]]; break;
				case DOWN: pSurfaceT = &pLevel->pSurface[pLevel->pField[i].iSurface[FACE_TOP]]; break;
				case LEFT: pSurfaceT = &pLevel->pSurface[pLevel->pField[i].iSurface[FACE_RIGHT]]; break;
				case UP: pSurfaceT = &pLevel->pSurface[pLevel->pField[i].iSurface[FACE_BOTTOM]]; break;
			}
		}
		if(CheckPlayerSurface(pSurfaceT, 0))
			goto Next;


	WrongAction:
		if(pPlayer->byAction2 != -1)
			pPlayer->byAction2 = -1;
		if(pPlayer->byAction != ACTION_WRONG && pPlayer->byAction2 == -1 && !pPlayer->bMove && !pPlayer->bShouldMove)
		{
			pPlayer->byAction = ACTION_WRONG;
			pPlayer->byAnimation = 6;
			pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
			pPlayer->dwAniTime = g_lNow;
		}
	}
Next:
	if(pPlayer->byAction == ACTION_JUMP)
		fSpeed /= 2.0f;
	// Turn the players direction smoothly:
	if(pPlayer->byDirection == RIGHT && pPlayer->fRot[Y] != 0.0f)
	{ // Turn to right:
		if(pPlayer->fRot[Y] > 180.0f)
		{
			pPlayer->fRot[Y] += g_lDeltatime/PLAYER_TURN_SPEED*fSpeed;
			if(pPlayer->fRot[Y] > 360.0f)
				pPlayer->fRot[Y] = 0.0f;
		}
		else
		if(pPlayer->fRot[Y] > 0.0f)
		{
			pPlayer->fRot[Y] -= g_lDeltatime/PLAYER_TURN_SPEED*fSpeed;
			if(pPlayer->fRot[Y] < 0.0f)
				pPlayer->fRot[Y] = 0.0f;
		}
		else
		{
			pPlayer->fRot[Y] += g_lDeltatime/PLAYER_TURN_SPEED*fSpeed;
			if(pPlayer->fRot[Y] > 0.0f)
				pPlayer->fRot[Y] = 0.0f;
		}
	}
	else
	if(pPlayer->byDirection == DOWN && pPlayer->fRot[Y] != 90.0f)
	{ // Turn to down:
		if(pPlayer->fRot[Y] > 90.0f)
		{
			pPlayer->fRot[Y] -= g_lDeltatime/PLAYER_TURN_SPEED*fSpeed;
			if(pPlayer->fRot[Y] < 90.0f)
				pPlayer->fRot[Y] = 90.0f;
		}
		else
		{
			pPlayer->fRot[Y] += g_lDeltatime/PLAYER_TURN_SPEED*fSpeed;
			if(pPlayer->fRot[Y] > 90.0f)
				pPlayer->fRot[Y] = 90.0f;
		}
	}
	else
	if(pPlayer->byDirection == LEFT && pPlayer->fRot[Y] != 180.0f)
	{ // Turn to left:
		if(pPlayer->fRot[Y] > 180.0f)
		{
			pPlayer->fRot[Y] -= g_lDeltatime/PLAYER_TURN_SPEED*fSpeed;
			if(pPlayer->fRot[Y] < 180.0f)
				pPlayer->fRot[Y] = 180.0f;
		}
		else
		{
			pPlayer->fRot[Y] += g_lDeltatime/PLAYER_TURN_SPEED*fSpeed;
			if(pPlayer->fRot[Y] > 180.0f)
				pPlayer->fRot[Y] = 180.0f;
		}
	}
	else
	if(pPlayer->byDirection == UP && pPlayer->fRot[Y] != 270.0f)
	{ // Turn to up:
		if(pPlayer->fRot[Y] < 90.0f)
		{
			pPlayer->fRot[Y] -= g_lDeltatime/PLAYER_TURN_SPEED*fSpeed;
			if(pPlayer->fRot[Y] < -90.0f)
				pPlayer->fRot[Y] = 270.0f;
		}
		else
		if(pPlayer->fRot[Y] > 270.0f)
		{
			pPlayer->fRot[Y] -= g_lDeltatime/PLAYER_TURN_SPEED*fSpeed;
			if(pPlayer->fRot[Y] < 270.0f)
				pPlayer->fRot[Y] = 270.0f;
		}
		else
		{
			pPlayer->fRot[Y] += g_lDeltatime/PLAYER_TURN_SPEED*fSpeed;
			if(pPlayer->fRot[Y] > 270.0f)
				pPlayer->fRot[Y] = 270.0f;
		}
	}
// Move the player:
	else
	{
		if(pPlayer->bShouldMove)
		{
			// The player is ready for moving:
			pPlayer->bShouldMove = FALSE;
			pPlayer->bMove = TRUE;
			// Ok, we could now move the boxes:
			for(i = 0; i < MAX_ACTORS; i++)
			{
				if(!Actor[i].bShouldMove)
					continue;
				Actor[i].bShouldMove = FALSE;
				Actor[i].bMove = TRUE;
			}
		}
		if(pPlayer->byAction != ACTION_PLAYER_CHECKPOINT)
		{
			MoveActor(pPlayer, PLAYER_MOVE_SPEED);
			if(pPlayer->bShouldMove || pPlayer->bMove)
				MakePlayerCameraRotation(ACTION_RUN_RIGHT);
		}
	}

	// Check the field the player is on:
	GET_FIELD_ID(pPlayer->iFieldPos[X], pPlayer->iFieldPos[Y], pPlayer->iFieldID)
	pFieldT = &pLevel->pField[pPlayer->iFieldID];

	// Check if the player collects a object:
	if(pFieldT->pObject && pFieldT->pObject->bActive && !pFieldT->pObject->bGoingDeath && pPlayer->fFieldPos[X] == 0.0f &&
	   pPlayer->fFieldPos[Y] == 0.0f && !PlayerInfo.bGhost && pPlayer->byAction != ACTION_JUMP && !pPlayer->fVelocity[Z])
	{ // Yes, he do it:
		pFieldT->pObject->bGoingDeath = TRUE;
		switch(pFieldT->pObject->byType)
		{
			case ACTOR_HEALTH_OBJ:
				pPlayer->fPower += HEALTH_OBJ_NUMBER;
			break;

			case ACTOR_LIVE_OBJ:
				PlayerInfo.iLives += LIVE_OBJ_NUMBER;
			break;
			
			case ACTOR_PULL_OBJ:
				PlayerInfo.bPullBoxes = TRUE;
				PlayerInfo.iPullBoxes += PULL_OBJ_NUMBER;
			break;
			
			case ACTOR_THROW_OBJ:
				PlayerInfo.bThrowBoxes = TRUE;
				PlayerInfo.iThrowBoxes += THROW_OBJ_NUMBER;
			break;

			case ACTOR_FORCE_OBJ:
				PlayerInfo.iForce += FORCE_OBJ_NUMBER;
				PlayerInfo.fForce = 1.0f;
			break;
			
			case ACTOR_WEAPON_OBJ:
				PlayerInfo.bWeapon = TRUE;
				PlayerInfo.iWeaponShots += WEAPON_OBJ_NUMBER;
			break;

			case ACTOR_POINT_OBJ:
				PlayerInfo.iPoints += POINT_OBJ_NUMBER;
				iCollectedPoints++;
			break;

			case ACTOR_GHOST_OBJ:
				PlayerInfo.bGhost = TRUE;
				PlayerInfo.lGhostTime = g_lNow;
				pLevel->pField[pPlayer->iFieldID].pActor = NULL;
			break;

			case ACTOR_TIME_OBJ:
				if(pLevel->bTimeLimit)
					pLevel->iTimeLimit += TIME_OBJ_NUMBER;
				else
				{
					pLevel->iTimeLimit -= TIME_OBJ_NUMBER;
					if(pLevel->iTimeLimit < 0)
						pLevel->iTimeLimit = 0;
				}
			break;

			case ACTOR_STEP_OBJ:
				if(pLevel->bStepsLimit)
					pLevel->iStepsLimit += STEPS_OBJ_NUMBER;
				else
				{
					pLevel->iStepsLimit -= STEPS_OBJ_NUMBER;
					if(pLevel->iStepsLimit < 0)
						pLevel->iStepsLimit = 0;
				}
			break;

			case ACTOR_SPEED_OBJ:
				PlayerInfo.bSpeed = TRUE;
				PlayerInfo.lSpeedTime = g_lNow;
			break;

			case ACTOR_WING_OBJ:
				PlayerInfo.bWing = TRUE;
				PlayerInfo.lWingTime = g_lNow;
			break;

			case ACTOR_SHIELD_OBJ:
				PlayerInfo.bShield = TRUE;
				PlayerInfo.lShieldTime = g_lNow;
			break;

			case ACTOR_JUMP_OBJ:
				PlayerInfo.bJump = TRUE;
				PlayerInfo.iJump += JUMP_OBJ_NUMBER;
			break;

			case ACTOR_AIR_OBJ:
				pPlayer->fAir = 1.0f;
			break;
		}
		pFieldT->pObject = NULL;
	}

	if(!PlayerInfo.bGhost && pPlayer->byAction != ACTION_PLAYER_DEATH && pPlayer->byAction != ACTION_JUMP)
	{
		// Check the fields it selves:
		for(i = 0; i < 2; i++)
		{
			if(!i)
				GET_FIELD_ID(pPlayer->iFieldPos[X], pPlayer->iFieldPos[Y], i2)
			else
			{
				if(pPlayer->bMove)
					break;
				if(pPlayer->byAction == ACTION_RUN_RIGHT)
					GET_FIELD_ID((pPlayer->iFieldPos[X]-1), pPlayer->iFieldPos[Y], i2)
				else
				if(pPlayer->byAction == ACTION_RUN_DOWN)
					GET_FIELD_ID(pPlayer->iFieldPos[X], (pPlayer->iFieldPos[Y]-1), i2)
				else
				if(pPlayer->byAction == ACTION_RUN_LEFT)
					GET_FIELD_ID((pPlayer->iFieldPos[X]+1), pPlayer->iFieldPos[Y], i2)
				else
				if(pPlayer->byAction == ACTION_RUN_UP)
					GET_FIELD_ID(pPlayer->iFieldPos[X], (pPlayer->iFieldPos[Y]+1), i2)
				else
					break;
			}
			pFieldT = &pLevel->pField[i2];
			if(!pFieldT->bActive)
				break;
			if(!pFieldT->pBridgeActor)
			{
				pSurfaceT = &pLevel->pSurface[pFieldT->iSurface[FACE_FLOOR]];
				CheckPlayerSurface(pSurfaceT, pFieldT->iID);
			}
		}
	}

	// Check ghost mode:
	if(g_lNow-PlayerInfo.lGhostTime > GHOST_TIME && PlayerInfo.bGhost)
	{ // The ghost time is left!
		// Check if the player is in a wall or an actor:
		if(pLevel->pField[pPlayer->iFieldID].bWall ||
		   pLevel->pField[pPlayer->iFieldID].pActor)
		{ // Yea, we are in a object... that hurts!
			pPlayer->fPower -= (float) g_lDeltatime/500;
		}
		else
		{ // Deactivate this mode:
			PlayerInfo.bGhost = FALSE;
			pLevel->pField[pPlayer->iFieldID].pActor = pPlayer;
		}
	}
	// Check the speed modus:
	if(g_lNow-PlayerInfo.lSpeedTime > SPEED_TIME && PlayerInfo.bSpeed)
	{ // The speed time is left!
		PlayerInfo.bSpeed = FALSE;
	}
	if(!pPlayer->bMove)
	{
		if(PlayerInfo.bSpeed)
			pPlayer->fVelocity[0] = PLAYER_MOVE_SPEED/3;
		else
			pPlayer->fVelocity[0] = PLAYER_MOVE_SPEED;
	}
	// Check the wing modus:
	if(g_lNow-PlayerInfo.lWingTime > WING_TIME && PlayerInfo.bWing)
	{ // The wing time is left!
		PlayerInfo.bWing = FALSE;
	}
	// Check the shield modus:
	if(g_lNow-PlayerInfo.lShieldTime > SHIELD_TIME && PlayerInfo.bShield)
	{ // The shield time is left!
		PlayerInfo.bShield = FALSE;
	}
	
	if(!pLevel->pField[pPlayer->iFieldID].bActive && !PlayerInfo.bWing)
	{ // The player falls in a hole:
		if(pPlayer->bMove)
		{ // Maybe, the player has a change!
			// Setup x/y direction:
			switch(pPlayer->byDirection)
			{
				case RIGHT: iX = 1; iY = 0; break;
				case DOWN: iX = 0; iY = 1; break;
				case LEFT: iX = -1; iY = 0; break;
				case UP: iX = 0; iY = -1; break;
			}
			pFieldT = &pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->iWidth+pPlayer->iFieldPos[X]+iX];
			if(pFieldT->bActive)
				goto NoFall;
		}
		pPlayer->fPower = 0.0f;
		pPlayer->fVelocity[Z] = 0.005f;
	}
NoFall:

	// Check the water:
	// Check the players air:
	if(pPlayer->fWorldPos[Z]-0.7f > pLevel->fWaterActualHeight)
	{ // The player is under water:
		pPlayer->fAir -= (float) g_lDeltatime/10000;
		if(pPlayer->fAir < 0.0f)
		{
			pPlayer->fAir = 0.0f;
			pPlayer->fPower -= (float) g_lDeltatime/50;
		}
	}
	else
	{
		pPlayer->fAir += (float) g_lDeltatime/5000;
		if(pPlayer->fAir > 1.0f)
			pPlayer->fAir = 1.0f;
	}
	if(pPlayer->fWorldPos[Z] > pLevel->fWaterActualHeight && pPlayer->byAction != ACTION_JUMP &&
	   !PlayerInfo.bGhost && !PlayerInfo.bShield)
	{
		// Is the water acid?
		if(pLevel->bWaterAcid)
		{ // The player get hurt:
			pPlayer->fPower -= (float) g_lDeltatime/50;
		}
		else // Is the water lava?
		if(pLevel->bWaterLava)
		{ // The player is now dead!
			pPlayer->fPower = 0.0f;
		}
	}

	if(bInvulnerable)
	{ // The player could't die:
		pPlayer->fPower = 100.0f;
		pPlayer->fVelocity[Z] = 0.0f;
	}
	// Check the players power:
	if(pPlayer->fPower <= 0.0f)
	{
		pPlayer->fPower = 0.0f;
		pPlayer->byAction2 = -1;
		if(pPlayer->byAction != ACTION_PLAYER_DEATH)
		{
			DeadSmileyActor.iAniStep = pDeadSmileyModel->Ani.anim[9].firstFrame;
			pPlayer->byAction = ACTION_PLAYER_DEATH;
			pPlayer->byAnimation = 16;
			pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
			pPlayer->dwAniTime = g_lNow;
		}
	}


AnimatePlayer:	
	// Rotate the shield:		
	PlayerInfo.fShieldRot[X] += (float) g_lDeltatime/SHIELD_ROTATE_SPEED;
	PlayerInfo.fShieldRot[Y] += (float) g_lDeltatime/SHIELD_ROTATE_SPEED;
	PlayerInfo.fShieldRot[Z] += (float) g_lDeltatime/SHIELD_ROTATE_SPEED;
	// Normalize the players
	for(i = 0; i < 3; i++)
		if(pPlayer->fColor[i] < 1.0f)
		{
			pPlayer->fColor[i] += (float) g_lDeltatime/PLAYER_PAINT_SPEED;
			if(pPlayer->fColor[i] > 1.0f)
				pPlayer->fColor[i] = 1.0f;
		}	
	if(pPlayer->bGoingDeath)
	{ // The player lies dead on the floor:
		pPlayer->dwAniTime = g_lNow;
		pPlayer->iNextAniStep = pPlayer->iAniStep = 183;
		if(g_lNow-pPlayer->lStartTime > PLAYER_DEAD_FLOOR_TIME)
		{ // Move the player to the last checkpoint:
			pPlayer->bGoingDeath = FALSE;
			
			// Was the player hunted by the Okta? If yes does he hit the player?
			if(OktaActor.bActive && OktaActor.bThrow)
			{ // Yes! Restart the Level:
				StartCurrentLevel();
			}
		
			PlayerInfo.iLives--;
			if(PlayerInfo.iLives < 0)
			{ // Game over!
				memset(pPlayer->fVelocity, 0, sizeof(FLOAT3));
				bInGameMenu = TRUE;
				return;
			}
			else
			{
				pPlayer->fPower = 100.0f;
				SetPlayerToCheckpoint();
			}
		}
		return;
	}
	pPlayer->dwAniDeltaTime = g_lNow-pPlayer->dwAniTime;
	// Animate the player:
	if(pPlayer->byAction2 == ACTION_PULL_RIGHT ||
	   pPlayer->byAction2 == ACTION_PULL_DOWN ||
	   pPlayer->byAction2 == ACTION_PULL_LEFT ||
	   pPlayer->byAction2 == ACTION_PULL_UP)
	{ // We pull something: (Turn animation replay)
		pPlayer->iNextAniStep = pPlayer->iAniStep-1;
		if(pPlayer->iNextAniStep < pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame)
			pPlayer->iNextAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].lastFrame-1;
		if(g_lNow-pPlayer->dwAniTime > PLAYER_ANIMATION_SPEED/fSpeed)
		{
			pPlayer->dwAniTime = g_lNow;
			pPlayer->iAniStep--;
			if(pPlayer->iAniStep < pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame)
				pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].lastFrame-1;
		}
	}
	else
	{
		pPlayer->iNextAniStep = pPlayer->iAniStep+1;
		if(pPlayer->byAction == ACTION_PLAYER_DEATH && pPlayer->iNextAniStep == 183)
		{ // The player lies now a few seconds on the floor:
			pPlayer->bGoingDeath = TRUE;
			pPlayer->lStartTime = g_lNow;
		}
		if(pPlayer->iNextAniStep >= pXeModel->Ani.anim[pPlayer->byAnimation].lastFrame)
		{
			if(pPlayer->byAction != ACTION_SHOT && pPlayer->byAction != ACTION_PLAYER_PAIN_2 &&
			   pPlayer->byAction != ACTION_PLAYER_CHECKPOINT && pPlayer->byAction != ACTION_PLAYER_PAIN_1 &&
			   pPlayer->byAction != ACTION_PLAYER_HEALTH)
				pPlayer->iNextAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
			else
				pPlayer->byAction = pPlayer->byAction2 = -1;
		}
		float f = (float) PLAYER_ANIMATION_SPEED/fSpeed;
		if(g_lNow-pPlayer->dwAniTime > ((float) PLAYER_ANIMATION_SPEED/fSpeed))
		{
			pPlayer->dwAniTime = g_lNow;
			pPlayer->iAniStep++;
			if(pPlayer->iAniStep >= pXeModel->Ani.anim[pPlayer->byAnimation].lastFrame)
				pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
		}
	}
	GET_FIELD_ID(pPlayer->iFieldPos[X], pPlayer->iFieldPos[Y], pPlayer->iFieldID)
} // end CheckPlayer()

BOOL CheckPlayerSurface(SURFACE *pSurfaceT, short iFieldID)
{ // begin CheckPlayerSurface()
	if(pSurfaceT->bRadioactive && !PlayerInfo.bShield && !bInvulnerable)
	{ // The player is on a radioactive field:	
		if(g_lNow-lGameTimer < 100)
			return 1;
		lGameTimer = g_lNow;
		pPlayer->fPower -= ((float) (rand() % 1000)/1000.0f);
		MakePlayerCameraRotation(ACTION_PLAYER_PAIN_2);
		if(pPlayer->byAction != ACTION_PLAYER_PAIN_1 && pPlayer->byAction != ACTION_SHOT)
		{
			pPlayer->byAction = ACTION_PLAYER_PAIN_1;
			pPlayer->byAnimation = 4;
			pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
			pPlayer->dwAniTime = g_lNow;
		}
		return 1;
	}
	else
	if((pSurfaceT->bHealth ||
		pSurfaceT->bAlcove) && !PlayerInfo.bShield)
	{ // The player is on a health field:	
		if(g_lNow-lGameTimer < 100)
			return 1;
		lGameTimer = g_lNow;
		if(pSurfaceT->bAlcove)
		{ // Checkpoint:
			if(iFieldID == pPlayer->iFieldID &&
			   PlayerInfo.iCheckpointFieldID != iFieldID &&
			   !pPlayer->bShouldMove && !pPlayer->bMove)
			{ // We are on a new checkpoint:
				pCamera->fRot2Velocity[0] = 0.0f;
				pCamera->fRot2Velocity[1] = 0.0f;
				pCamera->fRot2Velocity[1] = 0.0f;
				MakePlayerCameraRotation(ACTION_SHOT);
				PlayerInfo.iCheckpointFieldID = pPlayer->iFieldID;
				if(pPlayer->byAction != ACTION_PLAYER_CHECKPOINT && pPlayer->byAction != ACTION_SHOT)
				{
					pPlayer->byAction = ACTION_PLAYER_CHECKPOINT;
					pPlayer->byAction2 = -1;
					pPlayer->byAnimation = 5;
					pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
					pPlayer->dwAniTime = g_lNow;
				}
				return 1;
			}
		}
		if(pPlayer->fPower < 100.0f && pPlayer->byAction != ACTION_PLAYER_CHECKPOINT)
		{
			MakePlayerCameraRotation(ACTION_RUN_RIGHT);
			pPlayer->fPower += ((float) (rand() % 1000)/1000.0f);
			if(pPlayer->fPower > 100.0f)
				pPlayer->fPower = 100.0f;
			else
			{
				if(pPlayer->byAction != ACTION_PLAYER_HEALTH && pPlayer->byAction != ACTION_SHOT)
				{
					pPlayer->byAction = ACTION_PLAYER_HEALTH;
					pPlayer->byAnimation = 9;
					pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
					pPlayer->dwAniTime = g_lNow;
				}
			}
			return 1;
		}
		else
		{
			if(pPlayer->byAction == ACTION_PLAYER_HEALTH)
				pPlayer->byAction = -1;
		}
	}
	return 0;
} // end CheckPlayerSurface()

// The player push a box (or more), if it's possible then do it and return 1 else return 0
BOOL CheckPlayerPushBox(char byDirection, BOOL bPushBox)
{ // begin CheckPlayerPushBox()
	short iX, iY, iXD, iYD, i, iForce;
	float fForce, fVelocity;
	ACTOR *pActorT;
	FIELD *FieldT;

	// Setup x/y direction:
	switch(byDirection)
	{
		case RIGHT: iX = 1; iY = 0; break;
		case DOWN: iX = 0; iY = 1; break;
		case LEFT: iX = -1; iY = 0; break;
		case UP: iX = 0; iY = -1; break;
	}

	iForce = PlayerInfo.iForce;
	fForce = PlayerInfo.fForce;
	
	// Is it possible to move?
	if(pPlayer->iFieldPos[X]+iX < 0 || pPlayer->iFieldPos[X]+iX >= pLevel->iWidth-1 ||
	   pPlayer->iFieldPos[Y]+iY < 0 || pPlayer->iFieldPos[Y]+iY >= pLevel->iHeight-1)
		return 0; // It's absolutely not possible to move!!
	FieldT = &pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->iWidth+pPlayer->iFieldPos[X]+iX];
	if(PlayerInfo.bGhost)
	{ // Yep, move:
		pPlayer->bShouldMove = TRUE;
		if(PlayerInfo.iForce > 1)
		{ // This action costs a little of the force:
			PlayerInfo.fForce -= 0.005f;
			if(PlayerInfo.fForce <= 0.0f)
			{
				PlayerInfo.fForce = 1.0f;
				PlayerInfo.iForce--;
			}
		}
		return 1;
	}	
	if(!bPushBox)
		if(FieldT->bWall)
			return 0; // It's absolutely not possible to move!!
	
	if(FieldT->bWall && !FieldT->pActor)
		return 0; // It's absolutely not possible to move!!

	fVelocity = pPlayer->fVelocity[0];
	// Is there something to push?
	if(FieldT->bWall && FieldT->pActor)
	{ // Yes! Check it:
		for(i = 1;; i++)
		{
			iXD = iX*i;
			iYD = iY*i;
			if(i-1 < iForce)
			{				
				if(pPlayer->iFieldPos[X]+iXD < 0 || pPlayer->iFieldPos[X]+iXD >= pLevel->iWidth-1 ||
				   pPlayer->iFieldPos[Y]+iYD < 0 || pPlayer->iFieldPos[Y]+iYD >= pLevel->iHeight-1 ||
				  (pLevel->pField[(pPlayer->iFieldPos[Y]+iYD)*pLevel->iWidth+pPlayer->iFieldPos[X]+iXD].bWall &&
				   !pLevel->pField[(pPlayer->iFieldPos[Y]+iYD)*pLevel->iWidth+pPlayer->iFieldPos[X]+iXD].pActor))
					return 0; // No chance to move this thing!!
				// Does we have enought force?
				if(iForce > 1 && pLevel->pField[(pPlayer->iFieldPos[Y]+iYD)*pLevel->iWidth+pPlayer->iFieldPos[X]+iXD].pActor)
				{ // This action costs a little of the force:
					if(pLevel->pField[(pPlayer->iFieldPos[Y]+iYD)*pLevel->iWidth+pPlayer->iFieldPos[X]+iXD].pActor->bHeavy)
						fForce -= 0.1f;
					else
						fForce -= 0.05f;
					if(fForce <= 0.0f)
					{
						fForce = 1.0f;
						iForce--;
					}
				}
				if(pLevel->pField[(pPlayer->iFieldPos[Y]+iYD)*pLevel->iWidth+pPlayer->iFieldPos[X]+iXD].pActor &&
					pLevel->pField[(pPlayer->iFieldPos[Y]+iYD)*pLevel->iWidth+pPlayer->iFieldPos[X]+iXD].pActor->bHeavy)
					fVelocity *= 1.6f;
				else
					fVelocity *= 1.1f;
			}
			else
			{
				if(pPlayer->iFieldPos[X]+iXD < 0 || pPlayer->iFieldPos[X]+iXD >= pLevel->iWidth-1 ||
				   pPlayer->iFieldPos[Y]+iYD < 0 || pPlayer->iFieldPos[Y]+iYD >= pLevel->iHeight-1 ||
				   pLevel->pField[(pPlayer->iFieldPos[Y]+iYD)*pLevel->iWidth+pPlayer->iFieldPos[X]+iXD].bWall)
					return 0; // No chance to move this thing!!
			}
			if(!pLevel->pField[(pPlayer->iFieldPos[Y]+iYD)*pLevel->iWidth+pPlayer->iFieldPos[X]+iXD].bWall)
				break; // There is a free field!
		}
		// Ok, now we now that we could push, do this now:
		for(i = 1; i < 1+PlayerInfo.iForce; i++)
		{
			iXD = iX*i;
			iYD = iY*i;
			if(pPlayer->iFieldPos[X]+iXD < 0 || pPlayer->iFieldPos[X]+iXD >= pLevel->iWidth-1 ||
			   pPlayer->iFieldPos[Y]+iYD < 0 || pPlayer->iFieldPos[Y]+iYD >= pLevel->iHeight-1)
				break;
			pActorT = pLevel->pField[(pPlayer->iFieldPos[Y]+iYD)*pLevel->iWidth+pPlayer->iFieldPos[X]+iXD].pActor;
			if(!pActorT)
				break;
			if(PlayerInfo.iForce > 1)
			{ // This action costs a little of the force:
				if(pActorT->bHeavy)
					PlayerInfo.fForce -= 0.1f;
				else
					PlayerInfo.fForce -= 0.05f;
				if(PlayerInfo.fForce <= 0.0f)
				{
					PlayerInfo.fForce = 1.0f;
					PlayerInfo.iForce--;
				}
			}
			pActorT->fVelocity[0] = fVelocity;
			pActorT->bMove = TRUE;
			pActorT->byDirection = byDirection;
			DisableBoxDocking(pActorT);
		}
		// Give the next field this actor:
		for(i = 1; i < 1+PlayerInfo.iForce; i++)
		{
			iXD = iX*i;
			iYD = iY*i;
			if(pPlayer->iFieldPos[X]+iXD < 0 || pPlayer->iFieldPos[X]+iXD >= pLevel->iWidth-1 ||
			   pPlayer->iFieldPos[Y]+iYD < 0 || pPlayer->iFieldPos[Y]+iYD >= pLevel->iHeight-1 ||
			   pLevel->pField[(pPlayer->iFieldPos[Y]+iYD)*pLevel->iWidth+pPlayer->iFieldPos[X]-iXD].bWall)
				break;
			pActorT = pLevel->pField[(pPlayer->iFieldPos[Y]+iYD)*pLevel->iWidth+pPlayer->iFieldPos[X]+iXD].pActor;
			if(!pActorT ||
			   pActorT->iFieldPos[X]+iXD < 0 || pActorT->iFieldPos[X]+iXD >= pLevel->iWidth-1 ||
			   pActorT->iFieldPos[Y]+iYD < 0 || pActorT->iFieldPos[Y]+iYD >= pLevel->iHeight-1)
				break;
			if(!pLevel->pField[(pActorT->iFieldPos[Y]+iYD)*pLevel->iWidth+pActorT->iFieldPos[X]+iXD].bWall &&
				!pLevel->pField[(pActorT->iFieldPos[Y]+iYD)*pLevel->iWidth+pActorT->iFieldPos[X]+iXD].pActor)
				pLevel->pField[(pActorT->iFieldPos[Y]+iYD)*pLevel->iWidth+pActorT->iFieldPos[X]+iXD].pActor = pActorT;
		}
	}

	if(!pLevel->bUnlimitedForce && PlayerInfo.iForce > 1)
	{ // This action costs a little of the force:
		PlayerInfo.fForce -= 0.005f;
		if(PlayerInfo.fForce <= 0.0f)
		{
			PlayerInfo.fForce = 1.0f;
			PlayerInfo.iForce--;
		}
	}
	else
		PlayerInfo.fForce = 1.0f;
	// Yep, move:
	pPlayer->fVelocity[0] = fVelocity;
	pPlayer->bShouldMove = TRUE;
	if(pLevel->bStepsLimit)
	{
		pLevel->iStepsLimit--;
		if(pLevel->iStepsLimit < 0)
			pLevel->iStepsLimit = 0;
	}
	else
		pLevel->iStepsLimit++;
	// Give the next field this actor:
	if(!pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->iWidth+pPlayer->iFieldPos[X]+iX].pActor)
		pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->iWidth+pPlayer->iFieldPos[X]+iX].pActor = pPlayer;
	return 1; // Yes, lets pushing!
} // end CheckPlayerPushBox()

// The player throw a box, if it's possible then do it and return 1 else return 0
BOOL CheckPlayerPullBox(char byDirection)
{ // begin CheckPlayerPullBox()
	short iX, iY;
	char byOtherDirection;
	ACTOR *pActorT;

	// Could the player pull boxes?
	if(!PlayerInfo.bPullBoxes || PlayerInfo.bGhost)
		return 0; // Nope!

	// Setup x/y direction:
	switch(byDirection)
	{
		case RIGHT: iX = 1; iY = 0; byOtherDirection = LEFT; break;
		case DOWN: iX = 0; iY = 1; byOtherDirection = UP; break;
		case LEFT: iX = -1; iY = 0; byOtherDirection = RIGHT; break;
		case UP: iX = 0; iY = -1; byOtherDirection = DOWN; break;
	}

	// Check if we could push:
	if(pPlayer->iFieldPos[X]+iX < 0 || pPlayer->iFieldPos[X]+iX >= pLevel->iWidth-1 ||
	   pPlayer->iFieldPos[Y]+iY < 0 || pPlayer->iFieldPos[Y]+iY >= pLevel->iHeight-1 ||
	   pPlayer->iFieldPos[X]-iX < 0 || pPlayer->iFieldPos[X]-iX >= pLevel->iWidth-1 ||
	   pPlayer->iFieldPos[Y]-iY < 0 || pPlayer->iFieldPos[Y]-iY >= pLevel->iHeight-1 ||
	   !pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->iWidth+pPlayer->iFieldPos[X]+iX].bWall ||
	   pLevel->pField[(pPlayer->iFieldPos[Y]-iY)*pLevel->iWidth+pPlayer->iFieldPos[X]-iX].bWall ||
	   (pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->iWidth+pPlayer->iFieldPos[X]+iX].bWall &&
   	   !pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->iWidth+pPlayer->iFieldPos[X]+iX].pActor))
		return 0; // It's absolutely not possible to push!!
	// Push the box:
	pActorT = pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->iWidth+pPlayer->iFieldPos[X]+iX].pActor;
	if(pActorT->bHeavy)
	{
		PlayerInfo.fForce -= 0.1f;
		pPlayer->fVelocity[0] *= 1.6f;
	}
	else
	{
		PlayerInfo.fForce -= 0.05f;
		pPlayer->fVelocity[0] *= 1.1f;
	}
	if(PlayerInfo.fForce <= 0.0f)
	{
		PlayerInfo.fForce = 1.0f;
		PlayerInfo.iForce--;
	}
	pActorT->bMove = TRUE;
	pActorT->fVelocity[0] = pPlayer->fVelocity[0];
	pActorT->byDirection = byOtherDirection;
	DisableBoxDocking(pActorT);
	if(pLevel->bStepsLimit)
	{
		pLevel->iStepsLimit--;
		if(pLevel->iStepsLimit < 0)
			pLevel->iStepsLimit = 0;
	}
	else
		pLevel->iStepsLimit++;
	if(!pLevel->bUnlimitedPull)
	{
		PlayerInfo.iPullBoxes--;
		if(!PlayerInfo.iPullBoxes)
			PlayerInfo.bPullBoxes = FALSE;
	}
	return 1;
} // end CheckPlayerPullBox()

// The player throw a box, if it's possible then do it and return 1 else return 0
BOOL CheckPlayerThrowBox(char byDirection)
{ // begin CheckPlayerThrowBox()
	short iX, iY, iX2, iY2;
	ACTOR *pActorT;

	// Could the player pull boxes?
	if(!PlayerInfo.bThrowBoxes || PlayerInfo.bGhost)
		return 0; // Nope!

	// Setup x/y direction:
	switch(byDirection)
	{
		case RIGHT: iX = 1; iY = 0; break;
		case DOWN: iX = 0; iY = 1; break;
		case LEFT: iX = -1; iY = 0; break;
		case UP: iX = 0; iY = -1; break;
	}
	// Check if we could throw:
	if(pPlayer->iFieldPos[X]+iX < 0 || pPlayer->iFieldPos[X]+iX >= pLevel->iWidth-1 ||
	   pPlayer->iFieldPos[Y]+iY < 0 || pPlayer->iFieldPos[Y]+iY >= pLevel->iHeight-1 ||
	   !pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->iWidth+pPlayer->iFieldPos[X]+iX].pActor ||
	   (pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->iWidth+pPlayer->iFieldPos[X]+iX].pActor &&
	   !pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->iWidth+pPlayer->iFieldPos[X]+iX].bWall) ||
	   (!pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->iWidth+pPlayer->iFieldPos[X]+iX].pActor &&
	   pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->iWidth+pPlayer->iFieldPos[X]+iX].bWall))
		return 0; // There is nothing to throw!
	iX2 = iX*2;
	iY2 = iY*2;
	// It's absolutely not possible to throw a box!!
	if(pPlayer->iFieldPos[X]+iX2 < 0 || pPlayer->iFieldPos[X]+iX2 >= pLevel->iWidth-1 ||
	   pPlayer->iFieldPos[Y]+iY2 < 0 || pPlayer->iFieldPos[Y]+iY2 >= pLevel->iHeight-1 ||
	   pLevel->pField[(pPlayer->iFieldPos[Y]+iY2)*pLevel->iWidth+pPlayer->iFieldPos[X]+iX2].bWall)
		return 0; // There is nothing to throw!
	
	// Throw the box:
	pActorT = pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->iWidth+pPlayer->iFieldPos[X]+iX].pActor;
	if(pActorT->bThrow)
		return 0; // There is nothing to throw!
	if(pActorT->bHeavy)
	{
		PlayerInfo.fForce -= 0.2f;
		pActorT->fVelocity[0] = PLAYER_THROW_SPEED*1.6f;
	}
	else
	{
		PlayerInfo.fForce -= 0.1f;
		pActorT->fVelocity[0] = PLAYER_THROW_SPEED*1.1f;
	}
	pActorT->bMove = TRUE;
	pActorT->bThrow = TRUE;
	pActorT->fVelocity[0] = PLAYER_THROW_SPEED;
	pActorT->byDirection = byDirection;
	DisableBoxDocking(pActorT);
	if(!pLevel->bUnlimitedThrow)
	{
		PlayerInfo.iThrowBoxes--;
		if(!PlayerInfo.iThrowBoxes)
			PlayerInfo.bThrowBoxes = FALSE;
	}
	return 1;
} // end CheckPlayerThrowBox()

BOOL CheckPlayerJump(char byDirection)
{ // begin CheckPlayerJump()
	short iX, iY, iX2, iY2;

	// Setup x/y direction:
	switch(byDirection)
	{
		case RIGHT: iX = 1; iY = 0; break;
		case DOWN: iX = 0; iY = 1; break;
		case LEFT: iX = -1; iY = 0; break;
		case UP: iX = 0; iY = -1; break;
	}
	// Check if we could jump:
	if(pPlayer->iFieldPos[X]+iX < 0 || pPlayer->iFieldPos[X]+iX >= pLevel->iWidth-1 ||
	   pPlayer->iFieldPos[Y]+iY < 0 || pPlayer->iFieldPos[Y]+iY >= pLevel->iHeight-1 ||
	   (!PlayerInfo.bGhost && (pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->iWidth+pPlayer->iFieldPos[X]+iX].pActor ||
	    pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->iWidth+pPlayer->iFieldPos[X]+iX].bWall)))
		return 0; // It's not possible to jump!
	iX2 = iX*2;
	iY2 = iY*2;

	// Jump animation:
	pPlayer->byAction = ACTION_JUMP;
	pPlayer->byAction2 = -1;
	pPlayer->byAnimation = 5;
	pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
	pPlayer->dwAniTime = g_lNow;
	pPlayer->iTempFieldID = pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->iWidth+pPlayer->iFieldPos[X]+iX].iID;
	if(!pLevel->bUnlimitedJump)
	{				
		PlayerInfo.iJump--;
		if(PlayerInfo.iJump <= 0)
			PlayerInfo.bJump = FALSE;
	}
	return 1;
} // end CheckPlayerJump()

void SetPlayerToCheckpoint(void)
{ // begin SetPlayerToCheckpoint()
	pPlayer->iFieldID = PlayerInfo.iCheckpointFieldID;
	memset(pPlayer->fFieldPos, 0, sizeof(FLOAT3));
	memset(pPlayer->fVelocity, 0, sizeof(FLOAT3));
	pPlayer->iFieldPos[X] = pLevel->pField[pPlayer->iFieldID].iXField;
	pPlayer->iFieldPos[Y] = pLevel->pField[pPlayer->iFieldID].iYField;
	pPlayer->byType = ACTOR_PLAYER;
	pPlayer->byAction = -1;
	pPlayer->byAction2 = -1;
	if(!pPlayer->fPower)
		pPlayer->fPower = 0.1f;
	pPlayer->fColor[0] = 1.0f;
	pPlayer->fColor[1] = 1.0f;
	pPlayer->fColor[2] = 1.0f;
	pPlayer->fAir = 1.0f;
	pPlayer->fFieldPos[Z] = 0.0f;
	pPlayer->bGoingDeath = FALSE;
	pPlayer->bShouldMove = FALSE;
	pPlayer->bMove = FALSE;
	pPlayer->byAction = ACTION_PLAYER_CHECKPOINT;
	pPlayer->byAction2 = -1;
	pPlayer->byAnimation = 5;
	pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
	pPlayer->dwAniTime = g_lNow;

	pPlayer->fWorldPos[X] = pPlayer->iFieldPos[X]*pLevel->fFieldWidth+pPlayer->fFieldPos[X];
	pPlayer->fWorldPos[Y] = pPlayer->iFieldPos[Y]*pLevel->fFieldHeight+pPlayer->fFieldPos[Y];

	// Set the camera to this new location:
	pCamera->fPos2[X] = pCamera->fPos[X]+pPlayer->fWorldPos[X]+0.5f;
	pCamera->fPos2[Y] = pCamera->fPos[Y]+pPlayer->fWorldPos[Y]+0.5f;
	pCamera->fPos2[Z] = -(pCamera->fPos[Z]-(pPlayer->fWorldPos[Z]-STANDART_LEVEL_Z_POS));
	ComputeActorHeight(pPlayer, 0.2f);

	if(!pLevel->pField[pPlayer->iFieldID].bActive && !PlayerInfo.bWing)
	{ // The player falls in a hole:
		pPlayer->fPower = 0.0f;
		pPlayer->fVelocity[Z] = 0.005f;
	}
} // end SetPlayerToCheckpoint()

void MakePlayerCameraRotation(char byAction)
{ // begin MakePlayerCameraRotation()
	char i;

	switch(byAction)
	{
		case ACTION_SHOT:
			for(i = 1; i < 3; i++)
			{
				if(pCamera->fRot2Velocity[i] > 0.001f || pCamera->fRot2Velocity[i] < -0.001f)
					continue;
				if(!(rand() % 2))
					pCamera->fRot2Velocity[i] += (float) (rand() % 100)/10000;
				else
					pCamera->fRot2Velocity[i] -= (float) (rand() % 100)/10000;
			}
			if(pCamera->fRot2Velocity[X] < 0.001f && pCamera->fRot2Velocity[X] > -0.001f)
				pCamera->fRot2Velocity[X] -= 0.05f+((float) (rand() % 5)/50);
		break;
		
		case ACTION_RUN_RIGHT: case ACTION_RUN_DOWN: case ACTION_RUN_LEFT: case ACTION_RUN_UP:
			for(i = 0; i < 3; i++)
			{
				if(pCamera->fRot2Velocity[i] > 0.001f || pCamera->fRot2Velocity[i] < -0.001f)
					continue;
				if(!(rand() % 2))
					pCamera->fRot2Velocity[i] += (float) (rand() % 100)/10000;
				else
					pCamera->fRot2Velocity[i] -= (float) (rand() % 100)/10000;
			}
		break;

		case ACTION_STAND:
			for(i = 0; i < 3; i++)
			{
				if(pCamera->fRot2Velocity[i] > 0.001f || pCamera->fRot2Velocity[i] < -0.001f)
					continue;
				if(!(rand() % 2))
					pCamera->fRot2Velocity[i] += (float) (rand() % 100)/100000;
				else
					pCamera->fRot2Velocity[i] -= (float) (rand() % 100)/100000;
			}
		break;

		case ACTION_PLAYER_PAIN_1: case ACTION_PLAYER_PAIN_2: case ACTION_PLAYER_PAIN_3:
			for(i = 0; i < 3; i++)
			{
				if(pCamera->fRot2Velocity[i] > 0.001f || pCamera->fRot2Velocity[i] < -0.001f)
					continue;
				if(!(rand() % 2))
					pCamera->fRot2Velocity[i] += (float) (rand() % 100)/1000;
				else
					pCamera->fRot2Velocity[i] -= (float) (rand() % 100)/1000;
			}
		break;
	}
} // end MakePlayerCameraRotation()
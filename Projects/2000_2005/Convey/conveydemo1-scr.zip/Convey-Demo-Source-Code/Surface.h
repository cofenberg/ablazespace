//-----------------------------------------------------------------------------
// File: Surface.h
//-----------------------------------------------------------------------------

#ifndef __SURFACE_H__
#define __SURFACE_H__


// Classes: *******************************************************************
typedef struct TEXTURE_POS
{
	SHORT2 iPos[4];	
	FLOAT2 fPos[4];
	short iTimeToNext;
} TEXTURE_POS;

typedef class SURFACE
{
	public:

	char byFilename[MAX_PATH];
	char byName[256];
	short iID;
	short iUsed;
	char **byTextureFilename;
	
	short iAniSteps;
	TEXTURE_POS *pTexturePos;
	short *iTextureID;
	AS_TEXTURE **pTexture;

	// Attributes:
	BOOL bAlcove,
		 bRadioactive,
		 bHealth,
		 bExit,
		 bAnchor,
		 bColorPainter;
	char byAnchorType;
	char byColorPainterType;

	// Change:
	BOOL bChange,
		 bChangeState,
		 bChangeDestroy;
	short iChangeSurface;


		SURFACE(void);
		~SURFACE(void);

		HRESULT Load(char *);
		HRESULT Save(char *);
		void CalculateFloatTexturePos(void);
		void ChangeAnimationSteps(short);
		void Destroy(void);
} SURFACE;

///////////////////////////////////////////////////////////////////////////////
// Definitions: ***************************************************************
///////////////////////////////////////////////////////////////////////////////
// Variables: *****************************************************************
extern HWND hWndSurfaces, hWndSurface, hWndTextures, hWndObjects;
extern BOOL bSurfaceSave, bLoadTexture;
extern FLOAT3 fTextureViewPos;
extern short iCurrentTexturePos, iCurrentTextureAniStep;
extern char byFilenameTemp[MAX_PATH];
///////////////////////////////////////////////////////////////////////////////
// Functions: *****************************************************************
extern LRESULT CALLBACK SurfacesProc(HWND, UINT, WPARAM, LPARAM);
extern LRESULT CALLBACK SurfaceProc(HWND, UINT, WPARAM, LPARAM);
extern LRESULT CALLBACK TexturesProc(HWND, UINT, WPARAM, LPARAM);
///////////////////////////////////////////////////////////////////////////////


#endif // __SURFACE_H__
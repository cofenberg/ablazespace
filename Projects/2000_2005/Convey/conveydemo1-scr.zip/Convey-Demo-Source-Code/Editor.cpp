//-----------------------------------------------------------------------------
// File: Editor.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
HWND hWndEditorShow;	   // The window handle for the level view window
HDC hDCEditorShow;		   // Private GDI device context for the level view window
HGLRC hRCEditorShow;	   // Permanent rendering context for the level view window
BOOL bEditorTestLevel,	   // Do we test a level at the moment?
	 bCameraAnimation,	   // Should we play a camera script?
	 bEditorHeavy;		   // Does we set a normal or a heavy box?
char byEditorBrushSize,    // The brush size (radius)
     byEditorMenu,		   // The selected menu (in the editor dialog)
	 byEditorSelected,	   // The selected action (e.g. set a wall, set a object...)
	 byEditorSelectedID,   // The selected ID (e.g. from a field, object...)
	 byCurrentSkyCubeSide, // The selected sky-cube side
	 iEditorRotate;		   // The selected rotation (e.g. for surface rotating)
long lCameraTimer;		   // The time variable for the camera script animation
short iFieldX, iFieldY;	   // The position of the current selected field (were the mouse is over)
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern LRESULT CALLBACK EditorProc(HWND, UINT, WPARAM, LPARAM);
HRESULT Editor(void);
HRESULT EditorDraw(void);
HRESULT EditorCheck(void);
void ManipulateColor(FLOAT3 *, short);
void ManipulateDensity(FLOAT *, short);
///////////////////////////////////////////////////////////////////////////////


HRESULT Editor(void)
{ // begin Editor()
	_AS->WriteLogMessage("Enter editor module");
	// Open now the editor dialog:
	DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR), NULL, (DLGPROC) EditorProc);
	return 0;
} // end Editor()

HRESULT EditorDraw(void)
{ // begin EditorDraw()
//	char byTemp[256];

	// Check if we should update the level view window:
	if(hWndSurfaces || hWndSurface || hWndTextures ||
	   !wglMakeCurrent(hDCEditorShow, hRCEditorShow))
		return 0;

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	SetCameraTranslation(TRUE);
	pLevel->DrawSkyCube();
	pLevel->InitLevelDraw();
	ASEnableLighting();

	// Draw the level:
	glEnable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);
	SetCameraTranslation(FALSE);
	ASExtractFrustum();

	SetActorsLights();

	glColor3f(1.0f, 1.0f, 1.0f);
	pLevel->Draw(1);

	DrawActors();
	DrawPlayer();
	DrawEffects();

	// Draw the water:
	SetCameraTranslation(FALSE);
	pLevel->DrawWater();

	// Show text:	
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glColor4f(1.0f, 1.0f, 1.0f, 0.95f);

/*
	 = x;
	pPlayer->iMultiAniStep[1] = y;
	sprintf(byTemp, "ID: %d   x: %d    y:%d", SelectedField, pLevel->pField[SelectedField].iXField, pLevel->pField[SelectedField].iYField);
	glPrint(10, 400, byTemp, 0);
*/

	ASSwapBuffers(hDCEditorShow, NULL, TRUE);
	pLevel->DeInitLevelDraw();
	return 0;
} // end EditorDraw()

HRESULT EditorCheck(void)
{ // begin EditorCheck()
	short i;

	// Check if we should update the level view window:
	if(hWndSurfaces || hWndSurface || hWndTextures || GetForegroundWindow() != hWndEditor)
		return 0;

	// Check the keys:
	if(CHECK_KEY(ASKeys, DIK_ESCAPE))
	{
		ASKeys[DIK_ESCAPE] = 0;
		if(!SaveLevelQuestion())
		{
			_AS->SetShutDown(TRUE);
			EndDialog(hWndEditor, FALSE);
		}
	}
	if(CHECK_KEY(ASKeys, DIK_F1))
	{ // Open the help file:
		ASKeys[DIK_F1] = 0;
		OpenHelp();
	}
	if(CHECK_KEY(ASKeys, DIK_F2))
	{ // Load a level:
		ASKeys[DIK_F2] = 0;
		SendMessage(hWndEditor, WM_COMMAND, ID_FILE_LEVEL_SAVE, 0);
	}
	if(CHECK_KEY(ASKeys, DIK_F3))
	{ // Save a level:
		ASKeys[DIK_F3] = 0;
		SendMessage(hWndEditor, WM_COMMAND, ID_FILE_LEVEL_LOAD, 0);
	}
	if(CHECK_KEY(ASKeys, DIK_F12))
	{ // Open the configuration menu:
		ASKeys[DIK_F12] = 0;
		SendMessage(hWndEditor, WM_COMMAND, ID_OPTIONS_CONFIG, 0);
	}
	CheckCameraKeys(TRUE);
	CalculateCamersSinCos(); // Update the sin/cos for the camera

// Actors:
	CheckPlayer(TRUE);
	CheckActors(TRUE);
		
	if(PlayCameraScript(TRUE))
		return 0;



// Mouse usage for the level manipulaion:
	double fX, fY, fZ;
	char byColor, byColors;
	BOOL bTop, bFloor, bBoth, bTerrainChange = 0, bFieldChange = 0;
	short iX, iY, iSize, iIncrease, iPoint, iSizeOne;
	float fDepth, fTopMiddle, fFloorMiddle, fGreatestTopHeight, fLowestTopHeight,
		  fGreatestFloorHeight, fLowestFloorHeight;
	double fModelViewMatrix[16], fProjectionMatrix[16];
	int iViewport[4];
	POINT MousePos;
	static POINT LastMousePos;
	FIELD *pFieldT;
	FLOAT3 *fPosT;
	RECT Rect;
	HWND hWndT;
	ACTOR *pActorT;

	// Disable all field selection:
	for(i = 0; i < pLevel->iFields; i++)
		pLevel->pField[i].bSelected = FALSE;

	if(g_lNow-DisplayActor[0].dwAniTime > OBJECTS_ANI_SPEED)
	{
		DisplayActor[0].dwAniTime = g_lNow;
		DisplayActor[0].iAniStep++;
		if(DisplayActor[0].iAniStep > 3)
			DisplayActor[0].iAniStep = 0;
	}
	
	GetCursorPos(&MousePos);
	GetWindowRect(hWndEditorShow, &Rect);
	// Check if the mouse is in the level view area:
	if(MousePos.x > Rect.left &&
	   MousePos.x < Rect.right &&
	   MousePos.y > Rect.top &&
	   MousePos.y < Rect.bottom)
	{ // Yea, we are inside:
		goto ManipulateLevel;
	}
	else // Nope, the mouse isn't in the level view area:
		return 0;
	
ManipulateLevel:
	// Check mouse scrolling:
	if(_ASConfig->bMouseScroll)
	{
		if(MousePos.x < Rect.left+10)
		{
			pCamera->fPos[X] += fSin90*SCROLL_SPEED*g_lDeltatime;
			pCamera->fPos[Y] += fCos90*SCROLL_SPEED*g_lDeltatime;
		}
		if(MousePos.x > Rect.right-10)
		{
			pCamera->fPos[X] -= fSin90*SCROLL_SPEED*g_lDeltatime;
			pCamera->fPos[Y] -= fCos90*SCROLL_SPEED*g_lDeltatime;
		}
		if(MousePos.y < Rect.top+10)
		{
			pCamera->fPos[X] += fSin*SCROLL_SPEED*g_lDeltatime;
			pCamera->fPos[Y] += fCos*SCROLL_SPEED*g_lDeltatime;
		}
		if(MousePos.y > Rect.bottom-10)
		{
			pCamera->fPos[X] -= fSin*SCROLL_SPEED*g_lDeltatime;
			pCamera->fPos[Y] -= fCos*SCROLL_SPEED*g_lDeltatime;
		}
	}

	// Check the mouse on the level:
	// Get the 'real' mouse position in the level view area:
	MousePos.x -= Rect.left;
	MousePos.y -= Rect.top;

	// Check if the mouse should not be moved: (e.g. for changing terrain height)
	if((byEditorMenu == EDITOR_TERRAIN_MENU || byEditorMenu == EDITOR_ENVIRONMENT_MENU)
	   && (CHECK_KEY(ASMouse.byButtons, 0) ||
	   CHECK_KEY(ASMouse.byButtons, 1) || CHECK_KEY(ASMouse.byButtons, 2)))
	{ // The user change the hight of some points or something like that:
		iIncrease = (short) ASMouse.lY;
		SetCursorPos(LastMousePos.x+Rect.left, LastMousePos.y+Rect.top);
	}
	else
	{
		memcpy(&LastMousePos, &MousePos, sizeof(POINT));
		iIncrease = 0;
		// Get the 'real' mouse position in the level view area:
		GetCursorPos(&MousePos);
		MousePos.x -= Rect.left;
		MousePos.y -= Rect.top;
		MousePos.y = Rect.bottom-Rect.top-MousePos.y;
		
		// Get the mouse position in our 3D world:
		glReadBuffer(GL_FRONT);
		glReadPixels(MousePos.x, MousePos.y, 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, &fDepth);
		glGetDoublev(GL_MODELVIEW_MATRIX, fModelViewMatrix);
		glGetDoublev(GL_PROJECTION_MATRIX, fProjectionMatrix);
		glGetIntegerv(GL_VIEWPORT, iViewport);
		gluUnProject(MousePos.x, MousePos.y, fDepth, fModelViewMatrix, fProjectionMatrix, iViewport, &fX, &fY, &fZ);

		// Calculate the current field we are on:
		if(byEditorMenu == EDITOR_TERRAIN_MENU) // We select points:
			COMPUTE_FIELD_POS(fX+pLevel->fFieldWidth/2, fY+pLevel->fFieldHeight/2, iFieldX, iFieldY)
		else // We select fields:
			COMPUTE_FIELD_POS(fX, fY, iFieldX, iFieldY)
	}
		
	// Setup some other stuff:
	iSize = byEditorBrushSize;
	if(pLevel->pCurrentField && byEditorMenu == EDITOR_SELECT_MENU)
		pLevel->pCurrentField->bSelected = TRUE;
	hWndT = hWndEditorTab[TAB_EDITOR_TERRAIN];
	bTop = IsDlgButtonChecked(hWndT, IDC_EDITOR_TERRAIN_TOP);
	bFloor = IsDlgButtonChecked(hWndT, IDC_EDITOR_TERRAIN_FLOOR);
	bBoth = IsDlgButtonChecked(hWndT, IDC_EDITOR_TERRAIN_BOTH);

	if(byEditorMenu == EDITOR_ENVIRONMENT_MENU)
	{ // We change the environment of our world:
		switch(byEditorSelected)
		{
			case EDITOR_ENVIRONMENT_LIGHT: // Change the world's light
				ManipulateColor(&pLevel->fLevelColor, iIncrease);
			break;

			case EDITOR_ENVIRONMENT_FOG_COLOR: // Change the fog light
				ManipulateColor(&pLevel->fFogColor, iIncrease);
			break;

			case EDITOR_ENVIRONMENT_FOG_DENSITY: // Change the fog density
				ManipulateDensity(&pLevel->fFogDensity, iIncrease);
			break;

			case EDITOR_ENVIRONMENT_WATER_COLOR: // Change the water color
				ManipulateColor(&pLevel->fWaterColor, iIncrease);
			break;

			case EDITOR_ENVIRONMENT_WATER_DENSITY: // Change the water density
				ManipulateDensity(&pLevel->fWaterDensity, iIncrease);
			break;

			case EDITOR_ENVIRONMENT_WATER_HEIGHT: // Change the water height
				if(CHECK_KEY(ASMouse.byButtons, 0))
				{
					pLevel->fWaterHeight += iIncrease/500.0f;
					break;
				}
				if(CHECK_KEY(ASMouse.byButtons, 1))
					pLevel->fWaterHeight = STANDART_LEVEL_Z_POS-0.3f;
			break;

			case EDITOR_ENVIRONMENT_WATER_AMPLITUDE: // Change the water amplitude
				if(CHECK_KEY(ASMouse.byButtons, 0))
				{
					pLevel->fWaterAmplitude += iIncrease/50.0f;
					if(pLevel->fWaterAmplitude < 0.0f)
						pLevel->fWaterAmplitude = 0.0f;
					break;
				}
				if(CHECK_KEY(ASMouse.byButtons, 1))
					pLevel->fWaterAmplitude = 1.0f;
			break;

			case EDITOR_ENVIRONMENT_WATER_SPEED: // Change the water speed
				if(CHECK_KEY(ASMouse.byButtons, 0))
				{
					pLevel->fWaterSpeed += iIncrease/500.0f;
					if(pLevel->fWaterSpeed < 0.0f)
						pLevel->fWaterSpeed = 0.0f;
					break;
				}
				if(CHECK_KEY(ASMouse.byButtons, 1))
					pLevel->fWaterSpeed = 1.0f;
			break;

			case EDITOR_ENVIRONMENT_SKY_CUBE_COLOR: // Change the sky-cube color
				ManipulateColor(&pLevel->fSkyCubeColor, iIncrease);
			break;

			case EDITOR_ENVIRONMENT_SKY_CUBE_SIZE: // Change the sky-cube size
				byColor = -1;
				byColors = 1;
				// Which color we have to manipulate?
				if(CHECK_KEY(ASMouse.byButtons, 0) && CHECK_KEY(ASMouse.byButtons, 1))
					byColors = 3;
				if(CHECK_KEY(ASMouse.byButtons, 0))
					byColor = R;
				else
				if(CHECK_KEY(ASMouse.byButtons, 1))
					byColor = G;
				else
				if(CHECK_KEY(ASMouse.byButtons, 2))
					byColor = B;
				if(byColor == -1 && byColors == 1)
					break;
				for(i = 0; i < byColors; i++)
				{
					if(byColors == 3)
						byColor = (char) i;
					pLevel->fSkyCubeSize[byColor] += iIncrease;
				}
			break;
		}
		return 0;
	}

	// Is the mouse in the level?
	if(iFieldX < 0 || iFieldY < 0 || iFieldX >= pLevel->iWidth || iFieldY >= pLevel->iHeight)
		return 0; // The mouse is not on the level
	
	// The mouse is on a field:
	fTopMiddle = fFloorMiddle = fGreatestTopHeight = fLowestTopHeight = fGreatestFloorHeight =
	fLowestFloorHeight = 0.0f;
	i = 0;
	
	// Get some data from the selected field's: (middle hight, greatest hight...)
	if(!iSize)
	{
		iY = iFieldY;
		iSizeOne = 1;
	}
	else
	{
		iSizeOne = 0;
		iY = iFieldY-iSize;
		if(iSize > 1)
			iY++;
	}
	if(iY < 0)
		iY = 0;
	
	pPlayer->iMultiAniStep[0] = iFieldX;
	pPlayer->iMultiAniStep[1] = iFieldY;

	for(iPoint = 3; iY < iFieldY+iSize+iSizeOne; iY++)
	{
		if(iY >= pLevel->iHeight)
			break;
		if(!iSize)
			iX = iFieldX;
		else
		{
			iX = iFieldX-iSize;
			if(iSize > 1)
				iX++;
		}
		if(iX < 0)
			iX = 0;
		for(; iX < iFieldX+iSize+iSizeOne; iX++)
		{
			if(iX >= pLevel->iWidth)
				continue;
			pFieldT = &pLevel->pField[iY*pLevel->iWidth+iX];
			if(byEditorMenu != EDITOR_ENVIRONMENT_MENU)
				pFieldT->bSelected = TRUE;
			// Calculate the middle value:
			fTopMiddle += pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z];
			if(pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] < fGreatestTopHeight)
				fGreatestTopHeight = pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z];
			if(pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] > fLowestTopHeight)
				fLowestTopHeight = pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z];
			fFloorMiddle += pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z];
			if(pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] < fGreatestFloorHeight)
				fGreatestFloorHeight = pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z];
			if(pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] > fLowestFloorHeight)
				fLowestFloorHeight = pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z];
			i++;
		}
	}
	fTopMiddle /= i;
	fFloorMiddle /= i;
	
	// Now find out what we should do and make it:
	if(!iSize)
		iY = iFieldY;
	else
	{
		iY = iFieldY-iSize;
		if(iSize > 1)
			iY++;
	}
	if(iY < 0)
		iY = 0;
	for(iPoint = 3; iY < iFieldY+iSize+iSizeOne; iY++)
	{
		if(iY >= pLevel->iHeight)
			break;
		if(!iSize)
			iX = iFieldX;
		else
		{
			iX = iFieldX-iSize;
			if(iSize > 1)
				iX++;
		}
		if(iX < 0)
			iX = 0;
		for(; iX < iFieldX+iSize+iSizeOne; iX++)
		{
			if(iX >= pLevel->iWidth)
				continue;
			pFieldT = &pLevel->pField[iY*pLevel->iWidth+iX];
			
			// Now what should be done?
			if(byEditorMenu == EDITOR_OBJECT_MENU)
			{ // We set some stuff into your level:
				switch(byEditorSelected)
				{
					case EDITOR_SELECTED_OBJECT_XE:
						if(CHECK_KEY(ASMouse.byButtons, 1))
						{
							bFieldChange = TRUE;
							pPlayer->bActive = FALSE;
							pLevel->pField[pPlayer->iFieldID].pActor = NULL;
							break;
						}
						if(!CHECK_KEY(ASMouse.byButtons, 0))
							break;
						if(pFieldT->bWall || !pFieldT->bActive || (pFieldT->pBridgeActor && pFieldT->pBridgeActor->bBridgeMovement))
							break;
						bFieldChange = TRUE;
						pLevel->pField[pPlayer->iFieldID].pActor = NULL;
						pPlayer->bActive = TRUE;
						pPlayer->fPower = 1.0f;
						pPlayer->iFieldPos[X] = iX;
						pPlayer->iFieldPos[Y] = iY;
						pPlayer->byType = ACTOR_PLAYER;
						pPlayer->byDirection = iEditorRotate;
						pPlayer->fRot[Y] = pPlayer->byDirection*90.0f;
						pPlayer->iFieldID = pFieldT->iID;
						pPlayer->fColor[0] = 1.0f;
						pPlayer->fColor[1] = 1.0f;
						pPlayer->fColor[2] = 1.0f;
						pPlayer->fAir = 1.0f;
					break;

					case EDITOR_SELECTED_OBJECT_BOX_NORMAL:
					case EDITOR_SELECTED_OBJECT_BOX_RED:
					case EDITOR_SELECTED_OBJECT_BOX_GREEN:
					case EDITOR_SELECTED_OBJECT_BOX_BLUE:
						if(CHECK_KEY(ASMouse.byButtons, 1))
						{
							bFieldChange = TRUE;
							if(pFieldT->pActor && 
							  (pFieldT->pActor->byType == ACTOR_BOX_NORMAL ||
							   pFieldT->pActor->byType == ACTOR_BOX_RED ||
							   pFieldT->pActor->byType == ACTOR_BOX_GREEN ||
							   pFieldT->pActor->byType == ACTOR_BOX_BLUE))
							{ // Delete this box;
								pFieldT->pActor->bActive = FALSE;
								pFieldT->bWall = FALSE;
								pFieldT->pActor = NULL;
							}
							else
							if(pFieldT->pBridgeActor)
							{ // Delete the bridge actor;
								pFieldT->pBridgeActor->bActive = FALSE;
								pFieldT->pBridgeActor = NULL;
								pFieldT->bActive = FALSE;
							}
							break;
						}
						if(!CHECK_KEY(ASMouse.byButtons, 0))
							break;
						if(pFieldT->bWall || pFieldT->pActor ||
						   (pFieldT->pBridgeActor && pFieldT->pBridgeActor->bBridgeMovement))
							break;
						bFieldChange = TRUE;
						// Set a box on this field:
						pActorT	= FindFreeActor();
						if(!pActorT)
							break;
						pActorT->bActive = TRUE;
						pActorT->iFieldPos[X] = iX;
						pActorT->iFieldPos[Y] = iY;
						pActorT->fSize = 1.0f;
						pActorT->bHeavy = bEditorHeavy;
						switch(byEditorSelected)
						{
							case EDITOR_SELECTED_OBJECT_BOX_NORMAL:
								pActorT->byType = ACTOR_BOX_NORMAL;
								pActorT->fColor[0] = 1.0f; pActorT->fColor[1] = 1.0f; pActorT->fColor[2] = 1.0f;
							break;
							
							case EDITOR_SELECTED_OBJECT_BOX_RED:
								pActorT->byType = ACTOR_BOX_RED;
								pActorT->fColor[0] = 1.0f; pActorT->fColor[1] = 0.0f; pActorT->fColor[2] = 0.0f;
							break;
							
							case EDITOR_SELECTED_OBJECT_BOX_GREEN:
								pActorT->byType = ACTOR_BOX_GREEN;
								pActorT->fColor[0] = 0.0f; pActorT->fColor[1] = 1.0f; pActorT->fColor[2] = 0.0f;
							break;
							
							case EDITOR_SELECTED_OBJECT_BOX_BLUE:
								pActorT->byType = ACTOR_BOX_BLUE;
								pActorT->fColor[0] = 0.0f; pActorT->fColor[1] = 0.0f; pActorT->fColor[2] = 1.0f;
							break;
						}						
						pActorT->iFieldID = pFieldT->iID;
						pActorT->fLastHeightCheckWorldPos[X] = -1.0f;
						pActorT->fLastHeightCheckWorldPos[Y] = -1.0f;
						if(!pFieldT->bActive)
						{
							pFieldT->bActive = TRUE;
							ComputeActorHeight(pActorT, 0.5f);
							pFieldT->bActive = FALSE;
						}
						else
							ComputeActorHeight(pActorT, 0.5f);
					break;

					case EDITOR_SELECTED_OBJECT_HEALTH:
					case EDITOR_SELECTED_OBJECT_LIVE:
					case EDITOR_SELECTED_OBJECT_PULL:
					case EDITOR_SELECTED_OBJECT_THROW:
					case EDITOR_SELECTED_OBJECT_FORCE:
					case EDITOR_SELECTED_OBJECT_WEAPON:
					case EDITOR_SELECTED_OBJECT_POINT:
					case EDITOR_SELECTED_OBJECT_GHOST:
					case EDITOR_SELECTED_OBJECT_TIME:
					case EDITOR_SELECTED_OBJECT_STEP:
					case EDITOR_SELECTED_OBJECT_SPEED:
					case EDITOR_SELECTED_OBJECT_WING:
					case EDITOR_SELECTED_OBJECT_SHIELD:
					case EDITOR_SELECTED_OBJECT_JUMP:
					case EDITOR_SELECTED_OBJECT_AIR:
						if(CHECK_KEY(ASMouse.byButtons, 1))
						{
							if(pFieldT->pObject)
								pFieldT->pObject->bActive = FALSE;
							pFieldT->pObject = NULL;
							break;
						}
						if(!CHECK_KEY(ASMouse.byButtons, 0))
							break;
						if((pFieldT->bWall && !pFieldT->pActor) || pFieldT->pObject)
							break;
						pActorT	= FindFreeActor();
						if(!pActorT)
							break;
						pActorT->bActive = TRUE;
						pActorT->iFieldPos[X] = iX;
						pActorT->iFieldPos[Y] = iY;
						pActorT->fSize = 1.0f;
						pActorT->iFieldID = pFieldT->iID;
						switch(byEditorSelected)
						{
							case EDITOR_SELECTED_OBJECT_HEALTH: pActorT->byType = ACTOR_HEALTH_OBJ; break;
							case EDITOR_SELECTED_OBJECT_LIVE: pActorT->byType = ACTOR_LIVE_OBJ; break;
							case EDITOR_SELECTED_OBJECT_PULL: pActorT->byType = ACTOR_PULL_OBJ; break;
							case EDITOR_SELECTED_OBJECT_THROW: pActorT->byType = ACTOR_THROW_OBJ; break;
							case EDITOR_SELECTED_OBJECT_FORCE: pActorT->byType = ACTOR_FORCE_OBJ; break;
							case EDITOR_SELECTED_OBJECT_WEAPON: pActorT->byType = ACTOR_WEAPON_OBJ; break;
							case EDITOR_SELECTED_OBJECT_POINT: pActorT->byType = ACTOR_POINT_OBJ; break;
							case EDITOR_SELECTED_OBJECT_GHOST: pActorT->byType = ACTOR_GHOST_OBJ; break;
							case EDITOR_SELECTED_OBJECT_TIME: pActorT->byType = ACTOR_TIME_OBJ; break;
							case EDITOR_SELECTED_OBJECT_STEP: pActorT->byType = ACTOR_STEP_OBJ; break;
							case EDITOR_SELECTED_OBJECT_SPEED: pActorT->byType = ACTOR_SPEED_OBJ; break;
							case EDITOR_SELECTED_OBJECT_WING: pActorT->byType = ACTOR_WING_OBJ; break;
							case EDITOR_SELECTED_OBJECT_SHIELD: pActorT->byType = ACTOR_SHIELD_OBJ; break;
							case EDITOR_SELECTED_OBJECT_JUMP: pActorT->byType = ACTOR_JUMP_OBJ; break;
							case EDITOR_SELECTED_OBJECT_AIR: pActorT->byType = ACTOR_AIR_OBJ; break;
						}
						pFieldT->pObject = pActorT;
					break;

				}
			}
			if(byEditorMenu == EDITOR_TERRAIN_MENU)
			{ // We should manipulate the terrain:
				hWndT = hWndEditorTab[TAB_EDITOR_TERRAIN];
				switch(byEditorSelected)
				{
					case EDITOR_SELECTED_COLOR: // Change the vertex colors
						byColor = -1;
						byColors = 1;
						// Which color we have to manipulate?
						if(CHECK_KEY(ASMouse.byButtons, 0) && CHECK_KEY(ASMouse.byButtons, 1))
							byColors = 3;
						else
						if(CHECK_KEY(ASMouse.byButtons, 0))
							byColor = R;
						else
						if(CHECK_KEY(ASMouse.byButtons, 1))
							byColor = G;
						else
						if(CHECK_KEY(ASMouse.byButtons, 2))
							byColor = B;
						if(byColor == -1 && byColors == 1)
							break;
						for(i = 0; i < byColors; i++)
						{
							if(byColors == 3)
								byColor = (char) i;
							if(bTop || bBoth)
								pLevel->fColor[pFieldT->iFace[FACE_FRONT][iPoint]][byColor] += iIncrease/500.0f;
							if(bFloor || bBoth)
								pLevel->fColor[pFieldT->iFace[FACE_FLOOR][iPoint]][byColor] += iIncrease/500.0f;
							if(pLevel->fColor[pFieldT->iFace[FACE_FRONT][iPoint]][byColor] > 1.0f)
								pLevel->fColor[pFieldT->iFace[FACE_FRONT][iPoint]][byColor] = 1.0f;
							if(pLevel->fColor[pFieldT->iFace[FACE_FRONT][iPoint]][byColor] < 0.0f)
								pLevel->fColor[pFieldT->iFace[FACE_FRONT][iPoint]][byColor] = 0.0f;
							if(pLevel->fColor[pFieldT->iFace[FACE_FLOOR][iPoint]][byColor] > 1.0f)
								pLevel->fColor[pFieldT->iFace[FACE_FLOOR][iPoint]][byColor] = 1.0f;
							if(pLevel->fColor[pFieldT->iFace[FACE_FLOOR][iPoint]][byColor] < 0.0f)
								pLevel->fColor[pFieldT->iFace[FACE_FLOOR][iPoint]][byColor] = 0.0f;
						}
					break;

					case EDITOR_SELECTED_HEIGHT: // Change the heights
						if(CHECK_KEY(ASMouse.byButtons, 2))
						{ // Set to the standart height:
							bTerrainChange = TRUE;
							if(bTop || bBoth)
								pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] = pLevel->fFieldDepth+STANDART_LEVEL_Z_POS;
							if(bFloor || bBoth)
								pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] = STANDART_LEVEL_Z_POS;
						}
						if(!CHECK_KEY(ASMouse.byButtons, 0))
							break;
						bTerrainChange = TRUE;
						if(bTop || bBoth)
							pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] += iIncrease/50.0f;
						if(bFloor || bBoth)
							pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] += iIncrease/50.0f;
					break;
					
					case EDITOR_SELECTED_POINT: // Change the point positions
						if(CHECK_KEY(ASMouse.byButtons, 0))
						{ // Manipulate x position:
							if(bTop || bBoth)
								pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][X] += iIncrease/50.0f;
							if(bFloor || bBoth)
								pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][X] += iIncrease/50.0f;
						}
						if(CHECK_KEY(ASMouse.byButtons, 1))
						{ // Manipulate y position:
							if(bTop || bBoth)
								pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Y] += iIncrease/50.0f;
							if(bFloor || bBoth)
								pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Y] += iIncrease/50.0f;
						}
						// This effect should be not to extreme:
						for(i = 0; i < 2; i++)
						{
							if(!i)
								fPosT = &pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]];
							else
								fPosT = &pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]];
							
							if((*fPosT)[X] > iX*pLevel->fFieldWidth+0.5f)
								(*fPosT)[X] = iX*pLevel->fFieldWidth+0.5f;
							if((*fPosT)[X] < iX*pLevel->fFieldWidth-0.5f)
								(*fPosT)[X] = iX*pLevel->fFieldWidth-0.5f;
							
							if((*fPosT)[Y] > iY*pLevel->fFieldHeight+0.5f)
								(*fPosT)[Y] = iY*pLevel->fFieldHeight+0.5f;
							if((*fPosT)[Y] < iY*pLevel->fFieldHeight-0.5f)
								(*fPosT)[Y] = iY*pLevel->fFieldHeight-0.5f;
						}
						if(CHECK_KEY(ASMouse.byButtons, 2))
						{ // Set to standart position:
							if(bTop || bBoth)
							{
								pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][X] = iX*pLevel->fFieldWidth;
								pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Y] = iY*pLevel->fFieldHeight;
							}
							if(bFloor || bBoth)
							{
								pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][X] = iX*pLevel->fFieldWidth;
								pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Y] = iY*pLevel->fFieldHeight;
							}
						}
						bTerrainChange = TRUE;
					break;

					case EDITOR_SELECTED_MIDDLE_HEIGHT: // Middle the heights
						if(!CHECK_KEY(ASMouse.byButtons, 0))
							break;
						bTerrainChange = TRUE;
						if(bTop || bBoth)
						{
							if(pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] > fTopMiddle)
							{
								pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] -= iIncrease/50.0f;
								if(pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] < fTopMiddle)
									pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] = fTopMiddle;
							}
							else
								if(pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] < fTopMiddle)
								{
									pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] += iIncrease/50.0f;
									if(pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] > fTopMiddle)
										pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] = fTopMiddle;
								}
						}
						if(bFloor || bBoth)
						{
							if(pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] > fFloorMiddle)
							{
								pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] -= iIncrease/50.0f;
								if(pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] < fFloorMiddle)
									pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] = fFloorMiddle;
							}
							else
								if(pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] < fFloorMiddle)
								{
									pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] += iIncrease/50.0f;
									if(pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] > fFloorMiddle)
										pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] = fFloorMiddle;
								}
						}
					break;
					
					case EDITOR_SELECTED_LOWEST_HEIGHT: // Set to the lowest height
						if(!CHECK_KEY(ASMouse.byButtons, 0))
							break;
						bTerrainChange = TRUE;
						if(bTop || bBoth)
						{
							if(pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] < fLowestTopHeight)
							{
								pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] += iIncrease/50.0f;
								if(pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] > fLowestTopHeight)
									pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] = fLowestTopHeight;
							}
						}
						if(bFloor || bBoth)
						{
							if(pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] < fLowestFloorHeight)
							{
								pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] += iIncrease/50.0f;
								if(pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] > fLowestFloorHeight)
									pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] = fLowestFloorHeight;
							}
						}
					break;

					case EDITOR_SELECTED_GREATEST_HEIGHT: // Set to the greatest height
						if(!CHECK_KEY(ASMouse.byButtons, 0))
							break;
						bTerrainChange = TRUE;
						if(bTop || bBoth)
						{
							if(pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] > fGreatestTopHeight)
							{
								pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] -= iIncrease/50.0f;
								if(pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] < fGreatestTopHeight)
									pLevel->fPoint[pFieldT->iFace[FACE_FRONT][iPoint]][Z] = fGreatestTopHeight;
							}
						}
						if(bFloor || bBoth)
						{
							if(pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] > fGreatestFloorHeight)
							{
								pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] -= iIncrease/50.0f;
								if(pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] < fGreatestFloorHeight)
									pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][iPoint]][Z] = fGreatestFloorHeight;
							}
						}
					break;
				}
				continue;
			}
			if(CHECK_KEY(ASMouse.byButtons, 0))
			{
				switch(byEditorMenu)
				{
					case EDITOR_SURFACE_MENU: // We setup surfaces on the field faces:
						bFieldChange = TRUE;
						if(!pFieldT->bActive)
							continue;			
						hWndT = hWndEditorTab[TAB_EDITOR_SURFACES];
						if(SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_FLOOR, BM_GETCHECK, 0, 0L))
						{ // Floor:
							pFieldT->pSurface[FACE_FLOOR]->iUsed--;
							pFieldT->iSurface[FACE_FLOOR] = pLevel->iCurrentSurface;
							pFieldT->pSurface[FACE_FLOOR] = pLevel->pCurrentSurface;
							pFieldT->pSurface[FACE_FLOOR]->iUsed++;
							pFieldT->iSurfaceRotation[FACE_FLOOR] = iEditorRotate;
							pFieldT->iCurrentAniStep[FACE_FLOOR] = 0;
							pFieldT->dwLastTime[FACE_FLOOR] = g_lNow;

						}
						if(SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_FRONT, BM_GETCHECK, 0, 0L))
						{ // Front:
							pFieldT->pSurface[FACE_FRONT]->iUsed--;
							pFieldT->iSurface[FACE_FRONT] = pLevel->iCurrentSurface;
							pFieldT->pSurface[FACE_FRONT] = pLevel->pCurrentSurface;
							pFieldT->pSurface[FACE_FRONT]->iUsed++;
							pFieldT->iSurfaceRotation[FACE_FRONT] = iEditorRotate;
							pFieldT->iCurrentAniStep[FACE_FRONT] = 0;
							pFieldT->dwLastTime[FACE_FRONT] = g_lNow;
						}
						if(SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_TOP, BM_GETCHECK, 0, 0L))
						{ // Top:
							pFieldT->pSurface[FACE_TOP]->iUsed--;
							pFieldT->iSurface[FACE_TOP] = pLevel->iCurrentSurface;
							pFieldT->pSurface[FACE_TOP] = pLevel->pCurrentSurface;
							pFieldT->pSurface[FACE_TOP]->iUsed++;
							pFieldT->iSurfaceRotation[FACE_TOP] = iEditorRotate;
							pFieldT->iCurrentAniStep[FACE_TOP] = 0;
							pFieldT->dwLastTime[FACE_TOP] = g_lNow;
						}
						if(SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_RIGHT, BM_GETCHECK, 0, 0L))
						{ // Right:
							pFieldT->pSurface[FACE_RIGHT]->iUsed--;
							pFieldT->iSurface[FACE_RIGHT] = pLevel->iCurrentSurface;
							pFieldT->pSurface[FACE_RIGHT] = pLevel->pCurrentSurface;
							pFieldT->pSurface[FACE_RIGHT]->iUsed++;
							pFieldT->iSurfaceRotation[FACE_RIGHT] = iEditorRotate;
							pFieldT->iCurrentAniStep[FACE_RIGHT] = 0;
							pFieldT->dwLastTime[FACE_RIGHT] = g_lNow;
						}
						if(SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_BOTTOM, BM_GETCHECK, 0, 0L))
						{ // Bottom:
							pFieldT->pSurface[FACE_BOTTOM]->iUsed--;
							pFieldT->iSurface[FACE_BOTTOM] = pLevel->iCurrentSurface;
							pFieldT->pSurface[FACE_BOTTOM] = pLevel->pCurrentSurface;
							pFieldT->pSurface[FACE_BOTTOM]->iUsed++;
							pFieldT->iSurfaceRotation[FACE_BOTTOM] = iEditorRotate;
							pFieldT->iCurrentAniStep[FACE_BOTTOM] = 0;
							pFieldT->dwLastTime[FACE_BOTTOM] = g_lNow;
						}
						if(SendDlgItemMessage(hWndT, IDC_EDITOR_SURFACE_LEFT, BM_GETCHECK, 0, 0L))
						{ // Left:
							pFieldT->pSurface[FACE_LEFT]->iUsed--;
							pFieldT->iSurface[FACE_LEFT] = pLevel->iCurrentSurface;
							pFieldT->pSurface[FACE_LEFT] = pLevel->pCurrentSurface;
							pFieldT->pSurface[FACE_LEFT]->iUsed++;
							pFieldT->iSurfaceRotation[FACE_LEFT] = iEditorRotate;
							pFieldT->iCurrentAniStep[FACE_LEFT] = 0;
							pFieldT->dwLastTime[FACE_LEFT] = g_lNow;
						}
					break;

					case EDITOR_BRUSH_MENU: // We set something into the level: (a wall, or deactivate a field...)
						bFieldChange = TRUE;
						switch(byEditorSelected)
						{
							case EDITOR_SELECTED_WALL: // Set a wall
								if(pFieldT->pActor || pFieldT->pBridgeActor ||pFieldT->pObject)
									break;
								pLevel->SetFieldWall(iX, iY, TRUE, FALSE);
							break;
			
							case EDITOR_SELECTED_DEACTIVATE_FIELD: // Deactivate a field
								pLevel->SetFieldWall(iX, iY, FALSE, FALSE);
								pFieldT->bActive = FALSE;
								pFieldT->bWall = FALSE;
							goto FreeField;
							
							case EDITOR_SELECTED_2_SIDES:
								pFieldT->bNoBackfaceCulling = TRUE;
							break;

							case EDITOR_SELECTED_CLEAR_FIELD:
							FreeField:
								// Destroy all actors on this field;
								if(pPlayer->iFieldID == pFieldT->iID)
									pPlayer->bActive = FALSE;
								for(i = 0; i < MAX_ACTORS; i++)
								{
									if(Actor[i].iFieldID == pFieldT->iID)
										Actor[i].bActive = FALSE;
								}
								if(pFieldT->pActor && pFieldT->bWall)
									pFieldT->bWall = FALSE;
								if(pFieldT->pBridgeActor)
									pFieldT->bActive = FALSE;
								pFieldT->pActor = pFieldT->pBridgeActor = pFieldT->pObject = NULL;
							break;
						}
					break;
				}
			}
			if(CHECK_KEY(ASMouse.byButtons, 1))
			{
				bFieldChange = TRUE;
				switch(byEditorSelected)
				{
					case EDITOR_SELECTED_WALL: // Delete a wall
						if(pFieldT->pActor || pFieldT->pBridgeActor ||pFieldT->pObject)
							break;
						pLevel->SetFieldWall(iX, iY, FALSE, FALSE);
					break;

					case EDITOR_SELECTED_DEACTIVATE_FIELD: // Activate a field
						if(iX != pLevel->iWidth-1 && iY != pLevel->iHeight-1)						
							pFieldT->bActive = TRUE;
						pLevel->SetFieldWall(iX, iY, TRUE, TRUE);
					break;

					case EDITOR_SELECTED_2_SIDES:
						pFieldT->bNoBackfaceCulling = FALSE;
					break;
				}
			}							
		}
	}

	// Camera speed adjust keys:
	if(CHECK_KEY(ASKeys, DIK_1))
		fCameraVelocity = 0.1f;
	if(CHECK_KEY(ASKeys, DIK_2))
		fCameraVelocity = 0.2f;
	if(CHECK_KEY(ASKeys, DIK_3))
		fCameraVelocity = 0.3f;
	if(CHECK_KEY(ASKeys, DIK_4))
		fCameraVelocity = 0.4f;
	if(CHECK_KEY(ASKeys, DIK_5))
		fCameraVelocity = 0.5f;
	if(CHECK_KEY(ASKeys, DIK_6))
		fCameraVelocity = 0.6f;
	if(CHECK_KEY(ASKeys, DIK_7))
		fCameraVelocity = 0.7f;
	if(CHECK_KEY(ASKeys, DIK_8))
		fCameraVelocity = 0.8f;
	if(CHECK_KEY(ASKeys, DIK_9))
		fCameraVelocity = 0.9f;
	if(CHECK_KEY(ASKeys, DIK_0))
		fCameraVelocity = 1.0f;

	// Check if something on the fields has changed:
	if(bFieldChange)
	{
		for(i = 0; i < MAX_ACTORS; i++)
			CheckActorField(&Actor[i]);
		pLevel->UpdateMissions();
		UpdateAllActorFields();
	}

	
	if(!bTerrainChange)
		return 0;	
	// Recalculate all if something on the terrain has changed:
	for(i = 0; i < MAX_ACTORS; i++)
	{
		Actor[i].fLastHeightCheckWorldPos[X] = 
		Actor[i].fLastHeightCheckWorldPos[Y] = -1.0f;
	}
	pPlayer->fLastHeightCheckWorldPos[X] = 
	pPlayer->fLastHeightCheckWorldPos[Y] = -1.0f;
	pLevel->CalculateFieldNormals();
	pLevel->CalculateFieldBoundingBoxes();
	return 0;
} // end EditorCheck()

void ManipulateColor(FLOAT3 *fColor, short iIncrease)
{ // begin ManipulateColor()
	char byColor = -1, byColors = 1, i;
	
	// Which color we have to manipulate?
	if(CHECK_KEY(ASMouse.byButtons, 0) && CHECK_KEY(ASMouse.byButtons, 1))
		byColors = 3;
	if(CHECK_KEY(ASMouse.byButtons, 0))
		byColor = R;
	else
	if(CHECK_KEY(ASMouse.byButtons, 1))
		byColor = G;
	else
	if(CHECK_KEY(ASMouse.byButtons, 2))
		byColor = B;
	if(byColor == -1 && byColors == 1)
		return;
	for(i = 0; i < byColors; i++)
	{
		if(byColors == 3)
			byColor = i;
		(*fColor)[byColor] += iIncrease/500.0f;
		if((*fColor)[byColor] < 0.0f)
			(*fColor)[byColor] = 0.0f;
		if((*fColor)[byColor] > 1.0f)
			(*fColor)[byColor] = 1.0f;
	}
} // end ManipulateColor()

void ManipulateDensity(FLOAT *fColor, short iIncrease)
{ // begin ManipulateDensity()
	if(!CHECK_KEY(ASMouse.byButtons, 0))
		return;
	*fColor += iIncrease/500.0f;
	if(*fColor < 0.0f)
		*fColor = 0.0f;
	if(*fColor > 1.0f)
		*fColor = 1.0f;
} // end ManipulateDensity()
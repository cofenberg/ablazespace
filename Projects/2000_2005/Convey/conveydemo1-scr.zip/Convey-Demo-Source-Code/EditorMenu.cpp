//-----------------------------------------------------------------------------
// File: EditorMenu.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Variables: *****************************************************************
HWND hWndEditor,				 // The editor window handle
	 hWndEditorTab[EDITOR_TABS], // The tab handles
	 hWndKeyword;				 // The keyword dialog handle
short iCurrentEditorTab;		 // The current selected tab
char byKeyword[256];			 // The level keyword (temp)
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern HRESULT EditorDraw(void);
extern HRESULT EditorCheck(void);
LRESULT CALLBACK EditorProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditorSelectProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditorBrushProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditorSurfacesProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditorObjectsProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditorTerrainProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditorEnvironmentProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditorCameraProc(HWND, UINT, WPARAM, LPARAM);
void SetupEditorTabs(void);
void SetEditorLanguage(void);
LRESULT CALLBACK KeywordProc(HWND, UINT, WPARAM, LPARAM);
void KeywordLanguage(void);
HRESULT SaveLevelQuestion(void);
LRESULT CALLBACK SetCameraVelocityProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK CopyCameraStepProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK SetCameraStepsProc(HWND, UINT, WPARAM, LPARAM);
///////////////////////////////////////////////////////////////////////////////


LRESULT CALLBACK EditorProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorProc()
	char *pbyTemp, byTemp[256];
	RECT Rect1, Rect2;
	BOOL bKeyword;
	short i, i2;
	FILE *fp;

    switch(iMessage)
    {
        case WM_INITDIALOG:
			if(!hWndEditor)
				iCurrentEditorTab = -1;
			hWndEditor = hWnd;
			bLevelComplete = FALSE;
			bPlayerCameraView = FALSE;
			// Setup the last size:
			if(_ASConfig->EditorWindow.left < 0)
			{
				_ASConfig->EditorWindow.right += -_ASConfig->EditorWindow.left;
				_ASConfig->EditorWindow.left = 0;
			}
			if(_ASConfig->EditorWindow.top < 0)
			{
				_ASConfig->EditorWindow.bottom += -_ASConfig->EditorWindow.top;
				_ASConfig->EditorWindow.top = 0;
			}
			SetWindowPos(hWndEditor, NULL, _ASConfig->EditorWindow.left, _ASConfig->EditorWindow.top,
						 _ASConfig->EditorWindow.right-_ASConfig->EditorWindow.left,
						 _ASConfig->EditorWindow.bottom-_ASConfig->EditorWindow.top, 0);
			GetWindowRect(hWndEditorShow, &Rect2);

			// Setup the level show area:
			hWndEditorShow = GetDlgItem(hWnd, IDC_EDITOR_LEVEL);
			ASInitOpenGL(NULL, hWndEditorShow, &hDCEditorShow, &hRCEditorShow, FALSE);
			GetWindowRect(hWndEditor, &Rect1);
			SetWindowPos(hWndEditorShow, NULL, 5, 120, Rect1.right-Rect1.left-20, Rect1.bottom-Rect1.top-170, 0);
			GetWindowRect(hWndEditorShow, &Rect2);
			wglMakeCurrent(hDCEditorShow, hRCEditorShow);
			ASConfigOpenGL(Rect2.right-Rect2.left, Rect2.bottom-Rect2.top);
			
			//
			_AS->CreateDXInputDevices(hWnd, FALSE, TRUE, TRUE, FALSE);
			BuildFont();
			SetTimer(hWnd, 1, 1, NULL);
					
			// Init editor size:
			sprintf(byTemp, "1x1");
			SendDlgItemMessage(hWnd, IDC_EDITOR_SIZE, LB_ADDSTRING, 0, (LONG)(LPSTR) byTemp);
			sprintf(byTemp, "2x2");
			SendDlgItemMessage(hWnd, IDC_EDITOR_SIZE, LB_ADDSTRING, 0, (LONG)(LPSTR) byTemp);
			for(i = 1; i < 5; i++)
			{
				sprintf(byTemp, "%dx%d", i*2+1, i*2+1);
				SendDlgItemMessage(hWnd, IDC_EDITOR_SIZE, LB_ADDSTRING, 0, (LONG)(LPSTR) byTemp);
			}
 			byEditorBrushSize = 0;
			SendDlgItemMessage(hWnd, IDC_EDITOR_SIZE, LB_SETCURSEL, byEditorBrushSize, 0L);
			
			InitGameObjects();
			LoadGameTextures();
			GenOpenGLGameTextures();

			// Setup the current level:
			pLevel = new LEVEL;
			if(bEditorTestLevel)
				pLevel->Load(byCurrentLevelName);
			else
			{
				pPlayer->bActive = FALSE;
				for(i = 0; i < MAX_ACTORS; i++)
					memset(&Actor[i], 0, sizeof(ACTOR));
				pLevel->Create(11, 11, -2, 1, 1);
			}
			bEditorTestLevel = FALSE;
			pLevel->GenTexturesOpenGL(hDCEditorShow, 
									  hRCEditorShow);
			

			// Setup the other stuff:
			TabCtrl_SetCurSel(GetDlgItem(hWnd, IDC_EDITOR_TAB), 0);
			SendMessage(hWnd, WM_NOTIFY, IDC_EDITOR_TAB, 0);
			g_lNow = GetTickCount();
			g_lLastlooptime = g_lNow;
			SetEditorLanguage();

			lCameraTimer = g_lNow;
			bCameraAnimation = 0;
			bPause = bLevelComplete = bCameraAnimation= FALSE;
			_AS->ShowMouseCursor(TRUE);
		return TRUE;

		case WM_PAINT: case WM_TIMER:
			pCamera->fPos[Z] = pCamera->fZ+STANDART_LEVEL_Z_POS;
			_AS->ReadDXInput(hWnd);
			EditorDraw();
			EditorCheck();
			_AS->UpdateWindows();
		break;

        case WM_SIZE:
			GetWindowRect(hWndEditor, &Rect1);
			SetWindowPos(hWndEditorShow, NULL, 5, 120, Rect1.right-Rect1.left-20, Rect1.bottom-Rect1.top-170, 0);
			GetWindowRect(hWndEditorShow, &Rect2);
			wglMakeCurrent(hDCEditorShow, hRCEditorShow);
			ASConfigOpenGL(Rect2.right-Rect2.left, Rect2.bottom-Rect2.top);
		break;

		case WM_COMMAND:
            switch(LOWORD(wParam))
            {				
				case ID_EDITOR_FILE_TEXTURES:
					DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_TEXTURES), hWnd, (DLGPROC) TexturesProc);
					ASInitOpenGL(NULL, hWndEditorShow, &hDCEditorShow, &hRCEditorShow, FALSE);
				break;
				
				case ID_EDITOR_FILE_CAMPAIGN_EDITOR:
					DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_CAMPAIGN_EDITOR), hWnd, (DLGPROC) CampaignEditorProc);
				break;

				case IDC_EDITOR_SIZE:
   					byEditorBrushSize = (char) SendDlgItemMessage(hWnd, IDC_EDITOR_SIZE, LB_GETCURSEL, 0, 0L);
				break;

			// Menu:
				case ID_EDITOR_FILE_GAME:
					_AS->SetNextModule(MODULE_GAME);
					goto Close;

				case ID_EDITOR_FILE_QUIT:
					_AS->SetShutDown(TRUE);
					goto Close;

				case ID_FILE_LEVEL_NEW:
					if(SaveLevelQuestion())
						break;
					NewLevelDialog();
					TabCtrl_SetCurSel(GetDlgItem(hWnd, IDC_EDITOR_TAB), 0);
					SendMessage(hWnd, WM_NOTIFY, IDC_EDITOR_TAB, 0);
				break;

				case ID_FILE_LEVEL_SAVE:
					if(pLevel->byFilename[0] == '\0')
						goto SaveAs;
					pLevel->Save(pLevel->byFilename);
				break;

				case ID_FILE_LEVEL_SAVEAS:
				SaveAs:
					sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbySingleLevelsFile);
					pbyTemp = ASGetFileName(hWnd, T_SaveLevel, LEV_FILE, 1, FALSE, byTemp);
					if(!pbyTemp)
						break;
					pLevel->Save(pbyTemp);
				break;

				case ID_FILE_LEVEL_LOAD:
					if(SaveLevelQuestion())
						break;
					sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbySingleLevelsFile);
					pbyTemp = ASGetFileName(hWnd, T_LoadLevel, LEV_FILE, 0, FALSE, byTemp);
					if(!pbyTemp)
						break;
					// Check for keyword:
					fp = fopen(pbyTemp, "rb");
					if(!fp)
						break;
					fread(&bKeyword, sizeof(BOOL), 1, fp);
					fread(&byKeyword, sizeof(char)*256, 1, fp);
					fclose(fp);
					if(bKeyword && !bMasterAccess)
					{ // Check the keyword:
						bKeyword = DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_KEYWORD), hWnd, (DLGPROC) KeywordProc);
						if(!bKeyword)
						{ // Wrong keyword!!
							MessageBox(hWnd, M_WrongKeyword, GAME_NAME, MB_OK | MB_ICONINFORMATION);
							break;
						}
						else
							if(bKeyword == -1)
								break;
					}
					pLevel->Load(pbyTemp);
					TabCtrl_SetCurSel(GetDlgItem(hWnd, IDC_EDITOR_TAB), 0);
					SendMessage(hWnd, WM_NOTIFY, IDC_EDITOR_TAB, 0);
				break;

				case ID_FILE_LEVEL_PLAY:
					_AS->WriteLogMessage("Editor: Play current level");
					if(pLevel->byFilename[0] == '\0')
					{
						_AS->WriteLogMessage("Error: The current level has no filename");
						MessageBox(hWnd, M_TheLevelHasNoFilename, T_Error, MB_OK | MB_ICONINFORMATION);
						goto SaveAs;
					}
					_AS->WriteLogMessage("Save level %s", pLevel->byFilename);
					pLevel->Save(pLevel->byFilename);
					bEditorTestLevel = TRUE;
					sprintf(byCurrentLevelName, pLevel->byFilename);
					_AS->SetNextModule(MODULE_GAME);
					EndDialog(hWndEditor, FALSE);
				break;
				
				case ID_FILE_LEVEL_ADJUST:
					AdjustLevelDialog();
				break;

			// Options:
				case ID_OPTIONS_CONFIG:
					OpenConfigDialog(hWnd);
				break;

			// Help:
				case ID_HELP_HELP:
					OpenHelp();
				break;
				
				case ID_HELP_HOMEPAGE:
					_AS->WriteLogMessage("Open homepage");
					ShellExecute(0, "open", "http://ablazespace.exit.de/", 0, 0, SW_SHOW);
				break;

				case ID_HELP_CREDITS:
					OpenCreditsDialog(hWnd);
				break;
				
				case ID_FILE_SHOW_LOG:
					_AS->WriteLogMessage("Open Log");
					sprintf(byTemp, "%s"AS_LOG_FILE, _AS->pbyProgramPath);
					ShellExecute(0, "open", byTemp, 0, 0, SW_SHOW);				
				break;
            }
        break;

        case WM_NOTIFY: 
			switch(wParam)
			{
				case IDC_EDITOR_TAB:
					i = TabCtrl_GetCurSel(GetDlgItem(hWnd, IDC_EDITOR_TAB));
					if(i == iCurrentEditorTab)
						break; // This tab is already opend
					iCurrentEditorTab = i;
					for(i2 = 0; i2 < EDITOR_TABS; i2++)
					{
						ShowWindow(hWndEditorTab[i2], SW_HIDE);
						UpdateWindow(hWndEditorTab[i2]);
					}
					ShowWindow(hWndEditorTab[i], SW_SHOW);
					UpdateWindow(hWndEditorTab[i]);
					UpdateWindow(hWnd);
					SetFocus(hWndEditorTab[i]);
					SendMessage(hWndEditorTab[i], WM_INITDIALOG, 0, 0);
				break;
			} 
		break; 

		case WM_CLOSE:
			_AS->SetShutDown(TRUE);
		Close:
			if(SaveLevelQuestion())
			{ // The user will not close the editor:
				_AS->SetShutDown(FALSE);
				break;
			}
			GetWindowRect(hWndEditor, &_ASConfig->EditorWindow);

			DestroyOpenGLGameTextures();
			DestroyGameTextures();
			pLevel->DestroyTexturesOpenGL(hDCEditorShow, hRCEditorShow);
			KillFont();

			// This makes some trouble if you go to game and switch back to editor...
			if(_AS->GetNextModule() != MODULE_GAME)
				ASDestroyOpenGL(NULL, hWndEditorShow, hDCEditorShow, hRCEditorShow);

			_AS->FreeDXInputDevices();
			
			DestroyGameObjects();
			DestroyLevel(&pLevel);
			KillTimer(hWnd, 1);
			hWndEditor = NULL;
			hWndEditorShow = NULL;
			for(i2 = 0; i2 < EDITOR_TABS; i2++)
				hWndEditorTab[i2] = NULL;
			EndDialog(hWnd, FALSE);
			// Save the configuration:	
			sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyConfigFile);
			_ASConfig->Save(byTemp);
		break;
    }
    return FALSE;
} // end EditorProc()

LRESULT CALLBACK EditorSelectProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorSelectProc()
	switch(iMessage)
    {
        case WM_INITDIALOG:
  			// Texts:
			//
			byEditorMenu = EDITOR_SELECT_MENU;
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case 0:
				break;
            }
            break;
    }
    return FALSE;
} // end EditorSelectProc()

LRESULT CALLBACK EditorBrushProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorBrushProc()
	switch(iMessage)
    {
        case WM_INITDIALOG:
  			// Texts:
			SetDlgItemText(hWnd, IDC_EDITOR_BRUSH_WALL, T_Wall);
			SetDlgItemText(hWnd, IDC_EDITOR_BRUSH_DEACTIVATE_FIELD, T_DeactivateField);
			SetDlgItemText(hWnd, IDC_EDITOR_BRUSH_2_SIDES, T_2Sides);
			SetDlgItemText(hWnd, IDC_EDITOR_BRUSH_CLEAR_FIELD, T_ClearField);
			//
			byEditorMenu = EDITOR_BRUSH_MENU;
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_EDITOR_BRUSH_WALL:
					byEditorSelected = EDITOR_SELECTED_WALL;
				break;
				
				case IDC_EDITOR_BRUSH_DEACTIVATE_FIELD:
					byEditorSelected = EDITOR_SELECTED_DEACTIVATE_FIELD;
				break;
				
				case IDC_EDITOR_BRUSH_2_SIDES:
					byEditorSelected = EDITOR_SELECTED_2_SIDES;
				break;

				case IDC_EDITOR_BRUSH_CLEAR_FIELD:
					byEditorSelected = EDITOR_SELECTED_CLEAR_FIELD;
				break;
            }
            break;
    }
    return FALSE;
} // end EditorBrushProc()

LRESULT CALLBACK EditorSurfacesProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorSurfacesProc()
	char byTemp[256];
	
	switch(iMessage)
    {
        case WM_INITDIALOG:
  			// Texts:
			SetDlgItemText(hWnd, IDC_EDITOR_SURFACES_CHOOSE, T_Surface);
			SetDlgItemText(hWnd, IDC_EDITOR_SURFACES_ROTATION_T, T_Rotation);
			byEditorMenu = EDITOR_SURFACE_MENU;
			//
		Init:
			sprintf(byTemp, "%d�", iEditorRotate*90);
			SetDlgItemText(hWnd, IDC_EDITOR_SURFACES_ROTATION, byTemp);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_EDITOR_SURFACES_CHOOSE:
					DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_SURFACES), hWnd, (DLGPROC) SurfacesProc);
					ASInitOpenGL(NULL, hWndEditorShow, &hDCEditorShow, &hRCEditorShow, FALSE);
				break;

				case IDC_EDITOR_SURFACES_PLUS:
					iEditorRotate++;
					if(iEditorRotate > 3)
						iEditorRotate = 0;
					goto Init;

				case IDC_EDITOR_SURFACES_MINUS:
					iEditorRotate--;
					if(iEditorRotate < 0)
						iEditorRotate = 3;
					goto Init;
            }
            break;
    }
    return FALSE;
} // end EditorSurfacesProc()

LRESULT CALLBACK EditorObjectsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorObjectsProc()
	char byTemp[256];
	short i;

	switch(iMessage)
    {
        case WM_INITDIALOG:
  			// Texts:
			SetDlgItemText(hWnd, IDC_EDITOR_OBJECTS_ROTATION_T, T_Rotation);
			SetDlgItemText(hWnd, IDC_EDITOR_OBJECTS_HEAVY, T_Heavy);
			byEditorSelected = EDITOR_SELECTED_OBJECT_XE;
			//
		Init:
			// Objects list:
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_RESETCONTENT , 0, 0L);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) "Xe");
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_BoxNormal);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_BoxRed);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_BoxGreen);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_BoxBlue);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_HealthObj);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_LiveObj);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_PullObj);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_ThrowObj);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_ForceObj);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_WeaponObj);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_PointObj);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_GhostObj);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_TimeObj);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_StepObj);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_SpeedObj);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_WingsObj);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_ShieldObj);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_Jump);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_ADDSTRING, 0, (LPARAM) T_Air);
			SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_SETCURSEL, byEditorSelected-EDITOR_SELECTED_OBJECT_XE, 0L);
			// Rotation:
			sprintf(byTemp, "%d�", iEditorRotate*90);
			SetDlgItemText(hWnd, IDC_EDITOR_OBJECTS_ROTATION, byTemp);
			byEditorMenu = EDITOR_OBJECT_MENU;
			bEditorHeavy = FALSE;
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_EDITOR_OBJECTS_LIST:
					i = (short) SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_LIST, CB_GETCURSEL, 0, 0L);
					if(i < 0)
						i = 0;
					if(i > 19)
						i = 19;
					switch(i)
					{
						case 0: byEditorSelected = EDITOR_SELECTED_OBJECT_XE; break;
						case 1: byEditorSelected = EDITOR_SELECTED_OBJECT_BOX_NORMAL; break;
						case 2: byEditorSelected = EDITOR_SELECTED_OBJECT_BOX_RED; break;
						case 3: byEditorSelected = EDITOR_SELECTED_OBJECT_BOX_GREEN; break;
						case 4: byEditorSelected = EDITOR_SELECTED_OBJECT_BOX_BLUE; break;
						case 5: byEditorSelected = EDITOR_SELECTED_OBJECT_HEALTH; break;
						case 6: byEditorSelected = EDITOR_SELECTED_OBJECT_LIVE; break;
						case 7: byEditorSelected = EDITOR_SELECTED_OBJECT_PULL; break;
						case 8: byEditorSelected = EDITOR_SELECTED_OBJECT_THROW; break;
						case 9: byEditorSelected = EDITOR_SELECTED_OBJECT_FORCE; break;
						case 10: byEditorSelected = EDITOR_SELECTED_OBJECT_WEAPON; break;
						case 11: byEditorSelected = EDITOR_SELECTED_OBJECT_POINT; break;
						case 12: byEditorSelected = EDITOR_SELECTED_OBJECT_GHOST; break;
						case 13: byEditorSelected = EDITOR_SELECTED_OBJECT_TIME; break;
						case 14: byEditorSelected = EDITOR_SELECTED_OBJECT_STEP; break;
						case 15: byEditorSelected = EDITOR_SELECTED_OBJECT_SPEED; break;
						case 16: byEditorSelected = EDITOR_SELECTED_OBJECT_WING; break;
						case 17: byEditorSelected = EDITOR_SELECTED_OBJECT_SHIELD; break;
						case 18: byEditorSelected = EDITOR_SELECTED_OBJECT_JUMP; break;
						case 19: byEditorSelected = EDITOR_SELECTED_OBJECT_AIR; break;
					}
				break;

				case IDC_EDITOR_OBJECTS_PLUS:
					iEditorRotate++;
					if(iEditorRotate > 3)
						iEditorRotate = 0;
					goto Init;

				case IDC_EDITOR_OBJECTS_MINUS:
					iEditorRotate--;
					if(iEditorRotate < 0)
						iEditorRotate = 3;
					goto Init;
				
				case IDC_EDITOR_OBJECTS_HEAVY:
					bEditorHeavy = SendDlgItemMessage(hWnd, IDC_EDITOR_OBJECTS_HEAVY, BM_GETCHECK, 0, 0L);
				break;
            }
		break;
    }
    return FALSE;
} // end EditorObjectsProc()

LRESULT CALLBACK EditorTerrainProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorTerrainProc()
	switch(iMessage)
    {
        case WM_INITDIALOG:
  			// Texts:
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_COLOR, T_Color);
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_HEIGHT, T_Height);
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_POINT, T_Point);
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_MIDDLE_HEIGHT, T_MiddleHeight);
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_GREATEST_HEIGHT, T_GreatestHeight);
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_LOWEST_HEIGHT, T_LowestHeight);
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_TOP, T_Top);
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_FLOOR, T_Floor);
			SetDlgItemText(hWnd, IDC_EDITOR_TERRAIN_BOTH, T_Both);
			//
			byEditorMenu = EDITOR_TERRAIN_MENU;
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_EDITOR_TERRAIN_COLOR:
					byEditorSelected = EDITOR_SELECTED_COLOR;
				break;

				case IDC_EDITOR_TERRAIN_HEIGHT:
					byEditorSelected = EDITOR_SELECTED_HEIGHT;
				break;

				case IDC_EDITOR_TERRAIN_POINT:
					byEditorSelected = EDITOR_SELECTED_POINT;
				break;

				case IDC_EDITOR_TERRAIN_MIDDLE_HEIGHT:
					byEditorSelected = EDITOR_SELECTED_MIDDLE_HEIGHT;
				break;
				
				case IDC_EDITOR_TERRAIN_LOWEST_HEIGHT:
					byEditorSelected = EDITOR_SELECTED_LOWEST_HEIGHT;
				break;

				case IDC_EDITOR_TERRAIN_GREATEST_HEIGHT:
					byEditorSelected = EDITOR_SELECTED_GREATEST_HEIGHT;
				break;
            }
            break;
    }
    return FALSE;
} // end EditorTerrainProc()

LRESULT CALLBACK EditorEnvironmentProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorEnvironmentProc()
	char byTemp[256];
	short i;
	
	switch(iMessage)
    {
        case WM_INITDIALOG:
  			// Texts:
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_LIGHT, T_Color);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_FOG_T, T_Fog);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_FOG, T_Active);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_FOG_COLOR, T_Color);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_FOG_DENSITY, T_Density);
		    SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_FOG, BM_SETCHECK, pLevel->bFog, 0L);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_WATER_T, T_Water);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_WATER, T_Active);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_WATER_COLOR, T_Color);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_WATER_DENSITY, T_Density);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_WATER_HEIGHT, T_Height);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_WATER_AMPLITUDE, T_Amplitude);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_WATER_SPEED, T_SpeedObj);
		    SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_WATER, BM_SETCHECK, pLevel->bWater, 0L);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_SKY_CUBE_T, T_SkyCube);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_SKY_CUBE, T_Active);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_SKY_CUBE_COLOR, T_Color);
			SetDlgItemText(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SIZE, T_Size);
		    SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE, BM_SETCHECK, pLevel->bSkyCube, 0L);
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SIDE, CB_RESETCONTENT, 0, 0L);
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SIDE, CB_ADDSTRING, 0, (LPARAM) T_Floor);
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SIDE, CB_ADDSTRING, 0, (LPARAM) T_Sky);
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SIDE, CB_ADDSTRING, 0, (LPARAM) T_Back);
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SIDE, CB_ADDSTRING, 0, (LPARAM) T_Front);
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SIDE, CB_ADDSTRING, 0, (LPARAM) T_Right);
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SIDE, CB_ADDSTRING, 0, (LPARAM) T_Left);
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SIDE, CB_SETCURSEL, byCurrentSkyCubeSide, 0L);
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_ALL, CB_ADDSTRING, 0, (LPARAM) T_All);
			//
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SURFACE, CB_RESETCONTENT, 0, 0L);
			for(i = 0; i < pLevel->iSurfaces; i++)
			{
				sprintf(byTemp, "%s", pLevel->pSurface[i].byName);
				SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SURFACE, CB_ADDSTRING, 0, (LPARAM) byTemp);
			}
			SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SURFACE, CB_SETCURSEL, pLevel->iSkyCubeSurface[byCurrentSkyCubeSide], 0L);
			byEditorMenu = EDITOR_ENVIRONMENT_MENU;
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_ENVIRONMENT_LIGHT: byEditorSelected = EDITOR_ENVIRONMENT_LIGHT; break;
				case IDC_ENVIRONMENT_FOG: pLevel->bFog = SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_FOG, BM_GETCHECK, 0, 0L); break;
				case IDC_ENVIRONMENT_WATER: pLevel->bWater = SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_WATER, BM_GETCHECK, 0, 0L); break;
				case IDC_ENVIRONMENT_FOG_COLOR: byEditorSelected = EDITOR_ENVIRONMENT_FOG_COLOR; break;
				case IDC_ENVIRONMENT_FOG_DENSITY: byEditorSelected = EDITOR_ENVIRONMENT_FOG_DENSITY; break;
				case IDC_ENVIRONMENT_WATER_COLOR: byEditorSelected = EDITOR_ENVIRONMENT_WATER_COLOR; break;
				case IDC_ENVIRONMENT_WATER_DENSITY: byEditorSelected = EDITOR_ENVIRONMENT_WATER_DENSITY; break;
				case IDC_ENVIRONMENT_WATER_HEIGHT: byEditorSelected = EDITOR_ENVIRONMENT_WATER_HEIGHT; break;
				case IDC_ENVIRONMENT_WATER_AMPLITUDE: byEditorSelected = EDITOR_ENVIRONMENT_WATER_AMPLITUDE; break;
				case IDC_ENVIRONMENT_WATER_SPEED: byEditorSelected = EDITOR_ENVIRONMENT_WATER_SPEED; break;

				case IDC_ENVIRONMENT_SKY_CUBE_SIDE:
					i = (short) SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SIDE, CB_GETCURSEL, 0, 0L);
					if(i < 0 || i > 6)
						byCurrentSkyCubeSide = 0;
					else
						byCurrentSkyCubeSide = (char) i;
					SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SURFACE, CB_SETCURSEL, pLevel->iSkyCubeSurface[byCurrentSkyCubeSide], 0L);
				break;

				case IDC_ENVIRONMENT_SKY_CUBE_SURFACE:
					i = (short) SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE_SURFACE, CB_GETCURSEL, 0, 0L);
					if(i < 0 || i > pLevel->iSurfaces-1)
					{
						pLevel->iCurrentSurface	= -1;
						pLevel->pCurrentSurface = NULL;
					}
					else
						pLevel->iSkyCubeSurface[byCurrentSkyCubeSide] = pLevel->iCurrentSurface	= i;
				break;

				case IDC_ENVIRONMENT_SKY_CUBE: pLevel->bSkyCube = SendDlgItemMessage(hWnd, IDC_ENVIRONMENT_SKY_CUBE, BM_GETCHECK, 0, 0L); break;
				case IDC_ENVIRONMENT_SKY_CUBE_COLOR: byEditorSelected = EDITOR_ENVIRONMENT_SKY_CUBE_COLOR; break;
				case IDC_ENVIRONMENT_SKY_CUBE_SIZE: byEditorSelected = EDITOR_ENVIRONMENT_SKY_CUBE_SIZE; break;

				case IDC_ENVIRONMENT_SKY_CUBE_PLUS:
					pLevel->iSkyCubeSurfaceRotation[byCurrentSkyCubeSide]++;
					if(pLevel->iSkyCubeSurfaceRotation[byCurrentSkyCubeSide] > 4)
						pLevel->iSkyCubeSurfaceRotation[byCurrentSkyCubeSide] = 0;
				break;

				case IDC_ENVIRONMENT_SKY_CUBE_MINUS:
					pLevel->iSkyCubeSurfaceRotation[byCurrentSkyCubeSide]--;
					if(pLevel->iSkyCubeSurfaceRotation[byCurrentSkyCubeSide] < 0)
						pLevel->iSkyCubeSurfaceRotation[byCurrentSkyCubeSide] = 4;
				break;

				case IDC_ENVIRONMENT_SKY_CUBE_ALL:
					for(i = 0; i < 6; i++)
					{
						pLevel->iSkyCubeSurface[i] = pLevel->iCurrentSurface;
						pLevel->iSkyCubeSurfaceRotation[i] = pLevel->iSkyCubeSurfaceRotation[byCurrentSkyCubeSide];
					}
				break;
            }
            break;
    }
    return FALSE;
} // end EditorEnvironmentProc()

LRESULT CALLBACK EditorCameraProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin EditorCameraProc()
	char byTemp[256];
	BOOL bEnable;
	short i, i2;

	switch(iMessage)
    {
        case WM_INITDIALOG:
  			// Texts:
			SetDlgItemText(hWnd, IDC_EDITOR_CAMERA_SET_VELOCITY, T_CameraVelocity);

			if(!bCameraAnimation)
				SetDlgItemText(hWnd, IDC_EDITOR_CAMERA_PLAY, T_Play);
			else
				SetDlgItemText(hWnd, IDC_EDITOR_CAMERA_PLAY, T_Stop);
		Init:
			SendDlgItemMessage(hWnd, ID_EDITOR_CAMERA_SELECTED, LB_RESETCONTENT, 0, 0L);
			for(i = 0; i < pLevel->iCameraScripts; i++)
			{
				sprintf(byTemp, "%s", pLevel->pCameraScript[i].byName);
				SendDlgItemMessage(hWnd, ID_EDITOR_CAMERA_SELECTED, LB_ADDSTRING, 0, (LPARAM) byTemp);
			}
			SendDlgItemMessage(hWnd, ID_EDITOR_CAMERA_SELECTED, LB_SETCURSEL, pLevel->iCurrentCameraScript, 0L);
		Init2:
			if(pLevel->pCurrentCameraScript)
			{
				bEnable = TRUE;
				if(pLevel->iCurrentCameraStep < 0)
					pLevel->iCurrentCameraStep = 0;
				if(pLevel->iCurrentCameraStep >= pLevel->pCurrentCameraScript->iSteps)
					pLevel->iCurrentCameraStep = pLevel->pCurrentCameraScript->iSteps-1;
				SetDlgItemText(hWnd, IDC_EDITOR_CAMERA_NAME, pLevel->pCurrentCameraScript->byName);
				SendDlgItemMessage(hWnd, IDC_EDITOR_CAMERA_STEP_LIST, CB_RESETCONTENT, 0, 0L);
				for(i = 0; i < pLevel->pCurrentCameraScript->iSteps; i++)
				{
					sprintf(byTemp, "%d", i);
					SendDlgItemMessage(hWnd, IDC_EDITOR_CAMERA_STEP_LIST, CB_ADDSTRING, 0, (LPARAM) byTemp);
				}
				SendDlgItemMessage(hWnd, IDC_EDITOR_CAMERA_STEP_LIST, CB_SETCURSEL, pLevel->iCurrentCameraStep, 0L);
				sprintf(byTemp, "%d", pLevel->pCurrentCameraScript->pCamera[pLevel->iCurrentCameraStep].iTimeToNext);
				SetDlgItemText(hWnd, IDC_EDITOR_CAMERA_NEXT_TIME, byTemp);				
			}
			else
				bEnable = FALSE;
			EnableWindow(GetDlgItem(hWnd, ID_EDITOR_CAMERA_DUPLICATE), bEnable);
			EnableWindow(GetDlgItem(hWnd, ID_EDITOR_CAMERA_DELETE), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_NAME), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_COPY_LEFT), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_COPY), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_COPY_RIGHT), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_PLAY), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_STEPS), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_STEP_LIST), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_NEXT_TIME), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_EDITOR_CAMERA_NEXT_TIME_ALL), bEnable);
			//
			byEditorMenu = EDITOR_CAMERA_MENU;
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDC_EDITOR_CAMERA_SET_VELOCITY:
					DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_SET_CAMERA_VELOCITY), hWnd, (DLGPROC) SetCameraVelocityProc);
				break;
				
				case ID_EDITOR_CAMERA_NEW:
					// Create a new camera script:
					pLevel->iCameraScripts++;
					pLevel->pCameraScript = (AS_CAMERA_SCRIPT *) realloc(pLevel->pCameraScript, sizeof(AS_CAMERA_SCRIPT)*pLevel->iCameraScripts);
					memset(&pLevel->pCameraScript[pLevel->iCameraScripts-1], 0, sizeof(AS_CAMERA_SCRIPT));
					pLevel->iCurrentCameraScript = pLevel->iCameraScripts-1;
					pLevel->pCurrentCameraScript = &pLevel->pCameraScript[pLevel->iCurrentCameraScript];
					// Create the temp camera:
					pLevel->pCurrentCameraScript->iSteps++;
					pLevel->pCurrentCameraScript->pCamera = (AS_CAMERA *) malloc(sizeof(AS_CAMERA)*pLevel->pCurrentCameraScript->iSteps);
					memset(&pLevel->pCurrentCameraScript->pCamera[0], 0, sizeof(AS_CAMERA));
					sprintf(pLevel->pCurrentCameraScript->byName, "Camera script %d", pLevel->iCurrentCameraScript);
					goto Init;

				case ID_EDITOR_CAMERA_DUPLICATE:
					// Create a new camera script:
					pLevel->iCameraScripts++;
					pLevel->pCameraScript = (AS_CAMERA_SCRIPT *) realloc(pLevel->pCameraScript, sizeof(AS_CAMERA_SCRIPT)*pLevel->iCameraScripts);
					memset(&pLevel->pCameraScript[pLevel->iCameraScripts-1], 0, sizeof(AS_CAMERA_SCRIPT));
					pLevel->pCurrentCameraScript = &pLevel->pCameraScript[pLevel->iCurrentCameraScript];
					// Copy the script into the duplicate:
					memcpy(&pLevel->pCameraScript[pLevel->iCameraScripts-1], pLevel->pCurrentCameraScript, sizeof(AS_CAMERA_SCRIPT));
					pLevel->pCameraScript[pLevel->iCameraScripts-1].pCamera = (AS_CAMERA *) malloc(sizeof(AS_CAMERA)*pLevel->pCameraScript[pLevel->iCameraScripts-1].iSteps);
					for(i = 0; i < pLevel->pCurrentCameraScript->iSteps; i++)
						memcpy(&pLevel->pCameraScript[pLevel->iCameraScripts-1].pCamera[i], &pLevel->pCurrentCameraScript->pCamera[i], sizeof(AS_CAMERA));
					// Setup new camera script:
					pLevel->iCurrentCameraScript = pLevel->iCameraScripts-1;
					pLevel->pCurrentCameraScript = &pLevel->pCameraScript[pLevel->iCurrentCameraScript];
					sprintf(pLevel->pCurrentCameraScript->byName, "Camera script %d", pLevel->iCurrentCameraScript);
					goto Init;
				
				case ID_EDITOR_CAMERA_DELETE:
					// Update the camera users:
					if(pLevel->iStartCamera == pLevel->iCurrentCameraScript)
						pLevel->bStartCamera = FALSE;
					else
						if(pLevel->iStartCamera > pLevel->iCurrentCameraScript)
							pLevel->iStartCamera--;
					if(pLevel->iEndCamera == pLevel->iCurrentCameraScript)
						pLevel->bEndCamera = FALSE;
					else
						if(pLevel->iEndCamera > pLevel->iCurrentCameraScript)
							pLevel->iEndCamera--;

					// Delete the selected camera script:
					free(pLevel->pCurrentCameraScript->pCamera);
					for(i = pLevel->iCurrentCameraScript; i < pLevel->iCameraScripts-1; i++)
						memcpy(&pLevel->pCameraScript[i], &pLevel->pCameraScript[i+1], sizeof(AS_CAMERA_SCRIPT));
					pLevel->iCameraScripts--;
					pLevel->pCameraScript = (AS_CAMERA_SCRIPT *) realloc(pLevel->pCameraScript, sizeof(AS_CAMERA_SCRIPT)*pLevel->iCameraScripts);
					if(pLevel->iCurrentCameraScript >= pLevel->iCameraScripts)
						pLevel->iCurrentCameraScript = pLevel->iCameraScripts-1;
					if(pLevel->iCurrentCameraScript != -1)
						pLevel->pCurrentCameraScript = &pLevel->pCameraScript[pLevel->iCurrentCameraScript];
					else
						pLevel->pCurrentCameraScript = NULL;
					goto Init;

				case ID_EDITOR_CAMERA_SELECTED:
					i = (short) SendDlgItemMessage(hWnd, ID_EDITOR_CAMERA_SELECTED, LB_GETCURSEL, 0, 0L);
					if(i < 0)
						i = 0;
					if(i >= pLevel->iCameraScripts)
						i = pLevel->iCameraScripts-1;
					pLevel->iCurrentCameraScript = i;
					if(pLevel->iCurrentCameraScript < 0)
					{
						pLevel->pCurrentCameraScript = NULL;
						break;
					}
					pLevel->pCurrentCameraScript = &pLevel->pCameraScript[pLevel->iCurrentCameraScript];
					goto Init2;

				case IDC_EDITOR_CAMERA_NAME:
					GetDlgItemText(hWnd, IDC_EDITOR_CAMERA_NAME, pLevel->pCurrentCameraScript->byName, 256);
					SendDlgItemMessage(hWnd, ID_EDITOR_CAMERA_SELECTED, LB_RESETCONTENT, 0, 0L);
					for(i = 0; i < pLevel->iCameraScripts; i++)
					{
						sprintf(byTemp, "%s", pLevel->pCameraScript[i].byName);
						SendDlgItemMessage(hWnd, ID_EDITOR_CAMERA_SELECTED, LB_ADDSTRING, 0, (LPARAM) byTemp);
					}
					SendDlgItemMessage(hWnd, ID_EDITOR_CAMERA_SELECTED, LB_SETCURSEL, pLevel->iCurrentCameraScript, 0L);
				break;

				case IDC_EDITOR_CAMERA_COPY:
					if((i = DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_COPY_CAMERA_STEP), hWnd, (DLGPROC) CopyCameraStepProc)) == -1)
						break;
					memcpy(&pLevel->pCurrentCameraScript->pCamera[i], &pLevel->pCurrentCameraScript->pCamera[pLevel->iCurrentCameraStep], sizeof(AS_CAMERA));
					pLevel->iCurrentCameraStep = i;
					goto Init2;

				case IDC_EDITOR_CAMERA_COPY_LEFT:
					i = pLevel->iCurrentCameraStep-1;
					if(i < 0)
						i = pLevel->pCurrentCameraScript->iSteps-1;
					memcpy(&pLevel->pCurrentCameraScript->pCamera[i], &pLevel->pCurrentCameraScript->pCamera[pLevel->iCurrentCameraStep], sizeof(AS_CAMERA));
					pLevel->iCurrentCameraStep = i;
					goto Init2;

				case IDC_EDITOR_CAMERA_COPY_RIGHT:
					i = pLevel->iCurrentCameraStep+1;
					if(i >= pLevel->pCurrentCameraScript->iSteps)
						i = 0;
					memcpy(&pLevel->pCurrentCameraScript->pCamera[i], &pLevel->pCurrentCameraScript->pCamera[pLevel->iCurrentCameraStep], sizeof(AS_CAMERA));
					pLevel->iCurrentCameraStep = i;
					goto Init2;
				break;

				case IDC_EDITOR_CAMERA_STEPS:
					if((i = DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_SET_CAMERA_STEPS), hWnd, (DLGPROC) SetCameraStepsProc)) == -1)
						break;
					i2 = pLevel->pCurrentCameraScript->iSteps;
					pLevel->pCurrentCameraScript->iSteps = i;
					pLevel->pCurrentCameraScript->pCamera = (AS_CAMERA *) realloc(pLevel->pCurrentCameraScript->pCamera, sizeof(AS_CAMERA)*pLevel->pCurrentCameraScript->iSteps);
					for(; i2 < i; i2++)
						memset(&pLevel->pCurrentCameraScript->pCamera[i2], 0, sizeof(AS_CAMERA));
					if(pLevel->iCurrentCameraStep >= pLevel->pCurrentCameraScript->iSteps)
						pLevel->iCurrentCameraStep = pLevel->pCurrentCameraScript->iSteps-1;
					goto Init2;

				case IDC_EDITOR_CAMERA_NEXT_TIME:
					GetDlgItemText(hWnd, IDC_EDITOR_CAMERA_NEXT_TIME, byTemp, 256);
					pLevel->pCurrentCameraScript->pCamera[pLevel->iCurrentCameraStep].iTimeToNext = (short) atoi(byTemp);
				break;

				case IDC_EDITOR_CAMERA_NEXT_TIME_ALL:
					for(i = 0; i < pLevel->pCurrentCameraScript->iSteps; i++)
						pLevel->pCurrentCameraScript->pCamera[i].iTimeToNext = pLevel->pCurrentCameraScript->pCamera[pLevel->iCurrentCameraStep].iTimeToNext;
				break;

				case IDC_EDITOR_CAMERA_STEP_LIST:
					if(!pLevel->pCurrentCameraScript)
						goto Init;
					i = (short) SendDlgItemMessage(hWnd, IDC_EDITOR_CAMERA_STEP_LIST, CB_GETCURSEL, 0, 0L);
					if(i < 0)
						i = 0;
					if(i >= pLevel->pCurrentCameraScript->iSteps)
						i = pLevel->pCurrentCameraScript->iSteps-1;
					pLevel->iCurrentCameraStep = i;
					// Set the level camera to  this camera:
					memcpy(pCamera, &pLevel->pCurrentCameraScript->pCamera[pLevel->iCurrentCameraStep], sizeof(AS_CAMERA));
					goto Init2;
				
				case IDC_EDITOR_CAMERA_PLAY:
					lCameraTimer = g_lNow;
					bCameraAnimation = !bCameraAnimation;
					memset(&TempCamera, 0, sizeof(AS_CAMERA));
					if(!bCameraAnimation)
					{
						SetDlgItemText(hWnd, IDC_EDITOR_CAMERA_PLAY, T_Play);
						memcpy(pCamera, &pLevel->pCurrentCameraScript->pCamera[pLevel->iCurrentCameraStep], sizeof(AS_CAMERA));
					}
					else
					{
						SetDlgItemText(hWnd, IDC_EDITOR_CAMERA_PLAY, T_Stop);
						pLevel->iCurrentCameraStep = 0;
					}
				break;

				case IDC_EDITOR_CAMERA_SET:
					// Set the level camera to the camera from the script:
					memcpy(&pLevel->pCurrentCameraScript->pCamera[pLevel->iCurrentCameraStep], pCamera, sizeof(AS_CAMERA));
				break;
            }
            break;
    }
    return FALSE;
} // end EditorCameraProc()

void SetupEditorTabs(void)
{ // begin SetupEditorTabs()
	HWND hWndTab;
	TC_ITEM tie; 

	// Setup editor tabs:
	hWndTab = GetDlgItem(hWndEditor, IDC_EDITOR_TAB);
	TabCtrl_DeleteAllItems(hWndTab);
	tie.mask = TCIF_TEXT;
	// Select:
	tie.pszText	= T_Select;
	TabCtrl_InsertItem(hWndTab, TAB_EDITOR_SELECT, &tie);
	if(hWndEditorTab[TAB_EDITOR_SELECT])
		DestroyWindow(hWndEditorTab[TAB_EDITOR_SELECT]);
	hWndEditorTab[TAB_EDITOR_SELECT] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_SELECT), hWndTab, (DLGPROC) EditorSelectProc, WM_INITDIALOG);
	// Brush:
	tie.pszText	= T_Brush;
	TabCtrl_InsertItem(hWndTab, TAB_EDITOR_BRUSH, &tie);
	if(hWndEditorTab[TAB_EDITOR_BRUSH])
		DestroyWindow(hWndEditorTab[TAB_EDITOR_BRUSH]);
	hWndEditorTab[TAB_EDITOR_BRUSH] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_BRUSH), hWndTab, (DLGPROC) EditorBrushProc, WM_INITDIALOG);
	// Surfaces:
	tie.pszText	= T_Surfaces;
	TabCtrl_InsertItem(hWndTab, TAB_EDITOR_SURFACES, &tie);
	if(hWndEditorTab[TAB_EDITOR_SURFACES])
		DestroyWindow(hWndEditorTab[TAB_EDITOR_SURFACES]);
	hWndEditorTab[TAB_EDITOR_SURFACES] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_SURFACES), hWndTab, (DLGPROC) EditorSurfacesProc, WM_INITDIALOG);
	// Objects:
	tie.pszText	= T_Objects;
	TabCtrl_InsertItem(hWndTab, TAB_EDITOR_OBJECTS, &tie);
	if(hWndEditorTab[TAB_EDITOR_OBJECTS])
		DestroyWindow(hWndEditorTab[TAB_EDITOR_OBJECTS]);
	hWndEditorTab[TAB_EDITOR_OBJECTS] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_OBJECTS), hWndTab, (DLGPROC) EditorObjectsProc, WM_INITDIALOG);
	// Terrain:
	tie.pszText	= T_Terrain;
	TabCtrl_InsertItem(hWndTab, TAB_EDITOR_TERRAIN, &tie);
	if(hWndEditorTab[TAB_EDITOR_TERRAIN])
		DestroyWindow(hWndEditorTab[TAB_EDITOR_TERRAIN]);
	hWndEditorTab[TAB_EDITOR_TERRAIN] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_TERRAIN), hWndTab, (DLGPROC) EditorTerrainProc, WM_INITDIALOG);
	// Environment:
	tie.pszText	= T_Environment;
	TabCtrl_InsertItem(hWndTab, TAB_EDITOR_ENVIRONMENT, &tie);
	if(hWndEditorTab[TAB_EDITOR_ENVIRONMENT])
		DestroyWindow(hWndEditorTab[TAB_EDITOR_ENVIRONMENT]);
	hWndEditorTab[TAB_EDITOR_ENVIRONMENT] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_ENVIRONMENT), hWndTab, (DLGPROC) EditorEnvironmentProc, WM_INITDIALOG);
	// Camera:
	tie.pszText	= T_Camera;
	TabCtrl_InsertItem(hWndTab, TAB_EDITOR_CAMERA, &tie);
	if(hWndEditorTab[TAB_EDITOR_CAMERA])
		DestroyWindow(hWndEditorTab[TAB_EDITOR_CAMERA]);
	hWndEditorTab[TAB_EDITOR_CAMERA] = CreateDialogParam(_AS->GetInstance(), MAKEINTRESOURCE(IDD_EDITOR_CAMERA), hWndTab, (DLGPROC) EditorCameraProc, WM_INITDIALOG);

	//
	if(iCurrentEditorTab != -1 && iCurrentEditorTab < EDITOR_TABS)
	{
		TabCtrl_SetCurSel(GetDlgItem(hWndEditor, IDC_EDITOR_TAB), iCurrentEditorTab);
		ShowWindow(hWndEditorTab[iCurrentEditorTab], SW_SHOW);
	}
	SendMessage(hWndEditor, WM_NOTIFY, IDC_EDITOR_TAB, 0);
	ShowWindow(hWndEditor, _AS->GetCmdShow());
	UpdateWindow(hWndEditor);
} // end SetupEditorTabs()

void SetEditorLanguage(void)
{ // begin SetEditorLanguage()
	if(!hWndEditor)
		return;
	SetWindowText(hWndEditor, T_Editor);
	SetDlgItemText(hWndEditor, IDC_EDITOR_SIZE_TEXT, T_Size_);

	SetupEditorTabs();
} // end SetEditorLanguage()

LRESULT CALLBACK KeywordProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin KeywordProc()
	char byTemp[256];

    switch(iMessage)
    {
        case WM_INITDIALOG:
			hWndKeyword = hWnd;
			KeywordLanguage();
			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_KEYWORD_OK:
					hWndKeyword = NULL;
					// Check if this keyword is right:
					GetDlgItemText(hWnd, ID_KEYWORD_KEYWORD, byTemp, 256);
					if(!strcmp(byKeyword, byTemp))
						EndDialog(hWnd, 1);
					else
						EndDialog(hWnd, 0);
                return TRUE;

                case ID_KEYWORD_CANCEL:
					hWndKeyword = NULL;
					EndDialog(hWnd, -1);
                return TRUE;
            }
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_KEYWORD_CANCEL, 0);
		break;
    }
    return FALSE;
} // end KeywordProc()

void KeywordLanguage(void)
{ // begin KeywordLanguage()
	SetWindowText(hWndKeyword, T_Keyword);
	SetDlgItemText(hWndKeyword, ID_SET_ANIMATION_STEPS_OK, T_Ok);
	SetDlgItemText(hWndKeyword, ID_SET_ANIMATION_STEPS_CANCEL, T_Cancel);
} // end KeywordLanguage()

HRESULT SaveLevelQuestion(void)
{ // begin SaveLevelQuestion()
	char *pbyTemp, byTemp[256];
	int i;
	
	i = MessageBox(hWndEditor, M_SaveCurrentLevelQuestion, T_Question, MB_YESNOCANCEL | MB_ICONQUESTION);
	if(i == IDCANCEL)
		return 1;
	if(i == IDYES)
	{ // Save the current level:
		_AS->WriteLogMessage("Save level %s", pLevel->byFilename);
		sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbySingleLevelsFile);
		pbyTemp = ASGetFileName(hWndEditor, T_SaveLevel, LEV_FILE, 1, FALSE, byTemp);
		if(!pbyTemp)
			return 1;
		pLevel->Save(pbyTemp);
	}
	return 0;
} // end SaveLevelQuestion();

LRESULT CALLBACK SetCameraVelocityProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin SetCameraVelocityProc()
	char byTemp[256];

    switch(iMessage)
    {
        case WM_INITDIALOG:
			SetWindowText(hWnd, T_CameraVelocity);
			SetDlgItemText(hWnd, ID_SET_CAMERA_VELOCITY_OK, T_Ok);
			SetDlgItemText(hWnd, ID_SET_CAMERA_VELOCITY_CANCEL, T_Cancel);
			sprintf(byTemp, "%f", fCameraVelocity);
			SetDlgItemText(hWnd, ID_SET_CAMERA_VELOCITY_NUMBER, byTemp);
			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_SET_CAMERA_VELOCITY_OK:
					GetDlgItemText(hWnd, ID_SET_CAMERA_VELOCITY_NUMBER, byTemp, 256);
					fCameraVelocity = (float) atof(byTemp);
					EndDialog(hWnd, 0);
                return TRUE;

                case ID_SET_CAMERA_VELOCITY_CANCEL:
					EndDialog(hWnd, 0);
                return TRUE;
            }
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_SET_CAMERA_VELOCITY_CANCEL, 0);
		break;
    }
    return FALSE;
} // end SetCameraVelocityProc()

LRESULT CALLBACK CopyCameraStepProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin CopyCameraStepProc()
	char byTemp[256];
	short i;

    switch(iMessage)
    {
        case WM_INITDIALOG:
			sprintf(byTemp, "%s (Nr. %d)", T_CopyTexturePos, pLevel->iCurrentCameraStep);
			SetWindowText(hWnd, byTemp);
			SetDlgItemText(hWnd, ID_COPY_CAMERA_STEP_OK, T_Ok);
			SetDlgItemText(hWnd, ID_COPY_CAMERA_STEP_CANCEL, T_Cancel);
			SendDlgItemMessage(hWnd, ID_COPY_CAMERA_STEP_LIST, CB_RESETCONTENT , 0, 0L);
			for(i = 0; i < pLevel->pCurrentCameraScript->iSteps; i++)
			{
				sprintf(byTemp, "%d", i);
				SendDlgItemMessage(hWnd, ID_COPY_CAMERA_STEP_LIST, CB_ADDSTRING, 0, (LPARAM) byTemp);
			}
			SendDlgItemMessage(hWnd, ID_COPY_CAMERA_STEP_LIST, CB_SETCURSEL, pLevel->iCurrentCameraStep, 0L);
			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_COPY_CAMERA_STEP_OK:
					EndDialog(hWnd, SendDlgItemMessage(hWnd, ID_COPY_CAMERA_STEP_LIST, CB_GETCURSEL, 0, 0L));
                return TRUE;

                case ID_COPY_CAMERA_STEP_CANCEL:
					EndDialog(hWnd, -1);
                return TRUE;
            }
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_COPY_CAMERA_STEP_CANCEL, 0);
		break;
    }
    return FALSE;
} // end CopyCameraStepProc()

LRESULT CALLBACK SetCameraStepsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin SetCameraStepsProc()
	char byTemp[256];
	short i;

    switch(iMessage)
    {
        case WM_INITDIALOG:
			SetWindowText(hWnd, T_SetCameraSteps);
			SetDlgItemText(hWnd, ID_SET_CAMERA_STEPS_OK, T_Ok);
			SetDlgItemText(hWnd, ID_SET_CAMERA_STEPS_CANCEL, T_Cancel);
			sprintf(byTemp, "%d", pLevel->pCurrentCameraScript->iSteps);
			SetDlgItemText(hWnd, ID_SET_CAMERA_STEPS_NUMBER, byTemp);
			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_SET_CAMERA_STEPS_OK:
					GetDlgItemText(hWnd, ID_SET_CAMERA_STEPS_NUMBER, byTemp, 256);
					i = (short) atoi(byTemp);
					if(!i)
						i++;
					EndDialog(hWnd, i);
                return TRUE;

                case ID_SET_CAMERA_STEPS_CANCEL:
					EndDialog(hWnd, -1);
                return TRUE;
            }
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_SET_CAMERA_STEPS_CANCEL, 0);
		break;
    }
    return FALSE;
} // end SetCameraStepsProc()
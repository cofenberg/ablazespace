//-----------------------------------------------------------------------------
// File: Level.h
//-----------------------------------------------------------------------------

#ifndef __LEVEL_H__
#define __LEVEL_H__


// Definitions: ***************************************************************
#define COMPUTE_FIELD_POS(px, py, ix, iy)  { ix = (short) (px/pLevel->fFieldWidth);\
										     iy = (short) (py/pLevel->fFieldHeight); }
#define GET_FIELD_ID(x, y, id) id = y*pLevel->iWidth+x;
enum {FLOOR_SURFACE, WALL_SURFACE, WATER_SURFACE, AIR_SURFACE};
#define LEVEL_VERSION 1		// The level version is responsible to save for crashes if the level is to old or not correct
enum
{
			   FACE_FRONT,
			   FACE_TOP,
	FACE_LEFT,				FACE_RIGHT,
			   FACE_BOTTOM,
			   FACE_FLOOR,
};
#define STANDART_LEVEL_Z_POS (-1000.0f)
///////////////////////////////////////////////////////////////////////////////

// Classes: *******************************************************************
typedef struct FIELD
{
	BOOL bActive;
	BOOL bNoBackfaceCulling;
	BOOL bWall;
	short iID;
	short iXPos, iYPos;		// The world position
	short iXField, iYField; // The matrix field pos
	BOOL bFaceActive[6];
	short iFace[6][4]; // Six faces every has 4 points, all clockwise sorted, evey first one is in the front
	FLOAT3 fNormal[6][2]; // Each face consist of two triangles that there are two normals for each face

	short iSurface[6];
	short iSurfaceRotation[6];
	SURFACE *pSurface[6];

	
	FLOAT fBoundingBox[2][3]; // The fields bounding box min/max
	FLOAT fBoundingBoxX, fBoundingBoxY, fBoundingBoxZ, fBoundingBoxSize;
	BOOL bOnScreen;	// Is this field on screen?

	ACTOR *pActor; // The actor on this field:
	ACTOR *pBridgeActor; // The actor which is now used as a bridge
	ACTOR *pObject;	// Is a object on this field? (e.g. health)

	BOOL bSelected;
	
	short iCurrentAniStep[6];
	long dwLastTime[6];
} FIELD;

typedef class LEVEL
{

	public:

	BOOL bKeyword; // Has this level an keyword?
	char byKeyword[256]; // The keyword for this level

	BOOL bSingleLevel; // Is this level an single and none campaign level?

	char byName[256];
	char byAuthor[256];
	char byFilename[256];
	BOOL bMusic;
	char byMusicFile[256];
	AS_CAMERA StartCamera;

	short iWidth, iHeight, iFields, iPoints;
	float fFieldWidth, fFieldHeight, fFieldDepth, fWholeWidth, fWholeHeight;

	float fGravity;

	GLuint iFieldList;

// Sky cube:
	BOOL bSkyCube;
	FLOAT3 fSkyCubeColor, fSkyCubeSize;
	short iSkyCubeSurface[6], iSkyCubeSurfaceRotation[6], iSkyCubeSurfaceAniStep[6];
	long dwSkyCubeSurfaceLastTime[6];

// Fog:
	BOOL bFog;
	float fFogDensity;
	FLOAT3 fFogColor;

// Water:
	BOOL bWater;
	BOOL bWaterAcid;
	BOOL bWaterLava;
	float fWaterDensity,
		  fWaterHeight,
		  fWaterActualHeight,
		  fWaterAmplitude,
		  fWaterSpeed,
		  fWaterVar;
	FLOAT3 fWaterColor;
	BOOL bWaterSurface;
	short iWaterSurface, iWaterAniStep;
	long lWaterAniTime;
	FLOAT2 fWaterTextureRepeat;

// Box:
	SHORT2 iBoxSurface[6];		// The box surfaces for each side and each type (2 types, 6 sides)
	CHAR2 byBoxSurfaceRot[6];   // The box surface rotation for each side and each type (2 types, 6 sides)
		
// Actors:
	ACTOR PlayerT;
	ACTOR ActorT[MAX_ACTORS];


// Missions:
	BOOL bTimeLimit;			// Is there a time limit?
	short iTimeLimit;			// The time limit
	long lTimeLimitTime;		// Stores the last checked time
	BOOL bStepsLimit;			// Is there a step limit?
	short iStepsLimit;			// The number of steps the player have
	BOOL bMissionExit,			// Should be player stand on an exit?
		 bMissionAlcove,		// Should be player stand on a alcove?
		 bMissionCollectPoints, // Must the player collect points?
		 bMissionCollectHealth;	// Must the player have an special number of health?
	short iCollectPoints,		// The number of points which must be collected
		  iCollectHealth;	    // The total number of heath which the player must have
	
	// No free anchor:
	BOOL bMissionNoFreeForAllAnchor,
		 bMissionNoFreeNormalAnchor,
		 bMissionNoFreeRedAnchor,
		 bMissionNoFreeGreenAnchor,
		 bMissionNoFreeBlueAnchor;

	// No free box:
	BOOL bMissionNoFreeNormalBox,
		 bMissionNoFreeRedBox,
		 bMissionNoFreeGreenBox,
		 bMissionNoFreeBlueBox;

	// No box:
	BOOL bMissionNoNormalBox,
		 bMissionNoRedBox,
		 bMissionNoGreenBox,
		 bMissionNoBlueBox;
////////////////////////////////////
	// The number of this objects in the level:
	short iNormalBoxes,
		  iRedBoxes,
		  iGreenBoxes,
		  iBlueBoxes,

   		  iForAllAnchors,
		  iNormalAnchors,
		  iRedAnchors,
		  iGreenAnchors,
		  iBlueAnchors;
	//
////////////////////////////////////
////////////////////////////////////
	// Start tools:
	short iToolsLives,
		  iToolsPoints,
		  iToolsWeapon,
		  iToolsPull,
		  iToolsThrow,
		  iToolsForce,
		  iToolsJump;
	BOOL bUnlimitedWeapon,
		 bUnlimitedPull,
		 bUnlimitedThrow,
		 bUnlimitedForce,
		 bUnlimitedJump;
	BOOL bToolsGhost,
		 bToolsSpeed,
		 bToolsWing,
		 bToolsShield;
////////////////////////////////////


	FLOAT3 fLevelColor;


	FLOAT3 *fPoint, *fColor;

	FIELD *pField;
	short iCurrentField;
	FIELD *pCurrentField;

	// Surfaces:
	short iTextures;
	AS_TEXTURE *pTexture;
	short iSurfaces;
	SURFACE *pSurface;
	short iCameraScripts;
	AS_CAMERA_SCRIPT *pCameraScript;
	// Current pointers:
	short iCurrentTexture;
	AS_TEXTURE *pCurrentTexture;
	short iCurrentSurface;
	SURFACE *pCurrentSurface;
	short iCurrentCameraScript;
	AS_CAMERA_SCRIPT *pCurrentCameraScript;
	//
	
	// Camera:
	BOOL bFreeCamera, bPlayerCamera, bStandartCamera;
	short iCurrentCameraStep;
	BOOL bStartCamera, bEndCamera, bEndCameraLoop;
	short iStartCamera, iEndCamera;
	


	LEVEL(void);
	~LEVEL(void);

	void GenTexturesOpenGL(HDC, HGLRC);
	void DestroyTexturesOpenGL(HDC, HGLRC);

	HRESULT CreateSurface(void);
	void DestroySurface(short);
	HRESULT LoadSurface(char *);
	void DestroyTexture(short);
	HRESULT LoadTexture(char *);

	void Create(short, short, float, float, float);
	void Destroy(void);
	void SetFieldWall(short, short, BOOL, BOOL);
	void CalculateFieldNormals(void);
	void CalculateFieldBoundingBoxes(void);

	void InitLevelDraw(void);
	void DeInitLevelDraw(void);
	void Draw(BOOL);
	void DrawWater(void);
	void DrawSkyCube();
	void Load(char *);
	void Save(char *);
	void SetStandartView(void);

	void ComputeHeight(float, float, FLOAT3, FLOAT3 *, char, float);
	BOOL GetWall(float, float);
	void UpdateMissions(void);

} LEVEL;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern void CreateLevel(LEVEL **);
extern void DestroyLevel(LEVEL **);
///////////////////////////////////////////////////////////////////////////////


#endif // __LEVEL_H__
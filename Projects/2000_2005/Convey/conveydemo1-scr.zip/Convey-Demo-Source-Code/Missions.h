//-----------------------------------------------------------------------------
// File: Missions.h
//-----------------------------------------------------------------------------

#ifndef __MISSIONS_H__
#define __MISSIONS_H__


// Structures: ****************************************************************
typedef struct CAMPAIGN
{
	BOOL bKeyword;			// Is there a keyword?
	char byKeyword[256],	// The keyword for the editing access
		 byFilename[256],	// The filename of this campaign
		 byName[256];		// The name of this campaign
	short iLevels;			// The number of Levels
	char **byLevelFilename; // The level filenames
} CAMPAIGN;
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern CAMPAIGN CurrentCampaign;
extern short iCurrentCampaignLevel;
extern char **pbyCampaignLevelNames;

// Level missions state:
extern BOOL bLevelComplete;

extern BOOL bMissionExitComplete,
			bMissionAlcoveComplete;

// Collect objects:
extern BOOL bMissionCollectPointsComplete,
			bMissionCollectHealthComplete;
extern short iCollectedPoints;

// Anchors:
extern BOOL bMissionNoFreeForAllAnchorComplete,
			bMissionNoFreeNormalAnchorComplete,
			bMissionNoFreeRedAnchorComplete,
			bMissionNoFreeGreenAnchorComplete,
			bMissionNoFreeBlueAnchorComplete;
extern short iUsedForAllAnchors,
			 iUsedNormalAnchors,
			 iUsedRedAnchors,
			 iUsedGreenAnchors,
			 iUsedBlueAnchors;

// Free boxes:
extern BOOL bMissionNoFreeNormalBoxesComplete,
			bMissionNoFreeRedBoxesComplete,
			bMissionNoFreeGreenBoxesComplete,
			bMissionNoFreeBlueBoxesComplete;
extern short iNoneFreeNormalBoxes,
			 iNoneFreeRedBoxes,
			 iNoneFreeGreenBoxes,
			 iNoneFreeBlueBoxes;

// Destroyed boxes:
extern BOOL bMissionNoNormalBoxesComplete,
			bMissionNoRedBoxesComplete,
			bMissionNoGreenBoxesComplete,
			bMissionNoBlueBoxesComplete;
extern short iDestroyedNormalBoxes,
			 iDestroyedRedBoxes,
			 iDestroyedGreenBoxes,
			 iDestroyedBlueBoxes;
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern void InitMissions(void);
extern void CheckMissions(void);
extern void ShowMissionState(AS_WINDOW *);
extern LRESULT CALLBACK CampaignEditorProc(HWND, UINT, WPARAM, LPARAM);
extern BOOL LoadCampaign(CAMPAIGN *, char *);
extern void SaveCampaign(CAMPAIGN *, char *);
extern void DestroyCampaign(CAMPAIGN *);
///////////////////////////////////////////////////////////////////////////////


#endif // __MISSIONS_H__
//-----------------------------------------------------------------------------
// File: GameMenu.h
//-----------------------------------------------------------------------------

#ifndef __GAME_MENU_H__
#define __GAME_MENU_H__


// Definitions: ***************************************************************
#define GAME_MENU_TEXTURES 4
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern BOOL bInGameMenu;
extern AS_TEXTURE GameMenuTexture[GAME_MENU_TEXTURES];
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern HRESULT GameMenuLoop(void);
extern void StartMenuMusic(void);
extern HRESULT GameMenuDraw(AS_WINDOW *);
extern HRESULT GameMenuCheck(AS_WINDOW *);
extern void LoadGameMenuTextures(void);
extern void DestroyGameMenuTextures(void);
extern void GenOpenGLGameMenuTextures(void);
extern void DestroyOpenGLGameMenuTextures(void);
///////////////////////////////////////////////////////////////////////////////


#endif // __GAME_MENU_H__
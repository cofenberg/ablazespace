//-----------------------------------------------------------------------------
// File: Level.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"


// Definitions: ***************************************************************
enum {NEW_LEVEL_DIALOG, LEVEL_DIALOG};
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
char byLevelDialogMode,			// In which level dialog we are?
	 byLevelSelecedSide,		// The selected side of something
	 byLevelSelecedType,		// The selected type of something
	 byLevelRotation;			// Rotation storage of something
LEVEL *pLevelT, *pOldLevelTemp; // Level backups
HWND hWndLevel,					// The level dialog handle
	 hWndLevelMissions,			// The level missions dialog handle
	 hWndLevelTools;			// The level tools dialog handle
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
LRESULT CALLBACK LevelProc(HWND, UINT, WPARAM, LPARAM);
void NewLevelDialog(void);
void AdjustLevelDialog(void);
LRESULT CALLBACK LevelMissionsProc(HWND, UINT, WPARAM, LPARAM);
void UpdateLevelMissions(void);
LRESULT CALLBACK LevelToolsProc(HWND, UINT, WPARAM, LPARAM);
void UpdateLevelTools(void);
///////////////////////////////////////////////////////////////////////////////


// Functions: *****************************************************************
void UpdateLevelMenuButtons(void)
{ // begin UpdateLevelMenuButtons()
	// Music:
    SendDlgItemMessage(hWndLevel, IDC_LEVEL_MUSIC, BM_SETCHECK, pLevelT->bMusic, 0L);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_MUSIC_FILE), pLevelT->bMusic);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_FIND_MUSIC_FILE), pLevelT->bMusic);
	// Keyword:
    SendDlgItemMessage(hWndLevel, IDC_LEVEL_KEYWORD_CHECKED, BM_SETCHECK, pLevelT->bKeyword, 0L);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_KEYWORD), pLevelT->bKeyword);
	// Fog:
    SendDlgItemMessage(hWndLevel, IDC_LEVEL_FOG, BM_SETCHECK, pLevelT->bFog, 0L);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_FOG_COLOR_R), pLevelT->bFog);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_FOG_COLOR_G), pLevelT->bFog);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_FOG_COLOR_B), pLevelT->bFog);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_FOG_DENSITY), pLevelT->bFog);
	// Water:
    SendDlgItemMessage(hWndLevel, IDC_LEVEL_WATER, BM_SETCHECK, pLevelT->bWater, 0L);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_WATER_COLOR_R), pLevelT->bWater);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_WATER_COLOR_G), pLevelT->bWater);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_WATER_COLOR_B), pLevelT->bWater);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_WATER_HEIGHT), pLevelT->bWater);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_WATER_DENSITY), pLevelT->bWater);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_WATER_TEXTURE), pLevelT->bWater);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_WATER_ACID), pLevelT->bWater);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_WATER_LAVA), pLevelT->bWater);
    SendDlgItemMessage(hWndLevel, IDC_LEVEL_WATER_ACID, BM_SETCHECK, pLevelT->bWaterAcid, 0L);
    SendDlgItemMessage(hWndLevel, IDC_LEVEL_WATER_LAVA, BM_SETCHECK, pLevelT->bWaterLava, 0L);
	SendDlgItemMessage(hWndLevel, IDC_LEVEL_WATER_TEXTURE, BM_SETCHECK, pLevelT->bWaterSurface, 0L);
    if(pLevelT->bWater)
	{
		EnableWindow(GetDlgItem(hWndLevel, ID_LEVEL_WATER_SURFACE_LIST), pLevelT->bWaterSurface);
		EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_WATER_TEXTURE_REPEAT_X), pLevelT->bWaterSurface);
		EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_WATER_TEXTURE_REPEAT_Y), pLevelT->bWaterSurface);
	}
	else
	{
		EnableWindow(GetDlgItem(hWndLevel, ID_LEVEL_WATER_SURFACE_LIST), FALSE);
		EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_WATER_TEXTURE_REPEAT_X), FALSE);
		EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_WATER_TEXTURE_REPEAT_Y), FALSE);
	}
	// Camera:
    SendDlgItemMessage(hWndLevel, IDC_LEVEL_FREE_CAMERA, BM_SETCHECK, pLevelT->bFreeCamera, 0L);
    SendDlgItemMessage(hWndLevel, IDC_LEVEL_PLAYER_CAMERA, BM_SETCHECK, pLevelT->bPlayerCamera, 0L);
    SendDlgItemMessage(hWndLevel, IDC_LEVEL_STANDART_CAMERA, BM_SETCHECK, pLevelT->bStandartCamera, 0L);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_STANDART_CAMERA), pLevelT->bFreeCamera);
	if(!pLevelT->iCameraScripts)
	{
		EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_CAMERA_START), FALSE);
		EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_CAMERA_END), FALSE);
		pLevelT->bStartCamera = pLevelT->bEndCamera = FALSE;
	}
	else
	{
		EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_CAMERA_START), TRUE);
		EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_CAMERA_END), TRUE);
	}
    SendDlgItemMessage(hWndLevel, IDC_LEVEL_CAMERA_START, BM_SETCHECK, pLevelT->bStartCamera, 0L);
    SendDlgItemMessage(hWndLevel, IDC_LEVEL_CAMERA_END, BM_SETCHECK, pLevelT->bEndCamera, 0L);
    SendDlgItemMessage(hWndLevel, IDC_LEVEL_CAMERA_END_LOOP, BM_SETCHECK, pLevelT->bEndCameraLoop, 0L);
    SendDlgItemMessage(hWndLevel, IDC_LEVEL_SINGLE, BM_SETCHECK, pLevelT->bSingleLevel, 0L);
	EnableWindow(GetDlgItem(hWndLevel, ID_LEVEL_CAMERA_START_CAMERA), pLevelT->bStartCamera);
	EnableWindow(GetDlgItem(hWndLevel, ID_LEVEL_CAMERA_END_CAMERA), pLevelT->bEndCamera);
	EnableWindow(GetDlgItem(hWndLevel, IDC_LEVEL_CAMERA_END_LOOP), pLevelT->bEndCamera);
} // end UpdateLevelMenuButtons()

LRESULT CALLBACK LevelProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin LevelProc()
    char byTemp[256];
	char *pbyTemp;
	short i, i2;

	switch(iMessage)
    {
        case WM_INITDIALOG:
				_AS->WriteLogMessage("Open level dialog");
				hWndLevel = hWnd;
				byLevelSelecedSide = 0;
				byLevelSelecedType = 0;
				byLevelRotation = 0;
				// Texts:
				if(byLevelDialogMode == NEW_LEVEL_DIALOG)
					SetWindowText(hWnd, T_CreateANewLevel);
				else
					SetWindowText(hWnd, T_AdjustLevel);	
				SetDlgItemText(hWnd, IDC_LEVEL_KEYWORD_CHECKED, T_Keyword);
				SetDlgItemText(hWnd, IDC_LEVEL_MUSIC, T_Music);
				SetDlgItemText(hWnd, IDC_LEVEL_FOG, T_Fog);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER, T_Water);
				SetDlgItemText(hWnd, IDC_LEVEL_LEVEL_T, T_Level);
				SetDlgItemText(hWnd, IDC_LEVEL_FIELD_T, T_Field);
				SetDlgItemText(hWnd, IDC_LEVEL_FILE_T, T_File);
				SetDlgItemText(hWnd, IDC_LEVEL_NAME_T, T_Name);
				SetDlgItemText(hWnd, IDC_LEVEL_AUTHOR_T, T_Author);
				SetDlgItemText(hWnd, IDC_LEVEL_MUSIC_T, T_Music);
				SetDlgItemText(hWnd, IDC_LEVEL_WIDTH_T, T_Width);
				SetDlgItemText(hWnd, IDC_LEVEL_HEIGHT_T, T_Height);
				SetDlgItemText(hWnd, IDC_LEVEL_FIELD_WIDTH_T, T_Width);
				SetDlgItemText(hWnd, IDC_LEVEL_FIELD_HEIGHT_T, T_Height);
				SetDlgItemText(hWnd, IDC_LEVEL_FIELD_DEPTH_T, T_Depth);
				SetDlgItemText(hWnd, IDC_LEVEL_FOG_T, T_Fog);
				SetDlgItemText(hWnd, IDC_LEVEL_FOG_DENSITY_T, T_Density);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_T, T_Water);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_DENSITY_T, T_Density);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_HEIGHT_T, T_Height);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_TEXTURE, T_Texture);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_ACID, T_Acid);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_LAVA, T_Lava);
				SetDlgItemText(hWnd, IDC_LEVEL_LIGHT_T, T_Light);
				SetDlgItemText(hWnd, IDC_LEVEL_FREE_CAMERA, T_FreeCamera);
				SetDlgItemText(hWnd, IDC_LEVEL_PLAYER_CAMERA, T_PlayerCamera);
				SetDlgItemText(hWnd, IDC_LEVEL_STANDART_CAMERA, T_StandartCamera);
				SetDlgItemText(hWnd, IDC_LEVEL_BOX_SURFACE_ALL, T_All);
				SetDlgItemText(hWnd, ID_LEVEL_CANCEL, T_Cancel);
				SetDlgItemText(hWnd, ID_LEVEL_OK, T_Ok);
				SetDlgItemText(hWnd, ID_LEVEL_START_TOOLS, T_StartTools);
				SetDlgItemText(hWnd, ID_LEVEL_MISSIONS, T_LevelMissions);
				//
				// Level:
				SetDlgItemText(hWnd, IDC_LEVEL_FILENAME, pLevelT->byFilename);
				SetDlgItemText(hWnd, IDC_LEVEL_NAME, pLevelT->byName);
				SetDlgItemText(hWnd, IDC_LEVEL_AUTHOR, pLevelT->byAuthor);
				SetDlgItemText(hWnd, IDC_LEVEL_MUSIC_FILE, pLevelT->byMusicFile);
				sprintf(byTemp, "%d", pLevelT->iWidth-1);
				SetDlgItemText(hWnd, IDC_LEVEL_WIDTH, byTemp);
				sprintf(byTemp, "%d", pLevelT->iHeight-1);
				SetDlgItemText(hWnd, IDC_LEVEL_HEIGHT, byTemp);
				sprintf(byTemp, "%s", pLevelT->byKeyword);
				SetDlgItemText(hWnd, IDC_LEVEL_KEYWORD, byTemp);				
				// Fog:
				sprintf(byTemp, "%f", pLevelT->fFogDensity);
				SetDlgItemText(hWnd, IDC_LEVEL_FOG_DENSITY, byTemp);
				sprintf(byTemp, "%f", pLevelT->fFogColor[R]);
				SetDlgItemText(hWnd, IDC_LEVEL_FOG_COLOR_R, byTemp);
				sprintf(byTemp, "%f", pLevelT->fFogColor[G]);
				SetDlgItemText(hWnd, IDC_LEVEL_FOG_COLOR_G, byTemp);
				sprintf(byTemp, "%f", pLevelT->fFogColor[B]);
				SetDlgItemText(hWnd, IDC_LEVEL_FOG_COLOR_B, byTemp);
				// Water:
				sprintf(byTemp, "%f", pLevelT->fWaterDensity);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_DENSITY, byTemp);
				sprintf(byTemp, "%f", pLevelT->fWaterHeight);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_HEIGHT, byTemp);
				sprintf(byTemp, "%f", pLevelT->fWaterColor[R]);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_COLOR_R, byTemp);
				sprintf(byTemp, "%f", pLevelT->fWaterColor[G]);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_COLOR_G, byTemp);
				sprintf(byTemp, "%f", pLevelT->fWaterColor[B]);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_COLOR_B, byTemp);
				// Water texture:
				SendDlgItemMessage(hWnd, ID_LEVEL_WATER_SURFACE_LIST, CB_RESETCONTENT , 0, 0L);
				for(i = 0; i < pLevelT->iSurfaces; i++)
				{
					sprintf(byTemp, "%s (Used:%d)", pLevelT->pSurface[i].byName, pLevelT->pSurface[i].iUsed);
					SendDlgItemMessage(hWnd, ID_LEVEL_WATER_SURFACE_LIST, CB_ADDSTRING, 0, (LPARAM) byTemp);
				}
				if(pLevelT->bWaterSurface && pLevelT->iWaterSurface != -1)
					SendDlgItemMessage(hWnd, ID_LEVEL_WATER_SURFACE_LIST, CB_SETCURSEL, pLevelT->iWaterSurface, 0L);
				sprintf(byTemp, "%f", pLevelT->fWaterTextureRepeat[X]);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_TEXTURE_REPEAT_X, byTemp);
				sprintf(byTemp, "%f", pLevelT->fWaterTextureRepeat[Y]);
				SetDlgItemText(hWnd, IDC_LEVEL_WATER_TEXTURE_REPEAT_Y, byTemp);				
				// Level color:
				sprintf(byTemp, "%f", pLevelT->fLevelColor[R]);
				SetDlgItemText(hWnd, IDC_LEVEL_COLOR_R, byTemp);
				sprintf(byTemp, "%f", pLevelT->fLevelColor[G]);
				SetDlgItemText(hWnd, IDC_LEVEL_COLOR_G, byTemp);
				sprintf(byTemp, "%f", pLevelT->fLevelColor[B]);
				SetDlgItemText(hWnd, IDC_LEVEL_COLOR_B, byTemp);
				// Field:
				sprintf(byTemp, "%f", pLevelT->fFieldWidth);
				SetDlgItemText(hWnd, IDC_LEVEL_FIELD_WIDTH, byTemp);
				sprintf(byTemp, "%f", pLevelT->fFieldHeight);
				SetDlgItemText(hWnd, IDC_LEVEL_FIELD_HEIGHT, byTemp);
				sprintf(byTemp, "%f", pLevelT->fFieldDepth);
				SetDlgItemText(hWnd, IDC_LEVEL_FIELD_DEPTH_LENGTH, byTemp);
				// Camera:
				SetDlgItemText(hWnd, IDC_LEVEL_CAMERA, T_Camera);
				SetDlgItemText(hWnd, IDC_LEVEL_CAMERA_START, T_Start);
				SendDlgItemMessage(hWnd, ID_LEVEL_CAMERA_START_CAMERA, CB_RESETCONTENT , 0, 0L);
				for(i = 0; i < pLevelT->iCameraScripts; i++)
				{
					sprintf(byTemp, "%s", pLevelT->pCameraScript[i].byName);
					SendDlgItemMessage(hWnd, ID_LEVEL_CAMERA_START_CAMERA, CB_ADDSTRING, 0, (LPARAM) byTemp);
				}
				SendDlgItemMessage(hWnd, ID_LEVEL_CAMERA_START_CAMERA, CB_SETCURSEL, pLevelT->iStartCamera, 0L);
				SetDlgItemText(hWnd, IDC_LEVEL_CAMERA_END, T_End);
				SetDlgItemText(hWnd, IDC_LEVEL_CAMERA_END_LOOP, T_Loop);
				SendDlgItemMessage(hWnd, ID_LEVEL_CAMERA_END_CAMERA, CB_RESETCONTENT, 0, 0L);
				for(i = 0; i < pLevelT->iCameraScripts; i++)
				{
					sprintf(byTemp, "%s", pLevelT->pCameraScript[i].byName);
					SendDlgItemMessage(hWnd, ID_LEVEL_CAMERA_END_CAMERA, CB_ADDSTRING, 0, (LPARAM) byTemp);
				}
				SendDlgItemMessage(hWnd, ID_LEVEL_CAMERA_END_CAMERA, CB_SETCURSEL, pLevelT->iEndCamera, 0L);
				// Box:
				SetDlgItemText(hWnd, IDC_LEVEL_BOX_T, T_Box);
				SetDlgItemText(hWnd, IDC_LEVEL_BOX_ROTATION_T, T_Rotation);
				sprintf(byTemp, "%d", byLevelRotation*90);
				SetDlgItemText(hWnd, IDC_LEVEL_BOX_ROTATION, byTemp);
				pLevelT->byBoxSurfaceRot[byLevelSelecedSide][byLevelSelecedType] = byLevelRotation;
			Init:
				// Box type:
				SendDlgItemMessage(hWnd, ID_LEVEL_BOX_TYPE, CB_RESETCONTENT, 0, 0L);
				SendDlgItemMessage(hWnd, ID_LEVEL_BOX_TYPE, CB_ADDSTRING, 0, (LPARAM) T_Normal);
				SendDlgItemMessage(hWnd, ID_LEVEL_BOX_TYPE, CB_ADDSTRING, 0, (LPARAM) T_Heavy);
				SendDlgItemMessage(hWnd, ID_LEVEL_BOX_TYPE, CB_SETCURSEL, byLevelSelecedType, 0L);
				// Box side:
				SendDlgItemMessage(hWnd, ID_LEVEL_BOX_SIDE, CB_RESETCONTENT, 0, 0L);
				SendDlgItemMessage(hWnd, ID_LEVEL_BOX_SIDE, CB_ADDSTRING, 0, (LPARAM) T_Floor);
				SendDlgItemMessage(hWnd, ID_LEVEL_BOX_SIDE, CB_ADDSTRING, 0, (LPARAM) T_Sky);
				SendDlgItemMessage(hWnd, ID_LEVEL_BOX_SIDE, CB_ADDSTRING, 0, (LPARAM) T_Back);
				SendDlgItemMessage(hWnd, ID_LEVEL_BOX_SIDE, CB_ADDSTRING, 0, (LPARAM) T_Front);
				SendDlgItemMessage(hWnd, ID_LEVEL_BOX_SIDE, CB_ADDSTRING, 0, (LPARAM) T_Right);
				SendDlgItemMessage(hWnd, ID_LEVEL_BOX_SIDE, CB_ADDSTRING, 0, (LPARAM) T_Left);
				SendDlgItemMessage(hWnd, ID_LEVEL_BOX_SIDE, CB_SETCURSEL, byLevelSelecedSide, 0L);
				// Box surface:
				SendDlgItemMessage(hWnd, ID_LEVEL_BOX_SURFACE, CB_RESETCONTENT, 0, 0L);
				for(i = 0; i < pLevelT->iSurfaces; i++)
				{
					sprintf(byTemp, "%s", pLevelT->pSurface[i].byName, pLevelT->pSurface[i].iUsed);
					SendDlgItemMessage(hWnd, ID_LEVEL_BOX_SURFACE, CB_ADDSTRING, 0, (LPARAM) byTemp);
				}
				SendDlgItemMessage(hWnd, ID_LEVEL_BOX_SURFACE, CB_SETCURSEL, pLevelT->iBoxSurface[byLevelSelecedSide][byLevelSelecedType], 0L);

				UpdateLevelMenuButtons();
				
				ShowWindow(hWnd, _AS->GetCmdShow());
				UpdateWindow(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_LEVEL_OK:
					if(byLevelDialogMode == LEVEL_DIALOG && 
					   (pLevelT->iWidth != pLevel->iWidth || pLevelT->iHeight != pLevel->iHeight))
					{ // Yes the level must be resize inform the user:
						sprintf(byTemp, "%s %dx%d)", M_ChangeLevelSize, pLevel->iWidth, pLevel->iHeight);
						if(MessageBox(NULL, byTemp, T_Question, MB_YESNO | MB_ICONINFORMATION) == IDNO)
							break;
					}
					EndDialog(hWnd, TRUE);
					_AS->WriteLogMessage("Close level dialog(OK)");
                return TRUE;

                case ID_LEVEL_CANCEL:
					EndDialog(hWnd, FALSE);
					_AS->WriteLogMessage("Close level dialog(Cancel)");
                return TRUE;

			// Level:
				case IDC_LEVEL_FILENAME:
					GetDlgItemText(hWnd, IDC_LEVEL_FILENAME, pLevelT->byFilename, 256);
				break;

				case IDC_LEVEL_SINGLE:
				    pLevelT->bSingleLevel = SendDlgItemMessage(hWnd, IDC_LEVEL_SINGLE, BM_GETCHECK, 0, 0L);
				break;

				case IDC_LEVEL_FIND_FILENAME:
					sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbySingleLevelsFile);
					pbyTemp = ASGetFileName(hWnd, "Get level file name", LEV_FILE, 0, TRUE, byTemp);
					if(!pbyTemp)
						break;
					if(strlen(pbyTemp) > strlen(_AS->pbyProgramPath))
						strcpy(pLevelT->byFilename, &pbyTemp[strlen(_AS->pbyProgramPath)]);
					SetDlgItemText(hWnd, IDC_LEVEL_FILENAME, pLevelT->byFilename);
				break;

				case IDC_LEVEL_NAME:
					GetDlgItemText(hWnd, IDC_LEVEL_NAME, pLevelT->byName, 256);
				break;

				case IDC_LEVEL_AUTHOR:
					GetDlgItemText(hWnd, IDC_LEVEL_AUTHOR, pLevelT->byAuthor, 256);
				break;

				case IDC_LEVEL_MUSIC:
				    pLevelT->bMusic = SendDlgItemMessage(hWnd, IDC_LEVEL_MUSIC, BM_GETCHECK, 0, 0L);
					UpdateLevelMenuButtons();
				break;

				case IDC_LEVEL_MUSIC_FILE:
					GetDlgItemText(hWnd, IDC_LEVEL_MUSIC_FILE, pLevelT->byMusicFile, 256);
					UpdateLevelMenuButtons();
				break;

				case IDC_LEVEL_FIND_MUSIC_FILE:
					sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyMusicFile);
					pbyTemp = ASGetFileName(hWnd, "Load music", MUSIC_FILE, 0, TRUE, byTemp);
					if(!pbyTemp)
						break;
					if(strlen(pbyTemp) > strlen(_AS->pbyProgramPath))
						strcpy(pLevelT->byMusicFile, &pbyTemp[strlen(_AS->pbyProgramPath)]);
					SetDlgItemText(hWnd, IDC_LEVEL_MUSIC_FILE, pLevelT->byMusicFile);
				break;
				
				case IDC_LEVEL_KEYWORD_CHECKED:
				    pLevelT->bKeyword = SendDlgItemMessage(hWnd, IDC_LEVEL_KEYWORD_CHECKED, BM_GETCHECK, 0, 0L);
					UpdateLevelMenuButtons();
				break;

				case IDC_LEVEL_KEYWORD:
					GetDlgItemText(hWnd, IDC_LEVEL_KEYWORD, pLevelT->byKeyword, 256);
				break;
				
				case IDC_LEVEL_WIDTH:
					GetDlgItemText(hWnd, IDC_LEVEL_WIDTH, byTemp, 256);
					pLevelT->iWidth = atoi(byTemp)+1;
				break;

				case IDC_LEVEL_HEIGHT:
					GetDlgItemText(hWnd, IDC_LEVEL_HEIGHT, byTemp, 256);
					pLevelT->iHeight = atoi(byTemp)+1;
				break;
		
			// Fog:
				case IDC_LEVEL_FOG:
				    pLevelT->bFog = SendDlgItemMessage(hWnd, IDC_LEVEL_FOG, BM_GETCHECK, 0, 0L);
					UpdateLevelMenuButtons();
				break;

				case IDC_LEVEL_FOG_DENSITY:
					GetDlgItemText(hWnd, IDC_LEVEL_FOG_DENSITY, byTemp, 256);
					pLevelT->fFogDensity = (float) atof(byTemp);
				break;

				case IDC_LEVEL_FOG_COLOR_R:
					GetDlgItemText(hWnd, IDC_LEVEL_FOG_COLOR_R, byTemp, 256);
					pLevelT->fFogColor[R] = (float) atof(byTemp);
				break;

				case IDC_LEVEL_FOG_COLOR_G:
					GetDlgItemText(hWnd, IDC_LEVEL_FOG_COLOR_G, byTemp, 256);
					pLevelT->fFogColor[G] = (float) atof(byTemp);
				break;

				case IDC_LEVEL_FOG_COLOR_B:
					GetDlgItemText(hWnd, IDC_LEVEL_FOG_COLOR_B, byTemp, 256);
					pLevelT->fFogColor[B] = (float) atof(byTemp);
				break;

			// Water:
				case IDC_LEVEL_WATER:
				    pLevelT->bWater = SendDlgItemMessage(hWnd, IDC_LEVEL_WATER, BM_GETCHECK, 0, 0L);
					UpdateLevelMenuButtons();
				break;
				
				case IDC_LEVEL_WATER_DENSITY:
					GetDlgItemText(hWnd, IDC_LEVEL_WATER_DENSITY, byTemp, 256);
					pLevelT->fWaterDensity = (float) atof(byTemp);
				break;

				case IDC_LEVEL_WATER_HEIGHT:
					GetDlgItemText(hWnd, IDC_LEVEL_WATER_HEIGHT, byTemp, 256);
					pLevelT->fWaterHeight = (float) atof(byTemp);
				break;

				case IDC_LEVEL_WATER_COLOR_R:
					GetDlgItemText(hWnd, IDC_LEVEL_WATER_COLOR_R, byTemp, 256);
					pLevelT->fWaterColor[R] = (float) atof(byTemp);
				break;

				case IDC_LEVEL_WATER_COLOR_G:
					GetDlgItemText(hWnd, IDC_LEVEL_WATER_COLOR_G, byTemp, 256);
					pLevelT->fWaterColor[G] = (float) atof(byTemp);
				break;

				case IDC_LEVEL_WATER_COLOR_B:
					GetDlgItemText(hWnd, IDC_LEVEL_WATER_COLOR_B, byTemp, 256);
					pLevelT->fWaterColor[B] = (float) atof(byTemp);
				break;
				
				case IDC_LEVEL_WATER_TEXTURE:
				    pLevelT->bWaterSurface = SendDlgItemMessage(hWnd, IDC_LEVEL_WATER_TEXTURE, BM_GETCHECK, 0, 0L);
					UpdateLevelMenuButtons();
				break;

				case IDC_LEVEL_WATER_ACID:
				    pLevelT->bWaterAcid = SendDlgItemMessage(hWnd, IDC_LEVEL_WATER_ACID, BM_GETCHECK, 0, 0L);
					if(pLevelT->bWaterAcid && pLevelT->bWaterLava)
						pLevelT->bWaterLava = FALSE;
					UpdateLevelMenuButtons();
				break;

				case IDC_LEVEL_WATER_LAVA:
				    pLevelT->bWaterLava = SendDlgItemMessage(hWnd, IDC_LEVEL_WATER_LAVA, BM_GETCHECK, 0, 0L);
					if(pLevelT->bWaterAcid && pLevelT->bWaterLava)
						pLevelT->bWaterAcid = FALSE;
					UpdateLevelMenuButtons();
				break;

			// Water texture:
				case ID_LEVEL_WATER_SURFACE_LIST:
					i = (short) SendDlgItemMessage(hWnd, ID_LEVEL_WATER_SURFACE_LIST, CB_GETCURSEL, 0, 0L);
					if(i == -1 || i >= pLevelT->iSurfaces)
						break;
					pLevelT->iWaterSurface = i;
				break;

				case IDC_LEVEL_WATER_TEXTURE_REPEAT_X:
					GetDlgItemText(hWnd, IDC_LEVEL_WATER_TEXTURE_REPEAT_X, byTemp, 256);
					pLevelT->fWaterTextureRepeat[X] = (float) atof(byTemp);
				break;

				case IDC_LEVEL_WATER_TEXTURE_REPEAT_Y:
					GetDlgItemText(hWnd, IDC_LEVEL_WATER_TEXTURE_REPEAT_Y, byTemp, 256);
					pLevelT->fWaterTextureRepeat[Y] = (float) atof(byTemp);
				break;

			// Level color
				case IDC_LEVEL_COLOR_R:
					GetDlgItemText(hWnd, IDC_LEVEL_COLOR_R, byTemp, 256);
					pLevelT->fLevelColor[R] = (float) atof(byTemp);
				break;

				case IDC_LEVEL_COLOR_G:
					GetDlgItemText(hWnd, IDC_LEVEL_COLOR_G, byTemp, 256);
					pLevelT->fLevelColor[G] = (float) atof(byTemp);
				break;

				case IDC_LEVEL_COLOR_B:
					GetDlgItemText(hWnd, IDC_LEVEL_COLOR_B, byTemp, 256);
					pLevelT->fLevelColor[B] = (float) atof(byTemp);
				break;

			// Field:
				case IDC_LEVEL_FIELD_WIDTH:
					GetDlgItemText(hWnd, IDC_LEVEL_FIELD_WIDTH, byTemp, 256);
					pLevelT->fFieldWidth = (float) atof(byTemp);
					if(pLevelT->fFieldWidth < 0.0f)
					{
						pLevelT->fFieldWidth = 0.0f;
						sprintf(byTemp, "%f", pLevelT->fFieldWidth);
						SetDlgItemText(hWnd, IDC_LEVEL_FIELD_WIDTH, byTemp);
					}
				break;

				case IDC_LEVEL_FIELD_HEIGHT:
					GetDlgItemText(hWnd, IDC_LEVEL_FIELD_HEIGHT, byTemp, 256);
					pLevelT->fFieldHeight = (float) atof(byTemp);
					if(pLevelT->fFieldHeight < 0.0f)
					{
						pLevelT->fFieldHeight = 0.0f;
						sprintf(byTemp, "%f", pLevelT->fFieldHeight);
						SetDlgItemText(hWnd, IDC_LEVEL_FIELD_HEIGHT, byTemp);
					}
				break;
				
				case IDC_LEVEL_FIELD_DEPTH_LENGTH:
					GetDlgItemText(hWnd, IDC_LEVEL_FIELD_DEPTH_LENGTH, byTemp, 256);
					pLevelT->fFieldDepth = (float) atof(byTemp);
				break;

				// Camera:
				case IDC_LEVEL_FREE_CAMERA:
				    pLevelT->bFreeCamera = SendDlgItemMessage(hWnd, IDC_LEVEL_FREE_CAMERA, BM_GETCHECK, 0, 0L);
					if(!pLevelT->bFreeCamera && !pLevelT->bPlayerCamera)
					{
						pLevelT->bFreeCamera = TRUE;
						SendDlgItemMessage(hWnd, IDC_LEVEL_FREE_CAMERA, BM_SETCHECK, TRUE, 0L);
					}
					UpdateLevelMenuButtons();
				break;

				case IDC_LEVEL_PLAYER_CAMERA:
				    pLevelT->bPlayerCamera = SendDlgItemMessage(hWnd, IDC_LEVEL_PLAYER_CAMERA, BM_GETCHECK, 0, 0L);
					if(!pLevelT->bFreeCamera && !pLevelT->bPlayerCamera)
					{
						pLevelT->bPlayerCamera = TRUE;
						SendDlgItemMessage(hWnd, IDC_LEVEL_PLAYER_CAMERA, BM_SETCHECK, TRUE, 0L);
					}
				break;

				case IDC_LEVEL_STANDART_CAMERA:
				    pLevelT->bStandartCamera = SendDlgItemMessage(hWnd, IDC_LEVEL_STANDART_CAMERA, BM_GETCHECK, 0, 0L);
				break;

				case IDC_LEVEL_CAMERA_START:
				    pLevelT->bStartCamera = SendDlgItemMessage(hWnd, IDC_LEVEL_CAMERA_START, BM_GETCHECK, 0, 0L);
					UpdateLevelMenuButtons();
				break;

				case ID_LEVEL_CAMERA_START_CAMERA:
					i = (short) SendDlgItemMessage(hWnd, ID_LEVEL_CAMERA_START_CAMERA, CB_GETCURSEL, 0, 0L);
					if(i == -1 || i >= pLevelT->iCameraScripts)
						break;
					pLevelT->iStartCamera = i;
				break;

				case IDC_LEVEL_CAMERA_END:
				    pLevelT->bEndCamera = SendDlgItemMessage(hWnd, IDC_LEVEL_CAMERA_END, BM_GETCHECK, 0, 0L);
					UpdateLevelMenuButtons();
				break;

				case IDC_LEVEL_CAMERA_END_LOOP:
				    pLevelT->bEndCameraLoop = SendDlgItemMessage(hWnd, IDC_LEVEL_CAMERA_END_LOOP, BM_GETCHECK, 0, 0L);
				break;

				case ID_LEVEL_CAMERA_END_CAMERA:
					i = (short) SendDlgItemMessage(hWnd, ID_LEVEL_CAMERA_END_CAMERA, CB_GETCURSEL, 0, 0L);
					if(i == -1 || i >= pLevelT->iCameraScripts)
						break;
					pLevelT->iEndCamera = i;
				break;
			
				// Box:
				case ID_LEVEL_BOX_TYPE:
					i = (short) SendDlgItemMessage(hWnd, ID_LEVEL_BOX_TYPE, CB_GETCURSEL, 0, 0L);
					if(i == -1 || i >= 2)
						break;
					byLevelSelecedType = (char) i;
					goto Init;
				
				case ID_LEVEL_BOX_SIDE:
					i = (short) SendDlgItemMessage(hWnd, ID_LEVEL_BOX_SIDE, CB_GETCURSEL, 0, 0L);
					if(i == -1 || i >= 6)
						break;
					byLevelSelecedSide = (char) i;
					goto Init;

				case ID_LEVEL_BOX_SURFACE:
					i = (short) SendDlgItemMessage(hWnd, ID_LEVEL_BOX_SURFACE, CB_GETCURSEL, 0, 0L);
					if(i == -1 || i >= pLevelT->iSurfaces)
						break;
					pLevelT->iBoxSurface[byLevelSelecedSide][byLevelSelecedType] = i;
				break;

				case IDC_LEVEL_BOX_SURFACE_ALL:
					i = (short) SendDlgItemMessage(hWnd, ID_LEVEL_BOX_SURFACE, CB_GETCURSEL, 0, 0L);
					if(i == -1 || i >= pLevelT->iSurfaces)
						break;
					for(i2 = 0; i2 < 6; i2++)
						pLevelT->iBoxSurface[i2][byLevelSelecedType] = i;
				break;

				case IDC_LEVEL_BOX_ROTATION_PLUS:
					byLevelRotation--;
					if(byLevelRotation < 0)
						byLevelRotation = 3;
					pLevelT->byBoxSurfaceRot[byLevelSelecedSide][byLevelSelecedType] = byLevelRotation;
					sprintf(byTemp, "%d", byLevelRotation*90);
					SetDlgItemText(hWnd, IDC_LEVEL_BOX_ROTATION, byTemp);
				break;

				case IDC_LEVEL_BOX_ROTATION_MINUS:
					byLevelRotation++;
					if(byLevelRotation > 3)
						byLevelRotation = 0;
					pLevelT->byBoxSurfaceRot[byLevelSelecedSide][byLevelSelecedType] = byLevelRotation;
					sprintf(byTemp, "%d", byLevelRotation*90);
					SetDlgItemText(hWnd, IDC_LEVEL_BOX_ROTATION, byTemp);
				break;

				case ID_LEVEL_MISSIONS:
					DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_LEVEL_MISSIONS), hWnd, (DLGPROC) LevelMissionsProc);
				break;

				case ID_LEVEL_START_TOOLS:
					DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_LEVEL_TOOLS), hWnd, (DLGPROC) LevelToolsProc);
				break;
            }
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_LEVEL_CANCEL, 0);
		break;
    }
    return FALSE;
} // end LevelProc()

void NewLevelDialog(void)
{ // begin NewLevelDialog()
	short i;

	_AS->WriteLogMessage("Create a new level");
	pLevelT = new LEVEL;
	strcpy(pLevelT->byName, "Noname");
	byLevelDialogMode = NEW_LEVEL_DIALOG;
	if(!DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_LEVEL), hWndEditor, (DLGPROC) LevelProc))
	{ // The user canceled the creation of a new level:
		_AS->WriteLogMessage("Create a new level is canceled");
		DestroyLevel(&pLevelT);
		return;
	}
	pPlayer->bActive = FALSE;
	for(i = 0; i < MAX_ACTORS; i++)
		memset(&Actor[i], 0, sizeof(ACTOR));
	// OK, now destroy the old level and make the new to the current:
	memset(pPlayer, 0, sizeof(ACTOR));
	memset(&Actor, 0, sizeof(ACTOR)*MAX_ACTORS);
	DestroyLevel(&pLevel);
	pLevel = pLevelT;
	// Now setup the level:
	pLevel->Create(pLevel->iWidth, pLevel->iHeight, pLevel->fFieldDepth, pLevel->fFieldWidth, pLevel->fFieldHeight);
	if(!wglMakeCurrent(hDCEditorShow, hRCEditorShow))
		return;
	pLevel->DestroyTexturesOpenGL(hDCEditorShow, hRCEditorShow);
	pLevel->GenTexturesOpenGL(hDCEditorShow, hRCEditorShow);
	pLevel->lWaterAniTime = g_lNow;
} // end NewLevelDialog()

void AdjustLevelDialog(void)
{ // begin AdjustLevelDialog()
	byLevelDialogMode = LEVEL_DIALOG;
	pLevelT = new LEVEL;
	pOldLevelTemp = new LEVEL;
	memcpy(pOldLevelTemp, pLevel, sizeof(LEVEL)); // Save the old level
	memcpy(pLevelT, pLevel, sizeof(LEVEL)); // Save the old level
	if(!DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_LEVEL), hWndEditor, (DLGPROC) LevelProc))
	{ // The user canceled the changes of the level:
		_AS->WriteLogMessage("Change level attributes is canceled");
		delete pLevelT;
		delete pOldLevelTemp;
		return;
	}
	// Update the level data:
	memcpy(pLevel, pLevelT, sizeof(LEVEL));
	pLevel->iWaterAniStep = 0;
	// Now check if the level points must be updated:
	short i, i2 = pLevelT->iPoints/2, x, y;
	FIELD *pNewFieldT, *pOldFieldT;

	if(pLevel->fFieldWidth != pOldLevelTemp->fFieldWidth || pLevel->fFieldHeight != pOldLevelTemp->fFieldHeight)
	{
		for(i = 0, y = 0; y < pLevel->iHeight+1; y++)
			for(x = 0; x < pLevel->iWidth+1; x++, i++)
			{
				if(i >= i2)
					goto PointsEnd;
				// Front point:
				pLevel->fPoint[i][X] = (float) x*pLevel->fFieldWidth;
				pLevel->fPoint[i][Y] = (float) y*pLevel->fFieldHeight;
				pLevel->fPoint[i][Z] = (float) pLevel->fFieldDepth/2;
				// Back point:
				pLevel->fPoint[i2+i][X] = (float) x*pLevel->fFieldWidth;
				pLevel->fPoint[i2+i][Y] = (float) y*pLevel->fFieldHeight;
				pLevel->fPoint[i2+i][Z] = (float) -pLevel->fFieldDepth/2;
			}
	}
PointsEnd:
	// Check field depth:
	if(pLevel->fFieldDepth != pOldLevelTemp->fFieldDepth)
	{
		i2 = pLevel->iPoints/2;
		for(i = 0; i < i2; i++)
		{
			pLevel->fPoint[i+i2][Z] = 0.0f;
			pLevel->fPoint[i][Z] = pLevel->fFieldDepth;
		}
		pLevel->CalculateFieldNormals();
		pLevel->CalculateFieldBoundingBoxes();
	}
	if(pLevel->iWidth != pOldLevelTemp->iWidth || pLevel->iHeight != pOldLevelTemp->iHeight)
	{ // Yes, the level must be resized:
		if(pPlayer->iFieldPos[X] >= pLevel->iWidth-1 ||
		   pPlayer->iFieldPos[Y] >= pLevel->iHeight-1)
			pPlayer->bActive = FALSE;
		for(i = 0; i < MAX_ACTORS; i++)
		{
			if(Actor[i].iFieldPos[X] >= pLevel->iWidth-1 ||
			   Actor[i].iFieldPos[Y] >= pLevel->iHeight-1)
				Actor[i].bActive = FALSE;
		}
		// Create now a new level with the old information:
		pLevelT->pField = NULL; pLevelT->fPoint = NULL;
		 // Create the new level:
		pLevelT->Create(pLevelT->iWidth, pLevelT->iHeight, pLevelT->fFieldDepth, 
						  pLevelT->fFieldWidth, pLevelT->fFieldHeight);
		// Copy the old fields info into the new level:
		for(y = 0; y < pOldLevelTemp->iHeight-1; y++)
		{
			if(y > pLevelT->iHeight-2)
				break;
			for(x = 0; x < pOldLevelTemp->iWidth-1; x++)
			{
				if(x > pLevelT->iWidth-2)
					break;
				pNewFieldT = &pLevelT->pField[y*pLevelT->iWidth+x];
				pOldFieldT = &pOldLevelTemp->pField[y*pOldLevelTemp->iWidth+x];
				pNewFieldT->bWall = pOldFieldT->bWall;
				pNewFieldT->bActive = pOldFieldT->bActive;
				pNewFieldT->bNoBackfaceCulling = pOldFieldT->bNoBackfaceCulling;
				for(i = 0; i < 6; i++)
				{
					pNewFieldT->iSurface[i] = pOldFieldT->iSurface[i];
					pNewFieldT->pSurface[i] = pOldFieldT->pSurface[i];
				}
				// Copy the points: (some point's are copied more than 1 time... I think that's no problem...)
				for(i = 0; i < 6; i++)
					for(i2 = 0; i2 < 4; i2++)
					{
						memcpy(pLevelT->fPoint[pNewFieldT->iFace[i][i2]], pOldLevelTemp->fPoint[pOldFieldT->iFace[i][i2]], sizeof(FLOAT3));
						memcpy(pLevelT->fColor[pNewFieldT->iFace[i][i2]], pOldLevelTemp->fColor[pOldFieldT->iFace[i][i2]], sizeof(FLOAT3));
					}
			}
		}	
		//
		// Destroy the old stuff:
		if(pLevel->pField)
			free(pLevel->pField);
		if(pLevel->fPoint)
			free(pLevel->fPoint);
		delete pLevel;
		pLevel = pLevelT;
		delete pOldLevelTemp;
		// Update the actors:
		for(i = 0; i < MAX_ACTORS; i++)
		{
			if(!Actor[i].bActive)
				continue;
			GET_FIELD_ID(Actor[i].iFieldPos[X], Actor[i].iFieldPos[Y], Actor[i].iFieldID);
			if(Actor[i].iFieldID >= pLevel->iFields)
			{
				Actor[i].bActive = FALSE;
				continue;
			}
			if(Actor[i].bBridge)
			{
				pLevel->pField[Actor[i].iFieldID].pBridgeActor = &Actor[i];
				pLevel->pField[Actor[i].iFieldID].bActive = FALSE;
			}
			else
			{
				if(Actor[i].byType == ACTOR_BOX_NORMAL ||
				   Actor[i].byType == ACTOR_BOX_RED ||
				   Actor[i].byType == ACTOR_BOX_GREEN ||
				   Actor[i].byType == ACTOR_BOX_BLUE)
					pLevel->pField[Actor[i].iFieldID].pActor = &Actor[i];
				else
					pLevel->pField[Actor[i].iFieldID].pObject = &Actor[i];
			}
		}
		GET_FIELD_ID(pPlayer->iFieldPos[X], pPlayer->iFieldPos[Y], pPlayer->iFieldID);
		if(pPlayer->iFieldID >= pLevel->iFields)
			pPlayer->bActive = FALSE;
		else
			pLevel->pField[pPlayer->iFieldID].pActor = pPlayer;
		UpdateAllActorFields();
		// Update all walls:
		for(i = 0, y = 0; y < pLevel->iHeight; y++)
			for(x = 0; x < pLevel->iWidth; x++, i++)
			{
				if(!pLevel->pField[i].bActive)
					continue;
				pLevelT->SetFieldWall(x, y, pLevel->pField[i].bWall, FALSE);
			}
	}
	pLevel->lWaterAniTime = g_lNow;
	UpdateAllActorFields();
	if(!wglMakeCurrent(hDCEditorShow, hRCEditorShow))
		return;
} // end AdjustLevelDialog()	

LRESULT CALLBACK LevelMissionsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin LevelMissionsProc()
	char byTemp[256];
	short i;
	
	switch(iMessage)
    {
        case WM_INITDIALOG:
				hWndLevelMissions = hWnd;
				_AS->WriteLogMessage("Open level missions dialog");
				SetWindowText(hWnd, T_LevelMissions);
				SetDlgItemText(hWnd, ID_LEVEL_MISSIONS_OK, T_Ok);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_TIME_LIMIT, T_TimeLimit);
				sprintf(byTemp, "%d", pLevelT->iTimeLimit);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_TIME_LIMIT_TIME, byTemp);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_STEP_LIMIT, T_StepsLimit);
				sprintf(byTemp, "%d", pLevelT->iStepsLimit);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_STEP_LIMIT_LIMIT, byTemp);
				sprintf(byTemp, "%d", pLevelT->iCollectPoints);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_COLLECT_POINTS, byTemp);
				sprintf(byTemp, "%d", pLevelT->iCollectHealth);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_COLLECT_HEALTH, byTemp);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_EXIT, T_Exit);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_ALCOVE, T_Alcove);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_COLLECT_POINTS_CHECKED, T_CollectPoints);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_COLLECT_HEALTH_CHECKED, T_CollectHealth);
				// No free anchor:
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_ANCHOR, T_NoFreeAnchor);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_FOR_ALL_ANCHOR, T_ForAll);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_RED_ANCHOR, T_Red);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_GREEN_ANCHOR, T_Green);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_BLUE_ANCHOR, T_Blue);
				// No free box:
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_BOX, T_NoFreeBox);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_BOX, T_Normal);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_RED_BOX, T_Red);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_GREEN_BOX, T_Green);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_FREE_BLUE_BOX, T_Blue);
				// No box:
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_BOX, T_NoBox);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_NORMAL_BOX, T_Normal);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_RED_BOX, T_Red);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_GREEN_BOX, T_Green);
				SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_NO_BLUE_BOX, T_Blue);				


				UpdateLevelMissions();
				
				ShowWindow(hWnd, _AS->GetCmdShow());
				UpdateWindow(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_LEVEL_MISSIONS_OK:
					EndDialog(hWnd, FALSE);
					hWndLevelMissions = NULL;
					_AS->WriteLogMessage("Close level missions dialog");
				break;
			 
			    case IDC_LEVEL_MISSIONS_TIME_LIMIT:
					pLevelT->bTimeLimit = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_TIME_LIMIT, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_TIME_LIMIT_TIME:
					GetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_TIME_LIMIT_TIME, byTemp, 256);
					i = atoi(byTemp)		;
					if(i < 0)
					{
						i = 0;
						SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_TIME_LIMIT_TIME, "0");
					}
					pLevelT->iTimeLimit = i;
				break;

			    case IDC_LEVEL_MISSIONS_STEP_LIMIT:
					pLevelT->bStepsLimit = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_STEP_LIMIT, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_STEP_LIMIT_LIMIT:
					GetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_STEP_LIMIT_LIMIT, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
					{
						i = 0;
						SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_STEP_LIMIT_LIMIT, "0");
					}
					pLevelT->iStepsLimit = i;
				break;

			    case IDC_LEVEL_MISSIONS_EXIT:
					pLevelT->bMissionExit = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_EXIT, BM_GETCHECK, 0, 0L);
					pLevelT->bMissionAlcove = FALSE;
					UpdateLevelMissions();
				break;
			    
				case IDC_LEVEL_MISSIONS_ALCOVE:
					pLevelT->bMissionAlcove = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_ALCOVE, BM_GETCHECK, 0, 0L);
					pLevelT->bMissionExit = FALSE;
					UpdateLevelMissions();
				break;

				case IDC_LEVEL_MISSIONS_COLLECT_POINTS_CHECKED:
					pLevelT->bMissionCollectPoints = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_COLLECT_POINTS_CHECKED, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

				case IDC_LEVEL_MISSIONS_COLLECT_POINTS:
					GetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_COLLECT_POINTS, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
					{
						i = 0;
						SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_COLLECT_POINTS, "0");
					}
					pLevelT->iCollectPoints = i;
				break;

				case IDC_LEVEL_MISSIONS_COLLECT_HEALTH_CHECKED:
					pLevelT->bMissionCollectHealth = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_COLLECT_HEALTH_CHECKED, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

				case IDC_LEVEL_MISSIONS_COLLECT_HEALTH:
					GetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_COLLECT_HEALTH, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
					{
						i = 0;
						SetDlgItemText(hWnd, IDC_LEVEL_MISSIONS_COLLECT_HEALTH, "0");
					}
					pLevelT->iCollectHealth = i;
				break;

			// No free anchor:
			    case IDC_LEVEL_MISSIONS_NO_FREE_FOR_ALL_ANCHOR:
					pLevelT->bMissionNoFreeForAllAnchor = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_FOR_ALL_ANCHOR, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_ANCHOR:
					pLevelT->bMissionNoFreeNormalAnchor = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_ANCHOR, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_NO_FREE_RED_ANCHOR:
					pLevelT->bMissionNoFreeRedAnchor = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_RED_ANCHOR, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_NO_FREE_GREEN_ANCHOR:
					pLevelT->bMissionNoFreeGreenAnchor = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_GREEN_ANCHOR, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_NO_FREE_BLUE_ANCHOR:
					pLevelT->bMissionNoFreeBlueAnchor = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_BLUE_ANCHOR, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			// No free box:
			    case IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_BOX:
					pLevelT->bMissionNoFreeNormalBox = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_BOX, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_NO_FREE_RED_BOX:
					pLevelT->bMissionNoFreeRedBox = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_RED_BOX, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_NO_FREE_GREEN_BOX:
					pLevelT->bMissionNoFreeGreenBox = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_GREEN_BOX, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_NO_FREE_BLUE_BOX:
					pLevelT->bMissionNoFreeBlueBox = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_BLUE_BOX, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			// No box:
			    case IDC_LEVEL_MISSIONS_NO_NORMAL_BOX:
					pLevelT->bMissionNoNormalBox = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_NORMAL_BOX, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_NO_RED_BOX:
					pLevelT->bMissionNoRedBox = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_RED_BOX, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_NO_GREEN_BOX:
					pLevelT->bMissionNoGreenBox = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_GREEN_BOX, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;

			    case IDC_LEVEL_MISSIONS_NO_BLUE_BOX:
					pLevelT->bMissionNoBlueBox = SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_BLUE_BOX, BM_GETCHECK, 0, 0L);
					UpdateLevelMissions();
				break;
			}
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_LEVEL_MISSIONS_OK, 0);
		break;
    }
    return FALSE;
} // end LevelMissionsProc()

void UpdateLevelMissions(void)
{ // begin UpdateLevelMissions()
	if(!hWndLevelMissions)
		return;
	// Time limit:
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_TIME_LIMIT, BM_SETCHECK, pLevelT->bTimeLimit, 0L);
	EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_TIME_LIMIT_TIME), pLevelT->bTimeLimit);
	// Step limit:
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_STEP_LIMIT, BM_SETCHECK, pLevelT->bStepsLimit, 0L);
	EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_STEP_LIMIT_LIMIT), pLevelT->bStepsLimit);
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_EXIT, BM_SETCHECK, pLevelT->bMissionExit, 0L);
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_ALCOVE, BM_SETCHECK, pLevelT->bMissionAlcove, 0L);
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_COLLECT_POINTS_CHECKED, BM_SETCHECK, pLevelT->bMissionCollectPoints, 0L);
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_COLLECT_HEALTH_CHECKED, BM_SETCHECK, pLevelT->bMissionCollectHealth, 0L);
	EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_COLLECT_POINTS), pLevelT->bMissionCollectPoints);
	EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_COLLECT_HEALTH), pLevelT->bMissionCollectHealth);
	if(pLevelT->bMissionNoNormalBox && pLevelT->bMissionNoRedBox && pLevelT->bMissionNoGreenBox && pLevelT->bMissionNoBlueBox)
	{
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_FOR_ALL_ANCHOR), FALSE);
		pLevelT->bMissionNoFreeForAllAnchor = FALSE;
	}
	else
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_FOR_ALL_ANCHOR), TRUE);
	if(pLevelT->bMissionNoNormalBox)
	{
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_ANCHOR), FALSE);
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_BOX), FALSE);
		pLevelT->bMissionNoFreeNormalAnchor = FALSE;
		pLevelT->bMissionNoFreeNormalBox = FALSE;
	}
	else
	{
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_ANCHOR), TRUE);
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_BOX), TRUE);
	}
	if(pLevelT->bMissionNoRedBox)
	{
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_RED_ANCHOR), FALSE);
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_RED_BOX), FALSE);
		pLevelT->bMissionNoFreeRedAnchor = FALSE;
		pLevelT->bMissionNoFreeRedBox = FALSE;
	}
	else
	{
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_RED_ANCHOR), TRUE);
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_RED_BOX), TRUE);
	}
	if(pLevelT->bMissionNoGreenBox)
	{
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_GREEN_ANCHOR), FALSE);
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_GREEN_BOX), FALSE);
		pLevelT->bMissionNoFreeGreenAnchor = FALSE;
		pLevelT->bMissionNoFreeGreenBox = FALSE;
	}
	else
	{
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_GREEN_ANCHOR), TRUE);
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_GREEN_BOX), TRUE);
	}
	if(pLevelT->bMissionNoBlueBox)
	{
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_BLUE_ANCHOR), FALSE);
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_BLUE_BOX), FALSE);
		pLevelT->bMissionNoFreeBlueAnchor = FALSE;
		pLevelT->bMissionNoFreeBlueBox = FALSE;
	}
	else
	{
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_BLUE_ANCHOR), TRUE);
		EnableWindow(GetDlgItem(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_BLUE_BOX), TRUE);
	}
	// No free anchor:
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_FOR_ALL_ANCHOR, BM_SETCHECK, pLevelT->bMissionNoFreeForAllAnchor, 0L);
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_ANCHOR, BM_SETCHECK, pLevelT->bMissionNoFreeNormalAnchor, 0L);
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_RED_ANCHOR, BM_SETCHECK, pLevelT->bMissionNoFreeRedAnchor, 0L);
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_GREEN_ANCHOR, BM_SETCHECK, pLevelT->bMissionNoFreeGreenAnchor, 0L);
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_BLUE_ANCHOR, BM_SETCHECK, pLevelT->bMissionNoFreeBlueAnchor, 0L);
	// No free box:
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_NORMAL_BOX, BM_SETCHECK, pLevelT->bMissionNoFreeNormalBox, 0L);
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_RED_BOX, BM_SETCHECK, pLevelT->bMissionNoFreeRedBox, 0L);
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_GREEN_BOX, BM_SETCHECK, pLevelT->bMissionNoFreeGreenBox, 0L);
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_FREE_BLUE_BOX, BM_SETCHECK, pLevelT->bMissionNoFreeBlueBox, 0L);
	// No box:
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_NORMAL_BOX, BM_SETCHECK, pLevelT->bMissionNoNormalBox, 0L);
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_RED_BOX, BM_SETCHECK, pLevelT->bMissionNoRedBox, 0L);
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_GREEN_BOX, BM_SETCHECK, pLevelT->bMissionNoGreenBox, 0L);
	SendDlgItemMessage(hWndLevelMissions, IDC_LEVEL_MISSIONS_NO_BLUE_BOX, BM_SETCHECK, pLevelT->bMissionNoBlueBox, 0L);
} // end UpdateLevelMissions()

LRESULT CALLBACK LevelToolsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin LevelToolsProc()
	char byTemp[256];
	short i;
	
	switch(iMessage)
    {
        case WM_INITDIALOG:
				_AS->WriteLogMessage("Open level tools dialog");
				hWndLevelTools = hWnd;
				SetWindowText(hWnd, T_StartTools);
				SetDlgItemText(hWnd, ID_LEVEL_TOOLS_OK, T_Ok);

				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_LIVES_T, T_LiveObj);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_POINTS_T, T_PointObj);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_WEAPON_T, T_WeaponObj);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_PULL_BOXES_T, T_PullObj);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_THROW_BOXES_T, T_ThrowObj);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_FORCE_T, T_ForceObj);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_JUMP_T, T_Jump);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_GHOST, T_GhostObj);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_SPEED, T_SpeedObj);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_WING, T_WingsObj);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_SHIELD, T_ShieldObj);

				sprintf(byTemp, "%d", pLevelT->iToolsLives);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_LIVES, byTemp);
				sprintf(byTemp, "%d", pLevelT->iToolsPoints);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_POINTS, byTemp);
				sprintf(byTemp, "%d", pLevelT->iToolsWeapon);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_WEAPON, byTemp);
				sprintf(byTemp, "%d", pLevelT->iToolsPull);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_PULL, byTemp);
				sprintf(byTemp, "%d", pLevelT->iToolsThrow);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_THROW, byTemp);
				sprintf(byTemp, "%d", pLevelT->iToolsForce);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_FORCE, byTemp);
				sprintf(byTemp, "%d", pLevelT->iToolsJump);
				SetDlgItemText(hWnd, IDC_LEVEL_TOOLS_JUMP, byTemp);

				UpdateLevelTools();
				
				ShowWindow(hWnd, _AS->GetCmdShow());
				UpdateWindow(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_LEVEL_TOOLS_OK:
					EndDialog(hWnd, FALSE);
					hWndLevelTools = NULL;
					_AS->WriteLogMessage("Close level tools dialog");
				break;
					
				case IDC_LEVEL_TOOLS_LIVES:
					GetDlgItemText(hWnd, IDC_LEVEL_TOOLS_LIVES, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
						i = 0;
					pLevelT->iToolsLives = i;
				break;

				case IDC_LEVEL_TOOLS_POINTS:
					GetDlgItemText(hWnd, IDC_LEVEL_TOOLS_POINTS, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
						i = 0;
					pLevelT->iToolsPoints = i;
				break;

				case IDC_LEVEL_TOOLS_WEAPON_UNLIMITED:
					pLevelT->bUnlimitedWeapon = SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_WEAPON_UNLIMITED, BM_GETCHECK, 0, 0L);
					PlayerInfo.bWeapon = pLevelT->bUnlimitedWeapon;
					if(pLevelT->iToolsWeapon)
						PlayerInfo.bWeapon = TRUE;
					UpdateLevelTools();
				break;

				case IDC_LEVEL_TOOLS_WEAPON:
					GetDlgItemText(hWnd, IDC_LEVEL_TOOLS_WEAPON, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
						i = 0;
					pLevelT->iToolsWeapon = i;
					if(pLevelT->iToolsWeapon)
						PlayerInfo.bWeapon = TRUE;
				break;

				case IDC_LEVEL_TOOLS_PULL_UNLIMITED:
					pLevelT->bUnlimitedPull = SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_PULL_UNLIMITED, BM_GETCHECK, 0, 0L);
					UpdateLevelTools();
				break;

				case IDC_LEVEL_TOOLS_PULL:
					GetDlgItemText(hWnd, IDC_LEVEL_TOOLS_PULL, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
						i = 0;
					pLevelT->iToolsPull = i;
				break;

				case IDC_LEVEL_TOOLS_THROW_UNLIMITED:
					pLevelT->bUnlimitedThrow = SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_THROW_UNLIMITED, BM_GETCHECK, 0, 0L);
					UpdateLevelTools();
				break;

				case IDC_LEVEL_TOOLS_THROW:
					GetDlgItemText(hWnd, IDC_LEVEL_TOOLS_THROW, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
						i = 0;
					pLevelT->iToolsThrow = i;
				break;

				case IDC_LEVEL_TOOLS_FORCE_UNLIMITED:
					pLevelT->bUnlimitedForce = SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_FORCE_UNLIMITED, BM_GETCHECK, 0, 0L);
					UpdateLevelTools();
				break;

				case IDC_LEVEL_TOOLS_FORCE:
					GetDlgItemText(hWnd, IDC_LEVEL_TOOLS_FORCE, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
						i = 0;
					pLevelT->iToolsForce = i;
				break;

				case IDC_LEVEL_TOOLS_JUMP_UNLIMITED:
					pLevelT->bUnlimitedJump = SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_JUMP_UNLIMITED, BM_GETCHECK, 0, 0L);
					UpdateLevelTools();
				break;

				case IDC_LEVEL_TOOLS_JUMP:
					GetDlgItemText(hWnd, IDC_LEVEL_TOOLS_JUMP, byTemp, 256);
					i = atoi(byTemp);
					if(i < 0)
						i = 0;
					pLevelT->iToolsJump = i;
				break;

				case IDC_LEVEL_TOOLS_GHOST:
					pLevelT->bToolsGhost = SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_GHOST, BM_GETCHECK, 0, 0L);
					PlayerInfo.bGhost = pLevelT->bToolsGhost;
				break;

				case IDC_LEVEL_TOOLS_SPEED:
					pLevelT->bToolsSpeed = SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_SPEED, BM_GETCHECK, 0, 0L);
					PlayerInfo.bSpeed = pLevelT->bToolsSpeed;
				break;

				case IDC_LEVEL_TOOLS_WING:
					pLevelT->bToolsWing = SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_WING, BM_GETCHECK, 0, 0L);
				break;

				case IDC_LEVEL_TOOLS_SHIELD:
					pLevelT->bToolsShield = SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_SHIELD, BM_GETCHECK, 0, 0L);
					PlayerInfo.bShield = pLevelT->bToolsShield;
				break;
			}
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_LEVEL_TOOLS_OK, 0);
		break;
    }
    return FALSE;
} // end LevelToolsProc()

void UpdateLevelTools(void)
{ // begin UpdateLevelTools()
	if(!hWndLevelTools)
		return;
	SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_WEAPON_UNLIMITED, BM_SETCHECK, pLevelT->bUnlimitedWeapon, 0L);
	SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_PULL_UNLIMITED, BM_SETCHECK, pLevelT->bUnlimitedPull, 0L);
	SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_THROW_UNLIMITED, BM_SETCHECK, pLevelT->bUnlimitedThrow, 0L);
	SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_FORCE_UNLIMITED, BM_SETCHECK, pLevelT->bUnlimitedForce, 0L);
	SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_JUMP_UNLIMITED, BM_SETCHECK, pLevelT->bUnlimitedJump, 0L);
	if(pLevelT->bUnlimitedWeapon)
		EnableWindow(GetDlgItem(hWndLevelTools, IDC_LEVEL_TOOLS_WEAPON), FALSE);
	else
		EnableWindow(GetDlgItem(hWndLevelTools, IDC_LEVEL_TOOLS_WEAPON), TRUE);
	if(pLevelT->bUnlimitedPull)
		EnableWindow(GetDlgItem(hWndLevelTools, IDC_LEVEL_TOOLS_PULL), FALSE);
	else
		EnableWindow(GetDlgItem(hWndLevelTools, IDC_LEVEL_TOOLS_PULL), TRUE);
	if(pLevelT->bUnlimitedThrow)
		EnableWindow(GetDlgItem(hWndLevelTools, IDC_LEVEL_TOOLS_THROW), FALSE);
	else
		EnableWindow(GetDlgItem(hWndLevelTools, IDC_LEVEL_TOOLS_THROW), TRUE);
	if(pLevelT->bUnlimitedForce)
		EnableWindow(GetDlgItem(hWndLevelTools, IDC_LEVEL_TOOLS_FORCE), FALSE);
	else
		EnableWindow(GetDlgItem(hWndLevelTools, IDC_LEVEL_TOOLS_FORCE), TRUE);
	if(pLevelT->bUnlimitedJump)
		EnableWindow(GetDlgItem(hWndLevelTools, IDC_LEVEL_TOOLS_JUMP), FALSE);
	else
		EnableWindow(GetDlgItem(hWndLevelTools, IDC_LEVEL_TOOLS_JUMP), TRUE);
	SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_GHOST, BM_SETCHECK, pLevelT->bToolsGhost, 0L);
	SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_SPEED, BM_SETCHECK, pLevelT->bToolsSpeed, 0L);
	SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_WING, BM_SETCHECK, pLevelT->bToolsWing, 0L);
	SendDlgItemMessage(hWndLevelTools, IDC_LEVEL_TOOLS_SHIELD, BM_SETCHECK, pLevelT->bToolsShield, 0L);
} // end UpdateLevelTools()

//-----------------------------------------------------------------------------
// File: Player.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"



// Variables: *****************************************************************
CAMPAIGN CurrentCampaign;	 // The current campaign 
short iCurrentCampaignLevel; // The current level of the campaign
char **pbyCampaignLevelNames; // The level names of the campaign (e.g. for the level selection)
// Level missions state:
BOOL bLevelComplete;

BOOL bMissionExitComplete,
	 bMissionAlcoveComplete;

// Collect objects:
BOOL bMissionCollectPointsComplete,
	 bMissionCollectHealthComplete;
short iCollectedPoints;

// Anchors:
BOOL bMissionNoFreeForAllAnchorComplete,
	 bMissionNoFreeNormalAnchorComplete,
	 bMissionNoFreeRedAnchorComplete,
	 bMissionNoFreeGreenAnchorComplete,
	 bMissionNoFreeBlueAnchorComplete;
short iUsedForAllAnchors,
	  iUsedNormalAnchors,
	  iUsedRedAnchors,
	  iUsedGreenAnchors,
	  iUsedBlueAnchors;

// Free boxes:
BOOL bMissionNoFreeNormalBoxesComplete,
	 bMissionNoFreeRedBoxesComplete,
	 bMissionNoFreeGreenBoxesComplete,
	 bMissionNoFreeBlueBoxesComplete;
short iNoneFreeNormalBoxes,
	  iNoneFreeRedBoxes,
	  iNoneFreeGreenBoxes,
	  iNoneFreeBlueBoxes;

// Destroyed boxes:
BOOL bMissionNoNormalBoxesComplete,
	 bMissionNoRedBoxesComplete,
	 bMissionNoGreenBoxesComplete,
	 bMissionNoBlueBoxesComplete;
short iDestroyedNormalBoxes,
	  iDestroyedRedBoxes,
	  iDestroyedGreenBoxes,
	  iDestroyedBlueBoxes;
HWND hWndCampaignEditor;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
void InitMissions(void);
void CheckMissions(void);
void ShowMissionState(AS_WINDOW *);
LRESULT CALLBACK CampaignEditorProc(HWND, UINT, WPARAM, LPARAM);
void UpdateCampaignEditorButtons(void);
LRESULT CALLBACK SetNumberOfCampaignLevelsProc(HWND, UINT, WPARAM, LPARAM);
BOOL LoadCampaign(CAMPAIGN *, char *);
void SaveCampaign(CAMPAIGN *, char *);
void DestroyCampaign(CAMPAIGN *);
///////////////////////////////////////////////////////////////////////////////


void InitMissions(void)
{ // begin InitMissions()
	// Initalize the level missions state:
	bLevelComplete = FALSE;
	iUsedForAllAnchors = iUsedNormalAnchors = iUsedRedAnchors = iUsedGreenAnchors = iUsedBlueAnchors =
	iDestroyedNormalBoxes = iDestroyedRedBoxes = iDestroyedGreenBoxes = iDestroyedBlueBoxes = 
	iNoneFreeNormalBoxes = iNoneFreeRedBoxes = iNoneFreeGreenBoxes = iNoneFreeBlueBoxes = 0;
	iCollectedPoints = 0;

	if(pLevel->bMissionExit)
		bMissionExitComplete = FALSE;
	else
		bMissionExitComplete = TRUE;
	if(pLevel->bMissionAlcove)
		bMissionAlcoveComplete = FALSE;
	else
		bMissionAlcoveComplete = TRUE;

	// Collect objects:
	if(pLevel->bMissionCollectPoints)
		bMissionCollectPointsComplete = FALSE;
	else
		bMissionCollectPointsComplete = FALSE;
	if(pLevel->bMissionCollectHealth)
		bMissionCollectHealthComplete = FALSE;
	else
		bMissionCollectHealthComplete = FALSE;
	
	// Anchors:
	if(pLevel->bMissionNoFreeForAllAnchor)
		bMissionNoFreeForAllAnchorComplete = FALSE;
	else
		bMissionNoFreeForAllAnchorComplete = TRUE;
	if(pLevel->bMissionNoFreeNormalAnchor)
		bMissionNoFreeNormalAnchorComplete = FALSE;
	else
		bMissionNoFreeNormalAnchorComplete = TRUE;
	if(pLevel->bMissionNoFreeRedAnchor)
		bMissionNoFreeRedAnchorComplete = FALSE;
	else
		bMissionNoFreeRedAnchorComplete = TRUE;
	if(pLevel->bMissionNoFreeGreenAnchor)
		bMissionNoFreeGreenAnchorComplete = FALSE;
	else
		bMissionNoFreeGreenAnchorComplete = TRUE;
	if(pLevel->bMissionNoFreeBlueAnchor)
		bMissionNoFreeBlueAnchorComplete = FALSE;
	else
		bMissionNoFreeBlueAnchorComplete = TRUE;

	// No free boxes:
	if(pLevel->bMissionNoFreeNormalBox)
		bMissionNoFreeNormalBoxesComplete = FALSE;
	else
		bMissionNoFreeNormalBoxesComplete = TRUE;
	if(pLevel->bMissionNoFreeRedBox)
		bMissionNoFreeRedBoxesComplete = FALSE;
	else
		bMissionNoFreeRedBoxesComplete = TRUE;
	if(pLevel->bMissionNoFreeGreenBox)
		bMissionNoFreeGreenBoxesComplete = FALSE;
	else
		bMissionNoFreeGreenBoxesComplete = TRUE;
	if(pLevel->bMissionNoFreeBlueBox)
		bMissionNoFreeBlueBoxesComplete = FALSE;
	else
		bMissionNoFreeBlueBoxesComplete = TRUE;

	// Destroyed boxes:
	if(pLevel->bMissionNoNormalBox)
		bMissionNoNormalBoxesComplete = FALSE;
	else
		bMissionNoNormalBoxesComplete = TRUE;
	if(pLevel->bMissionNoRedBox)
		bMissionNoRedBoxesComplete = FALSE;
	else
		bMissionNoRedBoxesComplete = TRUE;
	if(pLevel->bMissionNoGreenBox)
		bMissionNoGreenBoxesComplete = FALSE;
	else
		bMissionNoGreenBoxesComplete = TRUE;
	if(pLevel->bMissionNoBlueBox)
		bMissionNoBlueBoxesComplete = FALSE;
	else
		bMissionNoBlueBoxesComplete = TRUE;

} // end InitMissions()

void CheckMissions(void)
{ // begin CheckMissions()
	short i;

	if(pLevel->bMissionExit)
	{
		if(pLevel->pField[pPlayer->iFieldID].pSurface[FACE_FLOOR]->bExit && 
		   pPlayer->fFieldPos[X] == 0.0f && pPlayer->fFieldPos[Y] == 0.0f &&
		   pPlayer->byAction != ACTION_JUMP)
			bMissionExitComplete = TRUE;
		else
			bMissionExitComplete = FALSE;
	}
	else
		bMissionExitComplete = TRUE;
	if(pLevel->bMissionAlcove)
	{
		if(pLevel->pField[pPlayer->iFieldID].pSurface[FACE_FLOOR]->bAlcove && 
		   pPlayer->fFieldPos[X] == 0.0f && pPlayer->fFieldPos[Y] == 0.0f &&
		   pPlayer->byAction != ACTION_JUMP)
			bMissionAlcoveComplete = TRUE;
		else
			bMissionAlcoveComplete = FALSE;
	}
	else
		bMissionAlcoveComplete = TRUE;

	// Collect objects:
	if(pLevel->bMissionCollectPoints)
	{
		if(iCollectedPoints < pLevel->iCollectPoints)
			bMissionCollectPointsComplete = FALSE;
		else
			bMissionCollectPointsComplete = TRUE;
	}
	else
		bMissionCollectPointsComplete = TRUE;
	if(pLevel->bMissionCollectHealth)
	{
		if(pPlayer->fPower < pLevel->iCollectHealth)
			bMissionCollectHealthComplete = FALSE;
		else
			bMissionCollectHealthComplete = TRUE;
	}
	else
		bMissionCollectHealthComplete = TRUE;

	// Check anchors:
	if(pLevel->bMissionNoFreeForAllAnchor && iUsedForAllAnchors == pLevel->iForAllAnchors)
		bMissionNoFreeForAllAnchorComplete = TRUE;
	else
	{
		if(pLevel->bMissionNoFreeForAllAnchor)
			bMissionNoFreeForAllAnchorComplete = FALSE;
	}
	if(pLevel->bMissionNoFreeNormalAnchor && iUsedNormalAnchors == pLevel->iNormalAnchors)
		bMissionNoFreeNormalAnchorComplete = TRUE;
	else
	{
		if(pLevel->bMissionNoFreeNormalAnchor)
			bMissionNoFreeNormalAnchorComplete = FALSE;
	}
	if(pLevel->bMissionNoFreeRedAnchor && iUsedRedAnchors == pLevel->iRedAnchors)
		bMissionNoFreeRedAnchorComplete = TRUE;
	else
	{
		if(pLevel->bMissionNoFreeRedAnchor)
			bMissionNoFreeRedAnchorComplete = FALSE;
	}
	if(pLevel->bMissionNoFreeGreenAnchor && iUsedGreenAnchors == pLevel->iGreenAnchors)
		bMissionNoFreeGreenAnchorComplete = TRUE;
	else
	{
		if(pLevel->bMissionNoFreeGreenAnchor)
			bMissionNoFreeGreenAnchorComplete = FALSE;
	}
	if(pLevel->bMissionNoFreeBlueAnchor && iUsedBlueAnchors == pLevel->iBlueAnchors)
		bMissionNoFreeBlueAnchorComplete = TRUE;
	else
	{
		if(pLevel->bMissionNoFreeBlueAnchor)
			bMissionNoFreeBlueAnchorComplete = FALSE;
	}

	// Check free boxes:
	if(pLevel->bMissionNoFreeNormalBox && iNoneFreeNormalBoxes == pLevel->iNormalBoxes)
		bMissionNoFreeNormalBoxesComplete = TRUE;
	else
	{
		if(pLevel->bMissionNoFreeNormalBox)
			bMissionNoFreeNormalBoxesComplete = FALSE;
	}
	if(pLevel->bMissionNoFreeRedBox && iNoneFreeRedBoxes == pLevel->iRedBoxes)
		bMissionNoFreeRedBoxesComplete = TRUE;
	else
	{
		if(pLevel->bMissionNoFreeRedBox)
			bMissionNoFreeRedBoxesComplete = FALSE;
	}
	if(pLevel->bMissionNoFreeGreenBox && iNoneFreeGreenBoxes == pLevel->iGreenBoxes)
		bMissionNoFreeGreenBoxesComplete = TRUE;
	else
	{
		if(pLevel->bMissionNoFreeGreenBox)
			bMissionNoFreeGreenBoxesComplete = FALSE;
	}
	if(pLevel->bMissionNoFreeBlueBox && iNoneFreeBlueBoxes == pLevel->iBlueBoxes)
		bMissionNoFreeBlueBoxesComplete = TRUE;
	else
	{
		if(pLevel->bMissionNoFreeBlueBox)
			bMissionNoFreeBlueBoxesComplete = FALSE;
	}

	// Check destroyed boxes:
	if(pLevel->bMissionNoNormalBox && iDestroyedNormalBoxes == pLevel->iNormalBoxes)
		bMissionNoNormalBoxesComplete = TRUE;
	else
	{
		if(pLevel->bMissionNoNormalBox)
			bMissionNoNormalBoxesComplete = FALSE;
	}
	if(pLevel->bMissionNoRedBox && iDestroyedRedBoxes == pLevel->iRedBoxes)
		bMissionNoRedBoxesComplete = TRUE;
	else
	{
		if(pLevel->bMissionNoRedBox)
			bMissionNoRedBoxesComplete = FALSE;
	}
	if(pLevel->bMissionNoGreenBox && iDestroyedGreenBoxes == pLevel->iGreenBoxes)
		bMissionNoGreenBoxesComplete = TRUE;
	else
	{
		if(pLevel->bMissionNoGreenBox)
			bMissionNoGreenBoxesComplete = FALSE;
	}
	if(pLevel->bMissionNoBlueBox && iDestroyedBlueBoxes == pLevel->iBlueBoxes)
		bMissionNoBlueBoxesComplete = TRUE;
	else
	{
		if(pLevel->bMissionNoBlueBox)
			bMissionNoBlueBoxesComplete = FALSE;
	}


	// Check if the mission is complete:
	if(bMissionNoFreeForAllAnchorComplete &&
	   bMissionNoFreeNormalAnchorComplete &&
	   bMissionNoFreeRedAnchorComplete &&
	   bMissionNoFreeGreenAnchorComplete &&
	   bMissionNoFreeBlueAnchorComplete &&
	   bMissionNoNormalBoxesComplete &&
	   bMissionNoRedBoxesComplete &&
	   bMissionNoGreenBoxesComplete &&
	   bMissionNoBlueBoxesComplete &&
	   bMissionNoFreeNormalBoxesComplete &&
	   bMissionNoFreeRedBoxesComplete &&
	   bMissionNoFreeGreenBoxesComplete &&
	   bMissionNoFreeBlueBoxesComplete &&
	   bMissionExitComplete &&
	   bMissionAlcoveComplete &&
	   bMissionCollectPointsComplete &&
	   bMissionCollectHealthComplete)
	{ // Yea, the level is complete:
		bLevelComplete = TRUE;
		lPauseTimer = g_lNow;
		bPause = TRUE;
		bCameraAnimation = pLevel->bEndCamera;
		memset(&TempCamera, 0, sizeof(AS_CAMERA));
		lCameraTimer = g_lNow;
		pLevel->iCurrentCameraStep = 0;
		if(pLevel->bEndCamera)
			pLevel->pCurrentCameraScript = &pLevel->pCameraScript[pLevel->iEndCamera];
		bLevelPressAnyKey = FALSE;
		lLevelCompleteTimer = g_lNow;
		iLevelCompleteSpeed = 200;
		for(i = 0; i < 256; i++)
			ASKeys[i] = 0;
		// Player stand now:
		pPlayer->byAction = ACTION_STAND;
		pPlayer->byAnimation = 1;
		pPlayer->iAniStep = 0;
		pPlayer->dwAniTime = g_lNow;
	}
	else
		bLevelComplete = FALSE;

	if(((pLevel->bTimeLimit && pLevel->iTimeLimit <= 0) ||
	   (pLevel->bStepsLimit && pLevel->iStepsLimit <= 0)) &&
	   !OktaActor.bActive && !bLevelComplete)
	{ // Time out or steps out, wake up the Okta:
		OktaActor.bActive = TRUE;
		OktaActor.bThrow = FALSE;
		OktaActor.fWorldPos[X] = pPlayer->fWorldPos[X];
		OktaActor.fWorldPos[Y] = pPlayer->fWorldPos[Y];
		OktaActor.fWorldPos[Z] = pPlayer->fWorldPos[Z]+pCamera->fZ;
		OktaActor.iAniStep = pOktaModel->Ani.anim[2].firstFrame;
	}
} // end CheckMissions()

void ShowMissionState(AS_WINDOW *pWindow)
{ // begin ShowMissionState()
	char byTemp[256];
	short iY = 250;

	// Level information:
	pWindow->glPrint(10, 390, pLevel->byName, 0);
	sprintf(byTemp, "%s: %s", T_Author, pLevel->byAuthor);
	pWindow->glPrint(10, 370, byTemp, 0);

	// Show missions state:
	if(bLevelComplete)
		pWindow->glPrint(250, 290, T_LevelComplete, 0);
	else
		pWindow->glPrint(250, 290, T_Missions, 0);
	
	if(pLevel->bMissionExit && !bMissionExitComplete)
	{
		pWindow->glPrint(150, iY, T_GoToExit, 0);
		iY -= 20;
	}
	if(pLevel->bMissionAlcove && !bMissionAlcoveComplete)
	{
		pWindow->glPrint(150, iY, T_GoToAlcove, 0);
		iY -= 20;
	}
	// Collect objects:
	if(pLevel->bMissionCollectPoints && !bMissionCollectPointsComplete)
	{
		sprintf(byTemp, "%s (%d)", T_CollectPoints, (short) pLevel->iCollectPoints-iCollectedPoints);
		pWindow->glPrint(150, iY, byTemp, 0);
		iY -= 20;
	}
	if(pLevel->bMissionCollectHealth && !bMissionCollectHealthComplete)
	{
		sprintf(byTemp, "%s (%d)", T_CollectHealth, (short) (pLevel->iCollectHealth-pPlayer->fPower));
		pWindow->glPrint(150, iY, byTemp, 0);
		iY -= 20;
	}
	// Anchors:
	if(pLevel->bMissionNoFreeForAllAnchor && !bMissionNoFreeForAllAnchorComplete)
	{
		
		sprintf(byTemp, "%s (%d)", T_FillAllForAllAnchors, pLevel->iForAllAnchors-iUsedForAllAnchors);
		pWindow->glPrint(150, iY, byTemp, 0);
		iY -= 20;
	}
	if(pLevel->bMissionNoFreeNormalAnchor && !bMissionNoFreeNormalAnchorComplete)
	{
		
		sprintf(byTemp, "%s (%d)", T_FillAllNormalAnchors, pLevel->iNormalAnchors-iUsedNormalAnchors);
		pWindow->glPrint(150, iY, byTemp, 0);
		iY -= 20;
	}
	if(pLevel->bMissionNoFreeRedAnchor &&!bMissionNoFreeRedAnchorComplete)
	{
		sprintf(byTemp, "%s (%d)", T_FillAllRedAnchors, pLevel->iRedAnchors-iUsedRedAnchors);
		pWindow->glPrint(150, iY, byTemp, 0);
		iY -= 20;
	}
	if(pLevel->bMissionNoFreeGreenAnchor &&!bMissionNoFreeGreenAnchorComplete)
	{
		sprintf(byTemp, "%s (%d)", T_FillAllGreenAnchors, pLevel->iGreenAnchors-iUsedGreenAnchors);
		pWindow->glPrint(150, iY, byTemp, 0);
		iY -= 20;
	}
	if(pLevel->bMissionNoFreeBlueAnchor &&!bMissionNoFreeBlueAnchorComplete)
	{
		sprintf(byTemp, "%s (%d)", T_FillAllBlueAnchors, pLevel->iBlueAnchors-iUsedBlueAnchors);
		pWindow->glPrint(150, iY, byTemp, 0);
		iY -= 20;
	}

	// Free boxes:
	if(pLevel->bMissionNoFreeNormalBox && !bMissionNoFreeNormalBoxesComplete)
	{
		sprintf(byTemp, "%s (%d)", T_NoFreeNormalBox, pLevel->iNormalBoxes-iNoneFreeNormalBoxes);
		pWindow->glPrint(150, iY, byTemp, 0);
		iY -= 20;
	}
	if(pLevel->bMissionNoFreeRedBox && !bMissionNoFreeRedBoxesComplete)
	{
		sprintf(byTemp, "%s (%d)", T_NoFreeRedBox, pLevel->iRedBoxes-iNoneFreeRedBoxes);
		pWindow->glPrint(150, iY, byTemp, 0);
		iY -= 20;
	}
	if(pLevel->bMissionNoFreeGreenBox && !bMissionNoFreeGreenBoxesComplete)
	{
		sprintf(byTemp, "%s (%d)", T_NoFreeGreenBox, pLevel->iGreenBoxes-iNoneFreeGreenBoxes);
		pWindow->glPrint(150, iY, byTemp, 0);
		iY -= 20;
	}
	if(pLevel->bMissionNoFreeBlueBox && !bMissionNoFreeBlueBoxesComplete)
	{
		sprintf(byTemp, "%s (%d)", T_NoFreeBlueBox, pLevel->iBlueBoxes-iNoneFreeBlueBoxes);
		pWindow->glPrint(150, iY, byTemp, 0);
		iY -= 20;
	}

	// Destroyed boxes:
	if(pLevel->bMissionNoNormalBox && !bMissionNoNormalBoxesComplete)
	{
		sprintf(byTemp, "%s (%d)", T_DestroyAllNormalBoxes, pLevel->iNormalBoxes-iDestroyedNormalBoxes);
		pWindow->glPrint(150, iY, byTemp, 0);
		iY -= 20;
	}
	if(pLevel->bMissionNoRedBox && !bMissionNoRedBoxesComplete)
	{
		sprintf(byTemp, "%s (%d)", T_DestroyAllRedBoxes, pLevel->iRedBoxes-iDestroyedRedBoxes);
		pWindow->glPrint(150, iY, byTemp, 0);
		iY -= 20;
	}
	if(pLevel->bMissionNoGreenBox && !bMissionNoGreenBoxesComplete)
	{
		sprintf(byTemp, "%s (%d)", T_DestroyAllGreenBoxes, pLevel->iGreenBoxes-iDestroyedGreenBoxes);
		pWindow->glPrint(150, iY, byTemp, 0);
		iY -= 20;
	}
	if(pLevel->bMissionNoBlueBox && !bMissionNoBlueBoxesComplete)
	{
		sprintf(byTemp, "%s (%d)", T_DestroyAllBlueBoxes, pLevel->iBlueBoxes-iDestroyedBlueBoxes);
		pWindow->glPrint(150, iY, byTemp, 0);
		iY -= 20;
	}
} // end ShowMissionState()

LRESULT CALLBACK CampaignEditorProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin CampaignEditorProc()
    char byTemp[256];
	char *pbyTemp;
	short i, i2;
	FILE *fp;
	BOOL bKeyword;
	char byKeyword[256];

	switch(iMessage)
    {
        case WM_INITDIALOG:
				_AS->WriteLogMessage("Open campaign editor");
				hWndCampaignEditor = hWnd;
				for(i = 0; i < CurrentCampaign.iLevels; i++)
					free(CurrentCampaign.byLevelFilename[i]);
				free(CurrentCampaign.byLevelFilename);
				memset(&CurrentCampaign, 0, sizeof(CAMPAIGN));
				iCurrentCampaignLevel = 0;
				CurrentCampaign.iLevels = 1;
				CurrentCampaign.byLevelFilename = (char **) malloc(sizeof(char *)*CurrentCampaign.iLevels);
				CurrentCampaign.byLevelFilename[0] = (char *) malloc(sizeof(char)*256);
				memset(CurrentCampaign.byLevelFilename[0], 0, sizeof(char)*256);
				// Texts:
				SetWindowText(hWnd, T_CampaignEditor);
				SetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_FILE_T, T_File);
				SetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_NAME_T, T_Name);
				SetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_KEYWORD_T, T_Keyword);
				SetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_LEVELS, T_Levels);
				SetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_LEVEL_T, T_Level);
				SetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_LEVEL_FILE_T, T_File);
				SetDlgItemText(hWnd, ID_CAMPAIGN_EDITOR_OK, T_Ok);
				SetDlgItemText(hWnd, ID_CAMPAIGN_EDITOR_CANCEL, T_Cancel);
				SetDlgItemText(hWnd, ID_CAMPAIGN_EDITOR_LOAD, T_Load);
				SetDlgItemText(hWnd, ID_CAMPAIGN_EDITOR_SAVE, T_Save);
			Init:
				SetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_FILENAME, CurrentCampaign.byFilename);
				SetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_NAME, CurrentCampaign.byName);
				SetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_KEYWORD, CurrentCampaign.byKeyword);
				//
				UpdateCampaignEditorButtons();				
				ShowWindow(hWnd, _AS->GetCmdShow());
				UpdateWindow(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case ID_CAMPAIGN_EDITOR_OK:
					// Save the campaign:
					if(CurrentCampaign.byFilename[0] == '\0')
					{ // Get an filename:
						sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyCampaignsFile);
						pbyTemp = ASGetFileName(hWnd, T_SaveCampaign, CAM_FILE, 1, FALSE, byTemp);
						if(!pbyTemp)
							break;
						if(strlen(pbyTemp) > strlen(_AS->pbyProgramPath))
							strcpy(CurrentCampaign.byFilename, &pbyTemp[strlen(_AS->pbyProgramPath)]);
					}
					sprintf(byTemp, "%s%s", _AS->pbyProgramPath, CurrentCampaign.byFilename);
					SaveCampaign(&CurrentCampaign, byTemp);
					_AS->WriteLogMessage("Close campaign editor (ok)");
					EndDialog(hWnd, 0);
					return TRUE;

				case ID_CAMPAIGN_EDITOR_CANCEL:
					EndDialog(hWnd, 0);
					return TRUE;

				case ID_CAMPAIGN_EDITOR_LOAD:
					sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyCampaignsFile);
					pbyTemp = ASGetFileName(hWnd, T_LoadCampaign, CAM_FILE, 0, FALSE, byTemp);
					if(!pbyTemp)
						break;
					// Check for keyword:
					fp = fopen(pbyTemp, "rb");
					if(!fp)
						break;
					fread(&bKeyword, sizeof(BOOL), 1, fp);
					fread(&byKeyword, sizeof(char)*256, 1, fp);
					fclose(fp);
					if(bKeyword && !bMasterAccess)
					{ // Check the keyword:
						bKeyword = DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_KEYWORD), hWnd, (DLGPROC) KeywordProc);
						if(!bKeyword)
						{ // Wrong keyword!!
							MessageBox(hWnd, M_WrongKeyword, GAME_NAME, MB_OK | MB_ICONINFORMATION);
							break;
						}
						else
							if(bKeyword == -1)
								break;
					}
					LoadCampaign(&CurrentCampaign, pbyTemp);
					if(strlen(pbyTemp) > strlen(_AS->pbyProgramPath))
						strcpy(CurrentCampaign.byFilename, &pbyTemp[strlen(_AS->pbyProgramPath)]);
					sprintf(byTemp, "%s%s", _AS->pbyProgramPath, CurrentCampaign.byFilename);
					goto Init;

				case ID_CAMPAIGN_EDITOR_SAVE:
					sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyCampaignsFile);
					pbyTemp = ASGetFileName(hWnd, T_SaveCampaign, CAM_FILE, 1, FALSE, byTemp);
					if(!pbyTemp)
						break;
					if(strlen(pbyTemp) > strlen(_AS->pbyProgramPath))
						strcpy(CurrentCampaign.byFilename, &pbyTemp[strlen(_AS->pbyProgramPath)]);
					sprintf(byTemp, "%s%s", _AS->pbyProgramPath, CurrentCampaign.byFilename);
					SaveCampaign(&CurrentCampaign, byTemp);
					goto Init;
				
				case IDC_CAMPAIGN_EDITOR_FILENAME:
					GetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_FILENAME, CurrentCampaign.byFilename, 256);
				break;

				case IDC_CAMPAIGN_EDITOR_FIND_FILENAME:
					sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyCampaignsFile);
					pbyTemp = ASGetFileName(hWnd, T_GetACampaignFilename, CAM_FILE, 0, TRUE, byTemp);
					if(!pbyTemp)
						break;
					if(strlen(pbyTemp) > strlen(_AS->pbyProgramPath))
						strcpy(pLevel->byFilename, &pbyTemp[strlen(_AS->pbyProgramPath)]);
					SetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_FILENAME, pLevel->byFilename);
				break;

				case IDC_CAMPAIGN_EDITOR_NAME:
					GetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_NAME, CurrentCampaign.byName, 256);
				break;

				case IDC_CAMPAIGN_EDITOR_KEYWORD_T:
					CurrentCampaign.bKeyword = SendDlgItemMessage(hWnd, IDC_CAMPAIGN_EDITOR_KEYWORD_T, BM_GETCHECK, 0, 0L);
					UpdateCampaignEditorButtons();
				break;

				case IDC_CAMPAIGN_EDITOR_KEYWORD:
					GetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_KEYWORD, CurrentCampaign.byKeyword, 256);
				break;

				case IDC_CAMPAIGN_EDITOR_LEVELS:
					if((i = DialogBox(_AS->GetInstance(), MAKEINTRESOURCE(IDD_SET_NUMBER_OF_CAMPAIGN_LEVELS), hWnd, (DLGPROC) SetNumberOfCampaignLevelsProc)) == -1)
						break;
					if(i <= 0)
						i = 1;
					i2 = CurrentCampaign.iLevels;
					CurrentCampaign.iLevels = i;
					for(; i2 > i; i2--)
						free(CurrentCampaign.byLevelFilename[i2-1]);
					CurrentCampaign.byLevelFilename = (char **) realloc(CurrentCampaign.byLevelFilename, sizeof(char *)*CurrentCampaign.iLevels);
					for(; i2 < i; i2++)
					{
						CurrentCampaign.byLevelFilename[i2] = (char *) malloc(sizeof(char)*256);
						memset(CurrentCampaign.byLevelFilename[i2], 0, sizeof(char)*256);
					}
					if(iCurrentCampaignLevel >= CurrentCampaign.iLevels)
						iCurrentCampaignLevel = 0;
					UpdateCampaignEditorButtons();
				break;

				case ID_CAMPAIGN_EDITOR_LEVEL_LIST:
					i = (short) SendDlgItemMessage(hWnd, ID_CAMPAIGN_EDITOR_LEVEL_LIST, CB_GETCURSEL, 0, 0L);
					if(i == -1 || i >= CurrentCampaign.iLevels)
						break;
					iCurrentCampaignLevel = i;
					SetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_LEVEL_FILENAME, CurrentCampaign.byLevelFilename[iCurrentCampaignLevel]);
				break;

				case IDC_CAMPAIGN_EDITOR_LEVEL_FILENAME:
					GetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_LEVEL_FILENAME, CurrentCampaign.byLevelFilename[iCurrentCampaignLevel], 256);
					UpdateCampaignEditorButtons();
				break;

				case IDC_CAMPAIGN_EDITOR_FIND_LEVEL_FILENAME:
					sprintf(byTemp, "%s%s", _AS->pbyProgramPath, _AS->pbyCampaignsFile);
					pbyTemp = ASGetFileName(hWnd, T_GetALevelFilename, LEV_FILE, 0, TRUE, byTemp);
					if(!pbyTemp)
						break;
					if(strlen(pbyTemp) > strlen(_AS->pbyProgramPath))
						strcpy(CurrentCampaign.byLevelFilename[iCurrentCampaignLevel], &pbyTemp[strlen(_AS->pbyProgramPath)]);
					SetDlgItemText(hWnd, IDC_CAMPAIGN_EDITOR_LEVEL_FILENAME, CurrentCampaign.byLevelFilename[iCurrentCampaignLevel]);
					UpdateCampaignEditorButtons();
				break;
			}
        break;

		case WM_CLOSE: case WM_DESTROY:
			_AS->WriteLogMessage("Close campaign editor (cancel)");
			SendMessage(hWnd, WM_COMMAND, ID_CAMPAIGN_EDITOR_CANCEL, 0);
		break;
    }
    return FALSE;
} // end CampaignEditorProc()

void UpdateCampaignEditorButtons(void)
{ // begin UpdateCampaignEditorButtons()
	short i;
	char byTemp[256];
	
	if(!hWndCampaignEditor)
		return;
    SendDlgItemMessage(hWndCampaignEditor, IDC_CAMPAIGN_EDITOR_KEYWORD_T, BM_SETCHECK, CurrentCampaign.bKeyword, 0L);
	EnableWindow(GetDlgItem(hWndCampaignEditor, IDC_CAMPAIGN_EDITOR_KEYWORD), CurrentCampaign.bKeyword);
	SendDlgItemMessage(hWndCampaignEditor, ID_CAMPAIGN_EDITOR_LEVEL_LIST, CB_RESETCONTENT , 0, 0L);
	for(i = 0; i < CurrentCampaign.iLevels; i++)
	{
		sprintf(byTemp, "%d: %s", i+1, CurrentCampaign.byLevelFilename[i]);
		SendDlgItemMessage(hWndCampaignEditor, ID_CAMPAIGN_EDITOR_LEVEL_LIST, CB_ADDSTRING, 0, (LPARAM) byTemp);
	}
	SendDlgItemMessage(hWndCampaignEditor, ID_CAMPAIGN_EDITOR_LEVEL_LIST, CB_SETCURSEL, iCurrentCampaignLevel, 0L);
} // end UpdateCampaignEditorButtons()

LRESULT CALLBACK SetNumberOfCampaignLevelsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin SetNumberOfCampaignLevelsProc()
	char byTemp[256];
	short i;

    switch(iMessage)
    {
        case WM_INITDIALOG:
			SetWindowText(hWnd, T_SetNumberOfCampaignLevels);
			SetDlgItemText(hWnd, ID_SET_CAMPAIGN_LEVELS_OK, T_Ok);
			SetDlgItemText(hWnd, ID_SET_CAMPAIGN_LEVELS_CANCEL, T_Cancel);
			sprintf(byTemp, "%d", CurrentCampaign.iLevels);
			SetDlgItemText(hWnd, ID_SET_CAMPAIGN_LEVELS_NUMBER, byTemp);
			ShowWindow(hWnd, _AS->GetCmdShow());
			UpdateWindow(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case ID_SET_CAMPAIGN_LEVELS_OK:
					GetDlgItemText(hWnd, ID_SET_CAMPAIGN_LEVELS_NUMBER, byTemp, 256);
					i = (short) atoi(byTemp);
					if(!i)
						i++;
					EndDialog(hWnd, i);
                return TRUE;

                case ID_SET_CAMPAIGN_LEVELS_CANCEL:
					EndDialog(hWnd, -1);
                return TRUE;
            }
        break;

		case WM_CLOSE: case WM_DESTROY:
			SendMessage(hWnd, WM_COMMAND, ID_SET_CAMPAIGN_LEVELS_CANCEL, 0);
		break;
    }
    return FALSE;
} // end SetNumberOfCampaignLevelsProc()

BOOL LoadCampaign(CAMPAIGN *pCampaign, char *pbyFilename)
{ // begin LoadCampaign()
	FILE *fp;
	short i, iTemp;
	BOOL bTemp;
	char byTemp[256];


	_AS->WriteLogMessage("Load campaign: %s", pbyFilename);
	if(!pbyFilename)
		return 1;
	fp = fopen(pbyFilename, "rb");
	if(!fp)
		return 1;
	DestroyCampaign(pCampaign);
	strcpy(pCampaign->byFilename, pbyFilename);
	// Keyword:
	fread(&pCampaign->bKeyword, sizeof(BOOL), 1, fp);
	fread(&pCampaign->byKeyword, sizeof(char)*256, 1, fp);
	// Name:
	fread(&pCampaign->byName, sizeof(char)*256, 1, fp);
	// Levels
	fread(&pCampaign->iLevels, sizeof(short), 1, fp);
	pCampaign->byLevelFilename = (char **) malloc(sizeof(char *)*pCampaign->iLevels);
	for(i = 0; i < pCampaign->iLevels; i++)
	{
		pCampaign->byLevelFilename[i] = (char *) malloc(sizeof(char)*256);
		fread(pCampaign->byLevelFilename[i], sizeof(char)*256, 1, fp);
	}
	fclose(fp);

	// Get the level names:
	pbyCampaignLevelNames = (char **) malloc(sizeof(char *)*pCampaign->iLevels);
	for(i = 0; i < pCampaign->iLevels; i++)
	{
		sprintf(byTemp, "%s%s", _AS->pbyProgramPath, pCampaign->byLevelFilename[i]);
		fp = fopen(byTemp, "rb");
		if(!fp)
			continue;
		pbyCampaignLevelNames[i] = (char *) malloc(sizeof(char)*256);
		fread(&bTemp, sizeof(BOOL), 1, fp);
		fread(&byTemp, sizeof(char)*256, 1, fp);
		fread(&bTemp, sizeof(BOOL), 1, fp);
		fread(&iTemp, sizeof(short), 1, fp);
		fread(pbyCampaignLevelNames[i], sizeof(char)*256, 1, fp);
		fclose(fp);
	}
	_AS->WriteLogMessage("OK");
	return 0;
} // end LoadCampaign()

void SaveCampaign(CAMPAIGN *pCampaign, char *pbyFilename)
{ // begin SaveCampaign()
	FILE *fp;
	short i;

	_AS->WriteLogMessage("Save campaign: %s", pbyFilename);
	if(!pbyFilename)
		return;
	fp = fopen(pbyFilename, "wb");
	if(!fp)
		return;
	// Keyword:
	fwrite(&pCampaign->bKeyword, sizeof(BOOL), 1, fp);
	fwrite(&pCampaign->byKeyword, sizeof(char)*256, 1, fp);
	// Name:
	fwrite(&pCampaign->byName, sizeof(char)*256, 1, fp);
	// Levels
	fwrite(&pCampaign->iLevels, sizeof(short), 1, fp);
	for(i = 0; i < pCampaign->iLevels; i++)
		fwrite(pCampaign->byLevelFilename[i], sizeof(char)*256, 1, fp);
	fclose(fp);
	_AS->WriteLogMessage("OK");
	strcpy(pCampaign->byFilename, pbyFilename);
} // end LoadCampaign()

void DestroyCampaign(CAMPAIGN *pCampaign)
{ // begin DestroyCampaign()
	short i;
	
	// Destroy the game stuff:
	if(CurrentCampaign.byLevelFilename)
		for(i = 0; i < CurrentCampaign.iLevels; i++)
			SAFE_DELETE(CurrentCampaign.byLevelFilename[i]);
	SAFE_DELETE(CurrentCampaign.byLevelFilename);
	SAFE_DELETE(pbyCampaignLevelNames);
	memset(&CurrentCampaign, 0, sizeof(CAMPAIGN));
} // end DestroyCampaign()

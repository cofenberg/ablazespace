//-----------------------------------------------------------------------------
// File: Editor.h
//-----------------------------------------------------------------------------

#ifndef __AS_EDITOR_H__
#define __AS_EDITOR_H__


// Definitions: ***************************************************************
enum {EDITOR_SELECT_MENU, EDITOR_BRUSH_MENU, EDITOR_SURFACE_MENU,
	  EDITOR_OBJECT_MENU, EDITOR_TERRAIN_MENU, EDITOR_ENVIRONMENT_MENU,
	  EDITOR_CAMERA_MENU};
enum {EDITOR_SELECTED_WALL, EDITOR_SELECTED_COLOR, EDITOR_SELECTED_HEIGHT,
	  EDITOR_SELECTED_POINT, EDITOR_SELECTED_MIDDLE_HEIGHT, EDITOR_SELECTED_OBJECT,
	  EDITOR_SELECTED_LOWEST_HEIGHT, EDITOR_SELECTED_GREATEST_HEIGHT,
	  EDITOR_SELECTED_DEACTIVATE_FIELD, EDITOR_SELECTED_2_SIDES, EDITOR_SELECTED_CLEAR_FIELD,
	  EDITOR_ENVIRONMENT_FOG_COLOR, EDITOR_ENVIRONMENT_FOG_DENSITY,
	  EDITOR_ENVIRONMENT_WATER_COLOR, EDITOR_ENVIRONMENT_WATER_DENSITY,
	  EDITOR_ENVIRONMENT_WATER_HEIGHT, EDITOR_ENVIRONMENT_WATER_AMPLITUDE,
	  EDITOR_ENVIRONMENT_WATER_SPEED, EDITOR_ENVIRONMENT_SKY_CUBE_COLOR,
	  EDITOR_ENVIRONMENT_LIGHT, EDITOR_ENVIRONMENT_SKY_CUBE_SIZE,
	  EDITOR_SELECTED_OBJECT_XE, EDITOR_SELECTED_OBJECT_BOX_NORMAL,
	  EDITOR_SELECTED_OBJECT_BOX_RED, EDITOR_SELECTED_OBJECT_BOX_GREEN,
	  EDITOR_SELECTED_OBJECT_BOX_BLUE, EDITOR_SELECTED_OBJECT_HEALTH,
	  EDITOR_SELECTED_OBJECT_LIVE, EDITOR_SELECTED_OBJECT_PULL,
	  EDITOR_SELECTED_OBJECT_THROW, EDITOR_SELECTED_OBJECT_FORCE,
	  EDITOR_SELECTED_OBJECT_WEAPON, EDITOR_SELECTED_OBJECT_POINT,
	  EDITOR_SELECTED_OBJECT_GHOST, EDITOR_SELECTED_OBJECT_TIME,
	  EDITOR_SELECTED_OBJECT_STEP, EDITOR_SELECTED_OBJECT_SPEED,
	  EDITOR_SELECTED_OBJECT_WING, EDITOR_SELECTED_OBJECT_SHIELD,
	  EDITOR_SELECTED_OBJECT_JUMP, EDITOR_SELECTED_OBJECT_AIR};
// For the menu:
enum {TAB_EDITOR_SELECT, TAB_EDITOR_BRUSH, TAB_EDITOR_SURFACES,
	  TAB_EDITOR_OBJECTS, TAB_EDITOR_TERRAIN, TAB_EDITOR_ENVIRONMENT,
	  TAB_EDITOR_CAMERA};
#define EDITOR_TABS 7
///////////////////////////////////////////////////////////////////////////////

// Variables: *****************************************************************
extern HWND hWndEditor, hWndEditorShow;
extern HDC hDCEditorShow;
extern HGLRC hRCEditorShow;
extern BOOL bEditorTestLevel, bCameraAnimation, bEditorHeavy;
extern char byEditorBrushSize, byEditorMenu, byEditorSelected, byEditorSelectedID,
			byCurrentSkyCubeSide, iEditorRotate;
extern HWND hWndEditorTab[EDITOR_TABS];
extern long lCameraTimer;
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
extern HRESULT Editor(void);
extern HRESULT EditorDraw(AS_WINDOW *);
extern HRESULT EditorCheck(AS_WINDOW *);
extern void SetEditorLanguage(void);
extern HRESULT SaveLevelQuestion(void);
extern LRESULT CALLBACK KeywordProc(HWND, UINT, WPARAM, LPARAM);
///////////////////////////////////////////////////////////////////////////////


#endif // __AS_EDITOR_H__
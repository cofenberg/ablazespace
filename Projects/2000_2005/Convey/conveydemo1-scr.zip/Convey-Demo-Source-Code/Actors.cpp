//-----------------------------------------------------------------------------
// File: Actors.cpp
//-----------------------------------------------------------------------------

#include "AS\AS_Engine.h"
#include "ModuleHeaders.h"



// Variables: *****************************************************************
ACTOR Actor[MAX_ACTORS];
///////////////////////////////////////////////////////////////////////////////

// Functions: *****************************************************************
ACTOR *FindFreeActor(void);
short SortActors(void);
void ComputeActorHeight(ACTOR *, float);
void SetActorsLights(void);
void MoveActor(ACTOR *, short);
void UpdateAllActorFields(void);
void CheckActorField(ACTOR *);
void DrawEffects(void);
void DrawActors(void);
void CheckActors(BOOL);
void AnimateActorModel(ACTOR *, AS_MD2_MODEL, long, char);
void KillBox(ACTOR *);
void CheckBoxThrow(ACTOR *);
void DamageBox(ACTOR *);
void DrawBoundingBox(float [2][3], float);
void DisableBoxDocking(ACTOR *);
void DeleteActorType(ACTOR *);
void DisableNoneFreeBox(ACTOR *);
void SetNoneFreeBox(ACTOR *);
///////////////////////////////////////////////////////////////////////////////

// ACTOR functions: ***********************************************************
ACTOR::ACTOR(void)
{ // begin ACTOR()
	memset(this, 0, sizeof(ACTOR));
} // end ACTOR()

ACTOR::~ACTOR(void)
{ // begin ~ACTOR()
} // end ~ACTOR()

void ACTOR::Init(void)
{ // begin Init()
	memset(this, 0, sizeof(ACTOR));
} // end Init()
///////////////////////////////////////////////////////////////////////////////


ACTOR *FindFreeActor(void)
{ // begin FindFreeActor()
	ACTOR *pActorT;

	// Find a none active actor and give a pointer to it back:
	for(short i = 0; i < MAX_ACTORS; i++)
	{
		pActorT = &Actor[i];
		if(pActorT->bActive)
			continue;
		memset(pActorT, 0, sizeof(ACTOR));	
		pActorT->iID = i;
		pActorT->dwAniTime = g_lNow;
		pActorT->fColor[0] = 1.0f;
		pActorT->fColor[1] = 1.0f;
		pActorT->fColor[2] = 1.0f;
		pActorT->fAir = 1.0f;
		pActorT->iTempFieldID = -1;
		return pActorT;
	}
	return 0;
} // end FindFreeActor()

short SortActors(void)
{ // begin SortActors()
	ACTOR ActorT[MAX_ACTORS];
	short i, i2;
	
	// Sort all actors that all active are on the top, and
	// give the number of active actors back:
	memset(&ActorT, 0, sizeof(ACTOR)*MAX_ACTORS);
	for(i = 0, i2 = 0; i < MAX_ACTORS; i++)
	{
		if(!Actor[i].bActive)
			continue;
		memcpy(&ActorT[i2], &Actor[i], sizeof(ACTOR));
		i2++;
	}
	memcpy(&Actor, &ActorT, sizeof(ACTOR)*i2);
	return i2;
} // end SortActors()

void ComputeActorHeight(ACTOR *pActorT, float fSize)
{ // begin ComputeActorHeight()
	short iXPos, iYPos, iXFieldPos, iYFieldPos, i, iFieldID;
	FIELD *pFieldT;
	FLOAT3 fPoint;
	FLOAT3 fRayDirection;

	if(pActorT->bGoingDeath || pActorT->bDocked || (!pActorT->fPower && pActorT->byType == ACTOR_PLAYER) ||
	  (pActorT->fWorldPos[X] == pActorT->fLastHeightCheckWorldPos[X] &&
	   pActorT->fWorldPos[Y] == pActorT->fLastHeightCheckWorldPos[Y] &&
	   pActorT->fWorldPos[Z] == pActorT->fLastHeightCheckWorldPos[Z]))
		return;

	// Update the last check pos: (we only have to check if the position has changed)
	pActorT->fLastHeightCheckWorldPos[X] = pActorT->fWorldPos[X];
	pActorT->fLastHeightCheckWorldPos[Y] = pActorT->fWorldPos[Y];

	// Ray direction for the 'normal' test points:
	fRayDirection[X] = 0.0f;
	fRayDirection[Y] = 0.0f;
	fRayDirection[Z] = 1.0f;

	fPoint[X] = fPoint[Y] = fPoint[Z] = 0.0f;

	// Get the height of the center:
	pLevel->ComputeHeight(pActorT->fWorldPos[X]+0.5f, pActorT->fWorldPos[Y]+0.5f, fRayDirection, &fPoint, FACE_FLOOR, fSize);
	if(pActorT->byAction != ACTION_JUMP)
	{
		if(!pActorT->fVelocity[Z])
			pActorT->fWorldPos[Z] = fPoint[Z];
		else
		{
			if(pActorT->fWorldPos[Z] >= fPoint[Z] && !pActorT->bGoingDeath)
			{
				pActorT->fWorldPos[Z] = fPoint[Z];
				pActorT->fVelocity[Z] = 0.0f;
			}
		}
	}

	// The four points around the floor:
	pLevel->ComputeHeight(pActorT->fWorldPos[X]+0.5f-fSize, pActorT->fWorldPos[Y]+0.5f-fSize, fRayDirection, &fPoint, FACE_FLOOR, fSize);
	if(pActorT->fWorldPos[Z] > fPoint[Z])
	{
		pActorT->fWorldPos[Z] = fPoint[Z];	
		pActorT->fVelocity[Z] = 0.0f;
	}
	pLevel->ComputeHeight(pActorT->fWorldPos[X]+0.5f+fSize, pActorT->fWorldPos[Y]+0.5f-fSize, fRayDirection, &fPoint, FACE_FLOOR, fSize);
	if(pActorT->fWorldPos[Z] > fPoint[Z])
	{
		pActorT->fWorldPos[Z] = fPoint[Z];
		pActorT->fVelocity[Z] = 0.0f;
	}
	pLevel->ComputeHeight(pActorT->fWorldPos[X]+0.5f+fSize, pActorT->fWorldPos[Y]+0.5f+fSize, fRayDirection, &fPoint, FACE_FLOOR, fSize);
	if(pActorT->fWorldPos[Z] > fPoint[Z])
	{
		pActorT->fWorldPos[Z] = fPoint[Z];
		pActorT->fVelocity[Z] = 0.0f;
	}
	pLevel->ComputeHeight(pActorT->fWorldPos[X]+0.5f-fSize, pActorT->fWorldPos[Y]+0.5f+fSize, fRayDirection, &fPoint, FACE_FLOOR, fSize);
	if(pActorT->fWorldPos[Z] > fPoint[Z])
	{
		pActorT->fWorldPos[Z] = fPoint[Z];
		pActorT->fVelocity[Z] = 0.0f;
	}


	// Because we only checked the bounding points it's possible that a terrain point is inside the box,
	// and then the box is inside a hill... now we have to check if a terrain point is inside the box if
	// yes then check it's height:

	// Compute the current field the given point is on:
	COMPUTE_FIELD_POS(pActorT->fWorldPos[X]+0.5f, pActorT->fWorldPos[Y]+0.5f, iXFieldPos, iYFieldPos);

	// Check the field and the fields around:
	for(iYPos = iYFieldPos-1; iYPos < iYFieldPos+1; iYPos++)
	{
		// Check if this coordinate is a correct one:
		if(iYPos < 0 || iYPos > pLevel->iHeight-2)
			continue; // No correct field!

		for(iXPos = iXFieldPos-1; iXPos < iXFieldPos+1; iXPos++)
		{
			// Check if this coordinate is a correct one:
			if(iXPos < 0 || iXPos > pLevel->iWidth-2)
				continue; // No correct field!

			// Get a pointer to this field:
			GET_FIELD_ID(iXFieldPos, iYFieldPos, iFieldID);
			pFieldT = &pLevel->pField[iFieldID];

			// Check if one of the points is in the bounding box:
			for(i = 0; i < 4; i++)
			{
				if(pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][i]][X] > pActorT->fWorldPos[X]+0.5-fSize-0.1f &&
				   pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][i]][Y] > pActorT->fWorldPos[Y]+0.5-fSize-0.1f &&
				   pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][i]][X] < pActorT->fWorldPos[X]+0.5+fSize+0.1f &&
				   pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][i]][Y] < pActorT->fWorldPos[Y]+0.5+fSize+0.1f)
				{ // Check the height;
					if(pActorT->fWorldPos[Z] > pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][i]][Z])
					{
						pActorT->fWorldPos[Z] = pLevel->fPoint[pFieldT->iFace[FACE_FLOOR][i]][Z];
						pActorT->fVelocity[Z] = 0.0f;
					}
				}
			}
		}
	}
} // end ComputeActorHeight()

void SetActorsLights(void)
{ // begin SetActorsLights()
	GLfloat afLightData[4]  = {0.0f, 0.0f, 0.0f, 0.0f};
	ACTOR *pActorT;
	short i, i2;
	float fScale;

	if(_ASConfig->byLight)
	{ // Setup the players 'aura':
		afLightData[0] = pPlayer->fWorldPos[X]+0.5f;
		afLightData[1] = pPlayer->fWorldPos[Y]+0.5f;
		afLightData[2] = pPlayer->fWorldPos[Z]-1.5f;
		afLightData[3] = 1.0f;
		glLightfv(GL_LIGHT2, GL_POSITION, afLightData);
		afLightData[0] = 1.0f;
		afLightData[1] = 1.0f;
		afLightData[2] = 1.0f;
		afLightData[3] = 1.0f;
		glLightfv(GL_LIGHT2, GL_DIFFUSE, afLightData);
		glEnable(GL_LIGHT2);
	}
	for(i = 0, i2 = 0; i < MAX_ACTORS; i++)
	{
		pActorT = &Actor[i];
		if(!pActorT->bActive)
			continue;
		if(pActorT->byType == ACTOR_PLAYER_SHOT)
		{ // Setup the shot light:
			fScale = pActorT->fSize;
			afLightData[0] = pActorT->fWorldPos[X]+0.5f;
			afLightData[1] = pActorT->fWorldPos[Y]+0.5f;
			afLightData[2] = pActorT->fWorldPos[Z]-0.5f;
			afLightData[3] = 1.0f;
			glLightfv(GL_LIGHT3+i2, GL_POSITION, afLightData);
			afLightData[0] = 1.0f*fScale;
			afLightData[1] = 0.3f*fScale;
			afLightData[2] = 0.3f*fScale;
			afLightData[3] = 1.0f;
			glLightfv(GL_LIGHT3+i2, GL_DIFFUSE, afLightData);
			glEnable(GL_LIGHT3+i2);
			i2++;
		}
		if(pActorT->bGoingDeath)
		{ // Setup the death light:
			fScale = pActorT->fSize;
			afLightData[0] = pActorT->fWorldPos[X]+0.5f;
			afLightData[1] = pActorT->fWorldPos[Y]+0.5f;
			afLightData[2] = pActorT->fWorldPos[Z]-0.5f;
			afLightData[3] = 1.0f;
			glLightfv(GL_LIGHT3+i2, GL_POSITION, afLightData);
			afLightData[0] = pActorT->fColor[0]*fScale;
			afLightData[1] = pActorT->fColor[1]*fScale;
			afLightData[2] = pActorT->fColor[2]*fScale;
			afLightData[3] = 1.0f;
			glLightfv(GL_LIGHT3+i2, GL_DIFFUSE, afLightData);
			glEnable(GL_LIGHT3+i2);
			i2++;
		}
	}
	if(OktaActor.bActive)
	{
		afLightData[0] = OktaActor.fWorldPos[X]+0.5f;
		afLightData[1] = OktaActor.fWorldPos[Y]+0.5f;
		afLightData[2] = OktaActor.fWorldPos[Z];
		afLightData[3] = 1.0f;
		glLightfv(GL_LIGHT3+i2, GL_POSITION, afLightData);
		afLightData[0] = 1.0f;
		afLightData[1] = 0.1f;
		afLightData[2] = 0.1f;
		afLightData[3] = 1.0f;
		glLightfv(GL_LIGHT3+i2, GL_DIFFUSE, afLightData);
		glEnable(GL_LIGHT3+i2);
		i2++;
	}
	if(PlayerInfo.bShield)
	{
		afLightData[0] = pPlayer->fWorldPos[X]+0.5f;
		afLightData[1] = pPlayer->fWorldPos[Y]+0.5f;
		afLightData[2] = pPlayer->fWorldPos[Z]-0.5f;
		afLightData[3] = 1.0f;
		glLightfv(GL_LIGHT3+i2, GL_POSITION, afLightData);
		afLightData[0] = 0.4f;
		afLightData[1] = 1.0f;
		afLightData[2] = 0.4f;
		afLightData[3] = 1.0f;
		glLightfv(GL_LIGHT3+i2, GL_DIFFUSE, afLightData);
		glEnable(GL_LIGHT3+i2);
		i2++;
	}
} // end SetActorsLights()

void MoveActor(ACTOR *pActorT, short iSpeed)
{ // begin MoveActor()
	// Should we move?
	if(!pActorT->bMove)
		return;
	char byTempDirection = -1;
	short iBackupField;
	BOOL bJumpEnd = FALSE;
	SURFACE *pSurfaceT;

	// Yes we should:
	// Check is we pull something:
	if(pActorT->byAction == ACTION_PULL_RIGHT || pActorT->byAction2 == ACTION_PULL_RIGHT)
	{
		byTempDirection = pActorT->byDirection;
		pActorT->byDirection = RIGHT;
	}
	else
	if(pActorT->byAction == ACTION_PULL_DOWN || pActorT->byAction2 == ACTION_PULL_DOWN)
	{
		byTempDirection = pActorT->byDirection;
		pActorT->byDirection = DOWN;
	}
	else
	if(pActorT->byAction == ACTION_PULL_LEFT || pActorT->byAction2 == ACTION_PULL_LEFT)
	{
		byTempDirection = pActorT->byDirection;
		pActorT->byDirection = LEFT;
	}
	else
	if(pActorT->byAction == ACTION_PULL_UP || pActorT->byAction2 == ACTION_PULL_UP)
	{
		byTempDirection = pActorT->byDirection;
		pActorT->byDirection = UP;
	}
	// Move now:
	switch(pActorT->byDirection)
	{
		case RIGHT:
			pActorT->fFieldPos[X] += (float) g_lDeltatime/pActorT->fVelocity[0];
			if(pActorT->fFieldPos[X] >= pLevel->fFieldWidth)
			{
				pActorT->fFieldPos[X] = 0.0f;
				pActorT->iFieldPos[X]++;
				goto MoveEnd;
			}
		break;

		case DOWN:
			pActorT->fFieldPos[Y] += (float) g_lDeltatime/pActorT->fVelocity[0];
			if(pActorT->fFieldPos[Y] >= pLevel->fFieldHeight)
			{
				pActorT->fFieldPos[Y] = 0.0f;
				pActorT->iFieldPos[Y]++;
				goto MoveEnd;
			}
		break;

		case LEFT:
			pActorT->fFieldPos[X] -= (float) g_lDeltatime/pActorT->fVelocity[0];
			if(pActorT->fFieldPos[X] <= -pLevel->fFieldWidth)
			{
				pActorT->fFieldPos[X] = 0.0f;
				pActorT->iFieldPos[X]--;
				goto MoveEnd;
			}
		break;

		case UP:
			pActorT->fFieldPos[Y] -= (float) g_lDeltatime/pActorT->fVelocity[0];
			if(pActorT->fFieldPos[Y] <= -pLevel->fFieldHeight)
			{
				pActorT->fFieldPos[Y] = 0.0f;
				pActorT->iFieldPos[Y]--;
				goto MoveEnd;
			}
		break;
	}
	if(byTempDirection != -1)
		pActorT->byDirection = byTempDirection;
	return;

MoveEnd:

	if(byTempDirection != -1)
		pActorT->byDirection = byTempDirection;
	if(pActorT->byAction == ACTION_JUMP)
	{ // The actor jumps:
		if(pActorT->bThrow)
		{ // We are on the overjumped field:
			pActorT->bThrow = FALSE;
			if(!CheckPlayerPushBox(pActorT->byDirection, FALSE))
			{ // The actor jumps againt a wall:
				if(!pLevel->pField[pActorT->iFieldID].bActive)
				{ // The actor falls into a gap:
					pActorT->fPower = 0.0f;
				}
				pActorT->byAction = -1;
				pActorT->iTempFieldID = -1;
			}
		}
		else
		{
			pActorT->byAction = -1;
			bJumpEnd = TRUE;
			pActorT->fVelocity[Z] = 0.005f;
		}
	}
	if(pActorT->byAction != ACTION_JUMP)
	{
		pActorT->bMove = FALSE;
		if(pActorT->byAction == ACTION_JUMP)
			pActorT->byAction = -1;
	}
	// Remove the actor from the old field:
	if(pActorT->byType == ACTOR_BOX_NORMAL ||
	   pActorT->byType == ACTOR_BOX_RED ||
	   pActorT->byType == ACTOR_BOX_GREEN ||
	   pActorT->byType == ACTOR_BOX_BLUE)
		pLevel->pField[pActorT->iFieldID].bWall = FALSE;
	pLevel->pField[pActorT->iFieldID].pActor = NULL;
	//
	iBackupField = pActorT->iFieldID;
	GET_FIELD_ID(pActorT->iFieldPos[X], pActorT->iFieldPos[Y], pActorT->iFieldID)
	if(pActorT->byType == ACTOR_PLAYER && !PlayerInfo.bGhost)
	{ // Check if the surface of one field should be changed:
		// Check the last field:
		pSurfaceT = &pLevel->pSurface[pLevel->pField[iBackupField].iSurface[FACE_FLOOR]];
		if(pSurfaceT->bChange && pSurfaceT->bChangeState && pActorT->iTempFieldID != iBackupField)
		{ // Yes, we have to change the surface:
			if(pSurfaceT->bChangeDestroy)
			{ // Destroy the field:
				pLevel->pField[iBackupField].bActive = FALSE;
			}
			else
			{
				pLevel->pField[iBackupField].iSurface[FACE_FLOOR] = pSurfaceT->iChangeSurface;
				pLevel->pField[iBackupField].pSurface[FACE_FLOOR] = &pLevel->pSurface[pSurfaceT->iChangeSurface];
			}
		}
		// Check the new field:
		pSurfaceT = &pLevel->pSurface[pLevel->pField[pActorT->iFieldID].iSurface[FACE_FLOOR]];
		if(pSurfaceT->bChange && !pSurfaceT->bChangeState && pActorT->iTempFieldID != pActorT->iFieldID)
		{ // Yes, we have to change the surface:
			if(pSurfaceT->bChangeDestroy)
			{ // Destroy the field:
				pLevel->pField[pActorT->iFieldID].bActive = FALSE;
			}
			else
			{
				pLevel->pField[pActorT->iFieldID].iSurface[FACE_FLOOR] = pSurfaceT->iChangeSurface;
				pLevel->pField[pActorT->iFieldID].pSurface[FACE_FLOOR] = &pLevel->pSurface[pSurfaceT->iChangeSurface];
			}
		}
	}
	if(bJumpEnd)
		pActorT->iTempFieldID = -1;
	CheckActorField(pActorT);
	UpdateAllActorFields();
} // end MoveActor()

void UpdateAllActorFields(void)
{ // begin UpdateAllActorFields()
	FIELD *pFieldT;
	ACTOR *pActorT;
	short i, i2;
	
	// Clear all actors from the fields:
	for(i = 0; i < pLevel->iFields; i++)
	{
		pFieldT = &pLevel->pField[i];
		if(pFieldT->pActor)
		{
			pFieldT->bWall = FALSE;
			if(pFieldT->pActor->bDocked)
				DisableNoneFreeBox(pFieldT->pActor);
		}
		if(pFieldT->pBridgeActor)
		{
			pFieldT->bActive = FALSE;
			DisableNoneFreeBox(pFieldT->pBridgeActor);
			pFieldT->pBridgeActor->bBridge = FALSE;
		}
		pFieldT->pBridgeActor = NULL;
		pFieldT->pActor = NULL;
		pFieldT->pObject = NULL;
	}

	// Set all actors to the fields:
	for(i = 0; i < MAX_ACTORS; i++)
	{
		pActorT = &Actor[i];
		if(!pActorT->bActive)
			continue;
		pFieldT = &pLevel->pField[pActorT->iFieldID];
		switch(pActorT->byType)
		{
			case ACTOR_BOX_NORMAL:
			case ACTOR_BOX_RED:
			case ACTOR_BOX_GREEN:
			case ACTOR_BOX_BLUE:
				// Check if another box is already in this hole:
				for(i2 = 0; i2 < MAX_ACTORS; i2++)
				{
					if(i2 == i || !Actor[i2].bActive)
						continue;
					if(Actor[i2].iFieldID == pFieldT->iID &&
					   Actor[i2].fFieldPos[Z] != 0.0f)
						goto Next; // There is already a bridge!
				}
				if(!pFieldT->bActive)
				{ // The box falls into a hole:
					pFieldT->bActive = TRUE;
					pFieldT->pBridgeActor = pActorT;
					pFieldT->bWall = TRUE;
					pActorT->bBridge = TRUE;
					pActorT->bBridgeMovement = TRUE;
					pActorT->fFieldPos[Z] = 1.0f;
					SetNoneFreeBox(pActorT);
					pActorT->bThrow = FALSE;
				}
				else
				{
			Next:
					if(pActorT->bDocked)
						SetNoneFreeBox(pActorT);
					if(pActorT->fFieldPos[Z] != 0.0f && !pActorT->bDocked)
						pActorT->bActive = FALSE;
					else
					{
						pFieldT->bWall = TRUE;
						pFieldT->pActor = pActorT;
					}
				}
			break;

			case ACTOR_HEALTH_OBJ:
			case ACTOR_LIVE_OBJ:
			case ACTOR_PULL_OBJ:
			case ACTOR_THROW_OBJ:
			case ACTOR_FORCE_OBJ:
			case ACTOR_WEAPON_OBJ:
			case ACTOR_POINT_OBJ:
			case ACTOR_GHOST_OBJ:
			case ACTOR_TIME_OBJ:
			case ACTOR_STEP_OBJ:
			case ACTOR_SPEED_OBJ:
			case ACTOR_WING_OBJ:
			case ACTOR_SHIELD_OBJ:
			case ACTOR_JUMP_OBJ:
			case ACTOR_AIR_OBJ:
				if(pFieldT->pObject)
					pActorT->bActive = FALSE;
				else
					pFieldT->pObject = pActorT;
			break;
		}
	}

	if(!pPlayer->bActive)
		return;
	// Set the player into the level:
	if(!pLevel->pField[pPlayer->iFieldID].bActive && !PlayerInfo.bWing && pPlayer->byAction != ACTION_JUMP)
	{ // The player falls in a hole:
		pPlayer->fPower = 0.0f;
		pPlayer->fVelocity[Z] = 0.005f;
	}
	else
	{
		if(!PlayerInfo.bGhost)
			pLevel->pField[pPlayer->iFieldID].pActor = pPlayer;
	}
} // end UpdateAllActorFields()

void CheckActorField(ACTOR *pActorT)
{ // begin CheckActorField()
	FIELD *pFieldT;
	SURFACE *pSurfaceT;
	short i;
	
	if(!pActorT->bActive)
		return;
	if(pActorT->byType == ACTOR_BOX_NORMAL ||
	   pActorT->byType == ACTOR_BOX_RED ||
	   pActorT->byType == ACTOR_BOX_GREEN ||
	   pActorT->byType == ACTOR_BOX_BLUE)
	{
		pFieldT = &pLevel->pField[pActorT->iFieldID];
		pFieldT->pActor = pActorT;
		pSurfaceT = &pLevel->pSurface[pFieldT->iSurface[FACE_FLOOR]];
		if(pSurfaceT->bColorPainter)
		{ // Change the color of this box:
			DeleteActorType(pActorT);
			switch(pSurfaceT->byColorPainterType)
			{
				case 0: // Change the color to normal
					pActorT->byType = ACTOR_BOX_NORMAL;
					pLevel->iNormalBoxes++;
				break;

				case 1: // Change the color to red
					pActorT->byType = ACTOR_BOX_RED;
					pLevel->iRedBoxes++;
				break;

				case 2: // Change the color to green
					pActorT->byType = ACTOR_BOX_GREEN;
					pLevel->iGreenBoxes++;
				break;

				case 3: // Change the color to blue
					pActorT->byType = ACTOR_BOX_BLUE;
					pLevel->iBlueBoxes++;
				break;
			}
		}
		// Check if the box is now in a anchor:
		if(pSurfaceT->bAnchor)
		{
			switch(pSurfaceT->byAnchorType)
			{
				case 0: // A anchor for all boxes
					pActorT->bDocked = TRUE;
					iUsedForAllAnchors++;
					goto Docked;

				case 1: // A anchor for normal boxes
					if(pActorT->byType != ACTOR_BOX_NORMAL)
						break;
					iUsedNormalAnchors++;
					goto Docked;

				case 2: // A anchor for red boxes
					if(pActorT->byType != ACTOR_BOX_RED)
						break;
					iUsedRedAnchors++;
					goto Docked;

				case 3: // A anchor for green boxes
					if(pActorT->byType != ACTOR_BOX_GREEN)
						break;
					iUsedGreenAnchors++;
					goto Docked;

				case 4: // A anchor for blue boxes
					if(pActorT->byType != ACTOR_BOX_BLUE)
						break;
					iUsedBlueAnchors++;
				Docked:
					pActorT->bDocked = TRUE;
					for(i = 0; i < 3; i++)
					{
						pActorT->fPosTemp[i] = 0.0f;
						pActorT->fPosTempTo[i] = 0.0f;
						pActorT->fPosTempVelocity[i] = 0.0f;

					}
					SetNoneFreeBox(pActorT);
				break;
			}
		}
		else
			pActorT->bDocked = FALSE;
	}
} // end CheckActorField()

void DrawEffects(void)
{ // begin DrawEffects()
	ACTOR *pActorT;
	short i;
	float fScale;

	glEnable(GL_BLEND);
	glDisable(GL_FOG);
	glDisable(GL_CULL_FACE);
	glDepthMask(FALSE);

	// Effects are drawn over the complete scene:
	for(i = 0; i < MAX_ACTORS; i++)
	{
		pActorT = &Actor[i];
		if(!pActorT->bActive || !pActorT->bGoingDeath)
			continue;
		// Draw the dead wave:
		glPushMatrix();
		glTranslatef(pActorT->fWorldPos[X]+0.5f, pActorT->fWorldPos[Y]+0.5f, pActorT->fWorldPos[Z]-0.5f);
		glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(pActorT->fRot[X], 0.0f, 1.0f, 0.0f);
		glRotatef(pActorT->fRot[Y], 0.0f, 1.0f, 0.0f);
		glRotatef(pActorT->fRot[Z], 0.0f, 1.0f, 0.0f);
		if(pActorT->byType == ACTOR_BOX_NORMAL ||
		   pActorT->byType == ACTOR_BOX_RED ||
		   pActorT->byType == ACTOR_BOX_GREEN ||
		   pActorT->byType == ACTOR_BOX_BLUE)
		{
			glScalef(pActorT->fSize, pActorT->fSize, pActorT->fSize);
			glColor4f(pActorT->fColor[0]+0.1f, pActorT->fColor[1]+0.1f, pActorT->fColor[2]+0.1f, pActorT->fSize);
		}
		else
		{
			glScalef(pActorT->fSize*0.2f, pActorT->fSize*0.2f, pActorT->fSize*0.2f);
			glColor4f(1.0f, 1.0f, 1.0f, pActorT->fSize);
		}
		fScale = (1.0f-pActorT->fSize)/0.3f*10.0f;
		glScalef(fScale, fScale, fScale);
		glCallList(iWaveList);
		glRotatef(45.0f, 1.0f, 0.0f, 0.0f);
		glCallList(iWaveList);
		glRotatef(45.0f, 1.0f, 0.0f, 0.0f);
		glCallList(iWaveList);
		glRotatef(45.0f, 1.0f, 0.0f, 0.0f);
		glCallList(iWaveList);
		glPopMatrix();
	}
	
	// Draw the players shield:
	if(PlayerInfo.bShield && pPlayer->bActive)
	{
		glColor4f(0.5f, 1.0f, 0.5f, 0.99f);
		glPushMatrix();
		glTranslatef(pPlayer->fWorldPos[X]+0.5f, pPlayer->fWorldPos[Y]+0.5f, pPlayer->fWorldPos[Z]-0.5f);
		glRotatef(PlayerInfo.fShieldRot[X], 1.0f, 0.0f, 0.0f);
		glRotatef(PlayerInfo.fShieldRot[Y], 0.0f, 1.0f, 0.0f);
		glRotatef(PlayerInfo.fShieldRot[Z], 0.0f, 0.0f, 1.0f);
		glCallList(iShieldList);
		glRotatef(45.0f, 1.0f, 0.0f, 0.0f);
		glCallList(iShieldList);
		glRotatef(45.0f, 1.0f, 0.0f, 0.0f);
		glCallList(iShieldList);
		glRotatef(45.0f, 1.0f, 0.0f, 0.0f);
		glCallList(iShieldList);
		glPopMatrix();
	}

	glDepthMask(TRUE);
	glDisable(GL_BLEND);
	glEnable(GL_CULL_FACE);
	if(pLevel->bFog)
		glEnable(GL_FOG);
} // end DrawEffects()

void DrawActors(void)
{ // begin DrawActors()
	float fScale, fSize, fPos;
	FLOAT3 fRayDirection, fPoint;
	short i, i2;
	GLuint iLastTexture = 0;
	ACTOR *pActorT;
	SURFACE *pSurfaceT;
	TEXTURE_POS *pTexturePosT;

	glEnable(GL_TEXTURE_2D);
	// Draw all actors:
	for(i = 0; i < MAX_ACTORS; i++)
	{
		pActorT = &Actor[i];
		if(i == 27)
			fScale = 0.0f;
		switch(pActorT->byType)
		{
			case ACTOR_BOX_NORMAL:
			case ACTOR_BOX_RED:
			case ACTOR_BOX_GREEN:
			case ACTOR_BOX_BLUE:
				if(!pActorT->bActive)
					break;;
				if(!pLevel->pField[pActorT->iFieldID].bOnScreen)
				{ // The box isn't on screen;
					iCulledObjects++;
					break;
				}
				fSize = pActorT->fSize;
				fPos = -(fSize-1.0f)/2;
				glPushMatrix();
				// Calculate the world position of the box:
				pActorT->fWorldPos[X] = pActorT->iFieldPos[X]*pLevel->fFieldWidth+pActorT->fFieldPos[X]+pActorT->fPosTemp[X];
				pActorT->fWorldPos[Y] = pActorT->iFieldPos[Y]*pLevel->fFieldHeight+pActorT->fFieldPos[Y]+pActorT->fPosTemp[Y];
				if(!pActorT->bBridge)
					ComputeActorHeight(pActorT, 0.5f);
				//
				if(pActorT->bGoingDeath)
					glTranslatef(pActorT->fWorldPos[X]+0.5f-(pActorT->fSize/2), pActorT->fWorldPos[Y]+0.5f-(pActorT->fSize/2), pActorT->fWorldPos[Z]-(0.5f-(pActorT->fSize/2)));
				else
				{
					if(pActorT->bDocked)
						glTranslatef(pActorT->fWorldPos[X]+fPos, pActorT->fWorldPos[Y]+fPos, pActorT->fWorldPos[Z]-fPos+pActorT->fPosTemp[Z]);
					else
						glTranslatef(pActorT->fWorldPos[X]+fPos, pActorT->fWorldPos[Y]+fPos, pActorT->fWorldPos[Z]);
				}
				glColor3f(pActorT->fColor[X]-0.3f+pActorT->fPower, pActorT->fColor[Y]-0.3f+pActorT->fPower, pActorT->fColor[Z]-0.3f+pActorT->fPower);

				// Check if all animation steps are vaild:
				for(i2 = 0; i2 < 6; i2++)
				{
					pSurfaceT = &pLevel->pSurface[pLevel->iBoxSurface[i2][pActorT->bHeavy]];
					if(pActorT->iMultiAniStep[i2] >= pSurfaceT->iAniSteps)
						pActorT->iMultiAniStep[i2] = 0;
				}

				glScalef(fSize, fSize, fSize);

				// Floor face
				pSurfaceT = &pLevel->pSurface[pLevel->iBoxSurface[0][pActorT->bHeavy]];
				pTexturePosT = &pSurfaceT->pTexturePos[pActorT->iMultiAniStep[0]];
				glBindTexture(GL_TEXTURE_2D, pSurfaceT->pTexture[pActorT->iMultiAniStep[0]]->iOpenGLID);
				glBegin(GL_QUADS);
					glNormal3f(0.0f, 0.0f, 1.0f);
					glTexCoord2fv(pTexturePosT->fPos[(0+pLevel->byBoxSurfaceRot[i2][0]) % 4]); glVertex3f(1.0f, 0.0f, 0.0f);
					glTexCoord2fv(pTexturePosT->fPos[(1+pLevel->byBoxSurfaceRot[i2][0]) % 4]); glVertex3f(1.0f, 1.0f, 0.0f);
					glTexCoord2fv(pTexturePosT->fPos[(2+pLevel->byBoxSurfaceRot[i2][0]) % 4]); glVertex3f(0.0f, 1.0f, 0.0f);
					glTexCoord2fv(pTexturePosT->fPos[(3+pLevel->byBoxSurfaceRot[i2][0]) % 4]); glVertex3f(0.0f, 0.0f, 0.0f);
				glEnd();

				// Sky face
				pSurfaceT = &pLevel->pSurface[pLevel->iBoxSurface[1][pActorT->bHeavy]];
				pTexturePosT = &pSurfaceT->pTexturePos[pActorT->iMultiAniStep[1]];
				glBindTexture(GL_TEXTURE_2D, pSurfaceT->pTexture[pActorT->iMultiAniStep[1]]->iOpenGLID);
				glBegin(GL_QUADS);
					glNormal3f(0.0f, 0.0f, -1.0f);
					glTexCoord2fv(pTexturePosT->fPos[(0+pLevel->byBoxSurfaceRot[i2][1]) % 4]); glVertex3f(0.0f, 1.0f, -1.0f);
					glTexCoord2fv(pTexturePosT->fPos[(1+pLevel->byBoxSurfaceRot[i2][1]) % 4]); glVertex3f(1.0f, 1.0f, -1.0f);
					glTexCoord2fv(pTexturePosT->fPos[(2+pLevel->byBoxSurfaceRot[i2][1]) % 4]); glVertex3f(1.0f, 0.0f, -1.0f);
					glTexCoord2fv(pTexturePosT->fPos[(3+pLevel->byBoxSurfaceRot[i2][1]) % 4]); glVertex3f(0.0f, 0.0f, -1.0f);
				glEnd();
					
				// Back face
				pSurfaceT = &pLevel->pSurface[pLevel->iBoxSurface[2][pActorT->bHeavy]];
				pTexturePosT = &pSurfaceT->pTexturePos[pActorT->iMultiAniStep[2]];
				glBindTexture(GL_TEXTURE_2D, pSurfaceT->pTexture[pActorT->iMultiAniStep[2]]->iOpenGLID);
				glBegin(GL_QUADS);
					glNormal3f(0.0f, 1.0f, 0.0f);
					glTexCoord2fv(pTexturePosT->fPos[(0+pLevel->byBoxSurfaceRot[i2][2]) % 4]); glVertex3f(1.0f, 1.0f, 0.0f);
					glTexCoord2fv(pTexturePosT->fPos[(1+pLevel->byBoxSurfaceRot[i2][2]) % 4]); glVertex3f(1.0f, 1.0f, -1.0f);
					glTexCoord2fv(pTexturePosT->fPos[(2+pLevel->byBoxSurfaceRot[i2][2]) % 4]); glVertex3f(0.0f, 1.0f, -1.0f);
					glTexCoord2fv(pTexturePosT->fPos[(3+pLevel->byBoxSurfaceRot[i2][2]) % 4]); glVertex3f(0.0f, 1.0f, 0.0f);
				glEnd();

				// Bottom Face
				pSurfaceT = &pLevel->pSurface[pLevel->iBoxSurface[3][pActorT->bHeavy]];
				pTexturePosT = &pSurfaceT->pTexturePos[pActorT->iMultiAniStep[3]];
				glBindTexture(GL_TEXTURE_2D, pSurfaceT->pTexture[pActorT->iMultiAniStep[3]]->iOpenGLID);
				glBegin(GL_QUADS);
					glNormal3f(0.0f, -1.0f, 0.0f);
					glTexCoord2fv(pTexturePosT->fPos[(0+pLevel->byBoxSurfaceRot[i2][3]) % 4]); glVertex3f(0.0f, 0.0f, -1.0f);
					glTexCoord2fv(pTexturePosT->fPos[(1+pLevel->byBoxSurfaceRot[i2][3]) % 4]); glVertex3f(1.0f, 0.0f, -1.0f);
					glTexCoord2fv(pTexturePosT->fPos[(2+pLevel->byBoxSurfaceRot[i2][3]) % 4]); glVertex3f(1.0f, 0.0f, 0.0f);
					glTexCoord2fv(pTexturePosT->fPos[(3+pLevel->byBoxSurfaceRot[i2][3]) % 4]); glVertex3f(0.0f, 0.0f, 0.0f);
				glEnd();
					
				// Right face
				pSurfaceT = &pLevel->pSurface[pLevel->iBoxSurface[4][pActorT->bHeavy]];
				pTexturePosT = &pSurfaceT->pTexturePos[pActorT->iMultiAniStep[4]];
				glBindTexture(GL_TEXTURE_2D, pSurfaceT->pTexture[pActorT->iMultiAniStep[4]]->iOpenGLID);
				glBegin(GL_QUADS);
					glNormal3f(1.0f, 0.0f, 0.0f);
					glTexCoord2fv(pTexturePosT->fPos[(0+pLevel->byBoxSurfaceRot[i2][4]) % 4]); glVertex3f(1.0f, 0.0f, -1.0f);
					glTexCoord2fv(pTexturePosT->fPos[(1+pLevel->byBoxSurfaceRot[i2][4]) % 4]); glVertex3f(1.0f, 1.0f, -1.0f);
					glTexCoord2fv(pTexturePosT->fPos[(2+pLevel->byBoxSurfaceRot[i2][4]) % 4]); glVertex3f(1.0f, 1.0f, 0.0f);
					glTexCoord2fv(pTexturePosT->fPos[(3+pLevel->byBoxSurfaceRot[i2][4]) % 4]); glVertex3f(1.0f, 0.0f, 0.0f);
				glEnd();

				// Left Face
				pSurfaceT = &pLevel->pSurface[pLevel->iBoxSurface[5][pActorT->bHeavy]];
				pTexturePosT = &pSurfaceT->pTexturePos[pActorT->iMultiAniStep[5]];
				glBindTexture(GL_TEXTURE_2D, pSurfaceT->pTexture[pActorT->iMultiAniStep[5]]->iOpenGLID);
				glBegin(GL_QUADS);
					glNormal3f(-1.0f, 0.0f, 0.0f);
					glTexCoord2fv(pTexturePosT->fPos[(0+pLevel->byBoxSurfaceRot[i2][5]) % 4]); glVertex3f(0.0f, 1.0f, 0.0f);
					glTexCoord2fv(pTexturePosT->fPos[(1+pLevel->byBoxSurfaceRot[i2][5]) % 4]); glVertex3f(0.0f, 1.0f, -1.0f);
					glTexCoord2fv(pTexturePosT->fPos[(2+pLevel->byBoxSurfaceRot[i2][5]) % 4]); glVertex3f(0.0f, 0.0f, -1.0f);
					glTexCoord2fv(pTexturePosT->fPos[(3+pLevel->byBoxSurfaceRot[i2][5]) % 4]); glVertex3f(0.0f, 0.0f, 0.0f);
				glEnd();
				
				iLastTexture = -1;
				glPopMatrix();
			break;
			
			case ACTOR_HEALTH_OBJ:
			case ACTOR_LIVE_OBJ:
			case ACTOR_PULL_OBJ:
			case ACTOR_THROW_OBJ:
			case ACTOR_FORCE_OBJ:
			case ACTOR_WEAPON_OBJ:
			case ACTOR_POINT_OBJ:
			case ACTOR_GHOST_OBJ:
			case ACTOR_PLAYER_SHOT:
			case ACTOR_TIME_OBJ:
			case ACTOR_STEP_OBJ:
			case ACTOR_SPEED_OBJ:
			case ACTOR_WING_OBJ:
			case ACTOR_SHIELD_OBJ:
			case ACTOR_JUMP_OBJ:
			case ACTOR_AIR_OBJ:
				if(!pActorT->bActive)
					break;
				if(pActorT->byType != ACTOR_PLAYER_SHOT)
				{
					if(!pLevel->pField[pActorT->iFieldID].bOnScreen)
					{ // The box isn't on screen;
						iCulledObjects++;
						break;
					}
					if(pLevel->pField[pActorT->iFieldID].pActor &&
					   pLevel->pField[pActorT->iFieldID].pActor->fFieldPos[X] == 0.0f &&
					   pLevel->pField[pActorT->iFieldID].pActor->fFieldPos[Y] == 0.0f &&
					   !pLevel->pField[pActorT->iFieldID].pActor->bGoingDeath &&
					   (pLevel->pField[pActorT->iFieldID].pActor->byType == ACTOR_BOX_NORMAL ||
						pLevel->pField[pActorT->iFieldID].pActor->byType == ACTOR_BOX_RED ||
						pLevel->pField[pActorT->iFieldID].pActor->byType == ACTOR_BOX_GREEN ||
						pLevel->pField[pActorT->iFieldID].pActor->byType == ACTOR_BOX_BLUE))
					{ // A box is over this actor... maybe a secret??
						iCulledObjects++;
						break;
					}
				}
				// Draw the object:
				glPushMatrix();
				if(pActorT->byType != ACTOR_PLAYER_SHOT)
				{
					// Calculate the world position of the object:
					pActorT->fWorldPos[X] = pActorT->iFieldPos[X]*pLevel->fFieldWidth+pActorT->fFieldPos[X]+pActorT->fPosTemp[X];
					pActorT->fWorldPos[Y] = pActorT->iFieldPos[Y]*pLevel->fFieldHeight+pActorT->fFieldPos[Y]+pActorT->fPosTemp[Y];
					fRayDirection[X] = 0.0f;
					fRayDirection[Y] = 0.0f;
					fRayDirection[Z] = 1.0f;
					pLevel->ComputeHeight(pActorT->fWorldPos[X]+0.5f, pActorT->fWorldPos[Y]+0.5f, fRayDirection, &fPoint, FACE_FLOOR, 0.1f);
					pActorT->fWorldPos[Z] = fPoint[Z];
					//
				}
				glTranslatef(pActorT->fWorldPos[X]+0.5f, pActorT->fWorldPos[Y]+0.5f, pActorT->fWorldPos[Z]-0.5f);
				if(pActorT->byType == ACTOR_WEAPON_OBJ)
					glTranslatef(-0.6f, -0.5f, 0.0f);
				glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
				if(pActorT->byType != ACTOR_WEAPON_OBJ && pActorT->byType != ACTOR_PLAYER_SHOT)
					glRotatef(pActorT->fRot[Y], 0.0f, 1.0f, 0.0f);
				glScalef(pActorT->fSize*0.2f, pActorT->fSize*0.2f, pActorT->fSize*0.2f);
				if(iLastTexture != GameTexture[pActorT->iAniStep].iOpenGLID)
				{ // We have to change the texture:
					iLastTexture = GameTexture[pActorT->iAniStep].iOpenGLID;
					glBindTexture(GL_TEXTURE_2D, GameTexture[pActorT->iAniStep].iOpenGLID);
				}
				glColor3f(pActorT->fColor[0], pActorT->fColor[1], pActorT->fColor[2]);
				if(pActorT->fColor[0] == 1.0f && pActorT->fColor[1] == 1.0f && pActorT->fColor[2] == 1.0f)
				{
					switch(pActorT->byType)
					{
						case ACTOR_HEALTH_OBJ:
							glCallList(iHealthObjList);
						break;

						case ACTOR_LIVE_OBJ:
							glCallList(iLiveObjList);
						break;

						case ACTOR_PULL_OBJ:
							glCallList(iPullObjList);
						break;

						case ACTOR_THROW_OBJ:
							glCallList(iThrowObjList);
						break;

						case ACTOR_FORCE_OBJ:
							glCallList(iForceObjList);
						break;

						case ACTOR_WEAPON_OBJ:
							glCullFace(GL_FRONT);
							glColor3f(1.0f, 1.0f, 1.0f);
							glScalef(0.2f, 0.2f, 0.2f);
							glBindTexture(GL_TEXTURE_2D, GameTexture[6].iOpenGLID);
							ASDrawMd2FrameInt(pXeWeaponModel, pActorT->iAniStep, pActorT->iNextAniStep, (float) (g_lNow-pActorT->dwAniTime)/(float) PLAYER_ANIMATION_SPEED);
							glCullFace(GL_BACK);
						break;

						case ACTOR_POINT_OBJ:
							glCallList(iPointObjList);
						break;

						case ACTOR_GHOST_OBJ:
							glCallList(iGhostObjList);
						break;

						case ACTOR_PLAYER_SHOT:
							glScalef(0.2f, 0.2f, 0.2f);
							glCallList(iPlayerShotObjList);
						break;

						case ACTOR_TIME_OBJ:
							glCallList(iTimeObjList);
						break;

						case ACTOR_STEP_OBJ:
							glCallList(iStepsObjList);
						break;

						case ACTOR_SPEED_OBJ:
							glCallList(iSpeedObjList);
						break;

						case ACTOR_WING_OBJ:
							glCallList(iWingObjList);
						break;

						case ACTOR_SHIELD_OBJ:
							glCallList(iShieldObjList);
						break;
						
						case ACTOR_JUMP_OBJ:
							glCallList(iJumpObjList);
						break;

						case ACTOR_AIR_OBJ:
							glCallList(iAirObjList);
						break;
					}
				}
				else
				{
					if(_ASConfig->bUseLevelVertexColor || _ASConfig->bHightRenderQuality)
						glDisableClientState(GL_COLOR_ARRAY);
					glEnable(GL_TEXTURE_GEN_S);
					glEnable(GL_TEXTURE_GEN_T);
					switch(pActorT->byType)
					{
						case ACTOR_HEALTH_OBJ:
							pHealthObject->Draw(TRUE, TRUE, FALSE);
						break;

						case ACTOR_LIVE_OBJ:
							pLiveObject->Draw(TRUE, TRUE, FALSE);
						break;

						case ACTOR_PULL_OBJ:
							pPullObject->Draw(TRUE, TRUE, FALSE);
						break;

						case ACTOR_THROW_OBJ:
							pThrowObject->Draw(TRUE, TRUE, FALSE);
						break;

						case ACTOR_FORCE_OBJ:
							pForceObject->Draw(TRUE, TRUE, FALSE);
						break;

						case ACTOR_WEAPON_OBJ:
							glCullFace(GL_FRONT);
							glScalef(0.2f, 0.2f, 0.2f);
							glBindTexture(GL_TEXTURE_2D, GameTexture[6].iOpenGLID);
							ASDrawMd2FrameInt(pXeWeaponModel, pActorT->iAniStep, pActorT->iNextAniStep, (float) (g_lNow-pActorT->dwAniTime)/(float) PLAYER_ANIMATION_SPEED);
							glCullFace(GL_BACK);
						break;

						case ACTOR_POINT_OBJ:
							pPointObject->Draw(TRUE, TRUE, FALSE);
						break;

						case ACTOR_GHOST_OBJ:
							pGhostObject->Draw(TRUE, TRUE, FALSE);
						break;

						case ACTOR_PLAYER_SHOT:
							pPlayerShot->Draw(TRUE, TRUE, FALSE);
						break;

						case ACTOR_TIME_OBJ:
							pTimeObject->Draw(TRUE, TRUE, FALSE);
						break;

						case ACTOR_STEP_OBJ:
							pStepsObject->Draw(TRUE, TRUE, FALSE);
						break;

						case ACTOR_SPEED_OBJ:
							pSpeedObject->Draw(TRUE, TRUE, FALSE);
						break;

						case ACTOR_WING_OBJ:
							pWingObject->Draw(TRUE, TRUE, FALSE);
						break;

						case ACTOR_SHIELD_OBJ:
							pShieldObject->Draw(TRUE, TRUE, FALSE);
						break;

						case ACTOR_JUMP_OBJ:
							pJumpObject->Draw(TRUE, TRUE, FALSE);
						break;

						case ACTOR_AIR_OBJ:
							pAirObject->Draw(TRUE, TRUE, FALSE);
						break;
					}
					if(_ASConfig->bHightRenderQuality && _ASConfig->bUseLevelVertexColor)  
						glEnableClientState(GL_COLOR_ARRAY);
					glDisable(GL_TEXTURE_GEN_S);
					glDisable(GL_TEXTURE_GEN_T);
				}
				glPopMatrix();
			break;
		}
	}

	// Draw the Okta:
	if(OktaActor.bActive)
	{
		glPushMatrix();
		glCullFace(GL_FRONT);
		glTranslatef(OktaActor.fWorldPos[X]+0.5f, OktaActor.fWorldPos[Y]+0.5f, OktaActor.fWorldPos[Z]-0.6f);
		glColor3f(1.0f, 1.0f, 1.0f);
		glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
		glScalef(0.024f, 0.024f, 0.024f);
		glBindTexture(GL_TEXTURE_2D, GameTexture[10].iOpenGLID);
		ASDrawMd2FrameInt(pOktaModel, OktaActor.iAniStep, OktaActor.iNextAniStep, (float) (g_lNow-OktaActor.dwAniTime)/(float) 150);
		glCullFace(GL_BACK);
		glPopMatrix();
	}
} // end DrawActors()

void CheckActors(BOOL bEditor)
{ // begin CheckActors()
	ACTOR *pActorT;
	FIELD *pFieldT;
	SURFACE *pSurfaceT;
	short i, i2, iX, iY, iXT, iYT;
	float fHeight;
	FLOAT3 fRayDirection, fPoint;

	if(bPause && !bLevelComplete)
		return;
	for(i = 0; i < MAX_ACTORS; i++)
	{
		pActorT = &Actor[i];
		if(pActorT->byType == ACTOR_PLAYER_SHOT)
			i2 = 0;
		if(!pActorT->bActive)
			continue;
		// Setup x/y direction:
		switch(pActorT->byDirection)
		{
			case RIGHT: iX = 1; iY = 0; break;
			case DOWN: iX = 0; iY = 1; break;
			case LEFT: iX = -1; iY = 0; break;
			case UP: iX = 0; iY = -1; break;
		}
		// Check the water:
		if(pActorT->fWorldPos[Z] > pLevel->fWaterActualHeight)
		{
			if(pLevel->bWaterLava)
			{
				if(bEditor)
					pActorT->bGoingDeath = TRUE;
				else
				{
					switch(pActorT->byType)
					{
						case ACTOR_BOX_NORMAL:
						case ACTOR_BOX_RED:
						case ACTOR_BOX_GREEN:
						case ACTOR_BOX_BLUE:				
							KillBox(pActorT);
						break;

						default:
							pActorT->bGoingDeath = TRUE;
						break;
					}
				}
			}

		}

		// Check the actor:
		switch(pActorT->byType)
		{
			case ACTOR_BOX_NORMAL:
			case ACTOR_BOX_RED:
			case ACTOR_BOX_GREEN:
			case ACTOR_BOX_BLUE:				
				// Animate the surfaces of this actor:
				for(i2 = 0; i2 < 6; i2++)
				{
					pSurfaceT = &pLevel->pSurface[pLevel->iBoxSurface[i2][pActorT->bHeavy]];
					if(g_lNow-pActorT->dwMultiAniTime[i2] >= (DWORD) pSurfaceT->pTexturePos[pActorT->iMultiAniStep[i2]].iTimeToNext)
					{ // It's time for a animation frame update:
						pActorT->dwMultiAniTime[i2] = g_lNow;
						pActorT->iMultiAniStep[i2]++;
						if(pActorT->iMultiAniStep[i2] >= pSurfaceT->iAniSteps)
							pActorT->iMultiAniStep[i2] = 0;
					}
				}
				if(pActorT->bGoingDeath)
				{ // Yes: (Killing sequenze)
					pActorT->fSize -= g_lDeltatime/BOX_KILLING_SPEED;
					if(pActorT->fSize < 0.0f)
					{
						pActorT->bActive = FALSE;
						pLevel->pField[pActorT->iFieldID].bWall = FALSE;
						if(pActorT->bBridge)
						{
							pLevel->pField[pActorT->iFieldID].pBridgeActor = NULL;
							pLevel->pField[pActorT->iFieldID].bActive = FALSE;
						}
						else
							pLevel->pField[pActorT->iFieldID].pActor = NULL;
					}
					break;
				}
				if(pActorT->bBridge && pActorT->bBridgeMovement)
				{	
					fHeight = pLevel->fPoint[pLevel->pField[pActorT->iFieldID].iFace[FACE_FLOOR][0]][Z];
					fHeight += pLevel->fPoint[pLevel->pField[pActorT->iFieldID].iFace[FACE_FLOOR][1]][Z];
					fHeight += pLevel->fPoint[pLevel->pField[pActorT->iFieldID].iFace[FACE_FLOOR][2]][Z];
					fHeight += pLevel->fPoint[pLevel->pField[pActorT->iFieldID].iFace[FACE_FLOOR][3]][Z];
					fHeight /= 4.0f;
					if(pActorT->fWorldPos[Z] > fHeight+1.0f)
					{
						pActorT->fWorldPos[Z] -= g_lDeltatime/200.0f;
						if(pActorT->fWorldPos[Z] < fHeight+1.0f)
						{
							pActorT->bBridgeMovement = FALSE;
							pActorT->fWorldPos[Z] = fHeight+1.0f;
						}
						else
							pActorT->bBridgeMovement = TRUE;
					}
					else
					{
						pActorT->fWorldPos[Z] += g_lDeltatime/200.0f;
						if(pActorT->fWorldPos[Z] > fHeight+1.0f)
						{
							pActorT->bBridgeMovement = FALSE;
							pActorT->fWorldPos[Z] = fHeight+1.0f;
						}
						else
							pActorT->bBridgeMovement = TRUE;
					}
					if(pActorT->fWorldPos[Z] == fHeight+1.0f && !pLevel->pField[pActorT->iFieldID].pActor)
						pLevel->pField[pActorT->iFieldID].bWall = FALSE;
				}
				MoveActor(pActorT, (short) pActorT->fVelocity[0]);				
				CheckBoxThrow(pActorT);

				// Check if we should make the 'fly' animation:
				if(pActorT->bDocked)
				{ // Yep:
					for(i2 = 0; i2 < 3; i2++)
					{
						pActorT->fPosTemp[i2] += pActorT->fPosTempVelocity[i2]*g_lDeltatime/1000.0f;
						if(pActorT->fPosTemp[i2] <= pActorT->fPosTempTo[i2]+0.1f &&
						   pActorT->fPosTemp[i2] >= pActorT->fPosTempTo[i2]-0.1f)
						{ // Change the direction:
							pActorT->fPosTempVelocity[i2] /= 1.5f;
							if(!(rand() % 2))
								pActorT->fPosTempTo[i2] = -(float) (rand() % 200)/1000.0f;
							else
								pActorT->fPosTempTo[i2] = (float) (rand() % 200)/1000.0f;
						}
						else
						{ // Increase the velocity:
							if(pActorT->fPosTemp[i2] < pActorT->fPosTempTo[i2])
								pActorT->fPosTempVelocity[i2] += g_lDeltatime/3000.0f;
							else
								pActorT->fPosTempVelocity[i2] -= g_lDeltatime/3000.0f;
						}
					}
					if(pActorT->fSize > BOX_DOCKED_SIZE)
					{
						pActorT->fSize -= g_lDeltatime/2000.0f;
						if(pActorT->fSize < BOX_DOCKED_SIZE)
						{
							pActorT->fSize = BOX_DOCKED_SIZE;
							// Get a new position:
							if(!(rand() % 2))
								pActorT->fPosTempTo[i2] = -(float) (rand() % 200)/1000.0f;
							else
								pActorT->fPosTempTo[i2] = (float) (rand() % 200)/1000.0f;
						}
					}
				}
				else
				{
					for(i2 = 0; i2 < 3; i2++)
					{
						pActorT->fPosTemp[i2] += pActorT->fPosTempVelocity[i2]*g_lDeltatime/1000.0f;
						if(pActorT->fPosTemp[i2] <= pActorT->fPosTempTo[i2]+0.01f &&
						   pActorT->fPosTemp[i2] >= pActorT->fPosTempTo[i2]-0.01f)
						{ // Set all to zero:
							pActorT->fPosTemp[i2] = pActorT->fPosTempTo[i2] = pActorT->fPosTempVelocity[i2] = 0.0f;
						}
						else
						{ // Increase the velocity:
							if(pActorT->fPosTemp[i2] < pActorT->fPosTempTo[i2])
								pActorT->fPosTempVelocity[i2] += g_lDeltatime/5000.0f;
							else
								pActorT->fPosTempVelocity[i2] -= g_lDeltatime/5000.0f;
						}
					}
					if(pActorT->fSize < BOX_NORMAL_SIZE)
					{
						pActorT->fSize += g_lDeltatime/1000.0f;
						if(pActorT->fSize > BOX_NORMAL_SIZE)
							pActorT->fSize = BOX_NORMAL_SIZE;
					}
				}

				switch(pActorT->byType)
				{
					case ACTOR_BOX_NORMAL:
						// Check if we should change the box color:
						for(i2 = 0; i2 < 3; i2++)
							if(pActorT->fColor[i2] < 1.0f)
							{
								pActorT->fColor[i2] += (float) BOX_COLOR_CHANGE_SPEED*g_lDeltatime/10.0f;
								if(pActorT->fColor[i2] > 1.0f)
									pActorT->fColor[i2] = 1.0f;
							}
					break;

					case ACTOR_BOX_RED:
						// Check if we should change the box color:
						for(i2 = 1; i2 < 3; i2++)
							if(pActorT->fColor[i2] > 0.0f)
							{
								pActorT->fColor[i2] -= (float) BOX_COLOR_CHANGE_SPEED*g_lDeltatime/10.0f;
								if(pActorT->fColor[i2] < 0.0f)
									pActorT->fColor[i2] = 0.0f;
							}
						if(pActorT->fColor[0] < 1.0f)
						{
							pActorT->fColor[0] += (float) BOX_COLOR_CHANGE_SPEED*g_lDeltatime/10.0f;
							if(pActorT->fColor[0] > 1.0f)
								pActorT->fColor[0] = 1.0f;
						}
					break;

					case ACTOR_BOX_GREEN:
						if(pActorT->fColor[0] > 0.0f)
						{
							pActorT->fColor[0] -= (float) BOX_COLOR_CHANGE_SPEED*g_lDeltatime/10.0f;
							if(pActorT->fColor[0] < 0.0f)
								pActorT->fColor[0] = 0.0f;
						}
						if(pActorT->fColor[1] < 1.0f)
						{
							pActorT->fColor[1] += (float) BOX_COLOR_CHANGE_SPEED*g_lDeltatime/10.0f;
							if(pActorT->fColor[1] > 1.0f)
								pActorT->fColor[1] = 1.0f;
						}
						if(pActorT->fColor[2] > 0.0f)
						{
							pActorT->fColor[2] -= (float) BOX_COLOR_CHANGE_SPEED*g_lDeltatime/10.0f;
							if(pActorT->fColor[2] < 0.0f)
								pActorT->fColor[2] = 0.0f;
						}
					break;

					case ACTOR_BOX_BLUE:
						// Check if we should change the box color:
						for(i2 = 0; i2 < 2; i2++)
							if(pActorT->fColor[i2] > 0.0f)
							{
								pActorT->fColor[i2] -= (float) BOX_COLOR_CHANGE_SPEED*g_lDeltatime/10.0f;
								if(pActorT->fColor[i2] < 0.0f)
									pActorT->fColor[i2] = 0.0f;
							}
						if(pActorT->fColor[2] < 1.0f)
						{
							pActorT->fColor[2] += (float) BOX_COLOR_CHANGE_SPEED*g_lDeltatime/10.0f;
							if(pActorT->fColor[2] > 1.0f)
								pActorT->fColor[2] = 1.0f;
						}
					break;
				}
			break;

			case ACTOR_HEALTH_OBJ:
			case ACTOR_LIVE_OBJ:
			case ACTOR_PULL_OBJ:
			case ACTOR_THROW_OBJ:
			case ACTOR_FORCE_OBJ:
			case ACTOR_WEAPON_OBJ:
			case ACTOR_POINT_OBJ:
			case ACTOR_GHOST_OBJ:
			case ACTOR_TIME_OBJ:
			case ACTOR_STEP_OBJ:
			case ACTOR_SPEED_OBJ:
			case ACTOR_WING_OBJ:
			case ACTOR_SHIELD_OBJ:
			case ACTOR_JUMP_OBJ:
			case ACTOR_AIR_OBJ:
				// Normalize the actors color:
				for(i2 = 0; i2 < 3; i2++)
					if(pActorT->fColor[i2] < 1.0f)
					{
						pActorT->fColor[i2] += (float) g_lDeltatime/OBJECT_PAINT_SPEED;
						if(pActorT->fColor[i2] > 1.0f)
							pActorT->fColor[i2] = 1.0f;
					}

				// Has the player this object collected?
				if(pActorT->bGoingDeath)
				{ // Yes: (Killing sequenze)
					pActorT->fSize -= g_lDeltatime/OBJECT_KILLING_SPEED;
					if(pActorT->fSize < 0.0f)
					{
						pActorT->bActive = FALSE;
						pLevel->pField[pActorT->iFieldID].pObject = FALSE;
					}
				}
				else
				if(pActorT->byType == ACTOR_LIVE_OBJ)
				{ // Change the size:
					if(pActorT->fSize > pActorT->fPosTempTo[X]+0.001f ||
					   pActorT->fSize < pActorT->fPosTempTo[X]-0.001f)
						pActorT->fPosTempTo[X] = 1.0f+(rand() % 100)/200.0f;
					pActorT->fSize += (float) g_lDeltatime*pActorT->fPosTempVelocity[X]/500.0f;
					if(pActorT->fSize > pActorT->fPosTempTo[X])
						pActorT->fPosTempVelocity[X] -= (float) g_lDeltatime/800;
					else
						pActorT->fPosTempVelocity[X] += (float) g_lDeltatime/800;
					if(pActorT->fPosTempVelocity[X] > 0.5f)
						pActorT->fPosTempVelocity[X] = 0.5f;
					if(pActorT->fPosTempVelocity[X] < -0.5f)
						pActorT->fPosTempVelocity[X] = -0.5f;
				}

				// Animate the object:
				pActorT->dwAniDeltaTime = g_lNow-pPlayer->dwAniTime;
				if(pActorT->byType == ACTOR_WEAPON_OBJ)
					AnimateActorModel(pActorT, *pXeWeaponModel, PLAYER_ANIMATION_SPEED, 1);
				else
				if(g_lNow-pActorT->dwAniTime > OBJECTS_ANI_SPEED)
				{
					pActorT->dwAniTime = g_lNow;
					pActorT->iAniStep++;
					if(pActorT->iAniStep > 3)
						pActorT->iAniStep = 0;
				}
				
				// Rotate the object:
				pActorT->fRot[Y] += (float) g_lDeltatime/OBJECT_ROTATE_SPEED;
			break;

			case ACTOR_PLAYER_SHOT:
				// Rotate the object:
				pActorT->fRot[X] += (float) g_lDeltatime/SHOT_ROTATE_SPEED;
				pActorT->fRot[Y] += (float) g_lDeltatime/SHOT_ROTATE_SPEED;
				pActorT->fRot[Z] += (float) g_lDeltatime/SHOT_ROTATE_SPEED;
				if(pActorT->bGoingDeath)
				{ // Yes: (Killing sequenze)
					pActorT->fSize -= g_lDeltatime/SHOT_KILLING_SPEED;
					if(pActorT->fSize < 0.0f)
						pActorT->bActive = FALSE;
					break;
				}
				// Move the shot:
				if(pActorT->byDirection == RIGHT)
					pActorT->fWorldPos[X] += (float) g_lDeltatime/PLAYER_SHOT_SPEED;
				else
				if(pActorT->byDirection == DOWN)
					pActorT->fWorldPos[Y] += (float) g_lDeltatime/PLAYER_SHOT_SPEED;
				else
				if(pActorT->byDirection == LEFT)
					pActorT->fWorldPos[X] -= (float) g_lDeltatime/PLAYER_SHOT_SPEED;
				else
				if(pActorT->byDirection == UP)
					pActorT->fWorldPos[Y] -= (float) g_lDeltatime/PLAYER_SHOT_SPEED;
				if(pActorT->fWorldPos[X] < 0.0f-pLevel->fFieldWidth/2 || 
				   pActorT->fWorldPos[Y] < 0.0f-pLevel->fFieldHeight/2 ||
				   pActorT->fWorldPos[X] > pLevel->fWholeWidth-pLevel->fFieldWidth*1.5f ||
				   pActorT->fWorldPos[Y] > pLevel->fWholeHeight-pLevel->fFieldHeight*1.5f)
				{ // The shot is now outside of the level:
					pActorT->bGoingDeath = TRUE;
					break;
				}
				// Check if the shot has hit something:
				COMPUTE_FIELD_POS(pActorT->fWorldPos[X]+0.5f, pActorT->fWorldPos[Y]+0.5f, iXT, iYT);
				GET_FIELD_ID(iXT, iYT, i2);
				pFieldT = &pLevel->pField[i2];
				if(pFieldT->bWall)
				{ // We hit a wall:
					// Does we hit a box?
					if(pFieldT->pActor &&
					   pActorT->fWorldPos[Z] < pFieldT->pActor->fWorldPos[Z]+pActorT->fSize/2 &&
				       pActorT->fWorldPos[Z] > pFieldT->pActor->fWorldPos[Z]-pActorT->fSize/2)
					{ // Yes. Make damage:
						pActorT->bGoingDeath = TRUE;
					    pActorT = pFieldT->pActor;
					   // Make the shock effect:
						pActorT->fPosTemp[X] += (float) iX/10.0f;
						pActorT->fPosTemp[Y] += (float) iY/10.0f;
						pActorT->fPosTempVelocity[X] += (float) iX/15.0f;
						pActorT->fPosTempVelocity[Y] += (float) iY/15.0f;
						DamageBox(pActorT);
					}
					else
					{ // Check if the shot is about a wall:
						if(!pFieldT->pActor)
						{
							fRayDirection[X] = 0.0f;
							fRayDirection[Y] = 0.0f;
							fRayDirection[Z] = 1.0f;

							// Get the height of the center:
							pLevel->ComputeHeight(pActorT->fWorldPos[X]+0.5f, pActorT->fWorldPos[Y]+0.5f, fRayDirection, &fPoint, FACE_FRONT, 0.1f);
							if(fPoint[Z] <= pActorT->fWorldPos[Z]-0.5f)
								pActorT->bGoingDeath = TRUE;
						}
					}
				}
				else
				{
					// Did we hit the floor? (a very height one...)
					fRayDirection[X] = 0.0f;
					fRayDirection[Y] = 0.0f;
					fRayDirection[Z] = 1.0f;

					// Get the height of the center:
					pLevel->ComputeHeight(pActorT->fWorldPos[X]+0.5f, pActorT->fWorldPos[Y]+0.5f, fRayDirection, &fPoint, FACE_FLOOR, 0.1f);
					if(fPoint[Z] <= pActorT->fWorldPos[Z]-0.5f)
						pActorT->bGoingDeath = TRUE;
				}
			break;
		}
	}

	// Check the Okta:
	if((bPause && bLevelComplete) || (!bPause && !bLevelComplete))
		AnimateActorModel(&OktaActor, *pOktaModel, 150, 2);
	if(OktaActor.bActive && !bLevelComplete)
	{ // The Okta hunts the player and trie to kill him:
		if((pLevel->bTimeLimit && pLevel->iTimeLimit > 0) ||
		   (pLevel->bStepsLimit && pLevel->iStepsLimit > 0) ||
		   PlayerInfo.bGhost || PlayerInfo.bShield)
		{ // Ok, give the player a second change:
			OktaActor.fWorldPos[Z] -= (float) g_lDeltatime/70;
			if(OktaActor.fWorldPos[Z] < pPlayer->fWorldPos[Z]+pCamera->fZ)
				OktaActor.bActive = FALSE;
		}
		else
		{
			if(OktaActor.fWorldPos[Z] >= pPlayer->fWorldPos[Z])
			{ // Yea, the Okta has the player!!
				OktaActor.bThrow = TRUE;
				pPlayer->fPower = 0.0f;
			}
			else
			{
				if((OktaActor.fWorldPos[X] == pPlayer->fWorldPos[X] && 
				   OktaActor.fWorldPos[Y] == pPlayer->fWorldPos[Y]) || 
				   OktaActor.fWorldPos[Z] < pPlayer->fWorldPos[Z]-4.0f)
				{
					OktaActor.fWorldPos[Z] += (float) g_lDeltatime/70;
				}
				else
				{
					OktaActor.fWorldPos[Z] -= (float) g_lDeltatime/70;
					if(OktaActor.fWorldPos[Z] <= pPlayer->fWorldPos[Z]-4.0f)
					{
						OktaActor.fWorldPos[Z] = pPlayer->fWorldPos[Z]-4.0f;
						if(OktaActor.fWorldPos[X] < pPlayer->fWorldPos[X])
						{
							OktaActor.fWorldPos[X] += (float) g_lDeltatime/100;
							if(OktaActor.fWorldPos[X] > pPlayer->fWorldPos[X])
								OktaActor.fWorldPos[X] = pPlayer->fWorldPos[X];
						}
						else
						if(OktaActor.fWorldPos[X] > pPlayer->fWorldPos[X])
						{
							OktaActor.fWorldPos[X] -= (float) g_lDeltatime/100;
							if(OktaActor.fWorldPos[X] < pPlayer->fWorldPos[X])
								OktaActor.fWorldPos[X] = pPlayer->fWorldPos[X];
						}
						if(OktaActor.fWorldPos[Y] < pPlayer->fWorldPos[Y])
						{
							OktaActor.fWorldPos[Y] += (float) g_lDeltatime/100;
							if(OktaActor.fWorldPos[Y] > pPlayer->fWorldPos[Y])
								OktaActor.fWorldPos[Y] = pPlayer->fWorldPos[Y];
						}
						else
						if(OktaActor.fWorldPos[Y] > pPlayer->fWorldPos[Y])
						{
							OktaActor.fWorldPos[Y] -= (float) g_lDeltatime/100;
							if(OktaActor.fWorldPos[Y] < pPlayer->fWorldPos[Y])
								OktaActor.fWorldPos[Y] = pPlayer->fWorldPos[Y];
						}
					}
				}
			}
		}
	}
} // end CheckActors()

void AnimateActorModel(ACTOR *pActorT, AS_MD2_MODEL pModel, long lSpeed, char byAnimation)
{ // begin AnimateActorModel()
	pActorT->dwAniDeltaTime = g_lNow-pActorT->dwAniTime;
	// Animate the md2 model:
	pActorT->iNextAniStep = pActorT->iAniStep+1;
	if(pActorT->iNextAniStep >= pModel.Ani.anim[byAnimation].lastFrame)
		pActorT->iNextAniStep = pModel.Ani.anim[byAnimation].firstFrame;
	if(g_lNow-pActorT->dwAniTime > ((DWORD) lSpeed))
	{
		pActorT->dwAniTime = g_lNow;
		pActorT->iAniStep++;
		if(pActorT->iAniStep >= pModel.Ani.anim[byAnimation].lastFrame)
			pActorT->iAniStep = pModel.Ani.anim[byAnimation].firstFrame;
	}
} // end AnimateActorModel()

void KillBox(ACTOR *pActorT)
{ // begin KillBox()
	FIELD *pFieldT;
	ACTOR *pActorT2;
	short i2, i3, i4, x, y;

	if(pActorT->bGoingDeath)
		return;
   	DisableBoxDocking(pActorT);
	pActorT->bGoingDeath = TRUE;
	DeleteActorType(pActorT);
	// Check the box type:
	if(pActorT->byType == ACTOR_BOX_RED)
	{ // Kill all other actors around this box, too:
		for(y = -1; y < 2; y++)
		{
			for(x = -1; x < 2; x++)
			{
				if(pActorT->iFieldPos[X]+x < 0 ||
				   pActorT->iFieldPos[X]+x > pLevel->iWidth-2 ||
				   pActorT->iFieldPos[Y]+y < 0 ||
				   pActorT->iFieldPos[Y]+y > pLevel->iHeight-2)
					continue;
				// Check the field:
				GET_FIELD_ID((pActorT->iFieldPos[X]+x), (pActorT->iFieldPos[Y]+y), i2);
				pFieldT = &pLevel->pField[i2];
				pActorT2 = pFieldT->pActor;
				if(pActorT2 && !pActorT2->bGoingDeath)
				{
					if(pActorT2->byType == ACTOR_BOX_NORMAL ||
					   pActorT2->byType == ACTOR_BOX_RED ||
					   pActorT2->byType == ACTOR_BOX_GREEN ||
					   pActorT2->byType == ACTOR_BOX_BLUE)
							KillBox(pActorT2);
					else
					{
						if(pActorT2->byType == ACTOR_PLAYER)
						{
							if(!PlayerInfo.bShield)
								pActorT2->fPower = 0.0f; // Kill the player:
						}
						else
							KillBox(pActorT2);
					}
				}
				else
					if(pFieldT->bWall)
						pLevel->SetFieldWall(pFieldT->iXField, pFieldT->iYField, FALSE, FALSE);  // Destroy this wall:
				if(pFieldT->pBridgeActor)
					KillBox(pFieldT->pBridgeActor);
				if(pFieldT->pObject)
					pFieldT->pObject->bGoingDeath = TRUE;
			}
		}
	}
	else
	if(pActorT->byType == ACTOR_BOX_GREEN)
	{ // Deactivate this field:
		GET_FIELD_ID(pActorT->iFieldPos[X], pActorT->iFieldPos[Y], i2);
		pFieldT = &pLevel->pField[i2];
		pFieldT->bActive = FALSE;
		if(pLevel->pSurface[pFieldT->iSurface[FACE_FLOOR]].bAnchor)
		{
			switch(pLevel->pSurface[pFieldT->iSurface[FACE_FLOOR]].byAnchorType)
			{
				case 0: pLevel->iForAllAnchors--; break;
				case 1: pLevel->iNormalAnchors--; break;
				case 2: pLevel->iRedAnchors--; break;
				case 3: pLevel->iGreenAnchors--; break;
				case 4: pLevel->iBlueAnchors--; break;
			}
		}
		if(pFieldT->pBridgeActor)
		{		
			KillBox(pFieldT->pBridgeActor);
			pFieldT->bActive = FALSE;
		}
		pFieldT->pBridgeActor = NULL;
		if(pFieldT->pObject)
			pFieldT->pObject->bActive = NULL;
   		pFieldT->pObject = NULL;

		// Damage the boxes (and player) around this green box:
   		for(y = -1; y < 2; y++)
		{
			for(x = -1; x < 2; x++)
			{
				if(pActorT->iFieldPos[X]+x < 0 ||
				   pActorT->iFieldPos[X]+x > pLevel->iWidth-2 ||
				   pActorT->iFieldPos[Y]+y < 0 ||
				   pActorT->iFieldPos[Y]+y > pLevel->iHeight-2)
					continue;
				// Check the field:
				GET_FIELD_ID((pActorT->iFieldPos[X]+x), (pActorT->iFieldPos[Y]+y), i2);
				pFieldT = &pLevel->pField[i2];
				if(pFieldT->pActor)
				{
					switch(pFieldT->pActor->byType)
					{
						// Damage the box if there is one:
						case ACTOR_BOX_NORMAL:
						case ACTOR_BOX_RED:
						case ACTOR_BOX_GREEN:
						case ACTOR_BOX_BLUE:
							DamageBox(pFieldT->pActor);
						break;
					
						// If the player is near this green box he will be damaged, too!
						case ACTOR_PLAYER:
							pPlayer->fPower -= 20.0f;
							MakePlayerCameraRotation(ACTION_PLAYER_PAIN_2);
							if(pPlayer->byAction != ACTION_PLAYER_PAIN_2)
							{
								pPlayer->byAction = ACTION_PLAYER_PAIN_2;
								pPlayer->byAnimation = 4;
								pPlayer->iAniStep = pXeModel->Ani.anim[pPlayer->byAnimation].firstFrame;
								pPlayer->dwAniTime = g_lNow;
							}
						break;
					}
					// Make the actor a little bit green:
					pFieldT->pActor->fColor[0] -= 0.3f;
					pFieldT->pActor->fColor[1] += 0.3f;
					pFieldT->pActor->fColor[2] -= 0.3f;
					for(i3 = 0; i3 < 3; i3++)
					{
						if(pFieldT->pActor->fColor[i3] < 0.0f)
							pFieldT->pActor->fColor[i3] = 0.0f;
						if(pFieldT->pActor->fColor[i3] > 1.0f)
							pFieldT->pActor->fColor[i3] = 1.0f;
					}
				}
				// Make the fields a little bit green:
				for(i3 = 0; i3 < 6; i3++)
					for(i4 = 0; i4 < 3; i4++)
					{
						pLevel->fColor[pFieldT->iFace[i3][i4]][0] -= 0.05f;
						if(pLevel->fColor[pFieldT->iFace[i3][i4]][0] < 0.0f)
							pLevel->fColor[pFieldT->iFace[i3][i4]][0] = 0.0f;
						pLevel->fColor[pFieldT->iFace[i3][i4]][1] += 0.05f;
						if(pLevel->fColor[pFieldT->iFace[i3][i4]][1] > 1.0f)
							pLevel->fColor[pFieldT->iFace[i3][i4]][1] = 1.0f;
						pLevel->fColor[pFieldT->iFace[i3][i4]][2] -= 0.05f;
						if(pLevel->fColor[pFieldT->iFace[i3][i4]][2] < 0.0f)
							pLevel->fColor[pFieldT->iFace[i3][i4]][2] = 0.0f;
					}
			}
		}
	}
	else
	if(pActorT->byType == ACTOR_BOX_BLUE)
	{ // Paint all other actors around this box blue:
   		for(y = -1; y < 2; y++)
		{
			for(x = -1; x < 2; x++)
			{
				if(pActorT->iFieldPos[X]+x < 0 ||
				   pActorT->iFieldPos[X]+x > pLevel->iWidth-2 ||
				   pActorT->iFieldPos[Y]+y < 0 ||
				   pActorT->iFieldPos[Y]+y > pLevel->iHeight-2)
					continue;
				// Check the field:
				GET_FIELD_ID((pActorT->iFieldPos[X]+x), (pActorT->iFieldPos[Y]+y), i2);
				pFieldT = &pLevel->pField[i2];
				if(pFieldT->pActor)
				{
					pActorT2 = pFieldT->pActor;
					if(pActorT2->byType == ACTOR_BOX_NORMAL ||
					   pActorT2->byType == ACTOR_BOX_RED ||
					   pActorT2->byType == ACTOR_BOX_GREEN)
					{
						if(!pActorT2->bGoingDeath)
						{
							DeleteActorType(pActorT2);
							pActorT2->byType = ACTOR_BOX_BLUE;
							CheckActorField(pActorT2);
							pLevel->iBlueBoxes++;
							if(pActorT2->bBridge)
								iNoneFreeBlueBoxes++;
						}
					}
					else
					{
						pActorT2->fColor[0] = 0.0f;
						pActorT2->fColor[1] = 0.0f;
						pActorT2->fColor[2] = 1.0f;
					}
				}
				if(pFieldT->pObject)
				{
					pActorT2 = pFieldT->pObject;
					pActorT2->fColor[0] = 0.0f;
					pActorT2->fColor[1] = 0.0f;
					pActorT2->fColor[2] = 1.0f;
				}
				if(pFieldT->pBridgeActor && !pFieldT->pBridgeActor->bGoingDeath &&
				   pFieldT->pBridgeActor->byType != ACTOR_BOX_BLUE)
				{
					DeleteActorType(pFieldT->pBridgeActor);
					pFieldT->pBridgeActor->byType = ACTOR_BOX_BLUE;
					pLevel->iBlueBoxes++;
					if(pActorT2->bBridge)
						iNoneFreeBlueBoxes++;
				}
				// Make the field blue:
				for(i3 = 0; i3 < 6; i3++)
					for(i4 = 0; i4 < 3; i4++)
					{
						pLevel->fColor[pFieldT->iFace[i3][i4]][0] -= 0.4f;
						if(pLevel->fColor[pFieldT->iFace[i3][i4]][0] < 0.0f)
							pLevel->fColor[pFieldT->iFace[i3][i4]][0] = 0.0f;
						pLevel->fColor[pFieldT->iFace[i3][i4]][1] -= 0.4f;
						if(pLevel->fColor[pFieldT->iFace[i3][i4]][1] < 0.0f)
							pLevel->fColor[pFieldT->iFace[i3][i4]][1] = 0.0f;
						pLevel->fColor[pFieldT->iFace[i3][i4]][2] += 0.4f;
						if(pLevel->fColor[pFieldT->iFace[i3][i4]][2] > 1.0f)
							pLevel->fColor[pFieldT->iFace[i3][i4]][2] = 1.0f;
					}
			}
		}
	}
} // end KillBox()

void CheckBoxThrow(ACTOR *pActorT)
{ // begin CheckBoxThrow()
	ACTOR *pActorT2;

	// Check if this box was thrown:
	if(!pActorT->bThrow || pActorT->bMove)
		return;

	// Yes! It should fly till a wall or an actor is stopping it!
	short iX, iY;
	FIELD *pFieldT;

	// Setup x/y direction:
	switch(pActorT->byDirection)
	{
		case RIGHT: iX = 1; iY = 0; break;
		case DOWN: iX = 0; iY = 1; break;
		case LEFT: iX = -1; iY = 0; break;
		case UP: iX = 0; iY = -1; break;
	}
	pFieldT = &pLevel->pField[(pActorT->iFieldPos[Y]+iY)*pLevel->iWidth+pActorT->iFieldPos[X]+iX];

	// Check if we could fly:
	if(pActorT->iFieldPos[X]+iX < 0 || pActorT->iFieldPos[X]+iX >= pLevel->iWidth-1 ||
	   pActorT->iFieldPos[Y]+iY < 0 || pActorT->iFieldPos[Y]+iY >= pLevel->iHeight-1 ||
	   pLevel->pField[(pActorT->iFieldPos[Y]+iY)*pLevel->iWidth+pActorT->iFieldPos[X]+iX].bWall)
	{
		pActorT->fPosTemp[X] += (float) iX/10.0f;
		pActorT->fPosTemp[Y] += (float) iY/10.0f;
		pActorT->fPosTempVelocity[X] += (float) iX/15.0f;
		pActorT->fPosTempVelocity[Y] += (float) iY/15.0f;
		if(pActorT->iFieldPos[X]+iX >= 0 && pActorT->iFieldPos[X]+iX < pLevel->iWidth-1 &&
		   pActorT->iFieldPos[Y]+iY >= 0 && pActorT->iFieldPos[Y]+iY < pLevel->iHeight-1 &&
	       pLevel->pField[(pActorT->iFieldPos[Y]+iY)*pLevel->iWidth+pActorT->iFieldPos[X]+iX].pActor)
		{ // A other holds the box: (shock effect)
			pActorT2 = pLevel->pField[(pActorT->iFieldPos[Y]+iY)*pLevel->iWidth+pActorT->iFieldPos[X]+iX].pActor;
			pActorT2->fPosTemp[X] += (float) iX/10.0f;
			pActorT2->fPosTemp[Y] += (float) iY/10.0f;
			pActorT2->fPosTempVelocity[X] += (float) iX/10.0f;
			pActorT2->fPosTempVelocity[Y] += (float) iY/10.0f;
			// Damage the hit box:
			DamageBox(pActorT2);
		};
		// Damage the thrown box:
		DamageBox(pActorT);
		pActorT->bThrow = FALSE;
		return; // The box is stopped by a wall!!
	}
	// The box fly 'again':
	pActorT->bMove = TRUE;
	DisableBoxDocking(pActorT);
	// Check if we kill or hit now a actor:
	pFieldT = &pLevel->pField[(pPlayer->iFieldPos[Y]+iY)*pLevel->iWidth+pPlayer->iFieldPos[X]+iX];
	if(!pFieldT->pActor)
	{ // There is nothing to kill ;-(
		pFieldT->pActor = pActorT;
		return; 
	}
	// Yep, Yep, Yep!! TERMINATE it!! ;->

} // end CheckBoxThrow()

void DamageBox(ACTOR *pActorT)
{ // begin DamageBox()
	float fDeadDamage;
	
	pActorT->fPower -= 0.1f;
	fDeadDamage = 0.0f;
	switch(pActorT->byType)
	{
		case ACTOR_BOX_NORMAL: fDeadDamage -= 0.1f; break;
		case ACTOR_BOX_GREEN: fDeadDamage -= 0.2f; break;
		case ACTOR_BOX_BLUE: fDeadDamage -= 0.3f; break;
	}
	// Check the power:
	if(pActorT->bHeavy)
	{
		if(pActorT->fPower < fDeadDamage-0.2f)
    	   KillBox(pActorT); // The box is no longer!
	}
	else
	{
		if(pActorT->fPower < fDeadDamage)
    	   KillBox(pActorT); // The box is no longer!
	}
} // end DamageBox()

void DrawBoundingBox(float fBox[2][3], float fScale)
{ // begin DrawBoundingBox()
	glDisable(GL_TEXTURE_2D);
	glColor3f(1.0f, 1.0f, 1.0f);
	glLineWidth(3.0f);
	// Left side:
	glBegin(GL_LINE_LOOP);
		glVertex3f(fBox[0][X], fBox[0][Y], fBox[0][Z]);
		glVertex3f(fBox[0][X], fBox[1][Y], fBox[0][Z]);
		glVertex3f(fBox[1][X], fBox[1][Y], fBox[0][Z]);
		glVertex3f(fBox[1][X], fBox[0][Y], fBox[0][Z]);
	glEnd();
	// Right side:
	glBegin(GL_LINE_LOOP);
		glVertex3f(fBox[0][X], fBox[0][Y], fBox[1][Z]);
		glVertex3f(fBox[0][X], fBox[1][Y], fBox[1][Z]);
		glVertex3f(fBox[1][X], fBox[1][Y], fBox[1][Z]);
		glVertex3f(fBox[1][X], fBox[0][Y], fBox[1][Z]);
	glEnd();
	// The other four lines:
	glBegin(GL_LINES);
		glVertex3f(fBox[0][X], fBox[0][Y], fBox[0][Z]);
		glVertex3f(fBox[0][X], fBox[0][Y], fBox[1][Z]);
		glVertex3f(fBox[0][X], fBox[1][Y], fBox[0][Z]);
		glVertex3f(fBox[0][X], fBox[1][Y], fBox[1][Z]);
		glVertex3f(fBox[1][X], fBox[1][Y], fBox[0][Z]);
		glVertex3f(fBox[1][X], fBox[1][Y], fBox[1][Z]);
		glVertex3f(fBox[1][X], fBox[0][Y], fBox[0][Z]);
		glVertex3f(fBox[1][X], fBox[0][Y], fBox[1][Z]);
	glEnd();
} // end DrawBoundingBox()

void DisableBoxDocking(ACTOR *pActorT)
{ // begin DisableBoxDocking()
	// Was the box already docked?
	if(pActorT->bDocked)
	{ // Yes:
		switch(pLevel->pField[pActorT->iFieldID].pSurface[FACE_FLOOR]->byAnchorType)
		{
			case 0: iUsedForAllAnchors--; break;
			case 1: iUsedNormalAnchors--; break;
			case 2: iUsedRedAnchors--; break;
			case 3: iUsedGreenAnchors--; break;
			case 4: iUsedBlueAnchors--; break;
		}
		pActorT->bDocked = FALSE;
		pActorT->fFieldPos[Z] = 0.0f;
		switch(pActorT->byType)
		{
			case ACTOR_BOX_NORMAL: iNoneFreeNormalBoxes--; break;
			case ACTOR_BOX_RED: iNoneFreeRedBoxes--; break;
			case ACTOR_BOX_GREEN: iNoneFreeGreenBoxes--; break;
			case ACTOR_BOX_BLUE: iNoneFreeBlueBoxes--; break;
		}
	}
} // end DisableBoxDocking()

void DeleteActorType(ACTOR *pActorT)
{ // begin DeleteActorType()
	switch(pActorT->byType)
	{
		case ACTOR_BOX_NORMAL: pLevel->iNormalBoxes--; break;
		case ACTOR_BOX_RED: pLevel->iRedBoxes--; break;
		case ACTOR_BOX_GREEN: pLevel->iGreenBoxes--; break;
		case ACTOR_BOX_BLUE: pLevel->iBlueBoxes--; break;
	}
	if(pActorT->bBridge)
		DisableNoneFreeBox(pActorT);
} // end DeleteActorType()

void DisableNoneFreeBox(ACTOR *pActorT)
{ // begin DisableNoneFreeBox()
	switch(pActorT->byType)
	{
		case ACTOR_BOX_NORMAL: iNoneFreeNormalBoxes--; break;
		case ACTOR_BOX_RED: iNoneFreeRedBoxes--; break;
		case ACTOR_BOX_GREEN: iNoneFreeGreenBoxes--; break;
		case ACTOR_BOX_BLUE: iNoneFreeBlueBoxes--; break;
	}
} // end DisableNoneFreeBox()

void SetNoneFreeBox(ACTOR *pActorT)
{ // begin SetNoneFreeBox()
	switch(pActorT->byType)
	{
		case ACTOR_BOX_NORMAL: iNoneFreeNormalBoxes++; break;
		case ACTOR_BOX_RED: iNoneFreeRedBoxes++; break;
		case ACTOR_BOX_GREEN: iNoneFreeGreenBoxes++; break;
		case ACTOR_BOX_BLUE: iNoneFreeBlueBoxes++; break;
	}
} // end SetNoneFreeBox()
/*

			RR   AAAA TTTTT EEEE      SSS PPP  I EEEE L
			R R  A  A   T   E        S    P  P I E    L
			RR   AAAA   T   EEEE      SS  PPP  I EEEE L
			R R  A  A   T   E           S P    I E    L
			R  R A  a   T   EEEE     SSS  P    I EEEE LLLLL

			2000 von Christian Ofenberg

	
	Entwicklungszeit: 4 Stunden (3 1/2 davon f�r die Dokumentation...)

	Anmerkungen:
	
	>> if(x) << ist eine verk�rzte Schreibwei�e von >> if(x != 0) <<
	>> if(!x) << ist eine verk�rzte Schreibwei�e von >> if(x == 0) <<


*/

#include "Ratespiel.h"		// Allgemeine includes welche f�r das Programm
							// ben�tigt werden


// Variablen: *****************************************************************
HINSTANCE hInstance;	// 'Griff' f�r das Programm
int iCmdShow;			// Darstellungsart des Fensters
HANDLE hMutex;          // Eine 'Ich bin schon da' kennung f�r das Programm
// Diese Variablen sind notwendig um das Verzeichnis zu ermiteln wo das Programm
// Installiert ist:
char byProgrammPfad[MAX_PATH], byProgrammExeName[MAX_PATH],
     byProgrammLaufwerk[MAX_PATH], byProgrammDir[MAX_PATH];
char byBenutzerName[256]; // Der Name des Benutzers oder zumindest der des Computers ;-)
///////////////////////////////////////////////////////////////////////////////


// Hier beginnt das Programm:
int PASCAL WinMain(HINSTANCE hInstanceT,     // 'Griff' f�r das Programm
				   HINSTANCE hPrevInstanceT, // Veraltet, wird vom neuen Windows 95x
				                             // nicht mehr verwendet
                   LPSTR lpCmdLineT,		 // Ein String mit Parametern die dem 
											 // Programm beim Starten mitgegeben
											 // wurden
				   int iCmdShowT)			 // Die Darstellungsart des Fensters (Standart)
{ // begin WinMain()
	char byTemp[256];
	ULONG i = 256;

	// Die allgemeinen Programminformationen speichern... diese k�nnten sp�ter
	// noch ben�tigt werden:
	hInstance = hInstanceT;
	iCmdShow = iCmdShowT;
	// Das Verzeichnis ermitteln in dem unser Programm gespeichert ist:
	// Mit absoluten Pfaden zu arbeiten ist 'Schwachsinnig' da das Programm
	// auf jeden Rechner in einem anderen Verzeichnis gespeichert wird...
	GetModuleFileName(hInstance, byProgrammExeName, MAX_PATH);
	_splitpath(byProgrammExeName, byProgrammLaufwerk, byProgrammDir, NULL, NULL);
	sprintf(byProgrammPfad, "%s%s", byProgrammLaufwerk, byProgrammDir);
	SetCurrentDirectory(byProgrammPfad);
	// Den Namen des Benutzers/Computers anholen: (vielleicht l�sst sich der Benutzer
	// davon beeindrucken das wir seinen Namen kennen...)
	GetUserName(byBenutzerName, &i);
	// Spieleinstellungen laden:
	sprintf(byTemp, "%s%s", byProgrammPfad, CONFIG_FILE);
	Einstellungen.Laden(byTemp);
	// Diese Abfrage verhindert das das Programm doppelt l�uft:
    hMutex = OpenMutex(SYNCHRONIZE, FALSE, SPIEL_NAME);
    if(hMutex)
    { // Das Programm l�uft schon!!
		// Darf das Programm doppelt laufen??
		if(!Einstellungen.bGleichzeitigLaufen)
		{
			CloseHandle(hMutex);
			sprintf(byTemp, SPIEL_NAME" l�uft schon!!");
			MessageBox(0, byTemp, SPIEL_NAME, MB_ICONERROR | MB_OK);
			return 1; // Programm mit Fehlercode beenden
		}
    }
    else
        hMutex = CreateMutex(NULL, TRUE, SPIEL_NAME);
	// Diese Zeilen geben unserem Programm MACHT... kurzum: nun bekommt unser Programm
	// von Windows die volle Aufmerksamkeit!
	SetPriorityClass(hInstance, 31);
	SetThreadPriority(hInstance, 31);
	// Ist dies der erste Programm start?
	if(Einstellungen.bErststart) // Ja! Also den Benutzer entsprechend gr��en.
	{
		sprintf(byTemp, "Hallo %s! Bin mal gespannt wann du mich wieder Beendest...\n", byBenutzerName);
		MessageBox(NULL, byTemp, SPIEL_NAME, MB_OK | MB_ICONINFORMATION);
		// So, das sollte den Benutzer schon mal Aufgew�rmt haben...
	}
	// Nun wird der Spiel-Dialog ge�ffnet, in ihm wird nun das gesammte Programm
	// ablaufen und man muss 'nur noch' im Hintergrund die F�den ziehen:
	DialogBox(hInstance, MAKEINTRESOURCE(IDD_SPIEL), NULL, (DLGPROC) SpielProc);
	// Der Tot unserer Application steht nun unmittelbar bevor:
	// Spieleinstellungen speichern:
	Einstellungen.bErststart = FALSE;
	sprintf(byTemp, "%s%s", byProgrammPfad, CONFIG_FILE);
	if(Einstellungen.Speichern(byTemp))
	{ // Es trat ein Fehler beim Speichern der Einstellungen auf!
		// Dies wird nun dem Benutzer mitgeteilt:
		MessageBox(NULL, "Die Spieleinstellungen konnten nicht gespeichert werden!.\n",
		           "Fehler", MB_OK | MB_ICONINFORMATION);
		return 1; // Das Programm mit einem Fehlercode beenden
	}
	// T�r nach drau�en �ffnen und nichts wie weg... oder einfach ausgedr�ckt:
	// Programm beenden und zu Windows 'zur�ckkehren':
	return 0; // Das Programm wurde ohne Fehler beendet
	// That's all!!
} // end WinMain()
// Hier endet das Programm
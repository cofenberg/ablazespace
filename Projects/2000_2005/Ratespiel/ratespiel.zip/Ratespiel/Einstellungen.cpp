#include "Ratespiel.h"		// Allgemeine includes welche f�r das Programm
							// ben�tigt werden


// Variablen: *****************************************************************
EINSTELLUNGEN Einstellungen;
///////////////////////////////////////////////////////////////////////////////


void EINSTELLUNGEN::Laden(char *pbyDateiName)
{ // begin EINSTELLUNGEN::Laden()
	bErststart = GetPrivateProfileInt("Allgemeines", "erststart", 1, pbyDateiName);
	bGleichzeitigLaufen = GetPrivateProfileInt("Allgemeines", "gleichzeitig_laufen", 1, pbyDateiName);
	bMusik = GetPrivateProfileInt("Allgemeines", "musik", 1, pbyDateiName);
} // end EINSTELLUNGEN::Laden()

BOOL EINSTELLUNGEN::Speichern(char *pbyDateiName)
{ // begin EINSTELLUNGEN::Speichern()
	FILE *pDatei;

	pDatei = fopen(pbyDateiName, "wt");
	if(!pDatei)
		return 1;
	fprintf(pDatei, "[Allgemeines]\n");
    fprintf(pDatei, "erststart=%d\n", bErststart);
    fprintf(pDatei, "gleichzeitig_laufen=%d\n", bGleichzeitigLaufen);
    fprintf(pDatei, "musik=%d\n", bMusik);
	fclose(pDatei);
	return 0;
} // end EINSTELLUNGEN::Speicheren()
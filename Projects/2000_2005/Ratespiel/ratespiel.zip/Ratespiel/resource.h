//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Resource.rc
//
#define IDD_CREDITS                     109
#define IDI_ICON                        134
#define IDD_SPIEL                       136
#define IDR_SPIEL_MENU                  137
#define IDD_SPIEL_EINSTELLUNGEN         138
#define IDC_CREDITS_BUILD_DATE          1016
#define IDC_CREDITS_BUILD_TIME          1017
#define IDC_CREDITS_OK                  1018
#define IDC_CREDITS_HOMEPAGE            1093
#define IDC_CREDITS_PROGRAMMING_AND_DESIGN 1094
#define IDC_CREDITS_MUSIC               1095
#define IDC_CREDITS_E_MAIL              1096
#define IDC_CREDITS_PROGRAM_INFO        1097
#define IDC_CREDITS_BUILD               1098
#define IDC_CREDITS_AUTOR               1099
#define none1                           1100
#define none2                           1101
#define none3                           1102
#define IDC_SPIEL_TITEL                 1118
#define IDC_MAX_ZAHL                    1123
#define IDC_MAX_VERSUCHE                1124
#define IDC_SPIEL_STARTEN               1125
#define IDC_ABRECHEN                    1126
#define IDC_SPIEL_ZAHL                  1127
#define IDC_SPIEL_ZAHL_TEXT             1128
#define IDC_VERSUCHE                    1129
#define none5                           40035
#define ID_HILFE_CREDITS                40036
#define ID_HILFE_HOMEPAGE               40037
#define ID_HILFE_HILFE                  40038
#define ID_DATEI_BEENDEN                40039
#define ID_DATEI_NEUES_SPIEL            40040
#define ID_SPIEL_ABRECHEN               40041
#define ID_SPIEL_OK                     40042

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         40041
#define _APS_NEXT_CONTROL_VALUE         1130
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

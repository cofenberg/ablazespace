#ifndef __SPIEL_H__
#define __SPIEL_H__


// Funktionen: ****************************************************************
extern LRESULT CALLBACK SpielProc(HWND, UINT, WPARAM, LPARAM);
extern LRESULT CALLBACK SpielEinstellungenProc(HWND, UINT, WPARAM, LPARAM);
extern LRESULT CALLBACK CreditsProc(HWND, UINT, WPARAM, LPARAM);
extern BOOL PlayMidi(HWND, char *);
extern BOOL StopMidi(void);
extern void GeheInSpiel(void);
extern void GeheInSpielMenue(void);
///////////////////////////////////////////////////////////////////////////////

// Variablen: *****************************************************************
extern HWND hWndSpiel;	    	// 'Griff' f�r den Spiel Dialog
extern short iMaxZahl,			// Die gr��tm�gliche zu Zahl
             iMaxVersuche,		// Die Anzahl der Versuche
			 iVersuche,			// Die Anzahl der Versuche die der Spieler schon
								// verbraucht hat
			 iZahl,				// Die vom Spieler eingegebene Zahl
			 iComputerZahl;		// Diese Zahl hat sich der Computer 'ausgesucht'
///////////////////////////////////////////////////////////////////////////////

#endif // __SPIEL_H__
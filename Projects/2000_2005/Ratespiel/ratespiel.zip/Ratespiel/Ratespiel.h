#ifndef __RATESPIEL_H__
#define __RATESPIEL_H__


// Includes: ******************************************************************
// Diese Dateien m�ssen eingebunden werden, da diese von manchen Befehlen
// ben�tige werden:
#include <Windows.h>				// Die Quelle allen �bels... Diablo Spieler
									// hereinspaziert!
#include <mmsystem.h>
#include <stdio.h>

// Unser Programm:
#include "resource.h"
#include "Spiel.h"
#include "Einstellungen.h"
///////////////////////////////////////////////////////////////////////////////

// Definationen: **************************************************************
#define SPIEL_NAME "Ratespiel"			// Name des Programms
#define AUTOR_NAME "Christian Ofenberg" // Name des Autors
#define CONFIG_FILE "Config.ini"		// Name der 'Einstellungs-Datei'
///////////////////////////////////////////////////////////////////////////////

// Variablen: *****************************************************************
extern HINSTANCE hInstance;
extern int iCmdShow;
extern HANDLE hMutex;
// Diese Variablen sind notwendig um das Verzeichnis zu ermiteln wo das Programm
// Installiert ist:
extern char byProgrammPfad[MAX_PATH], byProgrammExeName[MAX_PATH],
            byProgrammLaufwerk[MAX_PATH], byProgrammDir[MAX_PATH];
extern char byBenutzerName[256]; // Der Name des Benutzers oder zumindest der des Computers ;-)
///////////////////////////////////////////////////////////////////////////////


#endif // __RATESPIEL_H__
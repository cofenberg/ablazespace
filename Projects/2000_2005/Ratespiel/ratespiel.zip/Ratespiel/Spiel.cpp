#include "Ratespiel.h"		// Allgemeine includes welche f�r das Programm
							// ben�tigt werden


// Funktionen: ****************************************************************
LRESULT CALLBACK SpielProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK SpielEinstellungenProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK CreditsProc(HWND, UINT, WPARAM, LPARAM);
void GeheInSpiel(void);
void GeheInSpielMenue(void);
BOOL PlayMidi(HWND, char *);
BOOL StopMidi(void);
///////////////////////////////////////////////////////////////////////////////

// Variablen: *****************************************************************
HWND hWndSpiel;					// 'Griff' f�r den Spiel Dialog
short iMaxZahl = 100,			// Die gr��tm�gliche zu Zahl
      iMaxVersuche = 10,		// Die Anzahl der Versuche
	  iVersuche,				// Die Anzahl der Versuche die der Spieler schon
								// verbraucht hat
	  iZahl,					// Die vom Spieler eingegebene Zahl
	  iComputerZahl;			// Diese Zahl hat sich der Computer 'ausgesucht'
///////////////////////////////////////////////////////////////////////////////


/*
	UINT iMessage: In dierer Variable wird der Nachrichten Typ festgehalten, dieser
	               ist entscheident f�r die Folgende aktion!
	HWND hWnd:     Der Fenster-'Griff'(Handle) welcher die ID eines Fensters speichert.
				   Nur mit deren Hilfe ist es m�glich ein Fenster zu manipulieren.

	WPARAM wParamb & LPARAM lParam:
				   Je nach Nachrichtenart beinhalten diese Variablen genauere Informationen
				   der Nachricht.
*/


// Hier spielt die Musik. Alle Aktionen des Benutzers werden in form von Nachrichten empfangen
// welche dann nur noch Ausgewertet werden m�ssen.
LRESULT CALLBACK SpielProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin SpielProc()
    char byTemp[256];
	
	switch(iMessage)
    {
        // Wird ein Dialog ge�ffnet (z.B. per DialogBox()) so bedeutet diese Nachricht
		// soviel wie: "Hallo da bin ich!"
		case WM_INITDIALOG:
			hWndSpiel = hWnd;
			// Dem Spielfenster den richtigen Namen geben:
			SetWindowText(hWnd, SPIEL_NAME);
			// Midi Musik abspielen (falls Aktiviert!):
			if(Einstellungen.bMusik)
				PlayMidi(hWnd, "Monolith.mid");
			// Spiel men� Aktivieren:
			GeheInSpielMenue();
			// Fenster Aktualisieren:
			ShowWindow(hWnd, iCmdShow);
			UpdateWindow(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
			// Datei:
				// Neues Spiel starten:				
				case ID_DATEI_NEUES_SPIEL:
					if(!DialogBox(hInstance, MAKEINTRESOURCE(IDD_SPIEL_EINSTELLUNGEN), hWnd, (DLGPROC) SpielEinstellungenProc))
					{ // Das Spiel soll doch nicht gestartet werden...
						break;
					}
					// Spiel starten:
					// Alle Spielbuttons einstellen:
					GeheInSpiel();
					// Nun sicht sich der Computer eine Zahl in den Angegebenen bereich aus:
					iComputerZahl = rand() % (iMaxZahl+1);
					// Die Anzahl der Versuche auf Null setzen:
					iVersuche = 0;
				break;

                // Der benutzer will unverst�ndlicherwei�e unser Kultverd�chtiges Spiel beenden...
				case ID_DATEI_BEENDEN:
				Close:
					// War dies nur ein versehen oder meints der Typ erst??
					// Zu beachten: Diesmal wird als erster Parameter an Fenster-Handle mitgegeben,
					// dies hat zur folge das die Nachrichtenbox f�r dieses Fenster gesetzt wird und 
					// das selbige nun 'Inaktiv' ist:
					if(MessageBox(hWnd, "Wollen Sie das Spiel wirklich beenden??\n",
							       SPIEL_NAME, MB_YESNO | MB_ICONQUESTION) == IDNO)
					{ // Der Benutzer scheint doch einen Funken verstand zu haben... er will
					  // unser Spiel doch nicht beenden:
						break;
					}
					// Der 'Super-DAU' scheint sich ziemlich sicher zu sein...
					// Dann tun wir ihm halt den gefallen und beenden das Spiel:
					EndDialog(hWnd, FALSE);
					hWndSpiel = NULL;
					// Midi Musik anhalten:
					if(Einstellungen.bMusik)
						StopMidi();
                return TRUE;

			// Hilfe:
				// Die Hilfe datei �ffnen:
				case ID_HILFE_HILFE:
					ShellExecute(0, "open", "Hilfe.html", 0, 0, SW_SHOW);				
				break;

				// Die Credits anzeigen:
				case ID_HILFE_CREDITS:
					DialogBox(hInstance, MAKEINTRESOURCE(IDD_CREDITS), hWnd, (DLGPROC) CreditsProc);
				break;

				// Homepage besuchen:
				case ID_HILFE_HOMEPAGE:
					ShellExecute(0, "open", "http://ablazespace.exit.de", 0, 0, SW_SHOW);				
				break;
			
			// Anderes:
				case ID_SPIEL_ABRECHEN:
					// Ist der Kerl sicher das er 'sein' Spiel abrechen m�chte?
					if(MessageBox(hWnd, "Wollen Sie das Spiel wirklich Abrechen??\n",
							       SPIEL_NAME, MB_YESNO | MB_ICONQUESTION) == IDNO)
					{ // Da hat er ja noch mal Gl�ck gehabt das diese Abfrage da ist!!
						break;
					}
					// Er hat das Spiel tats�chlich Abgebrochen!!
					GeheInSpielMenue();
				break;

				case ID_SPIEL_OK:
					// Erh�he die verbrauten Versuche
					iVersuche++;
					// Hole die vom Spieler eingegebene Zahl:
					GetDlgItemText(hWnd, IDC_SPIEL_ZAHL, byTemp, 256);
					iZahl = (short) atoi(byTemp);
					// Nun erfolgt die Auswertung:
					if(iZahl == iComputerZahl)
					{ // Der Spieler hat die richtige Zahl gefunden!!
						sprintf(byTemp, ">- %d <- JA das meine ausgedachte Zahl!!", iZahl);
					}
					else
						if(iZahl > iMaxZahl)
						{ // Der Spieler hat eine Zahl eingegeben die au�erhalb des Zahlenbereichs liegt!!
							sprintf(byTemp, ">- %d <- Warum verschwendest du deine Versuche?\n"
											"Die gr��t m�gliche Zahl ist doch %d!!", iZahl, iMaxZahl);
						}
						else
							if(iZahl < 0)
							{ // Der Spieler hat eine negative Zahl eingegeben... UNG�LTIG!!
								sprintf(byTemp, ">- %d <- Du scherzt wohl! Warum verschwendest du deine Versuche?\n"
												"Die kleinst m�gliche Zahl ist 0!!", iZahl);
							}
							else
								if(iZahl > iComputerZahl)
								{ // Die Zahl vom Spieler ist zu gro�!
									sprintf(byTemp, ">- %d <- Meine Zahl ist kleiner!", iZahl);
								}
								else
									if(iZahl < iComputerZahl)
									{ // Die Zahl vom Spieler ist zu klein!
										sprintf(byTemp, ">- %d <- Meine Zahl ist gr��er!", iZahl);
									}
					MessageBox(hWnd, byTemp, SPIEL_NAME, MB_OK | MB_ICONINFORMATION);
					if(iVersuche == iMaxVersuche && iZahl == iComputerZahl)
					{ // Das Spiel ist zu ende: (Gewonnen)
						MessageBox(hWnd, "Du hast Gewonnen - ganz sch�n knapp gewesen!", SPIEL_NAME, MB_OK | MB_ICONINFORMATION);
						GeheInSpielMenue();
					}
					else
						if(iVersuche == iMaxVersuche)
						{ // Das Spiel ist zu ende: (Verloren)
							MessageBox(hWnd, "Du hast Verloren!", SPIEL_NAME, MB_OK | MB_ICONINFORMATION);
							GeheInSpielMenue();
						}
						else
							if(iZahl == iComputerZahl)
							{ // Das Spiel ist zu ende: (Gewonnen)
								MessageBox(hWnd, "Du hast Gewonnen!", SPIEL_NAME, MB_OK | MB_ICONINFORMATION);
								GeheInSpielMenue();
							}
					// Anzahl der Versuche Anzeigen:
					if(iMaxVersuche == iVersuche+1)
						sprintf(byTemp, "Du hast noch einen Versuch!"); // Der letzte Versuch
					else
						sprintf(byTemp, "Du hast noch %d Versuche", iMaxVersuche-iVersuche);
					SetDlgItemText(hWnd, IDC_VERSUCHE, byTemp);
				break;
			}
		break;

		// Diese Nachricht bedeutet den sicheren 'Tot' f�r unseren Dialog und damit auch 
		// f�r unser Spiel:
		case WM_CLOSE:
			goto Close; // Springt zu den Zeilen an denen der Dialog geschlossen wird
    }
    return FALSE;
} // end SpielProc()

// Die ist die Funktion welche f�r den Credits-Dialog zust�ndig ist:
LRESULT CALLBACK SpielEinstellungenProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin SpielEinstellungenProc()
	char byTemp[256];
	
	switch(iMessage)
    {
        // Hallo...
		case WM_INITDIALOG:
				// Die letzten Spieleistellungen setzen:
				sprintf(byTemp, "%d", iMaxZahl);
				SetDlgItemText(hWnd, IDC_MAX_ZAHL, byTemp);
				sprintf(byTemp, "%d", iMaxVersuche);
				SetDlgItemText(hWnd, IDC_MAX_VERSUCHE, byTemp);
				// Fenster Aktualisieren:
				ShowWindow(hWnd, iCmdShow);
				UpdateWindow(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case IDC_SPIEL_STARTEN:
					// Dialog schlie�en und Spiel beginnen:
					EndDialog(hWnd, TRUE);
                return TRUE;
                
				case IDC_ABRECHEN:
				Close:
					// Murks... und Spiel nicht beginnen:
					EndDialog(hWnd, FALSE);
                return TRUE;

				case IDC_MAX_ZAHL:
					GetDlgItemText(hWnd, IDC_MAX_ZAHL, byTemp, 256);
					iMaxZahl = (short) atoi(byTemp);
				break;

				case IDC_MAX_VERSUCHE:
					GetDlgItemText(hWnd, IDC_MAX_VERSUCHE, byTemp, 256);
					iMaxVersuche = (short) atoi(byTemp);
				break;
            }
        break;

		// Adios...
		case WM_CLOSE:
			goto Close;
    }
    return FALSE;
} // end SpielEinstellungenProc()

// Die ist die Funktion welche f�r den Credits-Dialog zust�ndig ist:
LRESULT CALLBACK CreditsProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{ // begin CreditsProc()
	switch(iMessage)
    {
        // Hallo...
		case WM_INITDIALOG:
			// Verschiedene Texte in die Textfelder einsetzen:
            SetDlgItemText(hWnd, IDC_CREDITS_AUTOR, AUTOR_NAME);            
			SetDlgItemText(hWnd, IDC_CREDITS_BUILD_DATE, __DATE__);
            SetDlgItemText(hWnd, IDC_CREDITS_BUILD_TIME, __TIME__);
			// Fenster Aktualisieren:
			ShowWindow(hWnd, iCmdShow);
			UpdateWindow(hWnd);
		return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case IDC_CREDITS_OK:
				Close:
					// Murks...
					EndDialog(hWnd, FALSE);
                return TRUE;
            }
        break;

		// Adios...
		case WM_CLOSE:
			goto Close;
    }
    return FALSE;
} // end CreditsProc()

void GeheInSpiel(void)
{ // begin GeheInSpiel()
	char byTemp[256];
	
	// Spielmen� Elemente unsichtbar machen:
	ShowWindow(GetDlgItem(hWndSpiel, ID_DATEI_NEUES_SPIEL), FALSE);
	ShowWindow(GetDlgItem(hWndSpiel, ID_DATEI_BEENDEN), FALSE);
	ShowWindow(GetDlgItem(hWndSpiel, ID_HILFE_HILFE), FALSE);
	ShowWindow(GetDlgItem(hWndSpiel, ID_HILFE_CREDITS), FALSE);
	ShowWindow(GetDlgItem(hWndSpiel, ID_HILFE_HOMEPAGE), FALSE);
	// Spiel Elemente sichtbar machen:	
	ShowWindow(GetDlgItem(hWndSpiel, ID_SPIEL_ABRECHEN), TRUE);
	ShowWindow(GetDlgItem(hWndSpiel, IDC_SPIEL_ZAHL), TRUE);
	ShowWindow(GetDlgItem(hWndSpiel, IDC_SPIEL_ZAHL_TEXT), TRUE);
	ShowWindow(GetDlgItem(hWndSpiel, ID_SPIEL_OK), TRUE);
	ShowWindow(GetDlgItem(hWndSpiel, IDC_VERSUCHE), TRUE);
	// Anzahl der Versuche Anzeigen:
	if(iMaxVersuche == iVersuche+1)
		sprintf(byTemp, "Du hast noch einen Versuch!"); // Der letzte Versuch
	else
		sprintf(byTemp, "Du hast noch %d Versuche", iMaxVersuche-iVersuche);
	SetDlgItemText(hWndSpiel, IDC_VERSUCHE, byTemp);
} // end GeheInSpiel()

void GeheInSpielMenue(void)
{ // begin GeheInSpielMenue()
	// Spielmen� Elemente sichtbar machen:
	ShowWindow(GetDlgItem(hWndSpiel, ID_DATEI_NEUES_SPIEL), TRUE);
	ShowWindow(GetDlgItem(hWndSpiel, ID_DATEI_BEENDEN), TRUE);
	ShowWindow(GetDlgItem(hWndSpiel, ID_HILFE_HILFE), TRUE);
	ShowWindow(GetDlgItem(hWndSpiel, ID_HILFE_CREDITS), TRUE);
	ShowWindow(GetDlgItem(hWndSpiel, ID_HILFE_HOMEPAGE), TRUE);
	// Spiel Elemente unsichtbar machen:	
	ShowWindow(GetDlgItem(hWndSpiel, ID_SPIEL_ABRECHEN), FALSE);
	ShowWindow(GetDlgItem(hWndSpiel, IDC_SPIEL_ZAHL), FALSE);
	ShowWindow(GetDlgItem(hWndSpiel, IDC_SPIEL_ZAHL_TEXT), FALSE);
	ShowWindow(GetDlgItem(hWndSpiel, ID_SPIEL_OK), FALSE);
	ShowWindow(GetDlgItem(hWndSpiel, IDC_VERSUCHE), FALSE);
} // end GeheInSpielMenue()

///////////////////////////////////////////////////////////////////////////////
// Windows Midi-Abspiel Funktionen:
// Spielt ein Midifile ab:
BOOL PlayMidi(HWND hWnd, char *sFileName)
{ // begin PlayMidi()
    char buf[256];

    sprintf(buf, "open %s type sequencer alias MUSIC", sFileName);
    if(mciSendString("close all", NULL, 0, NULL) != 0)
        return FALSE;
    if(mciSendString(buf, NULL, 0, NULL) != 0)
        return FALSE;
    if(mciSendString("play MUSIC from 0", NULL, 0, hWnd) != 0)
        return FALSE;
    return TRUE;
} // end PlayMidi()

// Stopt die Midimusik:
BOOL StopMidi(void)
{ // begin StopMidi()
    if(mciSendString("close all", NULL, 0, NULL) != 0)
        return FALSE;
    return TRUE;
} // end StopMidi()
///////////////////////////////////////////////////////////////////////////////
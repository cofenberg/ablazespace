#ifndef __EINSTELLUNGEN_H__
#define __EINSTELLUNGEN_H__


// Typendefinationen: *********************************************************
typedef class
{
	private:

	public:
		BOOL bErststart;
		BOOL bGleichzeitigLaufen;
		BOOL bMusik;

		void Laden(char *);
		BOOL Speichern(char *);
} EINSTELLUNGEN;
///////////////////////////////////////////////////////////////////////////////

// Variablen: *****************************************************************
extern EINSTELLUNGEN Einstellungen;
///////////////////////////////////////////////////////////////////////////////


#endif // __EINSTELLUNGEN_H__
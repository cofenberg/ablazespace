3d_Demo:

Wichtig:
Diese Version ist noch in arbeit, also weder fehlerfrei noch umfangreich, 
daher gebe ich dne Quellcode noch nicht raus, da ich mich sonst f�r dessen 
unordnung sch�men m�sste :->.!


Tasten:
F2: Punkts an/aus 
F3: Texturen an/aus 
F4: Ausgef�llt an/aus 
F5: Linie an/aus 
F12: Frame Rate an/aus
4: Object nach links verschieben
6: Object nach rechts verschieben
8: Object nach oben verschieben
2: Object nach unten verschieben
9: Object nach hinten verschieben
3: Object nach vorne verschieben
SPACE: Object Rotieren
RETURN: Object ROTIEREN
Maus: Object Rotieren, Uhrsprungs Punks aussuchen
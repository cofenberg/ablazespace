/*
	Line.h

    Last change:
    	18.2.2000


    Autor:
    	Christian Ofenberg

	Mail: Christian-Ofenberg@gmx.de
	HomePage: http://members.tripod.de/Ofenberg


    Description:

		Draw_Line_Float: Draws a line bewteen two points. This funktion use
                         float calculations.
		Draw_Line_NoFloat: Draws a line bewteen two points. This funktion use
                           int calculations.
		SetVisibleArea: Sets the visible area
        clip2d_line: This funktion clips a line into a given area.

        For more informations read the lection Linear Interpolation on my
        homepage.
*/

enum // The clipping Regions:
{
	CR_LEFT = 0x01,
	CR_TOP = 0x04,
	CR_RIGHT = 0x02,
	CR_BOTTOM = 0x08,
};
// Checks the Regin of a given Point, if it is in the visible Space, reg is
// equal 0:
#define CHECK_REGION(reg, x, y)\
{\
    reg = 0;\
    if(x < VLeft)\
        reg |= CR_LEFT;\
    else\
	    if(x > VRight)\
    	    reg |= CR_RIGHT;\
    if(y < VTop)\
        reg |= CR_TOP;\
    else\
	    if(y > VBottom)\
    	    reg |= CR_BOTTOM;\
}

void Draw_Line_Float(UCHAR *screen, int x1, int y1, int x2, int y2,
					 UCHAR color);
void Draw_Line_NoFloat(UCHAR *screen, int x1, int y1, int x2, int y2,
				       UCHAR color);
void SetVisibleArea(int x1, int y1, int x2, int y2);
BOOL clip2d_line(BOOL *exists, int *c_x1, int *c_y1, int *c_x2, int *c_y2,
                 int x1, int y1, int x2, int y2);


void Draw_Line_Float(UCHAR *screen, int x1, int y1, int x2, int y2, UCHAR color)
{ // begin Draw_Line_NoFloat()
    BOOL exists;
    int width, height, length, multi;
    float x_pos, y_pos, x_increase, y_increase;

    if(Clipping)
    { // Because the line clipping is activated, we are clipping now:
       clip2d_line(&exists, &x1, &y1, &x2, &y2, x1, y1, x2, y2);
       if(!exists) // We needn't to draw the line
           return;
    }
    if(y2 < y1) // It is strong important, that y1 is smaller than y2!
    {
        SWAP_INT(x1, x2);
        SWAP_INT(y1, y2);
    }
    width = x2-x1; // Calculate delta x
    height = y2-y1; // Calculate delta y
    if(!width)
    { // We have only to draw a vertical line:
        for(; height > -1; height--)
			// Draw point
            screen[screen_size_x*((int) y1+height)+((int) x1)] = color;
    	return;
    }
    if(!height)
    { // We have only to draw a horizontal line:
        if(x1 < x2)
	        for(; width > -1; width--)
			// Draw point
    	        screen[screen_size_x*((int) y1)+((int) x1+width)] = color;
        else
	        for(; width < 0; width++)
			// Draw point
    	        screen[screen_size_x*((int) y1)+((int) x2-width)] = color;

    	return;
    }
    if(width < 0)
    {
	    width = -width;
	    multi = -1;
    }
    else
	    multi = 1;
    if(width < height)
    {
	    x_increase = (float) width / height; // Calculate line increase
	    x_increase *= multi;
	    y_increase = 1;
	    length = height + 1;
    }
    else
    {
	    x_increase = 1;
	    x_increase *= multi;
	    y_increase = (float) height / width; // Calculate line increase
	    length = width + 1;
    }
    x_pos = (float) x1; // lay down the x start position
    y_pos = (float) y1; // lay down the y start position
    for(; length > 0; length--)
    {
		// Draw point
	    screen[screen_size_x*((int) y_pos)+((int) x_pos)] = color;
	    x_pos += x_increase; // Calculate next point
  	    y_pos += y_increase; // Calculate next point
    }
} // end Draw_Line_Float()

void Draw_Line_NoFloat(UCHAR *screen, int x1, int y1, int x2, int y2,
					   UCHAR color)
{ // begin Draw_Line_NoFloat()
    BOOL exists;
	int width, height, length, x_pos, y_pos, x_increase, y_increase,
        multi;

    if(Clipping)
    { // Because the line clipping is activated, we are clipping now:
       clip2d_line(&exists, &x1, &y1, &x2, &y2, x1, y1, x2, y2);
       if(!exists) // We needn't to draw the line
           return;
    }
    if(y2 < y1) // It is strong important, that y1 is smaller than y2!
    {
        SWAP_INT(x1, x2);
        SWAP_INT(y1, y2);
    }
    width = x2-x1; // Calculate delta x
    height = y2-y1; // Calculate delta y
    if(!width)
    { // We have only to draw a vertical line:
        for(; height > -1; height--)
			// Draw point
            screen[screen_size_x*(y1+height)+x1] = color;
    	return;
    }
    if(!height)
    { // We have only to draw a horizontal line:
        if(x1 < x2)
	        for(; width > -1; width--)
				// Draw point
    	        screen[screen_size_x*y1+x1+width] = color;
        else
	        for(; width < 0; width++)
    			// Draw point
    	        screen[screen_size_x*y1+x2-width] = color;

    	return;
    }
    if(width < 0)
    {
	    width = -width;
	    multi = -1;
    }
    else
	    multi = 1;
    if(width < height)
    {
	    x_increase = width << 16;
	    x_increase /= height; // Calculate line increase
	    x_increase *= multi;
	    y_increase = 1 << 16;
	    length = height + 1;
	}
    else
    {
	    x_increase = 1 << 16;
	    x_increase *= multi;
	    y_increase = height << 16;
	    y_increase /= width; // Calculate line increase
	    length = width + 1;
    }
    x_pos = x1 << 16; // lay down the x start position
    y_pos = y1 << 16; // lay down the y start position
    for(; length > 0; length--)
    {
		// Draw point
	    screen[screen_size_x*(y_pos >> 16)+(x_pos >> 16)] = color;
	    x_pos += x_increase; // Calculate next x point
	    y_pos += y_increase; // Calculate next y point
    }
} // end Draw_Line_NoFloat()

void SetVisibleArea(int x1, int y1, int x2, int y2)
{ // begin SetVisibleArea()
    VLeft = x1;
    VTop = y1;
    VRight = x2;
    VBottom = y2;
} // end SetVisibleArea()

BOOL clip2d_line(BOOL *exists, int *c_x1, int *c_y1, int *c_x2, int *c_y2,
							   int x1, int y1, int x2, int y2)
/*
	exists: Is the line outside the clipping region? Than FALSE!
    c_x1, c_y1: The clipped first point.
    c_x2, c_y2: The clipped second point.
    x1, y1: The first point.
    x2, y2: The second point.
*/
{ // begin clip2d_line
	char reg1, reg2; // The regions of the two points
    int outside = 0;

    *exists = TRUE;
    CHECK_REGION(reg1, x1, y1); // Check the region of the first point
    CHECK_REGION(reg2, x2, y2); // Check the region of the second point
    if(reg1)
    	outside++; // The fist point is outside of the visible space
    if(reg2)
    	outside++; // The second point is outside of the visible space
    if(!outside)      // Both point are complet is the visible space, we do not
    	return FALSE; // require clipping
	// Now starts the clipping:
    while(reg1 | reg2)
    {
		if(reg1 & reg2)
        { // The line is not visible:
        	*exists = FALSE;
        	return TRUE;
        }
      	if(reg1 == 0)
        {
        	SWAP_INT(reg1, reg2);
         	SWAP_INT(x1, x2); SWAP_INT(y1, y2);
      	}
      	if(reg1 & CR_LEFT)
      	{
       	    y1 += ((y2-y1)*(VLeft-x1)/(x2-x1));
         	x1 = VLeft;
      	}
      	else
            if(reg1 & CR_RIGHT)
            {
                y1 += ((y2-y1)*(VRight-x1))/(x2-x1);
                x1 = VRight;
            }
            else
                 if(reg1 & CR_TOP)
                 {
                     x1 += ((x2-x1)*(VTop-y1))/(y2-y1);
                   	 y1 = VTop;
                 }
                 else
                     if(reg1 & CR_BOTTOM)
                     {
                         x1 += ((x2-x1)*(VBottom-y1))/(y2-y1);
                         y1 = VBottom;
                     }
	  CHECK_REGION(reg1, x1, y1); // Check the region point
	}
    *c_x1 = x1;
    *c_y1 = y1;
    *c_x2 = x2;
    *c_y2 = y2;
    return TRUE;
} // end clip2d_line

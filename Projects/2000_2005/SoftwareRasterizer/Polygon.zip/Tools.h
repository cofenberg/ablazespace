/*
	Tools.h

    Last change:
    	18.2.2000


    Description:

		doInit: Init the whole programm stuff
		CleanUp: Destroy the whole programm stuff
		DDRelease: Destroy some of the programm stuff
        DDLoadPalette: Loads a palette from a BMP file
        DDInit: Creats the windows and so on
		DDStartup: Inits Direct X
		DDFullConfigure: Configure a fullscreen window
		DDCreateFlipper: Creat the flipper
		DDCreateFakeFlipper: Creat a fake flipper
		CreateFullScreenWindow: How the name say
		CreateDesktopWindow: How the name say
		DDWinConfigure: Configure a window
		DDLoadBitmap: Loads a normal BMP bitmap
        DDCopyBitmap: Copy a bitmap
		DDColorMatch:
        DDSetColorKey: Set the transparent color of a bitmap
		DDFillSurface: // Fills a Bitmap with a given color
		UpdateFrame: // Shows the new picture
		FlipSurfaces: Flip surfaces
		DrawBltFast: Draws a area from a bitmap to an other bitmap
*/

// Rendering setups
#define MODE_OVERLAY  1
#define MODE_FULL	  2
#define MODE_WINDOWED 3

typedef unsigned char UCHAR;
char temp[256];
HANDLE hMutex = 0;
HINSTANCE g_hInstance;
LPDIRECTDRAW lpDD;
LPDIRECTDRAWSURFACE lpDDSPrimary;
LPDIRECTDRAWSURFACE lpDDSBack;
DWORD g_dwRenderSetup;
HWND g_hwnd;
BOOL g_bActive;
BOOL g_bAppIsActive = FALSE;
BOOL g_bReInitialize = FALSE;
BOOL g_ExitProgramm = FALSE;
BOOL g_bAllowWindowed = TRUE;
BOOL g_bFullScreen = TRUE;
RECT g_rcWindow;
LPDIRECTDRAWPALETTE	lpDDPalette;
LPDIRECTDRAWSURFACE	lpDDSOverlay;
LPDIRECTDRAWCLIPPER	lpDDClipper;


long FAR PASCAL WindowProc(HWND hWnd, UINT message, WPARAM wParam,
				           LPARAM lParam);

BOOL doInit(HINSTANCE hInstance, int nCmdShow);
void CleanUp(void);
void DDRelease(void);
extern "C" IDirectDrawPalette * DDLoadPalette(IDirectDraw *pdd,
											  LPCSTR szBitmap);
BOOL DDInit(void);
HRESULT DDStartup(LPDIRECTDRAW* lplpDD, GUID FAR* lpGUID, HWND hwnd,
                  BOOL bFullScreen);
HRESULT DDFullConfigure(LPDIRECTDRAW lpDD,
                        LPDIRECTDRAWSURFACE* lplpDDSPrimary,
                        LPDIRECTDRAWSURFACE* lplpDDSBack);
HRESULT DDCreateFlipper(LPDIRECTDRAW lpDD,
                        LPDIRECTDRAWSURFACE* lplpDDSPrimary,
                        LPDIRECTDRAWSURFACE* lplpDDSBack,
                        DWORD dwBufferCount);
HRESULT DDCreateFakeFlipper(LPDIRECTDRAW lpDD,
                            LPDIRECTDRAWSURFACE* lplpDDSPrimary,
                            LPDIRECTDRAWSURFACE* lplpDDSBack);
HWND CreateFullScreenWindow(HINSTANCE hInstance,
							WNDPROC WindowProc);
HWND CreateDesktopWindow(HINSTANCE, WNDPROC, DWORD, DWORD);
HRESULT DDWinConfigure(LPDIRECTDRAW, LPDIRECTDRAWSURFACE*,
					   LPDIRECTDRAWSURFACE*, LPDIRECTDRAWCLIPPER*,
					   LPDIRECTDRAWSURFACE*, HWND);
extern "C" IDirectDrawSurface * DDLoadBitmap(IDirectDraw *pdd, LPCSTR szBitmap,
											 int dx, int dy, int SystemMem);
extern "C" HRESULT DDCopyBitmap(IDirectDrawSurface *pdds, HBITMAP hbm, int x,
							    int y, int dx, int dy);
extern "C" DWORD DDColorMatch(IDirectDrawSurface *pdds, COLORREF rgb);
extern "C" HRESULT DDSetColorKey(IDirectDrawSurface *pdds, COLORREF rgb);
HRESULT DDFillSurface(LPDIRECTDRAWSURFACE lpDDSurface, DWORD color);
HRESULT UpdateFrame(BOOL bFull);
HRESULT FlipSurfaces(void);
RECT DrawBltFast(RECT rcRahmen, LPDIRECTDRAWSURFACE ToPicture, short x, short y,
                 LPDIRECTDRAWSURFACE FromPicture, RECT rcRect, short Trans);

#include "Mouse.h"

class MOUSE Mouse;

BOOL doInit(HINSTANCE hInstance, int nCmdShow)
{ // begin doInit()
	LPDIRECTDRAWPALETTE     lpDDPal;        // DirectDraw palette

    g_hInstance = hInstance;
  ////////////////////////////////////////////////////
    // We prevent now, that the programm runs twice:
    hMutex = OpenMutex(SYNCHRONIZE, FALSE, MUTEX_NAME);
    if (hMutex != 0)
    {
        CloseHandle(hMutex);
        sprintf(temp, TITLE" is running!!");
        MessageBox(0, temp, TITLE, MB_ICONERROR | MB_OK);
        return(FALSE);
    }
    else
        hMutex = CreateMutex(NULL, TRUE, MUTEX_NAME);
  ////////////////////////////////////////////////////
    if FAILED(DDInit())
	{
        MessageBox( NULL, "DirectDraw Init FAILED", "ERROR", MB_OK );
    	CleanUp();
		return FALSE;
	}
    lpDDPal = DDLoadPalette(lpDD, "palette.bmp");
    lpDDSPrimary->SetPalette(lpDDPal);
    Mouse.Init();
	ShowWindow( g_hwnd, SW_SHOW );
    return TRUE;
} // end doInit()

void CleanUp(void)
{ // begin CleanUp()
    DDRelease();
    if(g_hwnd)
        DestroyWindow(g_hwnd);
} // end CleanUp()

void DDRelease(void)
{ // begin DDRelease()
    if(lpDD != NULL)
    {
        // The clipper and palette, if they exist, will destroy
        // themselves when the primary is released.
        if(lpDDSBack != NULL)
        {
            // This will fail if attempted on a complex surface
            lpDDSBack->Release();
            lpDDSBack = NULL;
        }
        if(lpDDSPrimary != NULL)
        {
            // This will release any associated backbuffers as
            // well, if it's a complex surface.
            lpDDSPrimary->Release();
            lpDDSPrimary = NULL;
        }
        lpDD->Release();
        lpDD = NULL;
    }
} // end DDRelease()

extern "C" IDirectDrawPalette * DDLoadPalette(IDirectDraw *pdd, LPCSTR szBitmap)
{ // begin IDirectDrawPalette()
    IDirectDrawPalette* ddpal;
    int                 i;
    int                 n;
    int                 fh;
    HRSRC               h;
    LPBITMAPINFOHEADER  lpbi;
    PALETTEENTRY        ape[256];
    RGBQUAD *           prgb;

    // build a 332 palette as the default.
    for (i=0; i<256; i++)
    {
        ape[i].peRed   = (BYTE)(((i >> 5) & 0x07) * 255 / 7);
        ape[i].peGreen = (BYTE)(((i >> 2) & 0x07) * 255 / 7);
        ape[i].peBlue  = (BYTE)(((i >> 0) & 0x03) * 255 / 3);
        ape[i].peFlags = (BYTE)0;
    }
    // get a pointer to the bitmap resource.
    if(szBitmap && (h = FindResource(NULL, szBitmap, RT_BITMAP)))
    {
        lpbi = (LPBITMAPINFOHEADER)LockResource(LoadResource(NULL, h));
        if (!lpbi)
            OutputDebugString("lock resource failed\n");
        prgb = (RGBQUAD*)((BYTE*)lpbi + lpbi->biSize);
        if (lpbi == NULL || lpbi->biSize < sizeof(BITMAPINFOHEADER))
            n = 0;
        else if (lpbi->biBitCount > 8)
            n = 0;
        else if (lpbi->biClrUsed == 0)
            n = 1 << lpbi->biBitCount;
        else
            n = lpbi->biClrUsed;
        //  a DIB color table has its colors stored BGR not RGB
        //  so flip them around.
        for(i=0; i<n; i++)
        {
            ape[i].peRed   = prgb[i].rgbRed;
            ape[i].peGreen = prgb[i].rgbGreen;
            ape[i].peBlue  = prgb[i].rgbBlue;
            ape[i].peFlags = 0;
        }
    }
    else
        if(szBitmap && (fh = _lopen(szBitmap, OF_READ)) != -1)
        {
            BITMAPFILEHEADER bf;
            BITMAPINFOHEADER bi;
            _lread(fh, &bf, sizeof(bf));
            _lread(fh, &bi, sizeof(bi));
            _lread(fh, ape, sizeof(ape));
            _lclose(fh);
            if(bi.biSize != sizeof(BITMAPINFOHEADER))
                n = 0;
            else
            	if (bi.biBitCount > 8)
                	n = 0;
                else
                	if (bi.biClrUsed == 0)
                		n = 1 << bi.biBitCount;
                    else
			        	n = bi.biClrUsed;
            //  a DIB color table has its colors stored BGR not RGB
            //  so flip them around.
            for(i = 0; i < n; i++)
            {
                BYTE r = ape[i].peRed;
                ape[i].peRed  = ape[i].peBlue;
                ape[i].peBlue = r;
            }
        }
    pdd->CreatePalette(DDPCAPS_8BIT, ape, &ddpal, NULL);
    return ddpal;
} // end IDirectDrawPalette

BOOL DDInit(void)
{ // begin DDInit()
	if(GetSystemMetrics( SM_CXSCREEN ) == screen_size_x)
	{
		// The desktop is already in 640x480. We can't use
		// windowed mode because there's not enough room for
		// our 640x480 playing field and the window.
		g_bAllowWindowed = FALSE;
		g_bFullScreen = TRUE;
	}

	if(g_bFullScreen)
		g_hwnd = CreateFullScreenWindow(g_hInstance, WindowProc);
	else
		g_hwnd = CreateDesktopWindow(g_hInstance, WindowProc, screen_size_x,
        							 screen_size_y);

	if(g_hwnd == NULL)
    	return FALSE;
    ShowWindow(g_hwnd,SW_SHOWNORMAL);
	if FAILED(DDStartup(&lpDD, NULL, g_hwnd, g_bFullScreen))
	{
        OutputDebugString( "DDStartup failed.\n" );
        return FALSE;
    }
    if(g_bFullScreen)
	    if FAILED(DDFullConfigure(lpDD, &lpDDSPrimary, &lpDDSBack))
            return FALSE;
		else
			g_dwRenderSetup = MODE_FULL;
    else
        if FAILED(DDWinConfigure(lpDD, &lpDDSPrimary, &lpDDSBack,
                                 &lpDDClipper, &lpDDSOverlay,
								 g_hwnd))
            return FALSE;
		else
			if(lpDDSOverlay)
				g_dwRenderSetup = MODE_OVERLAY;
			else
				g_dwRenderSetup = MODE_WINDOWED;
    return TRUE;
} // end DDInit()

HRESULT DDStartup(LPDIRECTDRAW* lplpDD, GUID FAR* lpGUID, HWND hwnd,
                  BOOL bFullScreen)
{ // begin DDStartup()
    HRESULT ddrval;

    ddrval = DirectDrawCreate(lpGUID, lplpDD, NULL);
    if FAILED( ddrval )
        return ddrval;
    if(bFullScreen)
    {
        // If fullscreen, get fullscreen exclusive mode
        ddrval = (*lplpDD)->SetCooperativeLevel(hwnd,
                            DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN);
        if FAILED(ddrval)
        {
            OutputDebugString(
				"DDStartup: Couldn't set exclusive mode.\n");
            return ddrval;
        }
        OutputDebugString(
			"DDStartup: Setting exclusive mode...\n");
        if SUCCEEDED(ddrval)
        {
	        ddrval = (*lplpDD)->SetDisplayMode(screen_size_x, screen_size_y, 8);
            return ddrval;
        }
        else
            return ddrval;
    }
    else
    {
        // otherwise, set normal mode for use in a window
        ddrval = (*lplpDD)->SetCooperativeLevel(hwnd, DDSCL_NORMAL);
        OutputDebugString("DDStartup: Setting windowed mode...\n");
    }
    return ddrval;
} // end DDStartup()

HRESULT DDFullConfigure(LPDIRECTDRAW lpDD,
                        LPDIRECTDRAWSURFACE* lplpDDSPrimary,
                        LPDIRECTDRAWSURFACE* lplpDDSBack)
{ // begin DDFullConfigure()
    // Attempt flipping surface with 2 back buffers
    if FAILED(DDCreateFlipper(lpDD, lplpDDSPrimary, lplpDDSBack, 2))
    {
        // Couldn't get two, try one.
        if FAILED(DDCreateFlipper(lpDD, lplpDDSPrimary, lplpDDSBack, 1))
        {
            // Couldn't even get one. Maybe flipping isn't supported
            // or we have a very small display memory
            if FAILED(DDCreateFakeFlipper(lpDD, lplpDDSPrimary,
                                                    lplpDDSBack))
            {
                OutputDebugString(
					"DDFullConfigure: Couldn't create fake flipper.\n" );
                return FALSE;
            }
            else
                OutputDebugString(
					"DDFullConfigure: Using fake flipper.\n" );
        }
        return(NO_ERROR);
    }
    return TRUE;
} // end DDFullConfigure()

HRESULT DDCreateFlipper(LPDIRECTDRAW lpDD,
                        LPDIRECTDRAWSURFACE* lplpDDSPrimary,
                        LPDIRECTDRAWSURFACE* lplpDDSBack,
                        DWORD dwBufferCount)
{ // begin DDCreateFlipper()
    DDSURFACEDESC	ddsd;
    DDSCAPS			ddscaps;
    HRESULT			ddrval;

    ddsd.dwSize = sizeof(ddsd);
    // Create the primary surface with back buffers
    ddsd.dwFlags = DDSD_CAPS | DDSD_BACKBUFFERCOUNT;
    ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE |
    					  DDSCAPS_FLIP |
                          DDSCAPS_COMPLEX |
                          DDSCAPS_VIDEOMEMORY;
    ddsd.dwBackBufferCount = dwBufferCount;
	ddsd.dwWidth = screen_size_x;
	ddsd.dwHeight = screen_size_y;
    ddrval = lpDD->CreateSurface(&ddsd, lplpDDSPrimary, NULL);
    if FAILED(ddrval)
    	return ddrval;
    // Get a pointer to the back buffer
    ddscaps.dwCaps = DDSCAPS_BACKBUFFER;
    ddrval = (*lplpDDSPrimary)->GetAttachedSurface(&ddscaps, lplpDDSBack);
    return ddrval;
} // end DDCreateFlipper()

HRESULT DDCreateFakeFlipper(LPDIRECTDRAW lpDD,
                            LPDIRECTDRAWSURFACE* lplpDDSPrimary,
                            LPDIRECTDRAWSURFACE* lplpDDSBack)
{ // begin DDCreateFakeFlipper()
    DDSURFACEDESC	ddsd;
    HRESULT			ddrval;

    ddsd.dwSize = sizeof(ddsd);
    // Create the primary surface
    ddsd.dwFlags = DDSD_CAPS;
    ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE;
    ddrval = lpDD->CreateSurface(&ddsd, lplpDDSPrimary, NULL);
    if FAILED(ddrval)
    {
        OutputDebugString(
			"DDCreateFakeFlipper: Couldn't create primary.\n" );
        return ddrval;
    }
    // Create an offscreen surface to serve as the backbuffer
    ddsd.dwFlags = DDSD_CAPS | DDSD_WIDTH | DDSD_HEIGHT;
    ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN;
    ddsd.dwWidth = screen_size_x;
    ddsd.dwHeight = screen_size_y;
    ddrval = lpDD->CreateSurface(&ddsd, lplpDDSBack, NULL);
    if FAILED(ddrval)
    {
        OutputDebugString(
			"DDCreateFakeFlipper: Couldn't create backbuffer.\n" );
        return ddrval;
    }
    OutputDebugString( "DDCreateFakeFlipper: Using fake flipper.\n" );
    return ddrval;
} // end DDCreateFakeFlipper()

HWND CreateFullScreenWindow(HINSTANCE hInstance,
							WNDPROC WindowProc)
{ // begin CreateFullScreenWindow()
    WNDCLASS    wc;
    HWND        hwnd;

     // Set up and register window class
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = WindowProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = hInstance;
    wc.hIcon = LoadIcon(hInstance, IDI_APPLICATION);
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = NULL;
    wc.lpszMenuName = NAME;
    wc.lpszClassName = NAME;
    RegisterClass(&wc);
    // Create a fullscreen window
    hwnd = CreateWindowEx(WS_EX_TOPMOST,
                          NAME,
                          TITLE,
                          WS_POPUP,
                          0, 0,
                          GetSystemMetrics(SM_CXSCREEN),
                          GetSystemMetrics(SM_CYSCREEN),
                          NULL,
                          NULL,
                          hInstance,
                          NULL);
    if(!hwnd)
        return NULL;
    return hwnd;
} // end CreateFullScreenWindow()

HWND CreateDesktopWindow(HINSTANCE hInstance,
                         WNDPROC WindowProc,
                         DWORD dwWidth,  // client area width
                         DWORD dwHeight)  // client area height
{ // begin CreateDesktopWindow()
    WNDCLASS    wc;
    RECT        rc;
    HWND        hwnd;

     // Set up and register window class
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = WindowProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = hInstance;
    wc.hIcon = LoadIcon( hInstance, IDI_APPLICATION );
    wc.hCursor = LoadCursor( NULL, IDC_ARROW );
    wc.hbrBackground = NULL;
    wc.lpszMenuName = NAME;
    wc.lpszClassName = NAME;
    RegisterClass( &wc );
    // Create a window
    hwnd = CreateWindowEx(
        0,
        NAME,
        TITLE,
        WS_SYSMENU | WS_CAPTION | WS_MINIMIZEBOX,
        CW_USEDEFAULT,
        SW_SHOW,
        0,
        0,
        NULL,
        NULL,
        hInstance,
        NULL );
    if(!hwnd)
        return NULL;
    // Set the desired size for the *client* area of the window.
    SetRect(&rc, 0, 0, dwWidth, dwHeight);
    // Adjust that to a size that includes the border, etc.
    AdjustWindowRectEx(&rc,
                GetWindowStyle(hwnd),     // style of our main window
                GetMenu(hwnd) != NULL,    // does the window have a menu?
                GetWindowExStyle(hwnd));  // extended style of the main window
    // Adjust the window to the new size
    MoveWindow(hwnd,
               CW_USEDEFAULT,
               CW_USEDEFAULT,
               rc.right-rc.left,
               rc.bottom-rc.top,
               FALSE);
    return hwnd;
} // end CreateDesktopWindow()

HRESULT DDWinConfigure(LPDIRECTDRAW lpDD,
					   LPDIRECTDRAWSURFACE* lplpDDSPrimary,
					   LPDIRECTDRAWSURFACE* lplpDDSBack,
					   LPDIRECTDRAWCLIPPER* lplpDDClipper,
					   LPDIRECTDRAWSURFACE* lplpDDOverlay,
					   HWND hWnd )
{ // begin DDWinConfigure()
    HRESULT	ddrval;

	ddrval = DDCreateFakeFlipper(lpDD, lplpDDSPrimary, lplpDDSBack);
	if FAILED(ddrval)
    	return ddrval;
	// Create a clipper and attach it to the primary surface
	ddrval = lpDD->CreateClipper(0, lplpDDClipper, NULL);
	if FAILED(ddrval)
    	return ddrval;
	ddrval = (*lplpDDClipper)->SetHWnd(0, hWnd);
	if FAILED(ddrval)
    	return ddrval;
	(*lplpDDSPrimary)->SetClipper(*lplpDDClipper);
	// So clipper will go away "automatically" when the primary
	// is released.
	(*lplpDDClipper)->Release();
	// Load art where ever it will fit
	return NO_ERROR;
} // end DDWinConfigure()

extern "C" IDirectDrawSurface * DDLoadBitmap(IDirectDraw *pdd, LPCSTR szBitmap,
											 int dx, int dy, int SystemMem)
{ // begin DDLoadBitmap()
    HBITMAP             hbm;
    BITMAP              bm;
    DDSURFACEDESC       ddsd;
    IDirectDrawSurface *pdds;

    //  try to load the bitmap as a resource, if that fails, try it as a file
    hbm = (HBITMAP)LoadImage(GetModuleHandle(NULL), szBitmap, IMAGE_BITMAP, dx,
                             dy, LR_CREATEDIBSECTION);
    if(hbm == NULL)
		hbm = (HBITMAP)LoadImage(NULL, szBitmap, IMAGE_BITMAP, dx, dy,
        						 LR_LOADFROMFILE|LR_CREATEDIBSECTION);
    if(hbm == NULL)
        return NULL;
    // get size of the bitmap
    GetObject(hbm, sizeof(bm), &bm);      // get size of bitmap
    // create a DirectDrawSurface for this bitmap
    ZeroMemory(&ddsd, sizeof(ddsd));
    ddsd.dwSize = sizeof(ddsd);
    ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH;
	if(SystemMem == TRUE)
	    ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_SYSTEMMEMORY;
    else
    	ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN;
    ddsd.dwWidth = bm.bmWidth;
    ddsd.dwHeight = bm.bmHeight;
    if(pdd->CreateSurface(&ddsd, &pdds, NULL) != DD_OK)
        return NULL;
    DDCopyBitmap(pdds, hbm, 0, 0, 0, 0);
    DeleteObject(hbm);
    return pdds;
} // end DDLoadBitmap()

extern "C" HRESULT DDCopyBitmap(IDirectDrawSurface *pdds, HBITMAP hbm, int x,
					            int y, int dx, int dy)
{ // begin DDCopyBitmap()
    HDC                 hdcImage;
    HDC                 hdc;
    BITMAP              bm;
    DDSURFACEDESC       ddsd;
    HRESULT             hr;

    if(hbm == NULL || pdds == NULL)
        return E_FAIL;
    // make sure this surface is restored.
    pdds->Restore();
    //  select bitmap into a memoryDC so we can use it.
    hdcImage = CreateCompatibleDC(NULL);
    if (!hdcImage)
        OutputDebugString("createcompatible dc failed\n");
    SelectObject(hdcImage, hbm);
    // get size of the bitmap
    GetObject(hbm, sizeof(bm), &bm);    // get size of bitmap
    dx = dx == 0 ? bm.bmWidth  : dx;    // use the passed size, unless zero
    dy = dy == 0 ? bm.bmHeight : dy;
    // get size of surface.
    ddsd.dwSize = sizeof(ddsd);
    ddsd.dwFlags = DDSD_HEIGHT | DDSD_WIDTH;
    pdds->GetSurfaceDesc(&ddsd);
    if((hr = pdds->GetDC(&hdc)) == DD_OK)
    {
        StretchBlt(hdc, 0, 0, ddsd.dwWidth, ddsd.dwHeight, hdcImage, x, y, dx,
                   dy, SRCCOPY);
        pdds->ReleaseDC(hdc);
    }
    DeleteDC(hdcImage);
    return hr;
} // end DDCopyBitmap()

extern "C" DWORD DDColorMatch(IDirectDrawSurface *pdds, COLORREF rgb)
{ // begin DDColorMatch()
    COLORREF rgbT;
    HDC hdc;
    DWORD dw = CLR_INVALID;
    DDSURFACEDESC ddsd;
    HRESULT hres;

    //  use GDI SetPixel to color match for us
    if(rgb != CLR_INVALID && pdds->GetDC(&hdc) == DD_OK)
    {
        rgbT = GetPixel(hdc, 0, 0);             // save current pixel value
        SetPixel(hdc, 0, 0, rgb);               // set our value
        pdds->ReleaseDC(hdc);
    }
    // now lock the surface so we can read back the converted color
    ddsd.dwSize = sizeof(ddsd);
    while((hres = pdds->Lock(NULL, &ddsd, 0, NULL)) == DDERR_WASSTILLDRAWING);
    if(hres == DD_OK)
    {
        dw  = *(DWORD *)ddsd.lpSurface;                     // get DWORD
        dw &= (1 << ddsd.ddpfPixelFormat.dwRGBBitCount)-1;  // mask it to bpp
        pdds->Unlock(NULL);
    }
    //  now put the color that was there back.
    if(rgb != CLR_INVALID && pdds->GetDC(&hdc) == DD_OK)
    {
        SetPixel(hdc, 0, 0, rgbT);
        pdds->ReleaseDC(hdc);
    }
    return dw;
} // end DDColorMatch()

extern "C" HRESULT DDSetColorKey(IDirectDrawSurface *pdds, COLORREF rgb)
{ // begin DDSetColorKey()
    DDCOLORKEY          ddck;

    ddck.dwColorSpaceLowValue  = DDColorMatch(pdds, rgb);
    ddck.dwColorSpaceHighValue = ddck.dwColorSpaceLowValue;
    return pdds->SetColorKey(DDCKEY_SRCBLT, &ddck);
} // end DDSetColorKey()

HRESULT DDFillSurface(LPDIRECTDRAWSURFACE lpDDSurface, DWORD color)
{ // begin DDFillSurface()
    DDBLTFX     ddbltfx;
    HRESULT     ddrval;

    ddbltfx.dwSize = sizeof(ddbltfx);
    ddbltfx.dwFillColor = color;
    ddrval = lpDDSurface->Blt(NULL,
                              NULL,
                              NULL,
                              DDBLT_COLORFILL | DDBLT_WAIT,
                              &ddbltfx);

    return ddrval;
} // end DDFillSurface()

HRESULT UpdateFrame(BOOL bFull)
{ // begin UpdateFrame()
	if(!bFull)
        return TRUE;
	Mouse.DrawOnBitmap(lpDDSBack);
    if FAILED(FlipSurfaces())
    {
        OutputDebugString( "UpdateFrame: Couldn't flip.\n" );
        return FALSE;
    }
    return TRUE;
} // end UpdateFrame()

HRESULT FlipSurfaces(void)
{ // begin FlipSurfaces()
    HRESULT ddrval;

	ddrval = lpDDSPrimary->Flip(NULL, DDFLIP_WAIT);
    return ddrval;
} // end FlipSurfaces()

RECT DrawBltFast(RECT rcRahmen, LPDIRECTDRAWSURFACE ToPicture, short x, short y,
                 LPDIRECTDRAWSURFACE FromPicture, RECT rcRect, short Trans)
{ // begin DrawBltFast()
    short b = (short)(rcRect.right-rcRect.left);
    short h = (short)(rcRect.bottom-rcRect.top);

    if(x+b < rcRahmen.left || y+h < rcRahmen.top ||
		x > rcRahmen.right || y > rcRahmen.bottom)
        return rcRect;
    if(x < rcRahmen.left)
	{
    	rcRect.left += (rcRahmen.left-x);
    	x = (short)rcRahmen.left;
    }
    if(y < rcRahmen.top)
	{
    	rcRect.top += (rcRahmen.top-y);
    	y = (short)rcRahmen.top;
    }
    if(x+b > rcRahmen.right)
		rcRect.right += rcRahmen.right-x-b;
    if(y+h > rcRahmen.bottom)
		rcRect.bottom += rcRahmen.bottom-y-h;
    ToPicture->BltFast(x, y, FromPicture, &rcRect, Trans);
    return rcRect;
} // end DrawBltFast()


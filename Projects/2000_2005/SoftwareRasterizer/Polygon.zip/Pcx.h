/*
	Pcx.h

    Pcx loading and saving Funktions.
*/

#define PCX_ERROR_NONE 0
#define PCX_ERROR_OPENING 1
#define PCX_ERROR_WRITING 2

/* PCX Header data type */
typedef struct	{
	UCHAR		Manufacturer;
	UCHAR		Version;
	UCHAR		Encoding;
	UCHAR		BitsPerPixel;
	short		Xmin;
	short		Ymin;
	short		Xmax;
	short		Ymax;
	short		Hdpi;
	short		Vdpi;
	UCHAR		ColorMap[16][3];
	UCHAR		Reserved;
	UCHAR		Nplanes;
	short		BytesPerLine;
	UCHAR		filler[60];
} PCXHeader;

typedef struct
{
    PCXHeader hdr;
    UCHAR   *bitmap;
    UCHAR   pal[768];
    unsigned long imagebytes;
    unsigned short width,height;
} PcxFile;
enum
{
	NORMAL,
	RLE
};
PcxFile pcxGlobal;	     // data structure for reading PCX files
UCHAR colordat[65000];


UCHAR *LoadPCX(char *);
int SavePcx(char *filename, UCHAR *bmp, UCHAR *palette, int x_size, int y_size);
int pcx_encode_line(UCHAR *inBuff, int inLen, FILE * fp);
int pcx_encode_byte(UCHAR byt, UCHAR cnt, FILE * fid);

// This routine loads a 256 color PCX file.
UCHAR *LoadPCX(char *filename)
{ // begin LoadPCX()
    long i;
    int mode = NORMAL, nbytes;
    char abyte,*p;
    FILE *f;
    PcxFile *pcx;

	pcx = &pcxGlobal;
    f = fopen(filename, "rb");
    if(!f)
    	return NULL;
	fread(&pcx->hdr,sizeof(PCXHeader),1,f);
	pcx->width = 1+pcx->hdr.Xmax-pcx->hdr.Xmin;
	pcx->height = 1+pcx->hdr.Ymax-pcx->hdr.Ymin;
	pcx->imagebytes = (unsigned long)(pcx->width*pcx->height);
	pcx->bitmap=(unsigned char*)malloc(pcx->imagebytes+4);
	if(!pcx->bitmap)
    {
		fclose(f);
	    return(NULL);
    }
	for (i = 0; i < pcx->imagebytes; i++)
    {
	    if(mode == NORMAL)
		{
			abyte = fgetc(f);
			if((unsigned char)abyte > 0xbf)
		    {
			    nbytes = abyte & 0x3f;
			    abyte = fgetc(f);
			    if(--nbytes > 0)
					mode = RLE;
		    }
		}
	    else
        	if(--nbytes == 0)
		    	mode = NORMAL;
	    pcx->bitmap[i+4] = abyte;
    }
	fseek(f, -768L, SEEK_END);      // get palette from pcx file
	fread(colordat, 768, 1, f);
	p = (char *) colordat;
	for(i = 0; i < 768; i++)	       // bit shift palette
    	*p++ = *p >>2;
    fclose(f);
	p = (char *)pcx->bitmap;
	(*(short *)p) = pcx->width;
	p += sizeof(short);
	(*(short *)p) = pcx->height;
	return(pcx->bitmap);	     // return success
} // end LoadPCX() */

/*// This routine saves a 256 color PCX file.
int SavePcx(char *filename, UCHAR *bmp, UCHAR *palette, int x_size, int y_size)
{ // begin SavePcx()
	int retval;
	int i;
	UCHAR data;
	PCXHeader header;
	FILE * PCXfile;

	memset(&header, 0, sizeof(PCXHeader));
	header.Manufacturer = 10;
	header.Encoding = 1;
	header.Nplanes = 1;
	header.BitsPerPixel = 8;
	header.Version = 5;
	header.Xmax = x_size-1;
	header.Ymax = y_size-1;
	header.BytesPerLine = x_size;
	PCXfile = fopen(filename , "wb");
	if(!PCXfile)
		return PCX_ERROR_OPENING;
	if(fwrite(&header, sizeof(PCXHeader), 1, PCXfile) != 1)
    {
		fclose(PCXfile);
		return PCX_ERROR_WRITING;
	}
	for(i = 0; i < y_size; i++)
    {
		if(!pcx_encode_line(&bmp[i*x_size], x_size, PCXfile))
        {
			fclose(PCXfile);
			return PCX_ERROR_WRITING;
		}
	}
	// Mark an extended palette
	data = 12;
	if(fwrite(&data, 1, 1, PCXfile)!= 1)
    {
		fclose(PCXfile);
		return PCX_ERROR_WRITING;
	}
	// Write the extended palette
	for(i = 0; i < 768; i++)
		palette[i] <<= 2;
	retval = fwrite(palette, 768, 1, PCXfile);
	for(i = 0; i < 768; i++)
		palette[i] >>= 2;
	if(retval !=1)
    {
		fclose(PCXfile);
		return PCX_ERROR_WRITING;
	}
	fclose(PCXfile);
	return PCX_ERROR_NONE;
} // end SavePcx()

// returns number of bytes written into outBuff, 0 if failed
int pcx_encode_line(UCHAR *inBuff, int inLen, FILE * fp)
{ // begin pcx_encode_line()
	unsigned char this last;
	int srcIndex, i;
	register int total;
	register UCHAR runCount; // max single runlength is 63
	total = 0;
	last = *(inBuff);
	runCount = 1;

	for(srcIndex = 1; srcIndex < inLen; srcIndex++)
    {
		this = *(++inBuff);
		if (this == last)
        {
			runCount++;	// it encodes
			if(runCount == 63)
            {
				if(!(i = pcx_encode_byte(last, runCount, fp)))
					return(0);
				total += i;
				runCount = 0;
			}
		}
        else
        { // this != last
			if(runCount)
            {
				if(!(i = pcx_encode_byte(last, runCount, fp)))
					return(0);
				total += i;
			}
			last = this;
			runCount = 1;
		}
	}
	if(runCount)
    { // finish up
		if(!(i = pcx_encode_byte(last, runCount, fp)))
			return 0;
		return total + i;
	}
	return total;
} // end pcx_encode_line()

// subroutine for writing an encoded byte pair
// returns count of bytes written, 0 if error
int pcx_encode_byte(UCHAR byt, UCHAR cnt, FILE * fid)
{ // begin pcx_encode_byte()
	if(cnt)
    {
		if((cnt == 1) && (0xc0 != (0xc0 & byt)))
        {
			if(EOF == putc((int)byt, fid))
				return 0; // disk write error (probably full)
			return 1;
		}
        else
        {
			if(EOF == putc((int)0xC0 | cnt, fid))
				return 0; // disk write error
			if(EOF == putc((int)byt, fid))
				return 0; // disk write error
			return 2;
		}
	}
	return 0;
} // end pcx_encode_byte()
  */

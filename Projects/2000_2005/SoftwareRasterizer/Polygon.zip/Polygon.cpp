/*
	Polygon.cpp

    Last chance:
    	18.2.2000


    Autor:
    	Christian Ofenberg

	Mail: Christian-Ofenberg@gmx.de
	HomePage: http://members.tripod.de/Ofenberg


    Description:

    	Draw_SoldPolygon_Float: Draws a simple colored polygon. This funktion
        						use float calculations.
    	Draw_SoldPolygon_NoFloat: Draws a simple colored polygon. This funktion
        						  use int calculations.
        scan_soldpolyline_Float: Store every x pos of a scan line. This
        						 funktion use float calculations.
        scan_soldpolyline_NoFloat: Store every x pos of a scan line. This
        						   funktion use int calculations.

        Draw_ShadePolygon_Float: Draws a shade polygon. This funktion
        						 use float calculations.
        Draw_ShadePolygon_NoFloat: Draws a shade polygon. This funktion
        						   use int calculations.
        scan_shadepolyline_Float: Store every x pos of a scan line. This
        						  funktion use float calculations.
        scan_shadepolyline_NoFloat: Store every x pos of a scan line. This
        						    funktion use int calculations.

        Draw_TexturePolygon_Float: Draws a texture polygon. This funktion
        						   use float calculations.
        Draw_TexturePolygon_NoFloat: Draws a texture polygon. This funktion
        						     use int calculations.
        scan_texturepolyline_Float: Store every x pos of a scan line. This
            						funktion use float calculations.
        scan_texturepolyline_NoFloat: Store every x pos of a scan line. This
                                      funktion use int calculations.

        Draw_TextureShadePolygon_Float: Draws a texture shade polygon. This
        						        funktion use float calculations.
        Draw_TextureShadePolygon_NoFloat: Draws a texture shade polygon. This
        						          funktion use int calculations.
        scan_textureshadepolyline_Float: Store every x pos of a scan line. This
        						         funktion use float calculations.
        scan_textureshadepolyline_NoFloat:Store every x pos of a scan line. This
        						          funktion use int calculations.
*/

#define NAME "Polygon"
#define TITLE "Polygon"
#define MUTEX_NAME "Polygon"
#define NO_AKTIV -1
#define IDB_BITMAP_MOUSE 1
// The polygon draw modes:
enum
{
	DRAW_SOLD,
	DRAW_SHADE,
	DRAW_TEXTURE,
	DRAW_TEXTURE_SHADE,
};

// Swaps two int Variables:
#define SWAP_INT(a, b) { intswap = a; a = b; b = intswap; }
// Swaps two char Variables:
#define SWAP_CHAR(a, b) { charswap = a; a = b; b = charswap; }
#define SMALL_NUMBER 0.1

#include <windows.h>
#include <windowsx.h>
#include <ddraw.h>
#include <stdio.h>
#include <mmsystem.h>


BOOL WindowMode = 0; // Should the programm eun in a window?
int intswap; // Temp Variable for int Type
UCHAR charswap; // Temp Variable for char Type
int screen_size_x = 640, screen_size_y = 480; // Screen size
int Texture_size_x = 150, Texture_size_y = 150; // The size of the Bitmap
UCHAR *Texture; // This is the texture
int g_x1 = 639, g_y1 = 0, g_x2 = 639, g_y2 = 479, g_x3 = 0, g_y3 = 479,
    *s_x, *s_y;
UCHAR g_c1 = 0, g_c2 = 20, g_c3 = 50; // The point light
// The point texture pos:
int g_tx1 = 0, g_ty1 = 0, g_tx2 = 0, g_ty2 = Texture_size_y,
    g_tx3 = Texture_size_x, g_ty3 = Texture_size_y;
// Frame Couter(FPS):
int FPS = 0; int FPSFrames = 0; int FPSFramesTotal = 0; int FPSLastTimer;
void InitFPS(void); void GetFPS(void);

static HFONT hFont;
HDC hdc;
COLORREF BackColor = RGB(0,0,0);
COLORREF TextColor = RGB(255,255,255);
int DrawMode;
int SelectedPoint;
BOOL Random = FALSE;
BOOL ShowFrame;
BOOL Float_Mode;
BOOL Clipping; // Is the clipping on or off?
int VLeft, VTop, VRight, VBottom; // View Window
int DrawCounter = 1;

#include "Tools.h"
#include "Line.h"
#include "Pcx.h"

// This structure stores the informations from a scanline:
typedef struct
{
	int s_xpos, e_xpos;
    UCHAR s_shade, e_shade;
    int s_xtexel, s_ytexel, e_xtexel, e_ytexel;
} SCAN_LINE;
SCAN_LINE *Scanline;

void Draw_SoldPolygon_Float(UCHAR *screen, int x1, int y1, int x2, int y2,
					        int x3, int y3, UCHAR color);
void Draw_SoldPolygon_NoFloat(UCHAR *screen, int x1, int y1, int x2, int y2,
					          int x3, int y3, UCHAR color);
void scan_soldpolyline_Float(int x1, int y1, int x2, int y2, BOOL page);
void scan_soldpolyline_NoFloat(int x1, int y1, int x2, int y2, BOOL page);


void Draw_ShadePolygon_Float(UCHAR *screen, int x1, int y1, int x2, int y2,
					         int x3, int y3, UCHAR c1, UCHAR c2, UCHAR c3);
void Draw_ShadePolygon_NoFloat(UCHAR *screen, int x1, int y1, int x2, int y2,
					           int x3, int y3, UCHAR c1, UCHAR c2, UCHAR c3);
void scan_shadepolyline_Float(int x1, int y1, int x2, int y2, UCHAR c1,
							  UCHAR c2, BOOL page);
void scan_shadepolyline_NoFloat(int x1, int y1, int x2, int y2, UCHAR c1,
								UCHAR c2, BOOL page);


void Draw_TexturePolygon_Float(UCHAR *screen, int x1, int y1, int tx1, int ty1,
							  int x2, int y2, int tx2, int ty2, int x3, int y3,
                              int tx3, int ty3);
void Draw_TexturePolygon_NoFloat(UCHAR *screen, int x1, int y1, int tx1,
							     int ty1, int x2, int y2, int tx2, int ty2,
                                 int x3, int y3, int tx3, int ty3);
void scan_texturepolyline_Float(int x1, int y1, int tx1, int ty1, int x2,
                                  int y2, int tx2, int ty2, BOOL page);
void scan_texturepolyline_NoFloat(int x1, int y1, int tx1, int ty1, int x2,
                                  int y2, int tx2, int ty2, BOOL page);


void Draw_TextureShadePolygon_Float(UCHAR *screen, int x1, int y1, UCHAR c1,
     	int tx1, int ty1, int x2, int y2, UCHAR c2, int tx2, int ty2, int x3,
        int y3, UCHAR c3, int tx3, int ty3);
void Draw_TextureShadePolygon_NoFloat(UCHAR *screen, int x1, int y1, UCHAR c1,
     	int tx1, int ty1, int x2, int y2, UCHAR c2, int tx2, int ty2, int x3,
        int y3, UCHAR c3, int tx3, int ty3);
void scan_textureshadepolyline_Float(int x1, int y1, UCHAR c1, int tx1, int ty1,
		int x2, int y2, UCHAR c2, int tx2, int ty2, BOOL page);
void scan_textureshadepolyline_NoFloat(int x1, int y1, UCHAR c1, int tx1,
		int ty1, int x2, int y2, UCHAR c2, int tx2, int ty2, BOOL page);

// Checks the messages from Windows:
long FAR PASCAL WindowProc(HWND hWnd, UINT message,
                           WPARAM wParam, LPARAM lParam)
{ // begin WindowProc()
    switch( message )
    {
        case WM_LBUTTONDOWN:
        case WM_LBUTTONUP:
        case WM_RBUTTONDOWN:
        case WM_RBUTTONUP:
        case WM_MOUSEMOVE:
            Mouse.Button = (char)wParam;
            Mouse.XPos = (short)LOWORD(lParam);
            Mouse.YPos = (short)HIWORD(lParam);
            if(Mouse.XPos < Mouse.BoundX)
                Mouse.XPos = Mouse.BoundX;
            if(Mouse.YPos < Mouse.BoundY)
                Mouse.YPos = Mouse.BoundY;
            if(Mouse.XPos > Mouse.BoundXB)
                Mouse.XPos = Mouse.BoundXB;
            if(Mouse.YPos > Mouse.BoundYH)
                Mouse.YPos = Mouse.BoundYH;
        break;

        case WM_ACTIVATEAPP:
            // If we wanted to pause the application when it
            // became inactive, we could do so here. In this case,
            // we decided to make it active at all times. When it is
            // minimized to the task bar, it just updates position.
            if(wParam)
            	OutputDebugString("Application activated!\n ");
            else
            	OutputDebugString("Application deactivated!\n ");
            g_bAppIsActive = wParam;
            break;

        case WM_CREATE:
            break;

        case WM_SIZE:
            // Our window size is fixed, so this could
            // only be a minimize or maximize
            if(wParam == SIZE_MINIMIZED)
            {
                // We've been minimized, no need to
                // redraw the screen.
                InvalidateRect( hWnd, NULL, TRUE );
                g_bActive = FALSE;
            }
            else
                g_bActive = TRUE;
            return 0;

        case WM_MOVE:
            // get the client rectangle
            if(g_bFullScreen)
                SetRect(&g_rcWindow, 0, 0, GetSystemMetrics(SM_CXSCREEN),
                        GetSystemMetrics(SM_CYSCREEN));
            else
            {
                GetClientRect(hWnd, &g_rcWindow);
                ClientToScreen(hWnd, (LPPOINT)&g_rcWindow);
                ClientToScreen(hWnd, (LPPOINT)&g_rcWindow+1);
            }
            break;

        case WM_PALETTECHANGED:
            if((HWND)wParam != hWnd)
            {
                OutputDebugString("Palette lost.\n");
                lpDDSPrimary->SetPalette(lpDDPalette);
            }
            break;

        case WM_QUERYNEWPALETTE:
            // Ignore this message if we're transitioning -- we may
            // not yet have created the the surface and palette.
            if(!lpDDSPrimary || !lpDDPalette)
            {
                OutputDebugString("Ignoring palette message.\n");
                return TRUE;
            }
            // We have control of the palette.
            OutputDebugString("We have the palette.\n");
            lpDDSPrimary->SetPalette(lpDDPalette);
            break;

        case WM_SETCURSOR:
            if(g_bFullScreen)
            {
            	SetCursor(NULL);
                return FALSE;
            }
            break;

        case WM_PAINT:
			ShowWindow(g_hwnd, SW_SHOW);
            break;

        case WM_SYSKEYUP:
            switch(wParam)
            {
                // Alt+Enter
                case VK_RETURN:
                    OutputDebugString("Alt+Enter...\n");
                    if(!g_bAllowWindowed)
                        break;
                    g_bReInitialize = TRUE;
                    g_bFullScreen = !g_bFullScreen;
                    CleanUp();
                    if FAILED(DDInit())
                        OutputDebugString("Error: new Init.\n" );
                    // Here must you built your Data:
					Mouse.Destroy(); // Destroy the mouse
                    Mouse.LoadBitmap(); // Load the mouse bitmaps
                    ShowWindow(g_hwnd, SW_SHOW);
                    g_bReInitialize = FALSE;
                    break;
            }
            break;

        case WM_DESTROY:
            if(!g_bReInitialize)
                g_ExitProgramm = TRUE;
            return 0;

        case WM_COMMAND:
        break;

        case WM_KEYDOWN:
            switch(wParam)
            {
                case VK_F1:
		            if(Random == TRUE)
                       	Random = FALSE;
					else
                       	Random = TRUE;
                    break;

                case VK_F2:
		            if(DrawCounter > 1)
                       	DrawCounter--;;
	                break;

                case VK_F3:
                   	DrawCounter++;;
	                break;

                case VK_ESCAPE:
                    g_ExitProgramm = TRUE;
	                break;

				case VK_LEFT:
                    *s_x -= 1;
	                break;

				case VK_UP:
                    *s_y -= 1;
	                break;

				case VK_RIGHT:
                    *s_x += 1;
	                break;

				case VK_DOWN:
                    *s_y += 1;
	                break;

				case VK_NUMPAD1:
					DrawMode = DRAW_SOLD;
	                break;

				case VK_NUMPAD2:
					DrawMode = DRAW_SHADE;
	                break;

				case VK_NUMPAD3:
					DrawMode = DRAW_TEXTURE;
	                break;

				case VK_NUMPAD4:
					DrawMode = DRAW_TEXTURE_SHADE;
	                break;

				case VK_TAB:
                    if(ShowFrame == 1)
                    	ShowFrame = 0;
                    else
	                    ShowFrame = 1;
	                break;

				case VK_SPACE:
                    if(Float_Mode == 1)
                    	Float_Mode = 0;
                    else
	                    Float_Mode = 1;
	                break;

				case VK_RETURN:
                    if(Clipping == 1)            
                    	Clipping = 0;
                    else
	                    Clipping = 1;
	                break;

				case VK_SUBTRACT:
                    if(VLeft < screen_size_x/2-10)
                    	VLeft += 1;
                    if(VTop < screen_size_y/2+5)
                    	VTop += 1;
                    if(VRight >= screen_size_x/2+10)
                    	VRight -= 1;
                    if(VBottom >= screen_size_y/2+10)
                    	VBottom -= 1;
	                break;

				case VK_ADD:
                    if(VLeft >= 1)
                    	VLeft -= 1;
                    if(VTop >= 1)
                    	VTop -= 1;
                    if(VRight <= screen_size_x-2)
                    	VRight += 1;
                    if(VBottom <= screen_size_y-2)
                    	VBottom += 1;
	                break;
            }
        break;
    }
    return DefWindowProc(hWnd, message, wParam, lParam);
} // end WindowProc()

int PASCAL WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    LPSTR lpCmdLine, int nCmdShow)
{ // begin WinMain()
    MSG         msg;
    UCHAR *dest;
    DDSURFACEDESC ddsd;
    RECT rc;
    int index;

    if(WindowMode == FALSE)
		g_bFullScreen = TRUE;
	else
    	g_bFullScreen = FALSE;
    if(!doInit(hInstance, nCmdShow))
       	return FALSE;
	InitFPS();
    Mouse.Init(); // Init the mouse
    Mouse.LoadBitmap(); // Load the mouse bitmaps
    Texture = LoadPCX("Texture.pcx"); // Loads the texture
    if(!Texture)
    	return 1;
    s_x = &g_x1;
    s_y = &g_y1;
    DrawMode = DRAW_TEXTURE_SHADE;
	SelectedPoint = 1;
	Float_Mode = 0;
    ShowFrame = 0; // Show us the frame of this polygon
    Clipping = FALSE; // Activate the cliping
    // Define a visible area:
	SetVisibleArea(30, 30, screen_size_x-31, screen_size_y-31);
	Scanline = (SCAN_LINE *) malloc(sizeof(SCAN_LINE)*screen_size_y);
    if(Scanline == NULL)
    	return 1;
    for(;;)
    {
    	if(PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
    	{
        	if(!GetMessage(&msg, NULL, 0, 0))
            	return msg.wParam;
        	TranslateMessage(&msg);
        	DispatchMessage(&msg);
    	}
		else
		{
            if(!g_bActive) // The programm is just breaked
	            continue;
            if(g_ExitProgramm == TRUE)
                break;
            if(Random == TRUE) 
            {
            	g_c1 += rand() % 20;
            	g_c1 -= rand() % 20;
            	g_c2 += rand() % 20;
            	g_c2 -= rand() % 20;
            	g_c3 += rand() % 20;
            	g_c3 -= rand() % 20;
            }
            if(Mouse.Button == BOTH_MOUSE_BUTTON)
	        {
                s_x = &g_x3;
                s_y = &g_y3;
                *s_x = (int) Mouse.XPos;
     	        *s_y = (int) Mouse.YPos;
                SelectedPoint = 3;
            }
            if(Mouse.Button == LEFT_MOUSE_BUTTON)
	        {
                s_x = &g_x1;
                s_y = &g_y1;
                *s_x = (int) Mouse.XPos;
     	        *s_y = (int) Mouse.YPos;
                SelectedPoint = 1;
            }
            if(Mouse.Button == RIGHT_MOUSE_BUTTON)
	        {
                s_x = &g_x2;
                s_y = &g_y2;
                *s_x = (int) Mouse.XPos;
     	        *s_y = (int) Mouse.YPos;
                SelectedPoint = 2;
            }
			DDFillSurface(lpDDSBack, 0);
            // Get informations on screen:
            if(IDirectDrawSurface_GetDC(lpDDSBack, &hdc) == DD_OK)
            {
                SelectObject(hdc, hFont);
                SetTextColor(hdc, TextColor);
                SetBkColor(hdc, BackColor);
                SetBkMode(hdc, OPAQUE);
                SetRect(&rc, 0, 0, 10000, 10000);
                if(Float_Mode == 1)
	            {
                	if(Clipping)
                  		sprintf(temp, "C Float- P1: %d/%d   P2: %d/%d   "
                        			  "P3: %d/%d  SelectedPoint: %d    "
                                      "FPS: %d, Total: %d  Pol:%d",
                                      g_x1, g_y1, g_x2, g_y2, g_x3, g_y3,
                                      SelectedPoint, FPS, FPSFramesTotal,
                                      DrawCounter);
	                else
                        sprintf(temp, "Float- P1: %d/%d   P2: %d/%d   P3: %d/%d"
                        	          "SelectedPoint: %d    "
                                      "FPS: %d, Total: %d  Pol:%d",
                                      g_x1, g_y1, g_x2,
                                      g_y2, g_x3, g_y3, SelectedPoint, FPS,
                                      FPSFramesTotal, DrawCounter);
	            }
                else
                {
                	if(Clipping)
    	                sprintf(temp, "C int- P1: %d/%d   P2: %d/%d   P3: %d/%d"
                                      "  SelectedPoint: %d    "
                                      "FPS: %d, Total: %d  Pol:%d",
                                      g_x1, g_y1, g_x2,
                                      g_y2, g_x3, g_y3, SelectedPoint,
                                      FPS, FPSFramesTotal, DrawCounter);
	                else
	                    sprintf(temp, "int- P1: %d/%d   P2: %d/%d   P3: %d/%d"
                                      "  SelectedPoint: %d    "
                                      "FPS: %d, Total: %d  Pol:%d",
                                      g_x1, g_y1, g_x2,
                                      g_y2, g_x3, g_y3, SelectedPoint,
                                      FPS, FPSFramesTotal, DrawCounter);
                }
                ExtTextOut(hdc, 0, 0, ETO_OPAQUE, &rc, temp, strlen(temp),
                           NULL);
                IDirectDrawSurface_ReleaseDC(lpDDSBack, hdc);
            }
		    ZeroMemory(&ddsd, sizeof(ddsd));
		    ddsd.dwSize = sizeof(ddsd);
		    ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH;
		    ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_SYSTEMMEMORY;
            if(WindowMode)
                lpDDSBack->Lock(NULL, &ddsd, DDLOCK_NOSYSLOCK, NULL);
            else
                lpDDSBack->Lock(NULL, &ddsd, DDLOCK_WAIT, NULL);
		    if(ddsd.lpSurface == NULL)
	    		continue;
		    dest = (BYTE *)ddsd.lpSurface;
            for(index = 0; index < DrawCounter; index++)
            {
                if(Float_Mode == 1)
                {
                    switch(DrawMode)
                    {
                        case DRAW_SOLD:
                            Draw_SoldPolygon_Float(dest, g_x1, g_y1, g_x2, g_y2,
                                                   g_x3, g_y3, 200);
                            break;

                        case DRAW_SHADE:
                            Draw_ShadePolygon_Float(dest, g_x1, g_y1, g_x2,
                                            g_y2, g_x3, g_y3, g_c1, g_c2, g_c3);
                            break;

                        case DRAW_TEXTURE:
                            Draw_TexturePolygon_Float(dest, g_x1, g_y1, g_tx1,
                                g_ty1, g_x2, g_y2, g_tx2, g_ty2, g_x3, g_y3,
                                g_tx3, g_ty3);
                            break;

                        case DRAW_TEXTURE_SHADE:
                            Draw_TextureShadePolygon_Float(dest, g_x1, g_y1,
                                g_c1, g_tx1, g_ty1, g_x2, g_y2, g_c2, g_tx2,
                                g_ty2, g_x3, g_y3, g_c3, g_tx3, g_ty3);
                            break;
                    }
                }
                else
                {
                    switch(DrawMode)
                    {
                        case DRAW_SOLD:
                            Draw_SoldPolygon_NoFloat(dest, g_x1, g_y1, g_x2,
                                                     g_y2, g_x3, g_y3, 200);
                            break;

                        case DRAW_SHADE:
                            Draw_ShadePolygon_NoFloat(dest, g_x1, g_y1, g_x2,
                        				    g_y2, g_x3, g_y3, g_c1, g_c2, g_c3);
                            break;

                        case DRAW_TEXTURE:
                            Draw_TexturePolygon_NoFloat(dest, g_x1, g_y1, g_tx1,
                                g_ty1, g_x2, g_y2, g_tx2, g_ty2, g_x3, g_y3,
                                g_tx3, g_ty3);
                            break;

                        case DRAW_TEXTURE_SHADE:
                            Draw_TextureShadePolygon_NoFloat(dest, g_x1, g_y1,
                                g_c1, g_tx1, g_ty1, g_x2, g_y2, g_c2, g_tx2,
                                g_ty2, g_x3, g_y3, g_c3, g_tx3, g_ty3);
                            break;
                    }
                }
            }
            // Draw now the visible area frame:
		    if(Clipping)
                if(Float_Mode == 1)
                {
                    Draw_Line_Float(dest, VLeft, VTop, VLeft, VBottom, 255);
                    Draw_Line_Float(dest, VLeft, VTop, VRight, VTop, 255);
                    Draw_Line_Float(dest, VRight, VTop, VRight, VBottom, 255);
                    Draw_Line_Float(dest, VLeft, VBottom, VRight, VBottom, 255);
                }
                else
                {
                    Draw_Line_NoFloat(dest, VLeft, VTop, VLeft, VBottom, 255);
                    Draw_Line_NoFloat(dest, VLeft, VTop, VRight, VTop, 255);
                    Draw_Line_NoFloat(dest, VRight, VTop, VRight, VBottom, 255);
                    Draw_Line_NoFloat(dest, VLeft, VBottom, VRight, VBottom,
                                      255);
                }
            // Draws the frame of the polygon:
            if(ShowFrame == 1)
            {
                if(Float_Mode == 1)
                {
                    Draw_Line_Float(dest, g_x1, g_y1, g_x2, g_y2, 255);
                    Draw_Line_Float(dest, g_x2, g_y2, g_x3, g_y3, 255);
                    Draw_Line_Float(dest, g_x3, g_y3, g_x1, g_y1, 255);
                }
                else
                {
                    Draw_Line_NoFloat(dest, g_x1, g_y1, g_x2, g_y2, 255);
                    Draw_Line_NoFloat(dest, g_x2, g_y2, g_x3, g_y3, 255);
                    Draw_Line_NoFloat(dest, g_x3, g_y3, g_x1, g_y1, 255);
                }
		    }
            lpDDSBack->Unlock(NULL);
            Mouse.DrawOnBitmap(lpDDSBack);
			UpdateFrame(g_bActive);
			GetFPS();
        }
    }
	free(Scanline);
    Mouse.Destroy(); // Destroy the mouse
    CleanUp();
    PostQuitMessage( 0 );
	return 0;
} // end WinMain()

void InitFPS(void)
{ // begin InitFPS()
     FPS = 0;
     FPSFrames = 0;
     FPSFramesTotal = 0;
     FPSLastTimer = 0;
} // end InitFPS()

void GetFPS(void)
{ // begin GetFPS()
     FPSFrames++;
     FPSFramesTotal++;
     if(timeGetTime()-FPSLastTimer < 1000)
         return;
     FPSLastTimer = timeGetTime();
     FPS = FPSFrames;
//     FPS = (FPSFrames*1000)/FPSTimer;
     FPSFrames = 0;
} // end GetFPS()


/* 								Demonstration of:

Sold Polygon:
void Draw_SoldPolygon_Float(UCHAR *screen, int x1, int y1, int x2, int y2,
					        int x3, int y3, UCHAR color);
void Draw_SoldPolygon_NoFloat(UCHAR *screen, int x1, int y1, int x2, int y2,
					          int x3, int y3, UCHAR color);
void scan_soldpolyline_Float (int x1, int y1, int x2, int y2, BOOL page);
void scan_soldpolyline_NoFloat (int x1, int y1, int x2, int y2, BOOL page);

Shade Polygon:
void Draw_ShadePolygon_Float(UCHAR *screen, int x1, int y1, int x2, int y2,
					         int x3, int y3, UCHAR c1, UCHAR c2, UCHAR c3);
void Draw_ShadePolygon_NoFloat(UCHAR *screen, int x1, int y1, int x2, int y2,
					           int x3, int y3, UCHAR c1, UCHAR c2, UCHAR c3);
void scan_shadepolyline_Float(int x1, int y1, int x2, int y2, UCHAR c1,
							  UCHAR c2, BOOL page);
void scan_shadepolyline_NoFloat(int x1, int y1, int x2, int y2, UCHAR c1,
								UCHAR c2, BOOL page);

Textured Polygon:
void Draw_TexturePolygon_Float(UCHAR *screen, int x1, int y1, int tx1, int ty1,
							  int x2, int y2, int tx2, int ty2, int x3, int y3,
                              int tx3, int ty3);
void Draw_TexturePolygon_NoFloat(UCHAR *screen, int x1, int y1, int tx1,
							     int ty1, int x2, int y2, int tx2, int ty2,
                                 int x3, int y3, int tx3, int ty3);
void scan_texturepolyline_Float(int x1, int y1, int tx1, int ty1, int x2,
                                  int y2, int tx2, int ty2, BOOL page);
void scan_texturepolyline_NoFloat(int x1, int y1, int tx1, int ty1, int x2,
                                  int y2, int tx2, int ty2, BOOL page);


Textured Shade Polygon:
void Draw_TextureShadePolygon_Float(UCHAR *screen, int x1, int y1, UCHAR c1,
     	int tx1, int ty1, int x2, int y2, UCHAR c2, int tx2, int ty2, int x3,
        int y3, UCHAR c3, int tx3, int ty3);
void Draw_TextureShadePolygon_NoFloat(UCHAR *screen, int x1, int y1, UCHAR c1,
     	int tx1, int ty1, int x2, int y2, UCHAR c2, int tx2, int ty2, int x3,
        int y3, UCHAR c3, int tx3, int ty3);
void scan_textureshadepolyline_Float(int x1, int y1, UCHAR c1, int tx1, int ty1,
		int x2, int y2, UCHAR c2, int tx2, int ty2, BOOL page);
void scan_textureshadepolyline_NoFloat(int x1, int y1, UCHAR c1, int tx1,
		int ty1, int x2, int y2, UCHAR c2, int tx2, int ty2, BOOL page);
*/



/*
*******************************************************************************
							    Sold Polygon
*******************************************************************************
*/

void Draw_SoldPolygon_Float(UCHAR *screen, int x1, int y1, int x2, int y2,
					        int x3, int y3, UCHAR color)
{ // begin Draw_SoldPolygon_Float()
    register UCHAR *pscreen;
    UCHAR *pscreene;
	SCAN_LINE *cScanline;
	int height, longest_side;
    float ftemp;

	// Sort the triangle so that x1/y1 to the topmost, x2/y2 to the middle and
	// x3/y3 to the bottom positions:
    if(y1 > y2) { SWAP_INT(x1, x2); SWAP_INT(y1, y2); }
    if(y1 > y3) { SWAP_INT(x1, x3);	SWAP_INT(y1, y3); }
    if(y2 > y3) { SWAP_INT(x2, x3);	SWAP_INT(y2, y3); }
    height = y3-y1;
    if(!height) // The polygon is not visible!
    	return;
    // Calculate the longest side:
    ftemp = (float) (y2-y1)/height;
    longest_side = (int) (ftemp*(x3-x1)+(x1-x2));
    if(!longest_side) // The polygon is not visible!
	    return;
    // Now that we have the length of the longest scanline we can use that
    // to tell us which is left and which is the right side of the triangle.
    if(longest_side < 0)
    {
        // If longest is neg. we have the middle vertex on the right side.
        // Store the pointers for the right and left edge of the triangle.
    	scan_soldpolyline_Float(x1, y1, x2, y2, 1);
    	scan_soldpolyline_Float(x2, y2, x3, y3, 1);
    	scan_soldpolyline_Float(x3, y3, x1, y1, 0);
    }
	else
    {
        // If longest is pos. we have the middle vertex on the left side.
        // Store the pointers for the left and right edge of the triangle.
    	scan_soldpolyline_Float(x1, y1, x2, y2, 0);
    	scan_soldpolyline_Float(x2, y2, x3, y3, 0);
    	scan_soldpolyline_Float(x3, y3, x1, y1, 1);
    }
    if(Clipping)
    {
        if(y1 < VTop)
            y1 = VTop;
        if(y3 > VBottom)
            y3 = VBottom;
        cScanline = &Scanline[y1];
        for(; y1 < y3; y1++) // Now draw the horizontal line list
        {
			if(cScanline->s_xpos < VLeft)
            	cScanline->s_xpos = VLeft;
			if(cScanline->e_xpos > VRight)
            	cScanline->e_xpos = VRight;
            pscreen = screen+screen_size_x*y1+cScanline->s_xpos;
	        pscreene = pscreen+cScanline->e_xpos-cScanline->s_xpos;
            for(; pscreen < pscreene; pscreen++)
                *pscreen = color;
	        cScanline++;
        }
	    return;
	}
    cScanline = &Scanline[y1];
    pscreen = screen+screen_size_x*y1+cScanline->s_xpos;
    for(; y1 < y3; y1++) // Now draw the horizontal line list
    {
        pscreene = pscreen+cScanline->e_xpos-cScanline->s_xpos;
        for(; pscreen < pscreene; pscreen++)
            *pscreen = color;
        pscreen += screen_size_x-cScanline->e_xpos;
        cScanline++;
        pscreen += cScanline->s_xpos;
    }
} // end Draw_SoldPolygon_Float()

void Draw_SoldPolygon_NoFloat(UCHAR *screen, int x1, int y1, int x2, int y2,
					          int x3, int y3, UCHAR color)
{ // begin Draw_SoldPolygon_NoFloat()
    register UCHAR *pscreen;
    UCHAR *pscreene;
	SCAN_LINE *cScanline;
	int height, longest_side, ftemp;

	// Sort the triangle so that x1/y1 to the topmost, x2/y2 to the middle and
	// x3/y3 to the bottom positions:
    if(y1 > y2) { SWAP_INT(x1, x2); SWAP_INT(y1, y2); }
    if(y1 > y3) { SWAP_INT(x1, x3);	SWAP_INT(y1, y3); }
    if(y2 > y3) { SWAP_INT(x2, x3);	SWAP_INT(y2, y3); }
    height = y3-y1;
    if(!height) // The polygon is not visible!
    	return;
    // Calculate the longest side:
    ftemp = ((y2-y1) << 16)/height;
    longest_side = (ftemp*(x3-x1)+((x1-x2 << 16))) >> 16;
    if(!longest_side) // The polygon is not visible!
	    return;
    // Now that we have the length of the longest scanline we can use that
    // to tell us which is left and which is the right side of the triangle.
    if(longest_side < 0)
    {
        // If longest is neg. we have the middle vertex on the right side.
        // Store the pointers for the right and left edge of the triangle.
    	scan_soldpolyline_NoFloat(x1, y1, x2, y2, 1);
    	scan_soldpolyline_NoFloat(x2, y2, x3, y3, 1);
    	scan_soldpolyline_NoFloat(x3, y3, x1, y1, 0);
    }
	else
    {
        // If longest is pos. we have the middle vertex on the left side.
        // Store the pointers for the left and right edge of the triangle.
    	scan_soldpolyline_NoFloat(x1, y1, x2, y2, 0);
    	scan_soldpolyline_NoFloat(x2, y2, x3, y3, 0);
    	scan_soldpolyline_NoFloat(x3, y3, x1, y1, 1);
    }
    if(Clipping)
    {
        if(y1 < VTop)
            y1 = VTop;
        if(y3 > VBottom)
            y3 = VBottom;
        cScanline = &Scanline[y1];
        for(; y1 < y3; y1++) // Now draw the horizontal line list
        {
			if(cScanline->s_xpos < VLeft)
            	cScanline->s_xpos = VLeft;
            if(cScanline->e_xpos > VRight)
            	cScanline->e_xpos = VRight;
            pscreen = screen+screen_size_x*y1+cScanline->s_xpos;
	        pscreene = pscreen+cScanline->e_xpos-cScanline->s_xpos;
	        for(; pscreen < pscreene; pscreen++)
	            *pscreen = color;
    	    cScanline++;
        }
	    return;
	}
    cScanline = &Scanline[y1];
    pscreen = screen+screen_size_x*y1+cScanline->s_xpos;
    for(; y1 < y3; y1++) // Now draw the horizontal line list
    {
        pscreene = pscreen+cScanline->e_xpos-cScanline->s_xpos;
        for(; pscreen < pscreene; pscreen++)
            *pscreen = color;
        pscreen += screen_size_x-cScanline->e_xpos;
        cScanline++;
        pscreen += cScanline->s_xpos;
    }
} // end Draw_SoldPolygon_NoFloat()

void scan_soldpolyline_Float(int x1, int y1, int x2, int y2, BOOL page)
{ // begin scan_soldpolyline_Float()
	SCAN_LINE *cScanline, *eScanline;
    int length;
    float x, m;

    if(y2 == y1) // This isn't a horizontal line
    	return;
    if(y2 < y1)
    {
        SWAP_INT(x1, x2);
        SWAP_INT(y1, y2);
    }
    length = y2-y1;
    x = (float) x1;
    m = (float) (x2-x1)/length;
    if(Clipping)
    { // Clip the polygon:
        if(y2 > VBottom)
            y2 = VBottom;
        if(y1 < VTop)
        {
            x -= m*(y1-VTop);
            y1 = VTop;
        }
    }
	cScanline = &Scanline[y1];
	eScanline = &Scanline[y2];
    if(!page)
        for(; cScanline <= eScanline; cScanline++) // Go through each row
        {
            cScanline->s_xpos = (int) x; // Store the first x coordinate
            x += m; // Add our constant to x
        }
    else
        for(; cScanline <= eScanline; cScanline++) // Go through each row
        {
            cScanline->e_xpos = (int) x; // Store the last x coordinate
            x += m;	// Add our constant to x
        }
} // end scan_soldpolyline_Float()

void scan_soldpolyline_NoFloat(int x1, int y1, int x2, int y2, BOOL page)
{ // begin scan_soldpolyline_NoFloat()
	SCAN_LINE *cScanline, *eScanline;
    int length, x, m;

    if(y2 == y1) // This isn't a horizontal line
    	return;
    if(y2 < y1)
    {
        SWAP_INT(x1, x2);
        SWAP_INT(y1, y2);
    }
    length = y2-y1;
    x = x1 << 16;
    m = ((x2-x1) << 16)/length ;
    if(Clipping)
    { // Clip the polygon:
        if(y2 > VBottom)
            y2 = VBottom;
        if(y1 < VTop)
        {
            x -= m*(y1-VTop);
            y1 = VTop;
        }
    }
	cScanline = &Scanline[y1];
	eScanline = &Scanline[y2];
    if(!page)
        for(; cScanline <= eScanline; cScanline++) // Go through each row
        {
            cScanline->s_xpos = x >> 16; // Store the first x coordinate
            x += m; // Add our constant to x

        }
    else
        for(; cScanline <= eScanline; cScanline++) // Go through each row
        {
            cScanline->e_xpos = x >> 16; // Store the last x coordinate
            x += m;	// Add our constant to x
        }
} // end scan_soldpolyline_NoFloat()


/*
*******************************************************************************
							   Shade Polygon
*******************************************************************************
*/

void Draw_ShadePolygon_Float(UCHAR *screen, int x1, int y1, int x2, int y2,
					         int x3, int y3, UCHAR c1, UCHAR c2, UCHAR c3)
{ // begin Draw_ShadePolygon_Float()
    UCHAR *pscreen, *pscreene;
	SCAN_LINE *cScanline;
	int height, longest_side;
    float ftemp, shade, shade_increase;

	// Sort the triangle so that x1/y1 to the topmost, x2/y2 to the middle and
	// x3/y3 to the bottom positions:
    if(y1 > y2) { SWAP_INT(x1, x2); SWAP_INT(y1, y2); SWAP_CHAR(c1, c2); }
    if(y1 > y3) { SWAP_INT(x1, x3);	SWAP_INT(y1, y3); SWAP_CHAR(c1, c3); }
    if(y2 > y3) { SWAP_INT(x2, x3);	SWAP_INT(y2, y3); SWAP_CHAR(c2, c3); }
    height = y3-y1;
    if(!height) // The polygon is not visible!
    	return;
    // Calculate the longest side:
    ftemp = (float) (y2-y1)/height;
    longest_side = (int) (ftemp*(x3-x1)+(x1-x2));
    if(!longest_side) // The polygon is not visible!
	    return;
    // Now that we have the length of the longest scanline we can use that
    // to tell us which is left and which is the right side of the triangle.
    if(longest_side < 0)
    {
        // If longest is neg. we have the middle vertex on the right side.
        // Store the pointers for the right and left edge of the triangle.
    	scan_shadepolyline_Float(x1, y1, x2, y2, c1, c2, 1);
    	scan_shadepolyline_Float(x2, y2, x3, y3, c2, c3, 1);
    	scan_shadepolyline_Float(x3, y3, x1, y1, c3, c1, 0);
    }
	else
    {
        // If longest is pos. we have the middle vertex on the left side.
        // Store the pointers for the left and right edge of the triangle.
    	scan_shadepolyline_Float(x1, y1, x2, y2, c1, c2, 0);
    	scan_shadepolyline_Float(x2, y2, x3, y3, c2, c3, 0);
    	scan_shadepolyline_Float(x3, y3, x1, y1, c3, c1, 1);
    }
    if(Clipping)
    {
        if(y1 < VTop)
            y1 = VTop;
        if(y3 > VBottom)
            y3 = VBottom;
        cScanline = &Scanline[y1];
        for(; y1 < y3; y1++) // Now draw the horizontal line list
        {
            shade = (float) cScanline->s_shade;
            shade_increase = (float) (cScanline->e_shade-cScanline->s_shade)/
                             (cScanline->e_xpos-cScanline->s_xpos+SMALL_NUMBER);
			if(cScanline->s_xpos < VLeft)
            {
             	shade += shade_increase*(VLeft-cScanline->s_xpos);
            	cScanline->s_xpos = VLeft;
			}
            if(cScanline->e_xpos > VRight)
            	cScanline->e_xpos = VRight;
            pscreen = screen+screen_size_x*y1+cScanline->s_xpos;
	        pscreene = pscreen+cScanline->e_xpos-cScanline->s_xpos;
            for(; pscreen < pscreene; pscreen++)
            {
                *pscreen = (UCHAR) shade;
                shade += shade_increase;
            }
            cScanline++;
        }
	    return;
	}
    cScanline = &Scanline[y1];
    pscreen = screen+screen_size_x*y1+cScanline->s_xpos;
    for(; y1 < y3; y1++) // Now draw the horizontal line list
    {
        shade = (float) cScanline->s_shade;
        if((cScanline->e_xpos-cScanline->s_xpos) != 0)
	        shade_increase = (float) (cScanline->e_shade-cScanline->s_shade)/
    	                     (cScanline->e_xpos-cScanline->s_xpos);
        else
	        shade_increase = 0;
        pscreene = pscreen+cScanline->e_xpos-cScanline->s_xpos;
        for(; pscreen < pscreene; pscreen++)
		{
            *pscreen = (UCHAR) shade;
            shade += shade_increase;
        }
        pscreen += screen_size_x-cScanline->e_xpos;
        cScanline++;
        pscreen += cScanline->s_xpos;
    }
} // end Draw_ShadePolygon_Float()

void Draw_ShadePolygon_NoFloat(UCHAR *screen, int x1, int y1, int x2, int y2,
					           int x3, int y3, UCHAR c1, UCHAR c2, UCHAR c3)
{ // begin Draw_ShadePolygon_NoFloat()
    UCHAR *pscreen, *pscreene;
	SCAN_LINE *cScanline;
	int height, longest_side, ftemp, shade, shade_increase;

	// Sort the triangle so that x1/y1 to the topmost, x2/y2 to the middle and
	// x3/y3 to the bottom positions:
    if(y1 > y2) { SWAP_INT(x1, x2); SWAP_INT(y1, y2); SWAP_CHAR(c1, c2); }
    if(y1 > y3) { SWAP_INT(x1, x3);	SWAP_INT(y1, y3); SWAP_CHAR(c1, c3); }
    if(y2 > y3) { SWAP_INT(x2, x3);	SWAP_INT(y2, y3); SWAP_CHAR(c2, c3); }
    height = y3-y1;
    if(!height) // The polygon is not visible!
    	return;
    // Calculate the longest side:
    ftemp = ((y2-y1) << 16)/height;
    longest_side = (ftemp*(x3-x1)+((x1-x2 << 16))) >> 16;
    if(!longest_side) // The polygon is not visible!
	    return;
    // Now that we have the length of the longest scanline we can use that
    // to tell us which is left and which is the right side of the triangle.
    if(longest_side < 0)
    {
        // If longest is neg. we have the middle vertex on the right side.
        // Store the pointers for the right and left edge of the triangle.
    	scan_shadepolyline_NoFloat(x1, y1, x2, y2, c1, c2, 1);
    	scan_shadepolyline_NoFloat(x2, y2, x3, y3, c2, c3, 1);
    	scan_shadepolyline_NoFloat(x3, y3, x1, y1, c3, c1, 0);
    }
	else
    {
        // If longest is pos. we have the middle vertex on the left side.
        // Store the pointers for the left and right edge of the triangle.
    	scan_shadepolyline_NoFloat(x1, y1, x2, y2, c1, c2, 0);
    	scan_shadepolyline_NoFloat(x2, y2, x3, y3, c2, c3, 0);
    	scan_shadepolyline_NoFloat(x3, y3, x1, y1, c3, c1, 1);
    }
    if(Clipping)
    {
        if(y1 < VTop)
            y1 = VTop;
        if(y3 > VBottom)
            y3 = VBottom;
        cScanline = &Scanline[y1];
        for(; y1 < y3; y1++) // Now draw the horizontal line list
        {
            shade = (int) cScanline->s_shade << 8;
            shade_increase = ((cScanline->e_shade-cScanline->s_shade) << 8)/
                             (cScanline->e_xpos-cScanline->s_xpos+SMALL_NUMBER);
			if(cScanline->s_xpos < VLeft)
            {
             	shade += shade_increase*(VLeft-cScanline->s_xpos);
				cScanline->s_xpos = VLeft;
			}
			if(cScanline->e_xpos > VRight)
            	cScanline->e_xpos = VRight;
            pscreen = screen+screen_size_x*y1+cScanline->s_xpos;
	        pscreene = pscreen+cScanline->e_xpos-cScanline->s_xpos;
	        for(; pscreen < pscreene; pscreen++)
            {
	            *pscreen = (UCHAR)(shade >> 8);
                shade += shade_increase;
            }
    	    cScanline++;
        }
	    return;
	}
    cScanline = &Scanline[y1];
    pscreen = screen+screen_size_x*y1+cScanline->s_xpos;
    for(; y1 < y3; y1++) // Now draw the horizontal line list
    {
        shade = (int) cScanline->s_shade << 16;
        shade_increase = ((cScanline->e_shade-cScanline->s_shade) << 16)/
                          (cScanline->e_xpos-cScanline->s_xpos+SMALL_NUMBER);
        pscreene = pscreen+cScanline->e_xpos-cScanline->s_xpos;
        for(; pscreen < pscreene; pscreen++)
		{
            *pscreen = (UCHAR) (shade >> 16);
            shade += shade_increase;
        }
        pscreen += screen_size_x-cScanline->e_xpos;
   	    cScanline++;
       	pscreen += cScanline->s_xpos;
    }
} // end Draw_ShadePolygon_NoFloat()

void scan_shadepolyline_Float(int x1, int y1, int x2, int y2, UCHAR c1,
						      UCHAR c2, BOOL page)
{ // begin scan_shadepolyline_Float()
	SCAN_LINE *cScanline, *eScanline;
    int length;
    float x, m, shade, shade_increase;

    if(y2 == y1) // This isn't a horizontal line
    	return;
    if(y2 < y1)
    {
        SWAP_INT(x1, x2);
        SWAP_INT(y1, y2);
        SWAP_CHAR(c1, c2);
    }
    length = y2-y1;
    x = (float) x1;
    m = (float) (x2-x1)/length;
    shade = (float) c1;
    shade_increase = (float) (c2-c1)/length;
    if(Clipping)
    { // Clip the polygon:
        if(y2 > VBottom)
            y2 = VBottom;
        if(y1 < VTop)
        {
            x -= m*(y1-VTop);
            shade -= shade_increase*(y1-VTop);
            y1 = VTop;
        }
    }
	cScanline = &Scanline[y1];
	eScanline = &Scanline[y2];
    if(!page)
        for(; cScanline <= eScanline; cScanline++) // Go through each row
        {
            cScanline->s_xpos = (int) x; // Store the first x coordinate
            cScanline->s_shade = (UCHAR)shade;//Store the first shade coordinate
            x += m; // Add our constant to x
            shade += shade_increase; // Add our constant to shade
        }
    else
        for(; cScanline <= eScanline; cScanline++) // Go through each row
        {
            cScanline->e_xpos = (int) x; // Store the last x coordinate
            cScanline->e_shade = (UCHAR) shade;//Store the last shade coordinate
            x += m;	// Add our constant to x
            shade += shade_increase; // Add our constant to shade
        }
} // end scan_shadepolyline_Float()

void scan_shadepolyline_NoFloat(int x1, int y1, int x2, int y2, UCHAR c1,
							    UCHAR c2, BOOL page)
{ // begin scan_shadepolyline_NoFloat()
	SCAN_LINE *cScanline, *eScanline;
    int length, x, m, shade, shade_increase;

    if(y2 == y1) // This isn't a horizontal line
    	return;
    if(y2 < y1)
    {
        SWAP_INT(x1, x2);
        SWAP_INT(y1, y2);
        SWAP_CHAR(c1, c2);
    }
    length = y2-y1;
    x = x1 << 16;
    m = ((x2-x1) << 16)/length ;
    shade = c1 << 8;
    shade_increase = ((c2-c1) << 8)/length;
    if(Clipping)
    { // Clip the polygon:
        if(y2 > VBottom)
            y2 = VBottom;
        if(y1 < VTop)
        {
            x -= m*(y1-VTop);
            shade -= shade_increase*(y1-VTop);
            y1 = VTop;
        }
    }
	cScanline = &Scanline[y1];
	eScanline = &Scanline[y2];
    if(!page)
        for(; cScanline <= eScanline; cScanline++) // Go through each row
        {
            cScanline->s_xpos = x >> 16; // Store the first x coordinate
            cScanline->s_shade = (UCHAR) (shade >> 8); // Store the first shade
            										// coordinate
            x += m; // Add our constant to x
            shade += shade_increase; // Add our constant to shade
        }
    else
        for(; cScanline <= eScanline; cScanline++) // Go through each row
        {
            cScanline->e_xpos = x >> 16; // Store the last x coordinate
            cScanline->e_shade = (UCHAR) (shade >> 8); // Store the last shade
            										 // coordinate
            x += m;	// Add our constant to x
            shade += shade_increase; // Add our constant to shade
        }
} // end scan_shadepolyline_NoFloat()


/*
*******************************************************************************
							 Textured Polygon
*******************************************************************************
*/

void Draw_TexturePolygon_Float(UCHAR *screen, int x1, int y1, int tx1, int ty1,
							  int x2, int y2, int tx2, int ty2, int x3, int y3,
                              int tx3, int ty3)
{ // begin Draw_TexturePolygon_Float()
	register UCHAR *pTexture = Texture;
    UCHAR *pscreen, *pscreene;
	SCAN_LINE *cScanline;
	int height, longest_side;
    float ftemp, tx, ty, tx_increase, ty_increase, length;

	// Sort the triangle so that x1/y1 to the topmost, x2/y2 to the middle and
	// x3/y3 to the bottom positions:
    if(y1 > y2) { SWAP_INT(x1, x2); SWAP_INT(y1, y2); SWAP_INT(ty1, tx2);
    			  SWAP_INT(ty1, ty2);}
    if(y1 > y3) { SWAP_INT(x1, x3);	SWAP_INT(y1, y3); SWAP_INT(tx1, tx3);
                  SWAP_INT(ty1, ty3);}
    if(y2 > y3) { SWAP_INT(x2, x3);	SWAP_INT(y2, y3); SWAP_INT(tx2, tx3);
                  SWAP_INT(ty2, ty3);}
    height = y3-y1;
    if(!height) // The polygon is not visible!
    	return;
    // Calculate the longest side:
    ftemp = (float) (y2-y1)/height;
    longest_side = (int) (ftemp*(x3-x1)+(x1-x2));
    if(!longest_side) // The polygon is not visible!
	    return;
    // Now that we have the length of the longest scanline we can use that
    // to tell us which is left and which is the right side of the triangle.
    if(longest_side < 0)
    {
        // If longest is neg. we have the middle vertex on the right side.
        // Store the pointers for the right and left edge of the triangle.
    	scan_texturepolyline_Float(x1, y1, tx1, ty1, x2, y2, tx2, ty2, 1);
    	scan_texturepolyline_Float(x2, y2, tx2, ty2, x3, y3, tx3, ty3, 1);
    	scan_texturepolyline_Float(x3, y3, tx3, ty3, x1, y1, tx1, ty1, 0);
    }
	else
    {
        // If longest is pos. we have the middle vertex on the left side.
        // Store the pointers for the left and right edge of the triangle.
    	scan_texturepolyline_Float(x1, y1, tx1, ty1, x2, y2, tx2, ty2, 0);
    	scan_texturepolyline_Float(x2, y2, tx2, ty2, x3, y3, tx3, ty3, 0);
    	scan_texturepolyline_Float(x3, y3, tx3, ty3, x1, y1, tx1, ty1, 1);
    }
    if(Clipping)
    {
        if(y1 < VTop)
            y1 = VTop;
        if(y3 > VBottom)
            y3 = VBottom;
        cScanline = &Scanline[y1];
        for(; y1 < y3; y1++) // Now draw the horizontal line list
        {
            length = cScanline->e_xpos-cScanline->s_xpos;
            tx_increase = (float) (cScanline->e_xtexel-cScanline->s_xtexel)/
                             (length+SMALL_NUMBER);
            ty_increase = (float) (cScanline->e_ytexel-cScanline->s_ytexel)/
                             (length+SMALL_NUMBER);
            tx = (float) cScanline->s_xtexel;
            ty = (float) cScanline->s_ytexel;
			if(cScanline->s_xpos < VLeft)
            {
             	tx += tx_increase*(VLeft-cScanline->s_xpos);
            	ty += ty_increase*(VLeft-cScanline->s_xpos);
            	cScanline->s_xpos = VLeft;
			}
            if(cScanline->e_xpos > VRight)
            	cScanline->e_xpos = VRight;
            pscreen = screen+screen_size_x*y1+cScanline->s_xpos;
	        pscreene = pscreen+cScanline->e_xpos-cScanline->s_xpos;
	    	for(; pscreen < pscreene; pscreen++)
            {
                *pscreen = pTexture[Texture_size_x*((int) ty)+((int) tx)];
                tx += tx_increase;
                ty += ty_increase;
            }
	        cScanline++;
        }
	    return;
	}
    cScanline = &Scanline[y1];
    pscreen = screen+screen_size_x*y1+cScanline->s_xpos;
    for(; y1 < y3; y1++) // Now draw the horizontal line list
    {
        length = cScanline->e_xpos-cScanline->s_xpos;
        tx_increase = (float) (cScanline->e_xtexel-cScanline->s_xtexel)/
                         (length+SMALL_NUMBER);
        ty_increase = (float) (cScanline->e_ytexel-cScanline->s_ytexel)/
                         (length+SMALL_NUMBER);
        tx = (float) cScanline->s_xtexel;
        ty = (float) cScanline->s_ytexel;
        pscreene = pscreen+cScanline->e_xpos-cScanline->s_xpos;
    	for(; pscreen < pscreene; pscreen++)
        {
            *pscreen = pTexture[Texture_size_x*((int) ty)+((int) tx)];
            tx += tx_increase;
            ty += ty_increase;
        }
        pscreen += screen_size_x-cScanline->e_xpos;
        cScanline++;
        pscreen += cScanline->s_xpos;
    }
} // end Draw_TexturePolygon_Float()

void Draw_TexturePolygon_NoFloat(UCHAR *screen, int x1, int y1, int tx1,
							     int ty1, int x2, int y2, int tx2, int ty2,
                                 int x3, int y3, int tx3, int ty3)
{ // begin Draw_TexturePolygon_NoFloat()
	register UCHAR *pTexture = Texture;
    register UCHAR *pscreen, *pscreene;
	SCAN_LINE *cScanline;
	int height, longest_side, ftemp, tx, ty, tx_increase, ty_increase, length;

	// Sort the triangle so that x1/y1 to the topmost, x2/y2 to the middle and
	// x3/y3 to the bottom positions:
    if(y1 > y2) { SWAP_INT(x1, x2); SWAP_INT(y1, y2); SWAP_INT(ty1, tx2);
    			  SWAP_INT(ty1, ty2);}
    if(y1 > y3) { SWAP_INT(x1, x3);	SWAP_INT(y1, y3); SWAP_INT(tx1, tx3);
                  SWAP_INT(ty1, ty3);}
    if(y2 > y3) { SWAP_INT(x2, x3);	SWAP_INT(y2, y3); SWAP_INT(tx2, tx3);
                  SWAP_INT(ty2, ty3);}
    height = y3-y1;
    if(!height) // The polygon is not visible!
    	return;
    // Calculate the longest side:
    ftemp = ((y2-y1) << 16)/height;
    longest_side = ((ftemp*(x3-x1)+((x1-x2 << 16))) >> 16);
    if(!longest_side) // The polygon is not visible!
	    return;
    // Now that we have the length of the longest scanline we can use that
    // to tell us which is left and which is the right side of the triangle.
    if(longest_side < 0)
    {
        // If longest is neg. we have the middle vertex on the right side.
        // Store the pointers for the right and left edge of the triangle.
    	scan_texturepolyline_NoFloat(x1, y1, tx1, ty1, x2, y2, tx2, ty2, 1);
    	scan_texturepolyline_NoFloat(x2, y2, tx2, ty2, x3, y3, tx3, ty3, 1);
    	scan_texturepolyline_NoFloat(x3, y3, tx3, ty3, x1, y1, tx1, ty1, 0);
    }
	else
    {
        // If longest is pos. we have the middle vertex on the left side.
        // Store the pointers for the left and right edge of the triangle.
    	scan_texturepolyline_NoFloat(x1, y1, tx1, ty1, x2, y2, tx2, ty2, 0);
    	scan_texturepolyline_NoFloat(x2, y2, tx2, ty2, x3, y3, tx3, ty3, 0);
    	scan_texturepolyline_NoFloat(x3, y3, tx3, ty3, x1, y1, tx1, ty1, 1);
    }
	if(Clipping)
    {
        if(y1 < VTop)
            y1 = VTop;
        if(y3 > VBottom)
            y3 = VBottom;
        cScanline = &Scanline[y1];
        for(; y1 < y3; y1++) // Now draw the horizontal line list
        {
            length = cScanline->e_xpos-cScanline->s_xpos;
            tx_increase = ((cScanline->e_xtexel-cScanline->s_xtexel) << 16)/
                          (length+SMALL_NUMBER);
            ty_increase = ((cScanline->e_ytexel-cScanline->s_ytexel) << 16)/
                          (length+SMALL_NUMBER);
            tx = cScanline->s_xtexel << 16;
            ty = cScanline->s_ytexel << 16;
			if(cScanline->s_xpos < VLeft)
            {
             	tx += tx_increase*(VLeft-cScanline->s_xpos);
            	ty += ty_increase*(VLeft-cScanline->s_xpos);
				cScanline->s_xpos = VLeft;
			}
			if(cScanline->e_xpos > VRight)
            	cScanline->e_xpos = VRight;
            pscreen = screen+screen_size_x*y1+cScanline->s_xpos;
    	    pscreene = pscreen+cScanline->e_xpos-cScanline->s_xpos;
	    	for(; pscreen < pscreene; pscreen++)
            {
                *pscreen = pTexture[Texture_size_x*(ty >> 16)+(tx >> 16)];
                tx += tx_increase;
                ty += ty_increase;
            }
    	    cScanline++;
        }
	    return;
	}
    cScanline = &Scanline[y1];
    pscreen = screen+screen_size_x*y1+cScanline->s_xpos;
    for(; y1 < y3; y1++) // Now draw the horizontal line list
    {
        length = cScanline->e_xpos-cScanline->s_xpos;
        tx_increase = ((cScanline->e_xtexel-cScanline->s_xtexel) << 16)/
                         (length+SMALL_NUMBER);
        ty_increase = ((cScanline->e_ytexel-cScanline->s_ytexel) << 16)/
                         (length+SMALL_NUMBER);
        tx = cScanline->s_xtexel << 16;
        ty = cScanline->s_ytexel << 16;
   	    pscreene = pscreen+cScanline->e_xpos-cScanline->s_xpos;
    	for(; pscreen < pscreene; pscreen++)
        {
            *pscreen = pTexture[Texture_size_x*(ty >> 16)+(tx >> 16)];
            tx += tx_increase;
            ty += ty_increase;
        }
        pscreen += screen_size_x-cScanline->e_xpos;
   	    cScanline++;
       	pscreen += cScanline->s_xpos;
    }
} // end Draw_TexturePolygon_NoFloat()

void scan_texturepolyline_Float(int x1, int y1, int tx1, int ty1, int x2,
                                int y2, int tx2, int ty2, BOOL page)
{ // begin scan_texturepolyline_Float()
	SCAN_LINE *cScanline, *eScanline;
    int length;
    float x, m, tx, ty, tx_increase, ty_increase;

    if(y2 == y1) // This isn't a horizontal line
    	return;
    if(y2 < y1)
    {
        SWAP_INT(x1, x2);
        SWAP_INT(y1, y2);
        SWAP_INT(tx1, tx2);
        SWAP_INT(ty1, ty2);
    }
    length = y2-y1;
    x = (float) x1;
    m = (float) (x2-x1)/length;
    tx = (float) tx1;
    tx_increase = (float) (tx2-tx1)/length;
    ty = (float) ty1;
    ty_increase = (float) (ty2-ty1)/length;
    if(Clipping)
    { // Clip the polygon:
        if(y2 > VBottom)
            y2 = VBottom;
        if(y1 < VTop)
        {
            x -= m*(y1-VTop);
            tx -= tx_increase*(y1-VTop);
            ty -= ty_increase*(y1-VTop);
            y1 = VTop;
        }
    }
	cScanline = &Scanline[y1];
	eScanline = &Scanline[y2];
    if(!page)
        for(; cScanline <= eScanline; cScanline++) // Go through each row
        {
            cScanline->s_xpos = (int) x; // Store the first x coordinate
            cScanline->s_xtexel = (int) tx; // Store the first tx coordinate
            cScanline->s_ytexel = (int) ty; // Store the first ty coordinate
            x += m; // Add our constant to x
            tx += tx_increase; // Add our constant to tx
            ty += ty_increase; // Add our constant to ty
        }
    else
        for(; cScanline <= eScanline; cScanline++) // Go through each row
        {
            cScanline->e_xpos = (int) x; // Store the last x coordinate
            cScanline->e_xtexel = (int) tx; // Store the last tx coordinate
            cScanline->e_ytexel = (int) ty; // Store the last ty coordinate
            x += m;	// Add our constant to x
            tx += tx_increase; // Add our constant to tx
            ty += ty_increase; // Add our constant to ty
        }
} // end scan_texturepolyline_Float()

void scan_texturepolyline_NoFloat(int x1, int y1, int tx1, int ty1, int x2,
                                  int y2, int tx2, int ty2, BOOL page)
{ // begin scan_texturepolyline_NoFloat()
	SCAN_LINE *cScanline, *eScanline;
    int length, x, m, tx, ty, tx_increase, ty_increase;

    if(y2 == y1) // This isn't a horizontal line
    	return;
    if(y2 < y1)
    {
        SWAP_INT(x1, x2);
        SWAP_INT(y1, y2);
        SWAP_INT(tx1, tx2);
        SWAP_INT(ty1, ty2);
    }
    length = y2-y1;
    x = x1 << 16;
    m =  ((x2-x1) << 16)/length;
    tx = tx1 << 16;
    tx_increase = ((tx2-tx1) << 16)/length;
    ty = ty1 << 16;
    ty_increase = ((ty2-ty1) << 16)/length;
    if(Clipping)
    { // Clip the polygon:
        if(y2 > VBottom)
            y2 = VBottom;
        if(y1 < VTop)
        {
            x -= m*(y1-VTop);
            tx -= tx_increase*(y1-VTop);
            ty -= ty_increase*(y1-VTop);
            y1 = VTop;
        }
    }
	cScanline = &Scanline[y1];
	eScanline = &Scanline[y2];
    if(!page)
        for(; cScanline <= eScanline; cScanline++) // Go through each row
        {
            cScanline->s_xpos = x >> 16; // Store the first x coordinate
            cScanline->s_xtexel = tx >> 16; // Store the first tx coordinate
            cScanline->s_ytexel = ty >> 16; // Store the first ty coordinate
            x += m; // Add our constant to x
            tx += tx_increase; // Add our constant to tx
            ty += ty_increase; // Add our constant to ty
        }
    else
        for(; cScanline <= eScanline; cScanline++) // Go through each row
        {
            cScanline->e_xpos = x >> 16; // Store the last x coordinate
            cScanline->e_xtexel = tx >> 16; // Store the last tx coordinate
            cScanline->e_ytexel = ty >> 16; // Store the last ty coordinate
            x += m;	// Add our constant to x
            tx += tx_increase; // Add our constant to tx
            ty += ty_increase; // Add our constant to ty
        }
} // end scan_texturepolyline_NoFloat()

/*
*******************************************************************************
							 Textured Shade Polygon
*******************************************************************************
*/

void Draw_TextureShadePolygon_Float(UCHAR *screen, int x1, int y1, UCHAR c1,
     	int tx1, int ty1, int x2, int y2, UCHAR c2, int tx2, int ty2, int x3,
        int y3, UCHAR c3, int tx3, int ty3)
{ // begin Draw_TextureShadePolygon_Float()
	register UCHAR *pTexture = Texture;
    UCHAR *pscreen, *pscreene;
	SCAN_LINE *cScanline;
	int height, longest_side, length, test;
    float ftemp, shade, shade_increase, tx, ty, tx_increase, ty_increase;
    UCHAR color;

	// Sort the triangle so that x1/y1 to the topmost, x2/y2 to the middle and
	// x3/y3 to the bottom positions:
    if(y1 > y2) { SWAP_INT(x1, x2); SWAP_CHAR(c1, c2); SWAP_INT(y1, y2);
                  SWAP_INT(ty1, tx2); SWAP_INT(ty1, ty2);}
    if(y1 > y3) { SWAP_INT(x1, x3);	SWAP_INT(y1, y3); SWAP_CHAR(c1, c3);
    			  SWAP_INT(tx1, tx3); SWAP_INT(ty1, ty3);}
    if(y2 > y3) { SWAP_INT(x2, x3);	SWAP_INT(y2, y3); SWAP_CHAR(c2, c3);
    		      SWAP_INT(tx2, tx3); SWAP_INT(ty2, ty3);}
    height = y3-y1;
    if(!height) // The polygon is not visible!
    	return;
    // Calculate the longest side:
    ftemp = (float) (y2-y1)/height;
    longest_side = (int) (ftemp*(x3-x1)+(x1-x2));
    if(!longest_side) // The polygon is not visible!
	    return;
    // Now that we have the length of the longest scanline we can use that
    // to tell us which is left and which is the right side of the triangle.
    if(longest_side < 0)
    {
        // If longest is neg. we have the middle vertex on the right side.
        // Store the pointers for the right and left edge of the triangle.
    	scan_textureshadepolyline_Float(x1, y1, c1, tx1, ty1, x2, y2, c2, tx2,
        							    ty2, 1);
    	scan_textureshadepolyline_Float(x2, y2, c2, tx2, ty2, x3, y3, c3, tx3,
        						        ty3, 1);
    	scan_textureshadepolyline_Float(x3, y3, c3, tx3, ty3, x1, y1, c1, tx1,
        								ty1, 0);
    }
	else
    {
        // If longest is pos. we have the middle vertex on the left side.
        // Store the pointers for the left and right edge of the triangle.
    	scan_textureshadepolyline_Float(x1, y1, c1, tx1, ty1, x2, y2, c2, tx2,
        							    ty2, 0);
    	scan_textureshadepolyline_Float(x2, y2, c2, tx2, ty2, x3, y3, c3, tx3,
        						        ty3, 0);
    	scan_textureshadepolyline_Float(x3, y3, c3, tx3, ty3, x1, y1, c1, tx1,
        								ty1, 1);
    }
    if(Clipping)
    {
        if(y1 < VTop)
            y1 = VTop;
        if(y3 > VBottom)
            y3 = VBottom;
        cScanline = &Scanline[y1];
        for(; y1 < y3; y1++) // Now draw the horizontal line list
        {
            length = cScanline->e_xpos-cScanline->s_xpos;
            shade_increase = (float) (cScanline->e_shade-cScanline->s_shade)
                             /(length+SMALL_NUMBER);
            tx_increase = (float) (cScanline->e_xtexel-cScanline->s_xtexel)/
                             (length+SMALL_NUMBER);
            ty_increase = (float) (cScanline->e_ytexel-cScanline->s_ytexel)/
                             (length+SMALL_NUMBER);
            shade = (float) cScanline->s_shade;
            tx = (float) cScanline->s_xtexel;
            ty = (float) cScanline->s_ytexel;
			if(cScanline->s_xpos < VLeft)
            {
            	shade += shade_increase*(VLeft-cScanline->s_xpos);
             	tx += tx_increase*(VLeft-cScanline->s_xpos);
            	ty += ty_increase*(VLeft-cScanline->s_xpos);
            	cScanline->s_xpos = VLeft;
			}
            if(cScanline->e_xpos > VRight)
            	cScanline->e_xpos = VRight;
            pscreen = screen+screen_size_x*y1+cScanline->s_xpos;
	   	    pscreene = pscreen+cScanline->e_xpos-cScanline->s_xpos;
	    	for(; pscreen < pscreene; pscreen++)
            {
                test = pTexture[Texture_size_x*((int) ty)+((int) tx)]-shade;
                if(test > 255)
                    color = 255;
                else
                    if(test < 0)
                        color = 0;
                    else
                        color = test;
                *pscreen = color;
                shade += shade_increase;
                tx += tx_increase;
                ty += ty_increase;
            }
   		    cScanline++;
        }
	    return;
	}
    cScanline = &Scanline[y1];
    pscreen = screen+screen_size_x*y1+cScanline->s_xpos;
    for(; y1 < y3; y1++) // Now draw the horizontal line list
    {
        length = cScanline->e_xpos-cScanline->s_xpos;
        shade_increase = (float) (cScanline->e_shade-cScanline->s_shade)
                         /(length+SMALL_NUMBER);
        tx_increase = (float) (cScanline->e_xtexel-cScanline->s_xtexel)/
                         (length+SMALL_NUMBER);
        ty_increase = (float) (cScanline->e_ytexel-cScanline->s_ytexel)/
                         (length+SMALL_NUMBER);
        shade = (float) cScanline->s_shade;
        tx = (float) cScanline->s_xtexel;
        ty = (float) cScanline->s_ytexel;
   	    pscreene = pscreen+cScanline->e_xpos-cScanline->s_xpos;
    	for(; pscreen < pscreene; pscreen++)
        {
            test = pTexture[Texture_size_x*((int) ty)+((int) tx)]-shade;
            if(test > 255)
                color = 255;
            else
            	if(test < 0)
                	color = 0;
	            else
               		color = test;
            *pscreen = color;
            shade += shade_increase;
            tx += tx_increase;
            ty += ty_increase;
        }
        pscreen += screen_size_x-cScanline->e_xpos;
	    cScanline++;
   		pscreen += cScanline->s_xpos;
    }
} // end Draw_TextureShadePolygon_Float()

void Draw_TextureShadePolygon_NoFloat(UCHAR *screen, int x1, int y1, UCHAR c1,
     	int tx1, int ty1, int x2, int y2, UCHAR c2, int tx2, int ty2, int x3,
        int y3, UCHAR c3, int tx3, int ty3)
{ // begin Draw_TextureShadePolygon_NoFloat()
	register UCHAR *pTexture = Texture;
    UCHAR *pscreen, *pscreene;
	SCAN_LINE *cScanline;
	int height, longest_side, ftemp, tx, ty, tx_increase, shade, shade_increase,
        ty_increase, length, test;
    UCHAR color;

	// Sort the triangle so that x1/y1 to the topmost, x2/y2 to the middle and
	// x3/y3 to the bottom positions:
    if(y1 > y2) { SWAP_INT(x1, x2); SWAP_CHAR(c1, c2); SWAP_INT(y1, y2);
                  SWAP_INT(ty1, tx2); SWAP_INT(ty1, ty2);}
    if(y1 > y3) { SWAP_INT(x1, x3);	SWAP_INT(y1, y3); SWAP_CHAR(c1, c3);
    			  SWAP_INT(tx1, tx3); SWAP_INT(ty1, ty3);}
    if(y2 > y3) { SWAP_INT(x2, x3);	SWAP_INT(y2, y3); SWAP_CHAR(c2, c3);
    		      SWAP_INT(tx2, tx3); SWAP_INT(ty2, ty3);}
    height = y3-y1;
    if(!height) // The polygon is not visible!
    	return;
    // Calculate the longest side:
    ftemp = ((y2-y1) << 16)/height;
    longest_side = ((ftemp*(x3-x1)+((x1-x2 << 16))) >> 16);
    if(!longest_side) // The polygon is not visible!
	    return;
    // Now that we have the length of the longest scanline we can use that
    // to tell us which is left and which is the right side of the triangle.
    if(longest_side < 0)
    {
        // If longest is neg. we have the middle vertex on the right side.
        // Store the pointers for the right and left edge of the triangle.
    	scan_textureshadepolyline_NoFloat(x1, y1, c1, tx1, ty1, x2, y2, c2, tx2,
        								ty2, 1);
    	scan_textureshadepolyline_NoFloat(x2, y2, c2, tx2, ty2, x3, y3, c3, tx3,
                                        ty3, 1);
    	scan_textureshadepolyline_NoFloat(x3, y3, c3, tx3, ty3, x1, y1, c1, tx1,
        								ty1, 0);
    }
	else
    {
        // If longest is pos. we have the middle vertex on the left side.
        // Store the pointers for the left and right edge of the triangle.
    	scan_textureshadepolyline_NoFloat(x1, y1, c1, tx1, ty1, x2, y2, c2, tx2,
        								ty2, 0);
    	scan_textureshadepolyline_NoFloat(x2, y2, c2, tx2, ty2, x3, y3, c3, tx3,
                                        ty3, 0);
    	scan_textureshadepolyline_NoFloat(x3, y3, c3, tx3, ty3, x1, y1, c1, tx1,
        								ty1, 1);
    }
    if(Clipping)
    {
        if(y1 < VTop)
            y1 = VTop;
        if(y3 > VBottom)
            y3 = VBottom;
        cScanline = &Scanline[y1];
        for(; y1 < y3; y1++) // Now draw the horizontal line list
        {
            length = cScanline->e_xpos-cScanline->s_xpos;
            shade_increase = ((cScanline->e_shade-cScanline->s_shade) << 16)
                             /(length+SMALL_NUMBER);
            tx_increase = ((cScanline->e_xtexel-cScanline->s_xtexel) << 16)/
                             (length+SMALL_NUMBER);
            ty_increase = ((cScanline->e_ytexel-cScanline->s_ytexel) << 16)/
                             (length+SMALL_NUMBER);
            shade = (int) cScanline->s_shade << 16;
            tx = cScanline->s_xtexel << 16;
            ty = cScanline->s_ytexel << 16;
			if(cScanline->s_xpos < VLeft)
            {
            	shade += shade_increase*(VLeft-cScanline->s_xpos);
             	tx += tx_increase*(VLeft-cScanline->s_xpos);
            	ty += ty_increase*(VLeft-cScanline->s_xpos);
            	cScanline->s_xpos = VLeft;
			}
            if(cScanline->e_xpos > VRight)
            	cScanline->e_xpos = VRight;
            pscreen = screen+screen_size_x*y1+cScanline->s_xpos;
	   	    pscreene = pscreen+cScanline->e_xpos-cScanline->s_xpos;
        	for(; pscreen < pscreene; pscreen++)
            {
	            test = pTexture[Texture_size_x*(ty >> 16)+(tx >> 16)]-(shade >> 16);
                if(test > 255)
                    color = 255;
                else
                    if(test < 0)
                        color = 0;
                    else
                        color = test;
                *pscreen = color;
	            shade += shade_increase;
                tx += tx_increase;
                ty += ty_increase;
            }
		    cScanline++;
        }
	    return;
	}
    cScanline = &Scanline[y1];
    pscreen = screen+screen_size_x*y1+cScanline->s_xpos;
    for(; y1 < y3; y1++) // Now draw the horizontal line list
    {
        length = cScanline->e_xpos-cScanline->s_xpos;
        shade_increase = ((cScanline->e_shade-cScanline->s_shade) << 16)/
                         (length+SMALL_NUMBER);
        tx_increase = ((cScanline->e_xtexel-cScanline->s_xtexel) << 16)/
                         (length+SMALL_NUMBER);
        ty_increase = ((cScanline->e_ytexel-cScanline->s_ytexel) << 16)/
                         (length+SMALL_NUMBER);
        shade = (int) cScanline->s_shade << 16;
        tx = cScanline->s_xtexel << 16;
        ty = cScanline->s_ytexel << 16;
   	    pscreene = pscreen+cScanline->e_xpos-cScanline->s_xpos;
    	for(; pscreen < pscreene; pscreen++)
        {
            test = pTexture[Texture_size_x*(ty >> 16)+(tx >> 16)]-(shade >> 16);
            if(test > 255)
                color = 255;
            else
                if(test < 0)
                    color = 0;
                else
                    color = test;
            *pscreen = color;
            shade += shade_increase;
            tx += tx_increase;
            ty += ty_increase;
        }
        pscreen += screen_size_x-cScanline->e_xpos;
	    cScanline++;
		pscreen += cScanline->s_xpos;
    }
} // end Draw_TextureShadePolygon_NoFloat()

void scan_textureshadepolyline_Float(int x1, int y1, UCHAR c1, int tx1, int ty1,
		int x2, int y2, UCHAR c2, int tx2, int ty2, BOOL page)
{ // begin scan_texturepolyline_Float()
	SCAN_LINE *cScanline, *eScanline;
    int length;
    float x, m, tx, shade, shade_increase, ty, tx_increase, ty_increase;

    if(y2 == y1) // This isn't a horizontal line
    	return;
    if(y2 < y1)
    {
        SWAP_INT(x1, x2);
        SWAP_INT(y1, y2);
        SWAP_CHAR(c1, c2);
        SWAP_INT(tx1, tx2);
        SWAP_INT(ty1, ty2);
    }
    length = y2-y1;
    x = (float) x1;
    m = (float) (x2-x1)/length;
    shade = (float) c1;
    shade_increase = (float) (c2-c1)/length;
    tx = (float) tx1;
    tx_increase = (float) (tx2-tx1)/length;
    ty = (float) ty1;
    ty_increase = (float) (ty2-ty1)/length;
    if(Clipping)
    { // Clip the polygon:
        if(y2 > VBottom)
            y2 = VBottom;
        if(y1 < VTop)
        {
            x -= m*(y1-VTop);
            shade -= shade_increase*(y1-VTop);
            tx -= tx_increase*(y1-VTop);
            ty -= ty_increase*(y1-VTop);
            y1 = VTop;
        }
    }
	cScanline = &Scanline[y1];
	eScanline = &Scanline[y2];
    if(!page)
        for(; cScanline <= eScanline; cScanline++) // Go through each row
        {
            cScanline->s_xpos = (int) x; // Store the first x coordinate
            cScanline->s_shade = (UCHAR)shade;//Store the first shade coordinate
            cScanline->s_xtexel = (int) tx; // Store the first tx coordinate
            cScanline->s_ytexel = (int) ty; // Store the first ty coordinate
            x += m; // Add our constant to x
            shade += shade_increase; // Add our constant to shade
            tx += tx_increase; // Add our constant to tx
            ty += ty_increase; // Add our constant to ty
        }
    else
        for(; cScanline <= eScanline; cScanline++) // Go through each row
        {
            cScanline->e_xpos = (int) x; // Store the last x coordinate
            cScanline->s_shade = (UCHAR)shade;//Store the first shade coordinate
            cScanline->e_xtexel = (int) tx;//Store the last tx coordinate
            cScanline->e_ytexel = (int) ty; // Store the last ty coordinate
            x += m;	// Add our constant to x
            shade += shade_increase; // Add our constant to shade
            tx += tx_increase; // Add our constant to tx
            ty += ty_increase; // Add our constant to ty
        }
} // end scan_textureshadepolyline_Float()

void scan_textureshadepolyline_NoFloat(int x1, int y1, UCHAR c1, int tx1,
		int ty1, int x2, int y2, UCHAR c2, int tx2, int ty2, BOOL page)
{ // begin scan_textureshadepolyline_NoFloat()
	SCAN_LINE *cScanline, *eScanline;
    int length, x, m, tx, ty, tx_increase, ty_increase, shade, shade_increase;

    if(y2 == y1) // This isn't a horizontal line
    	return;
    if(y2 < y1)
    {
        SWAP_INT(x1, x2);
        SWAP_INT(y1, y2);
        SWAP_CHAR(c1, c2);
        SWAP_INT(tx1, tx2);
        SWAP_INT(ty1, ty2);
    }
    length = y2-y1;
    x = x1 << 16;
    m = ((x2-x1) << 16)/length;
    shade = c1 << 8;
    shade_increase = ((c2-c1) << 8)/length;
    tx = tx1 << 16;
    tx_increase = ((tx2-tx1) << 16)/length;
    ty = ty1 << 16;
    ty_increase = ((ty2-ty1) << 16)/length;
    if(Clipping)
    { // Clip the polygon:
        if(y2 > VBottom)
            y2 = VBottom;
        if(y1 < VTop)
        {
            x -= m*(y1-VTop);
            shade -= shade_increase*(y1-VTop);
            tx -= tx_increase*(y1-VTop);
            ty -= ty_increase*(y1-VTop);
            y1 = VTop;
        }
    }
	cScanline = &Scanline[y1];
	eScanline = &Scanline[y2];
    if(!page)
        for(; cScanline <= eScanline; cScanline++) // Go through each row
        {
            cScanline->s_xpos = x >> 16; // Store the first x coordinate
            cScanline->s_shade = (UCHAR) (shade >> 8); // Store the first shade
            										// coordinate
            cScanline->s_xtexel = tx >> 16; // Store the first tx coordinate
            cScanline->s_ytexel = ty >> 16; // Store the first ty coordinate
            x += m; // Add our constant to x
            shade += shade_increase; // Add our constant to shade
            tx += tx_increase; // Add our constant to tx
            ty += ty_increase; // Add our constant to ty
        }
    else
        for(; cScanline <= eScanline; cScanline++) // Go through each row
        {
            cScanline->e_xpos = x >> 16; // Store the last x coordinate
            cScanline->s_shade = (UCHAR) (shade >> 8); // Store the first shade
            										// coordinate
            cScanline->e_xtexel = tx >> 16; // Store the last tx coordinate
            cScanline->e_ytexel = ty >> 16; // Store the last ty coordinate
            x += m;	// Add our constant to x
            shade += shade_increase; // Add our constant to shade
            tx += tx_increase; // Add our constant to tx
            ty += ty_increase; // Add our constant to ty
        }
} // end scan_textureshadepolyline_NoFloat()


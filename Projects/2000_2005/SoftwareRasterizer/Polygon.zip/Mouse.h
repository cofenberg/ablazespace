/*
	Mouse.h

    Last change:
    	18.2.2000


    Autor:
    	Christian Ofenberg

	Mail: Christian-Ofenberg@gmx.de
	HomePage: http://members.tripod.de/Ofenberg


    Description:
    	This is the mouse class with all stuff.
*/

#ifndef MOUSE_H
#define MOUSE_H

    #define NO_MOUSE_BUTTON 0
    #define LEFT_MOUSE_BUTTON 1
    #define RIGHT_MOUSE_BUTTON 2
    #define BOTH_MOUSE_BUTTON 3

    #define NORMAL_MOUSE_STYLE 0

    // All things that we need to control the mouse:
    class MOUSE
    {
        private:
        public:
            short XPos, YPos; // The mouse position
            short BoundX, BoundY, BoundXB, BoundYH; // The mouse area
            BOOL Visible; // Is the mouse visible?
            char Style; // The mouse style
            short CursorB, CursorH; // The width and hight from the mouse
            char Button; // Shows the presses mouse button
            LPDIRECTDRAWSURFACE Bitmap; // The mouse bitmap

            char Init(void);
            char LoadBitmap(void);
            void Destroy(void);
            void ReleaseBitmap(void);
            void SetBound(short, short, short, short);
            void SetPos(short, short);
            void DrawOnBitmap(LPDIRECTDRAWSURFACE);
            void SetStyle(char);
            char CheckRect(short, short, short, short);
    }; /* class MOUSE */

    // Init the mouse:
    char MOUSE::Init(void)
    { // begin MOUSE::Init()
        Visible = TRUE;
        SetBound(0, 0, (short)(screen_size_x-1), (short)(screen_size_y-1));
        SetStyle(NORMAL_MOUSE_STYLE);
        CursorB = CursorH = 25;
        return NO_ERROR;
    } // end MOUSE::Init()

    // Loads the mouse bitmap:
    char MOUSE::LoadBitmap(void)
    { // begin MOUSE::LoadBitmap()
        Bitmap = DDLoadBitmap(lpDD, MAKEINTRESOURCE(IDB_BITMAP_MOUSE), 0, 0,
                              TRUE);
        DDSetColorKey(Bitmap, 5);
        return NO_ERROR;
    } // end MOUSE::LoadBitmap()

    // Delete the mouse:
    void MOUSE::Destroy(void)
    { // begin MOUSE::Destroy()
    	ReleaseBitmap();
    } // end MOUSE::Destroy()

    // Delete the mouse bitmap:
    void MOUSE::ReleaseBitmap(void)
    { // begin MOUSE::ReleaseBitmap()
        if(Bitmap != NULL)
        {
            Bitmap->Release();
            Bitmap = NULL;
        }
    } // end MOUSE::ReleaseBitmap()

    // Sets the mouse area:
    void MOUSE::SetBound(short x, short y, short xb, short yh)
    { // begin MOUSE::SetBound()
        BoundX = x;
        BoundY = y;
        BoundXB = xb;
        BoundYH = yh;
    } // end MOUSE::SetBound()

    // Sets the mouse position:
    void MOUSE::SetPos(short x, short y)
    { // begin MOUSE::SetPos()
        XPos = x;
        YPos = y;
    } // end MOUSE::SetPos()

    // Draw the mouse in a bitmap:
    void MOUSE::DrawOnBitmap(LPDIRECTDRAWSURFACE Picture)
    { // begin MOUSE::DrawOnBitmap()
        RECT rcRect;
        RECT ScreenRect;
        short x;

        if(Visible == FALSE)
            return;
        x = (short)(1+(Style*(CursorB+1)));
        rcRect.left   = x;
        rcRect.top    = CursorH+2;
        if(XPos > screen_size_x-CursorB)
            rcRect.right = x+screen_size_x-XPos;
        else
            rcRect.right  = x+CursorB;
        if(YPos > screen_size_y-CursorH)
            rcRect.bottom = CursorH+1+screen_size_y-YPos;
        else
            rcRect.bottom = CursorH+1+CursorH+1;
        SetRect(&rcRect, 0, 0, CursorB, CursorH);
        ScreenRect.left = 0;
        ScreenRect.top = 0;
        ScreenRect.right = screen_size_x;
        ScreenRect.bottom = screen_size_y;
        DrawBltFast(ScreenRect, Picture, XPos, YPos, Bitmap, rcRect,
                    DDBLTFAST_SRCCOLORKEY);
    } // MOUSE::DrawOnBitmap()

    // Sets the mouse style:
    void MOUSE::SetStyle(char MStyle)
    { // begin MOUSE::SetStyle()
        if(MStyle != NO_AKTIV)
            Style = MStyle;
    } // end MOUSE::SetStyle()

    // Check a mouse area:
    char MOUSE::CheckRect(short x, short y, short xb, short yh)
    { // begin MOUSE::CheckRect()
        if(XPos > x && XPos < xb && YPos > y && YPos < yh)
            return TRUE;
        return NO_AKTIV;
    } // end MOUSE::CheckRect()

#endif // MOUSE_H

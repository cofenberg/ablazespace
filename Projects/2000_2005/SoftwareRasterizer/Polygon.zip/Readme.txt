Polygon

Dieses Programm demonstriert Routinen zum Zeichnen von Polygonen mit
float oder int, und einen Clipping Algorithmus.

Tasten:
F1 - Licht Animation an/aus
TAB - Polygon rahmen an/aus
SPACE - Zwischen float und int Funktionen w�hlen(Manchmal kann man einen kleinen unterschied 
	erkennen, dies liegt an der kleinen Ungenauigkeit der int Funktion)
RETURN - Schaltet das Clipping an/aus
1 - Polygon einfarbig Ausf�llen
2 - Polygon schattiert Ausf�llen
3 - Polygon Texturieren
4 - Polygon Texturieren und Schattieren
Pfeiltasten zum Positionieren des zuletzt verschobenen Punktes 
Maus und Linke Taste: Zum positionieren des ersten Punktes
Maus und Rechte Taste: Zum positionieren des zweiten Punktes
Maus und beide Tasten: Zum positionieren des dritten Punktes

Zum testen der Geschwindigkeit(Das Polygon wird pro Bild �fter gemalt):
F2 - weniger Polygone
F3 - mehr Polygone


Das Polygon wurde beim Test nicht ver�ndert, wenn Sie also das Programm starten, so haben Sie
die selbe Ausgangsbasis wie ich.
Hier Bilder pro Sekunde auf meinem Rechner(P133):

Ausgef�llt(float): 41 FPS
Ausgef�llt(int): 42 FPS

Schattiert(float): 9 FPS
Schattiert(int): 42 FPS

Texturiert(float): 5 FPS
Texturiert(int): 28 FPS

Texturiert und Schattiert(float): 2 FPS
Texturiert und Schattiert(int): 22 FPS

Sie k�nnen den Werten entnehmen, dass die float Berechnungen auf meinem Rechner ungef�hr 5 mal 
langsamer ablaufen als die int Berechnungen. Es gibt jedoch auch Prozessoren, bei denen dies
ganz anders Aussieht. Testen Sie doch mal ihren Computer auf float und int unterschiede.

Die Routinen sind nur als lern Beispiele ausgelegt. Daher sind sie komplett in C++ geschrieben. 
Bei einer richtigen Anwendung w�re es empfehlenswert, Teile der Funktionen in Assembler zu 
schreiben. Au�erdem k�nnte man noch als Optimierung die Horizontalen gleich in der Zeichenschleife 
berechnen ohne sie vorher in einen Array zu speichern, und die �bergabe jeder einzelnen
Variable an eine Funktion ist auch nicht die beste L�sung.




    Autor:
    	Christian Ofenberg
	
	Mail: Christian-Ofenberg@gmx.de
	HomePage: http://members.tripod.de/Ofenberg

/*
	Line.cpp

    Last change:
    	18.2.2000


    Autor:
    	Christian Ofenberg

	Mail: Christian-Ofenberg@gmx.de
	HomePage: http://members.tripod.de/Ofenberg


    Description:

		Draw_Line_Float: Draws a line bewteen two points. This funktion use
                         float calculations.
		Draw_Line_NoFloat: Draws a line bewteen two points. This funktion use
                           int calculations.
		Draw_Bresenham_Line: Draws a line bewteen two points. This is the
        					 classic Bresenham Algorithmus.
		SetVisibleArea: Sets the visible area
        clip2d_line: This funktion clips a line into a given area.
*/

#define NAME "Line"
#define TITLE "Line"
#define MUTEX_NAME "Line"
#define NO_AKTIV -1
#define IDB_BITMAP_MOUSE 1
enum // The clipping Regions:
{
	CR_LEFT = 0x01,
	CR_TOP = 0x04,
	CR_RIGHT = 0x02,
	CR_BOTTOM = 0x08,
};
// Checks the Regin of a given Point, if it is in the visible Space, reg is
// equal 0:
#define CHECK_REGION(reg, x, y)\
{\
    reg = 0;\
    if(x < VLeft)\
        reg |= CR_LEFT;\
    else\
	    if(x > VRight)\
    	    reg |= CR_RIGHT;\
    if(y < VTop)\
        reg |= CR_TOP;\
    else\
	    if(y > VBottom)\
    	    reg |= CR_BOTTOM;\
}
// Swaps two int Variables:
#define SWAP_INT(a, b) { intswap = a; a = b; b = intswap; }


#include <windows.h>
#include <windowsx.h>
#include <ddraw.h>
#include <stdio.h>


BOOL WindowMode = 0; // Should the programm eun in a window?
int screen_size_x = 640, screen_size_y = 480; // Screen size
int g_x1 = 10, g_y1 = 10, g_x2 = 100, g_y2 = 100, *s_x, *s_y;
static HFONT hFont;
HDC hdc;
COLORREF BackColor = RGB(0,0,0);
COLORREF TextColor = RGB(255,255,255);
int SelectedPoint;
BOOL Float_Mode;
BOOL classic; // The used draw Algorithmus
BOOL Clipping; // Is the clipping on or off?
int VLeft, VTop, VRight, VBottom; // View Window


void Draw_Line_Float(UCHAR *screen, int x1, int y1, int x2, int y2,
                     UCHAR color);
void Draw_Line_NoFloat(UCHAR *screen, int x1, int y1, int x2, int y2,
                       UCHAR color);
void Draw_Bresenham_Line(UCHAR *screen, int x1, int y1, int x2, int y2,
					   UCHAR color);
void SetVisibleArea(int x1, int y1, int x2, int y2);
BOOL clip2d_line(BOOL *exists, int *c_x1, int *c_y1, int *c_x2, int *c_y2,
				 int x1, int y1, int x2, int y2);

#include "Tools.h"

// Checks the messages from Windows:
long FAR PASCAL WindowProc(HWND hWnd, UINT message,
                           WPARAM wParam, LPARAM lParam)
{ // begin WindowProc()
    switch( message )
    {
        case WM_LBUTTONDOWN:
        case WM_LBUTTONUP:
        case WM_RBUTTONDOWN:
        case WM_RBUTTONUP:
        case WM_MOUSEMOVE:
            Mouse.Button = (char)wParam;
            Mouse.XPos = (short)LOWORD(lParam);
            Mouse.YPos = (short)HIWORD(lParam);
            if(Mouse.XPos < Mouse.BoundX)
                Mouse.XPos = Mouse.BoundX;
            if(Mouse.YPos < Mouse.BoundY)
                Mouse.YPos = Mouse.BoundY;
            if(Mouse.XPos > Mouse.BoundXB)
                Mouse.XPos = Mouse.BoundXB;
            if(Mouse.YPos > Mouse.BoundYH)
                Mouse.YPos = Mouse.BoundYH;
        break;

        case WM_ACTIVATEAPP:
            // If we wanted to pause the application when it
            // became inactive, we could do so here. In this case,
            // we decided to make it active at all times. When it is
            // minimized to the task bar, it just updates position.
            if(wParam)
            	OutputDebugString("Application activated!\n ");
            else
            	OutputDebugString("Application deactivated!\n ");
            g_bAppIsActive = wParam;
            break;

        case WM_CREATE:
            break;

        case WM_SIZE:
            // Our window size is fixed, so this could
            // only be a minimize or maximize
            if(wParam == SIZE_MINIMIZED)
            {
                // We've been minimized, no need to
                // redraw the screen.
                InvalidateRect( hWnd, NULL, TRUE );
                g_bActive = FALSE;
            }
            else
                g_bActive = TRUE;
            return 0;

        case WM_MOVE:
            // get the client rectangle
            if(g_bFullScreen)
                SetRect(&g_rcWindow, 0, 0, GetSystemMetrics(SM_CXSCREEN),
                        GetSystemMetrics(SM_CYSCREEN));
            else
            {
                GetClientRect(hWnd, &g_rcWindow);
                ClientToScreen(hWnd, (LPPOINT)&g_rcWindow);
                ClientToScreen(hWnd, (LPPOINT)&g_rcWindow+1);
            }
            break;

        case WM_PALETTECHANGED:
            if((HWND)wParam != hWnd)
            {
                OutputDebugString("Palette lost.\n");
                lpDDSPrimary->SetPalette(lpDDPalette);
            }
            break;

        case WM_QUERYNEWPALETTE:
            // Ignore this message if we're transitioning -- we may
            // not yet have created the the surface and palette.
            if(!lpDDSPrimary || !lpDDPalette)
            {
                OutputDebugString("Ignoring palette message.\n");
                return TRUE;
            }
            // We have control of the palette.
            OutputDebugString("We have the palette.\n");
            lpDDSPrimary->SetPalette(lpDDPalette);
            break;

        case WM_SETCURSOR:
            if(g_bFullScreen)
            {
            	SetCursor(NULL);
                return FALSE;
            }
            return FALSE;

        case WM_PAINT:
			ShowWindow(g_hwnd, SW_SHOW);
            break;

        case WM_SYSKEYUP:
            switch(wParam)
            {
                // Alt+Enter
                case VK_RETURN:
                    OutputDebugString("Alt+Enter...\n");
                    if(!g_bAllowWindowed)
                        break;
                    g_bReInitialize = TRUE;
                    g_bFullScreen = !g_bFullScreen;
                    CleanUp();
                    if FAILED(DDInit())
                        OutputDebugString("Error: new Init.\n" );
                    // Here must you built your Data:
					Mouse.Destroy(); // Destroy the mouse
                    Mouse.LoadBitmap(); // Load the mouse bitmaps
                    ShowWindow(g_hwnd, SW_SHOW);
                    g_bReInitialize = FALSE;
                    break;
            }
            break;

        case WM_DESTROY:
            if(!g_bReInitialize)
                g_ExitProgramm = TRUE;
            return 0;

        case WM_COMMAND:
        break;

        case WM_KEYDOWN:
            switch(wParam)
            {
                case VK_ESCAPE:
                    g_ExitProgramm = TRUE;
	                break;

				case VK_LEFT:
                    *s_x -= 1;
	                break;

				case VK_UP:
                    *s_y -= 1;
	                break;

				case VK_RIGHT:
                    *s_x += 1;
	                break;

				case VK_DOWN:
                    *s_y += 1;
	                break;

				case VK_TAB:
                    if(classic == 1)
                    	classic = 0;
                    else
	                    classic = 1;
	                break;

				case VK_SPACE:
                    if(Float_Mode == 1)
                    	Float_Mode = 0;
                    else
	                    Float_Mode = 1;
	                break;

				case VK_RETURN:
                    if(Clipping == 1)
                    	Clipping = 0;
                    else
	                    Clipping = 1;
	                break;

				case VK_SUBTRACT:
                    if(VLeft < screen_size_x/2-10)
                    	VLeft += 1;
                    if(VTop < screen_size_y/2+5)
                    	VTop += 1;
                    if(VRight >= screen_size_x/2+10)
                    	VRight -= 1;
                    if(VBottom >= screen_size_y/2+10)
                    	VBottom -= 1;
	                break;

				case VK_ADD:
                    if(VLeft >= 1)
                    	VLeft -= 1;
                    if(VTop >= 1)
                    	VTop -= 1;
                    if(VRight <= screen_size_x-2)
                    	VRight += 1;
                    if(VBottom <= screen_size_y-2)
                    	VBottom += 1;
	                break;
            }
        break;
    }
    return DefWindowProc(hWnd, message, wParam, lParam);
} // end WindowProc()

int PASCAL WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    LPSTR lpCmdLine, int nCmdShow)
{ // begin WinMain()
    MSG         msg;
    UCHAR *dest;
    DDSURFACEDESC ddsd;
    RECT rc;

    if(WindowMode == FALSE)
		g_bFullScreen = TRUE;
	else
    	g_bFullScreen = FALSE;
    if(!doInit(hInstance, nCmdShow))
       	return FALSE;
    Mouse.Init(); // Init the mouse
    Mouse.LoadBitmap(); // Load the mouse bitmaps
    s_x = &g_x1;
    s_y = &g_y1;
	SelectedPoint = 1;
	Float_Mode = 0;
    classic = 1;
    Clipping = TRUE; // Activate the cliping
    // Define a visible area:
	SetVisibleArea(30, 30, screen_size_x-31, screen_size_y-31);
    for(;;)
    {
    	if(PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
    	{
        	if(!GetMessage(&msg, NULL, 0, 0))
            	return msg.wParam;
        	TranslateMessage(&msg);
        	DispatchMessage(&msg);
    	}
		else
		{
            if(!g_bActive) // The programm is just breaked
	            continue;
            if(g_ExitProgramm == TRUE)
                break;
            if(Mouse.Button == LEFT_MOUSE_BUTTON)
	        {
                s_x = &g_x1;
                s_y = &g_y1;
                *s_x = (int) Mouse.XPos;
     	        *s_y = (int) Mouse.YPos;
                SelectedPoint = 1;
            }
            if(Mouse.Button == RIGHT_MOUSE_BUTTON)
	        {
                s_x = &g_x2;
                s_y = &g_y2;
                *s_x = (int) Mouse.XPos;
     	        *s_y = (int) Mouse.YPos;
                SelectedPoint = 2;
            }
			DDFillSurface(lpDDSBack, 0);
            // Get informations on screen:
            if(IDirectDrawSurface_GetDC(lpDDSBack, &hdc) == DD_OK)
            {
                SelectObject(hdc, hFont);
                SetTextColor(hdc, TextColor);
                SetBkColor(hdc, BackColor);
                SetBkMode(hdc, OPAQUE);
                SetRect(&rc, 0, 0, 10000, 10000);
                sprintf(temp, "%d, %d, %d, %d", VLeft, VTop, VRight, VBottom);
                if(classic)
                	if(Clipping)
                  		sprintf(temp, "C Bresenham- P1: %d/%d   P2: %d/%d"
                        	          " SelectedPoint: %d", g_x1, g_y1, g_x2,
                                g_y2, SelectedPoint);
	                else
                        sprintf(temp, "Bresenham- P1: %d/%d   P2: %d/%d"
                                      " SelectedPoint: %d", g_x1, g_y1, g_x2,
                                g_y2, SelectedPoint);
                else
                   if(Float_Mode == 1)
                   {
                       if(Clipping)
                           sprintf(temp, "C Float- P1: %d/%d   P2: %d/%d"
                                         " SelectedPoint: %d", g_x1, g_y1, g_x2,
                                   g_y2, SelectedPoint);
                       else
                           sprintf(temp, "Float- P1: %d/%d   P2: %d/%d"
                                         " SelectedPoint: %d", g_x1, g_y1, g_x2,
                                   g_y2, SelectedPoint);
                   }
                   else
                   {
                       if(Clipping)
                           sprintf(temp, "C int- P1: %d/%d   P2: %d/%d"
                                         " SelectedPoint: %d", g_x1, g_y1, g_x2,
                                         g_y2, SelectedPoint);
                       else
                           sprintf(temp, "int- P1: %d/%d   P2: %d/%d"
                                         " SelectedPoint: %d", g_x1, g_y1, g_x2,
                                         g_y2, SelectedPoint);
                   }
                ExtTextOut(hdc, 0, 0, ETO_OPAQUE, &rc, temp, strlen(temp),
                           NULL);
                IDirectDrawSurface_ReleaseDC(lpDDSBack, hdc);
            }
		    ZeroMemory(&ddsd, sizeof(ddsd));
		    ddsd.dwSize = sizeof(ddsd);
		    ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH;
		    ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_SYSTEMMEMORY;
            if(WindowMode)
                lpDDSBack->Lock(NULL, &ddsd, DDLOCK_NOSYSLOCK, NULL);
            else
                lpDDSBack->Lock(NULL, &ddsd, DDLOCK_WAIT, NULL);
		    if(ddsd.lpSurface == NULL)
	    		continue;
		    dest = (BYTE *)ddsd.lpSurface;
            if(classic)
                Draw_Bresenham_Line(dest, g_x1, g_y1, g_x2, g_y2, 11);
            else
                if(Float_Mode == 1)
                    Draw_Line_Float(dest, g_x1, g_y1, g_x2, g_y2, 11);
                else
                    Draw_Line_NoFloat(dest, g_x1, g_y1, g_x2, g_y2, 11);
            // Draw now the visible area frame:
		    if(Clipping)
                if(Float_Mode == 1)
                {
                    Draw_Line_Float(dest, VLeft, VTop, VLeft, VBottom, 15);
                    Draw_Line_Float(dest, VLeft, VTop, VRight, VTop, 15);
                    Draw_Line_Float(dest, VRight, VTop, VRight, VBottom, 15);
                    Draw_Line_Float(dest, VLeft, VBottom, VRight, VBottom, 15);
                }
                else
                {
                    Draw_Line_NoFloat(dest, VLeft, VTop, VLeft, VBottom, 15);
                    Draw_Line_NoFloat(dest, VLeft, VTop, VRight, VTop, 15);
                    Draw_Line_NoFloat(dest, VRight, VTop, VRight, VBottom, 15);
                    Draw_Line_NoFloat(dest, VLeft, VBottom, VRight, VBottom,
                                      15);
                }
		    lpDDSBack->Unlock(NULL);
            Mouse.DrawOnBitmap(lpDDSBack);
			UpdateFrame(g_bActive);
        }
    }
    Mouse.Destroy(); // Destroy the mouse
    CleanUp();
    PostQuitMessage( 0 );
	return 0;
} // end WinMain()



/* 								Demonstration of:
void Draw_Line_Float(UCHAR *screen, int x1, int y1, int x2, int y2,
					 UCHAR color);
void Draw_Line_NoFloat(UCHAR *screen, int x1, int y1, int x2, int y2,
				       UCHAR color);
void Draw_Bresenham_Line(UCHAR *screen, int x1, int y1, int x2, int y2,
					   UCHAR color);
void SetVisibleArea(int x1, int y1, int x2, int y2);
BOOL clip2d_line(BOOL *exists, int *c_x1, int *c_y1, int *c_x2, int *c_y2,
                 int x1, int y1, int x2, int y2);
*/

void Draw_Line_Float(UCHAR *screen, int x1, int y1, int x2, int y2, UCHAR color)
{ // begin Draw_Line_NoFloat()
    BOOL exists;
	int intswap; // Temp Variable for int Type
    int width, height, length, multi;
    float x_pos, y_pos, x_increase, y_increase;

    if(Clipping)
    { // Because the line clipping is activated, we are clipping now:
       clip2d_line(&exists, &x1, &y1, &x2, &y2, x1, y1, x2, y2);
       if(!exists) // We needn't to draw the line
           return;
    }
    if(y2 < y1) // It is strong important, that y1 is smaller than y2!
    {
        SWAP_INT(x1, x2);
        SWAP_INT(y1, y2);
    }
    width = x2-x1; // Calculate delta x
    height = y2-y1; // Calculate delta y
    if(!width)
    { // We have only to draw a vertical line:
        for(; height > -1; height--)
			// Draw point
            screen[screen_size_x*((int) y1+height)+((int) x1)] = color;
    	return;
    }
    if(!height)
    { // We have only to draw a horizontal line:
        if(x1 < x2)
	        for(; width > -1; width--)
			// Draw point
    	        screen[screen_size_x*((int) y1)+((int) x1+width)] = color;
        else
	        for(; width < 0; width++)
			// Draw point
    	        screen[screen_size_x*((int) y1)+((int) x2-width)] = color;

    	return;
    }
    if(width < 0)
    {
	    width = -width;
	    multi = -1;
    }
    else
	    multi = 1;
    if(width < height)
    {
	    x_increase = (float) width / height; // Calculate line increase
	    x_increase *= multi;
	    y_increase = 1;
	    length = height + 1;
    }
    else
    {
	    x_increase = 1;
	    x_increase *= multi;
	    y_increase = (float) height / width; // Calculate line increase
	    length = width + 1;
    }
    x_pos = (float) x1; // lay down the x start position
    y_pos = (float) y1; // lay down the y start position
    for(; length > 0; length--)
    {
		// Draw point
	    screen[screen_size_x*((int) y_pos)+((int) x_pos)] = color;
	    x_pos += x_increase; // Calculate next point
  	    y_pos += y_increase; // Calculate next point
    }
} // end Draw_Line_Float()

void Draw_Line_NoFloat(UCHAR *screen, int x1, int y1, int x2, int y2,
					   UCHAR color)
{ // begin Draw_Line_NoFloat()
    BOOL exists;
	int intswap; // Temp Variable for int Type
	int width, height, length, x_pos, y_pos, x_increase, y_increase,
        multi;

    if(Clipping)
    { // Because the line clipping is activated, we are clipping now:
       clip2d_line(&exists, &x1, &y1, &x2, &y2, x1, y1, x2, y2);
       if(!exists) // We needn't to draw the line
           return;
    }
    if(y2 < y1) // It is strong important, that y1 is smaller than y2!
    {
        SWAP_INT(x1, x2);
        SWAP_INT(y1, y2);
    }
    width = x2-x1; // Calculate delta x
    height = y2-y1; // Calculate delta y
    if(!width)
    { // We have only to draw a vertical line:
        for(; height > -1; height--)
			// Draw point
            screen[screen_size_x*(y1+height)+x1] = color;
    	return;
    }
    if(!height)
    { // We have only to draw a horizontal line:
        if(x1 < x2)
	        for(; width > -1; width--)
				// Draw point
    	        screen[screen_size_x*y1+x1+width] = color;
        else
	        for(; width < 0; width++)
    			// Draw point
    	        screen[screen_size_x*y1+x2-width] = color;

    	return;
    }
    if(width < 0)
    {
	    width = -width;
	    multi = -1;
    }
    else
	    multi = 1;
    if(width < height)
    {
	    x_increase = width << 16;
	    x_increase /= height; // Calculate line increase
	    x_increase *= multi;
	    y_increase = 1 << 16;
	    length = height + 1;
	}
    else
    {
	    x_increase = 1 << 16;
	    x_increase *= multi;
	    y_increase = height << 16;
	    y_increase /= width; // Calculate line increase
	    length = width + 1;
    }
    x_pos = x1 << 16; // lay down the x start position
    y_pos = y1 << 16; // lay down the y start position
    for(; length > 0; length--)
    {
		// Draw point
	    screen[screen_size_x*(y_pos >> 16)+(x_pos >> 16)] = color;
	    x_pos += x_increase; // Calculate next x point
	    y_pos += y_increase; // Calculate next y point
    }
} // end Draw_Line_NoFloat()

void Draw_Bresenham_Line(UCHAR *screen, int x1, int y1, int x2, int y2,
					   UCHAR color)
{ // begin Draw_Bresenham_Line()
    BOOL exists;
	int intswap; // Temp Variable for int Type
	short mod, dx, dy, sgn_dy;

    if(Clipping)
    { // Because the line clipping is activated, we are clipping now:
       clip2d_line(&exists, &x1, &y1, &x2, &y2, x1, y1, x2, y2);
       if(!exists) // We needn't to draw the line
           return;
    }
    // Now follows the Bresenham Algorithmus:
    if(x2 - x1 < 0)	{ SWAP_INT(x1, x2); SWAP_INT(y1, y2); }
    dx = x2 - x1;
    if(y2 - y1 > 0)
    	dy = y2 - y1, sgn_dy = 1;
    else
    	dy = y1 - y2, sgn_dy = -1;
    if(dy <= dx)
    	for(mod = -((dx+1) >> 1);; x1++, mod += dy)
        {
        	if(mod >= 0)
            {                                         
                y1 += sgn_dy;
                mod -= dx;
			}
            // Draw point
		    screen[screen_size_x*y1+x1] = color;
            if(x1 == x2)
            	return;
        }
    else
    	for(mod = -((dy+1) >> 1);; y1 += sgn_dy, mod += dx)
        {
        	if(mod >= 0)
            {
                x1++;
                mod -= dy;
			}
            // Draw point
		    screen[screen_size_x*y1+x1] = color;
            if(y1 == y2)
            	return;
        }
} // end Draw_Bresenham_Line()

void SetVisibleArea(int x1, int y1, int x2, int y2)
{ // begin SetVisibleArea()
    VLeft = x1;
    VTop = y1;
    VRight = x2;
    VBottom = y2;
} // end SetVisibleArea()

BOOL clip2d_line(BOOL *exists, int *c_x1, int *c_y1, int *c_x2, int *c_y2,
							   int x1, int y1, int x2, int y2)
/*
	exists: Is the line outside the clipping region? Than FALSE!
    c_x1, c_y1: The clipped first point.
    c_x2, c_y2: The clipped second point.
    x1, y1: The first point.
    x2, y2: The second point.
*/
{ // begin clip2d_line
	int intswap; // Temp Variable for int Type
	char reg1, reg2; // The regions of the two points
    int outside = 0;

    *exists = TRUE;
    CHECK_REGION(reg1, x1, y1); // Check the region of the first point
    CHECK_REGION(reg2, x2, y2); // Check the region of the second point
    if(reg1)
    	outside++; // The fist point is outside of the visible space
    if(reg2)
    	outside++; // The second point is outside of the visible space
    if(!outside)      // Both point are complet is the visible space, we do not
    	return FALSE; // require clipping
	// Now starts the clipping:
    while(reg1 | reg2)
    {
		if(reg1 & reg2)
        { // The line is not visible:
        	*exists = FALSE;
        	return TRUE;
        }
      	if(reg1 == 0)
        {
        	SWAP_INT(reg1, reg2);
         	SWAP_INT(x1, x2); SWAP_INT(y1, y2);
      	}
      	if(reg1 & CR_LEFT)
      	{
       	    y1 += ((y2-y1)*(VLeft-x1)/(x2-x1));
         	x1 = VLeft;
      	}
      	else
            if(reg1 & CR_RIGHT)
            {
                y1 += ((y2-y1)*(VRight-x1))/(x2-x1);
                x1 = VRight;
            }
            else
                 if(reg1 & CR_TOP)
                 {
                     x1 += ((x2-x1)*(VTop-y1))/(y2-y1);
                   	 y1 = VTop;
                 }
                 else
                     if(reg1 & CR_BOTTOM)
                     {
                         x1 += ((x2-x1)*(VBottom-y1))/(y2-y1);
                         y1 = VBottom;
                     }
	  CHECK_REGION(reg1, x1, y1); // Check the region point
	}
    *c_x1 = x1;
    *c_y1 = y1;
    *c_x2 = x2;
    *c_y2 = y2;
    return TRUE;
} // end clip2d_line


Line

Dieses Programm demonstriert Routinen zum Zeichnen von Linien mit
float oder int, und einen Clipping Algorithmus.

Tasten:
TAB - Wechselt den zeichen Algorithmus
SPACE - Zwischen float und int Funktionen w�hlen(Manchmal kann man einen kleinen unterschied 
	erkennen, dies liegt an der kleinen Ungenauigkeit der int Funktion)
RETURN - Schaltet das Clipping an/aus
Pfeiltasten zum Positionieren des zuletzt verschobenen Punktes 
Maus und Linke Taste: Zum positionieren des ersten Punktes
Maus und Rechte Taste: Zum positionieren des zweiten Punktes


    Autor:
    	Christian Ofenberg
	
	Mail: Christian-Ofenberg@gmx.de
	HomePage: http://members.tripod.de/Ofenberg

#include <windows.h>
#include <stdio.h>

// Checks if a string ends which a given string:
BOOL CheckStringEnding(char *pbyText, char byEnding[256])
{
	_strlwr(pbyText);
	for(int i = 0; i < (signed) strlen(byEnding); i++)
	{
		if(pbyText[strlen(pbyText)-(strlen(byEnding)-i)] != byEnding[i])
			break;
	}
	if(i == (signed) strlen(byEnding))
	   return TRUE;

	return FALSE;
} 

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine, int iCmdShow)
{
	WIN32_FIND_DATA FindFileData;
	char byTemp[256], byPath[256], byEnding[256],
 		 byProgramExeName[256],
		 byProgramDrive[256],
		 byProgramDir[256],
		 byProgramPath[256];
	HANDLE Find;
	FILE *fp;

	// Get the current program path:
	GetModuleFileName(NULL, byProgramExeName, 256);
	_splitpath(byProgramExeName, byProgramDrive, byProgramDir, NULL, NULL);
	sprintf(byProgramPath, "%s%s", byProgramDrive, byProgramDir);
	SetCurrentDirectory(byProgramPath);
	
	// Get settings from the config file:
	sprintf(byTemp, "%sconfig.ini", byProgramPath);
	BOOL bUsePath = GetPrivateProfileInt("general", "use_path", 0, byTemp);
	GetPrivateProfileString("general", "path", "", byPath, 256, byTemp);
	BOOL bOnlyEnding = GetPrivateProfileInt("general", "only_ending", 0, byTemp);
	GetPrivateProfileString("general", "ending", "", byEnding, 256, byTemp);
	
	// Open the list file:
	sprintf(byTemp, "%slist.txt", byProgramPath);
	fp = fopen(byTemp, "w");
	if(!fp)
	{
		printf("Couldn't create 'list.txt'!");
		return 1;
	}
	
	// Get the filenames and write them into the list:
	if(bUsePath)
		sprintf(byTemp, "%s*.*", byPath);
	else
		sprintf(byTemp, "*.*");

	// Get the first file:
	Find = FindFirstFile(byTemp, &FindFileData);
	for(;;)
	{
		// Transform the string to lower case for string comparing:
		strcpy(byTemp, FindFileData.cFileName);
		_strlwr(byTemp);

		// Check now if it's an right filename, if yes write it into the list:
		if(strcmp(byTemp, ".") && strcmp(byTemp, "..") &&
		   strcmp(byTemp, "list.exe") && strcmp(byTemp, "list.txt"))
			if(bOnlyEnding && CheckStringEnding(byTemp, byEnding) || // Check its ending:
			   !bOnlyEnding)
				fprintf(fp, "%s\n", FindFileData.cFileName);
		
		// Get the next file:
		if(!FindNextFile(Find, &FindFileData))
			break;
	}
	fclose(fp);

	// That's all!
	return 0;
}
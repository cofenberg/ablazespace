#define HELP_TEXT_MENU 3
#define HELP_TIPS_MENU 4
#define HELP_KEY_MENU 5
#define ABOUT_MENU 6

void LoadBarMenuBitmaps(void);
void DestroyBarMenuBitmaps(void);
int CheckMouseBarMenu(void);
void DrawBarMenu(void);

int MenuBar;
int MenuBar_SpielMenu;
int MenuBar_HelpMenu;
int MenuBar_HelpChooseMenu;
int MenuBar_OptionsMenu;
int MenuBar_LanguageChooseMenu;
LPDIRECTDRAWSURFACE BarBitmap;
#include "UnderMenus.h"

void LoadBarMenuBitmaps(void)
{
    BarBitmap = DDLoadBitmap(lpDD, "Bilder/Bar.bmp", 0, 0, NO);
    DDSetColorKey(BarBitmap, 5);
} /* LoadBarMenuBitmaps */

void DestroyBarMenuBitmaps(void)
{
    BarBitmap->Release();
} /* DestroyBarMenuBitmaps */

int CheckMouseBarMenu(void)
{
    if(MenuBar == NO)
    {
    	if(Mouse.YPos == 0)
        {
        	MenuBar = YES;
            MenuBar_SpielMenu = NO;
            MenuBar_HelpMenu = NO;
			MenuBar_HelpChooseMenu = NO;
        	return YES;
        }
    }
    if(MenuBar == YES)
    {
		if(CheckMouseRect(10, 0, 110, 20) != NO_AKTIV)
        {
            MenuBar_OptionsMenu = NO;
            MenuBar_SpielMenu = YES;
            MenuBar_HelpMenu = NO;
        }
		if(CheckMouseRect(230, 0, 330, 20) != NO_AKTIV)
        {
            MenuBar_OptionsMenu = NO;
            MenuBar_HelpMenu = YES;
            MenuBar_SpielMenu = NO;
        }
		if(CheckMouseRect(120, 0, 220, 20) != NO_AKTIV)
        {
            MenuBar_OptionsMenu = YES;
            MenuBar_HelpMenu = NO;
            MenuBar_SpielMenu = NO;
        }
    	if(MenuBar_SpielMenu == YES && Mouse.Button == LEFT_MOUSE_BUTTON)
        {
			if(CheckMouseRect(10, 20, 110, 35) != NO_AKTIV)
            { // Neues Spiel Starten:
            }
			if(CheckMouseRect(10, 35, 110, 50) != NO_AKTIV)
            { // Spiel Abbrechen:
            }
			if(CheckMouseRect(10, 50, 110, 65) != NO_AKTIV)
            { // Spiel beenden:
			    ExitProgramm = YES;
            }
        }
    	if(MenuBar_HelpMenu == YES && Mouse.Button == LEFT_MOUSE_BUTTON)
        {
			if(CheckMouseRect(230, 35, 310, 50) != NO_AKTIV)
            { // About Text:
            	AboutMenu();
            }
        }
    	if(MenuBar_HelpMenu == YES && CheckMouseRect(230, 20, 310, 35) != NO_AKTIV)
        { // Hilfe Text:
            MenuBar_HelpChooseMenu = YES;
        }
    	else
        {
            if(CheckMouseRect(300, 20, 400, 100) == NO_AKTIV)
            	MenuBar_HelpChooseMenu = NO;
		}
        if(MenuBar_HelpChooseMenu == YES && Mouse.Button == LEFT_MOUSE_BUTTON)
        {
			if(CheckMouseRect(300, 20, 400, 35) != NO_AKTIV)
            {
                HelpTextMenu();
            }
			if(CheckMouseRect(300, 35, 400, 50) != NO_AKTIV)
            {
                HelpTipsMenu();
            }
			if(CheckMouseRect(300, 50, 400, 65) != NO_AKTIV)
            {
                HelpKeyMenu();
            }
        }

    	if(MenuBar_OptionsMenu == YES && CheckMouseRect(120, 20, 220, 35) != NO_AKTIV)
        { // Hilfe Text:
            MenuBar_LanguageChooseMenu = YES;
        }
    	else
        {
            if(CheckMouseRect(200, 20, 300, 100) == NO_AKTIV)
            	MenuBar_LanguageChooseMenu = NO;
		}
        if(MenuBar_LanguageChooseMenu == YES && Mouse.Button == LEFT_MOUSE_BUTTON)
        {
			if(CheckMouseRect(200, 20, 300, 35) != NO_AKTIV)
            {
                DestroyGameTexte();
                if(LoadGameTexte(LANGUAGE_GERMAN) == YES)
                    ExitProgramm = YES;
            }
			if(CheckMouseRect(200, 35, 300, 50) != NO_AKTIV)
            {
                DestroyGameTexte();
            	if(LoadGameTexte(LANGUAGE_ENGLISH) == YES)
                    ExitProgramm = YES;
            }
        }
	//////////////////
       	MenuBar = NO;
        if(Mouse.YPos < 20)
            MenuBar = YES;
		if(MenuBar_SpielMenu == YES && CheckMouseRect(10, 0, 90, 99) != NO_AKTIV)
        	MenuBar = YES;
		if(MenuBar_HelpMenu == YES && CheckMouseRect(220, 0, 310, 99) != NO_AKTIV)
        	MenuBar = YES;
		if(MenuBar_HelpChooseMenu == YES && CheckMouseRect(300, 0, 380, 99) != NO_AKTIV)
        	MenuBar = YES;
		if(MenuBar_OptionsMenu == YES && CheckMouseRect(120, 0, 220, 99) != NO_AKTIV)
        	MenuBar = YES;
		if(MenuBar_LanguageChooseMenu == YES && CheckMouseRect(200, 0, 300, 99) != NO_AKTIV)
        	MenuBar = YES;
        if(MenuBar == NO)
        {
            MenuBar_SpielMenu = NO;;
            MenuBar_HelpMenu = NO;
            MenuBar_HelpChooseMenu = NO;
        	return YES;
        }
	//////////////////
    }
    if(MenuBar == YES || MenuBar_SpielMenu == YES ||
    	MenuBar_HelpMenu == YES || MenuBar_HelpChooseMenu == YES)
		return YES;
    if(ProgrammModule == HELP_TEXT_MENU || ProgrammModule == HELP_TIPS_MENU || ProgrammModule == HELP_KEY_MENU ||
    	ProgrammModule == ABOUT_MENU)
	{
        if(CheckMouseRect(300, 420, 400, 440) != NO_AKTIV && Mouse.Button == LEFT_MOUSE_BUTTON)
            ProgrammModule = SavedProgrammModule;
    	return YES;
	}
    return NO;
} /* CheckMouseBarMenu */

void DrawBarMenu(void)
{
    RECT rcRect;

	if(MenuBar == YES)
    {
        SetRect(&rcRect, 0, 0, 640, 20);
        Back->BltFast(0, 0, BarBitmap, &rcRect, FALSE);
      // Zeigt die aktuelle Uhr Zeit:
        struct  time t;
        char temp[50];
        gettime(&t);
        sprintf(temp, "%2d:%02d:%02d", t.ti_hour, t.ti_min, t.ti_sec);
        PrintText(550, 5, temp, 1, 0, 1000, 1000, Back);
      ///////////////////////////////////////////////////
        PrintText(10, 5, "Spiel", 1, 0, 1000, 1000, Back);
        PrintText(120, 5, "Options", 1, 0, 1000, 1000, Back);
        PrintText(230, 5, "Help", 1, 0, 1000, 1000, Back);
        if(MenuBar_SpielMenu == YES)
        {
	        SetRect(&rcRect, 0, 20, 80, 100);
    	    Back->BltFast(10, 19, BarBitmap, &rcRect, FALSE);
            PrintText(10, 20, "Neu", 1, 0, 1000, 1000, Back);
            PrintText(10, 35, "Abbruch", 1, 0, 1000, 1000, Back);
            PrintText(10, 50, "Exit", 1, 0, 1000, 1000, Back);
        }
        if(MenuBar_HelpMenu == YES)
        {
	        SetRect(&rcRect, 0, 20, 80, 100);
    	    Back->BltFast(230, 20, BarBitmap, &rcRect, FALSE);
            PrintText(230, 20, "Help ->", 1, 0, 1000, 1000, Back);
            PrintText(230, 35, "About", 1, 0, 1000, 1000, Back);
        }
        if(MenuBar_HelpChooseMenu == YES)
        {
	        SetRect(&rcRect, 0, 20, 80, 100);
    	    Back->BltFast(300, 20, BarBitmap, &rcRect, FALSE);
            PrintText(300, 20, "Hilfe", 1, 0, 1000, 1000, Back);
            PrintText(300, 35, "Tips", 1, 0, 1000, 1000, Back);
            PrintText(300, 50, "Tasten", 1, 0, 1000, 1000, Back);
        }
        if(MenuBar_OptionsMenu == YES)
        {
	        SetRect(&rcRect, 0, 20, 80, 100);
    	    Back->BltFast(120, 20, BarBitmap, &rcRect, FALSE);
            PrintText(120, 20, "Sprache ->", 1, 0, 1000, 1000, Back);
        }
        if(MenuBar_LanguageChooseMenu == YES)
        {
	        SetRect(&rcRect, 0, 20, 80, 100);
    	    Back->BltFast(200, 20, BarBitmap, &rcRect, FALSE);
            PrintText(200, 20, "Deutsch", 1, 0, 1000, 1000, Back);
            PrintText(200, 35, "Englisch", 1, 0, 1000, 1000, Back);
        }
    }
} /* DrawBarMenu */
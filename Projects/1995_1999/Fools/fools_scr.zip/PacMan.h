void CheckMoveKeys(WPARAM, int);
void CheckPacManAni(void);
void CheckPacManWalk(void);

void CheckMoveKeys(WPARAM wParam, int MouseCon)
{
    if(MouseCon == YES)
    {
        if(GameInfo.DirectControl == NO)
        	return;
		if(Mouse.Button == RIGHT_MOUSE_BUTTON)
        {
            GameInfo.DirectControl = NO;
            Mouse.Show = YES;
        	return;
        }
        if(Mouse.LastXPos-COMMAND_PIXEL_TURN > Mouse.XPos)
        	Szenario.Info.PacManInfo[GameInfo.SelectedFool-FIRST_PACMAN].Befehl = WALK_LEFT;
        if(Mouse.LastYPos-COMMAND_PIXEL_TURN > Mouse.YPos)
           	Szenario.Info.PacManInfo[GameInfo.SelectedFool-FIRST_PACMAN].Befehl = WALK_UP;
        if(Mouse.LastXPos+COMMAND_PIXEL_TURN < Mouse.XPos)
           	Szenario.Info.PacManInfo[GameInfo.SelectedFool-FIRST_PACMAN].Befehl = WALK_RIGHT;
        if(Mouse.LastYPos+COMMAND_PIXEL_TURN < Mouse.YPos)
           	Szenario.Info.PacManInfo[GameInfo.SelectedFool-FIRST_PACMAN].Befehl = WALK_DOWN;
    	return;
	}
    switch(wParam)
    {
        case VK_NUMPAD2:
            if(GameInfo.DirectControl == YES)
            {
            	GameInfo.DirectControl = NO;
                Mouse.Show = YES;
                break;
            }
            if(GameInfo.SelectedFool != NO_AKTIV)
				GameInfo.DirectControl = YES;
        break;

        case VK_LEFT:
	        if(GameInfo.DirectControl == YES)
            {
            	Szenario.Info.PacManInfo[GameInfo.SelectedFool-FIRST_PACMAN].Befehl = WALK_LEFT;
	    	}
	    	else
            	MoveScreenLeft(SCROLL_SPEED);
        break;

        case VK_RIGHT:
	        if(GameInfo.DirectControl == YES)
            {
            	Szenario.Info.PacManInfo[GameInfo.SelectedFool-FIRST_PACMAN].Befehl = WALK_RIGHT;
	    	}
	    	else
	    		MoveScreenRight(SCROLL_SPEED);
        break;

        case VK_UP:
	        if(GameInfo.DirectControl == YES)
            {
            	Szenario.Info.PacManInfo[GameInfo.SelectedFool-FIRST_PACMAN].Befehl = WALK_UP;
	    	}
            else
	    		MoveScreenUp(SCROLL_SPEED);
        break;

        case VK_DOWN:
	        if(GameInfo.DirectControl == YES)
            {
            	Szenario.Info.PacManInfo[GameInfo.SelectedFool-FIRST_PACMAN].Befehl = WALK_DOWN;
	    	}
            else
		    	MoveScreenDown(SCROLL_SPEED);
        break;
 	}
} /* CheckMoveKeys */

void CheckPacManAni(void)
{
    int i;

    for(i = 0; i < MAX_PACMAN; i++)
    {
        if(Szenario.Info.PacManInfo[i].PacMan_ID != NO_AKTIV)
        {
            if(Szenario.Info.PacManInfo[i].AnimationTurn == 0)
            {
				Szenario.Info.PacManInfo[i].AnimationStep++;
                if(Szenario.Info.PacManInfo[i].AnimationStep > 9)
                	Szenario.Info.PacManInfo[i].AnimationTurn = 1;
            }
            if(Szenario.Info.PacManInfo[i].AnimationTurn == 1)
            {
				Szenario.Info.PacManInfo[i].AnimationStep--;
                if(Szenario.Info.PacManInfo[i].AnimationStep < 1)
                	Szenario.Info.PacManInfo[i].AnimationTurn = 0;

            }
        }
    }
} /* CheckPacManAni */

void CheckPacManWalk(void)
{
    int zufall, SaveX, SaveY, i;
    int x, y;

    for(i = 0; i < MAX_PACMAN; i++)
    {
	    SaveX = Szenario.Info.PacManInfo[i].PosX;
    	SaveY = Szenario.Info.PacManInfo[i].PosY;
    	switch(Szenario.Info.PacManInfo[i].AktuellBefehl)
        {
            case NO_COMMAND:
                if(i == GameInfo.SelectedFool-FIRST_PACMAN)
    	        {
                    GameInfo.ScreenPixelPosX = 0;
	                GameInfo.ScreenPixelPosY = 0;
                }
                if(Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX][Szenario.Info.PacManInfo[i].PosY]].WallPicAniStepTurn == PUNKT)
                { // Der PacMan hat einen Punkt eingesammelt:
                    Szenario.Info.PunkteAnzahl--;
                    GameInfo.Points += 10;
                    Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX][Szenario.Info.PacManInfo[i].PosY]].WallPicAniStepTurn = NO_AKTIV;
                }
                if(Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX][Szenario.Info.PacManInfo[i].PosY]].Mask == ATOMIK)
                { // Oh!! Nicht sehr gut, der PacMan steht auf einem verstrahltem Feld:
                    zufall = random(3);
                    if(zufall == 0)
                    { // Autsch einen Energie Punkt weniger:
                        if(Szenario.Info.PacManInfo[i].Power > 0)
                            Szenario.Info.PacManInfo[i].Power--;
                    }
                }
                if(Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX][Szenario.Info.PacManInfo[i].PosY]].Mask == GESUND)
                {
                    zufall = random(3);
                    if(zufall == 0)
                    {
                        Szenario.Info.PacManInfo[i].Power++;
                        if(Szenario.Info.PacManInfo[i].Power > Szenario.Info.PacManInfo[i].MaxPower)
                            Szenario.Info.PacManInfo[i].Power = Szenario.Info.PacManInfo[i].MaxPower;
                    }
                }
                if(Szenario.Info.PacManInfo[i].Power < 1)
                { // Tja, da� wars!!
                    Szenario.Info.PacManInfo[i].Power = 0;
                    Szenario.Info.PacManInfo[i].LastWalk = YES;
                    if(Szenario.Info.PacManInfo[i].PixelPosX == 0 && Szenario.Info.PacManInfo[i].PixelPosY == 0)
                    {
//                        CheckPacManDead(i);
                        continue;
                    }
                }
                if(Szenario.Info.PacManInfo[i].Befehl == NO_COMMAND)
                	continue;
            	Szenario.Info.PacManInfo[i].AktuellBefehl = Szenario.Info.PacManInfo[i].Befehl;
                switch(Szenario.Info.PacManInfo[i].AktuellBefehl)
                {
                    case WALK_LEFT:
                        Szenario.Info.PacManInfo[i].Richtung = WALK_LEFT;
                        Szenario.Info.PacManInfo[i].Animation = WALK_LEFT;
                        if(Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX-1][Szenario.Info.PacManInfo[i].PosY]].WallPic == SPECIAL_EXIT ||
                            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX-1][Szenario.Info.PacManInfo[i].PosY]].WallPic == SPECIAL_EXIT_OVERLAY)
                        { // Der PacMan ist nun im Ziel!:
                            Szenario.Info.FoolInfo[i].Animation = ON_FINISH;
                            Szenario.Info.FoolInfo[i].AnimationStep = 0;
                            continue;
                        }
                      //////////////////////////////////////////////////
                     // Der Fool kann ohne die Gefahr in einen Abgrund zu st�rtzen weider gehen:
                        if(((Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX-1][Szenario.Info.PacManInfo[i].PosY]].WallPic != NO_AKTIV &&
                            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX-1][Szenario.Info.PacManInfo[i].PosY]].Mask != TAXI_KACHEL_SCHALTER &&
                            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX-1][Szenario.Info.PacManInfo[i].PosY]].Mask != BEAMER) ||
                            Szenario.Info.PacManInfo[i].PosX-1 < 0 || Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX-1][Szenario.Info.PacManInfo[i].PosY]].Besetzt != NO_AKTIV) &&
                            (Szenario.Info.PacManInfo[i].Richtung == WALK_LEFT || Szenario.Info.PacManInfo[i].Befehl == NO_COMMAND))
                        {  // Vor im befindet sich eine Wand:
                            Szenario.Info.PacManInfo[i].AktuellBefehl = NO_COMMAND;
                            continue;
                        }
                        else
                        {  // Der Weg ist frei, also geht der PacMan eine Kachel weiter:
                            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX][Szenario.Info.PacManInfo[i].PosY]].Besetzt = NO_AKTIV;
                            Szenario.Info.PacManInfo[i].PosX--;
                            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX][Szenario.Info.PacManInfo[i].PosY]].Besetzt = i+FIRST_PACMAN;
                            Szenario.Info.PacManInfo[i].PixelPosX = KACHEL_B;
                            if(i == GameInfo.SelectedFool-FIRST_PACMAN)
    				        {
                                GameInfo.ScreenPixelPosX = KACHEL_B;
                                x = Szenario.Info.PacManInfo[GameInfo.SelectedFool-FIRST_PACMAN].PosX;
                                y = Szenario.Info.PacManInfo[GameInfo.SelectedFool-FIRST_PACMAN].PosY;
                                CentereScreenPosition(&x, &y);
                                GameInfo.ScreenPosX = x;
                                GameInfo.ScreenPosY = y;
                            }
                        }
                    break;

                    case WALK_RIGHT:
                        Szenario.Info.PacManInfo[i].Richtung = WALK_RIGHT;
                        Szenario.Info.PacManInfo[i].Animation = WALK_RIGHT;
                        if(Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX+1][Szenario.Info.PacManInfo[i].PosY]].WallPic == SPECIAL_EXIT ||
                            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX+1][Szenario.Info.PacManInfo[i].PosY]].WallPic == SPECIAL_EXIT_OVERLAY)
                        {
                        }
                      //////////////////////////////////////////////////
                     // Der Fool kann ohne die Gefahr in einen Abgrund zu st�rtzen weider gehen:
                        if(((Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX+1][Szenario.Info.PacManInfo[i].PosY]].WallPic != NO_AKTIV &&
                            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX+1][Szenario.Info.PacManInfo[i].PosY]].Mask != TAXI_KACHEL_SCHALTER &&
                            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX+1][Szenario.Info.PacManInfo[i].PosY]].Mask != BEAMER) ||
                            Szenario.Info.PacManInfo[i].PosX+1 > Szenario.Info.KarteB || Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX+1][Szenario.Info.PacManInfo[i].PosY]].Besetzt != NO_AKTIV) &&
                            (Szenario.Info.PacManInfo[i].Richtung == WALK_RIGHT || Szenario.Info.PacManInfo[i].Befehl == NO_COMMAND))
                        {  // Vor im befindet sich eine Wand:
                            Szenario.Info.PacManInfo[i].AktuellBefehl = NO_COMMAND;
                            continue;
                        }
                        else
                        {  // Der Weg ist frei, also geht der PacMan eine Kachel weiter:
                            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX][Szenario.Info.PacManInfo[i].PosY]].Besetzt = NO_AKTIV;
                            Szenario.Info.PacManInfo[i].PosX++;
                            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX][Szenario.Info.PacManInfo[i].PosY]].Besetzt = i+FIRST_PACMAN;
                            Szenario.Info.PacManInfo[i].PixelPosX = -KACHEL_B;
                            if(i == GameInfo.SelectedFool-FIRST_PACMAN)
                            {
    				            GameInfo.ScreenPixelPosX = -KACHEL_B;
                                x = Szenario.Info.PacManInfo[GameInfo.SelectedFool-FIRST_PACMAN].PosX;
                                y = Szenario.Info.PacManInfo[GameInfo.SelectedFool-FIRST_PACMAN].PosY;
                                CentereScreenPosition(&x, &y);
                                GameInfo.ScreenPosX = x;
                                GameInfo.ScreenPosY = y;
                            }
                        }
                    break;

                    case WALK_UP:
                        Szenario.Info.PacManInfo[i].Richtung = WALK_UP;
                        Szenario.Info.PacManInfo[i].Animation = WALK_UP;
                      //////////////////////////////////////////////////
                     // Der Fool kann ohne die Gefahr in einen Abgrund zu st�rtzen weider gehen:
                        if(((Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX][Szenario.Info.PacManInfo[i].PosY-1]].WallPic != NO_AKTIV &&
                            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX][Szenario.Info.PacManInfo[i].PosY-1]].Mask != TAXI_KACHEL_SCHALTER &&
                            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX][Szenario.Info.PacManInfo[i].PosY-1]].Mask != BEAMER) ||
                            Szenario.Info.PacManInfo[i].PosY-1 < 0 || Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX][Szenario.Info.PacManInfo[i].PosY-1]].Besetzt != NO_AKTIV) &&
                            (Szenario.Info.PacManInfo[i].Richtung == WALK_UP || Szenario.Info.PacManInfo[i].Befehl == NO_COMMAND))
                        {  // Vor im befindet sich eine Wand:
                            Szenario.Info.PacManInfo[i].AktuellBefehl = NO_COMMAND;
                            continue;
                        }
                        else
                        {  // Der Weg ist frei, also geht der PacMan eine Kachel weiter:
                            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX][Szenario.Info.PacManInfo[i].PosY]].Besetzt = NO_AKTIV;
                            Szenario.Info.PacManInfo[i].PosY--;
                            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX][Szenario.Info.PacManInfo[i].PosY]].Besetzt = i+FIRST_PACMAN;
                            Szenario.Info.PacManInfo[i].PixelPosY = KACHEL_H;
                            if(i == GameInfo.SelectedFool-FIRST_PACMAN)
                            {
    				            GameInfo.ScreenPixelPosY = KACHEL_H;
                                x = Szenario.Info.PacManInfo[GameInfo.SelectedFool-FIRST_PACMAN].PosX;
                                y = Szenario.Info.PacManInfo[GameInfo.SelectedFool-FIRST_PACMAN].PosY;
                                CentereScreenPosition(&x, &y);
                                GameInfo.ScreenPosX = x;
                                GameInfo.ScreenPosY = y;
                            }
                        }
                    break;

                    case WALK_DOWN:
                        Szenario.Info.PacManInfo[i].Richtung = WALK_DOWN;
                        Szenario.Info.PacManInfo[i].Animation = WALK_DOWN;
                      //////////////////////////////////////////////////
                     // Der Fool kann ohne die Gefahr in einen Abgrund zu st�rtzen weider gehen:
                        if(((Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX][Szenario.Info.PacManInfo[i].PosY+1]].WallPic != NO_AKTIV &&
                            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX][Szenario.Info.PacManInfo[i].PosY+1]].Mask != TAXI_KACHEL_SCHALTER &&
                            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX][Szenario.Info.PacManInfo[i].PosY+1]].Mask != BEAMER) ||
                            Szenario.Info.PacManInfo[i].PosY+1 > Szenario.Info.KarteH || Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX][Szenario.Info.PacManInfo[i].PosY+1]].Besetzt != NO_AKTIV) &&
                            (Szenario.Info.PacManInfo[i].Richtung == WALK_DOWN || Szenario.Info.PacManInfo[i].Befehl == NO_COMMAND))
                        {  // Vor im befindet sich eine Wand:
                            Szenario.Info.PacManInfo[i].AktuellBefehl = NO_COMMAND;
                            continue;
                        }
                        else
                        {  // Der Weg ist frei, also geht der PacMan eine Kachel weiter:
                            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX][Szenario.Info.PacManInfo[i].PosY]].Besetzt = NO_AKTIV;
                            Szenario.Info.PacManInfo[i].PosY++;
                            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX][Szenario.Info.PacManInfo[i].PosY]].Besetzt = i+FIRST_PACMAN;
                            Szenario.Info.PacManInfo[i].PixelPosY = -KACHEL_H;
                            if(i == GameInfo.SelectedFool-FIRST_PACMAN)
                            {
    				            GameInfo.ScreenPixelPosY = -KACHEL_H;
                                x = Szenario.Info.PacManInfo[GameInfo.SelectedFool-FIRST_PACMAN].PosX;
                                y = Szenario.Info.PacManInfo[GameInfo.SelectedFool-FIRST_PACMAN].PosY;
                                CentereScreenPosition(&x, &y);
                                GameInfo.ScreenPosX = x;
                                GameInfo.ScreenPosY = y;
                            }
                        }
                    break;
                }
            break;

            case WALK_LEFT:
                if(Szenario.Info.PacManInfo[i].PixelPosX > 0)
                    Szenario.Info.PacManInfo[i].PixelPosX -= 3;
                else
                {
                    Szenario.Info.PacManInfo[i].AktuellBefehl = NO_COMMAND;
			        Szenario.Info.PacManInfo[i].Befehl = NO_COMMAND;
                }
                if(Szenario.Info.PacManInfo[i].PixelPosX < 0)
                {
	                Szenario.Info.PacManInfo[i].PixelPosX = 0;
	                Szenario.Info.PacManInfo[i].PixelPosY = 0;
                }
            break;

            case WALK_RIGHT:
                if(Szenario.Info.PacManInfo[i].PixelPosX < 0)
                    Szenario.Info.PacManInfo[i].PixelPosX += 3;
                else
                {
                    Szenario.Info.PacManInfo[i].AktuellBefehl = NO_COMMAND;
			        Szenario.Info.PacManInfo[i].Befehl = NO_COMMAND;
                }
                if(Szenario.Info.PacManInfo[i].PixelPosX > 0)
                {
	                Szenario.Info.PacManInfo[i].PixelPosX = 0;
	                Szenario.Info.PacManInfo[i].PixelPosY = 0;
                }
            break;

            case WALK_UP:
                if(Szenario.Info.PacManInfo[i].PixelPosY > 0)
                    Szenario.Info.PacManInfo[i].PixelPosY -= 3;
                else
                {
                    Szenario.Info.PacManInfo[i].AktuellBefehl = NO_COMMAND;
			        Szenario.Info.PacManInfo[i].Befehl = NO_COMMAND;
                }
                if(Szenario.Info.PacManInfo[i].PixelPosY < 0)
                {
	                Szenario.Info.PacManInfo[i].PixelPosX = 0;
	                Szenario.Info.PacManInfo[i].PixelPosY = 0;
                }
            break;

            case WALK_DOWN:
                if(Szenario.Info.PacManInfo[i].PixelPosY < 0)
                    Szenario.Info.PacManInfo[i].PixelPosY += 3;
                else
                {
                    Szenario.Info.PacManInfo[i].AktuellBefehl = NO_COMMAND;
			        Szenario.Info.PacManInfo[i].Befehl = NO_COMMAND;
                }
                if(Szenario.Info.PacManInfo[i].PixelPosY > 0)
                {
	                Szenario.Info.PacManInfo[i].PixelPosX = 0;
	                Szenario.Info.PacManInfo[i].PixelPosY = 0;
                }
            break;
        }
	    DrawMiniKachel(SaveX, SaveY);
    	DrawMiniKachel(Szenario.Info.PacManInfo[i].PosX, Szenario.Info.PacManInfo[i].PosY);
    }
    if(GameInfo.DirectControl == YES)
    {
        Mouse.Show = NO;
        Szenario.Info.PacManInfo[GameInfo.SelectedFool-FIRST_PACMAN].Befehl = NO_COMMAND;
        switch(Szenario.Info.PacManInfo[GameInfo.SelectedFool-FIRST_PACMAN].AktuellBefehl)
        {
        	case WALK_LEFT:
	            GameInfo.ScreenPixelPosX--;
            break;

        	case WALK_RIGHT:
	            GameInfo.ScreenPixelPosX++;
            break;

        	case WALK_UP:
	            GameInfo.ScreenPixelPosY--;
            break;

        	case WALK_DOWN:
	            GameInfo.ScreenPixelPosY++;
            break;
        }
        if(GameInfo.SelectedFool == NO_AKTIV)
		{
            GameInfo.DirectControl = NO;
            Mouse.Show = YES;
        }
   	}
} /* CheckPacManWalk */

void CheckPacManDead(int i)
{
    if(Szenario.Info.PacManInfo[i].LastWalk == NO)
    	return;
//	GameInfo.LiveFools--;
//	GameInfo.DeadFools++;
	Szenario.Info.PacManInfo[i].Animation = NOW_DIED;
    Szenario.Info.PacManInfo[i].AnimationStep = 0;
	SetBB_Message(GameTexte[T_YOU_HAVE_LOST_A_FOOL], 60, Szenario.Info.PacManInfo[i].PosX, Szenario.Info.PacManInfo[i].PosY, FOOL_DEAD_MESSAGE, NO);
} /* CheckPacManDead */

void PacManIsNowDead(int i)
{
   	Szenario.Info.PacManInfo[i].Power = 0;
	Szenario.Info.PacManInfo[i].OnLive = NO;
	Szenario.Info.PacManInfo[i].Animation = NO_AKTIV;
	Szenario.Info.PacManInfo[i].Befehl = NO_COMMAND;
	Szenario.Info.PacManInfo[i].PixelPosX = 0;
    Szenario.Info.PacManInfo[i].PixelPosY = 0;
    Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX][Szenario.Info.PacManInfo[i].PosY]].Besetzt = NO_AKTIV;
	DrawMiniKachel(Szenario.Info.PacManInfo[i].PosX, Szenario.Info.PacManInfo[i].PosY);
} /* PacManIsNowDead*/

void PacManFoolDiedAni(int i)
{
    Szenario.Info.PacManInfo[i].AnimationStep++;
    if(Szenario.Info.PacManInfo[i].AnimationStep > 19)
        PacManIsNowDead(i);
} /* CheckFoolDiedAni */


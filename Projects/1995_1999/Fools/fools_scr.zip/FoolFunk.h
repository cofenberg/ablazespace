/* Module  "FoolFunk.h":                                           (Project:  Fools)
	Steuert und Kontroliert die Bewegungsabl�ufe der Fools:
*/

void CheckFoolDead(int);
void FoolIsNowDead(int);
void CheckFoolDiedAni(int);
void MoveFools(void);
int CheckBefehle(int, int);
void MakeFoolWalk(int);
int CheckFoolKachel(int);
int CheckFoolTake(int, int, int);
int CheckFoolWait(int);
int CheckFoolUse(int, int);

void CheckFoolsHealth(int, int);

void CheckTaxiScene(int);
int CheckFoolJump(int, int, int);

void CheckFoolGegend(int);
int CheckFoolStat(int);
#include "FoolAnimate.h"
#include "FoolPush.h"

void CheckFoolDead(int i)
{
    if(Szenario.Info.FoolInfo[i].LastWalk == NO)
    	return;
	GameInfo.LiveFools--;
	GameInfo.DeadFools++;
	Szenario.Info.FoolInfo[i].Animation = NOW_DIED;
    Szenario.Info.FoolInfo[i].AnimationStep = 0;
	SetBB_Message(GameTexte[T_YOU_HAVE_LOST_A_FOOL], 60, Szenario.Info.FoolInfo[i].PosX, Szenario.Info.FoolInfo[i].PosY, FOOL_DEAD_MESSAGE, NO);
} /* CheckFoolDead */

void FoolIsNowDead(int i)
{
   	Szenario.Info.FoolInfo[i].Power = 0;
	Szenario.Info.FoolInfo[i].OnLive = NO;
	Szenario.Info.FoolInfo[i].Animation = NO_AKTIV;
	Szenario.Info.FoolInfo[i].Befehl = NO_COMMAND;
	Szenario.Info.FoolInfo[i].PixelPosX = 0;
    Szenario.Info.FoolInfo[i].PixelPosY = 0;
    Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Besetzt = NO_AKTIV;
	DrawMiniKachel(Szenario.Info.FoolInfo[i].PosX, Szenario.Info.FoolInfo[i].PosY);
} /* FoolIsNowDead*/

void CheckFoolDiedAni(int i)
{
    Szenario.Info.FoolInfo[i].AnimationStep++;
    if(Szenario.Info.FoolInfo[i].AnimationStep > 19)
        FoolIsNowDead(i);
} /* CheckFoolDiedAni */

int CheckFoolWait(int i)
{
    if(Szenario.Info.FoolInfo[i].Befehl == COMMAND_WAIT)
    {
        Szenario.Info.FoolInfo[i].Animation = WAITING;
        Szenario.Info.FoolInfo[i].AnimationStep = 10;
        Szenario.Info.FoolInfo[i].AnimationTurn = 0;
        return YES;
    }
	return NO_AKTIV;
} /* CkeckFoolWait */

void MoveFools(void)
{
    int i, Check, zufall;
    int Timer;
    static int LastTimer = 0;

    Timer = timeGetTime()-LastTimer;
    if(Timer < ProgrammSetup.GameSpeed)
    	return;
    LastTimer = timeGetTime();
	for(i = 0; i < MAX_FOOLS; i++)
    {
        if(Szenario.Info.FoolInfo[i].Animation == NOW_DIED)
        {
        	CheckFoolDiedAni(i);
        	continue;
        }
        if(Szenario.Info.FoolInfo[i].Fool_ID == NO_AKTIV ||
           CheckFoolAni(i) == YES ||
           CheckFoolStat(i) == YES ||
           CheckFoolTurnAni(i) == YES ||
           CheckFoolSillyAni(i, NO) == YES ||
           CheckFoolWaitAni(i) == YES ||
           CheckFoolJumpAni(i) == YES)
        	continue;
		if(CheckFoolBeamAni(i) == YES)
        {
	        CheckFoolGegend(i);
        	continue;
        }
       // Zum Objecte verschieben:
        Check = CheckFoolPushStartEnd(i);
        if(Check == YES) // Der Fool schiebt gerade einen Stein:
        	MakeFoolWalk(i);
        if(Check == NO)
        	continue;
        if(Check == NO_AKTIV) // Der Fool darf ganz normal laufen:
		{
           // Kann sich der Fool �berhaupt nicht bewegen, so ist er verzweifelt:
            if((Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+1][Szenario.Info.FoolInfo[i].PosY]].WallPic != NO_AKTIV ||
                Szenario.Info.FoolInfo[i].PosX+1 > Szenario.Info.KarteB || Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+1][Szenario.Info.FoolInfo[i].PosY]].Besetzt != NO_AKTIV) &&
               (Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY-1]].WallPic != NO_AKTIV ||
                Szenario.Info.FoolInfo[i].PosY+1 > Szenario.Info.KarteH || Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY-1]].Besetzt != NO_AKTIV) &&
               (Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX-1][Szenario.Info.FoolInfo[i].PosY]].WallPic != NO_AKTIV ||
                Szenario.Info.FoolInfo[i].PosX < 0  || Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX-1][Szenario.Info.FoolInfo[i].PosY]].Besetzt != NO_AKTIV) &&
               (Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY+1]].WallPic != NO_AKTIV ||
                Szenario.Info.FoolInfo[i].PosY < 0  || Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY+1]].Besetzt != NO_AKTIV) &&
               (Szenario.Info.FoolInfo[i].Animation != SILLY_LEFT && Szenario.Info.FoolInfo[i].Animation != SILLY_RIGHT &&
                Szenario.Info.FoolInfo[i].Animation != SILLY_UP && Szenario.Info.FoolInfo[i].Animation != SILLY_DOWN))
            {
                if(Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX-1][Szenario.Info.FoolInfo[i].PosY]].WallPic == SPECIAL_EXIT ||
	                Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX-1][Szenario.Info.FoolInfo[i].PosY]].WallPic == SPECIAL_EXIT_OVERLAY)
                {
                   	Szenario.Info.FoolInfo[i].PixelPosX++;
                    if(Szenario.Info.FoolInfo[i].Richtung != WALK_LEFT)
	   	            {
	                    Szenario.Info.FoolInfo[i].Richtung = WALK_LEFT;
	                	Szenario.Info.FoolInfo[i].AnimationStep = 0;
						continue;
                	}
                    if(Szenario.Info.FoolInfo[i].Richtung == WALK_LEFT && Szenario.Info.FoolInfo[i].Animation == WALK_LEFT)
                    	Szenario.Info.FoolInfo[i].PixelPosX++;
                   	goto Normal;
                }
                else
                {
                    if(Szenario.Info.FoolInfo[i].PosX == 0 && Szenario.Info.FoolInfo[i].PosY == 0)
                    {
                        zufall = random(5);
                        if(zufall == 2)
                        {
                            Szenario.Info.FoolInfo[i].AnimationTurn = Szenario.Info.FoolInfo[i].Animation;
                            Szenario.Info.FoolInfo[i].Animation = Szenario.Info.FoolInfo[i].Richtung+SILLY_LEFT;
                            Szenario.Info.FoolInfo[i].AnimationBackTurn = 0;
                            Szenario.Info.FoolInfo[i].AnimationStep = 0;
                            Szenario.Info.FoolInfo[i].Befehl  = NO_COMMAND;
                            continue;
                        }
                    }
                }
            }
           // Pr�ft ob er Fool normal gehen kann:
			if(Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+1][Szenario.Info.FoolInfo[i].PosY]].WallPic == NO_AKTIV &&
               Szenario.Info.FoolInfo[i].PosX+1 < Szenario.Info.KarteB  && Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+1][Szenario.Info.FoolInfo[i].PosY]].Besetzt == NO_AKTIV)
			{
                if(Szenario.Info.FoolInfo[i].Animation == SILLY_RIGHT &&
                    Szenario.Info.FoolInfo[i].AnimationBackTurn == 0 && Szenario.Info.FoolInfo[i].AnimationStep == 0)
	                Szenario.Info.FoolInfo[i].Animation = WALK_RIGHT;
            }
            if(Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY-1]].WallPic == NO_AKTIV &&
               Szenario.Info.FoolInfo[i].PosY+1 < Szenario.Info.KarteH  && Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY-1]].Besetzt == NO_AKTIV)
			{
                if(Szenario.Info.FoolInfo[i].Animation == SILLY_DOWN &&
                    Szenario.Info.FoolInfo[i].AnimationBackTurn == 0 && Szenario.Info.FoolInfo[i].AnimationStep == 0)
	                Szenario.Info.FoolInfo[i].Animation = WALK_DOWN;
			}
            if(Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX-1][Szenario.Info.FoolInfo[i].PosY]].WallPic == NO_AKTIV &&
                Szenario.Info.FoolInfo[i].PosX > 0  && Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX-1][Szenario.Info.FoolInfo[i].PosY]].Besetzt == NO_AKTIV)
			{
                if(Szenario.Info.FoolInfo[i].Animation == SILLY_LEFT &&
                    Szenario.Info.FoolInfo[i].AnimationBackTurn == 0 && Szenario.Info.FoolInfo[i].AnimationStep == 0)
	                Szenario.Info.FoolInfo[i].Animation = WALK_LEFT;
			}
            if(Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY+1]].WallPic == NO_AKTIV &&
                Szenario.Info.FoolInfo[i].PosY > 0  && Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY+1]].Besetzt == NO_AKTIV)
			{
                if(Szenario.Info.FoolInfo[i].Animation == SILLY_UP &&
                    Szenario.Info.FoolInfo[i].AnimationBackTurn == 0 && Szenario.Info.FoolInfo[i].AnimationStep == 0)
	                Szenario.Info.FoolInfo[i].Animation = WALK_UP;
			}
		}
 Normal: // Pr�ft, ob sich eine Plattform bewegen soll:
       	CheckTaxiScene(Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]);
      	if(Szenario.Info.FoolInfo[i].Animation == Szenario.Info.FoolInfo[i].Richtung)
        	MakeFoolWalk(i); // L�st den Fool laufen
    }
} /* MoveFools */

// �berpr�ft, ob der Fool von der Kachel, auf der er nun steht einen Befehl bekommt:
int CheckBefehle(int i, int SetRichtung)
{
    int Kachel; // Die Kachel, die der Fool gerade besetzt:

    Kachel = Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY];
    if(Szenario.Info.Kachel[Kachel].Command == NO_COMMAND)
    {
    	Szenario.Info.FoolInfo[i].Befehl = NO_COMMAND;
	  	return NO;
    }
    if(Szenario.Info.FoolInfo[i].Befehl != Szenario.Info.Kachel[Kachel].Command)
        Szenario.Info.FoolInfo[i].AnimationStep = 0;
    Szenario.Info.FoolInfo[i].Befehl = Szenario.Info.Kachel[Kachel].Command;
    if(SetRichtung == YES)
        switch(Szenario.Info.Kachel[Kachel].Command)
        {
            case WALK_LEFT: case PUSH_LEFT: case USE_LEFT: case TAKE_LEFT: Szenario.Info.FoolInfo[i].Richtung = WALK_LEFT; break;
            case WALK_RIGHT: case PUSH_RIGHT: case USE_RIGHT: case TAKE_RIGHT: Szenario.Info.FoolInfo[i].Richtung = WALK_RIGHT; break;
            case WALK_UP: case PUSH_UP: case USE_UP: case TAKE_UP: Szenario.Info.FoolInfo[i].Richtung = WALK_UP; break;
            case WALK_DOWN: case PUSH_DOWN: case USE_DOWN: case TAKE_DOWN: Szenario.Info.FoolInfo[i].Richtung = WALK_DOWN; break;
        }
    return YES;
} /* CheckBefehle */

// L�st den Fool eine Kachel weiter laufen:
void MakeFoolWalk(int i)
{
	int zufall, result, SaveX, SaveY, NextKachel;

    SaveX = Szenario.Info.FoolInfo[i].PosX;
    SaveY = Szenario.Info.FoolInfo[i].PosY;
	CheckFoolWalkAni(i);
    switch(Szenario.Info.FoolInfo[i].Richtung)
    {
        case WALK_LEFT:
            if(Szenario.Info.FoolInfo[i].PixelPosX > 0)
                Szenario.Info.FoolInfo[i].PixelPosX--;
            else
            {
                CheckFoolDead(i);
                result = CheckFoolKachel(i);
                if(result == YES)
                	return;
                CheckBefehle(i, YES);
                if(CheckFoolWait(i) == YES)
                    return;
                if(CheckFoolTake(i, -1, 0) == YES)
                	return;
                if(CheckFoolUse(i, USE_LEFT) == YES)
                    return;
                if(CheckFoolPush(i, PUSH_LEFT) == YES)
	                goto FoolPushLeft;
                if(CheckFoolJump(i, WALK_LEFT, YES) == YES)
                    return;
                NextKachel = Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX-1][Szenario.Info.FoolInfo[i].PosY];
                if(Szenario.Info.Kachel[NextKachel].WallPic == SPECIAL_EXIT ||
	                Szenario.Info.Kachel[NextKachel].WallPic == SPECIAL_EXIT_OVERLAY)
                { // Der Fool ist nun im Ziel!:
                    if(Szenario.Info.FoolInfo[i].Befehl == WALK_LEFT || Szenario.Info.FoolInfo[i].Befehl == PUSH_LEFT ||
						Szenario.Info.FoolInfo[i].Befehl == NO_COMMAND)
                    {
                        Szenario.Info.FoolInfo[i].Animation = ON_FINISH;
                        Szenario.Info.FoolInfo[i].AnimationStep = 0;
                        return;
                    }
                }
              //////////////////////////////////////////////////
             // Der Fool kann ohne die Gefahr in einen Abgrund zu st�rtzen weider gehen:
                if(((Szenario.Info.Kachel[NextKachel].WallPic != NO_AKTIV &&
                	Szenario.Info.Kachel[NextKachel].Mask != TAXI_KACHEL_SCHALTER &&
                    Szenario.Info.Kachel[NextKachel].Mask != BEAMER) ||
                    Szenario.Info.FoolInfo[i].PosX-1 < 0 || Szenario.Info.Kachel[NextKachel].Besetzt != NO_AKTIV) &&
                    (Szenario.Info.FoolInfo[i].Richtung == WALK_LEFT || Szenario.Info.FoolInfo[i].Befehl == NO_COMMAND))
                {  // Vor im befindet sich eine Wand:
                    CheckFoolsHealth(i, WALK_LEFT);
                    if(Szenario.Info.FoolInfo[i].Befehl == PUSH_LEFT || Szenario.Info.FoolInfo[i].Befehl == ON_PUSH_LEFT || Szenario.Info.FoolInfo[i].Befehl == OFF_PUSH_LEFT)
                    	break;
                    if(Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+1][Szenario.Info.FoolInfo[i].PosY]].WallPic != NO_AKTIV
                         ||	Szenario.Info.FoolInfo[i].PosX+1 > Szenario.Info.KarteB || Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+1][Szenario.Info.FoolInfo[i].PosY]].Besetzt != NO_AKTIV)
                        goto FoolHochOderRunter; // Der Weg nach hinten ist nicht frei:
                    else
                    { // Der Weg nach hinten ist frei:
                        Szenario.Info.FoolInfo[i].Richtung = WALK_RIGHT;
                        Szenario.Info.FoolInfo[i].AnimationStep = 0;
                        break;
                    }
                }
                else
                {  // Der Weg ist frei, also geht der Fool eine Kachel weiter:
                    if(Szenario.Info.FoolInfo[i].Richtung == WALK_RIGHT)
                        Szenario.Info.FoolInfo[i].PixelPosX = 0;
                    if(Szenario.Info.FoolInfo[i].Animation == WALK_LEFT && Szenario.Info.FoolInfo[i].Richtung == WALK_LEFT)
                    {
                FoolPushLeft:
                        Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Besetzt = NO_AKTIV;
                        Szenario.Info.FoolInfo[i].PosX--;
                        Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Besetzt = i;
                        Szenario.Info.FoolInfo[i].PixelPosX = KACHEL_B;
                    }
                }
            }
            CheckFoolGegend(i);
        break;

        case WALK_UP:
            if(Szenario.Info.FoolInfo[i].PixelPosY > 0)
                Szenario.Info.FoolInfo[i].PixelPosY--;
            else
            {
                CheckFoolDead(i);
                result = CheckFoolKachel(i);
                if(result == YES)
                	return;
                CheckBefehle(i, YES);
                if(CheckFoolWait(i) == YES)
                    return;
                if(CheckFoolTake(i, 0, -1) == YES)
                	return;
                if(CheckFoolUse(i, USE_UP) == YES)
                    return;
                if(CheckFoolPush(i, PUSH_UP) == YES)
	                goto FoolPushUp;
                if(CheckFoolJump(i, WALK_UP, YES) == YES)
                    return;
                NextKachel = Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY-1];
             // Der Fool kann ohne die Gefahr in einen Abgrund zu st�rtzen weider gehen:
                if(((Szenario.Info.Kachel[NextKachel].WallPic != NO_AKTIV &&
            		 Szenario.Info.Kachel[NextKachel].Mask != TAXI_KACHEL_SCHALTER &&
                     Szenario.Info.Kachel[NextKachel].Mask != BEAMER) ||
                     Szenario.Info.FoolInfo[i].PosY-1 < 0  || Szenario.Info.Kachel[NextKachel].Besetzt != NO_AKTIV) &&
                    (Szenario.Info.FoolInfo[i].Richtung == WALK_UP || Szenario.Info.FoolInfo[i].Befehl == NO_COMMAND))
                {
                    CheckFoolsHealth(i, WALK_UP);
                    if(Szenario.Info.FoolInfo[i].Befehl == PUSH_UP || Szenario.Info.FoolInfo[i].Befehl == ON_PUSH_UP || Szenario.Info.FoolInfo[i].Befehl == OFF_PUSH_UP)
                    	break;
                    if(Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY+1]].WallPic != NO_AKTIV
                         ||	Szenario.Info.FoolInfo[i].PosY+1 > Szenario.Info.KarteH || Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY+1]].Besetzt != NO_AKTIV)
                        goto FoolLinksOderRechts;  // Der Weg nach hinten ist nicht frei:
                    else
                    { // Der Weg nach hinten ist frei:
                         Szenario.Info.FoolInfo[i].Richtung = WALK_DOWN;
                         Szenario.Info.FoolInfo[i].AnimationStep = 0;
	                     Szenario.Info.FoolInfo[i].PixelPosY--;
                         break;
                    }
                }
                else
                {  // Der Weg ist frei, also geht der Fool eine Kachel weiter:
                    if(Szenario.Info.FoolInfo[i].Richtung == WALK_UP && Szenario.Info.FoolInfo[i].Richtung == WALK_UP)
                    {
                FoolPushUp:
                        Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Besetzt = NO_AKTIV;
                        Szenario.Info.FoolInfo[i].PosY--;
                        Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Besetzt = i;
                        Szenario.Info.FoolInfo[i].PixelPosY = KACHEL_H;
                    }
                }
            }
            CheckFoolGegend(i);
        break;

        case WALK_RIGHT:
            if(Szenario.Info.FoolInfo[i].PixelPosX < 0)
                Szenario.Info.FoolInfo[i].PixelPosX++;
            else
            {
            IsStopCheckBefehl1:
                CheckFoolDead(i);
                result = CheckFoolKachel(i);
                if(result == YES)
                	return;
                CheckBefehle(i, YES);
                if(CheckFoolWait(i) == YES)
                    return;
                if(CheckFoolTake(i, 1, 0) == YES)
                	return;
                if(CheckFoolUse(i, USE_RIGHT) == YES)
                    return;
                if(CheckFoolPush(i, PUSH_RIGHT) == YES)
	                goto FoolPushRight;
                if(CheckFoolJump(i, WALK_RIGHT, YES) == YES)
                    return;
                NextKachel = Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+1][Szenario.Info.FoolInfo[i].PosY];
                if(Szenario.Info.Kachel[NextKachel].WallPic == SPECIAL_EXIT ||
	                Szenario.Info.Kachel[NextKachel].WallPic == SPECIAL_EXIT_OVERLAY)
                { // Der Fool hat versucht das Ziel hinterum zu nehmen! BESTRAFUNG!!!!:
                    if(Szenario.Info.FoolInfo[i].Befehl == WALK_RIGHT || Szenario.Info.FoolInfo[i].Befehl == PUSH_RIGHT ||
                    	Szenario.Info.FoolInfo[i].Befehl == NO_COMMAND)
                    {
                    	Szenario.Info.FoolInfo[i].Animation = WRONG_EXIT_PAGE;
                    	Szenario.Info.FoolInfo[i].AnimationStep = 0;
	                    return;
                	}
                }
              //////////////////////////////////////////////////
             // Der Fool kann ohne die Gefahr in einen Abgrund zu st�rtzen weider gehen:
                if(((Szenario.Info.Kachel[NextKachel].WallPic != NO_AKTIV &&
                	Szenario.Info.Kachel[NextKachel].Mask != TAXI_KACHEL_SCHALTER &&
                    Szenario.Info.Kachel[NextKachel].Mask != BEAMER) ||
                   Szenario.Info.FoolInfo[i].PosX+1 > Szenario.Info.KarteB || Szenario.Info.Kachel[NextKachel].Besetzt != NO_AKTIV) &&
                   (Szenario.Info.FoolInfo[i].Richtung == WALK_RIGHT || Szenario.Info.FoolInfo[i].Befehl == NO_COMMAND))
                {
                    CheckFoolsHealth(i, WALK_RIGHT);
                    if(Szenario.Info.FoolInfo[i].Befehl == PUSH_RIGHT || Szenario.Info.FoolInfo[i].Befehl == ON_PUSH_RIGHT || Szenario.Info.FoolInfo[i].Befehl == OFF_PUSH_RIGHT)
                    	break;
                    if(Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX-1][Szenario.Info.FoolInfo[i].PosY]].WallPic != NO_AKTIV ||
                       Szenario.Info.FoolInfo[i].PosX-1 < 0 || Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX-1][Szenario.Info.FoolInfo[i].PosY]].Besetzt != NO_AKTIV)
                    { // Der Weg nach hinten ist nicht frei:
                    FoolHochOderRunter:
                        if((Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY+1]].WallPic == NO_AKTIV &&
                            Szenario.Info.FoolInfo[i].PosY+1 < Szenario.Info.KarteH && Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY+1]].Besetzt == NO_AKTIV) &&
                           (Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY-1]].WallPic == NO_AKTIV &&
                            Szenario.Info.FoolInfo[i].PosY-1 > 0 && Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY-1]].Besetzt == NO_AKTIV))
                        { // Der Fool hat die m�glichkeit nach oben, oder nach unten zu gehen:
                               zufall = random(2);
                               if(zufall == 1) // Der Fool entscheidet sich f�r oben:
                                   goto FoolWantToGoUp;
                               else   // Der Fool entscheidet sich f�r unten:
                                   goto FoolWantToGoDown;
                        }
                        else
                        { // Der Fool kann nur nach oben bzw. unten:
                            if(Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY-1]].WallPic == NO_AKTIV &&
                               Szenario.Info.FoolInfo[i].PosY-1 > 0 && Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY-1]].Besetzt == NO_AKTIV)
                            { // Der Fool weicht nach oben aus:
                            FoolWantToGoUp:
                                Szenario.Info.FoolInfo[i].Richtung = WALK_UP;
                                Szenario.Info.FoolInfo[i].AnimationStep = 0;
                                Szenario.Info.FoolInfo[i].PixelPosY++;
                                break;
                            }
                            if(Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY+1]].WallPic == NO_AKTIV &&
                               Szenario.Info.FoolInfo[i].PosY+1 < Szenario.Info.KarteH && Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY+1]].Besetzt == NO_AKTIV)
                            { // Der Fool weicht nach unten aus:
                            FoolWantToGoDown:
                                Szenario.Info.FoolInfo[i].Richtung = WALK_DOWN;
                                Szenario.Info.FoolInfo[i].AnimationStep = 0;
                                Szenario.Info.FoolInfo[i].PixelPosY = 1;
                                break;
                            }
                        }
                    }
                    else
                    { // Der Weg nach hinten ist frei:
                        Szenario.Info.FoolInfo[i].Richtung = WALK_LEFT;
                        Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Besetzt = NO_AKTIV;
                        Szenario.Info.FoolInfo[i].PosX--;
                        Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Besetzt = i;
                        Szenario.Info.FoolInfo[i].PixelPosX = KACHEL_B;
                        Szenario.Info.FoolInfo[i].AnimationStep = 0;
                        break;
                    }
                }
                else
                {
                    if(Szenario.Info.FoolInfo[i].Befehl == WALK_LEFT)
                    {
                        Szenario.Info.FoolInfo[i].PixelPosX--;
                    	break;
                    }
                    if(Szenario.Info.FoolInfo[i].Befehl == WALK_UP || Szenario.Info.FoolInfo[i].Befehl == WALK_DOWN)
                    {
                        Szenario.Info.FoolInfo[i].PixelPosX = 0;
                    	break;
                    }
                    if(Szenario.Info.FoolInfo[i].Befehl == WALK_RIGHT || Szenario.Info.FoolInfo[i].Richtung == WALK_RIGHT)
                    {
                FoolPushRight:
                        Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Besetzt = NO_AKTIV;
                        Szenario.Info.FoolInfo[i].PosX++;
                        Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Besetzt = i;
                        Szenario.Info.FoolInfo[i].PixelPosX = -KACHEL_B;
                	}
				}
            }
            CheckFoolGegend(i);
        break;

        case WALK_DOWN:
            if(Szenario.Info.FoolInfo[i].PixelPosY < 0)
                Szenario.Info.FoolInfo[i].PixelPosY++;
            else
            {
            IsStopCheckBefehl2:
                CheckFoolDead(i);
                result = CheckFoolKachel(i);
                if(result == YES)
                	return;
                CheckBefehle(i, YES);
                if(CheckFoolWait(i) == YES)
                    return;
                if(CheckFoolTake(i, 0, 1) == YES)
                	return;
                if(CheckFoolUse(i, USE_DOWN) == YES)
                    return;
                if(CheckFoolPush(i, PUSH_DOWN) == YES)
	                goto FoolPushDown;
                if(CheckFoolJump(i, WALK_DOWN, YES) == YES)
                    return;
                NextKachel = Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY+1];
              //////////////////////////////////////////////////
             // Der Fool kann ohne die Gefahr in einen Abgrund zu st�rtzen weider gehen:
                if(((Szenario.Info.Kachel[NextKachel].WallPic != NO_AKTIV &&
            		 Szenario.Info.Kachel[NextKachel].Mask != TAXI_KACHEL_SCHALTER &&
                     Szenario.Info.Kachel[NextKachel].Mask != BEAMER) ||
                    Szenario.Info.FoolInfo[i].PosY+1 > Szenario.Info.KarteH || Szenario.Info.Kachel[NextKachel].Besetzt != NO_AKTIV) &&
                    (Szenario.Info.FoolInfo[i].Richtung == WALK_DOWN || Szenario.Info.FoolInfo[i].Befehl == NO_COMMAND))
                {
                    CheckFoolsHealth(i, WALK_DOWN);
                    if(Szenario.Info.FoolInfo[i].Befehl == PUSH_DOWN || Szenario.Info.FoolInfo[i].Befehl == ON_PUSH_DOWN || Szenario.Info.FoolInfo[i].Befehl == OFF_PUSH_DOWN)
                    	break;
                    if(Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].CommandConst == NO)
                        Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Command = NO_COMMAND;
                        if(Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY-1]].WallPic != NO_AKTIV
                             ||	Szenario.Info.FoolInfo[i].PosY-1 < 0 || Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY-1]].Besetzt != NO_AKTIV)
                        { // Der Weg nach hinten ist nicht frei:
                        FoolLinksOderRechts:
                            if((Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+1][Szenario.Info.FoolInfo[i].PosY]].WallPic == NO_AKTIV &&
                                Szenario.Info.FoolInfo[i].PosX+1 < Szenario.Info.KarteH && Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+1][Szenario.Info.FoolInfo[i].PosY]].Besetzt == NO_AKTIV) &&
                               (Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX-1][Szenario.Info.FoolInfo[i].PosY]].WallPic == NO_AKTIV &&
                                Szenario.Info.FoolInfo[i].PosX-1 > 0 && Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX-1][Szenario.Info.FoolInfo[i].PosY]].Besetzt == NO_AKTIV))
                               { // Der Fool hat die m�glichkeit nach oben, oder nach unten zu gehen:
                                   zufall = random(2);
                                   if(zufall == 1) // Der Fool entscheidet sich f�r oben:
                                       goto FoolWantToGoLeft;
                                   else   // Der Fool entscheidet sich f�r unten:
                                       goto FoolWantToGoRight;
                               }
                            else
                            { // Der Fool kann nur nach links bzw. rechts:
                                if(Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+1][Szenario.Info.FoolInfo[i].PosY]].WallPic == NO_AKTIV &&
                                   Szenario.Info.FoolInfo[i].PosX+1 < Szenario.Info.KarteH && Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+1][Szenario.Info.FoolInfo[i].PosY]].Besetzt == NO_AKTIV)
                                { // Der Fool weicht nach oben aus:
                                FoolWantToGoRight:
                                    Szenario.Info.FoolInfo[i].Richtung = WALK_RIGHT;
                                    Szenario.Info.FoolInfo[i].AnimationStep = 0;
                                    Szenario.Info.FoolInfo[i].PixelPosY = 1;
                                    break;
                                }
                                if(Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX-1][Szenario.Info.FoolInfo[i].PosY]].WallPic == NO_AKTIV &&
                                   Szenario.Info.FoolInfo[i].PosX-1 > 0 && Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX-1][Szenario.Info.FoolInfo[i].PosY]].Besetzt == NO_AKTIV)
                                { // Der Fool weicht nach Rechts aus:
                                FoolWantToGoLeft:
                                    Szenario.Info.FoolInfo[i].Richtung = WALK_LEFT;
                                    Szenario.Info.FoolInfo[i].AnimationStep = 0;
                                    Szenario.Info.FoolInfo[i].PixelPosX = KACHEL_B;
                                    Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Besetzt = NO_AKTIV;
                                    Szenario.Info.FoolInfo[i].PosX--;
                                    Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Besetzt = i;
                                    break;
                                }
                            }
                        }
                        else
                        { // Der Weg nach hinten ist frei:
                            Szenario.Info.FoolInfo[i].Richtung = WALK_UP;
                            Szenario.Info.FoolInfo[i].AnimationStep = 0;
                            Szenario.Info.FoolInfo[i].PixelPosY++;
                        }
            	}
                else
                {  // Der Wer nach unten ist frei:
                    if(Szenario.Info.FoolInfo[i].Befehl == WALK_UP)
                    {
                        Szenario.Info.FoolInfo[i].PixelPosY++;
                    	break;
                    }
                    if(Szenario.Info.FoolInfo[i].Befehl == WALK_LEFT || Szenario.Info.FoolInfo[i].Befehl == WALK_RIGHT)
                    {
                        Szenario.Info.FoolInfo[i].PixelPosY = 0;
                    	break;
                    }
                    if(Szenario.Info.FoolInfo[i].Befehl == WALK_DOWN || Szenario.Info.FoolInfo[i].Richtung == WALK_DOWN)
                    {
                FoolPushDown:
                        Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Besetzt = NO_AKTIV;
                        Szenario.Info.FoolInfo[i].PosY++;
                        Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Besetzt = i;
                        Szenario.Info.FoolInfo[i].PixelPosY = -KACHEL_H;
                	}
                }
            }
            CheckFoolGegend(i);
        break;
    }
	DrawMiniKachel(SaveX, SaveY);
	DrawMiniKachel(Szenario.Info.FoolInfo[i].PosX, Szenario.Info.FoolInfo[i].PosY);
   // Soll der Fool die Richtung wechseln?:
    if(Szenario.Info.FoolInfo[i].Richtung != Szenario.Info.FoolInfo[i].Animation)
    {
        Szenario.Info.FoolInfo[i].AnimationInfo = Szenario.Info.FoolInfo[i].Animation;
        if(Szenario.Info.FoolInfo[i].Animation == WALK_LEFT && Szenario.Info.FoolInfo[i].Richtung == WALK_UP ||
           Szenario.Info.FoolInfo[i].Animation == WALK_LEFT && Szenario.Info.FoolInfo[i].Richtung == WALK_RIGHT)
        {
            Szenario.Info.FoolInfo[i].Animation = TURN_LEFT;
            Szenario.Info.FoolInfo[i].AnimationStep = 0;
            Szenario.Info.FoolInfo[i].AnimationTurn = 0;
            Szenario.Info.FoolInfo[i].AnimationPlusMinus = PLUS;
        }
        if(Szenario.Info.FoolInfo[i].Animation == WALK_RIGHT && Szenario.Info.FoolInfo[i].Richtung == WALK_LEFT ||
           Szenario.Info.FoolInfo[i].Animation == WALK_RIGHT && Szenario.Info.FoolInfo[i].Richtung == WALK_DOWN)
        {
            Szenario.Info.FoolInfo[i].Animation = TURN_RIGHT;
            Szenario.Info.FoolInfo[i].AnimationStep = MAX_TURN_ANI;
            Szenario.Info.FoolInfo[i].AnimationTurn = 1;
            Szenario.Info.FoolInfo[i].AnimationPlusMinus = MINUS;
        }
        if(Szenario.Info.FoolInfo[i].Animation == WALK_UP && Szenario.Info.FoolInfo[i].Richtung == WALK_DOWN ||
           Szenario.Info.FoolInfo[i].Animation == WALK_UP && Szenario.Info.FoolInfo[i].Richtung == WALK_RIGHT)
        {
            Szenario.Info.FoolInfo[i].Animation = TURN_LEFT;
            Szenario.Info.FoolInfo[i].AnimationStep = 0;
            Szenario.Info.FoolInfo[i].AnimationTurn = 1;
            Szenario.Info.FoolInfo[i].AnimationPlusMinus = PLUS;
        }
        if(Szenario.Info.FoolInfo[i].Animation == WALK_DOWN && Szenario.Info.FoolInfo[i].Richtung == WALK_UP ||
           Szenario.Info.FoolInfo[i].Animation == WALK_DOWN && Szenario.Info.FoolInfo[i].Richtung == WALK_LEFT)
        {
            Szenario.Info.FoolInfo[i].Animation = TURN_RIGHT;
            Szenario.Info.FoolInfo[i].AnimationStep = MAX_TURN_ANI;
            Szenario.Info.FoolInfo[i].AnimationTurn = 0;
            Szenario.Info.FoolInfo[i].AnimationPlusMinus = MINUS;
        }
        if(Szenario.Info.FoolInfo[i].Animation == WALK_LEFT && Szenario.Info.FoolInfo[i].Richtung == WALK_DOWN)
        {
            Szenario.Info.FoolInfo[i].Animation = TURN_RIGHT;
            Szenario.Info.FoolInfo[i].AnimationStep = 0;
            Szenario.Info.FoolInfo[i].AnimationTurn = 0;
            Szenario.Info.FoolInfo[i].AnimationPlusMinus = PLUS;
        }
        if(Szenario.Info.FoolInfo[i].Animation == WALK_RIGHT && Szenario.Info.FoolInfo[i].Richtung == WALK_UP)
        {
            Szenario.Info.FoolInfo[i].Animation = TURN_LEFT;
            Szenario.Info.FoolInfo[i].AnimationStep = MAX_TURN_ANI;
            Szenario.Info.FoolInfo[i].AnimationTurn = 1;
            Szenario.Info.FoolInfo[i].AnimationPlusMinus = MINUS;
        }
        if(Szenario.Info.FoolInfo[i].Animation == WALK_UP && Szenario.Info.FoolInfo[i].Richtung == WALK_LEFT)
        {
            Szenario.Info.FoolInfo[i].Animation = TURN_LEFT;
            Szenario.Info.FoolInfo[i].AnimationStep = MAX_TURN_ANI;
            Szenario.Info.FoolInfo[i].AnimationTurn = 0;
            Szenario.Info.FoolInfo[i].AnimationPlusMinus = MINUS;
        }
        if(Szenario.Info.FoolInfo[i].Animation == WALK_DOWN && Szenario.Info.FoolInfo[i].Richtung == WALK_RIGHT)
        {
            Szenario.Info.FoolInfo[i].Animation = TURN_RIGHT;
            Szenario.Info.FoolInfo[i].AnimationStep = 0;
            Szenario.Info.FoolInfo[i].AnimationTurn = 1;
            Szenario.Info.FoolInfo[i].AnimationPlusMinus = PLUS;
        }
    }
} /* MakeFoolWalk */

// Wenn ein Fool einen anderen Trifft, so versuchen die beiden Sich gegenseitig Energie zu geben:
void CheckFoolsHealth(int i, int Richtung)
{
	int x, y;

	x = Szenario.Info.FoolInfo[i].PosX;
	y = Szenario.Info.FoolInfo[i].PosY;
    switch(Richtung)
    {
    	case WALK_LEFT:	x = Szenario.Info.FoolInfo[i].PosX-1; break;
    	case WALK_RIGHT: x = Szenario.Info.FoolInfo[i].PosX+1; break;
    	case WALK_UP: y = Szenario.Info.FoolInfo[i].PosY-1; break;
    	case WALK_DOWN:	y = Szenario.Info.FoolInfo[i].PosY+1; break;
    	default: return;
    }
    if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Besetzt != NO_AKTIV)
    {
        if(Szenario.Info.FoolInfo[i].Power > Szenario.Info.FoolInfo[Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Besetzt].Power)
        {
            Szenario.Info.FoolInfo[i].Power -= 1;
            Szenario.Info.FoolInfo[Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Besetzt].Power += 2;
            if(Szenario.Info.FoolInfo[Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Besetzt].Power > Szenario.Info.FoolInfo[i].MaxPower)
                Szenario.Info.FoolInfo[Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Besetzt].Power = Szenario.Info.FoolInfo[i].MaxPower;
        }
        else
        {
            Szenario.Info.FoolInfo[Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Besetzt].Power -= 1;
            Szenario.Info.FoolInfo[i].Power += 2;
            if(Szenario.Info.FoolInfo[i].Power > Szenario.Info.FoolInfo[i].MaxPower)
                Szenario.Info.FoolInfo[i].Power = Szenario.Info.FoolInfo[i].MaxPower;
        }
    }
} /* CheckFoolsHealth */

// Der Fool ist nun auf einer neuen Kachel, diese wird nun �berpr�ft:
int CheckFoolKachel(int i)
{
    int Kachel;

    Kachel = Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY];
    if(Szenario.Info.Kachel[Kachel].WallPicAniStepTurn == PUNKT)
    { // Der Fool hat einen Punkt eingesammelt:
        Szenario.Info.PunkteAnzahl--;
        GameInfo.Points += 10;
        Szenario.Info.Kachel[Kachel].WallPicAniStepTurn = NO_AKTIV;
    }
	if(Szenario.Info.Kachel[Kachel].Mask >= FIRST_INSTABIL &&
	   Szenario.Info.Kachel[Kachel].Mask <= LAST_INSTABIL)
    { // Der Fool steht auf einem Instabielen Feld:
		Szenario.Info.Kachel[Kachel].Mask++;
		if(Szenario.Info.Kachel[Kachel].Mask > LAST_INSTABIL)
        { // Das Feld ist durchgebrochen:
			Szenario.Info.Kachel[Kachel].Mask = NO_AKTIV;
			Szenario.Info.Kachel[Kachel].Command = NO_COMMAND;
			Szenario.Info.Kachel[Kachel].Pic = DEADLY_WALKS;
        }
    }
	if(Szenario.Info.Kachel[Kachel].Intem != NO_AKTIV)
	{  // Der Fool hatt gerade einen Gegenstand zertreten:
    	Szenario.Info.Kachel[Kachel].Intem = NO_AKTIV;
        Szenario.Info.FoolInfo[i].AnimationTurn = Szenario.Info.FoolInfo[i].Animation;
        Szenario.Info.FoolInfo[i].Animation = Szenario.Info.FoolInfo[i].Animation+SILLY_LEFT;
        Szenario.Info.FoolInfo[i].AnimationBackTurn = 0;
        Szenario.Info.FoolInfo[i].AnimationStep = 0;
    	return YES;
    }
  	return NO;
} /* CheckFoolKachel*/

// Der Fool soll einen Gegenstand nehmen:
int CheckFoolTake(int i, int x, int y)
{
    int i2;

    if((Szenario.Info.FoolInfo[i].Befehl == TAKE_LEFT && Szenario.Info.FoolInfo[i].Richtung == WALK_LEFT) ||
       (Szenario.Info.FoolInfo[i].Befehl == TAKE_UP && Szenario.Info.FoolInfo[i].Richtung == WALK_UP) ||
       (Szenario.Info.FoolInfo[i].Befehl == TAKE_RIGHT && Szenario.Info.FoolInfo[i].Richtung == WALK_RIGHT) ||
       (Szenario.Info.FoolInfo[i].Befehl == TAKE_DOWN && Szenario.Info.FoolInfo[i].Richtung == WALK_DOWN))
    {
        if(Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+x][Szenario.Info.FoolInfo[i].PosY+y]].Intem != NO_AKTIV)
        {
            for(i2 = 0; i2 < MAX_FOOL_INTEMS; i2++)
                if(Szenario.Info.FoolInfo[i].Intem[i2] == NO_AKTIV)
                    break;
            if(i2 < MAX_FOOL_INTEMS)
            {
                Szenario.Info.FoolInfo[i].Intem[i2] = Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+x][Szenario.Info.FoolInfo[i].PosY+y]].Intem;
                Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+x][Szenario.Info.FoolInfo[i].PosY+y]].Intem = NO_AKTIV;
                Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Command = NO_COMMAND;
            }
            else
            	goto FullInventury;
            return YES;
        }
        else
        {  FullInventury:
            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Command = NO_COMMAND;
            Szenario.Info.FoolInfo[i].Animation = Szenario.Info.FoolInfo[i].Richtung+SILLY_LEFT;
            Szenario.Info.FoolInfo[i].AnimationBackTurn = 0;
            Szenario.Info.FoolInfo[i].AnimationStep = 0;
            Szenario.Info.FoolInfo[i].Befehl  = NO_COMMAND;
            Szenario.Info.FoolInfo[i].PixelPosX++;
            return YES;
        }
    }
	return NO_AKTIV;
} /* CheckFoolTake */


// Bewegt die Taxis:
void CheckTaxiScene(int Kachel)
{
    if(Szenario.Info.Kachel[Kachel].Mask != TAXI_KACHEL_SCHALTER)
 		return;
    int Taxi, TaxiRichtung, i, x, y, TaxiNext;

    Taxi = Szenario.Info.Kachel[Kachel].TAXI_SCHALTER_1;
    TaxiRichtung = Szenario.Info.Kachel[Kachel].TAXI_SCHALTER_1_RICHTUNG;
    for(i = 0; i < 2; i++)
    {
        if(Taxi != NO_AKTIV && TaxiRichtung != NO_AKTIV)
        {
            TaxiNext = NO_AKTIV;
            switch(TaxiRichtung)
            {
                case 0: // Nach links
                    Szenario.Kachel[Taxi][KACHEL_PIXEL_X] -= Szenario.Info.Kachel[Taxi].TAXI_SPEED;
                    if(Szenario.Kachel[Taxi][KACHEL_PIXEL_X] > -1)
                        break;  // Das Taxi bewegt sich noch ganz normal!
                    TaxiNext = Szenario.PosInfo[Szenario.Kachel[Taxi][KACHEL_POS_X]-1][Szenario.Kachel[Taxi][KACHEL_POS_Y]];
                break;

                case 2: // Nach rechts
                    Szenario.Kachel[Taxi][KACHEL_PIXEL_X] += Szenario.Info.Kachel[Taxi].TAXI_SPEED;
                    if(Szenario.Kachel[Taxi][KACHEL_PIXEL_X] < 1)
                        break;  // Das Taxi bewegt sich noch ganz normal!
                    TaxiNext = Szenario.PosInfo[Szenario.Kachel[Taxi][KACHEL_POS_X]+1][Szenario.Kachel[Taxi][KACHEL_POS_Y]];
                break;

                case 1: // Nach oben
                    Szenario.Kachel[Taxi][KACHEL_PIXEL_Y] -= Szenario.Info.Kachel[Taxi].TAXI_SPEED;
                    if(Szenario.Kachel[Taxi][KACHEL_PIXEL_Y] > -1)
                        break;  // Das Taxi bewegt sich noch ganz normal!
                    TaxiNext = Szenario.PosInfo[Szenario.Kachel[Taxi][KACHEL_POS_X]][Szenario.Kachel[Taxi][KACHEL_POS_Y]-1];
                    Szenario.Info.Kachel[Kachel].TAXI_SCHALTER_1 = TaxiNext;
                break;

                case 3: // Nach unten
                    Szenario.Kachel[Taxi][KACHEL_PIXEL_Y] += Szenario.Info.Kachel[Taxi].TAXI_SPEED;
                    if(Szenario.Kachel[Taxi][KACHEL_PIXEL_Y] < 1)
                        break;  // Das Taxi bewegt sich noch ganz normal!
                    TaxiNext = Szenario.PosInfo[Szenario.Kachel[Taxi][KACHEL_POS_X]][Szenario.Kachel[Taxi][KACHEL_POS_Y]+1];
                    Szenario.Info.Kachel[Kachel].TAXI_SCHALTER_1 = TaxiNext;
                break;
            }
            if(TaxiNext != NO_AKTIV)
            {
                if(Szenario.Info.Kachel[TaxiNext].Pic != NO_AKTIV && Szenario.Info.Kachel[TaxiNext].Pic > DEADLY_WALKS-1 &&
                    Szenario.Info.Kachel[TaxiNext].Mask == NO_AKTIV && Szenario.Info.Kachel[TaxiNext].WallPic == NO_AKTIV)
                {
                    Szenario.Info.Kachel[TaxiNext].Mask = Szenario.Info.Kachel[Taxi].Mask;
                    Szenario.Kachel[Taxi][KACHEL_PIXEL_X] = 0;
                    Szenario.Kachel[Taxi][KACHEL_PIXEL_Y] = 0;
                    Szenario.Info.Kachel[Taxi].Mask = NO_AKTIV;
                    if(i == 0)
                        Szenario.Info.Kachel[Kachel].TAXI_SCHALTER_1 = TaxiNext;
                    else
                        Szenario.Info.Kachel[Kachel].TAXI_SCHALTER_2 = TaxiNext;
                    // Untersucht, ob andere Schalter diese neue Position kennen sollen:
                    for(y = 0; y < Szenario.Info.KarteH; y++)
                        for(x = 0; x < Szenario.Info.KarteB; x++)
                        {
                        	if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].TAXI_SCHALTER_1 != NO_AKTIV &&
	                            Szenario.Info.Kachel[Szenario.PosInfo[x][y]].TAXI_SCHALTER_1 == Taxi)
								Szenario.Info.Kachel[Szenario.PosInfo[x][y]].TAXI_SCHALTER_1 = TaxiNext;
                        	if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].TAXI_SCHALTER_2 != NO_AKTIV &&
	                            Szenario.Info.Kachel[Szenario.PosInfo[x][y]].TAXI_SCHALTER_2 == Taxi)
								Szenario.Info.Kachel[Szenario.PosInfo[x][y]].TAXI_SCHALTER_2 = TaxiNext;
                        }
                    switch(TaxiRichtung)
                    {
                        case 0: Szenario.Kachel[TaxiNext][KACHEL_PIXEL_X] = KACHEL_B; break;
                        case 2: Szenario.Kachel[TaxiNext][KACHEL_PIXEL_X] = -KACHEL_B; break;
                        case 1: Szenario.Kachel[TaxiNext][KACHEL_PIXEL_Y] = KACHEL_H; break;
                        case 3: Szenario.Kachel[TaxiNext][KACHEL_PIXEL_Y] = -KACHEL_H; break;
                    }
                }
                else // Das Taxi wird angehalten:
                {
                    switch(TaxiRichtung)
                    {
                        case 0: Szenario.Kachel[Taxi][KACHEL_PIXEL_X] += Szenario.Info.Kachel[Taxi].TAXI_SPEED; break;
                        case 2: Szenario.Kachel[Taxi][KACHEL_PIXEL_X] -= Szenario.Info.Kachel[Taxi].TAXI_SPEED; break;
                        case 1: Szenario.Kachel[Taxi][KACHEL_PIXEL_Y] += Szenario.Info.Kachel[Taxi].TAXI_SPEED; break;
                        case 3: Szenario.Kachel[Taxi][KACHEL_PIXEL_Y] -= Szenario.Info.Kachel[Taxi].TAXI_SPEED; break;
                    }
                }
            }
        }
        // Nun kommt das zweite Taxi dran:
	    Taxi = Szenario.Info.Kachel[Kachel].TAXI_SCHALTER_2;
    	TaxiRichtung = Szenario.Info.Kachel[Kachel].TAXI_SCHALTER_2_RICHTUNG;
	}
} /* CheckTaxiScene */

// Pr�ft, ob der Fool etwas benutzen soll:
int CheckFoolUse(int i, int command)
{
    int xMin, yMin, richtung, silly;

    xMin = 0;
    yMin = 0;
    switch(command)
    {
    	case USE_LEFT:
        	richtung = WALK_LEFT;
            silly = SILLY_LEFT;
            xMin = -1;
        break;

    	case USE_UP:
        	richtung = WALK_UP;
            silly = SILLY_UP;
            yMin = -1;
        break;

    	case USE_RIGHT:
        	richtung = WALK_RIGHT;
            silly = SILLY_RIGHT;
            xMin = 1;
        break;

    	case USE_DOWN:
        	richtung = WALK_DOWN;
            silly = SILLY_DOWN;
            yMin = 1;
        break;
    }
    if((Szenario.Info.FoolInfo[i].Befehl == command && Szenario.Info.FoolInfo[i].Richtung == richtung) &&
       Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+xMin][Szenario.Info.FoolInfo[i].PosY+yMin]].WallPic < FIRST_OBJECT-1)
    {
        Szenario.Info.FoolInfo[i].AnimationStep = 0;
        Szenario.Info.FoolInfo[i].AnimationTurn = -1;
        Szenario.Info.FoolInfo[i].AnimationBackTurn = 0;
        Szenario.Info.FoolInfo[i].Animation = Szenario.Info.FoolInfo[i].Richtung+silly;
        Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Command = NO_COMMAND;
        return YES;
    }
    else
        if((Szenario.Info.FoolInfo[i].Befehl == command && Szenario.Info.FoolInfo[i].Richtung == richtung) &&
           (Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+xMin][Szenario.Info.FoolInfo[i].PosY+yMin]].WallPic > FIRST_OBJECT-1 &&
            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+xMin][Szenario.Info.FoolInfo[i].PosY+yMin]].Mask != TAXI_KACHEL_SCHALTER &&
            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+xMin][Szenario.Info.FoolInfo[i].PosY+yMin]].Mask != BEAMER))
        {
           Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Command = NO_COMMAND;
           Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+xMin][Szenario.Info.FoolInfo[i].PosY+yMin]].WallPic = NO_AKTIV;
	       return YES;
        }
	return NO;
} /* CheckFoolUse */

int CheckFoolJump(int i, int richtung, int FirstJump)
{
	if(Szenario.Info.FoolInfo[i].Befehl != COMMAND_JUMP)
    	return NO;
    int xMin, yMin, silly;
    Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Command = NO_COMMAND;
    xMin = 0;
    yMin = 0;
    switch(richtung)
   	{
    	case WALK_LEFT:
        	xMin = -1;
            silly = SILLY_LEFT;
        break;

    	case WALK_UP:
        	yMin = -1;
            silly = SILLY_UP;
        break;

    	case WALK_RIGHT:
        	xMin = 1;
            silly = SILLY_RIGHT;
        break;

    	case WALK_DOWN:
        	yMin = 1;
            silly = SILLY_DOWN;
        break;
    }
    if((Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+xMin][Szenario.Info.FoolInfo[i].PosY+yMin]].WallPic == NO_AKTIV ||
        Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+xMin][Szenario.Info.FoolInfo[i].PosY+yMin]].Mask == TAXI_KACHEL_SCHALTER ||
        Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+xMin][Szenario.Info.FoolInfo[i].PosY+yMin]].Mask == BEAMER) &&
       Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+xMin][Szenario.Info.FoolInfo[i].PosY+yMin]].Besetzt == NO_AKTIV)
	{  // Ok das zu �berspringende Feld ist frei:
	 	if(FirstJump == YES)
 			Szenario.Info.FoolInfo[i].AnimationTurn = FIRST_JUMP;
        if(FirstJump == NO)
	        Szenario.Info.FoolInfo[i].AnimationTurn = LAST_JUMP;
        Szenario.Info.FoolInfo[i].Animation = JUMPING;
        switch(richtung)
        {
            case WALK_LEFT:
               Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Besetzt = NO_AKTIV;
               Szenario.Info.FoolInfo[i].PosX--;
               Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Besetzt = i;
               Szenario.Info.FoolInfo[i].PixelPosX = KACHEL_B;
            break;

            case WALK_UP:
                Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Besetzt = NO_AKTIV;
                Szenario.Info.FoolInfo[i].PosY--;
                Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Besetzt = i;
                Szenario.Info.FoolInfo[i].PixelPosY = KACHEL_H;
            break;

            case WALK_RIGHT:
                Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Besetzt = NO_AKTIV;
                Szenario.Info.FoolInfo[i].PosX++;
                Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Besetzt = i;
                Szenario.Info.FoolInfo[i].PixelPosX = -KACHEL_B;
            break;

            case WALK_DOWN:
                Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Besetzt = NO_AKTIV;
                Szenario.Info.FoolInfo[i].PosY++;
                Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Besetzt = i;
                Szenario.Info.FoolInfo[i].PixelPosY = -KACHEL_H;
            break;
        }
      	return YES;
   	}
   	else
    {
        if(FirstJump == YES) // F�ngt der Fool an, zu springen, und eine Wand ist genau vor ihm,
 	    {                    // So weigert er sich verst�ndlicherwei�e, zu Springen!:
            Szenario.Info.FoolInfo[i].AnimationStep = 0;
            Szenario.Info.FoolInfo[i].AnimationTurn = -1;
            Szenario.Info.FoolInfo[i].AnimationBackTurn = 0;
            Szenario.Info.FoolInfo[i].Animation = Szenario.Info.FoolInfo[i].Richtung+silly;
         	return YES;
		}
	}
    return NO;
} /* CheckFoolJump */

// Pr�ft, ob der Fool irgend etwas in der n�heren umgebung ver�ndert hat:
void CheckFoolGegend(int i)
{
    CheckMoveWallCreateDestroyed(Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]);
    CheckMoveWallCreateDestroyed(Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX-1][Szenario.Info.FoolInfo[i].PosY]);
    CheckMoveWallCreateDestroyed(Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+1][Szenario.Info.FoolInfo[i].PosY]);
    CheckMoveWallCreateDestroyed(Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY-1]);
    CheckMoveWallCreateDestroyed(Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY+1]);
} /* CheckFoolGegend */

// �berpr�ft die Kachel die der Fool gerade besetzt, w�rend dieser nebenbei dinge tut:
int CheckFoolStat(int i)
{
    int Kachel, zufall;

    Kachel = Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY];
    if(Szenario.Info.Kachel[Kachel].Mask == ATOMIK)
    { // Oh!! Nicht sehr gut, der Fool steht auf einem verstrahltem Feld:
        zufall = random(3);
        if(zufall == 0)
        { // Autsch einen Energie Punkt weniger:
            if(Szenario.Info.FoolInfo[i].Power > 0)
                Szenario.Info.FoolInfo[i].Power--;
        }
    }
    if(Szenario.Info.Kachel[Kachel].Mask == GESUND)
    {
        zufall = random(3);
        if(zufall == 0)
        {
            Szenario.Info.FoolInfo[i].Power++;
            if(Szenario.Info.FoolInfo[i].Power > Szenario.Info.FoolInfo[i].MaxPower)
                Szenario.Info.FoolInfo[i].Power = Szenario.Info.FoolInfo[i].MaxPower;
        }
    }
    if(Szenario.Info.FoolInfo[i].Power < 1)
    { // Tja, da� wars!!
        Szenario.Info.FoolInfo[i].Power = 0;
        Szenario.Info.FoolInfo[i].LastWalk = YES;
        if(Szenario.Info.FoolInfo[i].PixelPosX == 0 && Szenario.Info.FoolInfo[i].PixelPosY == 0)
        {
            CheckFoolDead(i);
            return YES;
        }
    }
    if(((Szenario.Info.Kachel[Kachel].Pic > DEADLY_WALKS-1 ||
          Szenario.Info.Kachel[Kachel].Pic == NO_KACHEL) &&
         (Szenario.Info.Kachel[Kachel].Mask < FIRST_MOVE_MASK || Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Mask > FIRST_MOVE_MASK+MAX_MOVE_MASK)) ||
         (Szenario.Info.Kachel[Kachel].WallPic != NO_AKTIV && Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Mask != BEAMER &&
          Szenario.Info.Kachel[Kachel].Mask != TAXI_KACHEL_SCHALTER))
    { // Der Fool steht in einem Abgrund:
        Szenario.Info.FoolInfo[i].LastWalk = YES;
        if(Szenario.Info.FoolInfo[i].PixelPosX == 0 && Szenario.Info.FoolInfo[i].PixelPosY == 0)
        {
            CheckFoolDead(i);
            return YES;
        }
    }
    return NO;
} /* CheckFoolStat */


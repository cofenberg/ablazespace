#include "VirtualScene.h"
#include "Gegner.h"
#include "BarMenu.h"
#include "PacMan.h"

extern int Editor_SetKachelAni;

int LoadGameTexte(int);
int DestroyGameTexte(void);
void LoadWaitPic(void);
void ShowLoadStatus(int);
void LoadGlobalPics(void);
void DestroyGlobalPics(void);
void LoadLevelBitmaps(char *);
void DestroyLevelBitmaps(void);
//////////////////////////////////////////////////////////////////////////
void SaveLevel(char *);
void LoadLevel(char *);
//////////////////////////////////////////////////////////////////////////
void UpdateDisplay(void);
//////////////////////////////////////////////////////////////////////////
int CheckMouseRect(int, int, int , int);
//////////////////////////////////////////////////////////////////////////
int SucheKachel(void);
int FindMouseFool(void);
int FindMousePacMan(void);
int FindMouseGegner(void);
void CheckMouseFool(void);
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
void MouseScroll(void);
void MoveScreenDown(int);
void MoveScreenUp(int);
void MoveScreenRight(int);
void MoveScreenLeft(int);
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
void CentereScreenPosition(int *, int *);
//////////////////////////////////////////////////////////////////////////
void SetBB_Message(char *, int, int, int, int, int);
void ShowBB_Message(int);
void SetBB_SmallMessage(char *, int);
void ShowBB_SmallMessage(int);
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
void InitGetFrameRate(void);
void GetFrameRate(void);
void ShowFrameRate(void);
//////////////////////////////////////////////////////////////////////////
void CheckAniScene(void);
void CheckSelectedAni(void);
void CheckDoorAni(void);
//////////////////////////////////////////////////////////////////////////
void DrawMini(void);
void DrawMiniKachel(int, int);
void DrawMiniToDisplay(int, int);
void CheckMiniFilter(int, int);
void CheckMiniScroll(int, int);
//////////////////////////////////////////////////////////////////////////
void DrawRect(int, int, int, int, int, LPDIRECTDRAWSURFACE);
//////////////////////////////////////////////////////////////////////////
int CheckPushBar(int, int, int, int, int);
//////////////////////////////////////////////////////////////////////////
void CheckMoveWallCreateDestroyed(int);

void CheckBeamer(int);

void GameListeOnOff(void);

int CheckMouseRichtung(void);


LPDIRECTDRAWSURFACE    LoadStatusPic;

LPDIRECTDRAWSURFACE    MeldungPic;
LPDIRECTDRAWSURFACE    FoolSelectedPic;
LPDIRECTDRAWSURFACE    MiniPic;
LPDIRECTDRAWSURFACE LevelFool;

int LevelFoolAniStep, LevelFoolAniStepTurn;

int LoadGameTexte(int Language)
{
    char Text[1000];
    FILE *stream;
    int i;

    switch(Language)
    {
    	case LANGUAGE_GERMAN:
        	stream = fopen("Texte/German.txt", "a+");
			ProgrammSetup.Language = LANGUAGE_GERMAN;
            break;

    	case LANGUAGE_ENGLISH:
        	stream = fopen("Texte/English.txt", "a+");
			ProgrammSetup.Language = LANGUAGE_ENGLISH;
            break;

        default: return YES;
    }
    fseek(stream, 0, SEEK_SET);
    for(i = 0; i < MAX_GAME_TEXTE; i++)
    {
	    fgets(Text, 1000, stream);
        if(Text[0] == EOF)
        	break;
        GameTexte[i] = (char *)malloc(strlen(Text));
        strcpy(GameTexte[i], Text);
    }
    fclose(stream);
    return NO;
} /* LoadGameTexte */

int DestroyGameTexte(void)
{
    int i;

    for(i = 0; i < MAX_GAME_TEXTE; i++)
        free(GameTexte[i]);
    return NO;
} /* DestroyGameTexte */

void LoadGlobalPics(void)
{
    DDSURFACEDESC       ddsd;
    DDBLTFX ddbltfx;
    LPDIRECTDRAWSURFACE Pic;
    RECT rcRect, rcRect2;
    int i, i2, x, y, x2;

    ZeroMemory(&ddsd, sizeof(ddsd));
    ddsd.dwSize = sizeof(ddsd);
    ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH;
    ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_SYSTEMMEMORY;
    ZeroMemory(&ddbltfx, sizeof(ddbltfx));
    ddbltfx.dwSize = sizeof(ddbltfx);


    LoadStatusPic = DDLoadBitmap(lpDD, "Bilder/LoadStat.bmp", 0, 0, NO);
    DDSetColorKey(LoadStatusPic, 5);
	ShowLoadStatus(60);
	ShowLoadStatus(100);
	InitFontStruct(2, 15, 17);
	LoadFont(2, "Bilder/Font2.bmp");
	ShowLoadStatus(120);
	InitFontStruct(3, 10, 10);
	LoadFont(3, "Bilder/Font2.bmp");
	ShowLoadStatus(140);
    FoolSelectedPic = DDLoadBitmap(lpDD, "Bilder/Select.bmp", 0, 0, NO);
    DDSetColorKey(FoolSelectedPic, 5);
	ShowLoadStatus(160);
    FoolAniPic = DDLoadBitmap(lpDD, "Bilder/Fool_Ani.bmp", 0, 0, NO);
    DDSetColorKey(FoolAniPic, 5);
    GegnerAniPic = DDLoadBitmap(lpDD, "Bilder/Gegner.bmp", 0, 0, NO);
    DDSetColorKey(GegnerAniPic, 5);
    PacManAniPic = DDLoadBitmap(lpDD, "Bilder/PacMan.bmp", 0, 0, YES);
    DDSetColorKey(PacManAniPic, 5);
	ShowLoadStatus(190);
    GameListPic = DDLoadBitmap(lpDD, "Bilder/GameListe.bmp", 0, 0, YES);
    DDSetColorKey(GameListPic, 5);
	ShowLoadStatus(210);
    MeldungPic = DDLoadBitmap(lpDD, "Bilder/Meldung.bmp", 0, 0, NO);
    DDSetColorKey(MeldungPic, 5);
	ShowLoadStatus(220);
    // L�d die Befehl bilder:
    ddsd.dwWidth = 500;
    ddsd.dwHeight = 265;
    if(lpDD->CreateSurface(&ddsd, &BefehlePic, NULL) != DD_OK)
        return;
    ddbltfx.dwSize = sizeof(ddbltfx);
    ddbltfx.dwFillColor = 0;
    BefehlePic->Blt(NULL, NULL, NULL, DDBLT_COLORFILL, &ddbltfx);
    Pic = DDLoadBitmap(lpDD, "Bilder/com.bmp", 0, 0, NO);
    // Male die Normalen vorgegebenen Befehle:
    SetRect(&rcRect, 0, 0, 67, 265);
    BefehlePic->BltFast(0, 0, Pic, &rcRect, FALSE);
    SetRect(&rcRect, 66, 0, 132, 265);
    BefehlePic->BltFast(132, 0, Pic, &rcRect, FALSE);
    SetRect(&rcRect, 132, 0, 165, 265);
    BefehlePic->BltFast(264, 0, Pic, &rcRect, FALSE);
    // Malt die links Befehle Seitenverkehrt:
    ddbltfx.dwDDFX = DDBLTFX_MIRRORLEFTRIGHT;
    SetRect(&rcRect, 0, 0, 33, 265);
    SetRect(&rcRect2, 67, 0, 101, 265);
    BefehlePic->Blt(&rcRect2, Pic, &rcRect, DDBLT_DDFX, &ddbltfx);
    SetRect(&rcRect, 66, 0, 100, 265);
    SetRect(&rcRect2, 198, 0, 232, 265);
    BefehlePic->Blt(&rcRect2, Pic, &rcRect, DDBLT_DDFX, &ddbltfx);
    // Malt die nach oben Befehle Seitenverkehrt, und gespiegelt:
    ddbltfx.dwDDFX = DDBLTFX_MIRRORLEFTRIGHT | DDBLTFX_MIRRORUPDOWN;
    for(i2 = 0, y = 0; i2 < 9; i2++, y += 33)
        for(i = 0, x = 33, x2 = 99; i < 2; i++, x += 66, x2 += 132)
        {
            SetRect(&rcRect, x, y, x+34, y+34);
            SetRect(&rcRect2, x2, y, x2+34, y+34);
            BefehlePic->Blt(&rcRect2, Pic, &rcRect, DDBLT_DDFX, &ddbltfx);
        }
    Pic->Restore();
    DDSetColorKey(BefehlePic, 5);
	ShowLoadStatus(240);
   /////////
    CommandMenuAniPic = DDLoadBitmap(lpDD, "Bilder/Com_ani.bmp", 0, 0, YES);
    DDSetColorKey(CommandMenuAniPic, 5);
	ShowLoadStatus(250);
    ddsd.dwWidth = ScreenRes[0]+200;
    ddsd.dwHeight = ScreenRes[1]+250;
    if(lpDD->CreateSurface(&ddsd, &GameAusgabe, NULL) != DD_OK)
        return;
    ddsd.dwWidth = 80;
    ddsd.dwHeight = 80;
    if(lpDD->CreateSurface(&ddsd, &MiniPic, NULL) != DD_OK)
        return;
} /* LoadGlobalPics */

void DestroyGlobalPics(void)
{
    LoadStatusPic->Release();
    MiniPic->Release();
    FoolSelectedPic->Release();
    FoolAniPic->Release();
    GameListPic->Release();
    MeldungPic->Release();
    CommandMenuAniPic->Release();
    BefehlePic->Release();
} /* DestroyGlobalPics */

void LoadLevelBitmaps(char *SenarioPath)
{
    char temp[50];

	ShowLoadStatus(1);
    sprintf(temp, "Szenarios/%s/Floor.bmp", SenarioPath);
    Szenario.FloorLevelPic = DDLoadBitmap(lpDD, temp, 0, 0, NO);
    DDSetColorKey(Szenario.FloorLevelPic, 5);
	ShowLoadStatus(26);
    sprintf(temp, "Szenarios/%s/Wall.bmp", SenarioPath);
    Szenario.WallLevelPic = DDLoadBitmap(lpDD, temp, 0, 0, NO);
    DDSetColorKey(Szenario.WallLevelPic, 5);
	ShowLoadStatus(78);
    sprintf(temp, "Szenarios/%s/WallAni.bmp", SenarioPath);
    Szenario.WallAniLevelPic = DDLoadBitmap(lpDD, temp, 0, 0, NO);
    DDSetColorKey(Szenario.WallAniLevelPic, 5);
	ShowLoadStatus(160);
    sprintf(temp, "Szenarios/%s/MoveWall.bmp", SenarioPath);
    Szenario.MoveWallLevelPic = DDLoadBitmap(lpDD, temp, 0, 0, NO);
    DDSetColorKey(Szenario.MoveWallLevelPic, 5);
	ShowLoadStatus(186);
    sprintf(temp, "Szenarios/%s/Masks.bmp", SenarioPath);
    Szenario.MasksLevelPic = DDLoadBitmap(lpDD, temp, 0, 0, YES);
    DDSetColorKey(Szenario.MasksLevelPic, 5);
	ShowLoadStatus(212);
    sprintf(temp, "Szenarios/%s/Objects.bmp", SenarioPath);
    Szenario.ObjectsLevelPic = DDLoadBitmap(lpDD, temp, 0, 0, NO);
    DDSetColorKey(Szenario.ObjectsLevelPic, 5);
	ShowLoadStatus(225);
    sprintf(temp, "Szenarios/%s/Intems.bmp", SenarioPath);
    Szenario.IntemsLevelPic = DDLoadBitmap(lpDD, temp, 0, 0, NO);
    DDSetColorKey(Szenario.IntemsLevelPic, 5);
	ShowLoadStatus(235);
    sprintf(temp, "Szenarios/%s/DoorAni.bmp", SenarioPath);
    Szenario.DoorAniLevelPic = DDLoadBitmap(lpDD, temp, 0, 0, NO);
    DDSetColorKey(Szenario.DoorAniLevelPic, 5);
	ShowLoadStatus(250);
    sprintf(temp, "Szenarios/%s/Special.bmp", SenarioPath);
    Szenario.SpecialLevelPic = DDLoadBitmap(lpDD, temp, 0, 0, NO);
    DDSetColorKey(Szenario.SpecialLevelPic, 5);
    sprintf(temp, "Szenarios/%s/Punkt.bmp", SenarioPath);
    Szenario.PunktLevelPic = DDLoadBitmap(lpDD, temp, 0, 0, NO);
    DDSetColorKey(Szenario.PunktLevelPic, 5);
    LevelFool = DDLoadBitmap(lpDD, "Bilder/LevelEnd.bmp", 0, 0, YES);
    DDSetColorKey(LevelFool, 5);
} /* LoadLevelBitmaps */

void DestroyLevelBitmaps(void)
{
    Szenario.FloorLevelPic->Release();
    Szenario.WallLevelPic->Release();
    Szenario.WallAniLevelPic->Release();
    Szenario.MoveWallLevelPic->Release();
    Szenario.MasksLevelPic->Release();
    Szenario.IntemsLevelPic->Release();
    Szenario.DoorAniLevelPic->Release();
    Szenario.SpecialLevelPic->Release();
    Szenario.PunktLevelPic->Release();
}
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
// Aktualisiert den Bildspeicher:
void UpdateDisplay(void)
{
    HRESULT ddrval;
    int Timer;
    static int LastTimer = 0, Demo = 0;

    if(ProgrammSetup.ShowFps == YES)
	{
    	GetFrameRate();
		ShowFrameRate();
    }
    ShowBB_SmallMessage(1);
	DrawBarFunktionenMenu(ProgrammModule);
	DrawBarMenu();
    SetMouseCursorPic();
    if(GameInfo.MakeADemo == YES)
    {
        char temp[50];
        sprintf(temp, "Demo Recording  %d  - %d", GameInfo.DemoPointer, MAX_DEMO_POINTER),
        PrintText(ScreenRes[0]/2-200, ScreenRes[1]-20, temp, 0, 0, 1000, 1000, Back);
    }
    if(GameInfo.PlayDemo == YES)
    {
        char temp[50];
        sprintf(temp, "Demo Playing  %d  - %d", GameInfo.DemoPointer, MAX_DEMO_POINTER),
        PrintText(ScreenRes[0]/2-200, ScreenRes[1]-20, temp, 0, 0, 1000, 1000, Back);
    }
    Timer = timeGetTime()-LastTimer;
    if(Timer > 1000)
    {
        LastTimer = timeGetTime();
        if(Demo == 0)
        	Demo = 1;
        else
        	Demo = 0;
    }
    if(Demo == 2)
        PrintText(ScreenRes[0]/2-100, 5, "(Early Demo!)", 0, 0, 1000, 1000, Back);
	// Flip the surfaces
    while(1)
    {
        ddrval = Primary->Flip(NULL, 0);
        if(ddrval == DD_OK)
            break;
        if(ddrval != DDERR_WASSTILLDRAWING)
            break;
    }
} /* UpdateDisplay */
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
// Sucht eine Kachel:
int SucheKachel(void)
{
    int x, y;

    for(y = GameInfo.ScreenPosY; y < GameInfo.ScreenPosY+WINDOW_H; y++)
        for(x = GameInfo.ScreenPosX+PersXY[y][0]; x < GameInfo.ScreenPosX+WINDOW_B+PersXY[y][0]; x++)
            if(CheckMouseRect(KACHEL_DISPLAY_X-GameInfo.ScreenPixelPosX-KACHEL_B-70, KACHEL_DISPLAY_Y-GameInfo.ScreenPixelPosY-(KACHEL_H*2)-50,
                KACHEL_DISPLAY_X-GameInfo.ScreenPixelPosX-70, KACHEL_DISPLAY_Y-GameInfo.ScreenPixelPosY-KACHEL_H-50) != NO_AKTIV)
                return(Szenario.PosInfo[x][y]);
    return(NO_AKTIV);
} /* SucheKachel */

int FindMouseFool(void)
{
    int Fool, x, y, x2, y2;

    for(Fool = 0; Fool < MAX_FOOLS; Fool++)
    {
        if(Szenario.Info.FoolInfo[Fool].Fool_ID == NO_AKTIV || Szenario.Info.FoolInfo[Fool].OnLive == NO || Szenario.Info.FoolInfo[Fool].OnLive == FINISH)
        	continue;
    	if(Szenario.Info.FoolInfo[Fool].PosX > GameInfo.ScreenPosX &&
       		Szenario.Info.FoolInfo[Fool].PosX < GameInfo.ScreenPosX+WINDOW_B+20 &&
    		Szenario.Info.FoolInfo[Fool].PosY > GameInfo.ScreenPosY &&
       		Szenario.Info.FoolInfo[Fool].PosY < GameInfo.ScreenPosY+WINDOW_H+1)
        { // Der Fool befindet sich im Sichtbaren Fenster:
            x = Szenario.Info.FoolInfo[Fool].PosX;
            y = Szenario.Info.FoolInfo[Fool].PosY;
            x2 = KACHEL_DISPLAY_X-GameInfo.ScreenPixelPosX-2+Szenario.Info.FoolInfo[Fool].PixelPosX-KACHEL_B-70;
            y2 = KACHEL_DISPLAY_Y-(FOOL_H-KACHEL_H)-GameInfo.ScreenPixelPosY+Szenario.Info.FoolInfo[Fool].PixelPosY-(KACHEL_H*2)-50;
			if(CheckMouseRect(x2, y2, x2+FOOL_B, y2+FOOL_H) != NO_AKTIV)
            {
		        DrawRect(x2, y2, FOOL_B, FOOL_H, 15, Back);
                return Fool;
            }
        }
    }
	return NO_AKTIV;
} /* FindMouseFool */

int FindMousePacMan(void)
{
    int PacMan, x, y, x2, y2;

    for(PacMan = 0; PacMan < MAX_PACMAN; PacMan++)
    {
        if(Szenario.Info.PacManInfo[PacMan].PacMan_ID == NO_AKTIV || Szenario.Info.PacManInfo[PacMan].OnLive == NO || Szenario.Info.PacManInfo[PacMan].OnLive == FINISH)
        	continue;
    	if(Szenario.Info.PacManInfo[PacMan].PosX > GameInfo.ScreenPosX &&
       		Szenario.Info.PacManInfo[PacMan].PosX < GameInfo.ScreenPosX+WINDOW_B+20 &&
    		Szenario.Info.PacManInfo[PacMan].PosY > GameInfo.ScreenPosY &&
       		Szenario.Info.PacManInfo[PacMan].PosY < GameInfo.ScreenPosY+WINDOW_H+1)
        { // Der PacMan befindet sich im Sichtbaren Fenster:
            x = Szenario.Info.PacManInfo[PacMan].PosX;
            y = Szenario.Info.PacManInfo[PacMan].PosY;
            x2 = KACHEL_DISPLAY_X-GameInfo.ScreenPixelPosX-2+Szenario.Info.PacManInfo[PacMan].PixelPosX-KACHEL_B-70;
            y2 = KACHEL_DISPLAY_Y-(PACMAN_H-KACHEL_H)-GameInfo.ScreenPixelPosY+Szenario.Info.PacManInfo[PacMan].PixelPosY-(KACHEL_H*2)-50;
			if(CheckMouseRect(x2, y2, x2+PACMAN_B, y2+PACMAN_H) != NO_AKTIV)
            {
		        DrawRect(x2, y2, PACMAN_B, PACMAN_H, 15, Back);
                return PacMan;
            }
        }
    }
	return NO_AKTIV;
} /* FindMousePacMan */

int FindMouseGegner(void)
{
    int Gegner, x, y, x2, y2;

    for(Gegner = 0; Gegner < MAX_GEGNER; Gegner++)
    {
        if(Szenario.Info.GegnerInfo[Gegner].Gegner_ID == NO_AKTIV || Szenario.Info.GegnerInfo[Gegner].OnLive == NO || Szenario.Info.GegnerInfo[Gegner].OnLive == FINISH)
        	continue;
    	if(Szenario.Info.GegnerInfo[Gegner].PosX > GameInfo.ScreenPosX &&
       		Szenario.Info.GegnerInfo[Gegner].PosX < GameInfo.ScreenPosX+WINDOW_B+20 &&
    		Szenario.Info.GegnerInfo[Gegner].PosY > GameInfo.ScreenPosY &&
       		Szenario.Info.GegnerInfo[Gegner].PosY < GameInfo.ScreenPosY+WINDOW_H+1)
        { // Der Gegner befindet sich im Sichtbaren Fenster:
            x = Szenario.Info.GegnerInfo[Gegner].PosX;
            y = Szenario.Info.GegnerInfo[Gegner].PosY;
            x2 = KACHEL_DISPLAY_X-GameInfo.ScreenPixelPosX-2+Szenario.Info.GegnerInfo[Gegner].PixelPosX-KACHEL_B-70;
            y2 = KACHEL_DISPLAY_Y-(GEGNER_H-KACHEL_H)-GameInfo.ScreenPixelPosY+Szenario.Info.GegnerInfo[Gegner].PixelPosY-(KACHEL_H*2)-50;
			if(CheckMouseRect(x2, y2, x2+GEGNER_B, y2+GEGNER_H) != NO_AKTIV)
            {
		        DrawRect(x2, y2, GEGNER_B, GEGNER_H, 15, Back);
                return Gegner;
            }
        }
    }
	return NO_AKTIV;
} /* FindMouseGegner */

// Pr�ft, ob sich die Maus in dem Rechteck befindet:
int CheckMouseRect(int x, int y, int xb, int yh)
{
    if(Mouse.XPos > x && Mouse.XPos < xb && Mouse.YPos > y && Mouse.YPos < yh)
    	return YES;
	return NO_AKTIV;
} /* CheckMouseRect */

void CheckMouseFool(void)
{
    int i;

    if((GameInfo.GameListe.BuiltMenu.Taxi1ButtonDown == YES || GameInfo.GameListe.BuiltMenu.Taxi2ButtonDown == YES) &&
		Szenario.Info.Kachel[Mouse.SelectedKachel].Mask == TAXI_KACHEL)
	{
        // Es wurde eine Taxi auswahl getroffen:
        if(GameInfo.GameListe.BuiltMenu.Taxi1ButtonDown == YES)
            Szenario.Info.Kachel[GameInfo.SelectedKachel].TAXI_SCHALTER_1 = Mouse.SelectedKachel;
        if(GameInfo.GameListe.BuiltMenu.Taxi2ButtonDown == YES)
            Szenario.Info.Kachel[GameInfo.SelectedKachel].TAXI_SCHALTER_2 = Mouse.SelectedKachel;
	}
    if((GameInfo.GameListe.BuiltMenu.Taxi1ButtonDown == YES || GameInfo.GameListe.BuiltMenu.Taxi2ButtonDown == YES) &&
		Szenario.Info.Kachel[Mouse.SelectedKachel].Mask == BEAMER && Mouse.SelectedKachel != GameInfo.SelectedKachel)
	{ // Ein Beamer wurde ausgew�hlt:
        if(GameInfo.GameListe.BuiltMenu.Taxi1ButtonDown == YES)
            Szenario.Info.Kachel[GameInfo.SelectedKachel].BEAMER_NR_1 = Mouse.SelectedKachel;
        if(GameInfo.GameListe.BuiltMenu.Taxi2ButtonDown == YES)
            Szenario.Info.Kachel[GameInfo.SelectedKachel].BEAMER_NR_2 = Mouse.SelectedKachel;
	}
 //////////////////////////////////
    if(ProgrammSetup.ShowGameListe == NO)
    {
    	if(CheckMouseRect(LUPE_X+120, LUPE_Y, LUPE_X+120+25, LUPE_Y+25) != NO_AKTIV)
    		goto LupeCheck;
    	if(CheckMouseRect(INSPECT_X+120, INSPECT_Y, INSPECT_X+120+25, INSPECT_Y+25) != NO_AKTIV)
     		goto InspectCheck;
    }
    else
    {
        if(CheckMouseRect(LUPE_X, LUPE_Y, LUPE_X+25, LUPE_Y+25) != NO_AKTIV)
        {
        LupeCheck:
			GameInfo.GameListe.BuiltMenu.Taxi1ButtonDown = NO;
			GameInfo.GameListe.BuiltMenu.Taxi2ButtonDown = NO;
			GameInfo.SelectedKachel = NO_AKTIV;
            GameInfo.Befehl = SELECT_COMMAND;
            if(Mouse.Style != LUPE_MOUSE_STYLE)
                SetMouseStyle(LUPE_MOUSE_STYLE, YES, 1, 0, 0, 15, YES, 0);
            GameInfo.GameListe.BuiltDown = YES;
            GameInfo.GameListe.InfosDown = NO;
            GameInfo.GameListe.StatistikDown = NO;
            GameInfo.GameListe.OptionsDown = NO;
            GameInfo.GameListe.ObjectsDown = NO;
            GameInfo.GameListe.SzenarioDown = NO;
            GameInfo.GameListe.CommandsDown = NO;
        }
        if(CheckMouseRect(INSPECT_X, INSPECT_Y, INSPECT_X+25, INSPECT_Y+25) != NO_AKTIV)
        {
        InspectCheck:
			GameInfo.GameListe.BuiltMenu.Taxi1ButtonDown = NO;
			GameInfo.GameListe.BuiltMenu.Taxi2ButtonDown = NO;
            GameInfo.Befehl = INSPECT_COMMAND;
            if(Mouse.Style != INSPECT_MOUSE_STYLE)
                SetMouseStyle(INSPECT_MOUSE_STYLE, YES, 1, 0, 0, 15, YES, 0);
            GameInfo.GameListe.BuiltDown = YES;
            GameInfo.GameListe.InfosDown = NO;
            GameInfo.GameListe.StatistikDown = NO;
            GameInfo.GameListe.OptionsDown = NO;
            GameInfo.GameListe.ObjectsDown = NO;
            GameInfo.GameListe.SzenarioDown = NO;
            GameInfo.GameListe.CommandsDown = NO;
        }
    }
    if(GameInfo.Befehl == SELECT_COMMAND)
    {
        i = FindMouseFool();
    	if(i == NO_AKTIV)
        {
            i = FindMousePacMan();
        	if(i != NO_AKTIV)
            	i += FIRST_PACMAN;
    	}
    	if(i == NO_AKTIV)
        {
            i = FindMouseGegner();
        	if(i != NO_AKTIV)
            	i += MAX_FOOLS;
    	}
        if(i != NO_AKTIV)
        {
        	GameInfo.SelectedFool = i;
            GameInfo.GameListe.BuiltDown = YES;
            GameInfo.GameListe.InfosDown = NO;
            GameInfo.GameListe.StatistikDown = NO;
            GameInfo.GameListe.OptionsDown = NO;
            GameInfo.GameListe.ObjectsDown = NO;
            GameInfo.GameListe.SzenarioDown = NO;
        }
        else
        	GameInfo.SelectedFool = NO_AKTIV;
    	return;
    }
    if(Mouse.SelectedKachel != NO_AKTIV && GameInfo.Befehl == INSPECT_COMMAND &&
    	GameInfo.GameListe.BuiltMenu.Taxi1ButtonDown == NO && GameInfo.GameListe.BuiltMenu.Taxi2ButtonDown == NO)
	    GameInfo.SelectedKachel = Mouse.SelectedKachel;
} /* CheckMouseFool */
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
/*  Maus Scrollen:
    Wenn die Maus an einen der �usersten R�nder bewegt wird, Scrollt der
    Bildschirmausschnitt in die gew�hlte richtung. Wird zus�tzlich noch die
    linke Maustaste gedr�ckt, erh�ht sich die Srcoll Geschwindigkeit, bei
    der rechten Maustaste etwas st�rker.
    Wenn beim Scrollen eine Maustaste gedr�ckt wird, so kann kein Men� ge�ffnet
    werden, erst nach einmal loslassen sind sie wider w�hlbar. (PressedMouseScroll=YES/NO)
*/
void MouseScroll(void)
{
    int Timer;
    static int LastTimer = 0;

    if(Mouse.Show == NO)
    	return;
    Timer = timeGetTime()-LastTimer;
    if(Timer < ProgrammSetup.ScrollSpeed)
    	return;
    if(Mouse.XPos == Mouse.BoundX || Mouse.XPos == Mouse.BoundXB ||
       Mouse.YPos == Mouse.BoundY || Mouse.YPos == Mouse.BoundYH &&
       Mouse.Button != NO_MOUSE_BUTTON)
	{
        PressedMouseScroll = YES;
	    if(Mouse.Style != SCROLL_MOUSE_STYLE)
		    SetMouseStyle(SCROLL_MOUSE_STYLE, YES, 1, 0, NO_AKTIV, 15, NO, 0);
    }
	else
		if(Mouse.Button == NO_MOUSE_BUTTON)
	    {
        	PressedMouseScroll = NO;
            if(GameInfo.Befehl == SELECT_COMMAND)
            {
                if(Mouse.Style != LUPE_MOUSE_STYLE)
                    SetMouseStyle(LUPE_MOUSE_STYLE, YES, 1, 0, NO_AKTIV, 15, YES, 0);
            }
            else
            {
                if(GameInfo.Befehl == INSPECT_COMMAND)
                {
                    if(Mouse.Style != INSPECT_MOUSE_STYLE)
                        SetMouseStyle(INSPECT_MOUSE_STYLE, YES, 1, 0, NO_AKTIV, 15, YES, 0);
                }
                else
	                if(Mouse.Style != NORMAL_MOUSE_STYLE)
    	                SetMouseStyle(NORMAL_MOUSE_STYLE, YES, 1, 0, NO_AKTIV, 15, YES, 0);
        	}
    	}
    if(Mouse.XPos != Mouse.BoundX && Mouse.XPos != Mouse.BoundXB &&
    	Mouse.YPos != Mouse.BoundY && Mouse.YPos != Mouse.BoundYH)
    {
		if(Mouse.Button == NO_MOUSE_BUTTON)
        {
            if(GameInfo.Befehl == SELECT_COMMAND)
            {
                if(Mouse.Style != LUPE_MOUSE_STYLE)
                    SetMouseStyle(LUPE_MOUSE_STYLE, YES, 1, 0, NO_AKTIV, 15, YES, 0);
            }
            else
            {
                if(GameInfo.Befehl == INSPECT_COMMAND)
                {
                    if(Mouse.Style != INSPECT_MOUSE_STYLE)
                        SetMouseStyle(INSPECT_MOUSE_STYLE, YES, 1, 0, NO_AKTIV, 15, YES, 0);
                }
                else
                	if(Mouse.Style != NORMAL_MOUSE_STYLE)
                    	SetMouseStyle(NORMAL_MOUSE_STYLE, YES, 1, 0, NO_AKTIV, 15, YES, 0);
        	}
        }
        return;
	}
    if(Mouse.XPos == Mouse.BoundX && Mouse.Button == NO_MOUSE_BUTTON)
    	MoveScreenLeft(SCROLL_SPEED);
	if(Mouse.XPos == Mouse.BoundXB && Mouse.Button == NO_MOUSE_BUTTON)
    	MoveScreenRight(SCROLL_SPEED);
	if(Mouse.YPos == Mouse.BoundY && Mouse.Button == NO_MOUSE_BUTTON)
    	MoveScreenUp(SCROLL_SPEED);
	if(Mouse.YPos == Mouse.BoundYH && Mouse.Button == NO_MOUSE_BUTTON)
    	MoveScreenDown(SCROLL_SPEED);
	if(Mouse.XPos == Mouse.BoundX && Mouse.Button == LEFT_MOUSE_BUTTON)
    	MoveScreenLeft(SCROLL_SPEED+LEFT_MOUSE_BUTTON_SPEED);
	if(Mouse.XPos == Mouse.BoundXB && Mouse.Button == LEFT_MOUSE_BUTTON)
    	MoveScreenRight(SCROLL_SPEED+LEFT_MOUSE_BUTTON_SPEED);
	if(Mouse.YPos == Mouse.BoundY && Mouse.Button == LEFT_MOUSE_BUTTON)
    	MoveScreenUp(SCROLL_SPEED+LEFT_MOUSE_BUTTON_SPEED);
	if(Mouse.YPos == Mouse.BoundYH && Mouse.Button == LEFT_MOUSE_BUTTON)
    	MoveScreenDown(SCROLL_SPEED+LEFT_MOUSE_BUTTON_SPEED);
	if(Mouse.XPos == Mouse.BoundX && Mouse.Button == RIGHT_MOUSE_BUTTON)
    	MoveScreenLeft(SCROLL_SPEED+RIGHT_MOUSE_BUTTON_SPEED);
	if(Mouse.XPos == Mouse.BoundXB && Mouse.Button == RIGHT_MOUSE_BUTTON)
    	MoveScreenRight(SCROLL_SPEED+RIGHT_MOUSE_BUTTON_SPEED);
	if(Mouse.YPos == Mouse.BoundY && Mouse.Button == RIGHT_MOUSE_BUTTON)
    	MoveScreenUp(SCROLL_SPEED+RIGHT_MOUSE_BUTTON_SPEED);
	if(Mouse.YPos == Mouse.BoundYH && Mouse.Button == RIGHT_MOUSE_BUTTON)
    	MoveScreenDown(SCROLL_SPEED+RIGHT_MOUSE_BUTTON_SPEED);
} /* MouseScroll */

void MoveScreenLeft(int Speed)
{
    SetMouseStyle(SCROLL_MOUSE_STYLE, YES, 1, 0, NO_AKTIV, 15, NO, 0);
    if(GameInfo.ScreenPixelPosX > Speed)
        GameInfo.ScreenPixelPosX -= Speed;
    else
        if(GameInfo.ScreenPosX > -1-GameInfo.KachelLeftPlus)
        {
            GameInfo.ScreenPosX--;
            GameInfo.ScreenPixelPosX = (KACHEL_B/2);
        }
        else
        {
            GameInfo.ScreenPixelPosX = 0;
   			SetMouseStyle(NO_SCROLL_MOUSE_STYLE, YES, 1, 0, NO_AKTIV, 15, NO, 0);
        }
} /* MoveScreenLeft */

void MoveScreenRight(int Speed)
{
    SetMouseStyle(SCROLL_MOUSE_STYLE, YES, 1, 0, NO_AKTIV, 15, NO, 0);
    if(GameInfo.ScreenPixelPosX < KACHEL_B-Speed-(KACHEL_B/2))
       GameInfo.ScreenPixelPosX += Speed;
    else
        if(GameInfo.ScreenPosX < Szenario.Info.KarteB-WINDOW_B+GameInfo.KachelLeftPlus)
        {
            GameInfo.ScreenPosX++;
            GameInfo.ScreenPixelPosX = 0;
        }
        else
        {
            GameInfo.ScreenPixelPosX = (KACHEL_B/2);
   			SetMouseStyle(NO_SCROLL_MOUSE_STYLE, YES, 1, 0, NO_AKTIV, 15, NO, 0);
        }
} /* MoveScreenRight */

void MoveScreenUp(int Speed)
{
    SetMouseStyle(SCROLL_MOUSE_STYLE, YES, 1, 0, NO_AKTIV, 15, NO, 0);
    if(GameInfo.ScreenPixelPosY > Speed)
        GameInfo.ScreenPixelPosY -= Speed;
    else
        if(GameInfo.ScreenPosY > -2)
        {
            GameInfo.ScreenPosY--;
            GameInfo.ScreenPixelPosY = (KACHEL_H/2);
        }
        else
        {
            GameInfo.ScreenPixelPosY = 0;
   			SetMouseStyle(NO_SCROLL_MOUSE_STYLE, YES, 1, 0, NO_AKTIV, 15, NO, 0);
    	}
} /* MoveScreenUp */

void MoveScreenDown(int Speed)
{
    SetMouseStyle(SCROLL_MOUSE_STYLE, YES, 1, 0, NO_AKTIV, 15, NO, 0);
    if(GameInfo.ScreenPixelPosY < KACHEL_H-Speed-(KACHEL_H/2))
        GameInfo.ScreenPixelPosY += Speed;
    else
        if(GameInfo.ScreenPosY < Szenario.Info.KarteH-WINDOW_H-1)
        {
            GameInfo.ScreenPosY++;
            GameInfo.ScreenPixelPosY = 0;
        }
        else
        {
            GameInfo.ScreenPixelPosY = (KACHEL_H/2);
			SetMouseStyle(NO_SCROLL_MOUSE_STYLE, YES, 1, 0, NO_AKTIV, 15, NO, 0);
		}
} /* MoveScreenDown */
//////////////////////////////////////////////////////////////////////////

// Zentriert eine Position ins Spielfeld:
void CentereScreenPosition(int *ScreenPosX, int *ScreenPosY)
{
    int x, y;

    x = *ScreenPosX;
	y = *ScreenPosY;
    if(x > (WINDOW_B/2)+PersXY[y][0])
        x -= (WINDOW_B/2)+PersXY[y][0];
    else
        x = 0;
    if(y > (WINDOW_H/2))
        y -= (WINDOW_H/2);
    else
        y = 0;
    if(x+(WINDOW_B/2)+PersXY[y][0] > Szenario.Info.KarteB)
        x = Szenario.Info.KarteB-(WINDOW_B/2);
    if(y+(WINDOW_H/2) > Szenario.Info.KarteH)
        y = Szenario.Info.KarteH-(WINDOW_H/2);
	*ScreenPosX = x+2;
	*ScreenPosY = y+1;
} /* CentereScreenPosition */

//////////////////////////////////////////////////////////////////////////
void SetBB_Message(char *BlackMessage, int Time, int ScreenPosX, int ScreenPosY, int Info, int Jump)
{
	BB_Message.On = YES;
    sprintf(BB_Message.Message, BlackMessage);
	BB_Message.Time = Time;
	BB_Message.Step = 0;
    if(ScreenPosX != NO_AKTIV)
    {
        // Sorgt daf�r, das das Object m�glichst immer in der Bildmitte ist:
        CentereScreenPosition(&ScreenPosX, &ScreenPosY);
        BB_Message.ScreenPosX = ScreenPosX;
        BB_Message.ScreenPosY = ScreenPosY;
        BB_Message.ScreenPixelPosX = 0;
        BB_Message.ScreenPixelPosY = 0;
	    BB_Message.Info = Info;
	}
	if(Jump == YES)
    {
	    if(ScreenPosX == NO_AKTIV)
        	return;
        GameInfo.ScreenPosX = BB_Message.ScreenPosX;
        GameInfo.ScreenPosY = BB_Message.ScreenPosY;
        GameInfo.ScreenPixelPosX = BB_Message.ScreenPixelPosX;
        GameInfo.ScreenPixelPosY = BB_Message.ScreenPixelPosY;
    }
} /* SetBB_Message */

void ShowBB_Message(int FontNr)
{
	if(BB_Message.On == YES)
    {
        RECT rcRect;

        SetRect(&rcRect, 0, 0, 520, 100);
        Back->BltFast(0, ScreenRes[1]-110, MeldungPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        PrintText(60, ScreenRes[1]-80, BB_Message.Message, FontNr, 0, 34, 40, Back);
	}
} /* ShowBB_Message */

void SetBB_SmallMessage(char *BlackMessage, int Time)
{
	BB_SmallMessage.On = YES;
    sprintf(BB_SmallMessage.Message, BlackMessage);
	BB_SmallMessage.Time = Time;
	BB_SmallMessage.Step = 0;
} /* SetBB_SmallMessage */

void ShowBB_SmallMessage(int FontNr)
{
	if(BB_SmallMessage.On == YES)
    {
        RECT rcRect;
        DDBLTFX     ddbltfx;

        ddbltfx.dwSize = sizeof(ddbltfx);
        ddbltfx.dwFillColor = 15;
        SetRect(&rcRect, 0, 4, ScreenRes[0], 5);
        Back->Blt(&rcRect, NULL, NULL, DDBLT_COLORFILL, &ddbltfx);
        SetRect(&rcRect, 0, 21, ScreenRes[0], 22);
        Back->Blt(&rcRect, NULL, NULL, DDBLT_COLORFILL, &ddbltfx);
        ddbltfx.dwFillColor = 0;
        SetRect(&rcRect, 0, 5, ScreenRes[0]-1, 20);
        Back->Blt(&rcRect, NULL, NULL, DDBLT_COLORFILL, &ddbltfx);
        PrintText(10, 7, BB_SmallMessage.Message, FontNr, 0, 1000, 1000, Back);
	}
} /* ShowBB_SmallMessage */
//////////////////////////////////////////////////////////////////////////
void InitGetFrameRate(void)
{
	GameInfo.Fps = 0;
	GameInfo.FpsCount = 0;
    GameInfo.FpsTimer = 0;
    GameInfo.FpsLastTimer = 0;
} /* InitGetFrameRate */

void GetFrameRate(void)
{
    GameInfo.FpsCount++;
    GameInfo.FpsTimer = timeGetTime()-GameInfo.FpsLastTimer;
    if(GameInfo.FpsTimer < 1000)
    	return;
   	GameInfo.Fps = (GameInfo.FpsCount*1000)/GameInfo.FpsTimer;
    GameInfo.FpsLastTimer = timeGetTime();
    GameInfo.FpsCount = 0;
} /* GetFrameRate */

void ShowFrameRate(void)
{
    char temp[50];

    PrintText(5, 100, "Fps", 0, 0, 1, 40, Back);
    sprintf(temp, "%d", GameInfo.Fps);
    PrintText(5, 160, temp, 0, 0, 5, 40, Back);
} /* ShowFrameRate */
//////////////////////////////////////////////////////////////////////////

void LoadWaitPic(void)
{
    RECT rcRect;
	LPDIRECTDRAWSURFACE LadePic;
    char temp[50];

    LadePic = DDLoadBitmap(lpDD, "Bilder/Load.bmp", 0, 0, NO);
    DDSetColorKey(LadePic, 5);
    SetRect(&rcRect, 0, 0, 350, 250);
    Back->BltFast(ScreenRes[0]/2-175, ScreenRes[1]/2-125, LadePic, &rcRect, DDBLTFAST_SRCCOLORKEY);
    sprintf(temp, "%s...", GameTexte[T_LADE]);
    PrintText(ScreenRes[0]/2-80, ScreenRes[1]/2-25, temp, 0, 0, 1000, 1000, Back);
    sprintf(temp, "%s...", GameTexte[T_PLEASE_WAIT]);
    PrintText(ScreenRes[0]/2-130, ScreenRes[1]/2-5, temp, 0, 0, 1000, 1000, Back);
	LadePic->Release();
    UpdateDisplay();
} /* LoadWaitPic */

void ShowLoadStatus(int status)
{
    RECT rcRect;

    SetRect(&rcRect, 0+status, 0, 250, 25);
    Primary->BltFast(ScreenRes[0]/2-100+status, ScreenRes[1]/2+150, LoadStatusPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
    SetRect(&rcRect, 0, 25, 0+status, 50);
    Primary->BltFast(ScreenRes[0]/2-100, ScreenRes[1]/2+150, LoadStatusPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
} /* ShowLoadStatus */

void CheckAniScene(void)
{
    int Timer, x, y;
    static int LastTimer = 0;

    if(GameInfo.AnimatedWalls == NO)
    	return;
    Timer = timeGetTime()-LastTimer;
    if(Timer < ProgrammSetup.GameSpeed+70)
    	return;
    LastTimer = timeGetTime();
    for(y = 0; y < Szenario.Info.KarteH; y++)
        for(x = 0; x < Szenario.Info.KarteB; x++)
        {
            if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Mask == TAXI_KACHEL ||
            	Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Mask == TAXI_KACHEL_SCHALTER ||
                Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Mask == BEAMER)
                continue;
            if((Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Pic > FLOOR_ANI && Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Pic < DEADLY_WALKS) ||
            	Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Pic > DEADLY_WALKS_ANI && Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Pic < WALLS)
            {
                if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].PicAniCircle == YES)
                {
                    Szenario.Info.Kachel[Szenario.PosInfo[x][y]].PicAniStep++;
                    if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].PicAniStep > 13)
                        Szenario.Info.Kachel[Szenario.PosInfo[x][y]].PicAniStep = 0;
                }
                if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].PicAniCircle == NO)
                {
                    if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].PicAniStepTurn == 0)
                    {
                        Szenario.Info.Kachel[Szenario.PosInfo[x][y]].PicAniStep++;
                        if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].PicAniStep > 12)
                            Szenario.Info.Kachel[Szenario.PosInfo[x][y]].PicAniStep = 1;
                    }
                    else
                    {
                        Szenario.Info.Kachel[Szenario.PosInfo[x][y]].PicAniStep--;
                        if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].PicAniStep < 1)
                            Szenario.Info.Kachel[Szenario.PosInfo[x][y]].PicAniStepTurn = 0;
                    }
                }
            }
            if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPic == NO_AKTIV)
            {
                if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStepTurn == PUNKT)
	            {
                    Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStep++;
                    if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStep > 18)
						Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStep = 0;
                }
                continue;
			}
            if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPic == SPECIAL_EXIT)
            {
                if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStepTurn == 0)
                {
                    Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStep++;
                    if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStep > 6)
                        Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStepTurn = 1;
                }
                else
                {
                    Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStep--;
                    if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStep < 1)
                        Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStepTurn = 0;
                }
            	continue;
            }
        	if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPic < DOOR_ANI-1)
            {
                if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniCircle == YES)
                {
                    Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStep++;
                    if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStep > 14)
                        Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStep = 0;
                	continue;
                }
                if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniCircle == NO)
                {
                    if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStepTurn == 0)
                    {
                        Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStep++;
                        if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStep > 13)
                            Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStepTurn = 1;
                    }
                    else
                    {
                        Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStep--;
                        if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStep < 1)
                            Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStepTurn = 0;
                    }
                }
			}
        }
} /* CheckAniScene */

void CheckSelectedAni(void)
{
    int Timer;
    static int LastTimer = 0;

    Timer = timeGetTime()-LastTimer;
    if(Timer < ProgrammSetup.GameSpeed+70)
    	return;
    LastTimer = timeGetTime();
    if(GameInfo.LupeTurn == 0)
    {
        GameInfo.LupeStep++;
        if(GameInfo.LupeStep > 14)
            GameInfo.LupeTurn = 1;
    }
    else
    {
        GameInfo.LupeStep--;
        if(GameInfo.LupeStep < 1)
            GameInfo.LupeTurn = 0;
    }
    if(GameInfo.SelectedFoolAniStep == 0)
        if(GameInfo.SelectedFoolAni < 18)
            GameInfo.SelectedFoolAni++;
        else
            GameInfo.SelectedFoolAniStep = 1;
    else
        if(GameInfo.SelectedFoolAni > 0)
            GameInfo.SelectedFoolAni--;
        else
            GameInfo.SelectedFoolAniStep = 0;
} /* CheckSelectedAni */
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
void DrawMini(void)
{
    int x, y;
    DDBLTFX     ddbltfx;
    RECT rcRect;

    ddbltfx.dwSize = sizeof(ddbltfx);
    for(y = 0; y < Szenario.Info.KarteH; y++)
       for(x = 0; x < Szenario.Info.KarteB; x++)
    {
        SetRect(&rcRect, x, y, x+1, y+1);
        if(ProgrammSetup.MiniShowFloor == YES)
			if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Pic != NO_AKTIV
			   && (Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Pic > FLOOR-1 && Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Pic < DEADLY_WALKS-1))
        		ddbltfx.dwFillColor = 8;
        if(ProgrammSetup.MiniShowDeadlyFloor == YES)
			if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Pic == NO_AKTIV
			   ||(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Pic > DEADLY_WALKS-1 && Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Pic < MOVE_WALLS-1))
	    		ddbltfx.dwFillColor = 1;
        if(ProgrammSetup.MiniShowWalls == YES)
	        if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPic != NO_AKTIV && Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPic > WALLS-1 && Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPic < MOVE_WALLS-1)
    	        ddbltfx.dwFillColor = 2;
        if(ProgrammSetup.MiniShowMoveWalls == YES)
	        if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPic != NO_AKTIV && Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPic > MOVE_WALLS-1 && Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPic < FIRST_INTEM-1)
    	        ddbltfx.dwFillColor = 3;
        if(ProgrammSetup.MiniShowCommands == YES)
	        if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Command != NO_COMMAND)
    	        ddbltfx.dwFillColor = 14;
        if(ProgrammSetup.MiniShowIntems == YES)
	        if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Intem != NO_AKTIV)
    	        ddbltfx.dwFillColor = 13;
        if(ProgrammSetup.MiniShowObjects == YES)
	        if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPic != NO_AKTIV && Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPic > FIRST_OBJECT-1)
    	        ddbltfx.dwFillColor = 12;
        if(ProgrammSetup.MiniShowFools == YES)
	        if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Besetzt != NO_AKTIV)
    	        ddbltfx.dwFillColor = 15;
    	MiniPic->Blt(&rcRect, NULL, NULL, DDBLT_COLORFILL, &ddbltfx);
    }
} /* DrawMini */

void DrawMiniKachel(int x, int y)
{
    DDBLTFX     ddbltfx;
    RECT rcRect;

    ddbltfx.dwSize = sizeof(ddbltfx);
    SetRect(&rcRect, x, y, x+1, y+1);
    ddbltfx.dwFillColor = 0;
    if(ProgrammSetup.MiniShowFloor == YES)
        if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Pic != NO_AKTIV
           && (Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Pic > FLOOR-1 && Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Pic < DEADLY_WALKS-1))
            ddbltfx.dwFillColor = 8;
    if(ProgrammSetup.MiniShowDeadlyFloor == YES)
        if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Pic == NO_AKTIV
           ||(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Pic > DEADLY_WALKS-1 && Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Pic < MOVE_WALLS-1))
            ddbltfx.dwFillColor = 1;
    if(ProgrammSetup.MiniShowWalls == YES)
        if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPic != NO_AKTIV && Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPic > WALLS-1 && Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPic < MOVE_WALLS-1)
            ddbltfx.dwFillColor = 2;
    if(ProgrammSetup.MiniShowMoveWalls == YES)
        if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPic != NO_AKTIV && Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPic > MOVE_WALLS-1 && Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPic < FIRST_INTEM-1)
            ddbltfx.dwFillColor = 3;
    if(ProgrammSetup.MiniShowCommands == YES)
        if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Command != NO_COMMAND)
   	        ddbltfx.dwFillColor = 14;
    if(ProgrammSetup.MiniShowIntems == YES)
        if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Intem != NO_AKTIV)
   	        ddbltfx.dwFillColor = 13;
    if(ProgrammSetup.MiniShowObjects == YES)
        if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPic != NO_AKTIV && Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPic > FIRST_OBJECT-1)
   	        ddbltfx.dwFillColor = 12;
    if(ProgrammSetup.MiniShowFools == YES)
        if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Besetzt != NO_AKTIV)
            ddbltfx.dwFillColor = 15;
    MiniPic->Blt(&rcRect, NULL, NULL, DDBLT_COLORFILL, &ddbltfx);
} /* DrawMiniKachel */

void DrawMiniToDisplay(int x, int y)
{
    RECT rcRect;

    SetRect(&rcRect, 0, 0, 80, 80);
    Back->BltFast(x, y, MiniPic, &rcRect, FALSE);
    // Filter Kn�pfe:
    if(ProgrammSetup.MiniShowFools == YES)
	    SetRect(&rcRect, 1, 799, 11, 809);
    else
	    SetRect(&rcRect, 1, 788, 11, 798);
    Back->BltFast(x+85, y, GameListPic, &rcRect, FALSE);
    if(ProgrammSetup.MiniShowWalls == YES)
	    SetRect(&rcRect, 12, 799, 22, 809);
    else
	    SetRect(&rcRect, 12, 788, 22, 798);
    Back->BltFast(x+85, y+15, GameListPic, &rcRect, FALSE);
    if(ProgrammSetup.MiniShowMoveWalls == YES)
	    SetRect(&rcRect, 23, 799, 33, 809);
    else
	    SetRect(&rcRect, 23, 788, 33, 798);
    Back->BltFast(x+85, y+30, GameListPic, &rcRect, FALSE);
    if(ProgrammSetup.MiniShowFloor == YES)
	    SetRect(&rcRect, 34, 799, 44, 809);
    else
	    SetRect(&rcRect, 34, 788, 44, 798);
    Back->BltFast(x+85, y+45, GameListPic, &rcRect, FALSE);
    if(ProgrammSetup.MiniShowDeadlyFloor == YES)
	    SetRect(&rcRect, 45, 799, 55, 809);
    else
	    SetRect(&rcRect, 45, 788, 55, 798);
    Back->BltFast(x+85, y+60, GameListPic, &rcRect, FALSE);
    if(ProgrammSetup.MiniShowCommands == YES)
	    SetRect(&rcRect, 56, 799, 66, 809);
    else
	    SetRect(&rcRect, 56, 788, 66, 798);
    Back->BltFast(x+85, y+75, GameListPic, &rcRect, FALSE);
    if(ProgrammSetup.MiniShowIntems == YES)
	    SetRect(&rcRect, 67, 799, 77, 809);
    else
	    SetRect(&rcRect, 67, 788, 77, 798);
    Back->BltFast(x+100, y, GameListPic, &rcRect, FALSE);
    if(ProgrammSetup.MiniShowObjects == YES)
	    SetRect(&rcRect, 78, 799, 88, 809);
    else
	    SetRect(&rcRect, 78, 788, 88, 798);
    Back->BltFast(x+100, y+15, GameListPic, &rcRect, FALSE);
    if(ProgrammSetup.MiniShowRect == YES)
    {
        DrawRect(x+GameInfo.ScreenPosX, y+GameInfo.ScreenPosY, WINDOW_B, WINDOW_H, 15, Back);
	    SetRect(&rcRect, 89, 799, 99, 809);
    }
    else
	    SetRect(&rcRect, 89, 788, 99, 798);
    Back->BltFast(x+100, y+30, GameListPic, &rcRect, FALSE);
} /* DrawMiniToDisplay */

void CheckMiniFilter(int x, int y)
{
    if(Mouse.Button == LEFT_MOUSE_BUTTON && PressedMouseScroll == NO)
	{
        if(TimerNew == YES)
            TimerNew = NO;
        else
            return;
        if(CheckMouseRect(x+85, y, x+95, y+10) != NO_AKTIV)
        {
            if(ProgrammSetup.MiniShowFools == YES)
                ProgrammSetup.MiniShowFools = NO;
            else
                ProgrammSetup.MiniShowFools = YES;
			DrawMini();
        }
        if(CheckMouseRect(x+85, y+15, x+95, y+25) != NO_AKTIV)
        {
            if(ProgrammSetup.MiniShowWalls == YES)
                ProgrammSetup.MiniShowWalls = NO;
            else
                ProgrammSetup.MiniShowWalls = YES;
			DrawMini();
        }
        if(CheckMouseRect(x+85, y+30, x+95, y+40) != NO_AKTIV)
        {
            if(ProgrammSetup.MiniShowMoveWalls == YES)
                ProgrammSetup.MiniShowMoveWalls = NO;
            else
            	ProgrammSetup.MiniShowMoveWalls = YES;
			DrawMini();
        }
        if(CheckMouseRect(x+85, y+45, x+95, y+55) != NO_AKTIV)
        {
            if(ProgrammSetup.MiniShowFloor == YES)
                ProgrammSetup.MiniShowFloor = NO;
            else
                ProgrammSetup.MiniShowFloor = YES;
			DrawMini();
        }
        if(CheckMouseRect(x+85, y+60, x+95, y+70) != NO_AKTIV)
        {
            if(ProgrammSetup.MiniShowDeadlyFloor == YES)
                ProgrammSetup.MiniShowDeadlyFloor = NO;
            else
                ProgrammSetup.MiniShowDeadlyFloor = YES;
			DrawMini();
        }
        if(CheckMouseRect(x+85, y+75, x+95, y+85) != NO_AKTIV)
        {
            if(ProgrammSetup.MiniShowCommands == YES)
                ProgrammSetup.MiniShowCommands = NO;
            else
                ProgrammSetup.MiniShowCommands = YES;
			DrawMini();
        }
        if(CheckMouseRect(x+100, y, x+110, y+10) != NO_AKTIV)
        {
            if(ProgrammSetup.MiniShowIntems == YES)
                ProgrammSetup.MiniShowIntems = NO;
            else
                ProgrammSetup.MiniShowIntems = YES;
			DrawMini();
        }
        if(CheckMouseRect(x+100, y+15, x+110, y+25) != NO_AKTIV)
        {
            if(ProgrammSetup.MiniShowObjects == YES)
                ProgrammSetup.MiniShowObjects = NO;
            else
                ProgrammSetup.MiniShowObjects = YES;
			DrawMini();
        }
        if(CheckMouseRect(x+100, y+30, x+110, y+45) != NO_AKTIV)
        {
            if(ProgrammSetup.MiniShowRect == YES)
                ProgrammSetup.MiniShowRect = NO;
            else
                ProgrammSetup.MiniShowRect = YES;
			DrawMini();
        }
    }
} /* CheckMiniFilter */

void CheckMiniScroll(int x, int y)
{
    if(PressedMouseScroll == YES)
		return;
    if(Mouse.Button == RIGHT_MOUSE_BUTTON &&
    	CheckMouseRect(x, y, x+Szenario.Info.KarteB+1, y+Szenario.Info.KarteH+1) != NO_AKTIV)
    {
        GameInfo.ScreenPosX = Mouse.XPos-x;
        GameInfo.ScreenPosY = Mouse.YPos-y;
        if(GameInfo.ScreenPosX > Szenario.Info.KarteB)
            GameInfo.ScreenPosX = Szenario.Info.KarteB;
        if(GameInfo.ScreenPosY > Szenario.Info.KarteH-WINDOW_H+1)
            GameInfo.ScreenPosY = Szenario.Info.KarteH-WINDOW_H;
		PressedMouseScroll = 999;
        Mouse.SelectedKachel = NO_AKTIV;
        return;
    }
    if(PressedMouseScroll == 999)
    {
        if(Mouse.Button == 0)
            PressedMouseScroll = NO;
        Mouse.SelectedKachel = NO_AKTIV;
        return;
    }
} /* CheckMiniScroll */
//////////////////////////////////////////////////////////////////////////
void DrawRect(int x, int y, int b, int h, int color, LPDIRECTDRAWSURFACE Picture)
{
    DDBLTFX     ddbltfx;
    RECT rcRect;

    ddbltfx.dwSize = sizeof(ddbltfx);
    ddbltfx.dwFillColor = color;
    SetRect(&rcRect, x, y, x+b, y+1);
    Picture->Blt(&rcRect, NULL, NULL, DDBLT_COLORFILL, &ddbltfx);
    SetRect(&rcRect, x, y, x+1, y+h);
    Picture->Blt(&rcRect, NULL, NULL, DDBLT_COLORFILL, &ddbltfx);
    SetRect(&rcRect, x, y+h, x+b+1, y+h+1);
    Picture->Blt(&rcRect, NULL, NULL, DDBLT_COLORFILL, &ddbltfx);
    SetRect(&rcRect, x+b, y, x+b+1, y+h+1);
    Picture->Blt(&rcRect, NULL, NULL, DDBLT_COLORFILL, &ddbltfx);
} /* DrawRect */
//////////////////////////////////////////////////////////////////////////

// Ermitelt die Position, auf der sich der Balken befindet, und rechnet den Anteil aus:
int CheckPushBar(int BarX, int BarY, int BarB, int BarH, int Ausrichtung)
{
	BarB += 2;
    if(Mouse.Button != LEFT_MOUSE_BUTTON || PressedMouseScroll == YES ||
	    CheckMouseRect(BarX, BarY, BarX+BarB, BarY+BarH) == NO_AKTIV) // Die Mausbefintet sich nicht �ber dem Zieh Balken
    	return NO_AKTIV;
    // Ok die Maus manipuliert den Balken:
    if(Ausrichtung == 0) // Der Balken geht von links nach rechts
    	return(Mouse.XPos-BarX-1);
    if(Ausrichtung == 1) // Der Balken geht von unten nach oben
    	return(Mouse.YPos-BarY-1);
   	return NO_AKTIV;
} /* CheckPushBar */

// �ffnet oder Schlie�t eine T�re:
void CheckDoorAni(void)
{
    int x, y;
//    int Timer2, x, y;
//    static int LastTimer2 = 0;
    int Timer;
    static int LastTimer = 0;

    Timer = timeGetTime()-LastTimer;
    if(Timer < ProgrammSetup.GameSpeed)
    	return;
    LastTimer = timeGetTime();
//    Timer2 = timeGetTime()-LastTimer2;
//    if(Timer2 < 60)
//    	return;
//    LastTimer2 = timeGetTime();
    for(y = 0; y < Szenario.Info.KarteH; y++)
        for(x = 0; x < Szenario.Info.KarteB; x++)
        {
            if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStepTurn == DOOR_CLOSE)
                Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStepTurn == DOOR_OPEN;
            else
                Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStepTurn == DOOR_CLOSE;
        	if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPic > DOOR_ANI-1)
            {
				if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStepTurn == DOOR_OPENING)
                { // Die T�re �ffnet sich gerade:
                    if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStep < MAX_WALL_PIC_B)
						Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStep++;
                    else
						Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStepTurn = DOOR_OPEN;
                }
				if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStepTurn == DOOR_CLOSEING)
                { // Die T�re schlie�t sich gerade:
                    if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStep > 0)
						Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStep--;
                    else
						Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStepTurn = DOOR_CLOSE;
                }
            }
        }

} /* CheckDoorAni */

void CheckMoveWallCreateDestroyed(int i)
{
	CheckBeamer(i);
    if(Szenario.Info.Kachel[i].Pic > DEADLY_WALKS-1 &&
        Szenario.Info.Kachel[i].WallPic > MOVE_WALLS-1 &&
        Szenario.Kachel[i][KACHEL_PIXEL_X] == 0 &&
        Szenario.Kachel[i][KACHEL_PIXEL_Y] == 0 &&
        (Szenario.Info.Kachel[i].Mask < FIRST_MOVE_MASK-1 || Szenario.Info.Kachel[i].Mask > FIRST_MOVE_MASK+MAX_MOVE_MASK-1))
    {
        if(Szenario.Info.Kachel[i].WallPic-MOVE_WALLS < 20)
            Szenario.Info.Kachel[i].Mask = FIRST_MOVE_MASK+(Szenario.Info.Kachel[i].WallPic-MOVE_WALLS);
        Szenario.Info.Kachel[i].WallPic = NO_AKTIV;
        Szenario.Info.Kachel[i].Command = NO_COMMAND;
    }
    if(Szenario.Info.Kachel[i].Pic > FLOOR-1 &&
        Szenario.Info.Kachel[i].Pic < DEADLY_WALKS-1 &&
        Szenario.Info.Kachel[i].Mask != NO_AKTIV)
    {
        if(Szenario.Info.Kachel[i].Mask > FIRST_MOVE_MASK-1 && Szenario.Info.Kachel[i].Mask < FIRST_MOVE_MASK+MAX_MOVE_MASK-1)
        {
            Szenario.Info.Kachel[i].WallPic = Szenario.Info.Kachel[i].Mask+MOVE_WALLS+1-FIRST_MOVE_MASK-1;
            Szenario.Info.Kachel[i].Mask = NO_AKTIV;
        }
    }
} /* CheckMoveWallCreateDestroyed */

////////////////////////////////////////////////////////////////////////////7777
void SaveLevel(char *LevelName)
{
    char temp[100];
    int datei;
    int i;

   // Normales Szenenario vorbereiten:
    Szenario.Info.StartPosX = GameInfo.ScreenPosX;
    Szenario.Info.StartPosY = GameInfo.ScreenPosY;
    Szenario.Info.StartPixelPosX = GameInfo.ScreenPixelPosX;
    Szenario.Info.StartPixelPosY = GameInfo.ScreenPixelPosY;
    for(i = 0; i < (Szenario.Info.KarteB*Szenario.Info.KarteH); i++) // Alle Animationen auf Grundwert setzen
    {
        if(Szenario.Info.Kachel[i].Mask != TAXI_KACHEL_SCHALTER)
            Szenario.Info.Kachel[i].WallPicAniStep = Szenario.Kachel[i][START_WALL_ANI_STEP];
    }
    for(i = 0; i < (Szenario.Info.KarteB*Szenario.Info.KarteH); i++) // Alle Animationen auf Grundwert setzen
        Szenario.Info.Kachel[i].PicAniStep = Szenario.Kachel[i][START_KACHEL_PIC_ANI_STEP];
	stpcpy(Szenario.Info.LevelName, LevelName);
   // Level Optimieren:
    // Die Srceen startposition Sichern:
    SavedLevel.StartPosX = (char)Szenario.Info.StartPosX;
    SavedLevel.StartPosY = (char)Szenario.Info.StartPosY;
    SavedLevel.StartPixelPosX = (char)Szenario.Info.StartPixelPosX;
    SavedLevel.StartPixelPosY = (char)Szenario.Info.StartPixelPosY;
   // Die Levelgr��e festlegen:
    SavedLevel.KarteB = (char)Szenario.Info.KarteB;
    SavedLevel.KarteH = (char)Szenario.Info.KarteH;
   // Sonstige Werte sichern:
    SavedLevel.FoolAnzahl = (short)Szenario.Info.FoolAnzahl;
    SavedLevel.GegnerAnzahl = (short)Szenario.Info.GegnerAnzahl;
    SavedLevel.ExitAnzahl = (short)Szenario.Info.ExitAnzahl;
    SavedLevel.PacManAnzahl = (short)Szenario.Info.PacManAnzahl;
    SavedLevel.PunkteAnzahl = (short)Szenario.Info.PunkteAnzahl;
    SavedLevel.ToFinish_LiveFools = (short)Szenario.Info.ToFinish_LiveFools;
    for(i = 0; i < 9; i++)
	    SavedLevel.Commands[i] = (char)Szenario.Info.Commands[i];
    SavedLevel.LimitedTime = (char)Szenario.Info.LimitedTime;
    SavedLevel.TimeHours = (char)Szenario.Info.TimeHours;
    SavedLevel.TimeSeconds = (char)Szenario.Info.TimeSeconds;
    stpcpy(SavedLevel.LevelName, Szenario.Info.LevelName);
    stpcpy(SavedLevel.SzenarioSet, Szenario.Info.SzenarioSet);
   // Fools sichern:
    for(i = 0; i < MAX_FOOLS; i++)
    {
	    SavedLevel.FoolInfo[i].Fool_ID = (short)Szenario.Info.FoolInfo[i].Fool_ID;
	    SavedLevel.FoolInfo[i].OnLive = (char)Szenario.Info.FoolInfo[i].OnLive;
	    SavedLevel.FoolInfo[i].Power = (char)Szenario.Info.FoolInfo[i].Power;
	    SavedLevel.FoolInfo[i].MaxPower = (char)Szenario.Info.FoolInfo[i].MaxPower;
	    SavedLevel.FoolInfo[i].Richtung = (char)Szenario.Info.FoolInfo[i].Richtung;
	    SavedLevel.FoolInfo[i].Befehl = (char)Szenario.Info.FoolInfo[i].Befehl;
	    SavedLevel.FoolInfo[i].Intem[0] = (char)Szenario.Info.FoolInfo[i].Intem[0];
	    SavedLevel.FoolInfo[i].Intem[1] = (char)Szenario.Info.FoolInfo[i].Intem[1];
	    SavedLevel.FoolInfo[i].Intem[2] = (char)Szenario.Info.FoolInfo[i].Intem[2];
	    SavedLevel.FoolInfo[i].Intem[3] = (char)Szenario.Info.FoolInfo[i].Intem[3];
	    SavedLevel.FoolInfo[i].Intem[4] = (char)Szenario.Info.FoolInfo[i].Intem[4];
	    SavedLevel.FoolInfo[i].Intem[5] = (char)Szenario.Info.FoolInfo[i].Intem[5];
	    stpcpy(SavedLevel.FoolInfo[i].FoolName, Szenario.Info.FoolInfo[i].FoolName);
    }
   // Gegner sichern:
    for(i = 0; i < MAX_GEGNER; i++)
    {
	    SavedLevel.GegnerInfo[i].Gegner_ID = (short)Szenario.Info.GegnerInfo[i].Gegner_ID;
	    SavedLevel.GegnerInfo[i].Typ = (char)Szenario.Info.GegnerInfo[i].Typ;
	    SavedLevel.GegnerInfo[i].OnLive = (char)Szenario.Info.GegnerInfo[i].OnLive;
	    SavedLevel.GegnerInfo[i].Power = (char)Szenario.Info.GegnerInfo[i].Power;
	    SavedLevel.GegnerInfo[i].MaxPower = (char)Szenario.Info.GegnerInfo[i].MaxPower;
	    SavedLevel.GegnerInfo[i].Richtung = (char)Szenario.Info.GegnerInfo[i].Richtung;
    }
   // PacMan sichern:
    for(i = 0; i < MAX_PACMAN; i++)
    {
	    SavedLevel.PacManInfo[i].PacMan_ID = (char)Szenario.Info.PacManInfo[i].PacMan_ID;
	    SavedLevel.PacManInfo[i].OnLive = (char)Szenario.Info.PacManInfo[i].OnLive;
	    SavedLevel.PacManInfo[i].Power = (char)Szenario.Info.PacManInfo[i].Power;
	    SavedLevel.PacManInfo[i].MaxPower = (char)Szenario.Info.PacManInfo[i].MaxPower;
	    SavedLevel.PacManInfo[i].Richtung = (char)Szenario.Info.PacManInfo[i].Richtung;
    }
   // Die Kacheln sichern:
    for(i = 0; i < SavedLevel.KarteB*SavedLevel.KarteH; i++)
    {
	    SavedLevel.Kachel[i].Pic = (short)Szenario.Info.Kachel[i].Pic;
	    SavedLevel.Kachel[i].PicAniStep = (char)Szenario.Info.Kachel[i].PicAniStep;
	    SavedLevel.Kachel[i].PicAniStepTurn = (char)Szenario.Info.Kachel[i].PicAniStepTurn;
	    SavedLevel.Kachel[i].PicAniCircle = (char)Szenario.Info.Kachel[i].PicAniCircle;
	    SavedLevel.Kachel[i].WallPic = (short)Szenario.Info.Kachel[i].WallPic;
	    SavedLevel.Kachel[i].WallPicAniStep = (char)Szenario.Info.Kachel[i].WallPicAniStep;
	    SavedLevel.Kachel[i].WallPicAniStepTurn = (char)Szenario.Info.Kachel[i].WallPicAniStepTurn;
	    SavedLevel.Kachel[i].WallPicAniCircle = (char)Szenario.Info.Kachel[i].WallPicAniCircle;
	    SavedLevel.Kachel[i].Command = (char)Szenario.Info.Kachel[i].Command;
	    SavedLevel.Kachel[i].CommandConst = (char)Szenario.Info.Kachel[i].CommandConst;
	    SavedLevel.Kachel[i].Besetzt = (short)Szenario.Info.Kachel[i].Besetzt;
	    SavedLevel.Kachel[i].Mask = (char)Szenario.Info.Kachel[i].Mask;
	    SavedLevel.Kachel[i].Intem = (char)Szenario.Info.Kachel[i].Intem;
	    SavedLevel.Kachel[i].LeftOverlay = (char)Szenario.Info.Kachel[i].LeftOverlay;
	    SavedLevel.Kachel[i].UpOverlay = (char)Szenario.Info.Kachel[i].UpOverlay;
    }
    sprintf(temp, "Levels/%s.lev", LevelName);
    chmod(temp, S_IREAD | S_IWRITE);
    unlink(temp);
    datei = open(temp, O_WRONLY | O_CREAT | O_BINARY);
    write(datei, &SavedLevel, sizeof(SavedLevel));
    close(datei);
    sprintf(temp, " %s(%s)!", GameTexte[T_LEVEL_IS_SAVED], LevelName);
	SetBB_Message(temp, 30, -1, -1, NO_AKTIV, NO);
} /* SaveLevel */

void LoadLevel(char *LevelName)
{
    char temp[50];
    int datei, i, i2;

    sprintf(temp, "Levels/%s", LevelName);
    InitGameInfo();
    datei = open(temp, O_RDONLY |O_BINARY);
    read(datei, &SavedLevel, sizeof(SavedLevel));
    close(datei);
   // Level Dekomprimieren:
    // Die Srceen startposition Sichern:
    Szenario.Info.StartPosX = (int)SavedLevel.StartPosX;
    Szenario.Info.StartPosY = (int)SavedLevel.StartPosY;
    Szenario.Info.StartPixelPosX = (int)SavedLevel.StartPixelPosX;
    Szenario.Info.StartPixelPosY = (int)SavedLevel.StartPixelPosY;
   // Die Levelgr��e festlegen:
    Szenario.Info.KarteB = (int)SavedLevel.KarteB;
    Szenario.Info.KarteH = (int)SavedLevel.KarteH;
   // Sonstige Werte sichern:
    Szenario.Info.FoolAnzahl = (int)SavedLevel.FoolAnzahl;
    Szenario.Info.GegnerAnzahl = (int)SavedLevel.GegnerAnzahl;
    Szenario.Info.ExitAnzahl = (int)SavedLevel.ExitAnzahl;
    Szenario.Info.PacManAnzahl = (int)SavedLevel.PacManAnzahl;
    Szenario.Info.PunkteAnzahl = (int)SavedLevel.PunkteAnzahl;
    Szenario.Info.ToFinish_LiveFools = (int)SavedLevel.ToFinish_LiveFools;
    for(i = 0; i < 9; i++)
	    Szenario.Info.Commands[i] = (int)SavedLevel.Commands[i];
    Szenario.Info.LimitedTime = (int)SavedLevel.LimitedTime;
    Szenario.Info.TimeHours = (int)SavedLevel.TimeHours;
    Szenario.Info.TimeSeconds = (int)SavedLevel.TimeSeconds;
    stpcpy(Szenario.Info.LevelName, SavedLevel.LevelName);
    stpcpy(Szenario.Info.SzenarioSet, SavedLevel.SzenarioSet);
   // Die Kacheln laden:
    for(i = 0; i < SavedLevel.KarteB*SavedLevel.KarteH; i++)
    {
	    Szenario.Info.Kachel[i].Pic = (int)SavedLevel.Kachel[i].Pic;
	    Szenario.Info.Kachel[i].PicAniStep = (int)SavedLevel.Kachel[i].PicAniStep;
	    Szenario.Info.Kachel[i].PicAniStepTurn = (int)SavedLevel.Kachel[i].PicAniStepTurn;
	    Szenario.Info.Kachel[i].PicAniCircle = (int)SavedLevel.Kachel[i].PicAniCircle;
	    Szenario.Info.Kachel[i].WallPic = (int)SavedLevel.Kachel[i].WallPic;
	    Szenario.Info.Kachel[i].WallPicAniStep = (int)SavedLevel.Kachel[i].WallPicAniStep;
	    Szenario.Info.Kachel[i].WallPicAniStepTurn = (int)SavedLevel.Kachel[i].WallPicAniStepTurn;
	    Szenario.Info.Kachel[i].WallPicAniCircle = (int)SavedLevel.Kachel[i].WallPicAniCircle;
	    Szenario.Info.Kachel[i].Command = (int)SavedLevel.Kachel[i].Command;
	    Szenario.Info.Kachel[i].CommandConst = (int)SavedLevel.Kachel[i].CommandConst;
	    Szenario.Info.Kachel[i].Besetzt = (int)SavedLevel.Kachel[i].Besetzt;
	    Szenario.Info.Kachel[i].Mask = (int)SavedLevel.Kachel[i].Mask;
	    Szenario.Info.Kachel[i].Intem = (int)SavedLevel.Kachel[i].Intem;
	    Szenario.Info.Kachel[i].LeftOverlay = (int)SavedLevel.Kachel[i].LeftOverlay;
	    Szenario.Info.Kachel[i].UpOverlay = (int)SavedLevel.Kachel[i].UpOverlay;
    }
   // Fools laden:
    for(i = 0; i < MAX_FOOLS; i++)
    {
	    Szenario.Info.FoolInfo[i].Fool_ID = (int)SavedLevel.FoolInfo[i].Fool_ID;
	    Szenario.Info.FoolInfo[i].OnLive = (int)SavedLevel.FoolInfo[i].OnLive;
	    Szenario.Info.FoolInfo[i].Power = (int)SavedLevel.FoolInfo[i].Power;
	    Szenario.Info.FoolInfo[i].MaxPower = (int)SavedLevel.FoolInfo[i].MaxPower;
	    Szenario.Info.FoolInfo[i].Richtung = (int)SavedLevel.FoolInfo[i].Richtung;
	    Szenario.Info.FoolInfo[i].Befehl = (int)SavedLevel.FoolInfo[i].Befehl;
	    Szenario.Info.FoolInfo[i].Intem[0] = (int)SavedLevel.FoolInfo[i].Intem[0];
	    Szenario.Info.FoolInfo[i].Intem[1] = (int)SavedLevel.FoolInfo[i].Intem[1];
	    Szenario.Info.FoolInfo[i].Intem[2] = (int)SavedLevel.FoolInfo[i].Intem[2];
	    Szenario.Info.FoolInfo[i].Intem[3] = (int)SavedLevel.FoolInfo[i].Intem[3];
	    Szenario.Info.FoolInfo[i].Intem[4] = (int)SavedLevel.FoolInfo[i].Intem[4];
	    Szenario.Info.FoolInfo[i].Intem[5] = (int)SavedLevel.FoolInfo[i].Intem[5];
	    stpcpy(Szenario.Info.FoolInfo[i].FoolName, SavedLevel.FoolInfo[i].FoolName);
      ///////////////// Waren nicht gesichert:
	    for(i2 = 0; i2 < SavedLevel.KarteB*SavedLevel.KarteH; i2++)
	    	if(Szenario.Info.Kachel[i2].Besetzt != NO_AKTIV && Szenario.Info.Kachel[i2].Besetzt == Szenario.Info.FoolInfo[i].Fool_ID)
		    {
                Szenario.Info.FoolInfo[i].PosX = Szenario.Kachel[i2][KACHEL_POS_X];
                Szenario.Info.FoolInfo[i].PosY = Szenario.Kachel[i2][KACHEL_POS_Y];
            }
        Szenario.Info.FoolInfo[i].PixelPosX = 0;
	    Szenario.Info.FoolInfo[i].PixelPosY = 0;
	    Szenario.Info.FoolInfo[i].Animation = Szenario.Info.FoolInfo[i].Richtung;
	    Szenario.Info.FoolInfo[i].AnimationStep = 0;
	    Szenario.Info.FoolInfo[i].AnimationTurn = 0;
	    Szenario.Info.FoolInfo[i].AnimationBackTurn = 0;
	    Szenario.Info.FoolInfo[i].AnimationPlusMinus = 0;
	    Szenario.Info.FoolInfo[i].AnimationInfo = 0;
	    Szenario.Info.FoolInfo[i].LastWalk = NO;
	    Szenario.Info.FoolInfo[i].ThinkShowStep = NO_AKTIV;
    }
   // Gegner laden:
    for(i = 0; i < MAX_GEGNER; i++)
    {
	    Szenario.Info.GegnerInfo[i].Typ = (int)SavedLevel.GegnerInfo[i].Typ;
	    Szenario.Info.GegnerInfo[i].Gegner_ID = (int)SavedLevel.GegnerInfo[i].Gegner_ID;
	    Szenario.Info.GegnerInfo[i].OnLive = (int)SavedLevel.GegnerInfo[i].OnLive;
	    Szenario.Info.GegnerInfo[i].Power = (int)SavedLevel.GegnerInfo[i].Power;
	    Szenario.Info.GegnerInfo[i].MaxPower = (int)SavedLevel.GegnerInfo[i].MaxPower;
	    Szenario.Info.GegnerInfo[i].Richtung = (int)SavedLevel.GegnerInfo[i].Richtung;
      ///////////////// Waren nicht gesichert:
	    for(i2 = 0; i2 < SavedLevel.KarteB*SavedLevel.KarteH; i2++)
	    	if(Szenario.Info.Kachel[i2].Besetzt != NO_AKTIV && Szenario.Info.Kachel[i2].Besetzt == Szenario.Info.GegnerInfo[i].Gegner_ID+MAX_FOOLS)
		    {
                Szenario.Info.GegnerInfo[i].PosX = Szenario.Kachel[i2][KACHEL_POS_X];
                Szenario.Info.GegnerInfo[i].PosY = Szenario.Kachel[i2][KACHEL_POS_Y];
            }
	    Szenario.Info.GegnerInfo[i].PixelPosX = 0;
	    Szenario.Info.GegnerInfo[i].PixelPosY = 0;
	    Szenario.Info.GegnerInfo[i].Animation = NO_AKTIV;
	    Szenario.Info.GegnerInfo[i].AnimationStep = 0;
	    Szenario.Info.GegnerInfo[i].AnimationTurn = 0;
	    Szenario.Info.GegnerInfo[i].LastWalk = 0;
    }
   // PacMan laden:
    for(i = 0; i < MAX_PACMAN; i++)
    {
	    Szenario.Info.PacManInfo[i].PacMan_ID = (int)SavedLevel.PacManInfo[i].PacMan_ID;
	    Szenario.Info.PacManInfo[i].OnLive = (int)SavedLevel.PacManInfo[i].OnLive;
	    Szenario.Info.PacManInfo[i].Power = (int)SavedLevel.PacManInfo[i].Power;
	    Szenario.Info.PacManInfo[i].MaxPower = (int)SavedLevel.PacManInfo[i].MaxPower;
	    Szenario.Info.PacManInfo[i].Richtung = (int)SavedLevel.PacManInfo[i].Richtung;
      ///////////////// Waren nicht gesichert:
	    for(i2 = 0; i2 < SavedLevel.KarteB*SavedLevel.KarteH; i2++)
	    	if(Szenario.Info.Kachel[i2].Besetzt != NO_AKTIV && Szenario.Info.Kachel[i2].Besetzt == Szenario.Info.PacManInfo[i].PacMan_ID+FIRST_PACMAN)
		    {
                Szenario.Info.PacManInfo[i].PosX = Szenario.Kachel[i2][KACHEL_POS_X];
                Szenario.Info.PacManInfo[i].PosY = Szenario.Kachel[i2][KACHEL_POS_Y];
            }
	    Szenario.Info.PacManInfo[i].PixelPosX = 0;
	    Szenario.Info.PacManInfo[i].PixelPosY = 0;
	    Szenario.Info.PacManInfo[i].Richtung = (int)SavedLevel.PacManInfo[i].Richtung;
	    Szenario.Info.PacManInfo[i].Animation = Szenario.Info.PacManInfo[i].Richtung;
	    Szenario.Info.PacManInfo[i].AnimationStep = 0;
	    Szenario.Info.PacManInfo[i].AnimationTurn = 0;
	    Szenario.Info.PacManInfo[i].LastWalk = 0;
    }
   // Werte aktualisieren:
	GameInfo.LiveFools = Szenario.Info.FoolAnzahl;
	GameInfo.DeadFools = 0;
	GameInfo.FinishFools = 0;
	GameInfo.ScreenPosX = Szenario.Info.StartPosX;
    GameInfo.ScreenPosY = Szenario.Info.StartPosY;
	GameInfo.ScreenPixelPosX = Szenario.Info.StartPixelPosX;
    GameInfo.ScreenPixelPosY = Szenario.Info.StartPixelPosY;
    for(i = 0; i < 9; i++)
	    GameCommandMenu[i].Anzahl = Szenario.Info.Commands[i];
    GameInfo.TimeHours = Szenario.Info.TimeHours;
    GameInfo.TimeMin = Szenario.Info.TimeMinutes;
    GameInfo.TimeSec = Szenario.Info.TimeSeconds;
    GameInfo.LimitedTime = Szenario.Info.LimitedTime;
    if(GameInfo.LimitedTime == USER)
	    GameInfo.LimitedTime = NO;
	if(GameInfo.LimitedTime == YES)
    {
        GameInfo.PlayedTimeHours = Szenario.Info.TimeHours;
        GameInfo.PlayedTimeMin = Szenario.Info.TimeMinutes;
        GameInfo.PlayedTimeSec = Szenario.Info.TimeSeconds;
    }
	if(GameInfo.LimitedTime == NO)
    {
        GameInfo.TimeHours = 0;
        GameInfo.TimeMin = 0;
        GameInfo.TimeSec = 0;
    }
    stpcpy(GameInfo.AktuellesLevel, Szenario.Info.LevelName);
} /* LoadLevel */
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

void CheckBeamer(int Kachel)
{
	int i, Beamer;

    if(Szenario.Info.Kachel[Kachel].Mask != BEAMER)
        return;
    Beamer = Szenario.Info.Kachel[Kachel].BEAMER_NR_1;
    for(i = 0; i < 2; i++)
    {
        if(Beamer != NO_AKTIV && Szenario.Info.Kachel[Beamer].Besetzt == NO_AKTIV)
        {
            if(Szenario.Info.Kachel[Kachel].Besetzt != NO_AKTIV &&
                Szenario.Info.Kachel[Kachel].Besetzt < MAX_FOOLS &&
                Szenario.Info.FoolInfo[Szenario.Info.Kachel[Kachel].Besetzt].PixelPosX == 0 &&
                Szenario.Info.FoolInfo[Szenario.Info.Kachel[Kachel].Besetzt].PixelPosY == 0)
            { // Ein Fool steht Beam bereit:
                if(Szenario.Info.FoolInfo[Szenario.Info.Kachel[Kachel].Besetzt].Animation != BEAMING_START &&
                    Szenario.Info.FoolInfo[Szenario.Info.Kachel[Kachel].Besetzt].Animation != BEAMING_START_END &&
                    Szenario.Info.FoolInfo[Szenario.Info.Kachel[Kachel].Besetzt].Animation != BEAMING_END)
                { // F�ngt an, zu Beamen:
                    Szenario.Info.FoolInfo[Szenario.Info.Kachel[Kachel].Besetzt].Animation = BEAMING_START;
                    Szenario.Info.FoolInfo[Szenario.Info.Kachel[Kachel].Besetzt].AnimationStep = 0;
                    continue;
                }
                if(Szenario.Info.FoolInfo[Szenario.Info.Kachel[Kachel].Besetzt].Animation == BEAMING_START_END)
                {  // Hat sich aufgel�st, und wird nun an seine neue Stelle gebracht:
                    Szenario.Info.Kachel[Beamer].Besetzt = Szenario.Info.Kachel[Kachel].Besetzt;
                    Szenario.Info.Kachel[Kachel].Besetzt = NO_AKTIV;
                    Szenario.Info.FoolInfo[Szenario.Info.Kachel[Beamer].Besetzt].PosX = Szenario.Kachel[Beamer][KACHEL_POS_X];
                    Szenario.Info.FoolInfo[Szenario.Info.Kachel[Beamer].Besetzt].PosY = Szenario.Kachel[Beamer][KACHEL_POS_Y];
                    switch(Szenario.Info.FoolInfo[Szenario.Info.Kachel[Beamer].Besetzt].Richtung)
                    {
                        case 0: Szenario.Info.FoolInfo[Szenario.Info.Kachel[Beamer].Besetzt].PixelPosX--; break;
                        case 1: Szenario.Info.FoolInfo[Szenario.Info.Kachel[Beamer].Besetzt].PixelPosY--; break;
                        case 2: Szenario.Info.FoolInfo[Szenario.Info.Kachel[Beamer].Besetzt].PixelPosX++; break;
                        case 3: Szenario.Info.FoolInfo[Szenario.Info.Kachel[Beamer].Besetzt].PixelPosY++; break;
                    }
                }
            }
            if(Szenario.Info.Kachel[Kachel].Besetzt != NO_AKTIV &&
                Szenario.Info.Kachel[Kachel].Besetzt > MAX_FOOLS &&
                Szenario.Info.GegnerInfo[Szenario.Info.Kachel[Kachel].Besetzt].PixelPosX == 0 &&
                Szenario.Info.GegnerInfo[Szenario.Info.Kachel[Kachel].Besetzt].PixelPosY == 0)
            { // Ein Fool steht Beam bereit:
                Szenario.Info.Kachel[Beamer].Besetzt = Szenario.Info.Kachel[Kachel].Besetzt;
                Szenario.Info.Kachel[Kachel].Besetzt = NO_AKTIV;
                Szenario.Info.GegnerInfo[Szenario.Info.Kachel[Beamer].Besetzt].PosX = Szenario.Kachel[Beamer][KACHEL_POS_X];
                Szenario.Info.GegnerInfo[Szenario.Info.Kachel[Beamer].Besetzt].PosY = Szenario.Kachel[Beamer][KACHEL_POS_Y];
            }
        }
        Beamer = Szenario.Info.Kachel[Kachel].BEAMER_NR_2;
    }
} /* CheckBeamer */

// Game Liste Ein/Ausfahren
void GameListeOnOff(void)
{
    if(ProgrammSetup.ShowGameListe == YES)
    {
		if(CheckMouseRect(GameListeX-20, GameListeY+440, GameListeX-5, GameListeY+455) != NO_AKTIV)
		{
        	ProgrammSetup.ShowGameListe = NO;
    		return;
        }
    }
    else
    {
		if(CheckMouseRect(GameListeX+100, GameListeY+440, GameListeX+115, GameListeX+455) != NO_AKTIV)
		{
        	ProgrammSetup.ShowGameListe = YES;
    		return;
        }
    }
} /* GameListeOnOff */

int CheckMouseRichtung(void)
{
    if(Mouse.LastXPos != NO_AKTIV)
    {
        if(Mouse.LastXPos-COMMAND_PIXEL_TURN > Mouse.XPos)
			return 0;
        if(Mouse.LastYPos-COMMAND_PIXEL_TURN > Mouse.YPos)
			return 1;
        if(Mouse.LastXPos+COMMAND_PIXEL_TURN < Mouse.XPos)
			return 2;
        if(Mouse.LastYPos+COMMAND_PIXEL_TURN < Mouse.YPos)
			return 3;
    }
	return NO_AKTIV;
} /* CheckMouseRichtung */

void DrawBuiltMenu(void);
void CheckBuiltMenu(int);
void CheckEditorSetFoolIntem(int, int);

void DrawTaxiKachelInfo(void);
void CheckTaxiKachelInfo(void);

void DrawBeamerKachelInfo(void);
void CheckBeamerKachelInfo(void);

void DrawBuiltMenu(void)
{
    RECT rcRect;
	int i;
    char temp[50];

    if(GameInfo.GameListe.BuiltDown == YES)
	{
        SetRect(&rcRect, 1, 1, 34, 34);
        Back->BltFast(GameInfo.GameListe.BuiltMenu.DeleteButtonX, GameInfo.GameListe.BuiltMenu.DeleteButtonY, CommandMenuAniPic, &rcRect, FALSE);
        if(GameInfo.Befehl == COMMAND_DELETE)
            DrawRect(GameInfo.GameListe.BuiltMenu.DeleteButtonX-1, GameInfo.GameListe.BuiltMenu.DeleteButtonY-1, 34, 34, 15, Back);
        sprintf(temp, "%d", GameInfo.SelectedFool);
        PrintText(0, 200, temp, 1, 0, 1000, 1000, Back);
        if(GameInfo.SelectedKachel == NO_AKTIV)
        {
            i = GameInfo.SelectedFool;
            if(i != NO_AKTIV && i < MAX_FOOLS && Szenario.Info.FoolInfo[i].Fool_ID != NO_AKTIV)
            {
                if(Szenario.Info.FoolInfo[i].OnLive == YES)
                {
                    if(GameInfo.SelectedFool == i)
                    {
                        rcRect.left   = 0;
                        rcRect.top    = 1+GameInfo.SelectedFoolAni*51;
                        rcRect.right  = 59;
                        rcRect.bottom = 1+GameInfo.SelectedFoolAni*51+50;
                        Back->BltFast(GameInfo.GameListe.BuiltMenu.SelectFoolButtonX-12, GameInfo.GameListe.BuiltMenu.SelectFoolButtonY+22, FoolSelectedPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
                    }
                    DrawAnimatedFool(i, GameInfo.GameListe.BuiltMenu.SelectFoolButtonX, GameInfo.GameListe.BuiltMenu.SelectFoolButtonY, Back, YES);
                }
                if(Szenario.Info.FoolInfo[i].OnLive == NO)
                {
                    rcRect.left   = 1+(Szenario.Info.FoolInfo[i].AnimationStep*52);
                    rcRect.top    = 2481;
                    rcRect.right  = 1+(Szenario.Info.FoolInfo[i].AnimationStep*52)+50;
                    rcRect.bottom = 2552;
                    Back->BltFast(GameInfo.GameListe.BuiltMenu.SelectFoolButtonX, GameInfo.GameListe.BuiltMenu.SelectFoolButtonY, FoolAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
                }
                if(Szenario.Info.FoolInfo[i].OnLive == FINISH)
                {
                    rcRect.left   = 1+(Szenario.Info.FoolInfo[i].AnimationStep*52);
                    rcRect.top    = 2553;
                    rcRect.right  = 1+(Szenario.Info.FoolInfo[i].AnimationStep*52)+50;
                    rcRect.bottom = 2624;
                    Back->BltFast(GameInfo.GameListe.BuiltMenu.SelectFoolButtonX, GameInfo.GameListe.BuiltMenu.SelectFoolButtonY, FoolAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
                }
               //  Name des Fools:
                PrintText(GameInfo.GameListe.BuiltMenu.FoolNameButtonX, GameInfo.GameListe.BuiltMenu.FoolNameButtonY, Szenario.Info.FoolInfo[GameInfo.SelectedFool].FoolName, 1, 0, 1000, 1000, Back);
               // Noch vorhandene Energie der Fools:
                SetRect(&rcRect, Szenario.Info.FoolInfo[i].Power, 915, FULL_POWER, 930);
                Back->BltFast(GameInfo.GameListe.BuiltMenu.PowerFoolButtonX+Szenario.Info.FoolInfo[i].Power, GameInfo.GameListe.BuiltMenu.PowerFoolButtonY, GameListPic, &rcRect, FALSE);
                SetRect(&rcRect, 1, 772, Szenario.Info.FoolInfo[i].Power, 787);
                Back->BltFast(GameInfo.GameListe.BuiltMenu.PowerFoolButtonX, GameInfo.GameListe.BuiltMenu.PowerFoolButtonY, GameListPic, &rcRect, FALSE);
                sprintf(temp, "%d", Szenario.Info.FoolInfo[i].Power);
                PrintText(GameInfo.GameListe.BuiltMenu.PowerFoolButtonX+20, GameInfo.GameListe.BuiltMenu.PowerFoolButtonY+2, temp, 1, 0, 1000, 1000, Back);
               // Das Fool Inventar:
                SetRect(&rcRect, 1, 735, 44, 770);
                Back->BltFast(GameInfo.GameListe.BuiltMenu.Intem1ButtonX, GameInfo.GameListe.BuiltMenu.Intem1ButtonY, GameListPic, &rcRect, FALSE);
                Back->BltFast(GameInfo.GameListe.BuiltMenu.Intem2ButtonX, GameInfo.GameListe.BuiltMenu.Intem2ButtonY, GameListPic, &rcRect, FALSE);
                Back->BltFast(GameInfo.GameListe.BuiltMenu.Intem3ButtonX, GameInfo.GameListe.BuiltMenu.Intem3ButtonY, GameListPic, &rcRect, FALSE);
                Back->BltFast(GameInfo.GameListe.BuiltMenu.Intem4ButtonX, GameInfo.GameListe.BuiltMenu.Intem4ButtonY, GameListPic, &rcRect, FALSE);
                Back->BltFast(GameInfo.GameListe.BuiltMenu.Intem5ButtonX, GameInfo.GameListe.BuiltMenu.Intem5ButtonY, GameListPic, &rcRect, FALSE);
                Back->BltFast(GameInfo.GameListe.BuiltMenu.Intem6ButtonX, GameInfo.GameListe.BuiltMenu.Intem6ButtonY, GameListPic, &rcRect, FALSE);
                //////////////////////////////////////////////////////////////////////////
                // Setzt nun die Gegenst�nde ein:
                //////////////////////////////////////////////////////////////////////////
                if(Szenario.Info.FoolInfo[i].Intem[0] != NO_AKTIV)
                {
					DrawKachelIntemPic(Szenario.Info.FoolInfo[i].Intem[0], GameInfo.GameListe.BuiltMenu.Intem1ButtonX, GameInfo.GameListe.BuiltMenu.Intem1ButtonY, Back);
                    PrintText(GameInfo.GameListe.BuiltMenu.Intem1ButtonX, GameInfo.GameListe.BuiltMenu.Intem1ButtonY, "1", 1, 0, 1000, 1000, Back);
                }
                if(Szenario.Info.FoolInfo[i].Intem[1] != NO_AKTIV)
                {
					DrawKachelIntemPic(Szenario.Info.FoolInfo[i].Intem[1], GameInfo.GameListe.BuiltMenu.Intem2ButtonX, GameInfo.GameListe.BuiltMenu.Intem2ButtonY, Back);
                    PrintText(GameInfo.GameListe.BuiltMenu.Intem2ButtonX, GameInfo.GameListe.BuiltMenu.Intem2ButtonY, "2", 1, 0, 1000, 1000, Back);
                }
                if(Szenario.Info.FoolInfo[i].Intem[2] != NO_AKTIV)
                {
					DrawKachelIntemPic(Szenario.Info.FoolInfo[i].Intem[2], GameInfo.GameListe.BuiltMenu.Intem3ButtonX, GameInfo.GameListe.BuiltMenu.Intem3ButtonY, Back);
                    PrintText(GameInfo.GameListe.BuiltMenu.Intem3ButtonX, GameInfo.GameListe.BuiltMenu.Intem3ButtonY, "3", 1, 0, 1000, 1000, Back);
                }
                if(Szenario.Info.FoolInfo[i].Intem[3] != NO_AKTIV)
                {
					DrawKachelIntemPic(Szenario.Info.FoolInfo[i].Intem[3], GameInfo.GameListe.BuiltMenu.Intem4ButtonX, GameInfo.GameListe.BuiltMenu.Intem4ButtonY, Back);
                    PrintText(GameInfo.GameListe.BuiltMenu.Intem4ButtonX, GameInfo.GameListe.BuiltMenu.Intem4ButtonY, "4", 1, 0, 1000, 1000, Back);
                }
                if(Szenario.Info.FoolInfo[i].Intem[4] != NO_AKTIV)
                {
					DrawKachelIntemPic(Szenario.Info.FoolInfo[i].Intem[4], GameInfo.GameListe.BuiltMenu.Intem5ButtonX, GameInfo.GameListe.BuiltMenu.Intem5ButtonY, Back);
                    PrintText(GameInfo.GameListe.BuiltMenu.Intem5ButtonX, GameInfo.GameListe.BuiltMenu.Intem5ButtonY, "5", 1, 0, 1000, 1000, Back);
                }
                if(Szenario.Info.FoolInfo[i].Intem[5] != NO_AKTIV)
                {
					DrawKachelIntemPic(Szenario.Info.FoolInfo[i].Intem[5], GameInfo.GameListe.BuiltMenu.Intem6ButtonX, GameInfo.GameListe.BuiltMenu.Intem6ButtonY, Back);
                    PrintText(GameInfo.GameListe.BuiltMenu.Intem6ButtonX, GameInfo.GameListe.BuiltMenu.Intem6ButtonY, "6", 1, 0, 1000, 1000, Back);
                }
                sprintf(temp, "X:%d Y:%d", Szenario.Info.FoolInfo[GameInfo.SelectedFool].PosX, Szenario.Info.FoolInfo[GameInfo.SelectedFool].PosY);
                PrintText(GameListeX+5, GameListeY+410, temp, 1, 0, Font[1].MaxXZeichen, Font[1].MaxYZeichen, Back);
                sprintf(temp, "K:%d", Szenario.PosInfo[Szenario.Info.FoolInfo[GameInfo.SelectedFool].PosX][Szenario.Info.FoolInfo[GameInfo.SelectedFool].PosY]);
                PrintText(GameListeX+5, GameListeY+425, temp, 1, 0, Font[1].MaxXZeichen, Font[1].MaxYZeichen, Back);
                sprintf(temp, "pX:%d  pY:%d", Szenario.Info.FoolInfo[GameInfo.SelectedFool].PixelPosX, Szenario.Info.FoolInfo[GameInfo.SelectedFool].PixelPosY);
                PrintText(GameListeX+5, GameListeY+440, temp, 1, 0, Font[1].MaxXZeichen, Font[1].MaxYZeichen, Back);
                sprintf(temp, "B:%d A:%d", Szenario.Info.FoolInfo[GameInfo.SelectedFool].Befehl, Szenario.Info.FoolInfo[GameInfo.SelectedFool].Animation);
                PrintText(GameListeX+5, GameListeY+455, temp, 1, 0, Font[1].MaxXZeichen, Font[1].MaxYZeichen, Back);
            }
            if(i != NO_AKTIV && i > MAX_FOOLS-1 && i < MAX_FOOLS+MAX_GEGNER)
            {
                i -= MAX_FOOLS;
                if(Szenario.Info.GegnerInfo[i].Gegner_ID != NO_AKTIV)
                {
                    if(Szenario.Info.GegnerInfo[i].OnLive == YES)
                    {
                        if(GameInfo.SelectedFool == i+MAX_FOOLS)
                        {
                            rcRect.left   = 0;
                            rcRect.top    = 1+GameInfo.SelectedFoolAni*51;
                            rcRect.right  = 59;
                            rcRect.bottom = 1+GameInfo.SelectedFoolAni*51+50;
                            Back->BltFast(GameInfo.GameListe.BuiltMenu.SelectFoolButtonX-12, GameInfo.GameListe.BuiltMenu.SelectFoolButtonY+22, FoolSelectedPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
                        }
                        DrawAnimatedGegner(i, GameInfo.GameListe.BuiltMenu.SelectFoolButtonX+10, GameInfo.GameListe.BuiltMenu.SelectFoolButtonY+20, Back);
                    }
                    if(Szenario.Info.GegnerInfo[i].OnLive == NO)
                    {
                        rcRect.left   = 1+(Szenario.Info.GegnerInfo[i].AnimationStep*52);
                        rcRect.top    = 2481;
                        rcRect.right  = 1+(Szenario.Info.GegnerInfo[i].AnimationStep*52)+50;
                        rcRect.bottom = 2552;
                        Back->BltFast(GameInfo.GameListe.BuiltMenu.SelectFoolButtonX, GameInfo.GameListe.BuiltMenu.SelectFoolButtonY, FoolAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
                    }
                    if(Szenario.Info.GegnerInfo[i].OnLive == FINISH)
                    {
                        rcRect.left   = 1+(Szenario.Info.GegnerInfo[i].AnimationStep*52);
                        rcRect.top    = 2553;
                        rcRect.right  = 1+(Szenario.Info.GegnerInfo[i].AnimationStep*52)+50;
                        rcRect.bottom = 2624;
                        Back->BltFast(GameInfo.GameListe.BuiltMenu.SelectFoolButtonX, GameInfo.GameListe.BuiltMenu.SelectFoolButtonY, FoolAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
                    }
                   //  Name des Fools:
    //                PrintText(GameInfo.GameListe.BuiltMenu.FoolNameButtonX, GameInfo.GameListe.BuiltMenu.FoolNameButtonY, Szenario.Info.GegnerInfo[GameInfo.SelectedFool].GegnerName, 1, 0, 1000, 1000, Back);
                   // Noch vorhandene Energie der Fools:
                    SetRect(&rcRect, Szenario.Info.GegnerInfo[i].Power, 915, FULL_POWER, 930);
                    Back->BltFast(GameInfo.GameListe.BuiltMenu.PowerFoolButtonX+Szenario.Info.GegnerInfo[i].Power, GameInfo.GameListe.BuiltMenu.PowerFoolButtonY, GameListPic, &rcRect, FALSE);
                    SetRect(&rcRect, 1, 772, Szenario.Info.GegnerInfo[i].Power, 787);
                    Back->BltFast(GameInfo.GameListe.BuiltMenu.PowerFoolButtonX, GameInfo.GameListe.BuiltMenu.PowerFoolButtonY, GameListPic, &rcRect, FALSE);
                    sprintf(temp, "%d", Szenario.Info.GegnerInfo[i].Power);
                    PrintText(GameInfo.GameListe.BuiltMenu.PowerFoolButtonX+20, GameInfo.GameListe.BuiltMenu.PowerFoolButtonY+2, temp, 1, 0, 1000, 1000, Back);

                    sprintf(temp, "X:%d Y:%d", Szenario.Info.GegnerInfo[i].PosX, Szenario.Info.GegnerInfo[i].PosY);
                    PrintText(GameListeX+5, GameListeY+410, temp, 1, 0, Font[1].MaxXZeichen, Font[1].MaxYZeichen, Back);
                    sprintf(temp, "K:%d", Szenario.PosInfo[Szenario.Info.GegnerInfo[i].PosX][Szenario.Info.GegnerInfo[i].PosY]);
                    PrintText(GameListeX+5, GameListeY+425, temp, 1, 0, Font[1].MaxXZeichen, Font[1].MaxYZeichen, Back);
                    sprintf(temp, "pX:%d  pY:%d", Szenario.Info.GegnerInfo[i].PixelPosX, Szenario.Info.GegnerInfo[i].PixelPosY);
                    PrintText(GameListeX+5, GameListeY+440, temp, 1, 0, Font[1].MaxXZeichen, Font[1].MaxYZeichen, Back);
				}
            }
            if(i != NO_AKTIV && i > FIRST_PACMAN-1 && i < FIRST_PACMAN+MAX_PACMAN)
            {
                i -= FIRST_PACMAN;
                if(Szenario.Info.PacManInfo[i].PacMan_ID != NO_AKTIV)
                {
                    if(Szenario.Info.PacManInfo[i].OnLive == YES)
                    {
                        if(GameInfo.SelectedFool == i+FIRST_PACMAN)
                        {
                            rcRect.left   = 0;
                            rcRect.top    = 1+GameInfo.SelectedFoolAni*51;
                            rcRect.right  = 59;
                            rcRect.bottom = 1+GameInfo.SelectedFoolAni*51+50;
                            Back->BltFast(GameInfo.GameListe.BuiltMenu.SelectFoolButtonX-12, GameInfo.GameListe.BuiltMenu.SelectFoolButtonY+22, FoolSelectedPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
                        }
                        DrawAnimatedPacMan(i, GameInfo.GameListe.BuiltMenu.SelectFoolButtonX, GameInfo.GameListe.BuiltMenu.SelectFoolButtonY, Back);
                    }
                    if(Szenario.Info.PacManInfo[i].OnLive == NO)
                    {
                        rcRect.left   = 1+(Szenario.Info.PacManInfo[i].AnimationStep*52);
                        rcRect.top    = 2481;
                        rcRect.right  = 1+(Szenario.Info.PacManInfo[i].AnimationStep*52)+50;
                        rcRect.bottom = 2552;
                        Back->BltFast(GameInfo.GameListe.BuiltMenu.SelectFoolButtonX, GameInfo.GameListe.BuiltMenu.SelectFoolButtonY, FoolAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
                    }
                    if(Szenario.Info.PacManInfo[i].OnLive == FINISH)
                    {
                        rcRect.left   = 1+(Szenario.Info.PacManInfo[i].AnimationStep*52);
                        rcRect.top    = 2553;
                        rcRect.right  = 1+(Szenario.Info.PacManInfo[i].AnimationStep*52)+50;
                        rcRect.bottom = 2624;
                        Back->BltFast(GameInfo.GameListe.BuiltMenu.SelectFoolButtonX, GameInfo.GameListe.BuiltMenu.SelectFoolButtonY, FoolAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
                    }
                   //  Name des Fools:
                    PrintText(GameInfo.GameListe.BuiltMenu.FoolNameButtonX, GameInfo.GameListe.BuiltMenu.FoolNameButtonY, Szenario.Info.PacManInfo[GameInfo.SelectedFool].PacManName, 1, 0, 1000, 1000, Back);
                   // Noch vorhandene Energie der Fools:
                    SetRect(&rcRect, Szenario.Info.PacManInfo[i].Power, 915, FULL_POWER, 930);
                    Back->BltFast(GameInfo.GameListe.BuiltMenu.PowerFoolButtonX+Szenario.Info.PacManInfo[i].Power, GameInfo.GameListe.BuiltMenu.PowerFoolButtonY, GameListPic, &rcRect, FALSE);
                    SetRect(&rcRect, 1, 772, Szenario.Info.PacManInfo[i].Power, 787);
                    Back->BltFast(GameInfo.GameListe.BuiltMenu.PowerFoolButtonX, GameInfo.GameListe.BuiltMenu.PowerFoolButtonY, GameListPic, &rcRect, FALSE);
                    sprintf(temp, "%d", Szenario.Info.PacManInfo[i].Power);
                    PrintText(GameInfo.GameListe.BuiltMenu.PowerFoolButtonX+20, GameInfo.GameListe.BuiltMenu.PowerFoolButtonY+2, temp, 1, 0, 1000, 1000, Back);

                    sprintf(temp, "X:%d Y:%d", Szenario.Info.PacManInfo[i].PosX, Szenario.Info.PacManInfo[i].PosY);
                    PrintText(GameListeX+5, GameListeY+410, temp, 1, 0, Font[1].MaxXZeichen, Font[1].MaxYZeichen, Back);
                    sprintf(temp, "K:%d", Szenario.PosInfo[Szenario.Info.PacManInfo[i].PosX][Szenario.Info.PacManInfo[i].PosY]);
                    PrintText(GameListeX+5, GameListeY+425, temp, 1, 0, Font[1].MaxXZeichen, Font[1].MaxYZeichen, Back);
                    sprintf(temp, "pX:%d  pY:%d", Szenario.Info.PacManInfo[i].PixelPosX, Szenario.Info.PacManInfo[i].PixelPosY);
                    PrintText(GameListeX+5, GameListeY+440, temp, 1, 0, Font[1].MaxXZeichen, Font[1].MaxYZeichen, Back);
				}
            }
	      	if(GiveFoolANewName == YES)
            {
	            DrawRect(GameInfo.GameListe.BuiltMenu.FoolNameButtonX-1, GameInfo.GameListe.BuiltMenu.FoolNameButtonY-1, 60, 20, 15, Back);
            }
        }
        else
        {
            DrawKachelFloorPic(GameInfo.SelectedKachel, GameInfo.GameListe.BuiltMenu.SelectKachelFloorButtonX, GameInfo.GameListe.BuiltMenu.SelectKachelFloorButtonY, Back);
            DrawKachelWallPic(GameInfo.SelectedKachel, GameInfo.GameListe.BuiltMenu.SelectKachelWallButtonX, GameInfo.GameListe.BuiltMenu.SelectKachelWallButtonY, Back, 0);
			DrawKachelMasksPic(Szenario.Info.Kachel[GameInfo.SelectedKachel].Mask, GameInfo.GameListe.BuiltMenu.SelectKachelMaskButtonX, GameInfo.GameListe.BuiltMenu.SelectKachelMaskButtonY, Back);
			DrawKachelIntemPic(Szenario.Info.Kachel[GameInfo.SelectedKachel].Intem, GameInfo.GameListe.BuiltMenu.SelectKachelIntemButtonX, GameInfo.GameListe.BuiltMenu.SelectKachelIntemButtonY, Back);
			DrawCommand(GameInfo.SelectedKachel, GameInfo.GameListe.BuiltMenu.SelectKachelCommandButtonX, GameInfo.GameListe.BuiltMenu.SelectKachelCommandButtonY, NO, Back);
            if(GameInfo.GameListe.BuiltMenu.SelectKachelFloorLeftButtonDown)
                DrawRect(GameInfo.GameListe.BuiltMenu.SelectKachelFloorLeftButtonX, GameInfo.GameListe.BuiltMenu.SelectKachelFloorLeftButtonY, 6, KACHEL_H, 15, Back);
            if(GameInfo.GameListe.BuiltMenu.SelectKachelFloorUpButtonDown)
                DrawRect(GameInfo.GameListe.BuiltMenu.SelectKachelFloorUpButtonX, GameInfo.GameListe.BuiltMenu.SelectKachelFloorUpButtonY, KACHEL_B+6, 6, 15, Back);
            if(GameInfo.GameListe.BuiltMenu.SelectKachelFloorLeftButtonDown == YES)
            {
                SetRect(&rcRect, Szenario.Info.Kachel[GameInfo.SelectedKachel].LeftOverlay, 885, 100, 900);
                Back->BltFast(GameInfo.GameListe.BuiltMenu.AnzahlButtonX+Szenario.Info.Kachel[GameInfo.SelectedKachel].LeftOverlay, GameInfo.GameListe.BuiltMenu.AnzahlButtonY, GameListPic, &rcRect, FALSE);
                SetRect(&rcRect, 0, 900, Szenario.Info.Kachel[GameInfo.SelectedKachel].LeftOverlay, 915);
                Back->BltFast(GameInfo.GameListe.BuiltMenu.AnzahlButtonX, GameInfo.GameListe.BuiltMenu.AnzahlButtonY, GameListPic, &rcRect, FALSE);
                sprintf(temp, "%d", Szenario.Info.Kachel[GameInfo.SelectedKachel].LeftOverlay);
                PrintText(GameInfo.GameListe.BuiltMenu.AnzahlButtonX+30, GameInfo.GameListe.BuiltMenu.AnzahlButtonY+3, temp, 1, 0, 1000, 1000, Back);
            }
            if(GameInfo.GameListe.BuiltMenu.SelectKachelFloorUpButtonDown == YES)
            {
                SetRect(&rcRect, Szenario.Info.Kachel[GameInfo.SelectedKachel].UpOverlay, 885, 100, 900);
                Back->BltFast(GameInfo.GameListe.BuiltMenu.AnzahlButtonX+Szenario.Info.Kachel[GameInfo.SelectedKachel].UpOverlay, GameInfo.GameListe.BuiltMenu.AnzahlButtonY, GameListPic, &rcRect, FALSE);
                SetRect(&rcRect, 0, 900, Szenario.Info.Kachel[GameInfo.SelectedKachel].UpOverlay, 915);
                Back->BltFast(GameInfo.GameListe.BuiltMenu.AnzahlButtonX, GameInfo.GameListe.BuiltMenu.AnzahlButtonY, GameListPic, &rcRect, FALSE);
                sprintf(temp, "%d", Szenario.Info.Kachel[GameInfo.SelectedKachel].UpOverlay);
                PrintText(GameInfo.GameListe.BuiltMenu.AnzahlButtonX+30, GameInfo.GameListe.BuiltMenu.AnzahlButtonY+3, temp, 1, 0, 1000, 1000, Back);
            }
            sprintf(temp, "x:%d y:%d", Szenario.Kachel[GameInfo.SelectedKachel][KACHEL_PIXEL_X], Szenario.Kachel[GameInfo.SelectedKachel][KACHEL_PIXEL_Y]);
            PrintText(530, 400, temp, 1, 0, 1000, 1000, Back);
            DrawTaxiKachelInfo();
            DrawBeamerKachelInfo();
       }
       SetRect(&rcRect, 1, 625, 22, 646);
	}
    else
        SetRect(&rcRect, 1, 603, 22, 624);
    Back->BltFast(GameInfo.GameListe.BuiltX, GameInfo.GameListe.BuiltY, GameListPic, &rcRect, FALSE);
} /* DrawBuiltMenu*/
///////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////
void CheckBuiltMenu(int Module)
{
    if(GameInfo.GameListe.BuiltDown == YES)
    {
        int i, x, y;

        if(CheckMouseRect(GameInfo.GameListe.BuiltMenu.DeleteButtonX, GameInfo.GameListe.BuiltMenu.DeleteButtonY,
           GameInfo.GameListe.BuiltMenu.DeleteButtonX+KACHEL_B+KACHEL_OVERLAY, GameInfo.GameListe.BuiltMenu.DeleteButtonY+KACHEL_H+KACHEL_OVERLAY) != NO_AKTIV)
        {
   		    if(Mouse.Button == LEFT_MOUSE_BUTTON)
	            GameInfo.Befehl = COMMAND_DELETE;
        }
        if(CheckMouseRect(GameInfo.GameListe.BuiltMenu.FoolNameButtonX, GameInfo.GameListe.BuiltMenu.FoolNameButtonY,
           GameInfo.GameListe.BuiltMenu.FoolNameButtonX+100, GameInfo.GameListe.BuiltMenu.FoolNameButtonY+20) != NO_AKTIV)
        {
   		    if(Mouse.Button == LEFT_MOUSE_BUTTON)
	        {
            	GiveFoolANewName = YES;
            	Eingabe(Szenario.Info.FoolInfo[GameInfo.SelectedFool].FoolName, 256, strlen(Szenario.Info.FoolInfo[GameInfo.SelectedFool].FoolName));
            }
        }
      	if(GiveFoolANewName == YES)
        {
           	if(Eingabe(Szenario.Info.FoolInfo[GameInfo.SelectedFool].FoolName, 256, NO_AKTIV) == YES)
            	GiveFoolANewName = NO;
        }
        if(GameInfo.SelectedKachel == NO_AKTIV)
        {
			GameInfo.GameListe.BuiltMenu.Taxi1ButtonDown = NO;
			GameInfo.GameListe.BuiltMenu.Taxi2ButtonDown = NO;
            if(Szenario.Info.FoolInfo[GameInfo.SelectedFool].Fool_ID == NO_AKTIV || GameInfo.SelectedFool == NO_AKTIV)
                return;
            if(Module == EDITOR_SCENE)
            {
                i = CheckPushBar(GameInfo.GameListe.BuiltMenu.PowerFoolButtonX, GameInfo.GameListe.BuiltMenu.PowerFoolButtonY, FULL_POWER, 25, 0);
                if(i != NO_AKTIV)
                    Szenario.Info.FoolInfo[GameInfo.SelectedFool].Power = i;
            }
            if(CheckMouseRect(GameInfo.GameListe.BuiltMenu.SelectFoolButtonX, GameInfo.GameListe.BuiltMenu.SelectFoolButtonY,
               GameInfo.GameListe.BuiltMenu.SelectFoolButtonX+FOOL_B, GameInfo.GameListe.BuiltMenu.SelectFoolButtonY+FOOL_H) != NO_AKTIV)
            {
       		    if(Mouse.Button == RIGHT_MOUSE_BUTTON && Module != EDITOR_SCENE)
                {
	            	if(GameInfo.SelectedFool != NO_AKTIV)
						GameInfo.DirectControl = YES;
       		    }
                if(Mouse.Button == LEFT_MOUSE_BUTTON)
                {
                	if(GameInfo.SelectedFool == GameInfo.SelectedFool)
                    {
                        x = Szenario.Info.FoolInfo[GameInfo.SelectedFool].PosX;
                        y = Szenario.Info.FoolInfo[GameInfo.SelectedFool].PosY;
                        CentereScreenPosition(&x, &y);
                        GameInfo.ScreenPosX = x;
                        GameInfo.ScreenPosY = y;
                    }
                    else
                    {
                        x = Szenario.Info.FoolInfo[GameInfo.SelectedFool].PosX;
                        y = Szenario.Info.FoolInfo[GameInfo.SelectedFool].PosY;
                        CentereScreenPosition(&x, &y);
                        GameInfo.ScreenPosX = x;
                        GameInfo.ScreenPosY = y;
                        GameInfo.SelectedFool = GameInfo.SelectedFool;
                    }
				}
            }
            if(CheckMouseRect(GameInfo.GameListe.BuiltMenu.Intem1ButtonX, GameInfo.GameListe.BuiltMenu.Intem1ButtonY,
               GameInfo.GameListe.BuiltMenu.Intem1ButtonX+KACHEL_B+KACHEL_OVERLAY, GameInfo.GameListe.BuiltMenu.Intem1ButtonY+KACHEL_H+KACHEL_OVERLAY) != NO_AKTIV)
                CheckEditorSetFoolIntem(0, Module);
            if(CheckMouseRect(GameInfo.GameListe.BuiltMenu.Intem2ButtonX, GameInfo.GameListe.BuiltMenu.Intem2ButtonY,
               GameInfo.GameListe.BuiltMenu.Intem2ButtonX+KACHEL_B+KACHEL_OVERLAY, GameInfo.GameListe.BuiltMenu.Intem2ButtonY+KACHEL_H+KACHEL_OVERLAY) != NO_AKTIV)
                CheckEditorSetFoolIntem(1, Module);
            if(CheckMouseRect(GameInfo.GameListe.BuiltMenu.Intem3ButtonX, GameInfo.GameListe.BuiltMenu.Intem3ButtonY,
               GameInfo.GameListe.BuiltMenu.Intem3ButtonX+KACHEL_B+KACHEL_OVERLAY, GameInfo.GameListe.BuiltMenu.Intem3ButtonY+KACHEL_H+KACHEL_OVERLAY) != NO_AKTIV)
                CheckEditorSetFoolIntem(2, Module);
            if(CheckMouseRect(GameInfo.GameListe.BuiltMenu.Intem4ButtonX, GameInfo.GameListe.BuiltMenu.Intem4ButtonY,
               GameInfo.GameListe.BuiltMenu.Intem4ButtonX+KACHEL_B+KACHEL_OVERLAY, GameInfo.GameListe.BuiltMenu.Intem4ButtonY+KACHEL_H+KACHEL_OVERLAY) != NO_AKTIV)
                CheckEditorSetFoolIntem(3, Module);
            if(CheckMouseRect(GameInfo.GameListe.BuiltMenu.Intem5ButtonX, GameInfo.GameListe.BuiltMenu.Intem5ButtonY,
               GameInfo.GameListe.BuiltMenu.Intem5ButtonX+KACHEL_B+KACHEL_OVERLAY, GameInfo.GameListe.BuiltMenu.Intem5ButtonY+KACHEL_H+KACHEL_OVERLAY) != NO_AKTIV)
                CheckEditorSetFoolIntem(4, Module);
            if(CheckMouseRect(GameInfo.GameListe.BuiltMenu.Intem6ButtonX, GameInfo.GameListe.BuiltMenu.Intem6ButtonY,
               GameInfo.GameListe.BuiltMenu.Intem6ButtonX+KACHEL_B+KACHEL_OVERLAY, GameInfo.GameListe.BuiltMenu.Intem6ButtonY+KACHEL_H+KACHEL_OVERLAY) != NO_AKTIV)
                CheckEditorSetFoolIntem(5, Module);
            return;
        }
        if(CheckMouseRect(GameInfo.GameListe.BuiltMenu.SelectKachelFloorButtonX, GameInfo.GameListe.BuiltMenu.SelectKachelFloorButtonY,
            GameInfo.GameListe.BuiltMenu.SelectKachelFloorButtonX+KACHEL_B+KACHEL_OVERLAY, GameInfo.GameListe.BuiltMenu.SelectKachelFloorButtonY+KACHEL_H+KACHEL_OVERLAY) != NO_AKTIV)
        {
	        if(Mouse.Button == RIGHT_MOUSE_BUTTON && Module == EDITOR_SCENE)
    	    {
                x = Szenario.Kachel[GameInfo.SelectedKachel][KACHEL_POS_X];
                y = Szenario.Kachel[GameInfo.SelectedKachel][KACHEL_POS_Y];
                CentereScreenPosition(&x, &y);
                GameInfo.ScreenPosX = x;
                GameInfo.ScreenPosY = y;
            }
        }
        if(Module == GAME_SCENE)
            return;
        if(GameInfo.Befehl == COMMAND_DELETE)
        {
            CheckMouseButtonInfo(YES, 500, T_UNTERMENU_FIRST_COMMAND);
        	if(Mouse.Button == LEFT_MOUSE_BUTTON)
            {
                if(CheckMouseRect(GameInfo.GameListe.BuiltMenu.SelectKachelWallButtonX, GameInfo.GameListe.BuiltMenu.SelectKachelWallButtonY,
                    GameInfo.GameListe.BuiltMenu.SelectKachelWallButtonX+WALL_B, GameInfo.GameListe.BuiltMenu.SelectKachelWallButtonY+WALL_H) != NO_AKTIV)
                    Szenario.Info.Kachel[GameInfo.SelectedKachel].WallPic = NO_AKTIV;
                if(CheckMouseRect(GameInfo.GameListe.BuiltMenu.SelectKachelMaskButtonX, GameInfo.GameListe.BuiltMenu.SelectKachelMaskButtonY,
                    GameInfo.GameListe.BuiltMenu.SelectKachelMaskButtonX+40, GameInfo.GameListe.BuiltMenu.SelectKachelMaskButtonY+32) != NO_AKTIV)
                    Szenario.Info.Kachel[GameInfo.SelectedKachel].Mask = NO_AKTIV;
                if(CheckMouseRect(GameInfo.GameListe.BuiltMenu.SelectKachelIntemButtonX, GameInfo.GameListe.BuiltMenu.SelectKachelIntemButtonY,
                    GameInfo.GameListe.BuiltMenu.SelectKachelIntemButtonX+40, GameInfo.GameListe.BuiltMenu.SelectKachelIntemButtonY+32) != NO_AKTIV)
                    Szenario.Info.Kachel[GameInfo.SelectedKachel].Intem = NO_AKTIV;
                if(CheckMouseRect(GameInfo.GameListe.BuiltMenu.SelectKachelCommandButtonX, GameInfo.GameListe.BuiltMenu.SelectKachelCommandButtonY,
                    GameInfo.GameListe.BuiltMenu.SelectKachelCommandButtonX+40, GameInfo.GameListe.BuiltMenu.SelectKachelCommandButtonY+32) != NO_AKTIV)
                    Szenario.Info.Kachel[GameInfo.SelectedKachel].Command = NO_COMMAND;
			}
		}
        if(CheckMouseRect(GameInfo.GameListe.BuiltMenu.SelectKachelFloorLeftButtonX, GameInfo.GameListe.BuiltMenu.SelectKachelFloorLeftButtonY,
        	GameInfo.GameListe.BuiltMenu.SelectKachelFloorLeftButtonX+6, GameInfo.GameListe.BuiltMenu.SelectKachelFloorLeftButtonY+KACHEL_H) != NO_AKTIV)
        {
            CheckMouseButtonInfo(YES, 500, T_OBERMENU_UP_OVERLAY);
        	if(Mouse.Button == LEFT_MOUSE_BUTTON)
            {
                GameInfo.GameListe.BuiltMenu.SelectKachelFloorLeftButtonDown = YES;
                GameInfo.GameListe.BuiltMenu.SelectKachelFloorUpButtonDown = NO;
            }
	    }
        if(CheckMouseRect(GameInfo.GameListe.BuiltMenu.SelectKachelFloorUpButtonX, GameInfo.GameListe.BuiltMenu.SelectKachelFloorUpButtonY,
        	GameInfo.GameListe.BuiltMenu.SelectKachelFloorUpButtonX+KACHEL_B+6, GameInfo.GameListe.BuiltMenu.SelectKachelFloorUpButtonY+6) != NO_AKTIV)
        {
            CheckMouseButtonInfo(YES, 500, T_OBERMENU_LEFT_OVERLAY);
        	if(Mouse.Button == LEFT_MOUSE_BUTTON)
            {
                GameInfo.GameListe.BuiltMenu.SelectKachelFloorLeftButtonDown = NO;
                GameInfo.GameListe.BuiltMenu.SelectKachelFloorUpButtonDown = YES;
			}
        }
        if(GameInfo.GameListe.BuiltMenu.SelectKachelFloorLeftButtonDown == YES)
        {
            CheckMouseButtonInfo(YES, 500, T_OBERMENU_OVERLAY_CHOOSE);
        	if(Mouse.Button == LEFT_MOUSE_BUTTON)
            {
                i = CheckPushBar(GameInfo.GameListe.BuiltMenu.AnzahlButtonX, GameInfo.GameListe.BuiltMenu.AnzahlButtonY, 100, 15, 0);
                if(i != NO_AKTIV)
                {
                    if(i == 0)
                        Szenario.Info.Kachel[GameInfo.SelectedKachel].LeftOverlay = NO_AKTIV;
                    else
                    {
                        Szenario.Info.Kachel[GameInfo.SelectedKachel].LeftOverlay = i-1;
                        if(Szenario.Info.Kachel[GameInfo.SelectedKachel].LeftOverlay > 50)
                            Szenario.Info.Kachel[GameInfo.SelectedKachel].LeftOverlay = 50;
                    }
                }
         	}
         }
        if(GameInfo.GameListe.BuiltMenu.SelectKachelFloorUpButtonDown == YES)
        {
            CheckMouseButtonInfo(YES, 500, T_OBERMENU_OVERLAY_CHOOSE);
        	if(Mouse.Button == LEFT_MOUSE_BUTTON)
            {
                i = CheckPushBar(GameInfo.GameListe.BuiltMenu.AnzahlButtonX, GameInfo.GameListe.BuiltMenu.AnzahlButtonY, 100, 15, 0);
                if(i != NO_AKTIV)
                {
                    if(i == 0)
                        Szenario.Info.Kachel[GameInfo.SelectedKachel].UpOverlay = NO_AKTIV;
                    else
                    {
                        Szenario.Info.Kachel[GameInfo.SelectedKachel].UpOverlay = i-1;
                        if(Szenario.Info.Kachel[GameInfo.SelectedKachel].UpOverlay > 50)
                            Szenario.Info.Kachel[GameInfo.SelectedKachel].UpOverlay = 50;
                    }
                }
			}
		}
        CheckTaxiKachelInfo();
        CheckBeamerKachelInfo();
        return;
    }
} /* CheckBuiltMenu */

void CheckEditorSetFoolIntem(int i, int Module)
{
    int Check;

    if(Mouse.Button == LEFT_MOUSE_BUTTON)
    {
        Check = NO_AKTIV;
        if(Editor_SetKachel > FIRST_INTEM-1)
            Check = FIRST_INTEM;
        if(GameInfo.Befehl == COMMAND_DELETE)
            Check = COMMAND_DELETE;
        if(Check == FIRST_INTEM)
            Szenario.Info.FoolInfo[GameInfo.SelectedFool].Intem[i] = Editor_SetKachel-Check;;
        if(Check == COMMAND_DELETE)
        {
            if(Module == GAME_SCENE)
                if(UserMessage(GameTexte[REALY_DESTROY_THE_INTEM_ASK], NO, YES, YES) == NO_BUTTON)
                    return;
            Szenario.Info.FoolInfo[GameInfo.SelectedFool].Intem[i] = NO_AKTIV;
        }
    }
} /* CheckEditorSetFoolIntem */
///////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////
void DrawTaxiKachelInfo(void)
{
    char temp[50];
    RECT rcRect;

    // F�r die Taxi bewegungen, hier kann festgelegt werden, welch Taxis sich bewegen sollen:
    if(Szenario.Info.Kachel[GameInfo.SelectedKachel].Mask == TAXI_KACHEL_SCHALTER)
    {
        // Zeigt das Bild des Taxis:
        SetRect(&rcRect, 1, 735, 44, 770);
        Back->BltFast(GameInfo.GameListe.BuiltMenu.Taxi1ButtonX, GameInfo.GameListe.BuiltMenu.Taxi1ButtonY, GameListPic, &rcRect, FALSE);
        Back->BltFast(GameInfo.GameListe.BuiltMenu.Taxi2ButtonX, GameInfo.GameListe.BuiltMenu.Taxi2ButtonY, GameListPic, &rcRect, FALSE);
        DrawKachelMasksPic(Szenario.Info.Kachel[Szenario.Info.Kachel[GameInfo.SelectedKachel].TAXI_SCHALTER_1].Mask, GameInfo.GameListe.BuiltMenu.Taxi1ButtonX, GameInfo.GameListe.BuiltMenu.Taxi1ButtonY, Back);
        DrawKachelMasksPic(Szenario.Info.Kachel[Szenario.Info.Kachel[GameInfo.SelectedKachel].TAXI_SCHALTER_2].Mask, GameInfo.GameListe.BuiltMenu.Taxi2ButtonX, GameInfo.GameListe.BuiltMenu.Taxi2ButtonY, Back);
        PrintText(GameInfo.GameListe.BuiltMenu.Taxi1ButtonX-5, GameInfo.GameListe.BuiltMenu.Taxi1ButtonY+5, "Taxi 1:", 1, 0, 1000, 1000, Back);
        PrintText(GameInfo.GameListe.BuiltMenu.Taxi2ButtonX-5, GameInfo.GameListe.BuiltMenu.Taxi2ButtonY+5, "Taxi 2:", 1, 0, 1000, 1000, Back);
        sprintf(temp, "%d", Szenario.Info.Kachel[GameInfo.SelectedKachel].TAXI_SCHALTER_1);
        PrintText(GameInfo.GameListe.BuiltMenu.Taxi1ButtonX+5, GameInfo.GameListe.BuiltMenu.Taxi1ButtonY+15, temp, 1, 0, 1000, 1000, Back);
        sprintf(temp, "%d", Szenario.Info.Kachel[GameInfo.SelectedKachel].TAXI_SCHALTER_2);
        PrintText(GameInfo.GameListe.BuiltMenu.Taxi2ButtonX+5, GameInfo.GameListe.BuiltMenu.Taxi2ButtonY+15, temp, 1, 0, 1000, 1000, Back);
        // Zeigt, in welche Richtung es sich bewegen soll:
        SetRect(&rcRect, 1, 735, 44, 770);
        Back->BltFast(GameInfo.GameListe.BuiltMenu.Taxi1RichtungButtonX, GameInfo.GameListe.BuiltMenu.Taxi1RichtungButtonY, GameListPic, &rcRect, FALSE);
        Back->BltFast(GameInfo.GameListe.BuiltMenu.Taxi2RichtungButtonX, GameInfo.GameListe.BuiltMenu.Taxi2RichtungButtonY, GameListPic, &rcRect, FALSE);
        switch(Szenario.Info.Kachel[GameInfo.SelectedKachel].TAXI_SCHALTER_1_RICHTUNG)
        {
        	case 0: sprintf(temp, "links"); break;
        	case 1: sprintf(temp, "hoch"); break;
        	case 2: sprintf(temp, "rechts"); break;
        	case 3: sprintf(temp, "runter"); break;
        	case -1: sprintf(temp, "still"); break;
        }
        PrintText(GameInfo.GameListe.BuiltMenu.Taxi1RichtungButtonX+5, GameInfo.GameListe.BuiltMenu.Taxi1RichtungButtonY+15, temp, 1, 0, 1000, 1000, Back);
        switch(Szenario.Info.Kachel[GameInfo.SelectedKachel].TAXI_SCHALTER_2_RICHTUNG)
        {
        	case 0: sprintf(temp, "links"); break;
        	case 1: sprintf(temp, "hoch"); break;
        	case 2: sprintf(temp, "rechts"); break;
        	case 3: sprintf(temp, "runter"); break;
        	case -1: sprintf(temp, "still"); break;
        }
        PrintText(GameInfo.GameListe.BuiltMenu.Taxi2RichtungButtonX+5, GameInfo.GameListe.BuiltMenu.Taxi2RichtungButtonY+15, temp, 1, 0, 1000, 1000, Back);
        if(GameInfo.GameListe.BuiltMenu.Taxi1ButtonDown == YES)
            DrawRect(GameInfo.GameListe.BuiltMenu.Taxi1ButtonX-1, GameInfo.GameListe.BuiltMenu.Taxi1ButtonY-1, KACHEL_B+KACHEL_OVERLAY+8, KACHEL_H+KACHEL_OVERLAY+2, 15, Back);
        if(GameInfo.GameListe.BuiltMenu.Taxi2ButtonDown == YES)
            DrawRect(GameInfo.GameListe.BuiltMenu.Taxi2ButtonX-1, GameInfo.GameListe.BuiltMenu.Taxi2ButtonY-1, KACHEL_B+KACHEL_OVERLAY+8, KACHEL_H+KACHEL_OVERLAY+2, 15, Back);
    }
    // Zeigt das Taxi:
    if(Szenario.Info.Kachel[GameInfo.SelectedKachel].Mask == TAXI_KACHEL)
    {
        SetRect(&rcRect, 1, 735, 44, 770);
        Back->BltFast(GameInfo.GameListe.BuiltMenu.Taxi1ButtonX, GameInfo.GameListe.BuiltMenu.Taxi1ButtonY, GameListPic, &rcRect, FALSE);
        Back->BltFast(GameInfo.GameListe.BuiltMenu.Taxi2ButtonX, GameInfo.GameListe.BuiltMenu.Taxi2ButtonY, GameListPic, &rcRect, FALSE);
        DrawKachelMasksPic(Szenario.Info.Kachel[GameInfo.SelectedKachel].Mask, GameInfo.GameListe.BuiltMenu.Taxi1ButtonX, GameInfo.GameListe.BuiltMenu.Taxi1ButtonY, Back);
        sprintf(temp, "%d", GameInfo.SelectedKachel);
        PrintText(GameInfo.GameListe.BuiltMenu.Taxi1ButtonX+5, GameInfo.GameListe.BuiltMenu.Taxi1ButtonY+15, temp, 1, 0, 1000, 1000, Back);
        sprintf(temp, "%d", Szenario.Info.Kachel[GameInfo.SelectedKachel].TAXI_SPEED);
        PrintText(GameInfo.GameListe.BuiltMenu.Taxi2ButtonX+5, GameInfo.GameListe.BuiltMenu.Taxi2ButtonY+15, temp, 1, 0, 1000, 1000, Back);
    }
} /* DrawTaxiKachelInfo */

void CheckTaxiKachelInfo(void)
{
    int x, y;

    // F�r die Taxi bewegungen, hier kann festgelegt werden, welch Taxis sich bewegen sollen:
    if(Szenario.Info.Kachel[GameInfo.SelectedKachel].Mask == TAXI_KACHEL_SCHALTER)
    {
        if(CheckMouseRect(GameInfo.GameListe.BuiltMenu.Taxi1ButtonX, GameInfo.GameListe.BuiltMenu.Taxi1ButtonY,
            GameInfo.GameListe.BuiltMenu.Taxi1ButtonX+KACHEL_B+KACHEL_OVERLAY, GameInfo.GameListe.BuiltMenu.Taxi1ButtonY+KACHEL_H+KACHEL_OVERLAY) != NO_AKTIV)
        {
            if(Mouse.Button == RIGHT_MOUSE_BUTTON && Szenario.Info.Kachel[GameInfo.SelectedKachel].TAXI_SCHALTER_1 != NO_AKTIV)
            {
                x = Szenario.Kachel[Szenario.Info.Kachel[GameInfo.SelectedKachel].TAXI_SCHALTER_1][KACHEL_POS_X];
                y = Szenario.Kachel[Szenario.Info.Kachel[GameInfo.SelectedKachel].TAXI_SCHALTER_1][KACHEL_POS_Y];
                CentereScreenPosition(&x, &y);
                GameInfo.ScreenPosX = x;
                GameInfo.ScreenPosY = y;
            }
            CheckMouseButtonInfo(YES, 500, T_OBERMENU_TAXI_1);
            if(Mouse.Button == LEFT_MOUSE_BUTTON)
            {
                GameInfo.GameListe.BuiltMenu.Taxi1ButtonDown = YES;
                GameInfo.GameListe.BuiltMenu.Taxi2ButtonDown = NO;
            }
        }
        if(CheckMouseRect(GameInfo.GameListe.BuiltMenu.Taxi2ButtonX, GameInfo.GameListe.BuiltMenu.Taxi2ButtonY,
            GameInfo.GameListe.BuiltMenu.Taxi2ButtonX+KACHEL_B+KACHEL_OVERLAY, GameInfo.GameListe.BuiltMenu.Taxi2ButtonY+KACHEL_H+KACHEL_OVERLAY) != NO_AKTIV)
        {
            if(Mouse.Button == RIGHT_MOUSE_BUTTON && Szenario.Info.Kachel[GameInfo.SelectedKachel].TAXI_SCHALTER_2 != NO_AKTIV)
            {
                x = Szenario.Kachel[Szenario.Info.Kachel[GameInfo.SelectedKachel].TAXI_SCHALTER_2][KACHEL_POS_X];
                y = Szenario.Kachel[Szenario.Info.Kachel[GameInfo.SelectedKachel].TAXI_SCHALTER_2][KACHEL_POS_Y];
                CentereScreenPosition(&x, &y);
                GameInfo.ScreenPosX = x;
                GameInfo.ScreenPosY = y;
            }
            CheckMouseButtonInfo(YES, 500, T_OBERMENU_TAXI_2);
            if(Mouse.Button == LEFT_MOUSE_BUTTON)
            {
	            GameInfo.GameListe.BuiltMenu.Taxi1ButtonDown = NO;
    	        GameInfo.GameListe.BuiltMenu.Taxi2ButtonDown = YES;
			}
        }
        if(CheckMouseRect(GameInfo.GameListe.BuiltMenu.Taxi1RichtungButtonX, GameInfo.GameListe.BuiltMenu.Taxi1RichtungButtonY,
            GameInfo.GameListe.BuiltMenu.Taxi1RichtungButtonX+KACHEL_B+KACHEL_OVERLAY, GameInfo.GameListe.BuiltMenu.Taxi1RichtungButtonY+KACHEL_H+KACHEL_OVERLAY) != NO_AKTIV)
        {
            CheckMouseButtonInfo(YES, 500, T_OBERMENU_TAXI_1_RICHTUNG);
            if(Mouse.Button == LEFT_MOUSE_BUTTON)
            {
                Szenario.Info.Kachel[GameInfo.SelectedKachel].TAXI_SCHALTER_1_RICHTUNG++;
                if(Szenario.Info.Kachel[GameInfo.SelectedKachel].TAXI_SCHALTER_1_RICHTUNG > 3)
                    Szenario.Info.Kachel[GameInfo.SelectedKachel].TAXI_SCHALTER_1_RICHTUNG = NO_AKTIV;
        	}
        }
        if(CheckMouseRect(GameInfo.GameListe.BuiltMenu.Taxi2RichtungButtonX, GameInfo.GameListe.BuiltMenu.Taxi2RichtungButtonY,
            GameInfo.GameListe.BuiltMenu.Taxi2RichtungButtonX+KACHEL_B+KACHEL_OVERLAY, GameInfo.GameListe.BuiltMenu.Taxi2RichtungButtonY+KACHEL_H+KACHEL_OVERLAY) != NO_AKTIV)
        {
            CheckMouseButtonInfo(YES, 500, T_OBERMENU_TAXI_2_RICHTUNG);
            if(Mouse.Button == LEFT_MOUSE_BUTTON)
            {
                Szenario.Info.Kachel[GameInfo.SelectedKachel].TAXI_SCHALTER_2_RICHTUNG++;
                if(Szenario.Info.Kachel[GameInfo.SelectedKachel].TAXI_SCHALTER_2_RICHTUNG > 3)
                    Szenario.Info.Kachel[GameInfo.SelectedKachel].TAXI_SCHALTER_2_RICHTUNG = NO_AKTIV;
			}
        }
    }
    // Zeigt das Taxi:
    if(Szenario.Info.Kachel[GameInfo.SelectedKachel].Mask == TAXI_KACHEL)
    {
        if(CheckMouseRect(GameInfo.GameListe.BuiltMenu.Taxi2ButtonX, GameInfo.GameListe.BuiltMenu.Taxi2ButtonY,
            GameInfo.GameListe.BuiltMenu.Taxi2ButtonX+KACHEL_B+KACHEL_OVERLAY, GameInfo.GameListe.BuiltMenu.Taxi2ButtonY+KACHEL_H+KACHEL_OVERLAY) != NO_AKTIV)
        {
            CheckMouseButtonInfo(YES, 500, T_OBERMENU_TAXI_SPEED);
            if(Mouse.Button == LEFT_MOUSE_BUTTON)
            {
                Szenario.Info.Kachel[GameInfo.SelectedKachel].TAXI_SPEED++;
                if(Szenario.Info.Kachel[GameInfo.SelectedKachel].TAXI_SPEED > 10)
                    Szenario.Info.Kachel[GameInfo.SelectedKachel].TAXI_SPEED = 0;
            }
        }
    }
} /* CheckTaxiKachelInfo */
///////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////

void DrawBeamerKachelInfo(void)
{
    char temp[50];
    RECT rcRect;

    // Legt fest, zu welchem Beamer gebeamt werden soll: (Auch zufall m�glich!)
    if(Szenario.Info.Kachel[GameInfo.SelectedKachel].Mask != BEAMER)
		return;
    // Zeigt das Bild der Beamer :
    SetRect(&rcRect, 1, 735, 44, 770);
    Back->BltFast(GameInfo.GameListe.BuiltMenu.Taxi1ButtonX, GameInfo.GameListe.BuiltMenu.Taxi1ButtonY, GameListPic, &rcRect, FALSE);
    Back->BltFast(GameInfo.GameListe.BuiltMenu.Taxi2ButtonX, GameInfo.GameListe.BuiltMenu.Taxi2ButtonY, GameListPic, &rcRect, FALSE);
    DrawKachelMasksPic(Szenario.Info.Kachel[Szenario.Info.Kachel[GameInfo.SelectedKachel].BEAMER_NR_1].Mask, GameInfo.GameListe.BuiltMenu.Taxi1ButtonX, GameInfo.GameListe.BuiltMenu.Taxi1ButtonY, Back);
    DrawKachelMasksPic(Szenario.Info.Kachel[Szenario.Info.Kachel[GameInfo.SelectedKachel].BEAMER_NR_2].Mask, GameInfo.GameListe.BuiltMenu.Taxi2ButtonX, GameInfo.GameListe.BuiltMenu.Taxi2ButtonY, Back);
    PrintText(GameInfo.GameListe.BuiltMenu.Taxi1ButtonX-5, GameInfo.GameListe.BuiltMenu.Taxi1ButtonY+5, "Beamer 1:", 1, 0, 1000, 1000, Back);
    PrintText(GameInfo.GameListe.BuiltMenu.Taxi2ButtonX-5, GameInfo.GameListe.BuiltMenu.Taxi2ButtonY+5, "Beamer 2:", 1, 0, 1000, 1000, Back);
    sprintf(temp, "%d", Szenario.Info.Kachel[GameInfo.SelectedKachel].BEAMER_NR_1);
    PrintText(GameInfo.GameListe.BuiltMenu.Taxi1ButtonX+5, GameInfo.GameListe.BuiltMenu.Taxi1ButtonY+15, temp, 1, 0, 1000, 1000, Back);
    sprintf(temp, "%d", Szenario.Info.Kachel[GameInfo.SelectedKachel].BEAMER_NR_2);
    PrintText(GameInfo.GameListe.BuiltMenu.Taxi2ButtonX+5, GameInfo.GameListe.BuiltMenu.Taxi2ButtonY+15, temp, 1, 0, 1000, 1000, Back);
    if(GameInfo.GameListe.BuiltMenu.Taxi1ButtonDown == YES)
        DrawRect(GameInfo.GameListe.BuiltMenu.Taxi1ButtonX-1, GameInfo.GameListe.BuiltMenu.Taxi1ButtonY-1, KACHEL_B+KACHEL_OVERLAY+8, KACHEL_H+KACHEL_OVERLAY+2, 15, Back);
    if(GameInfo.GameListe.BuiltMenu.Taxi2ButtonDown == YES)
        DrawRect(GameInfo.GameListe.BuiltMenu.Taxi2ButtonX-1, GameInfo.GameListe.BuiltMenu.Taxi2ButtonY-1, KACHEL_B+KACHEL_OVERLAY+8, KACHEL_H+KACHEL_OVERLAY+2, 15, Back);
    if(Szenario.Info.Kachel[GameInfo.SelectedKachel].BEAMER_RANDOM == NO)
	{
	    SetRect(&rcRect, 50, 885, 100, 900);
	    Back->BltFast(GameInfo.GameListe.BuiltMenu.AnzahlButtonX+50, GameInfo.GameListe.BuiltMenu.AnzahlButtonY, GameListPic, &rcRect, FALSE);
        SetRect(&rcRect, 0, 900, 50, 915);
        Back->BltFast(GameInfo.GameListe.BuiltMenu.AnzahlButtonX, GameInfo.GameListe.BuiltMenu.AnzahlButtonY, GameListPic, &rcRect, FALSE);
	    PrintText(GameInfo.GameListe.BuiltMenu.AnzahlButtonX+70, GameInfo.GameListe.BuiltMenu.AnzahlButtonY, "NO", 1, 0, 1000, 1000, Back);
    }
    if(Szenario.Info.Kachel[GameInfo.SelectedKachel].BEAMER_RANDOM == YES)
	{
        SetRect(&rcRect, 0, 885, 100, 900);
	    Back->BltFast(GameInfo.GameListe.BuiltMenu.AnzahlButtonX, GameInfo.GameListe.BuiltMenu.AnzahlButtonY, GameListPic, &rcRect, FALSE);
	    PrintText(GameInfo.GameListe.BuiltMenu.AnzahlButtonX+70, GameInfo.GameListe.BuiltMenu.AnzahlButtonY, "YES", 1, 0, 1000, 1000, Back);
    }
    PrintText(GameInfo.GameListe.BuiltMenu.AnzahlButtonX-10, GameInfo.GameListe.BuiltMenu.AnzahlButtonY, "Random?", 1, 0, 1000, 1000, Back);
} /* DrawBeamerKachelInfo */

void CheckBeamerKachelInfo(void)
{
    int x, y, i;

    // Legt fest, zu welchem Beamer gebeamt werden soll: (Auch zufall m�glich!)
    if(Szenario.Info.Kachel[GameInfo.SelectedKachel].Mask != BEAMER)
		return;
    if(CheckMouseRect(GameInfo.GameListe.BuiltMenu.Taxi1ButtonX, GameInfo.GameListe.BuiltMenu.Taxi1ButtonY,
        GameInfo.GameListe.BuiltMenu.Taxi1ButtonX+KACHEL_B+KACHEL_OVERLAY, GameInfo.GameListe.BuiltMenu.Taxi1ButtonY+KACHEL_H+KACHEL_OVERLAY) != NO_AKTIV)
    {
        if(Mouse.Button == RIGHT_MOUSE_BUTTON && Szenario.Info.Kachel[GameInfo.SelectedKachel].BEAMER_NR_1 != NO_AKTIV)
        {
            x = Szenario.Kachel[Szenario.Info.Kachel[GameInfo.SelectedKachel].BEAMER_NR_1][KACHEL_POS_X];
            y = Szenario.Kachel[Szenario.Info.Kachel[GameInfo.SelectedKachel].BEAMER_NR_1][KACHEL_POS_Y];
            CentereScreenPosition(&x, &y);
            GameInfo.ScreenPosX = x;
            GameInfo.ScreenPosY = y;
        }
        CheckMouseButtonInfo(YES, 500, T_OBERMENU_BEAMER_1);
        if(Mouse.Button == LEFT_MOUSE_BUTTON)
        {
	        GameInfo.GameListe.BuiltMenu.Taxi1ButtonDown = YES;
    	    GameInfo.GameListe.BuiltMenu.Taxi2ButtonDown = NO;
    	}
    }
    if(CheckMouseRect(GameInfo.GameListe.BuiltMenu.Taxi2ButtonX, GameInfo.GameListe.BuiltMenu.Taxi2ButtonY,
        GameInfo.GameListe.BuiltMenu.Taxi2ButtonX+KACHEL_B+KACHEL_OVERLAY, GameInfo.GameListe.BuiltMenu.Taxi2ButtonY+KACHEL_H+KACHEL_OVERLAY) != NO_AKTIV)
    {
        if(Mouse.Button == RIGHT_MOUSE_BUTTON && Szenario.Info.Kachel[GameInfo.SelectedKachel].BEAMER_NR_2 != NO_AKTIV)
        {
            x = Szenario.Kachel[Szenario.Info.Kachel[GameInfo.SelectedKachel].BEAMER_NR_2][KACHEL_POS_X];
            y = Szenario.Kachel[Szenario.Info.Kachel[GameInfo.SelectedKachel].BEAMER_NR_2][KACHEL_POS_Y];
            CentereScreenPosition(&x, &y);
            GameInfo.ScreenPosX = x;
            GameInfo.ScreenPosY = y;
        }
        CheckMouseButtonInfo(YES, 500, T_OBERMENU_BEAMER_2);
        if(Mouse.Button == LEFT_MOUSE_BUTTON)
        {
	        GameInfo.GameListe.BuiltMenu.Taxi1ButtonDown = NO;
    	    GameInfo.GameListe.BuiltMenu.Taxi2ButtonDown = YES;
    	}
    }
    i = CheckPushBar(GameInfo.GameListe.BuiltMenu.AnzahlButtonX, GameInfo.GameListe.BuiltMenu.AnzahlButtonY, 100, 15, 0);
    if(i != NO_AKTIV)
    {
    	if(i >= 50)
            Szenario.Info.Kachel[GameInfo.SelectedKachel].BEAMER_RANDOM = NO;
	    else
        	Szenario.Info.Kachel[GameInfo.SelectedKachel].BEAMER_RANDOM = YES;
    }
} /* CheckBeamerKachelInfo */
///////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////



/* Module  "game.h":                                                (Project:  Fools)
	Definierte Constanden, die global f�r das gesammte Spiel ben�tigt werden:
*/

// Die Punkte werden auf den einzelnen Kacheln in -WallPicAniStepTurn- hinterlegt, da sowiso
// auf einem Punkt keine Wand stehen kann.
#define PUNKT -5

#define GEGNER_B 40
#define GEGNER_H 60

#define DRAW_GEGNER_DROHNE 2000
///////////////////////////////////////////////////////////////////////////////////////
// T�r Informationen:
// In "WallPicAniStepTurn" werd der T�r Status vermerkt!!
#define DOOR_OPEN 1000
#define DOOR_CLOSE 1001
#define DOOR_OPENING 1002
#define DOOR_CLOSEING 1003
///////////////////////////////////////////////////////////////////////////////////////
#define COMMAND_PIXEL_TURN 2 // Die Geschwindigkeit die die Maus haben muss, um einen Befehl auf eine Kachel zu setzen
#define NO_WALK     -1
#define NOW_DIED     999

#define FIRST_JUMP 0
#define LAST_JUMP 1
///////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////
// Globale Constanten
#define NO  0
#define YES 1
#define USER 2
#define PLUS 600
#define MINUS 601
#define NO_AKTIV -1
#define NO_LIMITED 100
///////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////
#define SCROLL_SPEED 4 // Geschwindigkeit des Scrolles beim Sichtfenster(keine Maustaste gedr�ckt!)
#define LEFT_MOUSE_BUTTON_SPEED 20  // Geschwindigkeit des Scrolles beim Sichtfenster(linke Maustaste gedr�ckt!)
#define RIGHT_MOUSE_BUTTON_SPEED 40  // Geschwindigkeit des Scrolles beim Sichtfenster(rechte Maustaste gedr�ckt!)
///////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////
#define KARTEN_B_MAX 80 // Maximale Gr��e die ein Level haben darf
#define KARTEN_H_MAX 80 // Maximale Gr��e die ein Level haben darf
#define KACHEL_B 32 // Breite einer Bodenflie�e
#define KACHEL_H 32 // H�he einer Bodenflie�e
#define WALL_B 40 // Breite einer Wand
#define WALL_H 68 // H�he einer Wand
#define FOOL_B 40 // Breite eines Fools
#define FOOL_H 60 // H�he eines Fools
#define MAX_FOOLS 100 // Maximale Anzahl der verf�gbaren Fool Einheiten
#define MAX_FOOL_INTEMS 6 // Maximale Anzahl der Gegenst�nde die ein Fool tragen kann
#define MAX_FOOL_ANIMATION 9 // Anzahl der Animationen eines Fools beim Laufen.
#define MAX_TURN_ANI 9 // Maximale Animationen f�r eine 90 Grad wendung
#define MAX_EXIT_ANZAHL 99

#define FIRST_PACMAN 150
#define PACMAN_B 45 // Breite eines PacMans
#define PACMAN_H 45 // H�he eines PacMans
///////////////////////////////////////////////////////////////////////////////////////
#define FULL_POWER 70
#define NO_POWER 0
///////////////////////////////////////////////////////////////////////////////////////
// Fool Animatioen:
	// Der Fool wei� nicht weiter:
    #define SILLY_LEFT 506
    #define SILLY_UP 507
    #define SILLY_RIGHT 508
    #define SILLY_DOWN 509
    #define WAITING 510
    #define JUMPING 511
    #define BEAMING_START 512
    #define BEAMING_START_END 513
    #define BEAMING_END 514

	#define ON_FINISH 515
	#define FINISH 516
	#define WRONG_EXIT_PAGE 517
    // Der Fool wechselt gerade seine Richtung:
	#define TURN_RIGHT 31
	#define TURN_LEFT 30
///////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////
// Die Pixel Koordinaten der Kacheln:
#define KACHEL_POS_X  1 // Virtuelle X Pixel Position
#define KACHEL_POS_Y  2 // Virtuelle Y Pixel Position
#define KACHEL_PIXEL_X 3 // Zum Objecte Pixelwei�e verschieben
#define KACHEL_PIXEL_Y 4 // Zum Objecte Pixelwei�e verschieben
#define START_KACHEL_PIC_ANI_STEP 5
#define START_WALL_ANI_STEP  6
///////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////
// Kachel Informationen:
    #define MAX_KACHEL_PICS 10000
// Gibt an, welches Bild der Boden hat:
    // (Pic):
        #define NO_KACHEL -1
        #define FLOOR 0  // NormaleBodenflie�en
        #define FLOOR_ANI 266   // Animierte Bodenflie�en
        #define DEADLY_WALKS 532   // Normale t�tliche Bodenflie�en
        #define DEADLY_WALKS_ANI 798   // Animierte t�tliche Bodenflie�en
// Zeigt, welche Wand auf der Kachel sitzt:
    // (WallPic):
	    #define WALLS 1100
	    #define WALL_ANI 1500
	    #define MOVE_WALLS 2500

    #define FIRST_INTEM 3000
    #define FIRST_OBJECT 3300
    #define DOOR_ANI 5000

	// Spezielle Objecte:
	#define  SPECIAL_EXIT 6000
	#define  SPECIAL_EXIT_OVERLAY 6001
    /////////

// Masken:
    #define FIRST_INSTABIL 0
    #define LAST_INSTABIL 9
    #define ATOMIK 10
    #define BEAMER 11
    #define GESUND 12
	#define FIRST_MOVE_MASK 14
	#define MAX_MOVE_MASK 20
  //////
    #define TAXI_KACHEL 50
	#define TAXI_RICHTUNG WallPicAniStep
	#define TAXI_SPEED    WallPicAniStepTurn
           /////
    #define TAXI_KACHEL_SCHALTER 51
    #define TAXI_SCHALTER_1          WallPic
    #define TAXI_SCHALTER_1_RICHTUNG WallPicAniStep
    #define TAXI_SCHALTER_2          WallPicAniStepTurn
    #define TAXI_SCHALTER_2_RICHTUNG WallPicAniCircle
  ////////// Informationen �ber den Beamer:
	#define BEAMER_RANDOM   WallPicAniStep
    #define BEAMER_NR_1     WallPic
    #define BEAMER_NR_2     WallPicAniStepTurn
// Die Befehle auf den Kacheln:
    #define NO_COMMAND -1
    #define WALK_LEFT    0
    #define WALK_UP      1
    #define WALK_RIGHT   2
    #define WALK_DOWN    3
    #define PUSH_LEFT    4
    #define PUSH_UP 5
    #define PUSH_RIGHT 6
    #define PUSH_DOWN 7
    // In Position Animationen f�r Schieben:
        #define ON_PUSH_LEFT 21
        #define OFF_PUSH_LEFT 22
        #define ON_PUSH_UP 23
        #define OFF_PUSH_UP 24
        #define ON_PUSH_RIGHT 25
        #define OFF_PUSH_RIGHT 26
        #define ON_PUSH_DOWN 27
        #define OFF_PUSH_DOWN 28
	//
    #define USE_LEFT 8
    #define USE_UP 9
    #define USE_RIGHT 10
    #define USE_DOWN 11

    #define TAKE_LEFT 12
    #define TAKE_UP 13
    #define TAKE_RIGHT 14
    #define TAKE_DOWN 15
//
///////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////
// Die Befehl die der Spieler aussuchen kann:
    #define COMMAND_DELETE 100
    #define COMMAND_WALK 101
    #define COMMAND_PUSH 102
    #define COMMAND_TAKE 103
    #define COMMAND_USE 104
    #define COMMAND_WAIT 105
    #define COMMAND_JUMP 106
//    #define COMMAND_NONE 104
    #define SELECT_COMMAND 107
    #define INSPECT_COMMAND 108
//    #define COMMAND_NONE 109
///////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////
// Definiert Werte f�r das Befehle Men�:
    #define C_MENU_B 127-Mouse.CursorB
    #define C_MENU_H 124-Mouse.CursorH
    // Nur im Editor:
		#define SET_FOOL -5
		#define SET_INSTABIL -6
		#define SET_ATOMIK -7
		#define SET_BEAMER -8
		#define SET_EXIT -9
		#define SET_TAXI_KACHEL -10
		#define SET_TAXI_KACHEL_SCHALTER -11
		#define SET_PACMAN -12
		#define SET_GESUND -13
		#define SET_PUNKT -14
///////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////
//	Dient als Hilfe beim Ausschneiten der Bilder aus einem gro�em Bild:
#define MAX_FLOOR_PICS MAX_FLOOR_PIC_B*MAX_FLOOR_PIC_H
#define MAX_WALL_PICS MAX_WALL_PIC_B*MAX_WALL_PIC_H
#define MAX_FLOOR_PIC_B 19
#define MAX_FLOOR_PIC_H 56
#define MAX_WALL_PIC_B 15
#define MAX_WALL_PIC_H  9
///////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////
// F�r den Editor:
#define KACHEL_MENU_ON 0
#define KACHEL_MENU_PAGE 1
#define MAX_KACHEL_PAGES 9
///////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////
// Die Position des Selectierungs Sympol auf dem Bildschirm:
#define LUPE_X GameListeX-30
#define LUPE_Y GameListeY+10

#define INSPECT_X GameListeX-30
#define INSPECT_Y GameListeY+30
///////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////
// Art einer Nachrricht an den Spieler:
#define FOOL_DEAD_MESSAGE 1 // Ein Fool ist dahingeschieden
///////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////
// Hilft bei der Perspektivischen Darstellung der Spielfl�che:
#define KACHEL_OVERLAY 4
#define PERS_PIC_MINUS 7
#define PERS_PIXEL 7
#define PERS_PIXEL_STEPS 4
#define PERS_STEPS 8
///////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////
extern int ExitModule; // Wenn zwischen den verschiedenen Programmteitel gewechselt wird
extern int ExitProgramm; // Soll das Programm beendet werden?
extern int FontB, FontH;
extern int WINDOW_X;
extern int WINDOW_Y;
extern int WINDOW_BP;
extern int WINDOW_HP;
extern int WINDOW_B;
extern int WINDOW_H;
extern int PressedMouseScroll;
///////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////
extern struct SAVED_LEVEL SavedLevel;
extern struct SZENARIO Szenario;
extern struct GAME_INFO GameInfo;
///////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////
extern LPDIRECTDRAWSURFACE GameAusgabe;
extern LPDIRECTDRAWSURFACE    MiniPic;
extern LPDIRECTDRAWSURFACE    GameListPic;
extern LPDIRECTDRAWSURFACE    CommandMenuPic;
extern LPDIRECTDRAWSURFACE    FoolAniPic;
extern LPDIRECTDRAWSURFACE    GegnerAniPic;
extern LPDIRECTDRAWSURFACE    PacManAniPic;
extern LPDIRECTDRAWSURFACE    BefehlePic;
extern LPDIRECTDRAWSURFACE    Primary;   // DirectDraw primary surface
extern LPDIRECTDRAWSURFACE    GameDeskPic;       // Offscreen surface 2
extern LPDIRECTDRAWPALETTE    lpDDPal;        // DirectDraw palette
extern BOOL                   bActive;        // is application active?
///////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////
extern void LoadFont(int, char *);
extern void DestroyFont(int);
extern void InitFontStruct(int, int, int);
extern void PrintText(int, int, char *, int, int, int, int, LPDIRECTDRAWSURFACE);
extern void PrintTextNo_Trans(int, int, char *, int, int, int, int, LPDIRECTDRAWSURFACE);
extern void SetBB_Message(char *, int, int, int, int, int);
extern void ShowBB_Message(int);
extern void SetBB_SmallMessage(char *, int);
extern void ShowBB_SmallMessage(int);
extern void LoadGlobalPics(void);
extern void DestroyGlobalPics(void);
extern void LoadLevelBitmaps(char *);
extern void DestroyLevelBitmaps(void);
extern void SaveLevel(char *);
extern void LoadLevel(char *);
extern void MouseScroll(void);
extern void MoveScreenDown(int);
extern void MoveScreenUp(int);
extern void MoveScreenRight(int);
extern void MoveScreenLeft(int);
///////////////////////////////////////////////////////////////////////////////////////
extern void InitGetFrameRate(void);
extern void GetFrameRate(void);
extern void ShowFrameRate(void);
///////////////////////////////////////////////////////////////////////////////////////
extern void LoadWaitPic(void);
extern void ShowLoadStatus(int);
extern int CheckFoolTurnAni(int);
extern int CheckFoolSillyAni(int, int);
extern void CheckFoolWalkAni(int);
///////////////////////////////////////////////////////////////////////////////////////
extern int Intro(void);
extern int Game(int);
extern int LevelEditor(void);
///////////////////////////////////////////////////////////////////////////////////////
extern void CheckAniScene(void);
extern void CheckSelectedAni(void);

extern int FindMouseFool(void);
extern int FindMousePacMan(void);
extern void CheckMouseFool(void);

extern void DrawMini(void);
extern void DrawMiniKachel(int, int);
extern void DrawMiniToDisplay(int, int);
extern void CheckMiniFilter(int, int);
extern void CheckMiniScroll(int, int);
//////////////////////////////////////////////////////////////////////////
extern void DrawRect(int, int, int, int, int, LPDIRECTDRAWSURFACE);
//////////////////////////////////////////////////////////////////////////
extern int CheckPushBar(int, int, int, int, int);
//////////////////////////////////////////////////////////////////////////
extern void DrawAnimatedFool(int, int, int, LPDIRECTDRAWSURFACE, int);
extern void CheckMoveWallCreateDestroyed(int);

extern void CheckDoorAni(void);

extern void MoveGegner(void);

extern void DrawKachelFloorPic(int, int, int, LPDIRECTDRAWSURFACE);
extern void DrawKachelMasksPic(int, int, int, LPDIRECTDRAWSURFACE);
extern void DrawKachelIntemPic(int, int, int, LPDIRECTDRAWSURFACE);
extern void DrawKachelWallPic(int, int, int, LPDIRECTDRAWSURFACE, int);
extern void DrawCommand(int, int, int, int, LPDIRECTDRAWSURFACE);

extern void CentereScreenPosition(int *, int *);
extern void GameListeOnOff(void);

struct FAST_MENU_BUTTON
{
	int x, y, b, h;
    int Funk;
    int Selected, SelectedOn, Step, Turn, Anzahl;
};
extern struct FAST_MENU_BUTTON GameCommandMenu[];

extern int SetScreenRes(int);
extern int XKachelPers[KACHEL_H+4];

#define MAX_DEMO_POINTER 30000
extern void LoadDemo(void);
extern void SaveDemo(void);
extern void PlayDemo(void);
extern void RecordDemo(int);
struct DEMO
{
    char LevelName[256];
    int DemoInfoTime[MAX_DEMO_POINTER];
    short DemoInfo[MAX_DEMO_POINTER][3];
    short DemoStarts[5];
};
extern struct DEMO DemoInfo;

extern LPDIRECTDRAWSURFACE LevelFool;
extern int LevelFoolAniStep, LevelFoolAniStepTurn;

extern void DrawVirtualScene(int);
extern int SucheKachel(void);
extern void LoadLevel(char *);
extern void UpdateDisplay(void);
extern int CheckMouseFoolsStatus(void);
extern void DrawAnimatedGegner(int, int, int, LPDIRECTDRAWSURFACE);
extern void DrawAnimatedPacMan(int, int, int, LPDIRECTDRAWSURFACE);

extern void CheckPacManAni(void);
extern void CheckPacManWalk(void);
extern void CheckMoveKeys(WPARAM, int);
extern int CheckMouseRichtung(void);

extern char LastLetterKey;
extern int Eingabe(char *, int, int);
extern int GiveFoolANewName;

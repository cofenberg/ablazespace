#define MAX_FONTS 5
#define ZEICHEN_POS_X 0
#define ZEICHEN_POS_Y 1

struct FONT
{
	int PicPos[123][2]; // 0 = Zeichen, 1 = xPos, 2 = yPos // Positionen der Bilder
    int MaxXZeichen, MaxYZeichen; // Maximale Zeichen pro Spalte...
    int FontB, FontH; // Die gr��e der Schrift
	LPDIRECTDRAWSURFACE FontPic; // Die Schriftart
};

extern struct FONT Font[MAX_FONTS];
extern void LoadFont(int, char *);
extern void DestroyFont(int);
extern void IntitFontStruct(int, int, int);
extern void PrintText(int, int, char *, int, int, int, int);
extern int Eingabe(char *, int, int);


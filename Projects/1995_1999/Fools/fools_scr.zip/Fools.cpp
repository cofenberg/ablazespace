#include "Global.h"
#include "Inits.h"

#include "Message.h"

extern void LoadBarMenuBitmaps(void);
extern void DestroyBarMenuBitmaps(void);

void (*CheckKeyModule)(WPARAM);
extern void InitGameInfo(void);
char VersionsInfo[30];
struct PROGRAMM_SETUP ProgrammSetup;
char *GameTexte[MAX_GAME_TEXTE];

int ProgrammModule, SavedProgrammModule;
void LoadSetupData(void);
void SaveSetupData(void);

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
 	int SaveShowFps;
    DDBLTFX     ddbltfx;

	stpcpy(VersionsInfo, "V. 0.5 -Alpha");
    randomize();
	LoadSetupData();
    if(!doInit(hInstance, nCmdShow))
        return FALSE;
	if(LoadGameTexte(ProgrammSetup.Language) == YES)
    	ExitProgramm = YES;
	LoadBarMenuBitmaps();
	LoadMouseCursorsPic();
    SaveShowFps = ProgrammSetup.ShowFps;
    ProgrammSetup.ShowFps = NO;
	InitFontStruct(0, 15, 15);
	LoadFont(0, "Bilder/Font1.bmp");
	InitFontStruct(1, 10, 10);
	LoadFont(1, "Bilder/Font1.bmp");
    ddbltfx.dwSize = sizeof(ddbltfx);
    ddbltfx.dwFillColor = 0;
    Primary->Blt(NULL, NULL, NULL, DDBLT_COLORFILL, &ddbltfx);
    Back->Blt(NULL, NULL, NULL, DDBLT_COLORFILL, &ddbltfx);
    UpdateDisplay();
    Back->Blt(NULL, NULL, NULL, DDBLT_COLORFILL, &ddbltfx);
    LoadWaitPic();
    InitGameInfo();
    LoadGlobalPics();
    ProgrammSetup.ShowFps = SaveShowFps;
    SetMouseBound(0, 0, ScreenRes[0]-Mouse.CursorB, ScreenRes[1]-Mouse.CursorH);
    SetMouseStyle(NORMAL_MOUSE_STYLE, YES, 1, 0, 0, 15, YES, 0);
	ExitModule = NO;
	ExitProgramm = NO;
	GameInfo.LimitedTime = NO;
	stpcpy(GameInfo.AktuellesLevel, "Default.lev");
	GameInfo.SelectedPath = NO_AKTIV;
    GameInfo.DemoPointer = 0;
    GameInfo.MakeADemo = NO;
    GameInfo.PlayDemo = NO;
    Mouse.LastXPos = NO_AKTIV;
    Mouse.LastYPos = NO_AKTIV;
    Mouse.VorLastXPos = NO_AKTIV;
    Mouse.VorLastYPos = NO_AKTIV;
    ProgrammSetup.MouseSpur = YES;
    Intro();
	SaveSetupData();
    DestroyGlobalPics();
	DestroyFont(0);
	DestroyBarMenuBitmaps();
	DestroyGameTexte();
    lpDD->RestoreDisplayMode();
    return(0);
} /* WinMain */

void LoadSetupData(void)
{
    int datei;

    datei = open(SETUP_FILE, O_RDONLY | O_BINARY);
    read(datei, &ProgrammSetup, sizeof(ProgrammSetup));
    close(datei);
} /* LoadSetupData */

void SaveSetupData(void)
{
    int datei;

    chmod(SETUP_FILE, S_IREAD | S_IWRITE);
    unlink(SETUP_FILE);
    datei = open(SETUP_FILE, O_WRONLY | O_CREAT | O_BINARY);
    write(datei, &ProgrammSetup, sizeof(ProgrammSetup));
    close(datei);
} /* SaveetupData */



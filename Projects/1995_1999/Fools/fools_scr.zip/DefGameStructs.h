// Der Spieler �ndert einige Programm einstellungen,
// und diese werden hier hinterlegt, so, dass sie auch beim n�chsten
// Programmstart vorhanden sind:
struct PROGRAMM_SETUP
{
	int ScreenResNr; // mit welcher Aufl�sung soll gespielt werden?
    int ShowFps; // Die Framerate anzeige ist akiv
    int ShowFoolPower;
    int ShowFoolName;
    int GameSpeed;
    int ScrollSpeed;
	//////////////////////////////////////////7
    int GameLongWalls; // �berdeckende W�nde erlaubt?
    int GameMouseTrans; // Soll die Maus die Wand Transparent darstellen?
    int GameSelectedTrans;   // Soll der Selectierte Fool die Wand Transparent darstellen?
	//////////////////////////////////////////7
    int ShowGameListe;
	// Mini Karte:
    int MiniShowFools;
    int MiniShowWalls;
    int MiniShowMoveWalls;
    int MiniShowFloor;
    int MiniShowDeadlyFloor;
    int MiniShowCommands;
    int MiniShowIntems;
    int MiniShowObjects;
    int MiniShowRect;
	//////////////////////////////////////////7
    int Language;
    int MouseHelp;
    int MouseSpur;
};

// Die Informationen �ber die Fools:
struct FOOL
{
    int Fool_ID;
    int OnLive;
    int Power;
    int MaxPower;
	int PosX, PosY;
    int PixelPosX, PixelPosY;
    int Richtung;
    int Befehl;
    int Animation;
    int AnimationStep;
    int AnimationTurn;
    int AnimationBackTurn;
    int AnimationPlusMinus;
    int AnimationInfo; // In welche Richtung schaut der Fool gerade?
    int LastWalk;
	int ThinkShowStep; // Animationsfase der Denk Blase.
    int Intem[6];
    char FoolName[256];
};

// Die Informationen �ber die Pacmans:
struct PACMAN
{
    int PacMan_ID;
    int OnLive;
    int Power;
    int MaxPower;
	int PosX, PosY;
    int PixelPosX, PixelPosY;
    int Richtung;
    int Animation;
    int AnimationStep;
    int AnimationTurn;
    int LastWalk;
    char PacManName[256];
    int Befehl;
    int AktuellBefehl;
};

#define MAX_PACMAN 10

#define MAX_GEGNER 50
#define GEGNER_DROHNE 0
// Die Informationen �ber die Gegner:
struct GEGNER
{
	int Typ; // Was ist es f�r ein Gegner?
    int Gegner_ID;
    int OnLive;
    int Power;
    int MaxPower;
	int PosX, PosY;
	int PixelPosX, PixelPosY;
    int Richtung;
    int Animation;
    int AnimationStep;
    int AnimationTurn;
    int LastWalk;
};

struct KACHEL
{
	int Pic;
    int PicAniStep;
    int PicAniStepTurn;
    int PicAniCircle;
	int WallPic;
    int WallPicAniStep;
    int WallPicAniStepTurn;
    int WallPicAniCircle;
    int Command;
    int CommandConst;
    int Besetzt;
    int Mask;
    int Intem;
    int LeftOverlay;
    int UpOverlay;
};
// Bewegbare Transporter:
//	wenn in Mask der Entsprechende wert f�r den Transporter eingestellt ist,
//  dann gibt Wall PicAniStep an, in welche Richtung sich diese Plattform bewegt
//  WallPicAniStepTurn gibt die Geschwindigkeit an
//  TAXI_RICHTUNG
//  #define TAXI_RICHTUNG WallPicAniStep
//  #define TAXI_SPEED    WallPicAniStepTurn

//  Dies ist f�r die Taxi Schalter:
//  Steht ein Fool oder ein sonstiges Object auf dem Schalter,
//  so bekommen die 2 m�glichen manipulierbaren Taxis die anweisung,
//  sich in die entsprechende Richtung zu bewegen.
//  Wird der Schalter wieder frei, so h�lt das Taxi an.
//    #define TAXI_SCHALTER_TAXI_1          WallPic
//    #define TAXI_SCHALTER_TAXI_1_RICHTUNG WallPicAniStep
//    #define TAXI_SCHALTER_TAXI_2          WallPicAniStepTurn
//    #define TAXI_SCHALTER_TAXI_2_RICHTUNG WallPicAniCircle

// Diese werte mussen gespeichert werden:
typedef struct
{
    char LevelName[256]; // Der Name der Level Datei
    char SzenarioSet[256]; // Welches Graphisch Set soll benutzt werden?
	int KarteB; // Die Breite des Levels
    int KarteH; // Die H�he des Levels
	int StartPosX; // Die Positzion der Kamera beim Start
	int StartPosY;
	int StartPixelPosX;
	int StartPixelPosY;
    int FoolAnzahl;
    int PacManAnzahl;
    int GegnerAnzahl;
    int PunkteAnzahl;
    int ExitAnzahl;
	int ToFinish_LiveFools; // Die Anzahl der �berlebenden Fools, die mann zum Gewinnen braucht!
    struct KACHEL Kachel[KARTEN_B_MAX*KARTEN_H_MAX];
    struct FOOL FoolInfo[MAX_FOOLS];
    struct PACMAN PacManInfo[MAX_PACMAN];
    struct GEGNER GegnerInfo[MAX_GEGNER];
    int Commands[9];
    int LimitedTime;
    int TimeHours, TimeMinutes, TimeSeconds;
} SCENARIO_INFO;

// Diese werte sind vom Programm ben�tigte informationen:
struct SZENARIO
{
	SCENARIO_INFO Info;  // Die Level informationen(Aufbau)
    int PosInfo[KARTEN_B_MAX][KARTEN_H_MAX]; // Erleichtert das Finden einer Kachel
    int Kachel[KARTEN_B_MAX*KARTEN_H_MAX][20]; // Die X und Y Pixel Koordinaten der Kacheln
    int FloorPicPos[MAX_FLOOR_PICS][2];
    int WallPicPos[MAX_WALL_PICS][2];
    LPDIRECTDRAWSURFACE    FloorLevelPic;
    LPDIRECTDRAWSURFACE    WallLevelPic;
    LPDIRECTDRAWSURFACE    MoveWallLevelPic;
    LPDIRECTDRAWSURFACE    DoorAniLevelPic;
    LPDIRECTDRAWSURFACE    WallAniLevelPic;
    LPDIRECTDRAWSURFACE    MasksLevelPic;
    LPDIRECTDRAWSURFACE    ObjectsLevelPic;
    LPDIRECTDRAWSURFACE    IntemsLevelPic;
    LPDIRECTDRAWSURFACE    SpecialLevelPic;
    LPDIRECTDRAWSURFACE    PunktLevelPic;
};

struct BUILD_MENU
{
	int SelectFoolButtonDown;
	int SelectFoolButtonX;
	int SelectFoolButtonY;
	int FoolNameButtonDown;
	int FoolNameButtonX;
	int FoolNameButtonY;
	int PowerFoolButtonDown;
	int PowerFoolButtonX;
	int PowerFoolButtonY;
    int Intem1ButtonDown;
	int Intem1ButtonX;
	int Intem1ButtonY;
    int Intem2ButtonDown;
	int Intem2ButtonX;
	int Intem2ButtonY;
    int Intem3ButtonDown;
	int Intem3ButtonX;
	int Intem3ButtonY;
    int Intem4ButtonDown;
	int Intem4ButtonX;
	int Intem4ButtonY;
    int Intem5ButtonDown;
	int Intem5ButtonX;
	int Intem5ButtonY;
    int Intem6ButtonDown;
	int Intem6ButtonX;
	int Intem6ButtonY;
    /////
    int SelectKachelFloorButtonDown;
	int SelectKachelFloorButtonX;
	int SelectKachelFloorButtonY;
    int SelectKachelFloorLeftButtonDown;
	int SelectKachelFloorLeftButtonX;
	int SelectKachelFloorLeftButtonY;
    int SelectKachelFloorUpButtonDown;
	int SelectKachelFloorUpButtonX;
	int SelectKachelFloorUpButtonY;
    int SelectKachelWallButtonDown;
	int SelectKachelWallButtonX;
	int SelectKachelWallButtonY;
    int SelectKachelMaskButtonDown;
	int SelectKachelMaskButtonX;
	int SelectKachelMaskButtonY;
    int SelectKachelIntemButtonDown;
	int SelectKachelIntemButtonX;
	int SelectKachelIntemButtonY;
    int SelectKachelCommandButtonDown;
	int SelectKachelCommandButtonX;
	int SelectKachelCommandButtonY;
    int Taxi1ButtonDown;
	int Taxi1ButtonX;
	int Taxi1ButtonY;
    int Taxi2ButtonDown;
	int Taxi2ButtonX;
	int Taxi2ButtonY;
    int Taxi1RichtungButtonDown;
	int Taxi1RichtungButtonX;
	int Taxi1RichtungButtonY;
    int Taxi2RichtungButtonDown;
	int Taxi2RichtungButtonX;
	int Taxi2RichtungButtonY;
   ////////
	int AnzahlButtonDown;
	int AnzahlButtonX;
	int AnzahlButtonY;
	int DeleteButtonDown;
	int DeleteButtonX;
	int DeleteButtonY;
};

struct INFOS_MENU
{
	int SlowDownButtonDown;
	int SlowDownButtonX;
	int SlowDownButtonY;
	int SlowUpButtonDown;
	int SlowUpButtonX;
	int SlowUpButtonY;
	int FastDownButtonDown;
	int FastDownButtonX;
	int FastDownButtonY;
	int FastUpButtonDown;
	int FastUpButtonX;
	int FastUpButtonY;
	int FirstButtonDown;
	int FirstButtonX;
	int FirstButtonY;
	int LastButtonDown;
	int LastButtonX;
	int LastButtonY;
};

struct STATISTIK_MENU
{
};

struct LOAD_LEVEL_MENU
{
	int LoadButtonDown;
	int LoadButtonX;
	int LoadButtonY;
};

struct OPTIONS_MENU
{
	int SaveButtonDown;
	int SaveButtonX;
	int SaveButtonY;
	int LoadButtonDown;
	int LoadButtonX;
	int LoadButtonY;
	struct LOAD_LEVEL_MENU LoadLevelMenu;
	int QuitButtonDown;
	int QuitButtonX;
	int QuitButtonY;
   // Nur im Spiel:
	int PauseButtonDown;
	int PauseButtonX;
	int PauseButtonY;
   // Nur im Editor:
	int NewButtonDown;
	int NewButtonX;
	int NewButtonY;
};

struct OBJECTS_MENU
{
	int PageUpButtonDown;
	int PageUpButtonX;
	int PageUpButtonY;
	int PageDownButtonDown;
	int PageDownButtonX;
	int PageDownButtonY;

   // Page 1:
	int SetFoolButtonDown;
	int SetFoolButtonX;
	int SetFoolButtonY;
	int SetPacManButtonDown;
	int SetPacManButtonX;
	int SetPacManButtonY;
	int SetGegnerDrohneButtonDown;
	int SetGegnerDrohneButtonX;
	int SetGegnerDrohneButtonY;
	int DeleteButtonDown;
	int DeleteButtonX;
	int DeleteButtonY;
	int AnzahlButtonDown;
	int AnzahlButtonX;
	int AnzahlButtonY;
	int SetInstabilButtonDown;
	int SetInstabilButtonX;
	int SetInstabilButtonY;
	int SetAtomikButtonDown;
	int SetAtomikButtonX;
	int SetAtomikButtonY;
	int SetBeamerButtonDown;
	int SetBeamerButtonX;
	int SetBeamerButtonY;
	int SetExitButtonDown;
	int SetExitButtonX;
	int SetExitButtonY;
	int SetTaxiKachelButtonDown;
	int SetTaxiKachelButtonX;
	int SetTaxiKachelButtonY;
	int SetTaxiKachelSchalterButtonDown;
	int SetTaxiKachelSchalterButtonX;
	int SetTaxiKachelSchalterButtonY;
   // Page 2:
	int SetGesundButtonDown;
	int SetGesundButtonX;
	int SetGesundButtonY;
	int SetPunktButtonDown;
	int SetPunktButtonX;
	int SetPunktButtonY;
};

struct LOAD_SZENARIO_MENU
{
	int LoadButtonDown;
	int LoadButtonX;
	int LoadButtonY;
};

struct SZENARIO_MENU
{
	int LoadSzenarioButtonDown;
	int LoadSzenarioButtonX;
	int LoadSzenarioButtonY;
    struct LOAD_SZENARIO_MENU LoadSzenarioMenu;
	int FinishFoolsButtonDown;
	int FinishFoolsButtonX;
	int FinishFoolsButtonY;
};

struct GL_COMMANDS_MENU
{
	int AnzahlButtonDown;
	int AnzahlButtonX;
	int AnzahlButtonY;
	int CommandsButtonDown[9];
	int CommandsButtonX[9];
	int CommandsButtonY[9];
	int TimeButtonDown;
	int TimeButtonX;
	int TimeButtonY;
    int TimeHoursButtonDown;
    int TimeHoursButtonX;
    int TimeHoursButtonY;
    int TimeMinutesButtonDown;
    int TimeMinutesButtonX;
    int TimeMinutesButtonY;
    int TimeSecondsButtonDown;
    int TimeSecondsButtonX;
    int TimeSecondsButtonY;
};

struct GAME_LISTE
{
	int ButtonB;
	int ButtonH;
	int BuiltDown;
	int BuiltX;
	int BuiltY;
	struct BUILD_MENU BuiltMenu;
	int InfosDown;
	int InfosX;
	int InfosY;
	struct INFOS_MENU InfosMenu;
	int StatistikDown;
	int StatistikX;
	int StatistikY;
	struct STATISTIK_MENU StatistikMenu;
	int OptionsDown;
	int OptionsX;
	int OptionsY;
	struct OPTIONS_MENU OptionsMenu;
   // Nur im Editor:
	int ObjectsDown;
	int ObjectsX;
	int ObjectsY;
	struct OBJECTS_MENU ObjectsMenu;
	int SzenarioDown;
	int SzenarioX;
	int SzenarioY;
	struct SZENARIO_MENU SzenarioMenu;
	int CommandsDown;
	int CommandsX;
	int CommandsY;
	struct GL_COMMANDS_MENU CommandsMenu;
};

struct GAME_INFO
{
	int PixelX;
	int ScreenPosX, ScreenPosY;   // Die Aktuell Position des Bildschirmaussnittes
	int ScreenPixelPosX, ScreenPixelPosY;   // Die Aktuell Position des Bildschirmaussnittes
	int PlayerPosX, PlayerPosY;   // Die Aktuell Positzion des Cursors
	int PlayerPixelPosX, PlayerPixelPosY;   // Die Aktuell Positzion des Cursors
    int Befehl;
	int AnimatetCommand;
	int AnimatetCommandOn;
    int KachelLeftPlus;
	int AnimatedWalls;
  ///
	DWORD Fps;
	DWORD FpsCount;
    DWORD FpsTimer;
    DWORD FpsLastTimer;
  ////
    int MenuAni;
    int LiveFools;
    int DeadFools;
    int FinishFools;
	int SelectedKachel;
	int SelectedFool;
	int SelectedFoolAni;
	int SelectedFoolAniStep;
   // Gespielte Zeit:
    int LimitedTime;
	int TimeHours;
	int TimeMin;
	int TimeSec;
	int PlayedTimeHours;
	int PlayedTimeMin;
	int PlayedTimeSec;
   // Lupen Animation
    int LupeStep;
    int LupeTurn;
	struct GAME_LISTE GameListe;
	int SelectedPath;
    int Module; // In welchem Programmteil befindet sich der Spieler Gerade:
    int PlayerAnzahl; // Anzahl der Spieler
    char AktuellesLevel[256]; // Das Aktuell ausfew�hlte Level
   // Vom Spieler manipulierbare Werte:
    int Pause;
    int GameEnd;

    int DemoPointer;
    int MakeADemo;
    int PlayDemo;

    int Gewonnen;
    int Points;

    int DirectControl;
};

struct BB_MESSAGE
{
	int On;
    int Time;
    int Step;
    char Message[100];
    int ScreenPosX, ScreenPosY;
    int ScreenPixelPosX, ScreenPixelPosY;
    int LastScreenPosX, LastScreenPosY;
    int LastScreenPixelPosX, LastScreenPixelPosY;
    int Info;
};


// Speicher optimiertes Level:
// Es wird nur das gesichert, was nicht wieder herstellbar ist:
struct SAVED_FOOL
{
    short Fool_ID;
    char OnLive;
    char Power;
    char MaxPower;
    char Richtung;
    char Befehl;
    char Intem[6];
    char FoolName[256];
};

struct SAVED_GEGNER
{
    short Gegner_ID;
	char Typ; // Was ist es f�r ein Gegner?
    char OnLive;
    char Power;
    char MaxPower;
    char Richtung;
};

// Die Informationen �ber die Pacmans:
struct SAVED_PACMAN
{
    int PacMan_ID;
    int OnLive;
    int Power;
    int MaxPower;
	int PosX, PosY;
    int Richtung;
    int LastWalk;
    char PacManName[256];
};

struct SAVED_KACHEL
{
	short Pic;
    char PicAniStep;
    char PicAniStepTurn;
    char PicAniCircle;
	short WallPic;
    char WallPicAniStep;
    char WallPicAniStepTurn;
    char WallPicAniCircle;
    char Command;
    char CommandConst;
    short Besetzt;
    char Mask;
    char Intem;
    char LeftOverlay;
    char UpOverlay;
};

struct SAVED_LEVEL
{
	char KarteB; // Die Breite des Levels
    char KarteH; // Die H�he des Levels
	char StartPosX; // Die Positzion der Kamera beim Start
	char StartPosY;
    char StartPixelPosX;
	char StartPixelPosY;
    short FoolAnzahl;
    short PacManAnzahl;
    short GegnerAnzahl;
    short PunkteAnzahl;
    char ExitAnzahl;
	char ToFinish_LiveFools; // Die Anzahl der �berlebenden Fools, die mann zum Gewinnen braucht!
    char Commands[9];
    char LimitedTime;
    char TimeHours, TimeMinutes, TimeSeconds;
    char LevelName[256]; // Der Name der Level Datei
    char SzenarioSet[256]; // Welches Graphisch Set soll benutzt werden?
    struct SAVED_FOOL FoolInfo[MAX_FOOLS];
    struct SAVED_GEGNER GegnerInfo[MAX_GEGNER];
    struct SAVED_PACMAN PacManInfo[MAX_PACMAN];
    struct SAVED_KACHEL Kachel[KARTEN_B_MAX*KARTEN_H_MAX];
};
///////////////////////////////


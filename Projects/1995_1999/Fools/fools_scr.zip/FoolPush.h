int CheckFoolPush(int);
void SetFoolPush(int, int, int, int);
int StartEndFoolPush(int, int);

int CheckFoolPush(int i, int command)
{
    int out_ani, xMin, yMin;

    switch(command)
    {
    	case PUSH_LEFT:
            out_ani = OFF_PUSH_LEFT;
            xMin = -1;
            yMin = 0;
		    SetFoolPush(i, PUSH_LEFT, ON_PUSH_LEFT, OFF_PUSH_LEFT);
        break;

    	case PUSH_UP:
            out_ani = OFF_PUSH_UP;
            xMin = 0;
            yMin = -1;
		    SetFoolPush(i, PUSH_UP, ON_PUSH_UP, OFF_PUSH_UP);
        break;

    	case PUSH_RIGHT:
            out_ani = OFF_PUSH_RIGHT;
            xMin = 1;
            yMin = 0;
		    SetFoolPush(i, PUSH_RIGHT, ON_PUSH_RIGHT, OFF_PUSH_RIGHT);
        break;

    	case PUSH_DOWN:
            out_ani = OFF_PUSH_DOWN;
            xMin = 0;
            yMin = 1;
		    SetFoolPush(i, PUSH_DOWN, ON_PUSH_DOWN, OFF_PUSH_DOWN);
        break;
    }
    // Der Fool schiebt gerade schon, und soll nun weiterschieben:
    if(Szenario.Info.FoolInfo[i].Befehl == command && Szenario.Info.FoolInfo[i].Animation == command)
    {
        Szenario.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+xMin][Szenario.Info.FoolInfo[i].PosY+yMin]][KACHEL_PIXEL_X] = 0;
        Szenario.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+xMin][Szenario.Info.FoolInfo[i].PosY+yMin]][KACHEL_PIXEL_Y] = 0;
        Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Command = NO_COMMAND;
        if(Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+xMin][Szenario.Info.FoolInfo[i].PosY+yMin]].WallPic > MOVE_WALLS-1 &&
            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+(xMin*2)][Szenario.Info.FoolInfo[i].PosY+(yMin*2)]].WallPic == NO_AKTIV)
        {
            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+(xMin*2)][Szenario.Info.FoolInfo[i].PosY+(yMin*2)]].WallPic = Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+xMin][Szenario.Info.FoolInfo[i].PosY+yMin]].WallPic;
            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+xMin][Szenario.Info.FoolInfo[i].PosY+yMin]].WallPic = NO_AKTIV;
            switch(command)
            {
                case PUSH_LEFT: Szenario.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+(xMin*2)][Szenario.Info.FoolInfo[i].PosY+(yMin*2)]][KACHEL_PIXEL_X] = KACHEL_B; break;
                case PUSH_UP: Szenario.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+(xMin*2)][Szenario.Info.FoolInfo[i].PosY+(yMin*2)]][KACHEL_PIXEL_Y] = KACHEL_H; break;
                case PUSH_RIGHT: Szenario.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+(xMin*2)][Szenario.Info.FoolInfo[i].PosY+(yMin*2)]][KACHEL_PIXEL_X] = -KACHEL_B; break;
                case PUSH_DOWN: Szenario.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+(xMin*2)][Szenario.Info.FoolInfo[i].PosY+(yMin*2)]][KACHEL_PIXEL_Y] = -KACHEL_H; break;
            }
            return YES;
        }
        else
        { // Kein schieben m�glich, entweder Feste Wand. oder gar nichts zum schieben vorhanden:
            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+xMin][Szenario.Info.FoolInfo[i].PosY+yMin]].Intem = NO_AKTIV;
            Szenario.Info.FoolInfo[i].Animation = out_ani;
            Szenario.Info.FoolInfo[i].AnimationBackTurn = 1;
            Szenario.Info.FoolInfo[i].AnimationTurn = 0;
        }
    }
    return NO;
} /* CheckFoolPush */

// Der Fool soll ein Object verschieben: (Animation vergeben)
void SetFoolPush(int i, int Animation, int AnimationOn, int AnimationOff)
{
    if(Szenario.Info.FoolInfo[i].Befehl == Animation)
    {  // Der Fool f�ngt an zu scheiben:
        if(Szenario.Info.FoolInfo[i].Animation != Animation)
        {
            Szenario.Info.FoolInfo[i].Animation = AnimationOn;
            Szenario.Info.FoolInfo[i].AnimationBackTurn = 0;
            Szenario.Info.FoolInfo[i].AnimationTurn = 0;
            Szenario.Info.FoolInfo[i].AnimationStep = 0;
        }
        return;
    }
    else
        if(Szenario.Info.FoolInfo[i].Animation == Animation)
        {  // Der Fool h�rt auf zu scheiben:
            switch(Animation)
            {
            	case PUSH_LEFT:
	                Szenario.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX-1][Szenario.Info.FoolInfo[i].PosY]][KACHEL_PIXEL_X] = 0;
    	            Szenario.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX-1][Szenario.Info.FoolInfo[i].PosY]][KACHEL_PIXEL_Y] = 0;
                    break;

            	case PUSH_UP:
	                Szenario.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY-1]][KACHEL_PIXEL_X] = 0;
    	            Szenario.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY-1]][KACHEL_PIXEL_Y] = 0;
                    break;

            	case PUSH_RIGHT:
	                Szenario.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+1][Szenario.Info.FoolInfo[i].PosY]][KACHEL_PIXEL_X] = 0;
    	            Szenario.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+1][Szenario.Info.FoolInfo[i].PosY]][KACHEL_PIXEL_Y] = 0;
                    break;

            	case PUSH_DOWN:
	                Szenario.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY+1]][KACHEL_PIXEL_X] = 0;
    	            Szenario.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY+1]][KACHEL_PIXEL_Y] = 0;
                    break;
            }
            Szenario.Info.FoolInfo[i].Animation = AnimationOff;
            Szenario.Info.FoolInfo[i].AnimationBackTurn = 0;
            Szenario.Info.FoolInfo[i].AnimationTurn = 0;
            Szenario.Info.FoolInfo[i].AnimationStep = 0;
            return;
        }
} /* SetFoolPush */

// Der Fool f�ngt an, ein Object zu verschieben, oder h�rt gerade wieder damit auf:
int CheckFoolPushStartEnd(int i)
{
    // Der Fool soll ein Object verschieben:
	StartEndFoolPush(i, Szenario.Info.FoolInfo[i].Animation);
    switch(Szenario.Info.FoolInfo[i].Animation)
    {
        case PUSH_LEFT:
			Szenario.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX-1][Szenario.Info.FoolInfo[i].PosY]][KACHEL_PIXEL_X]--;
	       	return YES;

        case PUSH_RIGHT:
			Szenario.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+1][Szenario.Info.FoolInfo[i].PosY]][KACHEL_PIXEL_X]++;
	       	return YES;

        case PUSH_UP: // Der Fool verschieb nun ein Object:
           // Object Pixel weise verschieben:
			Szenario.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY-1]][KACHEL_PIXEL_Y]--;
	       	return YES;

        case PUSH_DOWN: // Der Fool verschieb nun ein Object:
           // Object Pixel weise verschieben:
			Szenario.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY+1]][KACHEL_PIXEL_Y]++;
	       	return YES;

       //////// // Der Fool richtet sich wieder auf:
        case OFF_PUSH_LEFT: case OFF_PUSH_RIGHT: case OFF_PUSH_UP: case OFF_PUSH_DOWN:
            if(Szenario.Info.FoolInfo[i].AnimationStep > 0)
            {
                Szenario.Info.FoolInfo[i].AnimationStep--;
              	return NO;
            }
            else
            { // Der Fool steht wieder einsatzbereit:
                // Der Fool geht normal weiter:
				if(Szenario.Info.FoolInfo[i].Animation == OFF_PUSH_LEFT)
	                Szenario.Info.FoolInfo[i].Animation = WALK_LEFT;
				if(Szenario.Info.FoolInfo[i].Animation == OFF_PUSH_RIGHT)
	                Szenario.Info.FoolInfo[i].Animation = WALK_RIGHT;
				if(Szenario.Info.FoolInfo[i].Animation == OFF_PUSH_UP)
	                Szenario.Info.FoolInfo[i].Animation = WALK_UP;
				if(Szenario.Info.FoolInfo[i].Animation == OFF_PUSH_DOWN)
	                Szenario.Info.FoolInfo[i].Animation = WALK_DOWN;
                Szenario.Info.FoolInfo[i].AnimationStep = 0;
                Szenario.Info.FoolInfo[i].AnimationTurn = -1;
                Szenario.Info.FoolInfo[i].AnimationTurn = Szenario.Info.FoolInfo[i].Animation;
                if(Szenario.Info.FoolInfo[i].AnimationBackTurn == 1)
	                Szenario.Info.FoolInfo[i].Animation = Szenario.Info.FoolInfo[i].Richtung+SILLY_LEFT;
                Szenario.Info.FoolInfo[i].AnimationBackTurn = 0;
               	return YES;
            }
    }
   	return NO_AKTIV;
} /* CheckFoolPushStartEnd */

int StartEndFoolPush(int i, int command)
{
    if(command != ON_PUSH_LEFT && command != ON_PUSH_UP && command != ON_PUSH_RIGHT && command != ON_PUSH_DOWN)
    	return NO;
    if(Szenario.Info.FoolInfo[i].AnimationStep < 9)
    {
        Szenario.Info.FoolInfo[i].AnimationStep++;
        return NO;
    }
    else
    { // Der Fool ist in Position, kann er nun schieben?:
        int xMin = 0, yMin = 0;

        switch(command)
        {
            case ON_PUSH_LEFT: xMin = -1; break;
            case ON_PUSH_UP: yMin = -1; break;
            case ON_PUSH_RIGHT: xMin = 1; break;
            case ON_PUSH_DOWN: yMin = 1; break;
        }
        Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Command = NO_COMMAND;
        if(Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+xMin][Szenario.Info.FoolInfo[i].PosY+yMin]].WallPic > MOVE_WALLS-1 &&
            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+(xMin*2)][Szenario.Info.FoolInfo[i].PosY+(yMin*2)]].WallPic == NO_AKTIV)
        { // OK das Object kann verschoben werden:
            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+(xMin*2)][Szenario.Info.FoolInfo[i].PosY+(yMin*2)]].WallPic = Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+xMin][Szenario.Info.FoolInfo[i].PosY+yMin]].WallPic;
            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+xMin][Szenario.Info.FoolInfo[i].PosY+yMin]].WallPic = NO_AKTIV;
            switch(command)
            {
            	case ON_PUSH_LEFT:
                    Szenario.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+(xMin*2)][Szenario.Info.FoolInfo[i].PosY+(yMin*2)]][KACHEL_PIXEL_X] = KACHEL_B;
                    Szenario.Info.FoolInfo[i].Richtung = WALK_LEFT;
                    Szenario.Info.FoolInfo[i].Animation = PUSH_LEFT;
                    Szenario.Info.FoolInfo[i].PixelPosX = KACHEL_B;
                break;

            	case ON_PUSH_UP:
                    Szenario.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+(xMin*2)][Szenario.Info.FoolInfo[i].PosY+(yMin*2)]][KACHEL_PIXEL_Y] = KACHEL_H;
                    Szenario.Info.FoolInfo[i].Richtung = WALK_UP;
                    Szenario.Info.FoolInfo[i].Animation = PUSH_UP;
                    Szenario.Info.FoolInfo[i].PixelPosY = KACHEL_H;
                break;

            	case ON_PUSH_RIGHT:
                    Szenario.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+(xMin*2)][Szenario.Info.FoolInfo[i].PosY+(yMin*2)]][KACHEL_PIXEL_X] = -KACHEL_B;
                    Szenario.Info.FoolInfo[i].Richtung = WALK_RIGHT;
                    Szenario.Info.FoolInfo[i].Animation = PUSH_RIGHT;
                    Szenario.Info.FoolInfo[i].PixelPosX = -KACHEL_B;
                break;

            	case ON_PUSH_DOWN:
                    Szenario.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+(xMin*2)][Szenario.Info.FoolInfo[i].PosY+(yMin*2)]][KACHEL_PIXEL_Y] = -KACHEL_H;
                    Szenario.Info.FoolInfo[i].Richtung = WALK_DOWN;
                    Szenario.Info.FoolInfo[i].Animation = PUSH_DOWN;
                    Szenario.Info.FoolInfo[i].PixelPosY = -KACHEL_H;
                break;
            }
            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Besetzt = NO_AKTIV;
            Szenario.Info.FoolInfo[i].PosX += xMin;
            Szenario.Info.FoolInfo[i].PosY += yMin;
            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Besetzt = i;
            Szenario.Info.FoolInfo[i].AnimationBackTurn = 0;
            Szenario.Info.FoolInfo[i].AnimationTurn = 0;
            Szenario.Info.FoolInfo[i].AnimationStep = 0;
            return YES;
        }
        else
        { // Kein schieben m�glich, entweder Feste Wand. oder gar nichts zum schieben vorhanden:
            Szenario.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+xMin][Szenario.Info.FoolInfo[i].PosY+yMin]][KACHEL_PIXEL_X] = 0;
            Szenario.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX+xMin][Szenario.Info.FoolInfo[i].PosY+yMin]][KACHEL_PIXEL_Y] = 0;
            switch(command)
            {
                case ON_PUSH_LEFT: Szenario.Info.FoolInfo[i].Animation = OFF_PUSH_LEFT; break;
                case ON_PUSH_UP: Szenario.Info.FoolInfo[i].Animation = OFF_PUSH_UP; break;
                case ON_PUSH_RIGHT: Szenario.Info.FoolInfo[i].Animation = OFF_PUSH_RIGHT; break;
                case ON_PUSH_DOWN: Szenario.Info.FoolInfo[i].Animation = OFF_PUSH_DOWN; break;
            }
            Szenario.Info.FoolInfo[i].AnimationBackTurn = 1;
            Szenario.Info.FoolInfo[i].AnimationTurn = 0;
            return NO;
        }
    }
} /* StartEndFoolPush */

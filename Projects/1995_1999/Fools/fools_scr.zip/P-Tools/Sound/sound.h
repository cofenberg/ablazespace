/*==========================================================================
 *
 *  Copyright (C) 1997 Microsoft Corporation. All Rights Reserved.
 *
 *  File:       sound.h
 *  Content:    DirectSound routines include file
 *
 ***************************************************************************/


#include <dsound.h>

// Wenn's hier Probleme gibt, haben Sie noch die Include-Dateien
// f�r DirectX 3 im Pfad des Compilers...

#define PANLEFT (DSBPAN_LEFT / 10)
#define PANRIGHT (DSBPAN_RIGHT / 10)

BOOL PlayBuffer(void);
BOOL SetupStreamBuffer(LPSTR);
void PanStreaming(int);

BOOL  InitDSound(HWND, HINSTANCE, GUID*);
void  Cleanup(void);

BOOL CALLBACK EnumCallback(LPGUID, LPCSTR, LPCSTR, LPVOID);          

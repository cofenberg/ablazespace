/*==========================================================================
 *
 *  Copyright (C) 1997 Microsoft Corporation. All Rights Reserved.
 *
 *  File:       Static.h
 *  Content:    Static sound buffer management
 *
 ***************************************************************************/
#ifndef __STATIC_INCLUDED__
#define __STATIC_INCLUDED__

#ifdef __cplusplus
extern "C" {
#endif

#define SHORTWAVE "bounce.wav"

BOOL LoadStatic(LPDIRECTSOUND lpds, LPSTR lpzFileName);
void PlayStatic(void);

#ifdef __cplusplus
}
#endif

#endif


#include "P-Tools/Sound/wave.h"
#include <dsound.h>
#include "P-Tools/Sound/static.h"
#include <windowsx.h>

extern LPDIRECTSOUND lpds;
LPDIRECTSOUNDBUFFER  lpdsbStatic;



/* --------------------------------------------------------

   LoadStatic()
   Loads a sound from file, creating a static buffer for it
   if necessary.

   -------------------------------------------------------- */

BOOL LoadStatic( LPDIRECTSOUND lpds, LPSTR lpzFileName )
{
	WAVEFORMATEX  *pwfx;          // WAV-Datenformat
	HMMIO         hmmio;          // Dateihandle
	MMCKINFO      mmckinfo;       // aktueller Chunk
	MMCKINFO      mmckinfoParent; // �bergeordneter Chunk

    if ( WaveOpenFile( lpzFileName, &hmmio, &pwfx, &mmckinfoParent ) != 0 )
        return FALSE;
 
    if ( WaveStartDataRead( &hmmio, &mmckinfo, &mmckinfoParent ) != 0 )
        return FALSE;

    // Puffer anlegen (falls noch nicht vorhanden)
 
    DSBUFFERDESC         dsbdesc;

	// Wenn der Puffer bereits existiert, dann geht es hier um nur 
	// um das Neuladen nach einem Aufruf von Restore()

    if ( lpdsbStatic == NULL )
    {
        memset( &dsbdesc, 0, sizeof( DSBUFFERDESC ) ); 
        dsbdesc.dwSize = sizeof( DSBUFFERDESC ); 
        dsbdesc.dwFlags = DSBCAPS_STATIC; 
        dsbdesc.dwBufferBytes = mmckinfo.cksize;  
        dsbdesc.lpwfxFormat = pwfx; 
 
        if ( FAILED( lpds->CreateSoundBuffer( 
                &dsbdesc, &lpdsbStatic, NULL ) ) )
        {
            WaveCloseReadFile( &hmmio, &pwfx );
            return FALSE; 
        }
    }

    LPVOID lpvAudio1;
    DWORD  dwBytes1;

	if ( FAILED( lpdsbStatic->Lock(
        0,              // Start des Sperrbereichs innerhalb des Puffers
        0,              // Gr��e des Bereichs, bei ENTIREBUFFER ignoriert
        &lpvAudio1,     // programmeigene Variable, 
                        // wird auf den physischen Start gesetzt
        &dwBytes1,      // dito, wird mit der Gr��e des Bereichs gesetzt
        NULL,           // keine Variable f�r den Start 
                        // des zweiten Teilbereichs
        NULL,           // dto. f�r die Gr��e des zweiten Teilbereichs
        DSBLOCK_ENTIREBUFFER ) ) )  // gesamten Puffer sperren
    {
        // Fehlerbehandlung.
        WaveCloseReadFile( &hmmio, &pwfx );
        return FALSE;
    }
 
    UINT cbBytesRead;
 
	if ( WaveReadFile( hmmio,     // Handle der Datei
		    dwBytes1,             // Anzahl der zu lesenden Bytes
			( BYTE * )lpvAudio1,  // Zieladresse
			&mmckinfo,            // aktueller Chunk
			&cbBytesRead ) )      // programmeigene Variable, wird mit der 
                              // Anzahl tats�chlich gelesener Bytes gesetzt
    {
        // Fehlerbehandlung, wenn WaveReadFile nicht 0 zur�ckliefert
        WaveCloseReadFile( &hmmio, &pwfx );
        return FALSE;
    }

    lpdsbStatic->Unlock( lpvAudio1, dwBytes1, NULL, 0 );

    WaveCloseReadFile( &hmmio, &pwfx );

    return TRUE;
}  // LoadStatic


/* --------------------------------------------------------

   PlayStatic()
   Starts the static buffer from the beginning

   -------------------------------------------------------- */


void PlayStatic( void )
{
    HRESULT hr;

    if ( lpdsbStatic == NULL ) return;

    lpdsbStatic->SetCurrentPosition( 0 );
    hr = lpdsbStatic->Play( 0, 0, 0 );    // Mehrfach-Aufruf schadet nichts
    if ( hr == DSERR_BUFFERLOST )
    {
        if ( SUCCEEDED( lpdsbStatic->Restore() ) )
        {
            if ( LoadStatic( lpds, SHORTWAVE ) )
                lpdsbStatic->Play( 0, 0, 0 );
        }
    }
}

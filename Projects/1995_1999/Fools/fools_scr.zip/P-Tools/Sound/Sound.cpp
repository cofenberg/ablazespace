/*==========================================================================
 *  Copyright (C) 1997 Microsoft Corporation.
 *
 *  File:       Sound.cpp
 *  Content:    DirectSound management for MakeWave sample
 *
 ***************************************************************************/

#include "P-Tools/Sound/sound.h"
#include "P-Tools/Sound/wave.h"
#include <stdio.h>
#include "P-Tools/Sound/resource.h"


LPDIRECTSOUND               lpds;
LPDIRECTSOUNDBUFFER         lpdsb;
LPDIRECTSOUNDBUFFER         lpdsbPrimary;
WAVEFORMATEX                *pwfx;
HMMIO                       hmmio;
MMCKINFO                    mmckinfo, mmckinfoParent;
DWORD                       dwMidBuffer;

/* --------------------------------------------------------

   FillBufferWithSilence()
   Write silence to entire buffer

   -------------------------------------------------------- */

BOOL FillBufferWithSilence( LPDIRECTSOUNDBUFFER lpDsb )
{
    WAVEFORMATEX    wfx;
    DWORD           dwSizeWritten;

    PBYTE   pb1;
    DWORD   cb1;

    if ( FAILED( lpDsb->GetFormat( &wfx, sizeof( WAVEFORMATEX ), &dwSizeWritten ) ) )
        return FALSE;

    if ( SUCCEEDED( lpDsb->Lock( 0, 0, 
                         ( LPVOID * )&pb1, &cb1, 
                         NULL, NULL, DSBLOCK_ENTIREBUFFER ) ) )
    {
        FillMemory( pb1, cb1, ( wfx.wBitsPerSample == 8 ) ? 128 : 0 );

        lpDsb->Unlock( pb1, cb1, NULL, 0 );
        return TRUE;
    }

    return FALSE;
}  // FillBufferWithSilence


/* --------------------------------------------------------

   SetupStreamBuffer()
   Create a streaming buffer in same format as wave data

   -------------------------------------------------------- */

BOOL SetupStreamBuffer( LPSTR lpzFileName )
{
    DSBUFFERDESC    dsbdesc;
    HRESULT         hr;

    // Offene Datei schlie�en und Puffer abbauen, falls vorhanden
    WaveCloseReadFile( &hmmio, &pwfx );
    if ( lpdsb != NULL )
    {
        lpdsb->Release();
        lpdsb = NULL;
    }

    // Datei �ffnen, Datenformat lesen und weiter bis zum data-Chunk
    if ( WaveOpenFile( lpzFileName, &hmmio, &pwfx, &mmckinfoParent ) != 0 )
        return FALSE;
    if ( WaveStartDataRead( &hmmio, &mmckinfo, &mmckinfoParent ) != 0 )
        return FALSE;

    // Sekund�ren Puffer mit 2 Sekunden Spieldauer anlegen
    memset( &dsbdesc, 0, sizeof( DSBUFFERDESC ) ); 
    dsbdesc.dwSize = sizeof( DSBUFFERDESC ); 
    dsbdesc.dwFlags = DSBCAPS_GETCURRENTPOSITION2 
                    | DSBCAPS_GLOBALFOCUS
                    | DSBCAPS_CTRLPAN; 
    dsbdesc.dwBufferBytes = pwfx->nAvgBytesPerSec * 2;  
    dsbdesc.lpwfxFormat = pwfx; 
 
    if ( FAILED( hr = lpds->CreateSoundBuffer( &dsbdesc, &lpdsb, NULL ) ) )
    {
        WaveCloseReadFile( &hmmio, &pwfx );
        return FALSE; 
    }

    FillBufferWithSilence( lpdsb );
    hr = lpdsb->Play( 0, 0, DSBPLAY_LOOPING );

    dwMidBuffer = dsbdesc.dwBufferBytes / 2;

    return TRUE;
} // SetupStreamBuffer


/* --------------------------------------------------------
   
   PanStreaming()
   Pan the steaming buffer in response to keypress 

   -------------------------------------------------------- */

void PanStreaming( int PanShift )
{
    LONG lCurrent;

    if ( lpdsb != NULL )
    {
        lpdsb->GetPan( &lCurrent );  // aktueller Wert
        lCurrent += PanShift;	     // ver�ndern und begrenzen
        if ( lCurrent > DSBPAN_RIGHT ) lCurrent = DSBPAN_RIGHT;
        if ( lCurrent < DSBPAN_LEFT ) lCurrent = DSBPAN_LEFT;
        lpdsb->SetPan( lCurrent );   // neu setzen
    }
}


/* --------------------------------------------------------

   PlayBuffer()
   Stream data to the buffer every time the current play position
   has covered half the distance.

   -------------------------------------------------------- */

BOOL PlayBuffer( void )
{
    HRESULT         hr;
    DWORD           dwPlay;
    DWORD           dwStartOfs;
    static DWORD    dwLastPlayPos;
    VOID            *lpvData;
    DWORD           dwBytesLocked;
    UINT            cbBytesRead;

    if ( lpdsb == NULL ) return FALSE;

    if ( FAILED( lpdsb->GetCurrentPosition( &dwPlay, NULL ) ) ) 
		return FALSE;

    // Wenn der Abspielcursor gerade von der ersten in die zweite H�lfte
    // des Puffers gewechselt hat oder umgekehrt, dann k�nnen wir die jeweils
    // andere H�lfte des Puffers mit neuen Daten f�llen
    if ( ( ( dwPlay >= dwMidBuffer ) && ( dwLastPlayPos < dwMidBuffer ) )
        || ( dwPlay < dwLastPlayPos ) )
    {
        dwStartOfs = ( dwPlay >= dwMidBuffer ) ? 0 : dwMidBuffer;

        hr = lpdsb->Lock( dwStartOfs,  // Start = 0 oder Mitte des Puffers
                    dwMidBuffer,       // Gr��e = halber Puffer
                    &lpvData,          // Zeiger auf den Puffer, wird gesetzt
                    &dwBytesLocked,    // Anzahl gesperrter Bytes, dito
                    NULL,              // kein zweiter Bereichsstart
                    NULL,              // keine zweite Bereichsgr��e
                    0 );               // keine speziellen Flags
  
        WaveReadFile( hmmio,             // Handle der WAV-Datei
                      dwBytesLocked,     // zu lesen = Gr��e d. Sperrbereichs
                      ( BYTE * )lpvData, // Zieladresse
                      &mmckinfo,         // data-Chunk
                      &cbBytesRead );    // Anzahl gelesener Bytes

        if ( cbBytesRead < dwBytesLocked )  // Dateiende erreicht?
        {
            if ( WaveStartDataRead( &hmmio, &mmckinfo, &mmckinfoParent ) 
				 != 0 )
            {
               OutputDebugString( "Fehler bei Repositionierung " \
                      "auf Dateianfang.\n" );

            }
            else
            {   // die noch fehlenden Bytes einlesen
                WaveReadFile( hmmio,          
                              dwBytesLocked - cbBytesRead,
                              ( BYTE * )lpvData + cbBytesRead, 
                              &mmckinfo,      
                              &cbBytesRead );    
            }
        }

        lpdsb->Unlock( lpvData, dwBytesLocked, NULL, 0 );
    }

    dwLastPlayPos = dwPlay;
    return TRUE;
} // PlayBuffer


/* --------------------------------------------------------

   InitDSound()
   Initialize DirectSound

   -------------------------------------------------------- */

BOOL InitDSound( HWND hwnd, HINSTANCE hinst, GUID *pguid )
{
    HRESULT             hr;
    DSCAPS              dscaps;
 
    // DirectSound-Objekt anlegen
    if ( FAILED( hr = DirectSoundCreate( pguid, &lpds, NULL ) ) )
        return FALSE;

    // Kooperationsebene setzen
    if ( FAILED( hr = lpds->SetCooperativeLevel( hwnd, DSSCL_PRIORITY ) ) )
        return FALSE;

    // Get capabilities; we don't actually do anything with these.
    dscaps.dwSize = sizeof( DSCAPS );
    hr = lpds->GetCaps( &dscaps );

    return TRUE;
}  // InitDSound()


/* --------------------------------------------------------

   Cleanup()
   Cleans up DirectSound objects and closes any open wave file

   -------------------------------------------------------- */

void Cleanup( void )
{
    WaveCloseReadFile( &hmmio, &pwfx );
    if ( lpds ) lpds->Release();  // This releases buffers as well.
}


/* --------------------------------------------------------

    EnumCallback()

    Enumerates available devices and populates listbox;
    called for each device by DirectInputEnumerate().

    The GUID for the device is stored as the item data for
    each string added to the list.

   -------------------------------------------------------- */

BOOL CALLBACK EnumCallback( LPGUID lpGuid,            
                            LPCSTR lpstrDescription,  
                            LPCSTR lpstrModule,       
                            LPVOID hwnd )          
{
    LONG    i;
    LPGUID  lpTemp = NULL;

	// f�r "Prim�rer Audiotreiber" hat lpGUID den Wert NULL
	if ( lpGuid != NULL )
    {
        if ( ( lpTemp = ( LPGUID )LocalAlloc( LPTR, sizeof( GUID ) ) ) == NULL )
            return TRUE;

        memcpy( lpTemp, lpGuid, sizeof( GUID ) );
    }

    // Oberfl�chenname in die Listbox setzen
    i = SendDlgItemMessage( ( HWND )hwnd, IDC_LIST1, 
                            LB_ADDSTRING, 0, 
                            ( LPARAM )lpstrDescription );

    // GUID dazu
    SendDlgItemMessage( ( HWND )hwnd, IDC_LIST1, 
                        LB_SETITEMDATA, i, ( LPARAM )lpTemp );

    return TRUE;
} // EnumCallback


#include "Global.h"
#include "Font.h"
#include "FindPathsInc.h"
#include "GameListe.h"

#define KACHEL_DISPLAY_X (((x-PersXY[y][0])-GameInfo.ScreenPosX)*KACHEL_B)-GameInfo.ScreenPixelPosX-PersXY[y][1]
#define KACHEL_DISPLAY_Y ((y-GameInfo.ScreenPosY)*KACHEL_H)-GameInfo.ScreenPixelPosY
///////////////////////////////////////////////////////////////////////////////////////
int Game(int);
void CheckGameMouse(void);
void BuildGameScene(void);
void InitGameInfo(void);
void DestroyGameBitmaps(void);
void LoadGameBitmaps(void);
void DestroyGameBitmaps(void);
void CheckGameKeys(WPARAM);
void MoveFools(void);
int CheckBefehle(int);
int CheckMouseFoolsStatus(void);
void RunPlayTime(void);
void MinusCommand(void);

void CheckLevelFool(void);

void GameSave(void);
void GameLoad(void);
void GameNewStart(void);
void GameQuit(void);
void CheckGameEnd(void);

void LoadDemo(void);
void SaveDemo(void);
void PlayDemo(void);
void RecordDemo(int);
///////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////
struct BB_MESSAGE BB_Message =
{
	NO, 0, 0, "", 0, 0, NO_AKTIV, NO_AKTIV, NO_AKTIV
};

struct BB_MESSAGE BB_SmallMessage =
{
	NO, 0, 0, "", 0, 0, NO_AKTIV, NO_AKTIV, NO_AKTIV
};
///////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////
int WINDOW_X = 0;
int WINDOW_Y = 0;
int WINDOW_BP = ScreenRes[0];  // Die Breite des Sichtbaren Fensters
int WINDOW_HP = ScreenRes[1];  // Die H�he des Sichtbaren Fensters

int ResAreaX = 20;
int ResAreaY = 20;
int WINDOW_B = ResAreaX+5;  // Die Breite des Sichtbaren Fensters
int WINDOW_H = ResAreaY+5;  // Die H�he des Sichtbaren Fensters

int PersXY[KARTEN_H_MAX][3];
int XKachelPers[KACHEL_H+4];  // Hier steht, um wie viele Pixel die Kachel bei noch oben fahren eingedr�ck werden soll(Perspective)
///////////////////////////////////////////////////////////////////////////////////////
int GameListeX;
int GameListeY;

struct SAVED_LEVEL SavedLevel;
struct SZENARIO Szenario;
struct GAME_INFO GameInfo;

int PressedMouseScroll = NO;
int CommandMenu = NO;
int CommandMenuPosX;
int CommandMenuPosY;
int CommandMenuB = 127;
int CommandMenuH = 123;
//////////////////////////////////////////////////////////////////////////////////////
struct DEMO DemoInfo;
///////////////////////////////////////////////////////////////////////////////////////
LPDIRECTDRAWSURFACE GameAusgabe;
LPDIRECTDRAWSURFACE    FoolAniPic;
LPDIRECTDRAWSURFACE    GegnerAniPic;
LPDIRECTDRAWSURFACE    PacManAniPic;
LPDIRECTDRAWSURFACE    GameListPic;
LPDIRECTDRAWSURFACE    CommandMenuPic;
LPDIRECTDRAWSURFACE    CommandMenuAniPic;
LPDIRECTDRAWSURFACE    BefehlePic;
LPDIRECTDRAWSURFACE    LadePic;
///////////////////////////////////////////////////////////////////////////////////////
#include "FoolFunk.h"
extern void CheckComAni(int);
extern struct FAST_MENU_BUTTON GameCommandMenu[];
#include "GlobalM.h"
#include "CommandMenu.h"
///////////////////////////////////////////////////////////////////////////////////////

#include "GameIsOut.h"

int Game(int Demo)
{
    MSG         msg;

    GameInfo.DemoPointer = 0;
    GameInfo.MakeADemo = NO;
	GameInfo.PlayDemo = Demo;
	if(GameInfo.PlayDemo == YES)
    	LoadDemo();
    ExitModule = NO;
    LoadWaitPic();
	InitGameListe(GAME_SCENE);
	CheckKeyModule = CheckGameKeys;
 	LoadGameBitmaps();
    LoadLevel(GameInfo.AktuellesLevel);
	LoadLevelBitmaps(Szenario.Info.SzenarioSet);
    InitGameInfo();
    SetMouseBound(0, 0, ScreenRes[0], ScreenRes[1]);
    SetMouseStyle(NORMAL_MOUSE_STYLE, YES, 1, 0, 0, 15, YES, 0);
//	SetBB_Message(" Passen Sie auf ihre Fools auf!!", 30, Szenario.Info.StartPosX, Szenario.Info.StartPosY, NO_AKTIV, NO);
	InitGetFrameRate();
	DrawMini();
    if(GameInfo.LimitedTime == YES)
    {
	    GameInfo.PlayedTimeHours = Szenario.Info.TimeHours;
	    GameInfo.PlayedTimeMin = Szenario.Info.TimeMinutes;
	    GameInfo.PlayedTimeSec = Szenario.Info.TimeSeconds;
    }
    for(;;)
    {
        if(PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
        {
            if(!GetMessage( &msg, NULL, 0, 0))
                return msg.wParam;
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
        else
            if(!gExclusive || bActive)
            {
				CheckLevelFool();
                RecordDemo(YES);
                PlayDemo();
				CheckGameEnd();
                BuildGameScene();
                CheckGameMouse();
   				CheckGameListe(GAME_SCENE);
				if(GameInfo.Pause == NO)
				{
                    RunPlayTime();
//					CheckDoorAni();
                    MoveFools();
					MoveGegner();
                }
                UpdateDisplay();
                if(ExitModule == YES || ExitProgramm == YES)
                {
                    GameIsNowOut();
                    DestroyGameBitmaps();
                    DestroyLevelBitmaps();
                    return 0;
                }
            }
            else
            {
                WaitMessage();
            }
    }
} /* Game */


void CheckLevelFool(void)
{
    int Timer;
    static int LastTimer = 0;

    Timer = timeGetTime()-LastTimer;
    if(Timer < 100)
    	return;
    LastTimer = timeGetTime();
	if(LevelFoolAniStepTurn == 0)
    {
		LevelFoolAniStep++;
        if(LevelFoolAniStep > 9)
	        LevelFoolAniStepTurn = 1;
    }
	if(LevelFoolAniStepTurn == 1)
    {
		LevelFoolAniStep--;
        if(LevelFoolAniStep < 1)
	        LevelFoolAniStepTurn = 0;
    }
	if((LevelFoolAniStepTurn == 0 || LevelFoolAniStepTurn == 1) && Mouse.Button == LEFT_MOUSE_BUTTON && PressedMouseScroll == NO &&
    	CheckMouseRect(0, 340, 80, 470) != NO_AKTIV)
    {
    	if(GameInfo.Gewonnen == YES)
			SetBB_Message("Gut gemmacht!! Gehen Sie nun ins Obtions Men�, und beenden Sie das Level!", 100, Szenario.Info.StartPosX, Szenario.Info.StartPosY, NO_AKTIV, NO);
	   	if(GameInfo.Gewonnen == NO)
			SetBB_Message("Verloren!!! Gehen Sie nun ins Obtions Men�, und beenden Sie das Level!", 100, Szenario.Info.StartPosX, Szenario.Info.StartPosY, NO_AKTIV, NO);
    }
} /* CheckLevelFool */

void CheckGameEnd(void)
{
    if(GameInfo.GameEnd == YES || GameInfo.LiveFools != 0)
    	return;
    int i, i2;

    // Alle Fools sind Tot oder im Ziel:
	LevelFoolAniStep = 0;
    LevelFoolAniStepTurn = 0;
	SetBB_Message(" Level beendet", 100, Szenario.Info.StartPosX, Szenario.Info.StartPosY, NO_AKTIV, NO);
    GameInfo.GameEnd = YES;
	for(i = 0, i2 = 0; i < MAX_FOOLS; i++)
    {
        if((Szenario.Info.FoolInfo[i].OnLive == YES || Szenario.Info.FoolInfo[i].OnLive == FINISH) && Szenario.Info.FoolInfo[i].Fool_ID != NO_AKTIV)
        	i2++;
    }
	if(i2 >= Szenario.Info.ToFinish_LiveFools)
    	GameInfo.Gewonnen = YES;
    else
    	GameInfo.Gewonnen = NO;
} /* CheckGameEnd */


void LoadGameBitmaps(void)
{
    CommandMenuPic = DDLoadBitmap(lpDD, "Bilder/Commands.bmp", 0, 0, NO);
    DDSetColorKey(CommandMenuPic, 5);
} /* LoadGameBitmaps */

void DestroyGameBitmaps(void)
{
    CommandMenuPic->Restore();
} /* DestroyGamePics */

void RunPlayTime(void)
{
    int Timer;
    static int LastTimer = 0;

    Timer = timeGetTime()-LastTimer;
    if(Timer < 1000)
    	return;
	LastTimer = timeGetTime();
    if(GameInfo.LimitedTime == NO)
    {
        GameInfo.PlayedTimeSec++;
        if(GameInfo.PlayedTimeSec > 59)
        {  // Der Spieler hat schon eine Minute an dem Level gesessen:
            GameInfo.PlayedTimeSec = 0;
            GameInfo.PlayedTimeMin++;
            if(GameInfo.PlayedTimeMin > 59)
            { // Der Spieler hat schon eine Stunde an dem Level gesessen:
                GameInfo.PlayedTimeMin = 0;
                GameInfo.PlayedTimeHours++;
                if(GameInfo.PlayedTimeHours > 23)
                { // Der Spieler wird wohl kaum einen Tag an einem Level sitzen!!
                }
            }
        }
    }
    if(GameInfo.LimitedTime == YES)
    {
        GameInfo.PlayedTimeSec--;
        if(GameInfo.PlayedTimeSec < 0)
        {  // Der Spieler hat schon eine Minute an dem Level gesessen:
            if(GameInfo.PlayedTimeMin > 0)
            {
			    GameInfo.PlayedTimeSec = 59;
                GameInfo.PlayedTimeMin--;
			}
            else
            { // Der Spieler hat schon eine Stunde an dem Level gesessen:
                if(GameInfo.PlayedTimeHours > 0)
                {
                    GameInfo.PlayedTimeSec = 59;
                    GameInfo.PlayedTimeMin = 59;
                    GameInfo.PlayedTimeHours--;
                }
                else
                { // Zeit ist abgelaufen!!:
                }
            }
        }
    }
} /* RunPlayTime */

void InitGameInfo(void)
{
    int x, y, i2, ix, iy, Pers, i;

	GameInfo.DirectControl = NO;
	GameInfo.GameEnd = NO;
    GameInfo.Gewonnen = NO;
    GameInfo.Points = 0;
	LevelFoolAniStep = NO_AKTIV;
    LevelFoolAniStepTurn = NO_AKTIV;

    WINDOW_BP = ScreenRes[0]+1;
    WINDOW_HP = ScreenRes[1]+1;
    switch(ProgrammSetup.ScreenResNr)
    {
    	case 0:
            GameListeX = ScreenRes[0]-119;
            GameListeY = 0;
        break;

    	case 1:
            GameListeX = ScreenRes[0]-119;
            GameListeY = 60;
        break;

    	case 2:
            GameListeX = ScreenRes[0]-119;
            GameListeY = 120;
        break;
    }
    GameListeY = 0;
    GameInfo.SelectedPath = NO_AKTIV;
    GameInfo.Pause = NO;
    GameInfo.LupeStep = 0;
    GameInfo.LupeTurn = 0;
    GameInfo.MenuAni = 0;
	GameInfo.PlayedTimeHours = 0;
	GameInfo.PlayedTimeMin = 0;
	GameInfo.PlayedTimeSec = 0;
	GameInfo.SelectedKachel = NO_AKTIV;
	GameInfo.SelectedFool = NO_AKTIV;
	GameInfo.SelectedFoolAni = 0;
	GameInfo.SelectedFoolAniStep = 0;
	GameInfo.AnimatedWalls = YES;
	GameInfo.PixelX = 0;
	GameInfo.PlayerPosX = 8;
	GameInfo.PlayerPosY = 6;
	GameInfo.PlayerPixelPosX = 0;
	GameInfo.PlayerPixelPosY = 0;
	GameInfo.Befehl = NO_COMMAND;
	Szenario.Info.KarteB = KARTEN_B_MAX;
	Szenario.Info.KarteH = KARTEN_H_MAX;
    for(i = 0; i < 9; i++)
	    GameCommandMenu[i].Anzahl = Szenario.Info.Commands[i];
    for(i2 = 0, y = 1, iy = 0; iy < MAX_FLOOR_PIC_H; y += KACHEL_H+1, iy++)
        for(x = 1, ix = 0; ix < MAX_FLOOR_PIC_B; x += KACHEL_B+1, ix++, i2++)
        {
            Szenario.FloorPicPos[i2][0] = x;
            Szenario.FloorPicPos[i2][1] = y;
        }
    for(i2 = 0, y = 1, iy = 0; iy < MAX_WALL_PIC_H; y += WALL_H+1, iy++)
        for(x = 1, ix = 0; ix < MAX_WALL_PIC_B; x += WALL_B+1, ix++, i2++)
        {
            Szenario.WallPicPos[i2][0] = x;
            Szenario.WallPicPos[i2][1] = y;
        }
    for(GameInfo.KachelLeftPlus = 0, Pers = 0, y = 0; y < Szenario.Info.KarteH; y++, Pers++)
        if(Pers > 3)
	    {
            Pers = 0;
        	GameInfo.KachelLeftPlus++;
        }
    for(i = 0, y = 0; y < Szenario.Info.KarteH; y++)
        for(x = 0; x < Szenario.Info.KarteB; x++, i++)
        {
        	Szenario.PosInfo[x][y] = i;
        	Szenario.Kachel[i][KACHEL_POS_X] = x;
        	Szenario.Kachel[i][KACHEL_POS_Y] = y;
        	Szenario.Kachel[i][KACHEL_PIXEL_X] = 0;
        	Szenario.Kachel[i][KACHEL_PIXEL_Y] = 0;
        }
    for(y = 0, Pers = 0, i = 0; y < Szenario.Info.KarteH; y++, i++)
	{
        if(i > 3)
        {
        	i = 0;
        	Pers++;
        }
        PersXY[y][0] = Pers;
        PersXY[y][1] = 8*i;
        PersXY[y][2] = ((Szenario.Info.KarteH/4)*(KACHEL_B-7))-((y/4)*(KACHEL_B-7));
    }
    for(y = KACHEL_H+2, i = 0, i2 = 0; y > -1; y--, i++)
	{
	    if(i > 3)
        {
        	i = 0;
            i2++;
    	}
       	XKachelPers[y] = i2;
    }
} /* InitGameInfo */

// Erstellt die Gesamte Spielfl�che, und macht sie sichtbar:
void BuildGameScene(void)
{
    char temp[50];

    DrawVirtualScene(GAME_SCENE);
    sprintf(temp, "Scoore: %d", GameInfo.Points);
    PrintText(ScreenRes[0]/2-100, 0, temp, 0, 0, 1000, 1000, Back);
} /* BuildGameScene */

// Funktion zum Abfragen der Maus:
void CheckGameMouse(void)
{
    int i, Check;

	if(ProgrammSetup.ShowGameListe == YES)
	    CheckMiniScroll(GameListeX+5, GameListeY+10);
	if(GameInfo.Pause == YES)
    { // Das Spiel ist paussiert:
    	MouseScroll();
 		return;
    }
	if(Mouse.Button == LEFT_MOUSE_BUTTON && PressedMouseScroll == NO)
	    GameListeOnOff();
	CheckMoveKeys(NO, YES);
    if(Mouse.Show == NO)
    	return;
    i = SucheKachel();
    Mouse.SelectedKachel = i;
    if(ProgrammSetup.ShowGameListe == NO && Mouse.Button == LEFT_MOUSE_BUTTON && PressedMouseScroll == NO)
    	goto CheckKachel;
    if(Mouse.Button == LEFT_MOUSE_BUTTON && PressedMouseScroll == NO && (CheckMouseRect(GameListeX, GameListeY, GameListeX+120, GameListeY+480) == NO_AKTIV))
    {
    CheckKachel:
        CheckMouseFool();
        if(CheckMouseFoolsStatus() == YES)
        	return;
        if(Mouse.SelectedKachel != NO_AKTIV)// && Szenario.Info.Kachel[Mouse.SelectedKachel].CommandConst == NO)
        {
            if(Szenario.Info.Kachel[Mouse.SelectedKachel].WallPic > DOOR_ANI)
            {
                if(Szenario.Info.Kachel[Mouse.SelectedKachel].WallPicAniStepTurn == DOOR_OPEN || Szenario.Info.Kachel[Mouse.SelectedKachel].WallPicAniStepTurn == DOOR_OPENING)
                    Szenario.Info.Kachel[Mouse.SelectedKachel].WallPicAniStepTurn = DOOR_CLOSEING;
                else
                	if(Szenario.Info.Kachel[Mouse.SelectedKachel].WallPicAniStepTurn == DOOR_CLOSE || Szenario.Info.Kachel[Mouse.SelectedKachel].WallPicAniStepTurn == DOOR_CLOSEING)
                    	Szenario.Info.Kachel[Mouse.SelectedKachel].WallPicAniStepTurn = DOOR_OPENING;
            }
            if((i != NO_AKTIV && Szenario.Info.Kachel[Mouse.SelectedKachel].Pic != NO_KACHEL &&
                Szenario.Info.Kachel[Mouse.SelectedKachel].WallPic == NO_AKTIV &&
                Szenario.Info.Kachel[Mouse.SelectedKachel].Pic < DEADLY_WALKS) ||
               (i != NO_AKTIV && Szenario.Info.Kachel[Mouse.SelectedKachel].Pic != NO_KACHEL &&
                Szenario.Info.Kachel[Mouse.SelectedKachel].WallPic > MOVE_WALLS-1 &&
                Szenario.Info.Kachel[Mouse.SelectedKachel].Pic < DEADLY_WALKS) ||
               (Szenario.Info.Kachel[Mouse.SelectedKachel].Mask > FIRST_MOVE_MASK-1 && Szenario.Info.Kachel[Mouse.SelectedKachel].Mask < FIRST_MOVE_MASK+MAX_MOVE_MASK-1))
            {
                Check = CheckMouseRichtung();
				if(GameInfo.Befehl == COMMAND_DELETE || GameInfo.Befehl == COMMAND_WAIT || GameInfo.Befehl == COMMAND_JUMP)
	                Check = GameInfo.Befehl;
                if(Check != -1)
                {
                    switch(GameInfo.Befehl)
                    {
                        case COMMAND_DELETE:
                            if(Szenario.Info.Kachel[Mouse.SelectedKachel].Command != NO_COMMAND)
                            	MinusCommand();
                            Szenario.Info.Kachel[Mouse.SelectedKachel].Command = NO_COMMAND;
                            break;

                        case COMMAND_WAIT:
                            if(Szenario.Info.Kachel[Mouse.SelectedKachel].Command != COMMAND_WAIT)
                            	MinusCommand();
                            Szenario.Info.Kachel[Mouse.SelectedKachel].Command = COMMAND_WAIT;
                            break;

                        case COMMAND_JUMP:
                            if(Szenario.Info.Kachel[Mouse.SelectedKachel].Command != COMMAND_JUMP)
                            	MinusCommand();
                            Szenario.Info.Kachel[Mouse.SelectedKachel].Command = COMMAND_JUMP;
                            break;

                        case COMMAND_WALK:
                            if(Szenario.Info.Kachel[Mouse.SelectedKachel].Command != WALK_LEFT+Check)
                            	MinusCommand();
                            Szenario.Info.Kachel[Mouse.SelectedKachel].Command = WALK_LEFT+Check;
                            break;

                        case COMMAND_PUSH:
                            if(Szenario.Info.Kachel[Mouse.SelectedKachel].Command != PUSH_LEFT+Check)
                            	MinusCommand();
                            Szenario.Info.Kachel[Mouse.SelectedKachel].Command = PUSH_LEFT+Check;
                            break;

                        case COMMAND_USE:
                            if(Szenario.Info.Kachel[Mouse.SelectedKachel].Command != USE_LEFT+Check)
                            	MinusCommand();
                            Szenario.Info.Kachel[Mouse.SelectedKachel].Command = USE_LEFT+Check;
                            break;

                        case COMMAND_TAKE:
                            if(Szenario.Info.Kachel[Mouse.SelectedKachel].Command != TAKE_LEFT+Check)
                            	MinusCommand();
                            Szenario.Info.Kachel[Mouse.SelectedKachel].Command = TAKE_LEFT+Check;
                            break;
                    }
                    Szenario.Info.Kachel[Mouse.SelectedKachel].CommandConst = NO;
                }
        	}
        }
    }
    if(Mouse.Button == RIGHT_MOUSE_BUTTON && PressedMouseScroll == NO  && (CheckMouseRect(GameListeX, GameListeY, GameListeX+120, GameListeY+480) == NO_AKTIV))
    {
        CheckCommandMenu();   // Der Spieler m�chte einen Befehl aussuchen:
        return;
    }
    MouseScroll();
} /* CheckGameMouse */

void MinusCommand(void)
{
    if(GameCommandMenu[GameInfo.Befehl-100].Anzahl == NO_LIMITED)
    	return;
    GameCommandMenu[GameInfo.Befehl-100].Anzahl--;
    if(GameCommandMenu[GameInfo.Befehl-100].Anzahl < 0)
    {
        GameCommandMenu[GameInfo.Befehl-100].Anzahl = NO_AKTIV;
        GameInfo.Befehl = NO_COMMAND;
    }
} /* MinusCommand */

void CheckGameKeys(WPARAM wParam)
{
	CheckMoveKeys(wParam, NO);
    switch(wParam)
    {
        case VK_F12:
            if(UserMessage(GameTexte[T_PROGRAMM_EXIT_ASK], NO, YES, YES) == YES)
                ExitProgramm = YES;
        break;

        case VK_F4:
			if(GameInfo.AnimatedWalls == NO)
				GameInfo.AnimatedWalls = YES;
			else
            	GameInfo.AnimatedWalls = NO;
        break;

        case VK_ESCAPE:
			GameQuit();
        break;

        case VK_F9:
            if(BB_Message.On == YES)
            {
                if(BB_Message.LastScreenPosX == NO_AKTIV)
                {
                    BB_Message.LastScreenPosX = GameInfo.ScreenPosX;
                    BB_Message.LastScreenPosY = GameInfo.ScreenPosY;
                    BB_Message.LastScreenPixelPosX = GameInfo.ScreenPixelPosX;
                    BB_Message.LastScreenPixelPosY = GameInfo.ScreenPixelPosY;
                    GameInfo.ScreenPosX = BB_Message.ScreenPosX;
                    GameInfo.ScreenPosY = BB_Message.ScreenPosY;
                    GameInfo.ScreenPixelPosX = BB_Message.ScreenPixelPosX;
                    GameInfo.ScreenPixelPosY = BB_Message.ScreenPixelPosY;
            	}
                else
                {
                    GameInfo.ScreenPosX = BB_Message.LastScreenPosX;
                    GameInfo.ScreenPosY = BB_Message.LastScreenPosY;
                    GameInfo.ScreenPixelPosX = BB_Message.LastScreenPixelPosX;
                    GameInfo.ScreenPixelPosY = BB_Message.LastScreenPixelPosY;
                    BB_Message.LastScreenPosX = NO_AKTIV;
                    BB_Message.LastScreenPosY = NO_AKTIV;
                    BB_Message.LastScreenPixelPosX = NO_AKTIV;
                    BB_Message.LastScreenPixelPosY = NO_AKTIV;
                }
            }
            else
            {
                if(BB_Message.LastScreenPosX != NO_AKTIV)
                {
                    GameInfo.ScreenPosX = BB_Message.LastScreenPosX;
                    GameInfo.ScreenPosY = BB_Message.LastScreenPosY;
                    GameInfo.ScreenPixelPosX = BB_Message.LastScreenPixelPosX;
                    GameInfo.ScreenPixelPosY = BB_Message.LastScreenPixelPosY;
                    BB_Message.LastScreenPosX = NO_AKTIV;
                    BB_Message.LastScreenPosY = NO_AKTIV;
                    BB_Message.LastScreenPixelPosX = NO_AKTIV;
                    BB_Message.LastScreenPixelPosY = NO_AKTIV;
				}
            }
        break;

        case VK_F1:
            if(ProgrammSetup.GameSpeed > 0)
	            ProgrammSetup.GameSpeed--;
        break;

        case VK_F2:
            if(ProgrammSetup.GameSpeed < 3000)
	            ProgrammSetup.GameSpeed++;
        break;

        case VK_F3:
			if(ProgrammSetup.GameLongWalls == YES)
	            ProgrammSetup.GameLongWalls = NO;
            else
	            ProgrammSetup.GameLongWalls = YES;
        break;

        case VK_F5:
			if(ProgrammSetup.GameMouseTrans == YES)
	            ProgrammSetup.GameMouseTrans = NO;
            else
	            ProgrammSetup.GameMouseTrans = YES;
        break;

        case VK_F6:
			if(ProgrammSetup.GameSelectedTrans == YES)
	            ProgrammSetup.GameSelectedTrans = NO;
            else
	            ProgrammSetup.GameSelectedTrans = YES;
        break;

        case 0x50:
//        case VK_P:
			if(GameInfo.Pause == YES)
	            GameInfo.Pause = NO;
            else
	            GameInfo.Pause = YES;
        break;

        case VK_F7:
			if(ProgrammSetup.ShowFoolPower == YES)
	            ProgrammSetup.ShowFoolPower = NO;
            else
	            ProgrammSetup.ShowFoolPower = YES;
        break;

        case VK_F11:
			if(ProgrammSetup.ShowFoolName == YES)
	            ProgrammSetup.ShowFoolName = NO;
            else
	            ProgrammSetup.ShowFoolName = YES;
        break;

        case VK_TAB:
			if(ProgrammSetup.ShowGameListe == YES)
	            ProgrammSetup.ShowGameListe = NO;
            else
	            ProgrammSetup.ShowGameListe = YES;
        break;

        case VK_SPACE:
			if(GameInfo.MakeADemo == YES)
            {
                GameInfo.MakeADemo = NO;
                SaveDemo();
            }
            else
	        {
				SetBB_Message("Starte Demo Aufnahme...", 30, -1, -1, NO_AKTIV, NO);
                GameInfo.MakeADemo = YES;
                GameInfo.DemoPointer = 0;
                DemoInfo.DemoStarts[0] = (short)GameInfo.ScreenPosX;
                DemoInfo.DemoStarts[1] = (short)GameInfo.ScreenPosY;
                DemoInfo.DemoStarts[2] = (short)GameInfo.ScreenPixelPosX;
                DemoInfo.DemoStarts[3] = (short)GameInfo.ScreenPixelPosY;
                DemoInfo.DemoStarts[4] = (short)GameInfo.Befehl;
            }
        break;

        case VK_RETURN:
            GameInfo.DemoPointer = 0;
            GameInfo.MakeADemo = NO;
            GameInfo.PlayDemo = NO;
        break;

        case VK_BACK:
	        LoadLevel(GameInfo.AktuellesLevel);
	    	DrawMini();
            GameInfo.DemoPointer = 0;
            GameInfo.MakeADemo = NO;
            GameInfo.PlayDemo = YES;
            GameInfo.ScreenPosX = DemoInfo.DemoStarts[0];
            GameInfo.ScreenPosY = DemoInfo.DemoStarts[1];
            GameInfo.ScreenPixelPosX = DemoInfo.DemoStarts[2];
            GameInfo.ScreenPixelPosY = DemoInfo.DemoStarts[3];
            GameInfo.Befehl = DemoInfo.DemoStarts[4];
        break;
    }
} /* CheckGameKeys */

int CheckMouseFoolsStatus(void)
{
	int i, i2;

    if(GameInfo.LiveFools == 0 && GameInfo.DeadFools == 0)
	    GameInfo.SelectedFool = NO_AKTIV;
    if(Mouse.XPos > 5 && Mouse.XPos < 25 &&
        Mouse.YPos > 5 && Mouse.YPos < 35)
    { // Der Spieler sucht nach seinen Lebenden Fools:
        if(TimerNew2 == YES)
            TimerNew2 = NO;
        else
            return YES;
        for(i = GameInfo.SelectedFool, i2 = 0; ; i++, i2++)
        {
            if(Szenario.Info.FoolInfo[i].OnLive == YES && Szenario.Info.FoolInfo[i].Fool_ID != NO_AKTIV &&
                i != GameInfo.SelectedFool)
                {
                    GameInfo.SelectedFool = i;
                    SetBB_Message(GameTexte[T_FOOL_ON_LIFE], 20, Szenario.Info.FoolInfo[i].PosX, Szenario.Info.FoolInfo[i].PosY, NO_AKTIV, YES);
                    break;
                }
            if(i > MAX_FOOLS)
                i = 0;
            if(i2 > MAX_FOOLS)
            {
                if(GameInfo.SelectedFool != NO_AKTIV)
                {
                    if(Szenario.Info.FoolInfo[i].OnLive == NO)
                        GameInfo.SelectedFool = NO_AKTIV;
					else
                    	SetBB_Message(GameTexte[T_LAST_LIFE_FOOL], 20, Szenario.Info.FoolInfo[i].PosX, Szenario.Info.FoolInfo[i].PosY, NO_AKTIV, YES);
                }
                if(GameInfo.SelectedFool == NO_AKTIV)
                	SetBB_Message(GameTexte[T_THERE_IST_NO_FOOL_ON_LIFE], 20, Szenario.Info.FoolInfo[i].PosX, Szenario.Info.FoolInfo[i].PosY, NO_AKTIV, NO);
                break;
            }
        }
    	return YES;
    }
    if(Mouse.XPos > 5 && Mouse.XPos < 25 &&
        Mouse.YPos > 40 && Mouse.YPos < 80)
     // Der Spieler sucht nach seinen Lebenden Fools:
    {
        if(TimerNew2 == YES)
            TimerNew2 = NO;
        else
            return YES;
        if(GameInfo.DeadFools != 0)
        {
            for(i = GameInfo.SelectedFool, i2 = 0; ; i++, i2++)
            {
                if(Szenario.Info.FoolInfo[i].OnLive == NO && Szenario.Info.FoolInfo[i].Fool_ID != NO_AKTIV &&
                    i != GameInfo.SelectedFool)
                    {
                        GameInfo.SelectedFool = i;
                        SetBB_Message(GameTexte[T_HERE_DIES_A_FOOL], 10, Szenario.Info.FoolInfo[i].PosX, Szenario.Info.FoolInfo[i].PosY, NO_AKTIV, YES);
                        break;
                    }
                if(i > MAX_FOOLS)
                    i = 0;
                if(i2 > MAX_FOOLS)
                    break;
            }
        }
        else
            SetBB_Message(GameTexte[T_ON_THIS_TIME_NO_FOOL_IS_DEAD], 20, Szenario.Info.FoolInfo[i].PosX, Szenario.Info.FoolInfo[i].PosY, NO_AKTIV, NO);
    	return YES;
	}
   	return NO;
} /* CheckMouseFoolsStatus */

///////////////////////////////////////////////////////////////
void GameSave(void)
{
   	UserMessage("Spiel Speichern noch nicht eingebaut!", YES, NO, NO);
} /* GameSave */

void GameLoad(void)
{
   	UserMessage("Spiel Laden noch nicht eingebaut!", YES, NO, NO);
} /* GameLoad */

void GameNewStart(void)
{
   	if(UserMessage(GameTexte[T_START_THE_LEVEL_REALY_NEW], NO, YES, YES) == YES_BUTTON)
	{
        LoadLevel(GameInfo.AktuellesLevel);
    	DrawMini();
    }
} /* GameNewStart */

void GameQuit(void)
{
   	if(UserMessage(GameTexte[T_REALY_EXIT_THE_LEVEL_ASK], NO, YES, YES) == YES_BUTTON)
	{
    	ExitModule = YES;
    }
} /* GameQuit */
///////////////////////////////////////////////////////////////

void LoadDemo(void)
{
    char temp[100];
    int datei;

    sprintf(temp, "Demos/%s.dem", "Demo");
    datei = open(temp, O_RDONLY | O_BINARY);
    read(datei, &DemoInfo, sizeof(DemoInfo));
    close(datei);
   	stpcpy(GameInfo.AktuellesLevel, DemoInfo.LevelName);
} /* LoadDemo */

void SaveDemo(void)
{
    char temp[100];
    int datei;

   	sprintf(DemoInfo.LevelName, "%s.lev", GameInfo.AktuellesLevel);
    DemoInfo.DemoInfoTime[GameInfo.DemoPointer] = NO_AKTIV;
    sprintf(temp, "Demos/%s.dem", "Demo");
    chmod(temp, S_IREAD | S_IWRITE);
    unlink(temp);
    datei = open(temp, O_WRONLY | O_CREAT | O_BINARY);
    write(datei, &DemoInfo, sizeof(DemoInfo));
    close(datei);
    sprintf(temp, " Demo Gesichert!");
	SetBB_Message(temp, 30, -1, -1, NO_AKTIV, NO);
} /* SaveDemo */

void PlayDemo(void)
{
	if(GameInfo.PlayDemo == NO)
    	return;
    int Timer;
    static int LastTimer = 0;

    Timer = timeGetTime()-LastTimer;
    if(Timer < DemoInfo.DemoInfoTime[GameInfo.DemoPointer])
    	return;
	LastTimer = timeGetTime();
    Mouse.VorLastXPos = Mouse.LastXPos;
    Mouse.VorLastYPos = Mouse.LastYPos;
    Mouse.LastXPos = Mouse.XPos;
    Mouse.LastYPos = Mouse.YPos;
    Mouse.XPos = DemoInfo.DemoInfo[GameInfo.DemoPointer][0];
    Mouse.YPos = DemoInfo.DemoInfo[GameInfo.DemoPointer][1];
    Mouse.Button = DemoInfo.DemoInfo[GameInfo.DemoPointer][2];
    if(GameInfo.DemoPointer < MAX_DEMO_POINTER+1)
        GameInfo.DemoPointer++;
    if(DemoInfo.DemoInfoTime[GameInfo.DemoPointer] == NO_AKTIV)
    {
	    GameInfo.PlayDemo = NO;
		SetBB_Message("Demo Beendet!!!", 30, -1, -1, NO_AKTIV, NO);
    }
} /* PlayDemo */

void RecordDemo(int Button)
{
    int MouseButtonTimer;
    static int MouseButtonLastTimer = 0;

    if(GameInfo.PlayDemo == YES)
    	return;
    if(Button == YES)
    {
		if(Mouse.Button != LEFT_MOUSE_BUTTON && Mouse.Button != RIGHT_MOUSE_BUTTON && Mouse.Button != BOTH_MOUSE_BUTTON)
        	return;
    }
    MouseButtonTimer = timeGetTime()-MouseButtonLastTimer;
    MouseButtonLastTimer = timeGetTime();
    DemoInfo.DemoInfoTime[GameInfo.DemoPointer] = MouseButtonTimer;
    if(GameInfo.MakeADemo == NO)
    	return;
    DemoInfo.DemoInfo[GameInfo.DemoPointer][0] = (short)Mouse.XPos;
    DemoInfo.DemoInfo[GameInfo.DemoPointer][1] = (short)Mouse.YPos;
    DemoInfo.DemoInfo[GameInfo.DemoPointer][2] = (short)Mouse.Button;
    if(GameInfo.DemoPointer < MAX_DEMO_POINTER)
        GameInfo.DemoPointer++;
    else
    {
        SetBB_Message("Aufzeichnung beendet!!!", 30, -1, -1, NO_AKTIV, NO);
        GameInfo.MakeADemo  = NO;
    }
} /* RecordDemo */



extern void UpdateDisplay(void);

#define USER_MESSAGE_X (ScreenRes[0]/2-210)
#define USER_MESSAGE_Y (ScreenRes[1]/2-130)
#define USER_MESSAGE_B 420
#define USER_MESSAGE_H 260
#define USER_MESSAGE_OVERLAY 20
#define USER_MESSAGE_PART_B 240

int UserMessage(char *, int, int, int);
void LoadMessageBitmaps(void);
void DestroyMessageBitmaps(void);
void CheckUserMessageMouse(int, int, int);
void BuiltUserMessageScene(char *, int, int, int);
void CheckUserMessageKeys(WPARAM);
void OpenUserMessage(int, int, int);
void CloseUserMessage(int, int, int);
void OK(void);
void Ja(void);
void Nein(void);

LPDIRECTDRAWSURFACE UserMessagePic;

#define MAX_USER_MESSAGE_BUTTONS 3
#define USER_MESSAGE_BUTTON_B 130
#define USER_MESSAGE_BUTTON_H 30

struct ANIMATE_BUTTON UserMessageButtons[MAX_USER_MESSAGE_BUTTONS+1] =
{
    {50, 50, USER_MESSAGE_X+60, USER_MESSAGE_Y+140, 0, 0, 0, 0, 0, YES, YES, T_OK, OK, YES},
    {50, 100, USER_MESSAGE_X+60, USER_MESSAGE_Y+180, 1, 0, 0, 0, 0, YES, YES, T_YES, Ja, YES},
    {50, 150, USER_MESSAGE_X+60,USER_MESSAGE_Y+220, 2, 0, 0, 0, 0, YES, YES, T_NO, Nein, YES},
    {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, NO},
};

int PressedUserMessageButton;

int UserMessage(char *Text, int OKButton, int JaButton, int NeinButton)
{
    MSG         msg;
    int x, y, xb, yh;
	void (*SavedCheckKeyModule)(WPARAM);

    ExitModule = NO;
	PressedUserMessageButton = NO_AKTIV;
	SavedCheckKeyModule = CheckKeyModule;
    x = Mouse.BoundX;
    y = Mouse.BoundY;
    xb = Mouse.BoundXB;
    yh = Mouse.BoundYH;
	CheckKeyModule = CheckUserMessageKeys;
    SetMouseBound(USER_MESSAGE_X, USER_MESSAGE_Y, USER_MESSAGE_X+USER_MESSAGE_B-Mouse.CursorB, USER_MESSAGE_Y+USER_MESSAGE_H-Mouse.CursorH);
    SetMouseStyle(NORMAL_MOUSE_STYLE, YES, 1, 0, 0, 15, YES, 0);
    LoadMessageBitmaps();
    OpenUserMessage(OKButton, JaButton, NeinButton);
    for(;;)
    {
        if(PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
        {
            if(!GetMessage( &msg, NULL, 0, 0))
                return msg.wParam;
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
        else
            if(!gExclusive || bActive)
            {
				CheckUserMessageMouse(OKButton, JaButton, NeinButton);
				BuiltUserMessageScene(Text, OKButton, JaButton, NeinButton);
                UpdateDisplay();
                if(ExitModule == YES || ExitProgramm == YES)
                {
                    ExitModule = NO;
				    CloseUserMessage(OKButton, JaButton, NeinButton);
                    DestroyMessageBitmaps();
					CheckKeyModule = SavedCheckKeyModule;
				    SetMouseBound(x, y, xb, yh);
					return PressedUserMessageButton;
                }
            }
            else
                WaitMessage();
    }
} /* User */

void LoadMessageBitmaps(void)
{
    UserMessagePic = DDLoadBitmap(lpDD, "Bilder/Message.bmp", 0, 0, NO);
    DDSetColorKey(UserMessagePic, 5);
	UserMessagePic->Restore();
} /* LoadMessageBitmaps */

void DestroyMessageBitmaps(void)
{
	UserMessagePic->Restore();
} /* DestroyMessageBitmaps */

void CheckUserMessageMouse(int OKButton, int JaButton, int NeinButton)
{
    int i, i2;
    int MouseButtonTimer;
    static int MouseButtonLastTimer = 0;

    MouseButtonTimer = timeGetTime()-MouseButtonLastTimer;
    if(MouseButtonTimer < 70)
    	return;
    MouseButtonLastTimer = timeGetTime();
   // Pr�ft, ob sich die Maus auf einem Button befindet:
	for(i = 0; i < MAX_USER_MESSAGE_BUTTONS; i++)
    {
        if((i == 0 && OKButton == NO) || (i == 1 && JaButton == NO) || (i == 2 && NeinButton == NO))
        	continue;
    	if(CheckMouseRect(UserMessageButtons[i].X, UserMessageButtons[i].Y, UserMessageButtons[i].X+USER_MESSAGE_BUTTON_B, UserMessageButtons[i].Y+USER_MESSAGE_BUTTON_H) != NO_AKTIV)
        	break;
  	}
    CheckButtonLight(&UserMessageButtons[0], i);
    if(i < MAX_USER_MESSAGE_BUTTONS)
    {
	    if(Mouse.Button == LEFT_MOUSE_BUTTON && UserMessageButtons[i].Aktiv == YES)
			if(UserMessageButtons[i].Funktion != 0)
	        {
                UserMessageButtons[i].Funktion();
            }
    }
    else
        for(i2 = 0; i2 < MAX_USER_MESSAGE_BUTTONS; i2++)
            UserMessageButtons[i2].Selected = NO;
} /* CheckUserMessageMouse */

void BuiltUserMessageScene(char *Text, int OKButton, int JaButton, int NeinButton)
{
    RECT rcRect;
    int i;

    SetRect(&rcRect, 0, 0, ScreenRes[0], ScreenRes[1]);
    Back->BltFast(0, 0, GameAusgabe, &rcRect, FALSE);
    rcRect.left   = 1;
    rcRect.top    = 1;
    rcRect.right  = 1+USER_MESSAGE_PART_B;
    rcRect.bottom = 1+USER_MESSAGE_H;
    Back->BltFast(USER_MESSAGE_X, USER_MESSAGE_Y, UserMessagePic, &rcRect, DDBLTFAST_SRCCOLORKEY);
    rcRect.left   = 2+USER_MESSAGE_PART_B;
    rcRect.top    = 1;
    rcRect.right  = 2+USER_MESSAGE_PART_B+USER_MESSAGE_PART_B;
    rcRect.bottom = 1+USER_MESSAGE_H;
    Back->BltFast(USER_MESSAGE_X+USER_MESSAGE_PART_B-(USER_MESSAGE_OVERLAY*2), USER_MESSAGE_Y, UserMessagePic, &rcRect, DDBLTFAST_SRCCOLORKEY);
    for(i = 0; i < MAX_USER_MESSAGE_BUTTONS; i++)
    {
        if((i == 0 && OKButton == NO) || (i == 1 && JaButton == NO) || (i == 2 && NeinButton == NO))
        	continue;
        rcRect.left   = 1;
        rcRect.top    = 262;
        rcRect.right  = 131;
        rcRect.bottom = 292;
        Back->BltFast(UserMessageButtons[i].X, UserMessageButtons[i].Y, UserMessagePic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        rcRect.left   = 132+(31*UserMessageButtons[i].SelectedStep);
        rcRect.top    = 262;
        rcRect.right  = 132+(31*UserMessageButtons[i].SelectedStep)+30;
        rcRect.bottom = 292;
        if(UserMessageButtons[i].LeftLight == YES)
            Back->BltFast(UserMessageButtons[i].X, UserMessageButtons[i].Y+8, UserMessagePic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        if(UserMessageButtons[i].RightLight == YES)
            Back->BltFast(UserMessageButtons[i].X+USER_MESSAGE_BUTTON_B-30, UserMessageButtons[i].Y, UserMessagePic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        if(UserMessageButtons[i].Text != -1)
	        PrintText(UserMessageButtons[i].X+30, UserMessageButtons[i].Y+5, GameTexte[UserMessageButtons[i].Text], 0, 0, 1000, 1000, Back);
    }
    PrintText(USER_MESSAGE_X+30, USER_MESSAGE_Y+30, Text, 0, 0, 1000, 1000, Back);
    SetMouseCursorPic();
} /* BuiltUserMessageScene */

void CheckUserMessageKeys(WPARAM wParam)
{
    switch(wParam)
    {
        case VK_ESCAPE:
			ExitModule = YES;
        break;

        case VK_F12:
			ExitProgramm = YES;
        break;
	}
} /* CheckUserMessageKeys */

void OpenUserMessage(int OKButton, int JaButton, int NeinButton)
{
    RECT rcRect;
    int x, x2, i;

   // Hintergrund sichern:
    SetRect(&rcRect, 0, 0, ScreenRes[0], ScreenRes[1]);
    GameAusgabe->BltFast(0, 0, Back, &rcRect, FALSE);
    for(i = 0, x = USER_MESSAGE_X-50; i < MAX_USER_MESSAGE_BUTTONS; i++, x += USER_MESSAGE_BUTTON_B+10)
    {
		UserMessageButtons[i].X = x;
		UserMessageButtons[i].Y = 0;
        UserMessageButtons[i].X += USER_MESSAGE_X-USER_MESSAGE_OVERLAY;
        UserMessageButtons[i].Y += USER_MESSAGE_Y+170;
    }
    for(x = USER_MESSAGE_X+(USER_MESSAGE_PART_B/2-USER_MESSAGE_OVERLAY), x2 = USER_MESSAGE_X+(USER_MESSAGE_PART_B/2-USER_MESSAGE_OVERLAY); x > USER_MESSAGE_X; x -= 4, x2 += 4)
    {
	    SetRect(&rcRect, 0, 0, ScreenRes[0], ScreenRes[1]);
	    Back->BltFast(0, 0, GameAusgabe, &rcRect, FALSE);
        rcRect.left   = 1;
        rcRect.top    = 1;
        rcRect.right  = 1+USER_MESSAGE_PART_B;
        rcRect.bottom = 1+USER_MESSAGE_H;
        Back->BltFast(x, USER_MESSAGE_Y, UserMessagePic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        rcRect.left   = 2+USER_MESSAGE_PART_B;
        rcRect.top    = 1;
        rcRect.right  = 2+USER_MESSAGE_PART_B+USER_MESSAGE_PART_B;
        rcRect.bottom = 1+USER_MESSAGE_H;
        Back->BltFast(x2, USER_MESSAGE_Y, UserMessagePic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        for(i = 0; i < MAX_USER_MESSAGE_BUTTONS; i++)
        {
            if((i == 0 && OKButton == NO) || (i == 1 && JaButton == NO) || (i == 2 && NeinButton == NO))
                continue;
            rcRect.left   = 1;
            rcRect.top    = 262;
            rcRect.right  = 131;
            rcRect.bottom = 292;
            Back->BltFast(UserMessageButtons[i].X, UserMessageButtons[i].Y, UserMessagePic, &rcRect, DDBLTFAST_SRCCOLORKEY);
            rcRect.left   = 132+(31*UserMessageButtons[i].SelectedStep);
            rcRect.top    = 262;
            rcRect.right  = 132+(31*UserMessageButtons[i].SelectedStep)+30;
            rcRect.bottom = 292;
        	if(UserMessageButtons[i].LeftLight == YES)
                Back->BltFast(UserMessageButtons[i].X, UserMessageButtons[i].Y, UserMessagePic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        	if(UserMessageButtons[i].RightLight == YES)
                Back->BltFast(UserMessageButtons[i].X+USER_MESSAGE_BUTTON_B-30, UserMessageButtons[i].Y, UserMessagePic, &rcRect, DDBLTFAST_SRCCOLORKEY);
	        if(UserMessageButtons[i].Text != -1)
    	        PrintText(UserMessageButtons[i].X+30, UserMessageButtons[i].Y+5, GameTexte[UserMessageButtons[i].Text], 0, 0, 43, 40, Back);
            UserMessageButtons[i].X -= 4;
        }
        UpdateDisplay();
    }
} /* OpenUserMessage */

void CloseUserMessage(int OKButton, int JaButton, int NeinButton)
{
    RECT rcRect;
    int x, x2, i;

    for(x = USER_MESSAGE_X, x2 = USER_MESSAGE_X+USER_MESSAGE_PART_B-USER_MESSAGE_OVERLAY; x < USER_MESSAGE_X+(USER_MESSAGE_PART_B/2-USER_MESSAGE_OVERLAY); x += 4, x2 -= 4)
    {
	    SetRect(&rcRect, 0, 0, ScreenRes[0], ScreenRes[1]);
	    Back->BltFast(0, 0, GameAusgabe, &rcRect, FALSE);
        rcRect.left   = 1;
        rcRect.top    = 1;
        rcRect.right  = 1+USER_MESSAGE_PART_B;
        rcRect.bottom = 1+USER_MESSAGE_H;
        Back->BltFast(x, USER_MESSAGE_Y, UserMessagePic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        rcRect.left   = 2+USER_MESSAGE_PART_B;
        rcRect.top    = 1;
        rcRect.right  = 2+USER_MESSAGE_PART_B+USER_MESSAGE_PART_B;
        rcRect.bottom = 1+USER_MESSAGE_H;
        Back->BltFast(x2, USER_MESSAGE_Y, UserMessagePic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        for(i = 0; i < MAX_USER_MESSAGE_BUTTONS; i++)
        {
            if((i == 0 && OKButton == NO) || (i == 1 && JaButton == NO) || (i == 2 && NeinButton == NO))
                continue;
            rcRect.left   = 1;
            rcRect.top    = 262;
            rcRect.right  = 131;
            rcRect.bottom = 292;
            Back->BltFast(UserMessageButtons[i].X, UserMessageButtons[i].Y, UserMessagePic, &rcRect, DDBLTFAST_SRCCOLORKEY);
            rcRect.left   = 132+(31*UserMessageButtons[i].SelectedStep);
            rcRect.top    = 262;
            rcRect.right  = 132+(31*UserMessageButtons[i].SelectedStep)+30;
            rcRect.bottom = 292;
        	if(UserMessageButtons[i].LeftLight == YES)
                Back->BltFast(UserMessageButtons[i].X, UserMessageButtons[i].Y, UserMessagePic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        	if(UserMessageButtons[i].RightLight == YES)
                Back->BltFast(UserMessageButtons[i].X+USER_MESSAGE_BUTTON_B-30, UserMessageButtons[i].Y, UserMessagePic, &rcRect, DDBLTFAST_SRCCOLORKEY);
            if(UserMessageButtons[i].Text != -1)
                PrintText(UserMessageButtons[i].X+30, UserMessageButtons[i].Y+5, GameTexte[UserMessageButtons[i].Text], 0, 0, 43, 40, Back);
            UserMessageButtons[i].X += 4;
        }
        UpdateDisplay();
    }
   // Hintergrund wiederherstellen:
    SetRect(&rcRect, 0, 0, ScreenRes[0], ScreenRes[1]);
    Back->BltFast(0, 0, GameAusgabe, &rcRect, FALSE);
} /* CloseUserMessage */

void OK(void)
{
	PressedUserMessageButton = OK_BUTTON;
    ExitModule = YES;
} /* OK */

void Ja(void)
{
	PressedUserMessageButton = YES_BUTTON;
    ExitModule = YES;
} /* Ja */

void Nein(void)
{
	PressedUserMessageButton = NO_BUTTON;
    ExitModule = YES;
} /* Nein */


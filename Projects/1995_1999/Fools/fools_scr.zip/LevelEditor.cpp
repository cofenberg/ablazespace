#include "Global.h"

#define MAX_PATHS 30
struct PATHS {char PathName[256];};
struct PATHS SzenarioPaths[MAX_PATHS];
extern void FindSzenarios(void);
extern void FindLevels(void);
extern void ChangeSzenario(void);


#include "GameListeInc.h"

// Die verschiedenen Editor Auswahl Seiten:
#define EDITOR_WAYS        FLOOR
#define EDITOR_ANI_WAYS    FLOOR_ANI
#define EDITOR_WALLS       WALLS
#define EDITOR_ANI_WALLS   WALL_ANI
#define EDITOR_DEADLY      DEADLY_WALKS
#define EDITOR_ANI_DEADLY  DEADLY_WALKS_ANI
#define EDITOR_PUSHES      MOVE_WALLS
#define EDITOR_ANI_DOORS   DOOR_ANI
#define EDITOR_INTEMS      FIRST_INTEM
#define EDITOR_OBJECTS     FIRST_OBJECT
///////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////
extern int GameListeX, GameListeY;

void EndProgramm(void);

extern void RunPlayTime(void);
extern void InitGameInfo(void);

void NewLevel(void);
void LoadEditorBitmaps(void);
void DestroyEditorBitmaps(void);
void LoadEditorLevel(void);
void BuildEditorScene(void);
void InitEditorInfo(void);
void CheckEditorKeys(WPARAM);
void CheckEditorMouse(void);

void EditorSave(void);
void EditorLoad(void);
void EditorQuit(void);
void EditorNewLevel(void);

void CheckEditorSetChange(void);
/////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////
int InfoVar = 0;
int Editor_SetKachel = 0;
int Editor_SetKachelAni = 0;
int EditorKachelMenu[3];

int SetAnimationCircle, SetAnimationLeftRight, SetAnimationLeftRightTurn, SetAnimationRandom; // Zum festlegen, des Animationsverlaufes
///////////////////////////////////////////////////////////////////////////////////////
extern void LoadIntroBitmaps(void);
extern void PlayIntro(void);

///////////////////////////////////////////////////////////////////////////////////////
int LevelEditor(void)
{
    MSG         msg;

    ExitModule = NO;
    LoadWaitPic();
	InitGameListe(EDITOR_SCENE);
	CheckKeyModule = CheckEditorKeys;
 	LoadEditorBitmaps();
	stpcpy(Szenario.Info.SzenarioSet, "Starship");
	LoadLevelBitmaps(Szenario.Info.SzenarioSet);
    InitGameInfo();
    InitEditorInfo();
    SetMouseBound(0, 0, ScreenRes[0], ScreenRes[1]);
    SetMouseStyle(NORMAL_MOUSE_STYLE, YES, 1, 0, 0, 15, YES, 0);
    NewLevel();
	InitGetFrameRate();
	DrawMini();
    for(;;)
    {
        if(PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
        {
            if(!GetMessage(&msg, NULL, 0, 0))
                return msg.wParam;
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
        else
            if(!gExclusive || bActive)
            {
                BuildEditorScene();
                CheckEditorMouse();
				CheckGameListe(EDITOR_SCENE);
                UpdateDisplay();
                if(ExitModule == YES || ExitProgramm == YES)
                {
                    DestroyEditorBitmaps();
                    DestroyLevelBitmaps();
					return 0;
                }
            }
            else
            {
                WaitMessage();
            }
    }
} /* LevelEditor */
///////////////////////////////////////////////////////////////////////////////////////

void LoadEditorBitmaps(void)
{
} /* LoadEditorBitmaps */

void DestroyEditorBitmaps(void)
{
} /* DestroyEditorBitmaps */

void InitEditorInfo(void)
{
	GameInfo.GameListe.OptionsDown = YES;
	GameInfo.AnimatedWalls = YES;
	Editor_SetKachel = 0;
	Editor_SetKachelAni = 0;
	EditorKachelMenu[KACHEL_MENU_ON] = NO;
	EditorKachelMenu[KACHEL_MENU_PAGE] = 0;
    SetAnimationCircle = YES;
    SetAnimationLeftRight = NO;
    SetAnimationLeftRightTurn = 0;
    SetAnimationRandom = YES;
} /* InitEditorInfo */

void CheckEditorKeys(WPARAM wParam)
{
    int i;

    switch(wParam)
    {
        case VK_F12:
            if(UserMessage(GameTexte[T_PROGRAMM_EXIT_ASK], NO, YES, YES) == YES)
                ExitProgramm = YES;
        break;

        case VK_ESCAPE:
			EditorQuit();
        break;

        case VK_NUMPAD0:
            if(Editor_SetKachel > 0)
            	Editor_SetKachel--;
	        GameInfo.Befehl = NO_COMMAND;
        break;

        case VK_NUMPAD1:
            if(Editor_SetKachel < MAX_KACHEL_PICS)
                Editor_SetKachel++;
	        GameInfo.Befehl = NO_COMMAND;
        break;

        case VK_NUMPAD4:
	    	Editor_SetKachel = FLOOR;
	        GameInfo.Befehl = NO_COMMAND;
        break;

        case VK_NUMPAD7:
	    	Editor_SetKachel = FLOOR_ANI;
	        GameInfo.Befehl = NO_COMMAND;
        break;

        case VK_NUMPAD9:
		    Editor_SetKachel = DEADLY_WALKS;
	        GameInfo.Befehl = NO_COMMAND;
        break;

        case VK_NUMPAD6:
		    Editor_SetKachel = DEADLY_WALKS_ANI;
	        GameInfo.Befehl = NO_COMMAND;
        break;

        case VK_NUMPAD8:
		    Editor_SetKachel = WALLS;
	        GameInfo.Befehl = NO_COMMAND;
        break;

        case VK_NUMPAD5:
		    Editor_SetKachel = WALL_ANI;
	        GameInfo.Befehl = NO_COMMAND;
        break;

        case VK_NUMPAD3:
		    Editor_SetKachel = MOVE_WALLS;
	        GameInfo.Befehl = NO_COMMAND;
        break;

        case VK_LEFT:
	        if(GameInfo.DirectControl == YES)
            {
            	Szenario.Info.PacManInfo[GameInfo.SelectedFool-FIRST_PACMAN].Befehl = WALK_LEFT;
	    	}
	    	else
            	MoveScreenLeft(SCROLL_SPEED);
        break;

        case VK_RIGHT:
	        if(GameInfo.DirectControl == YES)
            {
            	Szenario.Info.PacManInfo[GameInfo.SelectedFool-FIRST_PACMAN].Befehl = WALK_RIGHT;
	    	}
	    	else
	    		MoveScreenRight(SCROLL_SPEED);
        break;

        case VK_UP:
	        if(GameInfo.DirectControl == YES)
            {
            	Szenario.Info.PacManInfo[GameInfo.SelectedFool-FIRST_PACMAN].Befehl = WALK_UP;
	    	}
            else
	    		MoveScreenUp(SCROLL_SPEED);
        break;

        case VK_DOWN:
	        if(GameInfo.DirectControl == YES)
            {
            	Szenario.Info.PacManInfo[GameInfo.SelectedFool-FIRST_PACMAN].Befehl = WALK_DOWN;
	    	}
            else
		    	MoveScreenDown(SCROLL_SPEED);
        break;

        case VK_F4:
			if(GameInfo.AnimatedWalls == NO)
				GameInfo.AnimatedWalls = YES;
			else
            	GameInfo.AnimatedWalls = NO;
            for(i = 0; i < (Szenario.Info.KarteB*Szenario.Info.KarteH); i++) // Alle Animationen auf Grundwert setzen
            {
                if(Szenario.Info.Kachel[i].Mask != TAXI_KACHEL_SCHALTER)
	                Szenario.Info.Kachel[i].WallPicAniStep = Szenario.Kachel[i][START_WALL_ANI_STEP];
            }
		    for(i = 0; i < (Szenario.Info.KarteB*Szenario.Info.KarteH); i++) // Alle Animationen auf Grundwert setzen
		        Szenario.Info.Kachel[i].PicAniStep = Szenario.Kachel[i][START_KACHEL_PIC_ANI_STEP];
			SetBB_Message(GameTexte[T_SZENARIO_ANI_ON_OUT], 30, -1, -1, NO_AKTIV, NO);
        break;

        case VK_F1:
            if(ProgrammSetup.GameSpeed > 0)
	            ProgrammSetup.GameSpeed--;
        break;

        case VK_F2:
            if(ProgrammSetup.GameSpeed < 3000)
	            ProgrammSetup.GameSpeed++;
        break;

        case VK_F3:
			if(ProgrammSetup.GameLongWalls == YES)
	            ProgrammSetup.GameLongWalls = NO;
            else
	            ProgrammSetup.GameLongWalls = YES;
        break;

        case VK_F5:
			if(ProgrammSetup.GameMouseTrans == YES)
	            ProgrammSetup.GameMouseTrans = NO;
            else
	            ProgrammSetup.GameMouseTrans = YES;
        break;

        case VK_F6:
			if(ProgrammSetup.GameSelectedTrans == YES)
	            ProgrammSetup.GameSelectedTrans = NO;
            else
	            ProgrammSetup.GameSelectedTrans = YES;
        break;

        case VK_F7:
			if(ProgrammSetup.ShowFoolPower == YES)
	            ProgrammSetup.ShowFoolPower = NO;
            else
	            ProgrammSetup.ShowFoolPower = YES;
        break;

        case VK_F11:
			if(ProgrammSetup.ShowFoolName == YES)
	            ProgrammSetup.ShowFoolName = NO;
            else
	            ProgrammSetup.ShowFoolName = YES;
        break;

        case VK_TAB:
			if(ProgrammSetup.ShowGameListe == YES)
	            ProgrammSetup.ShowGameListe = NO;
            else
	            ProgrammSetup.ShowGameListe = YES;
        break;
    }
} /* CheckEditorKeys */

void NewLevel(void)
{
    int i, i2;

	GameInfo.ScreenPosX = 30;
	GameInfo.ScreenPosY = 30;
	GameInfo.ScreenPixelPosX = 0;
	GameInfo.ScreenPixelPosY = 0;
	GameInfo.LiveFools = 0;
	GameInfo.DeadFools = 0;
	GameInfo.FinishFools = 0;
	Szenario.Info.KarteB = KARTEN_B_MAX;
    Szenario.Info.KarteH = KARTEN_H_MAX;
	Szenario.Info.StartPosX = 0;
    Szenario.Info.StartPosY = 0;
	Szenario.Info.StartPixelPosX = 0;
	Szenario.Info.StartPixelPosY = 0;
    Szenario.Info.FoolAnzahl = 0;
    Szenario.Info.PacManAnzahl = 0;
    Szenario.Info.GegnerAnzahl = 0;
    Szenario.Info.PunkteAnzahl = 0;
    Szenario.Info.ExitAnzahl = 0;
	Szenario.Info.ToFinish_LiveFools = 0;
    for(i = 0; i < (Szenario.Info.KarteB*Szenario.Info.KarteH); i++)
    {
        Szenario.Info.Kachel[i].Pic = 0;
        Szenario.Info.Kachel[i].WallPic = NO_AKTIV;
        Szenario.Info.Kachel[i].WallPicAniStep = 0;
        Szenario.Info.Kachel[i].Command = NO_COMMAND;
        Szenario.Info.Kachel[i].Besetzt = NO_AKTIV;
        Szenario.Info.Kachel[i].Mask = NO_AKTIV;
        Szenario.Info.Kachel[i].WallPicAniCircle = NO;
        Szenario.Info.Kachel[i].WallPicAniStepTurn = 0;
        Szenario.Info.Kachel[i].PicAniCircle = NO;
        Szenario.Info.Kachel[i].PicAniStepTurn = 0;
        Szenario.Info.Kachel[i].Intem = NO_AKTIV;
        Szenario.Info.Kachel[i].LeftOverlay = NO_AKTIV;
        Szenario.Info.Kachel[i].UpOverlay = NO_AKTIV;
        Szenario.Kachel[i][START_WALL_ANI_STEP] = 0;
        Szenario.Info.Kachel[i].CommandConst = NO;
    }
    for(i = 0; i < MAX_FOOLS; i++) // Alle Fools deakivieren
	{
        Szenario.Info.FoolInfo[i].Fool_ID = NO_AKTIV;
        Szenario.Info.FoolInfo[i].LastWalk = NO;
        Szenario.Info.FoolInfo[i].MaxPower = FULL_POWER;
    	for(i2 = 0; i2 < MAX_FOOL_INTEMS; i2++)
	        Szenario.Info.FoolInfo[i].Intem[i2] = NO_AKTIV;
	    stpcpy(Szenario.Info.FoolInfo[i].FoolName, "NOBODY");
	}
    for(i = 0; i < MAX_PACMAN; i++) // Alle Fools deakivieren
	{
        Szenario.Info.PacManInfo[i].PacMan_ID = NO_AKTIV;
        Szenario.Info.PacManInfo[i].LastWalk = NO;
        Szenario.Info.PacManInfo[i].MaxPower = FULL_POWER;
        Szenario.Info.PacManInfo[i].Befehl = NO_COMMAND;
        Szenario.Info.PacManInfo[i].AktuellBefehl = NO_COMMAND;
	    stpcpy(Szenario.Info.PacManInfo[i].PacManName, "NOBODY");
	}
    for(i = 0; i < MAX_GEGNER; i++) // Alle Gegner deakivieren
	{
        Szenario.Info.GegnerInfo[i].Gegner_ID = NO_AKTIV;
		Szenario.Info.GegnerInfo[i].Typ = GEGNER_DROHNE;
        Szenario.Info.GegnerInfo[i].LastWalk = NO;
        Szenario.Info.GegnerInfo[i].MaxPower = FULL_POWER;
        Szenario.Info.GegnerInfo[i].AnimationStep = 0;
        Szenario.Info.GegnerInfo[i].AnimationTurn = 0;
		Szenario.Info.GegnerInfo[i].Richtung = NO_AKTIV;
	}
    for(i = 0; i < 9; i++)
	    Szenario.Info.Commands[i] = NO_LIMITED;
    stpcpy(Szenario.Info.FoolInfo[0].FoolName, "Robert");
    stpcpy(Szenario.Info.FoolInfo[1].FoolName, "Aluis");
    stpcpy(Szenario.Info.FoolInfo[2].FoolName, "Jens");
    stpcpy(Szenario.Info.FoolInfo[3].FoolName, "Jogy");
    stpcpy(Szenario.Info.FoolInfo[4].FoolName, "Jasmin");
    stpcpy(Szenario.Info.FoolInfo[5].FoolName, "Moamet Ali");
    stpcpy(Szenario.Info.FoolInfo[6].FoolName, "Gutrun");
    stpcpy(Szenario.Info.FoolInfo[7].FoolName, "Herbert");
    stpcpy(Szenario.Info.FoolInfo[8].FoolName, "Timo");
    stpcpy(Szenario.Info.FoolInfo[9].FoolName, "Dominik");
    stpcpy(Szenario.Info.FoolInfo[10].FoolName, "Klaus");
    stpcpy(Szenario.Info.FoolInfo[11].FoolName, "Chris");
    stpcpy(Szenario.Info.FoolInfo[12].FoolName, "Annabel");
    stpcpy(Szenario.Info.FoolInfo[13].FoolName, "Markus");
    Szenario.Info.FoolInfo[0].Intem[0] = 0;
    Szenario.Info.FoolInfo[0].Intem[1] = 1;
    SetBB_Message(" Neues Level wurde erstellt!", 30, -1, -1, NO_AKTIV, NO);
    InitEditorInfo();
    InitGameInfo();
	DrawMini();
}

// Funktion zum Abfragen der Maus:
void CheckEditorMouse(void)
{
    int x, y, i, i2, Check, zufall;

    if(Mouse.Show == NO)
    	return;
    CheckEditorSetChange();
    if(EditorKachelMenu[KACHEL_MENU_ON] == YES)
    	return;
	if(ProgrammSetup.ShowGameListe == YES)
	    CheckMiniScroll(GameListeX+5, GameListeY+10);
    MouseScroll();
	i = SucheKachel();
    Mouse.SelectedKachel = i;
    if(Mouse.Button != LEFT_MOUSE_BUTTON || PressedMouseScroll == YES)
    	return; // Keine aktion n�tig!!
    GameListeOnOff();
    // Game Liste Ein/Ausfahren
    if(ProgrammSetup.ShowGameListe == YES)
    {
		if(CheckMouseRect(GameListeX-20, GameListeY+440, GameListeX-5, GameListeY+455) != NO_AKTIV)
		{
        	ProgrammSetup.ShowGameListe = NO;
    		return;
        }
    }
    else
    {
		if(CheckMouseRect(GameListeX+100, GameListeY+440, GameListeX+115, GameListeX+455) != NO_AKTIV)
		{
        	ProgrammSetup.ShowGameListe = YES;
    		return;
        }
    }
   /////////
    if(CheckMouseRect(GameListeX, GameListeY, GameListeX+120, GameListeY+480) == NO_AKTIV || ProgrammSetup.ShowGameListe == NO)
    {
        // Pr�ft die Kachel Animaimations Kn�pfe:
        if((Editor_SetKachel > FLOOR_ANI-1 && Editor_SetKachel < DEADLY_WALKS-1) ||
          (Editor_SetKachel > DEADLY_WALKS_ANI-1 && Editor_SetKachel < WALLS-1) ||
          (Editor_SetKachel > WALL_ANI-1 && Editor_SetKachel < MOVE_WALLS-1))
        {
            if(TimerNew2 == YES)
            {
                TimerNew2 = NO;
                if(CheckMouseRect(GameListeX-20, GameListeY+380, GameListeX, GameListeY+400) != NO_AKTIV)
                {
                    SetAnimationCircle = YES;
                    SetAnimationLeftRight = NO;
                    return;
                }
                if(CheckMouseRect(GameListeX-20, GameListeY+400, GameListeX, GameListeY+420) != NO_AKTIV)
                {
                    if(SetAnimationLeftRight == YES)
                    {
                        if(SetAnimationLeftRightTurn == 0)
                            SetAnimationLeftRightTurn = 1;
                        else
                            SetAnimationLeftRightTurn = 0;
                    }
                    else
                    {
                        SetAnimationCircle = NO;
                        SetAnimationLeftRight = YES;
                        SetAnimationLeftRightTurn = 0;
                    }
                    return;
                }
                if(CheckMouseRect(GameListeX-20, GameListeY+420, GameListeX, GameListeY+440) != NO_AKTIV)
                {
                    if(SetAnimationRandom == NO)
                        SetAnimationRandom = YES;
                    else
                        SetAnimationRandom = NO;
                    return;
                }
			}
        }
        //////////////
        CheckMouseFool();
        if(CheckMouseFoolsStatus() == YES)
        	return;
        if(Mouse.SelectedKachel == NO_AKTIV)
			return; // Keine aktion n�tig!! Keine g�ltige Kachel ausgew�hlet!!
        if(GameInfo.Befehl == SELECT_COMMAND || GameInfo.Befehl == INSPECT_COMMAND)
        	return;
        // Den Ausgang setzen:
        if(GameInfo.Befehl == SET_EXIT && Szenario.Info.ExitAnzahl < MAX_EXIT_ANZAHL &&
        	Szenario.Info.Kachel[Mouse.SelectedKachel].WallPic == NO_AKTIV &&
            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_X]][Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_Y]-1]].WallPic == NO_AKTIV &&
            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_X]+1][Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_Y]-1]].WallPic == NO_AKTIV)
        {
            Szenario.Info.ExitAnzahl++;
            Szenario.Info.Kachel[Mouse.SelectedKachel].WallPic = SPECIAL_EXIT;
            Szenario.Kachel[Mouse.SelectedKachel][START_WALL_ANI_STEP] = random(7);
            Szenario.Info.Kachel[Mouse.SelectedKachel].Command = NO_COMMAND;
            Szenario.Info.Kachel[Mouse.SelectedKachel].CommandConst = NO;
            Szenario.Info.Kachel[Mouse.SelectedKachel].Mask = NO_AKTIV;
            Szenario.Info.Kachel[Mouse.SelectedKachel].Intem = NO_AKTIV;
            x = Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_X]+1;
            y = Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_Y];
            Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPic = SPECIAL_EXIT_OVERLAY;
            Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Command = NO_COMMAND;
            Szenario.Info.Kachel[Szenario.PosInfo[x][y]].CommandConst = NO;
            Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Mask = NO_AKTIV;
            Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Intem = NO_AKTIV;
            x = Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_X];
            y = Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_Y]-1;
            Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPic = SPECIAL_EXIT_OVERLAY;
            Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Command = NO_COMMAND;
            Szenario.Info.Kachel[Szenario.PosInfo[x][y]].CommandConst = NO;
            Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Mask = NO_AKTIV;
            Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Intem = NO_AKTIV;
            x = Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_X]+1;
            y = Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_Y]-1;
            Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPic = SPECIAL_EXIT_OVERLAY;
            Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Command = NO_COMMAND;
            Szenario.Info.Kachel[Szenario.PosInfo[x][y]].CommandConst = NO;
            Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Mask = NO_AKTIV;
            Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Intem = NO_AKTIV;
            goto AktuMini;
        }
        // Die Kachel s�ubern:
        if(GameInfo.Befehl == COMMAND_DELETE)
        {
            if(Szenario.Info.Kachel[Mouse.SelectedKachel].WallPic != SPECIAL_EXIT_OVERLAY)
            {
                if(Szenario.Info.Kachel[Mouse.SelectedKachel].WallPic == SPECIAL_EXIT)
                {
					Szenario.Info.ExitAnzahl--;
                    Szenario.Info.Kachel[Mouse.SelectedKachel].WallPic = NO_AKTIV;
                    Szenario.Info.Kachel[Mouse.SelectedKachel].Command = NO_COMMAND;
                    Szenario.Info.Kachel[Mouse.SelectedKachel].CommandConst = NO;
                    Szenario.Info.Kachel[Mouse.SelectedKachel].Mask = NO_AKTIV;
                    Szenario.Info.Kachel[Mouse.SelectedKachel].Intem = NO_AKTIV;
                    x = Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_X]+1;
                    y = Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_Y];
                    Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPic = NO_AKTIV;
                    Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Command = NO_COMMAND;
                    Szenario.Info.Kachel[Szenario.PosInfo[x][y]].CommandConst = NO;
                    Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Mask = NO_AKTIV;
                    Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Intem = NO_AKTIV;
                    x = Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_X];
                    y = Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_Y]-1;
                    Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPic = NO_AKTIV;
                    Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Command = NO_COMMAND;
                    Szenario.Info.Kachel[Szenario.PosInfo[x][y]].CommandConst = NO;
                    Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Mask = NO_AKTIV;
                    Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Intem = NO_AKTIV;
                    x = Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_X]+1;
                    y = Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_Y]-1;
                    Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPic = NO_AKTIV;
                    Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Command = NO_COMMAND;
                    Szenario.Info.Kachel[Szenario.PosInfo[x][y]].CommandConst = NO;
                    Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Mask = NO_AKTIV;
                    Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Intem = NO_AKTIV;
                }
                if(Szenario.Info.Kachel[Mouse.SelectedKachel].WallPicAniStepTurn == PUNKT)
                {
                    Szenario.Info.PunkteAnzahl--;
                    Szenario.Info.Kachel[Mouse.SelectedKachel].WallPicAniStepTurn = NO_AKTIV;
                }
                Szenario.Info.Kachel[Mouse.SelectedKachel].WallPic = NO_AKTIV;
                Szenario.Info.Kachel[Mouse.SelectedKachel].Command = NO_COMMAND;
                Szenario.Info.Kachel[Mouse.SelectedKachel].CommandConst = NO;
                Szenario.Info.Kachel[Mouse.SelectedKachel].Mask = NO_AKTIV;
                Szenario.Info.Kachel[Mouse.SelectedKachel].Intem = NO_AKTIV;
                // Wenn ein fool das Feld besetzt, wird er gel�scht:
                for(i = 0; i < MAX_FOOLS; i++)
                {
                    if(Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_X] == Szenario.Info.FoolInfo[i].PosX &&
                        Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_Y] == Szenario.Info.FoolInfo[i].PosY &&
                        Szenario.Info.FoolInfo[i].Fool_ID != NO_AKTIV)
                    {
                        GameInfo.LiveFools--;
                        Szenario.Info.FoolAnzahl--;
                        Szenario.Info.FoolInfo[i].Fool_ID = NO_AKTIV;
                        Szenario.Info.Kachel[Mouse.SelectedKachel].Besetzt = NO_AKTIV;
                        for(i2 = 0; i2 < MAX_FOOL_INTEMS; i2++)
                            Szenario.Info.FoolInfo[i].Intem[i2] = NO_AKTIV;
                        if(i == GameInfo.SelectedFool)
                            GameInfo.SelectedFool = NO_AKTIV;
                    }
                }
                // Wenn ein PacMan das Feld besetzt, wird er gel�scht:
                for(i = 0; i < MAX_PACMAN; i++)
                {
                    if(Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_X] == Szenario.Info.PacManInfo[i].PosX &&
                        Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_Y] == Szenario.Info.PacManInfo[i].PosY &&
                        Szenario.Info.PacManInfo[i].PacMan_ID != NO_AKTIV)
                    {
//                        GameInfo.LiveFools--;
                        Szenario.Info.PacManAnzahl--;
                        Szenario.Info.PacManInfo[i].PacMan_ID = NO_AKTIV;
                        Szenario.Info.Kachel[Mouse.SelectedKachel].Besetzt = NO_AKTIV;
                        if(i+FIRST_PACMAN == GameInfo.SelectedFool)
                            GameInfo.SelectedFool = NO_AKTIV;
                    }
                }
                // Wenn ein Gegner das Feld besetzt, wird er gel�scht:
                for(i = 0; i < MAX_GEGNER; i++)
                {
                    if(Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_X] == Szenario.Info.GegnerInfo[i].PosX &&
                        Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_Y] == Szenario.Info.GegnerInfo[i].PosY &&
                        Szenario.Info.GegnerInfo[i].Gegner_ID != NO_AKTIV)
                    {
                        Szenario.Info.GegnerAnzahl--;
                        Szenario.Info.GegnerInfo[i].Gegner_ID = NO_AKTIV;
                        Szenario.Info.Kachel[Mouse.SelectedKachel].Besetzt = NO_AKTIV;
                    }
                }
                goto AktuMini;
        	}
        }
        if(GameInfo.Befehl == NO_COMMAND)
        {
            if(Editor_SetKachel > FIRST_INTEM-1)
            {
                Szenario.Info.Kachel[Mouse.SelectedKachel].Intem = Editor_SetKachel-FIRST_INTEM;
	            goto AktuMini;
            }
            if(Editor_SetKachel > WALLS-1 && Editor_SetKachel < FIRST_INTEM-1)
            {  // Eine Wand setzen:
                if(Szenario.Info.Kachel[Mouse.SelectedKachel].WallPic == SPECIAL_EXIT ||
                    Szenario.Info.Kachel[Mouse.SelectedKachel].WallPic == SPECIAL_EXIT_OVERLAY)
                    return;
                if(Szenario.Info.Kachel[Mouse.SelectedKachel].WallPicAniStepTurn == PUNKT)
                {
                    Szenario.Info.PunkteAnzahl--;
                    Szenario.Info.Kachel[Mouse.SelectedKachel].WallPicAniStepTurn = NO_AKTIV;
                }
                Szenario.Info.Kachel[Mouse.SelectedKachel].WallPic = Editor_SetKachel;
                if(SetAnimationRandom == YES)
                {
                    zufall = random(MAX_WALL_PIC_B-1);
                    Szenario.Info.Kachel[Mouse.SelectedKachel].WallPicAniStep = zufall;
                    Szenario.Kachel[Mouse.SelectedKachel][START_WALL_ANI_STEP] = zufall;
                }
                else
                {
                    Szenario.Info.Kachel[Mouse.SelectedKachel].WallPicAniStep = Editor_SetKachelAni;
                    Szenario.Kachel[Mouse.SelectedKachel][START_WALL_ANI_STEP] = Editor_SetKachelAni;
                }
                Szenario.Info.Kachel[Mouse.SelectedKachel].WallPicAniCircle = SetAnimationCircle;
                Szenario.Info.Kachel[Mouse.SelectedKachel].WallPicAniStepTurn = SetAnimationLeftRightTurn;
                Szenario.Info.Kachel[Mouse.SelectedKachel].Intem = NO_AKTIV;
				if(Editor_SetKachel < FIRST_OBJECT-1)
                {
               		Szenario.Info.Kachel[Mouse.SelectedKachel].Command = NO_COMMAND;
                	Szenario.Info.Kachel[Mouse.SelectedKachel].CommandConst = NO;
                }
                // Wenn ein fool das Feld besetzt, wird er gel�scht:
                for(i = 0; i < MAX_FOOLS; i++)
                    if(Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_X] == Szenario.Info.FoolInfo[i].PosX &&
                        Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_Y] == Szenario.Info.FoolInfo[i].PosY &&
                        Szenario.Info.FoolInfo[i].Fool_ID != NO_AKTIV)
                    {
                        GameInfo.LiveFools--;
                        Szenario.Info.FoolInfo[i].Fool_ID = NO_AKTIV;
                        Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Besetzt = NO_AKTIV;
                        for(i2 = 0; i2 < MAX_FOOL_INTEMS; i2++)
                            Szenario.Info.FoolInfo[i].Intem[i2] = NO_AKTIV;
                        if(i == GameInfo.SelectedFool)
                            GameInfo.SelectedFool = NO_AKTIV;
                    }
 		            goto AktuMini;
            }
            else
            { // Eine Bodenflie�e setzen:
                if(Editor_SetKachel < DOOR_ANI-1)
                {
                    Szenario.Info.Kachel[Mouse.SelectedKachel].Pic = Editor_SetKachel;
                    if((Editor_SetKachel > FLOOR_ANI-1 && Editor_SetKachel < DEADLY_WALKS) ||
                       (Editor_SetKachel > DEADLY_WALKS_ANI-1 && Editor_SetKachel < WALLS))
                    {
                        if(SetAnimationRandom == YES)
                        {
                            zufall = random(MAX_FLOOR_PIC_B-1);
                            Szenario.Info.Kachel[Mouse.SelectedKachel].PicAniStep = zufall;
                            Szenario.Kachel[Mouse.SelectedKachel][START_KACHEL_PIC_ANI_STEP] = zufall;
                        }
                        else
                        {
                            Szenario.Info.Kachel[Mouse.SelectedKachel].PicAniStep = Editor_SetKachelAni;
                            Szenario.Kachel[Mouse.SelectedKachel][START_KACHEL_PIC_ANI_STEP] = Editor_SetKachelAni;
                        }
                        Szenario.Info.Kachel[Mouse.SelectedKachel].PicAniCircle = SetAnimationCircle;
                        Szenario.Info.Kachel[Mouse.SelectedKachel].PicAniStepTurn = SetAnimationLeftRightTurn;
                    }
                    if((Editor_SetKachel > DEADLY_WALKS-1 && Editor_SetKachel < DEADLY_WALKS_ANI) ||
	                    (Editor_SetKachel > DEADLY_WALKS_ANI-1 && Editor_SetKachel < WALLS))
                    {
                        Szenario.Info.Kachel[Mouse.SelectedKachel].Command = NO_COMMAND;
                        Szenario.Info.Kachel[Mouse.SelectedKachel].CommandConst = NO;
                        Szenario.Info.Kachel[Mouse.SelectedKachel].Intem = NO_AKTIV;
                        for(i = 0; i < MAX_FOOLS; i++)
                        {
                            if(Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_X] == Szenario.Info.FoolInfo[i].PosX &&
                                Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_Y] == Szenario.Info.FoolInfo[i].PosY &&
                                Szenario.Info.FoolInfo[i].Fool_ID != NO_AKTIV)
                            {
                                GameInfo.LiveFools--;
                                Szenario.Info.FoolInfo[i].Fool_ID = NO_AKTIV;
                                Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Besetzt = NO_AKTIV;
                                for(i2 = 0; i2 < MAX_FOOL_INTEMS; i2++)
                                    Szenario.Info.FoolInfo[i].Intem[i2] = NO_AKTIV;
                                if(i == GameInfo.SelectedFool)
                                    GameInfo.SelectedFool = NO_AKTIV;
					            goto AktuMini;
                            }
                        }
                    }
                }
            }
/*            if(Editor_SetKachel > DOOR_ANI-1)
            {  // Eine T�re setzen:
                Szenario.Info.Kachel[Mouse.SelectedKachel].WallPic = Editor_SetKachel;
                Szenario.Info.Kachel[Mouse.SelectedKachel].WallPicAniStep = Editor_SetKachelAni;
                Szenario.Kachel[Mouse.SelectedKachel][START_WALL_ANI_STEP] = Editor_SetKachelAni;
                Szenario.Info.Kachel[Mouse.SelectedKachel].WallPicAniStepTurn = 0;
            }*/
            goto AktuMini;
        }
        if(Szenario.Info.Kachel[Mouse.SelectedKachel].WallPic == SPECIAL_EXIT ||
            Szenario.Info.Kachel[Mouse.SelectedKachel].WallPic == SPECIAL_EXIT_OVERLAY)
            return;
        // Eine freie Flur Kachel:
        if(Szenario.Info.Kachel[Mouse.SelectedKachel].Pic != NO_KACHEL && Szenario.Info.Kachel[Mouse.SelectedKachel].WallPic == NO_AKTIV &&
           Szenario.Info.Kachel[Mouse.SelectedKachel].Pic < DEADLY_WALKS)
        {
	      // Der Spieler setzt einen Fool:
            if(GameInfo.Befehl == SET_FOOL)
            {
                if(Szenario.Info.Kachel[Mouse.SelectedKachel].Besetzt == NO_AKTIV)
                {
                    for(i = 0; i < MAX_FOOLS; i++)
                    {
                        if(Szenario.Info.FoolInfo[i].Fool_ID == NO_AKTIV)
                        {
                            GameInfo.LiveFools++;
                            Szenario.Info.FoolAnzahl++;
                            Szenario.Info.FoolInfo[i].Fool_ID = i;
                            Szenario.Info.FoolInfo[i].OnLive = YES;
                            Szenario.Info.FoolInfo[i].PosX = Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_X];
                            Szenario.Info.FoolInfo[i].PosY = Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_Y];
                            Szenario.Info.FoolInfo[i].PixelPosX = 0;
                            Szenario.Info.FoolInfo[i].PixelPosY = 0;
                            Szenario.Info.FoolInfo[i].AnimationTurn = 0;
                            Szenario.Info.FoolInfo[i].AnimationPlusMinus = 0;
							Szenario.Info.Kachel[Mouse.SelectedKachel].Besetzt = i;
                        OldFool:
			                Check = CheckMouseRichtung();
                            if(Check != NO_AKTIV)
                            	Szenario.Info.FoolInfo[i].Richtung = Check;
                            Szenario.Info.FoolInfo[i].Befehl = Szenario.Info.FoolInfo[i].Richtung;
                            Szenario.Info.FoolInfo[i].Animation = Szenario.Info.FoolInfo[i].Richtung;
                            Szenario.Info.FoolInfo[i].AnimationInfo = Szenario.Info.FoolInfo[i].Richtung;
                            Szenario.Info.FoolInfo[i].Power = Szenario.Info.FoolInfo[i].MaxPower;
	                        goto AktuMini;
                        }
               		}
                }
                else
                {
                    i = Szenario.Info.Kachel[Mouse.SelectedKachel].Besetzt;
                    if(i < MAX_FOOLS)
	                    goto OldFool;
                }
            }
	      // Der Spieler setzt einen PacMan:
            if(GameInfo.Befehl == SET_PACMAN)
            {
                if(Szenario.Info.Kachel[Mouse.SelectedKachel].Besetzt == NO_AKTIV)
                {
                    for(i = 0; i < MAX_PACMAN; i++)
                    {
                        if(Szenario.Info.PacManInfo[i].PacMan_ID == NO_AKTIV)
                        {
//                            GameInfo.LivePacMan++;
                            Szenario.Info.PacManAnzahl++;
                            Szenario.Info.PacManInfo[i].PacMan_ID = i;
                            Szenario.Info.PacManInfo[i].OnLive = YES;
                            Szenario.Info.PacManInfo[i].PosX = Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_X];
                            Szenario.Info.PacManInfo[i].PosY = Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_Y];
                            Szenario.Info.PacManInfo[i].PixelPosX = 0;
                            Szenario.Info.PacManInfo[i].PixelPosY = 0;
                            Szenario.Info.PacManInfo[i].AnimationTurn = 0;
							Szenario.Info.Kachel[Mouse.SelectedKachel].Besetzt = i+FIRST_PACMAN;
                        OldPacMan:
			                Check = CheckMouseRichtung();
                            if(Check != NO_AKTIV)
                            	Szenario.Info.PacManInfo[i].Richtung = Check;
                            Szenario.Info.PacManInfo[i].Animation = Szenario.Info.PacManInfo[i].Richtung;
                            Szenario.Info.PacManInfo[i].Power = Szenario.Info.PacManInfo[i].MaxPower;
	                        goto AktuMini;
                        }
               		}
                }
                else
                {
                    i = Szenario.Info.Kachel[Mouse.SelectedKachel].Besetzt;
                    if(i > FIRST_PACMAN-1 && i < FIRST_PACMAN+MAX_PACMAN)
	                {
                        i -= FIRST_PACMAN;
                        goto OldPacMan;
                    }
                }
            }
            // Einen Punkt setzen:
            if(GameInfo.Befehl == SET_PUNKT)
            {
                if(Szenario.Info.Kachel[Mouse.SelectedKachel].WallPicAniStepTurn != PUNKT)
                {
                    Szenario.Info.PunkteAnzahl++;
					Szenario.Info.Kachel[Mouse.SelectedKachel].WallPicAniStepTurn = PUNKT;
    	            Szenario.Kachel[Mouse.SelectedKachel][START_WALL_ANI_STEP] = random(18);
                }
                goto AktuMini;
            }
        // Masken:
            // Eine instabiele Kachel setzen:
            if(GameInfo.Befehl == SET_INSTABIL)
            {
                Szenario.Info.Kachel[Mouse.SelectedKachel].Mask = FIRST_INSTABIL+(InfoVar/10);
                goto AktuMini;
            }
           // Eine verseuchte Kachel setzen:
            if(GameInfo.Befehl == SET_ATOMIK)
            {
                Szenario.Info.Kachel[Mouse.SelectedKachel].Mask = ATOMIK;
                goto AktuMini;
            }
           // Eine heilende Kachel setzen:
            if(GameInfo.Befehl == SET_GESUND)
            {
                Szenario.Info.Kachel[Mouse.SelectedKachel].Mask = GESUND;
                goto AktuMini;
            }
           // Einen Beamer Setzen:
            if(GameInfo.Befehl == SET_BEAMER)
            {
                Szenario.Info.Kachel[Mouse.SelectedKachel].Mask = BEAMER;
                Szenario.Info.Kachel[Mouse.SelectedKachel].BEAMER_NR_1 = NO_AKTIV;
                Szenario.Info.Kachel[Mouse.SelectedKachel].BEAMER_RANDOM = NO;
                Szenario.Info.Kachel[Mouse.SelectedKachel].BEAMER_NR_2 = NO_AKTIV;
                goto AktuMini;
            }
           // Ein Kachel Taxi Schalter setzen:
            if(GameInfo.Befehl == SET_TAXI_KACHEL_SCHALTER)
            {
                Szenario.Info.Kachel[Mouse.SelectedKachel].Mask = TAXI_KACHEL_SCHALTER;
                Szenario.Info.Kachel[Mouse.SelectedKachel].TAXI_SCHALTER_1 = NO_AKTIV;
                Szenario.Info.Kachel[Mouse.SelectedKachel].TAXI_SCHALTER_1_RICHTUNG = NO_AKTIV;
                Szenario.Info.Kachel[Mouse.SelectedKachel].TAXI_SCHALTER_2 = NO_AKTIV;
                Szenario.Info.Kachel[Mouse.SelectedKachel].TAXI_SCHALTER_2_RICHTUNG = NO_AKTIV;
                goto AktuMini;
            }
        /////
	     // Einen Gegenstand setzen:
            if(Editor_SetKachel > FIRST_INTEM-1)
            {
                Szenario.Info.Kachel[Mouse.SelectedKachel].Intem = Editor_SetKachel-FIRST_INTEM;
                goto AktuMini;
            }
        }
        // Ein Kachel Taxi setzen:
        if(Szenario.Info.Kachel[Mouse.SelectedKachel].Pic != NO_KACHEL && Szenario.Info.Kachel[Mouse.SelectedKachel].WallPic == NO_AKTIV &&
	        Szenario.Info.Kachel[Mouse.SelectedKachel].Pic > DEADLY_WALKS-1 && GameInfo.Befehl == SET_TAXI_KACHEL)
        {
            Szenario.Info.Kachel[Mouse.SelectedKachel].Mask = TAXI_KACHEL;
            Szenario.Info.Kachel[Mouse.SelectedKachel].TAXI_RICHTUNG = NO_AKTIV;
            Szenario.Info.Kachel[Mouse.SelectedKachel].TAXI_SPEED = 1;
            goto AktuMini;
        }
        if(Szenario.Info.Kachel[Mouse.SelectedKachel].Pic != NO_KACHEL && Szenario.Info.Kachel[Mouse.SelectedKachel].WallPic == NO_AKTIV &&
	        GameInfo.Befehl == DRAW_GEGNER_DROHNE)
        {
	      // Der Spieler setzt eine Drohne:
            if(Szenario.Info.Kachel[Mouse.SelectedKachel].Besetzt == NO_AKTIV)
            {
                for(i = 0; i < MAX_GEGNER; i++)
                {
                    if(Szenario.Info.GegnerInfo[i].Gegner_ID == NO_AKTIV)
                    {
                        Szenario.Info.GegnerAnzahl++;
                        Szenario.Info.GegnerInfo[i].Gegner_ID = i;
						Szenario.Info.GegnerInfo[i].Typ = GEGNER_DROHNE;
                        Szenario.Info.GegnerInfo[i].OnLive = YES;
                        Szenario.Info.GegnerInfo[i].PosX = Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_X];
                        Szenario.Info.GegnerInfo[i].PosY = Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_Y];
                        Szenario.Info.GegnerInfo[i].PixelPosX = 0;
                        Szenario.Info.GegnerInfo[i].PixelPosY = 0;
                        Szenario.Info.GegnerInfo[i].AnimationTurn = 0;
                        Szenario.Info.Kachel[Mouse.SelectedKachel].Besetzt = MAX_FOOLS+i;
                        Szenario.Info.GegnerInfo[i].Power = Szenario.Info.GegnerInfo[i].MaxPower;
                        goto AktuMini;
                    }
                }
            }
        }
        if((Szenario.Info.Kachel[Mouse.SelectedKachel].Pic != NO_KACHEL && Szenario.Info.Kachel[Mouse.SelectedKachel].WallPic == NO_AKTIV &&
           Szenario.Info.Kachel[Mouse.SelectedKachel].Pic < DEADLY_WALKS) ||
          (Szenario.Info.Kachel[Mouse.SelectedKachel].Mask > FIRST_MOVE_MASK-1 && Szenario.Info.Kachel[Mouse.SelectedKachel].Mask < FIRST_MOVE_MASK+MAX_MOVE_MASK-1))
        {
          // Einen Befehl setzen:
            if(GameInfo.Befehl != COMMAND_DELETE)
            {
                Check = CheckMouseRichtung();
                if(GameInfo.Befehl == COMMAND_WAIT)
                    Check = GameInfo.Befehl;
                if(GameInfo.Befehl == COMMAND_JUMP)
                    Check = GameInfo.Befehl;
                if(Check != -1)
                {
                    switch(GameInfo.Befehl)
                    {
                        case COMMAND_WAIT: Szenario.Info.Kachel[Mouse.SelectedKachel].Command = COMMAND_WAIT; break;
                        case COMMAND_JUMP: Szenario.Info.Kachel[Mouse.SelectedKachel].Command = COMMAND_JUMP; break;
                        case COMMAND_WALK: Szenario.Info.Kachel[Mouse.SelectedKachel].Command = WALK_LEFT+Check; break;
                        case COMMAND_PUSH: Szenario.Info.Kachel[Mouse.SelectedKachel].Command = PUSH_LEFT+Check; break;
                        case COMMAND_USE: Szenario.Info.Kachel[Mouse.SelectedKachel].Command = USE_LEFT+Check; break;
                        case COMMAND_TAKE: Szenario.Info.Kachel[Mouse.SelectedKachel].Command = TAKE_LEFT+Check; break;
                    }
                    Szenario.Info.Kachel[Mouse.SelectedKachel].CommandConst = YES;
                }
            }
        /////
        }
        // Die ver�nderung auf der Mini Karte sichtbar machen:
     AktuMini:
        for(y = 0, i = 0; y < Szenario.Info.KarteH; y++)
           for(x = 0; x < Szenario.Info.KarteB; x++, i++)
               if(i == Mouse.SelectedKachel)
                   DrawMiniKachel(x, y);
    	CheckMoveWallCreateDestroyed(Mouse.SelectedKachel);
    }
} /* CheckEditorMouse */
///////////////////////////////////////////////////////////////////////////////////////

void BuildEditorScene(void)
{
    DDBLTFX     ddbltfx;
    RECT rcRect;
    int Check, x, y, b, h;
    char temp[50];

   	if(EditorKachelMenu[KACHEL_MENU_ON] == YES)
    {
         ddbltfx.dwSize = sizeof(ddbltfx);
         ddbltfx.dwFillColor = 0;
         Back->Blt(NULL, NULL, NULL, DDBLT_COLORFILL, &ddbltfx);
    	 if(EditorKachelMenu[KACHEL_MENU_PAGE] == EDITOR_ANI_WALLS)
	         SetRect(&rcRect, 0, (EditorKachelMenu[2]*(WALL_H+1)), 640, 480+(EditorKachelMenu[2]*(WALL_H+1)));
	     else
             SetRect(&rcRect, 0, 0, 640, 480);

         switch(EditorKachelMenu[KACHEL_MENU_PAGE])
         {
           /////////////////
        	case EDITOR_WAYS:
		        SetRect(&rcRect, 0, 0, 628, 463);
       			Back->BltFast(0, 0, Szenario.FloorLevelPic, &rcRect, FALSE);
	   	     	PrintText(0, 0, GameTexte[T_WAYS], 0, 0, 34, 16, Back);
            break;

         	case EDITOR_ANI_WAYS:
		        SetRect(&rcRect, 0, 462, 628, 925);
       			Back->BltFast(0, 0, Szenario.FloorLevelPic, &rcRect, FALSE);
	   	     	PrintText(0, 0, GameTexte[T_ANIMATED_WAYS], 0, 0, 34, 16, Back);
            break;

         	case EDITOR_DEADLY:
		        SetRect(&rcRect, 0, 924, 628, 1387);
       			Back->BltFast(0, 0, Szenario.FloorLevelPic, &rcRect, FALSE);
	   	     	PrintText(0, 0, GameTexte[T_DEADLY_WAYS], 0, 0, 34, 16, Back);
            break;

         	case EDITOR_ANI_DEADLY:
		        SetRect(&rcRect, 0, 1386, 628, 1849);
       			Back->BltFast(0, 0, Szenario.FloorLevelPic, &rcRect, FALSE);
	   	     	PrintText(0, 0, GameTexte[T_DEADLY_ANI_WAYS], 0, 0, 34, 16, Back);
            break;
           /////////////////

         	case EDITOR_WALLS:
	            Back->BltFast(0, 0, Szenario.WallLevelPic, &rcRect, FALSE);
	   	     	PrintText(0, 0, GameTexte[T_WALLS], 0, 0, 34, 16, Back);
            break;

         	case EDITOR_ANI_WALLS:
	            Back->BltFast(0, 0, Szenario.WallAniLevelPic, &rcRect, FALSE);
	   	     	PrintText(0, 0, GameTexte[T_WALLS_ANI], 0, 0, 34, 16, Back);
            break;

         	case EDITOR_PUSHES:
                SetRect(&rcRect, 0, 0, 616, 139);
	            Back->BltFast(0, 0, Szenario.MoveWallLevelPic, &rcRect, FALSE);
	   	     	PrintText(0, 0, GameTexte[T_MOVE_WALLS], 0, 0, 34, 16, Back);
            break;

         	case EDITOR_ANI_DOORS:
                SetRect(&rcRect, 0, 0, 410, 480);
	            Back->BltFast(0, 0, Szenario.DoorAniLevelPic, &rcRect, FALSE);
	   	     	PrintText(0, 0, GameTexte[T_DOORS], 0, 0, 34, 16, Back);
            break;

         	case EDITOR_INTEMS:
	            Back->BltFast(0, 0, Szenario.IntemsLevelPic, &rcRect, FALSE);
	   	     	PrintText(0, 0, GameTexte[T_INTEMS], 0, 0, 34, 16, Back);
            break;

         	case EDITOR_OBJECTS:
	            Back->BltFast(0, 0, Szenario.ObjectsLevelPic, &rcRect, FALSE);
	   	     	PrintText(0, 0, GameTexte[T_OBJECTS], 0, 0, 34, 16, Back);
            break;
         }
         if(Editor_SetKachel > FLOOR-1 && Editor_SetKachel < FLOOR_ANI-1)
             Check = FLOOR;
         if(Editor_SetKachel > FLOOR_ANI-1 && Editor_SetKachel < WALLS-1)
             Check = FLOOR_ANI;
         if(Editor_SetKachel > DEADLY_WALKS-1 && Editor_SetKachel < DEADLY_WALKS_ANI-1)
             Check = DEADLY_WALKS;
         if(Editor_SetKachel > DEADLY_WALKS_ANI-1 && Editor_SetKachel < MOVE_WALLS-1)
             Check = DEADLY_WALKS_ANI;
         if(Editor_SetKachel > WALLS-1 &&
             Editor_SetKachel < WALL_ANI-1)
             Check = WALLS;
         if(Editor_SetKachel > WALL_ANI-1 &&
             Editor_SetKachel < DEADLY_WALKS-1)
             Check = WALL_ANI;
         if(Editor_SetKachel > MOVE_WALLS-1)
             Check = MOVE_WALLS;
         if(Editor_SetKachel > FIRST_INTEM-1)
             Check = FIRST_INTEM;
         if(Editor_SetKachel > FIRST_OBJECT-1)
             Check = FIRST_OBJECT;
         if(Editor_SetKachel > DOOR_ANI-1)
             Check = DOOR_ANI;
         switch(Check)
         {
             case FLOOR: case DEADLY_WALKS: case FIRST_INTEM:
                 x = Szenario.FloorPicPos[Editor_SetKachel-Check][0];
                 y = Szenario.FloorPicPos[Editor_SetKachel-Check][1];
                 b = KACHEL_B;
                 h = KACHEL_H;
             break;

             case FLOOR_ANI: case DEADLY_WALKS_ANI:
                 x = 1+Editor_SetKachelAni*(KACHEL_B+1);
                 y = 1+(Editor_SetKachel-Check)*(KACHEL_H+1);
                 b = KACHEL_B;
                 h = KACHEL_H;
             break;

             case WALLS: case MOVE_WALLS: case FIRST_OBJECT:
                 x = Szenario.WallPicPos[Editor_SetKachel-Check][0];
                 y = Szenario.WallPicPos[Editor_SetKachel-Check][1];
                 b = WALL_B;
                 h = WALL_H;
             break;

             case WALL_ANI: case DOOR_ANI:
                 x = Editor_SetKachelAni*(WALL_B+1)+1;
                 y = (Editor_SetKachel-Check)*(WALL_H+1)+1-(EditorKachelMenu[2]*(WALL_H+1));
                 b = WALL_B;
                 h = WALL_H;
             break;
         }
         DrawRect(x-1, y-1, b+1, h+1, 13, Back);
         sprintf(temp, "%s: %d  %s:%d", GameTexte[T_KACHEL], Editor_SetKachel, GameTexte[T_STEP], Editor_SetKachelAni);
     	 PrintText(ScreenRes[1]/2+10, 450, temp, 0, 0, 40, 60, Back);
         sprintf(temp, "%s:%d -%d", GameTexte[T_PAGE], EditorKachelMenu[KACHEL_MENU_PAGE], (EditorKachelMenu[2]*(WALL_H+1)));
     	 PrintText(10, 450, temp, 0, 0, 40, 60, Back);
    }
    else
    {
        DrawVirtualScene(EDITOR_SCENE);
        if(GameInfo.Befehl == NO_COMMAND)
        {
		    if(Editor_SetKachel > FLOOR-1 && Editor_SetKachel < WALLS-1)
            {
                rcRect.left   = Szenario.FloorPicPos[Editor_SetKachel][0];
                rcRect.top    = Szenario.FloorPicPos[Editor_SetKachel][1];
                rcRect.right  = Szenario.FloorPicPos[Editor_SetKachel][0]+KACHEL_B;
                rcRect.bottom = Szenario.FloorPicPos[Editor_SetKachel][1]+KACHEL_H;
                Back->BltFast(GameListeX-80, GameListeY+420-KACHEL_H, Szenario.FloorLevelPic, &rcRect, FALSE);
            }
            if(Editor_SetKachel > WALLS-1 &&
                Editor_SetKachel < WALL_ANI-1)
            {
                rcRect.left   = Szenario.WallPicPos[Editor_SetKachel-WALLS][0];
                rcRect.top    = Szenario.WallPicPos[Editor_SetKachel-WALLS][1];
                rcRect.right  = Szenario.WallPicPos[Editor_SetKachel-WALLS][0]+WALL_B;
                rcRect.bottom = Szenario.WallPicPos[Editor_SetKachel-WALLS][1]+WALL_H;
                Back->BltFast(GameListeX-80, GameListeY+420-WALL_H, Szenario.WallLevelPic, &rcRect, FALSE);
            }
            if(Editor_SetKachel > WALL_ANI-1 && Editor_SetKachel < MOVE_WALLS-1)
            {
                rcRect.left   = Editor_SetKachelAni*(WALL_B+1)+1;
                rcRect.top    = (Editor_SetKachel-WALL_ANI)*(WALL_H+1)+1;
                rcRect.right  = Editor_SetKachelAni*(WALL_B+1)+WALL_B+1;
                rcRect.bottom = (Editor_SetKachel-WALL_ANI)*(WALL_H+1)+WALL_H+1;
                Back->BltFast(GameListeX-80, GameListeY+420-WALL_H, Szenario.WallAniLevelPic, &rcRect, FALSE);
            }
            if(Editor_SetKachel > MOVE_WALLS-1 && Editor_SetKachel < MOVE_WALLS+40)
            {
                rcRect.left   = Szenario.WallPicPos[Editor_SetKachel-MOVE_WALLS][0];
                rcRect.top    = Szenario.WallPicPos[Editor_SetKachel-MOVE_WALLS][1];
                rcRect.right  = Szenario.WallPicPos[Editor_SetKachel-MOVE_WALLS][0]+WALL_B;
                rcRect.bottom = Szenario.WallPicPos[Editor_SetKachel-MOVE_WALLS][1]+WALL_H;
                Back->BltFast(GameListeX-80, GameListeY+420-WALL_H, Szenario.MoveWallLevelPic, &rcRect, FALSE);
            }
            if(Editor_SetKachel > DOOR_ANI-1)
            {
                rcRect.left   = Editor_SetKachelAni*(WALL_B+1)+1;
                rcRect.top    = (Editor_SetKachel-DOOR_ANI)*(WALL_H+1)+1;
                rcRect.right  = Editor_SetKachelAni*(WALL_B+1)+WALL_B+1;
                rcRect.bottom = (Editor_SetKachel-DOOR_ANI)*(WALL_H+1)+WALL_H+1;
                Back->BltFast(GameListeX-80, GameListeY+420-WALL_H, Szenario.DoorAniLevelPic, &rcRect, FALSE);
            }
            if(Editor_SetKachel > FIRST_INTEM-1 && Editor_SetKachel < FIRST_INTEM+50)
				DrawKachelIntemPic(Editor_SetKachel-FIRST_INTEM, GameListeX-80, GameListeY+420-KACHEL_H, Back);
            if(Editor_SetKachel > FIRST_OBJECT-1 && Editor_SetKachel < FIRST_OBJECT+50)
            {
                rcRect.left   = Szenario.WallPicPos[Editor_SetKachel-FIRST_OBJECT][0];
                rcRect.top    = Szenario.WallPicPos[Editor_SetKachel-FIRST_OBJECT][1];
                rcRect.right  = Szenario.WallPicPos[Editor_SetKachel-FIRST_OBJECT][0]+WALL_B;
                rcRect.bottom = Szenario.WallPicPos[Editor_SetKachel-FIRST_OBJECT][1]+WALL_H;
                Back->BltFast(GameListeX-80, GameListeY+420-WALL_H, Szenario.ObjectsLevelPic, &rcRect, FALSE);
            }
		}
        if(GameInfo.Befehl == SET_FOOL)
        {
            SetRect(&rcRect, 1, 1, 1+FOOL_B, 1+FOOL_H);
            Back->BltFast(GameListeX-80, GameListeY+420-FOOL_H, FoolAniPic, &rcRect, FALSE);
        }
        if(GameInfo.Befehl == DRAW_GEGNER_DROHNE)
        {
	        SetRect(&rcRect, 1, 1, 33, 42);
            Back->BltFast(GameListeX-80, GameListeY+420-41, GegnerAniPic, &rcRect, FALSE);
        }
		if(GameInfo.Befehl == SET_INSTABIL)
        {
            rcRect.left   = 1+Editor_SetKachelAni*(KACHEL_B+5);
            rcRect.top    = 1;
            rcRect.right  = 1+Editor_SetKachelAni*(KACHEL_B+5)+KACHEL_B+KACHEL_OVERLAY;
            rcRect.bottom = 1+KACHEL_H+KACHEL_OVERLAY;
            Back->BltFast(GameListeX-80, GameListeY+420-KACHEL_H, Szenario.MasksLevelPic, &rcRect, FALSE);
            sprintf(temp, "%d", InfoVar/10);
            PrintText(450, 400, temp, 0, 0, 40, 40, Back);
        }
        if(GameInfo.Befehl == SET_ATOMIK)
        {
            rcRect.left   = 451;
            rcRect.top    = 1;
            rcRect.right  = 495;
            rcRect.bottom = 37;
            Back->BltFast(GameListeX-80, GameListeY+420-KACHEL_H, Szenario.MasksLevelPic, &rcRect, FALSE);
            sprintf(temp, "%d", Editor_SetKachelAni);
            PrintText(450, 400, temp, 0, 0, 40, 40, Back);
        }
        if(GameInfo.Befehl == SET_EXIT)
        {
	        SetRect(&rcRect, 1, 1387, 42, 1449);
            Back->BltFast(GameListeX-80, GameListeY+420-KACHEL_H, GameListPic, &rcRect, FALSE);
        }
        if(GameInfo.Befehl == COMMAND_WALK)
        {
            rcRect.left   = 1;
            rcRect.top    = 1;
            rcRect.right  = 1+KACHEL_B;
            rcRect.bottom = 1+KACHEL_H;
            Back->BltFast(GameListeX-80, GameListeY+420-KACHEL_H, BefehlePic, &rcRect, FALSE);
        }
        if(GameInfo.Befehl == COMMAND_PUSH)
        {
            rcRect.left   = 1;
            rcRect.top    = 1+(KACHEL_H*2+2);
            rcRect.right  = 1+KACHEL_B;
            rcRect.bottom = 1+(KACHEL_H*3+2);
            Back->BltFast(GameListeX-80, GameListeY+420-KACHEL_H, BefehlePic, &rcRect, FALSE);
        }
        if(GameInfo.Befehl == COMMAND_DELETE)
            PrintText(GameListeX-80, GameListeY+420-KACHEL_H, " Del ", 0, 0, 34, 40, Back);
        if(GameInfo.Befehl == COMMAND_USE)
        {
            rcRect.left   = 165;
            rcRect.top    = 1;
            rcRect.right  = 165+KACHEL_B;
            rcRect.bottom = 1+KACHEL_H;
            Back->BltFast(GameListeX-80, GameListeY+420-KACHEL_H, BefehlePic, &rcRect, FALSE);
        }
        if(GameInfo.Befehl == COMMAND_WAIT)
        {
            rcRect.left   = 329;
            rcRect.top    = 1;
            rcRect.right  = 368;
            rcRect.bottom = 32;
            Back->BltFast(GameListeX-80, GameListeY+420-KACHEL_H, BefehlePic, &rcRect, FALSE);
        }
        sprintf(temp, "%s:%d", GameTexte[T_KACHEL], Editor_SetKachel);
        PrintText(GameListeX-150, GameListeY+430, temp, 0, 0, 1000, 1000, Back);
        if((Editor_SetKachel > FLOOR_ANI-1 && Editor_SetKachel < DEADLY_WALKS-1) ||
          (Editor_SetKachel > DEADLY_WALKS_ANI-1 && Editor_SetKachel < WALLS-1) ||
          (Editor_SetKachel > WALL_ANI-1 && Editor_SetKachel < MOVE_WALLS-1))
        {
            if(SetAnimationCircle == YES)
                SetRect(&rcRect, 45, 713, 65, 733);
            else
                SetRect(&rcRect, 45, 691, 65, 711);
            Back->BltFast(GameListeX-20, GameListeY+380, GameListPic, &rcRect, FALSE);
            if(SetAnimationLeftRight == YES)
                SetRect(&rcRect, 23, 713, 43, 733);
            else
                SetRect(&rcRect, 23, 691, 43, 711);
            Back->BltFast(GameListeX-20, GameListeY+400, GameListPic, &rcRect, FALSE);
            if(SetAnimationRandom == YES)
                SetRect(&rcRect, 67, 713, 87, 733);
            else
                SetRect(&rcRect, 67, 691, 87, 711);
            Back->BltFast(GameListeX-20, GameListeY+420, GameListPic, &rcRect, FALSE);
            sprintf(temp, "%d", SetAnimationLeftRightTurn);
	        PrintText(GameListeX-20, GameListeY+360, temp, 1, 0, 80, 80, Back);
        }
	}
} /* BuildEditorScene */

void EndProgramm(void)
{
//	PostMessage(hWnd, WM_CLOSE, 0, 0);
}
///////////////////////////////////////////////////////////////
void EditorSave(void)
{
    int i;
    char NewLevelName[256];
    MSG         msg;

   	if(UserMessage(GameTexte[T_OLD_LEVEL_WERE_DESTOYED], YES, NO, YES) == OK_BUTTON)
	{
        Eingabe(NewLevelName, 256, YES);
        for(;;)
        {
            if(PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
            {
                if(!GetMessage(&msg, NULL, 0, 0))
                    return;// msg.wParam;
                TranslateMessage(&msg);
                DispatchMessage(&msg);
            }
            else
                if(!gExclusive || bActive)
                {
                    PrintText(200, 350, NewLevelName, 0, 0, 1000, 1000, Back);
                    if(Eingabe(NewLevelName, 256, NO_AKTIV) == YES)
						break;
                    UpdateDisplay();
                    if(ExitModule == YES || ExitProgramm == YES)
                    {
                        return;
                    }
                }
                else
                {
                    WaitMessage();
                }
        }
	    for(i = 0; i < 9; i++)
		    Szenario.Info.Commands[i] = GameCommandMenu[i].Anzahl;
        Szenario.Info.LimitedTime = GameInfo.LimitedTime;
    	Szenario.Info.TimeHours = GameInfo.TimeHours;
        Szenario.Info.TimeMinutes = GameInfo.TimeMin;
        Szenario.Info.TimeSeconds = GameInfo.TimeSec;
        for(i = 0; i < (Szenario.Info.KarteB*Szenario.Info.KarteH); i++) // Alle Animationen auf Grundwert setzen
	    {
    	    if(Szenario.Info.Kachel[i].Mask != TAXI_KACHEL_SCHALTER)
        	    Szenario.Info.Kachel[i].WallPicAniStep = Szenario.Kachel[i][START_WALL_ANI_STEP];
        }
        for(i = 0; i < (Szenario.Info.KarteB*Szenario.Info.KarteH); i++) // Alle Animationen auf Grundwert setzen
            Szenario.Info.Kachel[i].PicAniStep = Szenario.Kachel[i][START_KACHEL_PIC_ANI_STEP];
		SaveLevel(NewLevelName);
    }
} /* EditorSave */

void EditorLoad(void)
{
    int i;

   	if(UserMessage(GameTexte[T_OLD_LEVEL_GOING_LOST], YES, NO, YES) == OK_BUTTON)
	{
        LoadWaitPic();
        DestroyLevelBitmaps();
        LoadLevel(SzenarioPaths[GameInfo.SelectedPath].PathName);
		LoadLevelBitmaps(Szenario.Info.SzenarioSet);
        for(i = 0; i < (Szenario.Info.KarteB*Szenario.Info.KarteH); i++) // Alle Animationen auf Grundwert setzen
            Szenario.Kachel[i][START_WALL_ANI_STEP] = Szenario.Info.Kachel[i].WallPicAniStep;
        for(i = 0; i < (Szenario.Info.KarteB*Szenario.Info.KarteH); i++) // Alle Animationen auf Grundwert setzen
            Szenario.Kachel[i][START_KACHEL_PIC_ANI_STEP] = Szenario.Info.Kachel[i].PicAniStep;
        SetBB_Message(GameTexte[T_LEVEL_WAS_LOAD], 30, -1, -1, NO_AKTIV, NO);
		DrawMini();
	}
} /* EditorLoad */

void EditorQuit(void)
{
	if(UserMessage(GameTexte[T_REALY_EXIT_THE_EDITOR_ASK], NO, YES, YES) == YES_BUTTON)
		ExitModule = YES;
} /* EditorQuit */

void EditorNewLevel(void)
{
	if(UserMessage(GameTexte[T_OLD_LEVEL_GOING_LOST], YES, NO, YES) == OK_BUTTON)
		NewLevel();
} /* EditorNewLevel */
///////////////////////////////////////////////////////////////

void CheckEditorSetChange(void)
{
    int i, x, y;

    if(Mouse.Button == RIGHT_MOUSE_BUTTON && PressedMouseScroll == NO)
    {
	    if(EditorKachelMenu[KACHEL_MENU_ON] == NO)
        	if(CheckMouseRect(GameListeX, GameListeY, GameListeX+120, GameListeY+480) == NO_AKTIV || ProgrammSetup.ShowGameListe == NO)
	    	{
             	EditorKachelMenu[KACHEL_MENU_ON] = YES;
    		    GameInfo.Befehl = NO_COMMAND;
                return;
            }
    	GameInfo.GameListe.BuiltMenu.Taxi1ButtonDown = NO;
		GameInfo.GameListe.BuiltMenu.Taxi2ButtonDown = NO;
        Editor_SetKachel = EditorKachelMenu[KACHEL_MENU_PAGE];
        switch(EditorKachelMenu[KACHEL_MENU_PAGE])
        {
            case EDITOR_WAYS:
                for(i = 0, y = 0; y < 14; y++)
                    for(x = 0; x < MAX_FLOOR_PIC_B; i++, x++)
                        if(Mouse.XPos > (x*(KACHEL_B+1)) && Mouse.YPos > (y*(KACHEL_H+1))-1 &&
                            Mouse.XPos < (x*(KACHEL_B+1)+KACHEL_B)+2 && Mouse.YPos < (y*(KACHEL_H+1)+KACHEL_H)+1)
                        {
                            Editor_SetKachel = i;
                            goto Weiter;
                        }
            break;

            case EDITOR_DEADLY:
                for(i = 532, y = 0; y < 14; y++)
                    for(x = 0; x < MAX_FLOOR_PIC_B; i++, x++)
                        if(Mouse.XPos > (x*(KACHEL_B+1)) && Mouse.YPos > (y*(KACHEL_H+1))-1 &&
                            Mouse.XPos < (x*(KACHEL_B+1)+KACHEL_B)+2 && Mouse.YPos < (y*(KACHEL_H+1)+KACHEL_H)+1)
                        {
                            Editor_SetKachel = i;
                            goto Weiter;
                        }
            break;

            case EDITOR_ANI_WAYS:
                for(i = 266+EditorKachelMenu[2], y = 0; y < 14; y++, i++)
                    for(x = 0, Editor_SetKachelAni = 0; x < MAX_FLOOR_PIC_B; x++, Editor_SetKachelAni++)
                        if(Mouse.XPos > (x*(KACHEL_B+1)) && Mouse.YPos > (y*(KACHEL_H+1)-1) &&
                            Mouse.XPos < (x*(KACHEL_B+1)+KACHEL_B)+2 && Mouse.YPos < (y*(KACHEL_H+1)+KACHEL_H)+1)
                        {
                            Editor_SetKachel = i;
                            goto Weiter;
                        }
            break;

            case EDITOR_ANI_DEADLY:
                for(i = 798, y = 0; y < 14; y++, i++)
                    for(x = 0, Editor_SetKachelAni = 0; x < MAX_FLOOR_PIC_B; x++, Editor_SetKachelAni++)
                        if(Mouse.XPos > (x*(KACHEL_B+1)) && Mouse.YPos > (y*(KACHEL_H+1)-1) &&
                            Mouse.XPos < (x*(KACHEL_B+1)+KACHEL_B)+2 && Mouse.YPos < (y*(KACHEL_H+1)+KACHEL_H)+1)
                        {
                            Editor_SetKachel = i;
                            goto Weiter;
                        }
            break;

            case EDITOR_INTEMS:
                for(i = 0, y = 0; y < MAX_FLOOR_PIC_H; y++)
                    for(x = 0; x < 266; i++, x++)
                        if(Mouse.XPos > (x*(KACHEL_B+1)) && Mouse.YPos > (y*(KACHEL_H+1))-1 &&
                            Mouse.XPos < (x*(KACHEL_B+1)+KACHEL_B)+2 && Mouse.YPos < (y*(KACHEL_H+1)+KACHEL_H)+1)
                        {
                            Editor_SetKachel += i;
                            goto Weiter;
                        }
            break;

            case EDITOR_WALLS: case EDITOR_PUSHES: case EDITOR_OBJECTS:
                for(i = EditorKachelMenu[2]*MAX_WALL_PIC_B, y = EditorKachelMenu[2]; y < EditorKachelMenu[2]+7; y++)
                    for( x = 0; x < MAX_WALL_PIC_B; i++, x++)
                        if(Mouse.XPos > (x*(WALL_B+1)) && Mouse.YPos > (y*(WALL_H+1))-1 &&
                            Mouse.XPos < (x*(WALL_B+1)+WALL_B)+2 && Mouse.YPos < (y*(WALL_H+1)+WALL_H)+1)
                            {
                                Editor_SetKachel += i;
	                            goto Weiter;
                            }
            break;

            case EDITOR_ANI_WALLS: case EDITOR_ANI_DOORS:
                for(i = EditorKachelMenu[2]*MAX_WALL_PIC_B, y = EditorKachelMenu[2]; y < EditorKachelMenu[2]+7; y++, i++)
                    for(x = 0, Editor_SetKachelAni = 0; x < MAX_WALL_PIC_B; x++, Editor_SetKachelAni++)
                        if(Mouse.XPos > (x*(WALL_B+1)) && Mouse.YPos > (y*(WALL_H+1)-1) &&
                            Mouse.XPos < (x*(WALL_B+1)+WALL_B)+2 && Mouse.YPos < (y*(WALL_H+1)+WALL_H)+1)
                        {
                            Editor_SetKachel += (i+EditorKachelMenu[2]);
	                        goto Weiter;
                        }
            break;
        }
    Weiter:
        if(TimerNew2 == NO)
        	return;
        TimerNew2 = NO;
        if(Mouse.XPos == Mouse.BoundXB)
        {
            switch(EditorKachelMenu[KACHEL_MENU_PAGE])
            {
                case EDITOR_WAYS:       EditorKachelMenu[KACHEL_MENU_PAGE] = EDITOR_ANI_WAYS; break;
                case EDITOR_ANI_WAYS:   EditorKachelMenu[KACHEL_MENU_PAGE] = EDITOR_DEADLY; break;
                case EDITOR_DEADLY:     EditorKachelMenu[KACHEL_MENU_PAGE] = EDITOR_ANI_DEADLY; break;
                case EDITOR_ANI_DEADLY:	EditorKachelMenu[KACHEL_MENU_PAGE] = EDITOR_INTEMS; break;
                case EDITOR_INTEMS:	    EditorKachelMenu[KACHEL_MENU_PAGE] = EDITOR_WALLS; break;
                case EDITOR_WALLS:      EditorKachelMenu[KACHEL_MENU_PAGE] = EDITOR_ANI_WALLS; break;
                case EDITOR_ANI_WALLS:  EditorKachelMenu[KACHEL_MENU_PAGE] = EDITOR_PUSHES; break;
                case EDITOR_PUSHES:     EditorKachelMenu[KACHEL_MENU_PAGE] = EDITOR_OBJECTS; break;
                case EDITOR_OBJECTS:    EditorKachelMenu[KACHEL_MENU_PAGE] = EDITOR_ANI_DOORS; break;
                case EDITOR_ANI_DOORS:  EditorKachelMenu[KACHEL_MENU_PAGE] = EDITOR_WAYS; break;
            }
        }
        if(Mouse.XPos == Mouse.BoundX)
        {
            switch(EditorKachelMenu[KACHEL_MENU_PAGE])
            {
                case EDITOR_WAYS: EditorKachelMenu[KACHEL_MENU_PAGE] = EDITOR_ANI_DOORS; break;
                case EDITOR_ANI_WAYS: EditorKachelMenu[KACHEL_MENU_PAGE] = EDITOR_WAYS; break;
                case EDITOR_DEADLY: EditorKachelMenu[KACHEL_MENU_PAGE] = EDITOR_ANI_WAYS; break;
                case EDITOR_ANI_DEADLY:	EditorKachelMenu[KACHEL_MENU_PAGE] = EDITOR_DEADLY; break;
                case EDITOR_INTEMS:	EditorKachelMenu[KACHEL_MENU_PAGE] = EDITOR_ANI_DEADLY; break;
                case EDITOR_WALLS: EditorKachelMenu[KACHEL_MENU_PAGE] = EDITOR_INTEMS; break;
                case EDITOR_ANI_WALLS: EditorKachelMenu[KACHEL_MENU_PAGE] = EDITOR_WALLS; break;
                case EDITOR_PUSHES: EditorKachelMenu[KACHEL_MENU_PAGE] = EDITOR_ANI_WALLS; break;
                case EDITOR_OBJECTS: EditorKachelMenu[KACHEL_MENU_PAGE] = EDITOR_PUSHES; break;
                case EDITOR_ANI_DOORS: EditorKachelMenu[KACHEL_MENU_PAGE] = EDITOR_OBJECTS; break;
            }
        }
        if(Mouse.YPos == Mouse.BoundY)
            if(EditorKachelMenu[2] > 0)
                EditorKachelMenu[2]--;
        if(Mouse.YPos == Mouse.BoundYH)
            if(EditorKachelMenu[2] < 5)
                EditorKachelMenu[2]++;
        if(EditorKachelMenu[KACHEL_MENU_PAGE] != EDITOR_ANI_WAYS)
        	EditorKachelMenu[2] = 0;
		GameInfo.Befehl = NO_COMMAND;
    }
   	else
    	EditorKachelMenu[KACHEL_MENU_ON] = NO;
} /* CheckEditorSetChange */



/* Module  "FoolAnimate.h":                                           (Project:  Fools)
	Animiete die Bewegungen der Fools:
*/

int CheckFoolAni(int);
int CheckFoolTurnAni(int);
int CheckFoolSillyAni(int, int);
void CheckFoolWalkAni(int);
int CheckFoolBeamAni(int);
int CheckFoolWaitAni(int);
int CheckFoolJumpAni(int);
void TurnFool(int);

//////////////////////////////////////////////////////////////////////////////////////////

int CheckFoolAni(int i)
{
    if(Szenario.Info.FoolInfo[i].OnLive == NO || Szenario.Info.FoolInfo[i].OnLive == FINISH)
    {
        if(Szenario.Info.FoolInfo[i].AnimationTurn == 0)
        {
            Szenario.Info.FoolInfo[i].AnimationStep++;
            if(Szenario.Info.FoolInfo[i].AnimationStep > 3)
                Szenario.Info.FoolInfo[i].AnimationTurn = 1;
        }
        else
        {
            Szenario.Info.FoolInfo[i].AnimationStep--;
            if(Szenario.Info.FoolInfo[i].AnimationStep < 1)
                Szenario.Info.FoolInfo[i].AnimationTurn = 0;
        }
        return YES;
    }
    if(Szenario.Info.FoolInfo[i].Animation == ON_FINISH)
    {
        int Timer;
        static int LastTimer = 0;

        Timer = timeGetTime()-LastTimer;
        if(Timer < ProgrammSetup.GameSpeed+50)
	        return YES;
        LastTimer = timeGetTime();
        Szenario.Info.FoolInfo[i].AnimationStep++;
        if(Szenario.Info.FoolInfo[i].PixelPosX > -20)
            Szenario.Info.FoolInfo[i].PixelPosX -= 2;
        if(Szenario.Info.FoolInfo[i].AnimationStep > 19)
        {
            Szenario.Info.FoolInfo[i].OnLive = FINISH;
            GameInfo.LiveFools--;
            GameInfo.FinishFools++;
            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Besetzt = NO_AKTIV;
            DrawMiniKachel(Szenario.Info.FoolInfo[i].PosX, Szenario.Info.FoolInfo[i].PosY);
        }
        return YES;
    }
    if(Szenario.Info.FoolInfo[i].Animation == WRONG_EXIT_PAGE)
    {
        Szenario.Info.FoolInfo[i].PixelPosX--;
        if(Szenario.Info.FoolInfo[i].PixelPosX > -15)
            Szenario.Info.FoolInfo[i].Power -= 2;
        if(Szenario.Info.FoolInfo[i].PixelPosX < -KACHEL_B)
        {
            Szenario.Info.FoolInfo[i].Animation = Szenario.Info.FoolInfo[i].Richtung;
            Szenario.Info.FoolInfo[i].AnimationStep = 0;
        }
        CheckFoolWalkAni(i);
    }
   return NO;
} /* CheckFoolAni */

// Animiert die Bewegungen der Fools:
int CheckFoolTurnAni(int i)
{
    if(Szenario.Info.FoolInfo[i].Animation == TURN_LEFT || Szenario.Info.FoolInfo[i].Animation == TURN_RIGHT)
    { // Der Fool dreht sich gerade:
        TurnFool(i);
        return YES;
    }
    return NO;
} /* CheckFoolTurnAni */

int CheckFoolSillyAni(int i, int Intro)
{
    if(Szenario.Info.FoolInfo[i].Animation == SILLY_LEFT || Szenario.Info.FoolInfo[i].Animation == SILLY_RIGHT ||
        Szenario.Info.FoolInfo[i].Animation == SILLY_UP || Szenario.Info.FoolInfo[i].Animation == SILLY_DOWN)
    { // Der Fool wei� nicht weiter:
        if(Szenario.Info.FoolInfo[i].AnimationBackTurn == 0)
            if(Szenario.Info.FoolInfo[i].AnimationStep < (MAX_FOOL_ANIMATION*2))
                Szenario.Info.FoolInfo[i].AnimationStep++;
            else
                Szenario.Info.FoolInfo[i].AnimationBackTurn = 1;
        else
            if(Szenario.Info.FoolInfo[i].AnimationStep > 0)
                Szenario.Info.FoolInfo[i].AnimationStep--;
            else
            {
                Szenario.Info.FoolInfo[i].AnimationBackTurn = 0;
                if(Szenario.Info.FoolInfo[i].AnimationTurn != NO_AKTIV && Intro == NO)
                {
                    Szenario.Info.FoolInfo[i].Animation = Szenario.Info.FoolInfo[i].AnimationTurn;
                    Szenario.Info.FoolInfo[i].Richtung = Szenario.Info.FoolInfo[i].AnimationTurn;
                }
                Szenario.Info.FoolInfo[i].AnimationTurn = 0;
            }
        return YES;
    }
    return NO;
} /* CheckFoolSillyAni */

int CheckFoolBeamAni(int i)
{
    if(Szenario.Info.FoolInfo[i].Animation != BEAMING_START && Szenario.Info.FoolInfo[i].Animation != BEAMING_START_END &&
    	Szenario.Info.FoolInfo[i].Animation != BEAMING_END)
	    return NO;
    if(Szenario.Info.FoolInfo[i].Animation == BEAMING_START)
	{
    	Szenario.Info.FoolInfo[i].AnimationStep++;
    	if(Szenario.Info.FoolInfo[i].AnimationStep > 19)
			Szenario.Info.FoolInfo[i].Animation = BEAMING_START_END;
    	return YES;
    }
    if(Szenario.Info.FoolInfo[i].Animation == BEAMING_START_END)
	{
		Szenario.Info.FoolInfo[i].Animation = BEAMING_END;
        Szenario.Info.FoolInfo[i].AnimationStep = 0;
    	return YES;
    }
    if(Szenario.Info.FoolInfo[i].Animation == BEAMING_END)
	{
    	Szenario.Info.FoolInfo[i].AnimationStep++;
    	if(Szenario.Info.FoolInfo[i].AnimationStep > 19)
        {
			Szenario.Info.FoolInfo[i].Animation = Szenario.Info.FoolInfo[i].Richtung;
            Szenario.Info.FoolInfo[i].AnimationStep = 0;
        }
    	return YES;
    }
    return NO;
} /* CheckFoolBeamAni */

void CheckFoolWalkAni(int i)
{
    switch(Szenario.Info.FoolInfo[i].AnimationTurn)
    {
        case 0:
            if(Szenario.Info.FoolInfo[i].AnimationBackTurn == 0)
                if(Szenario.Info.FoolInfo[i].AnimationStep < MAX_FOOL_ANIMATION)
                    Szenario.Info.FoolInfo[i].AnimationStep++;
                else
                    Szenario.Info.FoolInfo[i].AnimationBackTurn = 1;
            else
                if(Szenario.Info.FoolInfo[i].AnimationBackTurn == 1)
                    if(Szenario.Info.FoolInfo[i].AnimationStep > 0)
                        Szenario.Info.FoolInfo[i].AnimationStep--;
                    else
                    {
                        Szenario.Info.FoolInfo[i].AnimationBackTurn = 0;
                        Szenario.Info.FoolInfo[i].AnimationStep = MAX_FOOL_ANIMATION+1;
                        Szenario.Info.FoolInfo[i].AnimationTurn = 1;
                    }
        break;

        case 1:
            if(Szenario.Info.FoolInfo[i].AnimationBackTurn == 0)
                if(Szenario.Info.FoolInfo[i].AnimationStep < (MAX_FOOL_ANIMATION*2)+1)
                    Szenario.Info.FoolInfo[i].AnimationStep++;
                else
                    Szenario.Info.FoolInfo[i].AnimationBackTurn = 1;
            else
                if(Szenario.Info.FoolInfo[i].AnimationBackTurn == 1)
                    if(Szenario.Info.FoolInfo[i].AnimationStep > (MAX_FOOL_ANIMATION+1))
                        Szenario.Info.FoolInfo[i].AnimationStep--;
                    else
                    {
                        Szenario.Info.FoolInfo[i].AnimationBackTurn = 0;
                        Szenario.Info.FoolInfo[i].AnimationTurn = 0;
                        Szenario.Info.FoolInfo[i].AnimationStep = 0;
                    }
        break;
    }
} /* CheckFoolWalkAni */

int CheckFoolWaitAni(int i)
{
    int Timer;
    static int LastTimer = 0;

    CheckBefehle(i, NO);
    if(Szenario.Info.FoolInfo[i].Befehl == COMMAND_WAIT && Szenario.Info.FoolInfo[i].Animation == WAITING)
    {
	    if(Szenario.Info.FoolInfo[i].AnimationStep < 4)
	        Szenario.Info.FoolInfo[i].AnimationStep++;
		else
        {
            Timer = timeGetTime()-LastTimer;
            if(Timer < 1000)
                return YES;
            LastTimer = timeGetTime();
			Szenario.Info.FoolInfo[i].AnimationTurn--;
			if(Szenario.Info.FoolInfo[i].AnimationTurn < 0)
            {
			    Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.FoolInfo[i].PosX][Szenario.Info.FoolInfo[i].PosY]].Command = NO_COMMAND;
				Szenario.Info.FoolInfo[i].AnimationTurn = 0;
            }
        }
    	return YES;
    }
    else
    {
	    if(Szenario.Info.FoolInfo[i].Animation == WAITING)
		{
            if(Szenario.Info.FoolInfo[i].AnimationStep > 0)
		    {
                Szenario.Info.FoolInfo[i].AnimationStep--;
		    	return YES;
            }
    		else
            {
                Szenario.Info.FoolInfo[i].Animation = Szenario.Info.FoolInfo[i].Richtung+SILLY_LEFT;
				Szenario.Info.FoolInfo[i].AnimationTurn = 1;
            }
    	}
    }
   	return NO;
} /* CheckFoolWaitAni */

// Der Fool dreht sich in eine neue Richtung:
void TurnFool(int i)
{
    int Check;

    if(Szenario.Info.FoolInfo[i].AnimationPlusMinus == PLUS)
        Szenario.Info.FoolInfo[i].AnimationStep++;
    else
        Szenario.Info.FoolInfo[i].AnimationStep--;
    if(Szenario.Info.FoolInfo[i].AnimationPlusMinus == PLUS &&
        Szenario.Info.FoolInfo[i].AnimationStep > MAX_TURN_ANI)
        Check = YES;
    if(Szenario.Info.FoolInfo[i].AnimationPlusMinus == MINUS &&
        Szenario.Info.FoolInfo[i].AnimationStep < 0)
        Check = YES;
    if(Check == YES)
    {
        if(Szenario.Info.FoolInfo[i].AnimationPlusMinus == PLUS)
            Szenario.Info.FoolInfo[i].AnimationStep = 0;
        else
            Szenario.Info.FoolInfo[i].AnimationStep = MAX_TURN_ANI;
        if(Szenario.Info.FoolInfo[i].Animation == TURN_RIGHT)
        {   // Der Fool dreht sich nach rechts:
            switch(Szenario.Info.FoolInfo[i].AnimationInfo)
            {
                case WALK_LEFT:
                    if(Szenario.Info.FoolInfo[i].AnimationPlusMinus == PLUS)
                        Szenario.Info.FoolInfo[i].AnimationInfo = WALK_DOWN;
                    else
                        Szenario.Info.FoolInfo[i].AnimationInfo = WALK_UP;
                break;

                case WALK_RIGHT:
                    if(Szenario.Info.FoolInfo[i].AnimationPlusMinus == PLUS)
                        Szenario.Info.FoolInfo[i].AnimationInfo = WALK_UP;
                    else
                        Szenario.Info.FoolInfo[i].AnimationInfo = WALK_DOWN;
                break;

                case WALK_UP:
                    if(Szenario.Info.FoolInfo[i].AnimationPlusMinus == PLUS)
                        Szenario.Info.FoolInfo[i].AnimationInfo = WALK_LEFT;
                    else
                        Szenario.Info.FoolInfo[i].AnimationInfo = WALK_RIGHT;
                break;

                case WALK_DOWN:
                    if(Szenario.Info.FoolInfo[i].AnimationPlusMinus == PLUS)
                        Szenario.Info.FoolInfo[i].AnimationInfo = WALK_RIGHT;
                    else
                        Szenario.Info.FoolInfo[i].AnimationInfo = WALK_LEFT;
                break;
            }
        }
        if(Szenario.Info.FoolInfo[i].Animation == TURN_LEFT)
        {  // Der Fool dreht sich nach links:
            switch(Szenario.Info.FoolInfo[i].AnimationInfo)
            {
                case WALK_LEFT:
                    if(Szenario.Info.FoolInfo[i].AnimationPlusMinus == PLUS)
                        Szenario.Info.FoolInfo[i].AnimationInfo = WALK_UP;
                    else
                        Szenario.Info.FoolInfo[i].AnimationInfo = WALK_DOWN;
                break;

                case WALK_RIGHT:
                    if(Szenario.Info.FoolInfo[i].AnimationPlusMinus == PLUS)
                        Szenario.Info.FoolInfo[i].AnimationInfo = WALK_DOWN;
                    else
                        Szenario.Info.FoolInfo[i].AnimationInfo = WALK_UP;
                break;

                case WALK_UP:
                    if(Szenario.Info.FoolInfo[i].AnimationPlusMinus == PLUS)
                        Szenario.Info.FoolInfo[i].AnimationInfo = WALK_RIGHT;
                    else
                        Szenario.Info.FoolInfo[i].AnimationInfo = WALK_LEFT;
                break;

                case WALK_DOWN:
                    if(Szenario.Info.FoolInfo[i].AnimationPlusMinus == PLUS)
                        Szenario.Info.FoolInfo[i].AnimationInfo = WALK_LEFT;
                    else
                        Szenario.Info.FoolInfo[i].AnimationInfo = WALK_RIGHT;
                break;
            }
        }
        if(Szenario.Info.FoolInfo[i].AnimationInfo == Szenario.Info.FoolInfo[i].Richtung)
        { // Der Fool ist fertig mit dem drehen:
            Szenario.Info.FoolInfo[i].Animation = Szenario.Info.FoolInfo[i].AnimationInfo;
            Szenario.Info.FoolInfo[i].AnimationStep = 0;
            Szenario.Info.FoolInfo[i].AnimationTurn = 0;
            if(Szenario.Info.FoolInfo[i].Befehl == PUSH_LEFT)
	            Szenario.Info.FoolInfo[i].Animation = ON_PUSH_LEFT;
            if(Szenario.Info.FoolInfo[i].Befehl == PUSH_RIGHT)
	            Szenario.Info.FoolInfo[i].Animation = ON_PUSH_RIGHT;
            if(Szenario.Info.FoolInfo[i].Befehl == PUSH_DOWN)
	            Szenario.Info.FoolInfo[i].Animation = ON_PUSH_DOWN;
            if(Szenario.Info.FoolInfo[i].Befehl == PUSH_UP)
	            Szenario.Info.FoolInfo[i].Animation = ON_PUSH_UP;
            return;
        }
        if(Szenario.Info.FoolInfo[i].AnimationInfo == WALK_UP && Szenario.Info.FoolInfo[i].Richtung == WALK_RIGHT)
        {
            Szenario.Info.FoolInfo[i].Animation = TURN_LEFT;
            Szenario.Info.FoolInfo[i].AnimationStep = 0;
            Szenario.Info.FoolInfo[i].AnimationTurn = 1;
            Szenario.Info.FoolInfo[i].AnimationPlusMinus = PLUS;
            return;
        }
        if(Szenario.Info.FoolInfo[i].AnimationInfo == WALK_DOWN && Szenario.Info.FoolInfo[i].Richtung == WALK_LEFT)
        {
            Szenario.Info.FoolInfo[i].Animation = TURN_RIGHT;
            Szenario.Info.FoolInfo[i].AnimationStep = MAX_TURN_ANI;
            Szenario.Info.FoolInfo[i].AnimationTurn = 0;
            Szenario.Info.FoolInfo[i].AnimationPlusMinus = MINUS;
            return;
        }
        if(Szenario.Info.FoolInfo[i].AnimationInfo == WALK_RIGHT && Szenario.Info.FoolInfo[i].Richtung == WALK_DOWN)
        {
            Szenario.Info.FoolInfo[i].Animation = TURN_RIGHT;
            Szenario.Info.FoolInfo[i].AnimationStep = MAX_TURN_ANI;
            Szenario.Info.FoolInfo[i].AnimationTurn = 1;
            Szenario.Info.FoolInfo[i].AnimationPlusMinus = MINUS;
            return;
        }
        if(Szenario.Info.FoolInfo[i].AnimationInfo == WALK_LEFT && Szenario.Info.FoolInfo[i].Richtung == WALK_UP)
        {
            Szenario.Info.FoolInfo[i].Animation = TURN_LEFT;
            Szenario.Info.FoolInfo[i].AnimationStep = 0;
            Szenario.Info.FoolInfo[i].AnimationTurn = 0;
            Szenario.Info.FoolInfo[i].AnimationPlusMinus = PLUS;
            return;
        }
    }
} /* TurnFool */
//////////////////////////////////////////////////////////////////////////////////////////
int CheckFoolJumpAni(int i)
{
    if(Szenario.Info.FoolInfo[i].Befehl != COMMAND_JUMP)
		return NO;
    switch(Szenario.Info.FoolInfo[i].Richtung)
    {
    	case WALK_LEFT:
            if(Szenario.Info.FoolInfo[i].PixelPosX > 0)
            {
                Szenario.Info.FoolInfo[i].PixelPosX -= 2;
                if(Szenario.Info.FoolInfo[i].AnimationTurn == FIRST_JUMP)
                {
		            Szenario.Info.FoolInfo[i].PixelPosY--;
                }
                if(Szenario.Info.FoolInfo[i].AnimationTurn == LAST_JUMP)
                {
		            Szenario.Info.FoolInfo[i].PixelPosY++;
                }
                break;
            }
           	if(Szenario.Info.FoolInfo[i].PixelPosX < 0)
	            Szenario.Info.FoolInfo[i].PixelPosX = 0;
            // Das erste Feld w�re nun �bersprungen:
            if(Szenario.Info.FoolInfo[i].AnimationTurn == LAST_JUMP)
            	break;
            if(CheckFoolJump(i, WALK_LEFT, NO) == NO)
            { // Mist, eine Wand ist backbord voraus... autsch der Fool brallt ab:
                Szenario.Info.FoolInfo[i].PixelPosY = 0;
                Szenario.Info.FoolInfo[i].AnimationStep = 0;
                Szenario.Info.FoolInfo[i].AnimationTurn = -1;
                Szenario.Info.FoolInfo[i].AnimationBackTurn = 0;
                Szenario.Info.FoolInfo[i].Animation = Szenario.Info.FoolInfo[i].Richtung+SILLY_LEFT;
            }
        break;

    	case WALK_RIGHT:
            if(Szenario.Info.FoolInfo[i].PixelPosX < 0)
            {
                Szenario.Info.FoolInfo[i].PixelPosX += 2;
            	if(Szenario.Info.FoolInfo[i].PixelPosX > 0)
		            Szenario.Info.FoolInfo[i].PixelPosX = 0;
                if(Szenario.Info.FoolInfo[i].AnimationTurn == FIRST_JUMP)
                {
		            Szenario.Info.FoolInfo[i].PixelPosY--;
                }
                if(Szenario.Info.FoolInfo[i].AnimationTurn == LAST_JUMP)
                {
		            Szenario.Info.FoolInfo[i].PixelPosY++;
                }
                break;
            }
            // Das erste Feld w�re nun �bersprungen:
            if(Szenario.Info.FoolInfo[i].AnimationTurn == FIRST_JUMP)
			{
            	if(CheckFoolJump(i, WALK_LEFT, NO) == NO)
                { // Mist, eine Wand ist backbord voraus... autsch der Fool brallt ab:
		            Szenario.Info.FoolInfo[i].PixelPosY = 0;
                    Szenario.Info.FoolInfo[i].AnimationStep = 0;
                    Szenario.Info.FoolInfo[i].AnimationTurn = -1;
                    Szenario.Info.FoolInfo[i].AnimationBackTurn = 0;
                    Szenario.Info.FoolInfo[i].Animation = Szenario.Info.FoolInfo[i].Richtung+SILLY_LEFT;
                }
            }
        break;

    	case WALK_UP:
            if(Szenario.Info.FoolInfo[i].PixelPosY > 0)
            {
                Szenario.Info.FoolInfo[i].PixelPosY -= 2;
            	if(Szenario.Info.FoolInfo[i].PixelPosY < 0)
		            Szenario.Info.FoolInfo[i].PixelPosY = 0;
                if(Szenario.Info.FoolInfo[i].AnimationTurn == FIRST_JUMP)
                {
		            Szenario.Info.FoolInfo[i].PixelPosY--;
                }
                if(Szenario.Info.FoolInfo[i].AnimationTurn == LAST_JUMP)
                {
		            Szenario.Info.FoolInfo[i].PixelPosY++;
                }
                break;
            }
            // Das erste Feld w�re nun �bersprungen:
            if(Szenario.Info.FoolInfo[i].AnimationTurn == FIRST_JUMP)
			{
            	if(CheckFoolJump(i, WALK_LEFT, NO) == NO)
                { // Mist, eine Wand ist backbord voraus... autsch der Fool brallt ab:
		            Szenario.Info.FoolInfo[i].PixelPosY = 0;
                    Szenario.Info.FoolInfo[i].AnimationStep = 0;
                    Szenario.Info.FoolInfo[i].AnimationTurn = -1;
                    Szenario.Info.FoolInfo[i].AnimationBackTurn = 0;
                    Szenario.Info.FoolInfo[i].Animation = Szenario.Info.FoolInfo[i].Richtung+SILLY_LEFT;
                }
            }
        break;

    	case WALK_DOWN:
            if(Szenario.Info.FoolInfo[i].PixelPosY < 0)
            {
                Szenario.Info.FoolInfo[i].PixelPosY += 2;
            	if(Szenario.Info.FoolInfo[i].PixelPosY > 0)
		            Szenario.Info.FoolInfo[i].PixelPosY = 0;
                if(Szenario.Info.FoolInfo[i].AnimationTurn == FIRST_JUMP)
                {
		            Szenario.Info.FoolInfo[i].PixelPosY--;
                }
                if(Szenario.Info.FoolInfo[i].AnimationTurn == LAST_JUMP)
                {
		            Szenario.Info.FoolInfo[i].PixelPosY++;
                }
                break;
            }
            // Das erste Feld w�re nun �bersprungen:
            if(Szenario.Info.FoolInfo[i].AnimationTurn == FIRST_JUMP)
			{
            	if(CheckFoolJump(i, WALK_LEFT, NO) == NO)
                { // Mist, eine Wand ist backbord voraus... autsch der Fool brallt ab:
		            Szenario.Info.FoolInfo[i].PixelPosY = 0;
                    Szenario.Info.FoolInfo[i].AnimationStep = 0;
                    Szenario.Info.FoolInfo[i].AnimationTurn = -1;
                    Szenario.Info.FoolInfo[i].AnimationBackTurn = 0;
                    Szenario.Info.FoolInfo[i].Animation = Szenario.Info.FoolInfo[i].Richtung+SILLY_LEFT;
                }
            }
        break;
    }
   	return YES;
} /* CheckFoolJumpAni */


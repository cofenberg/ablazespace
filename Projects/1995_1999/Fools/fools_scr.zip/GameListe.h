#include "GameListeInc.h"

extern int InfoVar;
extern int Editor_SetKachel;
extern int Editor_SetKachelAni;
extern LPDIRECTDRAWSURFACE FoolSelectedPic;
extern LPDIRECTDRAWSURFACE  CommandMenuAniPic;
extern void DrawVirtualScene(int);
extern void GameSave(void);
extern void GameLoad(void);
extern void	GameNewStart(void);
extern void GameQuit(void);
extern void EditorSave(void);
extern void EditorLoad(void);
extern void EditorQuit(void);
extern void EditorNewLevel(void);

void InitGameListe(int);
void CheckGameListe(int);
void DrawGameListe(int);

void DrawSzenarioMenu(void);
void DrawObjectsMenu(void);
void CheckObjectsMenu(void);
void CheckSetCommandsMenu(void);
void DrawFoolsStatMenu(void);
void CheckFoolsStatMenu(void);
void SetAllInfoButtonsOff(void);

void AllObermenusOff(void);

int CommandSetSpeed = 1;
int InfoFoolStep = 0;
int InfoSelectedFool = 0;
int PressedButton;
int ObjectsMenuPage = 0;

int GiveFoolANewName = NO;
char NewFoolName[256];

#define MAX_INFO_FOOLS 4
//////////////////////////////////////////////////////////////////////////
extern int GameListeX, GameListeY;
#include "GameListeBuilt.h"
void InitGameListe(int Module)
{
    int i, i2, i3;

    ObjectsMenuPage = 0;
	GameInfo.GameListe.ButtonB = 20;
	GameInfo.GameListe.ButtonH = 20;
	GameInfo.GameListe.BuiltDown = NO;
	GameInfo.GameListe.BuiltX = GameListeX+10;
	GameInfo.GameListe.BuiltY = GameListeY+133;
	GameInfo.GameListe.InfosDown = NO;
	GameInfo.GameListe.InfosX = GameListeX+35;
	GameInfo.GameListe.InfosY = GameListeY+133;
	GameInfo.GameListe.StatistikDown = NO;
	GameInfo.GameListe.StatistikX = GameListeX+60;
	GameInfo.GameListe.StatistikY = GameListeY+133;
	GameInfo.GameListe.OptionsDown = NO;
	GameInfo.GameListe.OptionsX = GameListeX+85;
	GameInfo.GameListe.OptionsY = GameListeY+133;

	//////////////////////////////////////////////////////////////////////////
    // Fool Inspektions Men�:
        GameInfo.GameListe.BuiltMenu.SelectFoolButtonDown = NO;
        GameInfo.GameListe.BuiltMenu.SelectFoolButtonX = GameListeX;
        GameInfo.GameListe.BuiltMenu.SelectFoolButtonY = GameListeY+200;
        GameInfo.GameListe.BuiltMenu.FoolNameButtonDown = NO;
        GameInfo.GameListe.BuiltMenu.FoolNameButtonX = GameListeX+42;
        GameInfo.GameListe.BuiltMenu.FoolNameButtonY = GameListeY+210;
        GameInfo.GameListe.BuiltMenu.PowerFoolButtonDown = NO;
        GameInfo.GameListe.BuiltMenu.PowerFoolButtonX = GameListeX+42;
        GameInfo.GameListe.BuiltMenu.PowerFoolButtonY = GameListeY+230;
        GameInfo.GameListe.BuiltMenu.Intem1ButtonDown = NO;
        GameInfo.GameListe.BuiltMenu.Intem1ButtonX = GameListeX+10;
        GameInfo.GameListe.BuiltMenu.Intem1ButtonY = GameListeY+280;
        GameInfo.GameListe.BuiltMenu.Intem2ButtonDown = NO;
        GameInfo.GameListe.BuiltMenu.Intem2ButtonX = GameListeX+60;
        GameInfo.GameListe.BuiltMenu.Intem2ButtonY = GameListeY+280;
        GameInfo.GameListe.BuiltMenu.Intem3ButtonDown = NO;
        GameInfo.GameListe.BuiltMenu.Intem3ButtonX = GameListeX+10;
        GameInfo.GameListe.BuiltMenu.Intem3ButtonY = GameListeY+325;
        GameInfo.GameListe.BuiltMenu.Intem4ButtonDown = NO;
        GameInfo.GameListe.BuiltMenu.Intem4ButtonX = GameListeX+60;
        GameInfo.GameListe.BuiltMenu.Intem4ButtonY = GameListeY+325;
        GameInfo.GameListe.BuiltMenu.Intem5ButtonDown = NO;
        GameInfo.GameListe.BuiltMenu.Intem5ButtonX = GameListeX+10;
        GameInfo.GameListe.BuiltMenu.Intem5ButtonY = GameListeY+370;
        GameInfo.GameListe.BuiltMenu.Intem6ButtonDown = NO;
        GameInfo.GameListe.BuiltMenu.Intem6ButtonX = GameListeX+60;
        GameInfo.GameListe.BuiltMenu.Intem6ButtonY = GameListeY+370;
		//////////////////////////////////////////////////////////////////////////
        GameInfo.GameListe.BuiltMenu.SelectKachelFloorButtonDown = NO;
        GameInfo.GameListe.BuiltMenu.SelectKachelFloorButtonX = GameListeX+10;
        GameInfo.GameListe.BuiltMenu.SelectKachelFloorButtonY = GameListeY+200;
        GameInfo.GameListe.BuiltMenu.SelectKachelFloorLeftButtonDown = NO;
        GameInfo.GameListe.BuiltMenu.SelectKachelFloorLeftButtonX = GameListeX+4;
        GameInfo.GameListe.BuiltMenu.SelectKachelFloorLeftButtonY = GameListeY+200;
        GameInfo.GameListe.BuiltMenu.SelectKachelFloorUpButtonDown = NO;
        GameInfo.GameListe.BuiltMenu.SelectKachelFloorUpButtonX = GameListeX+4;
        GameInfo.GameListe.BuiltMenu.SelectKachelFloorUpButtonY = GameListeY+194;
        GameInfo.GameListe.BuiltMenu.SelectKachelMaskButtonDown = NO;
        GameInfo.GameListe.BuiltMenu.SelectKachelMaskButtonX = GameListeX+15+KACHEL_B;
        GameInfo.GameListe.BuiltMenu.SelectKachelMaskButtonY = GameListeY+210;
        GameInfo.GameListe.BuiltMenu.SelectKachelIntemButtonDown = NO;
        GameInfo.GameListe.BuiltMenu.SelectKachelIntemButtonX = GameListeX+15+KACHEL_B;
        GameInfo.GameListe.BuiltMenu.SelectKachelIntemButtonY = GameListeY+215+KACHEL_H;
        GameInfo.GameListe.BuiltMenu.SelectKachelCommandButtonDown = NO;
        GameInfo.GameListe.BuiltMenu.SelectKachelCommandButtonX = GameListeX+15+KACHEL_B;
        GameInfo.GameListe.BuiltMenu.SelectKachelCommandButtonY = GameListeY+220+KACHEL_H+KACHEL_H;
        GameInfo.GameListe.BuiltMenu.SelectKachelWallButtonDown = NO;
        GameInfo.GameListe.BuiltMenu.SelectKachelWallButtonX = GameListeX+10;
        GameInfo.GameListe.BuiltMenu.SelectKachelWallButtonY = GameListeY+200+KACHEL_H+5;
		//////////////////////////////////////////////////////////////////////////
        GameInfo.GameListe.BuiltMenu.Taxi1ButtonDown = NO;
        GameInfo.GameListe.BuiltMenu.Taxi1ButtonX = GameListeX+10;
        GameInfo.GameListe.BuiltMenu.Taxi1ButtonY = GameListeY+350;
        GameInfo.GameListe.BuiltMenu.Taxi2ButtonDown = NO;
        GameInfo.GameListe.BuiltMenu.Taxi2ButtonX = GameListeX+70;
        GameInfo.GameListe.BuiltMenu.Taxi2ButtonY = GameListeY+350;
        GameInfo.GameListe.BuiltMenu.Taxi1RichtungButtonDown = NO;
        GameInfo.GameListe.BuiltMenu.Taxi1RichtungButtonX = GameListeX+10;
        GameInfo.GameListe.BuiltMenu.Taxi1RichtungButtonY = GameListeY+400;
        GameInfo.GameListe.BuiltMenu.Taxi2RichtungButtonDown = NO;
        GameInfo.GameListe.BuiltMenu.Taxi2RichtungButtonX = GameListeX+70;
        GameInfo.GameListe.BuiltMenu.Taxi2RichtungButtonY = GameListeY+400;
		//////////////////////////////////////////////////////////////////////////
        GameInfo.GameListe.BuiltMenu.AnzahlButtonDown = NO;
        GameInfo.GameListe.BuiltMenu.AnzahlButtonX = GameListeX+10;
        GameInfo.GameListe.BuiltMenu.AnzahlButtonY = GameListeY+160;
        GameInfo.GameListe.BuiltMenu.DeleteButtonDown = NO;
        GameInfo.GameListe.BuiltMenu.DeleteButtonX = GameListeX+70;
        GameInfo.GameListe.BuiltMenu.DeleteButtonY = GameListeY+180;
	//////////////////////////////////////////////////////////////////////////
	GameInfo.GameListe.ObjectsMenu.PageUpButtonDown = NO;
	GameInfo.GameListe.ObjectsMenu.PageUpButtonX = GameListeX+50;
	GameInfo.GameListe.ObjectsMenu.PageUpButtonY = GameListeY+170;
	GameInfo.GameListe.ObjectsMenu.PageDownButtonDown = NO;
	GameInfo.GameListe.ObjectsMenu.PageDownButtonX = GameListeX+80;
	GameInfo.GameListe.ObjectsMenu.PageDownButtonY = GameListeY+170;
   // Page 1:
	GameInfo.GameListe.ObjectsMenu.SetFoolButtonDown = NO;
	GameInfo.GameListe.ObjectsMenu.SetFoolButtonX = GameListeX+10;
	GameInfo.GameListe.ObjectsMenu.SetFoolButtonY = GameListeY+180;
	GameInfo.GameListe.ObjectsMenu.SetGegnerDrohneButtonDown = NO;
	GameInfo.GameListe.ObjectsMenu.SetGegnerDrohneButtonX = GameListeX+10;
	GameInfo.GameListe.ObjectsMenu.SetGegnerDrohneButtonY = GameListeY+330;
	GameInfo.GameListe.ObjectsMenu.SetInstabilButtonDown = NO;
	GameInfo.GameListe.ObjectsMenu.SetInstabilButtonX = GameListeX+10;
	GameInfo.GameListe.ObjectsMenu.SetInstabilButtonY = GameListeY+190+FOOL_H+20;
	GameInfo.GameListe.ObjectsMenu.SetAtomikButtonDown = NO;
	GameInfo.GameListe.ObjectsMenu.SetAtomikButtonX = GameListeX+10+KACHEL_B+10;
	GameInfo.GameListe.ObjectsMenu.SetAtomikButtonY = GameListeY+190+FOOL_H+20;
	GameInfo.GameListe.ObjectsMenu.SetTaxiKachelButtonDown = NO;
	GameInfo.GameListe.ObjectsMenu.SetTaxiKachelButtonX = GameListeX+10+KACHEL_B+10;
	GameInfo.GameListe.ObjectsMenu.SetTaxiKachelButtonY = GameListeY+190+FOOL_H+25+KACHEL_H;
	GameInfo.GameListe.ObjectsMenu.SetTaxiKachelSchalterButtonDown = NO;
	GameInfo.GameListe.ObjectsMenu.SetTaxiKachelSchalterButtonX = GameListeX+10+KACHEL_B+10;
	GameInfo.GameListe.ObjectsMenu.SetTaxiKachelSchalterButtonY = GameListeY+190+FOOL_H+30+KACHEL_H+KACHEL_H;
	GameInfo.GameListe.ObjectsMenu.SetBeamerButtonDown = NO;
	GameInfo.GameListe.ObjectsMenu.SetBeamerButtonX = GameListeX+10+KACHEL_B+10;
	GameInfo.GameListe.ObjectsMenu.SetBeamerButtonY = GameListeY+190+FOOL_H+35+KACHEL_H+KACHEL_H+KACHEL_H;
	GameInfo.GameListe.ObjectsMenu.SetExitButtonDown = NO;
	GameInfo.GameListe.ObjectsMenu.SetExitButtonX = GameListeX+10;
	GameInfo.GameListe.ObjectsMenu.SetExitButtonY = GameListeY+390;
   // Page 2:
	GameInfo.GameListe.ObjectsMenu.SetGesundButtonDown = NO;
	GameInfo.GameListe.ObjectsMenu.SetGesundButtonX = GameListeX+10;
	GameInfo.GameListe.ObjectsMenu.SetGesundButtonY = GameListeY+200;
	GameInfo.GameListe.ObjectsMenu.SetPunktButtonDown = NO;
	GameInfo.GameListe.ObjectsMenu.SetPunktButtonX = GameListeX+10;
	GameInfo.GameListe.ObjectsMenu.SetPunktButtonY = GameListeY+240;
	GameInfo.GameListe.ObjectsMenu.SetPacManButtonDown = NO;
	GameInfo.GameListe.ObjectsMenu.SetPacManButtonX = GameListeX+60;
	GameInfo.GameListe.ObjectsMenu.SetPacManButtonY = GameListeY+240;
    ///////
	GameInfo.GameListe.OptionsMenu.SaveButtonDown = NO;
	GameInfo.GameListe.OptionsMenu.SaveButtonX = GameListeX+35;
	GameInfo.GameListe.OptionsMenu.SaveButtonY = GameListeY+190;
	GameInfo.GameListe.OptionsMenu.LoadButtonDown = NO;
	GameInfo.GameListe.OptionsMenu.LoadButtonX = GameListeX+10;
	GameInfo.GameListe.OptionsMenu.LoadButtonY = GameListeY+190;
    GameInfo.GameListe.OptionsMenu.QuitButtonDown = NO;
    GameInfo.GameListe.OptionsMenu.QuitButtonX = GameListeX+85;
    GameInfo.GameListe.OptionsMenu.QuitButtonY = GameListeY+190;
    GameInfo.GameListe.OptionsMenu.NewButtonDown = NO;
    GameInfo.GameListe.OptionsMenu.NewButtonX = GameListeX+60;
    GameInfo.GameListe.OptionsMenu.NewButtonY = GameListeY+190;
    if(Module == GAME_SCENE)
	{
        GameInfo.GameListe.OptionsMenu.PauseButtonDown = NO;
        GameInfo.GameListe.OptionsMenu.PauseButtonX = GameListeX+10;
        GameInfo.GameListe.OptionsMenu.PauseButtonY = GameListeY+220;
    }
    if(Module == EDITOR_SCENE)
	{
        GameInfo.GameListe.CommandsDown = NO;
        GameInfo.GameListe.CommandsX = GameListeX+10;
        GameInfo.GameListe.CommandsY = GameListeY+105;
       ///// Anzahl der Verf�gbaren Befehle festlege Obtions:
        GameInfo.GameListe.CommandsMenu.AnzahlButtonDown = NO;
        GameInfo.GameListe.CommandsMenu.AnzahlButtonX = GameListeX+10;
        GameInfo.GameListe.CommandsMenu.AnzahlButtonY = GameListeY+240;
        GameInfo.GameListe.ObjectsMenu.DeleteButtonDown = NO;
        GameInfo.GameListe.ObjectsMenu.DeleteButtonX = GameListeX+70;
        GameInfo.GameListe.ObjectsMenu.DeleteButtonY = GameListeY+200;
        GameInfo.GameListe.ObjectsMenu.AnzahlButtonDown = NO;
        GameInfo.GameListe.ObjectsMenu.AnzahlButtonX = GameListeX+10;
        GameInfo.GameListe.ObjectsMenu.AnzahlButtonY = GameListeY+190+FOOL_H;
        for(i = 0, i3 = 0; i < 4; i++)
            for(i2 = 0; i2 < 2; i2++, i3++)
            {
                GameInfo.GameListe.CommandsMenu.CommandsButtonDown[i3] = NO;
                GameInfo.GameListe.CommandsMenu.CommandsButtonX[i3] = GameListeX+20+(i2*35);
                GameInfo.GameListe.CommandsMenu.CommandsButtonY[i3] = GameListeY+260+(i*35);
            }
        GameInfo.GameListe.CommandsMenu.CommandsButtonDown[8] = NO;
        GameInfo.GameListe.CommandsMenu.CommandsButtonX[8] = GameListeX+20;
        GameInfo.GameListe.CommandsMenu.CommandsButtonY[8] = GameListeY+400;
        GameInfo.GameListe.CommandsMenu.TimeButtonDown = NO;
        GameInfo.GameListe.CommandsMenu.TimeButtonX = GameListeX+10;
        GameInfo.GameListe.CommandsMenu.TimeButtonY = GameListeY+180;
        GameInfo.GameListe.CommandsMenu.TimeHoursButtonDown = NO;
        GameInfo.GameListe.CommandsMenu.TimeHoursButtonX = GameListeX+10;
        GameInfo.GameListe.CommandsMenu.TimeHoursButtonY = GameListeY+210;
        GameInfo.GameListe.CommandsMenu.TimeMinutesButtonDown = NO;
        GameInfo.GameListe.CommandsMenu.TimeMinutesButtonX = GameListeX+40;
        GameInfo.GameListe.CommandsMenu.TimeMinutesButtonY = GameListeY+210;
        GameInfo.GameListe.CommandsMenu.TimeSecondsButtonDown = NO;
        GameInfo.GameListe.CommandsMenu.TimeSecondsButtonX = GameListeX+70;
        GameInfo.GameListe.CommandsMenu.TimeSecondsButtonY = GameListeY+210;
		/////////////////////////
        GameInfo.GameListe.ObjectsDown = NO;
        GameInfo.GameListe.ObjectsX = GameListeX+35;
        GameInfo.GameListe.ObjectsY = GameListeY+105;
        GameInfo.GameListe.SzenarioDown = NO;
        GameInfo.GameListe.SzenarioX = GameListeX+60;
        GameInfo.GameListe.SzenarioY = GameListeY+105;
        GameInfo.GameListe.OptionsMenu.LoadLevelMenu.LoadButtonDown = NO;
        GameInfo.GameListe.OptionsMenu.LoadLevelMenu.LoadButtonX = GameListeX+85;
        GameInfo.GameListe.OptionsMenu.LoadLevelMenu.LoadButtonY = GameListeY+190;
        GameInfo.GameListe.SzenarioMenu.LoadSzenarioButtonDown = NO;
        GameInfo.GameListe.SzenarioMenu.LoadSzenarioButtonX = GameListeX+10;
        GameInfo.GameListe.SzenarioMenu.LoadSzenarioButtonY = GameListeY+190;
        GameInfo.GameListe.SzenarioMenu.LoadSzenarioMenu.LoadButtonDown = NO;
        GameInfo.GameListe.SzenarioMenu.LoadSzenarioMenu.LoadButtonX = GameListeX+85;
        GameInfo.GameListe.SzenarioMenu.LoadSzenarioMenu.LoadButtonY = GameListeY+200;

        GameInfo.GameListe.SzenarioMenu.FinishFoolsButtonDown = NO;
        GameInfo.GameListe.SzenarioMenu.FinishFoolsButtonX = GameListeX+10;
        GameInfo.GameListe.SzenarioMenu.FinishFoolsButtonY = GameListeY+220;
    }
    GameInfo.GameListe.InfosMenu.SlowDownButtonDown = NO;
    GameInfo.GameListe.InfosMenu.SlowDownButtonX = GameListeX+10;
    GameInfo.GameListe.InfosMenu.SlowDownButtonY = GameListeY+170;
    GameInfo.GameListe.InfosMenu.SlowUpButtonDown = NO;
    GameInfo.GameListe.InfosMenu.SlowUpButtonX = GameListeX+35;
    GameInfo.GameListe.InfosMenu.SlowUpButtonY = GameListeY+170;
    GameInfo.GameListe.InfosMenu.FastDownButtonDown = NO;
    GameInfo.GameListe.InfosMenu.FastDownButtonX = GameListeX+60;
    GameInfo.GameListe.InfosMenu.FastDownButtonY = GameListeY+170;
    GameInfo.GameListe.InfosMenu.FastUpButtonDown = NO;
    GameInfo.GameListe.InfosMenu.FastUpButtonX = GameListeX+85;
    GameInfo.GameListe.InfosMenu.FastUpButtonY = GameListeY+170;
    GameInfo.GameListe.InfosMenu.FirstButtonDown = NO;
    GameInfo.GameListe.InfosMenu.FirstButtonX = GameListeX+10;
    GameInfo.GameListe.InfosMenu.FirstButtonY = GameListeY+195;
    GameInfo.GameListe.InfosMenu.LastButtonDown = NO;
    GameInfo.GameListe.InfosMenu.LastButtonX = GameListeX+35;
    GameInfo.GameListe.InfosMenu.LastButtonY = GameListeY+195;
    ///////
} /* InitGameListe */

void CheckGameListe(int Module)
{
    int i, y;

    if(ProgrammSetup.ShowGameListe == NO || CheckMouseRect(GameListeX, GameListeY, GameListeX+120, GameListeY+480) == NO_AKTIV)
    	return;
    CheckSetCommandsMenu();
	CheckFoolsStatMenu();
    if((CheckMouseRect(GameInfo.GameListe.ObjectsX, GameInfo.GameListe.ObjectsY,
       GameInfo.GameListe.ObjectsX+GameInfo.GameListe.ButtonB, GameInfo.GameListe.ObjectsY+GameInfo.GameListe.ButtonH) != NO_AKTIV) ||
       (CheckMouseRect(GameInfo.GameListe.SzenarioX, GameInfo.GameListe.SzenarioY,
       GameInfo.GameListe.SzenarioX+GameInfo.GameListe.ButtonB, GameInfo.GameListe.SzenarioY+GameInfo.GameListe.ButtonH) != NO_AKTIV) ||
       (CheckMouseRect(GameInfo.GameListe.BuiltX, GameInfo.GameListe.BuiltY,
       GameInfo.GameListe.BuiltX+GameInfo.GameListe.ButtonB, GameInfo.GameListe.BuiltY+GameInfo.GameListe.ButtonH) != NO_AKTIV) ||
       (CheckMouseRect(GameInfo.GameListe.InfosX, GameInfo.GameListe.InfosY,
       GameInfo.GameListe.InfosX+GameInfo.GameListe.ButtonB, GameInfo.GameListe.InfosY+GameInfo.GameListe.ButtonH) != NO_AKTIV) ||
       (CheckMouseRect(GameInfo.GameListe.StatistikX, GameInfo.GameListe.StatistikY,
       GameInfo.GameListe.StatistikX+GameInfo.GameListe.ButtonB, GameInfo.GameListe.StatistikY+GameInfo.GameListe.ButtonH) != NO_AKTIV) ||
       (CheckMouseRect(GameInfo.GameListe.OptionsX, GameInfo.GameListe.OptionsY,
       GameInfo.GameListe.OptionsX+GameInfo.GameListe.ButtonB, GameInfo.GameListe.OptionsY+GameInfo.GameListe.ButtonH) != NO_AKTIV))
    {
		if(Mouse.Button == RIGHT_MOUSE_BUTTON)
        {
            GameInfo.GameListe.BuiltDown = NO;
            GameInfo.GameListe.InfosDown = NO;
            GameInfo.GameListe.StatistikDown = NO;
            GameInfo.GameListe.OptionsDown = NO;
            GameInfo.GameListe.ObjectsDown = NO;
            GameInfo.GameListe.SzenarioDown = NO;
            GameInfo.GameListe.CommandsDown = NO;
	    }
    }
    PressedButton = NO;
    if(Mouse.Button == LEFT_MOUSE_BUTTON && PressedMouseScroll == NO)
        PressedButton = YES;
    CheckBuiltMenu(Module);
    if(Module == EDITOR_SCENE)
    {
       // Szenario Obermen�:
        if(CheckMouseRect(GameInfo.GameListe.SzenarioX, GameInfo.GameListe.SzenarioY,
           GameInfo.GameListe.SzenarioX+GameInfo.GameListe.ButtonB, GameInfo.GameListe.SzenarioY+GameInfo.GameListe.ButtonH) != NO_AKTIV)
        {
            CheckMouseButtonInfo(YES, 500, T_OBERMENU_SZENARIO);
            if(PressedButton == YES)
            {
                AllObermenusOff();
                GameInfo.GameListe.SzenarioDown = YES;
            }
        }
       // Objecte Obermen�:
        if(CheckMouseRect(GameInfo.GameListe.ObjectsX, GameInfo.GameListe.ObjectsY,
           GameInfo.GameListe.ObjectsX+GameInfo.GameListe.ButtonB, GameInfo.GameListe.ObjectsY+GameInfo.GameListe.ButtonH) != NO_AKTIV)
        {
            CheckMouseButtonInfo(YES, 500, T_OBERMENU_OBJECTS);
            if(PressedButton == YES)
            {
	            AllObermenusOff();
    	        GameInfo.GameListe.ObjectsDown = YES;
        	}
        }
        CheckObjectsMenu();
    }
    // Commandos Obermen�:
    if(CheckMouseRect(GameInfo.GameListe.CommandsX, GameInfo.GameListe.CommandsY,
       GameInfo.GameListe.CommandsX+GameInfo.GameListe.ButtonB, GameInfo.GameListe.CommandsY+GameInfo.GameListe.ButtonH) != NO_AKTIV)
    {
        CheckMouseButtonInfo(YES, 500, T_OBERMENU_COMMANDOS);
        if(PressedButton == YES)
        {
	        AllObermenusOff();
    	    GameInfo.GameListe.CommandsDown = YES;
    	}
    }
    // Fool Info Obermen�:
    if(CheckMouseRect(GameInfo.GameListe.BuiltX, GameInfo.GameListe.BuiltY,
       GameInfo.GameListe.BuiltX+GameInfo.GameListe.ButtonB, GameInfo.GameListe.BuiltY+GameInfo.GameListe.ButtonH) != NO_AKTIV)
    {
        CheckMouseButtonInfo(YES, 500, T_OBERMENU_BUILT);
        if(PressedButton == YES)
        {
	        AllObermenusOff();
    	    GameInfo.GameListe.BuiltDown = YES;
    	}
    }
    //  Infos Obermen�:
    if(CheckMouseRect(GameInfo.GameListe.InfosX, GameInfo.GameListe.InfosY,
       GameInfo.GameListe.InfosX+GameInfo.GameListe.ButtonB, GameInfo.GameListe.InfosY+GameInfo.GameListe.ButtonH) != NO_AKTIV)
    {
        CheckMouseButtonInfo(YES, 500, T_OBERMENU_INFOS);
        if(PressedButton == YES)
        {
	        AllObermenusOff();
    	    GameInfo.GameListe.InfosDown = YES;
    	}
    }
    //  Statistik Obermen�:
    if(CheckMouseRect(GameInfo.GameListe.StatistikX, GameInfo.GameListe.StatistikY,
       GameInfo.GameListe.StatistikX+GameInfo.GameListe.ButtonB, GameInfo.GameListe.StatistikY+GameInfo.GameListe.ButtonH) != NO_AKTIV)
    {
        CheckMouseButtonInfo(YES, 500, T_OBERMENU_STATISTIK);
        if(PressedButton == YES)
        {
	        AllObermenusOff();
    	    GameInfo.GameListe.StatistikDown = YES;
    	}
    }
    //  Options Obermen�:
    if(CheckMouseRect(GameInfo.GameListe.OptionsX, GameInfo.GameListe.OptionsY,
       GameInfo.GameListe.OptionsX+GameInfo.GameListe.ButtonB, GameInfo.GameListe.OptionsY+GameInfo.GameListe.ButtonH) != NO_AKTIV)
    {
        CheckMouseButtonInfo(YES, 500, T_OBERMENU_OPTIONS);
        if(PressedButton == YES)
        {
        	AllObermenusOff();
         	GameInfo.GameListe.OptionsDown = YES;
            GameInfo.GameListe.OptionsMenu.LoadButtonDown = NO;
        }
   }
   // Szenario Untermen�:
    if(GameInfo.GameListe.SzenarioDown == YES)
    {
        if(GameInfo.GameListe.SzenarioMenu.LoadSzenarioButtonDown == YES)
        {
            if(PressedButton == YES)
            {
                for(i = 2, y = 0;; i++, y += Font[3].FontB+5)
                {
                    if(SzenarioPaths[i].PathName[0] == EOF || i > MAX_PATHS)
                        break;
                    if(CheckMouseRect(GameListeX+10, GameListeY+230+y, GameListeX+120, GameListeY+230+y+Font[3].FontH) != NO_AKTIV)
                        GameInfo.SelectedPath = i;
                }
                if((CheckMouseRect(GameInfo.GameListe.SzenarioMenu.LoadSzenarioMenu.LoadButtonX, GameInfo.GameListe.SzenarioMenu.LoadSzenarioMenu.LoadButtonY,
                   GameInfo.GameListe.SzenarioMenu.LoadSzenarioMenu.LoadButtonX+GameInfo.GameListe.ButtonB, GameInfo.GameListe.SzenarioMenu.LoadSzenarioMenu.LoadButtonY+GameInfo.GameListe.ButtonH) != NO_AKTIV) &&
                   GameInfo.SelectedPath != NO_AKTIV)
                { // Der Spieler will sich ein anderes Spiel Szenario aussuchen:
                    LoadWaitPic();
                    DestroyLevelBitmaps();
                    LoadLevelBitmaps(SzenarioPaths[GameInfo.SelectedPath].PathName);
                    stpcpy(Szenario.Info.SzenarioSet, SzenarioPaths[GameInfo.SelectedPath].PathName);
                }
			}
        }
        else
        {
            if(CheckMouseRect(GameInfo.GameListe.SzenarioMenu.LoadSzenarioButtonX, GameInfo.GameListe.SzenarioMenu.LoadSzenarioButtonY,
               GameInfo.GameListe.SzenarioMenu.LoadSzenarioButtonX+GameInfo.GameListe.ButtonB, GameInfo.GameListe.SzenarioMenu.LoadSzenarioButtonY+GameInfo.GameListe.ButtonH) != NO_AKTIV)
            { // Der Spieler will sich ein anderes Spiel Szenario aussuchen:
                CheckMouseButtonInfo(YES, 500, T_UNTERMENU_LOAD);
                if(PressedButton == YES)
                {
                    GameInfo.GameListe.SzenarioMenu.LoadSzenarioButtonDown = YES;
                    FindSzenarios();
                }
            }
            if(CheckMouseRect(GameInfo.GameListe.SzenarioMenu.FinishFoolsButtonX, GameInfo.GameListe.SzenarioMenu.FinishFoolsButtonY,
               GameInfo.GameListe.SzenarioMenu.FinishFoolsButtonX+GameInfo.GameListe.ButtonB, GameInfo.GameListe.SzenarioMenu.FinishFoolsButtonY+GameInfo.GameListe.ButtonH) != NO_AKTIV)
            {
			    if(Mouse.Button == LEFT_MOUSE_BUTTON && PressedMouseScroll == NO)
                {
                	if(Szenario.Info.ToFinish_LiveFools < MAX_FOOLS)
	                    Szenario.Info.ToFinish_LiveFools++;
                }
			    if(Mouse.Button == RIGHT_MOUSE_BUTTON && PressedMouseScroll == NO)
                {
                	if(Szenario.Info.ToFinish_LiveFools > 0)
	                    Szenario.Info.ToFinish_LiveFools--;
                }
            }
        }
    }
    if(GameInfo.GameListe.OptionsDown == YES)
    {
        if(Module == GAME_SCENE)
        {
            if(CheckMouseRect(GameInfo.GameListe.OptionsMenu.PauseButtonX, GameInfo.GameListe.OptionsMenu.PauseButtonY,
               GameInfo.GameListe.OptionsMenu.PauseButtonX+GameInfo.GameListe.ButtonB, GameInfo.GameListe.OptionsMenu.PauseButtonY+GameInfo.GameListe.ButtonH) != NO_AKTIV)
            {
	            CheckMouseButtonInfo(YES, 500, T_UNTERMENU_PAUSE);
	            if(PressedButton == YES)
    	        {
    //                    if(TimerNew2 == YES)
    ///                    {
    //                        TimerNew2 = NO;
                        if(GameInfo.Pause == YES)
                        {
                            GameInfo.Pause = NO;
                            GameInfo.GameListe.OptionsMenu.PauseButtonDown = NO;
                        }
                        else
                        {
                            GameInfo.Pause = YES;
                            GameInfo.GameListe.OptionsMenu.PauseButtonDown = YES;
                        }
    //                    }
				}
            }
        }
        if(Module == EDITOR_SCENE)
        {
            if(GameInfo.GameListe.OptionsMenu.LoadButtonDown == NO)
            {
                if(CheckMouseRect(GameInfo.GameListe.OptionsMenu.SaveButtonX, GameInfo.GameListe.OptionsMenu.SaveButtonY,
                   GameInfo.GameListe.OptionsMenu.SaveButtonX+GameInfo.GameListe.ButtonB, GameInfo.GameListe.OptionsMenu.SaveButtonY+GameInfo.GameListe.ButtonH) != NO_AKTIV)
                {
		            CheckMouseButtonInfo(YES, 500, T_UNTERMENU_SAVE);
		            if(PressedButton == YES)
    		        {
                        GameInfo.GameListe.OptionsMenu.SaveButtonDown = YES;
                        DrawVirtualScene(Module);
                        EditorSave();
                        GameInfo.GameListe.OptionsMenu.SaveButtonDown = NO;
					}
                }
                if(CheckMouseRect(GameInfo.GameListe.OptionsMenu.LoadButtonX, GameInfo.GameListe.OptionsMenu.LoadButtonY,
                   GameInfo.GameListe.OptionsMenu.LoadButtonX+GameInfo.GameListe.ButtonB, GameInfo.GameListe.OptionsMenu.LoadButtonY+GameInfo.GameListe.ButtonH) != NO_AKTIV)
                {
		            CheckMouseButtonInfo(YES, 500, T_UNTERMENU_LOAD);
		            if(PressedButton == YES)
    		        {
	                    GameInfo.GameListe.OptionsMenu.LoadButtonDown = YES;
    	                FindLevels();
                	}
                }
            }
            if(GameInfo.GameListe.OptionsMenu.LoadButtonDown == YES)
            {
	            if(PressedButton == YES)
   		        {
                    for(i = 0, y = 0;; i++, y += Font[3].FontB+5)
                    {
                        if(SzenarioPaths[i].PathName[0] == EOF || i > MAX_PATHS)
                            break;
                        if(CheckMouseRect(GameListeX+10, GameListeY+230+y, GameListeX+120, GameListeY+230+y+Font[3].FontH) != NO_AKTIV)
                            GameInfo.SelectedPath = i;
                    }
                    if((CheckMouseRect(GameInfo.GameListe.OptionsMenu.LoadLevelMenu.LoadButtonX, GameInfo.GameListe.OptionsMenu.LoadLevelMenu.LoadButtonY,
                       GameInfo.GameListe.OptionsMenu.LoadLevelMenu.LoadButtonX+GameInfo.GameListe.ButtonB, GameInfo.GameListe.OptionsMenu.LoadLevelMenu.LoadButtonY+GameInfo.GameListe.ButtonH) != NO_AKTIV) &&
                       GameInfo.SelectedPath != NO_AKTIV)
                    { // Der Spieler hat Sich ein Level ausgesucht:
                        EditorLoad();
                    }
				}
            }
        }
        if(GameInfo.GameListe.OptionsMenu.LoadButtonDown == NO)
        {
            if(CheckMouseRect(GameInfo.GameListe.OptionsMenu.QuitButtonX, GameInfo.GameListe.OptionsMenu.QuitButtonY,
               GameInfo.GameListe.OptionsMenu.QuitButtonX+GameInfo.GameListe.ButtonB, GameInfo.GameListe.OptionsMenu.QuitButtonY+GameInfo.GameListe.ButtonH) != NO_AKTIV)
            {
	            CheckMouseButtonInfo(YES, 500, T_UNTERMENU_QUIT);
	            if(PressedButton == YES)
   		        {
                    GameInfo.GameListe.OptionsMenu.QuitButtonDown = YES;
                    DrawVirtualScene(Module);
                    if(Module == GAME_SCENE)
                        GameQuit();
                    if(Module == EDITOR_SCENE)
                        EditorQuit();
                    GameInfo.GameListe.OptionsMenu.QuitButtonDown = NO;
				}
            }
            if(CheckMouseRect(GameInfo.GameListe.OptionsMenu.NewButtonX, GameInfo.GameListe.OptionsMenu.NewButtonY,
               GameInfo.GameListe.OptionsMenu.NewButtonX+GameInfo.GameListe.ButtonB, GameInfo.GameListe.OptionsMenu.NewButtonY+GameInfo.GameListe.ButtonH) != NO_AKTIV)
            {
	            CheckMouseButtonInfo(YES, 500, T_UNTERMENU_NEW);
	            if(PressedButton == YES)
   		        {
                    GameInfo.GameListe.OptionsMenu.NewButtonDown = YES;
                    DrawVirtualScene(Module);
                    if(Module == EDITOR_SCENE)
                        EditorNewLevel();
                    if(Module == GAME_SCENE)
                        GameNewStart();
                    GameInfo.GameListe.OptionsMenu.NewButtonDown = NO;
                }
            }
        }
    }
} /* CheckGameListe*/

void CheckSetCommandsMenu(void)
{
    int i, i2;

    if(GameInfo.GameListe.CommandsDown == YES)
    {   // Zeit einstellung:
        if(CheckMouseRect(GameInfo.GameListe.CommandsMenu.TimeButtonX, GameInfo.GameListe.CommandsMenu.TimeButtonY,
           GameInfo.GameListe.CommandsMenu.TimeHoursButtonX+20, GameInfo.GameListe.CommandsMenu.TimeButtonY+20) != NO_AKTIV)
        {
            switch(GameInfo.LimitedTime)
            {
                case YES: CheckMouseButtonInfo(YES, 500, T_UNTERMENU_TIME_YES); break;
                case NO: CheckMouseButtonInfo(YES, 500, T_UNTERMENU_TIME_NO); break;
                case USER: CheckMouseButtonInfo(YES, 500, T_UNTERMENU_TIME_USER); break;
            }
            if(PressedButton == YES)
            {
                if(TimerNew2 == YES)
                {
                    TimerNew2 = NO;
                    switch(GameInfo.LimitedTime)
                    {
                        case YES: GameInfo.LimitedTime = NO; break;
                        case NO: GameInfo.LimitedTime = USER; break;
                        case USER: GameInfo.LimitedTime = YES; break;
                    }
                }
            }
        }
        if(CheckMouseRect(GameInfo.GameListe.CommandsMenu.TimeHoursButtonX, GameInfo.GameListe.CommandsMenu.TimeHoursButtonY,
           GameInfo.GameListe.CommandsMenu.TimeHoursButtonX+20, GameInfo.GameListe.CommandsMenu.TimeHoursButtonY+20) != NO_AKTIV)
        {
            CheckMouseButtonInfo(YES, 500, T_UNTERMENU_TIME_HOURS);
            if(PressedButton == YES)
            {
                for(i2 = 0; i2 < 9; i2++)
                    GameInfo.GameListe.CommandsMenu.CommandsButtonDown[i2] = NO;
                GameInfo.GameListe.CommandsMenu.TimeHoursButtonDown = YES;
                GameInfo.GameListe.CommandsMenu.TimeMinutesButtonDown = NO;
                GameInfo.GameListe.CommandsMenu.TimeSecondsButtonDown = NO;
            }
        }
        if(CheckMouseRect(GameInfo.GameListe.CommandsMenu.TimeMinutesButtonX, GameInfo.GameListe.CommandsMenu.TimeMinutesButtonY,
           GameInfo.GameListe.CommandsMenu.TimeMinutesButtonX+20, GameInfo.GameListe.CommandsMenu.TimeMinutesButtonY+20) != NO_AKTIV)
        {
            CheckMouseButtonInfo(YES, 500, T_UNTERMENU_TIME_MINUTES);
            if(PressedButton == YES)
            {
                for(i2 = 0; i2 < 9; i2++)
                    GameInfo.GameListe.CommandsMenu.CommandsButtonDown[i2] = NO;
                GameInfo.GameListe.CommandsMenu.TimeHoursButtonDown = NO;
                GameInfo.GameListe.CommandsMenu.TimeMinutesButtonDown = YES;
                GameInfo.GameListe.CommandsMenu.TimeSecondsButtonDown = NO;
            }
        }
        if(CheckMouseRect(GameInfo.GameListe.CommandsMenu.TimeSecondsButtonX, GameInfo.GameListe.CommandsMenu.TimeSecondsButtonY,
           GameInfo.GameListe.CommandsMenu.TimeSecondsButtonX+20, GameInfo.GameListe.CommandsMenu.TimeSecondsButtonY+20) != NO_AKTIV)
        {
            CheckMouseButtonInfo(YES, 500, T_UNTERMENU_TIME_SECONDS);
            if(PressedButton == YES)
            {
                for(i2 = 0; i2 < 9; i2++)
                    GameInfo.GameListe.CommandsMenu.CommandsButtonDown[i2] = NO;
                GameInfo.GameListe.CommandsMenu.TimeHoursButtonDown = NO;
                GameInfo.GameListe.CommandsMenu.TimeMinutesButtonDown = NO;
                GameInfo.GameListe.CommandsMenu.TimeSecondsButtonDown = YES;
            }
        }
        if(GameInfo.GameListe.CommandsMenu.TimeHoursButtonDown == YES)
        {
            CheckMouseButtonInfo(YES, 500, T_UNTERMENU_TIME_ANZAHL);
            if(PressedButton == YES)
            {
                i2 = CheckPushBar(GameInfo.GameListe.CommandsMenu.AnzahlButtonX, GameInfo.GameListe.CommandsMenu.AnzahlButtonY, 100, 15, 0);
                if(i2 != NO_AKTIV)
                {
                    GameInfo.TimeHours = i2;
                    if(GameInfo.TimeHours > 24)
                        GameInfo.TimeHours = 24;
                }
            }
        }
        if(GameInfo.GameListe.CommandsMenu.TimeMinutesButtonDown == YES)
        {
            CheckMouseButtonInfo(YES, 500, T_UNTERMENU_TIME_ANZAHL);
            if(PressedButton == YES)
            {
                i2 = CheckPushBar(GameInfo.GameListe.CommandsMenu.AnzahlButtonX, GameInfo.GameListe.CommandsMenu.AnzahlButtonY, 100, 15, 0);
                if(i2 != NO_AKTIV)
                {
                    GameInfo.TimeMin = i2;
                    if(GameInfo.TimeMin > 59)
                        GameInfo.TimeMin = 59;
                }
            }
        }
        if(GameInfo.GameListe.CommandsMenu.TimeSecondsButtonDown == YES)
        {
            CheckMouseButtonInfo(YES, 500, T_UNTERMENU_TIME_ANZAHL);
            if(PressedButton == YES)
            {
                i2 = CheckPushBar(GameInfo.GameListe.CommandsMenu.AnzahlButtonX, GameInfo.GameListe.CommandsMenu.AnzahlButtonY, 100, 15, 0);
                if(i2 != NO_AKTIV)
                {
                    GameInfo.TimeSec = i2;
                    if(GameInfo.TimeSec > 59)
                        GameInfo.TimeSec = 59;
                }
            }
        }
        if(GameInfo.LimitedTime == YES)
        {
            GameInfo.PlayedTimeHours = GameInfo.TimeHours;
            GameInfo.PlayedTimeMin = GameInfo.TimeMin;
            GameInfo.PlayedTimeSec = GameInfo.TimeSec;
        }
        if(GameInfo.LimitedTime == NO)
        {
            GameInfo.PlayedTimeHours = 0;
            GameInfo.PlayedTimeMin = 0;
            GameInfo.PlayedTimeSec = 0;
        }
      ////////////
        for(i = 0; i < 9; i++)
        {
            if(CheckMouseRect(GameInfo.GameListe.CommandsMenu.CommandsButtonX[i], GameInfo.GameListe.CommandsMenu.CommandsButtonY[i],
               GameInfo.GameListe.CommandsMenu.CommandsButtonX[i]+30, GameInfo.GameListe.CommandsMenu.CommandsButtonY[i]+30) != NO_AKTIV)
            {
                CheckMouseButtonInfo(YES, 500, T_UNTERMENU_FIRST_COMMAND+i);
                if(PressedButton == YES)
                {
                    GameInfo.GameListe.CommandsMenu.TimeHoursButtonDown = NO;
                    GameInfo.GameListe.CommandsMenu.TimeMinutesButtonDown = NO;
                    GameInfo.GameListe.CommandsMenu.TimeSecondsButtonDown = NO;
                    for(i2 = 0; i2 < 9; i2++)
                        GameInfo.GameListe.CommandsMenu.CommandsButtonDown[i2] = NO;
                    GameInfo.GameListe.CommandsMenu.CommandsButtonDown[i] = YES;
                    GameInfo.Befehl = i+100;
                }
            }
        }
        for(i = 0; i < 9; i++)
            if(GameInfo.GameListe.CommandsMenu.CommandsButtonDown[i] == YES)
                break;
        if(i < 9)
        {
            CheckMouseButtonInfo(YES, 500, T_UNTERMENU_TIME_ANZAHL);
            if(PressedButton == YES)
            {
                i2 = CheckPushBar(GameInfo.GameListe.CommandsMenu.AnzahlButtonX, GameInfo.GameListe.CommandsMenu.AnzahlButtonY, 100, 15, 0);
                if(i2 != NO_AKTIV)
                {
                    GameCommandMenu[i].Anzahl = i2;
                    if(i2 == 0)
                        GameCommandMenu[i].Anzahl = NO_AKTIV;
                    if(i2 == 100)
                        GameCommandMenu[i].Anzahl = NO_LIMITED;
                }
            }
        }
    }
} /* CheckSetCommandsMenu */

void DrawGameListe(int Module)
{
    RECT rcRect;
    int i, y;
    char temp[50];

   // Setzt die linke Men� liste:
    SetRect(&rcRect, 0, 0, 120, 165);
    Back->BltFast(GameListeX, GameListeY, GameListPic, &rcRect, FALSE); // Spiel Menu setzen
    SetRect(&rcRect, 0, 560+GameInfo.MenuAni*6, 120, 560+GameInfo.MenuAni*6+6);
    Back->BltFast(GameListeX, GameListeY+159, GameListPic, &rcRect, FALSE); // Spiel Menu setzen
    if(GameInfo.GameListe.BuiltDown == NO &&
        GameInfo.GameListe.InfosDown == NO &&
        GameInfo.GameListe.StatistikDown == NO &&
        GameInfo.GameListe.OptionsDown == NO &&
        GameInfo.GameListe.ObjectsDown == NO &&
        GameInfo.GameListe.SzenarioDown == NO &&
        GameInfo.GameListe.CommandsDown == NO)
	    SetRect(&rcRect, 0, 165, 120, 480);
	else
        SetRect(&rcRect, 0, 1000, 120, 1315);
    Back->BltFast(GameListeX, GameListeY+165, GameListPic, &rcRect, FALSE); // Spiel Menu setzen
	DrawFoolsStatMenu();
    if(Module == EDITOR_SCENE)
    {
	    SetRect(&rcRect, 0, 810, 109, 839);
        Back->BltFast(GameListeX+5, GameListeY+100, GameListPic, &rcRect, FALSE);
    }
    // Men� Buttons malen:
    DrawBuiltMenu();
    if(Module == EDITOR_SCENE)
    {
        if(GameInfo.GameListe.CommandsDown == YES)
            SetRect(&rcRect, 1, 863, 22, 884);
        else
            SetRect(&rcRect, 1, 841, 22, 862);
	    Back->BltFast(GameInfo.GameListe.CommandsX, GameInfo.GameListe.CommandsY, GameListPic, &rcRect, FALSE);
        DrawSzenarioMenu();
      	DrawObjectsMenu();
        if(GameInfo.GameListe.CommandsDown == YES)
        {
            if(GameInfo.LimitedTime == YES)
	            SetRect(&rcRect, 56, 1360, 77, 1381);
            if(GameInfo.LimitedTime == NO)
	            SetRect(&rcRect, 78, 1360, 99, 1381);
            if(GameInfo.LimitedTime == USER)
	            SetRect(&rcRect, 67, 691, 88, 712);
            Back->BltFast(GameInfo.GameListe.CommandsMenu.TimeButtonX, GameInfo.GameListe.CommandsMenu.TimeButtonY, GameListPic, &rcRect, FALSE);
            if(GameInfo.GameListe.CommandsMenu.TimeHoursButtonDown == YES)
            {
                DrawRect(GameInfo.GameListe.CommandsMenu.TimeHoursButtonX, GameInfo.GameListe.CommandsMenu.TimeHoursButtonY, 20, 20, 15, Back);
                SetRect(&rcRect, GameInfo.TimeHours, 885, 100, 900);
                Back->BltFast(GameInfo.GameListe.CommandsMenu.AnzahlButtonX+GameInfo.TimeHours, GameInfo.GameListe.CommandsMenu.AnzahlButtonY, GameListPic, &rcRect, FALSE);
                SetRect(&rcRect, 0, 900, GameInfo.TimeHours, 915);
                Back->BltFast(GameInfo.GameListe.CommandsMenu.AnzahlButtonX, GameInfo.GameListe.CommandsMenu.AnzahlButtonY, GameListPic, &rcRect, FALSE);
            }
            if(GameInfo.GameListe.CommandsMenu.TimeMinutesButtonDown == YES)
            {
                DrawRect(GameInfo.GameListe.CommandsMenu.TimeMinutesButtonX, GameInfo.GameListe.CommandsMenu.TimeMinutesButtonY, 20, 20, 15, Back);
                SetRect(&rcRect, GameInfo.TimeMin, 885, 100, 900);
                Back->BltFast(GameInfo.GameListe.CommandsMenu.AnzahlButtonX+GameInfo.TimeMin, GameInfo.GameListe.CommandsMenu.AnzahlButtonY, GameListPic, &rcRect, FALSE);
                SetRect(&rcRect, 0, 900, GameInfo.TimeMin, 915);
                Back->BltFast(GameInfo.GameListe.CommandsMenu.AnzahlButtonX, GameInfo.GameListe.CommandsMenu.AnzahlButtonY, GameListPic, &rcRect, FALSE);
            }
            if(GameInfo.GameListe.CommandsMenu.TimeSecondsButtonDown == YES)
            {
                DrawRect(GameInfo.GameListe.CommandsMenu.TimeSecondsButtonX, GameInfo.GameListe.CommandsMenu.TimeSecondsButtonY, 20, 20, 15, Back);
                SetRect(&rcRect, GameInfo.TimeSec, 885, 100, 900);
                Back->BltFast(GameInfo.GameListe.CommandsMenu.AnzahlButtonX+GameInfo.TimeSec, GameInfo.GameListe.CommandsMenu.AnzahlButtonY, GameListPic, &rcRect, FALSE);
                SetRect(&rcRect, 0, 900, GameInfo.TimeSec, 915);
                Back->BltFast(GameInfo.GameListe.CommandsMenu.AnzahlButtonX, GameInfo.GameListe.CommandsMenu.AnzahlButtonY, GameListPic, &rcRect, FALSE);
            }
            sprintf(temp, "%d:", GameInfo.TimeHours);
            PrintText(GameInfo.GameListe.CommandsMenu.TimeHoursButtonX, GameInfo.GameListe.CommandsMenu.TimeHoursButtonY+3, temp, 1, 0, 80, Font[0].MaxYZeichen, Back);
            sprintf(temp, "%d:", GameInfo.TimeMin);
            PrintText(GameInfo.GameListe.CommandsMenu.TimeMinutesButtonX, GameInfo.GameListe.CommandsMenu.TimeMinutesButtonY+3, temp, 1, 0, 80, Font[0].MaxYZeichen, Back);
            sprintf(temp, "%d", GameInfo.TimeSec);
            PrintText(GameInfo.GameListe.CommandsMenu.TimeSecondsButtonX, GameInfo.GameListe.CommandsMenu.TimeSecondsButtonY+3, temp, 1, 0, 80, Font[0].MaxYZeichen, Back);
          /////////
            for(i = 0; i < 9; i++)
            {
                rcRect.left   = 1+(34*i);
                rcRect.top    = 35;
                rcRect.right  = 1+(34*i)+32;
                rcRect.bottom = 35+33;
                Back->BltFast(GameInfo.GameListe.CommandsMenu.CommandsButtonX[i], GameInfo.GameListe.CommandsMenu.CommandsButtonY[i], CommandMenuAniPic, &rcRect, FALSE);
                if(GameCommandMenu[i].Anzahl == NO_AKTIV)
                    PrintText(GameInfo.GameListe.CommandsMenu.CommandsButtonX[i], GameInfo.GameListe.CommandsMenu.CommandsButtonY[i], "--", 1, 0, 1000, 1000, Back);
                else
                    if(GameCommandMenu[i].Anzahl != NO_LIMITED)
                    {
                        sprintf(temp, "%d", GameCommandMenu[i].Anzahl);
                        PrintText(GameInfo.GameListe.CommandsMenu.CommandsButtonX[i], GameInfo.GameListe.CommandsMenu.CommandsButtonY[i], temp, 1, 0, 1000, 1000, Back);
                    }
            }
	        for(i = 0; i < 9; i++)
	            if(GameInfo.GameListe.CommandsMenu.CommandsButtonDown[i] == YES)
                	break;
            if(i < 9)
            {
                if(GameCommandMenu[i].Anzahl == NO_AKTIV)
                {
                    SetRect(&rcRect, 0, 885, 100, 900);
                    Back->BltFast(GameInfo.GameListe.CommandsMenu.AnzahlButtonX, GameInfo.GameListe.CommandsMenu.AnzahlButtonY, GameListPic, &rcRect, FALSE);
				}
                else
                {
                    SetRect(&rcRect, GameCommandMenu[i].Anzahl, 885, 100, 900);
                    Back->BltFast(GameInfo.GameListe.CommandsMenu.AnzahlButtonX+GameCommandMenu[i].Anzahl, GameInfo.GameListe.CommandsMenu.AnzahlButtonY, GameListPic, &rcRect, FALSE);
                    SetRect(&rcRect, 0, 900, GameCommandMenu[i].Anzahl, 915);
                    Back->BltFast(GameInfo.GameListe.CommandsMenu.AnzahlButtonX, GameInfo.GameListe.CommandsMenu.AnzahlButtonY, GameListPic, &rcRect, FALSE);
                }
                DrawRect(GameInfo.GameListe.CommandsMenu.CommandsButtonX[i]-1, GameInfo.GameListe.CommandsMenu.CommandsButtonY[i]-1, 34, 34, 15, Back);
            }
        }
    }
    if(GameInfo.GameListe.InfosDown == YES)
    	SetRect(&rcRect, 23, 625, 44, 646);
    else
        SetRect(&rcRect, 23, 603, 44, 624);
    Back->BltFast(GameInfo.GameListe.InfosX, GameInfo.GameListe.InfosY, GameListPic, &rcRect, FALSE);
    if(GameInfo.GameListe.StatistikDown == YES)
    	SetRect(&rcRect, 45, 625, 66, 646);
    else
        SetRect(&rcRect, 45, 603, 66, 624);
    Back->BltFast(GameInfo.GameListe.StatistikX, GameInfo.GameListe.StatistikY, GameListPic, &rcRect, FALSE);
    if(GameInfo.GameListe.OptionsDown == YES)
        SetRect(&rcRect, 67, 625, 88, 646);
    else
        SetRect(&rcRect, 67, 603, 88, 624);
    Back->BltFast(GameInfo.GameListe.OptionsX, GameInfo.GameListe.OptionsY, GameListPic, &rcRect, FALSE);
    if(GameInfo.GameListe.OptionsDown == YES)
    {
        if(Module == GAME_SCENE)
        {
            if(GameInfo.Pause == YES)
	            SetRect(&rcRect, 1, 713, 22, 734);
            else
	            SetRect(&rcRect, 1, 691, 22, 712);
        	Back->BltFast(GameInfo.GameListe.OptionsMenu.PauseButtonX, GameInfo.GameListe.OptionsMenu.PauseButtonY, GameListPic, &rcRect, FALSE);
        }
        if(GameInfo.GameListe.OptionsMenu.LoadButtonDown == NO)
		{
            if(GameInfo.GameListe.OptionsMenu.SaveButtonDown == YES)
                SetRect(&rcRect, 1, 669, 22, 690);
            else
                SetRect(&rcRect, 1, 647, 22, 668);
            Back->BltFast(GameInfo.GameListe.OptionsMenu.SaveButtonX, GameInfo.GameListe.OptionsMenu.SaveButtonY, GameListPic, &rcRect, FALSE);
        }
        if(Module == GAME_SCENE)
		{
            if(GameInfo.GameListe.OptionsMenu.LoadButtonDown == NO)
            {
                SetRect(&rcRect, 23, 649, 44, 671);
	            Back->BltFast(GameInfo.GameListe.OptionsMenu.LoadButtonX, GameInfo.GameListe.OptionsMenu.LoadButtonY, GameListPic, &rcRect, FALSE);
            }
            else
            {
                if(GameInfo.SelectedPath == NO_AKTIV)
	               SetRect(&rcRect, 23, 669, 44, 690);
		        else
		            SetRect(&rcRect, 23, 648, 44, 669);
	            Back->BltFast(GameInfo.GameListe.OptionsMenu.LoadLevelMenu.LoadButtonX, GameInfo.GameListe.OptionsMenu.LoadLevelMenu.LoadButtonY, GameListPic, &rcRect, FALSE);
                PrintText(GameListeX+10, GameListeY+160, Szenario.Info.LevelName, 1, 0, 1000, 1000, Back);
            	for(i = 2, y = 0;; i++, y += Font[1].FontB+5)
                {
                	if(SzenarioPaths[i].PathName[0] == EOF || i > MAX_PATHS)
                    	break;
                    if(GameInfo.SelectedPath == i)
	                    PrintText(GameListeX+10, GameListeY+230+y, SzenarioPaths[i].PathName, 3, 0, 1000, 1000, Back);
	                else
                        PrintText(GameListeX+10, GameListeY+230+y, SzenarioPaths[i].PathName, 1, 0, 1000, 1000, Back);
                }
            }
		}
        if(Module == EDITOR_SCENE)
		{
            if(GameInfo.GameListe.OptionsMenu.LoadButtonDown == NO)
            {
                SetRect(&rcRect, 23, 647, 44, 667);
                Back->BltFast(GameInfo.GameListe.OptionsMenu.LoadButtonX, GameInfo.GameListe.OptionsMenu.LoadButtonY, GameListPic, &rcRect, FALSE);
            }
            else
            {
                if(GameInfo.SelectedPath == NO_AKTIV)
                   SetRect(&rcRect, 23, 669, 44, 690);
                else
                    SetRect(&rcRect, 23, 648, 44, 669);
                Back->BltFast(GameInfo.GameListe.OptionsMenu.LoadLevelMenu.LoadButtonX, GameInfo.GameListe.OptionsMenu.LoadLevelMenu.LoadButtonY, GameListPic, &rcRect, FALSE);
                PrintText(GameListeX+10, GameListeY+160, Szenario.Info.SzenarioSet, 1, 0, 1000, 1000, Back);
                for(i = 0, y = 0;; i++, y += Font[1].FontB+5)
                {
                    if(SzenarioPaths[i].PathName[0] == EOF || i > MAX_PATHS)
                        break;
                    if(GameInfo.SelectedPath == i)
                        PrintText(GameListeX+10, GameListeY+230+y, SzenarioPaths[i].PathName, 3, 0, 1000, 1000, Back);
                    else
                        PrintText(GameListeX+10, GameListeY+230+y, SzenarioPaths[i].PathName, 1, 0, 1000, 1000, Back);
                }
            }
        }
        if(GameInfo.GameListe.OptionsMenu.LoadButtonDown == NO)
        {
            if(GameInfo.GameListe.OptionsMenu.QuitButtonDown == YES)
                SetRect(&rcRect, 45, 669, 66, 690);
            else
                SetRect(&rcRect, 45, 647, 66, 668);
	        Back->BltFast(GameInfo.GameListe.OptionsMenu.QuitButtonX, GameInfo.GameListe.OptionsMenu.QuitButtonY, GameListPic, &rcRect, FALSE);
            if(GameInfo.GameListe.OptionsMenu.NewButtonDown == YES)
                SetRect(&rcRect, 67, 669, 88, 690);
            else
                SetRect(&rcRect, 67, 647, 88, 668);
            Back->BltFast(GameInfo.GameListe.OptionsMenu.NewButtonX, GameInfo.GameListe.OptionsMenu.NewButtonY, GameListPic, &rcRect, FALSE);
        }
    }
} /* DrawGameListe */

void DrawSzenarioMenu(void)
{
    RECT rcRect;
    int i, y;
    char temp[50];

    if(GameInfo.GameListe.SzenarioDown == YES)
        SetRect(&rcRect, 89, 669, 110, 690);
    else
        SetRect(&rcRect, 89, 647, 110, 668);
    Back->BltFast(GameInfo.GameListe.SzenarioX, GameInfo.GameListe.SzenarioY, GameListPic, &rcRect, FALSE);
    if(GameInfo.GameListe.SzenarioDown == YES)
    {
        if(GameInfo.GameListe.SzenarioMenu.LoadSzenarioButtonDown == NO)
        {
            SetRect(&rcRect, 23, 647, 44, 668);
            Back->BltFast(GameInfo.GameListe.SzenarioMenu.LoadSzenarioButtonX, GameInfo.GameListe.SzenarioMenu.LoadSzenarioButtonY, GameListPic, &rcRect, FALSE);
            sprintf(temp, "%d", Szenario.Info.ToFinish_LiveFools);
            PrintText(GameInfo.GameListe.SzenarioMenu.FinishFoolsButtonX, GameInfo.GameListe.SzenarioMenu.FinishFoolsButtonY, temp, 1, 0, 1000, 1000, Back);
            DrawRect(GameInfo.GameListe.SzenarioMenu.FinishFoolsButtonX, GameInfo.GameListe.SzenarioMenu.FinishFoolsButtonY, 20, 20, 15, Back);
		    SetRect(&rcRect, 100, 480, 120, 510);
            Back->BltFast(GameInfo.GameListe.SzenarioMenu.FinishFoolsButtonX+25, GameInfo.GameListe.SzenarioMenu.FinishFoolsButtonY-5, GameListPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        }
        else
        {
            if(GameInfo.SelectedPath == NO_AKTIV)
               SetRect(&rcRect, 23, 669, 43, 689);
            else
                SetRect(&rcRect, 23, 648, 43, 668);
            Back->BltFast(GameInfo.GameListe.SzenarioMenu.LoadSzenarioMenu.LoadButtonX, GameInfo.GameListe.SzenarioMenu.LoadSzenarioMenu.LoadButtonY, GameListPic, &rcRect, FALSE);
            PrintText(GameListeX+10, GameListeY+190, Szenario.Info.SzenarioSet, 1, 0, Font[1].MaxXZeichen, Font[1].MaxYZeichen, Back);
            for(i = 2, y = 0;; i++, y += Font[1].FontB+5)
            {
                if(SzenarioPaths[i].PathName[0] == EOF || i > MAX_PATHS)
                    break;
                if(GameInfo.SelectedPath == i)
                    PrintText(GameListeX+10, GameListeY+230+y, SzenarioPaths[i].PathName, 3, 0, Font[3].MaxXZeichen, Font[3].MaxYZeichen, Back);
                else
                    PrintText(GameListeX+10, GameListeY+230+y, SzenarioPaths[i].PathName, 1, 0, Font[1].MaxXZeichen, Font[1].MaxYZeichen, Back);
            }
        }
    }
} /* DrawSzenarioMenu */

void DrawObjectsMenu(void)
{
	RECT rcRect;
    char temp[50];

    if(GameInfo.GameListe.ObjectsDown == YES)
        SetRect(&rcRect, 89, 625, 110, 646);
    else
        SetRect(&rcRect, 89, 603, 110, 624);
    Back->BltFast(GameInfo.GameListe.ObjectsX, GameInfo.GameListe.ObjectsY, GameListPic, &rcRect, FALSE);
    if(GameInfo.GameListe.ObjectsDown == YES)
    {
        SetRect(&rcRect, 23, 841, 44, 862);
        Back->BltFast(GameInfo.GameListe.ObjectsMenu.PageUpButtonX, GameInfo.GameListe.ObjectsMenu.PageUpButtonY, GameListPic, &rcRect, FALSE);
        SetRect(&rcRect, 45, 841, 66, 862);
        Back->BltFast(GameInfo.GameListe.ObjectsMenu.PageDownButtonX, GameInfo.GameListe.ObjectsMenu.PageDownButtonY, GameListPic, &rcRect, FALSE);
        SetRect(&rcRect, 1, 1, 34, 34);
        Back->BltFast(GameInfo.GameListe.ObjectsMenu.DeleteButtonX, GameInfo.GameListe.ObjectsMenu.DeleteButtonY, CommandMenuAniPic, &rcRect, FALSE);
        if(GameInfo.Befehl == COMMAND_DELETE)
            DrawRect(GameInfo.GameListe.ObjectsMenu.DeleteButtonX-1, GameInfo.GameListe.ObjectsMenu.DeleteButtonY-1, 40, 34, 15, Back);
        switch(ObjectsMenuPage)
        {
        	case 0:
                SetRect(&rcRect, 1, 1, 1+FOOL_B, 1+FOOL_H);
                Back->BltFast(GameInfo.GameListe.ObjectsMenu.SetFoolButtonX, GameInfo.GameListe.ObjectsMenu.SetFoolButtonY, FoolAniPic, &rcRect, FALSE);
                if(GameInfo.Befehl == SET_FOOL)
                    DrawRect(GameInfo.GameListe.ObjectsMenu.SetFoolButtonX-1, GameInfo.GameListe.ObjectsMenu.SetFoolButtonY-1, FOOL_B+1, FOOL_H+1, 15, Back);
                sprintf(temp, "%d", MAX_FOOLS);
                PrintText(GameInfo.GameListe.ObjectsMenu.SetFoolButtonX, GameInfo.GameListe.ObjectsMenu.SetFoolButtonY, temp, 1, 0, 1000, 1000, Back);
                sprintf(temp, "%d", Szenario.Info.FoolAnzahl);
                PrintText(GameInfo.GameListe.ObjectsMenu.SetFoolButtonX, GameInfo.GameListe.ObjectsMenu.SetFoolButtonY+FOOL_H-10, temp, 1, 0, 1000, 1000, Back);
                SetRect(&rcRect, 1, 1, 33, 42);
                Back->BltFast(GameInfo.GameListe.ObjectsMenu.SetGegnerDrohneButtonX, GameInfo.GameListe.ObjectsMenu.SetGegnerDrohneButtonY, GegnerAniPic, &rcRect, FALSE);
                sprintf(temp, "%d", MAX_GEGNER);
                PrintText(GameInfo.GameListe.ObjectsMenu.SetGegnerDrohneButtonX, GameInfo.GameListe.ObjectsMenu.SetGegnerDrohneButtonY, temp, 1, 0, 1000, 1000, Back);
                sprintf(temp, "%d", Szenario.Info.GegnerAnzahl);
                PrintText(GameInfo.GameListe.ObjectsMenu.SetGegnerDrohneButtonX, GameInfo.GameListe.ObjectsMenu.SetGegnerDrohneButtonY+40, temp, 1, 0, 1000, 1000, Back);
                if(GameInfo.Befehl == DRAW_GEGNER_DROHNE)
                    DrawRect(GameInfo.GameListe.ObjectsMenu.SetGegnerDrohneButtonX-1, GameInfo.GameListe.ObjectsMenu.SetGegnerDrohneButtonY-1, 33, 42, 15, Back);
                if(GameInfo.Befehl == SET_INSTABIL)
                {
                    rcRect.left   = 1+Editor_SetKachelAni*(KACHEL_B+5);
                    rcRect.top    = 1;
                    rcRect.right  = 1+Editor_SetKachelAni*(KACHEL_B+5)+KACHEL_B+KACHEL_OVERLAY;
                    rcRect.bottom = 1+KACHEL_H+KACHEL_OVERLAY;
                    sprintf(temp, "%d", Editor_SetKachelAni);
                    PrintText(GameInfo.GameListe.ObjectsMenu.SetInstabilButtonX+20, GameInfo.GameListe.ObjectsMenu.SetInstabilButtonY+10, temp, 0, 0, 40, 40, Back);
                    DrawRect(GameInfo.GameListe.ObjectsMenu.SetInstabilButtonX-1, GameInfo.GameListe.ObjectsMenu.SetInstabilButtonY-1, 40+KACHEL_OVERLAY+1, 32+KACHEL_OVERLAY+1, 15, Back);
                }
                else
                {
                    rcRect.left   = 1;
                    rcRect.top    = 1;
                    rcRect.right  = 1+KACHEL_B+KACHEL_OVERLAY;
                    rcRect.bottom = 1+KACHEL_H+KACHEL_OVERLAY;
                    sprintf(temp, "%d", 0);
                    PrintText(GameInfo.GameListe.ObjectsMenu.SetInstabilButtonX+20, GameInfo.GameListe.ObjectsMenu.SetInstabilButtonY+10, temp, 0, 0, 40, 40, Back);
                }
                Back->BltFast(GameInfo.GameListe.ObjectsMenu.SetInstabilButtonX, GameInfo.GameListe.ObjectsMenu.SetInstabilButtonY, Szenario.MasksLevelPic, &rcRect, FALSE);
                DrawKachelMasksPic(ATOMIK, GameInfo.GameListe.ObjectsMenu.SetAtomikButtonX, GameInfo.GameListe.ObjectsMenu.SetAtomikButtonY, Back);
                if(GameInfo.Befehl == SET_ATOMIK)
                    DrawRect(GameInfo.GameListe.ObjectsMenu.SetAtomikButtonX-1, GameInfo.GameListe.ObjectsMenu.SetAtomikButtonY-1, 40+KACHEL_OVERLAY, 32+KACHEL_OVERLAY, 15, Back);
                DrawKachelMasksPic(BEAMER, GameInfo.GameListe.ObjectsMenu.SetBeamerButtonX, GameInfo.GameListe.ObjectsMenu.SetBeamerButtonY, Back);
                if(GameInfo.Befehl == SET_BEAMER)
                    DrawRect(GameInfo.GameListe.ObjectsMenu.SetBeamerButtonX-1, GameInfo.GameListe.ObjectsMenu.SetBeamerButtonY-1, 40+KACHEL_OVERLAY, 32+KACHEL_OVERLAY, 15, Back);
                rcRect.left   = 1;
                rcRect.top    = 2553;
                rcRect.right  = 51;
                rcRect.bottom = 2624;
                Back->BltFast(GameInfo.GameListe.ObjectsMenu.SetExitButtonX, GameInfo.GameListe.ObjectsMenu.SetBeamerButtonY+10, FoolAniPic, &rcRect, FALSE);
                if(GameInfo.Befehl == SET_EXIT)
                    DrawRect(GameInfo.GameListe.ObjectsMenu.SetExitButtonX-1, GameInfo.GameListe.ObjectsMenu.SetExitButtonY-1, 41, 61, 15, Back);
                sprintf(temp, "%d", MAX_EXIT_ANZAHL);
                PrintText(GameInfo.GameListe.ObjectsMenu.SetExitButtonX, GameInfo.GameListe.ObjectsMenu.SetExitButtonY, temp, 1, 0, 1000, 1000, Back);
                sprintf(temp, "%d", Szenario.Info.ExitAnzahl);
                PrintText(GameInfo.GameListe.ObjectsMenu.SetExitButtonX, GameInfo.GameListe.ObjectsMenu.SetExitButtonY+40, temp, 1, 0, 1000, 1000, Back);
                if(GameInfo.Befehl == SET_INSTABIL)
                {
                    SetRect(&rcRect, InfoVar, 885, 100, 900);
                    Back->BltFast(GameInfo.GameListe.ObjectsMenu.AnzahlButtonX+InfoVar, GameInfo.GameListe.ObjectsMenu.AnzahlButtonY, GameListPic, &rcRect, FALSE);
                    SetRect(&rcRect, 0, 900, InfoVar, 915);
                    Back->BltFast(GameInfo.GameListe.ObjectsMenu.AnzahlButtonX, GameInfo.GameListe.ObjectsMenu.AnzahlButtonY, GameListPic, &rcRect, FALSE);
                }
                DrawKachelMasksPic(TAXI_KACHEL, GameInfo.GameListe.ObjectsMenu.SetTaxiKachelButtonX, GameInfo.GameListe.ObjectsMenu.SetTaxiKachelButtonY, Back);
                if(GameInfo.Befehl == SET_TAXI_KACHEL)
                    DrawRect(GameInfo.GameListe.ObjectsMenu.SetTaxiKachelButtonX-1, GameInfo.GameListe.ObjectsMenu.SetTaxiKachelButtonY-1, 40+KACHEL_OVERLAY, 32+KACHEL_OVERLAY, 15, Back);
                DrawKachelMasksPic(TAXI_KACHEL_SCHALTER, GameInfo.GameListe.ObjectsMenu.SetTaxiKachelSchalterButtonX, GameInfo.GameListe.ObjectsMenu.SetTaxiKachelSchalterButtonY, Back);
                if(GameInfo.Befehl == SET_TAXI_KACHEL_SCHALTER)
                    DrawRect(GameInfo.GameListe.ObjectsMenu.SetTaxiKachelSchalterButtonX-1, GameInfo.GameListe.ObjectsMenu.SetTaxiKachelSchalterButtonY-1, 40+KACHEL_OVERLAY, 32+KACHEL_OVERLAY, 15, Back);
            break;

        	case 1:
                DrawKachelMasksPic(GESUND, GameInfo.GameListe.ObjectsMenu.SetGesundButtonX, GameInfo.GameListe.ObjectsMenu.SetGesundButtonY, Back);
                if(GameInfo.Befehl == SET_GESUND)
                    DrawRect(GameInfo.GameListe.ObjectsMenu.SetGesundButtonX-1, GameInfo.GameListe.ObjectsMenu.SetGesundButtonY-1, 40+KACHEL_OVERLAY, 32+KACHEL_OVERLAY, 15, Back);
                SetRect(&rcRect, 1, 1, 25, 25);
                Back->BltFast(GameInfo.GameListe.ObjectsMenu.SetPunktButtonX, GameInfo.GameListe.ObjectsMenu.SetPunktButtonY, Szenario.PunktLevelPic, &rcRect, FALSE);
                if(GameInfo.Befehl == SET_PUNKT)
                    DrawRect(GameInfo.GameListe.ObjectsMenu.SetPunktButtonX-1, GameInfo.GameListe.ObjectsMenu.SetPunktButtonY-1, 26, 26, 15, Back);
                sprintf(temp, "%d", Szenario.Info.PunkteAnzahl);
                PrintText(GameInfo.GameListe.ObjectsMenu.SetPunktButtonX, GameInfo.GameListe.ObjectsMenu.SetPunktButtonY, temp, 1, 0, 1000, 1000, Back);
                SetRect(&rcRect, 1, 1, 1+PACMAN_B, 1+PACMAN_H);
                Back->BltFast(GameInfo.GameListe.ObjectsMenu.SetPacManButtonX, GameInfo.GameListe.ObjectsMenu.SetPacManButtonY, PacManAniPic, &rcRect, FALSE);
                if(GameInfo.Befehl == SET_PACMAN)
                    DrawRect(GameInfo.GameListe.ObjectsMenu.SetPacManButtonX-1, GameInfo.GameListe.ObjectsMenu.SetPacManButtonY-1, PACMAN_B+1, PACMAN_H+1, 15, Back);
                sprintf(temp, "%d", MAX_PACMAN);
                PrintText(GameInfo.GameListe.ObjectsMenu.SetPacManButtonX, GameInfo.GameListe.ObjectsMenu.SetPacManButtonY, temp, 1, 0, 1000, 1000, Back);
                sprintf(temp, "%d", Szenario.Info.PacManAnzahl);
                PrintText(GameInfo.GameListe.ObjectsMenu.SetPacManButtonX, GameInfo.GameListe.ObjectsMenu.SetPacManButtonY+PACMAN_H-10, temp, 1, 0, 1000, 1000, Back);
            break;
        }
    }
} /* DrawObjectsMenu */

void CheckObjectsMenu(void)
{
    int i;

    if(GameInfo.GameListe.ObjectsDown == YES)
    {
        if(CheckMouseRect(GameInfo.GameListe.ObjectsMenu.PageUpButtonX, GameInfo.GameListe.ObjectsMenu.PageUpButtonY,
           GameInfo.GameListe.ObjectsMenu.PageUpButtonX+20, GameInfo.GameListe.ObjectsMenu.PageUpButtonY+20) != NO_AKTIV)
        {
            CheckMouseButtonInfo(YES, 500, T_UNTERMENU_PAGE_UP);
            if(PressedButton == YES && TimerNew2 == YES)
        	{
				TimerNew2 = NO;
		        ObjectsMenuPage++;
		        if(ObjectsMenuPage > 1)
	  		        ObjectsMenuPage = 0;
            }
            return;
        }
        if(CheckMouseRect(GameInfo.GameListe.ObjectsMenu.PageDownButtonX, GameInfo.GameListe.ObjectsMenu.PageDownButtonY,
           GameInfo.GameListe.ObjectsMenu.PageDownButtonX+20, GameInfo.GameListe.ObjectsMenu.PageDownButtonY+20) != NO_AKTIV)
        {
            CheckMouseButtonInfo(YES, 500, T_UNTERMENU_PAGE_DOWN);
            if(PressedButton == YES && TimerNew2 == YES)
        	{
				TimerNew2 = NO;
		        ObjectsMenuPage--;
		        if(ObjectsMenuPage < 0)
	  		        ObjectsMenuPage = 1;
            }
            return;
        }
        if(CheckMouseRect(GameInfo.GameListe.ObjectsMenu.DeleteButtonX, GameInfo.GameListe.ObjectsMenu.DeleteButtonY,
           GameInfo.GameListe.ObjectsMenu.DeleteButtonX+KACHEL_B+KACHEL_OVERLAY, GameInfo.GameListe.ObjectsMenu.DeleteButtonY+KACHEL_H+KACHEL_OVERLAY) != NO_AKTIV)
        {
            CheckMouseButtonInfo(YES, 500, T_UNTERMENU_FIRST_COMMAND);
            if(PressedButton == YES)
                GameInfo.Befehl = COMMAND_DELETE;
        }
        switch(ObjectsMenuPage)
        {
        	case 0:
                if(CheckMouseRect(GameInfo.GameListe.ObjectsMenu.SetFoolButtonX, GameInfo.GameListe.ObjectsMenu.SetFoolButtonY,
                   GameInfo.GameListe.ObjectsMenu.SetFoolButtonX+FOOL_B, GameInfo.GameListe.ObjectsMenu.SetFoolButtonY+FOOL_H) != NO_AKTIV)
                {
                    CheckMouseButtonInfo(YES, 500, T_UNTERMENU_FOOL);
                    if(PressedButton == YES)
                        GameInfo.Befehl = SET_FOOL;
                }
                if(CheckMouseRect(GameInfo.GameListe.ObjectsMenu.SetGegnerDrohneButtonX, GameInfo.GameListe.ObjectsMenu.SetGegnerDrohneButtonY,
                   GameInfo.GameListe.ObjectsMenu.SetGegnerDrohneButtonX+32, GameInfo.GameListe.ObjectsMenu.SetGegnerDrohneButtonY+41) != NO_AKTIV)
                {
                    CheckMouseButtonInfo(YES, 500, T_UNTERMENU_GEGNER_DROHNE);
                    if(PressedButton == YES)
                        GameInfo.Befehl = DRAW_GEGNER_DROHNE;
                }
                if(CheckMouseRect(GameInfo.GameListe.ObjectsMenu.SetInstabilButtonX, GameInfo.GameListe.ObjectsMenu.SetInstabilButtonY,
                   GameInfo.GameListe.ObjectsMenu.SetInstabilButtonX+KACHEL_B+KACHEL_OVERLAY, GameInfo.GameListe.ObjectsMenu.SetInstabilButtonY+KACHEL_H+KACHEL_OVERLAY) != NO_AKTIV)
                {
                    CheckMouseButtonInfo(YES, 500, T_UNTERMENU_INSTABLI);
                    if(PressedButton == YES)
                    {
                        GameInfo.GameListe.ObjectsMenu.SetInstabilButtonDown = YES;
                        if(GameInfo.Befehl != SET_INSTABIL)
                        {
                            GameInfo.Befehl = SET_INSTABIL;
                            Editor_SetKachelAni = FIRST_INSTABIL;
                        }
                        else
                        {
                            if(TimerNew == YES)
                                TimerNew = NO;
                            else
                                return;
                            Editor_SetKachelAni++;
                            if(Editor_SetKachelAni > LAST_INSTABIL)
                                Editor_SetKachelAni = FIRST_INSTABIL;
                        }
                    }
                }
                if(CheckMouseRect(GameInfo.GameListe.ObjectsMenu.SetAtomikButtonX, GameInfo.GameListe.ObjectsMenu.SetAtomikButtonY,
                   GameInfo.GameListe.ObjectsMenu.SetAtomikButtonX+KACHEL_B, GameInfo.GameListe.ObjectsMenu.SetAtomikButtonY+KACHEL_H) != NO_AKTIV)
                {
                    CheckMouseButtonInfo(YES, 500, T_UNTERMENU_ATOMIK);
                    if(PressedButton == YES)
                    {
                        GameInfo.Befehl = SET_ATOMIK;
                        GameInfo.GameListe.ObjectsMenu.SetInstabilButtonDown = NO;
                    }
                }
                if(CheckMouseRect(GameInfo.GameListe.ObjectsMenu.SetBeamerButtonX, GameInfo.GameListe.ObjectsMenu.SetBeamerButtonY,
                   GameInfo.GameListe.ObjectsMenu.SetBeamerButtonX+KACHEL_B, GameInfo.GameListe.ObjectsMenu.SetBeamerButtonY+KACHEL_H) != NO_AKTIV)
                {
                    CheckMouseButtonInfo(YES, 500, T_UNTERMENU_BEAMER);
                    if(PressedButton == YES)
                    {
                        GameInfo.Befehl = SET_BEAMER;
                        GameInfo.GameListe.ObjectsMenu.SetInstabilButtonDown = NO;
                    }
                }
                if(CheckMouseRect(GameInfo.GameListe.ObjectsMenu.SetExitButtonX, GameInfo.GameListe.ObjectsMenu.SetExitButtonY,
                   GameInfo.GameListe.ObjectsMenu.SetExitButtonX+40, GameInfo.GameListe.ObjectsMenu.SetExitButtonY+60) != NO_AKTIV)
                {
                    CheckMouseButtonInfo(YES, 500, T_UNTERMENU_EXIT);
                    if(PressedButton == YES)
                    {
                        GameInfo.Befehl = SET_EXIT;
                        GameInfo.GameListe.ObjectsMenu.SetInstabilButtonDown = NO;
                    }
                }
                if(CheckMouseRect(GameInfo.GameListe.ObjectsMenu.SetTaxiKachelButtonX, GameInfo.GameListe.ObjectsMenu.SetTaxiKachelButtonY,
                   GameInfo.GameListe.ObjectsMenu.SetTaxiKachelButtonX+KACHEL_B, GameInfo.GameListe.ObjectsMenu.SetTaxiKachelButtonY+KACHEL_H) != NO_AKTIV)
                {
                    CheckMouseButtonInfo(YES, 500, T_UNTERMENU_TAXI);
                    if(PressedButton == YES)
                    {
                        GameInfo.Befehl = SET_TAXI_KACHEL;
                        GameInfo.GameListe.ObjectsMenu.SetInstabilButtonDown = NO;
                    }
                }
                if(CheckMouseRect(GameInfo.GameListe.ObjectsMenu.SetTaxiKachelSchalterButtonX, GameInfo.GameListe.ObjectsMenu.SetTaxiKachelSchalterButtonY,
                   GameInfo.GameListe.ObjectsMenu.SetTaxiKachelSchalterButtonX+KACHEL_B, GameInfo.GameListe.ObjectsMenu.SetTaxiKachelSchalterButtonY+KACHEL_H) != NO_AKTIV)
                {
                    CheckMouseButtonInfo(YES, 500, T_UNTERMENU_TAXI_SCHALTER);
                    if(PressedButton == YES)
                    {
                        GameInfo.Befehl = SET_TAXI_KACHEL_SCHALTER;
                        GameInfo.GameListe.ObjectsMenu.SetInstabilButtonDown = NO;
                    }
                }
                if(GameInfo.Befehl == SET_INSTABIL)
                {
                    i = CheckPushBar(GameInfo.GameListe.ObjectsMenu.AnzahlButtonX, GameInfo.GameListe.ObjectsMenu.AnzahlButtonY, 100, 15, 0);
                    if(i != NO_AKTIV)
                        InfoVar = i;
                    if(InfoVar < 0)
                        InfoVar = 0;
                    if(InfoVar > 99)
                        InfoVar = 99;
                }
        	break;

        	case 1:
                if(CheckMouseRect(GameInfo.GameListe.ObjectsMenu.SetGesundButtonX, GameInfo.GameListe.ObjectsMenu.SetGesundButtonY,
                   GameInfo.GameListe.ObjectsMenu.SetGesundButtonX+40, GameInfo.GameListe.ObjectsMenu.SetGesundButtonY+32) != NO_AKTIV)
                {
                    CheckMouseButtonInfo(YES, 500, T_UNTERMENU_GESUND);
                    if(PressedButton == YES)
                    {
                        GameInfo.Befehl = SET_GESUND;
                        GameInfo.GameListe.ObjectsMenu.SetInstabilButtonDown = NO;
                    }
                }
                if(CheckMouseRect(GameInfo.GameListe.ObjectsMenu.SetPunktButtonX, GameInfo.GameListe.ObjectsMenu.SetPunktButtonY,
                   GameInfo.GameListe.ObjectsMenu.SetPunktButtonX+25, GameInfo.GameListe.ObjectsMenu.SetPunktButtonY+25) != NO_AKTIV)
                {
                    CheckMouseButtonInfo(YES, 500, T_UNTERMENU_PUNKT);
                    if(PressedButton == YES)
                    {
                        GameInfo.Befehl = SET_PUNKT;
                        GameInfo.GameListe.ObjectsMenu.SetInstabilButtonDown = NO;
                    }
                }
                if(CheckMouseRect(GameInfo.GameListe.ObjectsMenu.SetPacManButtonX, GameInfo.GameListe.ObjectsMenu.SetPacManButtonY,
                   GameInfo.GameListe.ObjectsMenu.SetPacManButtonX+PACMAN_B, GameInfo.GameListe.ObjectsMenu.SetPacManButtonY+PACMAN_H) != NO_AKTIV)
                {
                    CheckMouseButtonInfo(YES, 500, T_UNTERMENU_PACMAN);
                    if(PressedButton == YES)
                        GameInfo.Befehl = SET_PACMAN;
                }
        	break;
		}
    }
} /* CheckObjectsMenu */

void DrawFoolsStatMenu(void)
{
    RECT rcRect;
    int i, y;
    char temp[50];

    if(GameInfo.GameListe.InfosDown == NO)
    	return;
    if(GameInfo.GameListe.InfosMenu.SlowDownButtonDown == YES)
        SetRect(&rcRect, 23, 863, 44, 884);
    else
        SetRect(&rcRect, 23, 841, 44, 862);
    Back->BltFast(GameInfo.GameListe.InfosMenu.SlowDownButtonX, GameInfo.GameListe.InfosMenu.SlowDownButtonY, GameListPic, &rcRect, FALSE);
    if(GameInfo.GameListe.InfosMenu.SlowUpButtonDown == YES)
        SetRect(&rcRect, 45, 863, 66, 884);
    else
        SetRect(&rcRect, 45, 841, 66, 862);
    Back->BltFast(GameInfo.GameListe.InfosMenu.SlowUpButtonX, GameInfo.GameListe.InfosMenu.SlowUpButtonY, GameListPic, &rcRect, FALSE);
    if(GameInfo.GameListe.InfosMenu.FastDownButtonDown == YES)
        SetRect(&rcRect, 67, 863, 88, 884);
    else
        SetRect(&rcRect, 67, 841, 88, 862);
    Back->BltFast(GameInfo.GameListe.InfosMenu.FastDownButtonX, GameInfo.GameListe.InfosMenu.FastDownButtonY, GameListPic, &rcRect, FALSE);
    if(GameInfo.GameListe.InfosMenu.FastUpButtonDown == YES)
        SetRect(&rcRect, 89, 863, 110, 884);
    else
        SetRect(&rcRect, 89, 841, 110, 862);
    Back->BltFast(GameInfo.GameListe.InfosMenu.FastUpButtonX, GameInfo.GameListe.InfosMenu.FastUpButtonY, GameListPic, &rcRect, FALSE);
    if(GameInfo.GameListe.InfosMenu.FirstButtonDown == YES)
        SetRect(&rcRect, 56, 1316, 77, 1337);
    else
        SetRect(&rcRect, 56, 1338, 77, 1359);
    Back->BltFast(GameInfo.GameListe.InfosMenu.FirstButtonX, GameInfo.GameListe.InfosMenu.FirstButtonY, GameListPic, &rcRect, FALSE);
    if(GameInfo.GameListe.InfosMenu.LastButtonDown == YES)
        SetRect(&rcRect, 78, 1316, 99, 1337);
    else
        SetRect(&rcRect, 78, 1338, 99, 1359);
    Back->BltFast(GameInfo.GameListe.InfosMenu.LastButtonX, GameInfo.GameListe.InfosMenu.LastButtonY, GameListPic, &rcRect, FALSE);
    for(i = InfoFoolStep, y = GameListeY+230; i < InfoFoolStep+MAX_INFO_FOOLS; i++, y += FOOL_H)
    {
        if(Szenario.Info.FoolInfo[i].Fool_ID == NO_AKTIV)
		{
	        y -= FOOL_B+10;
        	continue;
        }
        if(Szenario.Info.FoolInfo[i].OnLive == YES)
        {
            if(GameInfo.SelectedFool == i)
            {
                rcRect.left   = 0;
                rcRect.top    = 1+GameInfo.SelectedFoolAni*51;
                rcRect.right  = 59;
                rcRect.bottom = 1+GameInfo.SelectedFoolAni*51+50;
                Back->BltFast(GameListeX-7, y+22, FoolSelectedPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
            }
            DrawAnimatedFool(i, GameListeX+5, GameListeY+y, Back, YES);
        }
        if(Szenario.Info.FoolInfo[i].OnLive == NO)
        {
            rcRect.left   = 1+(Szenario.Info.FoolInfo[i].AnimationStep*52);
            rcRect.top    = 2481;
            rcRect.right  = 1+(Szenario.Info.FoolInfo[i].AnimationStep*52)+50;
            rcRect.bottom = 2552;
            Back->BltFast(GameListeX, y-5, FoolAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        }
        if(Szenario.Info.FoolInfo[i].OnLive == FINISH)
        {
            rcRect.left   = 1+(Szenario.Info.FoolInfo[i].AnimationStep*52);
            rcRect.top    = 2553;
            rcRect.right  = 1+(Szenario.Info.FoolInfo[i].AnimationStep*52)+50;
            rcRect.bottom = 2624;
            Back->BltFast(GameListeX, y-5, FoolAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        }
       //  Name des Fools:
        PrintText(GameListeX+40, GameListeY+y+10, Szenario.Info.FoolInfo[i].FoolName, 1, 0, Font[1].MaxXZeichen, Font[1].MaxYZeichen, Back);
       // Noch vorhandene Energie der Fools:
        SetRect(&rcRect, Szenario.Info.FoolInfo[i].Power, 915, FULL_POWER, 930);
        Back->BltFast(GameListeX+40+Szenario.Info.FoolInfo[i].Power, GameListeY+y+30, GameListPic, &rcRect, FALSE);
        SetRect(&rcRect, 1, 772, Szenario.Info.FoolInfo[i].Power, 787);
        Back->BltFast(GameListeX+40, GameListeY+y+30, GameListPic, &rcRect, FALSE);
        sprintf(temp, "%d", Szenario.Info.FoolInfo[i].Power);
        PrintText(GameListeX+70, GameListeY+y+33, temp, 1, 0, 80, 80, Back);
        PrintText(GameListeX+60, GameListeY+190, GameTexte[T_SPALTE], 1, 0, 80, 80, Back);
        sprintf(temp, "%d", InfoFoolStep);
        PrintText(GameListeX+60, GameListeY+210, temp, 1, 0, 80, 80, Back);
    }
} /* DrawFoolsStatMenu */

void CheckFoolsStatMenu(void)
{
    int i, y;

    if(GameInfo.GameListe.InfosDown == NO)
    	return;
    if(CheckMouseRect(GameInfo.GameListe.InfosMenu.SlowDownButtonX, GameInfo.GameListe.InfosMenu.SlowDownButtonY,
       GameInfo.GameListe.InfosMenu.SlowDownButtonX+20, GameInfo.GameListe.InfosMenu.SlowDownButtonY+20) != NO_AKTIV)
    {
        CheckMouseButtonInfo(YES, 500, T_UNTERMENU_SLOW_DOWN);
        if(PressedButton == YES)
        {
            InfoFoolStep++;
            if(InfoFoolStep > MAX_FOOLS-MAX_INFO_FOOLS)
            {
                InfoFoolStep = MAX_FOOLS-MAX_INFO_FOOLS;
                GameInfo.GameListe.InfosMenu.SlowDownButtonDown = YES;
                GameInfo.GameListe.InfosMenu.FastDownButtonDown = YES;
            }
            else
                SetAllInfoButtonsOff();
        }
    }
    if(CheckMouseRect(GameInfo.GameListe.InfosMenu.SlowUpButtonX, GameInfo.GameListe.InfosMenu.SlowUpButtonY,
       GameInfo.GameListe.InfosMenu.SlowUpButtonX+20, GameInfo.GameListe.InfosMenu.SlowUpButtonY+20) != NO_AKTIV)
    {
        CheckMouseButtonInfo(YES, 500, T_UNTERMENU_SLOW_UP);
        if(PressedButton == YES)
        {
            InfoFoolStep--;
            if(InfoFoolStep < 0)
            {
                InfoFoolStep = 0;
                GameInfo.GameListe.InfosMenu.SlowUpButtonDown = YES;
                GameInfo.GameListe.InfosMenu.FastUpButtonDown = YES;
            }
            else
                SetAllInfoButtonsOff();
		}
    }
    if(CheckMouseRect(GameInfo.GameListe.InfosMenu.FastDownButtonX, GameInfo.GameListe.InfosMenu.FastDownButtonY,
       GameInfo.GameListe.InfosMenu.FastDownButtonX+20, GameInfo.GameListe.InfosMenu.FastDownButtonY+20) != NO_AKTIV)
    {
        CheckMouseButtonInfo(YES, 500, T_UNTERMENU_FAST_DOWN);
        if(PressedButton == YES)
        {
            InfoFoolStep += MAX_INFO_FOOLS;
            if(InfoFoolStep > MAX_FOOLS-MAX_INFO_FOOLS)
            {
                InfoFoolStep = MAX_FOOLS-MAX_INFO_FOOLS;
                GameInfo.GameListe.InfosMenu.SlowDownButtonDown = YES;
                GameInfo.GameListe.InfosMenu.FastDownButtonDown = YES;
            }
            else
                SetAllInfoButtonsOff();
		}
    }
    if(CheckMouseRect(GameInfo.GameListe.InfosMenu.FastUpButtonX, GameInfo.GameListe.InfosMenu.FastUpButtonY,
       GameInfo.GameListe.InfosMenu.FastUpButtonX+20, GameInfo.GameListe.InfosMenu.FastUpButtonY+20) != NO_AKTIV)
    {
        CheckMouseButtonInfo(YES, 500, T_UNTERMENU_FAST_UP);
        if(PressedButton == YES)
        {
            InfoFoolStep -= MAX_INFO_FOOLS;
            if(InfoFoolStep < 0)
            {
                InfoFoolStep = 0;
                GameInfo.GameListe.InfosMenu.SlowUpButtonDown = YES;
                GameInfo.GameListe.InfosMenu.FastUpButtonDown = YES;
            }
            else
                SetAllInfoButtonsOff();
		}
    }
    if(CheckMouseRect(GameInfo.GameListe.InfosMenu.FirstButtonX, GameInfo.GameListe.InfosMenu.FirstButtonY,
       GameInfo.GameListe.InfosMenu.FirstButtonX+20, GameInfo.GameListe.InfosMenu.FirstButtonY+20) != NO_AKTIV)
    {
        CheckMouseButtonInfo(YES, 500, T_UNTERMENU_FIRST);
        if(PressedButton == YES)
        {
            InfoFoolStep = 0;
            SetAllInfoButtonsOff();
            GameInfo.GameListe.InfosMenu.FirstButtonDown = YES;
            GameInfo.GameListe.InfosMenu.SlowUpButtonDown = YES;
            GameInfo.GameListe.InfosMenu.FastUpButtonDown = YES;
        }
    }
    if(CheckMouseRect(GameInfo.GameListe.InfosMenu.LastButtonX, GameInfo.GameListe.InfosMenu.LastButtonY,
       GameInfo.GameListe.InfosMenu.LastButtonX+20, GameInfo.GameListe.InfosMenu.LastButtonY+20) != NO_AKTIV)
    {
        CheckMouseButtonInfo(YES, 500, T_UNTERMENU_LAST);
        if(PressedButton == YES)
        {
            InfoFoolStep = MAX_FOOLS-MAX_INFO_FOOLS;
            SetAllInfoButtonsOff();
            GameInfo.GameListe.InfosMenu.LastButtonDown = YES;
            GameInfo.GameListe.InfosMenu.SlowDownButtonDown = YES;
            GameInfo.GameListe.InfosMenu.FastDownButtonDown = YES;
		}
    }
    for(i = InfoFoolStep, y = GameListeY+230; i < InfoFoolStep+MAX_INFO_FOOLS; i++, y += FOOL_H)
    {
        CheckMouseButtonInfo(YES, 500, T_UNTERMENU_INSPECT_FOOL);
        if(PressedButton == YES)
        {
            if(CheckMouseRect(GameListeX+5, y, GameListeX+5+FOOL_B, y+FOOL_H) != NO_AKTIV)
            {
                GameInfo.SelectedFool = i;
                GameInfo.GameListe.BuiltDown = YES;
                GameInfo.GameListe.InfosDown = NO;
                GameInfo.GameListe.StatistikDown = NO;
                GameInfo.GameListe.OptionsDown = NO;
                GameInfo.GameListe.ObjectsDown = NO;
                GameInfo.GameListe.SzenarioDown = NO;
                GameInfo.GameListe.CommandsDown = NO;
            }
		}
    }
} /* CheckFoolsStatMenu */

void SetAllInfoButtonsOff(void)
{
    GameInfo.GameListe.InfosMenu.SlowDownButtonDown = NO;
    GameInfo.GameListe.InfosMenu.SlowUpButtonDown = NO;
    GameInfo.GameListe.InfosMenu.FastDownButtonDown = NO;
    GameInfo.GameListe.InfosMenu.FastUpButtonDown = NO;
    GameInfo.GameListe.InfosMenu.FirstButtonDown = NO;
    GameInfo.GameListe.InfosMenu.LastButtonDown = NO;
} /* SetAllInfoButtonsOff */

void AllObermenusOff(void)
{
    GameInfo.GameListe.BuiltDown = NO;
    GameInfo.GameListe.InfosDown = NO;
    GameInfo.GameListe.StatistikDown = NO;
    GameInfo.GameListe.OptionsDown = NO;
    GameInfo.GameListe.ObjectsDown = NO;
    GameInfo.GameListe.SzenarioDown = NO;
    GameInfo.GameListe.SzenarioMenu.LoadSzenarioButtonDown = NO;
    GameInfo.GameListe.CommandsDown = NO;
}

#define GAME_OUT 6

extern void CheckIntroButtons(void);
extern void DrawMainButtons(struct ANIMATE_BUTTON *);
extern struct ANIMATE_BUTTON GameOutButtons[2];
extern void InitIntro(void);
extern void LoadIntroBitmaps(void);
extern void CheckMouseButtons(void);

int GameIsNowOut(void);
void BuildGameOutScene(void);
void CheckGameOutMouse(void);
void CheckGameOutKeys(WPARAM);

LPDIRECTDRAWSURFACE OutPic;

int GameIsNowOut(void)
{
    MSG         msg;

	if(ExitProgramm == YES)
    	return 0;
    InitIntro();
	LoadIntroBitmaps();
    OutPic = DDLoadBitmap(lpDD, "Bilder/Out.bmp", 0, 0, NO);
    ExitModule = NO;
	CheckKeyModule = CheckGameOutKeys;
    SetMouseBound(0, 0, ScreenRes[0], ScreenRes[1]);
    SetMouseStyle(NORMAL_MOUSE_STYLE, YES, 1, 0, 0, 15, YES, 0);
    GameInfo.Module = GAME_OUT;
    for(;;)
    {
        if(PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
        {
            if(!GetMessage( &msg, NULL, 0, 0))
                return msg.wParam;
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
        else
            if(!gExclusive || bActive)
            {
				if(CheckMouseBarMenu() == NO)
                {
					CheckMouseButtons();
                	CheckIntroButtons();
	                CheckGameOutMouse();
                }
                BuildGameOutScene();
                UpdateDisplay();
                if(ExitModule == YES || ExitProgramm == YES)
                {
                    OutPic->Release();
                    return 0;
                }
            }
            else
            {
                WaitMessage();
            }
    }
} /* GameIsNowOut */

void BuildGameOutScene(void)
{
    RECT rcRect;

    SetRect(&rcRect, 0, 0, 640, 480);
	Back->BltFast(0, 0, OutPic, &rcRect, FALSE);
    if(GameInfo.Gewonnen == NO)
	    PrintText(ScreenRes[0]/2-100, 5, "Level Verloren!", 0, 0, 1000, 1000, Back);
    if(GameInfo.Gewonnen == YES)
	    PrintText(ScreenRes[0]/2-100, 5, "Level Gewonnen!", 0, 0, 1000, 1000, Back);
	DrawMainButtons(&GameOutButtons[0]);

} /* BuildGameOutScene */

void CheckGameOutMouse(void)
{
} /* CheckGameOutMouse */

void CheckGameOutKeys(WPARAM wParam)
{
    switch(wParam)
    {
        case VK_F12:
            if(UserMessage(GameTexte[T_PROGRAMM_EXIT_ASK], NO, YES, YES) == YES)
                ExitProgramm = YES;
        break;

        case VK_ESCAPE:
	        ExitModule = YES;
        break;
    }
} /* CheckGameOutKeys */

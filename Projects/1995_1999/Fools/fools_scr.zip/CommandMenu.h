#define MAX_COM_ANI_STEP 9

int CheckCommandMenu(void);
void CheckCommandMouse(void);
void DrawCommandMenu(void);
void CheckComAni(int);

struct FAST_MENU_BUTTON GameCommandMenu[] =
{
	{9, 9, 35, 35, COMMAND_DELETE, 0, NO, 0, 0, NO_AKTIV},
	{44, 9, 35, 35, COMMAND_WALK, 0, NO, 0, 0, NO_AKTIV},
	{79, 9, 35, 35, COMMAND_PUSH, 0, NO, 0, 0, NO_AKTIV},
	{9, 44, 35, 35, COMMAND_TAKE, 0, NO, 0, 0, NO_AKTIV},
	{44, 44, 35, 35, COMMAND_USE, 0, NO, 0, 0, NO_AKTIV},
	{79, 44, 35, 35, COMMAND_WAIT, 0, NO, 0, 0, NO_AKTIV},
	{9, 79, 35, 35, COMMAND_JUMP, 0, NO, 0, 0, NO_AKTIV},
	{44, 79, 35, 35, -1, 0, NO, 0, 0, NO_AKTIV},
	{79, 79, 35, 35, -1, 0, NO, 0, 0, NO_AKTIV},
	{-1, -1, -1, -1, 0, NO_AKTIV},
};

int CheckCommandMenu(void)
{
    MSG msg;

    if(CommandMenu != YES)
    {
        CommandMenu = YES;
        if(Mouse.XPos < ScreenRes[0]-CommandMenuB)
	    	CommandMenuPosX = Mouse.XPos;
	    else
        	CommandMenuPosX = ScreenRes[0]-CommandMenuB;
        if(Mouse.YPos < ScreenRes[1]-CommandMenuH)
	    	CommandMenuPosY = Mouse.YPos;
	    else
        	CommandMenuPosY = ScreenRes[1]-CommandMenuH;
        Mouse.Style = NORMAL_MOUSE_STYLE;
        SetMouseBound(CommandMenuPosX, CommandMenuPosY, CommandMenuPosX+CommandMenuB-Mouse.CursorB, CommandMenuPosY+CommandMenuH-Mouse.CursorH);
    }
    for(;;)
    {
        if(PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
        {
            if(!GetMessage( &msg, NULL, 0, 0 ) )
                return msg.wParam;
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
        else
           if(!gExclusive || bActive)
           {
              PlayDemo();
		      if(Mouse.Button != RIGHT_MOUSE_BUTTON && PressedMouseScroll == NO)
              {
				  CommandMenu = NO;
  			      SetMouseBound(0, 0, ScreenRes[0], ScreenRes[1]);
                  return(0);
              }
              CheckCommandMouse();
              MoveFools();
 			  MoveGegner();
   		      BuildGameScene();
              DrawCommandMenu();
			  UpdateDisplay();
           }
           else
           {
               WaitMessage();
           }
    }
} /* CheckCommandMenu */

// Der Spieler kann mit der Rechten Maustaste ein Befehle Men� aufrufen, dieses
// wird hier abgefragt:
void CheckCommandMouse(void)
{
    char temp[50], CommandText[50];
	int i;

    for(i = 0; GameCommandMenu[i].x != NO_AKTIV; i++)
        GameCommandMenu[i].Selected = NO; // Schaltet alle Buttons aus
    for(i = 0; GameCommandMenu[i].x != NO_AKTIV; i++)
    {
    	if(CheckMouseRect(GameCommandMenu[i].x+CommandMenuPosX,
        	GameCommandMenu[i].y+CommandMenuPosY,
            GameCommandMenu[i].x+CommandMenuPosX+GameCommandMenu[i].b,
            GameCommandMenu[i].y+CommandMenuPosY+GameCommandMenu[i].h) == NO_AKTIV)
	        continue;  // Dieser Befehl wurde nicht gew�hlt, also zum n�chsten.
        if(GameCommandMenu[i].SelectedOn == NO)
        {
            GameCommandMenu[i].SelectedOn = YES;
            GameCommandMenu[i].Step = 0;
            GameCommandMenu[i].Turn = 0;
        }
        GameCommandMenu[i].Selected = YES;
        // Sucht den Befehl aus:
        switch(GameCommandMenu[i].Funk)
        {
            case COMMAND_DELETE: sprintf(CommandText, "%s", GameTexte[T_COMMAND_DELETE]); break;
            case COMMAND_WALK: sprintf(CommandText, "%s", GameTexte[T_COMMAND_WALK]); break;
            case COMMAND_PUSH: sprintf(CommandText, "%s", GameTexte[T_COMMAND_PUSH]); break;
            case COMMAND_TAKE: sprintf(CommandText, "%s", GameTexte[T_COMMAND_TAKE]); break;
            case COMMAND_USE: sprintf(CommandText, "%s", GameTexte[T_COMMAND_USE]); break;
            case COMMAND_WAIT: sprintf(CommandText, "%s", GameTexte[T_COMMAND_WAIT]); break;
            case COMMAND_JUMP: sprintf(CommandText, "%s", GameTexte[T_COMMAND_JUMP]); break;
            case -1: sprintf(CommandText, "%s", GameTexte[T_NOCH_NICHT_VORHANDEN]); break;
        }
        if(GameCommandMenu[i].Anzahl == NO_AKTIV)
        {
            GameInfo.Befehl = NO_COMMAND;
            sprintf(temp, "%s...(%s)", CommandText, GameTexte[T_BEFEHL_IST_VERBRAUCHT]);
            SetBB_SmallMessage(temp, 20);
        }
        else
        {
            GameInfo.Befehl = GameCommandMenu[i].Funk;
            sprintf(temp, "%s...", CommandText);
            SetBB_SmallMessage(temp, 20);
        }
        if(GameCommandMenu[i].Selected == YES && GameCommandMenu[i].SelectedOn == YES)
             CheckComAni(i);
        else
            if(GameCommandMenu[i].Step > 0)
                GameCommandMenu[i].Step--;
            else
                GameCommandMenu[i].SelectedOn = NO;
    }
}

void CheckComAni(int i)
{
    if(GameCommandMenu[i].Turn == 0)
        if(GameCommandMenu[i].Step < MAX_COM_ANI_STEP)
            GameCommandMenu[i].Step++;
        else
            GameCommandMenu[i].Turn = 1;
    else
        if(GameCommandMenu[i].Step > 0)
            GameCommandMenu[i].Step--;
        else
            GameCommandMenu[i].Turn = 0;
} /* CheckComAni */

void DrawCommandMenu(void)
{
    RECT rcRect;
    int i;
    char temp[5];

    SetRect(&rcRect, 0, 0, CommandMenuB, CommandMenuH);
    Back->BltFast(CommandMenuPosX, CommandMenuPosY, CommandMenuPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
    for(i = 0; GameCommandMenu[i].x != NO_AKTIV; i++)
    {
        rcRect.left   = 1+(34*i);
        rcRect.top    = 1+(34*GameCommandMenu[i].Step);
        rcRect.right  = 1+(34*i)+32;
        rcRect.bottom = 34+(34*GameCommandMenu[i].Step);
        Back->BltFast(GameCommandMenu[i].x+CommandMenuPosX+1, GameCommandMenu[i].y+CommandMenuPosY+1, CommandMenuAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        if(GameCommandMenu[i].SelectedOn == YES && GameCommandMenu[i].Selected == YES)
        {
            rcRect.left   = 341;
            rcRect.top    = 1+(34*GameCommandMenu[i].Step);
            rcRect.right  = 374;
            rcRect.bottom = 34+(34*GameCommandMenu[i].Step);
            Back->BltFast(GameCommandMenu[i].x+CommandMenuPosX+1, GameCommandMenu[i].y+CommandMenuPosY+1, CommandMenuAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        }
    	if(GameCommandMenu[i].Anzahl != NO_LIMITED)
	    {
	    	if(GameCommandMenu[i].Anzahl == NO_AKTIV)
	            sprintf(temp, "--");
	        else
                sprintf(temp, "%d", GameCommandMenu[i].Anzahl);
            PrintText(GameCommandMenu[i].x+CommandMenuPosX+1, GameCommandMenu[i].y+CommandMenuPosY+1, temp, 1, 0, 80, 80, Back);
        }
    }
    SetMouseCursorPic();
} /* DrawCommandMenu */

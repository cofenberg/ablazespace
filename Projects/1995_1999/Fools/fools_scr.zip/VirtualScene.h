//////////////////////////////////////////////////////////////////////////
void DrawCommand(int, int, int, int, LPDIRECTDRAWSURFACE);
void DrawVirtualScene(int);
void DrawFool(int, int);
void DrawAnimatedFool(int, int, int, LPDIRECTDRAWSURFACE, int);
void DrawPacMan(int, int);
void DrawAnimatedPacMan(int, int, int, LPDIRECTDRAWSURFACE);
//////////////////////////////////////////////////////////////////////////
void DrawGegner(int, int);
void DrawAnimatedGegner(int, int, int, LPDIRECTDRAWSURFACE);
void DrawKachelFloorPic(int, int, int, LPDIRECTDRAWSURFACE);
void DrawKachelMasksPic(int, int, int, LPDIRECTDRAWSURFACE);
void DrawKachelIntemPic(int, int, int, LPDIRECTDRAWSURFACE);
void DrawKachelWallPic(int, int, int, LPDIRECTDRAWSURFACE, int);
//////////////////////////////////////////////////////////////////////////

void DrawVirtualScene(int Module)
{
    RECT rcRect;
    int x, y, Trans, XPersPixel;
    int Liste;
    char temp[50];

    Liste = 0;
    if(ProgrammSetup.ShowGameListe == YES)
	    Liste = 3;
    if(ProgrammSetup.ScreenResNr != 0)
	    Liste = 0;
   // Erstellt den Kartenausschnitt:
    for(y = (GameInfo.ScreenPosY-2); y < GameInfo.ScreenPosY+WINDOW_H-3; y++)
       for(x = (GameInfo.ScreenPosX-1)+PersXY[y][0]; x < GameInfo.ScreenPosX+WINDOW_B+9-Liste+PersXY[y][0]-3; x++)
	   {
            if(x > Szenario.Info.KarteB || x < 0 || y > Szenario.Info.KarteH || y < 0)
            	continue;
			DrawKachelFloorPic(Szenario.PosInfo[x][y], KACHEL_DISPLAY_X, KACHEL_DISPLAY_Y, GameAusgabe);
        }
    for(y = (GameInfo.ScreenPosY-2); y < GameInfo.ScreenPosY+WINDOW_H-3; y++)
       for(x = (GameInfo.ScreenPosX-1)+PersXY[y][0]; x < GameInfo.ScreenPosX+WINDOW_B+9-Liste+PersXY[y][0]-3; x++)
	   {
            if(x > Szenario.Info.KarteB || x < 0 || y > Szenario.Info.KarteH || y < 0)
            	continue;
			DrawKachelMasksPic(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Mask, KACHEL_DISPLAY_X-KACHEL_OVERLAY+Szenario.Kachel[Szenario.PosInfo[x][y]][KACHEL_PIXEL_X], KACHEL_DISPLAY_Y-KACHEL_OVERLAY+Szenario.Kachel[Szenario.PosInfo[x][y]][KACHEL_PIXEL_Y], GameAusgabe);
			DrawKachelIntemPic(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Intem, KACHEL_DISPLAY_X-KACHEL_OVERLAY+Szenario.Kachel[Szenario.PosInfo[x][y]][KACHEL_PIXEL_X], KACHEL_DISPLAY_Y-KACHEL_OVERLAY+Szenario.Kachel[Szenario.PosInfo[x][y]][KACHEL_PIXEL_Y], GameAusgabe);
   //       sprintf(temp, "%d:", Szenario.PosInfo[x][y]);
   //       PrintText(KACHEL_DISPLAY_X+5, KACHEL_DISPLAY_Y+5, temp, 1, 0, 1000, 1000, GameAusgabe);
            if(Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Command != NO_COMMAND)
                DrawCommand(Szenario.PosInfo[x][y], KACHEL_DISPLAY_X, KACHEL_DISPLAY_Y, NO, GameAusgabe);
        }
	if(GameInfo.SelectedFool != NO_AKTIV)
    {
		x = Szenario.Info.FoolInfo[GameInfo.SelectedFool].PosX;
		y = Szenario.Info.FoolInfo[GameInfo.SelectedFool].PosY;
        rcRect.left   = 0;
        rcRect.top    = 1+GameInfo.SelectedFoolAni*51;
        rcRect.right  = 59;
        rcRect.bottom = 1+GameInfo.SelectedFoolAni*51+50;
        XPersPixel = 0;
		if(Szenario.Info.FoolInfo[GameInfo.SelectedFool].Richtung == WALK_UP)
        {
            XPersPixel = Szenario.Info.FoolInfo[GameInfo.SelectedFool].PixelPosY;
            if(XPersPixel < 0)
            {
                XPersPixel = XPersPixel*(-1);
                XPersPixel = XKachelPers[XPersPixel]*(-1);
            }
            else
                XPersPixel = XKachelPers[XPersPixel];
            XPersPixel -= 7;
		}
		if(Szenario.Info.FoolInfo[GameInfo.SelectedFool].Richtung == WALK_DOWN)
        {
            if(Szenario.Info.FoolInfo[GameInfo.SelectedFool].PixelPosY > -1)
	            XPersPixel = 0;
            else
            {
                XPersPixel = Szenario.Info.FoolInfo[GameInfo.SelectedFool].PixelPosY;
                if(XPersPixel < -1)
                {
                    XPersPixel = XPersPixel*(-1);
                    XPersPixel = XKachelPers[XPersPixel]*(-1);
                }
			}
            XPersPixel += 10;
		}
        GameAusgabe->BltFast(KACHEL_DISPLAY_X+Szenario.Info.FoolInfo[GameInfo.SelectedFool].PixelPosX-10+XPersPixel, KACHEL_DISPLAY_Y+Szenario.Info.FoolInfo[GameInfo.SelectedFool].PixelPosY-8, FoolSelectedPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
    }
    for(y = (GameInfo.ScreenPosY-2); y < GameInfo.ScreenPosY+WINDOW_H-2; y++)
        for(x = (GameInfo.ScreenPosX-1)+PersXY[y][0]; x < GameInfo.ScreenPosX+WINDOW_B+9-Liste+PersXY[y][0]-1; x++)
	    {
            if(x > Szenario.Info.KarteB || x < 0 || y > Szenario.Info.KarteH || y < 0)
            	continue;
            // Das Fool makiert zeichen wird gemalt:
            Trans = 0;
            if(GameInfo.SelectedFool != NO_AKTIV && ProgrammSetup.GameSelectedTrans == YES)
                if(Szenario.Info.Kachel[Szenario.PosInfo[x][y-1]].Besetzt == GameInfo.SelectedFool ||
                   Szenario.Info.Kachel[Szenario.PosInfo[x-1][y-1]].Besetzt == GameInfo.SelectedFool)
                {
                    if(Szenario.Info.Kachel[Szenario.PosInfo[x-1][y-1]].Besetzt == GameInfo.SelectedFool &&
                        Szenario.Info.Kachel[Szenario.PosInfo[x][y-1]].WallPic == NO_AKTIV)
                        Trans = KACHEL_H+2;
                    if(Szenario.Info.Kachel[Szenario.PosInfo[x][y-1]].Besetzt == GameInfo.SelectedFool &&
                        Szenario.Info.Kachel[Szenario.PosInfo[x][y-1]].WallPic == NO_AKTIV)
                        Trans = KACHEL_H+2;
                }
            if(((Mouse.SelectedKachel == Szenario.PosInfo[x][y-1] && Szenario.Info.Kachel[Szenario.PosInfo[x][y-1]].WallPic == NO_AKTIV) && ProgrammSetup.GameMouseTrans == YES) ||
                ProgrammSetup.GameLongWalls == NO)
                Trans = KACHEL_H+2;
 		    DrawGegner(x, y);
 		    DrawPacMan(x, y);
 		    DrawFool(x, y);
            XPersPixel = Szenario.Kachel[Szenario.PosInfo[x][y]][KACHEL_PIXEL_Y];
            if(XPersPixel < 0)
            {
                XPersPixel = XPersPixel*(-1);
                XPersPixel = XKachelPers[XPersPixel]*(-1);
            }
            else
                XPersPixel = XKachelPers[XPersPixel];
			DrawKachelWallPic(Szenario.PosInfo[x][y], KACHEL_DISPLAY_X+XPersPixel, KACHEL_DISPLAY_Y, GameAusgabe, PUNKT);
			DrawKachelWallPic(Szenario.PosInfo[x][y], KACHEL_DISPLAY_X+XPersPixel-10, KACHEL_DISPLAY_Y-(WALL_H-KACHEL_H)+Trans, GameAusgabe, Trans);
       }
	if(GameInfo.SelectedFool != NO_AKTIV)
    {
		x = Szenario.Info.FoolInfo[GameInfo.SelectedFool].PosX;
		y = Szenario.Info.FoolInfo[GameInfo.SelectedFool].PosY;
        if(Szenario.Info.FoolInfo[GameInfo.SelectedFool].OnLive == NO)
        {
            rcRect.left   = 261+(Szenario.Info.FoolInfo[GameInfo.SelectedFool].AnimationStep*52);
            rcRect.top    = 2481;
            rcRect.right  = 261+(Szenario.Info.FoolInfo[GameInfo.SelectedFool].AnimationStep*52)+50;
            rcRect.bottom = 2552;
            GameAusgabe->BltFast(KACHEL_DISPLAY_X, KACHEL_DISPLAY_Y-(FOOL_H-KACHEL_H)-10, FoolAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        }
        if(Szenario.Info.FoolInfo[GameInfo.SelectedFool].OnLive == FINISH)
        {
            rcRect.left   = 261+(Szenario.Info.FoolInfo[GameInfo.SelectedFool].AnimationStep*52);
            rcRect.top    = 2553;
            rcRect.right  = 261+(Szenario.Info.FoolInfo[GameInfo.SelectedFool].AnimationStep*52)+50;
            rcRect.bottom = 2624;
            GameAusgabe->BltFast(KACHEL_DISPLAY_X-20, KACHEL_DISPLAY_Y-(FOOL_H-KACHEL_H)-10, FoolAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        }
    }
    for(y = (GameInfo.ScreenPosY-2); y < GameInfo.ScreenPosY+WINDOW_H-3; y++)
        for(x = (GameInfo.ScreenPosX-1)+PersXY[y][0]; x < GameInfo.ScreenPosX+WINDOW_B+9-Liste+PersXY[y][0]-3; x++)
        {
            if(x > Szenario.Info.KarteB || x < 0 || y > Szenario.Info.KarteH || y < 0)
            	continue;
            if((Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Command != NO_COMMAND
            	&& Szenario.Info.Kachel[Szenario.PosInfo[x][y+1]].WallPic != NO_AKTIV) ||
               (Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Command != NO_COMMAND
            	&& Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPic > MOVE_WALLS-1) ||
                Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPicAniStepTurn == PUNKT)
                DrawCommand(Szenario.PosInfo[x][y], KACHEL_DISPLAY_X, KACHEL_DISPLAY_Y, YES, GameAusgabe);

        // Zeigt an, dass ein Commando gesetzt werden kann:
            if(GameInfo.Befehl != NO_COMMAND && GameInfo.AnimatetCommandOn == YES && Mouse.SelectedKachel == Szenario.PosInfo[x][y])
            {
                if((Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Pic != NO_KACHEL && Szenario.Info.Kachel[Mouse.SelectedKachel].WallPic == NO_AKTIV &&
                   Szenario.Info.Kachel[Szenario.PosInfo[x][y]].CommandConst == NO &&
                   Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Pic < DEADLY_WALKS) ||
                  (Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Pic != NO_KACHEL && Szenario.Info.Kachel[Mouse.SelectedKachel].WallPic > MOVE_WALLS-1 &&
                   Szenario.Info.Kachel[Szenario.PosInfo[x][y]].CommandConst == NO &&
                   Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Pic < DEADLY_WALKS) ||
                  (Szenario.Info.Kachel[Mouse.SelectedKachel].Mask > FIRST_MOVE_MASK-1 && Szenario.Info.Kachel[Mouse.SelectedKachel].Mask < FIRST_MOVE_MASK+MAX_MOVE_MASK-1))
                {
                    switch(GameInfo.Befehl)
                    {
                    	case COMMAND_WALK: Trans = WALK_LEFT+GameInfo.AnimatetCommand; break;
                    	case COMMAND_PUSH: Trans = PUSH_LEFT+GameInfo.AnimatetCommand; break;
                    	case COMMAND_TAKE: Trans = TAKE_LEFT+GameInfo.AnimatetCommand; break;
                    	case COMMAND_USE: Trans = USE_LEFT+GameInfo.AnimatetCommand; break;
                    	case COMMAND_WAIT: Trans = COMMAND_WAIT; break;
                        default: Trans = NO_AKTIV; break;
                    }
 					if(Trans != NO_AKTIV)
		                DrawCommand(Trans, KACHEL_DISPLAY_X, KACHEL_DISPLAY_Y, -2, GameAusgabe);
                }
            }
        }
   ////////////
    rcRect.left   = 70+GameInfo.ScreenPixelPosX+KACHEL_B;
    rcRect.top    = 50+GameInfo.ScreenPixelPosY+(KACHEL_H*2);
    rcRect.right  = 70+WINDOW_BP+GameInfo.ScreenPixelPosX+KACHEL_B;
    rcRect.bottom = 50+WINDOW_HP+GameInfo.ScreenPixelPosY+(KACHEL_H*2);
    Back->BltFast(WINDOW_X, WINDOW_Y, GameAusgabe, &rcRect, FALSE);
  // Lebende Fools Anzeige:
    SetRect(&rcRect, 100, 480, 120, 510);
    Back->BltFast(5, 5, GameListPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
    sprintf(temp, "%d", GameInfo.LiveFools);
    PrintText(25, 5, temp, 0, 0, 34, Font[0].MaxYZeichen, Back);
  // Tote Fools Anzeige:
    SetRect(&rcRect, 100, 510, 120, 540);
    Back->BltFast(5, 40, GameListPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
    sprintf(temp, "%d", GameInfo.DeadFools);
    PrintText(25, 40, temp, 0, 0, 34, Font[0].MaxYZeichen, Back);
  // Fisish Fools Anzeige:
    SetRect(&rcRect, 57, 530, 81, 557);
    Back->BltFast(5, 75, GameListPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
    sprintf(temp, "%d", GameInfo.FinishFools);
    PrintText(25, 75, temp, 0, 0, 34, Font[0].MaxYZeichen, Back);
  //////
    if(ProgrammSetup.ShowGameListe == YES)
	{
        DrawGameListe(Module);
    	CheckMiniFilter(GameListeX+6, GameListeY+10);
	    DrawMiniToDisplay(GameListeX+6, GameListeY+10);
  // Die Ecken des rechten Men�s:
        SetRect(&rcRect, 0, 480, 49, 530);
        Back->BltFast(GameListeX-49, GameListeY, GameListPic, &rcRect, DDBLTFAST_SRCCOLORKEY); // Spiel Menu setzen
        SetRect(&rcRect, 50, 480, 100, 530);
        Back->BltFast(GameListeX-49, GameListeY+430, GameListPic, &rcRect, DDBLTFAST_SRCCOLORKEY); // Spiel Menu setzen
       // Lupe Zeichen:
        SetRect(&rcRect, 79, 1+(GameInfo.LupeStep*26), 104, 1+(GameInfo.LupeStep*26)+25);
        Back->BltFast(LUPE_X, LUPE_Y, Mouse.Pic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        SetRect(&rcRect, 105, 1+(GameInfo.LupeStep*26), 130, 1+(GameInfo.LupeStep*26)+25);
        Back->BltFast(INSPECT_X, INSPECT_Y, Mouse.Pic, &rcRect, DDBLTFAST_SRCCOLORKEY);
       // An\Aus Symbol:
        SetRect(&rcRect, 46, 749, 61, 764);
        Back->BltFast(GameListeX-20, GameListeY+440, GameListPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
    }
    if(ProgrammSetup.ShowGameListe == NO)
    {
  // Die Ecken des rechten Men�s:
        SetRect(&rcRect, 0, 480, 49, 530);
        Back->BltFast(GameListeX+120-49, GameListeY, GameListPic, &rcRect, DDBLTFAST_SRCCOLORKEY); // Spiel Menu setzen
        SetRect(&rcRect, 50, 480, 100, 530);
        Back->BltFast(GameListeX+120-50, GameListeY+430, GameListPic, &rcRect, DDBLTFAST_SRCCOLORKEY); // Spiel Menu setzen
       // Lupe Zeichen:
        SetRect(&rcRect, 79, 1+(GameInfo.LupeStep*26), 104, 1+(GameInfo.LupeStep*26)+25);
        Back->BltFast(LUPE_X+120, LUPE_Y, Mouse.Pic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        SetRect(&rcRect, 105, 1+(GameInfo.LupeStep*26), 130, 1+(GameInfo.LupeStep*26)+25);
        Back->BltFast(INSPECT_X+120, INSPECT_Y, Mouse.Pic, &rcRect, DDBLTFAST_SRCCOLORKEY);
       // An\Aus Symbol:
        SetRect(&rcRect, 62, 749, 77, 764);
        Back->BltFast(GameListeX+100, GameListeY+440, GameListPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
    }
    // Malt das Maus Object auf den Bildschirm:
	switch(GameInfo.Befehl)
    {
    	case SET_FOOL:
            rcRect.left   = 1;
            rcRect.top    = 1861+((FOOL_H+2)*GameCommandMenu[0].Step);
            rcRect.right  = 1+FOOL_B;
            rcRect.bottom = 1861+((FOOL_H+2)*GameCommandMenu[0].Step)+FOOL_H;
            Back->BltFast(Mouse.XPos, Mouse.YPos, FoolAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
            CheckComAni(0);
        break;

    	case SET_PACMAN:
            int i;

	        i = GameCommandMenu[0].Step;
            if(i > 9)
            	i = 9;
	        SetRect(&rcRect, 1+(i*(PACMAN_B+2)), 1, 1+(i*(PACMAN_B+2))+PACMAN_B, 1+PACMAN_H);
            Back->BltFast(Mouse.XPos, Mouse.YPos, PacManAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
            CheckComAni(0);
        break;

    	case DRAW_GEGNER_DROHNE:
            SetRect(&rcRect, 1, 1, 33, 42);
            Back->BltFast(Mouse.XPos, Mouse.YPos, GegnerAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
            CheckComAni(0);
        break;

    	case SET_INSTABIL:
            rcRect.left   = 1+Editor_SetKachelAni*(KACHEL_B+5);
            rcRect.top    = 1;
            rcRect.right  = 1+Editor_SetKachelAni*(KACHEL_B+5)+KACHEL_B+KACHEL_OVERLAY;
            rcRect.bottom = 1+KACHEL_H+KACHEL_OVERLAY;
            Back->BltFast(Mouse.XPos, Mouse.YPos, Szenario.MasksLevelPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        break;

    	case SET_EXIT:
            rcRect.left   = 1;
            rcRect.top    = 2553;
            rcRect.right  = 51;
            rcRect.bottom = 2624;
            Back->BltFast(Mouse.XPos, Mouse.YPos, FoolAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        break;

    	case SET_PUNKT:
	        SetRect(&rcRect, 1+(GameCommandMenu[0].Step*27), 1, 1+(GameCommandMenu[0].Step*27)+26, 27);
            Back->BltFast(Mouse.XPos, Mouse.YPos, Szenario.PunktLevelPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
            CheckComAni(0);
        break;

        case SET_ATOMIK: DrawKachelMasksPic(ATOMIK, Mouse.XPos, Mouse.YPos, Back); break;
        case SET_GESUND: DrawKachelMasksPic(GESUND, Mouse.XPos, Mouse.YPos, Back); break;
        case SET_BEAMER: DrawKachelMasksPic(BEAMER, Mouse.XPos, Mouse.YPos, Back); break;
        case SET_TAXI_KACHEL: DrawKachelMasksPic(TAXI_KACHEL, Mouse.XPos, Mouse.YPos, Back); break;
        case SET_TAXI_KACHEL_SCHALTER: DrawKachelMasksPic(TAXI_KACHEL_SCHALTER, Mouse.XPos, Mouse.YPos, Back); break;

        default:
            if(GameInfo.Befehl == NO_COMMAND || GameInfo.Befehl == SELECT_COMMAND || GameInfo.Befehl == INSPECT_COMMAND)
		        break;
            rcRect.left   = 1+(34*(GameInfo.Befehl-100));
            rcRect.top    = 1+(34*GameCommandMenu[GameInfo.Befehl-100].Step);
            rcRect.right  = 1+(34*(GameInfo.Befehl-100))+32;
            rcRect.bottom = 1+(34*GameCommandMenu[GameInfo.Befehl-100].Step)+33;
            Back->BltFast(Mouse.XPos, Mouse.YPos, CommandMenuAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
            CheckComAni(GameInfo.Befehl-100);
        break;
    }
   // Zeit Anzeige Text:
    if(ProgrammSetup.ShowGameListe == YES)
	{
        SetRect(&rcRect, 0, 930, 85, 950);
        Back->BltFast(GameListeX-93, GameListeY+456, GameListPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        sprintf(temp, "%d:", GameInfo.PlayedTimeHours);
        PrintText(GameListeX-90, GameListeY+460, temp, 1, 0, 1000, 1000, Back);
        sprintf(temp, "%d:", GameInfo.PlayedTimeMin);
        PrintText(GameListeX-60, GameListeY+460, temp, 1, 0, 1000, 1000, Back);
        sprintf(temp, "%d", GameInfo.PlayedTimeSec);
        PrintText(GameListeX-30, GameListeY+460, temp, 1, 0, 1000, 1000, Back);
    }
    if(ProgrammSetup.ShowGameListe == NO)
	{
        SetRect(&rcRect, 0, 930, 85, 950);
        Back->BltFast(GameListeX-93+120, GameListeY+456, GameListPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        sprintf(temp, "%d:", GameInfo.PlayedTimeHours);
        PrintText(GameListeX-90+120, GameListeY+460, temp, 1, 0, 1000, 1000, Back);
        sprintf(temp, "%d:", GameInfo.PlayedTimeMin);
        PrintText(GameListeX-60+120, GameListeY+460, temp, 1, 0, 1000, 1000, Back);
        sprintf(temp, "%d", GameInfo.PlayedTimeSec);
        PrintText(GameListeX-30+120, GameListeY+460, temp, 1, 0, 1000, 1000, Back);
    }
    if(GameInfo.Pause == YES)
    {  // Das Spiel ist Pausiert worden:
	    SetRect(&rcRect, 0, 959, 120, 999);
	    Back->BltFast(ScreenRes[0]/2-60, ScreenRes[1]/2-20, GameListPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        PrintText(ScreenRes[0]/2-40, ScreenRes[1]/2-10, GameTexte[T_PAUSE], 0, 0, 40, Font[0].MaxYZeichen, Back);
    }
    else
    {
        CheckAniScene();
        CheckSelectedAni();
    }
   // Nachrichten Symbol:
   //    SetRect(&rcRect, 84, 735, 119, 760);
    SetRect(&rcRect, 84, 761, 119, 786);
    Back->BltFast(5, ScreenRes[1]-30, GameListPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
   ///////
    if((CheckMouseRect(GameListeX, GameListeY, GameListeX+120, GameListeY+480) == NO_AKTIV || ProgrammSetup.ShowGameListe == NO) && Mouse.SelectedKachel != NO_AKTIV)
    {
        sprintf(temp, "Selected Kachel:%d", Mouse.SelectedKachel);
        PrintText(100, ScreenRes[1]-20, temp, 0, 0, 1000, 100, Back);
    }
    ShowBB_Message(0);
    if(LevelFoolAniStep != NO_AKTIV && LevelFoolAniStepTurn != NO_AKTIV)
    {
        SetRect(&rcRect, 1, 1+(LevelFoolAniStep*129), 79, 1+(LevelFoolAniStep*129)+127);
        Back->BltFast(0, 340, LevelFool, &rcRect, DDBLTFAST_SRCCOLORKEY);
    }
	if(GameInfo.DirectControl == YES)
        PrintText(ScreenRes[0]/2-100, 30, "Directe Kontrolle!!", 0, 0, 1000, 100, Back);

/*       sprintf(temp, "Wall:%d: Pic:%d Be:%d Com:%d", Szenario.Info.Kachel[Mouse.SelectedKachel].WallPic, Szenario.Info.Kachel[Mouse.SelectedKachel].Pic, Szenario.Info.Kachel[Mouse.SelectedKachel].Besetzt, Szenario.Info.Kachel[Mouse.SelectedKachel].Command);
       PrintText(0, 100, temp, 1, 0, 1000, 1000, Back);
       sprintf(temp, "x:%d: y:%d    Pa:%d", Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_X], Szenario.Kachel[Mouse.SelectedKachel][KACHEL_POS_Y], FIRST_PACMAN);
       PrintText(0, 140, temp, 1, 0, 1000, 1000, Back);

       if(Szenario.Info.Kachel[Mouse.SelectedKachel].Besetzt > MAX_FOOLS-1)
       {
       sprintf(temp, "x:%d: y:%d typ:%d  R:%d", Szenario.Info.GegnerInfo[Szenario.Info.Kachel[Mouse.SelectedKachel].Besetzt-200].PosX, Szenario.Info.GegnerInfo[Szenario.Info.Kachel[Mouse.SelectedKachel].Besetzt-200].PosY, Szenario.Info.GegnerInfo[Szenario.Info.Kachel[Mouse.SelectedKachel].Besetzt-200].Typ, Szenario.Info.GegnerInfo[Szenario.Info.Kachel[Mouse.SelectedKachel].Besetzt-200].Richtung);
       PrintText(0, 180, temp, 1, 0, 1000, 1000, Back);
       }*/
	CheckPacManAni();
    CheckPacManWalk();
} /* DrawVirtualScene */

void DrawCommand(int i, int x, int y, int Trans, LPDIRECTDRAWSURFACE Picture)
{
    RECT rcRect;
    int com;

    if(Trans == -2)
    	com = i; // Nur als Befehl vorschau!
    else
		com = Szenario.Info.Kachel[i].Command;
    switch(com)
    {
        case WALK_LEFT: SetRect(&rcRect, 1, 1, 33, 32); break;
        case WALK_UP: SetRect(&rcRect, 34, 1, 66, 32); break;
        case WALK_RIGHT: SetRect(&rcRect, 67, 1, 99, 32); break;
        case WALK_DOWN:	SetRect(&rcRect, 100, 1, 132, 32); break;
        case USE_LEFT: SetRect(&rcRect, 133, 1, 165, 32); break;
        case USE_UP: SetRect(&rcRect, 166, 1, 198, 32); break;
        case USE_RIGHT:	SetRect(&rcRect, 199, 1, 231, 32); break;
        case USE_DOWN: SetRect(&rcRect, 232, 1, 264, 32); break;
        case COMMAND_WAIT: SetRect(&rcRect, 265, 1, 297, 32); break;
        case COMMAND_JUMP: SetRect(&rcRect, 265, 133, 297, 165); break;
        case PUSH_LEFT: SetRect(&rcRect, 1, 133, 33, 164); break;
        case PUSH_UP: SetRect(&rcRect, 34, 133, 66, 164); break;
        case PUSH_RIGHT: SetRect(&rcRect, 67, 133, 99, 164); break;
        case PUSH_DOWN:	SetRect(&rcRect, 100, 133, 132, 164); break;
        case TAKE_LEFT: SetRect(&rcRect, 133, 133, 165, 164); break;
        case TAKE_UP: SetRect(&rcRect, 166, 133, 198, 164); break;
        case TAKE_RIGHT: SetRect(&rcRect, 199, 133, 231, 164); break;
        case TAKE_DOWN:	SetRect(&rcRect, 232, 133, 264, 164); break;
    	default: return;
    }
    if(Trans != -1 && Trans != -2)
        if(Szenario.Info.Kachel[i].CommandConst == YES)
        {
            rcRect.top    += 1+((KACHEL_H+1)*2);
            rcRect.bottom += 1+((KACHEL_H+1)*2);
        }
    if(Trans == YES || Trans == -1 || Trans == -2)
    {
        rcRect.top    += KACHEL_H+1;
        rcRect.bottom += KACHEL_H+1;
    }
    Picture->BltFast(x, y, BefehlePic, &rcRect, DDBLTFAST_SRCCOLORKEY);
} /* DrawCommand */

void DrawFool(int KachelX, int KachelY)
{
    RECT rcRect;
    int i, x, y, XPersPixel;
    char temp[50];

    // Setzt einen Fool auf die Spielfl�che:
    if(Szenario.Info.Kachel[Szenario.PosInfo[KachelX][KachelY]].Besetzt != NO_AKTIV && Szenario.Info.Kachel[Szenario.PosInfo[KachelX][KachelY]].Besetzt < MAX_FOOLS)
    {
        i = Szenario.Info.Kachel[Szenario.PosInfo[KachelX][KachelY]].Besetzt;
        x = Szenario.Info.FoolInfo[i].PosX;
        y = Szenario.Info.FoolInfo[i].PosY;
        XPersPixel = 0;
		if(Szenario.Info.FoolInfo[i].Richtung == WALK_UP)
        {
            XPersPixel = Szenario.Info.FoolInfo[i].PixelPosY;
            if(XPersPixel < 0)
            {
                XPersPixel = XPersPixel*(-1);
                XPersPixel = XKachelPers[XPersPixel]*(-1);
            }
            else
                XPersPixel = XKachelPers[XPersPixel];
            XPersPixel -= 7;
		}
		if(Szenario.Info.FoolInfo[i].Richtung == WALK_DOWN)
        {
            if(Szenario.Info.FoolInfo[i].PixelPosY > -1)
	            XPersPixel = 0;
            else
            {
                XPersPixel = Szenario.Info.FoolInfo[i].PixelPosY;
                if(XPersPixel < -1)
                {
                    XPersPixel = XPersPixel*(-1);
                    XPersPixel = XKachelPers[XPersPixel]*(-1);
                }
			}
		}
        DrawAnimatedFool(i, KACHEL_DISPLAY_X+5+Szenario.Info.FoolInfo[i].PixelPosX+XPersPixel, KACHEL_DISPLAY_Y+Szenario.Info.FoolInfo[i].PixelPosY-(FOOL_H-KACHEL_H), GameAusgabe, YES);
        if(ProgrammSetup.ShowFoolPower == YES && Szenario.Info.FoolInfo[i].OnLive == YES)
        {
            SetRect(&rcRect, 46, 735, 83, 742);
            GameAusgabe->BltFast(KACHEL_DISPLAY_X+Szenario.Info.FoolInfo[i].PixelPosX-3, KACHEL_DISPLAY_Y+Szenario.Info.FoolInfo[i].PixelPosY-(FOOL_H-KACHEL_H)-8, GameListPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
            SetRect(&rcRect, 46, 743, 46+(Szenario.Info.FoolInfo[i].Power/2), 748);
            GameAusgabe->BltFast(KACHEL_DISPLAY_X+Szenario.Info.FoolInfo[i].PixelPosX-2, KACHEL_DISPLAY_Y+Szenario.Info.FoolInfo[i].PixelPosY-(FOOL_H-KACHEL_H)-7, GameListPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        }
        if(ProgrammSetup.ShowFoolName == YES)
        {
	        sprintf(temp, "%s", Szenario.Info.FoolInfo[i].FoolName);
	        PrintText(KACHEL_DISPLAY_X+5+Szenario.Info.FoolInfo[i].PixelPosX+Szenario.Kachel[Szenario.PosInfo[KachelX][KachelY]][KACHEL_PIXEL_X], KACHEL_DISPLAY_Y+Szenario.Info.FoolInfo[i].PixelPosY-(FOOL_H-KACHEL_H)+Szenario.Kachel[Szenario.PosInfo[KachelX][KachelY]][KACHEL_PIXEL_Y]+5,  temp, 1, 0, 1000, 1000, GameAusgabe);
        }
    }
} /* DrawFool */

void DrawAnimatedFool(int i, int x, int y, LPDIRECTDRAWSURFACE Picture, int Think)
{
    RECT rcRect;
    int Check;
    char temp[50];

    if(Szenario.Info.FoolInfo[i].Animation == NOW_DIED)
    {
        if(Szenario.Info.FoolInfo[i].AnimationStep < 9)
        {
            rcRect.left   = 1+(Szenario.Info.FoolInfo[i].Richtung*(FOOL_B+2));
            rcRect.top    = 1;
            rcRect.right  = 1+(Szenario.Info.FoolInfo[i].Richtung*(FOOL_B+2))+FOOL_B;
            rcRect.bottom = 1+FOOL_H;
            Picture->BltFast(x-5, y, FoolAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        }
        rcRect.left   = 44;
        rcRect.top    = 1241+(Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2));
        rcRect.right  = 44+FOOL_B;
        rcRect.bottom = 1241+(Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2))+FOOL_H;
        Picture->BltFast(x-5, y, FoolAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        goto End;
    }
    if(Szenario.Info.FoolInfo[i].Animation == BEAMING_START)
    {
        if(Szenario.Info.FoolInfo[i].AnimationStep < 9)
        {
            rcRect.left   = 1+(Szenario.Info.FoolInfo[i].Richtung*(FOOL_B+2));
            rcRect.top    = 1;
            rcRect.right  = 1+(Szenario.Info.FoolInfo[i].Richtung*(FOOL_B+2))+FOOL_B;
            rcRect.bottom = 1+FOOL_H;
            Picture->BltFast(x-5, y, FoolAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        }
        rcRect.left   = 127;
        rcRect.top    = 1241+(Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2));
        rcRect.right  = 168;
        rcRect.bottom = 1241+(Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2))+FOOL_H;
        Picture->BltFast(x-5, y, FoolAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        goto End;
    }
    if(Szenario.Info.FoolInfo[i].Animation == BEAMING_END)
    {
        if(Szenario.Info.FoolInfo[i].AnimationStep > 9)
        {
            rcRect.left   = 1+(Szenario.Info.FoolInfo[i].Richtung*(FOOL_B+2));
            rcRect.top    = 1;
            rcRect.right  = 1+(Szenario.Info.FoolInfo[i].Richtung*(FOOL_B+2))+FOOL_B;
            rcRect.bottom = 1+FOOL_H;
            Picture->BltFast(x-5, y, FoolAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        }
        rcRect.left   = 127;
        rcRect.top    = 1241+(Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2));
        rcRect.right  = 168;
        rcRect.bottom = 1241+(Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2))+FOOL_H;
        Picture->BltFast(x-5, y, FoolAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        goto End;
    }
    if(Szenario.Info.FoolInfo[i].Animation == ON_FINISH)
    {
        rcRect.left   = 169;
        rcRect.top    = 1241+(Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2));
        rcRect.right  = 210;
        rcRect.bottom = 1241+(Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2))+FOOL_H;
        Picture->BltFast(x-5, y, FoolAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        goto End;
    }
    if(Szenario.Info.FoolInfo[i].Animation == WRONG_EXIT_PAGE)
    {
        rcRect.left   = 589;
        rcRect.top    = 1+(Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2));
        rcRect.right  = 630;
        rcRect.bottom = 1+(Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2))+FOOL_H;
        Picture->BltFast(x-5, y, FoolAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        goto End;
    }
    if(Szenario.Info.FoolInfo[i].Animation != NOW_DIED && Szenario.Info.FoolInfo[i].Animation != BEAMING_START &&
	    Szenario.Info.FoolInfo[i].Animation != BEAMING_START_END && Szenario.Info.FoolInfo[i].Animation != BEAMING_END)
    {
        if(Szenario.Info.FoolInfo[i].OnLive == NO || Szenario.Info.FoolInfo[i].Fool_ID == NO_AKTIV)
            return;
        if(Szenario.Info.FoolInfo[i].Richtung == Szenario.Info.FoolInfo[i].Animation)
        {
            rcRect.left   = Szenario.Info.FoolInfo[i].Animation*(FOOL_B+2)+1;
            rcRect.top    = Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2)+1;
            rcRect.right  = Szenario.Info.FoolInfo[i].Animation*(FOOL_B+2)+1+FOOL_B;
            rcRect.bottom = Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2)+1+FOOL_H;
        }
        else
        {
            switch(Szenario.Info.FoolInfo[i].Animation)
            {
                case TURN_LEFT: case TURN_RIGHT:
                    if(Szenario.Info.FoolInfo[i].Animation == TURN_LEFT)
                        Check = 0;
                    else
                        Check = 10;
                    rcRect.top    = (Szenario.Info.FoolInfo[i].AnimationStep+Check)*(FOOL_H+2)+1;
                    rcRect.bottom = (Szenario.Info.FoolInfo[i].AnimationStep+Check)*(FOOL_H+2)+1+FOOL_H;
                    if(Szenario.Info.FoolInfo[i].AnimationTurn == 0)
                        Check = 4;
                    else
                        Check = 5;
                    rcRect.left   = Check*(FOOL_B+2)+1;
                    rcRect.right  = Check*(FOOL_B+2)+1+FOOL_B;
                break;

                case SILLY_LEFT: case SILLY_RIGHT: case SILLY_UP: case SILLY_DOWN:
                    rcRect.left   = (Szenario.Info.FoolInfo[i].Animation-SILLY_LEFT+6)*(FOOL_B+2)+1;
                    rcRect.right  = (Szenario.Info.FoolInfo[i].Animation-SILLY_LEFT+6)*(FOOL_B+2)+1+FOOL_B;
                    rcRect.top    = Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2)+1;
                    rcRect.bottom = Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2)+1+FOOL_H;
                break;

                case ON_PUSH_LEFT: case OFF_PUSH_LEFT:
                    rcRect.left   = 10*(FOOL_B+2)+1;
                    rcRect.right  = 10*(FOOL_B+2)+1+FOOL_B;
                    rcRect.top    = Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2)+1;
                    rcRect.bottom = Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2)+1+FOOL_H;
                break;

                case ON_PUSH_RIGHT: case OFF_PUSH_RIGHT:
                    rcRect.left   = 10*(FOOL_B+2)+1;
                    rcRect.right  = 10*(FOOL_B+2)+1+FOOL_B;
                    rcRect.top    = Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2)+1+10*(FOOL_H+2);
                    rcRect.bottom = Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2)+1+FOOL_H+10*(FOOL_H+2);
                break;

                case ON_PUSH_UP: case OFF_PUSH_UP:
                    rcRect.left   = 11*(FOOL_B+2)+1;
                    rcRect.right  = 11*(FOOL_B+2)+1+FOOL_B;
                    rcRect.top    = Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2)+1;
                    rcRect.bottom = Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2)+1+FOOL_H;
                break;

                case ON_PUSH_DOWN: case OFF_PUSH_DOWN:
                    rcRect.left   = 11*(FOOL_B+2)+1;
                    rcRect.right  = 11*(FOOL_B+2)+1+FOOL_B;
                    rcRect.top    = Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2)+1+10*(FOOL_H+2);
                    rcRect.bottom = Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2)+1+FOOL_H+10*(FOOL_H+2);
                break;

                case PUSH_LEFT:
                    rcRect.left   = 12*(FOOL_B+2)+1;
                    rcRect.right  = 12*(FOOL_B+2)+1+FOOL_B;
                    rcRect.top    = Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2)+1;
                    rcRect.bottom = Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2)+1+FOOL_H;
                break;

                case PUSH_UP:
                    rcRect.left   = 13*(FOOL_B+2)+1;
                    rcRect.right  = 13*(FOOL_B+2)+1+FOOL_B;
                    rcRect.top    = Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2)+1;
                    rcRect.bottom = Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2)+1+FOOL_H;
                break;

                case PUSH_RIGHT:
                    rcRect.left   = 14*(FOOL_B+2)+1;
                    rcRect.right  = 14*(FOOL_B+2)+1+FOOL_B;
                    rcRect.top    = Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2)+1;
                    rcRect.bottom = Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2)+1+FOOL_H;
                break;

                case PUSH_DOWN:
                    rcRect.left   = 1;
                    rcRect.right  = 1+FOOL_B;
                    rcRect.top    = Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2)+1+20*(FOOL_H+2);
                    rcRect.bottom = Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2)+1+FOOL_H+20*(FOOL_H+2);
                break;

                case WAITING:
                    if(Szenario.Info.FoolInfo[i].Richtung == WALK_LEFT)
                    {
                        rcRect.left   = 85;
                        rcRect.right  = 85+FOOL_B;
                        rcRect.top    = 1241+Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2);
                        rcRect.bottom = 1241+Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2)+FOOL_H;
                    }
                    if(Szenario.Info.FoolInfo[i].Richtung == WALK_UP)
                    {
                        rcRect.left   = 85;
                        rcRect.right  = 85+FOOL_B;
                        rcRect.top    = 1551+Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2);
                        rcRect.bottom = 1551+Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2)+FOOL_H;
                    }
                    if(Szenario.Info.FoolInfo[i].Richtung == WALK_RIGHT)
                    {
                        rcRect.left   = 85;
                        rcRect.right  = 85+FOOL_B;
                        rcRect.top    = 1861+Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2);
                        rcRect.bottom = 1861+Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2)+FOOL_H;
                    }
                    if(Szenario.Info.FoolInfo[i].Richtung == WALK_DOWN)
                    {
                        rcRect.left   = 85;
                        rcRect.right  = 85+FOOL_B;
                        rcRect.top    = 2171+Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2);
                        rcRect.bottom = 2171+Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2)+FOOL_H;
                    }
                break;

                case JUMPING:
                    if(Szenario.Info.FoolInfo[i].Richtung == WALK_LEFT)
                    {
                        rcRect.left   = 85;
                        rcRect.right  = 85+FOOL_B;
                        rcRect.top    = 1241+Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2);
                        rcRect.bottom = 1241+Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2)+FOOL_H;
                    }
                    if(Szenario.Info.FoolInfo[i].Richtung == WALK_UP)
                    {
                        rcRect.left   = 85;
                        rcRect.right  = 85+FOOL_B;
                        rcRect.top    = 1551+Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2);
                        rcRect.bottom = 1551+Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2)+FOOL_H;
                    }
                    if(Szenario.Info.FoolInfo[i].Richtung == WALK_RIGHT)
                    {
                        rcRect.left   = 85;
                        rcRect.right  = 85+FOOL_B;
                        rcRect.top    = 1861+Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2);
                        rcRect.bottom = 1861+Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2)+FOOL_H;
                    }
                    if(Szenario.Info.FoolInfo[i].Richtung == WALK_DOWN)
                    {
                        rcRect.left   = 85;
                        rcRect.right  = 85+FOOL_B;
                        rcRect.top    = 2171+Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2);
                        rcRect.bottom = 2171+Szenario.Info.FoolInfo[i].AnimationStep*(FOOL_H+2)+FOOL_H;
                    }
                break;
            }
        }
        Picture->BltFast(x-5, y, FoolAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
    }
End:
    if(Think == NO)
    	return;
    if(Szenario.Info.FoolInfo[i].Befehl != NO_COMMAND || Szenario.Info.FoolInfo[i].LastWalk == YES ||
       Szenario.Info.FoolInfo[i].Animation == SILLY_LEFT || Szenario.Info.FoolInfo[i].Animation == SILLY_RIGHT ||
       Szenario.Info.FoolInfo[i].Animation == SILLY_UP || Szenario.Info.FoolInfo[i].Animation == SILLY_DOWN)
    {
        rcRect.left   = 61;
        rcRect.top    = 1+(Szenario.Info.FoolInfo[i].ThinkShowStep*21);
        rcRect.right  = 90;
        rcRect.bottom = 1+(Szenario.Info.FoolInfo[i].ThinkShowStep*21)+20;
        Picture->BltFast(x+5, y-15, FoolSelectedPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        Szenario.Info.FoolInfo[i].ThinkShowStep++;
        if(Szenario.Info.FoolInfo[i].ThinkShowStep > 9)
            Szenario.Info.FoolInfo[i].ThinkShowStep = 0;
        if(Szenario.Info.FoolInfo[i].Animation == SILLY_LEFT || Szenario.Info.FoolInfo[i].Animation == SILLY_RIGHT ||
            Szenario.Info.FoolInfo[i].Animation == SILLY_UP || Szenario.Info.FoolInfo[i].Animation == SILLY_DOWN)
        {
		    SetRect(&rcRect, 60, 232, 90, 252);
        }
        else
        {
            if(Szenario.Info.FoolInfo[i].LastWalk == YES)
			    SetRect(&rcRect, 60, 211, 90, 231);
            else
            {
                if(Szenario.Info.FoolInfo[i].Befehl == COMMAND_WAIT)
				    SetRect(&rcRect, 60, 253, 90, 273);
                else
                {
                    if(Szenario.Info.FoolInfo[i].Befehl == COMMAND_JUMP)
                        SetRect(&rcRect, 60, 274, 90, 294);
                    else
                    {
                        rcRect.left   = 92;
                        rcRect.top    = 1+(Szenario.Info.FoolInfo[i].Befehl*21);
                        rcRect.right  = 120;
                        rcRect.bottom = 1+(Szenario.Info.FoolInfo[i].Befehl*21)+20;
					}
                }
            }
        }
        Picture->BltFast(x+5, y-15, FoolSelectedPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        if(Szenario.Info.FoolInfo[i].Befehl == COMMAND_WAIT)
        {
            sprintf(temp, "%d", Szenario.Info.FoolInfo[i].AnimationTurn);
            PrintText(x+15, y-15,  temp, 1, 0, 1000, 1000, Picture);
        }
    }
} /* DrawAnimatedFool */

void DrawPacMan(int KachelX, int KachelY)
{
    RECT rcRect;
    int i, x, y, XPersPixel;
    char temp[50];

    // Setzt einen PacMan auf die Spielfl�che:
    if(Szenario.Info.Kachel[Szenario.PosInfo[KachelX][KachelY]].Besetzt != NO_AKTIV && Szenario.Info.Kachel[Szenario.PosInfo[KachelX][KachelY]].Besetzt > FIRST_PACMAN-1 && Szenario.Info.Kachel[Szenario.PosInfo[KachelX][KachelY]].Besetzt < FIRST_PACMAN+MAX_PACMAN)
    {
        i = Szenario.Info.Kachel[Szenario.PosInfo[KachelX][KachelY]].Besetzt-FIRST_PACMAN;
        x = Szenario.Info.PacManInfo[i].PosX;
        y = Szenario.Info.PacManInfo[i].PosY;
        XPersPixel = 0;
		if(Szenario.Info.PacManInfo[i].Richtung == WALK_UP)
        {
            XPersPixel = Szenario.Info.PacManInfo[i].PixelPosY;
            if(XPersPixel < 0)
            {
                XPersPixel = XPersPixel*(-1);
                XPersPixel = XKachelPers[XPersPixel]*(-1);
            }
            else
                XPersPixel = XKachelPers[XPersPixel];
            XPersPixel -= 7;
		}
		if(Szenario.Info.PacManInfo[i].Richtung == WALK_DOWN)
        {
            if(Szenario.Info.PacManInfo[i].PixelPosY > -1)
	            XPersPixel = 0;
            else
            {
                XPersPixel = Szenario.Info.PacManInfo[i].PixelPosY;
                if(XPersPixel < -1)
                {
                    XPersPixel = XPersPixel*(-1);
                    XPersPixel = XKachelPers[XPersPixel]*(-1);
                }
			}
		}
        DrawAnimatedPacMan(i, KACHEL_DISPLAY_X+5+Szenario.Info.PacManInfo[i].PixelPosX+XPersPixel-5, KACHEL_DISPLAY_Y+Szenario.Info.PacManInfo[i].PixelPosY-(PACMAN_H-KACHEL_H)-5, GameAusgabe);
        if(ProgrammSetup.ShowFoolPower == YES && Szenario.Info.PacManInfo[i].OnLive == YES)
        {
            SetRect(&rcRect, 46, 735, 83, 742);
            GameAusgabe->BltFast(KACHEL_DISPLAY_X+Szenario.Info.PacManInfo[i].PixelPosX-3, KACHEL_DISPLAY_Y+Szenario.Info.PacManInfo[i].PixelPosY-(PACMAN_H-KACHEL_H)-8, GameListPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
            SetRect(&rcRect, 46, 743, 46+(Szenario.Info.PacManInfo[i].Power/2), 748);
            GameAusgabe->BltFast(KACHEL_DISPLAY_X+Szenario.Info.PacManInfo[i].PixelPosX-2, KACHEL_DISPLAY_Y+Szenario.Info.PacManInfo[i].PixelPosY-(PACMAN_H-KACHEL_H)-7, GameListPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        }
        if(ProgrammSetup.ShowFoolName == YES)
        {
	        sprintf(temp, "%s", Szenario.Info.PacManInfo[i].PacManName);
	        PrintText(KACHEL_DISPLAY_X+5+Szenario.Info.PacManInfo[i].PixelPosX+Szenario.Kachel[Szenario.PosInfo[KachelX][KachelY]][KACHEL_PIXEL_X], KACHEL_DISPLAY_Y+Szenario.Info.PacManInfo[i].PixelPosY-(PACMAN_H-KACHEL_H)+Szenario.Kachel[Szenario.PosInfo[KachelX][KachelY]][KACHEL_PIXEL_Y]+5,  temp, 1, 0, 1000, 1000, GameAusgabe);
        }
    }
} /* DrawPacMan */

void DrawAnimatedPacMan(int i, int x, int y, LPDIRECTDRAWSURFACE Picture)
{
    RECT rcRect;

    if(Szenario.Info.PacManInfo[i].Animation == NOW_DIED)
    {
        if(Szenario.Info.PacManInfo[i].AnimationStep < 9)
        {
            rcRect.left   = 1+(Szenario.Info.PacManInfo[i].Richtung*(PACMAN_B+2));
            rcRect.top    = 1;
            rcRect.right  = 1+(Szenario.Info.PacManInfo[i].Richtung*(PACMAN_B+2))+PACMAN_B;
            rcRect.bottom = 1+PACMAN_H;
            Picture->BltFast(x-5, y, FoolAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        }
        rcRect.left   = 44;
        rcRect.top    = 1241+(Szenario.Info.PacManInfo[i].AnimationStep*(PACMAN_H+2));
        rcRect.right  = 44+PACMAN_B;
        rcRect.bottom = 1241+(Szenario.Info.PacManInfo[i].AnimationStep*(PACMAN_H+2))+PACMAN_H;
        Picture->BltFast(x-5, y, PacManAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        goto End;
    }
    if(Szenario.Info.PacManInfo[i].Animation == BEAMING_START)
    {
        if(Szenario.Info.PacManInfo[i].AnimationStep < 9)
        {
            rcRect.left   = 1+(Szenario.Info.PacManInfo[i].Richtung*(PACMAN_B+2));
            rcRect.top    = 1;
            rcRect.right  = 1+(Szenario.Info.PacManInfo[i].Richtung*(PACMAN_B+2))+PACMAN_B;
            rcRect.bottom = 1+PACMAN_H;
            Picture->BltFast(x-5, y, PacManAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        }
        rcRect.left   = 127;
        rcRect.top    = 1241+(Szenario.Info.PacManInfo[i].AnimationStep*(PACMAN_H+2));
        rcRect.right  = 168;
        rcRect.bottom = 1241+(Szenario.Info.PacManInfo[i].AnimationStep*(PACMAN_H+2))+PACMAN_H;
        Picture->BltFast(x-5, y, FoolAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        goto End;
    }
    if(Szenario.Info.PacManInfo[i].Animation == BEAMING_END)
    {
        if(Szenario.Info.PacManInfo[i].AnimationStep > 9)
        {
            rcRect.left   = 1+(Szenario.Info.PacManInfo[i].Richtung*(PACMAN_B+2));
            rcRect.top    = 1;
            rcRect.right  = 1+(Szenario.Info.PacManInfo[i].Richtung*(PACMAN_B+2))+PACMAN_B;
            rcRect.bottom = 1+PACMAN_H;
            Picture->BltFast(x-5, y, PacManAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        }
        rcRect.left   = 127;
        rcRect.top    = 1241+(Szenario.Info.PacManInfo[i].AnimationStep*(PACMAN_H+2));
        rcRect.right  = 168;
        rcRect.bottom = 1241+(Szenario.Info.PacManInfo[i].AnimationStep*(PACMAN_H+2))+PACMAN_H;
        Picture->BltFast(x-5, y, PacManAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        goto End;
    }
    if(Szenario.Info.PacManInfo[i].Animation == ON_FINISH)
    {
        rcRect.left   = 169;
        rcRect.top    = 1241+(Szenario.Info.PacManInfo[i].AnimationStep*(PACMAN_H+2));
        rcRect.right  = 210;
        rcRect.bottom = 1241+(Szenario.Info.PacManInfo[i].AnimationStep*(PACMAN_H+2))+PACMAN_H;
        Picture->BltFast(x-5, y, PacManAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        goto End;
    }
    if(Szenario.Info.PacManInfo[i].Animation == WRONG_EXIT_PAGE)
    {
        rcRect.left   = 589;
        rcRect.top    = 1+(Szenario.Info.PacManInfo[i].AnimationStep*(PACMAN_H+2));
        rcRect.right  = 630;
        rcRect.bottom = 1+(Szenario.Info.PacManInfo[i].AnimationStep*(PACMAN_H+2))+PACMAN_H;
        Picture->BltFast(x-5, y, PacManAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        goto End;
    }
    if(Szenario.Info.PacManInfo[i].OnLive == NO || Szenario.Info.PacManInfo[i].PacMan_ID == NO_AKTIV)
        return;
    if(Szenario.Info.PacManInfo[i].Richtung == Szenario.Info.PacManInfo[i].Animation)
    {
        rcRect.left   = Szenario.Info.PacManInfo[i].AnimationStep*(PACMAN_B+2)+1;
        rcRect.top    = Szenario.Info.PacManInfo[i].Animation*(PACMAN_H+2)+1;
        rcRect.right  = Szenario.Info.PacManInfo[i].AnimationStep*(PACMAN_B+2)+1+PACMAN_B;
        rcRect.bottom = Szenario.Info.PacManInfo[i].Animation*(PACMAN_H+2)+1+PACMAN_H;
    }
    Picture->BltFast(x-5, y, PacManAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
End:
} /* DrawAnimatedPacMan */


///////////////////////////////////////////////////////////////////////////////////////////////////////////
void DrawGegner(int KachelX, int KachelY)
{
    int i, x, y, XPersPixel;

    // Setzt einen Fool auf die Spielfl�che:
    if(Szenario.Info.Kachel[Szenario.PosInfo[KachelX][KachelY]].Besetzt != NO_AKTIV && Szenario.Info.Kachel[Szenario.PosInfo[KachelX][KachelY]].Besetzt > MAX_FOOLS-1)
    {
        i = Szenario.Info.Kachel[Szenario.PosInfo[KachelX][KachelY]].Besetzt-MAX_FOOLS;
        x = Szenario.Info.GegnerInfo[i].PosX;
        y = Szenario.Info.GegnerInfo[i].PosY;
        XPersPixel = 0;
		if(Szenario.Info.GegnerInfo[i].Richtung == WALK_UP)
        {
            XPersPixel = Szenario.Info.GegnerInfo[i].PixelPosY;
            if(XPersPixel < 0)
            {
                XPersPixel = XPersPixel*(-1);
                XPersPixel = XKachelPers[XPersPixel]*(-1);
            }
            else
                XPersPixel = XKachelPers[XPersPixel];
            XPersPixel -= 7;
		}
		if(Szenario.Info.GegnerInfo[i].Richtung == WALK_DOWN)
        {
            if(Szenario.Info.GegnerInfo[i].PixelPosY > -1)
	            XPersPixel = 0;
            else
            {
                XPersPixel = Szenario.Info.GegnerInfo[i].PixelPosY;
                if(XPersPixel < -1)
                {
                    XPersPixel = XPersPixel*(-1);
                    XPersPixel = XKachelPers[XPersPixel]*(-1);
                }
			}
            XPersPixel += 10;
		}
        DrawAnimatedGegner(i, KACHEL_DISPLAY_X+5+Szenario.Info.GegnerInfo[i].PixelPosX+XPersPixel, KACHEL_DISPLAY_Y+Szenario.Info.GegnerInfo[i].PixelPosY, GameAusgabe);
    }
} /* DrawGegner */

void DrawAnimatedGegner(int i, int x, int y, LPDIRECTDRAWSURFACE Picture)
{
    RECT rcRect;

    if(Szenario.Info.GegnerInfo[i].Typ == GEGNER_DROHNE)
    {
	    if(Szenario.Info.GegnerInfo[i].Animation == NOW_DIED)
    	{
	        if(Szenario.Info.GegnerInfo[i].AnimationStep < 9)
    	    {
                rcRect.left   = 1;
                rcRect.top    = 1;
                rcRect.right  = 32;
                rcRect.bottom = 42;
                Picture->BltFast(x-5, y-20, GegnerAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
            }
            rcRect.left   = 44;
            rcRect.top    = 1241+(Szenario.Info.GegnerInfo[i].AnimationStep*(FOOL_H+2));
            rcRect.right  = 44+FOOL_B;
            rcRect.bottom = 1241+(Szenario.Info.GegnerInfo[i].AnimationStep*(FOOL_H+2))+FOOL_H;
            Picture->BltFast(x-5, y-30, FoolAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        	return;
	    }
        rcRect.left   = 1+(Szenario.Info.GegnerInfo[i].AnimationStep*34);
        rcRect.top    = 1;
        rcRect.right  = 1+(Szenario.Info.GegnerInfo[i].AnimationStep*34)+32;
        rcRect.bottom = 42;
        Picture->BltFast(x-5, y-20, GegnerAniPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        if(ProgrammSetup.ShowFoolPower == YES)
        {
            SetRect(&rcRect, 46, 735, 83, 742);
            Picture->BltFast(x-3, y-30, GameListPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
            SetRect(&rcRect, 46, 743, 46+(Szenario.Info.GegnerInfo[i].Power/2), 748);
            Picture->BltFast(x-2, y-29, GameListPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        }
	}
} /* DrawAnimatedGegner */

// Malt die Bodenflie�en:
void DrawKachelFloorPic(int i, int x, int y, LPDIRECTDRAWSURFACE Picture)
{
    RECT rcRect;

    if(i < 0)
    	return;
    if((Szenario.Info.Kachel[i].Pic > FLOOR-1 && Szenario.Info.Kachel[i].Pic < FLOOR_ANI-1) ||
        (Szenario.Info.Kachel[i].Pic > DEADLY_WALKS-1 && Szenario.Info.Kachel[i].Pic < DEADLY_WALKS_ANI-1))
    {
        rcRect.left   = Szenario.FloorPicPos[Szenario.Info.Kachel[i].Pic][0];
        rcRect.top    = Szenario.FloorPicPos[Szenario.Info.Kachel[i].Pic][1];
        rcRect.right  = Szenario.FloorPicPos[Szenario.Info.Kachel[i].Pic][0]+KACHEL_B;
        rcRect.bottom  = Szenario.FloorPicPos[Szenario.Info.Kachel[i].Pic][1]+KACHEL_H;
        goto Draw;
    }
    if(Szenario.Info.Kachel[i].Pic > FLOOR_ANI-1 && Szenario.Info.Kachel[i].Pic < DEADLY_WALKS-1)
    {
        rcRect.left   = 1+Szenario.Info.Kachel[i].PicAniStep*(KACHEL_B+1);
        rcRect.top    = 463+(Szenario.Info.Kachel[i].Pic-FLOOR_ANI)*(KACHEL_H+1);
        rcRect.right  = 1+Szenario.Info.Kachel[i].PicAniStep*(KACHEL_B+1)+KACHEL_B;
        rcRect.bottom = 463+(Szenario.Info.Kachel[i].Pic-FLOOR_ANI)*(KACHEL_H+1)+KACHEL_H;
        goto Draw;
    }
    if(Szenario.Info.Kachel[i].Pic > DEADLY_WALKS_ANI-1 && Szenario.Info.Kachel[i].Pic < WALLS-1)
    {
        rcRect.left   = 1+Szenario.Info.Kachel[i].PicAniStep*(KACHEL_B+1);
        rcRect.top    = 1387+(Szenario.Info.Kachel[i].Pic-DEADLY_WALKS_ANI)*(KACHEL_H+1);
        rcRect.right  = 1+Szenario.Info.Kachel[i].PicAniStep*(KACHEL_B+1)+KACHEL_B;
        rcRect.bottom = 1387+(Szenario.Info.Kachel[i].Pic-DEADLY_WALKS_ANI)*(KACHEL_H+1)+KACHEL_H;
    }
Draw:
    Picture->BltFast(x, y, Szenario.FloorLevelPic, &rcRect, FALSE);
    if(Szenario.Info.Kachel[i].LeftOverlay != NO_AKTIV)
    {
        int x2, x3, y2, i2;

        for(y2 = 1, i2 = 0; ; y2 += KACHEL_H+1)
        	for(x2 = 628, x3 = 0; x3 < 2; x2 += 6, x3++, i2++)
            {
            	if(i2 == Szenario.Info.Kachel[i].LeftOverlay)
                	goto Finish;
            }
    Finish:
        rcRect.left   = x2;
        rcRect.top    = y2;
        rcRect.right  = x2+6;
        rcRect.bottom = y2+KACHEL_H;
	    Picture->BltFast(x-6, y, Szenario.FloorLevelPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
    }
    if(Szenario.Info.Kachel[i].UpOverlay != NO_AKTIV)
    {
        int x2, x3, y2, i2;

        for(y2 = 1849, i2 = 0; ; y2 += 6)
        	for(x2 = 1, x3 = 0; x3 < 6; x2 += KACHEL_B+7, x3++, i2++)
            {
            	if(i2 == Szenario.Info.Kachel[i].UpOverlay)
                	goto Finish2;
            }
    Finish2:
        rcRect.left   = x2;
        rcRect.top    = y2;
        rcRect.right  = x2+KACHEL_B+6;
        rcRect.bottom = y2+6;
	    Picture->BltFast(x-6, y-6, Szenario.FloorLevelPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
    }
} /* DrawKachelFloorPic */

// Zeichnet �ber die Kacheln Masken:
void DrawKachelMasksPic(int i, int x, int y, LPDIRECTDRAWSURFACE Picture)
{
    RECT rcRect;

    if(i == NO_AKTIV || i < 0)
		return;
    if(i >= FIRST_INSTABIL &&
        i <= LAST_INSTABIL)
    {
        rcRect.left   = 1+i*45;
        rcRect.top    = 1;
        rcRect.right  = 1+i*45+44;
        rcRect.bottom = 1+KACHEL_H+KACHEL_OVERLAY;
        Picture->BltFast(x, y, Szenario.MasksLevelPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        return;
    }
    if(i == ATOMIK)
    {
        SetRect(&rcRect, 451, 1, 495, 37);
        Picture->BltFast(x, y, Szenario.MasksLevelPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        return;
    }
    if(i == GESUND)
    {
        SetRect(&rcRect, 586, 1, 630, 37);
        Picture->BltFast(x, y, Szenario.MasksLevelPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        return;
    }
    if(i == BEAMER)
    {
        SetRect(&rcRect, 541, 1, 585, 37);
        Picture->BltFast(x, y, Szenario.MasksLevelPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        return;
    }
    if(i == TAXI_KACHEL)
    {
        SetRect(&rcRect, 1, 75, 45, 111);
        Picture->BltFast(x, y, Szenario.MasksLevelPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        return;
    }
    if(i == TAXI_KACHEL_SCHALTER)
    {
        SetRect(&rcRect, 496, 1, 540, 37);
        Picture->BltFast(x, y, Szenario.MasksLevelPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        return;
    }
    if(i >= FIRST_MOVE_MASK &&
        i <= FIRST_MOVE_MASK+MAX_MOVE_MASK)
    {
        rcRect.left   = 1+(i-FIRST_MOVE_MASK)*(KACHEL_B+5);
        rcRect.top    = 38;
        rcRect.right  = 1+(i-FIRST_MOVE_MASK)*(KACHEL_B+5)+KACHEL_B+KACHEL_OVERLAY+KACHEL_OVERLAY;
        rcRect.bottom = 74;
        Picture->BltFast(x-KACHEL_OVERLAY, y-KACHEL_OVERLAY, Szenario.MasksLevelPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        return;
    }
} /* DrawKachelMasksPic */

// Zeichnet Gegenst�nde �ber die Kachel:
void DrawKachelIntemPic(int i, int x, int y, LPDIRECTDRAWSURFACE Picture)
{
    RECT rcRect;

    if(i == NO_AKTIV || i < 0)
	    return;
    rcRect.left   = Szenario.FloorPicPos[i][0];
    rcRect.top    = Szenario.FloorPicPos[i][1];
    rcRect.right  = Szenario.FloorPicPos[i][0]+KACHEL_B;
    rcRect.bottom  = Szenario.FloorPicPos[i][1]+KACHEL_H;
    Picture->BltFast(x, y, Szenario.IntemsLevelPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
} /* DrawKachelIntemPic */

// Zeichnet einen Wand Ausschnitt: // NO_AKTIV = Beides Zeichnen!!
void DrawKachelWallPic(int i, int x, int y, LPDIRECTDRAWSURFACE Picture, int Trans)
{
    RECT rcRect;

    if(Szenario.Info.Kachel[i].WallPic == NO_AKTIV || i < 0)
    {
		if(Szenario.Info.Kachel[i].WallPicAniStepTurn == PUNKT && Trans == PUNKT)
        {
	        SetRect(&rcRect, 1+Szenario.Info.Kachel[i].WallPicAniStep*27, 1, 1+Szenario.Info.Kachel[i].WallPicAniStep*27+26, 27);
            Picture->BltFast(x-3, y+2, Szenario.PunktLevelPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        }
    	return;
    }
    if(Szenario.Info.Kachel[i].Mask == TAXI_KACHEL_SCHALTER ||
	    Szenario.Info.Kachel[i].Mask == BEAMER || Trans == PUNKT)
    	return;
    if(Szenario.Info.Kachel[i].WallPic == SPECIAL_EXIT)
    {
        rcRect.left   = 1;
        rcRect.top    = 1+(Szenario.Info.Kachel[i].WallPicAniStep*132);
        rcRect.right  = 119;
        rcRect.bottom = 1+(Szenario.Info.Kachel[i].WallPicAniStep*132)+131;
        Picture->BltFast(x-KACHEL_B, y-70, Szenario.SpecialLevelPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
		return;
    }
	if(Szenario.Info.Kachel[i].WallPic == SPECIAL_EXIT_OVERLAY)
    	return;
  // Eine normale oder animirte Wand wird gemalt:
    if((Szenario.Info.Kachel[i].WallPic > WALLS-1 && Szenario.Info.Kachel[i].WallPic < MOVE_WALLS-1))
    {
        if(Szenario.Info.Kachel[i].WallPic > WALL_ANI-1)
        {
            rcRect.left   = Szenario.Info.Kachel[i].WallPicAniStep*(WALL_B+1)+1;
            rcRect.top    = (Szenario.Info.Kachel[i].WallPic-WALL_ANI)*(WALL_H+1)+1+Trans;
            rcRect.right  = Szenario.Info.Kachel[i].WallPicAniStep*(WALL_B+1)+WALL_B+1;
            rcRect.bottom = (Szenario.Info.Kachel[i].WallPic-WALL_ANI)*(WALL_H+1)+WALL_H+1;
            Picture->BltFast(x, y,  Szenario.WallAniLevelPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
            return;
        }
        else
        {
            rcRect.left   = Szenario.WallPicPos[Szenario.Info.Kachel[i].WallPic-WALLS][0];
            rcRect.top    = Szenario.WallPicPos[Szenario.Info.Kachel[i].WallPic-WALLS][1]+Trans;
            rcRect.right  = Szenario.WallPicPos[Szenario.Info.Kachel[i].WallPic-WALLS][0]+WALL_B;
            rcRect.bottom = Szenario.WallPicPos[Szenario.Info.Kachel[i].WallPic-WALLS][1]+WALL_H;
            Picture->BltFast(x, y,  Szenario.WallLevelPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
            return;
        }
    }
  // Ein verschiebbares Object wird gemalt:
    if(Szenario.Info.Kachel[i].WallPic > MOVE_WALLS-1 && Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPic < FIRST_OBJECT)
    {
        rcRect.left   = Szenario.WallPicPos[Szenario.Info.Kachel[i].WallPic-MOVE_WALLS][0];
        rcRect.top    = Szenario.WallPicPos[Szenario.Info.Kachel[i].WallPic-MOVE_WALLS][1]+Trans;
        rcRect.right  = Szenario.WallPicPos[Szenario.Info.Kachel[i].WallPic-MOVE_WALLS][0]+WALL_B;
        rcRect.bottom = Szenario.WallPicPos[Szenario.Info.Kachel[i].WallPic-MOVE_WALLS][1]+WALL_H;
        Picture->BltFast(x+Szenario.Kachel[i][KACHEL_PIXEL_X], y+Szenario.Kachel[i][KACHEL_PIXEL_Y], Szenario.MoveWallLevelPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        return;
    }
    if(Szenario.Info.Kachel[i].WallPic > FIRST_OBJECT-1 && Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPic < DOOR_ANI-1)
    {
        rcRect.left   = Szenario.WallPicPos[Szenario.Info.Kachel[i].WallPic-FIRST_OBJECT][0];
        rcRect.top    = Szenario.WallPicPos[Szenario.Info.Kachel[i].WallPic-FIRST_OBJECT][1]+Trans;
        rcRect.right  = Szenario.WallPicPos[Szenario.Info.Kachel[i].WallPic-FIRST_OBJECT][0]+WALL_B;
        rcRect.bottom = Szenario.WallPicPos[Szenario.Info.Kachel[i].WallPic-FIRST_OBJECT][1]+WALL_H;
        Picture->BltFast(x, y, Szenario.ObjectsLevelPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        return;
    }
    if(Szenario.Info.Kachel[i].WallPic > DOOR_ANI-1 && Szenario.Info.Kachel[i].WallPic < SPECIAL_EXIT)
    {
        rcRect.left   = Szenario.Info.Kachel[i].WallPicAniStep*(WALL_B+1)+1;
        rcRect.top    = (Szenario.Info.Kachel[i].WallPic-DOOR_ANI)*(WALL_H+1)+1+Trans;
        rcRect.right  = Szenario.Info.Kachel[i].WallPicAniStep*(WALL_B+1)+WALL_B+1;
        rcRect.bottom = (Szenario.Info.Kachel[i].WallPic-DOOR_ANI)*(WALL_H+1)+WALL_H+1;
        Picture->BltFast(x, y, Szenario.DoorAniLevelPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        return;
    }
} /* DrawKachelWallPic */

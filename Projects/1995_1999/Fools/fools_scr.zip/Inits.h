extern struct BB_MESSAGE BB_Message;
extern struct BB_MESSAGE BB_SmallMessage;
extern void RecordDemo(int);

#define TIMER_ID 1
#define TIMER_RATE 100

int doInit(HINSTANCE, int);
long FAR PASCAL CheckKeys(HWND, UINT, WPARAM, LPARAM);
void NormalKeyCheck(WPARAM);
int SetScreenRes(void);

extern void RunPlayTime(void);

char LastLetterKey;

HWND            hwnd;
BOOL gExclusive = FALSE;
HANDLE    hMutex = 0;
int TimerNew = NO;
int TimerNew2 = NO;
int TimerNewAktiv = 0;
int CommandAnimatetTimer;
int CommandAnimatetTimerT;

int ExitModule; // Wenn zwischen den verschiedenen Programmteitel gewechselt wird
int ExitProgramm; // Soll das Programm beendet werden?

LPDIRECTDRAW            lpDD;
LPDIRECTDRAWSURFACE     Primary;   // DirectDraw primary surface
LPDIRECTDRAWSURFACE     Back;      // DirectDraw back surface
LPDIRECTDRAWPALETTE     lpDDPal;        // DirectDraw palette
BOOL                    bActive;        // is application active?

int ScreenRes[3];

long Test;

extern int ResAreaX, ResAreaY;

int doInit(HINSTANCE hInstance, int nCmdShow)
{
    HWND                hwnd;
    WNDCLASS            wc;
    HRESULT             ddrval;
    HRESULT result;

  ////////////////////////////////////////////////////
    // Diese Zeilen verhindern, dass das Spiel gleichzeitg zweimal l�uft
    hMutex = OpenMutex(SYNCHRONIZE, FALSE, MUTEX_NAME);
    if (hMutex != 0)
    {
        CloseHandle(hMutex);
        MessageBox(0, "Fools l�uft schon!!", "Fools", MB_ICONERROR | MB_OK);
        return(FALSE);
    }
    else
        hMutex = CreateMutex(NULL, TRUE, MUTEX_NAME);
  ////////////////////////////////////////////////////
	CheckKeyModule = NormalKeyCheck;
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = CheckKeys;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = hInstance;
    wc.hIcon = LoadIcon( hInstance, "Fools.ico");
    wc.hCursor = LoadCursor( NULL, IDC_ARROW );
    wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wc.lpszMenuName = NAME;
    wc.lpszClassName = NAME;
    RegisterClass( &wc );

    hwnd = CreateWindowEx(
        WS_EX_APPWINDOW,
        NAME,
        TITLE,
        WS_POPUP | WS_SYSMENU,
        0,
        0,
        GetSystemMetrics(SM_CXSCREEN),
        GetSystemMetrics(SM_CYSCREEN),
        NULL,
        NULL,
        hInstance,
        NULL );
    if(!hwnd)
    {
        MessageBox(0, "Das Fools Fenster konnte nicht erstellt werden!!", "Fools", MB_ICONERROR | MB_OK);
    	return FALSE;
    }
    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    result = DirectDrawCreate(NULL, &lpDD, NULL);
    if(result != DD_OK)
    {
        MessageBox(0, "DirectDraw konnte nicht aufgerufen werden!!", "Fools", MB_ICONERROR | MB_OK);
    	return FALSE;
    }
    ddrval = lpDD->SetCooperativeLevel( hwnd, DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN );
    if(ddrval != DD_OK)
    {
        MessageBox(0, "Fools konnte nicht auf Vollbild umgestellt werden!!", "Fools", MB_ICONERROR | MB_OK);
        return FALSE;
    }
    SetScreenRes();
    SetTimer(hwnd, TIMER_ID, TIMER_RATE, NULL);
	GameInfo.AnimatetCommand = 0;
	GameInfo.AnimatetCommandOn = YES;
	CommandAnimatetTimer = 0;
	CommandAnimatetTimerT = 0;
    return TRUE;
} /* doInit */

int SetScreenRes(void)
{
    char temp[50];
    DDSURFACEDESC       ddsd;
    DDSCAPS ddscaps;
    HRESULT result;

    switch(ProgrammSetup.ScreenResNr)
    {
    	case 0:
		    result = lpDD->SetDisplayMode(640, 480, 8);
	        ScreenRes[0] = 640-1;
	        ScreenRes[1] = 480-1;
	        ScreenRes[2] = 8;
            ResAreaX = 20;
            ResAreaY = 16;
        break;

    	case 1:
		    result = lpDD->SetDisplayMode(800, 600, 8);
	        ScreenRes[0] = 800-1;
	        ScreenRes[1] = 600-1;
	        ScreenRes[2] = 8;
            ResAreaX = 30;
            ResAreaY = 25;
        break;

    	case 2:
		    result = lpDD->SetDisplayMode(1024, 768, 8);
	        ScreenRes[0] = 1024-1;
	        ScreenRes[1] = 768-1;
	        ScreenRes[2] = 8;
            ResAreaX = 40;
            ResAreaY = 35;
        break;

        default:
		    result = lpDD->SetDisplayMode(640, 480, 8);
	        ScreenRes[0] = 640-1;
	        ScreenRes[1] = 480-1;
	        ScreenRes[2] = 8;
            ResAreaX = 20;
            ResAreaY = 16;
        break;
    }
    if(result != DD_OK)
    {
        sprintf(temp, "Die aufl�sung konnte nicht auf %dx%dx%d gestellt werden!!", ScreenRes[0]+1, ScreenRes[1]+1, ScreenRes[2]);
        MessageBox(0, temp, "Fools", MB_ICONERROR | MB_OK);
        return FALSE;
    }
    // Create the primary surface with 1 back buffer
    ddsd.dwSize = sizeof( ddsd );
    ddsd.dwFlags = DDSD_CAPS | DDSD_BACKBUFFERCOUNT;
    ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE |
                          DDSCAPS_FLIP |
                          DDSCAPS_COMPLEX;
    ddsd.dwBackBufferCount = 2;
    result = lpDD->CreateSurface( &ddsd, &Primary, NULL );
    if(result != DD_OK)
        return FALSE;
    ddscaps.dwCaps = DDSCAPS_BACKBUFFER;
    result = Primary->GetAttachedSurface(&ddscaps, &Back);
    if(result != DD_OK)
        return FALSE;
    lpDDPal = DDLoadPalette(lpDD, "Bilder/Commands.bmp");
    Primary->SetPalette(lpDDPal);
    return TRUE;
} /* SetScreenRes */

long FAR PASCAL CheckKeys(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    hwnd = hWnd;
    switch(message)
    {
        case WM_LBUTTONDOWN:
        case WM_LBUTTONUP:
        case WM_RBUTTONDOWN:
        case WM_RBUTTONUP:
        case WM_MOUSEMOVE:
            if(GameInfo.PlayDemo == YES)
                break;
            Mouse.Button = wParam;
            Mouse.VorLastXPos = Mouse.LastXPos;
            Mouse.VorLastYPos = Mouse.LastYPos;
            Mouse.LastXPos = Mouse.XPos;
            Mouse.LastYPos = Mouse.YPos;
            Mouse.XPos = LOWORD(lParam);
            Mouse.YPos = HIWORD(lParam);
            if(Mouse.XPos < Mouse.BoundX)
            	Mouse.XPos = Mouse.BoundX;
            if(Mouse.YPos < Mouse.BoundY)
            	Mouse.YPos = Mouse.BoundY;
            if(Mouse.XPos > Mouse.BoundXB)
            	Mouse.XPos = Mouse.BoundXB;
            if(Mouse.YPos > Mouse.BoundYH)
            	Mouse.YPos = Mouse.BoundYH;
           	RecordDemo(NO);
        break;

        case WM_ACTIVATEAPP:
            bActive = wParam;
        break;

        case WM_SETCURSOR:
            SetCursor(NULL);
        return TRUE;

        case WM_PALETTECHANGED:
            if ((HWND)wParam == hWnd)
        	    break;

        case WM_QUERYNEWPALETTE:
            if (lpDDPal)
            {
                Primary->SetPalette(lpDDPal);
            }
        break;

        case WM_CREATE:
        break;

        case WM_KEYDOWN:
            LastLetterKey = wParam;
            switch(wParam)
            {
                case VK_F8:
                    if(ProgrammSetup.ShowFps == YES)
                        ProgrammSetup.ShowFps = NO;
                    else
                        ProgrammSetup.ShowFps = YES;
                break;
            }
			CheckKeyModule(wParam);
        break;

        case WM_DESTROY:
            PostQuitMessage( 0 );
        break;

	    case WM_TIMER:
			CheckMouseAni();
		    GameInfo.MenuAni++;
		    if(GameInfo.MenuAni > 6)
	   		    GameInfo.MenuAni = 0;
			CommandAnimatetTimer++;
			CommandAnimatetTimerT++;
            if(CommandAnimatetTimerT > 4)
            {
				CommandAnimatetTimerT = 0;
	            if(GameInfo.AnimatetCommandOn == YES)
					GameInfo.AnimatetCommandOn = NO;
				else
                	GameInfo.AnimatetCommandOn = YES;
            }
            if(CommandAnimatetTimer > 15)
            {
				CommandAnimatetTimer = 0;
                if(GameInfo.Befehl != NO_COMMAND)
                {
                    switch(GameInfo.Befehl)
                    {
                        case COMMAND_WALK: case COMMAND_PUSH: case COMMAND_USE: case COMMAND_TAKE: case COMMAND_WAIT:
                            GameInfo.AnimatetCommand++;
                            if(GameInfo.AnimatetCommand > 3)
                                GameInfo.AnimatetCommand = 0;
                        break;

                        case COMMAND_DELETE:
                            GameInfo.AnimatetCommand = NO_COMMAND;
                        break;
                    }
                }
            }
           ///////
			TimerNewAktiv++;
            if(TimerNewAktiv == 4)
	        {
				TimerNewAktiv = 0;
                TimerNew = YES;
                TimerNew2 = YES;
			}
            if(BB_Message.On == YES)
            {
                BB_Message.Step++;
                if(BB_Message.Step > BB_Message.Time)
                {
                    BB_Message.On = NO;
                    BB_Message.Step = 0;
					BB_Message.Info = -1;
                    sprintf(BB_Message.Message, "");
                }
			}
            if(BB_SmallMessage.On == YES)
            {
                BB_SmallMessage.Step++;
                if(BB_SmallMessage.Step > BB_SmallMessage.Time)
                {
                    BB_SmallMessage.On = NO;
                    BB_SmallMessage.Step = 0;
					BB_SmallMessage.Info = -1;
                    sprintf(BB_SmallMessage.Message, "");
                }
			}
        break;
    }
    return DefWindowProc(hWnd, message, wParam, lParam);
} /* CheckKeyModule */

void NormalKeyCheck(WPARAM wParam)
{
    switch(wParam)
    {
        case VK_ESCAPE:
			ExitModule = YES;
        break;

        case VK_F12:
			ExitProgramm = YES;
        break;
    }
} /* NormalKeyCheck */





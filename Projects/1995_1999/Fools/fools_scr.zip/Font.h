#define MAX_FONTS 5
#define ZEICHEN_POS_X 0
#define ZEICHEN_POS_Y 1

//////////////////////////////////////////////////////////////////////////
void LoadFont(int, char *);
void DestroyFont(int);
void InitFontStruct(int, int, int);
void PrintText(int, int, char *, int, int, int, int, LPDIRECTDRAWSURFACE);
void PrintTextNo_Trans(int, int, char *, int, int, int, int, LPDIRECTDRAWSURFACE);
int Eingabe(char *, int, int);
//////////////////////////////////////////////////////////////////////////

struct FONT
{
    int MaxXZeichen, MaxYZeichen; // Maximale Zeichen pro Spalte...
    int FontB, FontH; // Die gr��e der Schrift
	LPDIRECTDRAWSURFACE FontPic; // Die Schriftart
};

struct FONT Font[MAX_FONTS];
//////////////////////////////////////////////////////////////////////////


void LoadFont(int FontNr, char* FontName)
{
    DDSURFACEDESC   ddsd;
	LPDIRECTDRAWSURFACE Pic;
    RECT rcRect;
    RECT rcRect2;

    Pic = DDLoadBitmap(lpDD, FontName, 0, 0, NO);
    ZeroMemory(&ddsd, sizeof(ddsd));
    ddsd.dwSize = sizeof(ddsd);
    ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH;
    ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_SYSTEMMEMORY;
    ddsd.dwWidth = Font[FontNr].FontB;
    ddsd.dwHeight = 105*Font[FontNr].FontH;
    if(lpDD->CreateSurface(&ddsd, &Font[FontNr].FontPic, NULL) != DD_OK)
        return;
    rcRect.left   = 0;
    rcRect.top    = 0;
    rcRect.right  = 30;
    rcRect.bottom = 102*30;
    rcRect2.left   = 0;
    rcRect2.top    = 0;
    rcRect2.right  = Font[FontNr].FontB;
    rcRect2.bottom = 102*Font[FontNr].FontH;
    Font[FontNr].FontPic->Blt(&rcRect2, Pic, &rcRect, NULL, NULL);
    DDSetColorKey(Font[FontNr].FontPic, 5);
//    Pic->Restore();
} /* LoadFont */

void DestroyFont(int FontNr)
{
    Font[FontNr].FontPic->Restore();
} /* LoadFont */

void InitFontStruct(int FontNr, int FontB, int FontH)
{
    Font[FontNr].FontB = FontB;
    Font[FontNr].FontH = FontH;
	Font[FontNr].MaxXZeichen = ScreenRes[0]/Font[FontNr].FontB;
	Font[FontNr].MaxYZeichen = ScreenRes[1]/Font[FontNr].FontH;
} /* InitFontStruct */

void PrintText(int PosX, int PosY, char *Text, int FontNr, int HAbstand, int MaxXZeichen, int MaxYZeichen, LPDIRECTDRAWSURFACE Picture)
{
    RECT rcRect;
    int Buchstaben, x, y, xPixel, yPixel, xSave, i;
    char SavedText[1000];
//    char *SavedText;

    Buchstaben = strlen(Text);
//	SavedText = (char *)malloc(Buchstaben);
	stpcpy(SavedText, Text);
    xSave = PosX/Font[FontNr].FontB;
    xPixel = PosX-(xSave*Font[FontNr].FontB);
    y = PosY/Font[FontNr].FontH;
    yPixel = PosY-(y*Font[FontNr].FontH);
    for(i = 0; y < MaxYZeichen; y++)
        for(x = xSave; x < MaxXZeichen; x++, i++)
        {
            if(i > Buchstaben-1)
            	goto EndPrintText;
            switch(SavedText[i])
            {
                case -4: // �
                    rcRect.left = 0;
                    rcRect.top = (96*Font[FontNr].FontH);
                    rcRect.right = Font[FontNr].FontB;
                    rcRect.bottom = (96*Font[FontNr].FontH)+Font[FontNr].FontH;
                    Picture->BltFast((x*Font[FontNr].FontB)+xPixel, (y*Font[FontNr].FontH)+yPixel+HAbstand, Font[FontNr].FontPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
                break;

                case -28: // �
                    rcRect.left = 0;
                    rcRect.top = (97*Font[FontNr].FontH);
                    rcRect.right = Font[FontNr].FontB;
                    rcRect.bottom = (97*Font[FontNr].FontH)+Font[FontNr].FontH;
                    Picture->BltFast((x*Font[FontNr].FontB)+xPixel, (y*Font[FontNr].FontH)+yPixel+HAbstand, Font[FontNr].FontPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
                break;

                case -60: // �
                    rcRect.left = 0;
                    rcRect.top = (98*Font[FontNr].FontH);
                    rcRect.right = Font[FontNr].FontB;
                    rcRect.bottom = (98*Font[FontNr].FontH)+Font[FontNr].FontH;
                    Picture->BltFast((x*Font[FontNr].FontB)+xPixel, (y*Font[FontNr].FontH)+yPixel+HAbstand, Font[FontNr].FontPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
                break;

                case -10: //�
                    rcRect.left = 0;
                    rcRect.top = (99*Font[FontNr].FontH);
                    rcRect.right = Font[FontNr].FontB;
                    rcRect.bottom = (99*Font[FontNr].FontH)+Font[FontNr].FontH;
                    Picture->BltFast((x*Font[FontNr].FontB)+xPixel, (y*Font[FontNr].FontH)+yPixel+HAbstand, Font[FontNr].FontPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
                break;

                case -42: // �
                    rcRect.left = 0;
                    rcRect.top = (100*Font[FontNr].FontH);
                    rcRect.right = Font[FontNr].FontB;
                    rcRect.bottom = (100*Font[FontNr].FontH)+Font[FontNr].FontH;
                    Picture->BltFast((x*Font[FontNr].FontB)+xPixel, (y*Font[FontNr].FontH)+yPixel+HAbstand, Font[FontNr].FontPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
                break;

                case -36: // �
                    rcRect.left = 0;
                    rcRect.top = (101*Font[FontNr].FontH);
                    rcRect.right = Font[FontNr].FontB;
                    rcRect.bottom = (101*Font[FontNr].FontH)+Font[FontNr].FontH;
                    Picture->BltFast((x*Font[FontNr].FontB)+xPixel, (y*Font[FontNr].FontH)+yPixel+HAbstand, Font[FontNr].FontPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
                break;

                default:
                    rcRect.left = 0;
                    rcRect.top = ((SavedText[i]-33)*Font[FontNr].FontH);
                    rcRect.right = Font[FontNr].FontB;
                    rcRect.bottom = ((SavedText[i]-33)*Font[FontNr].FontH)+Font[FontNr].FontH;
                    Picture->BltFast((x*Font[FontNr].FontB)+xPixel, (y*Font[FontNr].FontH)+yPixel+HAbstand, Font[FontNr].FontPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
                break;
            }
       }
 EndPrintText:
// free(SavedText);
} /* PrintText */

void PrintTextNo_Trans(int PosX, int PosY, char *Text, int FontNr, int HAbstand, int MaxXZeichen, int MaxYZeichen, LPDIRECTDRAWSURFACE Picture)
{
    RECT rcRect;
    int Buchstaben, x, y, xPixel, yPixel, xSave, i;
    char SavedText[1000];
//    char *SavedText;

    Buchstaben = strlen(Text);
//	SavedText = (char *)malloc(Buchstaben);
	stpcpy(SavedText, Text);
    xSave = PosX/Font[FontNr].FontB;
    xPixel = PosX-(xSave*Font[FontNr].FontB);
    y = PosY/Font[FontNr].FontH;
    yPixel = PosY-(y*Font[FontNr].FontH);
    for(i = 0; y < MaxYZeichen; y++)
        for(x = xSave; x < MaxXZeichen; x++, i++)
        {
            if(i > Buchstaben-1)
            	goto EndPrintText;
            switch(SavedText[i])
            {
                case -4: // �
                    rcRect.left = 0;
                    rcRect.top = (96*Font[FontNr].FontH);
                    rcRect.right = Font[FontNr].FontB;
                    rcRect.bottom = (96*Font[FontNr].FontH)+Font[FontNr].FontH;
                    Picture->BltFast((x*Font[FontNr].FontB)+xPixel, (y*Font[FontNr].FontH)+yPixel+HAbstand, Font[FontNr].FontPic, &rcRect, FALSE);
                break;

                case -28: // �
                    rcRect.left = 0;
                    rcRect.top = (97*Font[FontNr].FontH);
                    rcRect.right = Font[FontNr].FontB;
                    rcRect.bottom = (97*Font[FontNr].FontH)+Font[FontNr].FontH;
                    Picture->BltFast((x*Font[FontNr].FontB)+xPixel, (y*Font[FontNr].FontH)+yPixel+HAbstand, Font[FontNr].FontPic, &rcRect, FALSE);
                break;

                case -60: // �
                    rcRect.left = 0;
                    rcRect.top = (98*Font[FontNr].FontH);
                    rcRect.right = Font[FontNr].FontB;
                    rcRect.bottom = (98*Font[FontNr].FontH)+Font[FontNr].FontH;
                    Picture->BltFast((x*Font[FontNr].FontB)+xPixel, (y*Font[FontNr].FontH)+yPixel+HAbstand, Font[FontNr].FontPic, &rcRect, FALSE);
                break;

                case -10: //�
                    rcRect.left = 0;
                    rcRect.top = (99*Font[FontNr].FontH);
                    rcRect.right = Font[FontNr].FontB;
                    rcRect.bottom = (99*Font[FontNr].FontH)+Font[FontNr].FontH;
                    Picture->BltFast((x*Font[FontNr].FontB)+xPixel, (y*Font[FontNr].FontH)+yPixel+HAbstand, Font[FontNr].FontPic, &rcRect, FALSE);
                break;

                case -42: // �
                    rcRect.left = 0;
                    rcRect.top = (100*Font[FontNr].FontH);
                    rcRect.right = Font[FontNr].FontB;
                    rcRect.bottom = (100*Font[FontNr].FontH)+Font[FontNr].FontH;
                    Picture->BltFast((x*Font[FontNr].FontB)+xPixel, (y*Font[FontNr].FontH)+yPixel+HAbstand, Font[FontNr].FontPic, &rcRect, FALSE);
                break;

                case -36: // �
                    rcRect.left = 0;
                    rcRect.top = (101*Font[FontNr].FontH);
                    rcRect.right = Font[FontNr].FontB;
                    rcRect.bottom = (101*Font[FontNr].FontH)+Font[FontNr].FontH;
                    Picture->BltFast((x*Font[FontNr].FontB)+xPixel, (y*Font[FontNr].FontH)+yPixel+HAbstand, Font[FontNr].FontPic, &rcRect, FALSE);
                break;

                default:
                    rcRect.left = 0;
                    rcRect.top = ((SavedText[i]-33)*Font[FontNr].FontH);
                    rcRect.right = Font[FontNr].FontB;
                    rcRect.bottom = ((SavedText[i]-33)*Font[FontNr].FontH)+Font[FontNr].FontH;
                    Picture->BltFast((x*Font[FontNr].FontB)+xPixel, (y*Font[FontNr].FontH)+yPixel+HAbstand, Font[FontNr].FontPic, &rcRect, FALSE);
                break;
            }
       }
 EndPrintText:
// free(SavedText);
} /* PrintTextNo_Trans */

// Wenn eine neue Eingabe erfolgen soll, so muss New == YES sein:
int Eingabe(char *Text, int MaxLetters, int New)
{
    static int Pointer = 0;

    if(New != NO_AKTIV)
    {
        Pointer = New;
        return NO;
    }
    if(LastLetterKey == 0)
        return NO;
    if(LastLetterKey == 8) // Back
    {
        if(Pointer > 0)
    		Text[--Pointer] = EOF;
    }
    if(LastLetterKey == 13) // Return
    {
		LastLetterKey = 0;
    	return YES;
    }
    if(LastLetterKey > 32 && LastLetterKey < 125)
    {
        if(Pointer < MaxLetters)
            Text[Pointer++] = LastLetterKey;
    }
	LastLetterKey = 0;
   	return NO;
} /* Eingabe */


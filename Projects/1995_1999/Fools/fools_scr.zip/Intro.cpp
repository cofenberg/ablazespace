#include "Global.h"

#include "FindPaths.h"
#include "FontInc.h"

extern LPDIRECTDRAWSURFACE    MeldungPic;
extern LPDIRECTDRAWSURFACE    FoolSelectedPic;
///////////////////////////////////////////////////////////////////////////////////////
extern void CheckComAni(int);
void EndProgramm(void);
extern void UpdateDisplay(void);
extern int CheckMouseBarMenu(void);

int Intro(void);
void InitIntro(void);
void LoadIntroBitmaps(void);
void DestroyIntroBitmaps(void);
void CheckIntroKeys(WPARAM);
void BuildIntroScene(void);
void MoveIntroButtons(struct ANIMATE_BUTTON *Buttons, int);
void MoveIntroFools(void);
void DrawMainButtons(struct ANIMATE_BUTTON *);
void DrawIntroFool(void);
void CheckIntroButtons(void);
void CheckMainButtons(void);
int CheckMouseRect(int, int, int , int);
void CheckMouseButtons(void);
/////////////////////////////
//    Hauptmen� Funktionen:
///////////////////////////////////////////////////////////////////////////////////////
void InitMainButtons(void);
void MainStartGame(void);
void MainPlayLastGame(void);
void MainLoadGame(void);
void MainStartEditor(void);
void MainShowCredits(void);
void MainGameExit(void);
void RestoreIntroSurfaces(void);

struct ANIMATE_BUTTON MainButtons[7] =
{
    {0, 50, 160, 240, 0, 0, 0, 0, 0, YES, YES, T_START, MainStartGame, YES}, // Start
    {400, 100, 160, 280, 1, 0, 0, 0, 0, YES, YES, T_WEITER, MainPlayLastGame, YES}, // Spiel fortsetzen
    {0, 150,160, 320, 2, 0, 0, 0, 0, YES, YES, T_SPIEL_LADEN, MainLoadGame, YES}, // Spiel laden
    {400, 200, 160, 360, 3, 0, 0, 0, 0, YES, YES, T_EDITOR, MainStartEditor, YES}, // Editor
    {0, 250, 160, 400, 4, 0, 0, 0, 0, YES, YES, T_CREDITS, MainShowCredits, YES}, // Credits
    {400, 300, 160, 440, 3, 1, 0, 0, 0, YES, YES, T_EXIT, MainGameExit, YES}, // Exit
    {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, NO},
};
/////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////
//    Spielart Auswahl Menu Funktionen:
///////////////////////////////////////////////////////////////////////////////////////
void InitSelectButtons(void);
void SelectKampangie(void);
void SelectOnePlayerTraining(void);
void SelectOnePlayerChooseLevel(void);
void SelectTwoPlayerTraining(void);
void SelectTwoPlayerChooseLevel(void);
void SelectReturn(void);
void CheckSelectButtons(void);

struct ANIMATE_BUTTON SelectButtons[7] =
{
    {0, 300, 30, 300, 0, 0, 0, 0, 0, YES, YES, T_KAMPANGIE, SelectKampangie, NO}, // Kampangien Spiel
    {0, 330, 30, 340, 1, 0, 0, 0, 0, YES, YES, T_TRAINING, SelectOnePlayerTraining, NO}, // Ein Spieler Trainings Spiel Sarten
    {0, 360, 30, 390, 2, 0, 0, 0, 0, YES, YES, T_EIGENE_KARTE, SelectOnePlayerChooseLevel, YES}, // Ein Spieler Eingene Karten
    {400, 390, 300, 300, 3, 0, 0, 0, 0, YES, YES, T_TRAINING, SelectTwoPlayerTraining, NO}, // Ein Spieler Trainings Spiel Sarten
    {400, 420, 300, 340, 4, 0, 0, 0, 0, YES, YES, T_EIGENE_KARTE, SelectTwoPlayerChooseLevel, NO},  // Ein Spieler Eingene Karten
    {400, 460, 160, 440, 3, 1, 0, 0, 0, YES, YES, T_ZURUECK, SelectReturn, YES}, // Zum vorherigen Men�
    {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, NO},
};
/////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////
//    Eigene Karte Ausw�hlen Funktionen:
///////////////////////////////////////////////////////////////////////////////////////
void InitChooseButtons(void);
void ChooseStart(void);
void ChooseReturn(void);
void ChoosePageUp(void);
void ChoosePageDown(void);
void CheckChooseButtons(void);

struct ANIMATE_BUTTON ChooseButtons[5] =
{
    {0, 260, 30, 300, 2, 0, 0, 0, 0, YES, YES, T_START, ChooseStart, NO},
    {0, 280, 160, 440, 3, 1, 0, 0, 0, YES, YES, T_ZURUECK, ChooseReturn, YES}, // Zum vorherigen Men�
    {0, 310, 30, 340, 4, 0, 0, 0, 0, YES, YES, T_HOCH, ChoosePageUp, YES},
    {0, 340, 30, 390, 5, 0, 0, 0, 0, YES, YES, T_RUNTER, ChoosePageDown, YES},
    {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, NO},
};
/////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////
//    Karten Informationen:
///////////////////////////////////////////////////////////////////////////////////////
void InitLevelInfoButtons(void);
void LevelInfoReturn(void);
void CheckLevelInfoButtons(void);

struct ANIMATE_BUTTON LevelInfoButtons[2] =
{
    {50, 440, 50, 440, 3, 1, 0, 0, 0, YES, YES, T_ZURUECK, LevelInfoReturn, YES}, // Zum vorherigen Men�
    {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, NO},
};
/////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////
//    About Informationen:
///////////////////////////////////////////////////////////////////////////////////////
void InitAboutInfoButtons(void);
void AboutInfoReturn(void);
void CheckAboutInfoButtons(void);

struct ANIMATE_BUTTON AboutInfoButtons[2] =
{
    {50, 440, 50, 440, 3, 1, 0, 0, 0, YES, YES, T_ZURUECK, LevelInfoReturn, YES}, // Zum vorherigen Men�
    {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, NO},
};
/////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////
//    Game Out Informationen:
///////////////////////////////////////////////////////////////////////////////////////
void InitGameOutButtons(void);
void GameOutReturn(void);
void CheckGameOutButtons(void);

struct ANIMATE_BUTTON GameOutButtons[2] =
{
    {200, 440, 200, 440, 3, 1, 0, 0, 0, YES, YES, T_ZURUECK, GameOutReturn, YES},
    {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, NO},
};

extern LPDIRECTDRAWSURFACE CommandMenuAniPic;
LPDIRECTDRAWSURFACE StonePic;
LPDIRECTDRAWSURFACE BackPic;
LPDIRECTDRAWSURFACE RightFool;
LPDIRECTDRAWSURFACE ChrisMirrorBitmap;
LPDIRECTDRAWSURFACE MiniStretchBitmap;
LPDIRECTDRAWSURFACE BlueMaskBitmap;
LPDIRECTDRAWSURFACE FLightBitmap;

#define MAX_INTRO_FOOLS 37
int FoolsInfo[MAX_INTRO_FOOLS+1][5] = {{0, 0, 60, 5, WALK_RIGHT},
                        {0, 0, 85, 10, WALK_RIGHT},
                        {0, 0, 110, 15, WALK_RIGHT},
                        {0, 0, 50, 40, WALK_RIGHT},
                        {0, 0, 40, 75, WALK_RIGHT},
                        {0, 0, 65, 80, WALK_RIGHT},
                        {0, 0, 90, 85, WALK_RIGHT},
                        {0, 0, 30, 110, WALK_RIGHT},
		        // F
                        {0, 0, 170, 15, WALK_RIGHT},
                        {0, 0, 150, 30, WALK_RIGHT},
                        {0, 0, 190, 30, WALK_RIGHT},
                        {0, 0, 135, 65, WALK_RIGHT},
                        {0, 0, 205, 70, WALK_RIGHT},
                        {0, 0, 145, 95, WALK_RIGHT},
                        {0, 0, 185, 95, WALK_RIGHT},
                        {0, 0, 165, 110, WALK_RIGHT},
		        // O
                        {320, 0, 270, 15, WALK_DOWN},
                        {320, 0, 250, 30, WALK_DOWN},
                        {320, 0, 290, 30, WALK_DOWN},
                        {320, 0, 235, 65, WALK_DOWN},
                        {320, 0, 305, 70, WALK_DOWN},
                        {320, 0, 245, 95, WALK_DOWN},
                        {320, 0, 285, 95, WALK_DOWN},
                        {320, 0, 265, 110, WALK_DOWN},
		        // O
                        {600, 0, 375, 5, WALK_LEFT},
                        {600, 0, 360, 45, WALK_LEFT},
                        {600, 0, 350, 75, WALK_LEFT},
                        {600, 0, 340, 105, WALK_LEFT},
                        {600, 0, 365, 115, WALK_LEFT},
                        {600, 0, 390, 125, WALK_LEFT},
		        // L
                        {600, 0, 500, 5, WALK_LEFT},
                        {600, 0, 470, 20, WALK_LEFT},
                        {600, 0, 450, 50, WALK_LEFT},
                        {600, 0, 470, 70, WALK_LEFT},
                        {600, 0, 485, 100, WALK_LEFT},
                        {600, 0, 460, 120, WALK_LEFT},
                        {600, 0, 435, 135, WALK_LEFT},
		        // S

                        {-1, -1, -1, -1, -1},
                       };

#define MAIN_BUTTON_MAX_STEP 4
#define MAIN_BUTTON_MAX_SELECT_STEP 7
#define MAIN_BUTTON_B 230
#define MAIN_BUTTON_H 40

///////////////////////////////////////////////////////////////////////////////////////
#define INTRO_MAIN_MENU 1
#define INTRO_SELECT_MENU 2
#define INTRO_CHOOSE_MENU 3
#define INTRO_LEVEL_INFO_MENU 4
#define INTRO_ABOUT_INFO_MENU 5
#define GAME_OUT 6
#define ONE_PLAYER 1
#define TWO_PLAYER 2

#define CHOOSE_WINDOW_X 280
#define CHOOSE_WINDOW_Y 270
#define CHOOSE_WINDOW_B 130
#define CHOOSE_WINDOW_H 170

#define LEVEL_INFO_X 550
#define LEVEL_INFO_Y 200

#define MAX_MAIN_STARS 100
int Star[MAX_MAIN_STARS][3];
int StretchMini;
int FoolLightAniStep[4];
int FoolLightAniStepTurn[4];
///////////////////////////////////////////////////////////////////////////////////////

int Intro(void)
{
    MSG         msg;

    LoadIntroBitmaps();
	InitIntro();
    CheckMouseButtonInfo(YES, 500, 1);
    for(;;)
    {
        if(PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
        {
            if(!GetMessage(&msg, NULL, 0, 0))
                return msg.wParam;
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
        else
            if(!gExclusive || bActive)
            {
                MoveIntroFools();
				if(CheckMouseBarMenu() == NO)
	                CheckMouseButtons();
                CheckIntroButtons();
                BuildIntroScene();
                UpdateDisplay();
                if(ExitModule == YES || ExitProgramm == YES)
                {
                    DestroyIntroBitmaps();
					return 0;
                }
            }
            else
            {
                WaitMessage();
            }
    }
} /* Intro */
///////////////////////////////////////////////////////////////////////////////////////

void CheckMouseButtons(void)
{
    switch(GameInfo.Module)
    {
        case INTRO_MAIN_MENU: CheckMainButtons(); break;
        case INTRO_SELECT_MENU: CheckSelectButtons(); break;
        case INTRO_CHOOSE_MENU: CheckChooseButtons(); break;
        case INTRO_LEVEL_INFO_MENU: CheckLevelInfoButtons(); break;
        case INTRO_ABOUT_INFO_MENU: CheckAboutInfoButtons(); break;
        case GAME_OUT: CheckGameOutButtons(); break;
    }
} /* CheckMouseButtons */

void InitIntro(void)
{
    int i;

	CheckKeyModule = CheckIntroKeys;
	ExitModule = NO;
    SetMouseBound(0, 0, ScreenRes[0], ScreenRes[1]);
    SetMouseStyle(NORMAL_MOUSE_STYLE, YES, 1, 0, 0, 15, YES, 0);
	Mouse.Show = YES;
    for(i = 0; i < 4; i++)
    {
		FoolLightAniStep[i] = 0;
	    FoolLightAniStepTurn[i] = 0;
    }
	StretchMini = NO;
	ProgrammModule = TITEL_MENU;
    for(i = 0; i < MAX_MAIN_STARS; i++)
    {
        Star[i][0] = NO_AKTIV;
        Star[i][1] = NO_AKTIV;
        Star[i][2] = NO_AKTIV;
    }
    for(i = 0; i < MAX_INTRO_FOOLS; i++)
    {
        Szenario.Info.FoolInfo[i].OnLive = YES;
        Szenario.Info.FoolInfo[i].Fool_ID = i;
        Szenario.Info.FoolInfo[i].PixelPosX = FoolsInfo[i][0];
        Szenario.Info.FoolInfo[i].PixelPosY = FoolsInfo[i][1];
        Szenario.Info.FoolInfo[i].Animation = FoolsInfo[i][4];
        Szenario.Info.FoolInfo[i].AnimationStep = (int)random((MAX_FOOL_ANIMATION*2));
		Szenario.Info.FoolInfo[i].Richtung = Szenario.Info.FoolInfo[i].Animation;
    }
    GameInfo.Module = INTRO_MAIN_MENU;
	InitMainButtons();
} /* InitIntro */

// Ver�ndert die Men� Buttons:
void MoveIntroButtons(struct ANIMATE_BUTTON *Buttons, int Ani)
{
    int i;

    for(i = 0; Buttons[i].SetX != -1; i++)
    {
        if(Ani == NO)
        {
            if(Buttons[i].X != Buttons[i].SetX)
            {
                if(Buttons[i].X > Buttons[i].SetX)
                    Buttons[i].X--;
                if(Buttons[i].X < Buttons[i].SetX)
                    Buttons[i].X++;
            }
            if(Buttons[i].Y != Buttons[i].SetY)
            {
                if(Buttons[i].Y > Buttons[i].SetY)
                    Buttons[i].Y--;
                if(Buttons[i].Y < Buttons[i].SetY)
                    Buttons[i].Y++;
            }
        }
        if(Buttons[i].Aktiv == NO)
        	continue;
        if(Ani == NO)
        	continue;
        if(Buttons[i].ButtonTurn == 0)
            if(Buttons[i].ButtonStep < MAIN_BUTTON_MAX_STEP)
                Buttons[i].ButtonStep++;
            else
                Buttons[i].ButtonTurn = 1;
        else
            if(Buttons[i].ButtonStep > 0)
                Buttons[i].ButtonStep--;
            else
                Buttons[i].ButtonTurn = 0;
    }
} /* MoveIntroButtons */

void MoveIntroFools(void)
{
    int i, zufall, i2;
    int MouseButtonTimer;
    static int MouseButtonLastTimer = 0;
    int MouseButtonTimer2;
    static int MouseButtonLastTimer2 = 0;

    MouseButtonTimer2 = (int)timeGetTime()-MouseButtonLastTimer2;
    if(MouseButtonTimer2 > 70)
    {
        MouseButtonLastTimer2 = (int)timeGetTime();
        for(i = 0; i < MAX_MAIN_STARS; i++)
        {
            if(Star[i][0] != NO_AKTIV)
            {
                Star[i][2]++;
                if(Star[i][2] > 6)
                {
                    Star[i][0] = NO_AKTIV;
                    Star[i][1] = NO_AKTIV;
                    Star[i][2] = NO_AKTIV;
                }
                continue;
            }
            zufall = (int)random(6);
            if(zufall != 5)
                continue;
            zufall = (int)random(ScreenRes[0]-10);
            Star[i][0] = zufall;
            zufall = (int)random(ScreenRes[1]-10);
            Star[i][1] = zufall;
            Star[i][2] = 0;
        }
    }
    MouseButtonTimer = (int)timeGetTime()-MouseButtonLastTimer;
    if(MouseButtonTimer < 20)
    	return;
    MouseButtonLastTimer = (int)timeGetTime();
    for(i = 0; i < MAX_INTRO_FOOLS; i++)
    {
		// Der Fool bringt sich in Position:
        if(Szenario.Info.FoolInfo[i].PixelPosX != FoolsInfo[i][2])
        {
	        if(Szenario.Info.FoolInfo[i].PixelPosX > FoolsInfo[i][2])
				Szenario.Info.FoolInfo[i].PixelPosX--;
	        if(Szenario.Info.FoolInfo[i].PixelPosX < FoolsInfo[i][2])
				Szenario.Info.FoolInfo[i].PixelPosX++;
			CheckFoolWalkAni(i);
        }
        if(Szenario.Info.FoolInfo[i].PixelPosY != FoolsInfo[i][3])
        {
	        if(Szenario.Info.FoolInfo[i].PixelPosY > FoolsInfo[i][3])
				Szenario.Info.FoolInfo[i].PixelPosY--;
	        if(Szenario.Info.FoolInfo[i].PixelPosY < FoolsInfo[i][3])
				Szenario.Info.FoolInfo[i].PixelPosY++;
			CheckFoolWalkAni(i);
        }
		// Der Fool vollf�hrt nun seine Animationen:
        if(Szenario.Info.FoolInfo[i].PixelPosX == FoolsInfo[i][2] &&
	        Szenario.Info.FoolInfo[i].PixelPosY == FoolsInfo[i][3])
        {
            for(i2 = 0; i2 < 4; i2++)
            {
                FoolLightAniStep[i2] = NO_AKTIV;
                FoolLightAniStepTurn[i2] = NO_AKTIV;
            }
        	Szenario.Info.FoolInfo[i].Animation = SILLY_DOWN;
            CheckFoolSillyAni(i, YES);
        }
    }
    if(GameInfo.Module == INTRO_SELECT_MENU)
    {
		CheckFoolWalkAni(MAX_INTRO_FOOLS);
		CheckFoolWalkAni(MAX_INTRO_FOOLS+1);
		CheckFoolWalkAni(MAX_INTRO_FOOLS+2);
    }
    if(GameInfo.Module == INTRO_CHOOSE_MENU || GameInfo.Module == INTRO_LEVEL_INFO_MENU)
    {
		CheckFoolWalkAni(MAX_INTRO_FOOLS);
        if(GameInfo.PlayerAnzahl == TWO_PLAYER)
			CheckFoolWalkAni(MAX_INTRO_FOOLS+1);
    }
} /* MoveIntroFools */

void LoadIntroBitmaps(void)
{
    DDSURFACEDESC ddsd;
    DDBLTFX ddbltfx;
    RECT rcRect, rcRect2;
	LPDIRECTDRAWSURFACE Pic;

    ZeroMemory(&ddsd, sizeof(ddsd));
    ddsd.dwSize = sizeof(ddsd);
    ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH;
    ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_SYSTEMMEMORY;
    ZeroMemory(&ddbltfx, sizeof(ddbltfx));
    ddbltfx.dwSize = sizeof(ddbltfx);
    Pic = DDLoadBitmap(lpDD, "Bilder/Stone.bmp", 0, 0, YES);
    ddsd.dwWidth = ScreenRes[0];
    ddsd.dwHeight = ScreenRes[1];
    if(lpDD->CreateSurface(&ddsd, &StonePic, NULL) != DD_OK)
        return;
    SetRect(&rcRect, 0, 0, 640, 480);
    SetRect(&rcRect2, 0, 0, ScreenRes[0], ScreenRes[1]);
    StonePic->Blt(&rcRect2, Pic, &rcRect, NULL, NULL);
    Pic->Restore();
	BackPic = DDLoadBitmap(lpDD, "Bilder/TitelHin.bmp", 0, 0, YES);
    DDSetColorKey(BackPic, 5);
    ddsd.dwWidth = 252;
    ddsd.dwHeight = 333;
    if(lpDD->CreateSurface(&ddsd, &RightFool, NULL) != DD_OK)
        return;
    ddbltfx.dwDDFX = DDBLTFX_MIRRORLEFTRIGHT;
    SetRect(&rcRect, 1, 1, 253, 334);
    SetRect(&rcRect2, 0, 0, 252, 333);
    RightFool->Blt(&rcRect2, BackPic, &rcRect, DDBLT_DDFX | DDBLT_WAIT, &ddbltfx);
    DDSetColorKey(RightFool, 5);
    ddsd.dwWidth = 131;
    ddsd.dwHeight = 145;
    if(lpDD->CreateSurface(&ddsd, &ChrisMirrorBitmap, NULL) != DD_OK)
        return;
    DDSetColorKey(ChrisMirrorBitmap, 5);
    ddbltfx.dwDDFX = DDBLTFX_MIRRORUPDOWN;
    SetRect(&rcRect, 254, 191, 375, 336);
    SetRect(&rcRect2, 0, 0, 121, 145);
    ChrisMirrorBitmap->Blt(&rcRect2, BackPic, &rcRect, DDBLT_DDFX | DDBLT_WAIT, &ddbltfx);
    SetRect(&rcRect, 0, 0, 121, 145);
    SetRect(&rcRect2, 0, 0, 121, 90);
    ChrisMirrorBitmap->Blt(&rcRect2, ChrisMirrorBitmap, &rcRect, DDBLT_WAIT, &ddbltfx);
    ddsd.dwWidth = 640;
    ddsd.dwHeight = 480;
    if(lpDD->CreateSurface(&ddsd, &BlueMaskBitmap, NULL) != DD_OK)
        return;
    ddsd.dwWidth = ScreenRes[0];
    ddsd.dwHeight = ScreenRes[1];
    if(lpDD->CreateSurface(&ddsd, &MiniStretchBitmap, NULL) != DD_OK)
        return;
	Pic = DDLoadBitmap(lpDD, "Bilder/FoolLi.bmp", 0, 0, YES);
    ddsd.dwWidth = 640;
    ddsd.dwHeight = 150;
    if(lpDD->CreateSurface(&ddsd, &FLightBitmap, NULL) != DD_OK)
        return;
    DDSetColorKey(FLightBitmap, 5);
    SetRect(&rcRect, 0, 0, 640, 71);
    FLightBitmap->BltFast(0, 0, Pic, &rcRect, FALSE);
    ddbltfx.dwDDFX = DDBLTFX_MIRRORLEFTRIGHT;
    SetRect(&rcRect, 0, 0, 640, 71);
    SetRect(&rcRect2, 0, 70, 640, 141);
    FLightBitmap->Blt(&rcRect2, Pic, &rcRect, DDBLT_DDFX, &ddbltfx);
    Pic->Restore();
} /* LoadIntroBitmaps */

void DestroyIntroBitmaps(void)
{
    BackPic->Release();
	RightFool->Release();
	ChrisMirrorBitmap->Release();
    MiniStretchBitmap->Release();
} /* DestroyIntroBitmaps */

void BuildIntroScene(void)
{
    RECT rcRect;
    int i, y;
    char temp[50];

    if(StretchMini == YES)
    { // Die Mini Karte wird gerade in voller Pracht betrachted:
	    SetRect(&rcRect, 0, 0, ScreenRes[0], ScreenRes[1]);
        Back->BltFast(0, 0, MiniStretchBitmap, &rcRect, FALSE);
        return;
    }
    if(GameInfo.Module == INTRO_MAIN_MENU)
    {
         DDBLTFX     ddbltfx;
        // L�scht die Gesamte Spielfl�che(Verhindert wasch Effecte!):
         ddbltfx.dwSize = sizeof(ddbltfx);
         ddbltfx.dwFillColor = 0;
         Back->Blt(NULL, NULL, NULL, DDBLT_COLORFILL, &ddbltfx);
         SetRect(&rcRect, 354, 1, 622, 154);
         Back->BltFast(ScreenRes[0]-269, ScreenRes[1]-154, BackPic, &rcRect, FALSE);
         SetRect(&rcRect, 254, 1, 353, 74);
         Back->BltFast(0, ScreenRes[1]-80, BackPic, &rcRect, FALSE);
         SetRect(&rcRect, 338, 156, 382, 190);
         Back->BltFast(ScreenRes[0]-150, 50, BackPic, &rcRect, FALSE);
         SetRect(&rcRect, 254, 75, 337, 180);
         Back->BltFast(10, 30, BackPic, &rcRect, FALSE);
        // Sterne malen:
         for(i = 0; i < MAX_MAIN_STARS; i++)
         {
             if(Star[i][0] == NO_AKTIV)
                 continue;
             SetRect(&rcRect, 254+(10*Star[i][2]), 181, 254+(10*Star[i][2])+8, 181+8);
             Back->BltFast(Star[i][0], Star[i][1], BackPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
         }
         SetRect(&rcRect, 383, 156, 507, 276);
         Back->BltFast(ScreenRes[0]/2, ScreenRes[1]/2, BackPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        // Linker Fool:
         SetRect(&rcRect, 1, 1, 253, 334);
         Back->BltFast(0, ScreenRes[1]-340, BackPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        // Rechter Fool:
         SetRect(&rcRect, 0, 0, 252, 333);
         Back->BltFast(ScreenRes[0]-260, ScreenRes[1]-340, RightFool, &rcRect, DDBLTFAST_SRCCOLORKEY);
        ///////////
    }
    else
    {
         SetRect(&rcRect, 0, 0, ScreenRes[0], ScreenRes[1]);
         Back->BltFast(0, 0, StonePic, &rcRect, FALSE);
    }
    switch(GameInfo.Module)
    {
    	case INTRO_MAIN_MENU: DrawMainButtons(&MainButtons[0]); break;
        case INTRO_SELECT_MENU: DrawMainButtons(&SelectButtons[0]); break;
        case INTRO_CHOOSE_MENU: DrawMainButtons(&ChooseButtons[0]); break;
        case INTRO_LEVEL_INFO_MENU: DrawMainButtons(&LevelInfoButtons[0]); break;
        case INTRO_ABOUT_INFO_MENU: DrawMainButtons(&AboutInfoButtons[0]); break;
    }
	if(GameInfo.Module == INTRO_SELECT_MENU)
    {
   	    SetRect(&rcRect, 1, 337, 100, 396);
        Back->BltFast(90, 240, BackPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
   	  	PrintText(95, 260, GameTexte[T_1_PLAYER], 1, 0, 80, 40, Back);
        SetRect(&rcRect, 101, 337, 200, 396);
        Back->BltFast(360, 240, BackPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
   	  	PrintText(365, 260, GameTexte[T_1_PLAYER], 1, 0, 80, 40, Back);
    }
	if(GameInfo.Module == INTRO_CHOOSE_MENU || GameInfo.Module == INTRO_LEVEL_INFO_MENU)
    {
        if(GameInfo.PlayerAnzahl == ONE_PLAYER)
        {
    	    SetRect(&rcRect, 1, 337, 100, 396);
            Back->BltFast(300, 200, BackPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
            PrintText(315, 220, GameTexte[T_1_PLAYER], 1, 0, 80, 40, Back);
        }
        if(GameInfo.PlayerAnzahl == TWO_PLAYER)
        {
	        SetRect(&rcRect, 101, 337, 200, 396);
            Back->BltFast(300, 200, BackPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
            PrintText(315, 220, GameTexte[T_2_PLAYER], 1, 0, 80, 40, Back);
        }
        SetRect(&rcRect, 259, 337, 389, 507);
        if(GameInfo.Module == INTRO_CHOOSE_MENU)
        {
            Back->BltFast(CHOOSE_WINDOW_X, CHOOSE_WINDOW_Y, BackPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
            for(i = 0, y = 0;; i++, y += Font[3].FontB+20)
            {
                if(SzenarioPaths[i].PathName[0] == EOF || i > MAX_PATHS)
                    break;
                if(GameInfo.SelectedPath == i)
                    PrintText(CHOOSE_WINDOW_X+5, CHOOSE_WINDOW_Y+y+5, SzenarioPaths[i].PathName, 3, 0, 1000, 1000, Back);
                else
                    PrintText(CHOOSE_WINDOW_X+5, CHOOSE_WINDOW_Y+y+5, SzenarioPaths[i].PathName, 1, 0, 1000, 1000, Back);
            }
		    if(ChooseButtons[0].Aktiv == YES)
            {
    	        SetRect(&rcRect, 201, 337, 231, 367);
	            Back->BltFast(LEVEL_INFO_X, LEVEL_INFO_Y, BackPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
            }
        }
        if(GameInfo.Module == INTRO_LEVEL_INFO_MENU)
        {
            Back->BltFast(15, 250, BackPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
           // Zeit Anzeige Text:
            PrintText(50, 255, GameTexte[T_GAME_TIME], 1, 0, 90, 90, Back);
            if(Szenario.Info.LimitedTime == YES)
	            SetRect(&rcRect, 56, 1360, 77, 1381);
            if(Szenario.Info.LimitedTime == NO)
	            SetRect(&rcRect, 78, 1360, 99, 1381);
            if(Szenario.Info.LimitedTime == USER)
	            SetRect(&rcRect, 67, 691, 88, 712);
            Back->BltFast(20, 255, GameListPic, &rcRect, FALSE);
            sprintf(temp, "%d:", GameInfo.PlayedTimeHours);
            PrintText(60, 280, temp, 1, 0, 1000, 1000, Back);
            sprintf(temp, "%d:", GameInfo.PlayedTimeMin);
            PrintText(90, 280, temp, 1, 0, 1000, 1000, Back);
            sprintf(temp, "%d", GameInfo.PlayedTimeSec);
            PrintText(120, 280, temp, 1, 0, 1000, 1000, Back);
            if(GameInfo.LimitedTime == YES)
	            SetRect(&rcRect, 56, 1360, 77, 1381);
            if(GameInfo.LimitedTime == NO)
	            SetRect(&rcRect, 78, 1360, 99, 1381);
            if(GameInfo.LimitedTime == USER)
	            SetRect(&rcRect, 67, 691, 88, 712);
            Back->BltFast(20, 280, GameListPic, &rcRect, FALSE);
         ///////
            for(i = 0; i < 9; i++)
            {
                rcRect.left   = 1+(34*i);
                rcRect.top    = 1+(34*GameCommandMenu[i].Step);
                rcRect.right  = 1+(34*i)+32;
                rcRect.bottom = 1+(34*GameCommandMenu[i].Step)+33;
                Back->BltFast(GameInfo.GameListe.CommandsMenu.CommandsButtonX[i], GameInfo.GameListe.CommandsMenu.CommandsButtonY[i], CommandMenuAniPic, &rcRect, FALSE);
                if(GameCommandMenu[i].Anzahl == NO_AKTIV)
	                PrintText(GameInfo.GameListe.CommandsMenu.CommandsButtonX[i], GameInfo.GameListe.CommandsMenu.CommandsButtonY[i], "--", 1, 0, 90, 90, Back);
                else
                	if(GameCommandMenu[i].Anzahl != NO_LIMITED)
	                {
                    	sprintf(temp, "%d", GameCommandMenu[i].Anzahl);
	                	PrintText(GameInfo.GameListe.CommandsMenu.CommandsButtonX[i], GameInfo.GameListe.CommandsMenu.CommandsButtonY[i], temp, 1, 0, 90, 90, Back);
                	}
            }
            sprintf(temp, "%d Fools m�ssen �berleben!!!", Szenario.Info.ToFinish_LiveFools);
            PrintText(200, 350, temp, 1, 0, 1000, 1000, Back);
        }
        SetRect(&rcRect, 390, 337, 600, 457);
        Back->BltFast(420, 350, BackPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        SetRect(&rcRect, 259, 508, 359, 608);
        Back->BltFast(480, 240, BackPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        if(GameInfo.SelectedPath != NO_AKTIV)
        {
            sprintf(temp, "%s: %s", GameTexte[T_NAME], GameInfo.AktuellesLevel);
            PrintText(430, 370, temp, 1, 0, 80, 80, Back);
            sprintf(temp, "%s:%dx%d", GameTexte[T_KARTEN_GROSSE], Szenario.Info.KarteB, Szenario.Info.KarteH);
            PrintText(430, 400, temp, 1, 0, 80, 80, Back);
            sprintf(temp, "%s:%s", GameTexte[T_SZENARIO], Szenario.Info.SzenarioSet);
            PrintText(430, 420, temp, 1, 0, 80, 80, Back);
            sprintf(temp, "%s:%d", GameTexte[T_FOOLS], GameInfo.LiveFools);
            PrintText(430, 440, temp, 1, 0, 80, 80, Back);
			CheckMiniFilter(490, 250);
			DrawMiniToDisplay(490, 250);
        }
    }
    PrintText(400, 190, VersionsInfo, 1, 0, 80, 80, Back);
	DrawIntroFool();
    if(GameInfo.Module == INTRO_ABOUT_INFO_MENU)
    {
        SetRect(&rcRect, 254, 191, 375, 336);
        Back->BltFast(50, 160, BackPic, &rcRect, FALSE);
	    SetRect(&rcRect, 0, 0, 131, 90);
        Back->BltFast(50, 160+145, ChrisMirrorBitmap, &rcRect, FALSE);
   	  	PrintText(180, 220, "Programmierung, Spieledesing, und Graphiken von              Christian Ofenberg", 0, 0, Font[0].MaxXZeichen, 40, Back);
   	  	PrintText(180, 300, "Mozartstr. 9", 0, 0, Font[0].MaxXZeichen, 1000, Back);
   	  	PrintText(180, 330, "97990 Weikersheim", 0, 0, Font[0].MaxXZeichen, 1000, Back);
   	  	PrintText(180, 360, "Tel: 97341/8684", 0, 0, Font[0].MaxXZeichen, 1000, Back);
    }
    if(FoolLightAniStep[0] != NO_AKTIV)
    {
        SetRect(&rcRect, 1+(FoolLightAniStep[0]*71), 1, 1+(FoolLightAniStep[0]*71)+70, 70);
        Back->BltFast(0, 0, FLightBitmap, &rcRect, DDBLTFAST_SRCCOLORKEY);
        SetRect(&rcRect, 1+(FoolLightAniStep[1]*71), 1, 1+(FoolLightAniStep[1]*71)+70, 70);
        Back->BltFast(340, 0, FLightBitmap, &rcRect, DDBLTFAST_SRCCOLORKEY);
        SetRect(&rcRect, 1+(FoolLightAniStep[2]*71), 71, 1+(FoolLightAniStep[2]*71)+70, 140);
        Back->BltFast(269, 0, FLightBitmap, &rcRect, DDBLTFAST_SRCCOLORKEY);
        SetRect(&rcRect, 1+(FoolLightAniStep[3]*71), 71, 1+(FoolLightAniStep[3]*71)+70, 140);
        Back->BltFast(570, 0, FLightBitmap, &rcRect, DDBLTFAST_SRCCOLORKEY);
    }
} /* BuildIntroScene*/

// Zeichnet die Ge�nschten Buttons:
void DrawMainButtons(struct ANIMATE_BUTTON *Buttons)
{
	RECT rcRect;
    int i;

    for(i = 0; Buttons[i].SetX != -1; i++)
	{
        rcRect.left   = 1;
        rcRect.top    = 397+(Buttons[i].ButtonStep*(MAIN_BUTTON_H+1));
        rcRect.right  = 1+MAIN_BUTTON_B;
        rcRect.bottom = 397+(Buttons[i].ButtonStep*(MAIN_BUTTON_H+1))+MAIN_BUTTON_H;
        Back->BltFast(Buttons[i].X, Buttons[i].Y, BackPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        rcRect.left   = 232;
        rcRect.top    = 397+(26*Buttons[i].SelectedStep);
        rcRect.right  = 257;
        rcRect.bottom = 397+(26*Buttons[i].SelectedStep)+25;
        if(Buttons[i].LeftLight == YES)
            Back->BltFast(Buttons[i].X, Buttons[i].Y+8, BackPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        if(Buttons[i].RightLight == YES)
            Back->BltFast(Buttons[i].X+MAIN_BUTTON_B-25, Buttons[i].Y+5, BackPic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        if(Buttons[i].Text != -1)
	    {
            if(Buttons[i].Selected == YES)
                PrintText(Buttons[i].X+40, Buttons[i].Y+10, GameTexte[Buttons[i].Text], 2, 0, 1000, 1000, Back);
            else
                PrintText(Buttons[i].X+40, Buttons[i].Y+10, GameTexte[Buttons[i].Text], 0, 0, 1000, 1000, Back);
        }
    }
} /* DrawMainButtons */

void DrawIntroFool(void)
{
    int i;

    for(i = 0; i < 4; i++)
    {
	    if(FoolLightAniStepTurn[i] == 0)
		{
            FoolLightAniStep[i]++;
			if(FoolLightAniStep[i] > 8)
	            FoolLightAniStepTurn[i] = 1;
        }
        else
		{
            FoolLightAniStep[i]--;
			if(FoolLightAniStep[i] < 1)
	            FoolLightAniStepTurn[i] = 0;
        }
    }
    for(i = 0; Szenario.Info.FoolInfo[i].PixelPosX != -1; i++)
    {
        // Setzt einen Fool auf die Spielfl�che:
        if(Szenario.Info.FoolInfo[i].OnLive == NO || Szenario.Info.FoolInfo[i].Fool_ID == NO_AKTIV)
            return;
		DrawAnimatedFool(i, Szenario.Info.FoolInfo[i].PixelPosX, Szenario.Info.FoolInfo[i].PixelPosY, Back, NO);
	}
} /* DrawIntroFool */

void CheckIntroButtons(void)
{
    int MouseButtonTimer;
    static int MouseButtonLastTimer = 0;
    int MouseButtonTimer2, i;
    static int MouseButtonLastTimer2 = 0;

    MouseButtonTimer2 = timeGetTime()-MouseButtonLastTimer2;
    if(MouseButtonTimer2 > 1) // Bewegt die Buttons
	{
        MouseButtonLastTimer2 = timeGetTime();
        switch(GameInfo.Module)
        {
            case INTRO_MAIN_MENU: MoveIntroButtons(&MainButtons[0], NO); break;
            case INTRO_SELECT_MENU: MoveIntroButtons(&SelectButtons[0], NO); break;
            case INTRO_CHOOSE_MENU: MoveIntroButtons(&ChooseButtons[0], NO); break;
            case GAME_OUT: MoveIntroButtons(&GameOutButtons[0], NO); break;
        }
    }
    MouseButtonTimer = timeGetTime()-MouseButtonLastTimer;
    if(MouseButtonTimer > 60)
    {
        MouseButtonLastTimer = timeGetTime();
		for(i = 0; i < 9; i++)
        	CheckComAni(i);
        switch(GameInfo.Module)
        {
            case INTRO_MAIN_MENU: MoveIntroButtons(&MainButtons[0], YES); break;
            case INTRO_SELECT_MENU: MoveIntroButtons(&SelectButtons[0], YES); break;
            case INTRO_CHOOSE_MENU: MoveIntroButtons(&ChooseButtons[0], YES); break;
            case INTRO_LEVEL_INFO_MENU: MoveIntroButtons(&LevelInfoButtons[0], YES); break;
            case INTRO_ABOUT_INFO_MENU: MoveIntroButtons(&AboutInfoButtons[0], YES); break;
            case GAME_OUT: MoveIntroButtons(&GameOutButtons[0], YES); break;
        }
    }
} /* CheckIntroButtons */
///////////////////////////////////////////////////////////////////////////////////////
void CheckIntroKeys(WPARAM wParam)
{
    switch(wParam)
    {
        case VK_ESCAPE: ExitModule = YES; break;

        case VK_F12:
           	if(UserMessage(GameTexte[T_PROGRAMM_EXIT_ASK], NO, YES, YES) == YES)
				ExitProgramm = YES;
        break;

        case VK_F8:
			if(ProgrammSetup.ShowFps == YES)
	            ProgrammSetup.ShowFps = NO;
            else
	            ProgrammSetup.ShowFps = YES;
        break;

        case VK_SPACE:
            DestroyIntroBitmaps();
			Game(YES);
            InitIntro();
            LoadIntroBitmaps();
        break;
    }
} /* CheckIntroKeys */

///////////////////////////////////////////////////////////////////////////////////////
//    Hauptmen� Funktionen:
///////////////////////////////////////////////////////////////////////////////////////
    void InitMainButtons(void)
    {
        int i;

        for(i = 0; MainButtons[i].SetX != -1; i++)
        {
            MainButtons[i].Selected = NO;
            MainButtons[i].SelectedOn = NO;
            MainButtons[i].SelectedStep = 0;
        }
        MainButtons[0].X = 0;
        MainButtons[0].Y = 50;
        MainButtons[1].X = 400;
        MainButtons[1].Y = 100;
        MainButtons[2].X = 0;
        MainButtons[2].Y = 150;
        MainButtons[3].X = 400;
        MainButtons[3].Y = 200;
        MainButtons[4].X = 0;
        MainButtons[4].Y = 250;
        MainButtons[5].X = 400;
        MainButtons[5].Y = 300;
        Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].PixelPosX = -1;
        Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+1].PixelPosX = -1;
        Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+2].PixelPosX = -1;
    } /* InitMainButtons */

    void MainStartGame(void)
    {
    	GameInfo.Module = INTRO_SELECT_MENU;
		InitSelectButtons();
    } /* StartGame */

    void MainPlayLastGame(void)
    {
    } /* PlayLastGame */

    void MainLoadGame(void)
    {
    } /* LoadGame */

    void MainStartEditor(void)
    {
        LevelEditor();
    } /* StartEditor */

    void MainShowCredits(void)
    {
    	GameInfo.Module = INTRO_ABOUT_INFO_MENU;
		InitAboutInfoButtons();
    } /* ShowCredits */

    void MainGameExit(void)
    {
        ExitProgramm = YES;
    } /* GameExit */

    void CheckMainButtons(void)
    {
        int i, i2;

       // Pr�ft, ob sich die Maus auf einem Button befindet:
        for(i = 0; MainButtons[i].SetX != -1; i++)
            if(CheckMouseRect(MainButtons[i].X, MainButtons[i].Y, MainButtons[i].X+MAIN_BUTTON_B, MainButtons[i].Y+MAIN_BUTTON_H) != NO_AKTIV)
                break;
        CheckButtonLight(&MainButtons[0], i);
        if(i < 6)
        {
            if(Mouse.Button == LEFT_MOUSE_BUTTON && MainButtons[i].Aktiv == YES)
            {
                if(MainButtons[i].Funktion != 0)
                {
                    if(i != 0 && i != 4)
	                    DestroyIntroBitmaps();
                    MainButtons[i].Funktion();
                    ExitModule = NO;
                    if(i != 0 && i != 4)
                    {
                        InitIntro();
                        LoadIntroBitmaps();
                    }
                }
            }
        }
        else
            for(i2 = 0; MainButtons[i2].SetX != -1; i2++)
                MainButtons[i2].Selected = NO;
    } /* CheckMainButtons */

///////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////
//    Spielart Auswahl Menu Funktionen:
///////////////////////////////////////////////////////////////////////////////////////
    void InitSelectButtons(void)
    {
        int i;

        for(i = 0; SelectButtons[i].SetX != -1; i++)
        {
            SelectButtons[i].Selected = NO;
            SelectButtons[i].SelectedOn = NO;
            SelectButtons[i].SelectedStep = 0;
        }
        SelectButtons[0].X = 0;
        SelectButtons[0].Y = 300;
        SelectButtons[1].X = 0;
        SelectButtons[1].Y = 330;
        SelectButtons[2].X = 0;
        SelectButtons[2].Y = 360;
        SelectButtons[3].X = 400;
        SelectButtons[3].Y = 390;
        SelectButtons[4].X = 400;
        SelectButtons[4].Y = 420;
        SelectButtons[5].X = 400;
        SelectButtons[5].Y = 460;
        Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].OnLive = YES;
        Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].Fool_ID = MAX_INTRO_FOOLS+2;
        Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].PixelPosX = 120;
        Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].PixelPosY = 240;
        Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].Animation = PUSH_DOWN;
        Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].AnimationStep = 0;
		Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].Richtung = WALK_DOWN;
      ///
        Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+1].OnLive = YES;
        Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+1].Fool_ID = MAX_INTRO_FOOLS+2;
        Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+1].PixelPosX = 371;
        Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+1].PixelPosY = 240;
        Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+1].Animation = PUSH_RIGHT;
        Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+1].AnimationStep = 0;
		Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+1].Richtung = WALK_RIGHT;
      ///
        Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+2].OnLive = YES;
        Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+2].Fool_ID = MAX_INTRO_FOOLS+3;
        Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+2].PixelPosX = 403;
        Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+2].PixelPosY = 240;
        Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+2].Animation = PUSH_LEFT;
        Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+2].AnimationStep = 0;
		Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+2].Richtung = WALK_LEFT;
    } /* InitSelectButtons */

    void SelectKampangie(void)
    {
        GameInfo.PlayerAnzahl = ONE_PLAYER;
        Game(NO);
    } /* SelectKampangie */

    void SelectOnePlayerTraining(void)
    {
        GameInfo.PlayerAnzahl = ONE_PLAYER;
    } /* SelectOnePlayerTraining */

    void SelectOnePlayerChooseLevel(void)
    {
        GameInfo.PlayerAnzahl = ONE_PLAYER;
    	GameInfo.Module = INTRO_CHOOSE_MENU;
		InitChooseButtons();
    } /* SelectOnePlayerChooseLevel */

    void SelectTwoPlayerTraining(void)
    {
        GameInfo.PlayerAnzahl = TWO_PLAYER;
    } /* SelectTwoPlayerTraining */

    void SelectTwoPlayerChooseLevel(void)
    {
        GameInfo.PlayerAnzahl = TWO_PLAYER;
    	GameInfo.Module = INTRO_CHOOSE_MENU;
		InitChooseButtons();
    } /* SelectTwoPlayerChooseLevel */

    void SelectReturn(void)
    {
        GameInfo.PlayerAnzahl = TWO_PLAYER;
    	GameInfo.Module = INTRO_MAIN_MENU;
		InitMainButtons();
    } /* SelectReturn */

    void CheckSelectButtons(void)
    {
        int i, i2;

       // Pr�ft, ob sich die Maus auf einem Button befindet:
        for(i = 0; SelectButtons[i].SetX != -1; i++)
            if(CheckMouseRect(SelectButtons[i].X, SelectButtons[i].Y, SelectButtons[i].X+MAIN_BUTTON_B, SelectButtons[i].Y+MAIN_BUTTON_H) != NO_AKTIV)
                break;
        CheckButtonLight(&SelectButtons[0], i);
        if(i < 6)
        {
            if(Mouse.Button == LEFT_MOUSE_BUTTON && SelectButtons[i].Aktiv == YES)
            {
                if(SelectButtons[i].Funktion != 0)
                {
                    if(i == 0)
	                    DestroyIntroBitmaps();
                    SelectButtons[i].Funktion();
                    ExitModule = NO;
                    if(i == 0)
                    {
	                    InitIntro();
	                    LoadIntroBitmaps();
                    }
                }
            }
        }
        else
            for(i2 = 0; SelectButtons[i2].SetX != -1; i2++)
                SelectButtons[i2].Selected = NO;
    } /* CheckSelectButtons */
///////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////
//    Eigene Karte Ausw�hlen Funktionen:
///////////////////////////////////////////////////////////////////////////////////////
    void InitChooseButtons(void)
    {
        int i;

        for(i = 0; ChooseButtons[i].SetX != -1; i++)
        {
            ChooseButtons[i].Selected = NO;
            ChooseButtons[i].SelectedOn = NO;
            ChooseButtons[i].SelectedStep = 0;
        }
        ChooseButtons[0].X = 0;
        ChooseButtons[0].Y = 260;
        ChooseButtons[1].X = 0;
        ChooseButtons[1].Y = 280;
        ChooseButtons[2].X = 0;
        ChooseButtons[2].Y = 310;
        ChooseButtons[3].X = 0;
        ChooseButtons[3].Y = 340;
        Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].PixelPosX = -1;
        Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+1].PixelPosX = -1;
        Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+2].PixelPosX = -1;
        if(GameInfo.PlayerAnzahl == ONE_PLAYER)
        {
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].OnLive = YES;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].Fool_ID = MAX_INTRO_FOOLS+2;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].PixelPosX = 330;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].PixelPosY = 200;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].Animation = PUSH_DOWN;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].AnimationStep = 0;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].Richtung = WALK_DOWN;
      	}
      ///
        if(GameInfo.PlayerAnzahl == TWO_PLAYER)
        {
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].OnLive = YES;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].Fool_ID = MAX_INTRO_FOOLS+2;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].PixelPosX = 315;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].PixelPosY = 200;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].Animation = PUSH_RIGHT;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].AnimationStep = 0;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].Richtung = WALK_RIGHT;
          ///
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+1].OnLive = YES;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+1].Fool_ID = MAX_INTRO_FOOLS+3;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+1].PixelPosX = 345;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+1].PixelPosY = 200;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+1].Animation = PUSH_LEFT;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+1].AnimationStep = 0;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+1].Richtung = WALK_LEFT;
		}
        FindLevels();
    } /* InitChooseButtons */

    void ChooseStart(void)
    {
        Game(NO);
    } /* ChooseStart */

    void ChooseReturn(void)
    {
    	GameInfo.Module = INTRO_SELECT_MENU;
		InitSelectButtons();
    } /* ChooseReturn */

    void ChoosePageUp(void)
    {
    } /* ChoosePageUp */

    void ChoosePageDown(void)
    {
    } /* ChoosePageDown */

    void CheckChooseButtons(void)
    {
        int i, i2, y;

       // Pr�ft, ob sich die Maus auf einem Button befindet:
        for(i = 0; ChooseButtons[i].SetX != -1; i++)
            if(CheckMouseRect(ChooseButtons[i].X, ChooseButtons[i].Y, ChooseButtons[i].X+MAIN_BUTTON_B, ChooseButtons[i].Y+MAIN_BUTTON_H) != NO_AKTIV)
                break;
        CheckButtonLight(&ChooseButtons[0], i);
        if(i < 4)
        {
            if(Mouse.Button == LEFT_MOUSE_BUTTON && ChooseButtons[i].Aktiv == YES)
            {
                if(ChooseButtons[i].Funktion != 0)
                {
                    if(i == 0)
	                    DestroyIntroBitmaps();
                    ChooseButtons[i].Funktion();
                    ExitModule = NO;
                    if(i == 0)
                    {
	                    InitIntro();
	                    LoadIntroBitmaps();
                    }
                }
            }
        }
        else
            for(i2 = 0; ChooseButtons[i2].SetX != -1; i2++)
                ChooseButtons[i2].Selected = NO;
        if(CheckMouseRect(492, 250, 573, 333) != NO_AKTIV)
        {
            if(StretchMini == NO)
                CheckMouseButtonInfo(YES, 500, T_STRETCH_KARTE);
            if(Mouse.Button == LEFT_MOUSE_BUTTON)
            {
                if(StretchMini == NO)
                {
                    RECT rcRect, rcRect2;

                    if(TimerNew2 == YES)
                    {
                        TimerNew2 = NO;
                        StretchMini = YES;
                        SetRect(&rcRect, 0, 0, ScreenRes[0], ScreenRes[1]);
                        SetRect(&rcRect2, 0, 0, 80, 80);
                        MiniStretchBitmap->Blt(&rcRect, MiniPic, &rcRect2, NULL, NULL);
                    }
                }
			}
        }
        if(StretchMini == YES && Mouse.Button == LEFT_MOUSE_BUTTON)
        {
            if(TimerNew2 == YES)
            {
                TimerNew2 = NO;
                StretchMini = NO;
            }
        }
        if(CheckMouseRect(LEVEL_INFO_X, LEVEL_INFO_Y, LEVEL_INFO_X+30, LEVEL_INFO_Y+30) != NO_AKTIV && ChooseButtons[0].Aktiv == YES && StretchMini == NO)
        {
            CheckMouseButtonInfo(YES, 500, T_LEVEL_INFO);
        	if(Mouse.Button == LEFT_MOUSE_BUTTON)
            {
                GameInfo.Module = INTRO_LEVEL_INFO_MENU;
                InitLevelInfoButtons();
                ExitModule = NO;
			}
        }
        if(CheckMouseRect(CHOOSE_WINDOW_X, CHOOSE_WINDOW_Y, CHOOSE_WINDOW_X+CHOOSE_WINDOW_B, CHOOSE_WINDOW_Y+CHOOSE_WINDOW_H) != NO_AKTIV && StretchMini == NO)
        {
            CheckMouseButtonInfo(YES, 500, T_CHOOSE_LEVEL);
        	if(Mouse.Button == LEFT_MOUSE_BUTTON)
            {
                for(i = 0, y = 0;; i++, y += Font[3].FontB+20)
                {
                    if(SzenarioPaths[i].PathName[0] == EOF || i > MAX_PATHS)
                        break;
                    if(CheckMouseRect(CHOOSE_WINDOW_X+5, CHOOSE_WINDOW_Y+y+5, CHOOSE_WINDOW_X+CHOOSE_WINDOW_B, CHOOSE_WINDOW_Y+y+Font[3].FontH+20) != NO_AKTIV)
                    {
                        GameInfo.SelectedPath = i;
                        LoadLevel(SzenarioPaths[i].PathName);
                        GameInfo.SelectedPath = i;
                        stpcpy(GameInfo.AktuellesLevel, SzenarioPaths[i].PathName);
                        for(i = 0; i < MAX_INTRO_FOOLS; i++)
                        {
                            Szenario.Info.FoolInfo[i].OnLive = YES;
                            Szenario.Info.FoolInfo[i].Fool_ID = i;
                            Szenario.Info.FoolInfo[i].PixelPosX = FoolsInfo[i][0];
                            Szenario.Info.FoolInfo[i].PixelPosY = FoolsInfo[i][1];
                            Szenario.Info.FoolInfo[i].Animation = FoolsInfo[i][4];
                            Szenario.Info.FoolInfo[i].AnimationStep = random((MAX_FOOL_ANIMATION*2));
                            Szenario.Info.FoolInfo[i].Richtung = Szenario.Info.FoolInfo[i].Animation;
                        }
                        InitChooseButtons();
                        DrawMini();
                    }
                }
			}
        }
        if(GameInfo.SelectedPath != NO_AKTIV)
			ChooseButtons[0].Aktiv = YES;
        else
			ChooseButtons[0].Aktiv = NO;
    } /* CheckChooseButtons */
///////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////
//    Karten Informationen:
///////////////////////////////////////////////////////////////////////////////////////
    void InitLevelInfoButtons(void)
    {
        int i, i2, i3;

        for(i = 0, i3 = 0; i < 3; i++)
            for(i2 = 0; i2 < 3; i2++, i3++)
            {
                GameInfo.GameListe.CommandsMenu.CommandsButtonDown[i3] = NO;
                GameInfo.GameListe.CommandsMenu.CommandsButtonX[i3] = (int)25+(i2*35);
                GameInfo.GameListe.CommandsMenu.CommandsButtonY[i3] = (int)310+(i*35);
            }
        Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].PixelPosX = -1;
        Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+1].PixelPosX = -1;
        Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+2].PixelPosX = -1;
        if(GameInfo.PlayerAnzahl == ONE_PLAYER)
        {
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].OnLive = YES;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].Fool_ID = MAX_INTRO_FOOLS+2;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].PixelPosX = 330;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].PixelPosY = 200;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].Animation = PUSH_DOWN;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].AnimationStep = 0;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].Richtung = WALK_DOWN;
      	}
      ///
        if(GameInfo.PlayerAnzahl == TWO_PLAYER)
        {
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].OnLive = YES;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].Fool_ID = MAX_INTRO_FOOLS+2;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].PixelPosX = 315;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].PixelPosY = 200;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].Animation = PUSH_RIGHT;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].AnimationStep = 0;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS].Richtung = WALK_RIGHT;
          ///
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+1].OnLive = YES;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+1].Fool_ID = MAX_INTRO_FOOLS+3;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+1].PixelPosX = 345;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+1].PixelPosY = 200;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+1].Animation = PUSH_LEFT;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+1].AnimationStep = 0;
            Szenario.Info.FoolInfo[MAX_INTRO_FOOLS+1].Richtung = WALK_LEFT;
		}
    } /* InitLevelInfoButtons */

    void LevelInfoReturn(void)
    {
    	GameInfo.Module = INTRO_CHOOSE_MENU;
		InitChooseButtons();
    } /* LevelInfoReturn */

    void CheckLevelInfoButtons(void)
    {
        int i, i2;

        for(i = 0; i < 9; i++)
            if(CheckMouseRect(GameInfo.GameListe.CommandsMenu.CommandsButtonX[i], GameInfo.GameListe.CommandsMenu.CommandsButtonY[i], GameInfo.GameListe.CommandsMenu.CommandsButtonX[i]+32, GameInfo.GameListe.CommandsMenu.CommandsButtonY[i]+32) != NO_AKTIV)
                CheckMouseButtonInfo(YES, 500, T_UNTERMENU_FIRST_COMMAND+i);
        if(CheckMouseRect(492, 250, 573, 333) != NO_AKTIV)
	    {
            if(StretchMini == NO)
                CheckMouseButtonInfo(YES, 500, T_STRETCH_KARTE);
            if(Mouse.Button == LEFT_MOUSE_BUTTON)
            {
                if(StretchMini == NO)
                {
                    RECT rcRect, rcRect2;

                    if(TimerNew2 == YES)
                    {
                        TimerNew2 = NO;
                        StretchMini = YES;
                        SetRect(&rcRect, 0, 0, ScreenRes[0], ScreenRes[1]);
                        SetRect(&rcRect2, 0, 0, 80, 80);
                        MiniStretchBitmap->Blt(&rcRect, MiniPic, &rcRect2, NULL, NULL);
                    }
                }
            }
        }
        if(StretchMini == YES && Mouse.Button == LEFT_MOUSE_BUTTON)
        {
            if(TimerNew2 == YES)
            {
                TimerNew2 = NO;
                StretchMini = NO;
            }
        }
       // Pr�ft, ob sich die Maus auf einem Button befindet:
        if(CheckMouseRect(20, 280, 50, 300) != NO_AKTIV)
        {
            switch(GameInfo.LimitedTime)
            {
                case YES: CheckMouseButtonInfo(YES, 500, T_UNTERMENU_TIME_YES); break;
                case NO: CheckMouseButtonInfo(YES, 500, T_UNTERMENU_TIME_NO); break;
                case USER: CheckMouseButtonInfo(YES, 500, T_UNTERMENU_TIME_USER); break;
            }
            if(Mouse.Button == LEFT_MOUSE_BUTTON && Szenario.Info.LimitedTime == USER)
            {
                if(TimerNew2 == YES)
                {
                    TimerNew2 = NO;
                    if(GameInfo.LimitedTime == YES)
                        GameInfo.LimitedTime = NO;
                    else
                        GameInfo.LimitedTime = YES;
                }
            }
        }
        for(i = 0; LevelInfoButtons[i].SetX != -1; i++)
            if(CheckMouseRect(LevelInfoButtons[i].X, LevelInfoButtons[i].Y, LevelInfoButtons[i].X+MAIN_BUTTON_B, LevelInfoButtons[i].Y+MAIN_BUTTON_H) != NO_AKTIV)
                break;
        CheckButtonLight(&LevelInfoButtons[0], i);
        if(i < 1)
        {
            if(Mouse.Button == LEFT_MOUSE_BUTTON && LevelInfoButtons[i].Aktiv == YES)
            {
                if(LevelInfoButtons[i].Funktion != 0)
                {
                    LevelInfoButtons[i].Funktion();
                    ExitModule = NO;
                }
            }
        }
        else
            for(i2 = 0; LevelInfoButtons[i2].SetX != -1; i2++)
                LevelInfoButtons[i2].Selected = NO;
    } /* CheckLevelInfoButtons */
///////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////
//    About Informationen:
///////////////////////////////////////////////////////////////////////////////////////
    void InitAboutInfoButtons(void)
    {
    } /* InitAboutInfoButtons */

    void AboutInfoReturn(void)
    {
    	GameInfo.Module = INTRO_MAIN_MENU;
		InitMainButtons();
    } /* AboutInfoReturn */

    void CheckAboutInfoButtons(void)
    {
        int i, i2;

       // Pr�ft, ob sich die Maus auf einem Button befindet:
        for(i = 0; AboutInfoButtons[i].SetX != -1; i++)
            if(CheckMouseRect(AboutInfoButtons[i].X, AboutInfoButtons[i].Y, AboutInfoButtons[i].X+MAIN_BUTTON_B, AboutInfoButtons[i].Y+MAIN_BUTTON_H) != NO_AKTIV)
                break;
        CheckButtonLight(&AboutInfoButtons[0], i);
        if(i < 1)
        {
            if(Mouse.Button == LEFT_MOUSE_BUTTON && AboutInfoButtons[i].Aktiv == YES)
            {
                if(AboutInfoButtons[i].Funktion != 0)
                {
                    AboutInfoButtons[i].Funktion();
                    ExitModule = NO;
                }
            }
        }
        else
            for(i2 = 0; AboutInfoButtons[i2].SetX != -1; i2++)
                AboutInfoButtons[i2].Selected = NO;
    } /* CheckAboutInfoButtons */
///////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////
//    Game Out Informationen:
///////////////////////////////////////////////////////////////////////////////////////
    void InitGameOutButtons(void)
    {
    } /* InitGameOutButtons */

    void GameOutReturn(void)
    {
        ExitModule = YES;
    } /* GameOutReturn */

    void CheckGameOutButtons(void)
    {
        int i, i2;

       // Pr�ft, ob sich die Maus auf einem Button befindet:
        for(i = 0; GameOutButtons[i].SetX != -1; i++)
            if(CheckMouseRect(GameOutButtons[i].X, GameOutButtons[i].Y, GameOutButtons[i].X+MAIN_BUTTON_B, GameOutButtons[i].Y+MAIN_BUTTON_H) != NO_AKTIV)
                break;
        CheckButtonLight(&GameOutButtons[0], i);
        if(i < 1)
        {
            if(Mouse.Button == LEFT_MOUSE_BUTTON && GameOutButtons[i].Aktiv == YES)
            {
                if(GameOutButtons[i].Funktion != 0)
                    GameOutButtons[i].Funktion();
            }
        }
        else
            for(i2 = 0; GameOutButtons[i2].SetX != -1; i2++)
                GameOutButtons[i2].Selected = NO;
    } /* CheckGameOutButtons */
///////////////////////////////////////////////////////////////////////////////////////

void RestoreIntroSurfaces(void)
{
    Back->Restore();
    Primary->Restore();
    BackPic->Restore();
    Mouse.Pic->Restore();
    MiniPic->Restore();
    FoolSelectedPic->Restore();
    FoolAniPic->Restore();
    GameListPic->Restore();
    MeldungPic->Restore();
    CommandMenuAniPic->Restore();
    BefehlePic->Restore();
    Font[0].FontPic->Restore();
    Font[1].FontPic->Restore();
    Font[2].FontPic->Restore();
    Font[3].FontPic->Restore();
} /* RestoreIntroSurfaces */


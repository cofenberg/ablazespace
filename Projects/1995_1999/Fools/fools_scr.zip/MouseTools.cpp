#include "Global.h"

void SetMouseCursorPic(void);
void SetMouseBound(int, int, int, int);
void SetMousePos(int, int);
void SetMouseStyle(int, int, int, int, int, int, int, int);

void LoadMouseCursorsPic(void);
void DestroyMouseCursorsPic(void);
void CheckMouseAni(void);

void CheckButtonLight(struct ANIMATE_BUTTON *, int);
void CheckMouseButtonInfo(int, int, int);

#define MAX_FONTS 5
struct FONT
{
    int MaxXZeichen, MaxYZeichen; // Maximale Zeichen pro Spalte...
    int FontB, FontH; // Die gr��e der Schrift
	LPDIRECTDRAWSURFACE FontPic; // Die Schriftart
};

extern struct FONT Font[MAX_FONTS];

struct MOUSE Mouse =
{
	NORMAL_MOUSE_STYLE, 25, 25, YES, 0, 0, ScreenRes[0]-1, ScreenRes[1]-1, ScreenRes[0]-1, ScreenRes[1]-1, 0, 0, 0, NO, 0, 0, NO_AKTIV,
};

void LoadMouseCursorsPic(void)
{
    Mouse.Pic = DDLoadBitmap(lpDD, "Bilder/Mouse.bmp", 0, 0, YES);
    DDSetColorKey(Mouse.Pic, 5);
    Mouse.ButtonHelpText = NO_AKTIV;
} /* LoadMouseCursorsPic */

void DestroyMouseCursorsPic(void)
{
    Mouse.Pic->Restore();
} /* DestroyMouseCursorsPic */

void SetMouseCursorPic(void)
{
    RECT rcRect;
    int x, i;

    CheckMouseButtonInfo(NO, NO_AKTIV, NO_AKTIV);
    if(Mouse.Show == NO)
    	return;
    for(x = 1, i = 0; i < Mouse.Style; x += Mouse.CursorB+1, i++);
    rcRect.left   = x;
    rcRect.top    = Mouse.AniStep*(Mouse.CursorH+1)+1;
    if(Mouse.XPos > ScreenRes[0]-Mouse.CursorB)
		rcRect.right = x+ScreenRes[0]-Mouse.XPos;
    else
        rcRect.right  = x+Mouse.CursorB;
    if(Mouse.YPos > ScreenRes[1]-Mouse.CursorH)
		rcRect.bottom = (Mouse.AniStep*(Mouse.CursorH+1)+1)+ScreenRes[1]-Mouse.YPos;
    else
        rcRect.bottom = Mouse.AniStep*(Mouse.CursorH+1)+Mouse.CursorH+1;
    if(ProgrammSetup.MouseSpur == YES)
    {
        int MouseButtonTimer;
        static int MouseButtonLastTimer = 0;

        if(Mouse.VorLastXPos != NO_AKTIV && Mouse.VorLastYPos != NO_AKTIV)
            Back->BltFast(Mouse.VorLastXPos, Mouse.VorLastYPos, Mouse.Pic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        if(Mouse.LastXPos != NO_AKTIV && Mouse.LastYPos != NO_AKTIV)
            Back->BltFast(Mouse.LastXPos, Mouse.LastYPos, Mouse.Pic, &rcRect, DDBLTFAST_SRCCOLORKEY);
        MouseButtonTimer = timeGetTime()-MouseButtonLastTimer;
        if(MouseButtonTimer > 50)
        {
            MouseButtonLastTimer = timeGetTime();
            if(Mouse.VorLastXPos == NO_AKTIV && Mouse.VorLastYPos == NO_AKTIV)
            {
                Mouse.LastXPos = NO_AKTIV;
                Mouse.LastYPos = NO_AKTIV;
            }
            Mouse.VorLastXPos = NO_AKTIV;
            Mouse.VorLastYPos = NO_AKTIV;
        }
    }
	Back->BltFast(Mouse.XPos, Mouse.YPos, Mouse.Pic, &rcRect, DDBLTFAST_SRCCOLORKEY);
    if(Mouse.ButtonHelpText != NO_AKTIV)
	    PrintTextNo_Trans(Mouse.XPos, Mouse.YPos+10, GameTexte[Mouse.ButtonHelpText], 1, 0, Font[1].MaxXZeichen, Font[1].MaxYZeichen, Back);
} /* SetMouseCursorPic */

void SetMouseBound(int x, int y, int xb, int yh)
{
	Mouse.BoundX = x;
	Mouse.BoundY = y;
	Mouse.BoundXB = xb;
	Mouse.BoundYH = yh;
} /* SetMouseBound */

void SetMousePos(int x, int y)
{
	Mouse.XPos = x;
	Mouse.YPos = y;
} /* SetMousePos */

void SetMouseStyle(int Style, int Animated, int AniSpeed, int Timer, int AniStep, int AniMaxStep, int AniBackPlay, int PlayTurn)
{
    if(Style != NO_AKTIV)
		Mouse.Style = Style;
    if(Animated != NO_AKTIV)
		Mouse.Animated = Animated;
    if(AniSpeed != NO_AKTIV)
		Mouse.AniSpeed = AniSpeed;
    if(AniStep != NO_AKTIV)
		Mouse.AniStep = AniStep;
    if(AniMaxStep != NO_AKTIV)
		Mouse.AniMaxStep = AniMaxStep;
    if(AniBackPlay != NO_AKTIV)
		Mouse.AniBackPlay = AniBackPlay;
    if(PlayTurn != NO_AKTIV)
		Mouse.PlayTurn = PlayTurn;
    if(Timer != NO_AKTIV)
		Mouse.Timer = Timer;
} /* SetMouseStyle */

// Maus Animation:
void CheckMouseAni(void)
{
    int Timer;
    static int LastTimer = 0;

    Timer = timeGetTime()-LastTimer;
    if(Timer < Mouse.AniSpeed)
    	return;
    LastTimer = timeGetTime();
    if(Mouse.Animated == YES)
    {
        switch(Mouse.PlayTurn)
        {
            case 0:
                if(Mouse.AniStep < Mouse.AniMaxStep)
                    Mouse.AniStep++;
                else
                    if(Mouse.AniBackPlay == YES)
                        Mouse.PlayTurn = 1;
                    else
                        Mouse.AniStep = 0;
            break;

            case 1:
                if(Mouse.AniStep > 0)
                    Mouse.AniStep--;
                else
                    if(Mouse.AniBackPlay == YES)
                        Mouse.PlayTurn = 0;
                    else
                        Mouse.AniStep = 0;
            break;
        }
	}
} /* CheckMouseAni */

void CheckButtonLight(struct ANIMATE_BUTTON *Button, int FoundButton)
{
    int i, i2;

    if(Button[FoundButton].SelectedOn == NO && Button[FoundButton].Aktiv == YES)
    {
        for(i2 = 0; Button[i2].SetX != -1; i2++)
            Button[i2].Selected = NO;
        Button[FoundButton].Selected = YES;
        Button[FoundButton].SelectedOn = YES;
        Button[FoundButton].SelectedStep = 0;
    }
    for(i = 0; Button[i].SetX != -1; i++)
    {
        // Ver�ndert die Animation:
        if(Button[i].Selected == YES &&
            Button[i].SelectedOn == YES)
        {
            Button[i].SelectedStep++;
            if(Button[i].SelectedStep > 7)
                Button[i].SelectedStep -= 2;
        }
       // Pr�ft, ob eine Button animation wieder zur�ck gehen soll:
        if(Button[i].Selected == NO &&
            Button[i].SelectedOn == YES)
        {
            Button[i].SelectedStep--;
            if(Button[i].SelectedStep <= 0)
                Button[i].SelectedOn = NO;
        }
    }
} /* CheckButtonLight */

void CheckMouseButtonInfo(int NewButton, int WTime, int ButtonText2)
{
    int Timer;
    static int LastTimer = 0, WaitTime = 0, ButtonText, LastNewButton;

	if(NewButton == YES)
    {
		LastNewButton = NewButton;
	    if(ButtonText != ButtonText2)
        {
            LastTimer = timeGetTime();
            WaitTime = WTime;
            Mouse.ButtonHelpText = NO_AKTIV;
            ButtonText = ButtonText2;
            return;
        }
        Timer = timeGetTime()-LastTimer;
        if(Timer < WaitTime)
            return;
        // Gut der Hilfe text soll nun angezeigt werden:
    	if(ProgrammSetup.MouseHelp == YES)
	        Mouse.ButtonHelpText = ButtonText;
		return;
	}
    if(LastNewButton != NO_AKTIV)
	{
        LastNewButton = NO_AKTIV;
		return;
    }
    Mouse.ButtonHelpText = NO_AKTIV;
} /* CheckMouseButtonInfo */


#define BAR_DISPLAY_X 100
#define BAR_DISPLAY_Y 100

void HelpTextMenu(void);
void HelpTipsMenu(void);
void HelpKeyMenu(void);
void AboutMenu(void);
////////////////////////////////////////////////////////////////////////////////
void DrawBarFunktionenMenu(int);
void DrawHelpTextMenu(void);
void DrawHelpTipsMenu(void);
void DrawHelpKeyMenu(void);
void DrawAboutMenu(void);
////////////////////////////////////////////////////////////////////////////////

extern LPDIRECTDRAWSURFACE BackPic;

void HelpTextMenu(void)
{
    if(ProgrammModule != HELP_TEXT_MENU && ProgrammModule != ABOUT_MENU && ProgrammModule != HELP_KEY_MENU && ProgrammModule != HELP_TIPS_MENU)
		SavedProgrammModule = ProgrammModule;
	ProgrammModule = HELP_TEXT_MENU;
} /* HelpTextMenu */

void HelpTipsMenu(void)
{
    if(ProgrammModule != HELP_TEXT_MENU && ProgrammModule != ABOUT_MENU && ProgrammModule != HELP_KEY_MENU && ProgrammModule != HELP_TIPS_MENU)
		SavedProgrammModule = ProgrammModule;
	ProgrammModule = HELP_TIPS_MENU;
} /* HelpTipsMenu */

void HelpKeyMenu(void)
{
    if(ProgrammModule != HELP_TEXT_MENU && ProgrammModule != ABOUT_MENU && ProgrammModule != HELP_KEY_MENU && ProgrammModule != HELP_TIPS_MENU)
		SavedProgrammModule = ProgrammModule;
	ProgrammModule = HELP_KEY_MENU;
} /* HelpKeyMenu */

void AboutMenu(void)
{
    if(ProgrammModule != HELP_TEXT_MENU && ProgrammModule != ABOUT_MENU && ProgrammModule != HELP_KEY_MENU && ProgrammModule != HELP_TIPS_MENU)
		SavedProgrammModule = ProgrammModule;
	ProgrammModule = ABOUT_MENU;
} /* AboutMenu */

////////////////////////////////////////////////////////////////////////////////
/////// Malt die aufgerufenen Bar Funktionen:
void DrawBarFunktionenMenu(int Module)
{
    switch(Module)
    {
        case HELP_TEXT_MENU:
            DrawHelpTextMenu();
        break;

        case HELP_TIPS_MENU:
            DrawHelpTipsMenu();
        break;

        case HELP_KEY_MENU:
            DrawHelpKeyMenu();
        break;

        case ABOUT_MENU:
            DrawAboutMenu();
        break;
	}
} /* DrawBarFunktionenMenu */

void DrawHelpTextMenu(void)
{
    PrintText(BAR_DISPLAY_X+20, BAR_DISPLAY_Y, "Hilfe Text", 0, 0, 1000, 1000, Back);
    PrintText(BAR_DISPLAY_X+10, BAR_DISPLAY_Y+30,
    "Spielregeln:                                      "
    "Accidental War ist ein  nicht besonderts schweres "
    "'Ich werde die Welt erobern' Spielchen. Obwohl    "
    "der Begriff schwer wohl etwas fehl am platze ist. "
    "Oh, Sie m�ssenschon minimale logische Taktiken    "
    "anwenden, aber allgemeingesehenh�ngt eigentlich   "
    "alles vom zufall ab."
    , 1, 0, 61, 30, Back);
    PrintText(300, 420, GameTexte[T_ZURUECK], 0, 0, 1000, 1000, Back);
}

void DrawHelpTipsMenu(void)
{
    PrintText(BAR_DISPLAY_X+20, BAR_DISPLAY_Y, "Tips Text", 0, 0, 1000, 1000, Back);
    PrintText(BAR_DISPLAY_X+10, BAR_DISPLAY_Y+30,
    "- lassen Sie ihr Vaterland unter keinen unstand   "
    "  unbesch�tzt.                                    "
    "- wenn Sie angreifen, dann aber richtig, so, dass "
    "  der Gegenspieler kaum noch eine Chance hat, sein"
    "  Land wieder aufzur�sten!                        "
    "- nutzen Sie Atombomben nur im �ustersten Notfall,"
    "  denn das Land ist dannach f�r 20 Spielrunden    "
    "  nicht mehr nutzbar!                             "
    "- versuchen Sie kein Land unbesch�tzt zu lassen,  "
    "  stationieren Sie aber niemals zu viele Truppen  "
    "  in einem Land, da so en Auflauf recht schmack-  "
    "  hauft f�r eine Atomare Spaltung ist, und Sie    "
    "  dann sehr stark geschw�cht werden k�nnen!       "
    "- versuchen Sie immer m�glichst das Hauptland des "
    "  Gegners anzivisieren.                           "
    , 1, 0, 61, 1000, Back);
    PrintText(300, 420, GameTexte[T_ZURUECK], 0, 0, 1000, 1000, Back);
} /* DrawHelpTipsMenu */

void DrawHelpKeyMenu(void)
{
    PrintText(BAR_DISPLAY_X+20, BAR_DISPLAY_Y, "Tastatur Text", 0, 0, 1000, 1000, Back);
    PrintText(BAR_DISPLAY_X+10, BAR_DISPLAY_Y+30,
    "F12: Programm beenden                             "
    , 1, 0, 61, 30, Back);
    PrintText(300, 420, GameTexte[T_ZURUECK], 0, 0, 1000, 1000, Back);
} /* DrawHelpKeyMenu */

void DrawAboutMenu(void)
{
    RECT rcRect;

    PrintText(BAR_DISPLAY_X+20, BAR_DISPLAY_Y, "About:", 0, 0, 1000, 1000, Back);
    PrintText(BAR_DISPLAY_X+130, BAR_DISPLAY_Y+20, "Accidental War  1998:", 0, 0, 1000, 1000, Back);
    PrintText(BAR_DISPLAY_X+140, BAR_DISPLAY_Y+40, "von Christian Ofenberg", 0, 0, 1000, 1000, Back);
    PrintText(BAR_DISPLAY_X+130, BAR_DISPLAY_Y+80, "Mozart str. 9", 0, 0, 1000, 1000, Back);
    PrintText(BAR_DISPLAY_X+130, BAR_DISPLAY_Y+100, "97990 Weikersheim", 0, 0, 1000, 1000, Back);
    PrintText(BAR_DISPLAY_X+130, BAR_DISPLAY_Y+120, "Tel: 97341/8684", 0, 0, 1000, 1000, Back);
    SetRect(&rcRect, 254, 191, 375, 336);
    Back->BltFast(BAR_DISPLAY_X, BAR_DISPLAY_Y+30, BackPic, &rcRect, FALSE);
    PrintText(300, 420, GameTexte[T_ZURUECK], 0, 0, 1000, 1000, Back);
} /* DrawAboutMenu */


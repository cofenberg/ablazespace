#define MAX_PATHS 30
struct PATHS
{
	char PathName[256];
};

extern void FindSzenarios(void);
extern void FindLevels(void);
extern void ChangeSzenario(void);
extern struct PATHS SzenarioPaths[MAX_PATHS];



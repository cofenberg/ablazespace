#define MAX_PATHS 30
struct PATHS
{
	char PathName[256];
};

extern struct PATHS SzenarioPaths[MAX_PATHS];
void FindSzenarios(void);
void FindLevels(void);
void ChangeSzenario(void);

// Sucht und merkt sich dann alle verf�gbaren Szenarios:
void FindSzenarios(void)
{
   struct ffblk Found;
   int done;
   int i = 0;

   done = findfirst("Szenarios/*.*", &Found, FA_DIREC);
   while(!done)
   {
      sprintf(SzenarioPaths[i++].PathName, "%s", Found.ff_name);
      done = findnext(&Found);
      if(i > MAX_PATHS)
      	break;
   }
   SzenarioPaths[i].PathName[0] = EOF;
} /* FindSzenarios */

void FindLevels(void)
{
   struct ffblk Found;
   int done;
   int i = 0;

   done = findfirst("Levels/*.lev", &Found, FA_RDONLY);
   while(!done)
   {
      sprintf(SzenarioPaths[i++].PathName, "%s", Found.ff_name);
      done = findnext(&Found);
      if(i > MAX_PATHS)
      	break;
   }
   SzenarioPaths[i].PathName[0] = EOF;
} /* FindLevels */

void ChangeSzenario(void)
{
} /* ChangeSzenario */

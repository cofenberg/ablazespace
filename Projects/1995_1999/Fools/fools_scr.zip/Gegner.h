void MoveGegner(void);

void MoveGegner(void)
{
	int i, zufall, x, y;
    int Timer;
    static int LastTimer = 0;

    Timer = timeGetTime()-LastTimer;
    if(Timer < ProgrammSetup.GameSpeed+30)
    	return;
    LastTimer = timeGetTime();
    for(i = 0; i < MAX_GEGNER; i++)
    {
    	if(Szenario.Info.GegnerInfo[i].OnLive == NO || Szenario.Info.GegnerInfo[i].Gegner_ID == NO_AKTIV)
    		continue;
        if(Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.GegnerInfo[i].PosX][Szenario.Info.GegnerInfo[i].PosY]].WallPic != NO_AKTIV &&
	        Szenario.Info.GegnerInfo[i].Animation != NOW_DIED)
        {
			Szenario.Info.GegnerInfo[i].LastWalk = YES;
			Szenario.Info.GegnerInfo[i].Animation = NOW_DIED;
			Szenario.Info.GegnerInfo[i].AnimationStep = 0;
            continue;
        }
		if(Szenario.Info.GegnerInfo[i].Animation == NOW_DIED)
        {
			Szenario.Info.GegnerInfo[i].AnimationStep++;
            if(Szenario.Info.GegnerInfo[i].AnimationStep > 18)
	        {
                Szenario.Info.GegnerInfo[i].OnLive = NO;
 	            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.GegnerInfo[i].PosX][Szenario.Info.GegnerInfo[i].PosY]].Besetzt = NO_AKTIV;
        	}
            continue;
        }
        if(Szenario.Info.GegnerInfo[i].AnimationTurn == 0)
        {
			Szenario.Info.GegnerInfo[i].AnimationStep++;
            if(Szenario.Info.GegnerInfo[i].AnimationStep > 8)
	            Szenario.Info.GegnerInfo[i].AnimationTurn = 1;
        }
        else
        {
			Szenario.Info.GegnerInfo[i].AnimationStep--;
            if(Szenario.Info.GegnerInfo[i].AnimationStep < 1)
	            Szenario.Info.GegnerInfo[i].AnimationTurn = 0;
        }
      /// Der Gegner verteilt Strom Schl�ge:
        if(Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.GegnerInfo[i].PosX-1][Szenario.Info.GegnerInfo[i].PosY]].Besetzt != NO_AKTIV &&
	        Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.GegnerInfo[i].PosX-1][Szenario.Info.GegnerInfo[i].PosY]].Besetzt < MAX_FOOLS)
        	Szenario.Info.FoolInfo[Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.GegnerInfo[i].PosX-1][Szenario.Info.GegnerInfo[i].PosY]].Besetzt].Power--;
        if(Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.GegnerInfo[i].PosX+1][Szenario.Info.GegnerInfo[i].PosY]].Besetzt != NO_AKTIV &&
	        Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.GegnerInfo[i].PosX+1][Szenario.Info.GegnerInfo[i].PosY]].Besetzt < MAX_FOOLS)
        	Szenario.Info.FoolInfo[Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.GegnerInfo[i].PosX+1][Szenario.Info.GegnerInfo[i].PosY]].Besetzt].Power--;
        if(Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.GegnerInfo[i].PosX][Szenario.Info.GegnerInfo[i].PosY-1]].Besetzt != NO_AKTIV &&
	        Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.GegnerInfo[i].PosX][Szenario.Info.GegnerInfo[i].PosY-1]].Besetzt < MAX_FOOLS)
        	Szenario.Info.FoolInfo[Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.GegnerInfo[i].PosX][Szenario.Info.GegnerInfo[i].PosY-1]].Besetzt].Power--;
        if(Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.GegnerInfo[i].PosX][Szenario.Info.GegnerInfo[i].PosY+1]].Besetzt != NO_AKTIV &&
	        Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.GegnerInfo[i].PosX][Szenario.Info.GegnerInfo[i].PosY+1]].Besetzt < MAX_FOOLS)
        	Szenario.Info.FoolInfo[Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.GegnerInfo[i].PosX][Szenario.Info.GegnerInfo[i].PosY+1]].Besetzt].Power--;
		//////////////
        if(Szenario.Info.GegnerInfo[i].Richtung != NO_AKTIV)
        {
            switch(Szenario.Info.GegnerInfo[i].Richtung)
            {
                case 0:
	                Szenario.Info.GegnerInfo[i].PixelPosX -= 2;
                    if(Szenario.Info.GegnerInfo[i].PixelPosX < 0)
						Szenario.Info.GegnerInfo[i].Richtung = NO_AKTIV;
                break;

                case 1:
	                Szenario.Info.GegnerInfo[i].PixelPosY -= 2;
                    if(Szenario.Info.GegnerInfo[i].PixelPosY < 0)
						Szenario.Info.GegnerInfo[i].Richtung = NO_AKTIV;
                break;

                case 2:
	                Szenario.Info.GegnerInfo[i].PixelPosX += 2;
                    if(Szenario.Info.GegnerInfo[i].PixelPosX > 0)
						Szenario.Info.GegnerInfo[i].Richtung = NO_AKTIV;
                break;

                case 3:
	                Szenario.Info.GegnerInfo[i].PixelPosY += 2;
                    if(Szenario.Info.GegnerInfo[i].PixelPosY > 0)
						Szenario.Info.GegnerInfo[i].Richtung = NO_AKTIV;
                break;
            }
        	continue;
        }
        zufall = random(7);
        switch(zufall)
        {
        	case 0:
                x = Szenario.Info.GegnerInfo[i].PosX-1;
                y = Szenario.Info.GegnerInfo[i].PosY;
            break;

        	case 1:
                x = Szenario.Info.GegnerInfo[i].PosX;
                y = Szenario.Info.GegnerInfo[i].PosY-1;
            break;

        	case 2:
                x = Szenario.Info.GegnerInfo[i].PosX+1;
                y = Szenario.Info.GegnerInfo[i].PosY;
            break;

        	case 3:
                x = Szenario.Info.GegnerInfo[i].PosX;
                y = Szenario.Info.GegnerInfo[i].PosY+1;
            break;

			default: continue;
        }
        if(x < 0 || y < 0 || x > Szenario.Info.KarteB || y > Szenario.Info.KarteH)
        	continue;
        if((Szenario.Info.Kachel[Szenario.PosInfo[x][y]].WallPic == NO_AKTIV ||
            Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Mask == TAXI_KACHEL_SCHALTER ||
            Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Mask == BEAMER) &&
           Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Besetzt == NO_AKTIV)
        {
            Szenario.Info.Kachel[Szenario.PosInfo[Szenario.Info.GegnerInfo[i].PosX][Szenario.Info.GegnerInfo[i].PosY]].Besetzt = NO_AKTIV;
            Szenario.Info.Kachel[Szenario.PosInfo[x][y]].Besetzt = i+MAX_FOOLS;
            switch(zufall)
            {
                case 0:
                    Szenario.Info.GegnerInfo[i].PixelPosX = KACHEL_B;
                    Szenario.Info.GegnerInfo[i].PixelPosY = 0;
					Szenario.Info.GegnerInfo[i].PosX--;
                break;

                case 1:
                    Szenario.Info.GegnerInfo[i].PixelPosX = 0;
                    Szenario.Info.GegnerInfo[i].PixelPosY = KACHEL_H;
					Szenario.Info.GegnerInfo[i].PosY--;
                break;

                case 2:
                    Szenario.Info.GegnerInfo[i].PixelPosX = -KACHEL_B;
                    Szenario.Info.GegnerInfo[i].PixelPosY = 0;
					Szenario.Info.GegnerInfo[i].PosX++;
                break;

                case 3:
                    Szenario.Info.GegnerInfo[i].PixelPosX = 0;
                    Szenario.Info.GegnerInfo[i].PixelPosY = -KACHEL_H;
					Szenario.Info.GegnerInfo[i].PosY++;
                break;
            }
            Szenario.Info.GegnerInfo[i].Richtung = zufall;
        }
    }
} /* MoveGegner */

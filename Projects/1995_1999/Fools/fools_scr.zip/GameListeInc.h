extern void InitGameListe(int);
#define GAME_SCENE 1
#define EDITOR_SCENE 2
extern void CheckGameListe(int);
extern void DrawGameListe(int);


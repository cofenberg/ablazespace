#define NO_MOUSE_BUTTON 0
#define LEFT_MOUSE_BUTTON 1
#define RIGHT_MOUSE_BUTTON 2
#define BOTH_MOUSE_BUTTON 3

#define NORMAL_MOUSE_STYLE 0
#define SCROLL_MOUSE_STYLE 1
#define NO_SCROLL_MOUSE_STYLE 2
#define LUPE_MOUSE_STYLE 3
#define INSPECT_MOUSE_STYLE 4

extern void SetMouseCursorPic(void);
extern void SetMouseBound(int, int, int, int);
extern void SetMousePos(int, int);
extern void SetMouseStyle(int, int, int, int, int, int, int, int);

extern void LoadMouseCursorsPic(void);
extern void DestroyMouseCursorsPic(void);
extern void CheckMouseAni(void);

extern int CheckMouseRect(int, int, int, int);
extern void CheckButtonLight(struct ANIMATE_BUTTON *, int);
extern void CheckMouseButtonInfo(int, int, int);

struct MOUSE
{
    int Style;
    int CursorB;
    int CursorH;
    int Show;
    // Die Mausbegrenzung:
    int BoundX, BoundY, BoundXB, BoundYH;
    // Der Status der Maus:
    int Button;
    int XPos;
    int YPos;
    int LastXPos;
    int LastYPos;
    int VorLastXPos;
    int VorLastYPos;
    int Animated;
    int AniSpeed;
    int Timer;
    int AniStep;
    int AniMaxStep;
    int AniBackPlay;
    int PlayTurn;
	LPDIRECTDRAWSURFACE Pic;
	int SelectedKachel;
	int ButtonHelpText;
};

extern struct MOUSE Mouse;


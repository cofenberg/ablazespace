////////////////////////////////////////////////////////////////////////////////////
#include <sys\stat.h>
#include <fcntl.h>
#include <io.h>
///////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <dos.h>
#include <dir.h>
///////////////////////////////////////////////////////////////////////////////////////
#define NAME "Fools"
#define TITLE "Fools"
#define MUTEX_NAME "FoolsMutex"
#define SETUP_FILE "Setup.dat"

///////////////////////////////////////////////////////////////////////////////////////
#include <ddraw.h>
#include <dinput.h>
#include "P-Tools/ddutil.h"    // Bitmap tools (Laden, bearbeiten)

#include <dsound.h>
#include "P-Tools/Sound/resource.h"
#include "P-Tools/Sound/Sound.h"
#include "P-Tools/Sound/Static.h"

#include "MouseTools.h"

#include "MessageGlobal.h"
///////////////////////////////////////////////////////////////////////////////////////
#include "Game.h"
#include "DefGameStructs.h"
///////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////
extern void (*CheckKeyModule)(WPARAM);
///////////////////////////////////////////////////////////////////////////////////////
extern BOOL gExclusive;
extern int ScreenRes[3];
extern struct PROGRAMM_SETUP ProgrammSetup;
extern char VersionsInfo[30];
extern int ProgrammModule, SavedProgrammModule;

extern LPDIRECTDRAWSURFACE     Back;      // DirectDraw back surface
extern LPDIRECTDRAW            lpDD;           // DirectDraw object
///////////////////////////////////////////////////////////////////////////////////////
extern int TimerNew;
extern int TimerNew2;

struct ANIMATE_BUTTON
{
	int X, Y, SetX, SetY, ButtonStep, ButtonTurn;
    int Selected, SelectedOn, SelectedStep;
    int LeftLight, RightLight;
    int Text;
    void (*Funktion)(void);
    int Aktiv;
};

#define TITEL_MENU 0

// Maximale Anzahl der Benutzbaren Texte:
#define MAX_GAME_TEXTE 200
#include "GameTexte.h" // Hier sind die Text inhalte festgelegt!
// Die Sprach, in der die Texte sind:
#define LANGUAGE_GERMAN 0
#define LANGUAGE_ENGLISH 1
extern char *GameTexte[MAX_GAME_TEXTE];
extern int LoadGameTexte(int);
extern int DestroyGameTexte(void);


Fools:

Quellcode:
Das Spiel wurde mit dem Compiler Borland C++ 5.01 geschrieben. Es sollte jedoch m�glich sein,
das Spiel auch problemlos mit einem anderen C++ Compiler zu �bersetzen.

Das Spiel ist das erste Windows Programm gewesen, au�erdem hatte ich damals noch nicht 
sonderlich viel Erfahrung im Programmieren. Deshalb ist der Programmaufbau und vor allem 
die Graphik Routinen nicht sonderlich beeindruckend. Jedoch kann man vielleicht so einiges 
aus meinen Fehlern lernen!


Rechtliches:
- Ich �bernehme keine Verantwortung f�r eventuelle Sch�den, die das Programm an ihnen 
  oder ihrem Computer verursacht.
- Fools ist FREEWARE und darf beliebig oft weiterkopiert werden und dazu erlaube ich es 
  sogar noch, das Programm nach belieben zu ver�ndern und auszuschlachten. 
- Haben Sie vor das Spiel zu vervollst�ndigen, so w�re es nett, wenn ich im Spiel erw�hnt werden
  w�rde, au�erdem k�nnten Sie mir Bescheid sagen! Ansonsten geh�rt das Spiel ihnen! 


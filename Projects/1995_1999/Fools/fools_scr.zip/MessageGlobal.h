extern int UserMessage(char *, int, int, int);

#define	OK_BUTTON 0
#define	YES_BUTTON 1
#define	NO_BUTTON 2


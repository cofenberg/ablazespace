Levels:
	Dead: 
	Ihre Fools sind auf einem Friedhof von Feinden eingekreist worden!
	Bringen Sie ein paar ihrer Sch�tzlinge durchs Tor um Verst�rkung 
	zu hohlen.

	Chicken:
	Sie wurden mit H�hnern verwechselt und eingesperrt, fliehen Sie!

	WAR!:
	Sie m�ssen die Gegnerische Stellung durchbrechen!

	Point:
	Sammeln Sie Punkte und verschwinden Sie dann, ehe der Gegner kommt!
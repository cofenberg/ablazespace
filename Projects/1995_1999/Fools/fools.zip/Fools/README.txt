Fools:

Rechtliches:
- Ich �bernehme keine Verantwortung f�r eventuelle Sch�den, die das Programm an       ihnen oder ihrem Computer verursacht.
- Fools ist FREEWARE und darf beliebig oft weiterkopiert werden und dazu erlaube ich es sogar noch, das Programm nach belieben zu ver�ndern und auszuschhlachten. 

Bitte lesen Sie f�r mehr Informationen Readme.doc!
Tastatur:
F1 = Spielgeschwindigkeit erh�hen
F2 = Spielgeschwindigkeit verlangsamen
F3 = �berdeckende W�nde an\aus
F4 = Level Animationen an\aus
F5 = Transparente Kachel Maus an\aus
F6 = Transparente Selectiere Fools an\aus
F9 = Bei Nachrricht zum Ort springen
F12 = Programm sofort verlassen
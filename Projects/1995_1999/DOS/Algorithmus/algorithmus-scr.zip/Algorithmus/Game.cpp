#include "Co_Tools/struct.h"

extern GXHEADER buttons_pic[5];
extern GXHEADER Main_pic, Options_pic;
extern GXHEADER Feld_pic_off, Feld_pic_on;
GXHEADER Feld_pic[2];

int Feld_info[100][10]; // 0 = x, 1 = y, 2 = an oder aus(nur f�r die Graphic),
int bisher, bis_max;  // der Spieler sucht eine reihenfolge, bisherige anzahl der aufeinanderfolgenden Felder
int Felder_liste[500][3];   // 0 = Kennzeichen richtigen des Feldes, farbe

extern void Save_Player_Setup(void);
extern void Draw_Back(int);
extern void abdunkeln(int);
extern void aufhellen(int);
extern void starm(struct STAR *);
void Main_Menu(void);
void Game(void);
void Stop_Game(void);
void Check_Feld_Mouse(void);
int suche_feld_button(void);
void init_Felder(void);
void Zeige_Feld(int);
void Neues_Feld_dazu(void);
void Zeige_Bis_Felder(int);
void Spiel_Ende(void);

extern struct GAME_INFO Game_info;
extern struct BIT_BUTTON bit_but_main_menu[];
extern struct STAR titel_star[];
extern struct PLAYER_SETUP Player_Setup;

struct BIT_BUTTON bit_but_spiel[] =
{
	{502, 62, 120, 25, 0, 1, Stop_Game, 1, "Das laufende Spiel beenden", 0, EXIT_ANI, ALT_S_KEY, 0},
	{140, 3, 235, 43, 0, 3, 0, 1, "Algorithmus 1998 von Christian Ofenberg", 0, AUGE_ANI, -1, 0},  // Info felder
	{16, 8, 120, 32, 0, 3, 0, 1, "Bisherige Felderanzahl", 0, HAMMER_ANI, -1, 0},
	{376, 8, 172, 32, 0, 3, 0, 1, "Ihre Punktezahl", 0, HAMMER_ANI, -1, 0},
	{999, 999, 999, 999, 999, 999, 0, 0, "", 0, 0, -1, 0},
};

void Stop_Game(void)
{
    end = 1;
}

void Game(void)
{
    int i, key;

    No_Show_mouse();
    bis_max = 0;
    bisher = 0;
    gxVirtualDisplay(&Main_pic, 0, 52, 0, 52, 478, 462, 0);
    gxVirtualDisplay(&buttons_pic[0], 0, 0, 502, 62, 622, 87, 0);
    gxVirtualDisplay(&buttons_pic[2], 0, 0, 498, 135, 618, 160, 0);
    gxVirtualDisplay(&buttons_pic[3], 0, 0, 499, 167, 619, 192, 0);
    gxVirtualDisplay(&buttons_pic[4], 0, 0, 502, 246, 621, 272, 0);
	init_Felder();
    gxVirtualDisplay(&Main_pic, 376, 8, 376, 8, 552, 40, 0);
    SetFont(1, grWHITE, grBLACK, txTRANS);
    sprintf(temp, "%d", Game_info.punkte);
    txPutString(temp, 495, 30);
    gxVirtualDisplay(&Main_pic, 16, 8, 16, 8, 136, 40, 0);
    SetFont(1, grWHITE, grBLACK, txTRANS);
    sprintf(temp, "%d", bis_max);
    txPutString(temp, 105, 30);
	for (i = 0; i < (Game_info.big*Game_info.big); i++)
    	Zeige_Feld(i);
    Neues_Feld_dazu();
    Show_mouse();
    for(;;)
    {
        starm(&titel_star[0]);
        CheckBitMouse(&bit_but_spiel[0]);
        Move_Mouse();
	    CheckSetupOptions();
        if(bioskey(1) != 0)
        {
            key = bioskey(0);
            Check_Key(key, &bit_but_spiel[0]);
        }
        Check_Feld_Mouse();
        if(end != 0)
            break;
    }
	gxDestroyVirtual(&Feld_pic[0]);
	gxDestroyVirtual(&Feld_pic[1]);
}

void Neues_Feld_dazu(void)
{
    int z;

    z = rand() % (Game_info.big*Game_info.big); // ein neues Feld hinzuf�gen
	Felder_liste[bis_max][0] = z;
    z = rand() % 100; // die Farbe des Feldes festlegen
    Felder_liste[bis_max][1] = (z+33);
    bis_max++;
    gxVirtualDisplay(&Main_pic, 16, 8, 16, 8, 136, 40, 0);
    gxVirtualDisplay(&Main_pic, 16, 8, 16, 8, 136, 40, 0);
    SetFont(1, grWHITE, grBLACK, txTRANS);
    sprintf(temp, "%d", bis_max);
    txPutString(temp, 105, 30);
	Zeige_Bis_Felder(NO);
}

void Zeige_Bis_Felder(int i) // i = 0 = spiel, 1 = verloren
{
    int c_red, c_blue, c_green;

    for(bisher = 0; bisher < bis_max; bisher++)
    {
        Feld_info[Felder_liste[bisher][0]][2] = 1;
        gxGetPaletteRGB(Felder_liste[bisher][1], &c_red, &c_blue, &c_green); // nim die farbe des Feldes
        gxSetPaletteRGB(250, c_red, c_blue, c_green);  // und setze die Farbe 250 auf die werte der gefundenen
       	Zeige_Feld(Felder_liste[bisher][0]);
        if(i == NO)
			WaitWBreak((Game_info.speed), NO);
        if(i == YES)
		{
        	if(WaitWBreak(10, 1) == YES)
            	return;
        }
        Feld_info[Felder_liste[bisher][0]][2] = 0;
        Zeige_Feld(Felder_liste[bisher][0]);
		WaitWBreak(2, NO);
        starm(&titel_star[0]);
        if(end != 0)
        	break;
	}
    bisher = 0;
}

void Check_Feld_Mouse(void)
{
    GXHEADER pic;
    int c_red, c_blue, c_green;
    int found_button = -1;

	if(co_Mouse.Mouse_on == 1)
	    grGetMousePos(&co_Mouse.mx, &co_Mouse.my);
	found_button = suche_feld_button();
	if(co_Mouse.Mouse_on == 1)
	   	co_Mouse.mb = grGetMouseButtons();
	if (co_Mouse.mb == grLBUTTON)
    {
		if(co_Mouse.Mouse_on == 1)
	    	co_Mouse.mb = grGetMouseButtons();
	    if(found_button != -1)
        {
	        co_Mouse.mb = 0;
            if(Felder_liste[bisher][0] == found_button) // ist das angew�hlte Feld korrekt?
            {
                No_Show_mouse();
                Feld_info[found_button][2]  = 1;
                gxGetPaletteRGB(Felder_liste[bisher][1], &c_red, &c_blue, &c_green); // nim die farbe des Feldes
                gxSetPaletteRGB(250, c_red, c_blue, c_green);  // und setze die Farbe 250 auf die werte der gefundenen
                Zeige_Feld(found_button);
                if(co_Mouse.Mouse_on == 1)
                    while(grGetMouseButtons())
                        starm(&titel_star[0]);
                if(co_Mouse.Joystick_on == 1)
                    for(;;)
                    {
                        starm(&titel_star[0]);
						if(joybutton() == 0)
                        	break;
                	}
                if(co_Mouse.Mouse_on == 0 && co_Mouse.Joystick_on == 0)
                	WaitWBreak(Game_info.speed, 0);
                Feld_info[found_button][2]  = 0;
                Zeige_Feld(found_button);
                // Zeige die Punkte
                gxVirtualDisplay(&Main_pic, 376, 8, 376, 8, 512, 40, 0);
                Game_info.punkte += ((Game_info.big*2)+Game_info.speed_punkte);
			    gxVirtualDisplay(&Main_pic, 376, 8, 376, 8, 552, 40, 0);
                SetFont(1, grWHITE, grBLACK, txTRANS);
                sprintf(temp, "%d", Game_info.punkte);
                txPutString(temp, 495, 30);
                bisher++;
                if(bisher > bis_max-1) // sind alle Bisherigen felder gefunden dann:
                    Neues_Feld_dazu();
                Show_mouse();
            }
            else  // Das Spiel ist beendet
            {
                No_Show_mouse();
                Feld_info[found_button][2]  = 1;
                gxSetPaletteRGB(250, 63, 0, 0);
                Zeige_Feld(found_button);
				WaitWBreak(5, NO);
                gxSetPaletteRGB(250, 0, 0, 0);
                Zeige_Feld(found_button);
				WaitWBreak(5, NO);
                gxSetPaletteRGB(250, 63, 0, 0);
                Zeige_Feld(found_button);
				WaitWBreak(5, NO);
                gxSetPaletteRGB(250, 0, 0, 0);
                Zeige_Feld(found_button);
				WaitWBreak(5, NO);
                Feld_info[found_button][2]  = 0;
                Zeige_Feld(found_button);
                gxCreateVirtual(gxEMM, &pic, Setup.gxtype, 350, 50);
                gxDisplayVirtual(70, 240, 420, 290, 0, &pic, 0, 0);
				SetFont(1, grWHITE, grBLACK, txTRANS);
                txPutString("Falsch!!!", 260, 255);
                txPutString("Diese Reihenfolge ist richtig:", 260, 270);
                if(co_Mouse.Mouse_on == 1)
                    while(grGetMouseButtons())
                        starm(&titel_star[0]);
                if(co_Mouse.Joystick_on == 1)
                    for(;;)
						if(joybutton() == 0)
                        	break;
                co_Mouse.mb = 0;
				WaitWBreak(40, YES);
                gxVirtualDisplay(&pic, 0, 0, 70, 240, 420, 290, 0);
       			gxDestroyVirtual(&pic);
                while(grGetMouseButtons())
	                grGetMouseButtons();
                co_Mouse.mb = 0;
				Zeige_Bis_Felder(YES);
				Spiel_Ende();
                end = 1;
                Show_mouse();
            }
    	}
	}
}

void Spiel_Ende(void)
{
    time_t timer;
    int platz, i, z;
    char best_name[30];
    long save_time;
    char text[30];
    int Vertig;

    No_Show_mouse();
    Draw_Back(0);
 	gxSetPaletteRGB(254, 0, 0, 0);
    end = 0;
	SetFont(1, 254, grBLACK, txTRANS);
    txPutString("Das Spiel ist Beendet. Sie erbeuteten", 320, 90);
    sprintf(temp, "aber ganze %d Punkte bei %d Feldern!", Game_info.punkte, bis_max);
	if(Player_Setup.punkte[4] == 0)
		if(Game_info.punkte == 0)
	    	sprintf(temp, "aber ganze %d Punkte bei %d Feldern!(eine Spitzenleistung!)", Game_info.punkte, bis_max);
    txPutString(temp, 320, 110);
    sprintf(temp, "");
    for(i = 0, platz = -1; i < 5; i++)
        if(Game_info.punkte >= Player_Setup.punkte[i])
        {
	        if(Game_info.punkte == Player_Setup.punkte[i])
            {
				if(bis_max < Player_Setup.Felder[i])
                	continue;
            }
            platz = i;
            i = 6;
        }
   	if(platz == -1 || Game_info.punkte == 0) // ale Eintr�ge der Besten sind besser als der Spieler:
    {
	    if(Game_info.punkte == 0)
        {
            txPutString("Mia Mama(oder so aehnlich) das war vieleicht *#�=(!!?*'�(Kein Druchkfehler)", 320, 230);
            txPutString("das musste ich jetzt einfach loswerden!", 320, 250);
            txPutString("Schaemen Sie sich!! Phui!!", 320, 280);
            txPutString("Beginnen Sie gleich nochmal ein Spiel, aber diesmal richtig!", 320, 320);
        }
        else
        {
            txPutString("Strengen Sie sich naechstes mal mehr an, damit Sie", 320, 230);
            sprintf(temp, "wenigstens '%s' der es auf", Player_Setup.best_5);
            txPutString(temp, 320, 250);
            sprintf(temp, "%d Punkte bei %d Feldern schaffte schlagen!", Player_Setup.punkte[4], Player_Setup.Felder[4]);
            txPutString(temp, 320, 270);
        }
        for(i = 0; i < 60; i += 1)
        {
            gxSetPaletteRGB(254, i, i, i);
            gxDelay(10);
        }
        gxDelay(800);
 		Warte_auf_Taste();
        for(i = 60; i > 0; i -= 1)
        {
            gxSetPaletteRGB(254, i, i, i);
            gxDelay(30);
        }
        return;
    }
    else
    {
        switch(platz)
        {
        	case 0:
	       		sprintf(temp, "Damit haben Sie '%s' der ", Player_Setup.best_1);
            	break;

        	case 1:
        		sprintf(temp, "Damit haben Sie '%s' der", Player_Setup.best_2);
            	break;

        	case 2:
        		sprintf(temp, "Damit haben Sie '%s' der", Player_Setup.best_3);
            	break;

        	case 3:
        		sprintf(temp, "Damit haben Sie '%s' der", Player_Setup.best_4);
            	break;

        	case 4:
        		sprintf(temp, "Damit haben Sie '%s' der", Player_Setup.best_5);
            	break;
        }
        txPutString(temp, 320, 190);
  		sprintf(temp, "es auf %d Punkte bei %d Feldern", Player_Setup.punkte[platz], Player_Setup.Felder[platz]);
        txPutString(temp, 320, 210);
        txPutString("brachte von seinem Platz verdraengt und sind nun", 320, 230);
        sprintf(temp ,"auf Position %d.", platz+1);
        txPutString(temp, 320, 270);
        txPutString("Herzlichen Glueckwunsch!!", 320, 310);
	    for(i = 0; i < 60; i += 1)
        {
            gxSetPaletteRGB(254, i, i, i);
            gxDelay(10);
        }
        gxDelay(1000);
        txPutString("Geben Sie bitte ihren Namen ein:", 320, 370);
    }
// Der Name des Spielers wird abgefragt:
    gxCreateVirtual(gxEMM, &Ein_pic, Setup.gxtype, 440, 30);
    gxDisplayVirtual(100, 380, 540, 410, 0, &Ein_pic, 0, 0);
    timer = time(NULL);
    save_time = timer;
    for(i = 0;;)
    {
        timer = time(NULL);
        if(save_time != timer)
        {
			save_time = timer;
            if(i == 0)
            {
				SetFont(1, grWHITE, grBLACK, txTRANS);
            	i = 1;
	        }
            else
            {
				SetFont(1, grDARKGRAY, grBLACK, txTRANS);
            	i = 0;
	        }
            txPutString("Geben Sie bitte ihren Namen ein:", 320, 370);
        }
      	strcpy(text, Eingabe(25, 310, 395, 100, 380, 540, 410, &Vertig));
    	if(Vertig != 0 || end != 0)
    		break;
    }
    gxDestroyVirtual(&Ein_pic);
	SetFont(1, 254, grBLACK, txTRANS);
    txPutString("Geben Sie bitte ihren Namen ein:", 320, 370);
    if(end == 0)
    {
        if(strlen(text) == 0)
        {
            z = rand() % 9;
            switch(z)
            {
                case 0:
                    strncpy(text, "Faulpelz", 10);
                    break;

                case 1:
                    strncpy(text, "Einfallsloss", 20);
                    break;

                case 2:
                    strncpy(text, "Speedy", 20);
                    break;

                case 3:
                    strncpy(text, "Big Key", 20);
                    break;

                case 4:
                    strncpy(text, "Anonym", 20);
                    break;

                case 5:
                    strncpy(text, "Big Flop", 20);
                    break;

                case 6:
                    strncpy(text, "Chippy", 20);
                    break;

                case 7:
                    strncpy(text, "Super Dau", 20);
                    break;

                case 9:
                    strncpy(text, "Multi Dump", 20);
                    break;

                case 10:
                    strncpy(text, "Monkey earth", 20);
                    break;
            }
            SetFont(1, grWHITE, grBLACK, txTRANS);
            txPutString(text, 310, 395);
        }
       	strncpy(best_name, text, 25); // Eingabe beendet.
	    gxDelay(1000);
        switch(platz)
        {
            case 0:
                strncpy(Player_Setup.best_5, Player_Setup.best_4, 25);
                Player_Setup.punkte[4] = Player_Setup.punkte[3];
	        	Player_Setup.Felder[4] = Player_Setup.Felder[3];
                strncpy(Player_Setup.best_4, Player_Setup.best_3, 25);
                Player_Setup.punkte[3] = Player_Setup.punkte[2];
	        	Player_Setup.Felder[3] = Player_Setup.Felder[2];
                strncpy(Player_Setup.best_3, Player_Setup.best_2, 25);
                Player_Setup.punkte[2] = Player_Setup.punkte[1];
	        	Player_Setup.Felder[2] = Player_Setup.Felder[1];
                strncpy(Player_Setup.best_2, Player_Setup.best_1, 25);  // Spieler wurden nach unten geschoben
                Player_Setup.punkte[1] = Player_Setup.punkte[0];
	        	Player_Setup.Felder[1] = Player_Setup.Felder[0];
                strncpy(Player_Setup.best_1, best_name, 25);
                Player_Setup.punkte[0] = Game_info.punkte;
                break;

            case 1:
                strncpy(Player_Setup.best_5, Player_Setup.best_4, 25);
                Player_Setup.punkte[4] = Player_Setup.punkte[3];
	        	Player_Setup.Felder[4] = Player_Setup.Felder[3];
                strncpy(Player_Setup.best_4, Player_Setup.best_3, 25);
                Player_Setup.punkte[3] = Player_Setup.punkte[2];
	        	Player_Setup.Felder[3] = Player_Setup.Felder[2];
                strncpy(Player_Setup.best_3, Player_Setup.best_2, 25);
                Player_Setup.punkte[2] = Player_Setup.punkte[1];
	        	Player_Setup.Felder[2] = Player_Setup.Felder[1];
                strncpy(Player_Setup.best_2, best_name, 25);
                Player_Setup.punkte[1] = Game_info.punkte;
                break;

            case 2:
                strncpy(Player_Setup.best_5, Player_Setup.best_4, 25);
                Player_Setup.punkte[4] = Player_Setup.punkte[3];
	        	Player_Setup.Felder[4] = Player_Setup.Felder[3];
                strncpy(Player_Setup.best_4, Player_Setup.best_3, 25);
                Player_Setup.punkte[3] = Player_Setup.punkte[2];
	        	Player_Setup.Felder[3] = Player_Setup.Felder[2];
                strncpy(Player_Setup.best_3, best_name, 25);
                Player_Setup.punkte[2] = Game_info.punkte;
                break;

            case 3:
                strncpy(Player_Setup.best_5, Player_Setup.best_4, 25);
                Player_Setup.punkte[4] = Player_Setup.punkte[3];
	        	Player_Setup.Felder[4] = Player_Setup.Felder[3];
                strncpy(Player_Setup.best_4, best_name, 25);
                Player_Setup.punkte[3] = Game_info.punkte;
                break;

            case 4:
                strncpy(Player_Setup.best_5, best_name, 25);
                Player_Setup.punkte[4] = Game_info.punkte;
                break;
        }
        Player_Setup.Felder[platz] = bis_max;
        Save_Player_Setup();
    }
    for(i = 60; i > 0; i -= 1)
	{
    	gxSetPaletteRGB(254, i, i, i);
    	gxDelay(30);
    }
    end = 0;
    co_Mouse.mx = bit_but_main_menu[0].x+90;
    co_Mouse.my = bit_but_main_menu[0].y+10;
    if(co_Mouse.Mouse_on == 1)
	    grSetMousePos(co_Mouse.mx, co_Mouse.my);
    Show_mouse();
}

int suche_feld_button(void)
{
    int i;

	for (i = 0; i < (Game_info.big*Game_info.big); i++)
		if ((co_Mouse.mx > Feld_info[i][0] && co_Mouse.mx < Feld_info[i][0]+Game_info.Feld_b &&
             co_Mouse.my > Feld_info[i][1] && co_Mouse.my < Feld_info[i][1]+Game_info.Feld_h))
            return(i);
	return(-1);
}

void init_Felder(void)
{
	int i, x, y, i_x, i_y;

	for (i = 0, i_y = 0, y = Game_info.Feld_y; i_y < Game_info.big; i_y++, y += Game_info.Feld_h)
    {
        for (i_x = 0, x = Game_info.Feld_x; i_x < Game_info.big; i_x++, i++, x += Game_info.Feld_b)
        {
        	Feld_info[i][0] = x;
        	Feld_info[i][1] = y;
        	Feld_info[i][2] = 0;
        }
    }
    gxCreateVirtual(gxEMM, &Feld_pic[0], Setup.gxtype, Game_info.Feld_b, Game_info.Feld_h);
    gxCreateVirtual(gxEMM, &Feld_pic[1], Setup.gxtype, Game_info.Feld_b, Game_info.Feld_h);
    gxVirtualScale(&Feld_pic_off, &Feld_pic[0]);
    gxVirtualScale(&Feld_pic_on, &Feld_pic[1]);
}

void Zeige_Feld(int i)
{
    gxVirtualVirtual(&Feld_pic[Feld_info[i][2]], 0, 0, Game_info.Feld_b, Game_info.Feld_h, &SV, Feld_info[i][0], Feld_info[i][1], gxSET);
    gxVirtualDisplay(&SV, Feld_info[i][0], Feld_info[i][1], Feld_info[i][0], Feld_info[i][1], Feld_info[i][0]+Game_info.Feld_b, Feld_info[i][1]+Game_info.Feld_h, 0);
}

#include "Co_Tools/struct.h"
#include "Co_Tools/MainPics.h"
#include "Co_Tools/About.h"
#include "Co_Tools/SetupOptions.h"

#define MENU_X 30
#define MENU_Y 90

char temp[100];

extern void Warte_auf_Taste(void);
extern void	Draw_Back(int);
extern void Game(void);
extern void Create_Mouse(void);
extern void	Save_Player_Setup(void);
extern void Fade_in(int);
extern void Fade_out(int);
extern void starm(struct STAR *);
void Losche_Best(void);
void Die_Besten_Spieler(void);
void Main_Menu(void);
void Main_End(void);
void Spielfeld_minus(void);
void Spielfeld_plus(void);
void Speed_minus(void);
void Speed_plus(void);
void Losche_Player_Setup(int);
void Set_Feld_Size(void);
void Speed_Size(void);
void Intro(void);

#include "star.h"

extern struct PLAYER_SETUP Player_Setup;
struct GAME_INFO Game_info = {4, 5, 0, 0, 0, 0, 0, 0};

struct BIT_BUTTON bit_but_main_menu[] =
{
	{502, 62, 120, 25, 0, 1, Game, 1, "Das Spiel starten", 0, NORMAL_ON, ALT_S_KEY, 0},
	{497, 135, 120, 25, 0, 0, SetupOptions, 1, "Einstellungen fuer fast alles  (Key: F5)", 0, HAMMER_ANI, ALT_E_KEY, 0},
	{498, 167, 120, 25, 0, 0, About, 1, "Ueber den Autor  (Key: F1)", 0, AUGE_ANI, ALT_I_KEY, 0},
	{502, 246, 120, 25, 0, 1, Main_End, 1, "Das Programm verlassen     (Key:  ESC, ALT-F4)", 0, EXIT_ANI, ALT_T_KEY, 0},
	{200, 400, 120, 25, 0, 0, Losche_Best, 1, "Alle Eintraege loeschen", 0, EIMER_ANI, ALT_L_KEY, 0},
	{MENU_X+322, MENU_Y+11, 43, 25, 0, 0, Spielfeld_minus, 1, "Weniger Felder", 0, PLEFT_ANI, -1, 1},
	{MENU_X+367, MENU_Y+11, 43, 25, 0, 1, Spielfeld_plus, 1, "Mehr Felder", 0, PRIGHT_ANI, -1, 1},
	{MENU_X+322, MENU_Y+48, 43, 25, 0, 0, Speed_minus, 1, "Schnelleres Aufblinken", 0, PLEFT_ANI, -1, 1},
	{MENU_X+367, MENU_Y+48, 43, 25, 0, 1, Speed_plus, 1, "Langsameres Aufblinken", 0, PRIGHT_ANI, -1, 1},
	{140, 3, 235, 43, 0, 3, About, 1, "Algorithmus 1998 von Christian Ofenberg", 0, AUGE_ANI, -1, 0},  // Info felder
	{16, 8, 120, 32, 0, 3, 0, 1, "Bisherige Felderanzahl", 0, HAMMER_ANI, -1, 0},
	{376, 8, 172, 32, 0, 3, 0, 1, "Ihre Punktezahl", 0, HAMMER_ANI, -1, 0},
	{999, 999, 999, 999, 999, 999, 0, 0, "", 0, 0, -1, 0},
};

void Losche_Player_Setup(int modus)
{
    int i;

    strncpy(Player_Setup.best_1, "Nobody", 20);
    strncpy(Player_Setup.best_2, "Nobody", 20);
    strncpy(Player_Setup.best_3, "Nobody", 20);
    strncpy(Player_Setup.best_4, "Nobody", 20);
    strncpy(Player_Setup.best_5, "Nobody", 20);
    for(i = 0; i < 5; i++)
    {
       Player_Setup.punkte[i] = 0;
       Player_Setup.Felder[i] = 0;
	}
    Save_Player_Setup();
    if(modus == 1) // 0 Modus nur zum Testen
	    Die_Besten_Spieler();
}

void Main_Menu(void)
{
    int i, key;
    time_t t;

	Create_Mouse();
	Lade_Main_Pics();
	srand((unsigned) time(&t)); // Der Zufallsgenerator wird gesetzt
    end = 0;
    pcxFileImage(gxEMM,"pic/algo_pi.pcx",&Main_pic, gxDETECT);
    Intro();
    gxVirtualDisplay(&Main_pic, 0, 0, 0, 0, 639, 479, 0);
    for(i = 0; titel_star[i].x != 999; i++)
        titel_star[i].ani = -1;
    Set_Feld_Size();
	Speed_Size();
    All_Keys = YES;
	SetMouseBounds(0, 0, 639, 479);
	co_Mouse.mx = bit_but_main_menu[0].x+90;
    co_Mouse.my = bit_but_main_menu[0].y+10;
    if(co_Mouse.Mouse_on == 1)
    	grSetMousePos(co_Mouse.mx, co_Mouse.my);
 	for(;;)
    {
         No_Show_mouse();
         Game_info.punkte = 0;
	     gxVirtualDisplay(&Main_pic, 0, 0, 0, 0, 639, 479, 0);
	     gxVirtualDisplay(&Options_pic, 0, 0, MENU_X, MENU_Y, MENU_X+426, MENU_Y+86, 0);
         if(Game_info.big < 3)
             gxVirtualDisplay(&L_R_Buttons[0], 0, 0, bit_but_main_menu[5].x+1, bit_but_main_menu[5].y+1, bit_but_main_menu[5].x+bit_but_main_menu[5].b+1, bit_but_main_menu[5].y+bit_but_main_menu[5].h, 0);
         else
        	gxVirtualDisplay(&Options_pic, 321, 12, bit_but_main_menu[5].x-1, bit_but_main_menu[5].y+1, bit_but_main_menu[5].x+bit_but_main_menu[5].b, bit_but_main_menu[5].y+bit_but_main_menu[5].h+1, 0);
         if(Game_info.big > 9)
             gxVirtualDisplay(&L_R_Buttons[1], 0, 0, bit_but_main_menu[6].x, bit_but_main_menu[6].y+1, bit_but_main_menu[6].x+bit_but_main_menu[6].b, bit_but_main_menu[6].y+bit_but_main_menu[6].h+1, 0);
         else
        	gxVirtualDisplay(&Options_pic, 367, 12, bit_but_main_menu[6].x, bit_but_main_menu[6].y+1, bit_but_main_menu[6].x+bit_but_main_menu[6].b, bit_but_main_menu[6].y+bit_but_main_menu[6].h+1, 0);
         if(Game_info.speed_step < 2)
             gxVirtualDisplay(&L_R_Buttons[0], 0, 0, bit_but_main_menu[7].x+1, bit_but_main_menu[7].y+1, bit_but_main_menu[7].x+bit_but_main_menu[7].b+1, bit_but_main_menu[7].y+bit_but_main_menu[7].h+1, 0);
         else
        	gxVirtualDisplay(&Options_pic, 321, 12, bit_but_main_menu[7].x-1, bit_but_main_menu[7].y+1, bit_but_main_menu[7].x+bit_but_main_menu[7].b, bit_but_main_menu[7].y+bit_but_main_menu[7].h+1, 0);
         if(Game_info.speed_step > 9)
             gxVirtualDisplay(&L_R_Buttons[1], 0, 0, bit_but_main_menu[8].x, bit_but_main_menu[8].y+1, bit_but_main_menu[8].x+bit_but_main_menu[8].b, bit_but_main_menu[8].y+bit_but_main_menu[8].h+1, 0);
         else
        	gxVirtualDisplay(&Options_pic, 367, 12, bit_but_main_menu[8].x, bit_but_main_menu[8].y+1, bit_but_main_menu[8].x+bit_but_main_menu[8].b, bit_but_main_menu[8].y+bit_but_main_menu[8].h+1, 0);
         SetFont(1, grDARKGRAY, grBLACK, txTRANS);
         txPutString("0000", 105, 30);
         txPutString("000000", 495, 30);
         SetFont(1, grWHITE, grBLACK, txTRANS);
         sprintf(temp, "%dx%d", Game_info.big, Game_info.big);
         txPutString(temp, MENU_X+255, MENU_Y+29);
         txPutString(temp, 555, 391); // Info anzeigen
         sprintf(temp, "%d", Game_info.speed_step);
         txPutString(temp, MENU_X+255, MENU_Y+67);
         txPutString(temp, 555, 454); // Info anzeigen
	     gxVirtualDisplay(&buttons_pic[1], 0, 0, bit_but_main_menu[4].x+1, bit_but_main_menu[4].y, bit_but_main_menu[4].x+bit_but_main_menu[4].b+1, bit_but_main_menu[4].x+bit_but_main_menu[4].h, 0);
		 bit_but_main_menu[0].an = 0;
	     co_Mouse.Mouse_style = NORMAL;
	     Die_Besten_Spieler();
         StarModule = TITELSTARS;
         end = 0;
	     gxDisplayVirtual(0, HELP_Y, 639, HELP_Y+25, 0, &SV, 0, HELP_Y);
         Show_mouse();
         for(;;)
         {
             starm(&titel_star[0]);
			 Move_Mouse();
			 CheckSetupOptions();
             CheckBitMouse(&bit_but_main_menu[0]);
             if(bioskey(1) != 0)
             {
                 key = bioskey(0);
		         Check_Key(key, &bit_but_main_menu[0]);
                 switch(key)
                 {
                     case ESC_KEY:
                         Ende(1);
                         break;
                 }
          	 }
             if(end != 0)
                 break;
         }
         if(end == 2)
          break;
    }
    No_Show_mouse();
    Destroy_Main_Pics();
    if(Setup.Mouse != 0)
		Player_Setup.Mouse_on = co_Mouse.Mouse_on;
    if(Setup.Joystick != 0)
		Player_Setup.Joystick_on = co_Mouse.Joystick_on;
	Save_Player_Setup();
	Fade_in(1);
    for(i = 0; i < 768; i++)
	    pal[i] = 63;
	Fade_out(1);
}

void Losche_Best(void)
{
    if(Yes_No_Check("Die Besten Spieler eliminieren?", 0) == 0)
      return;
	Losche_Player_Setup(1);
	Die_Besten_Spieler();
}

void Die_Besten_Spieler(void)
{
    int i, i2;

	No_Show_mouse();
    gxVirtualDisplay(&Main_pic, 0, 250, 0, 250, 478, 400, 0);
    SetFont(2, grWHITE, grBLACK, txTRANS);
    txPutString("Die Besten Spieler:", 280, 210);
    txPutString("Name:", 150, 235);
    txPutString("Punkte:", 320, 235);
    txPutString("Felder:", 420, 235);
    SetFont(1, grWHITE, grBLACK, txTRANS);
    for(i = 265, i2 = 0; i2 < 5; i += 30, i2++)
    {
	    sprintf(temp, "%d.", i2+1);
        txPutString(temp, 30, i);
        sprintf(temp, "%d", Player_Setup.punkte[i2]);
        txPutString(temp, 315, i);
        sprintf(temp, "%d", Player_Setup.Felder[i2]);
        txPutString(temp, 420, i);
    }
    txPutString(Player_Setup.best_1, 165, 265);
    txPutString(Player_Setup.best_2, 165, 295);
    txPutString(Player_Setup.best_3, 165, 325);
    txPutString(Player_Setup.best_4, 165, 355);
    txPutString(Player_Setup.best_5, 165, 385);
	Show_mouse();
}

void Main_End(void)
{
	Ende(1);
}

void Spielfeld_minus(void)
{
    if(Game_info.big > 2)
    {
        if(bit_but_main_menu[6].on == 0)
        {
            No_Show_mouse();
        	bit_but_main_menu[6].on = 1;
        	gxVirtualDisplay(&Options_pic, 367, 12, bit_but_main_menu[6].x, bit_but_main_menu[6].y+1, bit_but_main_menu[6].x+bit_but_main_menu[6].b, bit_but_main_menu[6].y+bit_but_main_menu[6].h+1, 0);
            Show_mouse();
     	}
        gxVirtualDisplay(&Options_pic, 213, 16, MENU_X+213, MENU_Y+16, MENU_X+298, MENU_Y+32, 0);
		Game_info.big--;
        if(Game_info.big < 3)
        {
            No_Show_mouse();
            gxVirtualDisplay(&L_R_Buttons[0], 0, 0, bit_but_main_menu[5].x+1, bit_but_main_menu[5].y+1, bit_but_main_menu[5].x+bit_but_main_menu[5].b, bit_but_main_menu[5].y+bit_but_main_menu[5].h, 0);
            bit_but_main_menu[5].on = 0;
            bit_but_main_menu[5].an = 0;
            Show_mouse();
        }
	    SetFont(1, grWHITE, grBLACK, txTRANS);
        sprintf(temp, "%dx%d", Game_info.big, Game_info.big);
        txPutString(temp, MENU_X+255, MENU_Y+30);
        gxVirtualDisplay(&Main_pic, 509, 374, 509, 374, 598, 398, 0);
        SetFont(1, grWHITE, grBLACK, txTRANS);
        txPutString(temp, 555, 392); // Info anzeigen
    	gxDisplayVirtual(MENU_X+213, MENU_Y+16, MENU_X+298, MENU_Y+32, 0, &SV, MENU_X+213, MENU_Y+16);
    	gxDisplayVirtual(509, 374, 598, 398, 0, &SV, 509, 374);
        Set_Feld_Size();
    }
}

void Spielfeld_plus(void)
{
    if(Game_info.big < 10)
    {
        if(bit_but_main_menu[5].on == 0)
        {
            No_Show_mouse();
            bit_but_main_menu[5].on = 1;
            gxVirtualDisplay(&Options_pic, 321, 12, bit_but_main_menu[5].x-1, bit_but_main_menu[5].y+1, bit_but_main_menu[5].x+bit_but_main_menu[5].b, bit_but_main_menu[5].y+bit_but_main_menu[5].h+1, 0);
            Show_mouse();
     	}
        gxVirtualDisplay(&Options_pic, 213, 16, MENU_X+213, MENU_Y+16, MENU_X+298, MENU_Y+32, 0);
		Game_info.big++;
	    if(Game_info.big > 9)
        {
            No_Show_mouse();
            gxVirtualDisplay(&L_R_Buttons[1], 0, 0, bit_but_main_menu[6].x, bit_but_main_menu[6].y+1, bit_but_main_menu[6].x+bit_but_main_menu[6].b, bit_but_main_menu[6].y+bit_but_main_menu[6].h+1, 0);
            bit_but_main_menu[6].on = 0;
            bit_but_main_menu[6].an = 0;
            Show_mouse();
        }
	    SetFont(1, grWHITE, grBLACK, txTRANS);
        sprintf(temp, "%dx%d", Game_info.big, Game_info.big);
        txPutString(temp, MENU_X+255, MENU_Y+30);
        gxVirtualDisplay(&Main_pic, 509, 374, 509, 374, 598, 398, 0);
        SetFont(1, grWHITE, grBLACK, txTRANS);
        txPutString(temp, 555, 392); // Info anzeigen
    	gxDisplayVirtual(MENU_X+213, MENU_Y+16, MENU_X+298, MENU_Y+32, 0, &SV, MENU_X+213, MENU_Y+16);
    	gxDisplayVirtual(509, 374, 598, 398, 0, &SV, 509, 374);
	    Set_Feld_Size();
    }
}

void Speed_Size(void)
{
	switch(Game_info.speed_step)
    {
    	case 1:
			Game_info.speed_punkte = 10;
			Game_info.speed = 3;
			break;

    	case 2:
			Game_info.speed_punkte = 9;
			Game_info.speed = 5;
			break;

    	case 3:
			Game_info.speed_punkte = 8;
			Game_info.speed = 6;
			break;

    	case 4:
			Game_info.speed_punkte = 7;
			Game_info.speed = 7;
			break;

    	case 5:
			Game_info.speed_punkte = 6;
			Game_info.speed = 9;
			break;

    	case 6:
			Game_info.speed_punkte = 5;
			Game_info.speed = 11;
			break;

    	case 7:
			Game_info.speed_punkte = 4;
			Game_info.speed = 13;
			break;

    	case 8:
			Game_info.speed_punkte = 3;
			Game_info.speed = 15;
			break;

    	case 9:
			Game_info.speed_punkte = 2;
			Game_info.speed = 17;
			break;

    	case 10:
			Game_info.speed_punkte = 1;
			Game_info.speed = 18;
			break;
	}
}

void Set_Feld_Size(void)
{
	switch(Game_info.big)
    {
    	case 2:
			Game_info.Feld_x = 89;
			Game_info.Feld_y = 107;
			Game_info.Feld_b = 150;
			Game_info.Feld_h = 150;
        	break;

    	case 3:
			Game_info.Feld_x = 14;
			Game_info.Feld_y = 53;
			Game_info.Feld_b = 150;
			Game_info.Feld_h = 136;
        	break;

    	case 4:
			Game_info.Feld_x = 1;
			Game_info.Feld_y = 53;
			Game_info.Feld_b = 119;
			Game_info.Feld_h = 102;
        	break;

    	case 5:
			Game_info.Feld_x = 1;
			Game_info.Feld_y = 52;
			Game_info.Feld_b = 95;
			Game_info.Feld_h = 82;
        	break;

    	case 6:
			Game_info.Feld_x = 2;
			Game_info.Feld_y = 62;
			Game_info.Feld_b = 79;
			Game_info.Feld_h = 65;
        	break;

    	case 7:
			Game_info.Feld_x = 1;
			Game_info.Feld_y = 54;
			Game_info.Feld_b = 68;
			Game_info.Feld_h = 58;
        	break;

    	case 8:
			Game_info.Feld_x = 3;
			Game_info.Feld_y = 53;
			Game_info.Feld_b = 59;
			Game_info.Feld_h = 51;
        	break;

    	case 9:
			Game_info.Feld_x = 1;
			Game_info.Feld_y = 54;
			Game_info.Feld_b = 53;
			Game_info.Feld_h = 45;
        	break;

    	case 10:
			Game_info.Feld_x = 4;
			Game_info.Feld_y = 52;
			Game_info.Feld_b = 47;
			Game_info.Feld_h = 41;
        	break;
    }
}


void Speed_minus(void)
{
    if(Game_info.speed_step > 1)
    {
        if(bit_but_main_menu[8].on == 0)
        {
            No_Show_mouse();
        	bit_but_main_menu[8].on = 1;
        	gxVirtualDisplay(&Options_pic, 367, 12, bit_but_main_menu[8].x, bit_but_main_menu[8].y+1, bit_but_main_menu[8].x+bit_but_main_menu[8].b, bit_but_main_menu[8].y+bit_but_main_menu[8].h+1, 0);
            Show_mouse();
     	}
        gxVirtualDisplay(&Options_pic, 213, 53, MENU_X+213, MENU_Y+53, MENU_X+298, MENU_Y+69, 0);
		Game_info.speed_step--;
	    if(Game_info.speed_step < 2)
        {
            No_Show_mouse();
            gxVirtualDisplay(&L_R_Buttons[0], 0, 0, bit_but_main_menu[7].x+1, bit_but_main_menu[7].y+1, bit_but_main_menu[7].x+bit_but_main_menu[7].b+2, bit_but_main_menu[7].y+bit_but_main_menu[7].h+1, 0);
            bit_but_main_menu[7].on = 0;
            bit_but_main_menu[7].an = 0;
            Show_mouse();
        }
	    SetFont(1, grWHITE, grBLACK, txTRANS);
        sprintf(temp, "%d", Game_info.speed_step);
        txPutString(temp, MENU_X+255, MENU_Y+67);
        gxVirtualDisplay(&Main_pic, 509, 437, 509, 437, 598, 461, 0);
        SetFont(1, grWHITE, grBLACK, txTRANS);
        txPutString(temp, 555, 455); // Info anzeigen
    	gxDisplayVirtual(MENU_X+213, MENU_Y+53, MENU_X+298, MENU_Y+69, 0, &SV, MENU_X+213, MENU_Y+53);
    	gxDisplayVirtual(509, 437, 598, 461, 0, &SV, 509, 437);
		Speed_Size();
    }
}

void Speed_plus(void)
{
    if(Game_info.speed_step < 10)
    {
        if(bit_but_main_menu[7].on == 0)
        {
            No_Show_mouse();
            bit_but_main_menu[7].on = 1;
            gxVirtualDisplay(&Options_pic, 321, 12, bit_but_main_menu[7].x-1, bit_but_main_menu[7].y+1, bit_but_main_menu[7].x+bit_but_main_menu[7].b, bit_but_main_menu[7].y+bit_but_main_menu[7].h+1, 0);
            Show_mouse();
        }
     	gxVirtualDisplay(&Options_pic, 213, 53, MENU_X+213, MENU_Y+53, MENU_X+298, MENU_Y+69, 0);
		Game_info.speed_step++;
    	if(Game_info.speed_step > 9)
        {
            No_Show_mouse();
            gxVirtualDisplay(&L_R_Buttons[1], 0, 0, bit_but_main_menu[8].x, bit_but_main_menu[8].y+1, bit_but_main_menu[8].x+bit_but_main_menu[8].b, bit_but_main_menu[8].y+bit_but_main_menu[8].h+1, 0);
            bit_but_main_menu[8].on = 0;
            bit_but_main_menu[8].an = 0;
            Show_mouse();
        }
	    SetFont(1, grWHITE, grBLACK, txTRANS);
        sprintf(temp, "%d", Game_info.speed_step);
        txPutString(temp, MENU_X+255, MENU_Y+67);
        gxVirtualDisplay(&Main_pic, 509, 437, 509, 437, 598, 461, 0);
        SetFont(1, grWHITE, grBLACK, txTRANS);
        txPutString(temp, 555, 455); // Info anzeigen
    	gxDisplayVirtual(MENU_X+213, MENU_Y+53, MENU_X+298, MENU_Y+69, 0, &SV, MENU_X+213, MENU_Y+53);
    	gxDisplayVirtual(509, 437, 598, 461, 0, &SV, 509, 437);
		Speed_Size();
    }
}

void Intro(void)
{
    int i, x, y;
    GXHEADER Normal_pic;
    GXHEADER Scale_pic;

    grSetBkColor(grBLACK);
    grClearArea(0, 0, 639, 479);
    gxCreateVirtual(gxEMM, &Normal_pic, Setup.gxtype, 231, 43);
    gxVirtualVirtual(&Main_pic, 141, 3, 372, 46, &Normal_pic, 0, 0, gxSET);
    for(x = 10, y = 10; x < 380; x += 2)
    {
        if(y < 100)
        	y++;
        gxCreateVirtual(gxEMM, &Scale_pic, Setup.gxtype, x, y);
        gxVirtualScale(&Normal_pic, &Scale_pic);
	    gxVirtualDisplay(&Scale_pic, 0, 0, 140, 200, 140+x, 200+y, 0);
	    gxDestroyVirtual(&Scale_pic);
        if(co_Mouse.Mouse_on == 1)
	        if(grGetMouseButtons() != 0)
	        	end = 1;
        if(co_Mouse.Joystick_on == 1)
		    if(joybutton() != 0)
	        	end = 1;
        if(bioskey(1) != 0)
        {
            bioskey(0);
	       	end = 1;
        }
        if(end != 0)
        	break;
    }
    for(; x > 320; x -= 2, y--)
    {
        gxCreateVirtual(gxEMM, &Scale_pic, Setup.gxtype, x, y);
        gxVirtualScale(&Normal_pic, &Scale_pic);
	    gxVirtualDisplay(&Scale_pic, 0, 0, 140, 200, 140+x, 200+y, 0);
	    gxDestroyVirtual(&Scale_pic);
        if(co_Mouse.Mouse_on == 1)
	        if(grGetMouseButtons() != 0)
	        	end = 1;
        if(co_Mouse.Joystick_on == 1)
		    if(joybutton() != 0)
	        	end = 1;
        if(bioskey(1) != 0)
        {
            bioskey(0);
        	end = 1;
        }
        if(end != 0)
        	break;
    }
    gxDestroyVirtual(&Normal_pic);
    SetFont(1, grBLACK, grBLACK, txTRANS);
    txPutString("1998", 477, 270);
    txPutString("von Christian Ofenberg", 355, 290);
    SetFont(1, 254, grBLACK, txTRANS);
    txPutString("1998", 472, 265);
    txPutString("von Christian Ofenberg", 350, 285);
    for(i = 0; i < 60; i += 1)
	{
    	gxSetPaletteRGB(254, i, i, i);
    	gxDelay(30);
        if(co_Mouse.Mouse_on == 1)
	        if(grGetMouseButtons() != 0)
	        	end = 1;
        if(co_Mouse.Joystick_on == 1)
		    if(joybutton() != 0)
	        	end = 1;
        if(bioskey(1) != 0)
        {
            bioskey(0);
        	end = 1;
        }
        if(end != 0)
        	break;
    }
    if(end == 0)
        WaitWBreak(50, YES);
	Fade_in(1);
    grSetBkColor(grBLACK);
    grClearArea(0, 0, 639, 479);
    end = 0;
 	gxSetDisplayPalette(pal);
}


#define SETUP_X 100
#define SETUP_B 440
#define SETUP_Y 70
#define SETUP_H 340
#define JOYSTICK_DANEBEN 80

GXHEADER OptionsAusgabe;

extern void Save_Player_Setup(void);
void SetupOptions(void);
void ExitSetup(void);
void ExitGame(void);
void JoystickKalibrieren(void);
void ShowMainSetup(void);
void HelpOn_Off(void);
void KeinJoystick(void);
void Control(void);
void CheckSetupOptions(void);
void Zeige_Uhrzeit(void);

struct BIT_BUTTON bit_but_SetupOptions[] =
{
	{SETUP_X+(SETUP_B/2-100), SETUP_Y+80, 200, 25, 0, 2, ExitGame, 1, "Algorithmus beenden    (Key:   ALT-F4)", 0, EXIT_ANI, -1, 0},
	{SETUP_X+(SETUP_B/2-70), SETUP_Y+110, 140, 25, 0, 2, ExitSetup, 1, "Das Setupmenu verlassen", 0, OK_ANI, -1, 0},
	{SETUP_X+(SETUP_B/2)-20, SETUP_Y+190, 180, 25, 0, 2, JoystickKalibrieren, 1, "Den Joystick Kalibrieren", 0, HAMMER_ANI, -1, 0},
	{SETUP_X+(SETUP_B/2-35), SETUP_Y+290, 60, 25, 0, 2, About, 1, "Ueber den Autor    (Key:    F1)", 0, AUGE_ANI, -1, 0},
	{SETUP_X+(SETUP_B/2-100), SETUP_Y+310, 210, 25, 0, 2, Save_Player_Setup, 1, "Alle aktuellen Einstellungen Speichern", 0, HAMMER_ANI, -1, 0},
	{SETUP_X+(SETUP_B/2-70), SETUP_Y+220, 150, 25, 0, 2, HelpOn_Off, 1, "Schnellhilfe an-/ausschalten(Key:   h)", 0, AUGE_ANI, -1, 0},
	{SETUP_X+(SETUP_B/2-100), SETUP_Y+170, 250, 25, 0, 2, Control, 1, "Die Mauszeiger Steuerung festlegen (Key: F8 - F10)", 0, HAMMER_ANI, -1, 0},
	{999, 999, 999, 999, 999, 999, 0, 0, "", 0, 0, -1, 0},
};

void SetupOptions(void)
{
    int key, style_save, save_mx, save_my;
    int StarModule_s, All_Keys_s;
	int MouseBound_x_s, MouseBound_y_s, MouseBound_x2_s, MouseBound_y2_s;
    GXHEADER OptionsBackground;
    GXHEADER OptionsBackgroundOut;
    GXHEADER OptionsSavedBack;

	No_Show_mouse();
// Einstellungen speichern:
	MouseBound_x_s = MouseBound_x;
    MouseBound_y_s = MouseBound_y;
    MouseBound_x2_s = MouseBound_x2;
    MouseBound_y2_s = MouseBound_y2;
    StarModule_s = StarModule;
    StarModule = NOSTARS;
    All_Keys_s = All_Keys;
    style_save = co_Mouse.Mouse_style;
	save_mx = co_Mouse.mx;
    save_my = co_Mouse.my;
    if(co_Mouse.Mouse_on == YES)
	    grGetMousePos(&save_mx, &save_my);
//
 	gxCreateVirtual(gxEMM, &OptionsSavedBack, Setup.gxtype, 640, 480);
	gxDisplayVirtual(0, 0, 640, 480, 0, &OptionsSavedBack, 0, 0);
    gxCreateVirtual(gxEMM, &OptionsAusgabe, Setup.gxtype, 640, 480);
    gxCreateVirtual(gxEMM, &OptionsBackground, Setup.gxtype, SETUP_B, SETUP_H);
    gxClearVirtual(&OptionsBackground, grBLUE);
	gxVirtualVirtual(&OptionsSavedBack, 0, 0, 640, 480, &OptionsAusgabe, 0, 0, gxSET);
	gxVirtualVirtual(&OptionsBackground, 0, 0, SETUP_B, SETUP_H, &OptionsAusgabe, SETUP_X, SETUP_Y, gxAND);
// Links abdunkeln:
    gxCreateVirtual(gxEMM, &OptionsBackgroundOut, Setup.gxtype, SETUP_X, 480);
    gxClearVirtual(&OptionsBackgroundOut, grDARKGRAY);
	gxVirtualVirtual(&OptionsBackgroundOut, 0, 0, SETUP_X, 480, &OptionsAusgabe, 0, 0, gxAND);
    gxVirtualDisplay(&OptionsAusgabe, 0, 0, 0, 0, SETUP_X, 480, 0);
    gxDestroyVirtual(&OptionsBackgroundOut);
// Rechts abdunkeln:
    gxCreateVirtual(gxEMM, &OptionsBackgroundOut, Setup.gxtype, 640-(SETUP_X+SETUP_B), 480);
    gxClearVirtual(&OptionsBackgroundOut, grDARKGRAY);
	gxVirtualVirtual(&OptionsBackgroundOut, 0, 0, 640-(SETUP_X+SETUP_B), 480, &OptionsAusgabe, SETUP_X+SETUP_B, 0, gxAND);
    gxVirtualDisplay(&OptionsAusgabe, SETUP_X+SETUP_B, 0, SETUP_X+SETUP_B, 0, 640, 480, 0);
    gxDestroyVirtual(&OptionsBackgroundOut);
// Oben abdunkeln:
    gxCreateVirtual(gxEMM, &OptionsBackgroundOut, Setup.gxtype, 640-SETUP_X-(640-(SETUP_X+SETUP_B)), SETUP_Y);
    gxClearVirtual(&OptionsBackgroundOut, grDARKGRAY);
	gxVirtualVirtual(&OptionsBackgroundOut, 0, 0, 640-SETUP_X-(640-(SETUP_X+SETUP_B)), 480, &OptionsAusgabe, SETUP_X, 0, gxAND);
    gxVirtualDisplay(&OptionsAusgabe, SETUP_X, 0, SETUP_X, 0, SETUP_X+SETUP_B, 480, 0);
    gxDestroyVirtual(&OptionsBackgroundOut);
// Unten abdunkeln:
    gxCreateVirtual(gxEMM, &OptionsBackgroundOut, Setup.gxtype, 640-SETUP_X-(640-(SETUP_X+SETUP_B)), 480-(SETUP_Y+SETUP_H));
    gxClearVirtual(&OptionsBackgroundOut, grDARKGRAY);
	gxVirtualVirtual(&OptionsBackgroundOut, 0, 0, 640-SETUP_X-(640-(SETUP_X+SETUP_B)), 480-(SETUP_Y+SETUP_H), &OptionsAusgabe, SETUP_X, SETUP_Y+SETUP_H, gxAND);
    gxVirtualDisplay(&OptionsAusgabe, SETUP_X, SETUP_Y+SETUP_H, SETUP_X, SETUP_Y+SETUP_H, SETUP_X+SETUP_B, 480, 0);
    gxDestroyVirtual(&OptionsBackgroundOut);
    ShowMainSetup();
    grSetColor(grYELLOW);
    grDrawRect(SETUP_X, SETUP_Y, SETUP_X+SETUP_B-1, SETUP_Y+SETUP_H-1, 0);
    SetMouseBounds(SETUP_X, SETUP_Y, SETUP_X+SETUP_B-25, SETUP_Y+SETUP_H-25);
	All_Keys = SETUP_ON;
	Show_mouse();
    for(;;)
    {
        Zeige_Uhrzeit();
        if(bioskey(1) != 0)
        {
            key = bioskey(0);
            Check_Key(key, &bit_but_SetupOptions[0]);
            switch(key)
            {
                case ESC_KEY: case F5_KEY:
                    end = 20;
                    break;
            }
        }
        Move_Mouse();
        CheckBitMouse(&bit_but_SetupOptions[0]);
        if(end != 0)
            break;
    }
	No_Show_mouse();
    gxVirtualDisplay(&OptionsSavedBack, 0, 0, 0, 0, 640, 480, 0);
    gxDestroyVirtual(&OptionsAusgabe);
    gxDestroyVirtual(&OptionsBackground);
    gxDestroyVirtual(&OptionsSavedBack);
// Alte Einstellungen wieder Herstellen:
	MouseBound_x = MouseBound_x_s;
    MouseBound_y = MouseBound_y_s;
    MouseBound_x2 = MouseBound_x2_s;
    MouseBound_y2 = MouseBound_y2_s;
	SetMouseBounds(MouseBound_x, MouseBound_y, MouseBound_x2, MouseBound_y2);
    if(co_Mouse.Mouse_on == YES)
	    grSetMousePos(save_mx, save_my);
    co_Mouse.mx = save_mx;
    co_Mouse.my = save_my;
    co_Mouse.Set_Mouse_style = style_save;
    StarModule = StarModule_s;
    All_Keys = All_Keys_s;
    if(end == 20)
    	end = 0;
	Show_mouse();
}

void Zeige_Uhrzeit(void)
{
   struct  time t;

   gettime(&t);
   sprintf(temp, "   %2d:%02d:%02d   ", t.ti_hour, t.ti_min, t.ti_sec);
   SetFont(1, grWHITE, grBLACK, txNORMAL);
   txPutString(temp, SETUP_X+(SETUP_B/2), SETUP_Y+SETUP_H+30);
}

void ShowMainSetup(void)
{
    gxVirtualDisplay(&OptionsAusgabe, SETUP_X+1, SETUP_Y+1, SETUP_X+1, SETUP_Y+1, SETUP_X+SETUP_B-2, SETUP_Y+SETUP_H-2, 0);
    SetFont(1, grBLACK, grBLACK, txTRANS);
    txPutString("Algorithmus 1998          Game Setup", SETUP_X+(SETUP_B/2)+5, SETUP_Y+35);
    txPutString("Algorithmus verlassen", bit_but_SetupOptions[0].x+(bit_but_SetupOptions[0].b/2)+5, bit_but_SetupOptions[0].y+(bit_but_SetupOptions[0].h/2)+5);
    txPutString("Setup verlassen", bit_but_SetupOptions[1].x+(bit_but_SetupOptions[1].b/2)+5, bit_but_SetupOptions[1].y+(bit_but_SetupOptions[1].h/2)+5);
    txPutString("Joystick Kalibrieren", bit_but_SetupOptions[2].x+(bit_but_SetupOptions[2].b/2)+5, bit_but_SetupOptions[2].y+(bit_but_SetupOptions[2].h/2)+5);
    txPutString("About", bit_but_SetupOptions[3].x+(bit_but_SetupOptions[3].b/2)+5, bit_but_SetupOptions[3].y+(bit_but_SetupOptions[3].h/2)+5);
    txPutString("Einstellungen Speichern", bit_but_SetupOptions[4].x+(bit_but_SetupOptions[4].b/2)+5, bit_but_SetupOptions[4].y+(bit_but_SetupOptions[4].h/2)+5);
    if(Player_Setup.Help == 0)
        txPutString("Schnellhilfe: Aus", bit_but_SetupOptions[5].x+(bit_but_SetupOptions[5].b/2)+5, bit_but_SetupOptions[5].y+(bit_but_SetupOptions[5].h/2)+5);
    else
       txPutString("Schnellhilfe: An", bit_but_SetupOptions[5].x+(bit_but_SetupOptions[5].b/2)+5, bit_but_SetupOptions[5].y+(bit_but_SetupOptions[5].h/2)+5);
    if(co_Mouse.Mouse_on == 1)
	    txPutString("Steuerung:    Maus (Key: F8)", bit_but_SetupOptions[6].x+(bit_but_SetupOptions[6].b/2)+5, bit_but_SetupOptions[6].y+(bit_but_SetupOptions[6].h/2)+5);
    if(co_Mouse.Joystick_on == 1)
	    txPutString("Steuerung:  Joystick (Key: F9)", bit_but_SetupOptions[6].x+(bit_but_SetupOptions[6].b/2)+5, bit_but_SetupOptions[6].y+(bit_but_SetupOptions[6].h/2)+5);
    if(co_Mouse.Mouse_on == 0 && co_Mouse.Joystick_on == 0)
	    txPutString("Steuerung:  Tastatur (Key: F10)", bit_but_SetupOptions[6].x+(bit_but_SetupOptions[6].b/2)+5, bit_but_SetupOptions[6].y+(bit_but_SetupOptions[6].h/2)+5);
    grSetColor(grLIGHTGREEN);
    grDrawRect(SETUP_X+(SETUP_B/2)-150, SETUP_Y+30, SETUP_X+(SETUP_B/2)+150, SETUP_Y+32, 0);
    SetFont(1, grWHITE, grBLACK, txTRANS);
    txPutString("Algorithmus 1998          Game Setup", SETUP_X+(SETUP_B/2), SETUP_Y+30);
    txPutString("Algorithmus verlassen", bit_but_SetupOptions[0].x+(bit_but_SetupOptions[0].b/2), bit_but_SetupOptions[0].y+(bit_but_SetupOptions[0].h/2));
    txPutString("Setup verlassen", bit_but_SetupOptions[1].x+(bit_but_SetupOptions[1].b/2), bit_but_SetupOptions[1].y+(bit_but_SetupOptions[1].h/2));
    txPutString("Joystick Kalibrieren", bit_but_SetupOptions[2].x+(bit_but_SetupOptions[2].b/2), bit_but_SetupOptions[2].y+(bit_but_SetupOptions[2].h/2));
    txPutString("About", bit_but_SetupOptions[3].x+(bit_but_SetupOptions[3].b/2), bit_but_SetupOptions[3].y+(bit_but_SetupOptions[3].h/2));
    txPutString("Einstellungen Speichern", bit_but_SetupOptions[4].x+(bit_but_SetupOptions[4].b/2), bit_but_SetupOptions[4].y+(bit_but_SetupOptions[4].h/2));
    if(Player_Setup.Help == 0)
        txPutString("Schnellhilfe: Aus", bit_but_SetupOptions[5].x+(bit_but_SetupOptions[5].b/2), bit_but_SetupOptions[5].y+(bit_but_SetupOptions[5].h/2));
    else
       txPutString("Schnellhilfe: An", bit_but_SetupOptions[5].x+(bit_but_SetupOptions[5].b/2), bit_but_SetupOptions[5].y+(bit_but_SetupOptions[5].h/2));
    if(co_Mouse.Mouse_on == 1)
	    txPutString("Steuerung:    Maus (Key: F8)", bit_but_SetupOptions[6].x+(bit_but_SetupOptions[6].b/2), bit_but_SetupOptions[6].y+(bit_but_SetupOptions[6].h/2));
    if(co_Mouse.Joystick_on == 1)
	    txPutString("Steuerung:  Joystick (Key: F9)", bit_but_SetupOptions[6].x+(bit_but_SetupOptions[6].b/2), bit_but_SetupOptions[6].y+(bit_but_SetupOptions[6].h/2));
    if(co_Mouse.Mouse_on == 0 && co_Mouse.Joystick_on == 0)
	    txPutString("Steuerung:  Tastatur (Key: F10)", bit_but_SetupOptions[6].x+(bit_but_SetupOptions[6].b/2), bit_but_SetupOptions[6].y+(bit_but_SetupOptions[6].h/2));
    co_Mouse.Set_Mouse_style = NORMAL;
    co_Mouse.mx = bit_but_SetupOptions[1].x+(bit_but_SetupOptions[1].y/2);
    co_Mouse.my = bit_but_SetupOptions[1].y+5;
    if(co_Mouse.Mouse_on == YES)
	    grSetMousePos(co_Mouse.mx, co_Mouse.my);
}

void ExitSetup(void)
{
	end = 20;
}

void ExitGame(void)
{
	Ende(1);
}

void JoystickKalibrieren(void)
{
    int x, y, key, i, JoystickOk;

	No_Show_mouse();
    gxVirtualDisplay(&OptionsAusgabe, SETUP_X+1, SETUP_Y+1, SETUP_X+1, SETUP_Y+1, SETUP_X+SETUP_B-2, SETUP_Y+SETUP_H-2, 0);
    if(Setup.Joystick == NO)
    {
        SetFont(1, grBLACK, grBLACK, txTRANS);
        txPutString("Es ist kein Joystick eingerichtet.", SETUP_X+(SETUP_B/2)+5, SETUP_Y+(SETUP_H/2)+5);
        SetFont(1, grWHITE, grBLACK, txTRANS);
        txPutString("Es ist kein Joystick eingerichtet", SETUP_X+(SETUP_B/2), SETUP_Y+(SETUP_H/2));
        SetFont(1, grBLACK, grBLACK, txTRANS);
        txPutString("Pruefe nun erneut...", SETUP_X+(SETUP_B/2)+5, SETUP_Y+(SETUP_H/2)+5+30);
        SetFont(1, grWHITE, grBLACK, txTRANS);
        txPutString("Pruefe nun erneut...", SETUP_X+(SETUP_B/2), SETUP_Y+(SETUP_H/2)+30);
        gxDelay(1000);
	    if(!initjoy())
        {
            KeinJoystick();
        	return;
        }
        SetFont(1, grBLACK, grBLACK, txTRANS);
        txPutString("Es wurde ein Joystick gefunden.", SETUP_X+(SETUP_B/2)+5, SETUP_Y+(SETUP_H/2)+5+90);
        SetFont(1, grLIGHTGREEN, grBLACK, txTRANS);
        txPutString("Es wurde ein Joystick gefunden.", SETUP_X+(SETUP_B/2), SETUP_Y+(SETUP_H/2)+90);
        gxDelay(2000);
        Setup.Joystick = YES;
    }
    if(!initjoy())
    {
        KeinJoystick();
        Setup.Joystick = NO;
    	return;
    }
    for(i = 0; i < 5; i++)
    {
	    gxVirtualDisplay(&OptionsAusgabe, SETUP_X+1, SETUP_Y+1, SETUP_X+1, SETUP_Y+1, SETUP_X+SETUP_B-2, SETUP_Y+SETUP_H-2, 0);
	    SetFont(1, grBLACK, grBLACK, txTRANS);
        switch(i)
        {
			case 0:
                txPutString("Den Joystick zentrieren und Taste dreucken", SETUP_X+(SETUP_B/2)+5, SETUP_Y+(SETUP_H/2)+5);
                SetFont(1, grWHITE, grBLACK, txTRANS);
                txPutString("Den Joystick zentrieren und Taste dreucken", SETUP_X+(SETUP_B/2), SETUP_Y+(SETUP_H/2));
            	break;

			case 1:
                txPutString("Den Joystick links und Taste dreucken", SETUP_X+(SETUP_B/2)+5, SETUP_Y+(SETUP_H/2)+5);
                SetFont(1, grWHITE, grBLACK, txTRANS);
                txPutString("Den Joystick links und Taste dreucken", SETUP_X+(SETUP_B/2), SETUP_Y+(SETUP_H/2));
            	break;

			case 2:
                txPutString("Den Joystick rechts und Taste dreucken", SETUP_X+(SETUP_B/2)+5, SETUP_Y+(SETUP_H/2)+5);
                SetFont(1, grWHITE, grBLACK, txTRANS);
                txPutString("Den Joystick rechts und Taste dreucken", SETUP_X+(SETUP_B/2), SETUP_Y+(SETUP_H/2));
            	break;

			case 3:
                txPutString("Den Joystick oben und Taste dreucken", SETUP_X+(SETUP_B/2)+5, SETUP_Y+(SETUP_H/2)+5);
                SetFont(1, grWHITE, grBLACK, txTRANS);
                txPutString("Den Joystick oben und Taste dreucken", SETUP_X+(SETUP_B/2), SETUP_Y+(SETUP_H/2));
            	break;

			case 4:
                txPutString("Den Joystick unten und Taste dreucken", SETUP_X+(SETUP_B/2)+5, SETUP_Y+(SETUP_H/2)+5);
                SetFont(1, grWHITE, grBLACK, txTRANS);
                txPutString("Den Joystick unten und Taste dreucken", SETUP_X+(SETUP_B/2), SETUP_Y+(SETUP_H/2));
            	break;
        }
        SetFont(1, grWHITE, grBLACK, txTRANS);
        txPutString("x Achse:", SETUP_X+(SETUP_B/2)-50, SETUP_Y+(SETUP_H/2)+30);
        txPutString("y Achse:", SETUP_X+(SETUP_B/2)-50, SETUP_Y+(SETUP_H/2)+50);
        for(;;)
        {
            Zeige_Uhrzeit();
            joypos(&x, &y);
	        sprintf(temp, "      %d      ", x);
    	    SetFont(1, grWHITE, grBLACK, txNORMAL);
        	txPutString(temp, SETUP_X+(SETUP_B/2)+35, SETUP_Y+(SETUP_H/2)+30);
      	    sprintf(temp, "      %d      ", y);
       	    txPutString(temp, SETUP_X+(SETUP_B/2)+35, SETUP_Y+(SETUP_H/2)+50);
            if(joybutton() != 0)
                break;
            if(bioskey(1) != 0)
            {
                key = bioskey(0);
                if(key == ESC_KEY)
                    end = 1;
                break;
            }
		}
       	JoystickOk = 0;
        switch(i)
        {
        	case 0:
                Player_Setup.Joystick_MitteX = x;
                Player_Setup.Joystick_MitteY = y;
            	break;

        	case 1:
                Player_Setup.Joystick_MinX = x-Player_Setup.Joystick_MitteX+JOYSTICK_DANEBEN;
                if(x >= Player_Setup.Joystick_MitteX)
                	JoystickOk = 1;
            	break;

        	case 2:
                Player_Setup.Joystick_MaxX = x-Player_Setup.Joystick_MitteX-JOYSTICK_DANEBEN;
                if(x <= Player_Setup.Joystick_MitteX)
                	JoystickOk = 1;
            	break;

        	case 3:
                Player_Setup.Joystick_MinY = y-Player_Setup.Joystick_MitteY+JOYSTICK_DANEBEN;
                if(y >= Player_Setup.Joystick_MitteY)
                	JoystickOk = 1;
            	break;

        	case 4:
                Player_Setup.Joystick_MaxY = y-Player_Setup.Joystick_MitteY-JOYSTICK_DANEBEN;
                if(y <= Player_Setup.Joystick_MitteY)
                	JoystickOk = 1;
            	break;
        }
        SetFont(1, grBLACK, grBLACK, txTRANS);
        if(JoystickOk == 0)
        {
            txPutString("OK", SETUP_X+(SETUP_B/2)+5, SETUP_Y+(SETUP_H/2)+105);
            SetFont(1, grLIGHTGREEN, grBLACK, txTRANS);
            txPutString("OK", SETUP_X+(SETUP_B/2), SETUP_Y+(SETUP_H/2)+100);
    	}
        else
        {
            txPutString("OK ?", SETUP_X+(SETUP_B/2)+5, SETUP_Y+(SETUP_H/2)+105);
            SetFont(1, grLIGHTMAGENTA, grBLACK, txTRANS);
            txPutString("OK ?", SETUP_X+(SETUP_B/2), SETUP_Y+(SETUP_H/2)+100);
    	}
        gxDelay(1000);
        if(end != 0)
        	break;
    }
    end = 0;
    ShowMainSetup();
    Show_mouse();
}

void HelpOn_Off(void)
{
     if(Player_Setup.Help == 0)
     {
         Player_Setup.Help = 1;
         SmallMessage(grGREEN, "Hilfetext:       An", 1000);
     }
     else
     {
         Player_Setup.Help = 0;
         SmallMessage(grGREEN, "Hilfetext:      Aus", 1000);
     }
     No_Show_mouse();
	 ShowMainSetup();
     Show_mouse();
}

void KeinJoystick(void)
{
    SetFont(1, grBLACK, grBLACK, txTRANS);
    txPutString("Es wurde kein Joystick gefunden!", SETUP_X+(SETUP_B/2)+5, SETUP_Y+(SETUP_H/2)+5+90);
    SetFont(1, grLIGHTRED, grBLACK, txTRANS);
    txPutString("Es wurde kein Joystick gefunden!", SETUP_X+(SETUP_B/2), SETUP_Y+(SETUP_H/2)+90);
    gxDelay(1000);
    SetFont(1, grBLACK, grBLACK, txTRANS);
    txPutString("Es wurde kein Joystick gefunden!", SETUP_X+(SETUP_B/2), SETUP_Y+(SETUP_H/2)+90);
    gxDelay(1000);
    SetFont(1, grBLACK, grBLACK, txTRANS);
    txPutString("Es wurde kein Joystick gefunden!", SETUP_X+(SETUP_B/2)+5, SETUP_Y+(SETUP_H/2)+5+90);
    SetFont(1, grLIGHTRED, grBLACK, txTRANS);
    txPutString("Es wurde kein Joystick gefunden!", SETUP_X+(SETUP_B/2), SETUP_Y+(SETUP_H/2)+90);
    gxDelay(1000);
    SetFont(1, grBLACK, grBLACK, txTRANS);
    txPutString("Es wurde kein Joystick gefunden!", SETUP_X+(SETUP_B/2), SETUP_Y+(SETUP_H/2)+90);
    gxDelay(1000);
    SetFont(1, grBLACK, grBLACK, txTRANS);
    txPutString("Es wurde kein Joystick gefunden!", SETUP_X+(SETUP_B/2)+5, SETUP_Y+(SETUP_H/2)+5+90);
    SetFont(1, grLIGHTRED, grBLACK, txTRANS);
    txPutString("Es wurde kein Joystick gefunden!", SETUP_X+(SETUP_B/2), SETUP_Y+(SETUP_H/2)+90);
    gxDelay(2000);
    ShowMainSetup();
    Show_mouse();
}

void Control(void)
{
	if(co_Mouse.Mouse_on == 1)
	{
        if(!initjoy())
            Setup.Joystick = NO;
        else
            Setup.Joystick = YES;
    	if(Setup.Joystick == YES)
        {
           co_Mouse.Mouse_on = 0;
           co_Mouse.Joystick_on = 1;
           SmallMessage(grGREEN, "Steuerung:    Joystick", 1000);
        }
        else
        {
           co_Mouse.Mouse_on = 0;
           co_Mouse.Joystick_on = 0;
           SmallMessage(grGREEN, "Steuerung:     Tastatur", 1000);
        }
	}
	else
    {
		if(co_Mouse.Joystick_on == 1)
        {
           co_Mouse.Mouse_on = 0;
           co_Mouse.Joystick_on = 0;
           SmallMessage(grGREEN, "Steuerung:     Tastatur", 1000);
        }
        else
        {
           co_Mouse.Mouse_on = 1;
           co_Mouse.Joystick_on = 0;
           SmallMessage(grGREEN, "Steuerung:     Maus", 1000);
        }
    }
    No_Show_mouse();
    ShowMainSetup();
    Show_mouse();
}

void CheckSetupOptions(void)
{
    if(co_Mouse.Mouse_on == YES)
	    co_Mouse.mb = grGetMouseButtons();
    if(co_Mouse.mb != 0)
		if(co_Mouse.mx == MouseBound_x && co_Mouse.my == MouseBound_y || co_Mouse.mx == MouseBound_x && co_Mouse.my == MouseBound_y2 ||
    	   co_Mouse.mx == MouseBound_x2 && co_Mouse.my == MouseBound_y || co_Mouse.mx == MouseBound_x2 && co_Mouse.my == MouseBound_y2)
  	    {
			SetupOptions();
    	}
}


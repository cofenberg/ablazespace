extern GXHEADER Message_pic;
extern GXHEADER OK_Button;
extern GXHEADER YES_NO_Button;
extern GXHEADER star_a[8];
extern GXHEADER star_x[8];
GXHEADER buttons_pic[5];
GXHEADER Main_pic, Options_pic;
GXHEADER L_R_Buttons[2];
GXHEADER Feld_pic_off, Feld_pic_on;
GXHEADER PassPhoto;

void Lade_Main_Pics(void);
void Destroy_Main_Pics(void);

void Lade_Main_Pics(void)
{
    GXHEADER pic;
    int i, x;

    pcxFileImage(gxEMM,"pic/Tools.pcx",&pic, gxDETECT);
    for(i = 0; i < 5; i++)
       gxCreateVirtual(gxEMM, &buttons_pic[i], Setup.gxtype, 120, 25);
    gxVirtualVirtual(&pic, 229, 0, 369, 25, &buttons_pic[0], 0, 0, gxSET);  // Stop
    gxVirtualVirtual(&pic, 349, 0, 469, 25, &buttons_pic[1], 0, 0, gxSET); // L�schen
    gxVirtualVirtual(&pic, 297, 25, 416, 49, &buttons_pic[2], 0, 0, gxSET); // Setup dunkel
    gxVirtualVirtual(&pic, 417, 25, 536, 49, &buttons_pic[3], 0, 0, gxSET); // Info dunkel
    gxVirtualVirtual(&pic, 469, 0, 588, 24, &buttons_pic[4], 0, 0, gxSET); // Quit dunkel
    for(i = 0; i < 2; i++)
       gxCreateVirtual(gxEMM, &L_R_Buttons[i], Setup.gxtype, 43, 25);
    gxVirtualVirtual(&pic, 209, 25, 252, 50, &L_R_Buttons[0], 0, 0, gxSET); // <-
    gxVirtualVirtual(&pic, 253, 25, 296, 50, &L_R_Buttons[1], 0, 0, gxSET); // ->
    for(i = 0, x = 1; i < 7; i++, x += 10)
    {
       gxCreateVirtual(gxXMM, &star_a[i], Setup.gxtype, 9, 9);
       gxCreateVirtual(gxXMM, &star_x[i], Setup.gxtype, 9, 9);
       gxVirtualVirtual(&pic, x, 420, x+9, 428, &star_a[i], 0, 0, gxSET);
    }
    for(i = 0; i < 7; i++, x += 10)
       gxVirtualVirtual(&pic, x, 420, x+9, 428, &star_x[i], 0, 0, gxSET);
    gxCreateVirtual(gxXMM, &PassPhoto, Setup.gxtype, 150, 180);
    gxVirtualVirtual(&pic, 426, 105, 575, 284, &PassPhoto, 0, 0, gxSET);
    gxCreateVirtual(gxEMM, &Options_pic, Setup.gxtype, 425, 84);
    gxVirtualVirtual(&pic, 0, 182, 425, 466, &Options_pic, 0, 0, gxSET);
    gxCreateVirtual(gxEMM, &Feld_pic_on, Setup.gxtype, 150, 150);
    gxCreateVirtual(gxEMM, &Feld_pic_off, Setup.gxtype, 150, 150);
    gxVirtualVirtual(&pic, 1, 268, 151, 418, &Feld_pic_off, 0, 0, gxSET);
    gxVirtualVirtual(&pic, 153, 268, 304, 418, &Feld_pic_on, 0, 0, gxSET);
    gxCreateVirtual(gxXMM, &Message_pic, Setup.gxtype, 270, 150);
    gxVirtualVirtual(&pic, 306, 285, 575, 434, &Message_pic, 0, 0, gxSET);
    gxCreateVirtual(gxXMM, &OK_Button, Setup.gxtype, 130, 25);
    gxVirtualVirtual(&pic, 240, 157, 370, 182, &OK_Button, 0, 0, gxSET);
    gxCreateVirtual(gxXMM, &YES_NO_Button, Setup.gxtype, 240, 25);
    gxVirtualVirtual(&pic, 0, 157, 239, 182, &YES_NO_Button, 0, 0, gxSET);
    gxDestroyVirtual(&pic);
}

void Destroy_Main_Pics(void)
{
    int i;

    for(i = 0; i < 5; i++)
        gxDestroyVirtual(&buttons_pic[i]);
    for(i = 0; i < 7; i++)
	{
        gxDestroyVirtual(&star_a[i]);
	    gxDestroyVirtual(&star_x[i]);
    }
    gxDestroyVirtual(&Message_pic);
    gxDestroyVirtual(&OK_Button);
    gxDestroyVirtual(&YES_NO_Button);
    gxDestroyVirtual(&PassPhoto);
    gxDestroyVirtual(&Main_pic);
	gxDestroyVirtual(&Options_pic);
    gxDestroyVirtual(&Feld_pic_off);
    gxDestroyVirtual(&Feld_pic_on);
}

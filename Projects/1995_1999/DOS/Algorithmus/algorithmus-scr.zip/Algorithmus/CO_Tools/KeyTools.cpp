// Hilfreich Tools zur Tastatur

// Letzte gro�e �nderung:  16.1.1997

#include "Co_Tools/struct.h"

extern char LastError[50];
GXHEADER Ein_pic;   // Um bei Eingaben den Hintergrund zu sichern
int All_Keys; // Werden alle Globalen Tasten erlaubt?

extern void ShowMainSetup(void);
extern void starm(struct STAR *);
extern struct STAR titel_star[];

extern void About(void);
extern void Bit_But_Down(struct BIT_BUTTON *);
extern void Bit_But_Up(struct BIT_BUTTON *);
int WaitWBreak(int, int);
void Warte_auf_Taste(void);
char *Eingabe(int, int, int, int, int, int, int, int*);
void Check_Key(int key, struct BIT_BUTTON *);

int WaitWBreak(int i, int key)   // i wie lange key 0 == keine Tasten zulassen  1 das gegenteil
{
    int PhotoKey;

	WhileWait(-1);
    for(;;)
    {
        if(StarModule == TITELSTARS)
	        starm(&titel_star[0]);
        if(WhileWait(i) == 1)
            return(0);
        if(bioskey(1) != 0)
        {
            PhotoKey = bioskey(0);
            if(PhotoKey == F4_KEY)
	        	MakePhoto();
            else
				if(key == YES)
                    return(1);
        }
		if(key == YES)
        {
            if(co_Mouse.Joystick_on == 1)
			    if(joybutton() != 0)
                    return(1);
            if(co_Mouse.Mouse_on == 1)
                 if(grGetMouseButtons() != 0)
                    return(1);
        }
    }
}

// Wartet Bis eine Taste der Maus oder der Tastatur gedr�ckt wird.
// H�lt der Anwender die Taste zu lange gibt es Meldungen
void Warte_auf_Taste(void)
{
    time_t timer;
    long save_time;
    int an = 0, i, key;

    timer = time(NULL);
    save_time = timer;
    for(;;)
    {
        timer = time(NULL);
        if(save_time != timer)
        {
            save_time = timer;
            if(an == 0)
    		{
            	SetFont(1, grWHITE, grWHITE, txTRANS);
            	an = 1;
            }
            else
            {
            	SetFont(1, grDARKGRAY, grBLACK, txTRANS);
            	an = 0;
	        }
            txPutString("Taste drucken...", 320, 460);
        }
        if(bioskey(1) != 0)
        {
            key = bioskey(0);
            switch(key)
            {
            	case F4_KEY:
	                MakePhoto();
                    break;

                default:
                	key = 999;
                	break;
            }
            if(key == 999)
            	break;
        }
        if(co_Mouse.Joystick_on == 1)
 		    if(joybutton() != 0)
                break;
		if(co_Mouse.Mouse_on == 1)
            if(grGetMouseButtons() != 0)
	        	break;
    }
  	SetFont(1, grBLACK, grBLACK, txTRANS);
    txPutString("Taste drucken...", 320, 460);
	an = 0;
    timer = time(NULL);
    save_time = timer;
    for(i = 0;;)
    {
        timer = time(NULL);
        if(save_time != timer)
        {
            save_time = timer;
            if(i < 2)
            	i++;
            else
            {
                if(an == 0)
                {
                    SetFont(1, grWHITE, grWHITE, txTRANS);
                    an = 1;
                }
                else
                {
                    SetFont(1, grDARKGRAY, grBLACK, txTRANS);
                    an = 0;
                }
                if(i < 20) // kleiner Scherz
                {
                    i++;
	                txPutString("Sie duerfen die Taste jetzt wieder loslassen...", 320, 460);
                    SetFont(1, grBLACK, grBLACK, txTRANS);
                    if(i == 20)
                        txPutString("Sie duerfen die Taste jetzt wieder loslassen...", 320, 460);
                }
                else
                {
                    if(i < 30) // kleiner Scherz
                    {
                        i++;
		                txPutString("Hallo ist da jemand?", 320, 460);
                        SetFont(1, grBLACK, grBLACK, txTRANS);
                        if(i == 30)
			                txPutString("Hallo ist da jemand?", 320, 460);
                    }
                    else
                    {
                        txPutString("Lassen sie entlich die Taste los, das koennen sie doch oder?!", 320, 460);
                        if(co_Mouse.Joystick_on == 1)
				 		    if(joybutton() != 0)
                                break;
                        if(co_Mouse.Mouse_on == 1)
                            co_Mouse.mb = grGetMouseButtons();
                        if (co_Mouse.mb == 0)
                        {
                            grGetMouseButtons();
                            SetFont(1, grBLACK, grBLACK, txTRANS);
                            txPutString("Lassen sie entlich die Taste los, das koennen sie doch oder?!", 320, 460);
                            timer = time(NULL);
                            save_time = timer;
                            for(i = 0;;)
                            {
                                timer = time(NULL);
                                if(save_time != timer)
                                {
                                    save_time = timer;
                                    if(i < 4)
                                        i++;
                                    else
                                    	break;
                                    if(an == 0)
                                    {
                                        SetFont(1, grWHITE, grWHITE, txTRANS);
                                        an = 1;
                                    }
                                    else
                                    {
                                        SetFont(1, grDARKGRAY, grBLACK, txTRANS);
                                        an = 0;
                                    }
                                    txPutString("Danke sehr, warum nicht gleich so???", 320, 460);
                            	}
                        	}
                        	return;
                        }
                	}
                }
        	}
        }
        if(i >= 30)
        	continue;
        if(co_Mouse.Joystick_on == 1)
		    if(joybutton() != 0)
           		continue;
        if(co_Mouse.Mouse_on == 1)
            if(grGetMouseButtons() != 0)
           		continue;
        if(bioskey(1) != 0)
     		continue;
    	break;
	}
    co_Mouse.mb = 0;
}

// Liest eine Wort wie z.B ein Name
// Anmerkung: Die funktion muss in einer Schleife aufgerufen werden
char *Eingabe(int max_zeichen, int x, int y, int vx, int vy, int vb, int vh, int *Vertig)
{
    static int i = 0;
	static char text[50];
    int key;

    if (max_zeichen >= sizeof(text))
		max_zeichen = sizeof(text)-1;
    SetFont(1, grWHITE, grBLACK, txTRANS);
    if(i == 0)
    	text[0] = 0;
    if(bioskey(1) != 0)
    {
        key = bioskey(0);
        switch(key)
        {
            case '%':
                key = 0;
                break;

            case ESC_KEY:
                end = 1;
                break;

            case RETURN_KEY:
                i = -5;
                break;

            case BACK_KEY: case ENTF_KEY:
                if(i > 0)
                {
                    i--;
                    text[i] = 0;
                }
                break;

            default:
                if(i < max_zeichen)
				{
                    text[i] = key;
                    text[i+1] = 0;
                }
                else
                {
                    i--;
                    text[i] = key;
                    text[i+1] = 0;
                }
                if(i < max_zeichen)
                    i++;
                    break;
        }
        gxVirtualDisplay(&Ein_pic, 0, 0, vx, vy, vx+vb, vy+vh, 0);
        txPutString(text, x, y);
    }
    if(i == -5 || end == 1)
    {
        i = 0;
        *Vertig = 1;
		return(text);
    }
    *Vertig = 0;
	return(text);
}

// Abfrage der Shot keys der Buttons und die abfrage der globalen Tasten
void Check_Key(int key, struct BIT_BUTTON *button)
{
    int i, modifiers;
    char error[50];

    for(i = 0; button[i].x != 999; i++) // Shot key abfrage
    {
    	if(key == button[i].ShotCut && button[i].ShotCut != -1)
		{
            gxVirtualDisplay(&SV, 0, HELP_Y, 0, HELP_Y, 640, HELP_Y+25, 0);
            button[i].help_on = 0;
			Bit_But_Down(&button[i]);
            gxDelay(40);
			Bit_But_Up(&button[i]);
		    if(button[i].p != 0)
        		button[i].p();
            return;
    	}
    }
    switch(key)                // wurde eine Globale Taste gedr�ckt ?
    {
       case F1_KEY:
		   gxVirtualDisplay(&SV, 0, HELP_Y, 0, HELP_Y, 640, HELP_Y+25, 0);
           About();
           break;

       case F4_KEY:
           MakePhoto();
           break;

       case F3_KEY:
           sprintf(error, "Last Error: %s", LastError);
           SmallMessage(grGREEN, error, 2000);
           break;

       case F5_KEY:
		   gxVirtualDisplay(&SV, 0, HELP_Y, 0, HELP_Y, 640, HELP_Y+25, 0);
           if(All_Keys != SETUP_ON)
		       SetupOptions();
           break;

       case F8_KEY:
		   if(Setup.Mouse == 1)
           {
               co_Mouse.Mouse_on = 1;
               co_Mouse.Joystick_on = 0;
               grSetMousePos(co_Mouse.mx, co_Mouse.my);
               SmallMessage(grGREEN, "Steuerung:       Maus", 1000);
           }
           if(All_Keys == SETUP_ON)
           {
	           gxVirtualDisplay(&SV, 0, HELP_Y, 0, HELP_Y, 640, HELP_Y+25, 0);
               No_Show_mouse();
               ShowMainSetup();
               Show_mouse();
           }
           break;

       case F9_KEY:
		   if(!initjoy())
               Setup.Joystick = NO;
		   if(Setup.Joystick == 1)
           {
               co_Mouse.Mouse_on = 0;
               co_Mouse.Joystick_on = 1;
               SmallMessage(grGREEN, "Steuerung:     Joystick", 1000);
           }
           else
               SmallMessage(grRED, "Kein Joystick eingerichtet, bitte das SetupMenu aufrufen(F5)!", 3000);
           if(All_Keys == SETUP_ON)
           {
	           gxVirtualDisplay(&SV, 0, HELP_Y, 0, HELP_Y, 640, HELP_Y+25, 0);
               No_Show_mouse();
               ShowMainSetup();
               Show_mouse();
           }
           break;

       case F10_KEY:
           co_Mouse.Mouse_on = 0;
           co_Mouse.Joystick_on = 0;
           SmallMessage(grGREEN, "Steuerung:     Tastatur", 1000);
           if(All_Keys == SETUP_ON)
           {
	           gxVirtualDisplay(&SV, 0, HELP_Y, 0, HELP_Y, 640, HELP_Y+25, 0);
               No_Show_mouse();
               ShowMainSetup();
               Show_mouse();
           }
           break;

       case ALT_F4_KEY:
           if(All_Keys != NO)
               Ende(1);
           break;

       case H_KEY:
           if(Player_Setup.Help == 0)
           {
	           Player_Setup.Help = 1;
               SmallMessage(grGREEN, "Hilfetext:       An", 1000);
           }
           else
           {
               Player_Setup.Help = 0;
               SmallMessage(grGREEN, "Hilfetext:      Aus", 1000);
           }
           if(All_Keys == SETUP_ON)
           {
	           gxVirtualDisplay(&SV, 0, HELP_Y, 0, HELP_Y, 640, HELP_Y+25, 0);
               No_Show_mouse();
               ShowMainSetup();
               Show_mouse();
           }
           break;
   }
   modifiers = bioskey(2);
   if(modifiers)
   {
      if(modifiers & RIGHT_SHIFT)
      {
          switch(key)
          {
              case LEFT_KEY:
                  key = STRG_LEFT_KEY;
                  break;

              case RIGHT_KEY:
                  key = STRG_RIGHT_KEY;
                  break;

              case UP_KEY:
                  key = STRG_UP_KEY;
                  break;

              case DOWN_KEY:
                  key = STRG_DOWN_KEY;
                  break;
          }
   	  }
   }
   Key_Mouse(key);
}


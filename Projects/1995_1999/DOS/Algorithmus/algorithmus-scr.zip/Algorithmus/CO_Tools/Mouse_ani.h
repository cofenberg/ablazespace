// Maus animationen:
GXHEADER OK_ani_and[5];
GXHEADER OK_ani_xor[5];
GXHEADER NO_ani_and[5];
GXHEADER NO_ani_xor[5];
GXHEADER PLEFT_ani_and[5];
GXHEADER PLEFT_ani_xor[5];
GXHEADER PRIGHT_ani_and[5];
GXHEADER PRIGHT_ani_xor[5];
GXHEADER EXIT_ani_and[5];
GXHEADER EXIT_ani_xor[5];
GXHEADER EDITOR_ani_and[7];
GXHEADER EDITOR_ani_xor[7];
GXHEADER EIMER_ani_and[5];
GXHEADER EIMER_ani_xor[5];
GXHEADER AUGE_ani_and[9];
GXHEADER AUGE_ani_xor[9];

void Creat_Mouse_Ani(void);
void Load_Mouse_Ani(void);
void Destroy_Mouse_Ani(void);
void Mouse_Ani(int);
void Show_Ani(void);

void Creat_Mouse_Ani(void)
{
    int i;

    for(i = 0; i < co_Mouse_Style[OK_ANI].max_ani; i++)
    {
        gxCreateVirtual(gxEMM, &OK_ani_xor[i], Setup.gxtype, MOUSE_B, MOUSE_H);
        gxCreateVirtual(gxEMM, &OK_ani_and[i], Setup.gxtype, MOUSE_B, MOUSE_H);
 	}
    for(i = 0; i < co_Mouse_Style[NO_ANI].max_ani; i++)
    {
        gxCreateVirtual(gxEMM, &NO_ani_xor[i], Setup.gxtype, MOUSE_B, MOUSE_H);
        gxCreateVirtual(gxEMM, &NO_ani_and[i], Setup.gxtype, MOUSE_B, MOUSE_H);
 	}
    for(i = 0; i < co_Mouse_Style[PLEFT_ANI].max_ani; i++)
    {
        gxCreateVirtual(gxEMM, &PLEFT_ani_and[i], Setup.gxtype, MOUSE_B, MOUSE_H);
        gxCreateVirtual(gxEMM, &PLEFT_ani_xor[i], Setup.gxtype, MOUSE_B, MOUSE_H);
 	}
    for(i = 0; i < co_Mouse_Style[PRIGHT_ANI].max_ani; i++)
    {
        gxCreateVirtual(gxEMM, &PRIGHT_ani_and[i], Setup.gxtype, MOUSE_B, MOUSE_H);
        gxCreateVirtual(gxEMM, &PRIGHT_ani_xor[i], Setup.gxtype, MOUSE_B, MOUSE_H);
 	}
    for(i = 0; i < co_Mouse_Style[EXIT_ANI].max_ani; i++)
    {
        gxCreateVirtual(gxEMM, &EXIT_ani_and[i], Setup.gxtype, MOUSE_B, MOUSE_H);
        gxCreateVirtual(gxEMM, &EXIT_ani_xor[i], Setup.gxtype, MOUSE_B, MOUSE_H);
 	}
    for(i = 0; i < co_Mouse_Style[HAMMER_ANI].max_ani; i++)
    {
        gxCreateVirtual(gxEMM, &EDITOR_ani_and[i], Setup.gxtype, MOUSE_B, MOUSE_H);
        gxCreateVirtual(gxEMM, &EDITOR_ani_xor[i], Setup.gxtype, MOUSE_B, MOUSE_H);
 	}
    for(i = 0; i < co_Mouse_Style[EIMER_ANI].max_ani; i++)
    {
        gxCreateVirtual(gxEMM, &EIMER_ani_and[i], Setup.gxtype, MOUSE_B, MOUSE_H);
        gxCreateVirtual(gxEMM, &EIMER_ani_xor[i], Setup.gxtype, MOUSE_B, MOUSE_H);
 	}
    for(i = 0; i < co_Mouse_Style[AUGE_ANI].max_ani; i++)
    {
        gxCreateVirtual(gxEMM, &AUGE_ani_and[i], Setup.gxtype, MOUSE_B, MOUSE_H);
        gxCreateVirtual(gxEMM, &AUGE_ani_xor[i], Setup.gxtype, MOUSE_B, MOUSE_H);
 	}
}

void Load_Mouse_Ani(void)
{
    GXHEADER pic;
    int i, x;

    pcxFileImage(gxEMM, "pic/Tools.pcx",&pic, gxDETECT);
    for(i = 0, x = 1; i < co_Mouse_Style[OK_ANI].max_ani; i++, x += MOUSE_B+1)
    {
//     OK ani
        gxVirtualVirtual(&pic, x, 3+(MOUSE_H*2), x+MOUSE_B, 5+(MOUSE_H*3), &OK_ani_xor[i], 0, 0, gxSET);
        gxVirtualVirtual(&pic, x, 4+(MOUSE_H*3), x+MOUSE_B, 6+(MOUSE_H*4), &OK_ani_and[i], 0, 0, gxSET);
    }
    for(i = 0; i < co_Mouse_Style[NO_ANI].max_ani; i++, x += MOUSE_B+1)
    {
//     NO ani
        gxVirtualVirtual(&pic, x, 3+(MOUSE_H*2), x+MOUSE_B, 5+(MOUSE_H*3), &NO_ani_xor[i], 0, 0, gxSET);
        gxVirtualVirtual(&pic, x, 4+(MOUSE_H*3), x+MOUSE_B, 6+(MOUSE_H*4), &NO_ani_and[i], 0, 0, gxSET);
    }
    for(i = 0; i < co_Mouse_Style[EIMER_ANI].max_ani; i++, x += MOUSE_B+1)
    {
//     EIMER ani
        gxVirtualVirtual(&pic, x, 3+(MOUSE_H*2), x+MOUSE_B, 5+(MOUSE_H*3), &EIMER_ani_xor[i], 0, 0, gxSET);
        gxVirtualVirtual(&pic, x, 4+(MOUSE_H*3), x+MOUSE_B, 6+(MOUSE_H*4), &EIMER_ani_and[i], 0, 0, gxSET);
    }
    for(i = 0; i < co_Mouse_Style[AUGE_ANI].max_ani; i++, x += MOUSE_B+1)
    {
//     AUGE ani
        gxVirtualVirtual(&pic, x, 3+(MOUSE_H*2), x+MOUSE_B, 5+(MOUSE_H*3), &AUGE_ani_xor[i], 0, 0, gxSET);
        gxVirtualVirtual(&pic, x, 4+(MOUSE_H*3), x+MOUSE_B, 6+(MOUSE_H*4), &AUGE_ani_and[i], 0, 0, gxSET);
    }
    for(i = 0, x = 1; i < co_Mouse_Style[PLEFT_ANI].max_ani; i++, x += MOUSE_B+1)
    {
//     PLEFT ani
        gxVirtualVirtual(&pic, x, 5+(MOUSE_H*4), x+MOUSE_B, 7+(MOUSE_H*5), &PLEFT_ani_xor[i], 0, 0, gxSET);
        gxVirtualVirtual(&pic, x, 6+(MOUSE_H*5), x+MOUSE_B, 8+(MOUSE_H*6), &PLEFT_ani_and[i], 0, 0, gxSET);
    }
    for(i = 0; i < co_Mouse_Style[PRIGHT_ANI].max_ani; i++, x += MOUSE_B+1)
    {
//     PRIGHT ani
        gxVirtualVirtual(&pic, x, 5+(MOUSE_H*4), x+MOUSE_B, 7+(MOUSE_H*5), &PRIGHT_ani_xor[i], 0, 0, gxSET);
        gxVirtualVirtual(&pic, x, 6+(MOUSE_H*5), x+MOUSE_B, 8+(MOUSE_H*6), &PRIGHT_ani_and[i], 0, 0, gxSET);
    }
    for(i = 0; i < co_Mouse_Style[EXIT_ANI].max_ani; i++, x += MOUSE_B+1)
    {
//     EXIT ani
        gxVirtualVirtual(&pic, x, 5+(MOUSE_H*4), x+MOUSE_B, 7+(MOUSE_H*5), &EXIT_ani_xor[i], 0, 0, gxSET);
        gxVirtualVirtual(&pic, x, 6+(MOUSE_H*5), x+MOUSE_B, 8+(MOUSE_H*6), &EXIT_ani_and[i], 0, 0, gxSET);
    }
    for(i = 0, x = MOUSE_B+2; i < co_Mouse_Style[HAMMER_ANI].max_ani; i++, x += MOUSE_B+1)
    {
//     EDITOR ani
        gxVirtualVirtual(&pic, x, 1, x+MOUSE_B, MOUSE_H+1, &EDITOR_ani_xor[i], 0, 0, gxSET);
        gxVirtualVirtual(&pic, x, 2+MOUSE_H, x+MOUSE_B, 2+MOUSE_H+MOUSE_H, &EDITOR_ani_and[i], 0, 0, gxSET);
    }
    gxDestroyVirtual(&pic);
}

void Destroy_Mouse_Ani(void)
{
    int i;

    for(i = 0; i < co_Mouse_Style[OK_ANI].max_ani; i++)
    {
	    gxDestroyVirtual(&OK_ani_xor[i]);
	    gxDestroyVirtual(&OK_ani_and[i]);
 	}
    for(i = 0; i < co_Mouse_Style[NO_ANI].max_ani; i++)
    {
	    gxDestroyVirtual(&NO_ani_xor[i]);
	    gxDestroyVirtual(&NO_ani_and[i]);
 	}
    for(i = 0; i < co_Mouse_Style[PLEFT_ANI].max_ani; i++)
    {
	    gxDestroyVirtual(&PLEFT_ani_xor[i]);
	    gxDestroyVirtual(&PLEFT_ani_and[i]);
 	}
    for(i = 0; i < co_Mouse_Style[PRIGHT_ANI].max_ani; i++)
    {
	    gxDestroyVirtual(&PRIGHT_ani_xor[i]);
	    gxDestroyVirtual(&PRIGHT_ani_and[i]);
 	}
    for(i = 0; i < co_Mouse_Style[EXIT_ANI].max_ani; i++)
    {
	    gxDestroyVirtual(&EXIT_ani_xor[i]);
	    gxDestroyVirtual(&EXIT_ani_and[i]);
 	}
    for(i = 0; i < co_Mouse_Style[HAMMER_ANI].max_ani; i++)
    {
	    gxDestroyVirtual(&EDITOR_ani_xor[i]);
	    gxDestroyVirtual(&EDITOR_ani_and[i]);
 	}
    for(i = 0; i < co_Mouse_Style[EIMER_ANI].max_ani; i++)
    {
	    gxDestroyVirtual(&EIMER_ani_xor[i]);
	    gxDestroyVirtual(&EIMER_ani_and[i]);
 	}
    for(i = 0; i < co_Mouse_Style[AUGE_ANI].max_ani; i++)
    {
	    gxDestroyVirtual(&AUGE_ani_xor[i]);
	    gxDestroyVirtual(&AUGE_ani_and[i]);
 	}
}

void Mouse_Ani(int i)
{
    static int mouse_ani_r = 0;
    static struct dostime_t time_save;
    struct dostime_t time;
    static int durchlauf = 0;

    if(i == 5)
    {
   		mouse_ani_r = 0;
    	durchlauf = 0;
        ani_step = 0;
    	return;
    }
    if(co_Mouse.Mouse_style < NORMAL)
    {
        _dos_gettime(&time);
        if(time.hsecond != time_save.hsecond)
        {
            time_save.hsecond = time.hsecond;
            durchlauf++;
        }
        if(durchlauf >= 3)
        {
            durchlauf = 0;
            gxVirtualVirtual(&Mouse_Back, 0, 0, MOUSE_B, MOUSE_H, &SV, co_Mouse.s_mx-M_BX, co_Mouse.s_my-M_BY, gxSET);
            if(mouse_ani_r == 0)
            {
                ani_step++;
                if(ani_step > co_Mouse_Style[co_Mouse.Mouse_style].max_ani-1 && co_Mouse_Style[co_Mouse.Mouse_style].ani_step == 2)
	                ani_step--;  // Animation bleibt stehen
                if(ani_step > co_Mouse_Style[co_Mouse.Mouse_style].max_ani-2 && co_Mouse_Style[co_Mouse.Mouse_style].ani_step == 1)
                    ani_step = 0;  // Animation f�ngt gleich wieder von vorne an
                if(ani_step > co_Mouse_Style[co_Mouse.Mouse_style].max_ani-2 && co_Mouse_Style[co_Mouse.Mouse_style].ani_step == 0)
                    mouse_ani_r = 1;  // Animation l�uft wieder zur�ck
            }
            else
            {
                ani_step--;
                if(ani_step < 1)
                    mouse_ani_r = 0;
            }
            Show_Ani();
            gxVirtualDisplay(&SV, co_Mouse.s_mx-M_BX, co_Mouse.s_my-M_BY, co_Mouse.s_mx-M_BX, co_Mouse.s_my-M_BY, co_Mouse.s_mx+MOUSE_B-M_BX, co_Mouse.s_my+MOUSE_H-M_BY, 0);
        }
	}
}

void Show_Ani(void)
{
    switch(co_Mouse.Mouse_style)
    {
        case OK_ANI:
            gxVirtualVirtual(&OK_ani_and[ani_step], 0, 0, MOUSE_B, MOUSE_H, &SV, co_Mouse.mx-M_BX, co_Mouse.my-M_BY, gxAND);
            gxVirtualVirtual(&OK_ani_xor[ani_step], 0, 0, MOUSE_B, MOUSE_H, &SV, co_Mouse.mx-M_BX, co_Mouse.my-M_BY, gxXOR);
            break;

        case NO_ANI:
            gxVirtualVirtual(&NO_ani_and[ani_step], 0, 0, MOUSE_B, MOUSE_H, &SV, co_Mouse.mx-M_BX, co_Mouse.my-M_BY, gxAND);
            gxVirtualVirtual(&NO_ani_xor[ani_step], 0, 0, MOUSE_B, MOUSE_H, &SV, co_Mouse.mx-M_BX, co_Mouse.my-M_BY, gxXOR);
            break;

        case PLEFT_ANI:
            gxVirtualVirtual(&PLEFT_ani_and[ani_step], 0, 0, MOUSE_B, MOUSE_H, &SV, co_Mouse.mx-M_BX, co_Mouse.my-M_BY, gxAND);
            gxVirtualVirtual(&PLEFT_ani_xor[ani_step], 0, 0, MOUSE_B, MOUSE_H, &SV, co_Mouse.mx-M_BX, co_Mouse.my-M_BY, gxXOR);
            break;

        case PRIGHT_ANI:
            gxVirtualVirtual(&PRIGHT_ani_and[ani_step], 0, 0, MOUSE_B, MOUSE_H, &SV, co_Mouse.mx-M_BX, co_Mouse.my-M_BY, gxAND);
            gxVirtualVirtual(&PRIGHT_ani_xor[ani_step], 0, 0, MOUSE_B, MOUSE_H, &SV, co_Mouse.mx-M_BX, co_Mouse.my-M_BY, gxXOR);
            break;

        case EXIT_ANI:
            gxVirtualVirtual(&EXIT_ani_and[ani_step], 0, 0, MOUSE_B, MOUSE_H, &SV, co_Mouse.mx-M_BX, co_Mouse.my-M_BY, gxAND);
            gxVirtualVirtual(&EXIT_ani_xor[ani_step], 0, 0, MOUSE_B, MOUSE_H, &SV, co_Mouse.mx-M_BX, co_Mouse.my-M_BY, gxXOR);
            break;

        case HAMMER_ANI:
            gxVirtualVirtual(&EDITOR_ani_and[ani_step], 0, 0, MOUSE_B, MOUSE_H, &SV, co_Mouse.mx-M_BX, co_Mouse.my-M_BY, gxAND);
            gxVirtualVirtual(&EDITOR_ani_xor[ani_step], 0, 0, MOUSE_B, MOUSE_H, &SV, co_Mouse.mx-M_BX, co_Mouse.my-M_BY, gxXOR);
            break;

        case EIMER_ANI:
            gxVirtualVirtual(&EIMER_ani_and[ani_step], 0, 0, MOUSE_B, MOUSE_H, &SV, co_Mouse.mx-M_BX, co_Mouse.my-M_BY, gxAND);
            gxVirtualVirtual(&EIMER_ani_xor[ani_step], 0, 0, MOUSE_B, MOUSE_H, &SV, co_Mouse.mx-M_BX, co_Mouse.my-M_BY, gxXOR);
            break;

        case AUGE_ANI:
            gxVirtualVirtual(&AUGE_ani_and[ani_step], 0, 0, MOUSE_B, MOUSE_H, &SV, co_Mouse.mx-M_BX, co_Mouse.my-M_BY, gxAND);
            gxVirtualVirtual(&AUGE_ani_xor[ani_step], 0, 0, MOUSE_B, MOUSE_H, &SV, co_Mouse.mx-M_BX, co_Mouse.my-M_BY, gxXOR);
            break;
    }
}


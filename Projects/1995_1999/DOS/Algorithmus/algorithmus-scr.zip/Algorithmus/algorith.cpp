#include <signal.h>

#include "Co_Tools/struct.h"

extern char LastError[50];
TXHEADER Font[5];
int end;

struct SETUP Setup;
extern int OpenDesk(void);
extern void CloseDesk(void);
extern void Main_Menu(void);
extern void Create_Mouse(void);
extern void Destroy_Mouse(void);
void ProgrammInfo(void);
void ProgrammThanks(void);

void main(void)
{
	gxSetMode(gxTEXT);
   	strncpy(LastError, "No Error", 50);
    end = 0;
    clrscr();
    ProgrammInfo();
    Setup.gxtype = gxVESA_101;
	if(OpenDesk() != gxSUCCESS)
    	end = 3;
    if(end == 0)
		Create_Mouse();
    if(end == 0)
	    Main_Menu();
	Destroy_Mouse();
    CloseDesk();
    if(end == 3)
    	exit(1);
    ProgrammThanks();
    exit(0);
}

void ProgrammInfo(void)
{
    textbackground(BLUE);
    textcolor(LIGHTGREEN);
	cprintf("  Algorithmus");
    textcolor(WHITE);
	cprintf("       von Christian Ofenberg  1998           Version Nr. 1.1    ");
    gxDelay(300);
    textbackground(BLACK);
    textcolor(WHITE);
    cprintf("\r\n\nDas Programm wird geladen...");
    gxDelay(1000);
}

void ProgrammThanks(void)
{
    textbackground(BLACK);
    textcolor(WHITE);
	cprintf("\n\rDanke das Sie ");
    textcolor(LIGHTGREEN);
	cprintf("Algorithmus ");
    textcolor(WHITE);
	cprintf("gespielt haben.");
	cprintf("\n\n\rDas Programm ist Freeware und soll so oft wie m�glich weiterkopiert werden.");
    cprintf("\n\rF�r m�gliche Sch�den die das Programm verursacht wird keine Haftung �bernommmen.");
    gxDelay(2000);
}


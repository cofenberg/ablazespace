Informationen �ber  Algorithmus   Version 1.1   1998 

	
*********************************- Starten des Programmes: -*******************************
Das Spiel braucht etwas EMS und CMM Speicher, unter Windows 95 sollte es aber keinerlei
Probleme mit dem Speicher geben. Sollte es aber doch Probleme beim Ausf�hren des Programmes
geben, sage ich nur eines: "Also auf MEINEM Rechner klappte das..." 
OK nun ein etwas hilfreicherer Tip, bei einem Fehler gibt das Programm eine Fehlermeldung
zur�ck, die Sie beachten sollten. 

Bevor Sie das Spiel starten, sollten Sie unter Windows alle Daten die verloren gehen k�nnten
sichern, f�r den fall, dass irgend etwas schief geht, und der Rechner sich zum trocknen aufh�ngt.    

Wenn w�hrend des Spieles der Bildschirm einmal kurz rot aufblinkt hei�t das, dass Daten
verlorengehen.
Kopieren Sie am besten das Spiel auf ihre Festplatte, so beugen sie Datenverluste des Spieles 
vor.


*************************************- Zum Spiel: -******************************************

Das Men�:
   Im Menu, das Sie gleich zu Beginn des Spieles sehen, k�nnen Sie einige Werte f�r das Spiel 
   einstellen.

Spielfeld Gr��e:    Hier geben Sie die Anzahl der Felder an. Je gr��er die Anzahl der Felder ist
		    desto schwieriger ist es sich eine Reihenfolge einzupr�gen. Wenn Sie noch
		    ein Blutiger Anf�nger sind, empfehle ich ihnen mit vier Feldern anzufangen.

Geschwindigkeit:    Hier legen Sie fest, wie lange Sie ein einzelnes Feld sehen wollen.
		    Je h�her diese Zahl ist desto l�nger ist das Feld sichtbar.
		    
Start:              Soll ich das noch erkl�ren?! OK, hier STARTEN sie das Spiel.

L�schen :           Wenn ihnen die Spieler der Liste zu gut sind, dann eliminieren Sie diese 
		    doch einfach, und schon sind SIE der Beste.

Setup:              Einige scheinbar sinnlose Einstellungen des Programmes.
 
Info:               Hier erfahren Sie alles, was Sie nicht die Bohne interessiert.

Quit:               Das Spiel beenden.


*********************************- Spielerleuterung: -*****************************************
   Wenn das Spiel begonnen hat, dann blinkt ein Feld f�r einige Zeit auf. Klicken Sie nun
   dieses Feld an. Nun Blinken zwei Felder nacheinander auf. Klicken Sie nun beiden Felder
   in dieser Reihenfolge an, und ein drittes Feld kommt hinzu. Das geht nun ewig so weiter, 
   bis Sie aus versehen (oder mit fahrl�ssiger Absicht) ein falsches Feld anklicken.
   Je nachdem, wie Sie die Schwierigkeitsstufe eingestellt haben, bekommen Sie entsprechend 
   viele Punkte pro richtiges Feld. 
   Also kurzgefa�t: 
      Einfaches herumgeklicke auf wehrlosen Feldern - mehr nicht. Macht aber dennoch immer
      wieder "Spa�".   

**************************************- Tastatur: -*********************************************
   Mit ALT-F4 k�nnen sie das Programm jederzeit beenden.
   
   Wenn Sie sich die einzelnen Maus K�stchen genauer ansehen, dann bemerken Sie sicherlich das 
   ein Buchstabe des K�stchens unterstrichen ist. Das ist der Hot Key f�r diesen Button.
   Halten Sie die ALT-Taste gedr�ckt, und dr�cken Sie den Unterstrichenen Buchstaben. Hat die 
   selbe Wirkung wie die Maus, geht aber schneller.    

   Die �bliche Tasten Belegung:
	F1 = About
        F3 = Die letzte Fehlermeldung anzeigen				
        F4 = Einen Screenshot anfertigen				
        F5 = Das Options Men� �ffnen (oder mit der Maus in eine der Bildschirmecken fahren
                                       und die linke Maustaste dr�cken)				
	F8 = Maus Steuerung       
	F9 = Joystick Steuerung(muss im Options Men� erst kalibriert werden)     
	F10 = Tastatur Steuerung       
        h  = Schnellhilfe an- oder ausschalten

*************************************- Das letzte Wort: -***************************************
  Verbesserungen in der Version 1.1:
  - Joysticksteuerung m�glich 
  - Jede Menge Bug Tierchen wurden beseitigt
  - Leicht verbesserte Graphik

****************************- Und nun noch die rechtlichen Dinge: -****************************
- Ich �bernehme keine Verantwortung f�r eventuelle Sch�den, die das Programm an ihnen oder ihrem
  Computer verursacht.
- Algorithmus ist FREEWARE und darf beliebig oft weiterkopiert werden, jedoch untersage ich es, 
  an den Programmdateien irgendwelche �nderungen vorzunehmen.
   

Adresse des Autors:
	      Christian Ofenberg
	      Mozartstr. 9
 	      97990 Weikersheim

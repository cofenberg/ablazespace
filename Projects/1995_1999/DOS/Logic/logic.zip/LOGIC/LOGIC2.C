#include <stdio.h>
#include <conio.h>
#include <dos.h>
#include <io.h>
#include <fcntl.h>
#include <alloc.h>
#include <gxlib.h>
#include <grlib.h>
#include <pcxlib.h>
#include <txlib.h>
#include <STDLIB.H>
#include <graphics.h>
#include <STRING.H>
#include <CTYPE.H>

#include "global.h"

void feldmalen(struct FELD *);
void spiel(void);
void opendesk(void);
void closedesk(void);
void exite(void);
void abdunkeln(void);
void maussehen(void);
void mausnichtsehen(void);
void button(int, struct TASTE *);
void bearbeitetaste(struct TASTE *);
void feldaktion(struct FELD *);
struct TASTE *suchetaste(int, int, struct TASTE *);
struct FELD *suchefeld(int, int, struct FELD *);
struct FELD *suchefeldvor(int, int, struct FELD *);
void brettende(void);
void undo(void);
void neu(void);
void lade(void);
void quit(void);
void brettaussuchen(void);
void brettplus(void);
void brettminus(void);
void hauptmenu(void);
void zuhaupt(void);
void malebrett(void);
void malebrettzu(void);
void info(void);
void about(void);


#define PAGE1              1

GXHEADER bilder;
int gxtype = gxVGA_12;
GXHEADER bild2;
int page;
int raus;
int feldan[225][20], feldbelegt[225][20];
int mx, my;
int spielbrett;

long frei;
TXHEADER tv[4];
GXHEADER stein[3];
GXHEADER steinausgabe;
int zufall;
char temp[100];
int savered[18];
int savegreen[18];
int saveblue[18];
int durchlauf, feld1, feld2;

int undo1, undo2, undo3, undo1belegt, undo2belegt, undo3belegt;

void far * far pascal bmalloc(unsigned long bytes)
{
	return (farmalloc(bytes));
}

int far pascal bfree(void far *ptr)
{
	farfree(ptr);
	return (0);
}

unsigned long far pascal bcoreleft(void)
{
	return (farcoreleft());
}

void opendesk(void)
{
	gxSetUserMalloc(bmalloc, bfree, bcoreleft);
	gxSetDisplay(gxtype);
	gxSetMode(gxGRAPHICS);
	grSetFillStyle(grDARKGRAY, grGRAY, grTRANS);     // Fl�chenfarbe
	txFileFont(gxCMM, "thymes21.gft", &tv[0]);
    txSetFont(&tv[0]);
    txSetFace(txTRANS);
    txSetColor(grBLACK, grWHITE);
}

void closedesk(void)
{
	txFreeFont(&tv[0]);
	gxSetMode(gxTEXT);
	gxSetUserMalloc(0, 0, 0);
}

/* Beendet das Programm */

void exite()
{
//    abdunkeln();
    grStopMouse();
    exit(1);
}

void abdunkeln(void)
{
    int leer, i;
    int farbe, red[16], green[16], blue[16];

    for (farbe = 0; farbe < 16; farbe++)
    {
    	gxGetPaletteRGB(farbe, &red[farbe], &blue[farbe], &green[farbe]);
    }
    for(i = 0; i < 16; i++)
    {
    	savered[i] = red[i];
    	savegreen[i] = green[i];
    	saveblue[i] = blue[i];
    }
    while (1)
    {
        leer = 0;
        for (farbe = 0; farbe < 16; farbe++)
        {
             if (red[farbe]>4)
             {
                 red[farbe] -= 5;
                 leer |= 1;
             }
             if (blue[farbe]>4)
             {
                 blue[farbe] -= 5;
                 leer |= 2;
             }
             if (green[farbe]>4)
             {
                 green[farbe] -= 5;
                 leer |= 4;
             }
		 	 gxSetPaletteRGB(farbe, red[farbe], blue[farbe], green[farbe]);
        }
 	 	if (leer == 0)
			break;
    }
}

/* Macht die Maus sichtbar */

void maussehen(void)
{
    grDisplayMouse(grSHOW);
    grTrackMouse(grTRACK);
}

/* L�st die Maus verschwinden */

void mausnichtsehen(void)
{
   	grDisplayMouse(grHIDE);
    grTrackMouse(grNOTRACK);
}

/* Mahlt die Mausk�stchen */

void button(int m, struct TASTE *b)
{
    int poly[25];
    int x,y, x2, y2;

    mausnichtsehen();
    x = b->x;
    y = b->y;
    x2= b->x+b->b;
    y2= b->y+b->h;
    grSetBkColor(b->bf);
	grClearArea(x, y, x2, y2);

    if (!m)
    {
	    if (b->u)
		   grSetColor(7);
	    else
		   grSetColor(15);
        switch (b->r)
	     {
	     default:
	     case 4:
		     poly[18] = x2 - 3;
		     poly[19] = y + 3;
		     poly[20] = x + 3;
		     poly[21] = y + 3;
		     poly[22] = x + 3;
		     poly[23] = y2 - 3;
	     case 3:
		     poly[12] = x + 2;
		     poly[13] = y2 - 2;
		     poly[14] = x + 2;
		     poly[15] = y + 2;
		     poly[16] = x2 - 2;
		     poly[17] = y + 2;
	     case 2:
		     poly[6] = x2 - 1;
		     poly[7] = y + 1;
		     poly[8] = x + 1;
		     poly[9] = y + 1;
		     poly[10] = x + 1;
		     poly[11] = y2 - 1;
	     case 1:
		     poly[0] = x;
		     poly[1] = y2;
		     poly[2] = x;
		     poly[3] = y;
		     poly[4] = x2;
		     poly[5] = y;

		     grDrawPoly(poly, b->r*3, grOUTLINE);
	     case 0:
		     break;
	     }

	     if (!b->u)
		    grSetColor(8);
	     else
		    grSetColor(15);
 	     switch (b->r)
	     {
	     default:
	     case 4:
		     poly[18] = x2 - 2;
		     poly[19] = y + 4;
		     poly[20] = x2 - 2;
		     poly[21] = y2 - 2;
		     poly[22] = x + 3;
		     poly[23] = y2 - 2;
	     case 3:
		     poly[12] = x + 2;
		     poly[13] = y2 - 1;
		     poly[14] = x2 - 1;
		     poly[15] = y2 - 1;
		     poly[16] = x2 - 1;
		     poly[17] = y + 3;
	     case 2:
		     poly[6] = x2;
		     poly[7] = y + 2;
		     poly[8] = x2;
		     poly[9] = y2;
		     poly[10] = x + 1;
		     poly[11] = y2;
	     case 1:
		     poly[0] = x;
		     poly[1] = y2 + 1;
		     poly[2] = x2 + 1;
		     poly[3] = y2 + 1;
		     poly[4] = x2 + 1;
		     poly[5] = y + 1;

		     grDrawPoly(poly, b->r*3, grOUTLINE);
	     case 0:
		     break;
	     }

	     txSetColor(grBLACK, grWHITE);
	     if (b->text)
	     {
    	     txSetAlign(txCENTER, txCENTER);
		     txSetColor(b->vf, b->hf);
		     txPutString(b->text, b->x+(b->b/2), b->y+(b->h/2)+7);
         }
    }
    else
    {
	    if (b->text)
	    {
    	    txSetAlign(txCENTER, txCENTER);
		    txSetColor(b->vf, b->hf);
		    txPutString(b->text, b->x+(b->b/2)+2, b->y+(b->h/2)+9);
        }
        if (b->r)
        {
		    grSetColor(8);
		    grMoveTo(x,y);
		    grLineTo(x2,y);
		    grMoveTo(x,y);
		    grLineTo(x,y2);
 	    }
    }
    maussehen();
}

/* Schaut ob die Maus bet�tigt wurde */

void bearbeitetaste(struct TASTE *ta)
{
	struct TASTE *t;
    int mb;

	grGetMousePos(&mx , &my);
    mb = grGetMouseButtons();
	if (mb == grLBUTTON)
    {
	    mb = grGetMouseButtons();
		if ((t = suchetaste(mx, my, ta)) != 0)
        {
            if (t->p)
            {
	            button(1, t);
                delay(70);
			    button(0, t);
			    t->p();
            }
    	}
	}
}

// hauptspiel

void bearbeitefeld(struct FELD *feld)
{
	struct FELD *f;
	struct FELD *f2;
	struct FELD *t;
    int mb, i;
    int style, color;

	grGetMousePos(&mx , &my);
    if ((t = suchefeldvor(mx, my, feld)) != 0)
    {
        if(t->an == 1)
        {
            grGetMouseStyle(&style, &color);
            if(durchlauf == 1)
	        {
                if(t->farbe == 4)
	 			{
                    if(style != grCRTHAND)
					    grSetMouseStyle(grCRTHAND, 15);
                }
                else
		        {
				    if(t->belegt == 1)
	 			    {
	                    if(style != grCUPHAND)
					    grSetMouseStyle(grCUPHAND, 15);
                    }
                    else
				    {
					    if(t->belegt == 0)
	 			        {
		                    if(style != grCSTOP)
						    	grSetMouseStyle(grCSTOP, 15);
                    	}
                        else
                        {
                            if(style != grCARROW)
					            grSetMouseStyle(grCARROW, 15);
                        }
                	}
		        }
    	    }
            if(durchlauf == 2)
	        {
		        if(t->belegt == 0)
	 			{
                    if(style != grCUPHAND)
					    grSetMouseStyle(grCUPHAND, 15);
                }
                else
	            {
				    if(t->belegt == 1)
                    {
				        if(style != grCSTOP)
	 			    	    grSetMouseStyle(grCSTOP, 15);
            	    }
                }
    	    }
    	}
	}
    mb = grGetMouseButtons();
	if (mb == grLBUTTON)
    {
	    mb = grGetMouseButtons();
        delay(50);
        if ((t = suchefeld(mx, my, feld)) != 0)
        {
            durchlauf++;
            if(durchlauf == 1)
            {
			    if(t->belegt == 1)
                {
            	    mausnichtsehen();
              	    feld1 = t->nr;
				    t->farbe = 4;
                    feldmalen(t);
                    delay(200);
            	    maussehen();
			    }
                else
			        if(t->belegt == 0)
                    {
                    	durchlauf--;
                    }
           	}
            if(durchlauf == 2)
            {
				if(t->nr == feld1)
                {
            	    mausnichtsehen();
				    t->farbe = 7;
                    feldmalen(t);
                	durchlauf = 0;
                    feld1 = 0;
                    delay(200);
            	    maussehen();
                    return;
                }
				if(t->belegt == 1)
                {
            	    mausnichtsehen();
				    t->farbe = 4;
                    feldmalen(t);
	                f = &feldinfo[feld1];
				    f->farbe = 7;
                    feldmalen(f);
                	durchlauf = 1;
                    feld1 = t->nr;
                    delay(200);
            	    maussehen();
                    return;
                }

                feld2 = t->nr;
			    if(t->belegt == 0)
                {
            	    mausnichtsehen();
                    f = &feldinfo[feld1];
                    f2 = &feldinfo[feld2];

                    if(f2->xnr < f->xnr)
                    {
                   	    if(f->xnr-2 == f2->xnr) // <-
                        {
						    for(i = 0; feldinfo[i].farbe != 0; i++)
						    {
			                    f = &feldinfo[i];
                                if(f->xnr == f2->xnr+1 && f->ynr == f2->ynr)
                                {
	                                feldaktion(f);
				                    maussehen();
                            	    return;
                                }
						    }
                        }
                    }
                    if(f2->xnr > f->xnr)
                    {
                   	    if(f->xnr+2 == f2->xnr) // ->
                        {
						    for(i = 0; feldinfo[i].farbe != 0; i++)
						    {
			                    f = &feldinfo[i];
                                if(f->xnr == f2->xnr-1 && f->ynr == f2->ynr)
                                {
	                                feldaktion(f);
				                    maussehen();
                            	    return;
                                }
						    }
                        }
                   	}
                    if(f2->ynr < f->ynr)
                    {
					    if(f->ynr-2 == f2->ynr) // hoch
                        {
						    for(i = 0; feldinfo[i].farbe != 0; i++)
						    {
			                    f = &feldinfo[i];
                                if(f->ynr == f2->ynr+1 && f->xnr == f2->xnr)
                                {
	                                feldaktion(f);
				                    maussehen();
                            	    return;
                                }
						    }
                        }
                   	}
                    if(f2->ynr > f->ynr)
                    {
					    if(f->ynr+2 == f2->ynr) // runter
                        {
						    for(i = 0; feldinfo[i].farbe != 0; i++)
						    {
			                    f = &feldinfo[i];
                                if(f->ynr == f2->ynr-1 && f->xnr == f2->xnr)
                                {
	                                feldaktion(f);
				                    maussehen();
                            	    return;
                                }
						    }
                        }
                    }
                    durchlauf--;
                    maussehen();
			    }
			    if(t->belegt == 1)
                {
                    durchlauf--;
                    maussehen();
                }
           	}
    	}
	}
}

void brettende(void)
{
 	int i;
	struct FELD *f;

    mausnichtsehen();
    grSetBkColor(7);
	grClearArea(215, 454, 635, 475);
	for (i = 0; quitinfo[i].b != 0; i++)
	{
		button(0, &quitinfo[i]);
    }
    maussehen();
	for(;;)
    {
        bearbeitetaste(&quitinfo[0]);
        if(raus == 1)
        {
		    mausnichtsehen();
            grSetBkColor(7);
	        grClearArea(215, 454, 635, 475);
	        for (i = 1; listeinfo[i].b != 0; i++)
	        {
		        button(0, &listeinfo[i]);
            }
            f = &feldinfo[feld1];
            f->farbe = 7;
	        feld1 = 0;
            f = &feldinfo[feld2];
            f->farbe = 7;
            feld2 = 0;
		    maussehen();
        	return;
        }
        if(raus == 2)
        {
		    mausnichtsehen();
            grSetBkColor(7);
	        grClearArea(215, 454, 635, 475);
	        for (i = 1; listeinfo[i].b != 0; i++)
	        {
		        button(0, &listeinfo[i]);
            }
            raus = 0;
		    maussehen();
        	return;
        }
	}
}

/* Schaut ob die Maus sich auf einen Mausk�stchen befindet */

struct TASTE *suchetaste(int mx, int my, struct TASTE *tasten)
{
    int i;

	for (i = 0; tasten->b != 0; i++, tasten++)
		if (!tasten->s &&
			(mx > tasten->x && mx < tasten->x+tasten->b &&
            my > tasten->y && my < tasten->y+tasten->h))
            return (tasten);
	return (0);
}

struct FELD *suchefeld(int mx, int my, struct FELD *feld)
{
    int i;

	for (i = 0; feld->farbe != 0; i++, feld++)
		if (feld->an == 1 &&
			(mx > feld->x && mx < feld->x+feld->b &&
            my > feld->y && my < feld->y+feld->h))
            return (feld);
	return (0);
}

struct FELD *suchefeldvor(int mx, int my, struct FELD *feld)
{
    int i;

	for (i = 0; feld->farbe != 0; i++, feld++)
		if ((mx > feld->x && mx < feld->x+feld->b &&
            my > feld->y && my < feld->y+feld->h))
            return (feld);
	return (0);
}

void feldmalen(struct FELD *feld)
{
    if(feld->belegt == 1)
    {
        if(feld->farbe == 4)
		    gxVirtualDisplay(&stein[2], 1, 1, feld->x, feld->y, feld->x+feld->b-1, feld->y+feld->h-1, page);
        if(feld->farbe == 7)
		    gxVirtualDisplay(&stein[1], 1, 1, feld->x, feld->y, feld->x+feld->b-1, feld->y+feld->h-1, page);
    }
    else
	    if(feld->belegt == 0)
		    gxVirtualDisplay(&stein[0], 1, 1, feld->x, feld->y, feld->x+feld->b-1, feld->y+feld->h-1, page);
}

void spiel(void)
{
    grSetMouseBounds(0, 0, 640, 480);
    raus = 1;
    neu();
    for(;;)
	{
        bearbeitefeld(&feldinfo[0]);
        bearbeitetaste(&listeinfo[0]);
		if(kbhit())
        	exite();
    	if(raus == 1)
			return;
    }
}

void undo(void)
{
	struct FELD *f;
	struct TASTE *t;
    int i;

    t = &listeinfo[3];
    if(t->s == 0)
    {
        mausnichtsehen();
	    t->s = 1;
        button(1, &listeinfo[3]);
        f = &feldinfo[undo1];
	    f->belegt = undo1belegt;
        f = &feldinfo[undo2];
	    f->belegt = undo2belegt;
        f = &feldinfo[undo3];
	    f->belegt = undo3belegt;
        f = &feldinfo[feld1];
        f->farbe = 7;
	    feld1 = 0;
        f = &feldinfo[feld2];
        f->farbe = 7;
        feld2 = 0;
	    durchlauf = 0;
	    for (i = 0; feldinfo[i].farbe != 0; i++)
	    {
            if(feldinfo[i].an == 1)
			    feldmalen(&feldinfo[i]);
        }
        maussehen();
    }
}

void feldaktion(struct FELD *f)
{
	struct TASTE *t;

    if(f->belegt == 1)
    {
        undo1 = f->nr;
        undo1belegt = f->belegt;
        f->belegt = 0;
        feldmalen(f);
        f = &feldinfo[feld1];
        undo2 = f->nr;
        undo2belegt = f->belegt;
        f->belegt = 0;
        f->farbe = 7;
        feldmalen(f);
        f = &feldinfo[feld2];
        undo3 = f->nr;
        undo3belegt = f->belegt;
        f->belegt = 1;
        f->farbe = 4;
        feld1 = f->nr;
        feldmalen(f);
	    durchlauf = 1;
        t = &listeinfo[3];
        if(t->s == 1)
        {
		    t->s = 0;
            button(0, &listeinfo[3]);
   	    }
		maussehen();
	}
}

void neu(void)
{
	struct FELD *f;
	struct TASTE *t;
    int i;
	GXHEADER bild;

    if(raus == 0)
    	brettende();
    if(raus == 1)
    {
        mausnichtsehen();
        raus = 0;
        f = &feldinfo[feld1];
        f->farbe = 7;
	    feld1 = 0;
        f = &feldinfo[feld2];
        f->farbe = 7;
        feld2 = 0;
	    durchlauf = 0;
   	    pcxFileImage(gxCMM,"hgrund1.pcx",&bild, gxDETECT);
        gxVirtualDisplay(&bild, 0, 0, 0, 0, 640, 480, PAGE1);
	    gxDestroyVirtual(&bild);
	    for (i = 0; listeinfo[i].b != 0; i++)
	    {
		    button(0, &listeinfo[i]);
        }
        t = &listeinfo[3];
        t->s = 1;
        button(1, &listeinfo[3]);
	    pcxFileImage(gxCMM,"logic.pcx",&bild, gxDETECT);
        gxVirtualDisplay(&bild, 0, 0, 4, 454, 210, 475, PAGE1);
	    gxDestroyVirtual(&bild);
	    for(i = 0; feldinfo[i].b != 0; i++)
        {
    	    f = &feldinfo[i];
            f->an = feldan[i][spielbrett];
            f->belegt = feldbelegt[i][spielbrett];
        }
	    for (i = 0; feldinfo[i].farbe != 0; i++)
	    {
            if(feldinfo[i].an == 1)
			    feldmalen(&feldinfo[i]);
        }
        maussehen();
	}
}

void lade(void)
{
    int datei;

    if ((datei = open("bilder.txt", O_BINARY)) == 0)
		printf("data error\n");
	read(datei, feldan, sizeof(feldan));
	close(datei);
    if ((datei = open("abb.txt", O_BINARY)) == 0)
		printf("data error\n");
	read(datei, feldbelegt, sizeof(feldbelegt));
	close(datei);
}

void quit(void)
{
	raus = 1;
}

void noquit(void)
{
	raus = 2;
}


void hauptmenu(void)
{
	GXHEADER bild;
    int i;

    for(;;)
    {
        mausnichtsehen();
        grSetMouseBounds(0, 0, 640, 480);
        raus = 0;
   	    pcxFileImage(gxCMM,"logictit.pcx",&bild, gxDETECT);
        gxVirtualDisplay(&bild, 0, 0, 0, 0, 640, 480, PAGE1);
	    gxDestroyVirtual(&bild);
	    for (i = 0; hauptmenuinfo[i].b != 0; i++)
	    {
		    button(0, &hauptmenuinfo[i]);
        }
        maussehen();
        for(;;)
        {
            bearbeitetaste(&hauptmenuinfo[0]);
        	if(raus == 1)
            	break;
        	if(kbhit())
            	exite();
        }
	}
}

void brettaussuchen(void)
{
	struct TITEL *titel;
	struct TASTE *t;
	GXHEADER bild;
    int mb, i, taste;
	GXHEADER ausgabe;
	GXHEADER bilder;
	GXHEADER stern[3];

    for(;;)
    {
        spielbrett = 0;
		gxCreateVirtual(gxCMM, &ausgabe, gxtype, 640, 480);
		gxCreateVirtual(gxCMM, &stern[0], gxtype, 5, 5);
		gxCreateVirtual(gxCMM, &stern[1], gxtype, 5, 5);
		gxCreateVirtual(gxCMM, &stern[2], gxtype, 5, 5);
        grSetMouseBounds(0, 0, 640, 480);
	    mausnichtsehen();
		pcxFileImage(gxCMM,"titel.pcx",&bilder, gxDETECT);
        page = PAGE1;
        gxVirtualDisplay(&bilder, 0, 0, 0, 0, 640, 480, PAGE1);
        gxGetImage(&stern[0], 0, 300, 2, 302, PAGE1);
        gxGetImage(&stern[1], 2, 300, 5, 303, PAGE1);
        gxGetImage(&stern[2], 5, 300, 9, 304, PAGE1);
		gxDestroyVirtual(&bilder);
		gxClearDisplay(0, 0);
	    for (i = 0; titelstern[i].g != 0; i++)
        {
		    titel = &titelstern[i];
            titel->y = rand() % 480;
        }
	    for (i = 0; titelstern[i].g != 0; i++)
        {
		    titel = &titelstern[i];
            zufall = rand() % 600;
            titel->x = 0 - zufall;
        }
    	t = &brettmenuinfo[4];
	    sprintf(temp,"Brett %d", spielbrett+1);
        t->text = temp;
    	button(0, t);
	    for (i = 0; brettmenuinfo[i].b != 0; i++)
	    {
		    button(0, &brettmenuinfo[i]);
        }
	    pcxFileImage(gxCMM,"logic.pcx",&bild, gxDETECT);
        gxVirtualDisplay(&bild, 0, 0, 210, 150, 416, 171, PAGE1);
	    gxDestroyVirtual(&bild);
        grSetMouseBounds(121, 141, 511, 325);
        malebrett();
        maussehen();
        for(;;)
        {
            gxClearVirtual(&ausgabe, 0);
			for (i = 0; titelstern[i].g != 0; i++)
            {
			    titel = &titelstern[i];
				gxVirtualVirtual(&stern[titel->s], 1, 1, titel->sb, titel->sh, &ausgabe, titel->x, titel->y, gxSET);
                titel->x += titel->g;
                if(titel->x > 650)
                {
				    titel->x = 0;
                    titel->y = rand() % 480;
                }
			}
	        gxVirtualDisplay(&ausgabe, 0, 0, 0, 0, 119, 480, page);
	        gxVirtualDisplay(&ausgabe, 522, 0, 522, 0, 640, 480, page);
	        gxVirtualDisplay(&ausgabe, 119, 0, 119, 0, 522, 139, page);
	        gxVirtualDisplay(&ausgabe, 119, 342, 119, 342, 522, 480, page);
            gxSetPage(page);
            page ^= 1;
			mb = grGetMouseButtons();
	        if (mb == grLBUTTON || mb == grRBUTTON)
            {
	            mb = grGetMouseButtons();
                bearbeitetaste(&brettmenuinfo[0]);
	        }
            if(raus == 1)
			{
                gxDestroyVirtual(&ausgabe);
                gxDestroyVirtual(&stern[0]);
                gxDestroyVirtual(&stern[1]);
                gxDestroyVirtual(&stern[2]);
			    return;
            }
        	if(kbhit())
            {
                taste = getch();
                if (taste == 0)
		            taste = getch();
                if(taste == 27)
                {
            	    raus = 1;
            	}
        	}
	    }
	}
}
    //frei = gxVirtualFree(gxCMM);
    //printf("%ld",frei);
    //getch();

void brettplus(void)
{
	struct TASTE *t;

    if(spielbrett < 19)
	{
	    spielbrett++;
    	t = &brettmenuinfo[4];
	    sprintf(temp,"Brett %d", spielbrett+1);
        t->text = temp;
    	button(0, t);
        malebrett();
    	delay(50);
    }
}

void brettminus(void)
{
	struct TASTE *t;

    if(spielbrett > 0)
	{
	    spielbrett--;
    	t = &brettmenuinfo[4];
	    sprintf(temp,"Brett %d", spielbrett+1);
        t->text = temp;
    	button(0, t);
        malebrett();
    	delay(50);
    }
}

void malebrett(void)
{
    malebrettzu();
    gxVirtualDisplay(&bilder, 0, 0, 243, 183, 507, 327, PAGE1);
    gxDestroyVirtual(&bilder);
}


void malebrettzu(void)
{
    if(spielbrett == 0)
	    pcxFileImage(gxCMM,"bbrett1.pcx",&bilder, gxDETECT);
    if(spielbrett == 1)
	    pcxFileImage(gxCMM,"bbrett2.pcx",&bilder, gxDETECT);
    if(spielbrett == 2)
	    pcxFileImage(gxCMM,"bbrett3.pcx",&bilder, gxDETECT);
    if(spielbrett == 3)
	    pcxFileImage(gxCMM,"bbrett4.pcx",&bilder, gxDETECT);
    if(spielbrett == 4)
	    pcxFileImage(gxCMM,"bbrett5.pcx",&bilder, gxDETECT);
    if(spielbrett == 5)
	    pcxFileImage(gxCMM,"bbrett6.pcx",&bilder, gxDETECT);
    if(spielbrett == 6)
	    pcxFileImage(gxCMM,"bbrett7.pcx",&bilder, gxDETECT);
    if(spielbrett == 7)
	    pcxFileImage(gxCMM,"bbrett8.pcx",&bilder, gxDETECT);
    if(spielbrett == 8)
	    pcxFileImage(gxCMM,"bbrett9.pcx",&bilder, gxDETECT);
    if(spielbrett == 9)
	    pcxFileImage(gxCMM,"bbrett10.pcx",&bilder, gxDETECT);
    if(spielbrett == 10)
	    pcxFileImage(gxCMM,"bbrett11.pcx",&bilder, gxDETECT);
    if(spielbrett == 11)
	    pcxFileImage(gxCMM,"bbrett12.pcx",&bilder, gxDETECT);
    if(spielbrett == 12)
	    pcxFileImage(gxCMM,"bbrett13.pcx",&bilder, gxDETECT);
    if(spielbrett == 13)
	    pcxFileImage(gxCMM,"bbrett14.pcx",&bilder, gxDETECT);
    if(spielbrett == 14)
	    pcxFileImage(gxCMM,"bbrett15.pcx",&bilder, gxDETECT);
    if(spielbrett == 15)
	    pcxFileImage(gxCMM,"bbrett16.pcx",&bilder, gxDETECT);
    if(spielbrett == 16)
	    pcxFileImage(gxCMM,"bbrett17.pcx",&bilder, gxDETECT);
    if(spielbrett == 17)
	    pcxFileImage(gxCMM,"bbrett18.pcx",&bilder, gxDETECT);
    if(spielbrett == 18)
	    pcxFileImage(gxCMM,"bbrett19.pcx",&bilder, gxDETECT);
    if(spielbrett == 19)
	    pcxFileImage(gxCMM,"bbrett20.pcx",&bilder, gxDETECT);
}

void info(void)
{
	GXHEADER hintergrund;
	GXHEADER bild;
    int mb, i;

    mausnichtsehen();
    gxCreateVirtual(gxCMM, &hintergrund, gxtype, 600, 400);
	gxDisplayVirtual(110, 130, 530, 350, page, &hintergrund, 0, 0);
    for (i = 0; aboutinfo[i].b != 0; i++)
    {
	    button(0, &aboutinfo[i]);
    }
	pcxFileImage(gxCMM,"logic.pcx",&bild, gxDETECT);
    gxVirtualDisplay(&bild, 0, 0, 210, 150, 416, 171, PAGE1);
	gxDestroyVirtual(&bild);
    txPutString("             Info                ", 320, 190);
    txPutString("         						  ", 320, 210);
    txPutString("                             	  ", 320, 230);
    txPutString("             					  ", 320, 250);
    txPutString("  								  ", 320, 270);
    txPutString(" 								  ", 320, 290);
    txPutString(" 								  ", 320, 310);
    txPutString(" Press any mouse button to quit. ", 320, 330);
	for(;;)
    {
		mb = grGetMouseButtons();
	    if (mb == grLBUTTON || mb == grRBUTTON)
        {
            gxVirtualDisplay(&hintergrund, 0, 0, 110, 130, 530, 350, page);
            gxDestroyVirtual(&hintergrund);
		    maussehen();
			return;
	    }
	}
}

void about(void)
{
	struct TITEL *titel;
	GXHEADER bild;
    int mb, i;
	GXHEADER ausgabe;
	GXHEADER stern[3];

	gxCreateVirtual(gxCMM, &ausgabe, gxtype, 640, 480);
	gxCreateVirtual(gxCMM, &stern[0], gxtype, 5, 5);
	gxCreateVirtual(gxCMM, &stern[1], gxtype, 5, 5);
	gxCreateVirtual(gxCMM, &stern[2], gxtype, 5, 5);
	mausnichtsehen();
	pcxFileImage(gxCMM,"titel.pcx",&bild, gxDETECT);
    page = PAGE1;
    gxVirtualDisplay(&bild, 0, 0, 0, 0, 640, 480, PAGE1);
    gxGetImage(&stern[0], 0, 300, 2, 302, PAGE1);
    gxGetImage(&stern[1], 2, 300, 5, 303, PAGE1);
    gxGetImage(&stern[2], 5, 300, 9, 304, PAGE1);
	gxDestroyVirtual(&bild);
	gxClearDisplay(0, 0);
	for (i = 0; titelstern[i].g != 0; i++)
    {
		titel = &titelstern[i];
        titel->y = rand() % 480;
    }
	for (i = 0; titelstern[i].g != 0; i++)
    {
		titel = &titelstern[i];
        zufall = rand() % 600;
        titel->x = 0 - zufall;
    }
    for (i = 0; aboutinfo[i].b != 0; i++)
    {
	    button(0, &aboutinfo[i]);
    }
	pcxFileImage(gxCMM,"logic.pcx",&bild, gxDETECT);
    gxVirtualDisplay(&bild, 0, 0, 210, 150, 416, 171, PAGE1);
	gxDestroyVirtual(&bild);
//	{ 120, 140, 400, 200, 3, 7, 8, 0, 7, 1,"", 0},
    txPutString("           Logic leap            ", 320, 190);
    txPutString("     by Christian Ofenberg       ", 320, 210);
    txPutString("             1996                ", 320, 230);
    txPutString("       97990 Weikersheim         ", 320, 250);
    txPutString("     Telephone: 07934 8684       ", 320, 270);
    txPutString("   Thise Programm is Freeware.   ", 320, 290);
    txPutString(" 								  ", 320, 310);
    txPutString(" Press any mouse button to quit. ", 320, 330);
    grSetMouseBounds(121, 141, 511, 325);
    for(;;)
    {
        gxClearVirtual(&ausgabe, 0);
		for (i = 0; titelstern[i].g != 0; i++)
        {
			titel = &titelstern[i];
			gxVirtualVirtual(&stern[titel->s], 1, 1, titel->sb, titel->sh, &ausgabe, titel->x, titel->y, gxSET);
            titel->x += titel->g;
            if(titel->x > 650)
            {
				titel->x = 0;
                titel->y = rand() % 480;
            }
		}
	    gxVirtualDisplay(&ausgabe, 0, 0, 0, 0, 119, 480, page);
	    gxVirtualDisplay(&ausgabe, 522, 0, 522, 0, 640, 480, page);
	    gxVirtualDisplay(&ausgabe, 119, 0, 119, 0, 522, 139, page);
	    gxVirtualDisplay(&ausgabe, 119, 342, 119, 342, 522, 480, page);
        gxSetPage(page);
        page ^= 1;
		mb = grGetMouseButtons();
	    if (mb == grLBUTTON || mb == grRBUTTON)
        {
        	raus = 1;
	    }
        if(raus == 1)
		{
            gxDestroyVirtual(&ausgabe);
            gxDestroyVirtual(&stern[0]);
            gxDestroyVirtual(&stern[1]);
            gxDestroyVirtual(&stern[2]);
		    maussehen();
			return;
        }
	}


}

/* Hauptprogramm */

void main(void)
{
//    int was;
	GXHEADER bild;

	opendesk();
	gxClearDisplay(0,0);
    grInitMouse();
    grSetMouseStyle(grCARROW, 15);
	gxCreateVirtual(gxCMM, &steinausgabe, gxtype, 41, 31);
	gxCreateVirtual(gxCMM, &stein[0], gxtype, 41, 31);
	gxCreateVirtual(gxCMM, &stein[1], gxtype, 41, 31);
	gxCreateVirtual(gxCMM, &stein[2], gxtype, 41, 31);
   	pcxFileImage(gxCMM,"stein.pcx",&bild, gxDETECT);
    page = PAGE1;
    gxVirtualDisplay(&bild, 0, 0, 0, 0, 640, 480, PAGE1);
    gxGetImage(&stein[0], 0, 0, 40, 30, PAGE1);
    gxGetImage(&stein[1], 41, 0, 81, 30, PAGE1);
    gxGetImage(&stein[2], 82, 0, 122, 30, PAGE1);
	gxDestroyVirtual(&bild);
    gxClearDisplay(0, 0);
    lade();
    maussehen();
    hauptmenu();
/*    scanf("%d", &was);
    if(was == 0)
	    spiel();
    if(was == 1)
	    editor();*/
	exite();
}
/*
    frei = gxVirtualFree(gxCMM);
    printf("%ld",frei);
    getch();*/


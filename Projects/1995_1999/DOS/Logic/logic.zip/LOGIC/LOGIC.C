#include <stdio.h>
#include <conio.h>
#include <dos.h>
#include <io.h>
#include <fcntl.h>
#include <alloc.h>
#include <gxlib.h>
#include <grlib.h>
#include <pcxlib.h>
#include <txlib.h>
#include <STDLIB.H>
#include <graphics.h>
#include <STRING.H>
#include <CTYPE.H>

#include "global.h"

void feldmalen(int);
void spiel(void);
void opendesk(void);
void closedesk(void);
void exite(void);
void abdunkeln(void);
void maussehen(void);
void mausnichtsehen(void);
void button(int, struct TASTE *);
void fenster(struct TASTE *b);
int bearbeitespringen(int i2);
void bearbeitetaste(struct TASTE *);
void anzeige(void);
void feldaktion(int);
struct TASTE *suchetaste(int, int, struct TASTE *);
int suchefeld(int, int);
void brettende(void);
void zeitablauf(void);
void undo(void);
void neu(void);
void lade(void);
void quit(void);
void brettaussuchen(void);
void brettplus(void);
void brettminus(void);
void hauptmenu(void);
void zuhaupt(void);
void linien(void);
void malebrett(void);
void malebrettzu(void);
void info(void);
void about(void);
void sprachentexte(void);
void sprachen(void);
void sternepos(void);
void sternebewegen(void);
void sternenfeldmalen(int i);

#include "co.h"
#define PAGE1              1

TXHEADER tv[4];
GXHEADER bilder;
GXHEADER ausgabe;
GXHEADER bild2;
GXHEADER stein[3];
GXHEADER hinter[13];
GXHEADER steinausgabe;
GXHEADER stern[4];
int gxtype = gxVGA_12;
int page;
int raus;
int feldan[225][20], feldbelegt[225][20], spielsteine[20];
int feldbild[225][20];
int mx, my, smx, smy;
int spielbrett;
int sprache;
/*
struct FELD

	int x, y, b, h, xnr, ynr, an, belegt, farbe, nr;
};
*/
int feld[225][11];
long frei;
int zufall;
char temp[100];
int savered[18];
int savegreen[18];
int saveblue[18];
int durchlauf, feld1, feld2;
int steine, spielzeit, zeit, punkte;
int undo1, undo2, undo3, undo1belegt, undo2belegt, undo3belegt;

void far * far pascal bmalloc(unsigned long bytes)
{
	return (farmalloc(bytes));
}

int far pascal bfree(void far *ptr)
{
	farfree(ptr);
	return (0);
}

unsigned long far pascal bcoreleft(void)
{
	return (farcoreleft());
}

void opendesk(void)
{
	gxSetUserMalloc(bmalloc, bfree, bcoreleft);
	gxSetDisplay(gxtype);
	gxSetMode(gxGRAPHICS);
	grSetFillStyle(grDARKGRAY, grGRAY, grTRANS);     // Fl�chenfarbe
	txFileFont(gxCMM, "thymes21.gft", &tv[0]);
    txSetFont(&tv[0]);
    txSetFace(txTRANS);
    txSetColor(grBLACK, grWHITE);
}

void closedesk(void)
{
	txFreeFont(&tv[0]);
	gxSetMode(gxTEXT);
	gxSetUserMalloc(0, 0, 0);
}

/* Beendet das Programm */

void exite()
{
    linien();
    grStopMouse();
    exit(1);
}

void abdunkeln(void)
{
    int leer, i;
    int farbe, red[16], green[16], blue[16];

    for (farbe = 0; farbe < 16; farbe++)
    {
    	gxGetPaletteRGB(farbe, &red[farbe], &blue[farbe], &green[farbe]);
    }
    for(i = 0; i < 16; i++)
    {
    	savered[i] = red[i];
    	savegreen[i] = green[i];
    	saveblue[i] = blue[i];
    }
    while (1)
    {
        leer = 0;
        for (farbe = 0; farbe < 16; farbe++)
        {
             if (red[farbe]>4)
             {
                 red[farbe] -= 5;
                 leer |= 1;
             }
             if (blue[farbe]>4)
             {
                 blue[farbe] -= 5;
                 leer |= 2;
             }
             if (green[farbe]>4)
             {
                 green[farbe] -= 5;
                 leer |= 4;
             }
		 	 gxSetPaletteRGB(farbe, red[farbe], blue[farbe], green[farbe]);
        }
 	 	if (leer == 0)
			break;
    }
}

/* Macht die Maus sichtbar */

void maussehen(void)
{
    grDisplayMouse(grSHOW);
    grTrackMouse(grTRACK);
}

/* L�st die Maus verschwinden */

void mausnichtsehen(void)
{
   	grDisplayMouse(grHIDE);
    grTrackMouse(grNOTRACK);
}

/* Mahlt die Mausk�stchen */

void button(int m, struct TASTE *b)
{
    int poly[25];
    int x,y, x2, y2;

    mausnichtsehen();
    x = b->x;
    y = b->y;
    x2= b->x+b->b;
    y2= b->y+b->h;
    grSetBkColor(b->bf);
	grClearArea(x, y, x2, y2);

    if (!m)
    {
	    if (b->u)
		   grSetColor(7);
	    else
		   grSetColor(15);
        switch (b->r)
	     {
	     default:
	     case 4:
		     poly[18] = x2 - 3;
		     poly[19] = y + 3;
		     poly[20] = x + 3;
		     poly[21] = y + 3;
		     poly[22] = x + 3;
		     poly[23] = y2 - 3;
	     case 3:
		     poly[12] = x + 2;
		     poly[13] = y2 - 2;
		     poly[14] = x + 2;
		     poly[15] = y + 2;
		     poly[16] = x2 - 2;
		     poly[17] = y + 2;
	     case 2:
		     poly[6] = x2 - 1;
		     poly[7] = y + 1;
		     poly[8] = x + 1;
		     poly[9] = y + 1;
		     poly[10] = x + 1;
		     poly[11] = y2 - 1;
	     case 1:
		     poly[0] = x;
		     poly[1] = y2;
		     poly[2] = x;
		     poly[3] = y;
		     poly[4] = x2;
		     poly[5] = y;

		     grDrawPoly(poly, b->r*3, grOUTLINE);
	     case 0:
		     break;
	     }

	     if (!b->u)
		    grSetColor(8);
	     else
		    grSetColor(15);
 	     switch (b->r)
	     {
	     default:
	     case 4:
		     poly[18] = x2 - 2;
		     poly[19] = y + 4;
		     poly[20] = x2 - 2;
		     poly[21] = y2 - 2;
		     poly[22] = x + 3;
		     poly[23] = y2 - 2;
	     case 3:
		     poly[12] = x + 2;
		     poly[13] = y2 - 1;
		     poly[14] = x2 - 1;
		     poly[15] = y2 - 1;
		     poly[16] = x2 - 1;
		     poly[17] = y + 3;
	     case 2:
		     poly[6] = x2;
		     poly[7] = y + 2;
		     poly[8] = x2;
		     poly[9] = y2;
		     poly[10] = x + 1;
		     poly[11] = y2;
	     case 1:
		     poly[0] = x;
		     poly[1] = y2 + 1;
		     poly[2] = x2 + 1;
		     poly[3] = y2 + 1;
		     poly[4] = x2 + 1;
		     poly[5] = y + 1;

		     grDrawPoly(poly, b->r*3, grOUTLINE);
	     case 0:
		     break;
	     }

	     txSetColor(grBLACK, grWHITE);
	     if (b->text)
	     {
    	     txSetAlign(txCENTER, txCENTER);
		     txSetColor(b->vf, b->hf);
		     txPutString(b->text, b->x+(b->b/2), b->y+(b->h/2)+7);
         }
    }
    else
    {
	    if (b->text)
	    {
    	    txSetAlign(txCENTER, txCENTER);
		    txSetColor(b->vf, b->hf);
		    txPutString(b->text, b->x+(b->b/2)+2, b->y+(b->h/2)+9);
        }
        if (b->r)
        {
		    grSetColor(8);
		    grMoveTo(x,y);
		    grLineTo(x2,y);
		    grMoveTo(x,y);
		    grLineTo(x,y2);
 	    }
    }
    maussehen();
}

void fenster(struct TASTE *b)
{
    mausnichtsehen();
    grSetColor(8);
    grDrawRect(b->x, b->y, b->x+b->b, b->y+b->h, grOUTLINE);
    grSetBkColor(0);
	grClearArea(b->x+1, b->y+1, b->x+b->b-1, b->y+b->h-1);
    grSetBkColor(15);
	grClearArea(b->x+3, b->y+3, b->x+3, b->y+3);
    grSetBkColor(7);
	grClearArea(b->x+4, b->y+4, b->x+4, b->y+4);
	grClearArea(b->x+4, b->y+3, b->x+4, b->y+3);
	grClearArea(b->x+3, b->y+4, b->x+3, b->y+4);
    grSetBkColor(8);
	grClearArea(b->x+5, b->y+5, b->x+5, b->y+5);
	grClearArea(b->x+5, b->y+4, b->x+5, b->y+4);
	grClearArea(b->x+4, b->y+5, b->x+4, b->y+5);
    maussehen();
}

/* Schaut ob die Maus bet�tigt wurde */

void bearbeitetaste(struct TASTE *ta)
{
	struct TASTE *t;
    int mb, style, color;

	grGetMousePos(&mx , &my);
    grGetMouseStyle(&style, &color);
	if ((t = suchetaste(mx, my, ta)) != 0)
    {
        if(style != t->ms)
			grSetMouseStyle(t->ms, 15);
        mb = grGetMouseButtons();
	    if (mb == grLBUTTON)
        {
	        mb = grGetMouseButtons();
            if (t->p)
            {
	            button(1, t);
                gxDelay(70);
			    button(0, t);
                if(raus == 1)
                	return;
			    t->p();
            }
    	}
	}
	else
    {
	    if(style != 0)
			grSetMouseStyle(0, 15);
	}
}

void anzeige(void)
{
	GXHEADER bild;
    struct TASTE *t;

    button(0, &listeinfo[0]);
    pcxFileImage(gxCMM,"logic.pcx",&bild, gxDETECT);
    gxVirtualDisplay(&bild, 0, 0, 4, 4, 210, 25, PAGE1);
    gxDestroyVirtual(&bild);
    txSetColor(grWHITE, grBLACK);
    fenster(&listeinfo[6]);
    t = &listeinfo[6];
    sprintf(temp, "%d", zeit);
	txPutString(temp, t->x+25, t->y+17);
    t = &listeinfo[7];
    fenster(&listeinfo[7]);
    sprintf(temp, "%d", steine);
	txPutString(temp, t->x+25, t->y+17);
    t = &listeinfo[8];
    fenster(&listeinfo[8]);
    sprintf(temp, "%d", punkte);
	txPutString(temp, t->x+50, t->y+17);
    txSetColor(grBLACK, grWHITE);
    t = &listeinfo[6];
	txPutString("Zeit", t->x+80, t->y+17);
    t = &listeinfo[7];
	txPutString("Steine", t->x+80, t->y+17);
    t = &listeinfo[8];
	txPutString("Punkte", t->x+130, t->y+17);
}

//    grSetBkColor(0);
//	grClearArea(t->x+5, t->y+1, t->x+t->b-1, t->y+t->h-1);

int bearbeitespringen(int i2)
{
	int i;

    if(feld[i2][7] == 0)
    {
        if(feld[i2][4] < feld[feld1][4] &&
		    feld[feld1][4]-2 == feld[i2][4])
        {
		    for(i = 0; feld[i][8] != 0; i++)
		    {
                if(feld[i][4] == feld[i2][4]+1 && feld[i][5] == feld[i2][5] && feld[i][7] == 1)
                {
                	return(i);
                }
		    }
        }
        else
        {
            if(feld[i2][4] > feld[feld1][4] &&
			    feld[feld1][4]+2 == feld[i2][4])
            {
			    for(i = 0; feld[i][8] != 0; i++)
			    {
                    if(feld[i][4] == feld[i2][4]-1 && feld[i][5] == feld[i2][5] && feld[i][7] == 1)
                    {
	                	return(i);
                    }
			    }
            }
            else
            {
                if(feld[i2][5] < feld[feld1][5] &&
				    feld[feld1][5]-2 == feld[i2][5])
                {
				    for(i = 0; feld[i][8] != 0; i++)
				    {
                        if(feld[i][5] == feld[i2][5]+1 && feld[i][4] == feld[i2][4] && feld[i][7] == 1)
                        {
		                	return(i);
                        }
				    }
                }
                else
                {
                    if(feld[i2][5] > feld[feld1][5] &&
					    feld[feld1][5]+2 == feld[i2][5])
                    {
					    for(i = 0; feld[i][8] != 0; i++)
					    {
                            if(feld[i][5] == feld[i2][5]-1 && feld[i][4] == feld[i2][4] && feld[i][7] == 1)
                            {
			                	return(i);
                            }
					    }
                    }
                }
            }
        }
    }
    return(999);
}

// hauptspiel

void bearbeitefeld(void)
{
    int mb, i, i2, style, color, gefunden;
    struct TASTE *t;

    grGetMouseStyle(&style, &color);
	grGetMousePos(&mx , &my);
    if(mx != smx && my != smy)
    {
        smx = mx;
        smy = my;
        if(my < 28)
        {
		    grSetMouseStyle(0, 15);
            button(0, &listeinfo[0]);
	        for (i = 0; listeinfo[i].b != 0; i++)
	        {
                if(listeinfo[i].s != 1)
			        button(0, &listeinfo[i]);
            }
            t = &listeinfo[3];
            if(t->s == 1)
		        button(1, &listeinfo[3]);
    	    for(;;)
            {
	            bearbeitetaste(&listeinfo[0]);
                if(raus == 1)
            	    return;
			    grGetMousePos(&mx , &my);
		        if(my > 28)
            	    break;
            }
            button(0, &listeinfo[0]);
		    grSetMouseStyle(2, 15);
            anzeige();
        }
        if ((i2 = suchefeld(mx, my)) != 0)
        {
            if(durchlauf == 0)
            {
                if(feld[i2][7] == 1)
                {
			        if(style != 5)
					    grSetMouseStyle(5, 15);
                }
                if(feld[i2][7] == 0)
                {
			        if(style != 6)
					    grSetMouseStyle(6, 15);
                }
            }
            if(durchlauf == 1)
            {
                if(feld[i2][7] == 1)
                {
			        if(style != 4)
					    grSetMouseStyle(4, 15);
                }
                else
                {
	                gefunden = bearbeitespringen(i2);
                    if(gefunden != 999)
                    {
				        if(style != 5)
					        grSetMouseStyle(5, 15);
                    }
                    else
                    {
				        if(gefunden == 999 && style != 6)
                        {
				            if(style != 6)
					            grSetMouseStyle(6, 15);
                        }
            	    }
        	    }
            }
        }
    }
	mb = grGetMouseButtons();
	if (mb == grLBUTTON)
    {
        while (grGetMouseButtons())
		{
          grGetMouseButtons();
	    }
        durchlauf++;
        if(durchlauf == 1)
        {
			if(feld[i2][7] == 1)
            {
            	mausnichtsehen();
              	feld1 = feld[i2][9];
				feld[i2][8] = 4;
                feldmalen(i2);
                gxDelay(200);
            	maussehen();
			}
            else
			    if(feld[i2][7] == 0)
                {
                    durchlauf = 1;
                }
        }
        if(durchlauf == 2)
        {
			if(feld[i2][9] == feld1)
            {
            	mausnichtsehen();
				feld[i2][8] = 7;
                feldmalen(i2);
                durchlauf = 0;
                feld1 = 0;
                gxDelay(200);
            	maussehen();
                return;
            }
			if(feld[i2][7] == 1)
            {
            	mausnichtsehen();
				feld[i2][8] = 4;
                feldmalen(i2);
				feld[feld1][8] = 7;
                feldmalen(feld1);
                durchlauf = 1;
                feld1 = feld[i2][9];
                gxDelay(200);
            	maussehen();
                return;
            }

            feld2 = feld[i2][9];
	        gefunden = bearbeitespringen(i2);
			if(gefunden != 999)
			{
                mausnichtsehen();
				feldaktion(gefunden);
                durchlauf = 1;
                maussehen();
            }
            else
            {
			    if(feld[i2][7] == 1)
                {
                    durchlauf--;
                    maussehen();
                }
                else
					durchlauf--;
            }
        }
    }
}

void linien(void)
{
	int i, i2;

    mausnichtsehen();
    grSetColor(0);
    for(i = 0; i < 50; i++)
	{
        gxDelay(10);
        for(i2 = 0; i2 < 500; i2 += 25)
			grDrawLine(0, i+i2, 640, i+i2);
	}
    maussehen();
}

void bildauf(void)
{
	int i, i2;

    mausnichtsehen();
    grSetColor(0);
    for(i = 0; i < 50; i++)
	{
        gxDelay(10);
        for(i2 = 0; i2 < 500; i2 += 25)
		    gxVirtualDisplay(&bild2, 0, i+i2, 0, i+i2, 640, i+i2, page);
	}
    maussehen();
}

void brettende(void)
{
 	int i;

    mausnichtsehen();
    grSetBkColor(7);
	grClearArea(215, 4, 635, 25);
	for (i = 0; quitinfo[i].b != 0; i++)
	{
		button(0, &quitinfo[i]);
    }
    maussehen();
	for(;;)
    {
        bearbeitetaste(&quitinfo[0]);
        if(raus == 1)
        {
		    mausnichtsehen();
            feld[feld1][8] = 7;
	        feld1 = 0;
            feld[feld2][8] = 7;
            feld2 = 0;
		    maussehen();
        	return;
        }
        if(raus == 2)
        {
		    mausnichtsehen();
            grSetBkColor(7);
	        grClearArea(215, 4, 635, 25);
	        for (i = 1; listeinfo[i].b != 0; i++)
	        {
		        button(0, &listeinfo[i]);
            }
            raus = 0;
		    maussehen();
        	return;
        }
	}
}

/* Schaut ob die Maus sich auf einen Mausk�stchen befindet */

struct TASTE *suchetaste(int mx, int my, struct TASTE *tasten)
{
    int i;

	for (i = 0; tasten->b != 0; i++, tasten++)
		if (!tasten->s &&
			(mx > tasten->x && mx < tasten->x+tasten->b &&
            my > tasten->y && my < tasten->y+tasten->h))
            return (tasten);
	return (0);
}

int suchefeld(int mx, int my)
{
    int i;

	for (i = 0; feld[i][8] != 0; i++)
		if (feld[i][6] == 1 &&
			(mx > feld[i][0] && mx < feld[i][0]+feld[i][2] &&
            my > feld[i][1] && my < feld[i][1]+feld[i][3]))
            return (i);
	return (0);
}

void feldmalen(int i)
{
    if(feld[i][6] == 0 && feld[i][10] != 12)
	    gxVirtualDisplay(&hinter[feld[i][10]], 1, 1, feld[i][0], feld[i][1], feld[i][0]+feld[i][2]-1, feld[i][1]+feld[i][3]-1, page);
	sternenfeldmalen(i);
	if(feld[i][6] == 1)
    {
        if(feld[i][7] == 1)
        {
            if(feld[i][8] == 4)
		        gxVirtualDisplay(&stein[2], 1, 1, feld[i][0], feld[i][1], feld[i][0]+feld[i][2]-1, feld[i][1]+feld[i][3]-1, page);
            if(feld[i][8] == 7)
		        gxVirtualDisplay(&stein[1], 1, 1, feld[i][0], feld[i][1], feld[i][0]+feld[i][2]-1, feld[i][1]+feld[i][3]-1, page);
        }
        else
	        if(feld[i][7] == 0)
		        gxVirtualDisplay(&stein[0], 1, 1, feld[i][0], feld[i][1], feld[i][0]+feld[i][2]-1, feld[i][1]+feld[i][3]-1, page);
	}
}

void sternenfeldmalen(int i)
{
    if(feld[i][6] == 0)
    {
        if(feld[i][10] == 12)
	        gxVirtualDisplay(&ausgabe, feld[i][0], feld[i][1], feld[i][0], feld[i][1], feld[i][0]+feld[i][2]-1, feld[i][1]+feld[i][3]-1, page);
        else
            if(feld[i][10] == 0)
		        gxVirtualDisplay(&ausgabe, feld[i][0]+7, feld[i][1], feld[i][0]+7, feld[i][1], feld[i][0]+feld[i][2]-1-7, feld[i][1]+feld[i][3]-1, page);
            if(feld[i][10] == 1)
		        gxVirtualDisplay(&ausgabe, feld[i][0], feld[i][1]+7, feld[i][0], feld[i][1]+7, feld[i][0]+feld[i][2]-1, feld[i][1]+feld[i][3]-1-7, page);
            if(feld[i][10] == 2)
		        gxVirtualDisplay(&ausgabe, feld[i][0], feld[i][1]+7, feld[i][0], feld[i][1]+7, feld[i][0]+feld[i][2]-1, feld[i][1]+feld[i][3]-1, page);
            if(feld[i][10] == 3)
		        gxVirtualDisplay(&ausgabe, feld[i][0], feld[i][1], feld[i][0], feld[i][1], feld[i][0]+feld[i][2]-1-5, feld[i][1]+feld[i][3]-1-7, page);
            if(feld[i][10] == 4)
		        gxVirtualDisplay(&ausgabe, feld[i][0]+7, feld[i][1], feld[i][0]+7, feld[i][1], feld[i][0]+feld[i][2]-1, feld[i][1]+feld[i][3]-1, page);
            if(feld[i][10] == 5)
		        gxVirtualDisplay(&ausgabe, feld[i][0], feld[i][1], feld[i][0], feld[i][1], feld[i][0]+feld[i][2]-1-7, feld[i][1]+feld[i][3]-1, page);
	}
}

void spiel(void)
{
    int i;

    linien();
	sternepos();
    raus = 1;
    zeit = 999;
    steine = spielsteine[spielbrett];
    punkte = 0;
    spielzeit = 0;
    maussehen();
    neu();
    for(;;)
	{
        bearbeitefeld();
		sternebewegen();
	    gxVirtualDisplay(&ausgabe, 0, 30, 0, 30, 19, 480, page);
	    gxVirtualDisplay(&ausgabe, 620, 30, 620, 30, 640, 480, page);
	    for (i = 0; feld[i][8] != 0; i++)
	    {
		    sternenfeldmalen(i);
        }
        zeitablauf();
		if(kbhit())
        	getch();
    	if(raus == 1)
		{
		    linien();
            gxDestroyVirtual(&ausgabe);
            gxDestroyVirtual(&stern[0]);
            gxDestroyVirtual(&stern[1]);
            gxDestroyVirtual(&stern[2]);
			return;
		}
    }
}

void zeitablauf(void)
{
	struct TASTE *t;

    if(spielzeit == 1)
    {
		txSetColor(grWHITE, grBLACK);
        zeit--;
        t = &listeinfo[6];
        grSetBkColor(0);
        grClearArea(t->x+5, t->y+1, t->x+t->b-1, t->y+t->h-1);
        sprintf(temp, "%d", zeit);
        txPutString(temp, t->x+25, t->y+17);
        txSetColor(grBLACK, grWHITE);
	}
}

void undo(void)
{
	struct TASTE *t;
    int i;

    t = &listeinfo[3];
    if(t->s == 0)
    {
        mausnichtsehen();
	    t->s = 1;
        button(1, &listeinfo[3]);
	    feld[undo1][7] = undo1belegt;
	    feld[undo2][7] = undo2belegt;
	    feld[undo3][7] = undo3belegt;
        feld[feld1][8] = 7;
	    feld1 = 0;
        feld[feld2][8] = 7;
        feld2 = 0;
		steine++;
        punkte -= 10;
	    durchlauf = 0;
	    for (i = 0; feld[i][8] != 0; i++)
	    {
		    feldmalen(i);
        }
        maussehen();
    }
}

void feldaktion(int i)
{
	struct TASTE *t;

    if(feld[i][7] == 1)
    {
        undo1 = feld[i][9];
        undo1belegt = feld[i][7];
        feld[i][7] = 0;
        feldmalen(i);
        undo2 = feld[feld1][9];
        undo2belegt = feld[feld1][7];
        feld[feld1][7] = 0;
        feld[feld1][8] = 7;
        feldmalen(feld1);
        undo3 = feld[feld2][9];
        undo3belegt = feld[feld2][7];
        feld[feld2][7] = 1;
        feld[feld2][8] = 4;
        feld1 = feld[feld2][9];
        feldmalen(feld2);
        t = &listeinfo[3];
        if(t->s == 1)
        {
		    t->s = 0;
   	    }
        steine--;
        punkte += 10;
        txSetColor(grWHITE, grBLACK);
        t = &listeinfo[7];
        grSetBkColor(0);
	    grClearArea(t->x+5, t->y+1, t->x+t->b-1, t->y+t->h-1);
        sprintf(temp, "%d", steine);
	    txPutString(temp, t->x+25, t->y+17);
        t = &listeinfo[8];
        grSetBkColor(0);
	    grClearArea(t->x+5, t->y+1, t->x+t->b-1, t->y+t->h-1);
        sprintf(temp, "%d", punkte);
	    txPutString(temp, t->x+25, t->y+17);
        txSetColor(grBLACK, grWHITE);
    	gxDelay(100);
		maussehen();
	}
    durchlauf = 1;
}

void neu(void)
{
	struct TASTE *t;
    int i;

    if(raus == 0)
    	brettende();
    if(raus == 1)
    {
        mausnichtsehen();
		grSetMouseStyle(2, 15);
        grSetMousePos(0, 30);
        raus = 0;
        feld[feld1][8] = 7;
	    feld1 = 0;
        feld[feld2][8] = 7;
        feld2 = 0;
	    durchlauf = 0;
        t = &listeinfo[3];
        t->s = 1;
        anzeige();
        steine = spielsteine[spielbrett];
	    for(i = 0; feld[i][8] != 0; i++)
        {
            feld[i][6] = feldan[i][spielbrett];
            feld[i][7] = feldbelegt[i][spielbrett];
            feld[i][10] = feldbild[i][spielbrett];
        }
	    for (i = 0; feld[i][8] != 0; i++)
	    {
		    feldmalen(i);
        }
        maussehen();
	}
}

void lade(void)
{
    int datei;

    if ((datei = open("bilder.txt", O_BINARY)) == 0)
		printf("data error\n");
	read(datei, feldan, sizeof(feldan));
	close(datei);
    if ((datei = open("abb.txt", O_BINARY)) == 0)
		printf("data error\n");
	read(datei, feldbelegt, sizeof(feldbelegt));
	close(datei);
    if ((datei = open("top.txt", O_BINARY)) == 0)
		printf("data error\n");
	read(datei, feldbild, sizeof(feldbild));
	close(datei);
    if ((datei = open("name.txt", O_BINARY)) == 0)
		printf("data error\n");
	read(datei, spielsteine, sizeof(spielsteine));
	close(datei);
}

void quit(void)
{
	raus = 1;
}

void noquit(void)
{
	raus = 2;
}


void hauptmenu(void)
{
    for(;;)
    {
        mausnichtsehen();
        grSetMouseBounds(0, 0, 640, 480);
        raus = 0;
   	    pcxFileImage(gxCMM,"logictit.pcx",&bild2, gxDETECT);
	    bildauf();
	    gxDestroyVirtual(&bild2);
        sprachentexte();
        maussehen();
        for(;;)
        {
            bearbeitetaste(&hauptmenuinfo[0]);
        	if(raus == 1)
            	break;
        	if(kbhit())
            	exite();
        }
	}
}

void sternepos(void)
{
	int i;
	struct TITEL *titel;
	GXHEADER bild;

	gxCreateVirtual(gxCMM, &ausgabe, gxtype, 640, 480);
	gxCreateVirtual(gxCMM, &stern[0], gxtype, 5, 5);
	gxCreateVirtual(gxCMM, &stern[1], gxtype, 5, 5);
	gxCreateVirtual(gxCMM, &stern[2], gxtype, 5, 5);
	gxCreateVirtual(gxCMM, &stern[3], gxtype, 5, 5);
	mausnichtsehen();
	pcxFileImage(gxCMM,"titel.pcx",&bild, gxDETECT);
    page = PAGE1;
    gxVirtualDisplay(&bild, 0, 0, 0, 0, 640, 480, PAGE1);
    gxGetImage(&stern[0], 0, 300, 2, 302, PAGE1);
    gxGetImage(&stern[1], 2, 300, 5, 303, PAGE1);
    gxGetImage(&stern[2], 5, 300, 9, 304, PAGE1);
    gxGetImage(&stern[3], 10, 300, 14, 304, PAGE1);
	gxDestroyVirtual(&bild);
	gxClearDisplay(0, 0);
    grSetMouseBounds(0, 0, 640, 480);
    gxClearVirtual(&ausgabe, 0);
    for (i = 0; titelstern[i].g != 0; i++)
    {
	    titel = &titelstern[i];
        titel->y = rand() % 480;
    }
    for (i = 0; titelstern[i].g != 0; i++)
    {
	    titel = &titelstern[i];
        zufall = rand() % 600;
        titel->x = 0 - zufall;
    }
}

void sternebewegen(void)
{
	int i;
	struct TITEL *titel;

    for (i = 0; titelstern[i].g != 0; i++)
    {
	    titel = &titelstern[i];
	    gxVirtualVirtual(&stern[3], 1, 1, titel->sb, titel->sh, &ausgabe, titel->x, titel->y, gxSET);
        titel->x += titel->g;
	    gxVirtualVirtual(&stern[titel->s], 1, 1, titel->sb, titel->sh, &ausgabe, titel->x, titel->y, gxSET);
        if(titel->x > 650)
        {
		    titel->x = 0;
            titel->y = rand() % 480;
        }
    }
}

void brettaussuchen(void)
{
	struct TASTE *t;
    int mb, i, taste;
	GXHEADER bild;

    linien();
    for(;;)
    {
        spielbrett = 0;
		grSetMouseStyle(0, 15);
		sternepos();
		t = &brettmenuinfo[4];
	    sprintf(temp,"Brett %d", spielbrett+1);
        t->text = temp;
    	button(0, t);
	    for (i = 0; brettmenuinfo[i].b != 0; i++)
	    {
		    button(0, &brettmenuinfo[i]);
        }
	    pcxFileImage(gxCMM,"logic.pcx",&bild, gxDETECT);
        gxVirtualDisplay(&bild, 0, 0, 210, 150, 416, 171, PAGE1);
	    gxDestroyVirtual(&bild);
        grSetMouseBounds(121, 141, 511, 325);
        malebrett();
        maussehen();
        for(;;)
        {
			sternebewegen();
	        gxVirtualDisplay(&ausgabe, 0, 0, 0, 0, 119, 480, page);
	        gxVirtualDisplay(&ausgabe, 522, 0, 522, 0, 640, 480, page);
	        gxVirtualDisplay(&ausgabe, 119, 0, 119, 0, 522, 139, page);
	        gxVirtualDisplay(&ausgabe, 119, 342, 119, 342, 522, 480, page);
            gxSetPage(page);
            page ^= 1;
			mb = grGetMouseButtons();
	        if (mb == grLBUTTON || mb == grRBUTTON)
            {
	            mb = grGetMouseButtons();
                bearbeitetaste(&brettmenuinfo[0]);
	        }
            if(raus == 1)
			{
                gxDestroyVirtual(&ausgabe);
                gxDestroyVirtual(&stern[0]);
                gxDestroyVirtual(&stern[1]);
                gxDestroyVirtual(&stern[2]);
			    return;
            }
        	if(kbhit())
            {
                taste = getch();
                if (taste == 0)
		            taste = getch();
                if(taste == 27)
                {
            	    raus = 1;
            	}
        	}
	    }
	}
}
    //frei = gxVirtualFree(gxCMM);
    //printf("%ld",frei);
    //getch();

void brettplus(void)
{
	struct TASTE *t;

    if(spielbrett < 19)
	{
	    spielbrett++;
    	t = &brettmenuinfo[4];
	    sprintf(temp,"Brett %d", spielbrett+1);
        t->text = temp;
    	button(0, t);
        malebrett();
    	gxDelay(50);
    }
}

void brettminus(void)
{
	struct TASTE *t;

    if(spielbrett > 0)
	{
	    spielbrett--;
    	t = &brettmenuinfo[4];
	    sprintf(temp,"Brett %d", spielbrett+1);
        t->text = temp;
    	button(0, t);
        malebrett();
    	gxDelay(50);
    }
}

void malebrett(void)
{
    malebrettzu();
    gxVirtualDisplay(&bilder, 0, 0, 243, 183, 507, 327, PAGE1);
    gxDestroyVirtual(&bilder);
}


void malebrettzu(void)
{
    if(spielbrett == 0)
	    pcxFileImage(gxCMM,"bbrett1.pcx",&bilder, gxDETECT);
    if(spielbrett == 1)
	    pcxFileImage(gxCMM,"bbrett2.pcx",&bilder, gxDETECT);
    if(spielbrett == 2)
	    pcxFileImage(gxCMM,"bbrett3.pcx",&bilder, gxDETECT);
    if(spielbrett == 3)
	    pcxFileImage(gxCMM,"bbrett4.pcx",&bilder, gxDETECT);
    if(spielbrett == 4)
	    pcxFileImage(gxCMM,"bbrett5.pcx",&bilder, gxDETECT);
    if(spielbrett == 5)
	    pcxFileImage(gxCMM,"bbrett6.pcx",&bilder, gxDETECT);
    if(spielbrett == 6)
	    pcxFileImage(gxCMM,"bbrett7.pcx",&bilder, gxDETECT);
    if(spielbrett == 7)
	    pcxFileImage(gxCMM,"bbrett8.pcx",&bilder, gxDETECT);
    if(spielbrett == 8)
	    pcxFileImage(gxCMM,"bbrett9.pcx",&bilder, gxDETECT);
    if(spielbrett == 9)
	    pcxFileImage(gxCMM,"bbrett10.pcx",&bilder, gxDETECT);
    if(spielbrett == 10)
	    pcxFileImage(gxCMM,"bbrett11.pcx",&bilder, gxDETECT);
    if(spielbrett == 11)
	    pcxFileImage(gxCMM,"bbrett12.pcx",&bilder, gxDETECT);
    if(spielbrett == 12)
	    pcxFileImage(gxCMM,"bbrett13.pcx",&bilder, gxDETECT);
    if(spielbrett == 13)
	    pcxFileImage(gxCMM,"bbrett14.pcx",&bilder, gxDETECT);
    if(spielbrett == 14)
	    pcxFileImage(gxCMM,"bbrett15.pcx",&bilder, gxDETECT);
    if(spielbrett == 15)
	    pcxFileImage(gxCMM,"bbrett16.pcx",&bilder, gxDETECT);
    if(spielbrett == 16)
	    pcxFileImage(gxCMM,"bbrett17.pcx",&bilder, gxDETECT);
    if(spielbrett == 17)
	    pcxFileImage(gxCMM,"bbrett18.pcx",&bilder, gxDETECT);
    if(spielbrett == 18)
	    pcxFileImage(gxCMM,"bbrett19.pcx",&bilder, gxDETECT);
    if(spielbrett == 19)
	    pcxFileImage(gxCMM,"bbrett20.pcx",&bilder, gxDETECT);
}

void info(void)
{
	GXHEADER hintergrund;
	GXHEADER bild;
    int mb, i;

    mausnichtsehen();
    gxCreateVirtual(gxCMM, &hintergrund, gxtype, 600, 400);
	gxDisplayVirtual(110, 130, 530, 350, page, &hintergrund, 0, 0);
    for (i = 0; aboutinfo[i].b != 0; i++)
    {
	    button(0, &aboutinfo[i]);
    }
	pcxFileImage(gxCMM,"logic.pcx",&bild, gxDETECT);
    gxVirtualDisplay(&bild, 0, 0, 210, 150, 416, 171, PAGE1);
	gxDestroyVirtual(&bild);
    txPutString("             Info                ", 320, 190);
    txPutString("         						  ", 320, 210);
    txPutString("                             	  ", 320, 230);
    txPutString("             					  ", 320, 250);
    txPutString("  								  ", 320, 270);
    txPutString(" 								  ", 320, 290);
    txPutString(" 								  ", 320, 310);
    txPutString(" Press any mouse button to quit. ", 320, 330);
	for(;;)
    {
		mb = grGetMouseButtons();
	    if (mb == grLBUTTON || mb == grRBUTTON)
        {
            gxVirtualDisplay(&hintergrund, 0, 0, 110, 130, 530, 350, page);
            gxDestroyVirtual(&hintergrund);
		    maussehen();
			return;
	    }
	}
}

void about(void)
{
	GXHEADER bild;
    int mb, i;

    linien();
	sternepos();
    for (i = 0; aboutinfo[i].b != 0; i++)
    {
	    button(0, &aboutinfo[i]);
    }
	pcxFileImage(gxCMM,"logic.pcx",&bild, gxDETECT);
    gxVirtualDisplay(&bild, 0, 0, 210, 150, 416, 171, PAGE1);
	gxDestroyVirtual(&bild);
    if(sprache == 0)
    {
        txPutString("           Logic leap            ", 320, 190);
        txPutString("     von Christian Ofenberg      ", 320, 210);
        txPutString("             1996                ", 320, 230);
        txPutString("       97990 Weikersheim         ", 320, 250);
        txPutString("     Telephone: 07934 8684       ", 320, 270);
        txPutString("       Dieses Programm ist       ", 320, 290);
        txPutString(" 		  FREI KOPIERBAR.		  ", 320, 310);
        txPutString("Zum weitermachen linke Taste dr�cken.", 310, 330);
    }
    if(sprache == 1)
    {
        txPutString("           Logic leap            ", 320, 190);
        txPutString("     by Christian Ofenberg       ", 320, 210);
        txPutString("             1996                ", 320, 230);
        txPutString("       97990 Weikersheim         ", 320, 250);
        txPutString("     Telephone: 07934 8684       ", 320, 270);
        txPutString("   This Program is Freeware.     ", 320, 290);
        txPutString(" 								  ", 320, 310);
        txPutString(" Press any mouse button to quit. ", 320, 330);
    }
	grSetMouseBounds(121, 141, 511, 325);
    for(;;)
    {
        sternebewegen();
	    gxVirtualDisplay(&ausgabe, 0, 0, 0, 0, 119, 480, page);
	    gxVirtualDisplay(&ausgabe, 522, 0, 522, 0, 640, 480, page);
	    gxVirtualDisplay(&ausgabe, 119, 0, 119, 0, 522, 139, page);
	    gxVirtualDisplay(&ausgabe, 119, 342, 119, 342, 522, 480, page);
        gxSetPage(page);
        page ^= 1;
		mb = grGetMouseButtons();
	    if (mb == grLBUTTON || mb == grRBUTTON)
        {
        	raus = 1;
	    }
        if(raus == 1)
		{
            gxDestroyVirtual(&ausgabe);
            gxDestroyVirtual(&stern[0]);
            gxDestroyVirtual(&stern[1]);
            gxDestroyVirtual(&stern[2]);
		    maussehen();
			return;
        }
	}
}

void sprachen(void)
{
   	sprache++;
    if(sprache == 2)
    	sprache = 0;
	sprachentexte();
}

void sprachentexte(void)
{
	struct TASTE *t;
    int i;

    if(sprache == 0)
    {
		t = &quitinfo[0];
        t->text = "Sind sie sicher?";
		t = &quitinfo[1];
        t->text = "Ja";
		t = &quitinfo[2];
        t->text = "Nein";
		t = &brettmenuinfo[1];
        t->text = "Anfangen";
		t = &brettmenuinfo[2];
        t->text = "Raus";
		t = &hauptmenuinfo[0];
        t->text = "Spiel";
		t = &hauptmenuinfo[1];
        t->text = "Editor";
		t = &hauptmenuinfo[2];
        t->text = "Autor";
		t = &hauptmenuinfo[3];
        t->text = "Deutsch";
		t = &hauptmenuinfo[4];
        t->text = "Ende";
		t = &listeinfo[1];
        t->text = "Neu";
		t = &listeinfo[2];
        t->text = "Raus";
		t = &listeinfo[3];
        t->text = "Zur�ck";
		t = &listeinfo[4];
        t->text = "Hilfe";
		t = &editorinfo[1];
        t->text = "Speichern";
		t = &editorinfo[2];
        t->text = "Testen";
		t = &editorinfo[3];
        t->text = "L�schen";
		t = &editorinfo[4];
        t->text = "Raus";
		t = &editorinfo[8];
        t->text = "Brett 1";
    }
    if(sprache == 1)
    {
		t = &quitinfo[0];
        t->text = "Are you sure?";
		t = &quitinfo[1];
        t->text = "Yes";
		t = &quitinfo[2];
        t->text = "No";
		t = &brettmenuinfo[1];
        t->text = "Start";
		t = &brettmenuinfo[2];
        t->text = "Quit";
		t = &hauptmenuinfo[0];
        t->text = "Game";
		t = &hauptmenuinfo[1];
        t->text = "Editor";
		t = &hauptmenuinfo[2];
        t->text = "About";
		t = &hauptmenuinfo[3];
        t->text = "English";
		t = &hauptmenuinfo[4];
        t->text = "Quit";
		t = &listeinfo[1];
        t->text = "Neu";
		t = &listeinfo[2];
        t->text = "Quit";
		t = &listeinfo[3];
        t->text = "Undo";
		t = &listeinfo[4];
        t->text = "Help";
		t = &editorinfo[1];
        t->text = "Save";
		t = &editorinfo[2];
        t->text = "Test";
		t = &editorinfo[3];
        t->text = "Clear";
		t = &editorinfo[4];
        t->text = "Quit";
		t = &editorinfo[8];
        t->text = "Brett 1";
    }
	for (i = 0; hauptmenuinfo[i].b != 0; i++)
	{
		cobutton(0, &hauptmenuinfo[i]);
    }
}

/* Hauptprogramm */

void main(void)
{
	GXHEADER bild;
    int i, i2, i3, i4, i5;

	opendesk();
	gxClearDisplay(0,0);
    sprache = 0;
    grInitMouse();
    grSetMouseStyle(grCARROW, 15);
    for(i = 0, i3 = 0; i < 15; i++)
    {
        for(i2 = 0; i2 < 15; i2++, i3++)
        {
            feld[i3][4] = i2;
            feld[i3][5] = i;
        }
    }
    for(i = 0, i3 = 30, i4 = 0; i4 < 224; i3 += 30)
    {
       for(i2 = 20, i5 = 0; i5 < 15; i++, i2 += 40, i4++, i5++)
       {
    	   feld[i][0] = i2;
           feld[i][1] = i3;
           feld[i][2] = 40;
           feld[i][3] = 30;
           feld[i][8] = 7;
           feld[i][9] = i4;
           feld[i][10] = feldbild[i][spielbrett];
       }
    }
	gxCreateVirtual(gxCMM, &steinausgabe, gxtype, 41, 31);
    for(i = 0; i < 3; i++)
		gxCreateVirtual(gxCMM, &stein[i], gxtype, 41, 31);
    for(i = 0; i < 13; i++)
		gxCreateVirtual(gxCMM, &hinter[i], gxtype, 41, 31);
   	pcxFileImage(gxCMM,"stein.pcx",&bild, gxDETECT);
    page = PAGE1;
    gxVirtualDisplay(&bild, 0, 0, 0, 0, 640, 480, PAGE1);
    gxGetImage(&stein[0], 0, 0, 40, 30, PAGE1);
    gxGetImage(&stein[1], 41, 0, 81, 30, PAGE1);
    gxGetImage(&stein[2], 82, 0, 122, 30, PAGE1);
    for(i = 0, i2 = 0; i < 12; i++, i2 += 41)
	    gxGetImage(&hinter[i], i2, 31, i2+41, 61, PAGE1);
	gxDestroyVirtual(&bild);
    gxClearDisplay(0, 0);
    lade();
    maussehen();
    hauptmenu();
	exite();
}
/*
    frei = gxVirtualFree(gxCMM);
    printf("%ld",frei);
    getch();*/


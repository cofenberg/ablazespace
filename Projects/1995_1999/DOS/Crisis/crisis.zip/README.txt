Informationen �ber  Crisis 1998

	
*********************************- Starten des Programmes: -*************************************
Das Spiel braucht etwas EMS und CMM Speicher, unter Windows 95 sollte es aber keinerlei Probleme
mit dem Speicher geben. Sollte es aber doch Probleme beim Ausf�hren des Programmes geben, sage
ich nur eines: "Also auf MEINEM Rechner klappte das..." 
OK nun ein etwas hilfreicherer Tip, bei einem Fehler gibt das Programm eine Fehlermeldung zur�ck,
die Sie beachten sollten. 

Bevor Sie das Spiel starten, sollten Sie unter Windows alle Daten die verloren gehen k�nnten
sichern, f�r den fall, dass irgend etwas schief geht, und der Rechner sich zum trocknen aufh�ngt.    

Wenn w�hrend des Spieles der Bildschirm einmal kurz rot aufblinkt hei�t das, dass Daten
verlorengehen.
Kopieren Sie am besten das Spiel auf ihre Festplatte.


*************************************- Zum Spiel: -*********************************************

Das Hauptmen�:
	Start      :    Das Spiel starten
	Editor     :    Ein eigenes Brett entwerfen, oder ein fertiges ver�ndern
	Credits    :    Einige Infos �ber den Autor
	Exit       :    Das Spiel verlassen
 	Die Besten :    Die Hightscoore der Verschiedenen Bretter anschauen

	Warten Sie ca. 20 Sekunden(oder dr�cken Sie F6), bekommen Sie einen Demo zu sehen. 
	W�hrend des Spieles k�nnen Sie einen neuen Demo erstellen, indem sie F6 dr�cken.
	Mit ESC verlassen sie den Demo wieder.


*********************************- Der Brett Editor: -******************************************
	Mit dem Editor k�nnen Sie ein eigenes Brett erstellen und speichern. Ist beim Speichern 
	die Funktion `Fest` aktiv so kann das Brett nach dem Speichern nicht mehr vom Editor
	geladen werden, und kann deshalb Logischerweise auch nicht mehr ver�ndert werden. 

        Tastatur:
            SPACE: Auswahl Men� 
            ESC:   Das Men� zum Speichern des Brettes
            1:     Einen Stein setzen
            2:     Ein Loch setzen 
            3/+/-: Ein Bildfeld setzen
            4:     Ein Feld l�schen
    
	Hinweise f�r das Brett style:
		Das ausgesuchte Brett, kann Graphisch noch etwas ihren Vorstellungen angepa�t 
		werden. Als hintergrundbild kann jedes Bild geladen werden, das im Verzeichnis
		`\Bretter\` steht. 
		Hier die Voraussetzungen f�r das Hintergrundbild:
		- Es muss im pcx Format vorliegen. 
		- Die Standart Palette in 256 Farben besitzen.
          	- 640x480 ist die Ideale Gr��e des Bildes.  
                
                Sie k�nnen auch selbst die Graphik f�r die Steine malen. Als kleine Hilfe dient
		das Bild `Schab.pcx`. Alle gemalten Stein Bilder m�ssen im Verzeichnis `\Stone\`
		und ebenfalls im pcx Format vorliegen. Wenn Sie etwas Hilfe oder Orientierung 
		brauchen, dann schauen Sie sich	doch einfach einmal ein fertiges Stein Set an.  
                Wenn Sie selbst Stein Bilder entwerfen, dann m�ssen sie unbedingt auf die Trans-
		parentfarben achten(Farbe: 0 und 255)! Sehen Sie sich deshalb Fertigen Bilder 
		ganz genau an!

Im Spiel selbst ist eine Button Hilfe eingebaut. Wenn der Mauszeiger auf einen Button zeigt, 
wird dessen Funktion erl�utert. Deshalb will ich hier die einzelnen Men�s nicht n�her erl�utern.

*******************************- Das Spielprinzip: -******************************************
Zu beginn des Spieles sehen Sie eine menge Steine auf der Spielfl�che. Ziel des Spieles ist es
nun, so viele Steine wie m�glich vom Tisch zu entfernen. Um eine Stein zu entfernen klicken Sie
einfach einen an, und �berspringen einen anderen, und schon ist der gerade �bersprungene Stein
verschwunden. Wenn Sie nicht nur herumklicken wollen, dann versuchen Sie doch einmal ihr Opfer
durch die Gegend zu schleifen. Dazu klicken Sie den Stein an, und halten die Linke Maustaste 
gedr�ckt. Das Spiel ist dann beendet, wenn kein Stein mehr entfernt werden kann. Nun folgt 
die Auswertung. 

Das Spiel kann in zwei Spielvarianten gespielt werden:
- Classic:  Die normale Variante des Spieles. Es gibt keinerlei Extra Felder.
- Modern :  Es gibt 6 verschiedene Extra Felder die im Spiel erl�utert werden. Die Bretter sind
		etwas Schwieriger und Anspruchsvoller.


***********************************- Tastatur: -***********************************************
   Mit ALT-F4 k�nnen sie das Programm jederzeit beenden.
   
   Wenn Sie sich die einzelnen Maus K�stchen genauer ansehen, dann bemerken Sie sicherlich das 
   ein Buchstabe des K�stchens unterstrichen ist. Das ist der Hot Key f�r diesen Button.
   Halten Sie die ALT-Taste gedr�ckt, und dr�cken Sie den Unterstrichenen Buchstaben. Hat die 
   selbe Wirkung wie die Maus, geht aber schneller.    

   Die �bliche Tasten Belegung:
       h  = Schnellhilfe an- oder ausschalten
      F1 = Die Funktionen der Extra Felder im detail				
      F2 = Von wem ist dieses Programm? Hier stehts! 				
      F3 = Die Letzte fehlermeldung einblenden				
      F4 = Einen Screenshot anfertigen				
      F5 = Das Options Men� �ffnen (oder mit der Maus in eine der Bildschirmecken fahren und die
					linke Maustaste dr�cken)				
      F8 = Maussteuerung				
      F9 = Joysticksteuerung(muss im Options Men� erst kalibriert werden)				
      F10 = Tastatursteuerung				


******************************- Und nun noch die Rechtlichen dinge: -***************************

- Ich �bernehme keine Verantwortung f�r eventuelle Sch�den, die das Programm an ihnen oder ihrem
  Computer verursacht.
- Crisis ist FREEWARE und darf beliebig oft weiterkopiert werden, jedoch untersage ich es, 
  an den Programmdateien irgendwelche �nderungen vorzunehmen.



Adresse des Autors:
	      Christian Ofenberg
	      Mozartstr. 9
 	      97990 Weikersheim

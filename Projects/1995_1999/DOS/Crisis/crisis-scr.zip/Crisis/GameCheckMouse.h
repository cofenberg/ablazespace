void Check_Mouse(void)
{
    struct dostime_t time_save;
    dostime_t time;
    int Kachel, jump, s_mx, s_my;

    if(co_Mouse.Mouse_on == 1)
	    grGetMousePos(&co_Mouse.mx , &co_Mouse.my);
    if(co_Mouse.my < 30)
        leiste();
    if((Kachel = suchefeld(co_Mouse.mx, co_Mouse.my)) != 999)
    {
        if(Game_Info.durchlauf == 0)
        {
            if(Kachel_info[Kachel][1] == 1)  // ist diese Kachel belegt?
			    co_Mouse.Set_Mouse_style = DROP_ANI;
            if(Kachel_info[Kachel][1] == 0)	 // wenn nicht
			    co_Mouse.Set_Mouse_style = NO_ANI;
        }
        if(Game_Info.durchlauf == 1)
        {
             if(Kachel_info[Kachel][1] == 0)
             {
                 jump = Check_jump(Kachel);
                 if(jump != -1) // Ist ein Sprung m�glich?
				    co_Mouse.Set_Mouse_style = DROP_ANI;
                 else  // kein Springen m�glich
				    co_Mouse.Set_Mouse_style = NO_ANI;
             }
             else
			     co_Mouse.Set_Mouse_style = DROP_ANI;
        }
    }
    else
        co_Mouse.Set_Mouse_style = NORMAL;
    if(co_Mouse.Mouse_on == 1)
	    co_Mouse.mb = grGetMouseButtons();
    if(co_Mouse.mb == grRBUTTON)
    {
    	printf("  Belegt: %d ", Kachel_info[Kachel][1]);
    	printf("  Aktivt: %d ", Kachel_info[Kachel][2]);
    	printf("  Hinter: %d ", Kachel_info[Kachel][8]);
        getch();
    }

    if(co_Mouse.mb == grLBUTTON)
    {
        co_Mouse.mb = 0;
	    if(co_Mouse.Mouse_on == 1 || co_Mouse.Joystick_on == 1)
        {
			if(co_Mouse.Mouse_on == 1)
	            grGetMousePos(&co_Mouse.mx, &co_Mouse.my);
            s_mx = co_Mouse.mx;
            s_my = co_Mouse.my;
            for(;;)
            {
				if(co_Mouse.Mouse_on == 1)
    	            if(grGetMouseButtons() != grLBUTTON)
        	        	break;
				if(co_Mouse.Joystick_on == 1)
    	            if(joybutton() == 0)
        	        	break;
				if(co_Mouse.Mouse_on == 1)
    	            grGetMousePos(&co_Mouse.mx, &co_Mouse.my);
		        if((Kachel = suchefeld(co_Mouse.mx, co_Mouse.my)) != 999)
                {
                    if(Game_Info.durchlauf == 0)
                    {
                        if(Kachel_info[Kachel][1] == 1)
                        {
                            Game_Info.feld1 = Kachel;
                            Kachel_info[Game_Info.feld1][2] = 1;
                            feldmalen(Game_Info.feld1, 0);
                            Game_Info.durchlauf = 1;
                        }
                    	else
                        	return;
                    }
                    gxVirtualVirtual(&Mouse_Back, 0, 0, MOUSE_B, MOUSE_H, &SV, co_Mouse.s_mx-M_BX, co_Mouse.s_my-M_BY, gxSET);
                    if(Game_Info.durchlauf == 1)
                    {
                        if(Kachel_info[Kachel][1] == 0)
                        {
                            jump = Check_jump(Kachel);
                            if(jump != -1) // Ist ein Sprung m�glich?
                            {
                                feldaktion(Kachel, jump, 0);
                                gxVirtualDisplay(&SV, co_Mouse.mx-M_BX, co_Mouse.my-M_BY, co_Mouse.mx-M_BX, co_Mouse.my-M_BY, co_Mouse.mx+MOUSE_B-M_BX, co_Mouse.my+MOUSE_H-M_BY, 0);
                                return;
                            }  // Kein Sprung m�glich
                            Kachel_info[Game_Info.feld1][2] = 0;
                            co_Mouse.Mouse_show = 0;
                            feldmalen(Game_Info.feld1, 0);
                            co_Mouse.Mouse_show = 1;
                            Game_Info.feld1 = -1;
                            Game_Info.durchlauf = 0;
                            return;
                        }
                    	else
                        {
                            Kachel_info[Game_Info.feld1][2] = 0;
                            feldmalen(Game_Info.feld1, 0);
                            Game_Info.feld1 = Kachel;
                            Kachel_info[Game_Info.feld1][2] = 1;
                            feldmalen(Game_Info.feld1, 0);
                        }
                    }
                    gxVirtualVirtual(&SV, co_Mouse.mx-M_BX, co_Mouse.my-M_BY, co_Mouse.mx+MOUSE_B-M_BX, co_Mouse.my+MOUSE_H-M_BY, &Mouse_Back, 0, 0, gxSET);
                    gxVirtualVirtual(&SV, co_Mouse.s_mx-20, co_Mouse.s_my-15, co_Mouse.s_mx+KACHEL_B-20, co_Mouse.s_my+KACHEL_H-15, &Mouse_Back2, 0, 0, gxSET);
                    gxVirtualDisplay(&SV, co_Mouse.s_mx-M_BX, co_Mouse.s_my-M_BY, co_Mouse.s_mx-M_BX, co_Mouse.s_my-M_BY, co_Mouse.s_mx+MOUSE_B-M_BX, co_Mouse.s_my+MOUSE_H-M_BY, 0);
                    // Es wurde kein Stein wurde gefunden, der Spieler h�lt die Taste immer
                    // gedr�ckt:
                    if(Game_Info.feld1 == -1)
                    {
                        No_Show_mouse();
                        co_Mouse.Set_Mouse_style = NORMAL;
                        Show_mouse();
	                    SetMouseBounds(0, 30, 620, 465);
						for(;;)
                        {
                            if(co_Mouse.Mouse_on == 1)
                                if(grGetMouseButtons() != grLBUTTON)
                                    break;
                            if(co_Mouse.Joystick_on == 1)
							    if(joybutton() == 0)
                                    break;
                            Move_Mouse(NO);
					 	    CheckSetupOptions();
                            listen_ani();
                            Liste_farbe();
                            starm(&liste_star[0]);
                        }
	                    SetMouseBounds(0, 0, 640, 480);
                    	return;
                    }
                    SetMouseBounds(20, 46, 620, 465);
                    if(co_Mouse.Mouse_on == 1)
  	                	if(grGetMouseButtons() == 0)
                        	break;
                    if(co_Mouse.Joystick_on == 1)
					    if(joybutton() == 0)
                    		break;
                    _dos_gettime(&time);
                    time_save.hsecond = time.hsecond;
                    // Ein richtiger Stein wurde gefunden, der Spieler h�lt die Taste immer
                    // noch gedr�ckt, also l�sst sich der Stein schieben:
                    for(;;)
                    {
                        if((Kachel = suchefeld(co_Mouse.mx, co_Mouse.my)) != 999)
                        {
                            co_Mouse.Set_Mouse_style = PUSH_ANI;
                            jump = Check_jump(Kachel);
                            if(jump != -1) // Ist ein Sprung m�glich?
	                            co_Mouse.Set_Mouse_style = DROP_ANI;   // Springen m�glich
                        }
                        else
	                        co_Mouse.Set_Mouse_style = NO_ANI;
                        listen_ani();
                        Liste_farbe();
                        starm(&liste_star[0]);
                        Move_Mouse(YES);
                        if(co_Mouse.Mouse_on == 1)
                            if(grGetMouseButtons() != grLBUTTON)
                                break;
                        if(co_Mouse.Joystick_on == 1)
						    if(co_Mouse.mb == 0)
                                break;
                    }
                    gxVirtualVirtual(&Mouse_Back, 0, 0, MOUSE_B, MOUSE_H, &SV, co_Mouse.s_mx-M_BX, co_Mouse.s_my-M_BY, gxSET);
                    gxVirtualVirtual(&Mouse_Back2, 0, 0, KACHEL_B, KACHEL_H, &SV, co_Mouse.s_mx-20, co_Mouse.s_my-15, gxSET);
                    gxVirtualDisplay(&SV, co_Mouse.s_mx-20, co_Mouse.s_my-15, co_Mouse.s_mx-20, co_Mouse.s_my-15, co_Mouse.s_mx+KACHEL_B-20, co_Mouse.s_my+KACHEL_H-15, 0);
 			        gxVirtualDisplay(&SV, co_Mouse.mx-M_BX, co_Mouse.my-M_BY, co_Mouse.mx-M_BX, co_Mouse.my-M_BY, co_Mouse.mx+MOUSE_B-M_BX, co_Mouse.my+MOUSE_H-M_BY, 0);
                    if(Game_Info.feld1 != -1)
                    {
                        if(co_Mouse.Set_Mouse_style != DROP_ANI)
                        {
                            gxVirtualVirtual(&Mouse_Back, 0, 0, MOUSE_B, MOUSE_H, &SV, co_Mouse.s_mx-M_BX, co_Mouse.s_my-M_BY, gxSET);
                            gxVirtualVirtual(&Mouse_Back2, 0, 0, KACHEL_B, KACHEL_H, &SV, co_Mouse.s_mx-20, co_Mouse.s_my-15, gxSET);
		                    gxVirtualDisplay(&SV, co_Mouse.s_mx-20, co_Mouse.s_my-15, co_Mouse.s_mx-20, co_Mouse.s_my-15, co_Mouse.s_mx+KACHEL_B-20, co_Mouse.s_my+KACHEL_H-15, 0);
					        gxVirtualVirtual(&SV, co_Mouse.mx-M_BX, co_Mouse.my-M_BY, co_Mouse.mx+MOUSE_B-M_BX, co_Mouse.my+MOUSE_H-M_BY, &Mouse_Back, 0, 0, gxSET);
                            No_Show_mouse();
                            co_Mouse.mx = s_mx;
                            co_Mouse.my = s_my;
                            co_Mouse.Set_Mouse_style = NORMAL;
                            if(co_Mouse.Mouse_on == 1)
    	                        grSetMousePos(co_Mouse.mx, co_Mouse.my);
	                        Show_mouse();
                        }
                        else
                        {
                            if(co_Mouse.Set_Mouse_style == DROP_ANI)
                            {
                                No_Show_mouse();
                                if(jump != -1)
                                    feldaktion(Kachel, jump, 0);
                                Show_mouse();
                            }
                        }
                	}
                    SetMouseBounds(0, 0, 640, 480);
                }
                else
                {
                    Kachel_info[Game_Info.feld1][2] = 0;
                    feldmalen(Game_Info.feld1, 0);
					Game_Info.feld1 = -1;
                    SetMouseBounds(0, 30, 640, 480);
                    for(;;)
                    {
                        if(co_Mouse.Mouse_on == 1)
                            if(grGetMouseButtons() != grLBUTTON)
                                break;
                        if(co_Mouse.Joystick_on == 1)
						    if(joybutton() == 0)
                                break;
                        Move_Mouse(NO);
				 	    CheckSetupOptions();
                        listen_ani();
                        Liste_farbe();
                        starm(&liste_star[0]);
                    }
                    SetMouseBounds(0, 0, 640, 480);
                    return;
               }
            }
		}
        else
        	if(Kachel != 999)
            	Check_durchlauf(Kachel);
    	SetMouseBounds(0, 0, 640, 480);
    }
}

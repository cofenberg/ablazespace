void zeiger_1(void)
{
    gxVirtualDisplay(&SV, 0, Player_Setup.HELP_Y, 0, Player_Setup.HELP_Y, 640, Player_Setup.HELP_Y+30, 0);
    No_Show_mouse();
	pcxFileDisplay("pic/pfeil_2.pcx", 400, 66, 0);
	pcxFileDisplay("pic/pfeil_1.pcx", 400, 98, 0);
	pcxFileDisplay("pic/pfeil_1.pcx", 400, 130, 0);
    Zeiger_info = 2;
    Show_mouse();
}

void zeiger_2(void)
{
    gxVirtualDisplay(&SV, 0, Player_Setup.HELP_Y, 0, Player_Setup.HELP_Y, 640, Player_Setup.HELP_Y+30, 0);
    No_Show_mouse();
	pcxFileDisplay("pic/pfeil_1.pcx", 400, 66, 0);
	pcxFileDisplay("pic/pfeil_2.pcx", 400, 98, 0);
	pcxFileDisplay("pic/pfeil_1.pcx", 400, 130, 0);
    Zeiger_info = 1;
    Show_mouse();
}

void zeiger_3(void)
{
    gxVirtualDisplay(&SV, 0, Player_Setup.HELP_Y, 0, Player_Setup.HELP_Y, 640, Player_Setup.HELP_Y+30, 0);
    No_Show_mouse();
	pcxFileDisplay("pic/pfeil_1.pcx", 400, 66, 0);
	pcxFileDisplay("pic/pfeil_1.pcx", 400, 98, 0);
	pcxFileDisplay("pic/pfeil_2.pcx", 400, 130, 0);
    Zeiger_info = 0;
    Show_mouse();
}

void auswahl(void)
{
    int key, y1, y2, i;
    int save_mx, save_my;

    gxDestroyVirtual(&hinter_pic);
    No_Show_mouse();
    grSetColor(BLACK);
    for(i = 0; i < 29; i += 2)
 	   grDrawLine(0, i, 640, i);
    for(i = 0; i < 640; i += 2)
 	   grDrawLine(i, 0, i, 29);
    if(co_Mouse.Mouse_on == 1)
	    grGetMousePos(&co_Mouse.mx, &co_Mouse.my);
	save_mx = co_Mouse.mx;
	save_my = co_Mouse.my;
    SetMouseBounds(120, 50, 508, 167);
    check = 3;
	Player_Setup.HELP_Y = 0;
    Draw_Back(30);
	pcxFileDisplay("pic/auswahl.pcx", 120, 50, 0);
    gxVirtualDisplay(&stein[1], 0, 0, 440, 59, 479, 88, 0);
    gxVirtualDisplay(&stein[0], 0, 0, 440, 91, 479, 120, 0);
    gxVirtualDisplay(&stein_back_and[zeiger_back], 0, 0, 440, 123, 479, 152, 0);
    check2 = 0;
    Zeige_Brett(2);
	SetFont(0, grWHITE, grBLUE, txTRANS);
	txPutString(BrettStyle.ff_name, 210, 90);
    txPutString(Brett_hintergrund.ff_name, 210, 133);
    bit_but_editor_auswahl[0].an = 0;
    co_Mouse.mx = bit_but_editor_auswahl[0].x+100;
    co_Mouse.my = bit_but_editor_auswahl[0].y+10;
    grSetMousePos(co_Mouse.mx, co_Mouse.my);
    gxDisplayVirtual(0, Player_Setup.HELP_Y, 640, Player_Setup.HELP_Y+30, 0, &SV, 0, Player_Setup.HELP_Y);
    if(Zeiger_info == 0)
        zeiger_3();
    if(Zeiger_info == 1)
         zeiger_2();
    if(Zeiger_info == 2)
         zeiger_1();
    Show_mouse();
    for(;;)
    {
        Move_Mouse(NO);
 	    CheckSetupOptions();
        CheckBitMouse(&bit_but_editor_auswahl[0]);
        if(bioskey(1) != 0)
        {
           key = bioskey(0);
           Check_Key(key, &bit_but_editor_auswahl[0]);
           switch(key)
           {
              case ESC_KEY: case SPACE_KEY:
                  end = 3;
                  break;

             case MINUS_KEY:
				 bild_minus();
                 break;

             case PLUS_KEY:
				 bild_plus();
                 break;

             case KEY_1:
                 Zeiger_info = 0;
		         zeiger_1();
   		         break;

             case KEY_2:
                 Zeiger_info = 1;
		         zeiger_2();
                 break;

             case KEY_3:
                 Zeiger_info = 2;
		         zeiger_3();
                 break;
           }
         }
         if(end != 0 || check2 != 0)
          break;
    }
    No_Show_mouse();
    if(end == 3)
    	end = 0;
    check2 = 0;
    Lade_hintergrund(WAHL_SET);
    menu_back_aktuel();
    y1 = 30;
    y2 = 481;
    for(;;)
    {
       y1 += 2;
       y2 -= 2;
       gxVirtualDisplay(&SV, 0, y1, 0, y1, 640, y1, 0);
       if(y2 > 29)
          gxVirtualDisplay(&SV, 0, y2, 0, y2, 640, y2, 0);
       if(y1 > 480 && y2 < 29)
          break;
     }
    gxVirtualDisplay(&SV, 0, 30, 0, 30, 640, 30, 0);
	pcxFileDisplay("pic/e_liste.pcx", 0, 0, 0);
	ZeigeSteinWahl();
    SetMouseBounds(0, 0, 640, 480);
	co_Mouse.mx = save_mx;
	co_Mouse.my = save_my;
    grSetMousePos(co_Mouse.mx, co_Mouse.my);
    SetFont(0, grWHITE, grBLUE, txTRANS);
    txPutString(Brett_file.ff_name, 540, 18);
    gxDisplayVirtual(0, Player_Setup.HELP_Y, 640, Player_Setup.HELP_Y+30, 0, &SV, 0, Player_Setup.HELP_Y);
	Player_Setup.HELP_Y = 450;
    Show_mouse();
}

void hintergrund_minus(void)
{
	Brett_struct.hintergrund--;
    Zeige_hintergrund();
}

void hintergrund_plus(void)
{
	Brett_struct.hintergrund++;
    Zeige_hintergrund();
}

void steinbilder_plus(void)
{
    No_Show_mouse();
    bilder_plus();
    gxVirtualDisplay(&stein[1], 0, 0, 440, 59, 479, 88, 0);
    gxVirtualDisplay(&stein[0], 0, 0, 440, 91, 479, 120, 0);
    gxVirtualDisplay(&stein_back_and[zeiger_back], 0, 0, 440, 123, 479, 152, 0);
    Show_mouse();
}

void steinbilder_minus(void)
{
    No_Show_mouse();
    bilder_minus();
    gxVirtualDisplay(&stein[1], 0, 0, 440, 59, 479, 88, 0);
    gxVirtualDisplay(&stein[0], 0, 0, 440, 91, 479, 120, 0);
    gxVirtualDisplay(&stein_back_and[zeiger_back], 0, 0, 440, 123, 479, 152, 0);
    Show_mouse();
}

void bild_minus(void)
{
    gxVirtualDisplay(&SV, 0, Player_Setup.HELP_Y, 0, Player_Setup.HELP_Y, 640, Player_Setup.HELP_Y+30, 0);
    No_Show_mouse();
    zeiger_back--;
    if(zeiger_back == -1)
	{
        Zeiger_info = 3;
	    gxVirtualDisplay(&hinter_pic, 0, 0, 440, 123, 479, 152, 0);
    }
    else
    {
        if(zeiger_back < -1)
            zeiger_back = STONE_TOOL_MAX-1;
        gxVirtualDisplay(&stein_back_and[zeiger_back], 0, 0, 440, 123, 479, 152, 0);
	}
    zeiger_3();
    Show_mouse();
}

void bild_plus(void)
{
    gxVirtualDisplay(&SV, 0, Player_Setup.HELP_Y, 0, Player_Setup.HELP_Y, 640, Player_Setup.HELP_Y+30, 0);
    No_Show_mouse();
    zeiger_back++;
    if(zeiger_back > STONE_TOOL_MAX-1)
	{
        Zeiger_info = 3;
    	zeiger_back = -1;
	    gxVirtualDisplay(&hinter_pic, 0, 0, 440, 123, 479, 152, 0);
    }
    else
    	gxVirtualDisplay(&stein_back_and[zeiger_back], 0, 0, 440, 123, 479, 152, 0);
	zeiger_3();
    Show_mouse();
}


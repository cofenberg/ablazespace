void Zeige_SpielModus_E(void)
{
    GXHEADER pic;

    pcxFileImage(gxEMM,"pic/e_menu.pcx",&pic, gxDETECT);
    gxVirtualDisplay(&pic, 438, 4, 438, 34, 562, 58, 0); // Spiel Modus �bermalen
    gxDestroyVirtual(&pic);
    SetFont(0, grWHITE, grBLACK, txNORMAL);
    if(Brett_struct.Spielart == MODERN)
       txPutString("MODERN", 500, 51);
    else
       txPutString("CLASSIC", 500, 51);
}

void SpielModus_E(void)
{
    GXHEADER pic;

    No_Show_mouse();
    pcxFileImage(gxEMM,"pic/e_menu.pcx",&pic, gxDETECT);
    gxVirtualDisplay(&pic, 438, 4, 438, 34, 562, 58, 0); // Spiel Modus �bermalen
    gxDestroyVirtual(&pic);
    SetFont(0, grWHITE, grBLACK, txNORMAL);
    if(Brett_struct.Spielart == MODERN)
    {
       Brett_struct.Spielart = CLASSIC;
       txPutString("CLASSIC", 500, 51);
    }
    else
    {
       Brett_struct.Spielart = MODERN;
       txPutString("MODERN", 500, 51);
    }
    Zeige_Brett(1);
    Show_mouse();
}

void Test(void)
{
    int Kachel_info_save2[KARTE_X * KARTE_Y][3];
    int i;

    gxDestroyVirtual(&hinter_pic);
    for(i = 0; i < KARTE_X*KARTE_Y; i++)
    {
    	Kachel_info_save2[i][0] = Kachel_info[i][0];
    	Kachel_info_save2[i][1] = Kachel_info[i][1];
    	Kachel_info_save2[i][2] = Kachel_info[i][8];
    }
    Game_Info.Test = YES;
 	Spiel();
	Player_Setup.HELP_Y = 0;
    co_Mouse.mx = bit_but_editor_menu[4].x+110;
    co_Mouse.my = bit_but_editor_menu[4].y+10;
    grSetMousePos(co_Mouse.mx, co_Mouse.my);
    Game_Info.Test = NO;
    No_Show_mouse();
    SetMouseBounds(0, 30, 640, 480);
    co_Mouse.Set_Mouse_style = NORMAL;
	check3 = 1;
    end = 0;
    for(i = 0; i < KARTE_X*KARTE_Y; i++)
    {
        Kachel_info[i][0] = Kachel_info_save2[i][0];
        Kachel_info[i][1] = Kachel_info_save2[i][1];
        Kachel_info[i][8] = Kachel_info_save2[i][2];
    }
	pcxFileDisplay("pic/e_liste.pcx", 0, 0, 0);
    SetFont(0, grWHITE, grBLUE, txTRANS);
    txPutString(Brett_file.ff_name, 540, 17);
    grSetColor(BLACK);
    for(i = 0; i < 29; i += 2)
 	   grDrawLine(0, i, 640, i);
    for(i = 0; i < 640; i += 2)
 	   grDrawLine(i, 0, i, 29);
}

void Fest_an_aus(void)
{
    GXHEADER pic;

    No_Show_mouse();
    pcxFileImage(gxEMM,"pic/e_menu.pcx",&pic, gxDETECT);
    gxVirtualDisplay(&pic, 196, 403, 196, 433, 238, 455, 0); // Fest �bermalen
    gxDestroyVirtual(&pic);
    SetFont(0, grWHITE, grBLACK, txNORMAL);
    if(Brett_struct.schreibschutz == 1)
    {
       Brett_struct.schreibschutz = 0;
       txPutString("Aus", 215, 448);
    }
    else
    {
       Brett_struct.schreibschutz = 1;
       txPutString("An", 215, 448);
    }
    Show_mouse();
}

void Laden_OK(void)
{
	check2 = 2;
}

void menu_zuruck(void)
{
	check2 = 1;
}

void zuruck(void)
{
 	check2 = 1;
}

void Zeige_menu(void)
{
    GXHEADER pic;
    int y1, y2;

    check3 = 0;
 	pcxFileImage(gxEMM,"pic/e_menu.pcx",&pic, gxDETECT);
    for(y1 = 30, y2 = 481;;)
    {
        y1 += 2;
        y2 -= 2;
        gxVirtualDisplay(&pic, 0, y1-30, 0, y1, 640, y1, 0);
        if(y2 > 29)
           gxVirtualDisplay(&pic, 0, y2-30, 0, y2, 640, y2, 0);
        if(y1 > 480 && y2 < 29)
           break;
        gxDelay(1);
    }
    gxVirtualDisplay(&pic, 0, 0, 0, 30, 640, 30, 0);
    gxDestroyVirtual(&pic);
    pcxFileImage(gxEMM,"pic/e_menu.pcx",&pic, gxDETECT);
    gxVirtualDisplay(&pic, 196, 403, 196, 433, 238, 455, 0); // Fest �bermalen
    gxDestroyVirtual(&pic);
    SetFont(0, grWHITE, grBLUE, txTRANS);
    txPutString(Brett_file.ff_name, 300, 75);
    SetFont(0, grWHITE, grBLACK, txNORMAL);
    txPutString(Brett_struct.von_name, 210, 421);
    SetFont(0, grWHITE, grBLACK, txNORMAL);
    if(Brett_struct.Spielart == MODERN)
       txPutString("MODERN", 500, 51);
    else
       txPutString("CLASSIC", 500, 51);
    Zeige_schreibschutz();
	Zeige_SpielModus_E();
    Zeige_Brett(1);
    gxDisplayVirtual(0, Player_Setup.HELP_Y, 640, Player_Setup.HELP_Y+30, 0, &SV, 0, Player_Setup.HELP_Y);
}

void menu(void)
{
    int y1, y2, key;
    int save_mx, save_my, i;

    No_Show_mouse();
    gxDestroyVirtual(&hinter_pic);
    if(co_Mouse.Mouse_on == 1)
	    grGetMousePos(&co_Mouse.mx, &co_Mouse.my);
	save_mx = co_Mouse.mx;
	save_my = co_Mouse.my;
    grSetColor(BLACK);
    for(i = 0; i < 29; i += 2)
 	   grDrawLine(0, i, 640, i);
    for(i = 0; i < 640; i += 2)
 	   grDrawLine(i, 0, i, 29);
    Zeige_menu();
    check2 = 0;
	Player_Setup.HELP_Y = 0;
	bit_but_editor_menu[4].an = 0;
    SetMouseBounds(0, 30, 640, 480);
    co_Mouse.mx = bit_but_editor_menu[4].x+110;
    co_Mouse.my = bit_but_editor_menu[4].y+10;
    grSetMousePos(co_Mouse.mx, co_Mouse.my);
    Show_mouse();
    if(check3 == 1)
       Brett_Laden();
    for(;;)
    {
		 Move_Mouse(NO);
 	     CheckSetupOptions();
         CheckBitMouse(&bit_but_editor_menu[0]);
         if(check3 == 1)
         {
             Zeige_menu();
             Show_mouse();
		 }
         if(bioskey(1) != 0)
         {
             key = bioskey(0);
             Check_Key(key, &bit_but_editor_menu[0]);
             switch(key)
             {
                case ESC_KEY:
                    end = 3;
                    break;
             }
         }
         if(end != 0 || check2 != 0)
          break;
    }
    No_Show_mouse();
    if(end == 3)
       end = 0;
    check2 = 0;
    Lade_hintergrund(WAHL_SET);
    menu_back_aktuel();
    y1 = 30;
    y2 = 481;
    for(;;)
    {
         y1 += 2;
         y2 -= 2;
         gxVirtualDisplay(&SV, 0, y1, 0, y1, 640, y1, 0);
         if(y2 > 29)
             gxVirtualDisplay(&SV, 0, y2, 0, y2, 640, y2, 0);
         if(y1 > 480 && y2 < 29)
             break;
    }
	pcxFileDisplay("pic/e_liste.pcx", 0, 0, 0);
	ZeigeSteinWahl();
	co_Mouse.mx = save_mx;
	co_Mouse.my = save_my;
    grSetMousePos(co_Mouse.mx, co_Mouse.my);
    SetMouseBounds(0, 0, 640, 480);
    SetFont(0, grWHITE, grBLUE, txTRANS);
    txPutString(Brett_file.ff_name, 540, 18);
    gxDisplayVirtual(0, Player_Setup.HELP_Y, 640, Player_Setup.HELP_Y+30, 0, &SV, 0, Player_Setup.HELP_Y);
	Player_Setup.HELP_Y = 450;
    Show_mouse();
}

void Lade_Editor_Karte(void)
{
   GXHEADER pic;

   No_Show_mouse();
   Lade_Karte();
   pcxFileImage(gxEMM,"pic/e_menu.pcx",&pic, gxDETECT);
   gxVirtualDisplay(&pic, 244, 33, 244, 63, 359, 79, 0); // Brett Name �bermalen
   gxVirtualDisplay(&pic, 109, 376, 109, 406, 316, 428, 0); // von Name �bermalen
   gxVirtualDisplay(&pic, 196, 403, 196, 433, 238, 455, 0); // Fest �bermalen
   gxDestroyVirtual(&pic);
   SetFont(0, grWHITE, grBLUE, txTRANS);
   txPutString(Brett_file.ff_name, 300, 75);
   SetFont(0, grWHITE, grBLACK, txTRANS);
   txPutString(Brett_struct.von_name, 210, 421);
   Zeige_schreibschutz();
   Zeige_SpielModus_E();
   Zeige_Brett(1);
   Show_mouse();
}

void Brett_neu(void)
{
    if(Yes_No_Check("Das vorhandene Brett loeschen?", 0) == 0)
    	return;
    No_Show_mouse();
    Zeiger_info = 0;
    stpcpy(Brett_file.ff_name, "No_Name");
    stpcpy(Brett_struct.von_name, "No_Name");
	Kacheln_init();
    Zeige_menu();
    Zeige_Brett(1);
    Show_mouse();
}

void Speichere_Karte(void)
{
    GXHEADER pic;
    char error[50];
	char text[30];
    int datei, i, vorhanden = 0, done;
    char name[10], von_name[30];

    Meldung("Bitte den Brettnamen eingeben.");
    No_Show_mouse();
    for(i = 0; i < 9; i++)
    	name[i] = 0;
    i = 0;
// Der Brett Name wird abgefragt:
    gxCreateVirtual(gxEMM, &Ein_pic, Setup.gxtype, 250, 40);
    gxDisplayVirtual(180, 220, 430, 260, 0, &Ein_pic, 0, 0);
    for(;;)
    {
      	strcpy(text, Eingabe(8, 310, 240, 180, 220, 430, 260, &i));
    	if(i != 0 || end != 0)
    		break;
    }
    gxDestroyVirtual(&Ein_pic);
    strncpy(name, text, strlen(text)); // Eingabe beendet.
    Meldung_weg();
    if(end != 0)
	{
        Show_mouse();
        end = 0;
    	return;
    }
   // Pr�ft, ob ein Brett mit diesem Namen schon vorhanden ist:
	done = findfirst("Bretter/*.log", &Brett_file, 0);
	vorhanden = 0;
  	i = memicmp(name, Brett_file.ff_name, strlen(name));
    if(i != 0)
    {
        for(;;)
        {
            done = findnext(&Brett_file);
            if(done != 0)
                break;
            i = memicmp(name, Brett_file.ff_name, strlen(name));
            if(i == 0)
            {
				vorhanden = 1;
            	break;
            }
        }
    }
    else
		vorhanden = 1;
    Show_mouse();
    if(vorhanden == 1)
        if(Yes_No_Check("Brett ueberschreiben?", 0) == 0)
            return;
    Meldung("Geben sie ihren Namen ein.");
    No_Show_mouse();
// Der Name des Spielers wird abgefragt:
    gxCreateVirtual(gxEMM, &Ein_pic, Setup.gxtype, 250, 40);
    gxDisplayVirtual(180, 220, 430, 260, 0, &Ein_pic, 0, 0);
    for(;;)
    {
      	strcpy(text, Eingabe(25, 310, 240, 180, 220, 430, 260, &i));
    	if(i != 0 || end != 0)
    		break;
    }
    gxDestroyVirtual(&Ein_pic);
    Meldung_weg();
    if(end != 0)
	{
        Show_mouse();
        end = 0;
    	return;
    }
    strncpy(von_name, text, 30);  // Eingabe beendet.
	sprintf(temp, "Bretter/%s.log", name);
    unlink(temp);
    if(Setup.DiskInfo == WRITE)
    {
        datei = open(temp, O_WRONLY | O_BINARY | O_CREAT);
        chmod(temp, S_IREAD|S_IWRITE);
        for(i = 0; i < KARTE_X*KARTE_Y; i++)
        {
            if(Kachel_info[i][0] == 0)
                Brett_struct.Brett_info[i] = 0;
            if(Kachel_info[i][0] == 1 && Kachel_info[i][1] == 0)
                Brett_struct.Brett_info[i] = 1;
            if(Kachel_info[i][0] == 1 && Kachel_info[i][1] == 1)
                Brett_struct.Brett_info[i] = 2;
            Brett_struct.bild[i] = Kachel_info[i][8];
        }
        strncpy(Brett_struct.von_name, von_name, 20);
        strncpy(Brett_struct.best_1, "Nobody", 20);
        strncpy(Brett_struct.best_2, "Nobody", 20);
        strncpy(Brett_struct.best_3, "Nobody", 20);
        strncpy(Brett_struct.best_4, "Nobody", 20);
        strncpy(Brett_struct.best_5, "Nobody", 20);
        for(i = 0; i < 5; i++)
        {
           Brett_struct.zeit[i] = 999;
           Brett_struct.steine[i] = 999;
        }
	    sprintf(Brett_struct.Backpic, "%s", Brett_hintergrund.ff_name);
	    sprintf(Brett_struct.Stylepic, "%s", BrettStyle.ff_name);
        write(datei, &Brett_struct, sizeof(Brett_struct));
        close(datei);
        done = findfirst(temp, &Brett_file, 0);
        pcxFileImage(gxEMM,"pic/e_menu.pcx",&pic, gxDETECT);
        gxVirtualDisplay(&pic, 244, 33, 244, 63, 359, 79, 0); // Brett Name �bermalen
        gxVirtualDisplay(&pic, 109, 376, 109, 406, 316, 428, 0); // von Name �bermalen
        gxDestroyVirtual(&pic);
        SetFont(0, grWHITE, grBLUE, txTRANS);
        txPutString(Brett_file.ff_name, 300, 75);
        SetFont(0, grWHITE, grBLACK, txNORMAL);
        txPutString(Brett_struct.von_name, 210, 421);
        gxDisplayVirtual(244, 63, 359, 79, 0, &SV, 244, 63);
        gxDisplayVirtual(109, 406, 316, 428, 0, &SV, 109, 406);
    }
    else
    {
        sprintf(error, "%s schreibschutz fehler!", temp);
        ProError(error);
    }
    Show_mouse();
}

void editor_links_Laden(void)
{
	Game_Info.Spielbrett--;
	Lade_Editor_Karte();
}

void editor_rechts_Laden(void)
{
	Game_Info.Spielbrett++;
	Lade_Editor_Karte();
}

void Zeige_schreibschutz(void)
{
    GXHEADER pic;

    pcxFileImage(gxEMM,"pic/e_menu.pcx",&pic, gxDETECT);
    gxVirtualDisplay(&pic, 196, 403, 196, 433, 238, 455, 0); // Fest �bermalen
    gxDestroyVirtual(&pic);
    SetFont(0, grWHITE, grBLACK, txNORMAL);
    if(Brett_struct.schreibschutz == 0)
       txPutString("Aus", 215, 448);
    if(Brett_struct.schreibschutz == 1)
       txPutString("An", 215, 448);
}

void Save_Brett_vor(void)
{
    int i;

    for(i = 0; i < KARTE_X*KARTE_Y; i++)
    {
    	Kachel_info_save[i][0] = Kachel_info[i][0];
    	Kachel_info_save[i][1] = Kachel_info[i][1];
    	Kachel_info_save[i][2] = Kachel_info[i][8];
    }
    Brett_struct_save = Brett_struct;
	Brett_file_save = Brett_file;
    spielbrett_save = Game_Info.Spielbrett;
}

void Brett_Laden(void)
{
    int key, done, save_mx, save_my;

    No_Show_mouse();
	Save_Brett_vor();
    Game_Info.Spielbrett = 0;
    done = Lade_Karte();
    if(done == -1)
    {
        Show_mouse();
    	Yes_No_Check("Kein Brett gefunden", 1);
        Laden_weg();
        return;
    }
    Lade_menu();
    No_Show_mouse();
    SetFont(0, grWHITE, grBLACK, txNORMAL);
    txPutString(Brett_struct.von_name, 210, 421);
    Zeige_schreibschutz();
	Zeige_SpielModus_E();
    check2 = 0;
	save_mx = co_Mouse.mx;
	save_my = co_Mouse.my;
    co_Mouse.mx = bit_but_editor_menu_laden[3].x+100;
    co_Mouse.my = bit_but_editor_menu_laden[3].y+10;
    grSetMousePos(co_Mouse.mx, co_Mouse.my);
    Show_mouse();
    for(;;)
    {
        for(;;)
        {
	        Move_Mouse(NO);
	 	    CheckSetupOptions();
		    CheckBitMouse(&bit_but_editor_menu_laden[0]);
            if(check3 == 1)
            	Lade_menu();
            if(bioskey(1) != 0)
            {
                key = bioskey(0);
                Check_Key(key, &bit_but_editor_menu_laden[0]);
                switch(key)
		        {
        	        case ESC_KEY:
                        end = 3;
                        break;
                }
            }
            if(end != 0 || check2 != 0)
        	    break;
	    }
        if(end != 0)
        	break;
    	if(check2 == 1)
        	break;
       if(check2 == 2)
       {
            if(Brett_struct.schreibschutz == 0)
            {
               if(Yes_No_Check("Brett geht verloren", 0) != 0)
                 break;
            }
            else
               Yes_No_Check("Das Brett ist geschuetzt", 1);
            check2 = 0;
        }
        else
           check2 = 0;
    }
 	No_Show_mouse();
	co_Mouse.mx = save_mx;
	co_Mouse.my = save_my;
    grSetMousePos(co_Mouse.mx, co_Mouse.my);
    Laden_weg();
    if(end == 3)
    	end = 0;
    check2 = 0;
	Show_mouse();
}

void Laden_weg(void)
{
    int i;

 	No_Show_mouse();
    if(check2 == 2)
    {
        Zeige_menu();
        Show_mouse();
    	return;
    }
    Brett_struct = Brett_struct_save;
    Lade_style(WAHL_SET);
	Brett_file = Brett_file_save;
    SetFont(0, grWHITE, grBLUE, txTRANS);
    txPutString(Brett_file.ff_name, 300, 75);
    SetFont(0, grWHITE, grBLACK, txNORMAL);
    txPutString(Brett_struct.von_name, 210, 421);
    for(i = 0; i < KARTE_X*KARTE_Y; i++)
    {
        Kachel_info[i][0] = Kachel_info_save[i][0];
        Kachel_info[i][1] = Kachel_info_save[i][1];
        Kachel_info[i][8] = Kachel_info_save[i][2];
    }
    Zeige_schreibschutz();
	Zeige_SpielModus_E();
    Zeige_menu();
	Show_mouse();
}

void Lade_menu(void)
{
    GXHEADER pic;
    int i;

    No_Show_mouse();
    Zeige_menu();
    grSetColor(BLACK);
    for(i = 146; i < 196; i += 2)
 	   grDrawLine(429, i, 558, i);
    for(i = 429; i < 558; i += 2)
 	   grDrawLine(i, 146, i, 196);
    for(i = 226; i < 304; i += 2)
 	   grDrawLine(429, i, 558, i);
    for(i = 429; i < 558; i += 2)
 	   grDrawLine(i, 226, i, 304);
    for(i = 432; i < 456; i += 2)
 	   grDrawLine(250, i, 313, i);
    for(i = 250; i < 313; i += 2)
 	   grDrawLine(i, 432, i, 456);
    for(i = 34; i < 58; i += 2)
 	   grDrawLine(568, i, 631, i);
    for(i = 568; i < 631; i += 2)
 	   grDrawLine(i, 34, i, 58);
    pcxFileImage(gxEMM,"pic/laden.pcx",&pic, gxDETECT);
    gxVirtualDisplay(&pic, 0, 0, 386, 59, 472, 83, 0);
    gxDestroyVirtual(&pic);
    pcxFileImage(gxEMM,"pic/laden_m.pcx",&pic, gxDETECT);
    gxVirtualDisplay(&pic, 0, 0, 407, 85, 536, 133, 0);
    gxDestroyVirtual(&pic);
    gxDisplayVirtual(0, Player_Setup.HELP_Y, 640, Player_Setup.HELP_Y+30, 0, &SV, 0, Player_Setup.HELP_Y);
    Show_mouse();
}

void Datei_loschen(void)
{
    int done, i;
    char error[50];

    sprintf(temp, "Datei %s loeschen?", Brett_file.ff_name);
    if(Yes_No_Check(temp, 0) == 0)
        return;
    sprintf(temp, "Bretter/%s", Brett_file.ff_name);
    if (chmod(temp, S_IREAD|S_IWRITE) != 0)
    {
        sprintf(error, "%s schreibschutz fehler!", temp);
    	ProError(error);
    }
    i = unlink(temp);
    if(i != 0)
	{
        sprintf(error, "%s konnte nicht geloescht werden!", temp);
    	ProError(error);
    }
    Game_Info.Spielbrett = 0;
    done = Lade_Karte();
    if(done == -1)
    	check =  1;
    Lade_menu();
}

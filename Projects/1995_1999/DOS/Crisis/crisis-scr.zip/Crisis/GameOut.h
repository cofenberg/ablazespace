void Spiel_aus(void)
{
    time_t timer;
    char text[30];
    int i, z, Vertig;
    int platz, datei;
    char best_name[30], error[50];
    long save_time;

	if(Game_Info.DemoOn == YES)
    	return;
    No_Show_mouse();
    for(i = 30; i > -1; i--)
    	gxVirtualDisplay(&liste, 0, i, 0, 0, 640, 29, 0);
	Liste_farbe();
    gxDelay(1000);
	SetFont(1, BLACK, grBLACK, txTRANS);
    txPutString("Das Spiel ist beendet!", 325, 265);
	SetFont(1, WHITE, grBLACK, txTRANS);
    txPutString("Das Spiel ist beendet!", 320, 260);
    gxDelay(1000);
	Warte_auf_Taste(YES);
    Draw_Back(0);
	SetFont(1, 254, grBLACK, txTRANS);
    txPutString("Es sind keine Spruenge mehr moeglich,", 320, 90);
    txPutString("damit ist das Spiel beendet.", 320, 110);
    txPutString("Ergebniss:", 320, 140);
    sprintf(temp, "Sie haben in %ld Sekunden %d von %d", Game_Info.zeit[0], Game_Info.spiel_steine-Game_Info.steine, Game_Info.spiel_steine);
    txPutString(temp, 320, 160);
    txPutString("Steinen entfernt.", 320, 180);
    end = 0;
    if(Game_Info.Test == YES)
    {
        for(i = 0; i < 60; i += 1)
        {
            gxSetPaletteRGB(254, i, i, i);
            gxDelay(10);
        }
        gxDelay(1000);
		Warte_auf_Taste(YES);
        end = 1;
        for(i = 60; i > 0; i -= 1)
        {
            gxSetPaletteRGB(254, i, i, i);
            gxDelay(30);
        }
	    Show_mouse();
        return;
    }
    for(i = 0, platz = 0; i < 6; i++)    // Ist der Spieler besser als die anderen?
    {
        if(Game_Info.steine <= Brett_struct.steine[i])
        {
            if(Game_Info.steine == Brett_struct.steine[i])
            {
                if(Game_Info.zeit[0] <= Brett_struct.zeit[i])
                {
                    platz = i;
                    i = 6;
                }
			}
            else
            {
                platz = i;
                i = 6;
            }
        }
    }
	if(platz == -1)
    {
        txPutString("Strengen Sie sich naechstes mal mehr an, damit Sie", 320, 230);
        sprintf(temp, "wenigstens '%s' der in %ld Sekunden %d von %d Steinen", Brett_struct.best_5, Brett_struct.zeit[4], Game_Info.spiel_steine-Brett_struct.steine[4], Game_Info.spiel_steine);
        txPutString(temp, 320, 250);
        txPutString("entfernte schlagen und dann auf Platz 5 kommen!", 320, 270);
        for(i = 0; i < 60; i += 1)
        {
            gxSetPaletteRGB(254, i, i, i);
            gxDelay(10);
        }
        gxDelay(1000);
		Warte_auf_Taste(YES);
        end = 1;
        for(i = 60; i > 0; i -= 1)
        {
            gxSetPaletteRGB(254, i, i, i);
            gxDelay(20);
        }
        return;
    }
    else
    {
        switch(platz)
        {
        	case 0:
	       		sprintf(temp, "Damit haben Sie '%s' der in %ld Sekunden", Brett_struct.best_1, Brett_struct.zeit[0]);
            	break;

        	case 1:
        		sprintf(temp, "Damit haben Sie '%s' der in %ld Sekunden", Brett_struct.best_2, Brett_struct.zeit[1]);
            	break;

        	case 2:
        		sprintf(temp, "Damit haben Sie '%s' der in %ld Sekunden", Brett_struct.best_3, Brett_struct.zeit[2]);
            	break;

        	case 3:
        		sprintf(temp, "Damit haben Sie '%s' der in %ld Sekunden", Brett_struct.best_4, Brett_struct.zeit[3]);
            	break;

        	case 4:
        		sprintf(temp, "Damit haben Sie '%s' der in %ld Sekunden", Brett_struct.best_5, Brett_struct.zeit[4]);
            	break;
        }
        txPutString(temp, 320, 210);
        switch(platz)
        {
        	case 0:
        		sprintf(temp, "%d von %d Steinen entfernte von", Game_Info.spiel_steine-Brett_struct.steine[0], Game_Info.spiel_steine);
            	break;

        	case 1:
        		sprintf(temp, "%d von %d Steinen entfernte von", Game_Info.spiel_steine-Brett_struct.steine[1], Game_Info.spiel_steine);
            	break;

        	case 2:
        		sprintf(temp, "%d von %d Steinen entfernte von", Game_Info.spiel_steine-Brett_struct.steine[2], Game_Info.spiel_steine);
            	break;

        	case 3:
        		sprintf(temp, "%d von %d Steinen entfernte von", Game_Info.spiel_steine-Brett_struct.steine[3], Game_Info.spiel_steine);
            	break;

        	case 4:
        		sprintf(temp, "%d von %d Steinen entfernte von", Game_Info.spiel_steine-Brett_struct.steine[4], Game_Info.spiel_steine);
            	break;
        }
        txPutString(temp, 320, 230);
        txPutString("seinem Platz verdraengt und sind nun", 320, 250);
        sprintf(temp ,"auf Position %d", platz+1);
        txPutString(temp, 320, 270);
        txPutString("Herzlichen Glueckwunsch!!", 320, 310);
        for(i = 0; i < 60; i += 1)
        {
            gxSetPaletteRGB(254, i, i, i);
            gxDelay(20);
        }
        gxDelay(1000);
        txPutString("Geben Sie bitte ihren Namen ein:", 320, 370);
    }
// Der Name des Spielers wird abgefragt:
    gxCreateVirtual(gxEMM, &Ein_pic, Setup.gxtype, 250, 40);
    gxDisplayVirtual(180, 380, 430, 430, 0, &Ein_pic, 0, 0);
    timer = time(NULL);
    save_time = timer;
    for(i = 0;;)
    {
        timer = time(NULL);
        if(save_time != timer)
        {
			save_time = timer;
            if(i == 0)
            {
				SetFont(1, grWHITE, grBLACK, txTRANS);
            	i = 1;
	        }
            else
            {
				SetFont(1, grDARKGRAY, grBLACK, txTRANS);
            	i = 0;
	        }
            txPutString("Geben Sie bitte ihren Namen ein:", 320, 370);
        }
      	strcpy(text, Eingabe(25, 310, 400, 180, 380, 430, 420, &Vertig));
    	if(end != 0 || Vertig == 1)
    		break;
    }
    gxDestroyVirtual(&Ein_pic);
	SetFont(1, 254, grBLACK, txTRANS);
    txPutString("Geben Sie bitte ihren Namen ein:", 320, 370);
	if(end == 0)
    {
        if(strlen(text) == 0)
        {
            z = rand() % 9;
            switch(z)
            {
                case 0:
                    strncpy(text, "Faulpelz", 20);
                    break;

                case 1:
                    strncpy(text, "Einfallsloss", 20);
                    break;

                case 2:
                    strncpy(text, "Speedy", 20);
                    break;

                case 3:
                    strncpy(text, "Big Key", 20);
                    break;

                case 4:
                    strncpy(text, "Anonym", 20);
                    break;

                case 5:
                    strncpy(text, "Big Flop", 20);
                    break;

                case 6:
                    strncpy(text, "Chippy", 20);
                    break;

                case 7:
                    strncpy(text, "Super Dau", 20);
                    break;

                case 9:
                    strncpy(text, "Multi Dump", 20);
                    break;

                case 10:
                    strncpy(text, "Monkey earth", 20);
                    break;
            }
            SetFont(1, grWHITE, grBLACK, txTRANS);
            txPutString(text, 310, 395);
        }
       	strncpy(best_name, text, 25); // Eingabe beendet.
        switch(platz)
        {
            case 0:
                strncpy(Brett_struct.best_5, Brett_struct.best_4, 25);
                Brett_struct.zeit[4] = Brett_struct.zeit[3];
                Brett_struct.steine[4] = Brett_struct.steine[3];
                strncpy(Brett_struct.best_4, Brett_struct.best_3, 25);
                Brett_struct.zeit[3] = Brett_struct.zeit[2];
                Brett_struct.steine[3] = Brett_struct.steine[2];
                strncpy(Brett_struct.best_3, Brett_struct.best_2, 25);
                Brett_struct.zeit[2] = Brett_struct.zeit[1];
                Brett_struct.steine[2] = Brett_struct.steine[1];
                strncpy(Brett_struct.best_2, Brett_struct.best_1, 25);  // Spieler wurden nach unten geschoben
                Brett_struct.zeit[1] = Brett_struct.zeit[0];
                Brett_struct.steine[1] = Brett_struct.steine[0];
                strncpy(Brett_struct.best_1, best_name, 25);
                Brett_struct.zeit[0] = Game_Info.zeit[0];
                Brett_struct.steine[0] = Game_Info.steine;
                break;

            case 1:
                strncpy(Brett_struct.best_5, Brett_struct.best_4, 25);
                Brett_struct.zeit[4] = Brett_struct.zeit[3];
                Brett_struct.steine[4] = Brett_struct.steine[3];
                strncpy(Brett_struct.best_4, Brett_struct.best_3, 25);
                Brett_struct.zeit[3] = Brett_struct.zeit[2];
                Brett_struct.steine[3] = Brett_struct.steine[2];
                strncpy(Brett_struct.best_3, Brett_struct.best_2, 25);
                Brett_struct.zeit[2] = Brett_struct.zeit[1];
                Brett_struct.steine[2] = Brett_struct.steine[1];
                strncpy(Brett_struct.best_2, best_name, 25);
                Brett_struct.zeit[1] = Game_Info.zeit[0];
                Brett_struct.steine[1] = Game_Info.steine;
                break;

            case 2:
                strncpy(Brett_struct.best_5, Brett_struct.best_4, 25);
                Brett_struct.zeit[4] = Brett_struct.zeit[3];
                Brett_struct.steine[4] = Brett_struct.steine[3];
                strncpy(Brett_struct.best_4, Brett_struct.best_3, 25);
                Brett_struct.zeit[3] = Brett_struct.zeit[2];
                Brett_struct.steine[3] = Brett_struct.steine[2];
                strncpy(Brett_struct.best_3, best_name, 25);
                Brett_struct.zeit[2] = Game_Info.zeit[0];
                Brett_struct.steine[2] = Game_Info.steine;
                break;

            case 3:
                strncpy(Brett_struct.best_5, Brett_struct.best_4, 25);
                Brett_struct.zeit[4] = Brett_struct.zeit[3];
                Brett_struct.steine[4] = Brett_struct.steine[3];
                strncpy(Brett_struct.best_4, best_name, 25);
                Brett_struct.zeit[3] = Game_Info.zeit[0];
                Brett_struct.steine[3] = Game_Info.steine;
                break;

            case 4:
                strncpy(Brett_struct.best_5, best_name, 25);
                Brett_struct.zeit[4] = Game_Info.zeit[0];
                Brett_struct.steine[4] = Game_Info.steine;
                break;
        }
        if(Setup.DiskInfo == WRITE)
        {
	        sprintf(temp, "Bretter/%s", Brett_file.ff_name);
            chmod(temp, S_IREAD|S_IWRITE);
            datei = open(temp, O_WRONLY | O_BINARY);
            write(datei, &Brett_struct, sizeof(Brett_struct));
            close(datei);
        }
        else
        {
            sprintf(error, "%s schreibschutz fehler!", temp);
            ProError(error);
        }
        for(i = 60; i > 0; i -= 1)
        {
            gxSetPaletteRGB(254, i, i, i);
            gxDelay(30);
        }
    }
    end = 0;
    Show_mouse();
    Die_Besten_Spieler(1); // Nur die Geschaffte liste anzeigen
}

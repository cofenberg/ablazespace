#include <sys\stat.h>

#include "Co_Tools/struct.h"

extern void Draw_Back(int);
extern void Lade_style(int);
extern void menu_back_aktuel(void);
extern void Kacheln_init(void);
extern Lade_Karte(void);
extern void feldmalen(int);
extern void Lade_hintergrund(int);
extern void Titel_bild(void);
void Die_Besten_Spieler(int);
void Best_OK(void);
void Del_Best(void);
void Best_links(void);
void Best_rechts(void);
void Zeige_Die_Besten(int);

extern struct ffblk Brett_file;
extern GXHEADER hinter_pic;
extern struct BRETT_STRUCT Brett_struct;
int modu;

struct BIT_BUTTON bit_but_best_1[] =
{
	{399, 55, 44, 25, 0, 0, Best_links, 1, "Ein Brett zurueck", 0, PLEFT_ANI, -1, 1},  //  Brett nach links
	{443, 55, 44, 25, 0, 1, Best_rechts, 1, "Ein Brett nach vorne", 0, PRIGHT_ANI, -1, 1},  //  Brett nach rechts
	{400, 365, 130, 25, 0, 1, Best_OK, 1, "Die Highscore verlassen", 0, OK_ANI, ALT_O_KEY, 0},  //  OK
	{400, 390, 130, 25, 0, 1, Del_Best, 1, "Alle Eintraege loeschen", 0, EIMER_ANI, ALT_L_KEY, 0},  //  L�schen
	{999, 999, 999, 999, 999, 999, 0, 0, "", 0, 0, -1, 0},
};

struct BIT_BUTTON bit_but_best_2[] =
{
	{400, 365, 130, 25, 0, 1, Best_OK, 1, "Die Highscore verlassen", 0, OK_ANI, ALT_O_KEY, 0},  //  OK
	{999, 999, 999, 999, 999, 999, 0, 0, "", 0, 0, -1, 0},
};

void Best_links(void)
{
	Game_Info.Spielbrett--;
    Zeige_Die_Besten(0);
}

void Best_rechts(void)
{
	Game_Info.Spielbrett++;
    Zeige_Die_Besten(0);
}

void Del_Best(void)
{
    char error[50];
    int i, datei;

    if(Yes_No_Check("Alle eintraege loeschen?", 0) == 0)
      return;
    strncpy(Brett_struct.best_1, "Nobody", 20);
    strncpy(Brett_struct.best_2, "Nobody", 20);
    strncpy(Brett_struct.best_3, "Nobody", 20);
    strncpy(Brett_struct.best_4, "Nobody", 20);
    strncpy(Brett_struct.best_5, "Nobody", 20);
    for(i = 0; i < 5; i++)
    {
       Brett_struct.zeit[i] = 999;
       Brett_struct.steine[i] = 999;
    }
    sprintf(temp, "Bretter/%s", Brett_file.ff_name);
    if(Setup.DiskInfo == WRITE)
    {
        datei = open(temp, O_WRONLY | O_BINARY);
        chmod(temp, S_IREAD|S_IWRITE);
        write(datei, &Brett_struct, sizeof(Brett_struct));
        close(datei);
    }
    else
    {
        sprintf(error, "%s schreibschutz fehler!", temp);
        ProError(error);
    }
    co_Mouse.mx = bit_but_best_2[0].x+90;
    co_Mouse.my = bit_but_best_2[0].y+10;
    grSetMousePos(co_Mouse.mx, co_Mouse.my);
    Zeige_Die_Besten(modu);
}

void Best_OK(void)
{
	end = 1;
}

void Zeige_Die_Besten(int modus)
{
    GXHEADER pic;
    int i, spiel_steine = 0, leere_felder = 0;

    No_Show_mouse();
	bit_but_best_1[0].an = 0;
	bit_but_best_1[1].an = 0;
 	gxSetDisplayPalette(Setup.palSave);
    if(modus == 0)
    {
	    Lade_Karte();
    	Lade_hintergrund(NORMAL_SET);
    	Lade_style(NORMAL_SET);
	}
    menu_back_aktuel();
	gxDestroyVirtual(&hinter_pic);
    gxVirtualDisplay(&SV, 0, 30, 0, 15, 640, 465, 0);
    Draw_Back(0);
    pcxFileImage(gxEMM,"pic/best_men.pcx",&pic, gxDETECT);
    gxVirtualDisplay(&pic, 0, 0, 400, 365, 528, 390, 0);
    if(modus == 0)
	{
        gxVirtualDisplay(&pic, 0, 25, 400, 390, 528, 415, 0);
	    gxVirtualDisplay(&pic, 0, 50, 400, 55, 486, 79, 0);
    }
    gxDestroyVirtual(&pic);
    pcxFileDisplay("pic/brett.pcx", 240, 55, 0);
    pcxFileDisplay("pic/info.pcx", 210, 365, 0);
    // Die liste ausgeben
    SetFont(2, grBLACK, grBLACK, txTRANS);
    txPutString("Brett:", 185, 80);
    SetFont(2, grWHITE, grBLACK, txTRANS);
    txPutString("Brett:", 180, 75);
    SetFont(3, grBLACK, grBLACK, txTRANS);
    txPutString("Spielsteine:", 125, 385);
    txPutString("Leere Felder:", 125, 410);
    SetFont(3, grWHITE, grBLACK, txTRANS);
    txPutString("Spielsteine:", 120, 380);
    txPutString("Leere Felder:", 120, 405);
	SetFont(0, grWHITE, grBLUE, txTRANS);
    txPutString(Brett_file.ff_name, 320, 71);
    for(i = 0; i < KARTE_X*KARTE_Y; i++)
        if(Kachel_info[i][1] == 1)
          spiel_steine++;
       else
          if(Kachel_info[i][0] == 1)
             leere_felder++;
	SetFont(0, grWHITE, grBLACK, txNORMAL);
    sprintf(temp, "%d", spiel_steine);
    txPutString(temp, 235, 380);
    sprintf(temp, "%d", leere_felder);
    txPutString(temp, 235, 405);
    SetFont(2, grBLACK, grBLACK, txTRANS);
    txPutString("Name:", 145, 140);
    txPutString("Steine:", 355, 140);
    txPutString("Zeit:", 515, 140);
    SetFont(2, grWHITE, grBLACK, txTRANS);
    txPutString("Name:", 140, 135);
    txPutString("Steine:", 350, 135);
    txPutString("Zeit:", 510, 135);
    SetFont(1, grWHITE, grBLACK, txTRANS);
    txPutString("1.", 20, 165);
    txPutString("2.", 20, 195);
    txPutString("3.", 20, 225);
    txPutString("4.", 20, 255);
    txPutString("5.", 20, 285);
    txPutString(Brett_struct.best_1, 160, 165);
    txPutString(Brett_struct.best_2, 160, 195);
    txPutString(Brett_struct.best_3, 160, 225);
    txPutString(Brett_struct.best_4, 160, 255);
    txPutString(Brett_struct.best_5, 160, 285);
    sprintf(temp, "%d", Brett_struct.steine[0]);
    txPutString(temp, 350, 165);
    sprintf(temp, "%d", Brett_struct.steine[1]);
    txPutString(temp, 350, 195);
    sprintf(temp, "%d", Brett_struct.steine[2]);
    txPutString(temp, 350, 225);
    sprintf(temp, "%d", Brett_struct.steine[3]);
    txPutString(temp, 350, 255);
    sprintf(temp, "%d", Brett_struct.steine[4]);
    txPutString(temp, 350, 285);
    sprintf(temp, "%d", Brett_struct.zeit[0]);
    txPutString(temp, 510, 165);
    sprintf(temp, "%d", Brett_struct.zeit[1]);
    txPutString(temp, 510, 195);
    sprintf(temp, "%d", Brett_struct.zeit[2]);
    txPutString(temp, 510, 225);
    sprintf(temp, "%d", Brett_struct.zeit[3]);
    txPutString(temp, 510, 255);
    sprintf(temp, "%d", Brett_struct.zeit[4]);
    txPutString(temp, 510, 285);
    Show_mouse();
}

void Die_Besten_Spieler(int modus)
{
   int key;

   No_Show_mouse();
   modu = modus;
   gxClearDisplay(0, 0);
   gxSetDisplayPalette(Setup.palSave);
   SetMouseBounds(0, 0, 640, 480);
   co_Mouse.Set_Mouse_style = NORMAL;
   co_Mouse.mx = bit_but_best_2[0].x+90;
   co_Mouse.my = bit_but_best_2[0].y+10;
   grSetMousePos(co_Mouse.mx, co_Mouse.my);
   Zeige_Die_Besten(modus);
   Show_mouse();
   end = 0;
   StarModule = NOSTARS;
   gxDisplayVirtual(0, Player_Setup.HELP_Y, 640, Player_Setup.HELP_Y+30, 0, &SV, 0, Player_Setup.HELP_Y);
   for(;;)
   {
   	  Move_Mouse(NO);
	  CheckSetupOptions();
      if(modus == 0)
	      CheckBitMouse(&bit_but_best_1[0]);  // Alle Listen aufrufbar
      if(modus == 1)
	      CheckBitMouse(&bit_but_best_2[0]);
      if(bioskey(1) != 0)
      {
         key = bioskey(0);
         if(modus == 0)
	         Check_Key(key, &bit_but_best_1[0]);
         if(modus == 1)
    	     Check_Key(key, &bit_but_best_2[0]);
         switch(key)
         {
         	case ESC_KEY:
                if(modus == 0)
                    Titel_bild();
                if(modus == 1)
                    end = 1;
                break;
         }
      }
	  if(end != 0)
      	break;
   }
   if(modus == 0 && end != 2)
       Titel_bild();
   if(modus == 1)
       end = 5;
}

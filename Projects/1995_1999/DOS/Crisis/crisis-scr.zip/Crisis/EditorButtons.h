struct BIT_BUTTON bit_but_editor[] =
{
	{112, 2, 130, 25, 0, 1, menu, 1, "Zum Editor Menu (Laden\Sichern usw.)", 0, NORMAL_ON, ALT_M_KEY, 0},
	{259, 2, 130, 25, 0, 1, auswahl, 1, "Das Brettstyle vestlegen", 0, NORMAL_ON, ALT_A_KEY, 0},
	{999, 999, 999, 999, 999, 999, 0, 0, "", 0, 0, -1, 0},
};

struct BIT_BUTTON bit_but_editor_auswahl[] =
{
	{260, 149, 130, 25, 0, 1, menu_zuruck, 1, "Zurueck zum Arbeitstisch (Key: ESC, SPACE)", 0, NORMAL_ON, ALT_Z_KEY, 0},
	{293, 74, 44, 25, 0, 0, steinbilder_minus, 1, "Ein Brettstyle zurueck", 0, PLEFT_ANI, -1, 1},  // bilder <
	{337, 74, 44, 25, 0, 1, steinbilder_plus, 1, "Ein Brettstyle nach vorne", 0, PRIGHT_ANI, -1, 1},  // bilder >
	{293, 116, 44, 25, 0, 0, hintergrund_minus, 1, "Einen Hintergrund zurueck", 0, PLEFT_ANI, -1, 1},  // hintergrund <
	{337, 116, 44, 25, 0, 1, hintergrund_plus, 1, "Einen Hintergrund nach vorne", 0, PRIGHT_ANI, -1, 1},  // hintergrund >
	{413, 156, 44, 25, 0, 0, bild_minus, 1, "Ein Hintergrundfeld zurueck  (Key: -, Ein Feld loeschen Key: 4)", 0, PLEFT_ANI, -1, 1},  // hintergrund Kachelbild <
	{457, 156, 44, 25, 0, 1, bild_plus, 1, "Ein Hintergrundfeld nach vorne (Key: +, Ein Feld loeschen Key: 4)", 0, PRIGHT_ANI, -1, 1},  // hintergrund Kachelbild >
	{439, 59, 65, KACHEL_H, 0, 1, zeiger_1, 2, "Einen Stein setzen (Key: 1, Ein Feld loeschen Key: 4)", 0, NORMAL_ON, -1, 0},
	{439, 91, 65, KACHEL_H, 0, 1, zeiger_2, 2, "Ein leeres Feld setzen (Key: 2, Ein Feld loeschen Key: 4)", 0, NORMAL_ON, -1, 0},
	{439, 123, 65, KACHEL_H, 0, 1, zeiger_3, 2, "Hintergrundfeld setzen (Key: 3, Ein Feld loeschen Key: 4)", 0, NORMAL_ON, -1, 0},
	{999, 999, 999, 999, 999, 999, 0, 0, "", 0, 0, -1, 0},
};

struct BIT_BUTTON bit_but_editor_menu[] =
{
	{428, 146, 130, 25, 0, 0, Speichere_Karte, 1, "Das Brett sichern", 0, NORMAL_ON, ALT_S_KEY, 0},
	{428, 171, 130, 25, 0, 0, Brett_Laden, 1, "Ein fertiges Brett laden", 0, NORMAL_ON, ALT_L_KEY, 0},
	{428, 196, 130, 25, 0, 0, Brett_neu, 1, "Das Brett loeschen", 0, EIMER_ANI, ALT_C_KEY, 0},
	{428, 225, 130, 25, 0, 0, Editor_Ende, 1, "Zurueck zum Hauptmenu", 0, EXIT_ANI, ALT_E_KEY, 0},
	{429, 280, 130, 25, 0, 0, menu_zuruck, 1, "Zurueck zum Arbeitstisch", 0, NORMAL_ON, ALT_Z_KEY, 0},
	{250, 432, 64, 25, 0, 1, Fest_an_aus, 1, "Das Brett Unbeschreibbar machen", 0, NORMAL_ON, ALT_F_KEY, 0},
	{450, 312, 130, 25, 0, 1, Test, 1, "Das Brett probespielen", 0, NORMAL_ON, ALT_T_KEY, 0},
	{102, 91, KARTE_X*19, KARTE_Y*19, 0, 2, Zeige_Brett_Voll, 1, "Zeige das Brett in Orginalgroesse", 0, AUGE_ANI, -1, 0},
	{568, 34, 64, 25, 0, 1, SpielModus_E, 1, "Wie wollen Sie Spielen?", 0, NORMAL_ON, ALT_M_KEY, 0},
	{999, 999, 999, 999, 999, 999, 0, 0, "", 0, 0, -1, 0},
};

struct BIT_BUTTON bit_but_editor_menu_laden[] =
{
	{385, 59, 44, 25, 0, 0, editor_links_Laden, 1, "Ein Brett zurueck", 0, PLEFT_ANI, -1, 1},
	{429, 59, 44, 25, 0, 1, editor_rechts_Laden, 1, "Ein Brett nach vorne", 0, PRIGHT_ANI, -1, 1},
	{407, 84, 131, 25, 0, 1, Laden_OK, 1, "Dieses Brett will ich", 0, OK_ANI, ALT_O_KEY, 0},
	{407, 109, 131, 25, 0, 1, zuruck, 1, "Das lade menu verlassen", 0, NORMAL_ON, ALT_Z_KEY, 0},
	{428, 196, 130, 25, 0, 0, Datei_loschen, 1, "Dieses Brett loeschen", 0, EIMER_ANI, ALT_C_KEY, 0},
	{450, 312, 130, 25, 0, 1, Test, 1, "Das Brett probespielen", 0, NORMAL_ON, ALT_T_KEY, 0},
	{102, 91, KARTE_X*19, KARTE_Y*19, 0, 2, Zeige_Brett_Voll, 1, "Zeige das Brett in orginalgroesse", 0, AUGE_ANI, -1, 0},
	{999, 999, 999, 999, 999, 999, 0, 0, "", 0, 0, -1, 0},
};

extern int WaitWBreak(int, int);
extern void Warte_auf_Taste(int);
extern char *Eingabe(int, int, int, int, int, int, int, int *);
extern void Check_Key(int key, struct BIT_BUTTON *);

extern GXHEADER Ein_pic;

// Tasten hilfe:
#define RIGHT_SHIFT  0x01
#define ALT_Z_KEY 0x2c00
#define ALT_F_KEY 0x2100
#define ALT_M_KEY 0x3200
#define ALT_C_KEY 0x2e00
#define ALT_B_KEY 0x3000
#define ALT_Q_KEY 0x1000
#define ALT_A_KEY 0x1e00
#define ALT_I_KEY 0x1700
#define ALT_E_KEY 0x1200
#define ALT_L_KEY 0x2600
#define ALT_J_KEY 0x2400
#define ALT_N_KEY 0x3100
#define ALT_O_KEY 0x1800
#define ALT_S_KEY 0x1f00
#define ALT_T_KEY 0x1400
#define ALT_U_KEY 0x1600
#define M_KEY 0x326d
#define S_KEY 0x1f73
#define H_KEY 0x2368
#define ENTF_KEY 0x5300
#define RETURN_KEY 0x1c0d
#define BACK_KEY 0xe08
#define SPACE_KEY 0x3920
#define ESC_KEY 0x11b
#define ALT_F4_KEY 0x6b00
#define UP_KEY 0x4800
#define DOWN_KEY 0x5000
#define LEFT_KEY 0x4b00
#define RIGHT_KEY 0x4d00
#define STRG_UP_KEY 0x1111
#define STRG_DOWN_KEY 0x2222
#define STRG_LEFT_KEY 0x3333
#define STRG_RIGHT_KEY 0x4444
#define F10_KEY 0x4400
#define F9_KEY 0x4300
#define F8_KEY 0x4200
#define F6_KEY 0x4000
#define F5_KEY 0x3f00
#define F4_KEY 0x3e00
#define F3_KEY 0x3d00
#define F2_KEY 0x3c00
#define F1_KEY 0x3b00
#define PLUS_KEY 0x4e2b
#define MINUS_KEY 0x4a2d
#define KEY_1 0x4f31
#define KEY_2 0x5032
#define KEY_3 0x5133
#define KEY_4 0x4b34


// Die Verschiedenen Mauszeiger:
#define OK_ANI 0
#define NO_ANI 1
#define PLEFT_ANI 2
#define PRIGHT_ANI 3
#define EXIT_ANI 4
#define HAMMER_ANI 5
#define EIMER_ANI 6
#define AUGE_ANI 7
#define DROP_ANI 8
#define PUSH_ANI 9
#define NORMAL 10
#define NORMAL_ON 11

// Verschiedene Definationen:
#define M_BX  co_Mouse_Style[co_Mouse.Mouse_style].b_x
#define M_BY  co_Mouse_Style[co_Mouse.Mouse_style].b_y
#define MOUSE_B 25
#define MOUSE_H 25

struct CO_MOUSE_STYLE
{
    int b_x, b_y, max_ani, ani_step;
};

struct CO_MOUSE
{
    int Joystick_on;                                       // Joystick aktiv oder nicht?
    int Mouse_on;                                       // Maus aktiv oder nicht?
    int Mouse_show, Mouse_style, Set_Mouse_style;       // Maus sichtbar?, Aktuelles Mausstyle, zu setzendes Mausstyle
    int mx, my, s_mx, s_my, mb;                         // Positzions angaben der Maus
};

extern GXHEADER SV;
extern GXHEADER Mouse_Back;
extern GXHEADER Mouse_Back2;
extern GXHEADER mouse_and[2], mouse_xor[2];
extern struct CO_MOUSE_STYLE co_Mouse_Style[];
extern struct CO_MOUSE co_Mouse;
extern int MouseBound_x, MouseBound_y, MouseBound_x2, MouseBound_y2; // Die Maus bekrenzung

extern void Key_Mouse(int);
extern void Show_mouse(void);
extern void No_Show_mouse(void);
extern void SetVirtualMouse(void);
extern void Move_Mouse(int);
extern void SetMouseBounds(int, int, int, int);


extern GXHEADER Message_pic;
extern GXHEADER OK_Button;
extern GXHEADER YES_NO_Button;
extern GXHEADER star_a[8];
extern GXHEADER star_x[8];
extern GXHEADER huge star_back[55];
GXHEADER stein[3];
GXHEADER huge stein_back_and[STONE_TOOL_MAX];
GXHEADER huge stein_back_xor[STONE_TOOL_MAX];
GXHEADER PassPhoto;

void Lade_Main_Pics(void);
void Destroy_Main_Pics(void);

void Lade_Main_Pics(void)
{
    GXHEADER pic;
    int i, x;

    pcxFileImage(gxEMM,"pic/Tools.pcx", &pic, gxDETECT);
    gxCreateVirtual(gxXMM, &Message_pic, Setup.gxtype, 270, 150);
    gxVirtualVirtual(&pic, 306, 285, 575, 434, &Message_pic, 0, 0, gxSET);
    gxCreateVirtual(gxXMM, &OK_Button, Setup.gxtype, 130, 25);
    gxVirtualVirtual(&pic, 240, 157, 370, 182, &OK_Button, 0, 0, gxSET);
    gxCreateVirtual(gxXMM, &YES_NO_Button, Setup.gxtype, 240, 25);
    gxVirtualVirtual(&pic, 0, 157, 239, 182, &YES_NO_Button, 0, 0, gxSET);
    for(i = 0; i < 55; i++)
      gxCreateVirtual(gxEMM, &star_back[i], Setup.gxtype, 9, 9);
    for(i = 0, x = 1; i < 7; i++, x += 10)
    {
       gxCreateVirtual(gxXMM, &star_a[i], Setup.gxtype, 9, 9);
       gxVirtualVirtual(&pic, x, 183, x+9, 192, &star_a[i], 0, 0, gxSET);
    }
    for(i = 0; i < 7; i++, x += 10)
    {
       gxCreateVirtual(gxXMM, &star_x[i], Setup.gxtype, 9, 9);
       gxVirtualVirtual(&pic, x, 183, x+9, 192, &star_x[i], 0, 0, gxSET);
    }
    gxCreateVirtual(gxXMM, &PassPhoto, Setup.gxtype, 150, 180);
    gxVirtualVirtual(&pic, 426, 105, 575, 284, &PassPhoto, 0, 0, gxSET);
    gxDestroyVirtual(&pic);
    for(i = 0; i < 3; i++)
      gxCreateVirtual(gxXMM, &stein[i], Setup.gxtype, KACHEL_B, KACHEL_H);
    gxCreateVirtual(gxXMM, &stein_and, Setup.gxtype, KACHEL_B, KACHEL_H);
    gxCreateVirtual(gxXMM, &stein_xor, Setup.gxtype, KACHEL_B, KACHEL_H);
    for(i = 0; i < STONE_TOOL_MAX; i++)
    {
        gxCreateVirtual(gxEMM, &stein_back_and[i], Setup.gxtype, KACHEL_B, KACHEL_H);
        gxCreateVirtual(gxEMM, &stein_back_xor[i], Setup.gxtype, KACHEL_B, KACHEL_H);
    }
}

void Destroy_Main_Pics(void)
{
    int i;

    for(i = 0; i < 7; i++)
	{
        gxDestroyVirtual(&star_a[i]);
	    gxDestroyVirtual(&star_x[i]);
    }
    for(i = 0; i < 55; i++)
	    gxDestroyVirtual(&star_back[i]);
    gxDestroyVirtual(&Message_pic);
    gxDestroyVirtual(&OK_Button);
    gxDestroyVirtual(&YES_NO_Button);
    gxDestroyVirtual(&PassPhoto);
    for(i = 0; i < 3; i++)
	    gxDestroyVirtual(&stein[i]);
    for(i = 0; i < STONE_TOOL_MAX; i++)
	{
        gxDestroyVirtual(&stein_back_and[i]);
	    gxDestroyVirtual(&stein_back_xor[i]);
    }
}

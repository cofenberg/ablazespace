// Die Funktionen Bit But Funktionen
// (Ein Bild das als Button verwendet wird)

// Letzte gro�e �nderung:  16.1.1997

GXHEADER an_aus[4];    // 0 = linkes licht an, 1 = rechtes,  2 = links aus, 3 = rechts aus

void CheckBitMouse(struct BIT_BUTTON *);
struct BIT_BUTTON *suche_bit_button(struct BIT_BUTTON *);
int Check_last_Bit_Button(struct BIT_BUTTON *, struct BIT_BUTTON *);
void Bit_But_Up(struct BIT_BUTTON *);
void Bit_But_Down(struct BIT_BUTTON *);
void Clear_Buttons_on(struct BIT_BUTTON *);
void Kennung_setzen(struct BIT_BUTTON *, struct BIT_BUTTON *);

struct BIT_BUTTON no_bit_but = {999, 999, 999, 999, 999, 999, 0, 0, "", 0, 0, -1, 0};

// Dies ist die Funktion, welche die Bit Buttons steuert
void CheckBitMouse(struct BIT_BUTTON *button)
{
    struct BIT_BUTTON *save_button;
    struct BIT_BUTTON *found_button;
    struct dostime_t time;
    static struct BIT_BUTTON *save_found_button = &init_bit_but;
    static struct dostime_t time_save;
    static struct dostime_t time_save2;
    int durchlauf, durchlauf2;
    int MausLange;

	if(co_Mouse.Mouse_on == 1)
	    grGetMousePos(&co_Mouse.mx, &co_Mouse.my);
	found_button = suche_bit_button(button);
    if(Ja == 1)
    {
        if(save_found_button != found_button)
            save_found_button->help_on = NO;
        if(Player_Setup.Help == NO && found_button->help_on == YES)
        {
            gxVirtualDisplay(&SV, 0, Player_Setup.HELP_Y, 0, Player_Setup.HELP_Y, 640, Player_Setup.HELP_Y+30, 0);
            save_found_button->help_on = NO;
        }
        if(Player_Setup.Help == YES && found_button->help_on == NO)
        {
            save_found_button = found_button;
            found_button->help_on = YES;
            gxVirtualDisplay(&SV, 0, Player_Setup.HELP_Y, 0, Player_Setup.HELP_Y, 640, Player_Setup.HELP_Y+30, 0);
            SetFont(1, grBLACK, grBLACK, txTRANS);
            txPutString(found_button->help_text, 325, Player_Setup.HELP_Y+25);
            SetFont(1, grWHITE, grBLACK, txTRANS);
            txPutString(found_button->help_text, 320, Player_Setup.HELP_Y+20);
        }
    }
    if(Ja == 0)
    {
	    if(save_found_button->help_on == YES)
        {
            gxVirtualDisplay(&SV, 0, Player_Setup.HELP_Y, 0, Player_Setup.HELP_Y, 640, Player_Setup.HELP_Y+30, 0);
            save_found_button->help_on = NO;
        }
        Clear_Buttons_on(&button[0]);
    }
    else
    {
        if(found_button->an == NO)
            Kennung_setzen(found_button, button);
        else
        {
            if(co_Mouse.Set_Mouse_style != found_button->Mouse_style)
                Kennung_setzen(found_button, button);
        }
    }
	Move_Mouse(NO);
    if(co_Mouse.Mouse_on == YES)
	    co_Mouse.mb = grGetMouseButtons();
	if (co_Mouse.mb == grLBUTTON)
    {
		if(co_Mouse.Mouse_on == YES)
	    	co_Mouse.mb = grGetMouseButtons();
        co_Mouse.mb = 0;
        if(Ja == 1)
        {
            if(found_button->richtung == 3 && found_button->p == 0)
            	return;
            MausLange = 0;
            save_button = found_button;
            gxVirtualDisplay(&SV, 0, Player_Setup.HELP_Y, 0, Player_Setup.HELP_Y, 640, Player_Setup.HELP_Y+30, 0);
            save_found_button->help_on = 0;
            if(save_found_button->richtung != 3) // keine richtige taste
	            Bit_But_Down(save_button);
            _dos_gettime(&time);
            time_save.hsecond = time.hsecond;
            time_save2.hsecond = time.hsecond;
            durchlauf = 0;
            durchlauf2 = 0;
			for(;;)
            {
                Move_Mouse(NO);
	            if(co_Mouse.Mouse_on == 0 && co_Mouse.Joystick_on == 0)
                	break;
	            if(co_Mouse.Mouse_on == 1)
    	            if(grGetMouseButtons() == 0)
                    	break;
	            if(co_Mouse.Joystick_on == 1)
    	            if(co_Mouse.mb == 0)
                    	break;
                _dos_gettime(&time);
                if(time.hsecond != time_save2.hsecond)
                {
                    time_save2.hsecond = time.hsecond;
                    if(durchlauf2 < 3)
                        durchlauf2++;
                    else
                        MausLange = 1;
                }
                if(Check_last_Bit_Button(save_button, button) == 1)
                {
                    if(found_button->an == 0)
                            Kennung_setzen(found_button, button);
                    else
                    {
                        if(co_Mouse.Set_Mouse_style != found_button->Mouse_style)
                            Kennung_setzen(found_button, button);
                    }
                    if(found_button->WhileClick == 1)
                    {
                        _dos_gettime(&time);
                        if(time.hsecond != time_save.hsecond)
                        {
                            time_save.hsecond = time.hsecond;
                            durchlauf++;
                        }
                        if(durchlauf >= 3)
                        {
                            durchlauf = 0;
                            if(save_button->p != 0)
                                save_button->p();
                        }
                    }
                }
                else
                    Clear_Buttons_on(&button[0]);
                if(StarModule == TITELSTARS)
                     starm(&titel_star[0]);
            }
	        if(save_found_button->richtung != 3) // keine richtige taste
           	{
                if(found_button->on == 1)
                    Bit_But_Up(save_button);
            }
            if(MausLange == 1)
            	if(Check_last_Bit_Button(save_button, button) != 1)
					return;
            if(save_button->p != 0)
                save_button->p();
    	}
	}
}

// Sucht einen Bit Button
struct BIT_BUTTON *suche_bit_button(struct BIT_BUTTON *button)
{
    int i;

	for (i = 0; button->b != 999; i++, button++)
		if ((button->on != 0 && co_Mouse.mx > button->x && co_Mouse.mx < button->x+button->b &&
             co_Mouse.my > button->y && co_Mouse.s_my < button->y+button->h))
        {
            Ja = 1;
            return (button);
    	}
    Ja = 0;
	return (0);
}

// Wenn Eine Maustaste getr�ckt wird, wird gepr�ft ob die Maus sich jetzt noch auf
// dem selben Bit Button befindet wie beim anklicken
int Check_last_Bit_Button(struct BIT_BUTTON *save_button, struct BIT_BUTTON *button)
{
    struct BIT_BUTTON *found_button;

	if(co_Mouse.Mouse_on == 1)
	    grGetMousePos(&co_Mouse.mx , &co_Mouse.my);
    found_button = suche_bit_button(&button[0]);
    if(found_button == save_button)
        return(1);
	else
		return(0);
}

// Zeichnet einen Bit Button nicht gedr�ckt
void Bit_But_Up(struct BIT_BUTTON *button)
{
    if(button->on != 2)
    {
        if(co_Mouse.Mouse_show == 1)
        {
            gxVirtualVirtual(&Mouse_Back, 0, 0, MOUSE_B, MOUSE_H, &SV, co_Mouse.s_mx-M_BX, co_Mouse.s_my-M_BY, gxSET);
        	gxVirtualDisplay(&SV, co_Mouse.s_mx-M_BX, co_Mouse.s_my-M_BY, co_Mouse.s_mx-M_BX, co_Mouse.s_my-M_BY, co_Mouse.s_mx+MOUSE_B-M_BX, co_Mouse.s_my+MOUSE_H-M_BY, 0);
        }
        grSetFillStyle(0, grGRAY, WHITE);
        if(button->richtung == 0)
        {
            grFloodSpill(button->x+button->b-10, button->y+2);
            grFloodSpill(button->x+button->b-2, button->y+5);
            grSetFillStyle(0, grDARKGRAY, grWHITE);
            grFloodSpill(button->x+25, button->y+button->h-2);
        }
        if(button->richtung == 1)
        {
            grFloodSpill(button->x+10, button->y+2);
            grSetFillStyle(0, grDARKGRAY, WHITE);
            grFloodSpill(button->x+2, button->y+5);
            grSetFillStyle(0, grDARKGRAY, grWHITE);
            grFloodSpill(button->x+5, button->y+button->h-2);
        }
        gxDisplayVirtual(button->x, button->y, button->x+button->b, button->y+button->h, 0, &SV, button->x, button->y);
        if(co_Mouse.Mouse_show == 1)
	    {
	       	gxVirtualVirtual(&SV, co_Mouse.s_mx-M_BX, co_Mouse.s_my-M_BY, co_Mouse.s_mx+MOUSE_B-M_BX, co_Mouse.s_my+MOUSE_H-M_BY, &Mouse_Back, 0, 0, gxSET);
        	SetVirtualMouse();
        	gxVirtualDisplay(&SV, co_Mouse.s_mx-M_BX, co_Mouse.s_my-M_BY, co_Mouse.s_mx-M_BX, co_Mouse.s_my-M_BY, co_Mouse.s_mx+MOUSE_B-M_BX, co_Mouse.s_my+MOUSE_H-M_BY, 0);
		}
    }
}

// Zeichnet einen Bit Button gedr�ckt
void Bit_But_Down(struct BIT_BUTTON *button)
{
    if(button->on != 2)
    {
        if(co_Mouse.Mouse_show == 1)
        {
            gxVirtualVirtual(&Mouse_Back, 0, 0, MOUSE_B, MOUSE_H, &SV, co_Mouse.s_mx-M_BX, co_Mouse.s_my-M_BY, gxSET);
        	gxVirtualDisplay(&SV, co_Mouse.s_mx-M_BX, co_Mouse.s_my-M_BY, co_Mouse.s_mx-M_BX, co_Mouse.s_my-M_BY, co_Mouse.s_mx+MOUSE_B-M_BX, co_Mouse.s_my+MOUSE_H-M_BY, 0);
        }
        grSetFillStyle(0, grDARKGRAY, WHITE);
        if(button->richtung == 0)
        {
            grFloodSpill(button->x+button->b-10, button->y+2);
            grFloodSpill(button->x+button->b-2, button->y+5);
            grSetFillStyle(0, grGRAY, grWHITE);
            grFloodSpill(button->x+25, button->y+button->h-2);
        }
        if(button->richtung == 1)
        {
            grFloodSpill(button->x+10, button->y+2);
            grSetFillStyle(0, grGRAY, WHITE);
            grFloodSpill(button->x+2, button->y+5);
            grSetFillStyle(0, grGRAY, grWHITE);
            grFloodSpill(button->x+5, button->y+button->h-2);
        }
        gxDisplayVirtual(button->x, button->y, button->x+button->b, button->y+button->h, 0, &SV, button->x, button->y);
        if(co_Mouse.Mouse_show == 1)
	    {
	       	gxVirtualVirtual(&SV, co_Mouse.s_mx-M_BX, co_Mouse.s_my-M_BY, co_Mouse.s_mx+MOUSE_B-M_BX, co_Mouse.s_my+MOUSE_H-M_BY, &Mouse_Back, 0, 0, gxSET);
        	SetVirtualMouse();
        	gxVirtualDisplay(&SV, co_Mouse.s_mx-M_BX, co_Mouse.s_my-M_BY, co_Mouse.s_mx-M_BX, co_Mouse.s_my-M_BY, co_Mouse.s_mx+MOUSE_B-M_BX, co_Mouse.s_my+MOUSE_H-M_BY, 0);
		}
    }
}

// Zeichnet alle kennungen f�r die Bit Button deaktiviert
void Clear_Buttons_on(struct BIT_BUTTON *button)
{
    int i;

    if(co_Mouse.Mouse_show == 1)
	   	gxVirtualVirtual(&Mouse_Back, 0, 0, MOUSE_B, MOUSE_H, &SV, co_Mouse.s_mx-M_BX, co_Mouse.s_my-M_BY, gxSET);
    for(i = 0; button[i].x != 999; i++)
    {
        if(button[i].an == 1)
        {
            if(button[i].richtung == 0)
            {
                gxVirtualVirtual(&an_aus[2], 0, 0, 8, 10, &SV, button[i].x+4, button[i].y+7, gxSET);
                gxVirtualDisplay(&SV, button[i].x+4, button[i].y+7, button[i].x+4, button[i].y+7, button[i].x+12, button[i].y+17, 0);
            }
            if(button[i].richtung == 1)
            {
                gxVirtualVirtual(&an_aus[3], 0, 0, 8, 10, &SV, button[i].x+(button[i].b-12), button[i].y+7, gxSET);
                gxVirtualDisplay(&SV, button[i].x+(button[i].b-12), button[i].y+7, button[i].x+(button[i].b-12), button[i].y+7, button[i].x+(button[i].b-12)+8, button[i].y+17, 0);
            }
            button[i].an = 0;
        }
    }
    co_Mouse.Set_Mouse_style = NORMAL;
    if(co_Mouse.Mouse_show == 1)
	{
        gxVirtualVirtual(&SV, co_Mouse.s_mx-M_BX, co_Mouse.s_my-M_BY, co_Mouse.s_mx+MOUSE_B-M_BX, co_Mouse.s_my+MOUSE_H-M_BY, &Mouse_Back, 0, 0, gxSET);
        Move_Mouse(NO);
	}
}

// Zeichnet eine kennung f�r den Bit Button aktiv
void Kennung_setzen(struct BIT_BUTTON *found_button, struct BIT_BUTTON *button)
{
    Clear_Buttons_on(&button[0]);
    found_button->an = 1;
    if(co_Mouse.Mouse_show == 1)
	   	gxVirtualVirtual(&Mouse_Back, 0, 0, MOUSE_B, MOUSE_H, &SV, co_Mouse.s_mx-M_BX, co_Mouse.s_my-M_BY, gxSET);
    if(found_button->richtung == 0)
    {
        gxVirtualVirtual(&an_aus[0], 0, 0, 8, 10, &SV, found_button->x+4, found_button->y+7, gxSET);
        gxVirtualDisplay(&SV, found_button->x+4, found_button->y+7, found_button->x+4, found_button->y+7, found_button->x+12, found_button->y+17, 0);
    }
    if(found_button->richtung == 1)
    {
        gxVirtualVirtual(&an_aus[1], 0, 0, 8, 10, &SV, found_button->x+(found_button->b-12), found_button->y+7, gxSET);
        gxVirtualDisplay(&SV, found_button->x+(found_button->b-12), found_button->y+7, found_button->x+(found_button->b-12), found_button->y+7, found_button->x+(button->b-12)+8, found_button->y+17, 0);
    }
    co_Mouse.Set_Mouse_style = found_button->Mouse_style;
    if(co_Mouse.Mouse_show == 1)
	{
        gxVirtualVirtual(&SV, co_Mouse.s_mx-M_BX, co_Mouse.s_my-M_BY, co_Mouse.s_mx+MOUSE_B-M_BX, co_Mouse.s_my+MOUSE_H-M_BY, &Mouse_Back, 0, 0, gxSET);
        Move_Mouse(NO);
	}
}



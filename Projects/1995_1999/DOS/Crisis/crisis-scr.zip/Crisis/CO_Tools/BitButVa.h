// Einige Variablen f�r den Bit Button

// Letzte gro�e �nderung:  16.1.1997

struct BIT_BUTTON
{
	int x, y, b, h, an, richtung; // richtung licht: <- = 0, -> = 1;     an = zeigt ob der Button gerade Markiert its
	void (*p)(void);
    int on;
    char help_text[100];
	int help_on, Mouse_style, ShotCut, WhileClick;  // WCl Das Button wird immer wieder gedr�ckt
};                // Steht richtung auf 3 ist das Feld kein richtiger BitButton

extern void CheckBitMouse(struct BIT_BUTTON *);

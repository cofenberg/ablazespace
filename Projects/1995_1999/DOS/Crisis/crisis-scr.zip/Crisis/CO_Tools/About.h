extern void	Draw_Back(int);

void About(void)
{
    GXHEADER pic;
    int save_mx, save_my;
    int x, y, i;

    No_Show_mouse();
	save_mx = co_Mouse.mx;
    save_my = co_Mouse.my;
    if(co_Mouse.Mouse_on == 1)
	    grGetMousePos(&save_mx, &save_my);
    gxCreateVirtual(gxEMM, &pic, Setup.gxtype, 640, 480);
    gxDisplayVirtual(0, 0, 640, 480, 0, &pic, 0, 0);
	Draw_Back(0);
    gxVirtualDisplay(&PassPhoto, 0, 0, 50, 150, 200, 330, 0);
    grSetBkColor(grBLACK);
	grClearArea(60, 330, 207, 337);
	grClearArea(200, 160, 207, 337);
	gxSetPaletteRGB(254, 0, 0, 0);
    for(i = 0, x = 430, y = 170; i < 2; i++, x -= 8, y -= 8)
    {
        if(i == 0)
 	       SetFont(1, grBLACK, grBLACK, txTRANS);
        if(i == 1)
 	       SetFont(1, 254, grBLACK, txTRANS);
        txPutString("Crisis 1998 von Christian Ofenberg", x, y);
        txPutString("Mozartstr. 9", x, y+50);
        txPutString("97990 Weikersheim", x, y+70);
        txPutString("Das Programm ist FREEWARE und darf", x, y+140);
        txPutString("beliebig oft weiterkopiert werden!", x, y+160);
	}
    SetFont(1, grBLACK, grBLACK, txTRANS);
    txPutString("Taste drucken...", 325, 465);
    for(i = 0; i < 60; i += 1)
	{
    	gxSetPaletteRGB(254, i, i, i);
    	gxDelay(30);
    }
    for(;;)
    {
    	if(kbhit())
        	getch();
        else
        	break;
    }
	Warte_auf_Taste(NO);
    for(i = 60; i > 0; i -= 1)
	{
    	gxSetPaletteRGB(254, i, i, i);
    	gxDelay(30);
    }
    for(y = 0; y < 20; y++)
        for(i = 0; i < 480; i += 20)
        {
            gxVirtualDisplay(&pic, 0, y+i, 0, y+i, 640, y+i, 0);
            gxDelay(1);
        }
    gxDestroyVirtual(&pic);
    grSetMousePos(save_mx, save_my);
    co_Mouse.mx = save_mx;
    co_Mouse.my = save_my;
    Show_mouse();
}

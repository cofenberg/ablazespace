extern void	Titel_bild(void);
extern struct ffblk DemoTest;
extern void Lade_style(int);
extern void Meldung(char *);
extern void Meldung_weg(void);
void SaveDemoGame(void);
int LoadDemoGame(void);
void PlayDemo(void);

struct DEMO_INFO
{
    char BrettName[15];
    char DemoName[15];
    int huge undo_zeiger;       // Wie viele Schritte gibt es?
    int huge undo_info[KARTE_X*KARTE_Y+50][4];  // Die gespeicherten Spielschritte
};

struct DEMO_INFO huge DemoInfo;

void SaveDemoGame(void)
{
    int i, datei, done, vorhanden;
    char error[50];
	char name[9];
	struct ffblk Test;

	DemoInfo.undo_zeiger = Game_Info.undo_zeiger;
    for(i = 0; i < (KARTE_X*KARTE_Y); i++)
	{
    	DemoInfo.undo_info[i][0] = Game_Info.undo_info[i][3];
    	DemoInfo.undo_info[i][1] = Game_Info.undo_info[i][6];
    	DemoInfo.undo_info[i][2] = Game_Info.undo_info[i][10];
    	DemoInfo.undo_info[i][3] = Game_Info.undo_info[i][11];
    }
    Meldung("Bitte den Demonamen eingeben.");
    No_Show_mouse();
    gxCreateVirtual(gxEMM, &Ein_pic, Setup.gxtype, 250, 40);
    gxDisplayVirtual(180, 220, 430, 260, 0, &Ein_pic, 0, 0);
    for(i = 0; i < 9; i++)
    	name[i] = 0;
    for(;;)
    {
      	strcpy(name, Eingabe(8, 310, 240, 180, 220, 430, 260, &i));
    	if(i != 0 || end != 0)
    		break;
    }
    gxDestroyVirtual(&Ein_pic);
    Meldung_weg();
    if(end != 0)
	{
        Show_mouse();
        end = 0;
    	return;
    }
    strcpy(DemoInfo.BrettName, Brett_file.ff_name);
    strcpy(DemoInfo.DemoName, name);
	sprintf(temp, "%s.dem", name);
	done = findfirst("*.dem", &Test, 0);
	vorhanden = 0;
  	i = memicmp(name, Test.ff_name, strlen(name));
    if(i != 0)
    {
        for(;;)
        {
            done = findnext(&Test);
            if(done != 0)
                break;
            i = memicmp(name, Test.ff_name, strlen(name));
            if(i == 0)
            {
				vorhanden = 1;
            	break;
            }
        }
    }
    else
		vorhanden = 1;
    Show_mouse();
    if(vorhanden == 1)
        if(Yes_No_Check("Demo ueberschreiben?", 0) == 0)
            return;
    No_Show_mouse();
    if(Setup.DiskInfo == WRITE)
    {
        datei = open(temp, O_WRONLY | O_BINARY | O_CREAT);
        chmod(temp, S_IREAD|S_IWRITE);
        write(datei, &DemoInfo, sizeof(DemoInfo));
        close(datei);
    }
    else
    {
        sprintf(error, "%s schreibschutz fehler!", temp);
        ProError(error);
    }
    Show_mouse();
}

void PlayDemo(void)
{
    int SavedControl[2];
    int i;
    
    No_Show_mouse();
    linien();
 	gxSetDisplayPalette(Setup.palSave);
	if(LoadDemoGame() != 0)
    {
        i = findnext(&DemoTest);
        if(i != 0)
            findfirst("*.dem", &DemoTest, 0);
        strcpy(DemoInfo.DemoName, DemoTest.ff_name);
		Titel_bild();
    	return;
    }
    Lade_style(NORMAL_SET);
    Game_Info.DemoOn = YES;
	Game_Info.DemoZeiger = 0;
	Game_Info.DemoWahl = 0;
    SavedControl[0] = co_Mouse.Mouse_on;
    SavedControl[1] = co_Mouse.Joystick_on;
	co_Mouse.Mouse_on = 0;
    co_Mouse.Joystick_on = 0;
    Show_mouse();
    Spiel();
    co_Mouse.Mouse_on = SavedControl[0];
    co_Mouse.Joystick_on = SavedControl[1];
    Game_Info.DemoOn = NO;
}

int LoadDemoGame(void)
{
    char error[50];
    int datei, i;

    i = memicmp("NNNNNNNN", DemoInfo.DemoName, strlen("NNNNNNNN"));
    if(i == 0)
    {
        sprintf(error, "Kein Demo gefunden!");
        ProError(error);
        return(1);
    }
	datei = open(DemoInfo.DemoName, O_BINARY);
	if(datei == -1)
    {
	    close(datei);
        sprintf(error, "Demo Datei nicht gefunden! (%s)", DemoInfo.DemoName);
        ProError(error);
        return(1);
    }
    read(datei, &DemoInfo, sizeof(DemoInfo));
    close(datei);
    sprintf(temp, "Bretter/%s", DemoInfo.BrettName);
	datei = open(temp, O_BINARY);
	if(datei == -1)
    {
	    close(datei);
        sprintf(error, "Demo Brett nicht gefunden! (%s)", DemoInfo.BrettName);
        ProError(error);
        return(1);
    }
	read(datei, &Brett_struct, sizeof(Brett_struct));
    for(i = 0; i < KARTE_X*KARTE_Y; i++)
    {
        if(Brett_struct.Brett_info[i] == 0)
	    {
       	    Kachel_info[i][0] = 0;
       	    Kachel_info[i][1] = 0;
        }
        if(Brett_struct.Brett_info[i] == 1)
	    {
			Kachel_info[i][0] = 1;
			Kachel_info[i][1] = 0;
        }
        if(Brett_struct.Brett_info[i] == 2)
	    {
			Kachel_info[i][0] = 1;
			Kachel_info[i][1] = 1;
        }
        Kachel_info[i][8] = Brett_struct.bild[i];
    }
    close(datei);
    return(0);
}




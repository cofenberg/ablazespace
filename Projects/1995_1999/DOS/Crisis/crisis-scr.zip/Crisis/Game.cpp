#include "Co_Tools/struct.h"

extern struct ffblk BrettStyle;
extern struct ffblk Brett_hintergrund;
extern GXHEADER PUSH_ani_and[5];
extern GXHEADER PUSH_ani_xor[5];
extern GXHEADER DROP_ani_and[5];
extern GXHEADER DROP_ani_xor[5];
extern GXHEADER star_virtual;
extern GXHEADER star_a[8];
extern GXHEADER star_x[8];
extern GXHEADER star_back[55];
extern int ani_step;
extern GXHEADER hinter_pic;
GXHEADER liste;
GXHEADER Mouse_Back2;
struct ffblk Brett_file;
int huge Kachel_info[KARTE_X*KARTE_Y+2][9];
int huge Kachel_info_save_2[KARTE_X * KARTE_Y][4];
// 0:an, 1:belegt, 2:aktiv, 3:kennzeichen, 4:x, 5:y, 6:v_x, 7:v_y
/*
char text[10000];
char *text;
text = malloc(10000);
feld = malloc ((KARTE_X*KARTE_Y)*11*sizeof (int));
free(text);
*/
struct GAME_INFO huge Game_Info;
extern struct BRETT_STRUCT Brett_struct;

#include "GameFunkListe.h"
#include "Demo.h"  // Demo abspielger�t

struct BIT_BUTTON bit_but_spiel[] =
{
	{119, 4, 130, 25, 0, 1, undo, 0, "Einen Schritt zureuck aber dally!!", 0, EIMER_ANI, -1},
	{259, 4, 130, 25, 0, 1, level_neu, 1, "Das Brett noch einmal von Vorne", 0, NORMAL_ON, -1},
	{399, 4, 130, 25, 0, 1, vor_Ende_2, 1, "Zureuck zum Hauptmenu", 0, EXIT_ANI, -1},
	{999, 999, 999, 999, 999, 999, 0, 0, "", 0, 0, -1},
};

struct STAR liste_star[] =
{
	{29, -4, -1},
	{13, 4, -1},
	{25, 14, -1},
	{10, 19, -1},
	{39, 5, -1},
	{41, 20, -1},
	{49, -2, -1},
	{47, 4, -1},
	{53, 17, -1},
	{56, 3, -1},
	{66, 4, -1},
	{69, -1, -1},
	{68, 16, -1},
	{84, 3, -1},
	{81, 21, -1},
	{999, 999, 999},
};

#include "GameOut.h"
#include "GameCheckMouse.h"

void listen_ani(void)
{
    static struct dostime_t time_save;
    struct dostime_t time;
    int i;

    _dos_gettime(&time);
    if(time.hsecond != time_save.hsecond)
    {
        time_save.hsecond = time.hsecond;
        for(i = 0; i < 2; i++)
        {
            if(Game_Info.pixel_rich[i] == 0)
            {
                Game_Info.pixel_x[i]++;
                grSetColor(grWHITE);
                grDrawLine(Game_Info.pixel_x[i], 29, Game_Info.pixel_x[i]+5, 29);
                grSetColor(grGRAY);
                grDrawLine(Game_Info.pixel_x[i]-1, 29, Game_Info.pixel_x[i]-5, 29);
                grSetColor(grDARKGRAY);
                grDrawLine(Game_Info.pixel_x[i]-5, 29, Game_Info.pixel_x[i]-7, 29);
                grSetColor(grBLACK);
                grDrawLine(Game_Info.pixel_x[i]-7, 29, Game_Info.pixel_x[i]-9, 29);
                if(Game_Info.pixel_x[i] > 630)
                   Game_Info.pixel_rich[i] = 1;
            }
            else
                if(Game_Info.pixel_rich[i] == 1)
                {
                    Game_Info.pixel_x[i]--;
                    grSetColor(grWHITE);
                    grDrawLine(Game_Info.pixel_x[i], 29, Game_Info.pixel_x[i]-5, 29);
                    grSetColor(grGRAY);
                    grDrawLine(Game_Info.pixel_x[i]+1, 29, Game_Info.pixel_x[i]+5, 29);
                    grSetColor(grDARKGRAY);
                    grDrawLine(Game_Info.pixel_x[i]+5, 29, Game_Info.pixel_x[i]+7, 29);
                    grSetColor(grBLACK);
                    grDrawLine(Game_Info.pixel_x[i]+7, 29, Game_Info.pixel_x[i]+9, 29);
                    if(Game_Info.pixel_x[i] < 10)
                       Game_Info.pixel_rich[i] = 0;
                }
        }
    }
}

void level_neu(void)
{
    if(Yes_No_Check("Wircklich neu beginnen?", 0) == 0)
    	return;
    neu();
}

void leiste(void)
{
    int i, key;

    No_Show_mouse();
    co_Mouse.Set_Mouse_style = NORMAL;
    for(i = 0; i < 30; i++)
    	gxVirtualDisplay(&liste, 0, i, 0, 0, 640, 29, 0);
    for(i = 0; liste_star[i].x != 999; i++)
        liste_star[i]. ani = -1;
    gxDisplayVirtual(0, Player_Setup.HELP_Y, 640, Player_Setup.HELP_Y+30, 0, &SV, 0, Player_Setup.HELP_Y);
    Show_mouse();
    for(;;)
    {
	    Move_Mouse(NO);
 	    CheckSetupOptions();
        CheckBitMouse(&bit_but_spiel[0]);
        if(bioskey(1) != 0)
        {
            key = bioskey(0);
            Check_Key(key, &bit_but_spiel[0]);
            switch(key)
            {
            	case 27:
                	Ende(0);
                    break;
            }
        }
        if(end != 0)
            break;
        if(co_Mouse.Mouse_on == 1)
		    grGetMousePos(&co_Mouse.mx , &co_Mouse.my);
	    if(co_Mouse.my > 30)
            break;
    }
    No_Show_mouse();
    Game_Info.pixel_x[0] = 10;
    Game_Info.pixel_rich[0] = 0;
    Game_Info.pixel_x[1] = 630;
    Game_Info.pixel_rich[1] = 1;
    Clear_Buttons_on(&bit_but_spiel[0]);
    for(i = 30; i > -1; i--)
    	gxVirtualDisplay(&liste, 0, i, 0, 0, 640, 29, 0);
    gxVirtualDisplay(&SV, 0, Player_Setup.HELP_Y, 0, Player_Setup.HELP_Y, 640, Player_Setup.HELP_Y+30, 0);
    Show_mouse();
}

int Check_Jumps_out(void)
{
    int i, i2;

	for (i = 0, i2 = 0; Kachel_info[i][3] != 999; i++)
	{
		i2 = Check_jumps(i);
        if(i2 == 1)
        	return(1);
    }
	return(0);
}

int Check_jumps(int Kachel)
{
	int zwischen, Kachel_2;

    if(Kachel_info[Kachel][0] == 1 && Kachel_info[Kachel][1] == 1)
    {
        // Sucht Links das Zwischen Feld:
	    zwischen = suchefeld(Kachel_info[Kachel][4]-5, Kachel_info[Kachel][5]+5);
        if(Game_Info.Spielart == CLASSIC)
            if(Kachel_info[zwischen][1] == 1)
            {   // Nun wird das Loch gesucht, in dem der Stein landen soll:
                Kachel_2 = zwischen;
                zwischen = suchefeld(Kachel_info[Kachel_2][4]-5, Kachel_info[Kachel_2][5]+5);
                if(zwischen != 999 && Kachel_info[zwischen][1] == 0)
                    return(1);
            }
        if(Game_Info.Spielart == MODERN)
            if(Kachel_info[zwischen][1] == 1 || Kachel_info[zwischen][8] == EXTRA_STEIN || Kachel_info[zwischen][8] == EXTRA_OTHER || Kachel_info[zwischen][8] == EXTRA_TWO)
            {   // Nun wird das Loch gesucht, in dem der Stein landen soll:
                Kachel_2 = zwischen;
                zwischen = suchefeld(Kachel_info[Kachel_2][4]-5, Kachel_info[Kachel_2][5]+5);
                if(zwischen != 999 && Kachel_info[zwischen][1] == 0)
                    return(1);
            }
        // Sucht Rechts das Zwischen Feld:
		zwischen = suchefeld(Kachel_info[Kachel][4]+KACHEL_B+5, Kachel_info[Kachel][5]+5);
        if(Game_Info.Spielart == CLASSIC)
            if(Kachel_info[zwischen][1] == 1)
            {   // Nun wird das Loch gesucht, in dem der Stein landen soll:
                Kachel_2 = zwischen;
                zwischen = suchefeld(Kachel_info[Kachel_2][4]+KACHEL_B+5, Kachel_info[Kachel_2][5]+5);
                if(zwischen != 999 && Kachel_info[zwischen][1] == 0)
                    return(1);
            }
        if(Game_Info.Spielart == MODERN)
            if(Kachel_info[zwischen][1] == 1 || Kachel_info[zwischen][8] == EXTRA_STEIN || Kachel_info[zwischen][8] == EXTRA_OTHER || Kachel_info[zwischen][8] == EXTRA_TWO)
            {   // Nun wird das Loch gesucht, in dem der Stein landen soll:
                Kachel_2 = zwischen;
                zwischen = suchefeld(Kachel_info[Kachel_2][4]+KACHEL_B+5, Kachel_info[Kachel_2][5]+5);
                if(zwischen != 999 && Kachel_info[zwischen][1] == 0)
                    return(1);
            }
        // Sucht Oben das Zwischen Feld:
	    zwischen = suchefeld(Kachel_info[Kachel][4]+5, Kachel_info[Kachel][5]-5);
        if(Game_Info.Spielart == CLASSIC)
            if(Kachel_info[zwischen][1] == 1)
            {   // Nun wird das Loch gesucht, in dem der Stein landen soll:
                Kachel_2 = zwischen;
                zwischen = suchefeld(Kachel_info[Kachel_2][4]+5, Kachel_info[Kachel_2][5]-10);
                if(zwischen != 999 && Kachel_info[zwischen][1] == 0)
                    return(1);
            }
        if(Game_Info.Spielart == MODERN)
            if(Kachel_info[zwischen][1] == 1 || Kachel_info[zwischen][8] == EXTRA_STEIN || Kachel_info[zwischen][8] == EXTRA_OTHER || Kachel_info[zwischen][8] == EXTRA_TWO)
            {   // Nun wird das Loch gesucht, in dem der Stein landen soll:
                Kachel_2 = zwischen;
                zwischen = suchefeld(Kachel_info[Kachel_2][4]+5, Kachel_info[Kachel_2][5]-10);
                if(zwischen != 999 && Kachel_info[zwischen][1] == 0)
                    return(1);
            }
        // Sucht Unten das Zwischen Feld:
	    zwischen = suchefeld(Kachel_info[Kachel][4]+5, Kachel_info[Kachel][5]+KACHEL_H+5);
        if(Game_Info.Spielart == CLASSIC)
            if(Kachel_info[zwischen][1] == 1)
            {   // Nun wird das Loch gesucht, in dem der Stein landen soll:
                Kachel_2 = zwischen;
                zwischen = suchefeld(Kachel_info[Kachel_2][4]+5, Kachel_info[Kachel_2][5]+KACHEL_H+5);
                if(zwischen != 999 && Kachel_info[zwischen][1] == 0)
                    return(1);
            }
        if(Game_Info.Spielart == MODERN)
            if(Kachel_info[zwischen][1] == 1 || Kachel_info[zwischen][8] == EXTRA_STEIN || Kachel_info[zwischen][8] == EXTRA_OTHER || Kachel_info[zwischen][8] == EXTRA_TWO)
            {   // Nun wird das Loch gesucht, in dem der Stein landen soll:
                Kachel_2 = zwischen;
                zwischen = suchefeld(Kachel_info[Kachel_2][4]+5, Kachel_info[Kachel_2][5]+KACHEL_H+5);
                if(zwischen != 999 && Kachel_info[zwischen][1] == 0)
                    return(1);
            }
    }
    return(0);
}

int Check_jump(int Kachel)
{
	int zwischen;

    if(Kachel_info[Kachel][1] == 0 && Game_Info.feld1 != -1)
    {
        // Sucht Links das Zwischen Feld:
	    zwischen = suchefeld(Kachel_info[Kachel][4]-5, Kachel_info[Kachel][5]+5);
        if(Game_Info.Spielart == CLASSIC)
	        if(Kachel_info[zwischen][1] == 1 && Kachel_info[Kachel][6]-2 == Kachel_info[Game_Info.feld1][6] && Kachel_info[Kachel][7] == Kachel_info[Game_Info.feld1][7])
    	    	return(zwischen);
        if(Game_Info.Spielart == MODERN)
	        if((Kachel_info[zwischen][1] == 1 || Kachel_info[zwischen][8] == EXTRA_STEIN || Kachel_info[zwischen][8] == EXTRA_TWO || Kachel_info[zwischen][8] == EXTRA_OTHER) && Kachel_info[Kachel][6]-2 == Kachel_info[Game_Info.feld1][6] && Kachel_info[Kachel][7] == Kachel_info[Game_Info.feld1][7] && Kachel_info[Kachel][8] != EXTRA_STEIN && Kachel_info[Kachel][8] != EXTRA_TWO && Kachel_info[Kachel][8] != EXTRA_OTHER)
    	    	return(zwischen);
        // Sucht Rechts das Zwischen Feld:
	    zwischen = suchefeld(Kachel_info[Kachel][4]+KACHEL_B+5, Kachel_info[Kachel][5]+5);
        if(Game_Info.Spielart == CLASSIC)
	        if(Kachel_info[zwischen][1] == 1 && Kachel_info[Kachel][6]+2 == Kachel_info[Game_Info.feld1][6] && Kachel_info[Kachel][7] == Kachel_info[Game_Info.feld1][7])
    	    	return(zwischen);
        if(Game_Info.Spielart == MODERN)
	        if((Kachel_info[zwischen][1] == 1 || Kachel_info[zwischen][8] == EXTRA_STEIN || Kachel_info[zwischen][8] == EXTRA_TWO || Kachel_info[zwischen][8] == EXTRA_OTHER) && Kachel_info[Kachel][6]+2 == Kachel_info[Game_Info.feld1][6] && Kachel_info[Kachel][7] == Kachel_info[Game_Info.feld1][7] && Kachel_info[Kachel][8] != EXTRA_STEIN && Kachel_info[Kachel][8] != EXTRA_TWO && Kachel_info[Kachel][8] != EXTRA_OTHER)
    	    	return(zwischen);
        // Sucht Oben das Zwischen Feld:
	    zwischen = suchefeld(Kachel_info[Kachel][4]+5, Kachel_info[Kachel][5]-5);
        if(Game_Info.Spielart == CLASSIC)
	        if(Kachel_info[zwischen][1] == 1 && Kachel_info[Kachel][6] == Kachel_info[Game_Info.feld1][6] && Kachel_info[Kachel][7]-2 == Kachel_info[Game_Info.feld1][7])
    	    	return(zwischen);
        if(Game_Info.Spielart == MODERN)
	        if((Kachel_info[zwischen][1] == 1 || Kachel_info[zwischen][8] == EXTRA_STEIN || Kachel_info[zwischen][8] == EXTRA_TWO || Kachel_info[zwischen][8] == EXTRA_OTHER) && Kachel_info[Kachel][6] == Kachel_info[Game_Info.feld1][6] && Kachel_info[Kachel][7]-2 == Kachel_info[Game_Info.feld1][7] && Kachel_info[Kachel][8] != EXTRA_STEIN && Kachel_info[Kachel][8] != EXTRA_TWO && Kachel_info[Kachel][8] != EXTRA_OTHER)
    	    	return(zwischen);
        // Sucht Unten das Zwischen Feld:
	    zwischen = suchefeld(Kachel_info[Kachel][4]+5, Kachel_info[Kachel][5]+KACHEL_H+5);
        if(Game_Info.Spielart == CLASSIC)
	        if(Kachel_info[zwischen][1] == 1 && Kachel_info[Kachel][6] == Kachel_info[Game_Info.feld1][6] && Kachel_info[Kachel][7]+2 == Kachel_info[Game_Info.feld1][7])
    	    	return(zwischen);
        if(Game_Info.Spielart == MODERN)
	        if((Kachel_info[zwischen][1] == 1 || Kachel_info[zwischen][8] == EXTRA_STEIN || Kachel_info[zwischen][8] == EXTRA_TWO || Kachel_info[zwischen][8] == EXTRA_OTHER) && Kachel_info[Kachel][6] == Kachel_info[Game_Info.feld1][6] && Kachel_info[Kachel][7]+2 == Kachel_info[Game_Info.feld1][7] && Kachel_info[Kachel][8] != EXTRA_STEIN && Kachel_info[Kachel][8] != EXTRA_TWO && Kachel_info[Kachel][8] != EXTRA_OTHER)
    	    	return(zwischen);
    }
    return(-1);
}

void Check_durchlauf(int Kachel)
{
    int jump;

    Game_Info.durchlauf++;
    No_Show_mouse();
    if(Game_Info.durchlauf == 1)
	    if(Kachel_info[Kachel][1] == 1)
        {
            Game_Info.feld1 = Kachel_info[Kachel][3];
		    Kachel_info[Kachel][2] = 1;
            feldmalen(Kachel, 1);
            gxDelay(200);
            Show_mouse();
	    }
        else
	        Game_Info.durchlauf--;
    if(Game_Info.durchlauf == 2)
    {
	    if(Kachel_info[Kachel][3] == Game_Info.feld1)
        {
		    Kachel_info[Kachel][2] = 0;
            feldmalen(Kachel, 1);
            Game_Info.durchlauf = 0;
            Game_Info.feld1 = 0;
            gxDelay(200);
            Show_mouse();
            return;
        }
	    if(Kachel_info[Kachel][1] == 1)
        {
		    Kachel_info[Kachel][2] = 1;
            feldmalen(Kachel, 1);
		    Kachel_info[Game_Info.feld1][2] = 0;
            feldmalen(Game_Info.feld1, 1);
            Game_Info.durchlauf = 1;
            Game_Info.feld1 = Kachel_info[Kachel][3];
            gxDelay(200);
            Show_mouse();
            return;
        }
	    jump = Check_jump(Kachel);
	    if(jump != -1)
	    {
		    feldaktion(Kachel, jump, 1);
            Game_Info.durchlauf--;
        }
        else
        {
            Game_Info.durchlauf--;
        }
    }
    Show_mouse();
}

void feldaktion(int Kachel, int jump, int i2)
{
    GXHEADER pic, stein_and_n, stein_xor_n, hoch;
    int i, tele, i3, i5, i6;

    No_Show_mouse();
    if(Kachel_info[Kachel][1] == 0)
    {
    // Sichert den Alten Spielstand:
       Game_Info.undo_info[Game_Info.undo_zeiger][0] = Kachel_info[jump][3];
       Game_Info.undo_info[Game_Info.undo_zeiger][1] = Kachel_info[jump][1];
       Game_Info.undo_info[Game_Info.undo_zeiger][2] = Kachel_info[jump][8];
       Game_Info.undo_info[Game_Info.undo_zeiger][3] = Kachel_info[Game_Info.feld1][3];
       Game_Info.undo_info[Game_Info.undo_zeiger][4] = Kachel_info[Game_Info.feld1][1];
       Game_Info.undo_info[Game_Info.undo_zeiger][5] = Kachel_info[Game_Info.feld1][8];
       Game_Info.undo_info[Game_Info.undo_zeiger][6] = Kachel_info[Kachel][3];
       Game_Info.undo_info[Game_Info.undo_zeiger][7] = Kachel_info[Kachel][1];
       Game_Info.undo_info[Game_Info.undo_zeiger][8] = Kachel_info[Kachel][8];
       Game_Info.undo_info[Game_Info.undo_zeiger][9] = Game_Info.steine;
    // Setzt den Neuen Spielstand:
       if(Game_Info.Spielart == CLASSIC)
       {
             Kachel_info[Game_Info.feld1][1] = 0;
             Kachel_info[Game_Info.feld1][2] = 0;
             feldmalen(Game_Info.feld1, i2);
             Kachel_info[Kachel][1] = 1;
             Kachel_info[Kachel][2] = 1;
             Game_Info.feld1 = Kachel_info[Kachel][3];
             feldmalen(Kachel, i2);
           // Der Mittlere Stein l�st sich auf:
             Kachel_info[jump][1] = 0;
             FeldInMalen(jump, 7);
       }
       if(Game_Info.Spielart == MODERN)
       {
             Game_Info.undo_info[Game_Info.undo_zeiger][10] = -1;
             Game_Info.undo_info[Game_Info.undo_zeiger][11] = -1;
			// Ist der Mittlere Stein ein Extra Stein:
             if(Kachel_info[jump][8] == EXTRA_STEIN)
             {
				 Kachel_info[jump][8] = -1;
                 Kachel_info[jump][1] = 1;  // Den Stein Normal machen
	             FeldInMalen(jump, 15);
             }
             else
             {
	             if(Kachel_info[jump][8] == EXTRA_TWO)
                 { // Der Stein verdoppler wird aktiviert:
                     Kachel_info[jump][8] = -1;
                     Kachel_info[jump][1] = 1;
                     Kachel_info[jump][2] = 1;
		             FeldInMalen(jump, 15);
                     Game_Info.steine++;
					 Liste_farbe();
                     Fade_in(5);
                     i5 = Kachel_info[Kachel][1];
                     i6 = Kachel_info[Kachel][2];
                     Kachel_info[Kachel][1] = 1;
                     Kachel_info[Kachel][2] = 1;
                     feldmalen(Kachel, i2);
                     Kachel_info[Game_Info.feld1][2] = 0;
                     feldmalen(Game_Info.feld1, i2);
                     Kachel_info[Game_Info.feld1][2] = 1;
                     Kachel_info[Kachel][1] = i5;
                     Kachel_info[Kachel][2] = i6;
					 Kachel_info[jump][8] = EXTRA_TWO;
	                 Kachel_info[jump][1] = 0;
	                 Kachel_info[jump][2] = 0;
				 	 gxSetDisplayPalette(pal);
                     for(i = 0, i3 = 0; i < KACHEL_B/2; i++, i3++)
                     {
                         if(i3 > KACHEL_H/2)
                            i3 = KACHEL_H/2;
                         gxVirtualDisplay(&stein_back_and[EXTRA_TWO], 0+i, 0, Kachel_info[jump][4]+i, Kachel_info[jump][5], Kachel_info[jump][4]+i+1, Kachel_info[jump][5]+KACHEL_H-1, 0);
                         gxVirtualDisplay(&stein_back_and[EXTRA_TWO], KACHEL_B-i, 0, Kachel_info[jump][4]+KACHEL_B-i, Kachel_info[jump][5], Kachel_info[jump][4]+KACHEL_B-i+1, Kachel_info[jump][5]+KACHEL_H-1, 0);
                         gxVirtualDisplay(&stein_back_and[EXTRA_TWO], i, 0+i3, Kachel_info[jump][4]+i, Kachel_info[jump][5]+i3, Kachel_info[jump][4]+KACHEL_B-1-i, Kachel_info[jump][5]+i3+1, 0);
                         gxVirtualDisplay(&stein_back_and[EXTRA_TWO], i, KACHEL_H-i3, Kachel_info[jump][4]+i, Kachel_info[jump][5]+KACHEL_H-i3, Kachel_info[jump][4]+KACHEL_B-1-i, Kachel_info[jump][5]+KACHEL_H-i3, 0);
                         gxDelay(15);
                     }
                 }
                 else
                 {
		             if(Kachel_info[jump][8] != EXTRA_OTHER)
                     {
						Kachel_info[jump][1] = 0;
                     	FeldInMalen(jump, 7);
                 	 }
                 }
             }
			// Ist das Loch ein Extra Loch:
             if(Kachel_info[Kachel][8] == EXTRA_LOCH)
             {  // Kein richtiger Sprung m�glich:
				 Kachel_info[Kachel][8] = -1;
                 Kachel_info[Kachel][1] = 0; // Das verdeckte Loch ist nun frei
	             FeldInMalen(Kachel, 15);
             }
             else
             {
                 // Wenn nein, ist nun ein Stein auf dem Loch:
                 // Der Ausgew�hlte Stein ist wegesprungen:
			     if(Kachel_info[jump][8] != EXTRA_TWO)
                 		Kachel_info[Game_Info.feld1][1] = 0;
                 Kachel_info[Game_Info.feld1][2] = 0;
                 feldmalen(Game_Info.feld1, i2);
                 if(Kachel_info[Kachel][8] == EXTRA_TELEPORTER)
                 { // Ist der Stein auf ein Teleportfeld gekommen?
                   // Der Transporter l�uft:
                      for(i = 0; i < 7; i++)
                      {
			              gxVirtualDisplay(&star_a[i], 0, 0, Kachel_info[Kachel][4]+5, Kachel_info[Kachel][5]+5, Kachel_info[Kachel][4]+13, Kachel_info[Kachel][5]+13, 0);
			              gxVirtualDisplay(&star_a[i], 0, 0, Kachel_info[Kachel][4]+20, Kachel_info[Kachel][5]+10, Kachel_info[Kachel][4]+28, Kachel_info[Kachel][5]+18, 0);
			              gxVirtualDisplay(&star_a[i], 0, 0, Kachel_info[Kachel][4]+32, Kachel_info[Kachel][5]+22, Kachel_info[Kachel][4]+40, Kachel_info[Kachel][5]+29, 0);
			              gxVirtualDisplay(&star_a[i], 0, 0, Kachel_info[Kachel][4]+1, Kachel_info[Kachel][5]+22, Kachel_info[Kachel][4]+9, Kachel_info[Kachel][5]+29, 0);
			              gxVirtualDisplay(&star_a[i], 0, 0, Kachel_info[Kachel][4]+32, Kachel_info[Kachel][5]+22, Kachel_info[Kachel][4]+40, Kachel_info[Kachel][5]+29, 0);
			              gxVirtualDisplay(&star_a[i], 0, 0, Kachel_info[Kachel][4]+32, Kachel_info[Kachel][5]+22, Kachel_info[Kachel][4]+40, Kachel_info[Kachel][5]+29, 0);
			              gxVirtualDisplay(&star_a[i], 0, 0, Kachel_info[Kachel][4]+20, Kachel_info[Kachel][5]+15, Kachel_info[Kachel][4]+28, Kachel_info[Kachel][5]+23, 0);
			              gxVirtualDisplay(&star_a[i], 0, 0, Kachel_info[Kachel][4]+32, Kachel_info[Kachel][5], Kachel_info[Kachel][4]+40, Kachel_info[Kachel][5]+8, 0);
			              gxVirtualDisplay(&star_a[i], 0, 0, Kachel_info[Kachel][4]+25, Kachel_info[Kachel][5]+5, Kachel_info[Kachel][4]+33, Kachel_info[Kachel][5]+13, 0);
			              gxVirtualDisplay(&star_a[i], 0, 0, Kachel_info[Kachel][4]+10, Kachel_info[Kachel][5]+20, Kachel_info[Kachel][4]+18, Kachel_info[Kachel][5]+28, 0);
			              gxVirtualDisplay(&star_a[i], 0, 0, Kachel_info[Kachel][4]+15, Kachel_info[Kachel][5]+15, Kachel_info[Kachel][4]+23, Kachel_info[Kachel][5]+23, 0);
			              gxVirtualDisplay(&star_a[i], 0, 0, Kachel_info[Kachel][4]+4, Kachel_info[Kachel][5]+10, Kachel_info[Kachel][4]+12, Kachel_info[Kachel][5]+18, 0);
			              gxVirtualDisplay(&star_a[i], 0, 0, Kachel_info[Kachel][4]+1, Kachel_info[Kachel][5]+15, Kachel_info[Kachel][4]+9, Kachel_info[Kachel][5]+23, 0);
			              gxVirtualDisplay(&star_a[i], 0, 0, Kachel_info[Kachel][4]+9, Kachel_info[Kachel][5]+11, Kachel_info[Kachel][4]+17, Kachel_info[Kachel][5]+19, 0);
			              gxVirtualDisplay(&star_a[i], 0, 0, Kachel_info[Kachel][4]+12, Kachel_info[Kachel][5]+2, Kachel_info[Kachel][4]+20, Kachel_info[Kachel][5]+10, 0);
                          gxDelay(20);
                      }
                      for(i = 0, i3 = 0; i < KACHEL_B/2; i++, i3++)
                      {
                          if(i3 > KACHEL_H/2)
                             i3 = KACHEL_H/2;
                          gxVirtualDisplay(&stein_back_and[EXTRA_TELEPORTER], 0+i, 0, Kachel_info[Kachel][4]+i, Kachel_info[Kachel][5], Kachel_info[Kachel][4]+i+1, Kachel_info[Kachel][5]+KACHEL_H-1, 0);
                          gxVirtualDisplay(&stein_back_and[EXTRA_TELEPORTER], KACHEL_B-i, 0, Kachel_info[Kachel][4]+KACHEL_B-i, Kachel_info[Kachel][5], Kachel_info[Kachel][4]+KACHEL_B-i+1, Kachel_info[Kachel][5]+KACHEL_H-1, 0);
                          gxVirtualDisplay(&stein_back_and[EXTRA_TELEPORTER], i, 0+i3, Kachel_info[Kachel][4]+i, Kachel_info[Kachel][5]+i3, Kachel_info[Kachel][4]+KACHEL_B-1-i, Kachel_info[Kachel][5]+i3+1, 0);
                          gxVirtualDisplay(&stein_back_and[EXTRA_TELEPORTER], i, KACHEL_H-i3, Kachel_info[Kachel][4]+i, Kachel_info[Kachel][5]+KACHEL_H-i3, Kachel_info[Kachel][4]+KACHEL_B-1-i, Kachel_info[Kachel][5]+KACHEL_H-i3, 0);
                          gxDelay(15);
                      }
                      tele = Teleporter(Kachel, jump);
                     // Der Stein wird ausgegeben:
                      if(tele != -1)
                      {
                          Game_Info.undo_info[Game_Info.undo_zeiger][6] = Kachel_info[tele][3];
                          Game_Info.undo_info[Game_Info.undo_zeiger][7] = Kachel_info[tele][1];
                          Game_Info.undo_info[Game_Info.undo_zeiger][8] = Kachel_info[tele][8];
                          Game_Info.undo_info[Game_Info.undo_zeiger][10] = Kachel_info[Kachel][3];
                          Game_Info.undo_info[Game_Info.undo_zeiger][11] = Kachel_info[tele][3];
                          Kachel_info[tele][1] = 1;
                          Kachel_info[tele][2] = 1;
                          Game_Info.feld1 = Kachel_info[tele][3];
				          FeldInMalen(tele, 15);
                          co_Mouse.mx = Kachel_info[tele][4]+KACHEL_B/2;
                          co_Mouse.my = Kachel_info[tele][5]+KACHEL_H/2;
                          grSetMousePos(co_Mouse.mx, co_Mouse.my);
                      }
                      else
                      { // Der Stein kann nirgends raus, also l�s er sich auf:
                          Game_Info.steine--;
                      }
                 }
                 else
                 {
                     Game_Info.undo_info[Game_Info.undo_zeiger][6] = Kachel_info[Kachel][3];
                     Game_Info.undo_info[Game_Info.undo_zeiger][7] = Kachel_info[Kachel][1];
                     Game_Info.undo_info[Game_Info.undo_zeiger][8] = Kachel_info[Kachel][8];
                     if(Kachel_info[Kachel][8] != EXTRA_HEIS && Kachel_info[jump][8] != EXTRA_OTHER)
                     { // Alle zu Springenden Steine platzen:
                         Kachel_info[Kachel][1] = 1;
                         Kachel_info[Kachel][2] = 1;
                         Game_Info.feld1 = Kachel_info[Kachel][3];
                         feldmalen(Kachel, i2);
                     }
                     else
                     {
						if(Kachel_info[Kachel][8] == EXTRA_HEIS)
                        {  // Der Stein Springt HOCH:
					        gxDisplayVirtual(Kachel_info[Kachel][4]-30, Kachel_info[Kachel][5]-30, Kachel_info[Kachel][4]+KACHEL_B+30, Kachel_info[Kachel][5]+KACHEL_H+30, 0, &SV, Kachel_info[Kachel][4]-30, Kachel_info[Kachel][5]-30);
                            for(i = 1, i3 = 1; i < 30; i++, i3++)
                            {
						        gxCreateVirtual(gxEMM, &stein_and_n, Setup.gxtype, KACHEL_B+(i*2), KACHEL_H+(i3*2));
						        gxCreateVirtual(gxEMM, &stein_xor_n, Setup.gxtype, KACHEL_B+(i*2), KACHEL_H+(i3*2));
						        gxCreateVirtual(gxEMM, &hoch, Setup.gxtype, KACHEL_B+(i*2), KACHEL_H+(i3*2));
							    gxVirtualScale(&stein_and, &stein_and_n);
							    gxVirtualScale(&stein_xor, &stein_xor_n);
 		           	    		gxVirtualVirtual(&SV, Kachel_info[Kachel][4]-i, Kachel_info[Kachel][5]-i3, Kachel_info[Kachel][4]+KACHEL_B+i, Kachel_info[Kachel][5]+KACHEL_H+i3, &hoch, 0, 0, gxSET);
 		           	    		gxVirtualVirtual(&stein_and_n, 0, 0, KACHEL_B+(i*2), KACHEL_H+(i3*2)-1, &hoch, 0, 0, gxAND);
            		    		gxVirtualVirtual(&stein_xor_n, 0, 0, KACHEL_B+(i*2), KACHEL_H+(i3*2)-1, &hoch, 0, 0, gxXOR);
						        gxVirtualDisplay(&hoch, 0, 0, Kachel_info[Kachel][4]-i, Kachel_info[Kachel][5]-i3, Kachel_info[Kachel][4]+KACHEL_B+i, Kachel_info[Kachel][5]+KACHEL_H+i3, 0);
                                gxDestroyVirtual(&stein_and_n);
                                gxDestroyVirtual(&stein_xor_n);
                                gxDestroyVirtual(&hoch);
							    gxDelay((Setup.PcSpeed));
                            }
					        gxVirtualDisplay(&SV, Kachel_info[Kachel][4]-i, Kachel_info[Kachel][5]-i3, Kachel_info[Kachel][4]-i, Kachel_info[Kachel][5]-i3, Kachel_info[Kachel][4]+KACHEL_B+i, Kachel_info[Kachel][5]+KACHEL_H+i3, 0);
				            Game_Info.steine--;
                        }
                     	Game_Info.feld1 = -1;
                 	 }
                 }
             }
       }
       Game_Info.undo_zeiger++;
       if(Kachel_info[jump][8] != EXTRA_TWO && Kachel_info[Kachel][8] != EXTRA_HEIS)
           Game_Info.steine--;
	   bit_but_spiel[0].on = 1;
       pcxFileImage(gxEMM,"pic/s_liste.pcx",&pic, gxDETECT);
       gxVirtualVirtual(&pic, 119, 33, 248, 57, &liste, 119, 33, gxSET);
       gxDestroyVirtual(&pic);
       Show_mouse();
       i = Check_Jumps_out();
       if(i == 0 || Game_Info.undo_zeiger > KARTE_X*KARTE_Y+48)   // Das Spiel ist beendet
	       Spiel_aus();
	}
    else
	    Game_Info.durchlauf = 1;
    Show_mouse();
}

void FeldInMalen(int jump, int tdelay)
{
	int i, i3;

	if(Kachel_info[jump][1] == 1 && Kachel_info[jump][2] == 0)
	{
        for(i = 1, i3 = 1; i < KACHEL_B/2; i++, i3++)
        {
            if(i3 > KACHEL_H/2)
               i3 = KACHEL_H/2;
            gxVirtualDisplay(&stein[1], 0+i, 0, Kachel_info[jump][4]+i, Kachel_info[jump][5], Kachel_info[jump][4]+i+1, Kachel_info[jump][5]+KACHEL_H-1, 0);
            gxVirtualDisplay(&stein[1], KACHEL_B-i, 0, Kachel_info[jump][4]+KACHEL_B-i, Kachel_info[jump][5], Kachel_info[jump][4]+KACHEL_B-i+1, Kachel_info[jump][5]+KACHEL_H-1, 0);
            gxVirtualDisplay(&stein[1], i, 0+i3, Kachel_info[jump][4]+i, Kachel_info[jump][5]+i3, Kachel_info[jump][4]+KACHEL_B-1-i, Kachel_info[jump][5]+i3+1, 0);
            gxVirtualDisplay(&stein[1], i, KACHEL_H-i3, Kachel_info[jump][4]+i, Kachel_info[jump][5]+KACHEL_H-i3, Kachel_info[jump][4]+KACHEL_B-1-i, Kachel_info[jump][5]+KACHEL_H-i3, 0);
            gxDelay(tdelay);
        }
	}
	if(Kachel_info[jump][1] == 0)
    {
        for(i = 1, i3 = 1; i < KACHEL_B/2; i++, i3++)
        {
            if(i3 > KACHEL_H/2)
               i3 = KACHEL_H/2;
            gxVirtualDisplay(&stein[0], 0+i, 0, Kachel_info[jump][4]+i, Kachel_info[jump][5], Kachel_info[jump][4]+i+1, Kachel_info[jump][5]+KACHEL_H-1, 0);
            gxVirtualDisplay(&stein[0], KACHEL_B-i, 0, Kachel_info[jump][4]+KACHEL_B-i, Kachel_info[jump][5], Kachel_info[jump][4]+KACHEL_B-i+1, Kachel_info[jump][5]+KACHEL_H-1, 0);
            gxVirtualDisplay(&stein[0], i, 0+i3, Kachel_info[jump][4]+i, Kachel_info[jump][5]+i3, Kachel_info[jump][4]+KACHEL_B-1-i, Kachel_info[jump][5]+i3+1, 0);
            gxVirtualDisplay(&stein[0], i, KACHEL_H-i3, Kachel_info[jump][4]+i, Kachel_info[jump][5]+KACHEL_H-i3, Kachel_info[jump][4]+KACHEL_B-1-i, Kachel_info[jump][5]+KACHEL_H-i3, 0);
            gxDelay(tdelay);
        }
	}
	if(Kachel_info[jump][1] == 1 && Kachel_info[jump][2] == 1)
	{
        for(i = 1, i3 = 1; i < KACHEL_B/2; i++, i3++)
        {
            if(i3 > KACHEL_H/2)
               i3 = KACHEL_H/2;
            gxVirtualDisplay(&stein[2], 0+i, 0, Kachel_info[jump][4]+i, Kachel_info[jump][5], Kachel_info[jump][4]+i+1, Kachel_info[jump][5]+KACHEL_H-1, 0);
            gxVirtualDisplay(&stein[2], KACHEL_B-i, 0, Kachel_info[jump][4]+KACHEL_B-i, Kachel_info[jump][5], Kachel_info[jump][4]+KACHEL_B-i+1, Kachel_info[jump][5]+KACHEL_H-1, 0);
            gxVirtualDisplay(&stein[2], i, 0+i3, Kachel_info[jump][4]+i, Kachel_info[jump][5]+i3, Kachel_info[jump][4]+KACHEL_B-1-i, Kachel_info[jump][5]+i3+1, 0);
            gxVirtualDisplay(&stein[2], i, KACHEL_H-i3, Kachel_info[jump][4]+i, Kachel_info[jump][5]+KACHEL_H-i3, Kachel_info[jump][4]+KACHEL_B-1-i, Kachel_info[jump][5]+KACHEL_H-i3, 0);
            gxDelay(tdelay);
        }
    }
}

int Teleporter(int Kachel, int jump)
{
    int i, i3, i4, i5, tele;

	if(Game_Info.DemoOn == YES)
    	return(DemoInfo.undo_info[Game_Info.DemoZeiger-1][3]);
    i = rand() % (KARTE_X*KARTE_Y+1);
    for(i3 = 0; i3 < KARTE_X*KARTE_Y+5; i++, i3++)
    {
         if(i > KARTE_X*KARTE_Y)
             i = 0;
         if(Kachel_info[i][8] == EXTRA_TELEPORTER)
         {
             i4 = rand() % 3;
             for(i5 = 0; i5 < 3; i4++, i5++)
             {
                 if(i4 > 3)
                     i4 = 0;
                 switch(i4)
                 {
                     case 0:
                     // Sucht ob Oben ein Feld frei ist
                         tele = suchefeld(Kachel_info[i][4]+5, Kachel_info[i][5]-10);
                         if(tele != 999 && Kachel_info[tele][1] == 0 && tele != Kachel && tele != jump && Kachel_info[tele][8] != EXTRA_LOCH && Kachel_info[tele][8] != EXTRA_STEIN)
                             return(tele);
                         break;

                     case 1:
                         // Sucht ob Unten ein Feld frei ist
                         tele = suchefeld(Kachel_info[i][4]+5, Kachel_info[i][5]+KACHEL_H+10);
                         if(tele != 999 && Kachel_info[tele][1] == 0 && tele != Kachel && tele != jump && Kachel_info[tele][8] != EXTRA_LOCH && Kachel_info[tele][8] != EXTRA_STEIN)
                             return(tele);
                         break;

                     case 2:
                         // Sucht ob Links ein Feld frei ist
                         tele = suchefeld(Kachel_info[i][4]-10, Kachel_info[i][5]+5);
                         if(tele != 999 && Kachel_info[tele][1] == 0 && tele != Kachel && tele != jump && Kachel_info[tele][8] != EXTRA_LOCH && Kachel_info[tele][8] != EXTRA_STEIN)
                             return(tele);
                         break;

                     case 3:
                         // Sucht ob Rechts ein Feld frei ist
                         tele = suchefeld(Kachel_info[i][4]+KACHEL_B+5, Kachel_info[i][5]+5);
                         if(tele != 999 && Kachel_info[tele][1] == 0 && tele != Kachel && tele != jump && Kachel_info[tele][8] != EXTRA_LOCH && Kachel_info[tele][8] != EXTRA_STEIN)
                             return(tele);
                         break;
                 }
         	}
         }
    }
    return(-1);
}

int suchefeld(int mx, int my)
{
    int i;

	for (i = 0; Kachel_info[i][3] != 999; i++)
		if (Kachel_info[i][0] == 1 &&
			(mx > Kachel_info[i][4] && mx < Kachel_info[i][4]+KACHEL_B+1 &&
            my > Kachel_info[i][5] && my < Kachel_info[i][5]+KACHEL_H+1))
            return (i);
	return (999);
}

void feldmalen(int i, int i2)
{
    if(i == -1)
    	return;
    if(co_Mouse.Mouse_show == 1)
	  	gxVirtualVirtual(&Mouse_Back, 0, 0, MOUSE_B, MOUSE_H, &SV, co_Mouse.s_mx-M_BX, co_Mouse.s_my-M_BY, gxSET);
 	gxVirtualVirtual(&hinter_pic, Kachel_info[i][4], Kachel_info[i][5]-30, Kachel_info[i][4]+KACHEL_B-1, Kachel_info[i][5]+KACHEL_H-31, &SV, Kachel_info[i][4], Kachel_info[i][5], gxSET);
    if(Kachel_info[i][0] == 1)
    {
        if(Kachel_info[i][1] == 1)
        {
            if(Kachel_info[i][2] == 1)
            	gxVirtualVirtual(&stein[2], 0, 0, KACHEL_B-1, KACHEL_H-1, &SV, Kachel_info[i][4], Kachel_info[i][5], gxSET);
            else
            	gxVirtualVirtual(&stein[1], 0, 0, KACHEL_B-1, KACHEL_H-1, &SV, Kachel_info[i][4], Kachel_info[i][5], gxSET);
        }
        else
           	gxVirtualVirtual(&stein[0], 0, 0, KACHEL_B-1, KACHEL_H-1, &SV, Kachel_info[i][4], Kachel_info[i][5], gxSET);
    }
    if(Kachel_info[i][8] != -1)
    {
        gxVirtualVirtual(&stein_back_xor[Kachel_info[i][8]], 0, 0, KACHEL_B-1, KACHEL_H-1, &SV, Kachel_info[i][4], Kachel_info[i][5], gxAND);
        gxVirtualVirtual(&stein_back_and[Kachel_info[i][8]], 0, 0, KACHEL_B-1, KACHEL_H-1, &SV, Kachel_info[i][4], Kachel_info[i][5], gxXOR);
    }
    gxVirtualVirtual(&SV, co_Mouse.s_mx-M_BX, co_Mouse.s_my-M_BY, co_Mouse.s_mx+MOUSE_B-M_BX, co_Mouse.s_my+MOUSE_H-M_BY, &Mouse_Back, 0, 0, gxSET);
    if(i2 == 1 && co_Mouse.Mouse_show == 1)
	    SetVirtualMouse();
    gxVirtualDisplay(&SV, Kachel_info[i][4], Kachel_info[i][5], Kachel_info[i][4], Kachel_info[i][5], Kachel_info[i][4]+KACHEL_B-1, Kachel_info[i][5]+KACHEL_H-1, 0);
    if(co_Mouse.Mouse_show == 1)
	    gxVirtualDisplay(&SV, co_Mouse.s_mx-M_BX, co_Mouse.s_my-M_BY, co_Mouse.s_mx-M_BX, co_Mouse.s_my-M_BY, co_Mouse.s_mx+MOUSE_B-M_BX, co_Mouse.s_my+MOUSE_H-M_BY, 0);
}

void undo(void)
{
    GXHEADER pic;

    if(Game_Info.undo_zeiger > 0)
    {
		Game_Info.undo_zeiger--;
		Kachel_info[Game_Info.feld1][2] = 0;
        Kachel_info[Game_Info.undo_info[Game_Info.undo_zeiger][0]][1] = Game_Info.undo_info[Game_Info.undo_zeiger][1];
        Kachel_info[Game_Info.undo_info[Game_Info.undo_zeiger][0]][8] = Game_Info.undo_info[Game_Info.undo_zeiger][2];
        Kachel_info[Game_Info.undo_info[Game_Info.undo_zeiger][3]][1] = Game_Info.undo_info[Game_Info.undo_zeiger][4];
        Kachel_info[Game_Info.undo_info[Game_Info.undo_zeiger][3]][8] = Game_Info.undo_info[Game_Info.undo_zeiger][5];
        Kachel_info[Game_Info.undo_info[Game_Info.undo_zeiger][6]][1] = Game_Info.undo_info[Game_Info.undo_zeiger][7];
        Kachel_info[Game_Info.undo_info[Game_Info.undo_zeiger][6]][8] = Game_Info.undo_info[Game_Info.undo_zeiger][8];
		Kachel_info[Game_Info.undo_info[Game_Info.undo_zeiger][3]][2] = 1;
        feldmalen(Kachel_info[Game_Info.feld1][3], 1);
        Game_Info.feld1 = Game_Info.undo_info[Game_Info.undo_zeiger][3];
        Game_Info.steine = Game_Info.undo_info[Game_Info.undo_zeiger][9];
        Game_Info.durchlauf = 1;
        feldmalen(Kachel_info[Game_Info.undo_info[Game_Info.undo_zeiger][0]][3], 1);
        feldmalen(Kachel_info[Game_Info.undo_info[Game_Info.undo_zeiger][3]][3], 1);
        feldmalen(Kachel_info[Game_Info.undo_info[Game_Info.undo_zeiger][6]][3], 1);
    }
    if(Game_Info.undo_zeiger == 0)
    {
        No_Show_mouse();
        bit_but_spiel[0].on = 0;
        pcxFileImage(gxEMM,"pic/undo_off.pcx",&pic, gxDETECT);
        gxVirtualVirtual(&pic, 0, 0, 131, 24, &liste, 119, 33, gxSET);
        gxDestroyVirtual(&pic);
        gxVirtualDisplay(&liste, 0, 29, 0, 0, 640, 29, 0);
        Show_mouse();
	}
}

void neu(void)
{
    GXHEADER pic;
    int i, y1, y2;
    time_t timer;

    No_Show_mouse();
    co_Mouse.Set_Mouse_style = NORMAL;
    co_Mouse.mx = 320;
    co_Mouse.my = 240;
    grSetMousePos(co_Mouse.mx, co_Mouse.my);
    Game_Info.pixel_x[0] = 10;
    Game_Info.pixel_rich[0] = 0;
    Game_Info.pixel_x[1] = 630;
    Game_Info.pixel_rich[1] = 1;
    timer = time(NULL);
    Game_Info.zeit[1] = timer;
    Game_Info.zeit[0] = 0;
    Game_Info.undo_zeiger = 0;
    end = 0;
    Kachel_info[Game_Info.feld1][2] = 0;
    Game_Info.feld1 = -1;
    Game_Info.durchlauf = 0;
    bit_but_spiel[0].on = 0;
    pcxFileImage(gxEMM,"pic/undo_off.pcx",&pic, gxDETECT);
    gxVirtualVirtual(&pic, 0, 0, 131, 24, &liste, 119, 33, gxSET);
    gxDestroyVirtual(&pic);
    Show_mouse();
    for(i = 0; i < KARTE_X*KARTE_Y; i++)
    {
         Kachel_info[i][0] = Kachel_info_save_2[i][0];
         Kachel_info[i][1] = Kachel_info_save_2[i][1];
         Kachel_info[i][2] = 0;
         Kachel_info[i][8] = Kachel_info_save_2[i][3];
    }
    No_Show_mouse();
    if(end == 1)
         return;
    for(i = 0, Game_Info.spiel_steine = 0; i < KARTE_X*KARTE_Y; i++)
    {
    	if(Kachel_info[i][1] == 1)
    		Game_Info.spiel_steine++;
    	if(Kachel_info[i][8] == EXTRA_STEIN && Game_Info.Spielart == MODERN)
    		Game_Info.spiel_steine += 2;
    }
    Game_Info.steine = Game_Info.spiel_steine;
    gxVirtualDisplay(&liste, 0, 0, 0, 0, 640, 29, 0);
    SetFont(1, grWHITE, grBLACK, txNORMAL);
    sprintf(temp, "%d", Game_Info.zeit[0]);
    txPutString(temp, 540, 20);
    menu_back_aktuel();
    y1 = 30;
    y2 = 481;
    for(;;)
    {
        y1 += 2;
        y2 -= 2;
        gxVirtualDisplay(&SV, 0, y1, 0, y1, 640, y1, 0);
        if(y2 > 29)
            gxVirtualDisplay(&SV, 0, y2, 0, y2, 640, y2, 0);
        if(y1 > 480 && y2 < 29)
            break;
    }
    gxVirtualDisplay(&SV, 0, 30, 0, 30, 640, 30, 0);
    Show_mouse();
}

void Liste_farbe(void)
{
    static int i = 18, r = 0;
    static struct dostime_t time_save;
    struct dostime_t time;

    _dos_gettime(&time);
    if(time.hsecond != time_save.hsecond)
    {
        time_save.hsecond = time.hsecond;
        if(r == 0)
        {
            i++;
            if(i > 30)
                r = 1;
        }
        else
            if(r == 1)
            {
                i--;
                if(i < 18)
                    r = 0;
            }
    }
	Zeige_steine_zahl(i);
    zeitablauf(i);
}

void Zeige_steine_zahl(int i)
{
    SetFont(1, i, grBLACK, txNORMAL);
    sprintf(temp, "     %d  ", Game_Info.steine);
    if(Game_Info.steine > 9)
        sprintf(temp, "   %d  ", Game_Info.steine);
    if(Game_Info.steine > 99)
        sprintf(temp, "  %d  ", Game_Info.steine);
    txPutString(temp, 280, 21);
}


void zeitablauf(int i)
{
    time_t timer;

    timer = time(NULL);
    if(Game_Info.zeit[1] != timer)
    {
        Game_Info.zeit[1] = timer;
        Game_Info.zeit[0]++;
	}
    sprintf(temp, "  %d  ", Game_Info.zeit[0]);
    txPutString(temp, 540, 21);
    SetFont(1, i, grBLACK, txTRANS);
}

void Spiel(void)
{
	int i, key;

	Game_Info.Spielart = Brett_struct.Spielart;
    i = Check_Jumps_out();
    i = 1;
    if(i == 0)
    {
        Yes_No_Check("Das Brett ist unloesbar!!", 1);
        return;
    }
    No_Show_mouse();
    linien();
    SetMouseBounds(0, 0, 640, 480);
    for(i = 0; i < KARTE_X*KARTE_Y; i++)
    {
        if(Game_Info.Spielart == CLASSIC)
        {
            if(Kachel_info[i][8] == EXTRA_STEIN || Kachel_info[i][8] == EXTRA_LOCH || Kachel_info[i][8] == EXTRA_TELEPORTER || Kachel_info[i][8] == EXTRA_TWO || Kachel_info[i][8] == EXTRA_HEIS || Kachel_info[i][8] == EXTRA_OTHER)
            	Kachel_info[i][0] = 0;
        }
    	Kachel_info_save_2[i][0] = Kachel_info[i][0];
    	Kachel_info_save_2[i][1] = Kachel_info[i][1];
    	Kachel_info_save_2[i][3] = Kachel_info[i][8];
    }
    for(i = 0; liste_star[i].x != 999; i++)
        liste_star[i].ani = -1;
	pcxFileImage(gxEMM, "pic/S_liste.pcx", &liste, gxDETECT);
    Lade_hintergrund(WAHL_SET);
    gxCreateVirtual(gxEMM, &Mouse_Back2, Setup.gxtype, KACHEL_B+10, KACHEL_H+10);
    StarModule = GAMESTARS;
	Player_Setup.HELP_Y = 450;
    Show_mouse();
    neu();
    for(;;)
	{
		Liste_farbe();
        listen_ani();
        starm(&liste_star[0]);
        Move_Mouse(NO);
		if(Game_Info.DemoOn == NO)
        {
            CheckSetupOptions();
            if(bioskey(1) != 0)
            {
                key = bioskey(0);
                if(key == ALT_U_KEY)
                    Check_Key(key, &bit_but_spiel[0]);
                else
                    Check_Key(key, &no_bit_but);
                switch(key)
                {
                    case ESC_KEY:
                        co_Mouse.mx = bit_but_spiel[2].x+90;
                        co_Mouse.my = bit_but_spiel[2].y+5;
                        grSetMousePos(co_Mouse.mx, co_Mouse.my);
                        leiste();
                        break;

                    case F6_KEY:
                        SaveDemoGame();
                        break;
                }
            }
		}
        else
        {
            sprintf(temp, "Demo Mode    (%s.dem)", DemoInfo.DemoName);
    		txPutString(temp, 320, 475);
            if(bioskey(1) != 0)
            {
                key = bioskey(0);
                switch(key)
                {
                    case ESC_KEY:
                        end = 1;
                        break;
                }
            }
        	ZeigeDemo();
        }
        Check_Mouse();
        if(end != 0)
    		break;
	}
    No_Show_mouse();
    gxDestroyVirtual(&Mouse_Back2);
    gxDestroyVirtual(&liste);
	gxDestroyVirtual(&hinter_pic);
    Show_mouse();
    if(end == 1)
        end = 3;
}

void ZeigeDemo(void)
{
    if(Game_Info.DemoZeiger < DemoInfo.undo_zeiger)
    {
        gxDelay(5);
        if(Game_Info.DemoWahl == 0)
        {
            // Stein W�hlen:
            if(Kachel_info[DemoInfo.undo_info[Game_Info.DemoZeiger][0]][3] != Game_Info.feld1)
            {
                if(co_Mouse.mx == Kachel_info[DemoInfo.undo_info[Game_Info.DemoZeiger][0]][4]+(KACHEL_B/2) && co_Mouse.my == Kachel_info[DemoInfo.undo_info[Game_Info.DemoZeiger][0]][5]+(KACHEL_H/2))
                {
                	co_Mouse.mb = grLBUTTON;
		            Game_Info.DemoWahl = 1;
                }
                else
                	DemoMouse(0);
			}
            else
                Game_Info.DemoWahl = 1;
        }
        else
        {
           // Loch W�hlen:
            if(Kachel_info[DemoInfo.undo_info[Game_Info.DemoZeiger][2]][8] == EXTRA_TELEPORTER)
            {
                if(co_Mouse.mx == Kachel_info[DemoInfo.undo_info[Game_Info.DemoZeiger][2]][4]+(KACHEL_B/2) && co_Mouse.my == Kachel_info[DemoInfo.undo_info[Game_Info.DemoZeiger][2]][5]+(KACHEL_H/2))
                {
                    co_Mouse.mb = grLBUTTON;
                    Game_Info.DemoWahl = 0;
                    Game_Info.DemoZeiger++;
                }
                else
                	DemoMouse(2);
            }
            else
            {
                if(co_Mouse.mx == Kachel_info[DemoInfo.undo_info[Game_Info.DemoZeiger][1]][4]+(KACHEL_B/2) && co_Mouse.my == Kachel_info[DemoInfo.undo_info[Game_Info.DemoZeiger][1]][5]+(KACHEL_H/2))
                {
                    co_Mouse.mb = grLBUTTON;
                    Game_Info.DemoWahl = 0;
                    Game_Info.DemoZeiger++;
                }
                else
                	DemoMouse(1);
        	}
        }
    }
    if(Game_Info.DemoZeiger == DemoInfo.undo_zeiger)
    {
        No_Show_mouse();
        end = 1;
        Show_mouse();
    }
}

void DemoMouse(int i)
{
    if(co_Mouse.mx > Kachel_info[DemoInfo.undo_info[Game_Info.DemoZeiger][i]][4]+(KACHEL_B/2))
        co_Mouse.mx--;
    if(co_Mouse.mx < Kachel_info[DemoInfo.undo_info[Game_Info.DemoZeiger][i]][4]+(KACHEL_B/2))
        co_Mouse.mx++;
    if(co_Mouse.my > Kachel_info[DemoInfo.undo_info[Game_Info.DemoZeiger][i]][5]+(KACHEL_H/2))
        co_Mouse.my--;
    if(co_Mouse.my < Kachel_info[DemoInfo.undo_info[Game_Info.DemoZeiger][i]][5]+(KACHEL_H/2))
        co_Mouse.my++;
}


#include <gxlib.h>
#include <pcxlib.h>
#include <txlib.h>
#include <grlib.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <conio.h>
#include <dir.h>

#define ALT_F4_KEY 0x06b
#define RETURN_KEY 0x00d
#define BACK_KEY 0x008
#define ENTF_KEY 0x053
#define ESC_KEY 0x01b
#define ALT_F4_KEY 0x06b

extern TXHEADER Font[5];
extern int gxtype;
extern int end;
int eingabe_zahl[5];
GXHEADER back;
char temp[50];
long versuche, gesuchte_zahl;

void Menu(void);
void Check_Key(void);
void Spiel(void);
void Ende(int);
void About(void);
void SetFont(int, int, int, int);
long Eingabe_zahl(int, int, int);
void Draw_Back(void);
void Gewonnen(void);
void warte_auf_taste(void);
void Zeige_back(void);
void linien(void);

void linien(void)
{
	int i, i2;

    grSetColor(0);
    for(i = 0; i < 50; i++)
	{
        gxDelay(8);
        for(i2 = 0; i2 < 500; i2 += 25)
			grDrawLine(0, i+i2, 640, i+i2);
	}
}

void Menu(void)
{
	struct ffblk info;
    int done;

    randomize();
 	done = findfirst("back.pcx", &info, 0);
	if(done != 0)
    {
    	printf("Fehlermeldung: \n");
    	printf("Das Bild 'back.pcx' konnte nicht gefunden werden! \n\n");
    	printf("Taste dr�cken...");
        getch();
        gxCreateVirtual(gxCMM, &back, gxtype, 640, 480);
		gxClearVirtual(&back, grBLACK);
    }
    else
		pcxFileImage(gxCMM,"back.pcx",&back, gxDETECT);
    for(;;)
    {
		Zeige_back();
        SetFont(0, grWHITE, grBLACK, txTRANS);
        txPutString("1.    Spiel starten", 320, 350);
        txPutString("2.    About", 320, 380);
        txPutString("3.    Ende", 320, 410);
        end = 0;
        for(;;)
        {
            Check_Key();
            if(end != 0)
                break;
        }
        if(end == 1)
        	break;
    }
    gxDestroyVirtual(&back);
    linien();
}

void Check_Key(void)
{
	int key;

    if(kbhit())
    {
    	key = getch();
        switch(key)
        {
            case ALT_F4_KEY: case ESC_KEY:
                Ende(0);
                break;

        	case '1':
                SetFont(0, grGREEN, grBLACK, txTRANS);
                txPutString("1.    Spiel starten", 320, 350);
                gxDelay(100);
                SetFont(0, grWHITE, grBLACK, txTRANS);
                txPutString("1.    Spiel starten", 320, 350);
            	Spiel();
            	break;

        	case '2':
                SetFont(0, grGREEN, grBLACK, txTRANS);
                txPutString("2.    About", 320, 380);
                gxDelay(100);
                SetFont(0, grWHITE, grBLACK, txTRANS);
                txPutString("2.    About", 320, 380);
            	About();
            	break;

        	case '3':
                SetFont(0, grGREEN, grBLACK, txTRANS);
                txPutString("3.    Ende", 320, 410);
                gxDelay(100);
                SetFont(0, grWHITE, grBLACK, txTRANS);
                txPutString("3.    Ende", 320, 410);
                Ende(0);
            	break;
        }
    }
}

void Ende(int modus)
{
    GXHEADER pic;
	int key;
    int y, i;

    gxCreateVirtual(gxCMM, &pic, gxtype, 640, 480);
    gxDisplayVirtual(0, 0, 640, 480, 0, &pic, 0, 0);
	Draw_Back();
    SetFont(1, grWHITE, grBLACK, txTRANS);
    if(modus == 0)
    	txPutString("Wollen sie High - Low wirklich verlassen? (j/n):", 320, 40);
    if(modus == 1)
    	txPutString("Wollen sie aufgeben? (j/n):", 320, 40);
    for(;;)
    {
        if(kbhit())
        {
            key = getch();
            switch(key)
            {
                case 'j': case 'J':
                    if(modus == 0)
                    	end = 1;
                    if(modus == 1)
                    	end = 2;
                    break;

                case 'n': case 'N':
                    end = 3;
                    break;
        	}
    	}
		if(end != 0)
        	break;
    }
	if(end == 3)
    	end = 0;
    for(y = 0; y < 20; y++)
        for(i = 0; i < 480; i += 20)
        {
            gxVirtualDisplay(&pic, 0, y+i, 0, y+i, 640, y+i, 0);
            gxDelay(1);
        }
    gxDestroyVirtual(&pic);
}

void SetFont(int font, int front_color, int back_color, int modus)
{
    txSetFont(&Font[font]);
    txSetColor(front_color, back_color);
    txSetAlign(txCENTER, txCENTER);
    txSetFace(modus);
}

void Draw_Back(void)
{
    int x, y, i;

    grSetColor(BLACK);
    for(x = 640; x > 0; x -= 5)
       grDrawLine(x, 0, 640, 480);
    for(y = 0; y < 480; y += 5)
       grDrawLine(0, y, 640, 480);
    for(i = 0; i < 480; i += 2)
       grDrawLine(0, i, 640, i);
    for(i = 0; i < 640; i += 2)
       grDrawLine(i, 0, i, 480);
}

long Eingabe_zahl(int x, int y, int modus)
{
    GXHEADER pic;
	int max_zeichen = 5;
    int eingabe_zahl_info[5];
    int i, i2, hoch, key;
    unsigned long zahl = 1;

    gxCreateVirtual(gxCMM, &pic, gxtype, 640, 480);
    gxDisplayVirtual(0, 0, 640, 480, 0, &pic, 0, 0);
    SetFont(0, grWHITE, grBLACK, txTRANS);
    if(modus == 2)
	    txPutString("1", x, y);
    else
	    txPutString("0", x, y);
    for(i = 0; i < max_zeichen; i++)
    {
        eingabe_zahl[i] = 0;
        eingabe_zahl_info[i] = 0;
    }
    i = 0;
    if(modus == 1)
        eingabe_zahl[0] = 0;
    if(modus == 2)
        eingabe_zahl[0] = 1;
    for(;;)
    {
    	if(kbhit())
        {
        	key = getch();
            switch(key)
            {
            	case ALT_F4_KEY:
                    Ende(0);
                    break;

            	case ESC_KEY:
                    if(modus == 0)
                    	end = 1;
                    if(modus == 1)
                        Ende(1);
                    break;

            	case RETURN_KEY:
                    end = 3;
                	break;

            	case BACK_KEY: case ENTF_KEY:
                    i--;
                    if(i > 0)
                    {
                        eingabe_zahl[0] = eingabe_zahl[1];
                        eingabe_zahl[1] = eingabe_zahl[2];
                        eingabe_zahl[2] = eingabe_zahl[3];
                        eingabe_zahl[3] = 0;
                        eingabe_zahl_info[i] = 0;
                    }
                    else
                    {
                        if(modus == 2)
                            eingabe_zahl[0] = 1;
                        if(modus == 1)
                            eingabe_zahl[0] = 0;
                        eingabe_zahl_info[i] = 0;
                    }
                	break;

               case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9':
                    if(i > max_zeichen)
	                    i--;
                    if(i == 0)
                    {
                        if(key == '0')
                        	break;
                        eingabe_zahl[0] = key-48;
                        i++;
                        break;
                    }
                    if(i < max_zeichen-1)
                    {
                        eingabe_zahl[3] = eingabe_zahl[2];
                        eingabe_zahl[2] = eingabe_zahl[1];
                        eingabe_zahl[1] = eingabe_zahl[0];
                        eingabe_zahl[0] = key-48;
                        eingabe_zahl_info[i] = 1;
						i++;
                    }
                	break;
            }
            gxVirtualDisplay(&pic, 0, 0, 0, 0, 640, 480, 0);
            for(zahl = eingabe_zahl[0], i2 = 1, hoch = 10; i2 < i+1; i2++, hoch = hoch*10)
                if(eingabe_zahl[i2] != 0)
	                zahl += (eingabe_zahl[i2]*hoch);
				else
	                if(eingabe_zahl_info[i2] != 0)
	                    zahl = (zahl*10);
            sprintf(temp ,"%d", zahl);
            txPutString(temp, x, y);
        }
    	if(end != 0)
    		break;
    }
    gxDestroyVirtual(&pic);
    if(end == 3)
	    end = 0;
	return(zahl);
}

void Spiel(void)
{
    long max_zahl, zahl;

    gxVirtualDisplay(&back, 0, 0, 0, 0, 640, 480, 0);
    SetFont(1, grWHITE, grBLACK, txTRANS);
    txPutString("Geben sie die maximal m�gliche Zahl ein:", 320, 360);
   	max_zahl = Eingabe_zahl(320, 390, 2);
    if(end != 0)
    	return;
    gxVirtualDisplay(&back, 0, 0, 0, 0, 640, 480, 0);
    gesuchte_zahl = rand() % max_zahl;
    versuche = 0;
    for(;;)
    {
	    gxVirtualDisplay(&back, 0, 0, 0, 0, 640, 480, 0);
	    SetFont(1, grWHITE, grBLACK, txTRANS);
        if(versuche == 1)
	        sprintf(temp, "Bisher %d Versuch", versuche);
        else
	        sprintf(temp, "Bisher %d Versuche", versuche);
        txPutString(temp, 320, 310);
    	txPutString("Geben sie eine Zahl ein:", 320, 370);
   		zahl = Eingabe_zahl(520, 370, 1);
        if(end != 0)
        	break;
        if(zahl == gesuchte_zahl) // Das Spiel ist beendet
        	Gewonnen();
        if(end != 0)
        	break;
        gxVirtualDisplay(&back, 0, 0, 0, 0, 640, 480, 0);
        SetFont(1, grWHITE, grBLACK, txTRANS);
        if(zahl > gesuchte_zahl)
            sprintf(temp, "Die Zahl %d ist zu gross!", zahl);
        if(zahl < gesuchte_zahl)
            sprintf(temp, "Die Zahl %d ist zu klein!", zahl);
        txPutString(temp, 320, 370);
        versuche++;
        warte_auf_taste();
        if(versuche > 200)
        {
	        gxVirtualDisplay(&back, 0, 0, 0, 0, 640, 480, 0);
		    SetFont(1, grWHITE, grBLACK, txTRANS);
        	txPutString("Wieviele versuche brauchen sie den noch?", 320, 340);
        	txPutString("500? 50000?", 320, 360);
        	txPutString("Das Spiel wird nun zu ihrem Schutz beendet!", 320, 390);
	        warte_auf_taste();
            end = 2;
        }
        if(end != 0)
        	break;
    }
}

void warte_auf_taste(void)
{
    time_t timer;
    long save_time;
    int an = 0;

    timer = time(NULL);
    save_time = timer;
    for(;;)
    {
        timer = time(NULL);
        if(save_time != timer)
        {
            save_time = timer;
            if(an == 0)
    		{
            	SetFont(1, grWHITE, grWHITE, txTRANS);
            	an = 1;
            }
            else
            {
            	SetFont(1, grBLACK, grBLACK, txTRANS);
            	an = 0;
	        }
            txPutString("Taste dr�cken...", 320, 460);
        }
    	if(kbhit())
        	break;
    }
	getch();
}

void Gewonnen(void)
{
	Draw_Back();
    SetFont(2, grWHITE, grBLACK, txTRANS);
    txPutString("GEWONNEN", 320, 100);
    SetFont(1, grWHITE, grBLACK, txTRANS);
    sprintf(temp ,"Sie haben die Zahl %d nach", gesuchte_zahl);
    txPutString(temp, 320, 270);
    if(versuche == 1)
    	sprintf(temp ,"%d versuch gefunden!", versuche);
    else
    	sprintf(temp ,"%d versuchen gefunden!", versuche);
    txPutString(temp, 320, 290);
    if(versuche > 70)
	    txPutString("Sch�men sie sich, das war miserabel!!", 320, 330);
    else
        if(versuche < 10)
            txPutString("Nicht schlecht!", 320, 330);
        else
            if(versuche < 3)
                txPutString("Prima!! Das war erste Sahne!!!", 320, 330);
	warte_auf_taste();
    end = 2;
}

void Zeige_back(void)
{
   int y, i;

   for(y = 0; y < 20; y++)
       for(i = 0; i < 480; i += 20)
	   {
       	   gxVirtualDisplay(&back, 0, y+i, 0, y+i, 640, y+i, 0);
           gxDelay(1);
   	   }
}

void About(void)
{
    GXHEADER pic;
    int y, i;

    gxCreateVirtual(gxCMM, &pic, gxtype, 640, 480);
    gxDisplayVirtual(0, 0, 640, 480, 0, &pic, 0, 0);
	Draw_Back();
    SetFont(1, grWHITE, grBLACK, txTRANS);
    txPutString("High-Low 1997 von Christian Ofenberg", 320, 180);
    txPutString("Mozartstr. 9", 320, 230);
    txPutString("97990 Weikersheim", 320, 250);
    txPutString("Das Programm ist FREEWARE und darf", 320, 320);
    txPutString("beliebig oft weiterkopiert werden!", 320, 340);
	warte_auf_taste();
    for(y = 0; y < 20; y++)
        for(i = 0; i < 480; i += 20)
        {
            gxVirtualDisplay(&pic, 0, y+i, 0, y+i, 640, y+i, 0);
            gxDelay(1);
        }
    gxDestroyVirtual(&pic);
}

#include <gxlib.h>
#include <txlib.h>
#include <grlib.h>
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>

TXHEADER Font[5];
int gxtype = gxVGA_12;
int end;

extern int opendesk(void);
extern void closedesk(void);
extern void menu(void);

void main(void)
{
    clrscr();
    textcolor(LIGHTGREEN);
	cprintf("Hight-Low 1997 ");
    textcolor(WHITE);
    cprintf("von Christian Ofenberg");
    gxDelay(1000);
    printf("\n\nDas Programm wird geladen...\n\n\n");
    gxDelay(1000);
    end = 0;
	if(opendesk() != gxSUCCESS)
    	end = 3;
    if(end == 0)
	    menu();
    closedesk();
	printf("Danke das sie Hight-Low gespielt haben.\n");
	printf("Das Programm ist Freeware und soll so oft wie m�glich weiterkopiert werden.\n\n");
    printf("F�r m�gliche Sch�den die das Programm verursacht wird keine Haftung �bernommmen\n\n\n");
    gxDelay(2000);
    if(end == 3)
    	exit(1);
    exit(0);
}
Informationen �ber  Hight-Low 1997

	
Starten des Programmes:
Das Spielchen ist so Simpel das es eigentlich auf jedem System laufen m��te. Sollte es aber
doch Probleme beim Ausf�hren des Programmes geben, dann Starten sie ihren Computer im 
DOS Modus, klappt das auch nicht dann �rgern sie sich nicht nicht, denn viel verpassen
sie nicht! 

Zum Spiel:
Zu beginn des Spiels m�ssen sie zuerst die gr��t m�gliche Zahl eingeben, der Computer sucht
sich dann per Zufallsgenarator eine Zahl in diesem Bereich, die sie erraten m�ssen. Ist die
gesuchte Zahl gefunden ist das Spiel beendet. Wenn die Zahl nach �ber 200 Versuchen(!!) noch 
nicht gefunden wurde, so wird das Spiel beendet.

Tastatur:
Mit ALT-F4 k�nnen sie das Programm jederzeit beenden.


  Verbesserungen in der Version 1.1:
  - Es k�nnen wesentlich gr��ere Zahlen erraten werden
  - Kleine Bugs der ersten Version wurden behoben


Adresse des Autors:
	      Christian Ofenberg
	      Mozartstr. 9
 	      97990 Weikersheim
